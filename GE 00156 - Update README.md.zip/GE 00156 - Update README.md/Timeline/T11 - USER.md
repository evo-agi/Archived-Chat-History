> Your README PR #43 (→ github.com) is ready for you to merge. It's synced with trunk_dev, your text is unchanged, and CI …


Merged.
