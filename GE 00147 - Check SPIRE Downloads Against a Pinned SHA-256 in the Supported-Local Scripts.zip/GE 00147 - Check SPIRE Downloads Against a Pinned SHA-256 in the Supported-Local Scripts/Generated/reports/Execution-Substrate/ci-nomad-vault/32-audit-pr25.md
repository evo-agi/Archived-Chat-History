# 32: Audit of ES PR #25 (SPIRE downloads checked against a pinned SHA-256), head 3f68146

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 13:31Z to 13:55Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Target: draft PR #25 at `3f68146`, on trunk_dev `df46164`. The writer's report is `31-spire-pin-pr25.md`, sha256 `9315e688…e204`. The coordinator asked for no red-team.

Evidence: `32-audit-pr25-evidence/`. Its README and `SHA256SUMS.txt` list every file.

## 1. Verdict: ACCEPT, with two Low findings to fix in this PR

The change is correct. Every path that uses SPIRE now uses only bytes that were checked against the pin, and every way I found to break the CI lookup fails closed. I found no security gap.

There are two Low findings. I recommend fixing both in this PR before the merge, then a narrow re-audit, as was done after audit 26. Both fixes are written and tested in the evidence.

- **A32-1 (Low, tests).** No test proves that the checked file is the file that gets used. Five mutants survive the PR's tests:
  - setup unpacks the prebuilt source instead of the checked copy;
  - setup copies the source again after the check;
  - the proof wrapper sends the prebuilt source to the guest;
  - the wrapper copies the source again after the check;
  - the helper honours a `SPIRE_RELEASE_PIN_FILE` from the environment.

  `fix-test-proposal.diff` adds two subtests and one test that catch all five. They pass under bash 5 and bash 3.2.
- **A32-2 (Low, ordering).** An unpinned SPIRE version is refused only after setup has already changed the host. By then it has created root-owned execution roots, installed `es-runtime-support` (by default to `/usr/local/bin`), stopped any dev Vault on the port, and possibly rebuilt the Codex image. The writer's reason for not checking earlier (section 4.2: the architecture needs Go) does not apply to a check that needs no architecture. `preflight-proposal.diff` moves the refusal before every effect in both scripts, and the related tests still pass.

**What the PR does.**
- `scripts/internal/spire_release.sha256` pins the SPIRE 1.14.4 amd64 and arm64 release files.
- `scripts/internal/spire_release.sh` looks a pin up and checks a file against it.
- Setup (72), the proof wrapper (73) and CI now accept only a SPIRE file with a pinned hash. This closes P30-1 from audit 30.

**The kind of change.** Scripts, CI config, tests and docs. There is no product code.

**Gate.**
- Manifest `51b3faf5…6baf` (10 files) against base `df46164`. I took it at the start (13:32Z) and at the end (13:45Z), twice each, and every run was byte-identical to the writer's.
- trunk_dev was `df46164` and the branch was `3f68146` at both ends.
- CI run 45178489186 is green on `3f68146`, and the real-SPIRE setup test ran and passed there.

## 2. Gate data

| Item | Value |
| --- | --- |
| Manifest tool | `/opt/audit/v2.py`, sha256 `c08597e2…a3ca`, checked before each run, not edited |
| Head | `3f681465976c48e432739942494e7f2b6f47e32a` (branch `claude/project-thread-a9tcoa-spire-pin`, 2 commits: `4be8193`, `3f68146`) |
| Base | trunk_dev `df461642d2f7c9481873ca74b7eaaba368feb12f`, the squash of PR #24. Its tree `9536ec04…` equals the tree of `de1d88d`, which audit 30 accepted. |
| Remote refs | `ls-remote-open.txt` 13:31:49Z, `ls-remote-close.txt` 13:45:20Z: branch `3f68146`, trunk_dev `df46164` both times |
| Manifest | `51b3faf51fa586c750cbf9fd6032b654fb4558412134d738ee7d1c3030746baf`, 10 files: open runs 1 and 2 at 13:32:05Z, close runs 1 and 2 at 13:45:21Z, all four byte-identical to the writer's `m1.json` |
| Diff | `git diff df46164 3f68146` (sha256 `1978bcde…87d5`), byte-identical to the writer's patch. 10 files, +659/−9. |
| Writer's report | `31-spire-pin-pr25.md` sha256 `9315e688f2df877a3a059e2fba7028109761fd93c0a75851050bf104bab5e204`. Its `SHA256SUMS.txt` checks OK (19 files). |
| CI | run 45178489186, job 137705980255, "build, vet and test", success, 12:53:17Z to 13:30:09Z. It is the only check run, and there are no legacy statuses. The PR is a draft and mergeable_state is clean. |
| Kind of change | `scripts/` (2 new files, 72 and 73 changed), `.github/workflows/go.yml`, `.github/ci/go_test_gate_selftest.py` (`WORKFLOW_SHA256`), `docs_contract_test.go`, a new test file `es/app/spire_release_pin_test.go`, two docs |

Sources: `writer-provenance-check.txt`, `manifest-v2-*.json`, `delta-df46164-3f68146.diff`, `ci-run-45178489186.txt`, `ci-job-137705980255.log`.

## 3. The coordinator's questions

### 3.1 Is any SPIRE byte used that was not checked?

No, in the code as it stands. Three things can go wrong in a check like this: something is extracted before the check, a cached file is reused, or the file changes between the check and its use (TOCTOU). I traced each path.

**Setup, 72 `prepare_spire_distribution`.**
1. It looks the pin up and stops if there is none.
2. It copies or downloads the file to `<proof>/downloads/spire.tar.gz`.
3. It runs `chmod 600` on it.
4. It checks that copy with `spire_release_verify`. On a mismatch it removes the copy and stops with "refused the SPIRE distribution; nothing was unpacked".
5. It runs `tar` on the same path.

The proof root is new for each run: `mkdir -- "${PROOF_DIR}"` fails if it already exists. So no earlier file can be reused.

**Proof wrapper, 73 `stage_spire_distribution`.**
1. It stages the file at `<bootstrap>/bin/spire.tar.gz`. The bootstrap directory is created 0700 under `umask 077`.
2. It checks the staged copy and removes it on a mismatch. Every step uses an explicit `return 1`, because `run_phase` turns errexit off.
3. `copy_tooling_to_guest` then sends that same path to the guest. It is the third `limactl` call.
4. In the guest, setup (72) checks the file again against the guest's own architecture.

**CI.**
- The job downloads into a fresh `$RUNNER_TEMP/tools/download`, and the workflow has no cache step.
- `fetch` runs `sha256sum --strict` before any `unzip` or `tar`. Audit 30 reproduced this, and C5 in `ci-step-fail-closed.log` shows it again with the pin file.
- The verified tarball then reaches the real-SPIRE setup test through `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL`, and 72 checks it once more. On CI that test ran and passed. Locally, the real pinned tarball also passed the new check: the log shows "using prebuilt SPIRE distribution", then certificates, then the server start.

**Other users of SPIRE.** Only 72, 73 and the CI step download or unpack SPIRE. The Remote Alpha scripts do not.

**The window between the check and its use.** Only the same UID or root can write the checked file during that window. The setup directories are created under the default umask, and the wrapper's directory is 0700. Inference: a same-UID attacker could just as well edit the scripts, so this window is outside the threat model.

**Not covered by the tests.** The tests do not hold "the checked bytes are the bytes used". That is A32-1.

### 3.2 Can the CI lookup fail open?

No. `ci-step-fail-closed.log` runs the workflow's install step verbatim under `bash -e` (step text sha256 `b000a23d…`), with a stub `curl` that copies the real release files.

| Case | Result |
| --- | --- |
| C0 unchanged | passes, `spire.tar.gz: OK` |
| C1 no amd64 line, C2 a malformed line, C3 pin file removed, C4 helper removed, C6 the amd64 line twice | exit 1 before the SPIRE download, with no unzip and no write to `GITHUB_PATH` or `GITHUB_ENV` |
| C5 one hex digit changed | exit 1 at `sha256sum` |
| C7 C1 with the lookup forced open (`\|\| true`) | still exit 1: an empty hash gives "no properly formatted checksum lines found" |
| C8 C1 with `SPIRE_RELEASE_PIN_FILE` exported to a file that pins amd64 | ignored, and the step is refused |

The lookup sits inside an assignment from a command substitution, so its exit status ends the step under `-e`. Even if a later edit kept the step running, the empty value fails `sha256sum --strict`, so the failure is caught twice.

The docs contract and the selftest catch a fail-open edit (N06 below). The docs contract also holds the pin file's exact content (M16 and M18 in the writer's mutants).

### 3.3 Does the helper work on bash 3.2 (Mac)?

Yes, as far as bash 3.2 itself goes. `bash32-tests-3f68146.log` runs the helper and wrapper tests on bash 3.2.57. The binary comes from `bash@sha256:2556c2da…3719` and runs in an Alpine image (`bash32.Dockerfile.txt`) with no network, a read-only tree, as 1500:1600.
- `bash -n` is clean on all three scripts.
- TestSpireReleasePinLookup (14 subtests), TestSpireReleaseVerifyComparesTheFileWithItsPin and the wrapper's staging test (6 subtests) pass. The setup test (6 subtests) passes too, although 72 runs in the Linux guest, not on the Mac.
- Positive control: that bash refuses `declare -A`, `${x,,}` and `mapfile`, so the run really was bash 3.2.
- The tree with the A32-1 fix also passes there (`bash32-fix-test.log`).

The userland was BusyBox, not macOS. Inference: the macOS tools the helper uses (`dirname --`, `pwd -P`, `python3 -I`) behave the same way.

### 3.4 Should the refusal come earlier, in preflight?

Yes. This is A32-2 (section 4.2).

## 4. Findings

### A32-1 (Low, tests): no test holds that the checked bytes are the bytes used

The writer's mutants M05 and M19 prove that the copy is what gets checked, not the source. Nothing proves that the checked copy is what gets unpacked or sent to the guest, or that the pin file cannot be redirected. `mutants32-uid1500-gid1600.log` ran these mutants against the PR's tests, the docs contract and the selftest's workflow class:

| Mutant | Change | On `3f68146` | With the fix |
| --- | --- | --- | --- |
| N01 | setup unpacks the prebuilt source, not the checked copy | SURVIVED | caught |
| N02 | setup copies the source again after the check, then unpacks | SURVIVED | caught |
| N03 | wrapper sends the prebuilt source to the guest | SURVIVED | caught |
| N04 | wrapper copies the source again after the check | SURVIVED | caught |
| N05 | helper uses an exported `SPIRE_RELEASE_PIN_FILE` | SURVIVED | caught |
| N06 | CI lookup made to fail open (`\|\| true`) | caught by the docs contract and the selftest | caught |

N00, the unmutated tree, passes. Its row in the first log reads "SURVIVED" because of a labelling slip, and a note in that log explains it.

**Fix.** `fix-test-proposal.diff`, 74 lines, applied with `patch -p0` from the repository root. It changes only `es/app/spire_release_pin_test.go` and is gofmt clean.
- Setup subtest "the checked copy is the file that is unpacked". `cp` copies faithfully and then changes the prebuilt source. The subtest requires exactly one recorded `tar -xzf <proof>/downloads/spire.tar.gz -C <proof>/spire/dist` and the synthetic binaries from the original file.
- Wrapper subtest "the checked staged copy is the file sent to the guest". It uses the same `cp`, then stages the file and runs `copy_tooling_to_guest` with a `limactl` that captures each call's input. It requires the input of call 2 to equal the original tarball's bytes.
- `TestSpireReleasePinFileIgnoresTheEnvironment` exports a pin file that pins `a.tar.gz`, and requires the lookup to refuse it.

`mutants32b-fix-test-uid1500-gid1600.log` shows N01 to N06 caught, with N00 passing. `bash32-fix-test.log` shows the fixed tests passing under bash 3.2.57, and `proposal-tests-uid1500-gid1600.log` under bash 5.2.

### A32-2 (Low, ordering): an unpinned SPIRE choice is refused after host effects

**Setup (72).** `setup()` runs its preflight first: exact Go, the retained-result auth and the execution roots. Then it acts on the host and only later reaches `prepare_spire_distribution`. `late-refusal-setup-3f68146.log` runs the real setup as user ci with `SUPPORTED_LOCAL_SPIRE_VERSION=9.9.9`. It uses fake docker, nomad and vault, has the Codex build off, and uses a prebuilt runtime-support binary. It exits 1 with "no SHA-256 is pinned…", and by then:
- the proof root, its binding file and its directories exist;
- `es-results` and `es-staging` are `root:root`, provisioned through sudo;
- `es-runtime-support` is installed at the install path. The default is `/usr/local/bin/es-runtime-support`, with a sudo fallback (72 lines 20 and 347–352).

Reading the code, before that point setup also does these things:
- it stops the proof's old SPIRE and Vault processes and any `vault server -dev` on `VAULT_PORT` (`stop_vault_dev_listener`);
- it builds and retags the Codex image when that build is on.

**Proof wrapper (73).** It creates the host proof directory, metadata and closeout, then the bootstrap scratch, the source snapshot and the inputs, and cross-builds runtime support, all before `spire-stage`. `run_phase` hides the output of a phase, as the writer notes in section 4.3. So the operator sees only "supported-local proof phase failed: spire-stage", not the reason (`wrapper-refusal-message-3f68146.log`).

**Why it matters.** The old code failed at the same point or later, so this is not a regression and not a security gap. But the repository's own rule is "Exact Go preflight … must precede proof/process/workspace mutation", and the `…BeforeMutation` and `…BeforeEffects` tests enforce that pattern. A wrong version is an operator input that can be refused before any effect.

**The writer's reason does not block it.** Finding the architecture needs `go env GOARCH`, and the preflight tests use fake Go. A preflight check needs no architecture:
- 73 already knows the exact file name, `SUPPORTED_LOCAL_SPIRE_ASSET`, without Go.
- 72 can refuse a version that has no pinned line for either supported architecture. That catches a new or mistyped version. The exact check for the host's architecture stays where the file is used.

**Fix.** `preflight-proposal.diff`:
- 72 gets a new `preflight_supported_local_setup_spire_pin`, called right after `preflight_supported_local_setup_execution_roots`.
- 73 looks up `SUPPORTED_LOCAL_SPIRE_ASSET` right after `preflight_supported_local_proof_bootstrap_scope`, before `umask 077` and `create_private_host_proof_dir`.

Results:
- `late-refusal-head-vs-proposal.log`: with the proposal, both scripts refuse `9.9.9` before they create anything, and each prints the reason. On the head tree, 72 leaves the effects above, and 73 has written its host proof directory before any phase runs.
- `proposal-tests-uid1500-gid1600.log`: the supported-local, SPIRE-pin, retained-result and Go-installer tests pass on both trees (52 tests on head, 53 with both proposals). That includes both `…ExactGoPreflightBeforeMutation` tests. The root package's docs, SPIRE and supported-local tests pass too.

The proposal has no test of its own yet. The writer should add one, for example "an unpinned version is refused before the proof root exists" for setup and the same for the wrapper's host proof directory.

## 5. Other checks

**The pins match the release.** `spire-pins-vs-release.log`:
- The two release checksum files, joined, are byte-identical to `scripts/internal/spire_release.sha256`.
- The amd64 and arm64 tarballs I downloaded check OK against the pin file.
- The writer's copies of the checksum files are identical to mine.
- The arm64 archive holds `spire-server`, `spire-agent`, two configs, the README and the LICENSE.

**The helper.**
- The pin file's path is set from `BASH_SOURCE` at source time, so an exported value is overwritten (C8). A32-1 adds the test for that.
- Names with a slash or a space, malformed lines, a missing or unreadable file, no line, and two lines are all refused. The writer's 14 lookup subtests and mutants M10 to M13 hold this.
- The hash is computed with `python3 -I`.
- A locale where `[0-9a-f]` also matches upper case could at most let an upper-case pin line through. That line then fails the comparison with the lower-case hash, so the check fails closed.

**Tests per identity.** `unit-tests-3f68146-uid1500-gid1600.log` and `…uid1700-gid1700.log` ran the writer's selection as two identities.
- vet (linux and darwin), gofmt and `bash -n` are clean.
- `es/admission` and the root package's docs, SPIRE and supported-local tests are ok.
- In `es/app`, 69 of 72 tests pass. The three that fail are environmental, and the same tests fail on base `df46164` (`rerun-base32-…log` vs `rerun-es32-…log`):
  - `TestBringupScriptUpCheckDownFullProfile`: the control-plane image build fails in this container. Not traced.
  - `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup`: an artifact of my harness, because nohup ignored SIGHUP. It passes in the foreground on head and on base.
  - `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`: as ci, the real pinned tarball passes the new check, and the test then stops at "SPIRE server admin socket did not appear". As ci2 it stops at "execution-root privilege is unavailable". Both are the same on base, and the writer's run shows the same socket failure. CI ran this test and it passed.

**CI** (`ci-run-45178489186.txt`, from the whole job log):
- The token has read-only permissions.
- The step sources the helper and looks the pin up, and `spire.tar.gz: OK` follows.
- Nomad is v2.1.1 and Vault v2.2.2. The selftest ran 121 tests, OK.
- `es/app` passed in both the gated run and the observed run, with no `es/app` self-skips.
- "test gate passed: 41 packages … 4 tests skipped themselves, all of them listed", and every listed entry still fails.

## 6. Observations

- **O32-1.** Inside the wrapper, a hash mismatch still shows only "phase failed: spire-stage" and `phase-spire-stage.json`, because `run_phase` hides the output of every phase by design. With A32-2, the more likely mistake, an unpinned asset, prints its reason. A mismatch would need the guest-side message or a rerun. This is not a finding, because it is the wrapper's existing design.
- **O32-2.** `SUPPORTED_LOCAL_SPIRE_ASSET` (wrapper) and `SUPPORTED_LOCAL_SPIRE_VERSION` with the guest's architecture (setup) are separate settings. If they disagree, the guest's check refuses the file, so the result fails closed.
- **O30-1 still applies.** The SPIRE checksum file is unsigned and comes from the same place as the tarball. A pin holds the file that was reviewed, but it does not prove who published it. The helper's header comment says exactly this.

## 7. What I did not run

- No macOS. Bash 3.2 ran on a BusyBox userland.
- No Lima and no guest, and no real end-to-end run of the wrapper.
- The full `es/app` package did not run locally, only the writer's selection and the related tests. CI ran the whole package.
- I did not trace the bring-up test failure or the real-SPIRE admin-socket failure. Both are the same on base, and both passed on CI.
- No downloaded binary was executed. The SPIRE tarballs were only hashed and listed, apart from the repository's own real-SPIRE test.
- There is no test for the A32-2 proposal yet (see section 4.2).

## 8. Evidence

`32-audit-pr25-evidence/README.md` lists each file. All of them were produced in this audit's cloud container or fetched read-only, and `SHA256SUMS.txt` covers every file.
