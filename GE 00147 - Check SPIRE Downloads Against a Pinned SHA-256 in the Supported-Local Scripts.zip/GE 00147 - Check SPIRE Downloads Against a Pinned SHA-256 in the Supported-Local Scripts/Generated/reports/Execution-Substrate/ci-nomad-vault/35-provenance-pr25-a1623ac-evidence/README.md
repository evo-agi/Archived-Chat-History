# 35-provenance-pr25-a1623ac evidence

Produced by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:38Z to 14:40Z, in its cloud container (read-only on GitHub). `SHA256SUMS.txt` lists all files. Evidence for `../35-provenance-pr25-a1623ac.md`, not authority.

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch a1623ac, trunk_dev 200fd60) |
| provenance-a1623ac.txt | Commit graph; 8dc991b = 6b3e3a4 + nit-amd64-subtest.diff; a1623ac tree = merge-tree(200fd60, 8dc991b) = audit 34's tested merge tree + 8 lines; patch-ids of both sides |
| manifest-v2-a1623ac-vs-200fd60-run1.json, -run2.json | v2 manifest against 200fd60: 85d4c312…b4dc, 10 files, both runs identical |
| delta-200fd60-a1623ac.diff | `git diff 200fd60 a1623ac` |
| check35.sh.txt, tests-a1623ac-uid1500-gid1600.log | SPIRE pin and preflight tests, root docs tests, internal/testtmpdir, selftest workflow class on a1623ac, then mutant N12 (caught) |

No key, certificate body, token or config file is copied here. A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes, personal names, mail and phone shapes, and model names found nothing.
