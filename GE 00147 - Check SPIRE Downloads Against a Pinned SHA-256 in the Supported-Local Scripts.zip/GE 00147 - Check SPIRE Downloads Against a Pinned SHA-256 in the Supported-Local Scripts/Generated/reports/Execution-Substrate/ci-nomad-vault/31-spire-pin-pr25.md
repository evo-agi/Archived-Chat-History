# PR #25: the supported-local scripts check SPIRE against a pinned SHA-256

Report 31 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 12:29Z: audit 30 found (P30-1) that `scripts/72_supported_local_setup.sh` downloads SPIRE with no hash check outside CI; fix it properly as its own small PR from trunk_dev, with a pinned hash verified before use, reusing the CI pin as the single source if feasible, with a test, then audit as usual.

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft [PR #25](https://github.com/evo-agi/Execution-Substrate/pull/25). Evidence: `31-spire-pin-pr25-evidence/` next to this file, with `SHA256SUMS.txt`.

## 1. Outcome

| Item | Result |
| --- | --- |
| P30-1 | **Closed.** Setup unpacks a SPIRE release file, downloaded or prebuilt, only after its SHA-256 matches its pinned line. The proof wrapper `scripts/73_supported_local_proof.sh` had the same unchecked download on the Mac host, so it gets the same check before it stages the file for the guest. |
| Single source | **Yes.** `scripts/internal/spire_release.sha256` is the one place the SPIRE hashes live. CI reads its value from it through the same helper the scripts use. The value CI checks is unchanged. |
| Scope | Scripts, one new test file, CI config, the docs contract and docs. No product code. Two commits on trunk_dev `df46164`. |
| Tests | New tests pass on every identity. All 19 mutants are caught; one survived the first commit and led to two more subtests. |
| Manifest | **`51b3faf51fa586c750cbf9fd6032b654fb4558412134d738ee7d1c3030746baf`** (`3f68146` against `df46164`, 10 files). |
| CI | **Green**: run [45178489186](https://github.com/evo-agi/Execution-Substrate/actions/runs/45178489186) on `3f68146` (12:53Z to 13:30Z). |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-spire-pin` |
| Head | `3f681465976c48e432739942494e7f2b6f47e32a` |
| Commits | `4be8193` "Check SPIRE downloads against a pinned SHA-256 in the supported-local scripts"; `3f68146` "Test that the scripts check the copy of a prebuilt SPIRE file, not the source" |
| Base | `df461642d2f7c9481873ca74b7eaaba368feb12f` (trunk_dev after PR #24), upstream `origin/trunk_dev` |
| Manifest tool | `governed_execution_audit_patch_manifest_v2.py`, sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest | `51b3faf51fa586c750cbf9fd6032b654fb4558412134d738ee7d1c3030746baf`, 10 files, textual diff sha256 `23bd6b8a746b1120d83e6b8dfb9bd0377505de7ec0054f9f1cac2231f4e07378` |

The manifest was taken twice in one fresh clone with umask 022 and upstream pinned to `origin/trunk_dev`; both runs are byte-identical (`manifest-3f68146/`). The three new files are untracked after the tool's `reset --mixed`, so they are carried by their own entries, not by the textual diff.

## 3. The pins

`scripts/internal/spire_release.sha256` is the concatenation of the two release checksum files, byte for byte:

```
4482db434af8a3d2f4c5aeaef8912b21311411a175ce7daeb49ea17b776bcbf5  spire-1.14.4-linux-amd64-musl.tar.gz
05dd598f80b39499fd2b1660ee419cbb2d204290abe9fa0a87256177836ce7f0  spire-1.14.4-linux-arm64-musl.tar.gz
```

- Both checksum files (`spire-1.14.4-linux-<arch>-musl_sha256sum.txt`) and both tarballs were downloaded from the v1.14.4 GitHub release, and `sha256sum --check --strict` passed for both. The checksum files are in the evidence.
- The amd64 value is the one PR #24's workflow already used.
- The arm64 tarball's `spire-server` is an ARM aarch64 ELF. The amd64 one, once unpacked through the new check, reports `--version` 1.14.4.
- As audit 30 noted (O30-1), the checksum file is unsigned and comes from the same place as the release file. A pin fixes the file that was reviewed; it does not prove who published it. The helper's header comment says this.

## 4. The change

`git diff df46164 3f68146` is in the evidence as `diff-df46164-3f68146.patch`.

### 4.1 `scripts/internal/spire_release.sh` (new, sourced)

- It sets `SPIRE_RELEASE_PIN_FILE` to `spire_release.sha256` next to itself. It does this at source time, from `BASH_SOURCE`, so the environment cannot point it elsewhere.
- `spire_release_pinned_sha256 NAME` prints the pinned SHA-256 for a release file name. It refuses:
  - an empty name, or one with a slash or whitespace;
  - an unreadable pin file;
  - any malformed line anywhere in the file (each line must be exactly 64 lowercase hex digits, two spaces and a file name);
  - a name with no line, saying to add its line from the release's checksum file after checking it;
  - a name with more than one line.
- `spire_release_verify FILE NAME` hashes the file with `python3 -I` (both scripts already require python3, and it behaves the same on macOS and Linux). It fails unless the hash equals the pin, and the message names both hashes.
- It is written for bash 3.2 as well, since the proof wrapper runs on the Mac host.

There is deliberately no environment variable for an expected hash. A new version or architecture needs a reviewed line in the pin file, and the docs contract makes that change visible.

### 4.2 `scripts/72_supported_local_setup.sh`

- It sources the helper.
- `prepare_spire_distribution` looks the pin up for `spire-<version>-linux-<arch>-musl.tar.gz` before the download or copy, and stops if there is none.
- After the file lands at `<proof>/downloads/spire.tar.gz` (downloaded, or copied from `SUPPORTED_LOCAL_PREBUILT_SPIRE_TARBALL`), the script checks that copy before `tar`. On a mismatch it removes the copy and stops with "refused the SPIRE distribution; nothing was unpacked".
- The help text says what is checked.

I did not add an earlier pin check to the setup preflight. Finding the architecture needs `go env GOARCH`, and the existing preflight-order tests run with fake toolchains. The check still comes before any SPIRE byte is used, and an unpinned version fails before the download.

### 4.3 `scripts/73_supported_local_proof.sh`

- It sources the helper.
- The `spire-stage` phase of `prepare_host_tooling` now runs `stage_spire_distribution`. That looks the pin up for `SUPPORTED_LOCAL_SPIRE_ASSET` (default arm64) before the download or copy, then checks the staged copy in host bootstrap scratch. On a mismatch it removes the copy and fails the phase.
- The guest's setup then checks the transported file again, against its own architecture.
- `run_phase` hides command output, as before, so the operator sees "supported-local proof phase failed: spire-stage" and `phase-spire-stage.json` records the failure.
- A `SUPPORTED_LOCAL_SPIRE_URL` override is now only a mirror: the content still has to match the pin.

### 4.4 CI, docs contract, docs

- **`go.yml`.** The install step sources the helper and sets `spire_sha256` from the pin for `spire-1.14.4-linux-amd64-musl.tar.gz`. A failed lookup ends the step under `set -e`. `fetch` then checks the download against that value as before. The comment says where the value comes from.
- **`WORKFLOW_SHA256`** is now `9fca494c50e584a5b0025ce720b9d74929cd580c1610698133d56db3e9e8a2e1`.
- **`TestGo1265ToolchainBaselineDocsAndBuildContract`** holds:
  - the three new workflow lines, in place of the old literal fetch line;
  - the pin file's exact content, which takes over the role the literal hash in the workflow line had: a pin change has to come to this test;
  - a new sentence in `go_toolchain_baseline.md` section 10, saying CI reads the SPIRE value from the pin file that both scripts check against.
- **`.docs/supported_local_cp_consumer_runbook.md`** (transport paragraph) says the wrapper stages SPIRE only after its hash matches, and that the guest checks it again.

## 5. Validation

### 5.1 New tests (`es/app/spire_release_pin_test.go`)

- **`TestSpireReleasePinLookup`**
  - Every line of the repository's pin file is found, and both default files are pinned.
  - These are refused: an unpinned version, empty, path-like and spaced names, a duplicate line, one space, uppercase hex, a short hash, a trailing space, a comment, an empty line, a malformed line for another file, and a missing pin file.
  - A last line without a newline is read.
- **`TestSpireReleaseVerifyComparesTheFileWithItsPin`**: a file passes only against its own pin, and the exact message names both hashes. A file under a name with no pin is refused, and so is a missing file.
- **`TestSupportedLocalSetupUnpacksOnlyAPinnedSpireDistribution`**: setup's `prepare_spire_distribution`, with the architecture fixed to amd64 and tar and curl recorded.
  - A prebuilt file that does not match its pin is refused.
  - A download that does not match its pin is refused, after exactly one curl of the release URL.
  - In both cases the copy is removed, and nothing is unpacked or installed.
  - An unpinned version is refused before any curl, and before the copy.
  - A copy that differs from a pinned prebuilt source is refused (cp is replaced).
  - A pinned file is unpacked once and both binaries are installed.
- **`TestSupportedLocalProofStagesOnlyAPinnedSpireDistribution`**: the wrapper's `stage_spire_distribution` with the same cases, plus `prepare_host_tooling` failing its `spire-stage` phase and staging nothing. The runtime-support phase before it passes with a fake `go`.

### 5.2 Mutants (`mutants31.py`)

19 mutants, each on a fresh export of the commit. A run where no test ran, or where a test skipped, counts as an error, not as survived. The Docker daemon is not involved.

- **On `4be8193`:** 17 of 18 were caught. M05 survived: setup checking the prebuilt source instead of the copy it unpacks. That is a real gap, since the bytes checked must be the bytes used. `3f68146` adds the two "copy is checked" subtests.
- **On `3f68146`:** all 19 are caught, including M05 and its wrapper twin M19.
- **Rows:**
  - setup without the check, with the check after `tar`, without the lookup before the download, keeping a refused file, or checking the source;
  - the wrapper without the check, without the lookup, with the old plain `cp` in the phase, keeping a refused file, or checking the source;
  - the helper with the last duplicate winning, malformed lines skipped, a missing pin treated as empty, path names allowed, SHA-1, or the comparison removed;
  - the pin file with one digit changed, or an extra version line;
  - the workflow with the literal hash back and its self-check value recomputed.
- Logs: `mutants31-4be8193-root.log`, `mutants31-3f68146-root.log`.

### 5.3 Existing tests, per identity

`tests-3f68146.sh.txt` ran on a fresh clone of `3f68146` as 30033:30033 (sudo) and as 31500:31600 (no sudo):

- `gofmt`, and `go vet` (linux and darwin/arm64) of `./es/app` and the root package;
- `bash -n` of both scripts and the helper;
- all 72 tests in the six `es/app` files that drive scripts 72 and 73, plus the new file;
- the `es/admission` test that sources script 72;
- the root package's docs, SPIRE and supported-local tests.

With `SUPPORTED_LOCAL_TEST_SPIRE_TARBALL` set to the real amd64 tarball and Vault 2.2.2 on `PATH`, everything passes for both identities except two tests. Those two fail the same way on trunk_dev `df46164` in this container, for both identities (`base-df46164-*.log`):

- **`TestBringupScriptUpCheckDownFullProfile`**: `scripts/01_bringup.sh up` fails in this container. I did not trace why; it does not touch SPIRE.
- **`TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`**:
  - As 30033 the real pinned tarball **passes the new check and is unpacked**. The log shows setup going on to the Dockerfile, the certificates and "starting proof-scoped SPIRE server" (`real-spire-setup-test-3f68146-uid30033.log`). It then fails because the SPIRE server's admin socket does not appear in this container.
  - As 31500, with no sudo, it stops at "supported-local execution-root privilege is unavailable".
  - Both tests ran and passed on the runner in PR #24's CI.

### 5.4 Real release files

`real-release-files-3f68146.log`, from the head tree:

- **Setup:**
  - It downloads amd64 from GitHub, checks it against the real pin, unpacks it and installs it (`spire-server --version` gives 1.14.4).
  - Given the arm64 file as prebuilt on amd64, it refuses with both hashes named and leaves only `bin` and an empty `downloads`.
- **Proof wrapper staging:**
  - It downloads arm64 from GitHub and stages it (hash `05dd598f…`).
  - Given the amd64 file as prebuilt for the arm64 asset, it refuses and stages nothing.

## 6. CI

Run [45178489186](https://github.com/evo-agi/Execution-Substrate/actions/runs/45178489186) on `3f68146` passed, 12:53Z to 13:30Z. Every step succeeded:

- "Install Nomad, Vault and SPIRE": it read the SPIRE value from the pin file through the helper, and the download matched it.
- "Check the test gate": the self-check holds the new workflow hash.
- "Test": every package ran, including the four new tests. The step fails on any skip without a line, so `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` ran and passed. That means the real 1.14.4 amd64 tarball passed setup's new check on the runner, and a real SPIRE server and agent started from it.
- "Listed tests still fail".

The earlier run on `4be8193` was cancelled by the push of `3f68146`, because the workflow cancels a pull request's older run.

## 7. Not run

- No macOS run and no Lima proof run (the wrapper's real host path).
  - The wrapper's staging was run on Linux, against the real files.
  - The helper avoids bash 4 features and GNU-only tools.
  - The tests use `/bin/bash`, which on macOS is 3.2, but they were not run there.
- No full `es/app` package run in the container. CI runs every package.

## 8. Handover

Fresh audit of `df46164..3f68146` (scripts, tests, CI config and docs; no red-team, per the scope rule). If it accepts and the gate passes, I will squash-merge without David's review, per his messages of 2026-11-22 20:18Z and 20:22Z. The gate is: CI green on the head, and trunk_dev still `df46164`, or merged without conflict and re-gated.
