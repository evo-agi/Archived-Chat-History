# 35: Provenance check of ES PR #25 head a1623ac (amd64 mirror subtest + trunk_dev merge)

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:38Z to 14:40Z.
Read-only. This short check follows `34-audit-pr25-repair.md`, which accepted `6b3e3a4`. Evidence: `35-provenance-pr25-a1623ac-evidence/`.

## Result: confirmed

`a1623ac` is exactly what audit 34 accepted and tested, plus the 8-line amd64 subtest from audit 34's nit N34-1. Nothing else changed.

## What I checked (`provenance-a1623ac.txt`)

**The commit graph.**
- `a1623ac` is a merge with parents `8dc991b` (the PR side) and `200fd60` (trunk_dev, PR #23).
- `8dc991b` has a single parent, `6b3e3a4`.

**8dc991b.** I applied `34-audit-pr25-repair-evidence/nit-amd64-subtest.diff` with `patch -p1` to `git archive 6b3e3a4`. Comparing that with `git archive 8dc991b` using `diff -r` shows no difference. The commit adds 8 lines to `es/app/spire_release_pin_test.go` and nothing else.

**The merge.**
- `git merge-tree --write-tree 200fd60 8dc991b` gives tree `b6ebb054…`, which is exactly `a1623ac^{tree}`. So the merge is automatic, with no manual edit.
- Against tree `5f880745…`, the merge of `6b3e3a4` and `200fd60` that I tested in audit 34, `a1623ac`'s tree differs only by those 8 lines.
- The PR side against the new base has the same patch-id as before. The patch-id (`--stable`) of `git diff 200fd60 a1623ac` equals that of `git diff df46164 8dc991b` (`d3c3d568…`).
- The trunk_dev side brings exactly `df46164..200fd60`, which has the same patch-id (`8fca7e5c…`).

**Manifest.** The v2 recipe (sha256 `c08597e2…a3ca`, checked before each run) against base `200fd60` gives `85d4c31244f7857f3a269d338be7606fcd010153a848f812258ba7df5b12b4dc`, with 10 files and textual diff `c13d5519…f023`. Two runs at 14:38:59Z were byte-identical.

**Refs.** These were taken at 14:38:48Z (`ls-remote-open.txt`) and 14:39:57Z (`ls-remote-close.txt`). The branch was `a1623ac` and trunk_dev was `200fd60` at both points.

**Tests on `git archive a1623ac`, as 1500:1600** (`tests-a1623ac-uid1500-gid1600.log`):
- gofmt and vet are clean.
- These pass:
  - the seven SPIRE pin tests;
  - the wrapper transport test;
  - both `…ExactGoPreflightBeforeMutation` tests;
  - the setup preflight test, now with 5 subtests including "version pinned only for amd64 reaches the first effect";
  - the root package's docs, SPIRE and supported-local tests;
  - `internal/testtmpdir`;
  - the selftest's workflow class.
- With mutant N12 (`for arch in arm64`), the new amd64 subtest fails, so N34-1 is closed.

## Not checked here

CI on `a1623ac`, which was starting when I checked. The merge gate needs it green. I did not rerun the full two-identity, bash 3.2 or mutant sets from audit 34. The only test change is the one subtest, and it uses no bash 4 feature.
