# 34: Narrow re-audit of ES PR #25 repair (A32-1, A32-2), 3f68146..6b3e3a4

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:07Z to 14:40Z.
Read-only. Nothing was pushed, commented, reviewed, merged or changed on GitHub.

Target: draft PR #25 at `6b3e3a4`, on trunk_dev `df46164`, which has not changed. The writer's repair report is `33-repair-pr25.md`, sha256 `779fe9a8…b79e`. The previous head, `3f68146`, was accepted in audit 32 (`32-audit-pr25.md`) with two Low findings, A32-1 and A32-2. This re-audit covers only the delta.

Evidence: `34-audit-pr25-repair-evidence/`. Its README and `SHA256SUMS.txt` list every file.

## 1. Verdict: ACCEPT. A32-1 and A32-2 are closed.

There are no new findings. There is one nit (N34-1), which does not block the merge.

**What changed.** The delta is one commit, `6b3e3a4`.
- I applied my two diffs from audit 32 to `3f68146` myself. Compared with `6b3e3a4`, the only differences are:
  - three help-text paragraphs, one each in 72, 73 and the consumer runbook. Each now says where the refusal happens, and each statement is accurate;
  - 154 added test lines, which are the writer's two new tests.
- No line of my diffs was changed or dropped.

**A32-1 is closed.**
- My three tests are in the tree unchanged.
- My mutants N01 to N05 are caught on `6b3e3a4`: setup or the wrapper using unchecked bytes, and an exported pin file.

**A32-2 is closed.**
- Both scripts refuse an unpinned SPIRE choice before their first effect.
- The real scripts, run on `6b3e3a4` with an unpinned version, created nothing, and each printed the reason.
- The two new tests hold this order. My preflight mutants N07 to N11 and N13 to N16 are all caught: the preflight removed, moved after the first effect, made silent, made to ignore its failure, or pointed at the wrong file.

**Nit N34-1.** One mutant survives. If setup's preflight checks only arm64, a version pinned only for amd64 is wrongly refused. The writer's test covers the arm64-only case but not the mirror case. This mutant only makes the preflight stricter: it fails closed, and today's pin file pins both architectures. `nit-amd64-subtest.diff` adds the mirror subtest, which catches it. It can go in now or with the next change to this test.

**Tests.**
- The two-identity runs pass everything, apart from the bring-up test and the known execution-root privilege refusal for the identity without sudo. Section 3 gives the causes.
- All seven SPIRE pin tests, including the two new ones, pass under bash 3.2.57.
- The real-SPIRE setup test passed on `6b3e3a4` and on base `df46164` in this container. In audit 32 it had stopped at the admin socket on both.

**Gate.**
- Manifest `f00590a3…a1c6` (10 files) against base `df46164`. It was byte-identical to the writer's at the start (14:07Z) and at the end (14:35Z). The branch was `6b3e3a4` at both points.
- CI run 45189284671 on `6b3e3a4` is green (13:58Z to 14:33Z). It covered the whole `es/app` package, including the new tests and the real-SPIRE test.
- **trunk_dev moved during the audit.** It was `df46164` at 14:07Z and `200fd60` at 14:35Z, after PR #23 merged at 14:13Z. This verdict covers `6b3e3a4` on `df46164`.
  - `6b3e3a4` merges onto `200fd60` with no conflict, giving tree `5f8807459b224f055e6d3ad57c3834b71e693725`. The SPIRE pin tests, the preflight tests and the root package's docs tests all pass on that tree (section 3.8).
  - The only file both sides change is `docs_contract_test.go`, and the merge handles it automatically.
  - The update merge still needs the usual re-gate: CI, plus a manifest against `200fd60`. If the pushed merge commit has that tree, it is the tree I tested.

## 2. Gate data

| Item | Value |
| --- | --- |
| Manifest tool | `/opt/audit/v2.py`, sha256 `c08597e2…a3ca`, checked before each run, not edited |
| Head | `6b3e3a4adeb24d1f18f68c47429875c45a9dc184` (branch `claude/project-thread-a9tcoa-spire-pin`). Its parent is `3f68146`, the head accepted in audit 32. |
| Base | trunk_dev `df461642d2f7c9481873ca74b7eaaba368feb12f`, unchanged since audit 32 |
| Remote refs | `ls-remote-open.txt` 14:07Z: branch `6b3e3a4`, trunk_dev `df46164`. `ls-remote-close.txt` 14:35Z: branch `6b3e3a4`, trunk_dev **`200fd60`** (PR #23, merged 14:13Z). |
| Manifest | `f00590a37a6085245402d523678d5f6507d4c7f7510c789c29dbd3af0c81a1c6`, 10 files, textual diff `e7c239a4…f6`. Open runs 1 and 2 at 14:07:21Z and 14:07:22Z, close runs 1 and 2 at 14:35:28Z, all byte-identical to the writer's `m1.json`. |
| Delta | `git diff 3f68146 6b3e3a4` (sha256 `c79ae55c…66ef`), byte-identical to the writer's patch. 4 files, +240/−4. |
| Writer's report | `33-repair-pr25.md` sha256 `779fe9a8653a45843db188ed515bfdf258792e8135d231c7c6ccb00729d9b79e`. Its `SHA256SUMS.txt` checks OK (11 files). |
| CI | run 45189284671, job 137743033731, "build, vet and test", success, 13:58:45Z to 14:33:39Z. It is the only check run. |
| Kind of change | scripts (72 and 73: the preflight and help text), a test file, one doc. No product code. |

Sources: `writer-provenance-check.txt`, `equivalence-check.txt`, `manifest-v2-*.json`, `delta-3f68146-6b3e3a4.diff`, `ci-run-45189284671.txt`, `trunk-move-200fd60.txt`.

## 3. Checks

### 3.1 Is the delta exactly my two proposals plus the stated additions?

Yes (`equivalence-check.txt`). I started from `git archive 3f68146`, applied `preflight-proposal.diff` with `patch -p1` and `fix-test-proposal.diff` with `patch -p0`, then ran `diff -r` against `git archive 6b3e3a4`. The only differences are:
- **72 help text.** It now reads: "A SPIRE version with no line there for any supported architecture is refused before setup changes anything; one with no line for this host's architecture is refused before the download." Both halves are accurate: the preflight sits after the other preflights and before `stop_background_process`, and `prepare_spire_distribution` looks the pin up before it downloads or copies.
- **73 help text.** It now reads: "A release file with no line there is refused before the wrapper creates anything." This is accurate: the lookup comes before `umask 077` and `create_private_host_proof_dir`.
- **The consumer runbook's transport paragraph** says the same as the wrapper's help text.
- **The test file** gains one block of 154 lines, the two new tests. No line of my proposal was changed or removed.

The only callers of the pin functions are still 72 (preflight and at use), 73 (preflight and at the staging step) and the CI step.

### 3.2 The two new tests

**`TestSupportedLocalSetupRefusesAnUnpinnedSpireVersionBeforeEffects`** sources 72 and runs `setup`.
- The Go and command checks are faked, and `sudo -n true` is allowed.
- `go`, `curl`, `docker`, `nomad`, `vault` and the bridge lookup are tripwires.
- `stop_background_process`, the first effect after the preflights, is replaced by a recorder that ends the run.
- Every subtest requires that the proof root does not exist afterwards.

I checked by reading `setup()` that nothing between the preflights and `stop_background_process` has an effect:
- the bridge lookup is skipped, because the test sets the public host;
- the token and secret values are given;
- the two KV path helpers are pure.

So the recorder does sit at the first effect. Because `go` is a tripwire, the subtests also hold that the preflight needs no Go.

**`TestSupportedLocalProofRefusesAnUnpinnedSpireReleaseFileBeforeEffects`** runs the wrapper's `run` with `create_private_host_proof_dir` replaced by a recorder. That call is the first effect after `umask 077`. The test requires that neither the host proof directory nor the bootstrap scratch exists afterwards. It covers an unpinned version, an unpinned asset (riscv64), and the default asset, which must reach the effect.

Both tests are sound. The nit is the missing amd64-only mirror of the arm64-only subtest (section 4).

### 3.3 Mutants (`mutants34-uid1500-gid1600.log`)

Each row edits a copy of a separate `git archive 6b3e3a4` tree. Each run covers:
- the seven SPIRE pin tests and `TestSupportedLocalProofWrapperTransportUsesBootstrapScratch`;
- the docs contract;
- the gate selftest's workflow class.

A run where a selected test did not run or skipped counts as an error, and there were none. N00, the unmutated tree, passes.

| Row | Change | Result |
| --- | --- | --- |
| N01, N02 | setup unpacks the prebuilt source; setup copies again after the check | caught by "the checked copy is the file that is unpacked" |
| N03, N04 | the wrapper sends the prebuilt source; it copies again after the check | caught by "the checked staged copy is the file sent to the guest" |
| N05 | the helper honours an exported pin file | caught by `TestSpireReleasePinFileIgnoresTheEnvironment` |
| N06 | CI lookup `\|\| true` | caught by the docs contract and the selftest |
| N07 | setup without the preflight call | caught (new setup test) |
| N08 | setup preflight checks amd64 only | caught (arm64-only subtest) |
| N09 | setup preflight moved after `stop_vault_dev_listener` | caught |
| N13 | setup preflight refuses without printing a reason | caught |
| N14 | setup preflight failure ignored (`\|\| true`) | caught |
| N10 | wrapper without the preflight lookup | caught (new wrapper test) |
| N11 | wrapper lookup moved after `create_private_host_proof_dir` | caught |
| N15 | wrapper preflight checks the version's arm64 file instead of `SUPPORTED_LOCAL_SPIRE_ASSET` | caught (unpinned-asset subtest) |
| N16 | wrapper preflight failure ignored (`\|\| true`) | caught |
| **N12** | **setup preflight checks arm64 only** | **SURVIVED** (N34-1) |

The writer's own run (`mutants33-6b3e3a4-root.log`) reports 29 of 29 caught. Its rows overlap mine for N01 to N05 and N07 to N11. My N12 to N16 are new.

### 3.4 The real scripts on `6b3e3a4` (`late-refusal-6b3e3a4.log`)

I ran the same harness as audit 32 on a copy of the `6b3e3a4` tree, with `SUPPORTED_LOCAL_SPIRE_VERSION=9.9.9`. The only fakes were docker, nomad, vault and limactl, which just log their calls; the Codex build was off and runtime support was a prebuilt dummy.
- Setup (72) exits 1 with "no SHA-256 is pinned for the SPIRE release file spire-9.9.9-linux-amd64-musl.tar.gz: …".
- The wrapper (73) exits 1 with the arm64 message.
- No fake command was called, and nothing was created. The only directory listed is the harness's own empty install directory.

In audit 32, the `3f68146` tree had left root-owned execution roots, an installed `es-runtime-support` and a host proof directory behind.

### 3.5 Tests per identity

These ran on `git archive 6b3e3a4`, with dockerd running and SIGHUP not ignored, using the writer's 72-test selection from audit 32 plus `TestSpireReleasePinFileIgnoresTheEnvironment` and the two new tests (75 tests). The two A32-1 subtests run inside tests already in the selection.

| | 1500:1600 (sudo) | 1700:1700 (no sudo) |
| --- | --- | --- |
| gofmt, vet (linux, darwin/arm64), `bash -n` | clean | clean |
| es/app (75 tests) | 74 pass, 1 fail | 73 pass, 2 fail |
| es/admission (sources 72) | ok | ok |
| root package (docs, SPIRE, supported-local) | ok | ok |

The failures, all from this container and not from the change:
- **`TestBringupScriptUpCheckDownFullProfile`, both identities.** The control-plane image build stops at `apk add --no-cache ca-certificates` (`bringup-image-build-errors.txt`). Inference: the build cannot reach the Alpine package mirror from this container. It is the same on base, and it passed on CI for `3f68146`.
- **`TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`, 1700:1700 only.** It fails with "supported-local execution-root privilege is unavailable", the deliberate refusal for an identity without sudo. This is the same as on base and in the writer's run.

`TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup` passes here. In audit 32 it failed only because nohup made the process ignore SIGHUP.

### 3.6 The real-SPIRE test (`real-spire-6b3e3a4-and-base-uid1500-gid1600.log`)

The test passes as 1500:1600 on both `6b3e3a4` and base `df46164`. It uses the pinned amd64 release file, sha256 `4482db43…cbf5`, which audit 32 checked against the release. Setup's preflight and the check where the file is used both accepted it, and a real SPIRE server and agent came up.

In audit 32 the same test stopped at "SPIRE server admin socket did not appear" on both trees, while dockerd was running. I did not trace the difference. Guess: contention from my parallel runs at the time. The writer saw the same pass after restarting the Docker daemon.

### 3.7 Bash 3.2 (`bash32-tests-6b3e3a4.log`)

The image and setup are the same as in audit 32: bash 3.2.57, no network, the tree read-only, running as 1500:1600.
- The positive control holds: that bash refuses `declare -A`, `${x,,}` and `mapfile`.
- `bash -n` is clean on all three scripts.
- All seven SPIRE pin tests pass, including both new before-effects tests.

**Observation O34-1.** My first run mounted the tree at `/src`, directly under `/`. There, the new wrapper test fails with "supported-local retained-result auth metadata or key placement is invalid". The existing `TestRetainedResultAuditF1SetupAndWrapperRefuseUnsafeMetadataBeforeEffects` fails in the same way (`bash32-repo-at-root-6b3e3a4.log`). Inference: with the repository directly under `/`, the wrapper's parent root is `/`, and its retained-result placement check refuses the scopes that result. That behaviour predates this change, and a real checkout does not sit at `/`. At a nested path, `/w/audit/es34`, everything passes.

### 3.8 trunk_dev moved to `200fd60` (`trunk-move-200fd60.txt`, `merge-onto-200fd60-uid1500-gid1600.log`)

PR #23 merged into trunk_dev at 14:13Z as `200fd60`, on top of `df46164`. It adds a `TestMain` in every test package that runs the tests under a temporary directory without a symbolic link. Its only overlap with PR #25 is `docs_contract_test.go`.

- `git merge-tree --write-tree 200fd60 6b3e3a4` reports no conflict and gives tree `5f8807459b224f055e6d3ad57c3834b71e693725`.
- On a `git archive` of that tree, as 1500:1600, all of these pass:
  - `go vet` of `es/app` and the root package;
  - the seven SPIRE pin tests, `TestSupportedLocalProofWrapperTransportUsesBootstrapScratch` and both `…ExactGoPreflightBeforeMutation` tests;
  - the root package's docs, SPIRE and supported-local tests;
  - `internal/testtmpdir`;
  - the selftest's workflow class.

This is a local check, not the re-gate. The re-gate on the pushed update still needs CI on the new head and a manifest against `200fd60`.

## 4. Nit N34-1: no amd64-only subtest

`TestSupportedLocalSetupRefusesAnUnpinnedSpireVersionBeforeEffects` holds that a version pinned only for arm64 reaches the first effect, but there is no amd64 mirror. So mutant N12, a preflight that checks arm64 only, survives. Under N12, setup on any host would refuse a version pinned only for amd64 before any effect, although the check where the file is used would accept it on amd64.

This is a nit, not a finding, for three reasons:
- the code is correct;
- the mutant only makes the preflight stricter, so it fails closed and never accepts an unpinned file;
- the pin file pins both architectures for its only version.

**Fix.** `nit-amd64-subtest.diff` (8 lines, `patch -p1`, gofmt clean) adds "version pinned only for amd64 reaches the first effect". `nit-amd64-subtest-uid1500-gid1600.log` shows it passing on `6b3e3a4` and failing under N12. I leave the timing to the coordinator. It is test-only, and a re-check would take minutes.

## 5. CI

Run 45189284671, job 137743033731, on `6b3e3a4`: success, 13:58:45Z to 14:33:39Z (`ci-run-45189284671.txt`, `ci-job-137743033731.log`).

- The install step reads the SPIRE value from the pin file, and `spire.tar.gz: OK` follows.
- Nomad is v2.1.1 and Vault v2.2.2. The selftest ran 121 tests, OK.
- `es/app` passed in both the gated run and the observed run, with no `es/app` self-skips. So the two new before-effects tests, the A32-1 tests and the real-SPIRE setup test ran and passed.
- "test gate passed: 41 packages, 3 of them with skipped entries (16 entries); 4 tests skipped themselves, all of them listed".
- With nothing skipped, only the 3 listed `es/app` tests fail. Every listed entry still fails, as the gate requires.

This run tested the PR against `df46164`, before trunk_dev moved.

## 6. What I did not run

- No macOS and no Lima. Bash 3.2 ran on a BusyBox userland.
- The full `es/app` package did not run locally, only the selection above. CI ran the whole package green on `6b3e3a4`.
- I did not trace why the real-SPIRE test now passes where it stopped in audit 32.

## 7. Evidence

`34-audit-pr25-repair-evidence/README.md` lists each file. All of them were produced in this audit's cloud container or fetched read-only, and `SHA256SUMS.txt` covers every file.
