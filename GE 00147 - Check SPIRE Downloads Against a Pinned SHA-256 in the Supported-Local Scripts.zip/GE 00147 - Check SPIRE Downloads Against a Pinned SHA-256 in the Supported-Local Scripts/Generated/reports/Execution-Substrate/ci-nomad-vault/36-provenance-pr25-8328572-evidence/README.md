# 36-provenance-pr25-8328572 evidence

Produced by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:57Z to 14:59Z, in its cloud container (read-only on GitHub). `SHA256SUMS.txt` lists all files. Evidence for `../36-provenance-pr25-8328572.md`, not authority.

| File | What |
| --- | --- |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch 8328572, trunk_dev 792f17c) |
| provenance-8328572.txt | Commit graph; tree 63c19dbc… = merge-tree(792f17c, a1623ac) = merge-tree(792f17c, 8dc991b); no common files; both sides byte-identical to their earlier diffs; patch-ids |
| manifest-v2-8328572-vs-792f17c-run1.json, -run2.json | v2 manifest against 792f17c: 6e8edf5d…3f70, 10 files, both runs identical |
| delta-792f17c-8328572.diff | `git diff 792f17c 8328572` |
| check36.sh.txt, tests-8328572-uid1500-gid1600.log | SPIRE pin and preflight tests, root docs tests, internal/testtmpdir, selftest workflow class on 8328572, then mutant N12 (caught) |

No key, certificate body, token or config file is copied here. A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes, personal names, mail and phone shapes, and model names found nothing.
