# PR #25 repair of audit 32's A32-1 and A32-2

Report 33 of the CI Nomad/Vault track. It answers the coordinator's request of 2026-11-23 13:56Z: fix A32-1 and A32-2 in PR #25, with a test for the preflight, then a narrow re-audit by the same auditor, gate and merge.

Date: 2026-11-23. Repository: `evo-agi/Execution-Substrate`, draft [PR #25](https://github.com/evo-agi/Execution-Substrate/pull/25). Evidence: `33-repair-pr25-evidence/` next to this file, with `SHA256SUMS.txt`.

## 1. Outcome

| Item | Result |
| --- | --- |
| A32-1: no test held that the checked bytes are the bytes used | **Closed with the auditor's tests, byte for byte** (`fix-test-proposal.diff`). Setup must unpack the checked copy, and the wrapper must send the checked staged copy to the guest, even when `cp` changes the source after copying. An exported `SPIRE_RELEASE_PIN_FILE` must be ignored. |
| A32-2: an unpinned SPIRE choice was refused after host effects | **Closed with the auditor's script change** (`preflight-proposal.diff`) **and two new tests.** Setup's preflight refuses a version with no pinned file for any supported architecture. The wrapper refuses an unpinned `SUPPORTED_LOCAL_SPIRE_ASSET` before it creates its host proof directory. |
| Scope | One commit, `6b3e3a4`, on `3f68146`: the two scripts, the test file and the consumer runbook. Nothing else changed. |
| Mutants | **29 of 29 caught** on `6b3e3a4`. That covers the 19 earlier rows, audit 32's N01 to N05, and five new rows for the preflight. |
| Manifest | **`f00590a37a6085245402d523678d5f6507d4c7f7510c789c29dbd3af0c81a1c6`** (`6b3e3a4` against `df46164`, 10 files). |
| CI | Run [45189284671](https://github.com/evo-agi/Execution-Substrate/actions/runs/45189284671) on `6b3e3a4`: **success** (section 5). |

## 2. Target identity

| Field | Value |
| --- | --- |
| Branch | `claude/project-thread-a9tcoa-spire-pin` |
| Head | `6b3e3a4adeb24d1f18f68c47429875c45a9dc184` |
| Audited head | `3f681465976c48e432739942494e7f2b6f47e32a` (audit 32, ACCEPT with A32-1 and A32-2) |
| Commit since | `6b3e3a4` "Refuse an unpinned SPIRE choice before any host effect, and test the checked bytes are used" |
| Base | trunk_dev `df461642d2f7c9481873ca74b7eaaba368feb12f` (unchanged) |
| Manifest | `f00590a37a6085245402d523678d5f6507d4c7f7510c789c29dbd3af0c81a1c6`, 10 files, textual diff sha256 `e7c239a4a8b281b20f53fb1e819ed0e7e343e8cb12ca76cc116ee250f9f7edf6`; two runs in one fresh clone, byte-identical |
| Previous manifest | `51b3faf51fa586c750cbf9fd6032b654fb4558412134d738ee7d1c3030746baf` (`3f68146`) |

## 3. The change

The diff is `diff-3f68146-6b3e3a4.patch`. `fix-equals-auditor-proposals.txt` compares `6b3e3a4` with `3f68146` after applying both of the auditor's diffs:

- **Scripts:** identical to the auditor's proposal, except one help-text paragraph in each script, which now says where the refusal happens.
- **Test file:** contains every line of the auditor's proposal unchanged, plus 154 added lines, which are the two new tests below. Nothing was removed.

### 3.1 A32-2 in the scripts (the auditor's change)

- **72, setup.** `preflight_supported_local_setup_spire_pin` runs right after `preflight_supported_local_setup_execution_roots`. It passes if a line exists for `spire-<version>-linux-amd64-musl.tar.gz` or for the arm64 file. Otherwise it repeats the amd64 lookup so that the helper prints its reason, and fails.
  - No architecture is needed, so this needs no Go.
  - The exact check for the host's architecture stays in `prepare_spire_distribution`, before the download.
- **73, wrapper.** Right after `preflight_supported_local_proof_bootstrap_scope`, before `umask 077` and `create_private_host_proof_dir`, it looks up `SUPPORTED_LOCAL_SPIRE_ASSET`. The reason prints, because this runs outside `run_phase`.
- **Help text** (my addition):
  - Setup now says an unpinned version is refused before it changes anything, and an unpinned file for the host's architecture is refused before the download.
  - The wrapper now says an unpinned release file is refused before it creates anything.
  - The consumer runbook's transport paragraph says the same.

This replaces my reason in report 31, section 4.2. The auditor was right that a check needing no architecture does not depend on Go.

### 3.2 A32-1 tests (the auditor's)

- Setup subtest "the checked copy is the file that is unpacked". `cp` copies, then rewrites its source. The subtest requires one `tar -xzf <proof>/downloads/spire.tar.gz -C <proof>/spire/dist`, and the synthetic binaries from the original file.
- Wrapper subtest "the checked staged copy is the file sent to the guest". The same `cp` is used, then `copy_tooling_to_guest` runs with a capturing `limactl`. The third call's input must equal the original tarball.
- `TestSpireReleasePinFileIgnoresTheEnvironment`.

### 3.3 New tests for A32-2

**`TestSupportedLocalSetupRefusesAnUnpinnedSpireVersionBeforeEffects`** runs `setup()` with:
- the Go and command checks faked;
- `sudo -n true` allowed;
- `docker`, `nomad`, `vault`, `curl`, `go` and the bridge lookup as tripwires;
- the first effect after the preflights, `stop_background_process`, replaced by a recorder that ends the run.

It checks four cases, and every subtest also requires that the proof root does not exist:
- `9.9.9` gives exactly one line, "no SHA-256 is pinned for the SPIRE release file spire-9.9.9-linux-amd64-musl.tar.gz: …", and no recorded event.
- A malformed pin file is refused with the helper's "malformed line in …" message, and no event.
- The default version reaches the first effect.
- A version pinned only for arm64 reaches it too.

**`TestSupportedLocalProofRefusesAnUnpinnedSpireReleaseFileBeforeEffects`** runs the wrapper's `run()` with `create_private_host_proof_dir` replaced by a recorder.
- An unpinned version and an unpinned asset (riscv64) each give exactly the pin message, with no event.
- The default asset reaches the first effect.
- In every subtest, neither the host proof directory nor the host bootstrap directory exists.

## 4. Validation

### 4.1 Mutants (`mutants33.py`, `mutants33-6b3e3a4-root.log`)

Each mutant runs on a fresh export of `6b3e3a4`. The selected tests are the eight SPIRE tests and `TestSupportedLocalProofWrapperTransportUsesBootstrapScratch`, plus the docs contract for the pin-file and workflow rows. A run in which no test ran, or one skipped, counts as an error. All 29 are caught, and the unmutated rows pass.

| Rows | What they break | Caught by |
| --- | --- | --- |
| M01 to M19 | the 19 rows of report 31 | as before (M11 and M12 now also by the new preflight tests) |
| N01, N02 | setup unpacks the prebuilt source; setup copies again after the check | the auditor's setup subtest |
| N03, N04 | the wrapper sends the prebuilt source to the guest; it copies again after the check | the auditor's wrapper subtest |
| N05 | the helper takes the pin file from the environment | `TestSpireReleasePinFileIgnoresTheEnvironment` |
| N07, N08, N09 | setup without the preflight; the preflight checks amd64 only; the preflight runs after the first effect | the new setup test |
| N10, N11 | the wrapper without the preflight; the preflight runs after the host proof directory is created | the new wrapper test |

The auditor's N06 (CI lookup forced open) is M17's twin and is held by the docs contract and the self-check, as audit 32 showed. I did not repeat it.

### 4.2 Per identity

`tests-6b3e3a4.sh.txt` ran on fresh clones of `6b3e3a4`, as 30033:30033 (sudo) and as 31500:31600 (no sudo). It covers:
- `gofmt` and `go vet` (linux and darwin/arm64) of `./es/app` and the root package, all clean;
- `bash -n` of both scripts and the helper, clean;
- all 75 tests of the six `es/app` files that drive scripts 72 and 73, plus the SPIRE test file;
- the `es/admission` test that sources 72, which passes;
- the root package's docs, SPIRE and supported-local tests, which pass.

Results:
- **30033:** every test passes except `TestBringupScriptUpCheckDownFullProfile`, which fails on trunk_dev in this container too (report 31, section 5.3).
  - **`TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` passed this time.** The real pinned tarball went through the new preflight and the check at use, and a real SPIRE server and agent and the Vault dev target came up.
  - On `3f68146` and on `df46164` it had stopped at the SPIRE admin socket in this container. I did not trace what differed; the Docker daemon had been restarted just before this run.
- **31500:** the same bring-up failure, and the real-SPIRE test stops at "execution-root privilege is unavailable", the same as on trunk_dev.
- **New tests:** all pass on both identities. The execution-roots preflight calls `sudo` only for the non-root identity, so both of its paths ran.

## 5. CI

Run [45189284671](https://github.com/evo-agi/Execution-Substrate/actions/runs/45189284671) on `6b3e3a4` started at 13:58:41Z and completed at 14:33:40Z with conclusion **success**.

trunk_dev moved from `df46164` to `200fd60` at 14:13Z (PR #23, a TestMain in every test package). Under section 7's gate, the branch takes trunk_dev by a merge commit and is gated again on that head before the merge.

## 6. Not run

- No macOS run and no Lima run. Audit 32 ran the helper and wrapper tests under bash 3.2.57 on BusyBox. I did not repeat that for the two new tests. They use no bash 4 features: `[[ ]]`, functions and `printf`.

## 7. Handover

Narrow re-audit of `3f68146..6b3e3a4` by the audit-32 auditor. If it accepts and the gate passes, I mark PR #25 ready and squash-merge it without David's review (scripts, tests, CI config and docs). The gate is: CI green on the head, and trunk_dev still `df46164`, or merged without conflict and re-gated.

## 8. Merge (added 2026-11-23 15:29Z)

- Re-audit 34 (`34-audit-pr25-repair.md`): ACCEPT, A32-1 and A32-2 closed, nit N34-1. On the coordinator's request the auditor's amd64 mirror subtest went in unchanged as `8dc991b`.
- trunk_dev moved twice, and the branch took each move by a merge commit: `a1623ac` (200fd60, #23; provenance 35) and `8328572` (792f17c, #22; provenance 36). In both, the PR-side diff is byte-identical to the audited one plus the 8-line subtest, and the auditor's manifest equals mine: `6e8edf5da7e361f2ce63ecd7ed6e91e383c4c9fef823cc50f16222a85fe23f70` against 792f17c, 10 files.
- On `8328572`, the per-identity tests of section 4.2 plus `internal/testtmpdir` gave the same results as on `6b3e3a4`: everything passes except the two container-only failures.
- CI run [45199699835](https://github.com/evo-agi/Execution-Substrate/actions/runs/45199699835) on `8328572`: success. The run on `a1623ac` was cancelled when the next merge was pushed.
- Squash-merged with expectedHeadSha `8328572` as **`036d50724b499b020c5149c55ad902cfcb1482c0`** on trunk_dev. Its tree, `63c19dbc78fb363084b73d0e16dd19c0519c4bb7`, equals the accepted head's tree. The branch was deleted automatically.
