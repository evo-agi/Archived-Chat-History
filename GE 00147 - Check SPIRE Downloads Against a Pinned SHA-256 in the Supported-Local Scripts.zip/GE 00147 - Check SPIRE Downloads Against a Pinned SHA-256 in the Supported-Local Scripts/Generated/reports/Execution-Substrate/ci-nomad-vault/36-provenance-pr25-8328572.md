# 36: Provenance check of ES PR #25 head 8328572 (merge of trunk_dev 792f17c)

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:57Z to 14:59Z.
Read-only. This check follows `35-provenance-pr25-a1623ac.md`. Evidence: `36-provenance-pr25-8328572-evidence/`.

## Result: confirmed

`8328572` is `a1623ac`, which notes 34 and 35 cover, merged automatically with trunk_dev `792f17c` (PR #22). The PR's own change is unchanged.

## What I checked (`provenance-8328572.txt`)

**The commit graph.** `8328572` is a merge with parents `a1623ac` (the PR side) and `792f17c` (trunk_dev). `792f17c` is PR #22 on top of `200fd60`.

**The merge.** `git merge-tree --write-tree 792f17c a1623ac` and `git merge-tree --write-tree 792f17c 8dc991b` both give tree `63c19dbc…`, which is exactly `8328572^{tree}`. There is no manual edit.

**Overlap.** PR #22 (`200fd60..792f17c`) and PR #25 (`df46164..8dc991b`) change no file in common. PR #22 touches:
- the TLS status collector script `scripts/internal/remote_alpha_es_tls_status.py`;
- three root-package test files;
- `PLANS.md`;
- three docs.

**Both sides are unchanged, byte for byte.**
- `git diff a1623ac 8328572` is byte-identical to `git diff 200fd60 792f17c`.
- `git diff 792f17c 8328572` is byte-identical to `git diff 200fd60 a1623ac`, which has the same patch-id as before (`d3c3d568…`).

**Manifest.** The v2 recipe (sha256 `c08597e2…a3ca`, checked before each run) against base `792f17c` gives `6e8edf5da7e361f2ce63ecd7ed6e91e383c4c9fef823cc50f16222a85fe23f70`, with 10 files and textual diff `c13d5519…f023`. Two runs at 14:57:28Z were identical. This matches the writer's manifest. Its file entries are identical to the `a1623ac`-vs-`200fd60` manifest, and only the `head` field differs.

**Refs.** These were taken at 14:57Z (`ls-remote-open.txt`) and at the end (`ls-remote-close.txt`). The branch was `8328572` and trunk_dev was `792f17c` both times.

**Tests on `git archive 8328572`, as 1500:1600** (`tests-8328572-uid1500-gid1600.log`):
- gofmt and vet are clean.
- These pass:
  - the seven SPIRE pin tests, including the setup preflight test with its 5 subtests;
  - the wrapper transport test;
  - both `…ExactGoPreflightBeforeMutation` tests;
  - the root package's docs, SPIRE and supported-local tests, which now include PR #22's docs;
  - `internal/testtmpdir`;
  - the selftest's workflow class.
- Mutant N12 is still caught.

## Not checked here

CI on `8328572`, which was starting when I checked. The merge gate needs it green. I did not audit PR #22's own change, which merged to trunk_dev under its own audit.
