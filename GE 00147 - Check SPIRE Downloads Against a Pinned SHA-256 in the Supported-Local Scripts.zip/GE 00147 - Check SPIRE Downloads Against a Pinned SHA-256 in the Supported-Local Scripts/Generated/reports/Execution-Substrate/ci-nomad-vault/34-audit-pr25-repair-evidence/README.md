# 34-audit-pr25-repair evidence (ES PR #25, 3f68146..6b3e3a4)

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 14:07Z to 14:40Z.
Every file here was produced in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../34-audit-pr25-repair.md`.

## Setup

- Repository clone `/opt/audit/es`. Manifests use the v2 recipe `/opt/audit/v2.py` (sha256 `c08597e2…a3ca`, checked before each run) on branch `claude/project-thread-a9tcoa-spire-pin` at `6b3e3a4`, reset to base `df46164`, upstream re-pinned to `origin/trunk_dev`.
- Local test runs used `git archive 6b3e3a4` trees: `/home/ci/es34` as user `ci` (1500:1600, sudo) and `/home/ci2/es34` as `ci2` (1700:1700, no sudo). Runs used `env -i`, Go 1.26.5 (`GOTOOLCHAIN=local`), dockerd running, and SIGHUP not ignored. Mutants and the nit used separate copies (`/home/ci/es34m`, `/home/ci/nit34`).
- No downloaded binary was executed, apart from the repository's own real-SPIRE test, which runs the pinned SPIRE release file after its checks.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-6b3e3a4-run1.json, -run2.json, manifest-v2-close-6b3e3a4-run1.json, -run2.json | Base-pinned manifests at the start and the end: `f00590a3…a1c6` every time, byte-identical to the writer's `m1.json` |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start (14:07Z: branch 6b3e3a4, trunk_dev df46164) and the end (14:35Z: branch 6b3e3a4, trunk_dev 200fd60 after PR #23) |
| delta-3f68146-6b3e3a4.diff | `git diff 3f68146 6b3e3a4`, byte-identical to the writer's patch |
| writer-provenance-check.txt | sha256 of the writer's repair report, its `SHA256SUMS.txt` check (11 files), the manifest comparison |
| equivalence-check.txt | `3f68146` + audit 32's two proposal diffs vs `6b3e3a4`: only three help-text paragraphs and the two new tests differ |
| mutants34.py.txt, mutants34-uid1500-gid1600.log | 17 rows: N00 passes; N01 to N11 and N13 to N16 caught; N12 (setup preflight checks arm64 only) survives (nit N34-1) |
| nit-amd64-subtest.diff, nit34.sh.txt, nit-amd64-subtest-uid1500-gid1600.log | The mirror subtest for N34-1 (`patch -p1`): passes on 6b3e3a4, fails under N12 |
| late-refusal34.sh.txt, late-refusal-6b3e3a4.log | Real 72 and 73 on 6b3e3a4 with an unpinned version: both refuse, print the reason, create nothing |
| unit34.sh.txt, run-unit34.sh.txt, unit-tests-6b3e3a4-uid1500-gid1600.log, unit-tests-6b3e3a4-uid1700-gid1700.log | vet, gofmt, `bash -n`, 75 es/app tests, the es/admission test that sources 72, the root package's docs, SPIRE and supported-local tests, as two identities |
| bringup-image-build-errors.txt | The dockerd lines showing why the bring-up test fails here (`apk add` in the image build) |
| realspire34.sh.txt, real-spire-6b3e3a4-and-base-uid1500-gid1600.log | The real-SPIRE setup test on 6b3e3a4 and on base df46164: passes on both |
| bash34-tests.sh.txt, bash32-tests-6b3e3a4.log | All seven SPIRE pin tests under bash 3.2.57 (image `audit32/bash32:1` from audit 32), tree at a nested path, with a positive control |
| bash34-root.sh.txt, bash32-repo-at-root-6b3e3a4.log | The same image with the tree at `/src`: the new wrapper test and an existing retained-result test both refuse a repository directly under `/` (O34-1) |
| ci-run-45189284671.txt, ci-job-137743033731.log | The check run on 6b3e3a4, an annotated reading, and the whole job log as the GitHub API returned it |
| trunk-move-200fd60.txt | What moved trunk_dev (PR #23), the file both sides change, and `git merge-tree` of 200fd60 and 6b3e3a4: no conflict, tree 5f880745… |
| merge34.sh.txt, merge-onto-200fd60-uid1500-gid1600.log | Vet, the SPIRE pin and preflight tests, the root package's docs tests, internal/testtmpdir and the selftest's workflow class on that merged tree: all pass |

## Sensitive material

The tests and fixtures are synthetic. The retained-result key in the late-refusal run is 32 repeated characters, made for the run and removed with its workspace. No key, certificate body, token or config file is copied here.
A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes,
personal names, mail and phone shapes, and model names found nothing.
