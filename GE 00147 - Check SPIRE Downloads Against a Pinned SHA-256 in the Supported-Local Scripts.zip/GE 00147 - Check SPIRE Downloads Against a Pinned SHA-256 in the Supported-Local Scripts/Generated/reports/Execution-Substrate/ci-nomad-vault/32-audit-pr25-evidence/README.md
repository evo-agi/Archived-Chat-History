# 32-audit-pr25 evidence (ES PR #25, head 3f68146)

Written by the independent audit thread "Audit ES bring-up and CI changes", 2026-11-23, 13:31Z to 13:55Z.
Every file here was produced in the audit's cloud container or fetched read-only. `SHA256SUMS.txt` lists all files.
Nothing in this folder is authority; it is evidence for `../32-audit-pr25.md`.

## Setup

- Repository clone `/opt/audit/es`. Manifests use the v2 recipe `/opt/audit/v2.py` (sha256 `c08597e2…a3ca`, checked before each run) on branch `claude/project-thread-a9tcoa-spire-pin` at `3f68146`, reset to base `df46164`, upstream re-pinned to `origin/trunk_dev`.
- Local test runs: a tree from `git archive 3f68146` at `/home/ci/es32`, and from `df46164` at `/home/ci/base32`. They ran as user `ci` (1500:1600) and, for the unit run, also as `ci2` (1700:1700), with `env -i` and Go 1.26.5 (`GOTOOLCHAIN=local`). Mutants and the two proposals ran on copies of the head tree.
- Downloads went to their own directory and were only hashed and listed. No downloaded binary was executed, apart from the repository's own real-SPIRE test, which runs the pinned SPIRE after the new check.

## Files

| File | What |
| --- | --- |
| manifest-v2-open-3f68146-run1.json, -run2.json, manifest-v2-close-3f68146-run1.json, -run2.json | Base-pinned manifests taken at 13:32:05Z and 13:45:21Z: `51b3faf5…6baf` all four times, byte-identical to the writer's `m1.json` |
| ls-remote-open.txt, ls-remote-close.txt | Remote refs at the start and the end (branch 3f68146, trunk_dev df46164 both times) |
| delta-df46164-3f68146.diff | `git diff df46164 3f68146`, byte-identical to the writer's patch |
| writer-provenance-check.txt | sha256 of the writer's report, its `SHA256SUMS.txt` check (19 files), manifest and diff comparisons, the two commits, base tree = de1d88d tree. Commit attribution trailers are omitted. |
| ci-run-45178489186.txt, ci-job-137705980255.log | The check run on 3f68146, an annotated reading, and the whole job log as the GitHub API returned it |
| ci-step32.py.txt, ci-step-fail-closed.log | The workflow's install step run verbatim under `bash -e` with a stub curl serving the real release files: C0 passes; C1 to C8 (missing, malformed, duplicate or wrong pin, missing helper, forced fail-open, exported pin file) all fail closed |
| unit32.sh.txt, run-unit32.sh.txt, unit-tests-3f68146-uid1500-gid1600.log, unit-tests-3f68146-uid1700-gid1700.log | vet, gofmt, `bash -n`, the writer's test selection in es/app, es/admission and the root package, as two identities |
| rerun32.sh.txt, rerun-es32-uid1500-gid1600.log, rerun-base32-uid1500-gid1600.log | The three failing es/app tests re-run in the foreground on head and on base: same results |
| bash32.Dockerfile.txt, bash32-tests.sh.txt, bash32-tests-3f68146.log, bash32-fix-test.log | Helper, wrapper and setup tests under bash 3.2.57 (image from `bash@sha256:2556c2da…3719`), with a positive control, and the tree with the A32-1 fix |
| mutants32.py.txt, mutants32-uid1500-gid1600.log | Six mutants (N01 to N06) against the PR's tests, the docs contract and the selftest's workflow class: N01 to N05 survive |
| fix-test-proposal.diff | A32-1 fix, test file only (`patch -p0` from the repository root) |
| mutants32b.py.txt, mutants32b-fix-test-uid1500-gid1600.log | The same mutants with the A32-1 fix applied: all caught |
| late-refusal32.sh.txt, late-refusal-setup-3f68146.log | Real 72 setup with an unpinned SPIRE version: what exists when it refuses |
| wrapper-refusal32.sh.txt, wrapper-refusal-message-3f68146.log | What the operator sees when the wrapper's spire-stage phase refuses (the reason is hidden by `run_phase`) |
| preflight-proposal.diff | A32-2 fix, 72 and 73 (`patch -p1` from the repository root) |
| late-refusal32b.sh.txt, late-refusal-head-vs-proposal.log | 72 and 73 with an unpinned version, head tree vs the A32-2 proposal: with the proposal nothing is created |
| proposal32.sh.txt, proposal-tests-uid1500-gid1600.log | Supported-local, SPIRE-pin, retained-result and Go-installer tests and the root package's docs tests on head and on the tree with both proposals |
| spire-pins-vs-release.log, spire-1.14.4-linux-amd64-musl_sha256sum.txt, spire-1.14.4-linux-arm64-musl_sha256sum.txt | The release checksum files as downloaded, joined and compared with the pin file, the tarballs checked against it, the arm64 listing |

## Sensitive material

The tests and fixtures are synthetic. The retained-result key in the late-refusal runs is 32 repeated characters, made for the run and removed with its workspace. No key, certificate body, token or config file is copied here.
A pattern scan for private-key headers, certificates, Vault, JWT, GitHub, Anthropic and AWS token shapes,
personal names, mail and phone shapes, and model names found nothing.
