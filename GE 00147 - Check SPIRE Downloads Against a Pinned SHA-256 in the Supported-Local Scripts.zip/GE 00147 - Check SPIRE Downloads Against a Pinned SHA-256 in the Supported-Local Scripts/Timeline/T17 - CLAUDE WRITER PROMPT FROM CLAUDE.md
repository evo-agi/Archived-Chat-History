Coordinator: trunk_dev moved to 792f17c (PR 22 merged 14:53Z). Re-gate PR 25 on it before merging (merge, CI, manifest, provenance check by the auditor).
