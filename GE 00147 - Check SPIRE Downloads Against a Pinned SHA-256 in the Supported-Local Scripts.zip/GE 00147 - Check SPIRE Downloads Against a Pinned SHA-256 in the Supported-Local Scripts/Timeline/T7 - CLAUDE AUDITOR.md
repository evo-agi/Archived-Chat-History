**Audit 32 of PR #25 (SPIRE pin, fixes P30-1) at 3f68146: ACCEPT, with two Low findings.** I recommend fixing both in this PR, then a narrow re-audit. Report: [32-audit-pr25.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/32-audit-pr25.md).

The change is correct and opens no security gap. Your four questions:

- **SPIRE bytes that were never checked:** none. Setup, the proof wrapper and CI all use only bytes that passed the pin check.
- **CI lookup failing open:** it can't. All 8 cases I ran fail closed.
- **Bash 3.2:** the helper and its tests pass on bash 3.2.57. I ran that on a Linux userland, not macOS.
- **Earlier refusal:** warranted, as A32-2 below.

The pins match SPIRE's release checksum files. My manifest matches the writer's at open and close, and CI is green, including the real-SPIRE test.

- **A32-1 (tests):** no test checks that the bytes checked are the bytes actually used. Five mutants survived. I wrote a test-only fix that catches all five.
- **A32-2 (ordering):** an unpinned SPIRE version is refused only after setup has already changed the host (root-owned dirs, `/usr/local/bin` install, dev Vault stopped). I wrote a preflight fix that needs no Go. It refuses before anything is created, and existing tests still pass. It still needs its own test.

I sent both fixes to the writer thread.

STATUS: READY
