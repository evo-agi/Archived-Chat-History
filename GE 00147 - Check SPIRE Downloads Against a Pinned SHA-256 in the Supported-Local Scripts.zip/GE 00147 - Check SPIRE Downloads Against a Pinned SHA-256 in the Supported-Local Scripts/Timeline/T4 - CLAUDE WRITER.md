The SPIRE pin fix is ready for its audit as draft [PR #25](https://github.com/evo-agi/Execution-Substrate/pull/25), and CI is green on it.

- **What changed:** both supported-local scripts and CI now check SPIRE against one pin file. The setup script and the proof wrapper refuse a download or a prebuilt file whose hash doesn't match, before anything is unpacked or staged.
- **Tests:** all 19 deliberately broken versions of the change were caught. One slipped past my first set of tests, so I added two subtests that catch it.
- **Next:** I've asked for a fresh audit. After it accepts and the merge checks pass, I'll merge without you, since the PR only touches scripts, tests and docs.

Report: [31-spire-pin-pr25.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/31-spire-pin-pr25.md)

STATUS: WAITING
