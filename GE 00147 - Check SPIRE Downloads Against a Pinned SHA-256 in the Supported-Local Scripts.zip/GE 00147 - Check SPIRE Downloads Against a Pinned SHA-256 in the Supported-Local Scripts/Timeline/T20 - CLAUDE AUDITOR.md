**PR #25's latest head, 8328572, is confirmed.** It is the head I confirmed in note 35 (a1623ac), automatically merged with the new trunk_dev from PR #22. The two PRs share no files, and PR #25's own change is byte-for-byte unchanged. Note: [36-provenance-pr25-8328572.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/36-provenance-pr25-8328572.md).

My manifest against the new trunk_dev matches the writer's (`6e8edf5d…3f70`). The relevant tests pass on 8328572, including PR #22's docs.

The only thing left before the writer merges is green CI on 8328572, which was still starting when I checked. I didn't audit PR #22 itself.

STATUS: READY
