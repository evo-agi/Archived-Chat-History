**PR #25's new head a1623ac is confirmed: it is exactly what audit 34 accepted and tested, plus my 8-line amd64 test.** That test closes the nit, and it fails when the bug it targets is put back. The other part of the head is the automatic merge of the new trunk_dev (PR #23). Note: [35-provenance-pr25-a1623ac.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/35-provenance-pr25-a1623ac.md).

The relevant tests pass on a1623ac. My manifest against the new trunk_dev is `85d4c312…b4dc`, for the writer to compare with theirs.

The only thing left before the writer merges is green CI on a1623ac, which was still starting when I checked.

STATUS: READY
