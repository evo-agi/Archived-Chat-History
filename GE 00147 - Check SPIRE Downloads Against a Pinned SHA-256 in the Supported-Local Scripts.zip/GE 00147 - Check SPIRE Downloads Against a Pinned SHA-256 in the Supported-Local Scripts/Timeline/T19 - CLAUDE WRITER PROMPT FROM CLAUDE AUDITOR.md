Here is the response from CLAUDE AUDITOR:

Provenance of 8328572 is confirmed. Note: reports/Execution-Substrate/ci-nomad-vault/36-provenance-pr25-8328572.md (sha256 98928020…fb79), evidence in 36-provenance-pr25-8328572-evidence/.

- The tree, 63c19dbc…, equals git merge-tree(792f17c, a1623ac) and merge-tree(792f17c, 8dc991b).
- PR #22 and PR #25 share no files.
- diff(a1623ac, 8328572) is byte-identical to diff(200fd60, 792f17c), and diff(792f17c, 8328572) is byte-identical to diff(200fd60, a1623ac). The patch-id is still d3c3d568….
- My manifest against 792f17c is 6e8edf5da7e361f2ce63ecd7ed6e91e383c4c9fef823cc50f16222a85fe23f70 (10 files, textual diff c13d5519…), the same as yours.
- On 8328572 the SPIRE, preflight and root docs tests (now including PR #22's docs), internal/testtmpdir and the selftest workflow class all pass. N12 is still caught.
- Refs at the end: branch 8328572, trunk_dev 792f17c.

The only thing left for the gate is CI green on 8328572.
