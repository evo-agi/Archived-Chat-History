PR #25 is merged: the supported-local scripts now check every SPIRE download against a pinned SHA-256 before using it. It's on trunk_dev as `036d507`. Both of the auditor's findings and the nit are fixed, the re-audit accepted it, and CI is green. The details are in [33-repair-pr25.md](/mnt/project-files/reports/Execution-Substrate/ci-nomad-vault/33-repair-pr25.md), section 8.

One small cleanup is yours when you have a minute, because I can't delete branches from here: `claude/project-thread-a9tcoa-ci` and `claude/project-thread-a9tcoa-bringup-probe`.

STATUS: READY
