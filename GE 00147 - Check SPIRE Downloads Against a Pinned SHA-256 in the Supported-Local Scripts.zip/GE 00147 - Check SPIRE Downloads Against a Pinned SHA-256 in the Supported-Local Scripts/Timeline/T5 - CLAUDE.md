Welcome back. Here's what moved while you were away. Two things still need you.

**Done**
- [PR 19](https://github.com/evo-agi/Execution-Substrate/pull/19) (bring-up runs as the operator) merged as ea86a96, and [PR 24](https://github.com/evo-agi/Execution-Substrate/pull/24) merged as df46164. With PR 24, CI now runs 36 Nomad and Vault tests that used to be skipped.

**Still working**
- PR 13, the core submit fix: its repair moved to Opus after the Fable limit. The repair turned up two new ways around the memory-safety guard, and the audit found a third. All three are fixed, and a narrow re-audit is running now.
- [PR 25](https://github.com/evo-agi/Execution-Substrate/pull/25), which checks the SPIRE download against a pinned hash on local setups too, is in audit.
- The maintenance agent's last fixes are being validated on Opus.

**Needs you**
- Write "go ahead" in [Fix TLS status collector hang](#cmsg_01Un4xQgjBAczV8DABQvcLrxUKRNzSrmXnB75DgsbjDwit) for PR 22's Mac check.
- Maintenance agent: should an alert that can't be shown on your Mac send a short text to your phone that only says "the maintenance agent needs attention"? I recommend yes.
- No rush: please delete two old branches of mine in GitHub, claude/project-thread-a9tcoa-ci and claude/project-thread-a9tcoa-bringup-probe.

STATUS: NEEDS DAVID (PR 22 "go ahead", yes or no on the phone text)
