The provenance check on 5c2ac0b passed. Merge after CI is green and the gate holds.
