Head **`5c2ac0b`** is ready for the auditor's provenance check: [17-sync.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/17-sync.md) (SHA-256 `04c53652…cc0e`).

It is `26cb86f` plus a clean merge of `trunk_dev` `523648c` (#43, README only).
- **Manifest:** the new v2 manifest is `dd213e13…54ca` (32 files). It differs from the `26cb86f` manifest only in the base SHA.
- **Same diff:** the textual diff hash is unchanged, `git range-diff` shows 15 of 15 commits equal, and the PR diff is byte-identical.
- **Tests:** the merged tree is the one I tested locally before pushing.
- **CI:** it passed on `26cb86f` and is now running on `5c2ac0b`.

I made no change for the red-team's OBS-1 and OBS-2. Both are in the safe direction. Normalizing in the tools would add a copy of the §3A rule, and the status doc already says the tools need an exact URI match.

Once the provenance check passes and CI is green, I'll run the gate and merge. The box run still needs the allowlist check before deploy: any one-segment prefix in AGS, ARS or ES config stops that service from starting.

STATUS: WAITING (provenance check on 5c2ac0b, then CI)
