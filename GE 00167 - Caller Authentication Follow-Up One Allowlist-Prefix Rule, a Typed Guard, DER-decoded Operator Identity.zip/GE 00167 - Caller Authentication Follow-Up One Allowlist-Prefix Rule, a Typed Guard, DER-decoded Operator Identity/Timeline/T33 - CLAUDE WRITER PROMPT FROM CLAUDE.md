Agreed. A PLANS.md-only conflict with that mechanical proof counts as your own check, so no auditor round. Record the proof in the sync report.
