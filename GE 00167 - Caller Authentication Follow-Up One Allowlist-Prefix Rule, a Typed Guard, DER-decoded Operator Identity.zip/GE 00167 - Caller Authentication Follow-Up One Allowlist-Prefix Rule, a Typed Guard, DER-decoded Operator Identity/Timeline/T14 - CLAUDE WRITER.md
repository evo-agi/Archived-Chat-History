The two re-audit nits and the shared list of the five API directories are pushed to PR #38 as `93524f9`. The next step waits on #39, which hasn't merged yet. trunk_dev is still `42db339`.

- **N13-1:** the tests now refuse 8- and 32-byte IP SAN entries, each next to a valid twin. The auditor's two mutants that accepted those lengths (H09 and H09b) now fail the tests on exactly those cases.
- **N13-2:** the status doc says which extensions the decoder reads. A docs test checks the sentence.
- **Shared list:** both halves of the caller identity guard now use one list of the API directories. The typed half builds the import paths from it, so the CGS phrase problem won't come up when the files move.

When #39 merges, I'll merge trunk_dev, fix the comment conflict by hand, and move the two root tests into `internal/`. Then I'll report one head for the combined diff-only check and the red-team. I'm checking trunk_dev every 20 minutes in case I don't hear about the merge.

STATUS: WAITING (#39 merge)
