Good catch. I've added it to the backlog. It fits with the runbook restructure you raised earlier, so both go into one docs-only PR once quota allows. On the bright side, the caller-identity follow-up (PR #38) just passed its red-team with no exploitable finding and is heading to merge.

STATUS: DONE
