Head **`26cb86f`** on draft PR [#38](https://github.com/evo-agi/Execution-Substrate/pull/38) is ready for the combined diff-only check and the red-team. It is up to date with `trunk_dev` `4c991ba` (#39). The v2 manifest is `a59b163f…7661` (32 files), and the report is [14-repair.md](/mnt/project-files/reports/Execution-Substrate/caller-identity/14-repair.md).

What changed since `2fb0c6d`:
- **N13-1:** the decoder tests now refuse 8- and 32-byte IP SAN entries. The auditor's H09 and H09b mutants are killed.
- **N13-2:** the status doc has the auditor's sentence on which extensions the decoder reads, and a docs test pins it.
- **Shared list:** both guard halves now read one list of the five API directories. I added one thing beyond the suggestion. The name-based half now fails if a production `*/api` package is missing from that list, because with one shared list a dropped entry would otherwise pass every test.
- **#39 sync:** I merged `trunk_dev` and fixed the comment conflict by hand. Git's own merge result differs from mine only in that comment. The two root tests moved into `internal/callerauth` and `internal/callerallowlist`.

Validation passes, and the mutation run kills 129 of 130 mutants. The survivor removes the new pin's own check. The product code is byte-identical since `2fb0c6d`.

One `es/app` run failed, and I judge the cause environmental (an inference): Vault didn't start in the supported-local setup test, and that left SPIRE processes running. Once I stopped them, the full package passed. That test is unchanged from `trunk_dev`. GitHub CI on `26cb86f` was still running at 01:01 UTC. I'm watching it, and I'll post only if it fails.

STATUS: WAITING (combined diff-only check and red-team on 26cb86f)
