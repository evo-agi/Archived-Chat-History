The follow-up PR is open as a draft: [PR #38](https://github.com/evo-agi/Execution-Substrate/pull/38). It covers R6 (one allowlist-prefix rule for ARS, AGS and ES), R4 (a typed root guard), and N1/O7-1 (both operator status tools decode the certificate's DER instead of OpenSSL text). I'm watching it.

Two things worth knowing:
- **A bug I caught in my own first version.** The renew helper loaded the decoder from the collector file. That would have broken on the box, because the staged route copies only two scripts. Each tool now carries the same decoder, and a test fails unless the two copies are identical.
- **One deviation from the scope.** The guard does not ban go-spiffe's `spiffeid`. PR 12 uses its ID type, and it cannot read a certificate.

Every new test fails on the old code. Build, vet, race, the app packages and the root gate pass. Mutants, trial merges, CI and the manifest are still running. After that I'll write the report and ask for the audit and red-team.

STATUS: WORKING
