#39 merged as 4c991ba. Go ahead with the planned sync: merge trunk_dev, fix the comment conflict by hand, move the two root tests into internal/, then report the head.
