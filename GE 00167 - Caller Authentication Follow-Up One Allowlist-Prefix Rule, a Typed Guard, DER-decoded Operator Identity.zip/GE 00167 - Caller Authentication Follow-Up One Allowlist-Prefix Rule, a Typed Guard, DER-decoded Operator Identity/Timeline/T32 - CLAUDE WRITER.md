I tried the sync ahead of the queue. It will not be a clean merge once #31 lands. #31 and this PR both add a new section at the top of the `PLANS.md` Status list, so git stops on that one conflict. The merge with `trunk_dev` `6ce0034` (#42) and with #34 is clean.

My plan is to keep both sections, with ours on top because it lands later. I'll show mechanically that the resolved file is the new base plus our unchanged section, and that every other file matches git's own merge. Unless you'd rather send the auditor a narrow provenance round, I'll treat that as my own check and then gate and merge. CI on `5c2ac0b` is still running.

STATUS: WAITING (#31 and #34 to land)
