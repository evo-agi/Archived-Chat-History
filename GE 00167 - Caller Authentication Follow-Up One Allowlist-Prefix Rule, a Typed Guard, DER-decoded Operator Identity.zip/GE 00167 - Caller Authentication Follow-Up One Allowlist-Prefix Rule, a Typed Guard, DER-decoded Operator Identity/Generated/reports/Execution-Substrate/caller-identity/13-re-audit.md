# ES PR #38 narrow re-audit 13: the audit 11 repair (900d4eb..2fb0c6d)

- Pull request: evo-agi/Execution-Substrate #38 (draft), branch `claude/project-thread-i9yve2`.
- Audited head: `2fb0c6dc17bfb76e419ea31d26171a2c2287e6eb`, tree `9d829e76…`.
- Base: `trunk_dev` `725c97a9663df060e49270fce3bc8c904a88986e`.
- Previous audit: `11-audit.md` at `900d4eb`.
- Writer's report: `12-repair.md` (sha256 `7ced8b9f…95ab`).
- Scope (coordinator, 23:50Z):
  - A11-1 to A11-4;
  - the optional E16, F03 and fixture items;
  - the PR #39 merge-order plan in §6 of `12-repair.md`;
  - CI.
- Read-only: nothing was pushed, commented or merged. No subagents were used.

## 0. Verdict in plain words

**ACCEPT at `2fb0c6d`, with two small nits for this PR. Each is a test case or a doc sentence.**

All four audit 11 findings are closed:
- **A11-1:** the typed guard now catches go-spiffe's `spiffetls` and `spiffegrpc` peer readers, and the JWT-SVID readers.
- **A11-2:** linux/arm64 is a guard target, with a per-platform self-test.
- **A11-3 and A11-4:** I ran 43 crafted certificates through both status tools and through ES over real mutual TLS.
  - The tools at `900d4eb` said pass for 15 certificates that ES refuses.
  - At `2fb0c6d`, one such certificate is left. It is the unknown-critical-extension one, which `openssl verify` (the tools' trust check) refuses, as in audit 11.

The three optional items are done, and E16 is killed.

Nothing regressed:
- Whole module, `725c97a` against `2fb0c6d`: 7,157 shared test verdicts, 0 different, 93 new ones, all passing. The same 16 container-only failures appear on both sides.
- GitHub CI run 134 on `2fb0c6d` passed.

The PR #39 merge plan is right, with two notes for whoever merges second:
- **Step 1:** a blind union of the comment conflict leaves a broken sentence, so merge it by hand.
- **Step 3:** naming the API packages by directory works. I tested it.

Nits (project rule: low nits are fixed in the PR; a diff-only check of them is enough, no new re-audit):
- **N13-1 (test gap):** no test refuses an 8- or 32-byte iPAddress SAN entry. Two of my mutants that accept those lengths survive. Go refuses both lengths.
- **N13-2 (doc):** the status doc does not say that other extensions are not decoded. A leaf that Go refuses for a malformed certificatePolicies or authorityInfoAccess can still show identity pass.

## 1. Provenance (PASS)

Log: `provenance/provenance-13.log`; script: `provenance/provenance-13.sh.txt`.

- Heads:
  - the branch and `refs/pull/38/head` are both `2fb0c6d`;
  - `trunk_dev` is `725c97a`, which is also the merge base;
  - `900d4eb` is an ancestor of the tip.
- `trunk_dev` moved `fdfa3bc..725c97a` through:
  - `400ff7f` (#36, README);
  - `0aa4a2b` (#33, `es/config` tests);
  - `725c97a` (#41, `runtimeconfig/v1` tests).
- First-parent commits after `900d4eb`:
  - six repair commits: `3a2cd86`, `257d585`, `02182f8`, `33b67d1`, `30c7e5f`, `f6bdde8`;
  - three merges: `91243f5`, `031c02e`, `2fb0c6d`.
  - Each merge's tree equals `git merge-tree` of its two parents.
- The repair delta, excluding the five trunk files, has 11 files and sha256 `ed2f05c6…b580`. It is byte-identical to the writer's `delta-900d4eb.diff`.
- No repair commit touches a trunk file.
- v2 manifest, run with the operating-protocol tool (sha256 `c08597e2…a3ca`) and the v2 recipe:
  - two runs are identical, and byte-identical to the writer's `manifest-v2-2fb0c6d.json` and `-run2.json`;
  - `textual_diff_sha256` `51af9bbd…ad1c`, `manifest_sha256` `ef001237…aa98`, 32 files.
- `12-evidence/SHA256SUMS` checks out: 101 entries OK.

## 2. A11-1: go-spiffe peer readers (CLOSED)

The guard's import rule is now a closed list:
- Allowed: `spiffeid`, `workloadapi`, `svid/jwtsvid` and `proto/spiffe/workload`.
- Everything else under `github.com/spiffe/go-spiffe/v2/` is refused.
- New rule: a `types.Func` use of `jwtsvid.ParseAndValidate`/`ParseInsecure`, `workloadapi.ValidateJWTSVID` or the proto client's `ValidateJWTSVID` is refused.

Probes on the repair head (`runs/guards-probes.log`; sources in `probes/guard/`):

| Probe tree | What it adds | Typed guard, each of the 3 targets |
|---|---|---|
| g38ra | the red-team's `rtprobe.go` + `zz_rtprobe.go` | 6 findings (as at 900d4eb) |
| g38rb | my audit 11 probe that reads the peer ID over real mTLS with `spiffetls` and `spiffegrpc/grpccredentials`, plus a new probe that imports `bundle/jwtbundle` and calls `jwtsvid.ParseAndValidate` through a function value | 4 findings: the spiffetls, grpccredentials and jwtbundle imports, and the ParseAndValidate use |

At `900d4eb`, both guards passed the same spiffetls probe (audit 11, `11-audit-evidence`). The name-based guard still passes all probes, as designed.

**Judgment call 6 (JWT-SVID readers refused): agree.**
- A peer identity read from a bearer token is another copy of the identity rule.
- No production code uses those readers. The only production go-spiffe imports are in `es/runtimehelper/helper.go` and `cmd/es-workload-api-mock/main.go`, and the guard passes on the head.
- PRs 12 and 40 add only allowed imports and call none of the readers (§9).

## 3. A11-2: linux/arm64 (CLOSED)

- `callerIdentityBuildTargets` lists linux/amd64, linux/arm64 and darwin/arm64.
- The self-test runs once per target, with a probe file per platform, and fails if any platform's probe goes uncaught.
- **Probe g38rc** adds `es/admission/zz_issuerprobe_linux_arm64.go`. Results:
  - the linux_arm64 run has 4 findings;
  - the other two targets have none, as expected;
  - at `900d4eb`, both guards passed this probe (audit 11).
- **`TestCallerIdentityTypedGuardCoversTheScriptsBuildTargets`** scans `scripts/` for `GOOS=`/`GOARCH=` literals and parses `control_plane_target_arch`. My mutants F05 (drop linux/arm64), F05b (drop darwin/arm64) and F19b (GOOS scan finds nothing) are killed.

## 4. A11-3 and A11-4: the status tools refuse what ES refuses (CLOSED)

**Code reading.** I checked the shared decoder (`client-certificate-der-decoder`, identical in both tools) against Go's `crypto/x509` parser, rule by rule:
- the version and TBS layout (extensions only in v3, after optional primitive `[1]`/`[2]` unique IDs);
- SAN per-type checks: rfc822Name and dNSName IA5, iPAddress 4 or 16 bytes, constructed entries ignored;
- the extension-identifier encoding, using the same base-128 limits as `readBase128Int`;
- basicConstraints: BOOLEAN only `00`/`FF`;
- keyUsage: padding rules, keyCertSign = `0x04` and cRLSign = `0x02` of the first byte;
- extKeyUsage: an empty list or anyExtendedKeyUsage allows client auth, as in `checkChainForKeyUsage`.

Every rule matches. The places where the decoder is stricter are listed in §10, and all of them refuse.

The collector judges the URI first, then `identity_not_end_entity`, then `identity_not_for_client_auth` (failure class `identity_mismatch`). The renew helper adds `end_entity` and `client_auth_usage`, with one blocker each. The Mac-side status checker knows both new labels.

**Independent comparison.**
- 43 certificates, crafted and signed by a probe CA (`probes/dercraft/zz_audit_der2_test.go.txt`; public PEMs in `certs/`; tool probe `probes/dercraft/der_probe2.py.txt`):
  - the 19 from audit 11;
  - 24 new ones covering the new rules: anyEKU, empty and unknown EKU, cRLSign, explicit cA FALSE, negative and non-boolean basicConstraints, keyUsage padding, version encodings, unique IDs, constructed entries, trailing fields.
- Each certificate was presented to `callerauth.CallerFromConnectionState` over real mutual TLS.
- Each was also run through:
  - the collector's `classify_identity`, using its real `run_command` and `openssl`;
  - the renew helper's decoder copy with the helper's classification order;
  - `openssl verify` without and with `-purpose sslclient`.
- The `900d4eb` tools were run on the same set.
- Full table: `runs/der2-table.md`.

These are the rows that changed. At `900d4eb` both tools said pass for every one of them, and ES refuses every one:

| Certificate | ES over mTLS | 2fb0c6d collector / renew |
|---|---|---|
| v1 with extensions, v2 with extensions | 401 no URI SAN | malformed / malformed |
| SAN iPAddress of 5 bytes, rfc822Name with byte 0x80 | TLS refused (Go parse) | malformed / malformed |
| version INTEGER 3 (v4) | TLS refused (Go parse) | malformed / malformed |
| extKeyUsage with a non-minimal OID | TLS refused (Go parse) | malformed / malformed |
| basicConstraints BOOLEAN `01`, negative pathLen | TLS refused (Go parse) | malformed / malformed |
| keyUsage with set padding bits | TLS refused (Go parse) | malformed / malformed |
| cA TRUE, keyCertSign, cRLSign leaves | 401 CA or may sign certificates or CRLs | not_end_entity / not_end_entity |
| serverAuth-only EKU, unknown-OID-only EKU | TLS refused (verify) | not_for_client_auth / not_for_client_auth |

Rows where the tools and ES agree on pass:
- base;
- explicit critical FALSE and critical TRUE;
- constructed `[6]` plus the URI;
- constructed `[1]` with byte 0x80;
- valid email, IP and otherName entries;
- issuer and both unique IDs;
- anyEKU only, serverAuth plus anyEKU, no EKU, empty EKU sequence;
- explicit cA FALSE, pathLen without cA;
- empty keyUsage bit string.

Count of rows where a tool says pass and ES refuses:
- **`900d4eb`: 15.**
- **`2fb0c6d`: 1.** That row is the unknown critical extension. The tools' `openssl verify` trust check refuses it, which is unchanged from audit 11 (§10).

The red-team's 9 certificates and my 2 DNS-text certificates from audit 07 still get the right verdict from both tools.

## 5. Optional items (DONE)

- **E16:** `TestAGSPublishAllowsACallerThatMatchesALaterPrefix` (prefixes `operator/local` and `service/control-plane`) expects 200, 200, then 403 for `service/control-plane-evil`, and a publisher count of 2. My audit 11 mutant E16 (AGS checks only the first prefix) is now killed by it.
- **F03:** the self-test's overlay now has a `ResponseState(resp *http.Response) bool { return resp.TLS != nil }`. The F03 mutant (`isFieldOf` always true) is now killed, where audit 11 judged it equivalent.
- **Fixture:** `remote_alpha_prepare_es_config_tls_test.go` lines 295 and 1415 now use `"operator/local"`. The two `TestRemoteAlphaESConfigTLSPrep…` tests that use it pass.

## 6. Regression and CI

**Whole module**, as an unprivileged user, base `725c97a` against head `2fb0c6d` (`runs/full-*.log.gz`):
- 7,157 shared verdicts, 0 different;
- 93 head-only verdicts, all PASS;
- the same 16 top-level failures on both sides:
  - 14 root remote-alpha and hygiene tests;
  - 2 reliablesubmit SQLite old-binary tests;
  - all are container-only and known from earlier audits.

**Build and static checks** (`runs/bv-h38r.log`):
- build, and vet for linux/amd64, linux/arm64 and darwin/arm64: clean;
- gofmt: clean on the PR's Go files and on `docs_contract_test.go`, `remote_alpha_prepare_es_config_tls_test.go` and `ags/api`;
- the collector parses, and `bash -n` passes on the renew helper.

**PR tests** (`runs/pr-tests-h38r.log`), covering the packages, app mTLS tests and root tests, now including the P0v docs test and ES config prep:
- every test passes except the known container-only `…RuntimeSourceMode`;
- the new `…RuntimeKeepsEachIdentityClassification` passes here and in the full run.

**GitHub CI:**
- workflow `go`, run 45291708901 (run number 134) on `2fb0c6d`;
- completed at 00:16:41Z 2026-11-24 with conclusion **success**;
- check run "build, vet and test" (`runs/ci-2fb0c6d.txt`).

## 7. Mutation run (mine, independent of the writer's 124)

Mutants were applied to `2fb0c6d`. Every decoder mutant changes both copies, so the copies-match test can't be what kills it. Results: `mutants/results*.json` and `mutants/*.log.gz`; runner: `scripts/mutants38r.py.txt`.

**50 meaningful mutants, 45 killed.** F19 was killed only by a build failure, so it was replaced with the compiling F19b.
- **H01–H36** (decoder, both tools, Mac labels): 36 mutants; with H09b and H09c, 38 in total. **36 killed.**
  - These include the stricter-than-Go directions: H05 (unique IDs refused), H11 (constructed `[1]`/`[2]` checked) and H26/H27 (trailing fields).
- **F03, F05, F05b, F13–F16, F19b** (guard): all killed.
- **E16:** killed.

Survivors:
- **H09 and H09b** (iPAddress of 8 or 32 bytes accepted): the tests refuse 0- and 5-byte entries only. Go refuses 8 and 32 too. Those are the nameConstraints address-plus-mask lengths, so the mix-up is plausible. This is nit **N13-1**: add an 8-byte case (and a 32-byte one) to the refused list.
- **F17** (final "no target caught this probe" loop disabled): equivalent with today's targets. Every probe's target runs and checks it, so the loop only matters when a target is removed, which F05 covers.
- **F18** (control-plane arm64 not added to the found set): equivalent. `GOARCH=arm64` literals already put arm64 in the set, and the scan pin fails if they disappear.
- **F09** (minimum package count): equivalent, as in audit 11.

## 8. PR #39 merge-order plan (§6 of `12-repair.md`)

**Trial run.** PR #39 is still at `d768e5d`, based on `725c97a`. I merged it into `2fb0c6d` and applied the steps (`scripts/trial-pr39.sh.txt`, `runs/trial-pr39*.log`):

| Step | What happened |
|---|---|
| Merge | One conflict, in the moved `internal/callerauth/caller_authentication_contract_test.go`, as the writer says. |
| 1: union | Works, but a blind union leaves a broken comment (`runs/pr39-contract-union.diff`): "…an alias or an embedded struct.", then a stray "// fails here. The test walks the repository from its root; see package testutil." **Merge this comment by hand:** keep this PR's text, and add PR #39's sentence about `testutil`. |
| 2: move | My move diff is identical to the writer's `pr39-move.diff` (`runs/pr39-move-audit.diff`). gofmt is clean, and no root file uses `executionSubstrateRepoRoot` any more. |
| After 1–2 | build and vet ×3: 0. `internal/testutil` (`TestRootKeepsOnlyItsDocsTests`), `internal/callerauth/...` (all four guard tests), `internal/callerallowlist`, the five APIs and `es/config` pass. The selected `scripts/` tests pass. Root: exactly the two phrase rules fail, naming `internal/callerauth/caller_authentication_typed_guard_test.go` and `"execution-substrate/cgs"`, plus the container-only `TestTrackedGeneratedArtifactHygiene` (no `.git` in an exported tree). |
| 3: by directory | I replaced the import-path list with directories (`"cgs/api"`, …) and derived the import paths from them (`runs/pr39-step3-audit.diff`). The whole root package then passes, apart from the hygiene test, and everything above still passes. |

**Assessment: the plan is correct and complete.**
- None of its steps can be skipped silently:
  - git forces step 1;
  - `TestRootKeepsOnlyItsDocsTests` forces step 2;
  - the two phrase rules force step 3.
- That makes the trigger machine-enforced, so this is not a "revisit later".

Two suggestions:
- **Step 3:** after the move, both guard halves are in package `callerauth_test`. The cleanest fix is one package-level list of the five API directories that both halves use. The name-based half already has `apiPackages := []string{"ars/api", …}`.
- **Optional:** the same one-list change can land in this PR now, because both files are in the root package today. That would shrink the PR #39 merge recipe to steps 1 and 2.

## 9. Other open PRs

- **PR 40** (the PR 12 line, head `75d0f5c`):
  - merge-tree with `2fb0c6d` conflicts only in `PLANS.md`;
  - on that tree, build, `go vet ./es/... ./internal/...`, all four root `TestCallerIdentity…` tests, `es/admission` (250 s), `internal/callerauth` and `internal/callerallowlist` pass (`runs/trial-pr40.log`);
  - three reliablesubmit tests fail on "old PB1 production-source probe is required" and "authenticated schema-4 opener is required". Those are environment prerequisites this container lacks, the same class as the known two (`runs/trial-pr40-reliablesubmit.log`).
- **PRs 12 and 40** add only allowed go-spiffe imports and no JWT-SVID reader calls.
- **PRs 30, 31, 34, 35, 37 and 39** add no go-spiffe imports.
- I did not repeat the writer's other trial merges.

## 10. Observations (no action needed in this PR)

- **Unknown critical extension:** both tools still say identity pass, and ES refuses at the handshake. `openssl verify`, which both tools run as their trust check, refuses it. Unchanged from audit 11.
- **Judgment call 7** (certificatePolicies and AIA are not decoded): agree that matching ES exactly needs an ES subcommand, which is out of scope.
  - It fails closed at ES.
  - The repo doc should say so (**N13-2**). Suggested sentence for the identity paragraph of `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`: "The decoder reads only the subjectAltName, basicConstraints, keyUsage and extKeyUsage extensions, so a certificate that Go refuses for another malformed extension, such as certificatePolicies or authorityInfoAccess, can still show identity pass, and ES refuses it at the handshake."
  - I did not re-run the writer's `extprobe`.
- **Places where the decoder is stricter than Go,** each a certificate ES accepts and the tools fail (safe direction, documented in judgment call 8):
  - trailing bytes after GeneralNames;
  - an upper-case URI scheme;
  - a field after the extensions block;
  - a field after an extension's value.
- **Extended key usage checks:**
  - The renew helper's existing `openssl verify -purpose sslclient` refuses three leaves that ES accepts: anyEKU-only (the writer notes this), serverAuth plus anyEKU, and an empty EKU sequence. This check predates the PR.
  - The tools check only the leaf's EKU. Go also checks intermediates.
    - The supported local setup signs the operator leaf directly with its CA (`scripts/72_supported_local_setup.sh:1475`).
    - Inference: the Remote Alpha mint path is single-tier too, so no intermediate is involved.
- **Certificates OpenSSL cannot read** (non-minimal version, constructed unique ID, trailing fields) come out as `identity_unavailable` (`remote_status_unavailable`) from the collector and `malformed` from the renew helper. Both fail closed. The collector label is pre-existing behaviour for an OpenSSL read failure.

## 11. Reproduce and evidence

`13-re-audit-evidence/` (SHA256SUMS inside) has:
- `README.md` (index);
- provenance;
- guard probe sources and log;
- the 43 public certificate PEMs (`.txt`) and the crafting test;
- tool and ES logs and the full table;
- whole-module logs (gzipped);
- PR tests, build and vet logs;
- PR #39 and PR #40 trial scripts, diffs and logs;
- the mutation runner, results and logs;
- the CI record.

Scripts are saved as `.txt`. The leak scan (`ge_chat_archive.py scan`, gz contents included) is clean. No subagents were used.
