# Red-team of ES PR #38 (caller-identity follow-up) — 16-redteam

Target: Execution-Substrate draft PR #38, branch `claude/project-thread-i9yve2`,
head `26cb86fe5018e21d5c12728d0c1626683d29d693`, tree
`c5b4996eef2be68a23a34a8b315c0173805a802c` (verified by fetch; the head did not
move during the pass). `trunk_dev` was `4c991ba` when the PR was last rebased.

Scope (coordinator's brief): the shared allowlist prefix rule
(`internal/callerallowlist`, used by ARS, AGS and ES) and the status tools' DER
URI-SAN decoding against what ES actually accepts. Goals: get a caller admitted
that should not be, via a prefix, path or SAN trick; or make the tools and ES
disagree in a dangerous direction. The guard-evasion angle was left to the
auditor. Local lab only, read-only, nothing pushed.

Everything here was produced in a cloud container with Go 1.26.5 and Python
3.11. Evidence: `16-redteam-evidence/`.

## Outcome in one line

No admission bypass and no dangerous tool-vs-ES divergence. The allowlist rule is
tight by construction; ES's identity extraction deliberately matches go-spiffe
and its normalizations are documented in contract 3A; the status tools' decoder
is stricter than ES, so the one direction that would matter — the tool calling a
certificate "the expected identity" while ES admits a different or privileged one
— is structurally impossible. Two safe-direction divergences are noted below for
the record; neither is exploitable.

## Method

- Read `internal/callerallowlist/callerallowlist.go`, `internal/callerauth/callerauth.go`,
  the shared DER decoder in the collector
  (`scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`,
  lines 636-892) and the renew helper, the collector's `classify_identity`, and
  contract `.docs/system_overview/contracts.md` section 3A.
- Built a differential over many URI-SAN forms comparing ES's identity
  extraction (`net/url.Parse(raw).String()` -> `callerauth.ParseSPIFFEID`, as
  Go's x509 and callerauth do it) against the tool's decoder rule (printable
  ASCII, <=256 bytes) and `classify_identity`'s exact compare.
  (`16-redteam-evidence/logs/es-vs-tool-differential.txt`).
- Confirmed the one interesting case end to end with crafted certificates whose
  URI-SAN IA5String bytes are set verbatim (bypassing url re-serialization),
  running both the real `callerauth.CallerFromConnectionState` and the real
  Python decoder on the same bytes
  (`16-redteam-evidence/logs/end-to-end-es.txt`, `end-to-end-tool.txt`).
- Ran the in-scope suites: `internal/callerallowlist` (incl. `FuzzPrefixRule`)
  and the decoder copies-match test — all pass
  (`16-redteam-evidence/logs/`).

## The allowlist prefix rule is tight (no prefix/path trick)

`callerallowlist.Matches(id, prefix)` re-validates the prefix on every call and
then matches `path == prefix || strings.HasPrefix(path, prefix+"/")`. Both the
caller path (`id.Path()`, from `callerauth`) and the prefix (`ValidatePrefix`
runs `callerauth.ParseSPIFFEID("spiffe://execution.internal/" + prefix)`) pass
through the same strict parser, so the two sides are canonical and consistent by
construction. The segment-boundary match closes the `operator/local-evil` class.
`MinimumSegments = 2` and startup `ValidatePrefixes` stop an over-broad prefix,
and a bad prefix that reaches `Matches` anyway matches nothing. Path comparison
is case-sensitive on both sides (ES preserves path case; the prefix keeps its
case), so there is no case-folding mismatch. I found no prefix, path or
normalization input that admits a caller to a prefix it should not match. The
package's tests and `FuzzPrefixRule` pass here.

## The dangerous tool-vs-ES direction is impossible by design

ES authenticates `ParseSPIFFEID(uri.String())`, where `uri` is Go's parsed URL;
the status tools decode the raw URI-SAN IA5String bytes and
`classify_identity` reports `pass`/`expected` only when the decoded URI-SAN list
equals exactly `["spiffe://execution.internal/operator/local"]` (and the leaf is
end-entity and client-auth). For the tool to be fooled in the dangerous
direction it would have to report `expected` for a certificate ES admits as some
*other* identity. That cannot happen: the only input the tool calls `expected`
is the exact canonical operator byte-string, and ES maps that exact string
deterministically to `operator/local`. So the tool never under-reports a
privileged or unexpected identity as the benign expected one.

## Safe-direction divergences (noted, not exploitable)

### OBS-1 — the tools' exact match is stricter than ES's go-spiffe-aligned normalization

ES accepts two non-canonical URI-SAN forms as the canonical identity, and this is
deliberate and documented: contract 3A (lines 193-196) states "the rule applies
to the URI as Go's certificate parser hands it over. That parser lower-cases the
URI scheme and drops an empty fragment ... go-spiffe's `x509svid.IDFromCert`
reads a certificate the same way," and `callerauth_test.go`'s
`TestCallerFromConnectionStateReadsTheURIAsTheCertificateParserHandsItOver` locks
it in. So a leaf whose URI-SAN bytes are `SPIFFE://execution.internal/operator/local`
(upper/mixed-case scheme) or `spiffe://execution.internal/operator/local#`
(empty fragment) is admitted by ES as `operator/local`.

The status tools' decoder returns the raw bytes and `classify_identity` compares
them exactly, so the same certificate is reported `identity_mismatch`. Confirmed
end to end on the same bytes: ES admits `op-upper.der` as `operator/local` while
the tool reports `matches_expected=False, classification=identity_mismatch`
(and likewise `svc-upper.der` -> `service/control-plane`).

Direction and impact: this is the *safe* direction (the tool is stricter than
ES). It cannot admit a caller or fool the tool into a false `pass`. In practice
it never triggers, because SPIRE issues canonical SANs, so a deployed operator
certificate is canonical and the two agree. Requiring the exact canonical form
for the operator's own healthcheck certificate is arguably the right behaviour.
No change is required; if the writer wants the tools and ES to agree bit for bit,
the tools could normalize the scheme case and drop an empty fragment before the
compare, or the tool doc could note that it requires the exact canonical form.

### OBS-2 — the decoder's 256-byte URI-SAN cap rejects URI SANs ES accepts

`MAX_URI_SAN_LENGTH = 256`: a URI SAN longer than 256 bytes makes the decoder
return `None` (the tool reports the certificate malformed), while ES/`ParseSPIFFEID`
impose no length limit and would admit a valid long SPIFFE ID. Safe direction
(the tool fails closed). It never bites the operator healthcheck, whose expected
URI is 42 bytes. Noted only because it is a decoder-vs-ES difference; no change
required unless the tools are meant to mirror ES exactly.

## What this pass did not cover

- The typed guard (R4, `internal/callerauth` guard tests): out of scope by the
  brief (the auditor covers guard-evasion). For the record, the callerauth
  guard test fails *in this scratch clone only* because its internal `go build`
  invocation fails VCS stamping (`error obtaining VCS status: exit status 128`,
  a dubious-git-ownership artifact of the clone), which makes the guard analysis
  return no violations; the 13-re-audit ran it green in CI. This is an
  environment artifact, not a code result, and I did not pursue it. The in-scope
  `internal/callerallowlist` and `scripts` decoder tests pass here.
- The decoder's structural alignment with Go for extensions/BC/KU/EKU was spot-
  checked by reading and by the differential, not re-exhausted; the 13-re-audit
  already ran 7,157 shared tool-vs-ES verdicts with 0 differences and 43 crafted
  certificates. The live validity period and certificate chain are ES/TLS
  concerns that the file-only decoder does not and need not check.

## Pointers

Audit chain: `11-audit.md`, `13-re-audit.md` (ACCEPT), `14-repair.md`. Contract:
`.docs/system_overview/contracts.md` section 3A. Finding record:
[[es-pr38-red-team-16]].
