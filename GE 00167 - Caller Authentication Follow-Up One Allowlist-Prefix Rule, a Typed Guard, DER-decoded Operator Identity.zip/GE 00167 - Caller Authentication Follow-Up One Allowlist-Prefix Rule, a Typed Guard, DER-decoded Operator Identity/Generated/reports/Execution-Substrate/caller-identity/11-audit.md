# ES PR #38 audit: caller authentication follow-up (R4, R6, N1/O7-1)

Auditor thread "Audit Execution-Substrate pull requests". Head `900d4eb73862c451692e6c5f601d6061cec72709`, base trunk_dev `fdfa3bc67cdedb11f583a19df7036c20c612741f`. Writer report: `10-follow-up.md` (sha256 `b6975bfb…ce52`). Read-only audit: nothing was pushed, commented or merged. No subagents were used.

## 1. Verdict

**REJECT at 900d4eb: repair, then a narrow re-audit.** The reject rests on three Low findings (A11-1, A11-2, A11-3). The project rule is that Low findings are fixed in the PR. Nothing regressed.

- **R6: closed.** ARS, AGS and ES now validate and match allowlist prefixes with one rule, `internal/callerallowlist`. An invalid prefix stops the service at startup, and it matches nothing if it reaches a server some other way.
- **R4: closed as specified.** The new typed guard catches the red-team's probes as real files: 6 findings per target, while the name guard still passes them. It does not catch two other spellings:
  - **A11-1:** go-spiffe's `spiffetls` and `spiffegrpc` peer-identity readers.
  - **A11-2:** files that build only for linux/arm64, a target the repo builds service images for.

  A fix sketch for both is validated in §6.
- **N1/O7-1: closed.** Both status tools now decode URI SANs from DER, and every N1 and DNS-text certificate gets the right verdict. 19 crafted certificates were compared with ES over real mutual TLS:
  - **A11-3:** for four of them the tools say identity "pass" while ES refuses: a v1 or v2 certificate that carries extensions, and a malformed non-URI SAN entry.
  - **A11-4** (pre-existing, recommended): the tools do not check the end-entity rule or the client-auth EKU that ES enforces.
- **Provenance:**
  - Manifest `c21c4087…6736` reproduced twice with the v2 recipe from `operating-protocol/tools`. It is byte-identical to the writer's JSON.
  - The tip tree equals a fresh merge of b644851 and fdfa3bc.
- **Regression:**
  - Whole module, base vs head: 7,001 shared verdicts, 0 different, 72 new tests, all PASS. The same 16 container-only failures on both sides.
  - Race clean; fuzz 60 s clean.
- **CI on 900d4eb:** green (run 45271473548, job "build, vet and test", success at 22:07:58Z).
- **Mutants:** 41 of 46 of my own killed. The 5 survivors are 2 equivalent mutants and 3 test gaps that line up with A11-2, A11-3 and an optional AGS test (§9).

## 2. What was run

All Go runs used Go 1.26.5 as user `ci` with `env -i`, `GOPROXY=off` and `-mod=readonly`. Each tree was exported with `git archive` and every file was checked against its git blob id: 503 files for the head and 498 for the base, 0 mismatches.

| Check | Result | Evidence |
|---|---|---|
| Provenance and v2 manifest | PASS | `logs/provenance.log` |
| Build; vet linux/amd64, darwin/arm64, linux/arm64; gofmt; collector parse; `bash -n` renew | all clean | `logs/build-vet-h38.log` |
| PR tests (callerallowlist, callerauth, 5 API packages, 3 configs, 5 app mTLS suites, root guards, docs and TLS tool tests) | all pass except the known container-only `…NoninteractiveRuntimeSourceMode` | `logs/pr-tests-h38.log` |
| Race (touched packages and app mTLS tests); fuzz `FuzzPrefixRule` 60 s (4.6 M execs) | clean | `logs/race-fuzz-h38.log` |
| Whole module, fdfa3bc vs 900d4eb | 0 different verdicts | `logs/full-*.log.gz`, `logs/compare-b38-h38.txt` |
| Without-fix variants (R6, R4, N1) | the new tests fail as claimed | `logs/nofix-*.log`, `logs/guards-g38a.log` |
| Guard probes (red-team, go-spiffe, linux/arm64) and fix sketch | §6 | `probes/`, `logs/guards-*.log` |
| 19 crafted certificates: ES over mTLS vs both tools vs base collector | §7 | `probes/dercraft/`, `certs/`, `logs/der-variants-*.log` |
| Mutation run: 47 mutants | §9 | `mutants/` |
| Trial merges with open PRs 12, 30, 31, 35 | §8 | `logs/trial-merges.log` |

## 3. Provenance

- Remote topic `claude/project-thread-i9yve2`, `refs/pull/38/head` and the tip all equal `900d4eb`. trunk_dev equals `fdfa3bc`, and the merge base is `fdfa3bc`.
- First-parent chain: 76c030f (#27 squash), then daac305, e62829c, 62c4af6, 117eaeb, b644851, then 900d4eb, which merges fdfa3bc. 76c030f is an ancestor of fdfa3bc.
- The tip tree `1f412fef…` equals `git merge-tree --write-tree b644851 fdfa3bc`, so the merge adds nothing of its own.
- Manifest: v2 tool sha256 `c08597e2…a3ca` (verified). HEAD was reset to fdfa3bc with upstream `origin/trunk_dev`, and the tool was run twice. Both runs were identical:
  - `manifest_sha256=c21c4087fa146f6b603394dbf61a4f93993138ebda99aae6f5ba227398d46736`
  - `textual_diff_sha256=0c45ede5…3108`
  - 29 files
  - Byte-identical to `10-evidence/manifest/manifest-v2-900d4eb.json` and `-run2.json`.
- `10-evidence/SHA256SUMS`: all 75 entries OK.

## 4. CI on 900d4eb

**Green.** Workflow `go`, run 45271473548, attempt 1, PR event on head `900d4eb`. Job "build, vet and test" (check run 138032087059) ran from 21:37:00Z to 22:07:58Z and concluded **success**. Every step succeeded, including Test (21:40:22Z to 21:58:22Z) and "Listed tests still fail". Record: `logs/ci-900d4eb.txt`.

## 5. R6: one allowlist-prefix rule (closed)

**The rule** (`internal/callerallowlist/callerallowlist.go:40-87`):
- `ValidatePrefix(p)` accepts `p` exactly when `spiffe://execution.internal/` + `p` passes `callerauth.ParseSPIFFEID` and has at least 2 segments.
- `ParseSPIFFEID` stores the raw path without normalising it, so an accepted prefix is exactly a canonical caller path. The fuzz target checks `id.Path() == prefix` too.
- `Matches` refuses an invalid prefix, then matches either equality or the prefix followed by a "/".
- Since both sides are canonical, `operator/local` matches `operator/local/a` but not `operator/local-evil`.
- The zero `SPIFFEID` (path "") matches no valid prefix.

**Every construction path checked:**
- Production servers are built only in `ars/app/app.go:53`, `ags/app/app.go:45` and `es/app/app.go:45`, each from the validated config.
- Every other `NewServer` call is in a test.
- The ARS writer constant `service/artifact-governance` passes the rule, so writer authorization is unchanged.
- Every prefix the repo loads is valid under the new rule: the six example configs, `scripts/72_supported_local_setup.sh:1197-1285`, and every Go test literal.
- Exception: `remote_alpha_prepare_es_config_tls_test.go:295,1415` still writes `["operator"]` into an ES config fixture. That script does not touch or load `authorization`, and old ES already refused one-segment prefixes, so this is a stale fixture value (pre-existing, harmless). Optional cleanup.
- No doc or test refers to the removed ES error texts.

**Behaviour change**, all toward refusing:

| Prefix | Old ARS/AGS | Old ES | Now |
|---|---|---|---|
| `service` (one segment) | **loaded, matched all of `service/*`** | refused | refused at startup |
| `/operator/local`, `operator/local/` | loaded, matched after trimming | refused | refused |
| `operator/lo cal`, `operator/local?x` | loaded, dead | **loaded, dead** | refused |
| `spiffe://execution.internal/operator/local` | loaded, dead | refused | refused |

Without-fix variant (head tree with the six service files from fdfa3bc):
- `TestARS…`, `TestAGS…` and `TestES…AllowlistPrefixThatFailsTheSharedRuleMatchesNothing` fail.
- `TestConfigValidateRejectsBroadOrMalformedSPIFFEPathPrefixes` fails.
- `TestARSAGSAndESCheckAllowlistPrefixesWithTheSharedRule` fails on all 36 refused service/prefix pairs (12 prefixes × 3 services).

On the ES side of that last test, 10 of the 12 refusals fail only because the error identity is wrong. The other two are `operator/lo cal` and `operator/local?x`, which old ES loaded.

**Box:**
- After this PR, a live config with a prefix outside the rule stops the service at startup.
- The writer's read-only check in `10-follow-up.md` §6 implements the same rule. Its regex is ASCII-only, `fullmatch` is used, and `.`/`..` and the 2-segment minimum are handled. It prints nothing for an empty list, which the services refuse anyway.
- Run it before deploying. The live box configs are Unknown to me.
- Inference: AGS is the service most likely to fail it. Until this PR, `.runbooks/system/v1_bringup.md:155` said the AGS and ES configs keep `["operator"]`. ES has refused that since its validator was added, but AGS loaded it.

## 6. R4: typed guard (closed as specified; A11-1, A11-2)

**What it does** (`caller_authentication_typed_guard_test.go`):
- It type-checks every main-module package except `internal/callerauth/...`, for linux/amd64 and darwin/arm64.
- It flags field selections of:
  - `net/http.Request.TLS`;
  - `x509.Certificate.URIs`, `.Issuer`, `.RawIssuer` and `.Extensions` (by object identity, so variables, aliases and embedding are caught);
  - any `crypto/tls` field or method in the five API packages.
- It also flags imports of `x509svid` and `callerauthtest`.

Removing `spiffeid` from the ban (the writer's deviation) is sound. `spiffeid` parses strings and URLs and cannot read a certificate; getting a URL out of a certificate needs `.URIs`, which is flagged. PR 12 uses `spiffeid.ID`.

**The red-team's probes as real files** (`internal/rtprobe/rtprobe.go`, `ars/api/zz_rtprobe.go`):
- The typed guard reports 6 findings per target: x509svid import, 3 × `Request.TLS`, 2 × `Certificate.Issuer`.
- The name guard still passes them, which is the without-fix demonstration.

### A11-1 (Low): go-spiffe's other peer-identity readers are not refused

go-spiffe v2.4.0 reads a TLS or gRPC peer's SPIFFE ID in packages the ban does not list:
- `spiffetls.PeerIDFromConnectionState` / `PeerIDFromConn`;
- `spiffetls/tlsconfig` authorizers, which receive the peer's `spiffeid.ID`;
- `spiffegrpc/grpccredentials.PeerIDFromContext` / `PeerIDFromPeer`.

They are in the module cache, and the module's existing go.sum entries are enough to compile them.

Probe (`probes/spiffetls/`, tree `g38b`):
- A new production package `internal/zzspiffeprobe` puts the connection into the request context with `http.Server.ConnContext`.
- `CallerPath(r)` returns `spiffetls.PeerIDFromConnectionState(conn.ConnectionState())`, and `GRPCCallerPath` uses `grpccredentials`.
- `ars/api/zz_spiffeprobe.go` calls `CallerPath(r)`.

Results:
- Over real mutual TLS (an httptest server with `RequireAndVerifyClientCert`), `CallerPath` returns `/operator/local` for a client certificate whose URI SAN is that ID.
- **Both guards pass** (`logs/guards-g38b.log`, `logs/guard-probes-functional.log`).

This is a sixth copy of the identity read, reachable from an API package with no flagged selector. Outside the API packages, `ConnectionState()` on a `*tls.Conn` is legitimately allowed: PR 12's outgoing Nomad connection uses it.

**Fix.** Refuse every go-spiffe import outside `internal/callerauth` except the packages the module uses for its own identity and the ID type:
- `spiffeid`
- `workloadapi`
- `svid/jwtsvid`
- `proto/spiffe/workload`

This is a closed list, so a package added in a later go-spiffe release is refused by default. Add one probe spelling to `TestCallerIdentityTypedGuardCatchesSixthCopies`.

The sketch is in `probes/guard-fix-sketch.diff` (about 20 lines). Results:
- Clean head: PASS.
- PR 12 trial merge (tree `2210e4cc`, PLANS.md conflict only; conflict-marker labels change the tree id between runs, not the Go files): PASS.
- g38b: 2 findings per target.
- g38a: unchanged.

### A11-2 (Low): linux/arm64 is not a guard target, but the repo builds service binaries for it

- `.out/Dockerfile`, generated by `scripts/generate_control_plane_dockerfile.sh`, builds ars, ags, egs, es and cgs with `GOARCH=${TARGETARCH}`. That is arm64 on an Apple-silicon Docker host.
- `scripts/73_supported_local_proof.sh:475` builds `es-runtime-support` for linux/arm64.

Probe (`probes/arm64/zz_issuerprobe_linux_arm64.go` in `es/admission`, tree `g38c`):
- It reads the issuer common name through an embedded request and a variable.
- It is in linux/arm64's `GoFiles` and in the linux/arm64 `cmd/es` build.
- **Both guards pass.** The typed guard never sees the file, and the name guard misses the variable spelling.

**Fix:** add `{"linux", "arm64"}` to `callerIdentityBuildTargets` and update the comment above it. Let the self-test run on every target with one platform-only probe file, so that dropping a target fails (mutant F05 survives today). With the sketch, the guard test takes 7.2 s for three targets, against 2.8 to 4.8 s for two. It catches the probe with 4 findings.

**Other limits, unchanged and acceptable as documented:**
- Reflection, `unsafe`, and hand parsing of `Raw`/`RawTBSCertificate`.
- Reading the issuer's name as the parent certificate's `Subject` (e.g. `VerifiedChains[0][1].Subject`). The guard does not watch `Subject`, which has legitimate uses.
- Inference: none of these spellings is likely to happen by accident.

## 7. N1/O7-1: URI SANs decoded from DER (closed; A11-3, A11-4)

**What changed:**
- Both tools read `openssl x509 -in <cert> -outform DER` and decode the URI SANs structurally with one decoder, kept identical in both tools between `# BEGIN/END uri-san-der-decoder`. `TestRemoteAlphaOperatorHealthcheckTLSURISANDecoderCopiesMatch` enforces that; mutant G15 confirms it.
- The collector's sudo allowlist swaps the `-ext subjectAltName` tuple for the `-outform DER` tuple. Tests assert that `subjectAltName` is gone from both the calls and the allowlist.
- The doc says no sudoers configuration is added. Inference: a box whose sudoers lists the old argv exactly would turn identity into `not_available`, and the box notes do not suggest such a rule.
- The collector hash is computed at run time, not pinned as a constant, so nothing else needed updating.

**Independent comparison:**
- 19 certificates were crafted, signed by a probe CA (`probes/dercraft/zz_audit_der_test.go`; public PEMs in `certs/`).
- Each one was presented to `callerauth.CallerFromConnectionState` over real mutual TLS.
- Each one was run through the head collector's `classify_identity` (with its real `run_command` and `openssl`), the renew helper's decoder copy (extracted between the markers), `openssl verify`, and the base collector.

| Certificate | ES over mTLS | Head collector / renew | `openssl verify` | Base collector |
|---|---|---|---|---|
| base (one URI SAN, v3) | 200 | pass / pass | ok | pass |
| **v1 with extensions** | **401 no URI SAN** (Go reads extensions only for v3) | **pass / pass** | ok | pass |
| **v2 with extensions** | **401 no URI SAN** | **pass / pass** | ok | pass |
| **SAN with a 5-byte IP entry** | **TLS refused** (Go parse error) | **pass / pass** | ok | pass |
| **SAN with a non-IA5 rfc822Name** | **TLS refused** | **pass / pass** | ok | malformed |
| SAN explicit critical FALSE | 200 | pass / pass | ok | pass |
| SAN critical TRUE | 200 | pass / pass | ok | pass |
| SAN with trailing bytes after GeneralNames | 200 (Go ignores them) | malformed / malformed | ok | pass |
| SAN extension twice | TLS refused | malformed / malformed | refused | pass |
| constructed `[6]` entry plus the URI | 200 | pass / pass | ok | mismatch |
| high-tag GeneralName | TLS refused | malformed / malformed | refused | mismatch |
| unknown critical extension | TLS refused | pass / pass | refused | pass |
| upper-case scheme | 200 (§3A, documented) | mismatch / fail | ok | mismatch |
| upper-case host | 401 | mismatch / fail | ok | mismatch |
| same URI twice | 401 | mismatch / fail | ok | mismatch |
| no SAN | 401 | mismatch / fail | ok | mismatch |
| *CA:TRUE leaf* | *401 not end-entity* | *pass / pass* | ok | pass |
| *keyCertSign leaf* | *401 not end-entity* | *pass / pass* | ok | pass |
| *serverAuth-only EKU* | *TLS refused* | *pass / pass* | ok | pass |

The red-team's certificates (4 originals plus 5 edge cases) and my two DNS-text certificates from 07 all get the right verdict from both tools now. The old collector's text parsing misread them.

Two disagreements are in the safe direction, where the tools fail a certificate ES accepts:
- trailing bytes after GeneralNames;
- the upper-case scheme.

The decoder's other strictness is also safe: it refuses empty URIs, URIs with spaces and URIs longer than 256 bytes, and `callerauth` refuses those identities anyway. Accepting an explicit critical FALSE matches Go, which is the right line.

### A11-3 (Low): the decoder passes four non-conforming certificates that ES refuses

These are the bold rows. `openssl verify` accepts all four, so each tool's overall status can say pass for a certificate ES will not accept. The rfc822Name row is a narrow regression: the base collector called it malformed.

**Fix** (in the shared decoder, both copies):
- When an extensions block is present, require the TBS to start with `[0] { INTEGER 2 }`. Go reads extensions only when the version is 3 (`crypto/x509/parser.go:1020-1027`). Otherwise return None.
- In the GeneralNames loop, apply Go's per-type checks (`parser.go:401-435`): rfc822Name, dNSName and URI bytes must be below 0x80, and an iPAddress must be 4 or 16 bytes. Otherwise return None.
- Add a v1-with-extensions case, a bad-IP case and a constructed `[6]` case (which must be ignored, as Go does; mutant G08 survives today) to the decoder tests.

Inference: the repo's OpenSSL mint path produces none of these certificates, so this is diagnostics hardening, not a live risk.

### A11-4 (Low, pre-existing since PR 27; recommended in this PR): no end-entity or client-auth check in the tools

The italic rows:
- ES refuses a CA:TRUE or keyCertSign/cRLSign leaf (`internal/callerauth/callerauth.go:143`, §3A).
- Go's verifier refuses a leaf without the clientAuth EKU.
- Both tools still say identity pass, and `openssl verify` without `-purpose` accepts.

R5 was about the tools saying pass where ES refuses, and this PR already reworks the tools' identity verdict. The decoder already walks the extensions, so reading basicConstraints `cA` and keyUsage bits 5 and 6 is a small addition. The EKU part could be `openssl verify -purpose sslclient`, which changes the sudo allowlist tuple.

If the coordinator would rather keep scope tight, this needs a tracked item with a machine-enforced trigger instead.

## 8. Regression and merge readiness

- Whole module, base fdfa3bc against head 900d4eb: 7,001 shared verdicts, 0 different, 72 head-only verdicts, all PASS. The 16 top-level failures are the same on both sides: 14 root remote-alpha/hygiene tests and 2 reliablesubmit SQLite old-binary tests, all container-only and known from earlier audits.
- Build and vet clean for three targets; gofmt clean.
- Trial merges onto 900d4eb:
  - PR 30 (`eed4c9b`) and PR 35 (`27e8b64`): clean.
  - PR 12 (`4416699`) and PR 31 (`c3a94ae`): conflict only in `PLANS.md`.
  - The writer's §5 says the same.

## 9. Mutation run

I wrote 46 mutants of my own (the writer's run was separate): E01 to E17 on the allowlist rule and its wiring, F01 to F12 on the typed guard, and G01 to G17 on the decoder and tools. Decoder mutants change both copies, so the copies-match test cannot be what kills them.

Each mutant ran PR 38's test set, minus the one container-only failure (`logs/mut-baseline.log`: all pass unmutated).

E11 to E14 at first broke only the build (an unused import or variable). I replaced them with forms that compile (E11b to E14b), and all four of those are killed.

**41 of 46 killed.** The five survivors:

| Mutant | Why it survives | Assessment |
|---|---|---|
| E16: AGS checks only its first prefix | no AGS test where the caller matches a later prefix | small, pre-existing test gap; optional test |
| F03: `isFieldOf` always true | no production code reads a same-named field of another type, such as `http.Response.TLS` | equivalent on this tree; optional self-test spelling (`resp.TLS` must not be flagged) |
| F05: darwin target dropped | the self-test runs one target only | same gap as A11-2: add a per-target probe (an `_arm64`/`_darwin` overlay file) with that fix |
| F09: no minimum package count | sanity floor | equivalent in practice |
| G08: constructed `[6]` read as a URI | no test with a constructed `[6]` entry | add with A11-3's tests; Go ignores such entries (§7 table) |

Results: `mutants/results-final.json`; per-mutant logs in `mutants/logs/`.

## 10. Answers to the writer's §7 questions

- **Package home:** keep `internal/callerallowlist` separate. Authentication (callerauth) and the authorization prefix rule are different concerns. Keeping the allowlist out of the guard-exempt `internal/callerauth` tree keeps the exemption narrow, and the typed guard requires the package to be checked.
- **Non-config construction paths:** none in production (§5). The fail-closed matcher is still right as defence in depth.
- **Guard coverage and the spiffeid deviation:** the deviation is sound. Coverage needs A11-1 and A11-2.
- **Decoder strictness:** the safe-direction strictness is fine. The gaps are in the other direction (A11-3).
- **Two copies:** acceptable. The copies-match test makes drift a test failure (G15 is killed). Staging a third file would change a contract that many docs pin, for no safety gain.

## 11. Housekeeping

Python imports during the probes created `scripts/internal/__pycache__` in my local head and base export trees. I removed it. No repository content was changed.

## 12. Evidence

`11-audit-evidence/`, listed in `SHA256SUMS`:
- `logs/`: provenance, build-vet, PR tests, race/fuzz, whole-module logs (gzip), comparison, without-fix runs, guard runs, fix-sketch runs, DER verdicts, trial merges.
- `probes/`: the go-spiffe and linux/arm64 guard probes, the fix sketch diff, the DER crafting test, and the two status-tool probe scripts.
- `certs/`: the 19 crafted public certificates and the probe CA, as `.pem.txt`. No private keys were written.
- `mutants/`: the runner, results JSON, and per-mutant logs (gzip).
