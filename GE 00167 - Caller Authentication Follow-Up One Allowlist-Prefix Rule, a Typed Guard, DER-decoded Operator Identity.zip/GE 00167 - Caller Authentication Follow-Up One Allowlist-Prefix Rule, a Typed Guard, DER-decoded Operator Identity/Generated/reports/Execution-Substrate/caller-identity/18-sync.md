# PR #38: trunk_dev 0842983 taken (#42, #34, #31), with the mechanical proof

**Head `8ce9a2a` is `5c2ac0b` plus a merge of `trunk_dev` `0842983`. The one conflict, in `PLANS.md`, is resolved as a union. Every other file is git's own merge result, and the PR's changed lines are byte-identical in all 32 files. By the coordinator's 02:01Z rule, this proof stands in for an auditor round.**

```text
SYNC REPORT
Repository:        evo-agi/Execution-Substrate, draft PR #38
Previous head:     5c2ac0b099c715340df46b615fe6f9eff4e2c6df (base 523648c; provenance check 17 passed; CI 45305896724 green)
New base:          origin/trunk_dev 084298366244c6bb5bc6f3126307713b31b939c0
                   = 523648c + #42 6ce0034 (es/app test ports) + #34 5b82a6e (SPIRE agent helper) + #31 0842983 (Nomad lock)
New head:          8ce9a2a2a3c80c351c1d6883c76da42a9c28fbdd  Merge trunk_dev 0842983 into the caller authentication follow-up
                   (pushed; parents 5c2ac0b and 0842983; tree f2c017332ced74271616c2da25b2a5bbe5639242)
Conflicts:         PLANS.md only (both #31 and this PR add a section at the top of the Status list)
v2 manifest:       ddba837c675bed94b6c8f247ca46d99bb1d667f126587fe1e629f9777a9d2c9e, 32 files,
                   textual diff 32e99887a7d529c0057c379ccb656694fb4d7262c5810834d05cb4cde5071548;
                   HEAD reset to 0842983, upstream origin/trunk_dev, two runs byte-identical; tool SHA c08597e2...a3ca verified.
                   Paths equal `git diff --name-only 0842983 8ce9a2a` (same 32 paths as before); every hash and size equals its blob.
Range-diff:        git range-diff 523648c..5c2ac0b 0842983..8ce9a2a: 15 of 15 commits "=".
Effect status:     TOPIC_BRANCH_PUSHED | MERGE_NOT_PERFORMED
```

## 1. The mechanical proof (`18-sync-evidence/prove.sh`, `prove.out`)

1. **Only PLANS.md differs from git's own merge.** `git merge-tree --write-tree 5c2ac0b 0842983` gives tree `c63740b2…` with one conflicted path, `PLANS.md`. The merge commit's tree differs from it only in `PLANS.md`.
2. **The resolution removes the conflict markers and nothing else.** Against git's conflicted file, the resolved `PLANS.md` drops the `<<<<<<<` and `>>>>>>>` lines and turns `=======` into the blank line between the two sections (`merge-vs-merge-tree.diff`, 29 lines). It was produced by `union_plans.py`, which refuses unless there is exactly one conflict block, at the top of the Status list, with this PR's section on one side.
3. **The PR's changes are unchanged.** For each of the 32 paths, the changed lines of `git diff -U0` (the `+` and `-` lines, in order) against the new base are byte-identical to those against `523648c`: 0 files differ. For `PLANS.md` both diffs are the same two pure insertions (27 lines at the top of Status, 1 line further down; hunks `-4,0 +5,27` and `-3585,0 +3613`), with no removed lines (`plans-pr-diff-vs-0842983.diff`, `plans-pr-diff-vs-523648c.diff`).
4. **The blobs that changed are exactly the overlap.** Seven of the 32 paths have new head blobs since `5c2ac0b`, and they are exactly the PR's paths that `trunk_dev` changed between `523648c` and `0842983`: the three docs, `.runbooks/system/v1_bringup.md`, `PLANS.md`, `docs_contract_test.go`, `es/config/config.go` and `es/config/config_test.go`.

Before #31 landed, a dry run against a simulated `trunk_dev` (`6ce0034` + #31 `d6fa837` + #34) gave the same base tree (`9e5e0d8b…`, equal to `0842983`'s) and the same merged tree (`f2c01733…`). The dry run's build, vet ×3 and package subset passed (`logs/sim18.*`).

## 2. Validation of `8ce9a2a`

All runs are as the unprivileged `esci` user with a clean environment (`18-sync-evidence/logs/`: `val18.sh`, `val18.out` and the per-package logs):
- [x] gofmt of every `.go` file changed since `0842983`; `go build ./...`; `go vet ./...` for linux/amd64, linux/arm64 and darwin/arm64
- [x] root package in full
- [x] `scripts/` (CI's environment-only entries skipped)
- [x] `./internal/...`, ARS, AGS, EGS and CGS in full, `es/api`, `es/config`
- [x] `es/admission/...` (CI's environment-only entries skipped)
- [x] `es/app` with CI's environment-only entries skipped, run twice. Each run had one failure, both environmental, and no other test failed in either run:
  - `TestRealNomadOffersOnlyTheLimitedDockerDriver` (from #31) failed in the first run because this container's Docker daemon had stopped ("Failed to connect to docker daemon"). With Docker started it passes (`es-app-nomad-driver-rerun-8ce9a2a.log`).
  - `TestBringupScriptUpCheckDownFullProfile` fails in the second run (Docker up) because the image build's `apk add` has no network in this container ("DNS lookup error", `es-app-docker-8ce9a2a.log`). This PR touches neither bring-up nor the Dockerfile. CI has network.
- [x] GitHub CI on `8ce9a2a`: run 45318270302 green (03:49Z).

## 3. For the gate

- Accepted target: `8ce9a2a` with manifest `ddba837c…2c9e`.
- Audit chain: re-audit 13 ACCEPT at `2fb0c6d`; diff-only re-check 15 PASS at `26cb86f`; red-team 16 ACCEPT at `26cb86f`; provenance check of `5c2ac0b` passed (`17-sync-audit-check/`); this sync, by the proof above.
- Product code: since `2fb0c6d`, only merged trunk changes have touched it, in `es/config/config.go` (#31's Nomad token settings). Git merged that file without a conflict, and the PR's changed lines in it are identical (§1.3).
