# PR #38 repair after audit 11: A11-1, A11-2, A11-3 and A11-4

**Verdict: REPAIRED. Draft PR [#38](https://github.com/evo-agi/Execution-Substrate/pull/38) at `2fb0c6d`, up to date with `trunk_dev` `725c97a`. Needs the narrow re-audit of `900d4eb..2fb0c6d` by the same auditor, then the red-team and the merge gate (product code).**

Validation in this cloud container: build, vet for linux/amd64, linux/arm64 and darwin/arm64, the root package, the caller identity, ARS, AGS, EGS, CGS and ES API/config packages, `es/admission/...` and `es/app` all pass (only `trunk_dev`'s two listed environment-only probe tests fail). The mutation run kills all 124 mutants. Trial merges with the 8 other open PRs pass. PR 39's new root layout rule needs one merge step from whichever of the two PRs merges second (§6). GitHub CI on `2fb0c6d` is running (run 134). The runs on the four commits before it were cancelled by the next push, and `900d4eb`'s run passed.

```text
REPAIR REPORT
Findings:         11-audit.md A11-1, A11-2, A11-3 (Low, fix in PR 38) and A11-4 (Low, pre-existing;
                  in this PR as the coordinator asked at 22:17Z), plus the audit's optional items:
                  E16 (AGS later-prefix test), F03 (resp.TLS self-test spelling), the stale
                  ["operator"] fixture in remote_alpha_prepare_es_config_tls_test.go
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 725c97a9663df060e49270fce3bc8c904a88986e (#41, runtimeconfig/v1 tests only,
                  merged in; before it #33 0aa4a2b, es/config tests only, and #36 400ff7f, README only)
Topic branch:     claude/project-thread-i9yve2
Audited head:     900d4eb73862c451692e6c5f601d6061cec72709
New head SHA:     2fb0c6dc17bfb76e419ea31d26171a2c2287e6eb (pushed; refs/pull/38/head is the same)
Tree SHA:         9d829e7646cec5bcb04ff9bdc2db342cc20e910f
Commits added:    3a2cd86  Refuse in the operator status tools what ES and Go refuse in a client certificate (A11-3, A11-4)
                  257d585  Refuse go-spiffe's peer identity readers and type-check linux/arm64 in the caller identity guard (A11-1, A11-2, F03)
                  02182f8  Test an AGS caller that matches a later prefix, and use a valid prefix in the ES config prep fixtures (E16, fixture)
                  91243f5  Merge trunk_dev 400ff7f into the caller authentication follow-up (clean; README only)
                  33b67d1  Keep each decoder rule in one check, and test a malformed version field
                  30c7e5f  Say in the status doc that the decoder refuses malformed key usage extensions
                  f6bdde8  Make each build-target scan of the guard pin prove that it found something (mutant F10)
                  031c02e  Merge trunk_dev 0aa4a2b into the caller authentication follow-up (clean; es/config tests only)
                  2fb0c6d  Merge trunk_dev 725c97a into the caller authentication follow-up (clean; runtimeconfig/v1 tests only)
Delta diff:       900d4eb..2fb0c6d without the five trunk_dev files (README.md, es/config/config_field_guard_test.go,
                  es/config/config_test.go, internal/contracts/runtimeconfig/v1/workload_zone_vault_guard_test.go and
                  workload_zone_vault_test.go; no repair commit touches them): 11 files, +1097 -165,
                  sha256 ed2f05c64432f83de346f5008dc7009b792b3ab0c6ccc4b108b449c1245eb580 (12-evidence/delta-900d4eb.diff)
v2 manifest:      ef00123741a96dbf768f21c908d71e240ef51c1438eec1eb4a6eb8d86059aa98, 32 files, textual diff
                  51af9bbdb0a321e9534f1a1b69386bed64d56f1fc1ff17de9807b018963cad1c; HEAD reset to 725c97a, upstream
                  origin/trunk_dev, two runs byte-identical; tool SHA c08597e2...a3ca verified before use
                  (12-evidence/manifest/). Paths equal `git diff --name-only origin/trunk_dev 2fb0c6d`, and every
                  file hash equals its blob at 2fb0c6d. The textual diff is the same as against 0aa4a2b at 031c02e:
                  the #41 merge changed nothing in the PR's own diff
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED | RE_AUDIT_NOT_PERFORMED
```

## 0. In plain words

The audit found three small gaps in this PR and one older gap next to it. None let a wrong caller into ES. Each one let a test or a status tool say "fine" about something ES refuses.

- **A11-3: the status tools' certificate reader was looser than Go.** It read the identity from a version 1 or 2 certificate that has extensions (Go ignores those extensions, so ES sees no identity), and it accepted a malformed email name, DNS name or IP address entry next to the identity (Go refuses the whole certificate). It now follows Go's rules for these.
- **A11-4: the status tools did not check what kind of certificate it is.** ES refuses a CA certificate as a caller, and Go's TLS server refuses a certificate whose extended key usage does not allow client authentication. The tools said "pass" for both. They now fail them, with their own labels.
- **A11-1: the guard missed two go-spiffe packages that read a caller's identity.** The guard now allows only the four go-spiffe packages a workload needs for its own identity and refuses every other one, including any that a later go-spiffe release adds.
- **A11-2: the guard did not check linux/arm64,** which the control-plane images build for on an Apple-silicon Docker host. It checks it now, its self-test proves it checks every platform, and a new test fails if a script starts building for a platform the guard does not check.

Nothing changes for a caller with a normal operator certificate. The operator certificates the repo issues are version 3 end-entity certificates with clientAuth, and they pass as before (the Go-made certificates in the tests are made the same way).

## 1. A11-3 and A11-4: the status tools refuse what ES and Go refuse

**One decoder, two copies.** The decoder block in the collector and in the renew helper is renamed `client-certificate-der-decoder`, and its copies test is now `TestRemoteAlphaOperatorHealthcheckTLSCertificateDecoderCopiesMatch`. It also requires the new constants in the block. `decode_client_certificate(der)` returns `None` (malformed) or `{"uri_sans": [...], "end_entity": bool, "client_auth": bool}`. The unused `extract_uri_sans` wrapper is gone, and the docs contract test pins `decode_client_certificate` instead.

**What the decoder now checks, each as Go's `crypto/x509` parser does:**

| Rule | Go | Decoder |
|---|---|---|
| Extensions only in a version 3 certificate | reads `[3]` only when the version is 3 | with an `A3` field present, the TBSCertificate must be `[0] INTEGER 2`, serial, five SEQUENCEs, then `[1]`, `[2]`, both or neither, then `A3` as the last field; the version field must hold exactly one minimal INTEGER `02` |
| rfc822Name, dNSName | refused if not IA5 | refused if a byte is above `0x7F` |
| iPAddress | refused unless 4 or 16 bytes | the same |
| Other general names, constructed `[6]` included | ignored | ignored (G08) |
| URI | IA5, then `url.Parse` | printable ASCII without spaces, at most 256 bytes (stricter, unchanged) |
| Extension identifier | `ReadASN1ObjectIdentifier`; repeated extension refused | minimal base 128, each subidentifier below 2^31; repeated extension refused |
| basicConstraints | SEQUENCE, optional BOOLEAN `00`/`FF`, optional INTEGER | the same, and refuses fields after the INTEGER and a negative INTEGER (stricter, see §8) |
| keyUsage | BIT STRING with Go's padding rules | the same; keyCertSign is mask `0x04` and cRLSign mask `0x02` of the first byte |
| extKeyUsage | SEQUENCE of object identifiers | the same |

**The facts it reports** (A11-4):
- `end_entity` is false when basicConstraints has cA TRUE or keyUsage has keyCertSign or cRLSign. That is `callerauth`'s rule (`leaf.IsCA || leaf.KeyUsage&(CertSign|CRLSign) != 0`, contracts §3A).
- `client_auth` is false when an extKeyUsage is present, is not empty, and holds neither clientAuth nor anyExtendedKeyUsage. That is Go's `checkChainForKeyUsage` for the leaf with `ExtKeyUsageClientAuth`, which ES's TLS server config requests. An empty extKeyUsage counts as none, as in Go.

**Collector.** The URI is judged first, then the end-entity rule, then client auth. `matches_expected` stays the URI-only match. The two new classifications are `identity_not_end_entity` and `identity_not_for_client_auth`. Both use the existing failure class `identity_mismatch`, so the v1 output vocabulary of failure classes is unchanged. The local runtime's `IDENTITY_CLASSIFICATIONS` accepts the two labels.

**Renew helper `--status`.** The identity record gains `end_entity` and `client_auth_usage` (`null` when the certificate cannot be decoded). The identity passes only when the URI matches and both are true. There are two new classifications, `operator_identity_not_end_entity` and `operator_identity_not_for_client_auth`, and a blocker for each. The URI blocker now appears only when the URI does not match.

**Status doc** (`.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`): the identity paragraph names the version 3 and last-field rule, Go's per-type rules, the extension encodings and the two new labels. The failure mapping lists the two leaf rules under `identity_mismatch`. `caller_authentication_docs_contract_test.go` pins both sentences.

**Tests:**
- Collector (`TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRemoteCollectorPureFunctions`):
  - 47 new malformed cases, each breaking one rule, and 21 well-formed twins that differ from one of them only in that rule and must decode.
  - 8 refused clients, checked against the exact facts and the collector's classification.
  - 17 accepted variants: clientAuth among others, anyExtendedKeyUsage, an empty extKeyUsage, cA FALSE, unique identifiers, unknown extensions, IA5 boundary `0x7F`, 4- and 16-byte IPs, ignored constructed entries, and others.
  - URI-first ordering, and the constructed `[6]` cases.
  - 11 Go-made certificates, the issuing CA among them, checked against exact facts.
- Runtime: `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeKeepsEachIdentityClassification` sends each of the 5 failing identity classifications through the local runtime. That covers `identity_malformed`, which no runtime test covered before.
- Renew helper: `TestRemoteAlphaOperatorHealthcheckTLSStatusRefusesWhatESRefusesAsAClientCertificate` runs the staged two-file helper on Go-made leaves. CA, keyCertSign, cRLSign, serverAuth-only and unknown-usage-only fail with the right classification and blocker, and without the URI blocker. A leaf with no key usages, one with clientAuth among others, and one with anyExtendedKeyUsage pass the identity check (see §8 for anyExtendedKeyUsage and OpenSSL).

**On the audited code** (`12-evidence/probes/old_vs_new_decoder.out`; the collector at `900d4eb` against the head):

```text
case                                          900d4eb  head                        
A11-3 v1 certificate with extensions          pass     malformed                   
A11-3 v2 certificate with extensions          pass     malformed                   
A11-3 version INTEGER not minimal             pass     malformed                   
A11-3 field before the extensions             pass     malformed                   
A11-3 iPAddress of 5 bytes                    pass     malformed                   
A11-3 rfc822Name not IA5                      pass     malformed                   
A11-3 dNSName not IA5                         pass     malformed                   
A11-3 constructed [6] only (G08)              mismatch mismatch                    
A11-4 CA (basicConstraints cA TRUE)           pass     not_end_entity              
A11-4 keyCertSign                             pass     not_end_entity              
A11-4 cRLSign                                 pass     not_end_entity              
A11-4 serverAuth only                         pass     not_for_client_auth         
A11-4 unknown usage only                      pass     not_for_client_auth         
accepted: clientAuth and serverAuth           pass     pass                        
accepted: issuer and subject unique ids       pass     pass                        
```

## 2. A11-1: a closed list of go-spiffe imports

`caller_authentication_typed_guard_test.go`, the auditor's sketch plus one rule:
- `goSpiffeAllowedImports` = `spiffeid`, `workloadapi`, `svid/jwtsvid`, `proto/spiffe/workload`. `callerIdentityImportForbidden` refuses `callerauthtest` and every other `github.com/spiffe/go-spiffe/v2/` package. `x509svid` is refused by the closed list now, so the explicit list keeps only `callerauthtest`.
- **Added beyond the sketch:** the allowed packages also hold readers of a peer's JWT-SVID. These are `jwtsvid.ParseAndValidate`, `jwtsvid.ParseInsecure`, `workloadapi.ValidateJWTSVID` (function and `Client` method) and the workload API client's `ValidateJWTSVID`. The guard refuses any use of them (`info.Uses`, by package path and name). A caller identity read from a bearer token would be another copy of the identity rule. Production uses none of them. ES's runtime helper uses `FetchJWTSVID` and `jwtsvid.Params`, which stay allowed, and the self-test checks that.
- Self-test: a new overlay file `internal/zzcalleridentityprobe/spiffe.go`. It has `spiffetls.PeerIDFromConnectionState`, `grpccredentials.PeerIDFromContext` and the five JWT-SVID reads, next to an allowed `FetchJWTSVID`. The guard reports exactly the 2 imports and 5 reads.

## 3. A11-2: linux/arm64, and a self-test per platform

- `callerIdentityBuildTargets` = linux/amd64, linux/arm64, darwin/arm64, and the comment says why.
- `TestCallerIdentityTypedGuardCatchesSixthCopies` now runs for every target, with the same overlay. The overlay adds one platform-only probe per platform, `es/admission/zz_calleridentityprobe_<goos>_<goarch>.go` (issuer read through an embedded request and a variable). Each target must report its own probe and no other. The test fails when one of the three probes is caught by no target, so dropping a target fails it (F05).
- New `TestCallerIdentityTypedGuardCoversTheScriptsBuildTargets`: every `GOOS=`/`GOARCH=` literal under `scripts/`, and every architecture `control_plane_target_arch` prints, must be a guard target (GOARCH as linux). Today it finds linux, amd64 and arm64, and it fails if the scan finds less, so it cannot pass vacuously. The two dynamic builds (`GOARCH=${TARGETARCH}` and the host `go env GOARCH`) cannot be pinned. `control_plane_target_arch` limits the first to amd64 or arm64 unless `CONTROL_PLANE_TARGETARCH` overrides it.
- Run time: the guard tests take 4 to 9 s here for the three targets, depending on the build cache (`guard-2fb0c6d.log`: 4.1 s).

## 4. The optional items

- **E16:** `TestAGSPublishAllowsACallerThatMatchesALaterPrefix` (ags/api). With prefixes `operator/local` and `service/control-plane`, callers under the second prefix are allowed and `service/control-plane-evil` is not.
- **F03:** the self-test probe has `resp.TLS` on an `*http.Response`, which must not be flagged.
- **Fixture:** both ES configs in `remote_alpha_prepare_es_config_tls_test.go` use `operator/local`.

## 5. Validation

All runs as the unprivileged `esci` user with a clean environment (`12-evidence/logs/`).

On the head `2fb0c6d` (`val12d.sh`, `val12d.out`):
- [x] every `.go` file changed since `725c97a` is `gofmt`-clean; `go build ./...`; `go vet ./...` for linux/amd64, linux/arm64 and darwin/arm64
- [x] Root package with the CI list of environment-only tests skipped (`root-skip-2fb0c6d.log`, 166 s)
- [x] `internal/callerallowlist`, `internal/callerauth/...`, `ags/api`, `es/config` with #33's new tests, and `internal/contracts/runtimeconfig/...` with #41's
- [x] The caller identity guard tests by name (`guard-2fb0c6d.log`)
- [x] The same checks passed on `031c02e` before the #41 merge (`val12c.out`)

On `91243f5` (the three A11 fix commits merged with `400ff7f`; `val12.sh`, `val12.out`):
- [x] ARS, AGS, EGS and CGS in full, `es/api`, `es/config`
- [x] `es/admission/...`: only `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` and `TestSQLiteV3OldBinaryRefusesWithoutMutation` fail. Both are on `.github/ci/environment-only-tests.txt` (they need an authenticated production-source probe) and fail the same way on `900d4eb`
- [x] `es/app` in full

After `91243f5` the branch changed only the two status tools, the status doc, two root test files, and by the trunk merges two `es/config` and two `runtimeconfig/v1` test files (`git diff --name-only 91243f5 2fb0c6d`). No Go package outside the root package reads the two tools, so the `91243f5` results for the other packages still hold, and the root package and the packages with new trunk tests ran again on the head.

- [ ] GitHub CI on `2fb0c6d`: run 134 is in progress. The runs on `33b67d1`, `30c7e5f`, `f6bdde8` and `031c02e` were cancelled by the next push, and `900d4eb` passed (run 109).

## 6. Trial merges with the open PRs

Each open PR head was merged into `031c02e` in a scratch worktree (`trial-merge-c.sh`, `trial-merge-c.out`). A PLANS.md conflict was resolved as a union. The tests were build, vet for all three targets, and in the root package the caller identity, docs, contract, allowlist, operator status, P0v and ES config prep tests. They also covered the caller identity, API and config packages, and the admission guards for PR 12 and PR 40 (`trial-r12c.sh`, `trial-r12c.out`, `trial-c-*.log`). `2fb0c6d` adds only #41's two test files, and #41 was one of the PRs trial-merged.

| PR | Head | Merge | Result |
|---|---|---|---|
| 12 | `4416699` | PLANS.md conflict (`trunk_dev`'s, not this repair's) | pass |
| 40 (PR 12 repairs) | `fd399a1` | PLANS.md conflict | pass |
| 31 | `b150657` | PLANS.md conflict | pass |
| 41 | `d7914c7` | clean | pass; merged into `trunk_dev` since, as `725c97a` |
| 30, 34, 35, 37 | `eed4c9b`, `9993c62`, `6a9d4c7`, `4736803` | clean | pass |
| 39 (root tests move) | `d768e5d` (the table run used `8e77b95`) | comment conflict in the moved `caller_authentication_contract_test.go` | needs the merge step below, then passes |

**PR 39 and this PR.** PR 39's repair (`f3b5289`, after its audit 03) added `TestRootKeepsOnlyItsDocsTests` in `internal/testutil`. The repository root may then keep only `*_docs_contract_test.go` files and three named files. This PR has had two other root test files since its first commits (`900d4eb` already had both), so this repair adds nothing to the conflict:
- `caller_allowlist_contract_test.go` (R6)
- `caller_authentication_typed_guard_test.go` (R4)

My first trial table missed this, because it did not run `internal/testutil`. Whichever of the two PRs merges second has to do the following. I tested it on the merge of this head with `d768e5d` (`trial-pr39-move-root.sh`, `trial-pr39-move-esci.sh`, `trial-pr39-move.out`, the diff in `pr39-move.diff`):
1. Keep both comment additions in `internal/callerauth/caller_authentication_contract_test.go`. A union of the two sides does it.
2. Move `caller_authentication_typed_guard_test.go` to `internal/callerauth/` (package `callerauth_test`, next to its name-based half) and `caller_allowlist_contract_test.go` to `internal/callerallowlist/` (package `callerallowlist_test`). In both, `executionSubstrateRepoRoot` becomes `testutil.Root`. The root then needs no `executionSubstrateRepoRoot`.
3. Fix one line in the moved guard. The docs contract rules `TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal` and `TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal` refuse the text `execution-substrate/cgs` in any file under `es/` or `internal/`. The guard's list of the five API packages names `"execution-substrate/cgs/api"` (line 86 after the move). That is a package the guard inspects, not a dependency. Two proper fixes:
   - name the API packages by directory, as the name-based half already does (`cgs/api`), and match on the package's directory;
   - or exempt the guard file in those two rules, with the reason.
   A string built at run time only to dodge the phrase check would be a hack. Recommendation: match by directory.

With steps 1 and 2 done, these pass: build, vet for the three targets, `internal/testutil` (the layout rule), `internal/callerauth/...`, `internal/callerallowlist`, the five API packages, `es/config`, and the selected `scripts/` tests. The whole root package also passes, apart from the two phrase rules and `TestTrackedGeneratedArtifactHygiene`. That last test needs a git checkout, and the trial tree is a plain copy; it passes in the repository. With line 86 left out, as a probe only, both phrase rules pass, so step 3 is the only change left. Rename detection carried this repair's edits into PR 39's moved status and renew test files.

## 7. Mutation run

`12-evidence/mutation/` holds the runner (`mutants-r12.py`, `mut12.sh`) and the logs. Each mutant is one edit to the code under test. The runner applies it in a scratch clone of the head, runs the pinning tests in order, stops at the first failure ("killed"), vets Go edits, and checks that the clone is clean afterwards.

**Final run on `031c02e`: 124 mutants, 124 killed** (`mutants-031c02e.log` and `.json`). The files it mutates and the tests it runs are byte-identical at `2fb0c6d`.

| Group | Mutants | What they break |
|---|---|---|
| D | 8 | DER element reading: tags, lengths, children |
| L | 15 | Certificate and TBSCertificate layout, the version field (A11-3) |
| X | 13 | Extensions block, critical flag, repeated extensions |
| O | 5 | Extension identifier encoding |
| S | 17 | subjectAltName: per-type rules, the URI rule, constructed entries (A11-3) |
| B | 9 | basicConstraints (A11-4) |
| I | 5 | pathLenConstraint INTEGER |
| K | 9 | keyUsage (A11-4) |
| E | 9 | extKeyUsage (A11-4) |
| C | 9 | Collector classification order and labels, runtime vocabulary |
| R | 13 | Renew helper status facts, classifications and blockers |
| F | 11 | Typed guard: closed list, JWT-SVID readers, each target, F03, the build-target pin (A11-1, A11-2) |
| W | 1 | AGS later prefix (E16) |

First killing test: the collector pure-function test for 90, the renew helper status tests for 13, the guard tests for 11, the collector, runtime and decoder-copies tests for 9, and `ags/api` for 1.

**Earlier runs.** The first run was stopped. It showed three checks that other checks already made, which `33b67d1` removed (§8, item 5). A run on the code of `33b67d1` (`mutants-run2.log`; the doc commit `30c7e5f` changes nothing it mutates or runs) killed 122 of 123 and marked F10 INVALID. The F10 edit did not compile, and in a compiling form the pin test would still have passed, because `control_plane_target_arch` alone yields amd64 and arm64. `f6bdde8` makes each scan prove that it found something. F11 was added, and both are killed (`mutants-f10-f11.log`).

## 8. Judgment calls and limits

1. **The JWT-SVID reader rule goes beyond the sketch** (§2). It closes the same kind of gap inside the allowed packages, and costs one loop over `info.Uses`. If the auditor prefers the sketch as sent, dropping `callerIdentityTokenReaders` and its loop is a clean removal.
2. **Where the decoder is stricter than Go.** In each case the tools fail a certificate that ES might accept, never the other way round:
   - the URI rule (unchanged);
   - fields after basicConstraints' INTEGER, and a negative pathLenConstraint (RFC 5280 says `INTEGER (0..MAX)`);
   - bytes after an extension's one value;
   - fields after the extensions block.

   None of these occurs in a certificate a CA issues.
3. **Where the decoder stops mirroring Go.** It mirrors Go for what the caller rule reads: the version and extension layout, the subjectAltName, basicConstraints, keyUsage, extKeyUsage and extension identifiers. It does not reimplement the rest of Go's certificate parser. Probe (`12-evidence/probes/extprobe/`): a leaf with a malformed extension value of each kind, made with Go 1.26.5 and checked with OpenSSL 3.0.13.
   - Go refuses malformed subjectKeyIdentifier, nameConstraints, cRLDistributionPoints, certificatePolicies and authorityInfoAccess.
   - Both tools' `openssl verify` refuses the first three (and a malformed authorityKeyIdentifier, which Go accepts).
   - certificatePolicies and authorityInfoAccess pass OpenSSL. So a leaf with one of those malformed, and otherwise the expected identity, would pass the tools while ES refuses it at the handshake. ES still fails closed.
   - Inference: no CA in this project issues such a leaf. If the tools ever need to match ES exactly, the proper route is an ES subcommand that runs `callerauth` on a certificate file, not more Python. That is out of scope here.
4. **The renew helper's `openssl verify -purpose sslclient` is stricter than Go for anyExtendedKeyUsage.** OpenSSL's SSL-client purpose refuses a leaf whose only extended key usage is anyExtendedKeyUsage, while Go accepts it.
   - That check predates this PR. The test records it: the identity check passes and the verification fails.
   - The collector's `openssl verify` has no purpose, so it does not do this.
5. **Checks that other checks already make were removed** (`33b67d1`), each found while writing the mutants:
   - "A3 is the last field" followed from the layout list;
   - a URI's IA5 check followed from the stricter URI check;
   - the five-byte subidentifier limit followed from the value limit once the leading byte is not `0x80`.

   Each rule is now one check, so no mutant of it is equivalent. The docstring keeps the reasoning for the subidentifier limit.
6. **The collector test certificates use one more Go-made CA leaf per rule** (IsCA, CertSign, CRLSign, serverAuth only, anyExtendedKeyUsage, no key usages, IP and email SANs) and the issuing CA itself, so the decoder is checked against Go's own encoder and not only against hand-encoded DER.

## 9. For the narrow re-audit

- Delta: `900d4eb..2fb0c6d` without the five `trunk_dev` files (`README.md` from #36, the two `es/config` test files from #33, the two `internal/contracts/runtimeconfig/v1` test files from #41), `12-evidence/delta-900d4eb.diff`. No repair commit touches those five files.
- The v2 manifest (`ef001237…aa98`) is the whole PR against `trunk_dev` `725c97a`, for the merge gate.
- The PR 39 merge step in §6 is for whichever PR merges second. It is not in this PR, because PR 39's `internal/testutil` and its layout rule are not on `trunk_dev` yet.
- Product-facing code: the two status tools and the local runtime's label list. Everything else in the delta is tests and one doc.
- Before deploying to the box, the read-only allowlist-prefix check from `10-follow-up.md` §6 still applies.
