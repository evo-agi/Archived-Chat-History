# Caller authentication follow-up: implementation report

**PR:** [#38](https://github.com/evo-agi/Execution-Substrate/pull/38) (draft) into `trunk_dev`, branch `claude/project-thread-i9yve2`.
**Base:** `trunk_dev` `fdfa3bc67cdedb11f583a19df7036c20c612741f` (#29's squash merge). The branch started from `76c030f` (#27's squash merge) and merged `fdfa3bc` in `900d4eb`; the merge was clean, and the only files both sides changed are `PLANS.md`, `.docs/execution_lifecycle/contracts.md` and `.docs/system_overview/boundaries.md`.
**Head:** `900d4eb73862c451692e6c5f601d6061cec72709`. Five commits, `daac305`, `e62829c`, `62c4af6`, `117eaeb` and `b644851`, then the merge `900d4eb`.
**v2 audit manifest (head `900d4eb`):** `manifest_sha256` `c21c4087fa146f6b603394dbf61a4f93993138ebda99aae6f5ba227398d46736`, `textual_diff_sha256` `0c45ede52a926b0d176e9d811a8043dae9ed51f9bd09757012660223c7d53108`, 29 files, `head` `fdfa3bc` (HEAD reset to `origin/trunk_dev` = `fdfa3bc`, upstream `origin/trunk_dev`). Two runs gave byte-identical output (`10-evidence/manifest/manifest-v2-900d4eb.json`). Tool SHA-256 `c08597e2…a3ca`, checked before the run. The earlier manifest for `b644851` against `76c030f` (`a5b2c63e…1263`) differs only in the three files the merge touched.
**Scope:** `follow-up-pr-scope.md`, items R4, R6, N1 and O7-1. O2-2 is not in scope.

## 1. Summary

| Item | What changed | Product code? |
|---|---|---|
| R6 | New package `internal/callerallowlist`: one rule for which allowlist prefixes are valid and how a caller's path matches one. ARS, AGS and ES validate their `authorization.allowed_spiffe_path_prefixes` with it at startup and authorize with it. The three `matchesAuthorizedPathPrefix` copies are removed. | Yes: three config packages, three API packages, one new package |
| R4 | A typed half of the root guard: type-checks every production package of the module for linux/amd64 and darwin/arm64. The name-based half stays. | No (test only) |
| N1, O7-1 | Both operator healthcheck TLS status tools decode the operator certificate's subjectAltName from DER instead of OpenSSL's printed text. | Scripts only |

Docs: contracts §3A records the allowlist-prefix rule and the new package's ownership. The ARS, AGS and ES contract sections, lifecycle contract §4, configuration reference, boundaries §11, architecture and PLANS.md (a status entry and a current-state fact) refer to it. The operator status doc says where URI SANs come from. A stale `["operator"]` allowlist in `.runbooks/system/v1_bringup.md` is now `["operator/local"]`. Docs tests pin each of these.

## 2. Design

### 2.1 R6: `internal/callerallowlist`

- `ValidatePrefix(prefix)`: the prefix is valid exactly when `spiffe://execution.internal/` + prefix passes `callerauth.ParseSPIFFEID`, and it has at least `MinimumSegments` (2) segments. So the allowlist uses the same segment grammar as §3A by construction; there is no second grammar. Errors: `ErrNotCanonical` and `ErrTooBroad`.
- `ValidatePrefixes(field, prefixes)`: an empty list is `<field> is required`; otherwise the first bad entry is `<field>[i]: <error>`.
- `Matches(id callerauth.SPIFFEID, prefix)`: false unless `ValidatePrefix(prefix)` passes; then `path == prefix || HasPrefix(path, prefix+"/")`. The function takes the authenticated ID type, not a string, so only a path that `callerauth` produced can be matched.
- `MatchesAny(id, prefixes)`.

**Placement.** §3A says `internal/callerauth` owns authentication only, and AGENTS.md §6 warns against widening a shared package casually. So the rule lives in its own package, which owns only the shape of a prefix and the match. It owns no allowlist content and no route. Boundaries §11 has a row for it, and PLANS.md has a status entry, as AGENTS.md §7 requires for a new shared package.

**Why the matcher moved too** (judgment call). The scope asked for one shared validator. The matcher is the other half of the same rule, and #27's PR text listed the three copies as a follow-up with no trigger. For every prefix that passes validation, the new matcher gives the same answer as the old copies. The only difference: the old copies trimmed slashes, so a server built directly with `/service/execution` matched `service/execution`. Now an invalid prefix matches nothing. Production servers get only validated prefixes, so this changes nothing in a deployment.

**Effect on deployments.** ARS and AGS used to refuse only blank prefixes. They now refuse at startup what ES refused, and all three also refuse a segment character outside `A-Z a-z 0-9 . - _` (for example a space, `?`, `%` or a non-ASCII letter), which ES used to accept. Every configuration the repo writes uses canonical two-segment prefixes: the example configs, `scripts/72_supported_local_setup.sh`, and every test config. The box's live configs are not in the repo; see §6.

### 2.2 R4: typed guard (`caller_authentication_typed_guard_test.go`)

- For each target, `go list -deps -export -json=… ./...` with `GOOS`/`GOARCH` set, `CGO_ENABLED=0`, `GOFLAGS=-mod=readonly`, `GOPROXY=off`, `GOENV=off` and `GOTOOLCHAIN=local`. This is the same environment discipline as `es/admission`'s typed guard.
- It selects every package whose module is the main module, including packages that only a dependency reaches (for example under `_` or `testdata` directories, which `./...` skips), except `execution-substrate/internal/callerauth` and its subpackages. Each package's `GoFiles` are parsed and type-checked against the export data.
- It reports:
  - a selection of the field `net/http.Request.TLS`;
  - the `crypto/x509.Certificate` fields `URIs`, `Issuer`, `RawIssuer` and `Extensions`. Field identity is checked against the struct's own fields (`isFieldOf`), so aliases, embedding and variables are covered;
  - an import of `github.com/spiffe/go-spiffe/v2/svid/x509svid` or `execution-substrate/internal/callerauth/callerauthtest`;
  - in the five API packages, any selection of a `crypto/tls` object.
- It requires at least 40 checked packages, the five API packages, `es/admission` and `internal/callerallowlist`, and no `callerauth` package.
- Findings are reported at unadjusted positions (`PositionFor(pos, false)`), so a `//line` directive cannot move a finding to another file. PR 12's position guard (`TestOperationalGuardReadsUnadjustedPositions`, which walks every test file of the module) refused the first version's `fset.Position` read in the trial merge; `b644851` fixed it.
- **Self-test** (`TestCallerIdentityTypedGuardCatchesSixthCopies`): it writes the red-team's two probes, plus alias, embedding, promoted-field, `Extensions`, `RawIssuer`, `callerauthtest` and `//line` spellings, to a temp directory. It maps them into the module with a `go build -overlay` file and requires exactly the 13 expected findings, no more and no fewer. Nothing is written into the repository tree.

**Deviation from the scope** (judgment call). The scope listed go-spiffe's `spiffeid` among the banned imports. The trial merge with PR 12 (`4416699`) failed the guard: `es/admission/reliable_submit_operational_handoff.go` imports `spiffeid` and uses `spiffeid.ID` as the value type of its private handoff caller. `spiffeid` cannot read a certificate. Getting a URI out of one is the `URIs` read the guard already reports, and `x509svid`, which does read the identity from a certificate, stays banned. So the ban would have blocked PR 12 for no security gain. `117eaeb` removes `spiffeid` from the list and says why in the code.

**Known limits** (also in the PR text). The guard does not see reflection, or hand parsing of `Certificate.Raw`. A package under a `_`, `.` or `testdata` directory is checked when any package imports it, because it is then in a binary; one that nothing imports is in no binary. The repo has no Go files in such directories, no nested module and no `replace` directive today. Server-side TLS hooks (`VerifyPeerCertificate`, `VerifyConnection`, `ConnContext`) can reach a certificate without `Request.TLS`. Reading its identity there is still a `URIs`/`Issuer`/`Extensions` read and is reported.

### 2.3 N1, O7-1: DER decoding in both status tools

- **Collector.** The fixed sudo allowlist entry `openssl x509 -in <cert> -noout -ext subjectAltName` becomes `openssl x509 -in <cert> -outform DER`. The public certificate's DER is consumed in memory and never emitted. `extract_uri_sans(der)` decodes the certificate structurally:
  - outer SEQUENCE spanning all bytes; three parts `SEQUENCE, SEQUENCE, BIT STRING`;
  - at most one `[3]` extensions block holding exactly one SEQUENCE of Extension SEQUENCEs, each `OID [BOOLEAN] OCTET STRING`, where the optional critical flag is one byte, `0x00` or `0xFF` (`b644851`; Go's certificate parser refuses any other value, so the status tools no longer pass a certificate that ES cannot parse);
  - no repeated extension OID;
  - the SAN value is exactly one SEQUENCE filling the OCTET STRING;
  - only one-byte tags, and only definite, minimal lengths (short form, or long form of 1 to 4 bytes with no leading zero, never used for a length under 128), each inside its parent.
  
  It returns the `[6]` URI entries in certificate order with duplicates, `[]` when there is no URI SAN, or `None` when anything is malformed. A URI must be 1 to 256 bytes of printable ASCII without spaces. `None` is classified `identity_malformed` and fails with `identity_mismatch`.
- **Renew helper `--status`.** It decodes the DER of `openssl x509 -outform DER` with the same decoder. `uri_san_count` is `null` and the classification is `operator_identity_malformed` when the SAN is malformed. The printed SAN text is kept in the summary for reading only.
- **One decoder, two copies** (judgment call). The collector is streamed over SSH with its hash pinned. The Mac-side `operator-healthcheck-tls-status` and `-renew` routes stage exactly the two renew shell scripts (`scripts/remote_alpha_operator.sh:2770-2786` and its help text). So neither tool can load the other at run time. My first version had the renew helper import the collector from its own directory. Its tests passed from the repository, but on the box it would have reported `operator_identity_malformed` for every certificate. The decoder therefore sits between `# BEGIN uri-san-der-decoder` and `# END uri-san-der-decoder` in both files, and `TestRemoteAlphaOperatorHealthcheckTLSURISANDecoderCopiesMatch` fails unless the lines between the markers are identical. The renew helper's N1/O7-1 tests and a pass case run the helper from a temp directory holding only the two staged scripts in their `scripts/` and `scripts/internal/` layout. Against the import version, that pass case fails with `operator_identity_malformed` (`10-evidence/logs/staged-import-version.log`).

## 3. Tests that fail on the old code

Run on `76c030f` with the new test files copied in (and `internal/callerallowlist` present but unwired, because the root test refers to its error values). Logs are in `10-evidence/logs/old-code-*.log`.

| Test | Result on `76c030f` |
|---|---|
| `TestARSAGSAndESCheckAllowlistPrefixesWithTheSharedRule` | ARS and AGS load 11 of the 12 refused cases (all but `""`). ES loads `operator/lo cal` and `operator/local?x`, and refuses the others with its old messages, which do not wrap the shared errors. |
| `TestARSAllowlistPrefixThatFailsTheSharedRuleMatchesNothing` | 500 from the counting store: the caller got past authorization with prefix `/service/execution` |
| `TestAGSAllowlistPrefixThatFailsTheSharedRuleMatchesNothing` | 200, published |
| `TestESAllowlistPrefixThatFailsTheSharedRuleMatchesNothing` | 200, contract answered |
| `TestConfigValidateRejectsBroadOrMalformedSPIFFEPathPrefixes` (5 new cases) | 4 accepted: space, query, percent encoding, non-ASCII |
| The red-team's `rtprobe.go` and `zz_rtprobe.go` as real files | old `TestCallerIdentityIsReadOnlyByCallerauth` passes; `TestCallerIdentityIsReadOnlyByCallerauthByType` reports 6 findings on each target |
| `TestRemoteAlphaOperatorHealthcheckTLSStatusDecodesURISANsFromTheCertificate` | 5 of 5 fail: comma, space, `, DNS:x` and DNS-text cases pass the old status; the DNS-text-plus-other-URI case is counted as 2 URI SANs |
| `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRemoteCollectorPureFunctions` | fails (old `extract_uri_sans` takes text) |
| `TestRemoteAlphaOperatorHealthcheckTLSURISANDecoderCopiesMatch` | fails (no marked block) |
| `TestRemoteAlphaOperatorHealthcheckTLSStatusCallsAnUnreadableCertificateMalformed` (added in `b644851`) | `identity.uri_san_count = 0, want null` |

`TestRemoteAlphaOperatorHealthcheckTLSStagedStatusPassesTheExpectedIdentity` passes on the old code. That is expected: the old helper had no second file to depend on. The test exists to catch the import design.

## 4. Validation on the head

All runs used an unprivileged user (`esci`, UID 30033) started with `runuser -u esci -- env -i`, in a copy of the tree checked against the working tree before each run. Go 1.26.5, `GOFLAGS=-mod=readonly`, `GOPROXY=off`.

Go code outside `_test.go` files has not changed since `62c4af6`: `117eaeb` changes only the typed guard test, and `b644851` changes root test files, the two status scripts and one doc. So the package runs on `62c4af6` stand, and `b644851` was re-checked where it changed something.

**On `62c4af6`** (`10-evidence/validation/val-62c4af6.out`):

| Check | Result |
|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | pass |
| Race detector: `internal/callerallowlist`, `internal/callerauth/...`, the five API packages, `es/config`, `cgs/policy` | pass |
| Race detector: the five services' mutual TLS caller authentication tests and the expired-certificate test | pass |
| `./ars/... ./ags/... ./egs/... ./cgs/...` in full | pass |
| `es/admission` in full | pass |
| Root package with CI's list of host-caused failures skipped | pass |
| `es/app` in full | 1 failure: `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` ("Vault dev/test HTTPS listener did not appear"). On `76c030f` it fails too, one step earlier ("SPIRE server admin socket did not appear", `old-code/es-app-supported-local-base.log`). The test starts real SPIRE and Vault processes, which this container does not run reliably; nothing in this PR touches that path. |

**On `b644851`** (`10-evidence/validation/val2-b644851.out`):

| Check | Result |
|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | pass |
| Root package with CI's skip list (154 s) | pass |
| `FuzzPrefixRule` for 60 s: the prefix rule against `callerauth.ParseSPIFFEID`, 2.78 million inputs | pass, no disagreement |
| `gofmt -l` on every changed `.go` file | clean |
| CI on PR #38 (`b644851`) | `build, vet and test` passed ([run 45264898932](https://github.com/evo-agi/Execution-Substrate/actions/runs/45264898932)) |

**On `900d4eb`, the merge with `trunk_dev` `fdfa3bc`** (`10-evidence/validation/val3-900d4eb.out`):

| Check | Result |
|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | pass |
| Root package with CI's skip list | pass |
| `internal/callerallowlist`, `internal/callerauth/...`, `./ars/...`, `./ags/...`, `es/api`, `es/config` | pass |
| `./es/admission/...` | `es/admission` passes; the only failures are `TestSQLiteV4PreviousSchema3BinaryRefusesWithoutMutation` and `TestSQLiteV3OldBinaryRefusesWithoutMutation`, which need an authenticated probe binary and are on `trunk_dev`'s list of environment-only tests |
| CI on `900d4eb` | `build, vet and test` passed ([run 45271473548](https://github.com/evo-agi/Execution-Substrate/actions/runs/45271473548)) |

The mutation runs below are on `b644851`. The merge changed none of the files the mutants edit or the tests that kill them.

## 4A. Mutation testing

The runner (`10-evidence/mutation/mutants-fu.py`) applies each mutant to a clean clone, builds, and runs the tests that should kill it, as `esci` under `env -i`. A decoder mutant edits the marked block in both the collector and the renew helper the same way, so the copies-match test still passes and only behaviour tests can kill it. The decoder mutants are killed by the collector's hand-encoded DER cases; the renew helper's copy is covered by the same cases through the copies-match test, and its own tests use real certificates.

**Run 1, on `117eaeb`: 48 mutants, 40 killed.** One was invalid (A12 left a variable unused; rewritten as `0*i`). Seven survived:

| Mutant | What survived | Why | Fix in `b644851` |
|---|---|---|---|
| D01 | high-tag-number tags accepted | the high-tag case's next bytes also failed the length check | a tag-31 name laid out so a one-byte-tag reader sees a well-formed 31-byte element, followed by the expected URI |
| D02 | long-form length with a leading zero accepted | the case's length (6) also failed the minimal-length check | a 133-byte URI whose length is written `82 00 85` |
| D04 | element may run past its parent | no case | a DNS name whose length runs past the SAN sequence into the next extension |
| D06 | certificate part tags not checked | only a two-part case | a signature encoded as an OCTET STRING |
| D08 | extensions block may hold two sequences | no case | `[3]` holding two SEQUENCEs |
| D09 | extension field count not checked | the four-field case also ended in NULL | four fields that start with the OID and end with the OCTET STRING |
| R03 | renew status treats a failed DER read as "no URI SAN" | no case | `TestRemoteAlphaOperatorHealthcheckTLSStatusCallsAnUnreadableCertificateMalformed` |

Each new malformed case has a well-formed twin in the test that decodes to its URI SAN, so the case is malformed only by its one named rule.

**Run 2, on `b644851`: 64 mutants, 64 killed** (`mutation/mut-b644851.out`, `mutation/mutants-b644851.log.json`). These are the 48 of run 1, with D10 updated for the new critical-flag value check, plus 16 new decoder mutants D22 to D37: certificate tag, extension tag, extension OID tag, extension value tag, critical flag tag, length and value, a malformed certificate, TBS, extensions block, extensions sequence, extension fields and general names, an element header past the end, an indefinite length, and missing length octets.

Not mutated: the `count > 4` check. Without a leading zero, a length of five or more bytes is at least 2^32, which fails the bounds check anyway, so that mutant is equivalent.

**New tests on the old code.** `TestRemoteAlphaOperatorHealthcheckTLSStatusCallsAnUnreadableCertificateMalformed` fails on `76c030f`: `identity.uri_san_count = 0, want null` (`old-code/renew-unreadable.log`).

## 5. Trial merges with the open PRs

Each open ES PR head was merged with this branch in a scratch tree, then built, vetted, and run with the root caller-identity, docs, contract, allowlist and status tests, plus `internal/callerallowlist`, `internal/callerauth`, the ARS, AGS and ES API packages and `es/config`. First on `117eaeb`, then with `b644851` applied on top (`trial/trial-117eaeb.out`, `trial/trial-b644851.out`):

| PR | Merge | On `b644851` |
|---|---|---|
| 12 (`4416699`) | conflict in PLANS.md only (both status entries kept) | build, vet, tests pass |
| 29, 30, 33, 34, 35, 36, 37 | clean | build, vet, tests pass |
| 31 | conflict in PLANS.md only (both kept) | build, vet, tests pass |

Two findings, both fixed in this PR:

1. **`spiffeid`** (`117eaeb`): PR 12 uses `spiffeid.ID` as a value type, so banning the import would have failed PR 12. See §2.2.
2. **Position reads** (`b644851`): PR 12's `TestOperationalGuardReadsUnadjustedPositions` refuses any adjusted `FileSet.Position` read in any test file of the module, and the typed guard had one. With `PositionFor(pos, false)` that guard passes on the merge (`trial/trial-pr12-b644851-position-guard.log`).

PR 12's `es/admission/...` and `es/api` were also run on the merge (`trial/trial-pr12-admission.log`). Apart from the position guard, the only failures are PR 12's three schema-probe tests, which fail without the authenticated opener in their environment and are on PR 12's own list of environment-only tests (`.github/ci/environment-only-tests.txt`).

## 6. Before deploying to the box (read-only)

After this PR, ARS, AGS and ES refuse to start if a live allowlist prefix is not a canonical path of at least two segments. Run this read-only check in the box session before deploying. It prints only the prefixes:

```sh
for f in /etc/execution-substrate/ars.json /etc/execution-substrate/ags.json /etc/execution-substrate/es.json; do
  sudo python3 -I - "$f" <<'PY'
import json, re, sys
path = sys.argv[1]
try:
    with open(path) as handle:
        prefixes = json.load(handle)["authorization"]["allowed_spiffe_path_prefixes"]
except FileNotFoundError:
    print(path, "missing: find the service's config path with systemctl cat")
    sys.exit(0)
segment = re.compile(r"[A-Za-z0-9._-]+")
for prefix in prefixes:
    parts = prefix.split("/")
    ok = len(parts) >= 2 and all(segment.fullmatch(p) and p not in (".", "..") for p in parts)
    print(path, repr(prefix), "ok" if ok else "REFUSED after PR 38")
PY
done
```

Every line must say `ok`. This is in addition to #27's U1 check of the client certificates.

## 7. For the auditor and the red-team

- Is `internal/callerallowlist` the right home, or should the rule be part of `internal/callerauth` with §3A's ownership sentence changed?
- The matcher now fails closed on an invalid prefix at the API level (§2.1). Is there any non-config path that builds a server with prefixes?
- The typed guard's coverage and limits (§2.2), and the `spiffeid` deviation.
- The DER decoder's strictness (§2.3): it calls some certificates malformed that Go's parser accepts, such as a URI SAN that holds a space, is empty, or is longer than 256 bytes. `callerauth` refuses each of those identities anyway, and for a status tool a refusal only fails the status. It accepts an explicit critical flag of `0x00`, which strict DER forbids (a DEFAULT value must be omitted) but Go accepts, so the tool does not fail a certificate ES accepts. Is that the right line?
- Whether the two-copies design for the decoder is acceptable, or the staged route should copy a third file instead (that would change the route's "stages only" contract, which docs and help text pin in many places).

## 8. Evidence (`10-evidence/`, listed in `SHA256SUMS`)

All under `10-evidence/`, with SHA-256 sums in `10-evidence/SHA256SUMS`.

- `old-code/`: the new tests on `76c030f` (`root.log`, `api.log`, `guard-probes.log`, `renew-unreadable.log`) and the base `es/app` bring-up failure (`es-app-supported-local-base.log`).
- `validation/`: `val-62c4af6.out` with its logs (`race-unit.log`, `race-app.log`, `apps.log`, `admission.log`, `root-skip.log`, `es-app.log`), `val2-b644851.out` with `root-skip-b644851.log` and `fuzz-60s.log`, and `val3-900d4eb.out` with `root-skip-merge.log`, `pkgs-merge.log` and `admission-merge.log`.
- `staged-import-version.log`: the import design passing in the repository and failing staged (§2.3).
- `trial/`: trial outputs and per-PR logs for both heads, the PR 12 admission run and the position-guard rerun.
- `mutation/`: the runner as used on each head (`mutants-fu-117eaeb.py`, `mutants-fu.py`), and each run's verdicts, log and JSON.
- `manifest/`: both v2 manifest runs for `900d4eb`, and the earlier pair for `b644851`.
