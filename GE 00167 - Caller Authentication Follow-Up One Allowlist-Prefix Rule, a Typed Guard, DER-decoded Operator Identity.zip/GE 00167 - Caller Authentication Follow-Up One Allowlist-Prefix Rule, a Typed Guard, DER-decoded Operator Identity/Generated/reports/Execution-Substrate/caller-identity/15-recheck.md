# ES PR #38 recheck 15: diff-only check of 2fb0c6d..26cb86f

- Pull request: evo-agi/Execution-Substrate #38 (draft).
- Head: `26cb86fe5018e21d5c12728d0c1626683d29d693`, tree `c5b4996e…`.
- Base: `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690` (#39, with #37 before it).
- Previous: `13-re-audit.md` (ACCEPT at `2fb0c6d`, nits N13-1 and N13-2).
- Writer's report: `14-repair.md` (sha256 `bbbbfabe…71b4b`).
- Scope (coordinator, 01:03Z):
  - N13-1 and N13-2;
  - the shared API-directory list and its new missing-package pin;
  - the hand-merged comment conflict;
  - the move of the two root tests;
  - that product code is unchanged since `2fb0c6d`;
  - CI.
- Read-only: nothing was pushed, commented or merged. No subagents were used.

## 0. Verdict in plain words

**PASS. `26cb86f` keeps the re-audit 13 ACCEPT and closes both nits. Nothing new needs fixing.**

- **Product code** is byte-identical to `2fb0c6d`, and `trunk_dev` did not touch any of those files.
- **N13-1:** the 8- and 32-byte iPAddress cases are in, and my H09 and H09b mutants are now killed.
- **N13-2:** the doc carries the suggested sentence, and a docs contract test pins it.
- **The shared API-directory list and its pin** work:
  - a planted sixth `api` package fails the guard;
  - dropping any list entry fails it too.
- **The merge** differs from git's own result only in the hand-merged comment, which now reads correctly.
- **The move** is the same edit I reproduced in re-audit 13.
- **Whole module against `trunk_dev` `4c991ba`:** 7,166 shared verdicts, 0 different, 93 head-only, all passing.
- **GitHub CI run 147 on `26cb86f`:** passed.

## 1. Provenance (PASS)

Log: `provenance/provenance-15.log`; script: `provenance/provenance-15.sh.txt`.

- Heads:
  - the branch and `refs/pull/38/head` are both `26cb86f`;
  - `trunk_dev` is `4c991ba`, which is also the merge base;
  - `2fb0c6d` is an ancestor of the head.
- Commits since `2fb0c6d`, first parent:
  - `80b7b1d`: the nits;
  - `93524f9`: the shared list;
  - `1e20a0e`: merge of `4c991ba`;
  - `f588c29`: the move;
  - `26cb86f`: the pin.
- **Merge `1e20a0e`:**
  - `git merge-tree` reports one conflict, in `internal/callerauth/caller_authentication_contract_test.go`.
  - The merge commit differs from the merge-tree result only in that file.
  - The difference matches the writer's `2-merge-vs-merge-tree.diff`, apart from the conflict-marker labels, which carry the commit names given to merge-tree. That is also why the two merge-tree tree ids differ.
- **v2 manifest** (operating-protocol tool, sha256 `c08597e2…a3ca`, v2 recipe):
  - two runs are identical, and byte-identical to the writer's `manifest-v2-26cb86f.json` and `-run2.json`;
  - `textual_diff_sha256` `2848606e…fc94`, `manifest_sha256` **`a59b163f…7661`**, 32 files.
- **`14-evidence/SHA256SUMS`:** all 33 entries OK.

## 2. Product code unchanged since 2fb0c6d (PASS)

I checked every non-test, non-doc path in the PR's diff against `trunk_dev`, at both points:
- `ags/api/server.go`, `ags/config/config.go`
- `ars/api/server.go`, `ars/config/config.go`
- `es/api/server.go`, `es/config/config.go`
- `internal/callerallowlist/callerallowlist.go`
- the renew helper, the collector, and the Mac status script

For all ten files:
- the blob at `26cb86f` equals the blob at `2fb0c6d`;
- the blob at `4c991ba` equals the blob at `725c97a`.

So the PR's product change is byte-identical to the one re-audit 13 accepted.

The PR's path list changed only by moves:
- #39 moved the status, renew and prep tests into `scripts/`;
- this PR moved the two guard and contract tests into `internal/`.

## 3. N13-1 and N13-2 (CLOSED)

**N13-1** (`80b7b1d`):
- `ip_eight_bytes` (an IPv4 address and mask) and `ip_thirty_two_bytes` (an IPv6 address and mask) are added to the refused list, each with a well-formed 4- or 16-byte twin.
- My re-audit 13 mutants, re-run at the new test location in `scripts/` (`mutants/`):
  - H09, which accepts 8 bytes in both copies: **killed**;
  - H09b, which accepts 32 bytes: **killed**;
  - H08 and H12 are still killed, which shows the moved tests still run the decoder.

**N13-2** (`80b7b1d`): the identity paragraph of `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` has the suggested sentence word for word, and `TestCallerAuthenticationContractIsDocumentedOnce` pins it.

## 4. The shared list and the pin (PASS)

**The list** (`93524f9`):
- `callerIdentityAPIDirs` lives in the name-based half.
- The typed half builds its import paths as `callerIdentityModule + "/" + dir`.
- After the move, the two CGS phrase rules see only `cgs/api` and pass.

**The pin** (`26cb86f`): the name-based walk records every production package in a directory named `api` that is not on the list, and fails on it.

Independent probe (`probes/pin/`, `runs/pin-probe.log`): on a copy of the head I added `xgs/api/server.go`, which reads `r.TLS`, and `internal/zzsvc/api/api.go`, a plain constant.
- **Name-based half:** reports both directories as "holds a service API package that callerIdentityAPIDirs does not list".
- **Typed half:** reports the `r.TLS` read on all three targets.

My mutants:

| Mutant | What it does | Result |
|---|---|---|
| P01 | drops `cgs/api` from the list | killed, only by the pin |
| P02 | drops `es/api` | killed |
| P04 | builds the typed import paths without the slash | killed by both typed tests |
| P05 | lists a missing directory | killed ("walk did not reach") |
| F05, F13 | the guard mutants at the new location | killed |
| P03, P06 | turn the pin off | survive |

P03 and P06 survive because they matter only when an unlisted `api` directory exists. That is the writer's G03, and my probe above shows the pin's check itself works. There is no in-repo self-test for the pin. That matches the F17 situation in re-audit 13 and needs no action.

## 5. The comment merge and the move (PASS)

**Comment** (`1e20a0e`, `runs/merge-1e20a0e-vs-merge-tree.diff`):
- It keeps this PR's text and adds #39's point in one sentence: "…whatever its build constraints, and walks the repository from its root (see package testutil); TestCallerIdentityIsReadOnlyByCallerauthByType (…) is the typed half…".
- There is no leftover fragment, which was the blind-union problem in re-audit 13 §8.

**Move** (`f588c29`, `runs/move-f588c29.diff`):
- Two renames, at 96% and 98% similarity.
- Package names, the `testutil` import and `executionSubstrateRepoRoot` → `testutil.Root`.
- It is line for line the move diff I reproduced in re-audit 13. The only differences are hunk offsets, because `93524f9` adds five lines above.
- The root now holds only docs tests, and `TestRootKeepsOnlyItsDocsTests` passes.

## 6. Regression and CI

**Whole module**, as an unprivileged user, base `4c991ba` against head `26cb86f` (`runs/full-*.log.gz`, `runs/compare-verdicts-4c991ba-26cb86f.txt`):
- 7,166 shared verdicts, 0 different;
- 93 head-only, all PASS;
- the same 18 top-level failures on both sides:
  - the 16 known container-only ones;
  - `TestMarkdownRelativeLinksResolve` and `TestRunbookPathMentionsExist`, which arrived with #37. Both fail with "git ls-files inventory failed", because an exported tree has no `.git`.

**Build and static checks** (`runs/bv-h15.log`):
- build, and vet for linux/amd64, linux/arm64 and darwin/arm64: clean;
- gofmt: clean on all 21 Go files the PR changes against `trunk_dev`;
- the collector parses, and `bash -n` passes on the renew helper.

**GitHub CI:**
- workflow `go`, run 45299743778 (run number 147) on `26cb86f`;
- completed at 01:14:14Z with conclusion **success** (`runs/ci-26cb86f.txt`).

The writer's first `es/app` failure (leftover SPIRE processes) did not show up in my whole-module run or in CI. Inference: it is environmental, as the writer says.

## 7. Evidence

`15-recheck-evidence/` (SHA256SUMS inside) has:
- `README.md`;
- `provenance/`: the log, the script and the manifest runs;
- `probes/pin/`: the two planted files;
- `runs/`: the whole-module logs (gzipped), the comparison, build and vet, the pin probe, the per-commit diffs and the CI record;
- `mutants/`: results and gzipped logs;
- `scripts/`: every script used, as `.txt`.

The leak scan (gz contents included) finds no private data. Its only two hits are the repository's own rfc822Name test fixtures (`operator\x80@` and `operator\x7f@` at the reserved `example.invalid` domain) inside `runs/nits-80b7b1d.diff`. No subagents were used.
