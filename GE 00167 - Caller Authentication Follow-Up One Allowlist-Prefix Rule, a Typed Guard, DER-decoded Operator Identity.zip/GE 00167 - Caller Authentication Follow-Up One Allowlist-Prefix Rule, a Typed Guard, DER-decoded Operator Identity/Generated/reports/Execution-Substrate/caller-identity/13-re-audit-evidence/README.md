# Evidence for 13-re-audit.md (ES PR #38, narrow re-audit of 900d4eb..2fb0c6d)

All runs used an unprivileged user (`scripts/run-as-ci.sh.txt`), on trees exported from `2fb0c6d` (head) and `725c97a` (base). Scripts are saved as `.txt`. The certificates are public PEMs of throwaway probe certificates; there are no private keys anywhere here.

- `provenance/`
  - `provenance-13.log`, `provenance-13.sh.txt`: heads, commits, merge-tree checks, the delta hash and the 12-evidence SHA256SUMS check.
  - `manifest-v2-2fb0c6d-run{1,2}.json`, `manifest-run1.stdout.txt`: the two v2 manifest runs, `manifest_sha256` `ef001237…aa98`.
- `probes/guard/`
  - g38ra: the red-team probes.
  - g38rb: spiffetls, grpccredentials, jwtbundle and ParseAndValidate through a function value.
  - g38rc: the linux/arm64-only file.
  - Log: `runs/guards-probes.log`.
- `probes/dercraft/`
  - `zz_audit_der2_test.go.txt`: crafts the 43 certificates and asks callerauth over mTLS. Log: `runs/der2-es.log`.
  - `der_probe2.py.txt`: runs them through both tools at 2fb0c6d. Log: `runs/der2-tools-h38r.log`.
  - `der_probe_900d4eb.py.txt`: the same at 900d4eb. Log: `runs/der2-tools-900d4eb.log`.
  - Merged table: `runs/der2-table.md`.
- `certs/`: the probe CA and the 43 certificates.
- `runs/`
  - `full-b38r.log.gz` (725c97a) and `full-h38r.log.gz` (2fb0c6d): whole-module runs. Exit codes are in `full-exit.txt`; both are 1 because of the 16 known container-only failures. The comparison is in `compare-verdicts-725c97a-2fb0c6d.txt`.
  - `bv-h38r.log`: build, vet ×3, gofmt, python parse, `bash -n`.
  - `pr-tests-h38r.log`: the PR's tests.
  - `trial-pr39*.log`, `pr39-*.diff`: the PR #39 trial merge, steps 1-2, and the audit's step 3.
  - `trial-pr40*.log`: the PR #40 trial merge.
  - `ci-2fb0c6d.txt`: GitHub CI run 134.
- `mutants/`: `results.json` (48 mutants), `results-F19b-H09b-H09c.json` (3 follow-ups), `run.out`, and one gzipped log per mutant.
- `scripts/`: every script used, as `.txt`.

No subagents were used.
