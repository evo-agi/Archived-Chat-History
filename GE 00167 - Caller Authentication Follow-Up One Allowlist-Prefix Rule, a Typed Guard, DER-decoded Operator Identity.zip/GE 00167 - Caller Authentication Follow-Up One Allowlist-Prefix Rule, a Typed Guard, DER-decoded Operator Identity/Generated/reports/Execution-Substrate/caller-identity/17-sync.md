# PR #38: trunk_dev 523648c taken, for the provenance check

**Head `5c2ac0b` is `26cb86f` plus a clean merge of `trunk_dev` `523648c` (#43, README only). The PR diff is byte-identical, so the diff-only check (15-recheck.md, PASS) and the red-team (16-redteam.md, ACCEPT) on `26cb86f` carry over.**

```text
SYNC REPORT
Repository:        evo-agi/Execution-Substrate, draft PR #38
Reviewed head:     26cb86fe5018e21d5c12728d0c1626683d29d693 (base 4c991ba)
New base:          origin/trunk_dev 523648cc9880c63d7e6592c2ae0754582d32f169 (#43, README.md only)
New head:          5c2ac0b099c715340df46b615fe6f9eff4e2c6df  Merge trunk_dev 523648c into the caller authentication follow-up
                   (pushed; parents 26cb86f and 523648c; tree 48ad3aa0d472c78f8c6eae3fe51434cbe1d85040)
Conflicts:         none
v2 manifest:       dd213e13fbd55bd3e76ea0815bba99522145387c016ac1bf5564f6af1cfc54ca, 32 files,
                   textual diff 2848606e971a701053bdef33f6e6f8aa20eef8fd7ffc576e71f17b0115b3fc94 (unchanged);
                   HEAD reset to 523648c, upstream origin/trunk_dev, two runs byte-identical; tool SHA c08597e2...a3ca verified.
                   Paths equal `git diff --name-only origin/trunk_dev 5c2ac0b`; every hash and size equals its blob at 5c2ac0b.
                   The only field that differs from the 26cb86f manifest (a59b163f...7661) is "head" (the base SHA).
Range-diff:        git range-diff 4c991ba..26cb86f 523648c..5c2ac0b: 15 of 15 commits "=".
                   git diff 4c991ba 26cb86f and git diff 523648c 5c2ac0b: same SHA-256 (d39cab85...d6cb).
Effect status:     TOPIC_BRANCH_PUSHED | MERGE_NOT_PERFORMED
```

## Checks

- `git diff 26cb86f 5c2ac0b` touches only `README.md` (`merge-5c2ac0b-vs-26cb86f.diff`).
- Before the merge, a local-only trial merge with the same tree (`48ad3aa0…`) passed the root package, `internal/testutil` and `internal/callerauth/...` as the unprivileged `esci` user (`trial43.sh`, `trial43.out`). None of this PR's files mention the README in their changes.
- GitHub CI on `26cb86f` passed (run 45299743778). CI on `5c2ac0b` started on push.

## Red-team OBS-1 and OBS-2

No change. Both are in the safe direction (the tools are stricter than ES), and the red-team said no change is required. OBS-1 (case-variant scheme or empty fragment) follows contract §3A, which records that ES reads the URI as Go's parser hands it over. Normalizing in the tools would add another copy of that rule, which is what #27 removed. The status doc already says that identity passes only for exactly one URI SAN equal to the expected ID.

## Evidence

`17-sync-evidence/`: both manifest runs and their output, the range-diff, the merge diff, the trial script and its output.
