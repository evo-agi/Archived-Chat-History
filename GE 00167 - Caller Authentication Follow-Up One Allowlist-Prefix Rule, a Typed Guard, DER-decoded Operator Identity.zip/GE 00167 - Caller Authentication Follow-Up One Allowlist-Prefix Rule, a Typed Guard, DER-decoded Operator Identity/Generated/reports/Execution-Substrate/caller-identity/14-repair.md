# PR #38 after re-audit 13: the two nits, one API list, and the move after #39

**Verdict: READY for the combined diff-only check and the red-team. Draft PR [#38](https://github.com/evo-agi/Execution-Substrate/pull/38) at `26cb86f`, up to date with `trunk_dev` `4c991ba` (#39).**

Re-audit 13 accepted `2fb0c6d` with two nits (`13-re-audit.md`). This report covers what changed since then:
- the two nits;
- the shared API list the auditor suggested, plus a pin on it;
- the merge of `trunk_dev` with #37 and #39;
- the move of this PR's two remaining root tests, which #39's layout rule requires.

Validation on the head passes. The mutation run on the head kills 129 of 130 mutants. The survivor, G03, removes the new pin's own check, and G01 shows that check works (§7). GitHub CI on `26cb86f` is running.

```text
REPAIR REPORT
Findings:         13-re-audit.md N13-1, N13-2 (nits, fix in PR 38); §8 suggestion (one list of the API
                  directories for both guard halves); coordinator 00:25Z: merge trunk_dev after #39, resolve
                  the comment conflict by hand, move the two root tests into internal/
Repository:       evo-agi/Execution-Substrate
Base ref and SHA: origin/trunk_dev 4c991ba1c43ac135d9d94853696d14a21523a690 (#39; #37 42db339 before it)
Topic branch:     claude/project-thread-i9yve2
Re-audited head:  2fb0c6dc17bfb76e419ea31d26171a2c2287e6eb
New head SHA:     26cb86fe5018e21d5c12728d0c1626683d29d693 (pushed; refs/pull/38/head is the same)
Tree SHA:         c5b4996eef2be68a23a34a8b315c0173805a802c
Commits added:    80b7b1d  Refuse 8- and 32-byte IP SAN entries in the decoder tests, and say which extensions it reads
                  93524f9  Give both halves of the caller identity guard one list of the API directories
                  1e20a0e  Merge trunk_dev 4c991ba into the caller authentication follow-up (one comment merged by hand)
                  f588c29  Move the typed caller identity guard and the allowlist contract test out of the root
                  26cb86f  Fail the caller identity guard when an api package is missing from its list
Diffs:            14-evidence/diffs/ (one per step, below)
v2 manifest:      a59b163fcb4ff31b968f775cdfdeb7daa6d142009dc29fb68f037337e5d67661, 32 files, textual diff
                  2848606e971a701053bdef33f6e6f8aa20eef8fd7ffc576e71f17b0115b3fc94; HEAD reset to 4c991ba, upstream
                  origin/trunk_dev, two runs byte-identical; tool SHA c08597e2...a3ca verified before use.
                  Paths equal `git diff --name-only origin/trunk_dev 26cb86f`; every hash equals its blob at 26cb86f
Effect status:    TOPIC_BRANCH_PUSHED | DRAFT_PR_UPDATED | MERGE_NOT_PERFORMED | CHECK_NOT_PERFORMED
```

## 1. N13-1: 8- and 32-byte iPAddress entries (`80b7b1d`)

The collector test's refused list gains `ip_eight_bytes` (an IPv4 address and mask) and `ip_thirty_two_bytes` (an IPv6 address and mask), the nameConstraints lengths that Go refuses in a subjectAltName. Each has a well-formed twin: the 4-byte and the 16-byte address. The auditor's mutants H09 (`(4, 8, 16)`) and H09b (`(4, 16, 32)`), applied to both decoder copies, are now killed by exactly these cases (`AssertionError: ip_eight_bytes` and `ip_thirty_two_bytes`; `logs/nits13-*`, and H09/H09b in the mutation run below).

## 2. N13-2: which extensions the decoder reads (`80b7b1d`)

The identity paragraph of `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` now has the auditor's sentence, word for word:

> The decoder reads only the subjectAltName, basicConstraints, keyUsage and extKeyUsage extensions, so a certificate that Go refuses for another malformed extension, such as certificatePolicies or authorityInfoAccess, can still show identity pass, and ES refuses it at the handshake.

`caller_authentication_docs_contract_test.go` pins it.

## 3. One list of the API directories (`93524f9`, `26cb86f`)

- `callerIdentityAPIDirs` (`"ars/api"`, `"ags/api"`, `"egs/api"`, `"cgs/api"`, `"es/api"`) is a package-level list in the name-based half. The typed half builds its import paths from it, as `callerIdentityModule + "/" + dir`.
- So after the move, the two docs contract rules that keep CGS out of `es/` and `internal/` see the directory `cgs/api`, not a CGS import path, and pass. The list names a package the guard inspects, not a dependency.
- **The pin (`26cb86f`, beyond the suggestion).** With one list, dropping an entry would remove that package from both halves at once. Before, each half had its own list, so one deletion weakened only one half. The name-based half now also fails when a production package in a directory named `api` is not on the list. So an entry cannot be dropped, nor a sixth service's API package left out, without a failure. The repository has exactly the five `*/api` directories today. The mutants G01 and G02 (drop `cgs/api`, drop `ars/api`) are killed by it.

## 4. The merge of `trunk_dev` `4c991ba` (`1e20a0e`)

- `git merge-tree --write-tree 93524f9 4c991ba` gives tree `5abfa99a…67d3` with one conflict, in `internal/callerauth/caller_authentication_contract_test.go`. The merge commit's tree differs from it only in that conflict (`diffs/2-merge-vs-merge-tree.diff`).
- The comment is merged by hand, not as a blind union (re-audit 13 §8). It keeps this PR's text and adds #39's point: "This half matches names in every production file, whatever its build constraints, and walks the repository from its root (see package testutil); TestCallerIdentityIsReadOnlyByCallerauthByType (caller_authentication_typed_guard_test.go) is the typed half, …" (`diffs/2-merge-resolution-1e20a0e.diff`, a combined diff against both parents).
- Everything else merged by itself, including this PR's edits to the status and renew tests that #39 moved into `scripts/`, `docs_contract_test.go` and `.runbooks/system/v1_bringup.md`.
- On its own, the merge commit does not build the root test package, because #39 moved `executionSubstrateRepoRoot` into `scripts/`. The next commit fixes that. I kept the move out of the merge so that the merge differs from git's own result only in the comment.

## 5. The move (`f588c29`)

`git mv` plus these changes, and nothing else (`diffs/3-move-1e20a0e..f588c29.diff`, 11 lines added, 8 removed):
- `caller_authentication_typed_guard_test.go` → `internal/callerauth/` (package `callerauth_test`, next to its name-based half);
- `caller_allowlist_contract_test.go` → `internal/callerallowlist/` (package `callerallowlist_test`);
- `executionSubstrateRepoRoot` → `testutil.Root`, and the `testutil` import in each.

The diff is the one the auditor reproduced in re-audit 13 §8 (`pr39-move-audit.diff`), applied to the merged tree. The root now holds only docs tests and the three files #39 names.

## 6. Validation

All runs are as the unprivileged `esci` user with a clean environment (`14-evidence/logs/`).

On `f588c29` (`val14.sh`, `val14.out`):
- [x] every `.go` file changed since `4c991ba` is `gofmt`-clean; `go build ./...`; `go vet ./...` for linux/amd64, linux/arm64 and darwin/arm64
- [x] Root package in full, with nothing skipped. Only docs tests remain there, and `TestTrackedGeneratedArtifactHygiene` passes in this git checkout
- [x] `scripts/` with its CI environment-only entries skipped (144 s)
- [x] `internal/testutil` (`TestRootKeepsOnlyItsDocsTests` and the importer rules), `internal/callerauth/...`, `internal/callerallowlist`, ARS, AGS, EGS and CGS in full, `es/api`, `es/config`, `internal/contracts/runtimeconfig/...`
- [x] The four caller identity guard tests by name in `internal/callerauth` (`guard-f588c29.log`)

On `26cb86f` (`callerauth-26cb86f.log`; the commit changes only the name-based half): vet ×3 of `internal/callerauth`, and `internal/callerauth/...` and the root package pass.

`es/app` and `es/admission/...` on `26cb86f`. Both read files that #37 changed: `es/app` reads `.runbooks/system/v1_bringup.md` and `scripts/70_linux_setup.sh`.
- [x] `es/admission/...`: only the two environment-only probes fail, as before (`admission-26cb86f.log`).
- [x] `es/app` in full passes (`es-app-rerun-26cb86f.log`, 105 s).
- The first `es/app` run (`es-app-26cb86f.log`) failed in `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget`: "Vault dev/test HTTPS listener did not appear on port 39565". It was the first run of that test in this container since it restarted.
  - The failed setup left its SPIRE server and agent running.
  - Because of them, the next run failed at an earlier step: "SPIRE server admin socket did not appear". So did a run on `trunk_dev` `4c991ba` itself (`es-app-supported-local-base-4c991ba.log`).
  - After I stopped the two leftover processes, the test passed alone (`es-app-supported-local-rerun2-26cb86f.log`), and then the whole package passed.
  - Inference: the first failure is environmental. The test and the setup script are the same as on `trunk_dev`, and this PR does not touch them. The leftover processes after a failed setup are a pre-existing cleanup gap, outside this PR.

- [ ] GitHub CI on `26cb86f`: running at the time of writing.

## 7. Mutation run on `26cb86f`

Runner: `mutation/mutants-r14.py` (the r12 runner with the paths #39 and this move changed: the decoder tests are now in `./scripts/`, and the guard tests in `./internal/callerauth/`), plus six new mutants. Logs: `mutation/mutants-26cb86f.log`, `.json` and `mut14-26cb86f.out`.

**130 mutants, 129 killed.**
- All 124 earlier mutants are killed again at their new test locations. That shows #39's move and this one kept every kill.
- **H09, H09b** (iPAddress of 8 or 32 bytes accepted, in both copies): killed by `ip_eight_bytes` and `ip_thirty_two_bytes` (N13-1).
- **G01, G02** (drop `cgs/api` or `ars/api` from the shared list): killed. G01 is killed only by the new pin: "cgs/api holds a service API package that callerIdentityAPIDirs does not list". Without the pin, dropping `cgs/api` would pass every test, because both halves read the same list.
- **G04** (the typed half ignores the list): killed by the typed self-test, which then misses its `crypto/tls` probe in `ars/api` on every target.
- **G03 survives.** It removes the pin's check itself. That only matters when a directory named `api` is not on the list, which today happens only under a mutant such as G01. So G03 is to G01 what the auditor's F17 is to F05. A self-test for the pin would need the name-based walk to run on a planted tree, which this PR does not build.

## 8. For the combined diff-only check

- Steps: `diffs/1-nits-and-shared-list-2fb0c6d..93524f9.diff`, `diffs/2-merge-*.diff`, `diffs/3-move-1e20a0e..f588c29.diff`, `diffs/4-api-list-pin-f588c29..26cb86f.diff`.
- Product code: unchanged since `2fb0c6d`. Every change since then is a test, the status doc, or the merge.
- The v2 manifest (`a59b163f…7661`) covers the whole PR against `trunk_dev` `4c991ba`, for the merge gate and the red-team.
- Before deploying to the box, the read-only allowlist-prefix check from `10-follow-up.md` §6 still applies.
