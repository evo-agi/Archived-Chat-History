# Diff check of ES PR #54 at dc01e3b (red-team O54-1)

Verdict: **ACCEPT**.

- O54-1 is fixed (Read, Ran):
  - `check` and `apply` now refuse a payload folder, `provenance.json` or
    payload file that is not `root:root`.
  - `es` and `es-runtime-support` must name `go1.26.5`, the commit and
    `vcs.modified=false` in their own Go build info.
- The new build-info reader returns exactly what `go version -m` returns on
  four real Go binaries. On 3,380 damaged binaries it only ever returns a
  result or a refusal (Ran).
- The new refusals pass as `ci` and as root. My owner and build-info
  mutants are killed (Ran).
- Nothing outside `load_payload` changed (Read).
- CI on `8a42864` passed. CI run 45460621561 on `dc01e3b` was still in
  progress at 19:08Z, and the merge gate must see it green.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `06-diff-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, PR #54, branch
  `claude/es-box-upgrade`, on trunk_dev `cacf5c1`.
- Head: `dc01e3b04b8f7c75e89853870bb2e96a224b0f0e`, one commit on
  `8a42864` (accepted in 04).
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified), merge-base
  `cacf5c1`:
  - manifest_sha256
    `0f1ed615a7cf1c769c28bc455b94327b2491cff646cd0ab7e0038b5944b9cc9d`;
  - textual_diff_sha256 `4c68f307…8b59`;
  - 9 paths; no `.github` path.
- Scope: the writer's request of 18:32Z, a diff check of the fix for the
  red-team's O54-1 (`05-redteam.md`, sha256 `7e695591…784c`).

## Provenance (Ran, `provenance/`)

- Two opening runs on a local branch with the PR's name give identical
  output. Two closing runs after the tests match them.
- Delta `8a42864..dc01e3b`: 3 files (the script, the host test and the
  docs), +311/−19 (`delta-8a42864-dc01e3b.diff`, sha256 `af54581b…c7a`).

## The fix (Read)

`load_payload`, which `check` and `apply` both run:

- **Ownership.** The folder (by `lstat`), `provenance.json` and each
  payload file must be `root:root` (the test user on a test host) and not
  writable by group or others. The checks use the `stat` of the file
  descriptor that was read.
- **Build stamp.** `es` and `es-runtime-support` must carry, in their own
  `.go.buildinfo`:
  - Go `go1.26.5`;
  - `vcs.revision=<commit>`;
  - `vcs.modified=false`.
- **Staging.** `stage_payload` re-reads the payload and requires the
  SHA-256s that `load_payload` verified, so the staged copies carry the
  checked stamp.
- **esconfigcheck** is bound by owner and SHA-256 only. The docs say so,
  and why: the upgrade runs it but does not install it.
- **Why the owner check is the real guard.** A forged stamp still passes,
  so against another account the owner check is what holds. With `root:root`
  required, only root or the operator, who has sudo, can supply the payload.
  That matches the red-team's threat model (Inference).

## The build-info reader (Ran, `probes/`)

`go_build_info` parses the 64-bit little-endian ELF section headers, finds
`.go.buildinfo`, and checks:

- the magic;
- the inline-strings flag;
- the bounds of every section and string it reads.

It then reads the uvarint version and module-info strings, as
`debug/buildinfo` does.

- **Agreement** (`buildinfo-real.txt`). On Go 1.26.5's `go` and `gofmt`,
  and on HashiCorp's Nomad 2.1.1 (go1.27.3) and 2.0.0 (go1.26.2), the
  version and every build setting equal `go version -m`'s output: 8, 8, 13
  and 13 settings. A non-Go ELF (`/bin/ls`) is refused.
- **Damaged input** (`buildinfo-fuzz.txt`). I fed it 3,380 cases from
  `gofmt`:
  - 380 truncations;
  - 3,000 random byte changes in the ELF header, the section headers and
    the start of each section.
  - Every case either parsed (2,774) or was refused (606). No other
    exception occurred.
- **One difference from Go.** When the module-info sentinels are missing,
  Go keeps no settings, while this reader parses the raw string. A forged
  stamp passes either way, so this changes nothing.
- **Test coverage.** The PR's `TestRemoteAlphaUpgradeESReadsGoBuildInfoLikeGoVersion`
  makes the same comparison on a real Go binary and on the test fixtures.

## Tests and mutants (Ran)

- **New refusal cases** in `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`:
  - folder of another account;
  - folder of another group;
  - binary of another group;
  - `provenance.json` of another group;
  - build info naming another commit, another Go, a modified build, or
    none.
  - They pass as `ci` and as root on a `git archive` copy
    (`tests/upgrade-tests.txt`, `tests/upgrade-tests-as-root.txt`).
- **Mutants.** My mutants V1–V9 cover the payload owner and build-info
  checks. As root (`mutants/mut21-as-root.txt`), V1, V2, V3, V8a and V8b
  are all killed. V8b checks the gid only; it needs root because a non-root
  test cannot make a file with its own group and another owner.
- **The round-20 set (U1–U20)** was re-run against the new fixtures as
  `ci`. Together with V1–V9 that is 30 mutants, and 25 are killed
  (`mutants/mut21.txt`). The survivors:
  - U5, U6b (equivalent) and U20, as in 04;
  - V8b, which is killed as root;
  - V9 (the section bounds check removed). It is equivalent in Python:
    an out-of-range slice comes back short, and the later checks refuse
    it.
  - So 26 of the 30 are killed, and two of the four left are
    equivalent.
- **The session-drop probe** gives the same result as in 04: tty →
  `rolled_back` with nothing differing; pipe → `applied`; files →
  `rolled_back` (`probes/hangup.txt`).

## Observations (Info, no action required)

- `go_build_info` requires exactly `go1.26.5`, with no suffix. A toolchain
  built with a `GOEXPERIMENT` would report, for example,
  `go1.26.5 X:…` and be refused. The box's toolchain is a standard one
  (Inference), so this fails closed.
- The script does not check the clone it runs from, and no script can
  usefully check itself: a changed copy would skip the check. The docs
  and plan step 2 chown the clone to root, together with the payload,
  before `check` (Read). This is outside O54-1.

## Validation (Ran, at dc01e3b)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`; `gofmt -l` on the upgrade tests and the helper | pass; gofmt lists nothing (`tests/build-vet.txt`) |
| `TestRemoteAlphaUpgradeES*`, `TestESConfigCheck*` as `ci` | all pass (`tests/upgrade-tests.txt`) |
| the same as root on a `git archive` copy | all pass (`tests/upgrade-tests-as-root.txt`) |
| root package | pass (`tests/root-package.txt`) |
| `./internal/testutil/`, all of `./es/admission/` | pass (`tests/repo-guards.txt`) |
| build-info reader against `go version -m`, and fuzz | see above (`probes/buildinfo-*.txt`) |
| session-drop probe | as in 04 (`probes/hangup.txt`) |
| mutants | as `ci`, 25 of 30 killed; as root, V1, V2, V3, V8a and V8b killed (`mutants/mut21.txt`, `mutants/mut21-as-root.txt`) |
| CI | run 45460621561 on `dc01e3b` in progress at 19:08Z; run 45447840451 on `8a42864` passed (`ci/runs.txt`) |

## Sensitive material

- The tests use random tokens and test fixtures.
- A scan of the evidence for UUID-shaped strings, names, e-mail addresses
  and LAN addresses found none.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.
- Two temporary changes, both undone:
  - the probe file was copied into my test clone, then removed;
  - the root copy is a local `git archive` with a local commit.
- Both trees were clean afterwards.

## Final verdict

**ACCEPT**

For the merge gate:

- the PR head must equal `dc01e3b`;
- CI must be green on it;
- the coordinator decides whether the red-team needs to see this fix
  before the merge.
