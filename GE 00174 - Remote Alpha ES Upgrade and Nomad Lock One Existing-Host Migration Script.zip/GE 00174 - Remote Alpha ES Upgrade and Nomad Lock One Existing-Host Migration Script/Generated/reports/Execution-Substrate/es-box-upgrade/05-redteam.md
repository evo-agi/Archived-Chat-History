# ES PR #54: red-team of the box ES upgrade / Nomad-lock script (report 05)

```
Target:    evo-agi/Execution-Substrate PR #54, head 8a428648ee4a15903080597395b7b1a9b89a7326
           (refs/pull/54/head, base trunk_dev cacf5c1). The script is
           scripts/remote_alpha_upgrade_es.sh -> scripts/internal/remote_alpha_upgrade_es.py
           (1354 lines) plus scripts/internal/esconfigcheck/main.go.
Asked by:  the coordinator, as the fix's red-team before merge. Audit ACCEPT at 8a42864
           (es-box-upgrade/03-audit.md BLOCK on A19-1/2/3 -> 04-diff-check.md ACCEPT; plan
           02-plan.md). Named vectors: links, owners, races, token exposure, build source,
           and whether rollback can be made to do harm.
Posture:   the thread that wrote reports 01, 06, 14, 25; separate from the writer and the
           auditor; read-only on the repo; nothing pushed, no PR comment; nothing on the box.
           One cloud container, cloud only. The attack surface here is a local unprivileged
           account on the box (for example ds or es) against a root-run `check`/`apply`/
           `rollback`, plus the unprivileged `build`.
Verdict:   NO reachable bypass by an unprivileged local account. The write primitives are
           symlink-safe and race-safe, every root write lands in a root-controlled parent,
           the retained-result key and the ES Nomad-token file are owner- and mode-checked,
           and `rollback` is gated on a backup directory root owns at 0700, which another
           account cannot forge. The token is never printed. ONE build-source observation
           (O54-1, Low, defense-in-depth, not a reachable escalation in the intended flow):
           at `apply`, the installed binaries are bound to the named commit only by an
           unauthenticated provenance.json, and the payload directory's owner is not checked.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. What the script does, and the threat model (Read)

`apply` runs as root and, after a read-only `check`: backs up the files it will change into a
new root-only directory, stops ES, locks Nomad (rewrites `/etc/nomad.d/nomad.hcl` to the
driver allowlist plus `acl{}` and the Docker plugin block, makes `/etc/nomad.d`, `/opt/nomad`
and `/opt/nomad/data` root-owned, chowns every foreign-owned entry in the data dir to root,
provisions ACLs via `nomad_acl_setup.sh`), provisions the retained-result key, migrates
`es.json` (adds `nomad.token_file` and `execution.retained_result_auth`), installs the `es`
and `es-runtime-support` binaries, starts ES and verifies. Any failure or interrupt rolls the
backup back. `rollback` puts a backup back on demand. `build` (unprivileged) builds the three
binaries from a clean checkout of a named commit and writes `provenance.json`.

The account that runs `build` and `sudo apply` is the trusted operator. The red-team question
is whether a **different**, unprivileged local account (ds, es, or any other) can turn any of
these steps into a write it should not get, into the Nomad management token, or into code of
its choosing running as root or as the `es` service account.

## 2. Links, races, owners: the write primitives hold (Read, one Ran)

Every write the root path makes goes through one of three primitives, and each refuses a link
and cannot be redirected by a racing second account:

- **`atomic_replace`** (es.json, both binaries, nomad.hcl, nomad.env; `remote_alpha_upgrade_es.py:288`):
  writes a sibling temp file with `O_CREAT|O_EXCL|O_NOFOLLOW` (a planted name or link fails
  the create, fail-closed), `fchown`/`fchmod` by descriptor, then `os.rename` over the target.
  `rename` replaces the target path itself, link or not, without following it. A second account
  cannot make the write land anywhere but the literal path, and the literal path's parent
  (`/etc/execution-substrate`, `/usr/local/lib/execution-substrate/bin`, `/usr/local/bin`,
  `/etc/nomad.d`) is root-controlled.
- **`provision_key`** (`:195`): opens the parent `O_DIRECTORY|O_NOFOLLOW` (a symlinked parent
  raises ELOOP -> Refusal), `fstat`s the real fd to require it be a dir owned by `es` or root
  and not group/other-writable, `stat`s the key with `dir_fd=` and `follow_symlinks=False`,
  and creates it `O_CREAT|O_EXCL|O_NOFOLLOW` through the parent fd, then `fchown` to `es` and
  `fchmod 0400`. All by descriptor, so nothing can be swapped between the checks and the
  create. An existing key is accepted only if it is a 32-byte, single-link, `es`-owned,
  0400/0600 regular file.
- **`read_regular_file` / `backup_files`** (`:265`, `:334`): every read opens `O_NOFOLLOW` and
  refuses a non-regular file; every backup copy is created `O_EXCL|O_NOFOLLOW`.

`foreign_owned_entries` + the data-dir chown (`:714`, `:1031`) walk `/opt/nomad/data` with
`followlinks=False` and apply `os.lchown`, which does not follow a symlink. A planted link in
the data dir has its own ownership changed, not a target's. The walk's `onerror` re-raises, so
an injected permission error aborts `apply` into a rollback (fail-closed), not past the guard.

**Check-to-apply TOCTOU is closed:** `apply` does not act on what `check` read. It re-reads
`es.json` and re-derives the migration (`:1196`), and `apply_nomad_lock` re-reads `nomad.hcl`
and re-runs `plan_nomad_hcl`, which re-verifies the file's SHA-256 against the preflight value
(`:1012`, `:686`). A file changed after `check` is re-validated or refused before any write.

Signals: a non-root account cannot signal a root process, so the interrupt handling is not a
second-account surface; it is a reliability guard (one interrupt ends the forward path and is
then masked so it cannot break the rollback).

## 3. The Nomad management token is not exposed (Read)

The script never reads the management token and never prints a token. `install_es` reads the ES
Nomad-token file only to check it is `es`-owned 0400/0600 and discards the bytes
(`_, tst = read_regular_file(...)`, `:1051`). The token flows only inside
`nomad_acl_setup.sh`, which the upgrade invokes with the environment passed through
(`acl_setup`, `:1002`); `NOMAD_TOKEN` reaches that child but is never logged here. The
`summary.json` and the event log record paths, SHA-256s, owners and modes, never key or token
material, and the summary is written root:root 0600 inside the 0700 root backup directory.

One Info carry (not a PR #54 defect): `acl_setup` runs with `check=True`, so if
`nomad_acl_setup.sh` ever failed **and** printed secret material to its own stdout/stderr, up
to 400 characters would appear in the Refusal text (and thus in the root-only summary and on
the operator's terminal). Whether that can happen is a property of `nomad_acl_setup.sh`
(PR #31/#48), not of this script. Worth one glance there; contained either way.

## 4. Rollback cannot be made to do harm by a second account (Read)

`rollback`/`restore_host` is the most dangerous primitive (root writing arbitrary bytes with
arbitrary owner and mode from a directory), so the gate matters:

- `load_backup` (`:366`) requires the backup directory be a **0700 directory owned by the euid
  running the restore** (root, in production). A non-root account cannot create a root-owned
  0700 directory, so it cannot present a forged backup to a root `rollback`.
- Every input `restore_host` trusts (manifest.json, ownership.json, directories.json, the file
  copies) lives **inside** that 0700 root directory, created by `apply` from real host state.
  A second account cannot write into it, so the restored paths, owners and modes are the real
  originals, not attacker choices.
- Restores write through `atomic_replace` (symlink-safe) and `os.lchown` (no follow); the
  one `os.chmod` on a data-dir entry is guarded by an `lstat` S_ISLNK check, and during a
  rollback the data dir is root-owned and ES/Nomad are stopped, so there is no second-account
  write window on those paths.

A rollback that itself fails leaves services stopped and reports `rollback_failed` (fail-closed
to "down", never to "running attacker code"). That is an availability concern, not an
escalation.

## 5. O54-1 (Low, defense-in-depth): apply binds the binaries to the commit only by an unauthenticated file, and does not check the payload directory's owner (Ran)

This is the "build source" vector. `build` proves the binaries are a clean build of the named
commit by reading each binary's embedded VCS stamp (`go version -m`, checking
`vcs.revision=<commit>` and `vcs.modified=false`, `:1280`). But `apply` does **not** re-read
that stamp. `load_payload` (`:826`) binds the payload to the commit only through
`provenance.json`: it requires the payload directory and each file be not group/other-writable
(`st.st_mode & 0o022`) and each file's SHA-256 match the hashes **claimed in that same
provenance.json**, and the provenance's `commit` equal the commit typed at the CLI. It does
**not** check the payload directory's **owner**, and nothing downstream re-checks the binaries'
VCS stamp (`stage_payload` re-hashes against the same provenance; the staged `esconfigcheck`
that validates the migrated config is itself one of the payload binaries).

So a payload directory that is self-consistent but not a real build of the commit is accepted.
I built one and `load_payload` accepted it (Ran, `05-evidence/payload_binding_probe.py`,
`payload_binding_probe.out`): an `es`, `es-runtime-support` and `esconfigcheck` of arbitrary
bytes, a `provenance.json` carrying their hashes, `commit=<40 hex>`, `go_version=go1.26.5`,
`vcs_modified=false`, directory mode 0755. `apply` would then stage these, run the attacker's
`esconfigcheck`, install the attacker's `es`/`es-runtime-support` (root:root 0755) and start
ES, so the attacker's code runs as the `es` service account.

**Reachability (Inference): this is not an unprivileged-to-root escalation in the intended
flow.** The operator runs `build` into a directory they own and then `sudo apply --payload`
that directory. Another account cannot modify a directory the operator owns at 0755 (not
group/other-writable), so `load_payload`'s non-writable check already blocks **substitution**
of a correctly built payload. The gap bites only if `apply` is pointed at a payload directory
owned by someone other than the operator (a shared build location, or the operator being
directed to an attacker's directory). It is a weakening of the exact property this PR exists to
guarantee (what runs as the box's ES is a faithful build of the reviewed commit), resting on an
unauthenticated JSON file, so I am raising it; I do not consider it a merge blocker on its own.

**Fix (two cheap, independent hardenings):**
1. At `apply`, after staging, re-run `go version -m` on `es` and `es-runtime-support` and
   require `vcs.revision=<commit>` and `vcs.modified=false`, exactly as `build` does. This
   makes the payload self-verifying and removes all trust in `provenance.json` for the
   commit binding. (`go` is present on the box that just built; the toolchain version need not
   match to read a stamp.)
2. In `load_payload`, also require the payload directory be owned by root or by the invoking
   uid, matching the backup directory's own-or-root rule.

## 6. Everything else checked, no finding

- **`clean_absolute`** (`:74`) rejects `..`, `//`, trailing space, NUL and a root-level parent;
  it guards every operator-supplied path in the host-independent subcommands.
- **`migrate_config`** (`:114`) refuses an `es.json` whose key set differs from the preflight's
  (`EXPECTED_ES_PATHS`), refuses a token/auth already set to other values, and the migrated
  config is then run through the real `esconfigcheck` (`config.Load`).
- **`esconfigcheck/main.go`** calls only `config.Load(os.Args[1])` and maps load/refuse/usage
  to exit 0/1/2; a test pins that it does nothing else (Read).
- **`cmd_build`** refuses an out-dir inside the checkout, a non-40-hex commit, a wrong Go
  version, a HEAD that is not the commit, and a dirty checkout, and binds each binary to the
  commit via its VCS stamp. It runs unprivileged; its only gap is that `apply` does not repeat
  the stamp check (O54-1).
- **`backup_root_ready`** (`:979`) refuses a `BACKUP_ROOT` root does not own.

## 7. Coverage this pass could not provide

- **Nothing on the box, cloud only.** I exercised the script's logic directly; I did not run
  `check`/`apply`/`rollback` against a live ES, Nomad, systemd or SSH, and I did not drive the
  Mac-to-box orchestration. The symlink/race/owner reasoning for the root path is from reading
  the primitives, confirmed where it was pure logic (section 5).
- I ran in a container as root (euid 0), so the probe demonstrates the **logic** gap in
  `load_payload` (no owner check, no stamp re-check); it does not stand in for a two-account
  box run. The intended-flow reachability in section 5 is Inference.
- I did not rerun the suite or the auditor's mutants; reports 03 and 04 cover those. The merge
  gate still needs CI green at the head.

## 8. Evidence

`05-evidence/` (hashes in `SHA256SUMS`): `payload_binding_probe.py` (the probe, scratch only,
never pushed) and `payload_binding_probe.out`.
