# Audit of ES PR #54 at bbdfc7c (ES upgrade and Nomad lock script)

Verdict: **BLOCK**, on three Low findings.

- **A19-1:** when the terminal or output pipe of `apply` goes away, `apply`
  does not roll back. ES is left stopped, and no summary is written (Ran).
- **A19-2:** no test covers the two ownership restores: the Nomad data
  ledger and the Nomad folder owners (Ran, mutants).
- **A19-3:** no test covers the build's dirty-checkout and `vcs.revision`
  refusals (Ran, mutants).

The rest of what you asked about holds (Ran, Read):

- every tested failure and `SIGTERM` rolls back, and the new group drain
  works;
- restores are verified, and each file is replaced atomically;
- the `nomad.hcl` pin and the lock transform are correct;
- `esconfigcheck` calls only `config.Load`;
- `OBSERVER_USER=root` and the backup root are sound.

CI run 45441427185 on `bbdfc7c` was still in progress at 17:06Z.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `03-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, PR #54, branch
  `claude/es-box-upgrade`, on trunk_dev `cacf5c1`.
- Head: `bbdfc7c2040d991fea8e260125bee4da1a9ad2f9`, tree `85e4b10c…`. It
  is one commit (the Codex P2 fixes) on `ea08d2f`, which was the first
  audit request (Ran, `provenance/facts.txt`).
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified), merge-base
  `cacf5c1`:
  - manifest_sha256
    `b4e3625a7917cead4bbc98dd8ed3af9449dc4c57078a581766b1082160cac8a2`;
  - textual_diff_sha256 `194fe6e3…2d7f`;
  - 9 paths: 3 docs, the Python script and its shell wrapper, the
    `esconfigcheck` helper, and 3 test files.
  - No `.github` path changed.
- At `ea08d2f`, the manifest was `b56b3970…7731`.
- Scope: the writer's requests of 16:42Z and 16:49Z. The plan is
  `02-plan.md`.

## Provenance (Ran)

- I ran the recipe twice at the start, on a local branch with the PR's
  name. Both runs give identical output, and two closing runs after all
  the tests match them.
- No manifest for `bbdfc7c` came with the request, so the value above is
  mine.
- The delta `ea08d2f..bbdfc7c` covers 3 files, +218/−49
  (`provenance/delta-ea08d2f-bbdfc7c.diff`, sha256 `b39c7fd7…dbe9`).

## Findings

### A19-1 (Low, Ran): no rollback when the terminal or output pipe goes away

`cmd_apply`'s `log()` prints to stdout with `flush=True`
(`remote_alpha_upgrade_es.py:1139-1141`). The failure handler calls `log()`
before `restore_host` (`:1175`).

- **Terminal hangup.** The terminal hangs up, which is what sends
  `SIGHUP`. `Interrupted` is raised. Then the handler's `log()` fails with
  `EIO`, and that error escapes the handler before the restore starts.
- **Output pipe closed.** An SSH session without a pty drops: no signal
  arrives, but the next `log()` fails with `EPIPE`. Its handler fails the
  same way.

Probe `probes/zz_audit_hangup_test.go` with `probes/pty_hangup.py`. It
uses the PR's own fake host and drops the session during the slow Nomad
validation (`probes/hangup.txt`, at `bbdfc7c`; the same result at
`ea08d2f`):

| Mode | Exit | summary.json | ES | Rollback |
| --- | --- | --- | --- | --- |
| tty (terminal hangs up, `SIGHUP`) | 120 | none | stopped | none (only `systemctl stop es` ran) |
| pipe (reader closes, no signal) | 120 | none | stopped | none |
| files (control: output to files, terminal hangs up) | 1 | written, `rolled_back` | running | complete |

- The docs say that on `SIGHUP`, `apply` "ignores further signals and
  rolls back". A terminal hangup is the usual source of `SIGHUP`, and in
  exactly that case `apply` does not roll back.
- With the pipe, the failure comes at whichever `log()` follows the drop.
  A drop during the ACL setup would leave a locked Nomad with changed
  owners, ES stopped, and no record of it (Inference).
- The documented route is `systemd-run`, with output to the journal, and
  the plan uses it. So the planned box run should not hit this
  (Inference). That is why this is Low.
- U6 (the `SIGHUP` handler removed) survives, because no test sends
  `SIGHUP` or closes the output.

Fix: make `log()` and the final prints in `apply` and `rollback` never
raise. For example, catch `OSError` and keep the event in the summary. Add
two tests: one that runs `apply` with its output pipe closed, and one that
sends `SIGHUP`. Each should expect `rolled_back` and a summary.

### A19-2 (Low, Ran): no test covers the ownership restores

Mutants U1 and U2 survive at both heads (`mutants/mut19.txt`):

- U1: the rollback skips `ownership.json`'s `lchown`.
- U2: the rollback skips the Nomad folders' `chown`.

There are two reasons:

- Under a test host root, `root_ids()` is the test user (`:577-578`).
  Every fake entry belongs to that user, so the ledger is always empty.
- `snapshot()` records the mode and hash but not the owner
  (`remote_alpha_upgrade_es_host_test.go:431`).

The writer named the ledger and its restore as a focus area. Its code
reads correctly (Read):

- The ledger is written with `O_EXCL` and `fsync` after Nomad stops and
  before the first `lchown`.
- Its restore runs after the file restore.
- Links are listed, never followed.

Fix:

- Add `uid:gid` to the snapshot.
- Give the fake host at least one data entry, and one folder, whose owner
  is not the stand-in root. For example, a test-only setting could name
  the stand-in root's gid, or the test could chgrp to a supplementary
  group of the test user.
- Assert that the ledger is non-empty after `apply` and that owners are
  equal after the rollback.

### A19-3 (Low, Ran): no test covers the build's dirty-checkout and revision refusals

U10 (`git status --porcelain` check removed) and U11 (`vcs.revision` and
`vcs.modified` check removed) survive.

`TestRemoteAlphaUpgradeESBuildRefusals` covers only two refusals:

- an out folder inside the checkout;
- a short commit.

The Go version and HEAD-mismatch refusals are untested as well (Read). The
checks read correctly (`:1212-1230`, Read).

Fix: copy the script into a throwaway git repo at
`scripts/internal/`, commit it, and run `build --go <fake go>`. Expect a
refusal for each of these:

- an untracked file;
- a `version -m` output without the commit;
- a `version -m` output with `vcs.modified=true`;
- a wrong `GOVERSION`;
- HEAD not equal to the commit.

## Answers to the review questions

- **Can a path leave ES or Nomad stopped, or a file half-restored?**
  - Apart from A19-1, every path that leaves a service stopped records
    `rollback_failed` in the summary. That covers a stop that fails (the
    new subtest), a restore error, a start that fails, and no leader
    (Ran, Read).
  - Each file is replaced through a temporary file and a rename, after
    the whole backup is verified (U13 killed). So no single file is
    half-written. A failure partway through can leave some files
    restored and others not, and that is reported. `rollback` can safely
    be run again: it re-verifies the backup and rewrites everything
    (Read, Inference).
  - The new group drain works: the grandchild subtest passes, and a
    runner without it fails (Ran).
- **The ledger:** see A19-2. Also Info I19-1 below.
- **The pin and the transform:**
  - U12 (the SHA-256 check removed) is killed.
  - The locked box `nomad.hcl` (`probes/locked.hcl`) passes
    `nomad config validate` on Nomad 2.0.0 and 2.1.1
    (`probes/validate-locked.txt`).
  - `TestRemoteAlphaUpgradeESNomadLockMatchesSupportedConfig` passes (Ran).
- **esconfigcheck:**
  - `main.go` calls only `config.Load(os.Args[1])` (Read).
  - `TestESConfigCheckOnlyCallsConfigLoad` and the agreement cases pass
    (Ran).
- **OBSERVER_USER=root:**
  - It matches the healthcheck runbook, which runs with sudo.
  - `nomad_acl_setup.sh` would otherwise default to `SUDO_USER`.
  - Both the code comment and the docs say to pass the same value to any
    later `check` or `rotate` (Read).
- **The backup root:**
  - `mkdir 0700`; `lstat` must show a directory, not a link, owned by
    root; then `chmod 0700`.
  - It is under `/var/backups`, not the `ds`-owned staging tree (Read).
- **build:** the checks are correct, but untested (A19-3).

## Observations (Info, no action required for the verdict)

- **I19-1:** when root `chown`s a non-directory, Linux clears its setuid
  and setgid bits, and changing the owner back does not restore them
  (Ran, `probes/chown-mode.txt`: 6755 became 755).
  - The ledger records owners only, while the docs say "every backed-up
    file, owner and mode".
  - Nomad's data folder with 0 jobs is unlikely to hold such files
    (Inference).
  - Recording the mode in the ledger, while you are in A19-2, would make
    the restore exact.
- **I19-2:** U5 survives: no test sends a second signal.
  - A second signal can arrive while the handler is being entered, before
    `SIG_IGN` is set, or while `run()` drains a group. It then escapes
    before the drain or the restore finishes.
  - With `SIGTERM` the group dies within milliseconds, so the window is
    narrow (Inference). A double Ctrl-C at a terminal is the likely way to
    hit it.
  - Fix: have the handler set `SIG_IGN` itself before raising, and install
    it for `SIGINT` too.
- **I19-3 (box run, not the PR):** the docs say to give the `systemd-run`
  unit `KillMode=mixed` and a long `TimeoutStopSec`. The plan's step 3
  (`02-plan.md`) does not name these yet.

## Validation

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`; `gofmt -l` on the new Go files | pass; gofmt lists nothing (`tests/build-vet.txt`) |
| `TestRemoteAlphaUpgradeES*`, `TestESConfigCheck*` at `bbdfc7c`, as `ci` | all pass, including the 5 new subtests (`tests/upgrade-tests.txt`) |
| root package | pass (`tests/root-package.txt`) |
| hangup probe, tty/pipe/files | see A19-1 (`probes/hangup.txt`) |
| mutants U1–U13 | U3, U7, U12, U13 killed; U1, U2, U5, U6, U10, U11 survive (`mutants/mut19.txt`; the same at `ea08d2f`) |
| CI run 45441427185 on `bbdfc7c` | in progress at 17:06Z (`ci/runs.txt`) |

- The files ending in `-ea08d2f` are the same runs at the first head.
- I did not run the wider scripts package. The writer reports 28 failures
  there that also fail on a pristine `cacf5c1`.

## Sensitive material

- No token, key or personal data appears in the evidence.
- A scan for UUID-shaped strings, "SecretID", names, e-mail addresses and
  LAN addresses found none.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.
- The probe file was copied into my test clone, then removed. The clone's
  tree was clean afterwards.

## Final verdict

**BLOCK**

To accept:

- fix A19-1, A19-2 and A19-3 in the PR;
- a diff check of the fix;
- CI green on the final head.

The Info items are optional.
