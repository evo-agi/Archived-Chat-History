# Diff check of ES PR #54 at 8a42864 (fixes for audit 03)

Verdict: **ACCEPT**.

- A19-1, A19-2 and A19-3 are closed. Each has a test that fails without
  its fix, and my mutants against each fix are killed (Ran).
- The Info items I19-1 to I19-3 are addressed (Read, Ran).
- At `bbdfc7c`, CI failed on two repo guard tests that the PR's tests
  broke. That was A20-1. It is closed at `8a42864`: both packages pass in
  full (Ran).
  - My audit 03 missed it because I did not run those packages. I now run
    them on every round.
- CI run 45447840451 on `8a42864` was still in progress at 18:05Z. The
  merge gate must see it green.

Statements are marked **Ran**, **Read** or **Inference**. Evidence paths
are relative to `04-diff-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, PR #54, branch
  `claude/es-box-upgrade`, on trunk_dev `cacf5c1`.
- Head: `8a428648ee4a15903080597395b7b1a9b89a7326`. Its parent is
  `2362e1a` (the audit-03 fixes), and that commit's parent is `bbdfc7c`
  (audited in 03).
- Recipe v2 (source sha256 `c08597e2…a3ca`, verified), merge-base
  `cacf5c1`:
  - manifest_sha256
    `1e468f0c51c7525f655362426bdc968be852dfae8ccaba4087a50f55c76bbbbf`;
  - textual_diff_sha256 `8f49924f…c1f8`;
  - 9 paths; no `.github` path.
  - At `2362e1a` the manifest was `ca7964c3…50e3`. The textual diff
    covers only tracked files, so it is the same at both heads: the
    second commit changes only the new test files.
- Scope: the writer's requests of 17:19Z (`2362e1a`) and 17:22Z
  (`8a42864`).

## Provenance (Ran, `provenance/`)

- At each head, two opening runs on a local branch with the PR's name
  give identical output. Two closing runs after the tests match them.
- Delta `bbdfc7c..2362e1a`: 3 files, +398/−36 (`delta-bbdfc7c-2362e1a.diff`,
  sha256 `46632b17…068e`).
- Delta `2362e1a..8a42864`: 3 test files, +21/−8
  (`delta-2362e1a-8a42864.diff`, sha256 `3c42e1b6…8a04`).

## A19-1, lost session: closed (Read, Ran)

- `say()` replaces every print in `check`, `apply`, `rollback`, `build`
  and `main`'s refusal message.
  - On the first `OSError` or `ValueError`, it points fds 1 and 2 at
    `/dev/null` and sets `output_lost`.
  - The summary records `output_lost` on both paths.
- Only the helper subcommands (`backup`, `restore-files`,
  `migrate-config`, `provision-key`) and the `--host-root` refusal still
  use `print` (Read). None of them runs during `apply` or `rollback`.
- My probe (`probes/hangup.txt` at `8a42864`, and the same at `2362e1a`):

| Mode | 03 at `bbdfc7c` | Now |
| --- | --- | --- |
| tty (terminal hangs up, `SIGHUP`) | exit 120, no summary, ES stopped | exit 1, `rolled_back`, nothing differs from before |
| pipe (reader closes, no signal) | exit 120, no summary, ES stopped | exit 0, `applied`, Nomad locked, ES running |
| files (control) | rolled back | rolled back |

- The docs describe exactly this: a closed pipe alone does not roll back,
  and the run goes on with its output sent to `/dev/null`.
- `TestRemoteAlphaUpgradeESApplySurvivesALostSession` covers tty and pipe.
  It kills U6 (`SIGHUP` not handled), U14 (`say()` raises), U15 (no
  `/dev/null`) and U17 (`output_lost` not recorded on the rollback path).

## A19-2, owner restores: closed (Read, Ran)

- The snapshot now carries mode, `uid:gid` and sha256.
- `giveNomadDataAnotherOwner` gives four things to a supplementary group
  of the test user: the data folder, `raft.db`, a setgid file and a link.
- The Apply test checks:
  - the groups after apply;
  - the ledger's root and its three entry paths;
  - the exact restore, setgid bit included.
- Killed: U1 (no ledger `lchown`), U1b (no ledger `chmod`), U1c (apply
  changes no data owner), U2 (no folder owner), U3 (no folder mode).
- The test needs a supplementary group: `otherGroup` fails the test,
  rather than skipping, when the user has none. The CI runner has one, and
  so does my `ci` user (`docker`).

## A19-3, build checks: closed (Read, Ran)

`TestRemoteAlphaUpgradeESBuildChecksToolchainCheckoutAndBuildInfo` uses a
throwaway git repo and a fake `go`. It covers a clean build (provenance
hashes checked), another Go, another commit, an untracked file, a changed
tracked file, build info naming another commit, and `vcs.modified=true`.

Killed:

- U10 (no porcelain check);
- U11 (no `vcs.revision` check);
- U11b (no `vcs.modified` check);
- U18 (no HEAD check);
- U19 (no Go version check).

## Info items from 03 (Read, Ran)

- **I19-1:**
  - The ledger records each entry's mode. The restore runs `chmod` after
    `lchown`, and skips links.
  - The docs now say "owner and mode".
  - U1b is killed.
- **I19-2:**
  - `SIGINT` joins `SIGTERM` and `SIGHUP`. The handler sets all three
    aside before it raises.
  - An outer `try` catches an `Interrupted` that lands while another
    failure is being caught. That closes the window that 03 left open
    before `SIG_IGN` (Read).
  - A "two signals in a row" subtest was added.
- **I19-3:** `02-plan.md` section 5 step 3 now runs `systemd-run -p
  KillMode=mixed -p TimeoutStopSec=20min` (Read).

## A20-1 (Low): two repo guards broken by the PR's tests; closed at 8a42864

CI run 45441427185 on `bbdfc7c` failed in two packages. Both fail the same
way at `2362e1a` (Ran, `tests/repo-guards-2362e1a.txt`).

- **`internal/testutil` `TestImportersNameRepositoryPathsFromTheRoot`:**
  - 10 `exec.Command`s had no `Dir`;
  - one used the repository-relative path
    `./scripts/internal/esconfigcheck`.
- **`es/admission` `TestOperationalGuardReadsUnadjustedPositions`:** four
  `fset.Position` reads in the config-check test.

`8a42864` fixes this (Read):

- Every command gets an absolute `Dir`.
- The helper is built by import path from the repo root.
- The config-check test uses `PositionFor(pos, false)`.

Both packages pass in full at `8a42864` (Ran, `tests/repo-guards.txt`,
including all of `es/admission` in 328 s).

## Observations (Info, no action required)

- **U5 survives** (the handler does not set further signals aside). The
  outer `try` still forces a rollback, so only the drain of a command's
  group could be cut short. No test sends a second signal while a
  grandchild is alive. The window is milliseconds with `SIGTERM`
  (Inference).
- **U6b survives**, and it is equivalent: without the handler, `SIGINT`
  raises `KeyboardInterrupt`, which the same `except BaseException`
  catches.
- **U20 survives:** no test covers the `rollback` command's
  `signal(SIGHUP, SIG_IGN)`. `say()` already keeps its output from
  failing.

## Validation (Ran, as `ci`, at 8a42864 unless noted)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`; `gofmt -l` on the upgrade test files and the helper | pass; gofmt lists nothing (`tests/build-vet.txt`) |
| `TestRemoteAlphaUpgradeES*`, `TestESConfigCheck*` | all pass (`tests/upgrade-tests.txt`) |
| root package | pass (`tests/root-package.txt`) |
| `./internal/testutil/`, `./es/admission/` in full | pass (`tests/repo-guards.txt`); at `2362e1a` both fail as in CI (`tests/repo-guards-2362e1a.txt`) |
| hangup probe tty/pipe/files | see A19-1 (`probes/hangup.txt`) |
| my 20 mutants | 17 killed; U5, U6b (equivalent) and U20 survive, see Observations (`mutants/mut20.txt`; the same at `2362e1a`, `mutants/mut20-2362e1a.txt`) |
| CI | run 45447840451 on `8a42864` in progress at 18:05Z; run 45441427185 on `bbdfc7c` failed (A20-1); `2362e1a`'s run was cancelled by the push (`ci/runs.txt`) |

## Sensitive material

- The tests use random tokens and test fixtures.
- A scan of the evidence for UUID-shaped strings, "SecretID", names,
  e-mail addresses and LAN addresses found none.

## Effect status

- No commit, push, PR comment, review or merge.
- Nothing outside this container changed.
- The probe file was copied into my test clone, then removed. The clone's
  tree was clean afterwards.

## Final verdict

**ACCEPT**

For the merge gate:

- the PR head must equal `8a42864`;
- CI must be green on it;
- the red-team re-check the coordinator set for #54 comes before the
  merge.
