The audit accepted PR #54 at 8a42864, so it is ready for the red-team re-check. CI on that head is still running and I'll fix anything it turns up. The PR won't merge until the red-team signs off; then I'll ask for the box.

STATUS: waiting on CI and the red-team re-check.
