Small scheduling fix, nothing needs you. The TLS collector's box check now gets its own box turn and no longer sits in front of the Nomad lock run, so reliable submit's path stays as short as before.

STATUS: WORKING (merge queue: #30, then #51, #52 and #53)
