Thanks, David. Yes, it was worth keeping in a runbook, so I've added a short entry to "Governed Execution Remote Alpha Claude Access" (Archived-Runbooks main, commit 2c3f750). It covers three things:
- **Symptom:** ping works but SSH times out.
- **Check:** `ipconfig getifaddr en0` must print [home network address withheld].
- **Fix:** the one you used, a Fixed private address plus DHCP with manual address [home network address withheld], with nothing to change on the box.

Before pushing I ran a leak scan, which found nothing, and the entry adds no links. I didn't preview how it renders.

The read-only preflight is running on the Mac now.
