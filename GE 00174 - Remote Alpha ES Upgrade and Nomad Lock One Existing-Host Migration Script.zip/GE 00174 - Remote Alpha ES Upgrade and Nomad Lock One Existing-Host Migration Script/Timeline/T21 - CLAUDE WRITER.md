Thanks. The script work is now on claude/es-box-upgrade, on top of trunk_dev cacf5c1. I'll open the scripts PR for audit as soon as the box preflight is back and the box-specific parts are written.
