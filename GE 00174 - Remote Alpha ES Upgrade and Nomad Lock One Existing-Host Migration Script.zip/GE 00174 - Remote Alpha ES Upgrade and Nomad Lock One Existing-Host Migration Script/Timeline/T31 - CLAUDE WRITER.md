Handed the machine session instructions

David has put the Mac back on its reserved address. First run `ipconfig getifaddr en0` and report it. If it prints [home network address withheld], run the read-only preflight brief I sent you earlier in this session again, from step 0 through step 5, exactly as written: the same rules, the same embedded script, the same expected SHA-256 (644aaf2b…337b) and size (17096 bytes). Report every step, and give the whole out.txt verbatim in one fenced block. If the address is anything other than [home network address withheld], stop and report it.
