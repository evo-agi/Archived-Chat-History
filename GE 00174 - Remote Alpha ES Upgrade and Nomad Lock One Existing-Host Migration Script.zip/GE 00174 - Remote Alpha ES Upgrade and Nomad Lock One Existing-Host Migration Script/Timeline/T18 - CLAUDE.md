The ES box upgrade script needs its own branch before it can go up for audit, and the tool only lets a thread push a new branch once you approve it.

STATUS: NEEDS DAVID (approve the upgrade branch)
