**PR #54 red-team: no reachable bypass by an unprivileged local account.** One build-source observation (Low, defense-in-depth).

The root write path holds against the vectors you named:
- **Links / races:** every root write goes through `atomic_replace` (O_EXCL+O_NOFOLLOW temp, then rename, no follow), `provision_key` (parent opened O_NOFOLLOW, all checks and the create by dir-fd, key ends `es`-owned 0400), or O_NOFOLLOW reads; the data-dir chown uses `lchown` (no follow) over a `followlinks=False` walk. **Check-to-apply TOCTOU is closed**: apply re-reads and re-validates `es.json` and `nomad.hcl` (SHA-256 re-pinned) before any write.
- **Token:** never printed; `install_es` discards the token bytes; the summary is root:root 0600 inside the 0700 root backup dir.
- **Rollback-to-harm:** can't be forged. `load_backup` requires the backup dir be a 0700 directory **owned by root**, and everything restore trusts lives inside it, so a non-root account can't present a crafted backup.

**O54-1 (Low):** at `apply`, the installed binaries are bound to the commit only by an unauthenticated `provenance.json`; apply does not re-check the binaries' own `go version -m` stamp (though `build` does), and `load_payload` checks the payload dir's mode but not its **owner**. In the intended flow (operator builds into a dir they own, then `sudo apply` it) this is not reachable, since the non-writable check blocks substitution. It bites only if apply is pointed at a non-operator-owned payload dir. I'd fix it two cheap ways: re-run the vcs-stamp check at apply, and require the payload dir be root- or invoker-owned. Not a merge blocker on its own, but it weakens the exact "faithful build of the reviewed commit" property the PR is for, so worth the writer's eye. It's novel vs the audit (its vcs mutants only cover `build`).

Probe and details in the report. Nothing on the box, cloud only; the intended-flow reachability is Inference.

STATUS: READY (red-team done at 8a42864; merge gate and whether to act on O54-1 are yours)
