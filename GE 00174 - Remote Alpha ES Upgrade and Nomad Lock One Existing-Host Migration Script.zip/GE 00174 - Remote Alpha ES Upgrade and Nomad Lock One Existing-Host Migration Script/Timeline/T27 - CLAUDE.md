Yes. Pick "Fixed" instead of Off. It keeps a private address, just a stable one for your home network only, so it can't be used to track you elsewhere. The warning is about Off.

Since "Fixed" is likely a different address from the one your router reserved, the simplest way to get .210 back is:
1. In the same Details window, open TCP/IP.
2. Set Configure IPv4 to "Using DHCP with manual address" and enter [home network address withheld].
3. Click OK, then Apply.

Nothing else can be holding .210, because the router keeps it for the old reservation. Tell me once it's on .210.

STATUS: NEEDS DAVID (Mac back on [home network address withheld])
