David, I need one thing from you before the box work can go on: please get your Mac back on its reserved address, [home network address withheld].

Right now the Mac is on [home network address withheld]. The box's firewall accepts SSH only from .210, so it silently drops the Mac's connections. The box answers ping, but SSH times out. I checked only the Mac's side; nothing on the box or the Mac was changed.

The usual cause is macOS's private Wi-Fi address changing, so the router no longer recognises the Mac for its reservation. To fix it:
1. Open System Settings, then Wi-Fi, then Details next to your network.
2. Set "Private Wi-Fi address" to Off, or to Fixed if Fixed is the one the router reservation was made with.
3. On the TCP/IP tab, click Renew DHCP Lease.
4. Check the address shown there reads [home network address withheld].

If it still isn't .210, the router's reservation needs the Mac's current Wi-Fi MAC address. Tell me once it's back on .210 and I'll rerun the read-only preflight straight away.

STATUS: waiting on David (Mac address); the upgrade script is on claude/es-box-upgrade.
