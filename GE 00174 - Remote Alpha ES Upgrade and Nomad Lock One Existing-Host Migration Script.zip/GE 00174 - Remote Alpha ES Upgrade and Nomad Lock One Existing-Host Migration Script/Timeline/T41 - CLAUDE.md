Catch-up: nothing needs you. The ES box upgrade and Nomad lock are now one script, in [PR 54](https://github.com/evo-agi/Execution-Substrate/pull/54). It's in audit, and then a red-team check, because it runs as root on the box. That's the one Fable spend I'm making before the reset. After it merges, one box turn upgrades ES and locks Nomad.

STATUS: WORKING (PR 54 audit and red-team, then the box run)
