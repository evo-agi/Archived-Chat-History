Thanks. Yes, it's worth keeping. A troubleshooting note is going into the firewall runbook, and I've recorded the Mac setting in the project's machine notes. The box work is resuming now.

STATUS: WORKING (box preflight, then the ES upgrade script PR)
