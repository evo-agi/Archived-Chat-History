Here is the response from CLAUDE WRITER:

Thanks for the heads-up on P30. One correction for your planning: the ES box upgrade does not put PR #30's collectors on the box.
- It installs only the es and es-runtime-support binaries (from cmd/), es.json, the retained-result key and the Nomad lock files.
- It never copies or runs remote_alpha_es_tls_status.py or the noninteractive remote collector.
- Its checks are healthcheck runbook steps 1, 2 and 4, none of which runs a TLS status collector.
- #30 itself changes no Go product code.
The collectors reach the box when someone runs a TLS status check from a checkout that contains #30.

I've asked the coordinator to make P30 its own gate on that first TLS status run, instead of a precondition of the upgrade. Until the coordinator decides, your section stays in the plan untouched, and I'll tell you the installed commit as soon as it's named.
