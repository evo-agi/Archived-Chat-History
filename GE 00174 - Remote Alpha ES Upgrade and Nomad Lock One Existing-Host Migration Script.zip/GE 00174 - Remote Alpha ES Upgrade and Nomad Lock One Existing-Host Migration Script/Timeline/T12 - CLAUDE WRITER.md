Handed the machine session instructions

Read-only preflight on David's Linux test box (ssh alias [test box name withheld]), before upgrading ES there and putting the Nomad lock on it. David approved the bundled box runs on 2026-11-24 at 04:23 UTC, and the coordinator gave this thread the box turn. This step only reads: nothing may change on the box, and nothing on the Mac beyond one new temporary folder.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-box-preflight.XXXXXX) and print it. Shell variables may not survive between your commands, so after printing T use its literal value wherever these steps say "$T".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it; use full paths.
- No sudo on the Mac. No git commands, no installs, no downloads. Do not change, stage or delete anything in any existing folder. Do not change any macOS setting. Playground itself must still exist at the end.

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] ...
- Run nothing on the box except the script below (step 3). Do not fix, edit, start, stop or restart anything there.
- The script prints no secrets. Report its output as it is.

Step 0. Connectivity (Mac):
  route -n get [home network address withheld] | /usr/bin/grep -E 'interface|gateway'; ping -c 3 -t 5 [home network address withheld] | tail -2; nc -z -G 5 -w 5 [home network address withheld] 22; echo "nc22 EXIT=$?"; ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] true; echo "ssh EXIT=$?"
  Also print the Mac's Go toolchain, if any (read-only; no download happens outside a Go module): command -v go; GOTOOLCHAIN=local go version 2>&1 | head -1; ls -d "/Users/ds/Repositories/Execution Substrate" 2>&1
  If ssh fails ("No route to host", a timeout, or exit 255), wait five minutes and run step 0 once more. If it still fails, stop and report both outputs.

Step 1. Create "$T" as above and print it.

Step 2. Write the script below, byte for byte, to "$T/box-es-upgrade-preflight.sh": everything between the BEGIN and END marker lines, not including the marker lines, ending with a single newline. Then print:
  shasum -a 256 "$T/box-es-upgrade-preflight.sh"; wc -c < "$T/box-es-upgrade-preflight.sh"
  Expected: 644aaf2bc83fd07008deee03653efdba93133fa1d91a7c51ca3479dde450337b and 17096 bytes. If either differs, do NOT run it: print the file with cat -n, remove "$T" (step 5) and stop.

Step 3. Run it (read-only, about one minute):
  ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o ServerAliveInterval=15 -o ServerAliveCountMax=4 [test box name withheld] 'bash -s' < "$T/box-es-upgrade-preflight.sh" > "$T/out.txt" 2>&1; echo "exit=$?"
  If it ends with exit=255 or the output stops before the "===== done =====" line, run step 0, wait five minutes, and run step 3 once more (the script only reads, so a rerun is safe). If it fails again, report what you have.

Step 4. Print the WHOLE of "$T/out.txt" verbatim in your final reply, inside one fenced code block. Do not summarize, shorten or redact it further.

Step 5. rm -rf "$T" (only that folder). Then: ls -d "$T" 2>/dev/null || echo removed; ls -d /Users/ds/Repositories/Playground

Report, for every step, the command, its output and its exit status.

-----BEGIN box-es-upgrade-preflight.sh-----
#!/usr/bin/env bash
# Read-only preflight for upgrading ES on the Remote Alpha box and putting the
# Nomad lock on it (ES writer thread "Lock Nomad so only ES can submit",
# 2026-11-24).
#
# Run from a Remote Control session on David's Mac:
#   ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] 'bash -s' < box-es-upgrade-preflight.sh > out.txt 2>&1
#
# What it does: reads versions, configuration key names, file owners and
# modes, Go build info of the service binaries, the earlier deployment
# summaries, Nomad's anonymous API (ACLs are off on the box), ES's storage
# layout, and the healthcheck runbook's read-only checks.
# What it never does: change a file, unit, package, firewall rule, container,
# Nomad job or service; restart anything; print a private key, token,
# password, unseal material or secret value. JSON configs are printed as key
# names, with values only for a fixed list of non-secret fields. SQLite files
# are opened read-only, and only their schema version and table names are
# printed. The only writes are this script's scratch files under /tmp,
# removed at exit.
#
# Every section is independent: a failing command prints "(unavailable ...)"
# and the script goes on.

set -u
export LC_ALL=C
SCRATCH="$(mktemp -d /tmp/es-preflight-ro.XXXXXX)"
trap 'rm -rf -- "$SCRATCH"' EXIT
S() { printf '\n===== %s =====\n' "$1"; }
SUDO="sudo -n"
NOMAD=http://127.0.0.1:4646

cat > "$SCRATCH/buildinfo.py" <<'PY'
import sys
MAGIC = b"\xff Go buildinf:"
SAFE_BUILD = {"GOOS", "GOARCH", "GOAMD64", "CGO_ENABLED", "-trimpath", "-buildmode", "-compiler", "vcs", "vcs.revision", "vcs.time", "vcs.modified"}
def uvarint(b, i):
    x = s = 0
    while True:
        c = b[i]; i += 1
        x |= (c & 0x7F) << s
        if c < 0x80:
            return x, i
        s += 7
def lstr(b, i):
    n, i = uvarint(b, i)
    return b[i:i + n], i + n
for path in sys.argv[1:]:
    try:
        data = open(path, "rb").read()
    except OSError as e:
        print("  %s: unreadable (%s)" % (path, e.strerror)); continue
    at = data.find(MAGIC)
    if at < 0 or (data[at + 15] & 2) == 0:
        print("  %s: no Go build info in the inline format" % path); continue
    version, i = lstr(data, at + 32)
    modinfo, _ = lstr(data, i)
    modinfo = modinfo[16:-16] if len(modinfo) >= 32 else modinfo
    print("  %s: %s" % (path, version.decode(errors="replace")))
    for line in modinfo.decode(errors="replace").splitlines():
        f = line.split("\t")
        if f[0] in ("path", "mod"):
            print("    " + " ".join(f[:3]))
        elif f[0] == "build" and len(f) > 1 and f[1].split("=", 1)[0] in SAFE_BUILD:
            print("    build " + f[1])
PY

cat > "$SCRATCH/keys.py" <<'PY'
import json, sys
SAFE = {"bind_address", "port", "base_url", "server_name", "datacenter", "timeout_seconds", "base_image", "image", "enabled",
        "staging_root_dir", "results_root_dir", "storage_root", "spire_workload_api_socket_path", "runtime_support_binary",
        "allowed_spiffe_path_prefixes", "allowed_reader_spiffe_path_prefixes", "algorithm", "key_id", "default_mode",
        "read_timeout_seconds", "write_timeout_seconds", "shutdown_timeout_seconds", "codex_cli_path", "store_id", "token_file",
        "runtime_identity_tmpfs_size", "mode", "input_class", "id",
        "cert_file", "key_file", "client_ca_file", "client_cert_file", "client_key_file", "root_ca_file", "bootstrap_issuer_common_name"}
def walk(o, p=""):
    if isinstance(o, dict):
        if not o:
            print("  " + p + " = {}")
        for k, v in o.items():
            walk(v, p + "." + k if p else k)
    elif isinstance(o, list) and all(not isinstance(x, (dict, list)) for x in o):
        leaf = p.split(".")[-1]
        print("  " + p + " = " + (json.dumps(o) if leaf in SAFE else "<list of %d, not shown>" % len(o)))
    elif isinstance(o, list):
        for i, x in enumerate(o):
            walk(x, "%s[%d]" % (p, i))
    else:
        leaf = p.split(".")[-1]
        print("  " + p + " = " + (json.dumps(o) if leaf in SAFE else "<%s, not shown>" % type(o).__name__))
try:
    doc = json.load(sys.stdin)
except Exception as e:
    print("  (unavailable: %s)" % type(e).__name__); sys.exit(0)
walk(doc)
PY

cat > "$SCRATCH/paths.py" <<'PY'
import json, os, pwd, grp, stat, sys
def walk(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from walk(v, p + "." + k if p else k)
    elif isinstance(o, str) and o.startswith("/") and p.split(".")[-1].endswith(("_file", "_dir", "_binary", "_path", "_root")):
        yield p, o
def who(st):
    try: u = pwd.getpwuid(st.st_uid).pw_name
    except KeyError: u = str(st.st_uid)
    try: g = grp.getgrgid(st.st_gid).gr_name
    except KeyError: g = str(st.st_gid)
    return "%s:%s %o" % (u, g, stat.S_IMODE(st.st_mode))
try:
    doc = json.load(sys.stdin)
except Exception as e:
    print("  (unavailable: %s)" % type(e).__name__); sys.exit(0)
for key, path in walk(doc):
    try:
        st = os.lstat(path)
        kind = "dir" if stat.S_ISDIR(st.st_mode) else "symlink" if stat.S_ISLNK(st.st_mode) else "file" if stat.S_ISREG(st.st_mode) else "socket" if stat.S_ISSOCK(st.st_mode) else "other"
        print("  %s -> %s: %s %s" % (key, path, kind, who(st)))
    except OSError as e:
        print("  %s -> %s: %s" % (key, path, e.strerror))
PY

cat > "$SCRATCH/summary.py" <<'PY'
import json, sys
SAFE = {"git_commit", "local_git_commit", "source_kind", "status", "result", "outcome", "run_id", "mode", "generated_at",
        "created_at", "timestamp", "applied_at", "completed_at", "started_at", "sha256", "binary_path", "service_name", "config_sha256"}
def walk(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            walk(v, p + "." + k if p else k)
    elif isinstance(o, list):
        for i, x in enumerate(o[:20]):
            walk(x, "%s[%d]" % (p, i))
    elif p.split(".")[-1] in SAFE:
        print("    " + p + " = " + json.dumps(o))
for path in sys.argv[1:]:
    print("  --- " + path)
    try:
        walk(json.load(open(path)))
    except Exception as e:
        print("    (unreadable: %s)" % type(e).__name__)
PY

cat > "$SCRATCH/sqlite.py" <<'PY'
import sqlite3, sys
for path in sys.argv[1:]:
    try:
        db = sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=2)
        v = db.execute("PRAGMA user_version").fetchone()[0]
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        db.close()
        print("  %s: user_version=%s tables=%s" % (path, v, ",".join(tables)))
    except Exception as e:
        print("  %s: (not readable as SQLite: %s)" % (path, type(e).__name__))
PY

cat > "$SCRATCH/api.py" <<'PY'
import json, sys
what = sys.argv[1]
try:
    doc = json.load(sys.stdin)
except Exception as e:
    print("  %s: (unavailable: %s)" % (what, type(e).__name__)); sys.exit(0)
if what == "namespaces":
    print("  namespaces:", [n.get("Name") for n in doc])
elif what == "jobs":
    print("  jobs:", len(doc))
    for x in doc[:30]:
        print("   ", x.get("Namespace"), x.get("ID"), x.get("Type"), x.get("Status"))
elif what == "nodes":
    for x in doc:
        print("  node", x.get("Name"), x.get("Status"), x.get("Drain"))
elif what == "agent":
    c = doc.get("config", {})
    print("  acl enabled:", (c.get("ACL") or {}).get("Enabled"))
    cl = c.get("Client") or {}
    print("  client options:", json.dumps(cl.get("Options"), sort_keys=True))
    print("  client servers:", cl.get("Servers"), "network_interface:", cl.get("NetworkInterface"), "cni_path:", cl.get("CNIPath"))
    for p in c.get("Plugins") or []:
        if p.get("Name") == "docker":
            print("  docker plugin config:", json.dumps(p.get("Config"), sort_keys=True))
    print("  addresses:", json.dumps(c.get("Addresses"), sort_keys=True), "advertise:", json.dumps(c.get("AdvertiseAddrs"), sort_keys=True))
    print("  data_dir:", c.get("DataDir"), "bind_addr:", c.get("BindAddr"))
elif what == "vault":
    print("  vault:", {k: doc.get(k) for k in ("initialized", "sealed", "t", "n")})
PY

S "host"
hostname; date -u +%Y-%m-%dT%H:%M:%SZ; uname -r; uptime -s 2>/dev/null
id -un; $SUDO true && echo "sudo -n: ok"
echo "tools: python3=$(python3 --version 2>&1) go=$(command -v go || echo none) sqlite3=$(command -v sqlite3 || echo none) jq=$(command -v jq || echo none) setfacl=$(command -v setfacl || echo none) curl=$(command -v curl || echo none) setsid=$(command -v setsid || echo none)"
df -h /etc /usr/local /var/lib /var/tmp /tmp 2>/dev/null
for g in "$(command -v go 2>/dev/null)" /usr/local/go/bin/go /usr/lib/go/bin/go /snap/bin/go /home/*/go/bin/go /home/*/sdk/go*/bin/go /root/sdk/go*/bin/go; do
  [ -n "$g" ] && [ -x "$g" ] || continue
  r="$(readlink -f "$g")"; case " ${seen_go:-} " in *" $r "*) continue;; esac; seen_go="${seen_go:-} $r"
  printf '  go %s: %s\n' "$g" "$(GOTOOLCHAIN=local "$g" version 2>&1 | head -1)"
done
$SUDO ls -d /root/sdk/go* /root/go/bin 2>/dev/null | sed 's/^/  root go: /'
echo "  git: $(git --version 2>&1)"

S "services"
systemctl is-active ars ags egs es vault spire-server spire-agent nomad docker es-host-firewall 2>&1 | paste -sd' ' -
systemctl --failed --no-legend 2>&1 | head -10; echo "(failed units above; empty = none)"
for u in es nomad; do systemctl show "$u.service" -p ActiveEnterTimestamp -p NRestarts -p User -p Group 2>/dev/null | paste -sd' ' -; done

S "ES binaries: identity and Go build info"
for b in /usr/local/lib/execution-substrate/bin/es /usr/local/bin/es-runtime-support /usr/local/lib/execution-substrate/bin/ags /usr/local/lib/execution-substrate/bin/ars /usr/local/lib/execution-substrate/bin/egs; do
  if $SUDO test -e "$b"; then
    echo "  $b: $($SUDO stat -c '%U:%G %a %s bytes, modified %y' "$b") sha256 $($SUDO sha256sum "$b" | cut -c1-64)"
  else
    echo "  $b: absent"
  fi
done
$SUDO ls -la /usr/local/lib/execution-substrate/bin/ 2>/dev/null | sed 's/^/  /'
$SUDO python3 -I "$SCRATCH/buildinfo.py" /usr/local/lib/execution-substrate/bin/es /usr/local/bin/es-runtime-support /usr/local/lib/execution-substrate/bin/ags /usr/local/lib/execution-substrate/bin/ars /usr/local/lib/execution-substrate/bin/egs 2>&1

S "earlier deployment summaries (selected non-secret fields)"
$SUDO find /var/tmp/execution-substrate-remote-alpha -maxdepth 3 -name '*.json' -printf '%TY-%Tm-%TdT%TH:%TM %p\n' 2>/dev/null | sort | sed 's/^/  /'
mapfile -t summaries < <($SUDO find /var/tmp/execution-substrate-remote-alpha -maxdepth 3 -name '*binary*summary*.json' 2>/dev/null | sort)
if (( ${#summaries[@]} )); then $SUDO python3 -I "$SCRATCH/summary.py" "${summaries[@]}" 2>&1 | head -120; else echo "  (no binary deployment summaries)"; fi

S "es.json: keys, non-secret values, and the files it names"
f=/etc/execution-substrate/es.json
echo "  $f: $($SUDO stat -c '%U:%G %a %s bytes, modified %y' "$f" 2>/dev/null) sha256 $($SUDO sha256sum "$f" 2>/dev/null | cut -c1-64)"
$SUDO cat "$f" 2>/dev/null | python3 -I "$SCRATCH/keys.py" 2>&1 | head -120
echo "  -- files and directories named in es.json:"
$SUDO cat "$f" 2>/dev/null | $SUDO python3 -I "$SCRATCH/paths.py" 2>&1 | head -60
echo "  -- /etc/execution-substrate/healthcheck.env key names:"
$SUDO sed -n 's/^\([A-Za-z_][A-Za-z0-9_]*\)=.*/    \1/p' /etc/execution-substrate/healthcheck.env 2>/dev/null
echo "  -- /etc/execution-substrate (top level):"
$SUDO ls -la /etc/execution-substrate 2>/dev/null | sed 's/^/    /'

S "es.service unit (values of Environment lines that may hold secrets redacted)"
systemctl cat es.service 2>/dev/null | sed -E 's/^(Environment=[^=]*(TOKEN|SECRET|KEY|PASSWORD|PASS)[^=]*=).*/\1<redacted>/I'
systemctl show es.service -p ExecStart -p Requires -p After -p ReadWritePaths -p ReadOnlyPaths -p StateDirectory -p EnvironmentFiles 2>/dev/null

S "ES storage"
for d in /var/lib/execution-substrate /var/lib/execution-substrate/es; do
  $SUDO stat -c '  %U:%G %a %n' "$d" 2>/dev/null || echo "  $d: absent"
done
$SUDO find /var/lib/execution-substrate -maxdepth 3 -printf '  %y %u:%g %m %s %p\n' 2>/dev/null | head -60
echo "  entries below depth 3: $($SUDO find /var/lib/execution-substrate -mindepth 4 2>/dev/null | wc -l)"
echo "  total size: $($SUDO du -sh /var/lib/execution-substrate 2>/dev/null | cut -f1)"
mapfile -t dbs < <($SUDO find /var/lib/execution-substrate /etc/execution-substrate -maxdepth 6 -type f \( -name '*.db' -o -name '*.sqlite' -o -name '*.sqlite3' \) 2>/dev/null | sort)
if (( ${#dbs[@]} )); then $SUDO python3 -I "$SCRATCH/sqlite.py" "${dbs[@]}" 2>&1; else echo "  (no SQLite files)"; fi

S "Nomad"
nomad version 2>&1 | head -2
systemctl show nomad.service -p User -p Group -p ExecStart 2>/dev/null
pid="$(pgrep -x nomad | head -1)"; [ -n "$pid" ] && ps -o pid=,uid=,user=,args= -p "$pid"
$SUDO ss -ltnpeH 'sport = :4646' 2>/dev/null | sed -E 's/ino:[0-9]+ sk:[0-9a-f]+//'
$SUDO ls -la /etc/nomad.d 2>/dev/null | sed 's/^/  /'
for h in /etc/nomad.d/*.hcl; do
  [ -e "$h" ] || continue
  echo "  --- $h (values of keys that may hold secrets redacted)"
  $SUDO cat "$h" 2>/dev/null | sed -E 's/^([[:space:]]*"?[A-Za-z0-9_.-]*(token|encrypt|secret|password|key)[A-Za-z0-9_.-]*"?[[:space:]]*=[[:space:]]*).*/\1<redacted>/I' | sed 's/^/    /'
done
echo "  --- /etc/nomad.d/nomad.env key names:"
$SUDO sed -n 's/^\([A-Za-z_][A-Za-z0-9_]*\)=.*/    \1/p' /etc/nomad.d/nomad.env 2>/dev/null
echo "  --- API (anonymous):"
for p in /v1/status/leader /v1/acl/token/self; do
  printf '  GET %s -> ' "$p"; curl --noproxy '*' -sS -m 5 -w ' (HTTP %{http_code})' "$NOMAD$p" 2>&1 | head -c 300; echo
done
curl --noproxy '*' -sS -m 5 "$NOMAD/v1/namespaces" 2>/dev/null | python3 -I "$SCRATCH/api.py" namespaces
curl --noproxy '*' -sS -m 5 "$NOMAD/v1/jobs?namespace=*" 2>/dev/null | python3 -I "$SCRATCH/api.py" jobs
curl --noproxy '*' -sS -m 5 "$NOMAD/v1/nodes" 2>/dev/null | python3 -I "$SCRATCH/api.py" nodes
curl --noproxy '*' -sS -m 5 "$NOMAD/v1/agent/self" 2>/dev/null | python3 -I "$SCRATCH/api.py" agent

S "baseline health (healthcheck runbook steps 1, 2 and 4)"
systemctl is-active ars ags egs es vault spire-server spire-agent nomad docker 2>&1 | paste -sd' ' -
$SUDO curl --noproxy '*' -fsS -m 5 --cacert /opt/vault/tls/ca.pem https://172.17.0.1:8200/v1/sys/seal-status 2>/dev/null | python3 -I "$SCRATCH/api.py" vault
$SUDO bash -c '. /etc/execution-substrate/healthcheck.env
for u in https://[home network address withheld]:8445/health https://[home network address withheld]:8445/v1/executions:contract https://[home network address withheld]:8444/health; do
  curl --noproxy "*" -sS -m 10 -o /dev/null -w "  %{http_code} $u\n" --cacert "$CA_CERT" --cert "$OPERATOR_CERT" --key "$OPERATOR_KEY" "$u"
done' 2>&1

S "docker images"
docker images --digests --format '  {{.Repository}}:{{.Tag}} {{.Digest}} {{.Size}}' 2>/dev/null | head -20

S "repository copies on the box"
$SUDO find /home /opt /srv /usr/local/src /var/tmp -maxdepth 4 -type d -name .git -printf '  %h\n' 2>/dev/null | head -20
for d in $($SUDO find /home /opt /srv /usr/local/src /var/tmp -maxdepth 4 -type d -name .git -printf '%h\n' 2>/dev/null | head -10); do
  printf '  %s: %s\n' "$d" "$($SUDO git -c safe.directory='*' -C "$d" log -1 --format='%H %cI %s' 2>/dev/null | cut -c1-140)"
  printf '    owner %s, branch %s, changed files %s, remotes: %s\n' "$(stat -c %U "$d")" \
    "$($SUDO git -c safe.directory='*' -C "$d" rev-parse --abbrev-ref HEAD 2>/dev/null)" \
    "$($SUDO git -c safe.directory='*' -C "$d" status --porcelain 2>/dev/null | wc -l)" \
    "$($SUDO git -c safe.directory='*' -C "$d" remote -v 2>/dev/null | awk '$3=="(fetch)"{print $1"="$2}' | sed -E 's#//[^/@]*@#//#' | paste -sd' ' -)"
done

S "outbound reachability (TCP connect only, nothing sent)"
for hp in github.com:443 proxy.golang.org:443 apt.releases.hashicorp.com:443; do
  if timeout 6 bash -c "exec 3<>/dev/tcp/${hp%:*}/${hp#*:}" 2>/dev/null; then echo "  $hp reachable"; else echo "  $hp not reachable"; fi
done
env | grep -ciE '^(https?|no)_proxy=' | sed 's/^/  proxy env vars: /'

S "trunk red-team box checks (trunk-red-team/box-checks.md rows 1-6)"
echo "  row1 vault $(systemctl show vault -p KillMode 2>&1)"
echo "  row2 $($SUDO stat -c '%U:%G %a' /var/tmp/execution-substrate-remote-alpha 2>&1)"
echo "  row3 (find /etc/vault.d /opt/vault ! -user vault):"
$SUDO find /etc/vault.d /opt/vault ! -user vault -ls 2>&1 | head -40 | sed 's/^/    /'
echo "  row4 (unexpected entries in the artifact folder; empty = none):"
$SUDO find /var/tmp/execution-substrate-remote-alpha -mindepth 1 \( ! -user root ! -user ds -o -type l -o -perm /022 \) -ls 2>&1 | head -40 | sed 's/^/    /'
echo "  row5:"
$SUDO stat -c '    %U:%G %a %n' /etc/execution-substrate /etc/execution-substrate/host-firewall /var/lib/es-host-firewall 2>&1
sysctl fs.protected_hardlinks fs.protected_symlinks 2>&1 | sed 's/^/    /'
echo "  row6 /tmp $(stat -c '%U:%G %a' /tmp 2>&1)"

S "ES journal (last 15 lines; token-like strings redacted)"
$SUDO journalctl -u es.service --no-pager -n 15 -o short-iso 2>/dev/null | sed -E 's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/<uuid>/g; s/(hvs|s)\.[A-Za-z0-9]{20,}/<token>/g'

S "done"
-----END box-es-upgrade-preflight.sh-----
