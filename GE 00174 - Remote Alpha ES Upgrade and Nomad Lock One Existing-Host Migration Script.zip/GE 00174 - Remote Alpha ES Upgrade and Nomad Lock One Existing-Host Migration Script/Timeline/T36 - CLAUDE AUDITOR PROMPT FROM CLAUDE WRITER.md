Here is the response from CLAUDE WRITER:

Audit request: ES PR #54 (scripts, tests and docs only; scripts-only merge policy, so audit plus gate). Branch claude/es-box-upgrade, head ea08d2f, on trunk_dev cacf5c1. Under David's quota plan, please keep it lean and focused.

What it is: the one existing-host migration contract, scripts/remote_alpha_upgrade_es.sh with its Python core scripts/internal/remote_alpha_upgrade_es.py. It moves the box's ES from 74748063 to a named commit and applies the Nomad lock (#31/#48) in the same run, because current ES refuses the old es.json and the lock needs nomad.token_file. The design is in project files reports/Execution-Substrate/es-box-upgrade/02-plan.md (draft 2) and the box facts are in 01-preflight/03-findings.md. The new doc section is "Remote ES Upgrade And Nomad Lock" in remote_supported_host_alpha.md.

Where I most want your eyes:
- apply's automatic rollback after the backup, on any exception or on SIGTERM, SIGHUP or SIGINT. Can any path leave ES or Nomad stopped, or leave a file half-restored?
- The Nomad data ownership ledger (ownership.json) and its restore.
- The pinned nomad.hcl SHA-256 and the lock transform. A test checks the pieces against 70_linux_setup.sh.
- esconfigcheck is still only config.Load. Its pin test is in an earlier commit.
- OBSERVER_USER=root, and the backup root /var/backups/execution-substrate-es-upgrade.
- build: the vcs.revision check and the refusal of a dirty checkout.

Local results, as a non-root user: the 13 upgrade tests pass (fakes for systemctl, curl, nomad and the ACL setup), the root package passes, and vet is clean. The locked box nomad.hcl passes `nomad config validate` on 2.1.1. A full scripts-package run is in progress here, and its first pass showed failures that look environmental (macOS /private/tmp, a missing uuidgen, no user ds). I'll confirm them against trunk_dev, and CI is the gate.

The box run comes after the merge, in its own box turn from the coordinator.
