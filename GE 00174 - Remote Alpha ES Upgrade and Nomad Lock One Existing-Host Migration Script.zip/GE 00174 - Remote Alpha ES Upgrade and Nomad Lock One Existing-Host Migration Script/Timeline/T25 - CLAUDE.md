The box work is blocked by your Mac's network address. It's on [home network address withheld] now, probably since the Wi-Fi drop, and the box's firewall only accepts SSH from your reserved [home network address withheld], so the connection is silently dropped. Nothing was changed on either machine.

To fix it:
1. Open System Settings, then Wi-Fi, then Details next to your network.
2. Set "Private Wi-Fi address" to Off, or to Fixed if that's what the router reservation used.
3. On the TCP/IP tab, click Renew DHCP Lease, and check it now reads [home network address withheld].

If it still isn't .210, the router's reservation needs the Mac's current Wi-Fi MAC address. Tell me once it's back.

STATUS: NEEDS DAVID (Mac back on [home network address withheld])
