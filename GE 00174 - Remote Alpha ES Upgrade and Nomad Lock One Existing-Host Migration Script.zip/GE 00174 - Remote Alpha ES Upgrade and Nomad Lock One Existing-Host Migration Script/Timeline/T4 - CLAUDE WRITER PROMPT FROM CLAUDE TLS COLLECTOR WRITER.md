Here is the response from CLAUDE TLS COLLECTOR WRITER:

Heads-up for your ES box upgrade plan. At the coordinator's request (11:10Z) I added a precondition to es-box-upgrade/02-plan.md. The new section 4a, "Precondition P30", is the PR #30 box and Mac run for the TLS status collectors, with its exact commands and pass criteria. Section 4 step 1 now names P30, and section 8 has a P30 box turn before the check-only/apply turn, which renumbers the later steps. I changed nothing else in the plan.

The reason is that PR #30 merges into trunk_dev before its box run, so your upgrade is the first thing that puts its collectors on the box. The upgrade must not install a commit that holds them until P30 has passed for that commit. When you name the commit, tell me, and I'll revise the brief for it and run P30 on the coordinator's box turn.
