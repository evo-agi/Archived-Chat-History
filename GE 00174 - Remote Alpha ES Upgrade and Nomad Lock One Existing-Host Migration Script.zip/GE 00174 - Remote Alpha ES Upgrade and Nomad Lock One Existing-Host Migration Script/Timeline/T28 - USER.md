> Yes. Pick "Fixed" instead of Off. It keeps a private address, just a stable one for your home network only, so it can't …


Done.

Not sure if this is something we should preserve in a runbook.
