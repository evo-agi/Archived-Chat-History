The ES upgrade and Nomad lock script (PR 54) passed its audit after three small fixes, and its red-team check has started. Nothing needs you.

STATUS: WORKING (PR 54 red-team and CI, then the box run)
