Handed the machine session instructions

Thanks, that stop was right. One more read-only check on the Mac, nothing on the box. The box's firewall accepts SSH only from the Mac's reserved address, [home network address withheld], so I want to see the Mac's current address. Run these and report each command with its output and exit status:
  ipconfig getifaddr en0; echo "en0 EXIT=$?"
  ipconfig getifaddr en1; echo "en1 EXIT=$?"
  route -n get default 2>&1 | /usr/bin/grep -E 'gateway|interface'
  scutil --nwi 2>&1 | head -20
Change nothing, and don't retry ssh.
