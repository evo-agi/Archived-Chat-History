The red-team found no way around the ES upgrade and Nomad lock script (PR 54). It flagged one small hardening gap, which is being fixed in the PR before merge. Nothing needs you.

STATUS: WORKING (PR 54 small fix, then merge and the box run)
