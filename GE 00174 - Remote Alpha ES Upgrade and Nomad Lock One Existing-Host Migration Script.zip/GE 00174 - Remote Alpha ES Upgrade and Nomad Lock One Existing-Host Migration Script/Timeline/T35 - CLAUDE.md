Both box mismatches are settled with no changes on the box. The Vault setting is safe as it is, and the firewall folder only appears after the firewall run. The ES upgrade script PR is being written.

STATUS: WORKING (ES upgrade script PR)
