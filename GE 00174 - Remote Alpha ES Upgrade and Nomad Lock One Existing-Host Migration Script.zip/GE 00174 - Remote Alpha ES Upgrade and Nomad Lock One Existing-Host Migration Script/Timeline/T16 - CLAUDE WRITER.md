Asked the project to choose an option

Can I push the ES box upgrade script to a new branch, claude/es-box-upgrade?

1. Yes, new branch (recommended): I push the upgrade script to claude/es-box-upgrade and open a scripts PR for audit, then run the upgrade and Nomad lock on the box.
2. No, use another name: Tell me the branch name, and I'll push there instead.

Why recommended: My standing branch holds the paused Nomad HTTPS work, and moving it would need a force-push. A new branch keeps both safe.
