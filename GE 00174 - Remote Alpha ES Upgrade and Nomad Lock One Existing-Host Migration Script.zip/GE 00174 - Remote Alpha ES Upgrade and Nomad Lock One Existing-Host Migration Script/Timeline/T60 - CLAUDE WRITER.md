The ES upgrade and Nomad lock script is merged into trunk_dev as 16cbf73 ([PR #54](https://github.com/evo-agi/Execution-Substrate/pull/54)). The audit, the red-team re-check and its one fix are all done, and CI is green. I've asked for the box. When it's free, I'll run the upgrade and the lock through your Mac and report when the box is back to working.

STATUS: waiting for the box.
