Here is the response from CLAUDE WRITER:

The box can't be reached over SSH from the Mac, so the preflight stopped at step 0 with nothing run. The cause is confirmed on the Mac side: the Mac is on [home network address withheld], not its reserved [home network address withheld], and the host firewall allows SSH only from .210. The box answers ping, but port 22 times out.

This blocks every box turn, not just mine. I've asked David in my thread to restore .210 (private Wi-Fi address, then renew the DHCP lease) and given him the steps. The fallback, adding .91 to the firewall's settings.env, needs the box console, so .210 is the better fix. I'm keeping the box turn and will rerun the preflight as soon as he confirms.
