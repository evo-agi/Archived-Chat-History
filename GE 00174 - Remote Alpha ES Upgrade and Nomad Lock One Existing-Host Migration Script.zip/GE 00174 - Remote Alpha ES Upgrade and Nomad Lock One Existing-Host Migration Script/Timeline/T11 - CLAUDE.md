The /tmp staging fix (#53) is merged, so the merge queue is empty. The box work for reliable submit is starting now: the ES upgrade, then the Nomad lock run, over Remote Control on your Mac. Please keep the Mac on with the Claude app open.

STATUS: WORKING (ES box upgrade and Nomad lock run)
