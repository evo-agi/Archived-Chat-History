> The box work is blocked by your Mac's network address. It's on [home network address withheld] now, probably since the Wi-Fi drop, and the …


MacBook warns that turning `Private Wi-Fi address` off can allow others to build a profile against me. Is there another way to go about it?
