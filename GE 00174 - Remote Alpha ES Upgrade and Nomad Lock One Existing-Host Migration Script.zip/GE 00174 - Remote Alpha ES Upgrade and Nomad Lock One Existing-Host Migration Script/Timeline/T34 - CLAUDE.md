The box preflight ran cleanly and changed nothing. The box's ES is 97 commits behind trunk_dev, so the upgrade script will build it fresh on the box. The script PR comes next, then one box turn for the upgrade and the Nomad lock. Two small mismatches turned up, in a Vault setting and a missing firewall folder. Neither blocks the upgrade, and the owners have them.

STATUS: WORKING (ES upgrade script PR)
