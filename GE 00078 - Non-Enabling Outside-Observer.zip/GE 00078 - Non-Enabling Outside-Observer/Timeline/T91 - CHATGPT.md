**Retain the migration block, but carry forward C1, its source projection, C2, and R7 as locally satisfied design judgments. The next task is a bounded T1–T3 correction—not another receiver redesign or an implementation attempt.** The review identifies no essential missing input; its blockers are contradictions and omissions in the active map, plus the missing F-grant handoff. :chatgpt-content-reference{index="0"}

**Send this to the original design/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="11"}[T1–T3 authority and owner-closure correction prompt](sandbox:/mnt/data/ES_Temporal_Authority_Owner_Closure/ES_Temporal_T1_T3_Authority_and_Owner_Closure_Prompt.md).**

Paste this boundary directly into the Codex message **before the attachment**, rather than leaving it only inside the file:

> Read the entire attached task before selecting any command. Do not run Git or a repository bootstrap. Work outside all checkouts under `/Users/ds/Downloads/`; repository guidance may be read only as plain files.

The task authorizes external document/map correction and inert-data checks only. It does not authorize code migration, host contact, cleanup, or live adoption.

## The recurring defect is disagreement between map levels

The report shows that some nested dispatch rows now say the right thing while their enclosing family gates still grant broader authority. Other rows count the same release obligation twice or describe an acquisition-bearing inventory operation as pure observation. All 419 source-range hashes matched, but those checks could not establish semantic completeness. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

**The correction must give each actual effect and acquired-owner duty one canonical meaning inside the existing map.** Family summaries, caller references, examples, and scenarios must agree with it. They must not independently restate permissions that can diverge.

This is a proposed correction to the map’s organization—not a new runtime registry, policy engine, or map compiler. It should reduce competing rules, not add another overlay explaining why contradictory active rows should be ignored.

## 1. T1: remove parent authority from local paths and finish the caller mapping

The review identifies two separate unfinished tasks.

First, E35–E37 still offer **“T or” local authority** at family level. That conflicts with their L dispatch rows and the corpus’s separation between worker/supervisor-local stopping and independently authorized external-parent teardown.

Second, actual local dispatch and fallback paths remain unmapped: `finalizeCandidate`, `terminateCandidate`, `signalCandidateGroup`, and formatter pidfd/group signaling. The report supplies their exact locations, including `worker_linux.go:1227,1242,1284–1306,1412,1422` and `live_linux.go:693–723`. These are reviewer-reported source anchors for Codex to inspect, not source I independently examined here. :chatgpt-content-reference{index="3"}

The selected direction remains unchanged:

**A local signal consumes its original local authority. A valid parent grant cannot rescue an expired or revoked local grant.**

A shared primitive can have different callers, but that does not make their authorities interchangeable. The correction must map each actual caller to its actor, subject custody, original phase cutoff, normal or emergency rule, fallback check, and returned uncertainty.

The source-selected emergency KILL behavior remains preserved. It neither requires the external parent’s TERM/grace sequence nor permits guessing a target when adequate custody is absent. Signal return, leader reap, and group absence remain different facts. The current review expressly retains those distinctions. :chatgpt-content-reference{index="4"}

## 2. T2: specify F from independent issuance through actual consumption

This is the one remaining operating-model decision that needs more than correcting map labels.

The corpus says F is independently established and narrowly scoped. The map does not yet identify its issuer, holder, transfer, or consumption. Meanwhile, the accepted terminal protocol uses ordinary `request.Owner.authorize`; that owner cannot manufacture independent F authority merely because the run failed. The map also offers F for ledger, scratch, unmount, worker-close, and ordinary finalization effects outside its selected scope. :chatgpt-content-reference{index="5"}

**For the correction, I am selecting one separately scoped F term inside the independently issued run-v4 approval.** It uses the already proposed independent run-approver/custodian role—not a new F-issuer service.

The proposed path is:

```text
Independent run-v4 approval with narrow F term
→ strict phase-specific authority ingress
→ distinct immutable validated F authority held by the supervisor
→ exact terminal publication request
→ separate admission of each permitted failure-publication effect
```

This is a **successor design decision**, not current functionality or an issued grant.

The future live entry must validate and retain that term before run effects. Its absence cannot be repaired afterward by a helper flag, a receipt, or a detached context. The enclosing approval authenticates the term; it must not contain its own future digest.

The contract must bind the designated holder, episode, target, source/build, temporal contract, original D, fixed failure-publication roles, resource limits, and independent cancellation/revocation semantics. It must also identify the source and limits of each current validity check. “Unrevoked” cannot remain an unsupported Boolean supplied by the helper.

Export custody needs a noncircular treatment. The approval can bind an independently established base and fixed episode-relative targets; newly created child identities are bound when acquired. The grant does not invent those future identities or supply missing held custody.

**F’s effect ceiling stays narrow:** the selected E48 failure-file Open/Write, file Chmod/Sync, failure-directory Chmod/Sync, and parent Sync. Each is separately admitted under valid F and before D. F does not authorize the other ledger, scratch, unmount, worker-close, or finalization paths. E49 remains its distinct fallback, not an implicit extension of F.

After failure or refusal, qualifying C releases remain separate. A later close cannot repair a missed Sync, create a durable post-D report, or upgrade the episode to success.

Adding this F term necessarily touches the proposed run-authority graph. The task must recheck those affected C2 relationships while preserving import-v3’s canonical bytes and C1’s bounded input relationships. It must not introduce an unmetered F sidecar or reopen the already settled receiver design generally.

## 3. T3: count acquisitions and release duties—not appearances in the map

The review’s clearest example is `heldRoot`: one acquisition and deferred close in `scratch_removal.go`, referenced again by its caller, but two active C placements in E20. Worker channel, namespace, and pidfd releases are similarly cross-indexed without an alias relationship. :chatgpt-content-reference{index="6"}

**A caller reference is not another release permission.**

The successor map must have one canonical duty for each acquisition instance, with explicit non-effect aliases or mutually exclusive release branches. That does not mean deduplicating by pathname, inode, or descriptor number: two actual opens or duplicates can create separate owned handles, while a reused numeric descriptor can identify a different acquisition.

The missing acquisition side matters equally. The scratch path opens parent, root, inventory-view, child, current, and ancestry handles. Those operations require actual admission edges and partial-result treatment. Labeling the overall purpose “inventory” does not make its descriptor acquisitions disappear. :chatgpt-content-reference{index="7"}

The correction must therefore connect:

> Admission → successful acquisition → actual owner or transfer → consuming invalidation → one primitive release attempt → released or uncertain result.

A refused acquisition creates no C duty. A successful acquisition followed by a refused next operation retains its duty. A close error does not recreate ownership or permit another attempt through a saved number.

The corrected image-release anchor and useful finite owner inventory should remain; the review explicitly recognizes those improvements. This is completion of their relationships, not another inventory restart.

## Make these failures part of the owner’s completion checks

The next handoff requires checks against the **whole active map**, not just the corrected nested rows.

In disposable in-memory copies, the owner must restore a `T or L` family gate, add F to an unmount or ledger operation, remove a required local dispatch or scratch acquisition, duplicate the `heldRoot` release duty, break a worker-release alias, and remove F ingress. Each must fail its named, independently fixed conformance obligation.

Those are inert map checks, not runtime tests or a proof of general program correctness. Source inspection still establishes whether the listed primitive and caller relationships are accurate. Their purpose is to prevent this particular set of contradictions from surviving another round of successful hashing and row counting.

C1’s budgets and source projection, C2’s existing ingress/version treatment, and R7’s reservation rules carry forward at their stated **design-level** scope. Actual receiver implementation, feed qualification, and custodian enforcement remain future work. :chatgpt-content-reference{index="8"}

## The Git violation remains a real method failure

The review ran both prohibited Git commands before reading the no-Git restriction. Its 228 matching consumed-file fingerprints are useful preservation evidence, but they are not a full repository comparison or proof that those initial commands had no transient effects. The report correctly limits that claim. :chatgpt-content-reference{index="9"}

I will not characterize the review as fully compliant with its execution boundary. Its concrete findings remain actionable; repeating the unchanged rejected review would not repair the design.

Putting the restriction in the top-level message makes it visible before attachment-driven work begins. It is not technical enforcement. The next owner report must still account for the actual commands and retain any departure rather than letting matching file hashes excuse it.

## Endpoint and remaining gates

The intended owner endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_T1_T3_AUTHORITY_OWNER_CLOSURE_READY_FOR_FRESH_REVIEW
```

It requires a corrected sole corpus, complete active map, concrete F handoff, unambiguous acquisition/release relationships, and the fixed conformance checks. It leads to a fresh separate-parent affected design review—not implementation.

The old helper’s scoped source closure remains historical under its old contract. Remote scratch, survivor, and possible disconnected-observer state remain unknown. Administrative establishment, actual approvals and F issuer, target/feed/clock/storage qualification, reservation enforcement, mounted cases, deployment and supported-local proof, the unconditional whole-candidate ES audit, and exact-byte publication remain separate pending gates. :chatgpt-content-reference{index="10"}

### Inspection boundary and confidence

I read and fingerprinted the complete attached review: **17,392 bytes**, SHA-256:

```text
c499f1898a82d8aaa5ed08fd9b357e1865d15b2c42ffd64771ab3a780cbe2852
```

I also inspected the preceding correction handoff. The latest review ZIP, complete migration map, specialist originals, and accepted implementation were not inspected here; their detailed authentication and source findings remain **independent-reviewer-reported**. The new prompt supplies their retained paths and known identities. No repository commands, reviewed code, tests, hosts, or cleanup were executed here.

**Sources:** attached independent review, current proposed corpus, and preceding correction handoff. **Confidence: 0.97 in retaining the migration block; 0.92 in this bounded correction direction.** Attachment identity is measured; corrected-contract coherence, implementation readiness, operational consent, and privileged readiness remain unestablished.
