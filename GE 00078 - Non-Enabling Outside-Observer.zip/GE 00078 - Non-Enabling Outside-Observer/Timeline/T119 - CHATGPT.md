Attached Codex's response.
Current result as of 2026-10-11 18:57:59 EDT (UTC−04:00).

### A. Primary result

`SELECTION_PROBE_AUTHORIZATION_SOURCE_ROLE_ACCESS_CONTRACT_READY`

The **architecture contract is frozen**. The existing W180 source and unaccepted W181 draft still contain the prohibited edges; W182 adjudicated them and defined the next implementation, without changing pipeline code.

### B. Repository and predecessor-authority identities

The repository remained clean on `codex/wallpaper-selection-restoration-probe-v1`: HEAD `a3d3f845fcbf55d62adc2a96f7c87c9c7eec14dc`, tree `a480d73433aade14d714c8ec8a49f8d511df08d1`, parent `c2b9f5016ca0d65ed984a5e56f8f345a69fa40fb`, upstream at HEAD, divergence `0/0`. Protected and publication refs matched their authority; 29 `refs/codex/turn-diffs/**` refs were recorded separately.

The accepted executable remained 223,552 bytes, SHA-256 `7f9da30522be4222085454035337503755254b76dd1e73fbb5a0cdbe2f124009`, CDHash `d7171e15f7ecbf0d4b9b69bc17bd7d25e0911fa7`, with App Sandbox as its sole effective entitlement and zero observed processes. Both W171 authority bundles matched SHA-256 `853447111bbb51025bc6977e541f85554c369eb12b8cd9cf63ab3a6c0e7e0139`. W130 matched `5b55e8566ff2bdc55a97170889ceb642fc01e5070c84b7e9d138bde28ff23142`; W131 ACCEPT and W172 pipeline-only readiness retain their stated verdict scope. W180’s 127-file source freeze matched SHA-256 `4f6c40eb9920399a68908c8ebe291a8283a47be891a319b178dd4c3384808ce5`.

### C. W181 conflict disposition

W181 stopped before source freeze and created no live authority. Its conflict was the literal rule treating every cross-domain byte read as execution authority. The frozen rule now distinguishes imports and execution from immutable reads, requires mounted packet evidence to use role C, and permits only the pinned gate handoff into mounted execution. W181’s source remains draft evidence.

### D. Complete source inventory

| Source set | Total | Mounted | External | Roles A / B / C / D / E |
|---|---:|---:|---:|---|
| W180 accepted | 127 | 77 | 50 | 76 / 46 / 1 / 0 / 4 |
| W181 draft | 130 | 77 | 53 | 76 / 49 / 1 / 0 / 4 |

Role C in the original inventory is `pipeline/README.md`. The active `pipeline/integration.json` is role A configuration. The four role E files are `calibrate_environment.py`, `generate_w175_template.py`, `regenerate_w175_derived.py`, and `retained_metadata.py`; the two W175 scripts contain dormant imports and must remain unreachable. Every observed file’s location, mode, size, hash, role, and consumers are in the [complete inventory](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/complete-source-inventory.json).

### E. Import and execution graph

W180 has 38 static external-to-mounted imports and two dynamic imports. The W181 draft has 42 static and two dynamic sites: **30 active role-B-to-A sites** and 14 dormant role-E-to-A sites. No ordinary mounted-to-external Python import was found. The graph also records 27 module-path mutations and 165 lexical execution callsites; ten `re.compile` calls are regex compilation, not code execution.

Two edges need explicit treatment beyond ordinary imports: `digest_callsite_controls.py` executes AST-extracted mounted function bodies, so its replacement must be role B; the native gate’s `execve` into the mounted launcher is permitted only as the pinned, post-mount, finite-command domain handoff. See the [classified execution graph](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/import-and-execution-graph.json).

### F. Data-read and evidence graph

The scan records 4,323 lexical read/hash candidates. Parameter-bound calls are recorded symbolically; that number is **not** a claim that 4,323 concrete filesystem paths were resolved. The critical cross-domain flows were expanded independently from their comprehensions.

The packet builder and external closure currently package live task-root B source. The preseal packet estimator also reads those bytes, and the staging manifest separately hashes the external derived producer. Thirty-five B source files, totaling 568,871 bytes in W180, occur in the packet source tuple. These reads are data access, but their source-evidence authority must be redirected to C or its sealed manifest. The [data-read graph](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/data-read-and-evidence-graph.json) records the symbolic calls and the resolved critical flows.

### G. Source-role model

A is mounted executable source; B is external controller executable source; C is evidence-only data; D is an optional pure shared protocol role and is **unused**; E is unreachable historical source. Each original source file has exactly one role in the [authority partition](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/frozen-source-authority-partition.json). The generated C projection is separately enumerated in the projection contract.

### H. Access-mode contract

Imports and execution stay in their assigned A or B domain. External B may read, hash, and compare mounted A bytes as immutable data. Mounted packet, closure, and budget authority for B source must use sealed C evidence. C may be read, hashed, compared, and packaged, but never imported, loaded, compiled, or used as a program. A B-to-A subprocess transition is allowed only through the exact admitted gate after mount and before detach. The [access contract](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/source-role-access-contract.json) defines all seven modes and the detach boundary.

### I. External-to-mounted import adjudication

All 30 active draft import sites have a specified role-B replacement. They occur in the bootstrap and its controls, alias authority, environment and observer controls, template and linker generation, corpus materialization and conformance, derived generation, and template verification. The pre-mount import of mounted `preseal_records.py` must become a B-owned estimator. AST-extracted execution in digest controls must become independent B vectors checked against A data. No existing mixed module qualifies wholesale for D. The [edge adjudications](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/edge-adjudications.json) give each site and disposition.

### J. Mounted-to-external read adjudication

The packet builder, external closure, and preseal packet estimator must stop taking B source bytes from the live external executable tree. They must consume the C projection or its sealed metadata. The derived-producer hash in the staging manifest must bind the B source manifest and corresponding C hash. External bootstrap records remain separately admitted data inputs.

### K. Evidence-projection design

The frozen corpus location is `proof/external-control-source-evidence/`. The W181 draft fixture contains **49 uniquely named `.blob` files, 726,379 bytes total**, plus a manifest. Each row binds the external path, observed B source-index identity, original and projected mode/size/hash, producer action and direct exit, and consumers. The observed draft B index is SHA-256 `8c0f37173ae586facfad22cdb619dec1ab9a2656c5c54a26ca5dc402a8514a1f`.

Production must generate a new B manifest after final source edits, then copy and independently verify C during post-freeze expansion. C files must be regular, single-link, mode `0444`, absent from `sys.path` and every loader or command path. W180’s 151-node source stage can retain its chronology; its historical 547-node expanded layout must be recalculated. With the 49 draft B files alone, the provisional count is **598 nodes**. The [projection contract](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/external-control-source-evidence-projection.json) and fixture do not claim to be a materialized pipeline corpus.

### L. Shared pure protocol adjudication

Role D is unused. The imported contracts, substrate, preseal, and compiler modules contain filesystem, process, or lifecycle behavior. Pure values can be implemented independently in B and compared as data. Synthetic checks rejected differing D projections, environment and filesystem access, import-time effects, and mutable globals; a pure serializer passed. No real D module was certified or created.

### M. Final source authority partition

The closed candidate partition covers all 130 observed W181 draft source files, with the W180 accepted identities retained separately. It binds roles, permitted execution domains and access modes, import and data-read consumers, lifecycle use, and the planned C path for every B file. Its final-state invariants require zero active cross-domain imports, zero C execution paths, E unreachability, and runtime binding for parameterized inputs. Current source violations remain until the next task implements those dispositions.

### N. Lifecycle and detach independence

Pre-mount execution is B-only. Mounted operation permits A execution through the gate and B verification of A data. `DETACH STARTED` begins after export verification and quiescence, before the first detach mutation: all mounted children must have exited; the controller must have no cwd or executable-source descriptor under E; no new E import or launch may occur. Read-only inspection found `external_mount_controller.py` implements final and abort detach from B, including mount/image checks. W182 did not invoke detach.

### O. Contract control results

`python3 contract_controls.py` passed **23/23** cases, including all 18 required cases and extra gate, projection-generation, and mutable-global checks. Case 18 validates the **modeled graph after the specified dispositions**; it does not assert that W180 or W181 code has already been repaired.

### P. Independent review and disagreements

A separately implemented checker reparsed source without importing the primary classifier and passed **199 checks**. It confirmed the 42 static plus two dynamic W181 cross-import sites, 35 packet-tuple B sources, 49 projected blobs, the native gate handoff, and B-only detach structure.

Three cautions remain explicit: lexical read candidates are not resolved filesystem reads; the gate needs a finite exception to a literal B-only execution rule; and packet-only analysis misses the preseal estimator and producer hash. The [independent review](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/independent-review.json) preserves them.

### Q. Exact next implementation contract

The [next implementation contract](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/next-implementation-contract.json) freezes a **40-path task-owned scope**, with no inherited-target path. Its path set covers the import-removal sites; command contracts and nine linker-policy owners; packet, closure, budget and source binding; source freeze, mode and layout verification; materialization; and bootstrap, gate and detach controls. The sequence is: rebaseline; implement B-owned cross-domain replacements and C producer; generate and independently verify one canonical nine-owner linker policy; generate its command template; recalculate layout and budget; run controls; freeze source; project C; verify expanded corpus; publish the manifest transactionally; then verify packet, closure and B-only detach. Any additional source path requires an explicit scope amendment in that next task. W182 performed none of these implementation steps.

### R. Review-packet identities

[Packet A](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/W182-review-packet-A.tar) and [packet B](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/W182-review-packet-B.tar) are byte-identical: **10,721,280 bytes**, SHA-256 `b1ba2788ce701b533f8a3d0cf2b8ec4217723d9a5a51b091c4143c75ce2be769`. Both contain 72 members, were safely extracted, and passed every [packet-index](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/packet-index.json) size, mode, and hash check.

### S. Failed/skipped checks and limitations

Exact successful validation commands, run in `/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD`, were `python3 opening_verify.py` (PASS), `python3 analyze_graph.py` (127/130 source graphs), `python3 build_contract.py` (PASS), `python3 contract_controls.py` (23/23), `python3 independent_review.py` (199 checks), and `python3 finalize_architecture.py` (two verified identical packets). Final `git status --porcelain=v1 --untracked-files=all` returned empty; `git rev-parse HEAD HEAD^{tree}` matched the stated identities.

Three audit-script errors were corrected before final PASS: an initial W171 index path and missing W130 key in the opening script, control case 22’s evaluator order, and an attempted rewrite of an already read-only fixture manifest. None indicated a baseline mismatch. No diagnostic, candidate, linker repair, materialization, image, mount, launcher, AST run, gate, preflight, transaction, recovery, or `xcodebuild` was executed. The [limitations record](/private/tmp/WALLPAPER-MENUBAR-182.access.ITiXShPD/limitations.json) lists the remaining evidence limits.

### T. Final unchanged repository/process/mount state

All writes were confined to the fresh mode-`0700` W182 audit root; its packet index identifies the packet contents. No repository, inherited-target, W180, W181, or predecessor path was edited. The final read-only check found the repository clean at the stated HEAD/tree, accepted-diagnostic process count zero, and task mount and attached-image counts zero.

### U. Confidence

**Authority contract: high.** Source identities, role counts, critical cross-domain flows, the projection fixture, controls, and independent review agree.

**Next implementation gate: conditional.** Its source changes, runtime path closure, revised exact layout and budget, transactional manifest publication, and mounted lifecycle have not been implemented or exercised.
