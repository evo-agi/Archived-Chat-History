Here is ChatGPT's response:

# `R6_ONE_CANDIDATE_R01_R05_INTEGRATED_MODEL_ARTIFACT_REVIEW_BLOCKED`

The candidate-scoped integration is substantially sound, but the exact normative corpus is not yet internally coherent.

## Blocking findings

**F-001 — The new projection contradicts the unchanged general R6 source-projection rule.**

`TEMPORAL_CONTRACT.md:80` requires every native record to appear with the **same native kind and payload**. R9.19 instead requires every selected record to become `kind="candidate-flow"`, with the native kind moved into `detail.transition`, common identity fields added, and some payload fields renamed or flattened.

The finite witness is native sequence `7045`:
```
native:
  kind = controller.receive
  detail = {operation: poll, response_ref: repair-normal-record-44}

projected:
  kind = candidate-flow
  detail.transition = adapter.response-received
  detail also contains the R9.19 common identity fields
```

The mapping is lossless and semantically appropriate, but it is not the literal same kind and payload required by the unchanged rule. R9.19 does not explicitly specialize or amend that rule.

**F-002 — The R9.19 string types contradict the unchanged 256-byte event-detail limit.**

The general event rule at `TEMPORAL_CONTRACT.md:82` limits detail string scalars to 256 decoded ASCII bytes unless a *stricter* rule applies. R9.19 permits:

- `stdout_base64` up to 65,536 raw ASCII bytes;
- `error4096` up to 4,096 UTF-8 bytes; and
- error-array elements up to the same 4,096-byte limit.

The ordinary-success specimen contains a `stdout_base64` value of **5,632 raw ASCII bytes**, decoding to **4,223 bytes**. It satisfies the new candidate-specific token limit but violates the unchanged 256-byte detail-scalar rule. The new raw-token exception does not explicitly amend that separate rule, and 65,536 is not stricter than 256.

## What passed

The review independently confirmed that:

- all three input ZIPs and the nested owner package authenticate exactly;
- the target corpus and map match their claimed bytes and SHA-256 identities;
- the historical `controller.receive` meaning is live-adapter receipt and request/response binding—not the later return of `Controller.apply`;
- the mapping is one-way to `adapter.response-received`, with no legacy alias;
- the 25 native kinds form a closed, unique 25-transition union;
- every parseable positive/refusal specimen reproduced exactly under reviewer-authored projection code;
- ordinary poll, spawn-ungated, RC01, and RC02 preserve their intended causal ordering;
- reviewer-authored structural and type checks found all four positive accounts satisfy R01–R05, while RC01/RC02 fail only the intended poll-treatment ordering;
- all 24 rebound controls are rebound to their current native bytes and expose their intended defects rather than stale hashes or parser errors;
- the malformed body remains a reader error;
- the flat representation remains within five container levels and 50 events in the supplied specimens;
- all 96 scenarios, 176 affected-caller rows, 30 migration rows, 11 fixed cases, and 19 reference positions are exact-preserved;
- the other eighteen candidate lifetimes remain unchanged and uncredited;
- reviewer-authored replay reconstructs the exact target pair; and
- the paired checkpoint is authentic and byte-identical to the current core pair/specifications, while its chronology remains same-owner evidence rather than independent timestamp attestation.

The minimum correction is candidate-scoped: explicitly reconcile R9.19 with the general same-kind/same-payload rule and the general detail-string rule, regenerate the paired artifacts, and submit those bytes to fresh review. Expansion to the remaining candidates should not begin before that correction passes.

## Downloadable review artifacts

- R6_ONE_CANDIDATE_R01_R05_INTEGRATED_MODEL_FRESH_ARTIFACT_REVIEW_BLOCKED_20261014.zip
- R6_ONE_CANDIDATE_R01_R05_INTEGRATED_MODEL_FRESH_ARTIFACT_REVIEW_BLOCKED_20261014.zip.sha256

The compact package is **62,574 bytes**, SHA-256:
```
5f9ea997b5f4096a37a1caf5eda3fb4a10ba15c4eec679d45dac261ddc31d861
```

Its self-verification passed with 21 unique regular ZIP members, 20 manifested payloads, no mismatches, and no copies of the three large primary inputs.

No supplied program was executed. No Codex, repository, Git, host, Bridge, connector, network, repair, or candidate expansion was used.

**Sources:** the authenticated handoff, integrated owner delivery, repaired pilot, preceding scoped review, nested owner package, and reviewer-authored results identified in the report.

**Confidence:** provenance and identity 0.995; artifact replay/static validation 0.98; blocking contract judgment 0.96.
