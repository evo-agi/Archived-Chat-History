Here is ChatGPT's response:

# `R6J_R26_ADMISSION_ACTIVATION_ARTIFACT_REVIEW_BLOCKED`

The exact R26.G05 successor authenticates, and the three R26.G04 findings are closed on their designed repair paths. A new blocking defect remains within the required G05 scope.

## Blocking finding: `R26-G05-FRESH-01`

**Dynamic poll-owner resolution can replace the fixed prerequisite producer before readiness and activation.**

For `q-eof-0004-ppoll`, the prerequisite table fixes the session and peer producers as:

- `q-custodian-0133-accept4`
- `q-custodian-0212-peer-pidfd`

However, the `actual-referenced-owner-instance` branch in `program/admission26.py`:

1. looks up whichever owner instance the input names;
2. checks only that its actor matches;
3. replaces the fixed `producer_request` with that candidate’s producer;
4. uses the replacement producer both for dependency readiness and admission.

It does not require the actual owner to equal `expected_owner_instance`, or the substituted producer to equal the fixed graph producer. The fixed relationship is checked only later by `POLL_ROLE` in `native_account`.

The authenticated `repair__POLL_SAME_ACTOR_WRONG_ROLE` case uses the peer acquisition for both poll roles and reaches `POLL_ROLE`. That confirms the invalid session role has already passed admission.

There is also a first-failure masking path. The authenticated known-error poll shape installs sticky state and causes a later same-scope `recvmsg` to stop at `PHASE_STICKY_STOP`. Because admission runs before `native_account`, combining the valid known-error shape with a wrong same-actor owner shape can prevent `POLL_ROLE` from being reached at all. This is a static source-level composition; I did not execute a newly composed specimen.

No evidence shows that this produces final acceptance of an invalid artifact. The failure is nevertheless blocking because the fixed 22-request/20-edge graph is not the sole determinant of poll readiness and activation, contrary to the review requirement.

## Supported portions

The following passed independent artifact inspection:

- The fixed graph contains exactly 22 ordinary requests and 20 prerequisite edges, is acyclic, and has five declared layers.
- Timestamp buckets and dependency waves avoid lexical request IDs, serialized event order, and dictionary order for fixed prerequisites.
- A ready wave is validated completely before any request, owner/result fact, or sticky fact is committed.
- Sticky facts are created only after admission and affect later admissions only under strict `returned_at < admitted_at`.
- Ordinary wrapper, use, dispatch, poll, and inherited-C accounting consume `activated_owner_facts`, not raw candidates.
- Inherited C requires the exact activated acquisition, matching actor, descriptor, inherited request and reference, invalidation before dispatch, `retry == false`, one consumption, and complete owner closure.
- Candidate and separately validated nonordinary result facts remain separately represented evidence.

All six new G05 controls matched their declared results. The genuinely earlier sticky-error control reached `PHASE_STICKY_STOP`, and all seven positive-base C replacement controls reached `INHERITED_C`.

Thus the original G04 defects are closed on their intended paths:

- premise-invalid error contamination: closed;
- lexical equal-time activation: closed;
- unactivated candidates reaching ordinary ownership/C semantics: closed.

## Authentication and retained execution evidence

All required identities passed:

- Current owner: **428,771,064 bytes**, SHA-256\
  `1ba8866ae3682e4646a7e6eaa36b1ae1e0e66cca2c72fe6c6319c3bda17b2ce6`
- G04 predecessor: **417,231,281 bytes**, SHA-256\
  `81bd7e88cd330abdd53cfdd55bf35c936716549aebaa5e68367d328c026bacbd`
- Compact G05 delivery: **1,604,252 bytes**, SHA-256\
  `9a49aa2069d24c9dc3b7e08b2161019043b5b4d0511e9c169a23e6617b174554`
- Prior blocked review: **73,881 bytes**, SHA-256\
  `3b970f1d2c9dec0b33b4da48e80aa7c4a41d3e0716720278a7c458c39dc8ac31`

Both complete self-excluding owner manifests passed exact membership, safe-path, type, mode, byte-count, SHA-256, and CRC32 verification.

The saved execution evidence also authenticates:

- first substantive checkpoint: **15/15 matched**;
- final round 1: **691/691 matched**;
- final round 2: **691/691 matched**;
- repeated stdout and stderr identities matched;
- zero unexpected exceptions;
- all records bind to the current G05 sources, exact inputs, commands, entry classes, exits, and outputs;
- successor lineage is recorded throughout;
- no retained G03 execution or static G04 prediction was substituted for current successor execution.

These are authenticated owner executions, not reviewer executions.

## Preservation and reconstruction

The declared preservation scope passed:

- normative pair: 2 files;
- historical counterparts: 16 rows / 48 files;
- C replacements: 7 rows / 21 files;
- retirements without replacement: 4;
- unaffected controls: 5;
- register: 393 rows;
- state table: 180 rows;
- companion: 20 rows;
- displacement ledger: 60 rows;
- all 685 G04 expectations retained byte-for-byte;
- phase and shared decision records unchanged;
- direct NRC reopening flags remain false.

The scoped reconstruction also passed at its declared selected-file scope:

- **5,709 targets**: 5,702 additions and 7 replacements;
- exact equality with the selected current/predecessor byte delta;
- no missing, extra, duplicate, or unsafe paths;
- all before, removed-span, and after identities matched;
- wrong-before, wrong-removed-span, and wrong-after guards map to the expected ordered checks.

This does not establish whole-owner reconstruction or semantic correctness.

No uploaded owner, predecessor, checkpoint, replayer, or guard program was executed. No Codex, repository, host, repair, implementation handoff, or general-join expansion occurred.

## Deliverables

&#x20; SHA-256 `10f3c5cea4f25b5a9e7846160015914803e620a542e92ef4cade426b9507a74f`

- ES_R6J_R26_G05_FRESH_ARTIFACT_REVIEW_BLOCKED_20261024.zip\
  53,387 bytes; SHA-256 `376c2c151730afeb4e78a2226620af61bf2ecda2ac1edb040caf1811e7d6755f`

The package contains 18 reviewer-authored reports, evidence summaries, source excerpts, and inert audit scripts. It does not duplicate either large owner.

**Sources:** `program/admission26.py:76–112, 138–155, 314–390`; `program/semantics26.py:283–325, 405–428`; `rules/ADMISSION_PREREQUISITES.json` poll row; `rules/EXPECTED_NATIVE_SCOPE.json`; `rules/NATIVE_RESULT_REGISTRY.json`; `fixed/FINAL_EXPECTATIONS_G05.json`; complete source ledger in the downloadable report.

**Confidence:** provenance 1.00; execution-evidence binding 0.99; preservation/reconstruction 0.99; semantic verdict 0.98.
