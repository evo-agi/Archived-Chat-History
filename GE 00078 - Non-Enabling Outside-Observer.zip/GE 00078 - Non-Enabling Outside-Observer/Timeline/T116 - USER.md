What message should I send to the new ChatGPT chat?
