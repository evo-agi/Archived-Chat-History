**Accept this as the completed artifact-only review result, and retain its `BLOCKED` judgment.** This time the reviewer authenticated the supplied archives, examined the proposal and source, and reached a substantive design decision. It is not another startup failure or a blanket incomplete-input result. Three High design findings remain. :chatgpt-content-reference{index="0"}

**The next task is one owner correction covering AR-01–AR-03. Do not begin implementation or repeat the review against unchanged bytes.**

Send the following prompt **and the full attached review** to the **original Codex design/preparation conversation**:

**:chatgpt-content-reference{index="19"}[AR-01–AR-03 design-correction prompt](sandbox:/mnt/data/ES_AR01_AR03_Design_Correction/ES_AR01_AR03_Design_Correction_Prompt.md)** · **:chatgpt-content-reference{index="20"}[Full artifact review](sandbox:/mnt/data/ARTIFACT_DESIGN_REVIEW.md)**

This is a Codex **authoring task**, not a Codex independent-review task. After correction, the independent gate should return to a fresh **ChatGPT uploaded-artifact review**.

## What should carry forward

The review supports the corrected **numeric-only emergency-target refusal** and the central **inherited-C timing rule**. All 61 canonical C entries now use the surviving, live, unconsumed acquisition-instance prerequisite; ordinary authority expiry no longer erases the release duty. The fresh E40/E50 read acquisitions and worker-channel ownership distinctions also receive substantive support. AR-01 prevents whole-map ownership closure, but does not undo those narrower corrections. :chatgpt-content-reference{index="1"}

The abstract Q/F relationship is also supported: preissuance can be acyclic, query attempts and favorable responses are consumed separately, validity bounds remain meaningful, and status does not become a renewed grant or per-effect human approval. **The unresolved problem is the exact selected realization—not the basic distinction between Q and F.** :chatgpt-content-reference{index="2"}

That gives the next task a useful boundary:

| Finding | Required work | What it does **not** establish |
|---|---|---|
| **AR-01 — raw-owner crosswalk** | Reconcile contradictory active references and cover the omitted shared-helper callers. | A demonstrated live leak or double-close. |
| **AR-02 — Q transport** | Complete both-end setup, qualification, receive-control grammar, and acquisition/release accounting. | An inevitable descriptor installation, credential attack, or unavailable target capability. |
| **AR-03 — exact encoding** | Freeze the complete wire/record grammar and derive its actual maximum serialization. | Proof that the existing caps are necessarily too small. |

Those limits are explicit in the review and should survive the correction report. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

## 1. AR-01: repair every active representation of the owner

This is a concrete map contradiction, not a request for a larger inventory.

E12.03 and E13.02 correctly point to the loop-control and selected-loop acquisitions through their **singular** references. Their other active fields identify a scratch owner, six unrelated scratch acquisitions, and scratch-specific correction records. The reciprocal inventories disagree as well. **An implementer currently has to choose which active fields to ignore.** :chatgpt-content-reference{index="6"}

The correction must reconcile the singular and plural acquisition references, owner class, inventory backlinks, actual primitive, aliases, and active correction metadata together. It cannot fix the singular reference again and leave the conflicting plural fields untouched.

The scratch omission is separate. Parent and root acquisition use the shared terminal helpers, whereas other scratch acquisitions use `openScratchDirectoryAt`. E20.10’s scratch-helper-only release description does not cover all acquisitions it lists, and the existing E52 alternatives do not fill those two caller gaps. :chatgpt-content-reference{index="7"}

The new handoff therefore requires **reciprocal caller/acquisition/owner/release checks**, with each formerly contradictory field corrupted independently. A loop-only acquisition with no scratch handles must still have one coherent release duty; each scratch caller must reach its actual raw-or-wrapped alternative.

It also preserves the reviewer’s reachability qualification. No nil-wrapper failure was executed. A branch may be removed only through exact API/caller reasoning and consistent changes to the map and scenarios—not by assuming it is impossible because its mapping is inconvenient. :chatgpt-content-reference{index="8"}

## 2. AR-02 and AR-03 should be completed together

**These are two parts of one unfinished protocol.** Setup and receive choices determine the identities, control results, errors, and ownership facts that the record must encode. The exact encoding, in turn, determines whether the proposed channel and retained history fit their limits.

I am keeping the already selected finite abstract `AF_UNIX SOCK_SEQPACKET` arrangement, seven attempted exchanges, no reconnect, separate Q/F scopes, and existing evidence budgets. The next task is to complete that arrangement—not replace it with another transport architecture or status-service project.

### Complete the selected setup and receive path

The review identifies missing decisions about endpoint encoding and address length, relevant namespace contexts, the option/qualification sequence, current peer identity construction, exact ancillary capacity, accepted controls, and disposition of unexpected acquired descriptors. Both supervisor and custodian sides need those decisions. :chatgpt-content-reference{index="9"}

The correction must therefore specify the actual sequence and effects, including any bind/autobind relationship, connection completion, peer qualification, send/wait/receive configuration, and release on each early return.

**“Reject unexpected ancillary” is an acceptance rule, not yet an ownership rule.** The task must establish what the selected receive configuration can acquire before that rejection. Where a qualified configuration prevents installation, retain the exact prevention basis. Where installation remains possible, account for the bounded acquired owners without permitting their use. Required credential metadata must remain distinguishable from prohibited controls.

This does not assume either leakage or its absence. The reviewer expressly rejected both shortcuts. Its Linux-source reading was conditional API corroboration, not observation of the actual host. :chatgpt-content-reference{index="10"}

The correction prompt permits narrowly scoped reading of pinned public primary sources to settle those details. It still prohibits socket experiments, descriptor-transfer tests, listener establishment, host contact, and implementation.

### Freeze bytes that independent implementations can agree on

AR-03 is equally specific. The current proposal names semantic field families, but lacks complete canonical challenge, signed-response, and whole-exchange grammars. The issuer-authenticated sequence floor has no exact encoded placement, and nonce derivation has no exact input-byte definition. Those omissions affect constructors, signatures, digests, strict decoders, and replay handling. :chatgpt-content-reference{index="11"}

The next design must select **one exact representation**, including field types and bounds, ordering, presence rules, escaping, signature representation, signed versus unsigned bytes, digest domains, sequence-floor origin, and nonce input boundaries. An abstract `Sign` operation or a list of acceptable formats would leave implementation to make the same missing design decisions.

The existing arithmetic remains useful:

```text
5,464 + 5,464 + 4,096 = 15,024 < 16,384
```

But it establishes the full bound only when **every remaining encoded field** fits the 4,096-byte metadata allowance. Keys, delimiters, escaping, authentication, control/error results, holder and target facts, timing, and filesystem outcomes all need a complete allocation. The review did not establish that they exceed the cap; it established that the packet does not yet demonstrate they fit. :chatgpt-content-reference{index="12"}

The handoff requires a field-by-field maximum calculation and exact inert encoding specimens. A small example that fits is insufficient; an enforced cap that rejects every necessary complete record would also be insufficient.

No limit increase, fourth evidence domain, new signing service, or real key operation is authorized.

## Keep retention chronology explicit

The failure-file Write payload must exist before its Q challenge. It therefore cannot contain that query’s later response, the eventual Write result, or exchanges three through seven. This is a dependency-order constraint—not something hashing or a final transcript object can fix. :chatgpt-content-reference{index="13"}

The corrected design must specify when each exchange record becomes fixed, who holds it, what is only in memory or returned data, and which separately scoped later packaging may consume already existing facts.

**Missing durable history remains an allowed failure outcome.** The task must not create an eighth F effect, rewrite an immutable earlier payload, authorize a post-D helper write, or make a record certify its own future synchronization.

The ordinary-success path also needs its existing distinction preserved: zero F attempts, disposition of the unused Q session, and no reconnect if a later failure occurs after that session was deliberately closed. The artifact review found that abstract history coherent while retaining the setup and observation qualifications. :chatgpt-content-reference{index="14"}

## The four missing ES clauses are a separate evidence limit

The reviewer authenticated the available primary bytes but could not obtain the exact bodies for these four owning-repository anchors:

```text
PLANS.md:399–424
PLANS.md:483–524
.docs/execution_lifecycle/contracts.md:1296–1319
.docs/execution_lifecycle/design.md:660–698
```

It did not substitute older snapshots or reports for them. Their absence limits a broader ES-authority conclusion; it does not invalidate the proposal-level contradictions establishing this block. :chatgpt-content-reference{index="15"}

The correction task includes a bounded source supplement for those clauses from the exact retained versions, where available. If current plain files differ, they must be identified as newer readings—not placed under historical hashes. No full repository-state comparison or additional snapshot project is required.

This should improve the next artifact review’s evidence without turning source collection into another prerequisite loop.

## Routing and completion

Send the correction prompt and full review to the **original Codex owner**. Put this short boundary directly before the attachment:

> Design correction only. Read the entire task before choosing commands. No Git, repository bootstrap, or checkout working directory is authorized. A prohibited action stops the task.

The intended owner endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_AR01_AR03_CORRECTED_DESIGN_READY_FOR_ARTIFACT_REVIEW
```

That requires a corrected sole corpus, complete active map, exact protocol and record definitions, source-derived ownership relationships, and meaningful inert checks. It leads back to **fresh ChatGPT artifact-only review**, not automatically to implementation.

The report describes one actual reviewer performing sequential analytical passes. It does not claim independent subagents, and I am not upgrading it to a multi-reviewer audit. Its reported method and scope are sufficient to use this substantive result without restarting the failed Codex-review procedure. :chatgpt-content-reference{index="16"} :chatgpt-content-reference{index="17"}

Remote scratch, survivor, and possible disconnected-observer state remain unresolved. Actual Q/F establishment, target qualification, reservation enforcement, mounted cases, supported-local evidence, the unconditional whole-candidate ES audit, and exact-byte publication gates remain pending. :chatgpt-content-reference{index="18"}

## Inspection boundary and confidence

I read both attachments and the preceding correction/review briefs. The full attached review measures **35,939 bytes**, with computed SHA-256:

```text
4cce132a44cdf8088d9dfdf78fab51d8770694e214758dd5f31486ade4906e9e
```

I have **not reauthenticated the four underlying archives or the reviewer’s evidence bundle in this conversation**. Their byte-authentication and source/map conclusions remain artifact-reviewer-reported, not a second independent examination by me. No repository commands, uploaded code, tests, hosts, sockets, or cleanup were executed here.

**Sources:** attached `ARTIFACT_DESIGN_REVIEW.md`, the relayed ChatGPT response, and the inspected preceding correction and artifact-review briefs. **Confidence: 0.98 in retaining the block and this sequencing; 0.93 in the bounded correction scope.** Corrected-design coherence, implementation readiness, and live qualification remain unestablished.
