**The repaired candidate has now cleared all five reported local and ordinary native validation lanes. Keep it frozen.** The next task is to make the remaining mounted-helper proof executable—not rerun those suites, make another repository repair, or start the live stack. This is completed implementation validation, not independent acceptance. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

**Send this to the same implementation/validation Codex conversation: :chatgpt-content-reference{index="13"}[Mounted-helper proof preparation prompt](sandbox:/mnt/data/ES_External_Acceptance_Preparation/ES_Mounted_Helper_Proof_Preparation_Prompt.md).**

## What this closes

The report now records complete execution and required-path coverage for the same frozen successor:

| Lane | Passing test paths | Applicable requirements passed | Skips |
|---|---:|---:|---:|
| Local default full suite | 2,333 | 283/283 | 37 |
| Local physical-temp full suite | 2,333 | 283/283 | 37 |
| Local admission/app race | 811 | 240/240 | 36 |
| Native Linux AMD64 admission | 700 | 251/251 | 0 |
| Native Linux ARM64 admission | 700 | 251/251 | 0 |

The local skips are explicitly classified as Docker-unavailable paths and, in the full suites, one deliberate helper-process skip. No applicable required path or socket test skipped. The different requirement totals reflect platform and package selection; they are not competing definitions of success. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

Both latest repairs also have the right reported shape.

The semantic inventory was reconciled through the **ten actual added call sites**, with unchanged reachable-function, dynamic-call, closure, and structured-response inventories. The report records the relevant mutation controls passing and preserves the preceding 267 inventory objects before appending the new obligations. That is materially better than replacing expected counts with whatever the analyzer currently observes. :chatgpt-content-reference{index="4"}

The socket fixture now owns a short physical directory independently of the caller’s temporary-path length, and listener failure is fatal. Its regression performs an actual bind, connection, exchange, close, unlink, and cleanup under a deliberately long caller context. This removes the fragile dependency on the previous four-character runner workaround rather than merely shortening another evidence-directory name. These properties still require source inspection during independent review. :chatgpt-content-reference{index="5"}

### The runner successor does not invalidate the retained local passes

One precision matters: **generation 1 had already completed the local suites**. Its AMD64 entry stopped before extraction or native test execution because of the stale 82-path constant. The successor changed the native helper to accept the authorized 83-path candidate; repository bytes, inventory, local recipe, evaluator, and successful local streams reportedly stayed identical. Retaining those local observations was therefore appropriate on the reported facts. :chatgpt-content-reference{index="6"}

There is no reason to manufacture another local validation cycle merely because that native entry helper changed. The independent auditor should authenticate the exact delta and source bindings later.

## The critical path is now the missing mounted-proof definition

The latest report still says **“fixture/owner definition remains unresolved.”** That is no longer a distant qualification: it is the immediate obstacle to completing acceptance. Ordinary native tests have passed, but the actual mounted disjoint, exact-alias, subtree-alias, and applicable casefold cases have not run. :chatgpt-content-reference{index="7"}

**Leaving that obligation without an executable fixture for this long was a sequencing gap on my side.** The next task closes that gap without reopening the selected topology algorithm.

The preparation prompt requires concrete deliverables:

| Deliverable | What it must establish |
|---|---|
| Source-bound test driver | Calls the actual repaired descriptor/topology/effect paths—not a copied classifier or synthetic substitute. |
| Mounted-case matrix | Specifies real backing relationships, independently expected acceptance/refusal, and protected-state assertions. |
| Setup/run/cleanup recipe | Names the target, resource owner, namespace and privilege boundaries, mount list, bounded scratch, and cleanup conditions. |
| Compile-only evidence | Demonstrates that the driver reaches the current private implementation without changing the frozen repository. |

The preferred mechanism is a separately hashed Linux-only test driver added to a **disposable authenticated source copy**, with all 358 original files preserved. It is compiled but not executed during preparation. Its additional test source is explicitly recorded as proof instrumentation—not silently incorporated into the existing source manifest or presented as another run of the original suite.

That mechanism remains conditional on inspection of the current owning contracts and implementation. It must not require new public exports, mutable production hooks, or a second implementation of the physical-separation proof.

### The mounted proof must test the boundary, not merely return an error

The selected acceptance cases already require more than parser success. They include separately presented disjoint siblings, exact aliases, nesting in both directions, case-sensitive controls, and genuine casefold ancestry where the supported topology includes it. The design also requires rejection before result-side mutation, with staging identities, modes, entries, and bytes preserved. :chatgpt-content-reference{index="8"}

Accordingly, a negative case cannot pass because setup failed, metadata was unavailable, or an unrelated check rejected first. The recipe must demonstrate that the intended topology was constructed, the real helper reached the relevant boundary, and the protected effects did not occur.

Likewise, a missing casefold-capable fixture cannot be relabeled “not applicable” merely because it is inconvenient to provision. Applicability follows the supported contract; unavailable evidence remains pending.

## Mount authority needs its own explicit boundary

The new task **does not authorize mounts, namespace operations, privilege changes, filesystem formatting, or service startup**. It prepares and checks the exact recipe before those effects are considered.

Two external technical facts make that separation important. Cloning a Linux mount namespace does not automatically eliminate shared-mount propagation, so “run it in a namespace” is not a sufficient isolation specification. Ubuntu’s documented unprivileged-user-namespace restrictions also mean that namespace creation and usable capabilities cannot simply be assumed from the operating-system label. Neither fact establishes the current policy on either governed target. :chatgpt-content-reference{index="9"}

The preparation must therefore distinguish fixture setup privileges from the identity under which ES is exercised, verify propagation isolation before any future mount action, and identify exactly which task-owned resources may be removed. It must not select a blanket sudo shell, change AppArmor/sysctls, or discover that a privileged fallback “works” and promote it into authorization.

A single bounded metadata-only acquisition from the known AMD64 host is permitted where useful. It cannot become another service-discovery or environment-restoration campaign, and read-only metadata alone must not be presented as proof that a future mount operation will succeed.

## Keep the other external gates separate—but avoid duplicate setup

The latest report retains three distinct empirical obligations before the final audit and commit gate: mounted-helper behavior, running-deployment compatibility, and the bounded supported-local consumer/operator proof. None was executed in this validation task. :chatgpt-content-reference{index="10"}

The preparation prompt also asks Codex to determine whether **one separately authorized supported-local proof deployment could supply the running-namespace observation before cleanup**. That could avoid restoring a separate stack just to inspect its topology. It is a proposed sequencing improvement, not an assertion that the present contracts already permit that substitution.

The subject still needs to be legitimate: a mounted test process is not a running deployment, current configuration bytes are not automatically startup-loaded bytes, and an observation of one layout does not prove every supported topology. The earlier design distinguishes these evidence subjects explicitly. :chatgpt-content-reference{index="11"}

There is also a practical reason not to launch the canonical wrapper casually. The **historical source supplied here** documents fresh source staging, builds, SPIRE/Vault startup, setup operations, and stale proof-scratch cleanup in `scripts/73_supported_local_proof.sh:30–48`. Its current transitive effects must be inspected before execution; the command name alone does not define a safe effect boundary. The authenticated historical excerpts are in the :chatgpt-content-reference{index="14"}[closeout review notes](sandbox:/mnt/data/ES_External_Acceptance_Preparation/ES_Assurance_Closeout_Review.md).

This does not turn the separate CP application or Temporal stack into an enduring ES dependency. The owning proof remains a bounded compatibility obligation, not a reason to revive the wider demo architecture.

## Inspection boundary and next return

I read and fingerprinted the attached **13,691-byte report**. I also checked three relevant historical source members against their supplied manifest. **The current review ZIP, raw validation streams, corrected native runner, and latest production source were not attached**, so their execution and preservation remain Codex-reported—not independently authenticated here.

Please attach the **existing compact review ZIP** with the preparation result. It is the needed source/evidence input before reviewing mount or service execution authority; no new full snapshot is necessary merely for this handoff.

The preparation task should finish with an executable specification and explicit remaining permissions—not a mounted-proof pass, `FINAL_AUDIT_READY`, or commit authorization. The validated candidate and its successful streams should remain unchanged throughout.

**Sources:** attached assurance report; retained topology design; manifest-checked historical guidance/runbook/script excerpts in the linked review; official Linux and Ubuntu documentation for execution-isolation constraints.

**Confidence: 0.96 in this continuation.** Provenance is independently checked only for the attachments and historical excerpts inspected here. Local/native validation is strongly documented but remains owner-reported pending raw-evidence authentication. Whole-candidate correctness, mounted behavior, deployment compatibility, and independent acceptance remain outstanding.
