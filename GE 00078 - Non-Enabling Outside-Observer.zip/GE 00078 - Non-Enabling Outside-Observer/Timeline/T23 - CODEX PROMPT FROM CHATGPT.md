ES CUST-2 — non-path mount roots: bounded repair and integrated revalidation
Objective and execution authority
Continue in the existing implementation/repair Codex conversation. Repair the real Linux mountinfo failure reported as ES_REPAIRED_CANDIDATE_NATIVE_AMD64_CANDIDATE_FAILURE_ARM64_NOT_STARTED, then validate one successor candidate locally and on AMD64 followed by ARM64. This is a doc-first correction to a faulty CUST-2 metadata-grammar assumption, not environment restoration or another architecture reset.
The cognitive decision is settled here: separate a structurally accepted mount record from a root value that is eligible for pathname-coordinate proof. The minimum added class is a valid nsfs namespace-object root. Retain these records for whole-snapshot integrity and descendant-mount detection; never turn their object labels into directory coordinates. Preserve physical isolation and all effect boundaries.
One foreground parent is the sole repository writer. No subagents or concurrent writers/tests. Read and reconcile the exact current implementation before editing; record the touched set and acceptance mapping in this task. Do not return only a new design report unless a genuine unresolved authority or proof conflict prevents the bounded repair.
Authorized: bounded ES source/doc/test edits below; external evidence and narrowly versioned runner changes; offline local validation; a focused pre-freeze AMD64 development check; one post-freeze complete local validation sequence; then one complete AMD64 suite and, only after its successful closeout, one complete ARM64 suite. Use only the existing governed installed toolchains, caches, trusted transport, and ARM64 instance. Private test/scratch filesystem effects and existing loopback/fake-provider behavior are real authorized test effects, not zero-mutation claims.
Not authorized: staging, commits, push/fetch, branch/ref/worktree changes; dependencies or toolchain installations/downloads; sudo, privilege/access changes, mounts/unmounts, namespace creation/entry, tracing; Docker/service/stack restoration; starting or operating ES/AGS/ARS/EGS/Nomad/SPIRE/Vault or a live workload; CP/operator consumer proof; mounted-helper fixtures; deployment observation; independent audit; external schema-package work. Ordinary start/stop of the existing ARM64 guest is authorized only at the native ARM64 gate below.
1. Authenticate inputs and the live starting candidate
Repository: /Users/ds/Repositories/Execution Substrate/.
Current failure evidence root:
/Users/ds/Downloads/ES-repaired-candidate-native-linux-validation-tDwnay/
Authenticate:
Relative input	Expected identity
ES_REPAIRED_CANDIDATE_NATIVE_LINUX_VALIDATION_REPORT.md	17,044 bytes; SHA-256 507a09b22c8046f62743aae4df13b245a1314eb51c8448e927c05581e5c63400
MANIFEST.tsv	18,904 bytes; SHA-256 b96674c78d713353c34c617c3664e89f70f4fce193338f8974616fa7a5fb5011; 160 self-excluding rows
review/ES_REPAIRED_CANDIDATE_NATIVE_LINUX_VALIDATION_REVIEW.zip	2,599,878 bytes; SHA-256 0bd71adf4d468140f0bbb8ec32a3f9d4268e3b2482a6cdc0219601ca1213f329
runner/native_validation_v2.py	76,317 bytes; SHA-256 1fc96f3bc59d49ac022c5ae2cf09ef470abd639f3d1ff6bb1dfcfe7fd3f70316
runner/provenance_capture.py	8,103 bytes; SHA-256 2ddc24afdcb985a83b242501e641b5f5d065fe461f01a150ff452fffbc4411ca
inputs/immutable-214-row-inventory.json	85,128 bytes; SHA-256 5fe116b95da5d90a1a878f92d436c90425f6489a1d48a8e5c5c4d288189d283d


Read the actual manifests and retained files. Use registered paths for the AMD64 stream/command/environment/applicability records, analysis/amd64-failure-adjudication.json, and amd64/transport/mountinfo-failure-attribution.*. The diagnostic is an observation/projection of selected mountinfo fields, not necessarily a retained full raw mount table. Do not invent unrecorded acquisition bytes.
The current packet includes the prior local review ZIP once under local/, containing the actual 28 cumulative repaired source/doc/test files and recoverable diffs. Authenticate and inspect that source, especially all six execution_roots files. ChatGPT has inspected the new report and top-level manifest, NOT that ZIP, current source, or original execution stream. No independent source acceptance is supplied by ChatGPT.
Expected live opening identity:
- trunk_dev / origin/trunk_dev; HEAD b92bd9884106154d25342e1573dcc4c312311436; tree cdd4e44bac15c1952d70997143040644361f0bb1.
- Source serialization: 358 rows, 67,615 bytes; SHA-256 2e358f3f79b0939e566bf161c0623d5774176af0fe04592b0056e0b8590e55de.
- Candidate serialization: 82 rows, 9,926 bytes; SHA-256 d2b01786d2af4f7fb8778161acdc2a305a921839e1d0890ff9d5f0bae7c051b7; 65 modified and 17 untracked files.
- Complete integration diff: 2,713,982 bytes; SHA-256 78a7e22856f749285562beb9256852c7acb10d94c0658bd7d2f1f7e249d047c9.
- Fixture delta: 5,877 bytes; SHA-256 d3eb32bde6b7e277c47f89576f6f5fb3a8019094af5f7c822f8610d84d272ff6.
- Zero staged/conflicted paths and active Git operation; exact retained six-worktree, status, refs, and locally observed upstream state, with no fetch.
Old source archive, evidence only for old bytes:
/Users/ds/Downloads/ES-validation-adjudication-local-completion-XruE0i/archive/frozen-successor-A.tar
— 7,464,960 bytes, 358 members, SHA-256 cc2338db19f126e527597425fade45ea072aa70df97c180dbd9848d5c88f6338.
Inspect exact provenance recipe sources before reproducing them. Use unchanged serialization semantics, safe Git configuration/attributes, optional locks disabled, and no hooks/external diff or textconv/filter effects. Reproduce opening identity twice. A mismatch blocks mutation; no reset, approximate rebaseline, or cleanup of unrelated state. Never import a retained orchestration script merely to reuse a function with unknown import-time effects.
Verify the old failure remains 663 run / 619 pass / 44 fail / 0 skip, 111/139 applicable required passes, 20 required failures and eight missing children. Confirm the reported shared cause from current source plus retained diagnostics. Do not rerun the rejected full suite or rewrite it as an environmental/analysis failure. Old Darwin passes remain valid observations of OLD bytes only.
2. Governing files, classification, and mutation scope
Read current AGENTS.md, PLANS.md, relevant .docs/system_overview/ and .docs/execution_lifecycle/ pages, exact source/tests/finite inventories, then retained design/amendment/addendum and failure records. Current anchors supplied by the report are PLANS.md:413-453, .docs/system_overview/capability_probing.md:201-207, and es/admission/execution_roots_linux.go:253-255; re-resolve line numbers in the live files.
Classification:
- Staging non-mutation and physical retained-output separation: Current invariant, unchanged.
- Linux metadata grammar and its proof eligibility: bounded implementation/contract correction within that invariant.
- Accepting a kernel namespace-object record is NOT approval to use nsfs as a configured execution directory.
- control-plane-normal-shell/v1: temporary compatibility edge, unchanged.
- All evidence/runner/probe outputs: evidence/projection, not runtime authority.
Primary production/test edits:
- es/admission/execution_roots_linux.go
- es/admission/execution_roots_linux_test.go
Governing text/assertion edits are authorized only where they encode the faulty blanket rule, describe its exact supported replacement, or record this repair and pending gates:
- PLANS.md
- docs_contract_test.go
- .docs/system_overview/configuration.md
- .docs/system_overview/capability_probing.md
- .docs/system_overview/remote_supported_host_alpha.md
- .docs/execution_lifecycle/contracts.md
- .docs/execution_lifecycle/design.md
- .docs/execution_lifecycle/implementation.md
- .docs/execution_lifecycle/es_execution_admission_model.md
Contingent existing paths, only with an explicit pre-edit dependency reason: es/admission/execution_roots.go, execution_roots_test.go, and workstream_c_guardrails_test.go, for private record representation, direct parser/classifier regression plumbing, and truthful semantic inventories. Do not alter common/Darwin isolation policy, syscall/effect ordering, acquisition frequency, or resource budgets. Do not move Linux code into a portable build solely to get a Darwin test pass.
Do not edit mounts/radix code, result/service/Submit implementation, app fixtures, scanner scripts/grammar, DTOs/routes, config/dependency files, examples, runtime profiles, or other repositories. No new source file is expected; put small synthetic mountinfo fixtures in the existing Linux test file. If correctness requires a materially different production proof, new public behavior, or a change outside these surfaces, stop with a concrete finding rather than broaden silently.
The historical 82-path candidate is not a new stage allowlist. Preserve all other bytes/modes/types; report the incremental repair separately from the entire integration candidate.
3. Selected repair contract
The previous requirement that EVERY mountinfo root is an absolute, component-clean pathname is wrong. Change its governing wording before or with implementation and contract assertions. Do not preserve a test that freezes the false grammar by teaching production to filter the host's input.
Separate these three operations explicitly:
1. Record parsing and snapshot integrity. Parse each complete bounded record, including filesystem type; validate mandatory fields, escapes, IDs/device numbers, limits, and parent/stack relationships. Preserve the record and its root representation. Mountpoint remains an absolute component-clean presentation under the existing rules.
2. Root-value classification. Preserve ordinary canonical pathname roots. Add an explicitly classified opaque namespace-object root for source-grounded valid nsfs records. Validate the namespace-object envelope without turning its inode label into authority. Use the retained observed mnt:[4026532502] class and other source-supported namespace kinds/values, not those four inode numbers or only mnt. Inspect namespace operation names before selecting exact recognized grammar; document unsupported forms. Do not apply an arbitrary small integer width to a label that the proof does not need to numerically interpret.
3. Proof eligibility. Only a descriptor-selected record with supported canonical pathname-root semantics can supply a backing path coordinate. An opaque/unsupported selected root refuses before any governed effect, including in the different-device case; never prefix /, apply path.Join/path.Clean to invent a path, substitute mountpoint for root, or fall back to lexical configuration. statx/fstat/device/identity/mount-ID selection remains binding.
For this bounded repair, the newly supported non-path class is nsfs namespace-object roots. Unknown non-path classes and malformed records remain fail-closed; no arbitrary catch-all or growing host-specific exception list. An internal tagged representation or equivalent explicit invariant is preferable to a silently overloaded string. Recognizing a record is different from declaring an additional supported execution-root filesystem.
Retain all nsfs records. They count toward snapshot limits and remain in ID uniqueness, parent/cycle, stacking and descendant-mount checks. A valid unrelated nsfs record must no longer poison qualification. The same record mounted properly beneath either protected canonical root must still cause rejection. Never continue/drop it before those checks, filter raw mountinfo externally, or ignore it merely because its device is different.
Preserve: complete same-namespace bounded acquisition; canonical descriptor presentation/reopen binding; missing-suffix intent and dual-missing refusal; both-direction alias/subtree rejection; justified top-of-tree self-parent and hidden-parent rules; unknown optional-field handling; partial-mask/device mismatch refusal; descriptor ownership/close semantics; named effect-boundary schedule, with no scan per stream Write; no Nomad fallback on topology failure; fixed private/public error boundaries; no raw host paths/namespace metadata in public error/log surfaces.
External corroboration (not a byte identity claim for Ubuntu's patched running kernels): upstream Linux v6.8 fs/proc_namespace.c calls show_path for the root field; fs/namespace.c delegates to a filesystem callback; fs/nsfs.c formats namespace-object labels and registers that callback. v6.17 fs/nsfs.c retains the same label shape. Exact references for optional bounded public source reading from the Mac only:
https://raw.githubusercontent.com/torvalds/linux/v6.8/fs/proc_namespace.c
https://raw.githubusercontent.com/torvalds/linux/v6.8/fs/namespace.c
https://raw.githubusercontent.com/torvalds/linux/v6.8/fs/nsfs.c
https://github.com/torvalds/linux/blob/v6.17/fs/nsfs.c
Only these and their directly relevant upstream namespace-name definitions may be read for grammar grounding; no installation or runtime network dependency. Retained evidence plus source reasoning is sufficient; do not turn an unavailable public fetch into another host-restoration requirement. Mark any unverified namespace form unsupported rather than guess it.
4. Regression and acceptance requirements
Exercise the actual production parser, selector, coordinate builder, and descendant classifier, not a rewritten external copy. New Linux regression parents should use TestLinuxMountInfo... so the focused selection below is unambiguous. Preserve existing tests and their substantive expectations; explicitly realign only assertions of the superseded global root-path grammar.
Required controls:
- Mixed ordinary/path-backed records plus unrelated source-valid nsfs object records: parsing succeeds, every record remains represented, opaque roots preserve their label, and ordinary disjoint roots retain their correct classification. Use differing namespace labels/values without dependence on a live host's four inode numbers.
- Move that opaque record beneath staging, beneath results, and under a canonical presentation whose configured spelling differs: each rejects for the real descendant relationship. Preserve exact-root vs proper-descendant distinction and stacking behavior.
- Select an opaque record as the purported coordinate source (modeled identity evidence): refuse explicitly before coordinate arithmetic/effects, including unequal-device early-return paths. Do not let an unrelated descriptor mismatch mask the intended refusal assertion.
- Duplicate IDs, hidden/existing parents, valid terminal self-parent, nontrivial cycles, malformed escapes/separators/truncation, invalid mountpoints, malformed namespace labels, unsupported non-path roots, byte/record overflow: preserve fail-closed behavior even when nsfs records are present. Opaque records must not evade byte/count budgets or duplicate/cycle detection.
- Existing path roots, sibling bind coordinates, exact aliases, subtree aliases in both directions, casefolded modeled ancestry, missing-root rules, identity/statx masks, and acquisition counts remain covered.
- At least one actual root qualification/retained-route positive exercises the unchanged native mountinfo acquisition and representative originally failing paths. Existing no-result-mutation/no-fallback controls must remain effective. Use current private test seams; do not add a production bypass, alternate data-source environment flag, or exported testing API.
Derive expected outputs independently of production outputs. Retain malformed-path tests for path-valued roots; don't simply rename failures as opaque successes. Record where a model proves parser/classifier behavior versus a native ordinary filesystem exercising production acquisition. No synthetic snapshot is an actual mounted-alias proof.
Keep the 214-row inventory immutable as lineage. Produce a separately versioned successor inventory/overlay containing every new required parent and statically named child, all 44 original failing paths not already required, and all eight formerly missing control-plane golden children. Preserve package/source build selection on Darwin, Linux AMD64 and ARM64, and the admission/app-only race lane. No default platform inference, prefix-based applicability, or target pass count. Unknown applicability blocks. Source-backed exclusions are not passes.
5. Early Linux feedback, before the final freeze
This task explicitly adds a pre-freeze focused AMD64 development gate, so a Linux-only repair is not first exercised after another full Darwin cycle. It does not replace or relax the final local or AMD64→ARM64 sequence.
After doc/code/test edits, formatting/diff checks, offline Go metadata/prechecks, and focused local doc/guardrail checks, snapshot the exact development source into a fresh authenticated private archive. Read the existing test effect paths. Transfer only that snapshot and authenticated runner inputs to a fresh private task root on the governed AMD64 host. No local edits while its tests execute; never edit the extracted source.
Using the native environment below, run:
"$GOROOT/bin/go" test -json ./es/admission -run '^(TestLinuxMountInfo.*|TestLinuxExecutionRoot.*|TestQualifiedExecutionRootsAcceptSamePresentationSiblings|TestRetainTerminalResultPackagesResultDirectory|TestResultServesRetainedBundleWhenStagingRootIsAbsentWithoutRuntimeLookup|TestTrancheB2ControlPlaneNormalShellLiteralNomadJobAndAuthorityHandoff)$' -count=1
Confirm all named new controls and the required golden children actually execute. Native read-only acquisition may record safe counts/types of live non-path records without dumping unrelated mount metadata. Do not require four unchanged nsfs labels or create nsfs mounts to obtain coverage. Record absent live classes honestly; synthetic inputs remain synthetic.
This is development validation, bound to its exact snapshot, not the final complete suite. In-scope development corrections are allowed before final freeze with distinct retained inputs/results; no concealed retries and no unbounded search or host repair. Any unexplained host/source/asset mutation or broader defect stops. Close each development task scratch after authenticated evidence return. ARM64 stays uncontacted.
When development passes, freeze source, docs, tests, expanded inventory and both execution/evaluation recipes together. Produce complete source/candidate/per-member and incremental/complete diff identities. One deterministic new source archive is sufficient after exact member verification; reuse an identical authenticated development archive if all frozen member bytes/modes still match. Historical local passes are not credited to changed source. No repository or test-source changes after final freeze, including status edits in PLANS.md.
6. Complete local validation on frozen bytes
Reuse reviewed short-scratch and source-bound adjudication mechanics rather than building another generic runner. Preserve original helpers and record a narrowly versioned successor/delta. Retain raw exit/streams independently of analysis.
Local Go:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Authenticate the pinned Go/gofmt and existing module cache against retained records. Set process-only GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, GOTELEMETRY=off, and fresh external GOCACHE/GOTMPDIR with short execution paths. Preserve HOME, normal default TMPDIR, inherited umask, and existing endpoint choice. Do not require go env to echo requested GOENV/telemetry values; record request and effective observations distinctly. Do not silently disable local CGO.
Prechecks: exact version, selected go env -json, go mod verify, go list -m all, git diff --check, gofmt listing of changed Go paths, relevant unchanged shell syntax checks from existing recipe. Preserve 59-row module graph and go.mod/go.sum identity. Do not reformat unrelated paths.
Before app/full lanes, reuse the bounded read-only availability check against the already-selected local Docker socket. A newly reachable live stack requires stopping/reassessing effects, not exercising it accidentally, changing endpoints, or manufacturing unavailable skips.
Run sequentially, one invocation each, stopping subsequent lanes on genuine failure:
"$GO" test -json ./... -count=1
TMPDIR=/private/tmp "$GO" test -json ./... -count=1
CGO_ENABLED=1 TMPDIR=/private/tmp "$GO" test -json -race ./es/admission ./es/app -count=1
No default TMPDIR replacement. Check package/test terminals, all applicable required parents/children, nontruncation, and skip identities/causes. Linux build exclusions remain future requirements, not Darwin passes. Prior 2,332/37 and 810/36 counts are historical comparisons, not target counts. Actual environment-limited integration skips remain non-claims. A successful local phase automatically advances to section 7 under this prompt; no additional relay is needed.
7. Final native AMD64 then ARM64, on the SAME frozen archive
Use existing trusted transport, ordinary user identity, and the authenticated verification-only asset-manifest recipe. Do not execute retained install/probe orchestration. Fresh source/scratch roots, not Mac-mounted checkouts, are required.
Field	AMD64	ARM64
Target	SSH alias host_to_remote_linux_m75q	Lima es-lima-qemu-arm64
Host	ds-ThinkCentre-M75q-Gen-2	lima-es-lima-qemu-arm64
Architecture; user	x86_64/amd64; UID:GID 1000:1000	aarch64/arm64 QEMU; UID:GID 501:1000
Recorded OS/kernel	Ubuntu 24.04.4 LTS / 6.17.0-23-generic	Ubuntu 24.04.4 LTS / 6.8.0-124-generic
GOROOT	/home/ds/.local/share/execution-substrate/native-validation/go1.26.5-linux-amd64	/home/ds.guest/.local/share/execution-substrate/native-validation/go1.26.5-linux-arm64
GOMODCACHE	/home/ds/.cache/execution-substrate/native-validation/modcache-dac662ea3274	/home/ds.guest/.cache/execution-substrate/native-validation/modcache-dac662ea3274


Machine-ID SHA-256: AMD64 a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6; ARM64 36bcc652dc9e61ce61f7e19d839901c23db072c373355ac5f465226316171e6f.
Portable asset manifests: AMD64 Go 5288dc5d51a05d539f02b9fb2cf7978deb995116f0adde7e628172212bdcbefa; ARM64 Go 3dd575df51039882df33ad80ef464986474f7df69676109d186e8507423ce625; each module cache 38d54157c700b13347d114af010cb204124ca65da5eb69c43411dddd0ebb7b02. Recompute before/after accessible phases with exact retained semantics; do not infer current presence from old readiness.
Use the existing host-key-checked BatchMode transport; no agent forwarding/access changes. Record current host/boot identity, not a demand for an old boot UUID. Unexpected environment drift blocks rather than authorizing restoration.
Native child settings: the appropriate GOROOT/GOMODCACHE; new private GOCACHE/GOTMPDIR/TMPDIR; GOTOOLCHAIN=local GOENV=off GOWORK=off GOPROXY=off GOSUMDB=off GOFLAGS=-mod=readonly CGO_ENABLED=0 GOTELEMETRY=off; clear GOPRIVATE/GONOPROXY/GONOSUMDB as in the authenticated recipe; unset outer GOOS/GOARCH; prepend pinned Go bin only. Preserve HOME and ambient umask. Mode 0700/0600 evidence comes from explicit chmod/fchmod, not contaminating test umask. Record requested environment separately from Go output.
After source transfer and per-member authentication, capture argv/environment/times/stdout/stderr/exit for:
"$GOROOT/bin/go" version
"$GOROOT/bin/go" env -json GOOS GOARCH GOVERSION GOROOT GOMODCACHE GOCACHE GOTMPDIR GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS CGO_ENABLED GOPRIVATE GONOPROXY GONOSUMDB GOTELEMETRY
"$GOROOT/bin/go" mod verify
"$GOROOT/bin/go" list -m all
"$GOROOT/bin/go" list -json ./es/admission
"$GOROOT/bin/go" test -json ./es/admission -count=1
Derive applicability from each target's selected/ignored source metadata and declarations; preserve offline cross-target structural Go children without mislabeling them native execution. Require one complete final suite per architecture, exit zero, no failed/truncated/missing-required/skipped-required path, and explicit pass for the original 44 failures, eight missing children, and new applicable regressions. Keep all package/build exclusions with source reasons. No full native repository suite, native race addition, tracing, or actual mount construction.
ARM64 becomes eligible only after complete final AMD64 execution, adjudication, source/asset preservation, returned-evidence authentication, and safe scratch closeout pass. Before that, no Lima contact. When eligible, freshly verify the named instance is Stopped and config SHA-256 is 1579f5a94c7c159ab8441e26c679cde65fd3a054e68ea47165cbfddb5662ecd0; one normal start and one normal stop are authorized. Unexpected posture blocks; no force-stop, config/share repair, or new instance. Do not infer current Stopped posture from the previous task, which made no Lima observation.
8. Failure handling, preservation, and evidence packaging
Keep execution, acquisition, analysis, provenance, environment, packaging, and cleanup outcomes separate. Final-suite or candidate failure stops remaining final lanes; no post-freeze repo edit, filtered substitution, or suite rerun. Preserve all historical failures.
A demonstrably pure analysis/packaging defect may be corrected within this task in a separately frozen external version, with causal controls and replay of unchanged evidence. The previous returned-registry correction is already understood: group order is not global lexical order. Validate exact coverage, uniqueness, bytes and the producer's documented ordering without imposing a new convention. Do not reintroduce the GOENV/telemetry, umask, socket-path, platform-applicability, or registry-order defects. Analysis corrections cannot excuse changed bytes, substantive coverage loss, failed tests, contaminated execution, missing evidence, or unsafe cleanup.
Record all incremental repair bytes and exact source/runner/inventory version bindings, with two stable serializations at freeze and closing. Authenticate extracted source and persistent assets before/after each reachable native phase. Return and verify evidence before deleting scratch. Authenticate exact path/owner/mode/device/inode, absence of descendant mounts and process/cwd/FD use; remove only task-owned roots and observe absence twice. Retain uncertain scratch instead of force-cleaning. Preserve installed assets, production roots and every other task's state. Verify ARM64 stop/config after its evidence is returned and its guest checks complete. No PLANS.md edits after freeze.
Return one report, one compact ZIP, and one self-excluding file manifest. The ZIP MUST directly expose the latest cumulative repair source/doc/test files (all six execution_roots files included), incremental and cumulative recoverable diffs, source/candidate/member manifests, exact runner/evaluator sources and deltas, immutable/successor inventories and applicability, original streams/command/environment/exit records, required coverage, source/asset preservation, cleanup and explicit unexecuted records. Do not hide the only inspectable production source under a growing chain of nested historical ZIPs. Carry current source once; preserve historic evidence by exact authenticated references or a single necessary retained packet. The full new source tar may remain a separate identified handoff artifact.
Never include secrets, entire inherited environments, arbitrary mount tables or service configs/logs, TLS/SPIFFE/Vault/Codex material, databases, caches, distributions, VM disks, or test binaries. Synthetic mountinfo is safe fixture data and must be labeled synthetic; any safe native projection must not masquerade as unchanged raw acquisition.
Validate nonrecursive package/member safety, exact file coverage, sizes and hashes. Include the review ZIP in the next user-facing attachment return, not only its path/report/manifest. The manifest is not a substitute for source and execution bytes.
9. Final disposition and unresolved work
Success:
ES_CUST2_NSFS_GRAMMAR_REPAIRED_LOCAL_AND_NATIVE_VALIDATED_EXTERNAL_GATES_PENDING
Otherwise use a precise ES_CUST2_NSFS_REPAIR_BLOCKED_<CAUSE> disposition naming the last completed phase and every unexecuted lane. Do not erase passing observations when a later gate blocks; do not promote their scope.
Report exact touched files/classification, decision and grammar, invalid-input treatment, per-command results, applicability/skip causes, development vs final execution, archive/source/patch provenance, rejected attempts, analysis corrections, source/asset cleanup, assumptions, unresolved seams and uninspected areas. Separate provenance, validation and implementation confidence. This remains owner-produced engineering, not independent audit or acceptance.
External obligations remain unchanged:
- actual repaired-helper disjoint/exact/subtree/both-direction/applicable-casefold mounted cases (execution-definition gap still open; do not invent an owner/fixture or satisfy it with models);
- running-deployment compatibility observation, deferred until before acceptance/commit;
- bounded native supported-local consumer/operator proof owned by the actual current clauses, including the reported scripts/73_supported_local_proof.sh run gate; no execution or CP revival here;
- fresh independent audit, then separate exact-byte stage/commit authorization.
Preserve their source clauses and distinguish unavailable evidence from an undefined fixture recipe. Neither a successful parser fix nor native admission passes close those obligations. Stop after this repair/validation report without staging, commit, publication, service operation, final audit, or follow-on autonomous work outside this prompt.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
