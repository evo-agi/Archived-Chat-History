**Retain the design-review block. The next task is one bounded correction of T1–T3 and C1–C2, including the related source-sequence rule—not another deadline-model redesign or an implementation attempt.** The review supports the uniform cutoff, whole-file contract identity, and reservation direction; the remaining defects are in the proposed contract’s connection to actual effects, authority ingress, and receiver processing. :chatgpt-content-reference{index="0"}

**Send this to the original design/preparation Codex conversation: :chatgpt-content-reference{index="14"}[Temporal effect-map and receiver-boundary correction prompt](sandbox:/mnt/data/ES_Temporal_Map_Completion/ES_Temporal_T1_T3_C1_C2_Design_Correction_Prompt.md).**

This handoff authorizes external document/map correction and inert-data checks only. The accepted helper, ES candidate, and historical evidence remain unchanged.

## Preserve the design decisions that survived review

The review found no missing essential input or provenance mismatch. Its structural checks also reproduced all 432 source anchors—but correctly distinguished that from proving the map selected the right source locations or covered every relevant operation. **Correctly hashing a range does not establish that the range contains the effect attributed to it.** :chatgpt-content-reference{index="1"}

The following remain the selected direction: one original D; successful completion strictly before S=D−8 seconds; action-adjacent checks without claiming atomic dispatch; a narrowly inherited one-close duty; independently derived observation predicates; and custodian-enforced collision reservation. The review does not require replacing those choices. :chatgpt-content-reference{index="2"}

The correction should therefore fix the actual map and contract gaps, not increase the inventory merely to produce a larger count.

## 1. Keep worker emergency KILL distinct from parent teardown

**I am selecting preservation of the existing case-local emergency KILL behavior, rather than redesigning those branches to require the external parent’s TERM/grace sequence.**

The review identifies immediate worker-owned KILL after specified start-identity or pidfd-acquisition failures and process-ceiling violations. The current map incorrectly assigns those operations the R5 parent rule, which requires a returned TERM request and three-second grace before KILL. At an early case failure, that either prohibits the existing emergency action or silently treats the worker as the administrative parent. This is a proposed migration conflict, not a newly established defect in the accepted implementation. :chatgpt-content-reference{index="3"}

The corrected map must distinguish normal case stopping, case-local emergency stopping, and external-parent teardown. Each needs its actual actor, exact subject, original authority, applicable phase bound, and dispatch check.

Preserving emergency KILL does **not** mean permitting arbitrary immediate KILL. Only the existing source-selected branches qualify. Missing trustworthy targeting facts still require refusal; an old numeric PID is not a substitute. Revocation, expiry, and fallback checks remain intact, and the parent’s later D-bound authority cannot extend an expired worker authority.

The result must also remain truthful: a signal request or leader reap does not establish group absence, and an emergency stop cannot turn its triggering failure into successful proof. The review explicitly requires worker effects to remain attributed to the worker in the observation record. :chatgpt-content-reference{index="4"}

## 2. Complete failure-closeout and release ownership together

T2 and T3 should use one source-derived inventory, while retaining separate findings.

**T2 concerns omitted effects on the failure path.** E48 lists failure-file operations but omits the failure directory’s mode and synchronization operations, parent synchronization, and several subsequent handle releases. E49 describes a different fallback and cannot stand in for them. :chatgpt-content-reference{index="5"}

The correction must map each deliberate failure-retention effect separately. A file write completed before D does not authorize a directory synchronization after D. A qualifying close after D may discharge its existing owner, but it cannot repair the missed synchronization or restore success.

**T3 concerns owners omitted from the supposedly finite close list.** The report identifies formatter execution-closure files and scratch parent/root/inventory handles. It also identifies a false anchor: E09.04 describes an image close using a range that actually opens, truncates, and synchronizes; the release occurs elsewhere. :chatgpt-content-reference{index="6"}

Each corrected owner row must identify acquisition, ownership or transfer, invalidation, the actual primitive close, and propagation of release uncertainty. Compound callbacks do not gain blanket post-deadline permission because their names contain `close`.

This is a bounded walk of the affected callers, error paths, and release consumers—not a request to instrument every runtime syscall or build another custody framework.

## 3. Give the receiver one explicit combined budget

C1 needs an actual policy decision. The proposed parent body has a 16 MiB limit, the existing carrier/graph reconstruction has another 16 MiB limit, and the public receiver currently copies caller-supplied confirmation bytes before a length guard on that path. The draft never chooses a combined boundary. :chatgpt-content-reference{index="7"}

**For the corrected successor design, I am selecting:**

| Input domain | Maximum admitted raw bytes |
|---|---:|
| Existing receipt carrier and held producer graph | 16 MiB |
| One parent-observation body | 16 MiB |
| Raw confirmation input | 64 KiB |
| **All three combined** | **32 MiB, inclusive** |

All limits apply simultaneously. Two full 16 MiB domains plus a nonempty confirmation therefore exceed the combined cap and must refuse.

This is an **explicit new-profile increase in the combined evidence allowance**, not a change to the old graph’s individual limit and not live risk adoption. The previous contract did not establish this number; it is the design choice supplied by this handoff.

The correction must place confirmation admission before receiver-owned copying, string conversion, decoding, or verifier invocation. It must also account for actual held reads, checked arithmetic, exact-byte cache reuse, and bounded oversize detection—not trust declared lengths.

**A raw-byte cap is not a process-memory guarantee.** The design must additionally specify finite nesting, token/string and array cardinality, decoded-object lifetime, and semantic traversal bounds derived from the actual schemas. It must identify the complete processing boundary rather than permit an unbounded qualification reference or second reconstruction path.

No cgroup, quota, worker service, or new resource-management subsystem is selected. These are receiver contract and future implementation requirements.

### Resolve source-sequence projection in the same correction

The review also found that “gapless source sequence” does not say whether all covered source records must appear in the body or a relevance filter may omit some. Renumbering the body’s global sequence and reporting zero loss cannot resolve that ambiguity. :chatgpt-content-reference{index="8"}

**I am selecting complete inclusion for each designated finite episode source stream:** every source record within a claimed covered sequence interval must appear exactly once as its typed outside event. This version admits no optional relevance filter or evidence-selected omission.

The corrected corpus must bind the actual source instance, reconcile interval overlaps and sequence membership, reject hidden resets or missing records, and keep producer-origin events from filling outside-observation gaps.

This does not mean collecting every event on the host. The independently qualified stream must have a defined episode scope and event vocabulary. If it cannot provide that finite complete stream within the bounds, qualification remains unavailable; the receiver must not truncate or silently downsample it. No feed technology is selected or deployed here.

## 4. Map authority ingress and every affected assurance caller

C2 is more consequential than a missing filename in a checklist. The map omits `authority_linux.go`, where the actual v3 entry request is constructed and strict ingress occurs. A migration that changes downstream records without changing this producer/parser could retain a v3 run path or accidentally alter import-v3’s canonical bytes. :chatgpt-content-reference{index="9"}

The correction must trace:

> Independent approval → phase-specific encoding and ingress → immutable owner → outcome and receipt → observation and confirmation → public receiver.

It must add the actual constructor/parser and affected tests, including old hard-deadline assumptions, cutoff fixtures, and direct receiver callers in the empty-log, namespace-custody, and namespace-receiver tests. Existing old-family tests may remain as historical-contract tests; successor tests must be explicitly identified. Blindly replacing field names would not establish the migration.

One related ordering detail must survive: the producer’s normal and diagnostic records are interleaved, while the new observation body has canonical normal-then-diagnostic order. **Reconcile by exact case identity and digest; do not reorder the producer ledger to make the arrays look alike.** :chatgpt-content-reference{index="10"}

## Change the next task’s preservation method

The fresh-parent separation was satisfied this time. The initial unguarded status query was not. Later matching captures cannot retroactively make that first query guarded. The report preserves both facts. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

**For this document-only correction, I am removing Git subprocesses from the authorized work entirely.** Codex will use the authenticated helper archive for exact implementation evidence and plain-file reads for current governing guidance. It will fingerprint the original files actually consumed and preserve the prior complete repository captures as history.

That deliberately narrows the preservation claim: the next task must not claim a fresh full ref/index/worktree comparison it did not perform. It avoids repeating the same procedural departure merely to obtain another repository snapshot for a task that changes no repository.

This does not require repeating the rejected review. Its concrete findings remain actionable.

## What completion should mean

The next deliverable is one corrected normative file, the complete updated migration map, individual responses to T1–T3/C1–C2, and source-backed design checks. Original files remain immutable history, but erroneous **active rows in the new map must actually change**; appending a contradictory rule while preserving the old active one is not a correction.

The intended owner endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_T1_T3_C1_C2_CORRECTED_CONTRACT_MAP_READY_FOR_FRESH_REVIEW
```

It leads to a fresh separate-parent design review, then separately authorized coupled implementation. It does not authorize the entry foundation, target qualification, reservation enforcement, or live adoption.

The report’s modeled successful timeline remains an inert example with simplified payloads—not a receiver execution or qualified observation feed. The next design checks must retain that evidence classification. :chatgpt-content-reference{index="13"}

Remote recovery remains unresolved. The accepted helper’s old scoped closure, original operational failures, and pending whole-candidate ES audit and exact-byte publication gates are not changed by this design work.

### Sources, inspection boundary, and confidence

I read the complete attached review and the preceding correction/review prompts. The attachment is **19,189 bytes**, with computed SHA-256:

```text
15784c7617cee81a49f52ee60e16f52da4130000f08ab68fa3283f1d75084572
```

The latest review ZIP, full migration map, specialist originals, and accepted implementation were not inspected here. Their detailed authentication and source findings remain **independent-reviewer-reported**. The handoff directs Codex to those retained inputs before authoring.

**Sources:** attached independent review, proposed temporal corpus, and preceding correction/review handoffs. No repository commands, reviewed code, tests, hosts, or cleanup were executed here.

**Confidence: 0.97 in retaining the migration block; 0.92 in this bounded correction direction.** Attachment identity is verified. Corrected-contract coherence, implementation readiness, operational consent, and privileged readiness remain unestablished.
