## Retain the block; complete the architecture before implementation

The rejection is correct. The previous owner selected the desired components, but Stage C and D would still have needed to invent authority, process, identity, protocol, and durability semantics during implementation.

I consolidated all six blockers into one governed **R9.24** correction rather than another partial topology patch.

### ES_R6J_R924_OUTSIDE_OBSERVER_CLOSURE_REPAIR_HANDOFF_20261026_01.zip[Download the self-contained R9.24 repair handoff](sandbox:/mnt/data/ES_R6J_R924_OUTSIDE_OBSERVER_CLOSURE_REPAIR_HANDOFF_20261026_01.zip)

:chatgpt-content-reference{index="5"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_R924_OUTSIDE_OBSERVER_CLOSURE_REPAIR_HANDOFF_20261026_01_VERIFICATION.json)

```text
Bytes:             13,250,772
Members:           41
Manifest payloads: 40
SHA-256:           e75fb7877d7e056bb1a184098ca639b4cb86c28f51f2be8942589c51e6a3f477
Verification:      PASS
```

The package embeds:

- the exact blocked R9.23 owner;
- the complete fresh blocked review;
- the **exact original repair-handoff ZIP** that the owner incorrectly claimed to embed;
- the frozen R9.24 decisions;
- complete owner instructions and control requirements.

No other attachment is needed.

## Architecture selected in the handoff

### 1. Concrete Nomad and PID-1 topology

The target is now one exact Nomad Docker task:

- exactly one main task and no lifecycle sidecars;
- Docker driver;
- `es/outsideobserver` is the direct container entrypoint;
- Docker `init=false`, so no `tini` process replaces it as PID 1;
- host PID mode is forbidden;
- no shell or intermediate wrapper;
- private PID namespace;
- no network;
- immutable image digest;
- explicit user, group, mount, capability, and PID-limit posture.

Nomad’s Docker driver supports an explicit entrypoint and an `init` switch; enabling `init` inserts a separate init process as PID 1, so the target fixes it off. The driver also supports isolated task containers and volume mounts. [HashiCorp Developer](https://developer.hashicorp.com/nomad/docs/job-declare/task-driver/docker?utm_source=chatgpt.com)

### 2. Descendant-complete process safety

Outsideobserver is the sole Wait/reap owner for one direct runtimehelper supervisor. The new state machine specifies:

- direct fork/exec without a shell;
- frozen PID/start/namespace/pidfd identity;
- exactly-once supervisor reap;
- separate reaping of reparented descendants;
- process-group termination as the first action;
- complete `/proc` namespace sweep as the final containment boundary;
- no terminal success until only PID 1 remains and no child is waitable;
- no double Wait;
- explicit already-exited-child, evidence-failure, observer-death, and transport-loss paths.

Linux makes PID 1 the orphan reaper inside its PID namespace, and if the namespace’s PID 1 terminates, the kernel kills the remaining processes in that namespace. [man7.org](https://www.man7.org/linux/man-pages/man7/pid_namespaces.7.html?utm_source=chatgpt.com)

### 3. One authoritative permit-consumption ledger

`OutsideObservationPermitV1` no longer authorizes launching runtimehelper. Existing RunEntry execution authority remains the launch authority; P authorizes observation, Wait, and evidence emission only.

The sole durable consumption owner is the **existing RunEntry issuer**:

```text
ISSUED
  -- atomic CompareAndConsumeOutsideObservationPermitV1 -->
CONSUMED
```

The key is:

```text
issuer_id
key_id
run_id
single_use_nonce
```

The issuer returns a signed, session-bound consumption receipt. Receiver mediates the call but does not become authority. Observer launches only after verifying the receipt and the existing execution authority.

There is no rollback after consumption. Crash, timeout, duplicate consume, or lost response cannot permit reuse; a new attempt requires a new run and permit.

### 4. Exact SPIFFE and endpoint model

The target trust domain and workload IDs are now explicit:

```text
spiffe://governed-execution.local/es/r6j/outsideobserver
spiffe://governed-execution.local/es/r6j/receiver
```

The architecture fixes:

- observer Docker-label, image-config-digest, and UID selectors;
- receiver systemd-unit, UID, binary-path, and binary-digest selectors;
- dedicated host receiver service;
- each process calling the Workload API for its own X.509-SVID;
- no Delegated Identity API;
- same-trust-domain-only operation;
- in-memory private keys;
- rotation, expiry, withdrawal, and prelaunch failure behavior.

SPIRE registration entries bind a SPIFFE ID to selectors and a parent ID. Its Docker attestor supports label and image-config-digest selectors; Unix and systemd attestors provide UID/path/hash and unit selectors. Workloads obtain short-lived X.509-SVIDs and trust bundles through the Workload API. [Spiffe](https://spiffe.io/docs/latest/deploying/registering/?utm_source=chatgpt.com)

The receiver exclusively owns endpoint creation:

```text
/run/governed-execution/r6j/<run_id>.<endpoint_nonce>/receiver.sock
```

The handoff freezes creation, ownership, modes, bind/listen order, bind mounting, no-symlink checks, inode verification, cleanup, crash scavenging, and nonreuse. Path possession remains explicitly non-authenticating.

### 5. Closed wire protocol

The private protocol now has exact message schemas:

- `ObserverHelloV1`
- `ReceiverHelloV1`
- `PermitConsumptionReceiptV1`
- `EvidenceFrameV1`
- `AckV1`

It freezes:

- canonical JSON rules;
- version and unknown-field behavior;
- concrete frame and aggregate limits;
- big-endian length framing;
- initial sequence and previous-hash value;
- payload and record hash domains;
- exact replay, gap, duplicate, reordering, and digest refusals;
- no compression.

### 6. Durable journal and crash matrix

The receiver journal is explicitly transactional:

```text
validate
→ append exact frame
→ fdatasync journal
→ write/fsync next state file
→ atomic rename
→ fsync source directory
→ publish commit ID
→ send ACK
```

The design now distinguishes:

- uncommitted tail;
- durable committed record;
- ACK loss;
- receiver crash;
- source incomplete;
- source complete;
- orphaned committed evidence;
- observer death;
- final-ACK uncertainty.

No reconnect, session resume, or cross-run adoption exists in version 1.

### 7. Safe A–E staging

The stages now have explicit state owners:

- **A:** contracts, schemas, and static tests only.
- **B:** pure libraries and in-memory fakes only.
- **C:** isolated Linux integration with test issuer/SPIRE/receiver state.
- **D:** disabled end-to-end integration only.
- **E:** sole production-enablement gate.

Stages A–D may not create a production job, live endpoint, live issuer consume, production SPIRE registration, or production evidence intake.

### 8. Complete control expansion

The handoff requires controls for every review gap, including:

- exact archive lineage;
- wrong driver/init/PID mode/entrypoint;
- descendant group/session escape;
- Wait and pidfd races;
- atomic consume races and crash points;
- SPIFFE selector, rotation, and Workload API failures;
- endpoint symlink/stale/reuse attacks;
- protocol versions, unknown fields, caps, hash chain, and replay;
- journal crash points and lost ACK;
- premature Stage A–D production wiring.

## Message to send

Open a **fresh ChatGPT artifact-design owner conversation**—not the reviewer conversation and not Codex. Attach the single handoff ZIP and send:

```text
Continue as the artifact-only design owner for the R9.24 outside-observer
closure correction.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md,
analysis/CORRECTION_MATRIX.json, every other analysis record,
external/PRIMARY_SOURCE_NOTES.md,
receiving/RECEIVING_INSPECTION.md, the complete blocked review, and
NEXT_OWNER_TASK.md before authoring.

Authenticate the embedded blocked R9.23 owner, blocked review, and the exact
original repair handoff. The prior package defect must be closed with the
actual handoff bytes—not excerpts or an authentication claim.

Preserve all accepted R9.21 reference bytes and the reviewed R9.22
ownership split. Preserve R9.23 as immutable predecessor history.

Author the complete R9.24 successor under:

R6J-ES-NATIVE-OUTSIDE-P-CLOSURE/v1

Implement every frozen design record in the handoff:

- exact Nomad Docker task, entrypoint, PID1 and namespace contract;
- direct-child and sole Wait/reap state machine;
- namespace-wide descendant drain and failure teardown;
- existing-issuer-owned atomic permit consumption and signed receipt;
- observation-only P authority, separate from execution authority;
- exact SPIFFE identities, registration selectors, Workload API and
  rotation rules;
- receiver-owned endpoint lifecycle;
- closed handshake, frame and ACK schemas, bounds and hash domains;
- receiver journal transaction, source states and complete crash/lost-ACK
  matrix;
- independently safe A-E stages;
- the complete required control matrix.

Do not leave an authority owner, mutable state transition, topology choice,
protocol field, bound, crash outcome or stage boundary for implementation
to invent.

Generate the full R9.24 contract and migration map, unchanged framed-pair
algorithm, noncircular pair/package/governance chain, four rebound modeled
profiles, and all 429 active-map records.

Keep all implementation, repository-adoption, production-wiring, authority-
issuance, credential-qualification, runtime and independent-acceptance
flags false.

Save and reopen a substantive checkpoint before broad control expansion.
Then run the final inert finite suite twice, preserve exact results, and
produce both checked-before reconstruction routes and final-owner guards.

Do not launch Codex, access repositories or hosts, execute uploaded
programs, implement source, issue credentials, adopt the proposal or claim
live qualification.

Return actual downloadable artifacts only under:

OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_COMPLETED_READY_FOR_FRESH_REVIEW
```

## Sequence after the correction

```text
R9.24 corrected owner
→ different fresh architecture review
→ repository-adoption decision
→ authenticated clean/stable baseline
→ Stage A contracts/docs/schema/tests only
```

Codex remains premature.

**Sources:** the uploaded blocked topology review and exact R9.23 owner; official Nomad, Linux PID-namespace, and SPIFFE/SPIRE documentation cited above.  
**Confidence:** **0.999** in the review findings and handoff identities; **0.96** in the selected R9.24 topology, authority, protocol, and durability closure. Independent architectural acceptance remains pending.
