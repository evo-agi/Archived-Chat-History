**Proceed to a fresh, separate-parent design review of this exact contract and migration map. Do not begin implementation yet.** The correction now states concrete rules for the six disputed areas; independent review must establish that those rules agree with one another and can direct the coupled migration. The contract itself remains explicitly proposed and unapproved. :chatgpt-content-reference{index="0"}

**Send this to a new Codex review conversation—not the design/correction conversation: :chatgpt-content-reference{index="16"}[Corrected B1–B6 contract and migration review prompt](sandbox:/mnt/data/ES_Temporal_B1_B6_Fresh_Review/ES_Temporal_B1_B6_Corrected_Design_Independent_Review_Prompt.md).**

The handoff authorizes source and document inspection, independent data checks, and a design verdict. It authorizes no repairs, builds, tests, host contact, reservations, cleanup, or live adoption.

## What the correction makes concrete

The attached normative file addresses the decisions requested in the preceding handoff:

| Finding | Rule now stated in the proposed corpus |
|---|---|
| **B1 — competing deadlines** | Successful work and required terminal observations finish strictly before **S = D−8 seconds**. The remaining interval is for an already nonpassing episode’s still-authorized stopping and failure handling. |
| **B2 — one-close discharge** | An acquired, genuinely owned handle retains one narrowly defined release attempt. Compound cleanup, writes, synchronization, signals, retries, and reacquisition do not inherit that exception. |
| **B3 — compound effects** | Each deliberate implementation-controlled dispatch needs its own adjacent check. Qualified library primitives must have their actual boundary, internal effects, retries, and failure consequences identified. |
| **B4 — contract identity** | One complete normative file, hashed as raw bytes, defines the temporal profile. The independently approved digest cannot be replaced by agreement among episode-supplied claims. |
| **B5 — independent observation** | Confirmation binds one bounded observation body; the receiver derives the required predicates from its records rather than accepting favorable flags alone. |
| **B6 — dynamic collisions** | An independent custodian enforces exclusion over the relevant target loop-allocation domain before selection, expands the reservation with acquired identities, and separately authorizes release or noninterference. |

Those are **proposed rules, not independently closed findings or installed capabilities**. The relevant timing and close rules are explicit in R4–R5; dispatch, corpus, observation, and reservation rules are likewise now substantive rather than placeholders. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

The most useful next review is therefore not “are B1–B6 mentioned?” It is **whether the actual migration can preserve these relationships across producers, authority records, effects, evidence, and the receiver**.

## The main scrutiny belongs on the observation contract

R6 is now much more precise. It defines bounded coverage intervals, event kinds, source origins, sequence and loss information, case references, terminal records, and the relationships from which the receiver must derive its conclusions. It also distinguishes authenticated producer claims from outside observations. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

**My principal review question is whether that precision establishes a feasible finite observation contract—or moves the former unspecified guarantee into the word “qualified.”**

The corpus requires coverage of **every instant**, with no gap, from before the first run effect through the terminal record. Direct-parent coverage requires a separately qualified sequence/gap/pause mechanism; ordinary polling cannot assert unobserved continuity. That is materially stronger than simply collecting start and end observations. :chatgpt-content-reference{index="6"}

The reviewer must therefore establish a coherent positive under the specified premises and distinguish two different situations:

**An adequately defined observation interface awaiting implementation and target qualification** can be a legitimate future prerequisite.

**An undefined or unsatisfiable monitoring obligation hidden behind a qualification label** is still a present design problem.

The prompt does not permit silently weakening continuous coverage to point-in-time checks. Equally, it does not demand deployment of a feed, tracing system, or new service during design review. The reviewer must assess the meaning and feasibility of the stated prerequisite, not invent an operational solution to make the verdict pass.

### The terminal-record distinction is worth preserving

The correction expressly allows the complete JSON observation body and its authentication to be assembled later from protected source records fixed before S. Its `retained_at` field does not claim that a body containing itself was already written. That avoids requiring a record to prove its own future persistence. :chatgpt-content-reference{index="7"}

The review must trace that distinction through the proposed receiver. Later assembly may package and authenticate existing timely observations; it cannot supply a missing pre-S observation, enlarge the covered interval, or rescue late completion.

The new observation body also has a 16 MiB ceiling. Its acquisition, parsing, and semantic work need an explicit relationship to the helper graph’s existing limits. The reviewer should determine from the map whether it is a separately bounded input or part of an existing budget—and verify the resulting combined bound. **I have not inspected the map, so I am not asserting that this accounting is defective.** The body’s individual cap alone does not answer that integration question. :chatgpt-content-reference{index="8"}

## The map must connect rules to actual callers

The reported **50 source families, 178 steps, and 189 author checks** are useful inventory and author-validation results. They do not establish that every relevant caller is covered or that the predicates are mutually satisfiable.

The independent review must derive the important transitions from the accepted source, then compare them with the corrected map. Particular attention belongs on create→write, write→sync→close, publication→directory synchronization, worker/candidate preparation, and signal fallback. A row for `Controller.apply` cannot substitute for checks inside a compound operation. The proposed corpus correctly distinguishes a permitted non-atomic check-to-one-dispatch interval from a second deliberate operation that lacks a fresh valid check. :chatgpt-content-reference{index="9"}

The **one-close exception** needs equally concrete treatment. The corpus explicitly excludes whole routines such as `workerClient.close`, `forceClose`, and `writeFinalizationPayload` from blanket admission under that exception. The reviewer must inspect their components and ownership transfers; a method’s name cannot establish its effect boundary. :chatgpt-content-reference{index="10"}

The version migration remains coupled. Run-only v4 records, outcome-v4, receipt-v4, expectations-v3, and confirmation-v4 must agree on the new claim, while import-v3’s canonical bytes remain unchanged. Mixed families, old hard-containment aliases, and automatic conversions are prohibited by the draft. Those requirements need validation against the actual types, encoders, parsers, and templates—not only the version table. :chatgpt-content-reference{index="11"}

## Keep reservation enforcement separate from proof acceptance

R7 now identifies the previously missing preselection collision domain and prohibits automatic release at S, D, process exit, receipt production, or parent loss. It also distinguishes a known-returned selection with an independently approved possible-unbound residual from a request whose outcome remains unknown. :chatgpt-content-reference{index="12"}

The reviewer must check that these rules remain consistent with successful proof. A completed proof may support a custodian’s later release decision; it is not itself release authority. Conversely, a reservation awaiting that independent decision should not be confused with an unresolved kernel request when the contract treats them differently.

**No actual reservation or residual-policy consent is issued here.** The draft itself says the custodian, enforcement, target consent, and evidence sources remain to be established. Existing remote scratch and observer uncertainty are outside this new reservation; it does not retroactively adopt or resolve them. :chatgpt-content-reference{index="13"}

## The next gate stays finite

The review prompt uses a fresh parent with two complementary read-only specialists and requires individual B1–B6 judgments, complete R1–R8 coverage, concrete positive/refusal timelines, and source-to-map verification. It also requires inspection of the guarded preservation procedure **before any Git subprocess**. The prior same-parent review and unguarded query remain disclosed history, not a pattern to repeat. :chatgpt-content-reference{index="14"}

A satisfactory endpoint may be:

```text
ES_MOUNTED_HELPER_TEMPORAL_B1_B6_DESIGN_REVIEW_SATISFIED_IMPLEMENTATION_AND_LIVE_ADOPTION_PENDING
```

That would support separately authorizing the coupled external migration. It would not authorize the entry foundation, target effects, policy adoption, or mounted execution. The normative file preserves that sequencing explicitly. :chatgpt-content-reference{index="15"}

## Inspection boundary and confidence

I read the complete attached normative contract and the preceding B1–B6 correction prompt. The attachment matches the supplied identity exactly:

```text
36,197 bytes
SHA-256 ba36d3e70065aea6a04e04efbff5888b9561184f79a3be12899f5e441feab614
```

Its UTF-8 encoding, absence of BOM and CR, and exactly one final LF also match its declared representation.

The **634,434-byte migration map, correction report, review ZIP, author-check records, and failed-attempt records were not attached here**. Their identities and results remain owner-reported. The new prompt supplies their exact retained paths and supplied anchors for independent inspection. No repository commands, reviewed code, tests, host actions, or cleanup were executed here.

**Sources:** attached `TEMPORAL_CONTRACT.md`, preceding blocked temporal review, prior correction handoff, and your relayed completion report. **Confidence: 0.96 in proceeding to fresh design review.** Contract-byte provenance is verified; full design coherence, migration completeness, operational consent, and privileged readiness remain unestablished.
