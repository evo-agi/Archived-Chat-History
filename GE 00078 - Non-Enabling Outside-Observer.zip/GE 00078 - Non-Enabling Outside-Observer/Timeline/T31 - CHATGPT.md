**The block is justified. Do not run the v1 fixture as root, and do not reset the validated ES candidate.** The audit identifies concrete defects in the **external proof tooling**, including two independently blocking failures: inaccessible test paths and a possible leaked loop association accompanied by a false `clean` result. :chatgpt-content-reference{index="0"}

**Send this to the original implementation/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="21"}[Mounted-proof v2 repair prompt](sandbox:/mnt/data/ES_Mounted_Proof_V2_Repair/ES_Mounted_Proof_V2_Repair_Prompt.md).**

The next task implements and checks one coherent successor outside the repository. It authorizes **no host contact, root execution, mounts, service operations, or ES-suite reruns**.

## What this audit changes—and what it does not

The report contains **sixteen findings: two Critical, eight High, and six Medium**. They include proven defects, missing safety evidence, inadequate test oracles, and a documentation overclaim. They are not sixteen newly discovered ES product defects. The auditor expressly reports no new substantive product defect on the reviewed root-classifier path, while limiting that conclusion to the inspected scope. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The earlier preparation claim that the fixture was “fully defined” was too strong. Compilation and shell syntax checks had not established executable permissions, resource ownership through failure, or sound result adjudication. The independent review was therefore necessary before introducing privileged effects. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

The completed local and ordinary native validation remains evidence for the unchanged ES bytes. This audit does not invalidate those observations; it blocks the proposed additional mounted-proof execution. The audit authenticated the retained source and validation identities and matched the 358-file source and 83-path candidate. :chatgpt-content-reference{index="5"}

One provenance qualification should survive: the report discloses app-owned `refs/codex/turn-diffs/...` **name churn**, with the same referenced object and unchanged meaningful branch/source identity. That is not full-ref byte equality, and it must not become a blanket exemption for future ref changes. The handoff preserves that distinction. :chatgpt-content-reference{index="6"}

## Repair the ownership model, not just individual shell lines

**My selected direction is a narrowly scoped compiled lifecycle owner for v2, with an explicit setup-worker-candidate split.** This is a change to the external fixture implementation—not to ES architecture, standing policy, or the supported topology contract.

The reason is the combination of failures. Permissions can be repaired locally, but loop acquisition, interrupted bookkeeping, child termination, cleanup, and evidence export are interdependent. Adding more shell traps without a clear owner for the underlying resources would leave the central problem unresolved. The audit traces those interactions through both acquisition windows and partial-failure cleanup. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

The handoff groups the work as follows, while preserving a separate closure row for every finding:

| Repair group | Findings | Required outcome |
|---|---|---|
| Permissions and privileged input handling | F-1, F-3, F-4, F-5, F-9, F-10 | Reachable test paths, protected control data, authenticated inputs, controlled execution context, and fully observed child privileges. |
| Resource ownership and failure recovery | F-2, F-6, F-7, F-11, F-15, F-16 | No unowned acquisition window, supervised child lifetimes, identity-bound cleanup, enforced limits, and honest residual-state reporting. |
| Case results and proof adequacy | F-8, F-12, F-13, F-14 | Required events actually checked, meaningful refusal evidence, independently specified fixtures, and accurate production-reachability labels. |

These groups follow the audit’s findings; the supervisor arrangement is the new engineering decision for addressing them together. :chatgpt-content-reference{index="9"}

The proposed supervisor owns authenticated inputs, image/loop custody, the namespace-worker lifetime, deadlines, and final closeout. The namespace worker owns mount construction and in-namespace cleanup. The candidate runs separately without privileged control descriptors. The adjudicator checks evidence but cannot confer cleanup authority or declare resources absent.

This must remain **one finite, one-shot fixture**: the selected host, eleven cases, one image, one loop association, and the bounded mount inventory. No generic privileged service, arbitrary command runner, new deployment platform, or routine user-approval machinery is being introduced.

### Fix access without exposing control data

F-1 is not solved by changing the binary’s executable bit. The report identifies both root-only base ancestry and root-only intermediate directories created under `umask 077`. Either can prevent the unprivileged process from reaching the intended code or fixture. :chatgpt-content-reference{index="10"}

The successor must explicitly distinguish **traversable, root-owned test ancestry** from **root-private control, ledger, image, and evidence paths**. Every component needs an owner/mode/access specification. Blanket recursive permission changes are not authorized, and pre-existing directories must not be silently normalized.

### Fix the acquisition window—not just its log

F-2 is the most serious cleanup defect: acquiring the loop association before recording it creates a state in which the resource exists but cleanup’s record is empty. The current cleanup can then remove the image pathname and report success without establishing that the association disappeared. :chatgpt-content-reference{index="11"}

The prompt requires a pending acquisition state before the effect, continuous held-object custody, and successful residual inventories before deletion or a clean declaration. It selects `LOOP_CONFIGURE` as the preferred bounded mechanism for associating the image and setting supported autoclear flags together, rather than treating separate association and flag-setting operations as atomic. Upstream Linux provides that configuration interface and implements autoclear through last-reference release. This corroborates the mechanism, **not the named host’s current capability or the correctness of the future helper**. :chatgpt-content-reference{index="12"}

Two cautions remain essential: an available loop number is not exclusive ownership, and a successful detach command is not necessarily completed destruction. The pinned util-linux documentation explicitly describes both the unlocked selection behavior and deferred destruction semantics. :chatgpt-content-reference{index="13"}

Accordingly, **“autoclear enabled” cannot replace a cleanup observation**. Nor should Codex invent a kernel “association generation” field to satisfy F-7. The ownership argument must use actual interfaces, fresh backing-file identity, continuously held custody, and explicit limits on conflicting privileged actors.

## Tighten the proof without changing production behavior

Three evidence corrections deserve particular attention.

**First, eleven zero exits are insufficient.** The launcher currently does not enforce the machine-readable events that its recipe claims are required. The successor must reject missing, duplicated, malformed, truncated, wrong-case, incomplete, or failed events independently of the child’s exit code. It must also keep case outcome, process outcome, cleanup outcome, and export outcome separate. :chatgpt-content-reference{index="14"}

**Second, F-12’s disagreement must remain visible.** One specialist regarded the frozen source’s control order as support for the intended topology refusal; the parent still found that a generic `codeResultUnavailable` observation did not independently distinguish it from other failures. Both positions are recorded. :chatgpt-content-reference{index="15"}

The repair should provide a discriminating observation without modifying public errors, inserting production hooks, or bypassing the real implementation. The prompt permits separately identified compiler instrumentation where necessary. If the distinction cannot be established within the external-only scope, that specific finding remains unresolved; a prior direct qualification call must not be mislabeled as proof of the later public call’s cause.

**Third, fix the coverage label rather than manufacturing production wiring.** `Service.reconcileRetainedResultArtifacts` has no non-test production caller in the audited source. Its coverage should be described as **direct package-local helper coverage**. There is no reason to wire a new production caller merely to rescue the preparation report’s wording. :chatgpt-content-reference{index="16"}

The independently specified sentinel values required by F-13 also belong in the fixed case manifest. Comparing a tree with itself before and after is insufficient when the initial tree could already be missing the intended sentinel. :chatgpt-content-reference{index="17"}

## What the next task actually executes

The prompt authorizes one external implementation pass, preceded by a concrete owner/state/effect table. It does **not** require another general design-only round.

Before returning for independent review, Codex must run ordinary-user controls against the actual external controller and adjudicator. Those controls cover malformed evidence, source/destination substitution, inaccessible permission layouts, successful acquisition followed by failed bookkeeping, partial setup, child termination, observation errors, resource reuse, and simultaneous primary/cleanup failures.

The lifecycle controls use substituted effect adapters. **They establish controller behavior—not real mount, privilege-transition, or kernel cleanup behavior.** The Linux supervisor and updated source-bound proof driver are compiled but not executed.

All 358 original source members remain unchanged in the disposable proof source union. The repaired driver and supervisor receive new identities; the old binary does not become valid for a changed driver. The existing ES source archive, candidate manifest, required-test inventory, and successful local/native streams remain untouched.

The next successful disposition should be:

```text
ES_MOUNTED_HELPER_V2_REPAIRED_PREEXECUTION_REAUDIT_REQUIRED
```

It should not claim mounted validation, root authorization, final-audit readiness, or commit readiness.

After that, a fresh independent review examines the actual replacement artifacts. **Only a suitable reviewed successor can proceed to a separately bounded root-execution decision.** The running-deployment observation, supported-local consumer/operator proof, whole-candidate audit, and exact-byte commit gate remain separate outstanding obligations; this repair neither executes nor waives them. :chatgpt-content-reference{index="18"} :chatgpt-content-reference{index="19"}

### Sources, inspection boundary, and confidence

I read the complete attached audit and fingerprinted its **33,252 bytes** as SHA-256 `03eecb21…42e4116`. The audit ZIP and actual launcher, cleanup, and driver were not attached here. Their source-level defects and authentication therefore remain **independent-auditor-reported**, not independently reproduced by me. No repository code, tests, host commands, or privileged operations were executed in this review.

Sources are the attached audit and preparation/validation reports, plus upstream Linux and pinned util-linux documentation for the narrow loop-lifecycle distinctions above.

**Confidence:** **0.98** in retaining the execution block; **0.93** in the external-only repair direction. Attachment provenance is established, but replacement-tooling correctness, mounted behavior, and whole-candidate acceptance remain outstanding.
