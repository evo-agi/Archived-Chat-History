Here is ChatGPT's response:

**Completed the bounded authority-to-failure-prefix owner slice.** The full AR-01–AR-03 correction remains incomplete, and independent acceptance remains pending a different reviewer.

ES_AR01_AR03_AUTHORITY_FAILURE_PREFIX_SLICE_20261012_01.zip

The exact ZIP was reopened and checked, including its specimen chains, saved negative mutations, complete corpus/map binding, and CP04 reconstruction:
```
Bytes:   654,877
Members: 82
SHA-256: d4b05444671f0d60c1dafcf65bf36f86d7ecade3e07c61190390e4210f4f36df
```

### Substantive result

The packet contains the **complete updated TEMPORAL_CONTRACT.md** and **complete updated TEMPORAL_CONTRACT_MIGRATION.json**, not excerpts or an unchanged preservation pair. Their sizes are 204,691 and 1,733,181 bytes respectively.

Two source-grounded corrections were necessary. B’s production manifest permits **1–32 formatter dependencies, giving 8–39 run objects**, rather than CP04’s allowance of 57 dependencies and 64 objects. Also, `prerequisite_import_observation_sha256` binds the **raw installation-receipt file**, not the typed import EntryObservation. These corrections and the prefix chronology are reflected in the corpus and affected active consumers—not merely in a sidecar. The source anchors and distinctions between historical implementation and proposed behavior are recorded in the OWNER_SLICE_REPORT.md.

The active-map changes cover eight relevant M rows, authority and version records, failure and receiver accounting, E48’s family gate and Q1/Q2 consumers, selected E51/E53 consumers, 28 caller records, and six scenario expectations. All 96 scenario identities remain present and prospective; this does not certify the remaining scenarios.

The **43 actual specimen files** construct:

> Complete modeled approval → exact request → exact entry → Q1 challenge / unissued response / Open result → immutable FailureCloseoutV2 → prepared Q2.

The complete failure prefix is **6,251 bytes**. Q2 binds its actual raw length and SHA-256, including the terminal LF. The prefix contains neither its own hash nor a later Q2 response, Write return, sync/Close result, or subsequent exchange. Q2 remains **prepared but unsent**.

Signature and key material are conspicuous fixed-width placeholders. Physical identity, custody, setup and clock observations are explicit model premises—not observed kernel facts or cryptographic validation. Complete authority containers are constructed and hashed; none is replaced by a seed hash.

### Checks and reconstruction

The separate reader/recomputer passes both positive inventory chains: the minimum eight-object case and the fully rebound **32-dependency / 39-object** boundary case.

**All 36 saved negative controls refuse at their intended predicate.** They include different complete approvals and requests, reversed source order, wrong corpus/subterm dependencies, import-field leakage, target and acquired-file contradictions, future/self facts in the prefix, incorrect prefix length/hash, cause and clock contradictions, omission, truncation and inventory-limit violations. For semantic cases, unrelated enclosing hashes were rebuilt rather than left stale.

The checks also reproduce the **13,631-byte Exchange maximum**, including 2,703 bytes of metadata, and exercise actual raw-cap and aggregate-accounting boundaries. These are format and conditional semantic checks—not a receiver or runtime pass. SLICE_VERIFICATION_RESULTS.json

Exact CP04 reconstruction uses **CP04_TO_SLICE_CORPUS_DELTA.json** and **CP04_TO_SLICE_MAP_DELTA.json**. A separately implemented replayer checked every before-image and reproduced both complete files byte-for-byte. Wrong-before-image controls also refused.

### Remaining whole-correction obligations

No I01–I07 obligation is marked wholly closed. The remaining work includes full active-map and all-scenario reconciliation, the outstanding pinned setup/parser/API checks on both actors, complete remaining histories and failure-branch coverage, preserved receiver/projection obligations, and exact **A-to-final** reconstruction with whole-correction verification. CP04-relative replay does not replace that final reconstruction.

The SLICE_STATUS.json separates supported portions from remaining obligations. Original inputs remain unchanged, and the six-member received versus seven-member reported archive discrepancy remains preserved.

**Sources:** SOURCE_INSPECTION.json; FIELD_PRODUCER_CONSUMER_CROSSWALK.json; owner report and verification results above.

**Confidence:** Provenance **0.99**; finite owner-check validation **0.97**; conditional slice-design judgment **0.88**. Whole-correction correctness, implementation, runtime behavior and independent acceptance are not established.
