**Retain `BLOCK`. The next repair must cover the complete lifecycle through final publication—not just the individual helpers named in the findings. Keep the validated ES candidate frozen.** The audit authenticates the retained validation but identifies eight defects in the external component under its own contract; absent policy or privileged execution does not explain them away. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation, not the audit conversation: :chatgpt-content-reference{index="18"}[Terminal-lifecycle and proof-binding repair prompt](sandbox:/mnt/data/ES_Terminal_Lifecycle_Repair/ES_Terminal_Lifecycle_and_Proof_Repair_Prompt.md).**

The handoff authorizes local, external-only repair and engineering validation. It authorizes no host contact, devices, privileged execution, gateway or watchdog implementation, mounted work, ES-suite rerun, or repository change.

## What this audit establishes

The **344 passing tests in each local lane are authentic observations**, and all 37 required MH-CUM regressions ran. The seven inherited Linux controls also authenticate. However, those safe controls do not execute the changed lifecycle implementation, and the local regressions missed the actual caller transitions now implicated. Their success remains valid evidence, but insufficient acceptance evidence. :chatgpt-content-reference{index="1"}

There is also genuine closure to preserve. The audit supports the administrative phase-graph repair and the narrow occupied-status and loop-number corrections. It does not reopen everything indiscriminately: several other repairs are substantial but incomplete because of specific remaining paths. :chatgpt-content-reference{index="2"}

**My assessment is that the recurring weakness is integration between stages.** The audit repeatedly finds that an isolated helper behaves correctly while its caller loses a deadline, identity, observation, or status. For example, finalization tests received a deadline directly and therefore bypassed the faulty controller-to-string-to-caller transition. Partial-removal tests modeled deletion as all-or-nothing and therefore missed an intermediate deletion failure. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

The next task therefore requires composed caller-level tests and actual temporary-file publication checks, with privileged effects substituted. Another unchanged broad-suite run—or eight disconnected new unit tests—will not meet its acceptance criteria.

## The central repair is the terminal evidence protocol

**LNX-NEW-02 is not a reporting cosmetic.** The audit finds that the exported ledger omits later write/export acknowledgements, the saved result can disagree with the returned result, final mode changes lack a subsequent durability operation, and the failure fallback is private rather than exported. A late completion can consequently leave a previously published success representation while the returned state becomes uncertain. :chatgpt-content-reference{index="5"}

The selected direction in the prompt is one finite, acyclic protocol:

**Freeze the operational ledger and semantic outcome; bind the published bundle to those exact bytes; report subsequent publication and durability observations separately.**

That means the implementation must define where the ledger ends, rather than recursively trying to log publication of itself. It must distinguish an attempted append from a known durable append. All records claiming to contain the same semantic outcome must agree, rather than serializing `result` and then changing its meaning in memory.

It must also define what a receiver needs before accepting completion. A record cannot prove that its own future write or synchronization succeeded merely by containing `CloseoutDurable=true`. A provisional or late artifact must not become accepted success because its JSON parses or its checksum matches.

The prompt requires fault tests across the **real publication sequence**: append, write, synchronization, close, mode changes, directory publication, sealing, and failure export. The tests must reopen the resulting temporary-file evidence and check what a receiver can actually establish—not inspect only the final in-memory object.

This remains a repair to the helper’s evidence contract. It does not create another source of ES run truth or a general transaction framework.

## Close the other findings at their actual boundaries

| Findings | Required change in the next task |
|---|---|
| **LNX-NEW-01 and 06 — time authority** | Carry the original deadline internally through finalization; recheck the owning context immediately before each signal. The existing test that expects KILL after expiry must change. |
| **LNX-NEW-03 and 04 — partial effects** | Preserve exact partial acquisition identities and deletion progress before handling errors. A failed post-state observation must not leave a successful pre-state inventory standing in its place. |
| **LNX-NEW-05 and 07 — exact resource custody** | Invalidate the stored pidfd before attempting close; never retry its number. After loop configuration, require a present, held, non-uncertain association—not merely a complete observation with a matching candidate identity. |
| **PV-01 — proof binding** | Bind accepted source coordinates to independent staging/results expectations, not just valid syntax and correct presentations. |

These changes follow the audit’s concrete source traces and required corrections. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

Three details are especially important.

**The deadline is control state; its formatted timestamp is evidence.** The current caller reparses RFC3339 text before finalization. Public Go documentation independently corroborates the underlying distinction: formatting and serialization omit the monotonic reading, and parsing does not reconstruct it. The repair should preserve the original typed deadline, not devise another string format. This corroboration does not replace the audit’s pinned-source analysis. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

**A close error must not leave the descriptor number available for another close attempt.** The audit identifies precisely that formatter path and points to an already safer pattern elsewhere in the component. Linux’s close documentation also warns that retrying a failed close can affect an unrelated descriptor that reused the number. The regression must demonstrate that repeated cleanup does not close such a replacement, while preserving release uncertainty. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

**PV-01 needs a coordinate-only negative.** The existing whole-observation swap fails because the presentation changes; it does not test the demonstrated escape. The new tests must leave presentations, arrays, hashes, and root identities valid while changing only source paths or devices. The report shows that such a mutation currently passes. Refusal cases must still not be required to supply acceptance-only observations. :chatgpt-content-reference{index="12"}

## Do not turn the prerequisites into new projects

Two decisions remain outside this repair.

**The proposed loop-object lease is not the current implementation.** The audit now explicitly establishes that the selector always issues `GET_FREE`, while the approval grammar has no lease, handoff, term, or retirement relationship. Adopting that recommendation would require a separately decided change; it cannot be treated as an available way to run the present helper. :chatgpt-content-reference{index="13"}

For this task, preserve the existing fail-closed residual-policy gate. The disposition `accept-single-get-free-possible-unbound-without-removal` remains unapproved. No removal, retry, scan, reset, implicit host-restoration claim, or lease implementation is authorized.

**The external hard-deadline owner remains absent.** The audit requires it to be established before the first privileged effect and to cover the complete episode, including final evidence. A helper-supplied boolean or elapsed-time observation is not that mechanism. :chatgpt-content-reference{index="14"}

The next task specifies the handoff and acceptance dependency but does not implement a watchdog. It must still repair its own monotonic deadline and post-expiry signal defects. External enforcement would not make either defect correct.

This is how the scope stays finite: correct the internal component and its interfaces without commissioning an allocator, gateway, watchdog, or recovery service merely to obtain another preparation verdict.

## Validation changes in this handoff

The prompt requires representative **combined failures**, not an unbounded test matrix. Examples include partial acquisition followed by ledger failure, partial removal followed by inventory failure, expiry during formatter grace followed by finalization timeout, and successful operational work followed by partial publication and failed failure-export.

Those tests must traverse the same control and decision functions used by the live caller. Where Darwin cannot execute a Linux-selected method, the source must show the binding to the shared routine under test. That remains substituted-effect evidence, not native privileged execution.

After development, Codex freezes the successor and runs the external tooling’s unit/race suites, native and Linux vet, formatting/environment checks, and deterministic supervisor builds. It must derive required coverage from the repaired obligations; **344 is not a target count**.

Artifact reuse remains selective. The changed supervisor gets new identities and remains unexecuted. The safe executable is rebuilt locally and its selected closure compared; byte-identical results allow the seven historical controls to carry forward without another remote run. Normal and diagnostic proof builds need change only if an essential driver change is demonstrated. The audit already confirms that these artifacts have distinct scopes and that none supplies mounted-runtime evidence. :chatgpt-content-reference{index="15"}

The task also permits a pure evaluator correction to replay unchanged execution records when their bindings remain valid. That exception cannot turn a failed test into a pass or validate changed source.

## Endpoint and inspection boundary

The intended engineering endpoint is:

```text
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REPAIRED_LOCAL_VALIDATION_PASSED_REAUDIT_REQUIRED
```

It requires source-level responses to all eight findings and the new caller-level controls. An unresolved implementation defect must be reported as such, not relabeled “policy pending.”

Fresh independent successor review still follows. Residual policy, administrative establishment, target/formatter qualification, hard-deadline support, mounted cases, deployment observation, supported-local consumer/operator proof, the unconditional whole-candidate ES audit, and exact-byte commit authority remain outstanding. :chatgpt-content-reference{index="16"}

I read the complete attached report and verified its **31,971 bytes** against SHA-256 `264838b9…1b037a`. The engineering ZIP, current source, specialist bodies, and raw streams were not attached here; their detailed authentication and findings remain **independent-auditor-reported**. The prompt identifies the retained inputs for Codex to inspect before editing. No repository code, tests, host commands, or privileged operations were executed here.

**Sources:** attached lifecycle re-audit and retained engineering report; official Go and Linux documentation used only for the two narrow semantic corroborations above.

**Confidence:** **0.98** in retaining `BLOCK`; **0.91** in this repair handoff. Report-byte provenance is verified. Successor correctness, privileged readiness, and whole-candidate acceptance remain unestablished.
