**Retain `R6_ONE_CANDIDATE_R01_R04_ARTIFACT_REVIEW_BLOCKED`.** R01–R04 are addressed within the inspected pilot branches, but R05 is a real, bounded causal-order omission: the reader permits poll custody absorption before the adapter has finished processing and returning that poll result.

### ES_R6_PILOT_R05_REPAIR_HANDOFF_20261014_01.zip[Download the self-contained R05 owner-repair handoff](sandbox:/mnt/data/ES_R6_PILOT_R05_REPAIR_HANDOFF_20261014_01.zip)

The package contains the repaired pilot and blocked review unchanged, plus the exact repair task, input identities, and receiving inspection.

```text
Bytes:   40,359,154
Members: 7
SHA-256: afd8c5a673f066e8f6a79220543302caf09b18b9814133bf62892dbb1a733e8f
```

The ZIP was reopened and verified against its self-excluding manifest, including member bytes, hashes, modes, CRCs, safe paths, and exact input identities.

## Repair direction

The valid histories already use the source-consistent order:

```text
poll return
→ controller receive
→ adapter error/storage treatment
→ controller absorption
→ finish
→ seal
```

The current reader instead allows:

```text
poll return
→ controller receive
→ controller absorption
→ adapter result
```

because the absorption branch checks the received response and custody hash but not whether matching adapter treatment has completed.

The repair task therefore requires a **poll-specific** causal gate:

- `adapter.result` must complete for the exact poll request and received response before `controller.absorb`;
- the normal path must retain its post-completion sample before adapter result;
- the Close-error path must preserve the adapter’s exact error/stored-false treatment before absorption;
- spawn remains unchanged because this pilot does not model a separate spawn `adapter.result`;
- later adapter treatment cannot retroactively validate an earlier absorption.

The two review specimens remain unchanged and must refuse at a new fixed causal-order predicate, not through stale hashes or an unrelated rule:

- `RC01_EARLY_POLL_ABSORPTION`
- `RC02_EARLY_ERROR_ABSORPTION`

The repaired normal and consuming-Close-error histories should require **no event-byte changes** because they already have the intended order.

## Message to send

Send the ZIP to the **existing ChatGPT pilot-owner conversation**, not Codex and not a reviewer:

> Repair R05 under `NEXT_OWNER_TASK.md`. Authenticate both nested input archives and inspect the actual successor reader, fixed rules, two R05 specimens, and accepted B source before authoring.
>
> Freeze a new explicit pilot-local interpretation requiring matching poll adapter-result treatment before controller absorption. Preserve R01–R04, all historical evidence, the unchanged RC01/RC02 specimens, the valid normal and Close-error histories, the lost-ack prefix, and the inherited-C witness.
>
> Author and execute only a newly written inert successor reader. Save and verify the first substantive repair before expanding controls. Return one actual downloadable repaired-pilot package with exact changed-file reconstruction and repeatable results.
>
> Do not modify the full corpus/map, expand to other candidates or full R6, launch Codex, access repositories or hosts, execute uploaded predecessor/reviewer programs, or claim independent acceptance.

The intended owner endpoint is:

```text
OWNER_BOUNDED_R6_ONE_CANDIDATE_R05_REPAIRED_REVIEW_REQUIRED
```

After owner delivery, use a **genuinely different ChatGPT conversation** to review the exact successor bytes. The current blocked review did not satisfy fresh author/reviewer separation.

**Sources:** the uploaded repaired-pilot artifact review, its R05 counterexamples and source excerpts, and the exact repaired reader and rules; the preceding owner report confirms the pilot’s bounded scope and unresolved independent-acceptance boundary. OWNER_REPORT

**Confidence:** 0.99 in archive identity and the observed causal gap; 0.97 in the bounded repair direction. Successor-reader correctness and independent acceptance remain unestablished.
