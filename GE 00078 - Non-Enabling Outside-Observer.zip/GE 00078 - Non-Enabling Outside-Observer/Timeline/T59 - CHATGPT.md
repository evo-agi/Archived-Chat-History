**Proceed to a fresh, read-only cumulative re-audit of this exact successor. Keep the ES candidate and external helper frozen.** The report supports completing the engineering repair phase; it does not independently close the eight findings or establish privileged suitability. No further repair is justified from this report alone. :chatgpt-content-reference{index="0"}

**Send this to a fresh Codex audit conversation—not the implementation conversation: :chatgpt-content-reference{index="13"}[Action-custody and receiver cumulative re-audit prompt](sandbox:/mnt/data/ES_Action_Custody_Receiver_Reaudit/ES_Action_Custody_Receiver_Cumulative_Reaudit_Prompt.md).**

The handoff authorizes source inspection and independent analysis of retained evidence. It authorizes no repairs, builds, test reruns, host contact, gateway installation, mounted execution, or repository changes.

## What this result supports

The reported receiver repair now addresses the preceding audit’s central objection: **it replays the actual case predicates rather than treating committed waits or authenticated success labels as proof.** It requires nineteen `ProcessRecord` payloads—eleven normal and eight diagnostic—and routes them through `AdjudicateCase` and `AdjudicateDiagnostic`. That is the selected repair direction. The auditor must verify the real producer’s payloads, the receiver’s expectations, and the composed tests agree. :chatgpt-content-reference{index="1"}

The reported validation has distinct scopes:

| Evidence | Reported result | Limit |
|---|---|---|
| Local external-tooling unit and race lanes | **959 started and passing test/subtest paths in each; 151 named controls present** | Darwin/ARM64 execution, not privileged Linux behavior |
| Linux-only controls | Two named tests compiled; Linux vet and full test compilation passed | No execution credit for those tests |
| Supervisor A/B | Identical deterministic builds | Never executed |
| Safe executable and import closure | Match the authenticated inherited identities | Support reuse of the old safe-control observations, not validation of the changed supervisor |

The source grew from 111 to 119 members through eight additions and 39 modifications. The report says the safe mechanics, dependencies, proof drivers, instrumentation, and inherited source-union material remained unchanged. Those are exact-delta and dependency claims for the auditor to authenticate—not reasons to repeat the earlier ES validation lanes. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

## The main audit question: can the live producer satisfy its receiver?

The new terminal validator requires a **fixed eighty-action lifecycle**, exact identities and transitions, and a live-only initial `episode-durable` row. This is substantially more restrictive than the preceding receiver. **Restrictiveness alone does not establish correctness.** A receiver can reject malformed evidence while also rejecting every legitimate live output. :chatgpt-content-reference{index="4"}

The prompt therefore makes two independent judgments mandatory:

**Soundness:** failed, uncertain, substituted, incorrectly timed, or over-budget evidence cannot pass merely because its hashes and authentication agree.

**Reachability under stated prerequisites:** a correct live producer emits the exact records, identities, versions, payloads, and ordering that the receiver accepts—without fixture-only preparation, fabricated facts, or suppressed errors.

The auditor must derive the successful sequence **forward from the actual producer**, then compare it with the receiver and tests. Generating a synthetic ledger from the receiver’s own expected-action table would not independently establish that the producer can produce it.

The same review must distinguish successful proof acceptance from preservation of truthful failure evidence. Failed or partial episodes need not match the complete successful trace. Any recovered history that the existing contract expressly permits must retain its errors and fresh observations rather than being silently rewritten into an error-free eighty-action history.

This is a review of the external helper’s selected contract. **The eighty-action grammar does not become an ES lifecycle contract.**

## The three lifecycle repairs need syscall-level caller review

The report describes appropriate corrections: action-adjacent ownership checks, explicit custody of both original socket endpoints and the retained duplicate, and separate authorization immediately before each signal syscall. Their adequacy still depends on their actual callers and error paths. :chatgpt-content-reference{index="5"}

The re-audit focuses on the intervals that previously escaped the controls:

**Entry effects:** cancellation after one successful check must prevent the next deliberate effect. A guard around several actions is not equivalent to checking each action. Acquisitions completed before cancellation must still leave accurate custody and release uncertainty.

**Channel acquisition:** the producer must record the original descriptors, ownership transfers, duplicate, and close outcomes as they occur. A controller test supplied with a fully populated partial observation cannot establish that the live producer captures those facts before its next possible failure.

**Signals:** each actual syscall—including fallback—must use the original per-subject authority. An intervening observation cannot leave an earlier authorization available for a later syscall, and cleanup reentry cannot renew expiry.

The reported descriptor non-aliasing checks also need their stated **co-held** scope preserved. The audit should not turn them into an unsupported lifetime-wide prohibition on reusing a released descriptor number. :chatgpt-content-reference{index="6"}

These are review targets, not newly established defects in the unseen implementation.

## Check the contract changes together, not file by file

Three receiver changes deserve particular scrutiny.

### Deadline and schema consistency

The repair versions administrative approval, entry request, and entry observation to v3; publication receipt to v3; and receiver expectations and confirmation to v2. They reportedly bind one exact pre-effect deadline in Unix nanoseconds. :chatgpt-content-reference{index="7"}

The audit must follow that value through the actual administrative phases, owner construction, internal deadline, publication, persisted receipt, confirmation, and receiver. It must check mixed generations, stale templates, earlier inherited deadlines, cancellation, and cleanup without silently substituting a different episode deadline.

It must also distinguish **completion within the authorized deadline** from **later retrospective verification**. An offline auditor may read evidence afterward; that does not relax the requirement to establish which effects and observations occurred within the original bound.

### Profile validity and independent selection

The receiver now accepts only `synthetic-complete/v1` and `live-complete/v1`, both under `normal-with-required-diagnostics`, with fixed paths, modes, subjects, and payload relationships. :chatgpt-content-reference{index="8"}

The reviewer must establish that untrusted evidence cannot select its own profile, verifier, expected root, deadline, or policy. Matching actual and expected values still do not suffice when both describe an out-of-contract profile.

The synthetic profile must remain explicitly test-only. Conversely, the currently unapproved live residual policy must not conceal an unreachable live success path or another present source defect. **No residual policy, signer, gateway, or watchdog is adopted by this audit.**

### Aggregate reconstruction limits

The report specifies one 16 MiB budget beginning with the receipt carrier, a 512-member cap, bounded enumeration, and cached reuse of each acquired member. :chatgpt-content-reference{index="9"}

The audit must verify the budget’s complete domain and the member cap’s relationship to the finite schema. It must trace actual reads—not only declared sizes—and ensure decoding, repeated checks, and any legacy path cannot reset the accounting or reopen an unbounded tree. Cached reuse must preserve the original object and byte bindings.

These checks require no new quota or resource-management subsystem.

## Preserve history without confusing it with current acceptance

The matrix reportedly retains the 59 inherited rows byte-for-byte and appends five DRA rows. A preliminary generation was invalidated after explanatory text entered an inherited row; that row was restored, and the complete corrected plan reran. This is a disclosed governance correction, not a reported test failure. :chatgpt-content-reference{index="10"}

The independent auditor must preserve those historical artifacts while issuing its **own current 64-row judgments**. Historical immutability does not require repeating stale dispositions.

Coverage needs a separate crosswalk. The preceding audit established retention of all 530 earlier terminal identities and 269 earlier requirements in the 628-terminal generation. The new report’s 959 terminals and 151 named controls do not, by themselves, establish preservation of those obligations. The prompt requires an explicit retained/added/corrected/excluded mapping, including any old positive expectation deliberately changed because it embodied a confirmed defect. :chatgpt-content-reference{index="11"}

Current evaluator and packaging invocations must also authenticate. The old `INCOMPLETE` history remains unchanged, but it is not a permanent blocker to independently complete successor evidence.

## Endpoint and inspection boundary

A satisfactory review may conclude:

```text
ES_MOUNTED_HELPER_ACTION_CUSTODY_RECEIVER_STATIC_REVIEW_SATISFIED_EXTERNAL_GATES_PENDING
```

That would establish scoped static adequacy and adequate retained evidence—not privileged execution or whole-candidate ES acceptance. Residual policy, trusted entry and parent storage, target/formatter qualification, external containment and confirmation, mounted cases, deployment observation, supported-local proof, the unconditional whole-candidate ES audit, and exact-byte staging/commit authority remain outstanding. :chatgpt-content-reference{index="12"}

I read the complete attached report and computed its fingerprint: **13,222 bytes**, SHA-256 `dda3cdf87fe2438910097b417626c109ca216a0aaf17ce48b91d23a30e57737d`. The current ZIP, implementation, raw streams, and invocation records were not attached here; their detailed authentication and execution remain **owner-reported**. The prompt supplies their retained paths and expected identities, so the fresh Codex auditor can inspect them without another collection task.

**Sources:** attached action-custody/receiver report, preceding independent receiver audit, and the preceding repair handoff. No repository code, tests, hosts, or privileged operations were executed here.

**Confidence: 0.96 in proceeding to this re-audit.** Report-byte identity is established; current implementation closure and validation adequacy await independent inspection. Privileged readiness and whole-candidate acceptance remain unestablished.
