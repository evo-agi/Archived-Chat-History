**Proceed to a fresh, read-only cumulative re-audit of this exact successor. Keep both the ES candidate and the external helper frozen.** The report supports completing the narrow owner correction; it does not independently close SB-1…SB-5 or establish readiness for privileged execution. No further implementation change is justified from this report alone. :chatgpt-content-reference{index="0"}

**Send this to a fresh Codex audit conversation—not the implementation conversation: :chatgpt-content-reference{index="16"}[SB-4, lineage, and closeout cumulative re-audit prompt](sandbox:/mnt/data/ES_SB4_Cumulative_Reaudit/ES_SB4_Lineage_Closeout_Cumulative_Independent_Reaudit_Prompt.md).**

The handoff authorizes inspection and independent analysis of retained evidence. It authorizes no repairs, builds, test reruns, host contact, gateway work, mounted execution, or repository changes.

## What this correction supports

The reported changes address the two disclosed omissions and the completion check that missed them.

**The new SB-4 witness distinguishes successful stdio release from failure before acquisition.** Its setup exercises the real `startWorkerWithOperations` sequence with primitive effects substituted: stdio acquisition and identification, a process-start error, successful stdio close, and a separate channel-close error. The assertions require released stdio to remain known while channel release remains uncertain, with no invented child references, false terminal absence, or later retry of the invalidated descriptor. That is the missing property—not a renamed version of the weaker predecessor case. The auditor must inspect those assertions and their actual production binding. :chatgpt-content-reference{index="1"}

**The historical matrix is reportedly restored from an independent original.** The report identifies the four altered rows, restores the complete 24,949-byte file to SHA-256 `d9a7c54c…f8fa2a`, and keeps current interpretations in the separate owner-response document. Restoring historical schema wording does not mean reverting the current implementation; it preserves what the historical record actually said. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

**The completion check now retains the obligation independently of test discovery.** The predecessor could report success because its inventory came from the tests already present, and its handoff trusted those passing decisions plus packaging checks. The successor reportedly pins both the historical matrix and the explicit reciprocal requirement, then checks their bindings again against the closed packet. Its adversarial controls include a missing witness, a deleted requirement, altered matrix rows with regenerated hashes, wrong-generation evidence, and passing decision bodies without invocation records. That addresses the demonstrated false-success mechanism. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

A machine check can enforce those bindings. **It still cannot substitute for reviewing what the witness’s assertions actually prove.**

## The unchanged test totals are expected

The new startup witness is Linux-selected and was **compiled, not executed**. The local AST/source-binding control and portable composed receiver-refusal control ran in the Darwin suites. Those are complementary evidence classes, not three executions of the same behavior. :chatgpt-content-reference{index="6"}

| Evidence | Reported treatment |
|---|---|
| Local unit and race suites | 1,016 passing terminals and 166 named portable controls in each |
| New direct SB-4 startup witness | Source-reviewed and included among five Linux compile-only controls |
| Supervisor and safe executable | Inherited under unchanged non-test inputs; no new execution |
| Normal and diagnostic proof artifacts | Historical compile-only identities, retaining the current-body-unavailable qualification |

The unchanged Darwin totals therefore do not indicate that the new test was omitted from its applicable build. The auditor must verify the selection and compilation records rather than expect the local count to increase. The report also explicitly preserves the distinction between the inherited seven safe Linux observations and the unexecuted repaired supervisor. :chatgpt-content-reference{index="7"}

## The audit must still assess the complete five-block repair

**This is not just an audit of two test files and a restored Markdown file.** The latest correction made no non-test runtime changes, so it retains the preceding SB-1…SB-5 implementation—the implementation that still awaits independent review. The new source contains 126 members, derived from the rejected 125-member generation rather than rolled back to the older 119-member source. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

The prompt gives the reviewers three connected obligations.

**Lifecycle and custody:** trace actual formatter release into the controller and receiver; inspect stdio/channel partial states through all relevant errors; and verify that candidate ownership after pidfd failure persists until exact group absence—not merely leader reap—is established.

**Producer and receiver:** establish that the actual live producer can satisfy the receiver under explicitly hypothetical valid prerequisites. The conditional possible-unbound policy branch must remain fail-closed without real approval, and timely historical evidence must remain reviewable later without renewing effect authority.

**Assurance and evidence:** independently inspect the reciprocal witness, restored history, fixed requirement, current invocation chain, coverage crosswalk, and closed-packet checks. A successful handoff field is a conclusion to verify, not the audit’s premise.

These are the outstanding source questions from the latest independent audit. Its qualified closures—such as action-adjacent entry checks, individual signal authorization, case-semantic replay, and bounded reconstruction—should carry forward unless a concrete current interaction undermines them. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

The auditor should preserve the immutable historical matrix while issuing **separate current judgments**. Historical preservation does not require repeating stale dispositions.

## Verify the completed companions, not the report’s prospective wording

The attached report was intentionally finalized before packaging. Its A–F section describes stages D, E, and F prospectively; your relayed closeout now supplies their completed invocation paths. The re-auditor must read those actual records and streams, alongside the closed ZIP and `HANDOFF.json`. The pre-packaging report cannot establish that those later calls occurred. :chatgpt-content-reference{index="12"}

The prompt also handles the recording order without creating another circular requirement: a completed stage-F invocation record can only exist after F produces its handoff output. It may remain an external companion; the handoff need not recursively authenticate its own future completed invocation.

The disclosed failed closing-provenance attempt is similarly bounded. The report says it failed on an already-created empty destination, before reading ES, then replayed unchanged after that placeholder was removed. Its failed triplet remains accessible outside the ZIP. The audit should authenticate that account and distinguish it from a test failure or source-generation change—not require another validation cycle to make the history shorter. :chatgpt-content-reference{index="13"}

### One documentary discrepancy I found

The report’s digest for `tooling/internal/proof/terminal_receiver_test.go` contains **63 hexadecimal characters**, so it is not a usable complete SHA-256 anchor. :chatgpt-content-reference{index="14"}

The prompt explicitly prohibits padding or guessing the missing character. The auditor must authenticate that member through the complete anchored source/packet manifests and compute its actual digest. **If those bindings agree, the malformed report literal alone need not block source authentication.** It does not justify another correction-and-packaging tranche before this review.

## Next endpoint and limits

A satisfactory scoped result may be:

```text
ES_MOUNTED_HELPER_SB4_CUMULATIVE_STATIC_REVIEW_SATISFIED_EXTERNAL_GATES_PENDING
```

That would establish current static adequacy and sufficient retained evidence—not policy approval, mounted-proof success, or whole-candidate ES acceptance. Concrete source defects and essential current evidence gaps must still receive separate blocking or incomplete judgments.

Administrative/trust/storage establishment, residual-policy selection, target and formatter qualification, external containment and confirmation, mounted cases, deployment observation, supported-local proof, the **unconditional whole-candidate ES audit**, and exact-byte Git/publication authority remain pending. :chatgpt-content-reference{index="15"}

I read the complete attached report and computed its fingerprint: **24,515 bytes**, SHA-256 `417789308a774207d15c933739b622667a0449de029e45f68ae3b6a47c21320c`. The current ZIP, source, handoff, and invocation companions were not attached here. Their detailed authentication and execution remain **owner-reported**; the audit prompt supplies their retained local paths for direct inspection. No collection task or rebuild is needed to initiate that review.

**Sources:** attached correction report, preceding independent source audit, and the prior SB-4 correction handoff. No repository code, tests, hosts, or privileged operations were executed here.

**Confidence: 0.96 in proceeding to this cumulative re-audit.** Report-byte identity is established. Current source correctness, assertion adequacy, and companion completeness await independent inspection; privileged readiness and whole-candidate acceptance remain unestablished.
