ES final combined independent audit — repaired, dual-Linux-validated candidate
Objective and posture
Run this in a fresh Codex audit conversation, separate from the implementation/revalidation conversation. Independently decide whether the complete current ES integration candidate is ready for a separately authorized commit gate. Do not audit only the last one-file fixture repair.
Repository: /Users/ds/Repositories/Execution Substrate/
The audit is read-only with respect to every repository, index/ref/worktree, historical evidence root, and persistent maintenance asset. You may create a fresh private audit-evidence directory outside repositories, run the explicitly authorized local validation below, and remove only your own authenticated disposable scratch. Existing test-owned temporary files, in-memory mutation fixtures, fake clients, and loopback test servers are authorized. No implementation, formatting writes, assertion changes, doc/status edits, repair, staging, commit, push, fetch, branch switch, worktree creation, dependency installation/download, live-service call, remote contact, SSH, Lima start/stop, deployment, target audit, A6, or reliable-submit wiring is authorized. Do not run operator commands against real environments.
The Linux runs are completed validation evidence to authenticate and review, not instructions to repeat remote testing. Do not start another environment-readiness cycle or external schema-package audit. No separate preliminary collection task is needed when the retained files below are accessible.
1. Context, scope, and historical findings
The active candidate comprises 75 dirty paths: 64 modified tracked regular files and 11 untracked regular files, within a complete 352-file source inventory. It includes production, documentation, assurance, and operator-compatibility changes accumulated before the latest repair. The last task changed only an existing test file; that fact does not reduce the final audit to a test-only audit.
Earlier final audit T584 reported four commit-blocking findings:
- M1: custody-sensitive test fixtures used nonphysical macOS temp-path spellings. Centralized physicalTestTempDir repairs were subsequently reported; negative symlink tests were to remain intact.
- M2: Go semantic guards used raw substring counts/order instead of object/call-flow identity. Subsequent tests use AST/go-types, bounded call inventories, and behavior-preserving/behavior-breaking mutations.
- M3: shell retired-route guards depended on whole-function text and layout. Subsequent tests use structure-insensitive inventories and actual safe refusal behavior, preserving privacy-first ordering.
- M4: native admission-suite evidence was missing for both claimed Linux architectures.
T586 reported the M1–M3 repairs, default/physical full-suite passes, and a race pass. Those full-suite/race results precede the latest fixture bytes and are historical, not current-candidate validation. Source anchors in the pre-fixture snapshot: es/admission/staging_custody_test.go:13–35, es/admission/workstream_c_guardrails_test.go:4017 onward, and remote_alpha_operator_test.go:5173 onward; verify current locations rather than relying on line positions.
The first native AMD64 attempt failed because newWorkstreamCTestService configured /bin/sh, whose ancestry/leaf were symlinks on the governed host. Production no-follow capture correctly refused the fixture. ARM64 was not started in that failed attempt. The latest task replaced that dependency with test-owned inert runtime-support bytes, added TestWorkstreamCRuntimeSupportFixtureIsHermetic, corrected an external GOENV reporting predicate, and reports local admission plus both native admission suites passing.
These are reported outcomes to audit, not accepted conclusions. Re-adjudicate M1–M4 and the later Linux fixture issue against current source and retained evidence. Preserve the original native failure as failure. Do not manufacture a new issue for every derivative failing subtest.
Earlier T584 proposed one integration commit containing all 75 paths, subject:
execution: finalize resolved plan, custody, and retired routes
That is a proposed boundary/subject, not an accepted audit or publication authorization. Confirm or reject it based on the entire current diff.
2. Authenticate retained inputs and current bytes before correctness review
Latest retained root:
/private/tmp/ES-native-linux-fixture-repair-revalidation-1G6rj3Sg
Latest full report:
/private/tmp/ES-native-linux-fixture-repair-revalidation-1G6rj3Sg/report/native-linux-fixture-repair-revalidation-report.md
Latest review ZIP:
/Users/ds/Downloads/ES-native-linux-fixture-repair-revalidation-20261005T002620Z-1G6rj3Sg.zip
- ZIP: 530305 bytes; SHA-256 6fd48d67c5afbba2f088dfe15f265847b431624091e70b5894f7541c7fbd7d29.
- Self-excluding internal manifest SHA-256: cd9cfe009d1f6c8c16cfe9d878ea06e52a96590d61f370225f4a7801dc96dc39.
Inspect archive member names/types and authenticate the exact manifest and all included files before using them. Reject duplicate, escaping, absolute, or unexpected special member paths. Locate exact source/manifest/recipe/log filenames through the authenticated packet and registries; do not invent subpaths. Distinguish compact packet records from full raw evidence retained outside it. Neither missing raw evidence nor malformed event streams may be converted into success by a summary boolean.
The source/candidate serializers and verification helper must be available as exact source bytes bound to this packet. Inspect their semantics and authenticate their registered source identities before reuse. Do not execute an installer, remote orchestrator, or the native test harness merely to reproduce a manifest. Use the retained verification-only recipe/entry point where available. A small audit-only comparison driver may safely reimplement explicitly documented serialization semantics, but it must be labeled independent analysis, retain its own source, reproduce every expected canonical byte, and must not be represented as the original recipe. Do not revise the frozen recipe or substitute the project's unrelated generic recipe for the expected identities. If exact recipe source is missing or ambiguous, report that precise provenance limitation; do not guess.
Require the live opening state:
Field	Expected value
Branch / upstream	trunk_dev / origin/trunk_dev
HEAD	b92bd9884106154d25342e1573dcc4c312311436
HEAD tree	cdd4e44bac15c1952d70997143040644361f0bb1
Sole parent	4f797fb63d3c5b95275b1455af36ebc9b695f773
Local ref comparison	1 ahead / 0 behind; do not fetch
Status	zero staged/conflicted paths; no active Git operation; 64 modified tracked + 11 untracked regular files
Worktrees	six; exact retained worktree inventory unchanged
Status digest	adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93
Complete source manifest	352 rows; 66503 bytes; 7e48b9407da4117bc22c862802f94d324e5b216394b78f040b3ba4087eb6ca5c
Candidate manifest	75 rows; 9109 bytes; 2fa0cd9f49bacf98727b109362ca8514d780b9a4ddb8c6d01e94ba1cc0fe071f
Complete tracked binary diff	2246275 bytes; c8d68d2eb71a4482c1cf2e66209d32d8fdf83b0f7fdc55f299b31277b315b54e


The recorded diff command is git -c core.fsmonitor=false diff --binary --full-index; inspect the retained recipe/environment and use them exactly for its byte-identity check. Disable optional Git locks. Do not silently change flags, locale, serialization, path prefixes, or newline rules and call the result the same recipe. Additional safe review diffs are separate analysis. Inspect relevant Git configuration/attributes before invoking anything that could select external tools; do not authorize external commands through unexamined diff configuration.
Latest fixture file:
es/admission/workstream_c_guardrails_test.go
- Mode 0644; 241999 bytes; SHA-256 164d20bb4f9c1bd9e9fbd8d9c8b05bcc70b0da17447495caeefc935a1dc23263.
- Pre-repair file: 239149 bytes; e77463365f503425f6bb0349349f322d50398fdfa87efcabe583d24f0a2e1a46.
- Exact fixture repair diff: 3941 bytes; e6b51fd66e50e279baaa69106c6b574fd4eb21e8402f3c7b655f5df0291f0378.
- Revalidation archive: 7290880 bytes; 6d58fa67429ee25a3b84da3d88d57d1456938b8b67790e92a73c9f36b79b2c8e.
- Archive-member manifest: 78108 bytes; 852ca9be36a863fb098fbaf96f4bec9e4764eef14af91a481f3898ca8345039a.
Compare every full-source and candidate row, not only aggregate counts. Reproduce the source/candidate serialization twice and require byte equality. Verify the new packet's opening-to-frozen transition changes only the stated fixture row; verify current live bytes equal the frozen candidate. The older source/candidate digests were respectively b1d43619d4bd989fdf66e0254d11c8d38c8a05333f83072c2ede24f795bd6a89 and 7474bf8cd336421b56cf7e0f8b034280d9e01c92f25cb72464a700ba88313678; they are not the current audit target.
Stop before semantic audit or tests on a true baseline/recipe/byte mismatch. Do not rebase, absorb new edits, regenerate a convenient target, or repair a manifest to match live drift. Provenance proves byte identity, not correctness or authority.
3. Governing sources and classifications
After provenance matches, read the live AGENTS.md, PLANS.md, applicable nested guidance, and each changed document/source/test/script. Use README.md as navigation, not design authority. Inspect relevant unchanged callers, build metadata, configs, examples, schemas/migrations, and artifacts where the diff depends on them; record non-applicable surfaces rather than inventing work.
Important supplied-source anchors, whose current locations/content must be verified:
- AGENTS.md:21–36,79–99,132–159: guidance hierarchy, doc-first boundary changes, conflict handling, capability-sensitive validation.
- PLANS.md:195–251: admitted semantic plan versus byte material, qualified host context, run projection, freeze point, single runtime-command grammar, and limits of semantic-plan equality.
- PLANS.md:252–303: B2 privacy/independent assurance and related bounded claims.
- PLANS.md:304–397: expected-tree bounds, resource/file custody, retention/cleanup, result publication, platform behavior, and mandatory native Linux evidence before final combined audit/commit.
- PLANS.md:399–407: excluded canonical binding, durable replay/runtime wiring, new public surfaces, host substitution, and cross-repo integration.
- PLANS.md:521 onward: current operator-route/evidence retirement and privacy ordering.
- .docs/system_overview/{boundaries,contracts,configuration,capability_probing,remote_supported_host_alpha,artifact_publication_storage}.md and changed qualification/ownership/privilege documents.
- .docs/execution_lifecycle/{contracts,design,implementation,es_execution_admission_model,reliable_submit_persistence_and_concurrency,submit_idempotency_correlation_and_recovery}.md.
- All changed .runbooks/, docs_contract_test.go, admission/app tests, root operator tests, scripts/remote_alpha_operator.sh, and changed compatibility wrappers/internal scripts.
Use current invariant, bounded slice rule, temporary compatibility edge, reopened redesign seam, implementation detail, and evidence/projection deliberately. The selected runtime-support no-follow/single-link capture contract is not reopened by the fixture repair. control-plane-normal-shell/v1 remains a retained temporary compatibility edge. CP workflow authority is confined to the maintained demo path; no enduring target-peer status is inferred. Coordinator autonomy is strategic target context, not an implemented ES capability or an audit prerequisite. Reports, test output, manifests, and external schema packages do not become product authority.
The older external current-schema-package promotion is historical evidence-only work with no ES-owned consumer. Verify that this candidate has not introduced external schema bytes, a Downloads/tmp role binding, content-snapshot reader, external digest pin, or audit/promotion dependency. Do not audit/rebuild that historical subsystem.
4. Independent review coverage
Use one fresh foreground audit parent and up to four bounded read-only audit perspectives with self-contained context. No nested delegation, writers, independent child tests, remote operations, or installation. Each receives the same frozen candidate identities and explicit non-goals. Inspect any repo custom-agent instructions before using them; do not let a stale architectural assumption predetermine the result.
Suggested non-overlapping assignments:
1. Contracts and semantic ownership: governing plan/docs, resolved-plan/material/host/run split, public and compatibility semantics, durable-source versus unwired runtime distinctions, claim accuracy, and commit coherence.
2. Execution correctness and custody security: input/resource limits, exclusive claim/materialization, descriptor and filesystem identity/lifetimes, mount parsing, publication/retention/cleanup, synchronization and all error paths.
3. Assurance and validation: M1/M2 closure, actual latest fixture and independent regression, Go typed guardrails/mutation tests, finite inventories, literal golden independence, native/local evidence and required-test adjudication.
4. Operator/privacy/artifact boundaries: M3 closure, shell parsing and actual refusal behavior, route/flag retirement, logging/error privacy, privilege/config/runbook agreement, artifact hygiene and unwanted integration.
Parent owns complete coverage across all 75 candidate paths and relevant unchanged dependencies, reconciles overlaps, and preserves disagreements. At most one retry for an unavailable subagent. The fresh audit parent may explicitly cover a missing perspective itself; never invent a subagent report or claim unperformed coverage. Any remaining material coverage gap blocks ACCEPT. Close all children before parent-owned local validation.
Mandatory substantive checks
Resolved execution and authority: trace resolveExecutionForSubmit through freeze, one locator/projection, claim, captured-byte materialization, handoff, job, revalidation, one Nomad call, receipt, lifecycle and results. Identify every authoritative writer and downstream copy. Verify that plan equality is not promoted into dispatch/replay/host-substitution identity; material and host context stay outside semantic truth where required; no parallel admission grammar, mutable shadow fact, unselected PlanBinding, or keyed-submit runtime capability appears.
Custody/resource/retained results: inspect all tracked/untracked production paths and platform variants. Verify configured-root qualification, no-follow/single-link stable capture, exclusive run-root creation, refusal without adopting/mutating existing objects, bounded mount/dependency consumption, incremental expected-tree checks with fresh cursors, expected-node/edge bounds, hard-link/symlink/replacement/mount-crossing behavior, source identity revalidation, no-replace final publication, trustworthy existing-final idempotence, and exact incomplete-leaf/probe/temporary cleanup. Trace every early return and descriptor close. Preserve post-claim visible-root retention and the explicit absence of general reclamation. Do not mistake a test pass for proof of all flags or descriptor-close paths.
Reconstruct finite inventories: expected-tree ReadDir versus result traversal; claim constructor/callers/platform helpers; materialization producer/caller/mutation graph; mutex/atomic owners and exact readers/writers/escapes; rejected A3 namespace/root-pair/global registry/lease-marker/flock/mutation-poison topology; and retired operator routes/flags/handlers/privacy order. Check identities and roles, not just counts. Explain missing/extra/stale rows and production/test/platform classifications. Existing guards are bounded assurance, not general whole-program alias/taint analysis.
Independent assurance: read literal default and control-plane job goldens, token/template ledger, handoff expectations, and negative controls. Expected trees must not be generated from the actual job or a shared defective projector. Verify all formerly unreachable wrong_job_*/wrong_handoff_* controls remain independent and now execute. Go semantic guards must reject relevant hidden/dead/closure/order/alternate-consumer mutations while accepting inert strings/comments, formatting and local renaming. Shell guards must inspect semantic structure where claimed and be backed by safe behavioral vectors, not whole-function equality.
Latest fixture: inspect the authenticated 3941-byte repair diff and actual final file. Require an independently allocated physical source directory outside staging/results; exclusive regular-file creation; deterministic nonempty inert bytes; exact owner-only mode; checked write/chmod/close; close before capture; and no source/execution/host dependency. Verify every shared-helper caller uses fake clients and does not execute/qualify the fixture as a real supervisor. The regression must check the actual helper through unchanged production capture, independently specify bytes/digest, test separation/regular type/link count/mode, and reject the old /bin/sh setup. Do not infer this from the implementation report alone. Test-only fixture construction must not weaken production no-follow or broaden test-support claims.
Public privacy and operator retirement: preserve fixed public messages, provider-body exclusions, log restrictions, successful receipts/profile/handoff semantics, and existing unbounded surfaces where the governing plan explicitly leaves policy open. Inventory split/equals historical flags, nested/top-level routes, existing-host tombstones, exact exit/stdout/stderr, privacy checks before helper/path initialization, no side effects on refused routes, and preservation of unrelated live routes. No real operator helper execution is authorized outside existing mocked/test-local coverage.
Artifact and commit scope: classify all 75 paths as source/test/doc/script/etc., sensitivity, intended inclusion, and proposed commit boundary. Classify caches, .pyc, databases/WAL, archives, build products, egg-info, OS metadata, symlinks and unexpected executables before judging them. Do not read/expose secret-bearing ignored state or indiscriminately package private config/logs. No blanket cleanup. No source archive, generated evidence, credentials, or ignored artifact belongs in the proposed stage set.
5. Authenticate and adjudicate native evidence without contacting either host
Read original JSON streams and command/child-environment records, not only summaries. The latest report binds:
Evidence	Size / digest
Local admission JSON	601783 bytes / 964e9e79d0ab8dedddb8e06c721b6bed1ab9aa1958c8391a17fba0e409c27d4f
AMD64 admission JSON	606983 bytes / b488b227830ef77566fe6747f9d36a17052d1f3f63e316b5d74f993eba2e11a4
ARM64 admission JSON	607057 bytes / 79d53bcf74b1d9cffada12b7cc12cfcaec90a4aeeb8e242d77924b6356662d56
AMD64 returned registry	42 files / 13270434 aggregate bytes / b18b54f77831503adb0e27b3b89e3ebfaab90ffb2fe30c7af7a1fc34054fe5c1
ARM64 returned registry	42 files / 13270709 aggregate bytes / c282d9d6d9f779757c518950097bf3c505f39e3972a6e767c0e1ba065d137107
Corrected native helper	43544 bytes / 1e4e19b99d8f16ff173f6eebda16b63acd740c05fd711e779de2d7b2a0019798


The report states local 617 paths passed; each Linux architecture 616 paths passed; no failures/skips; all 81 required native paths explicitly passed. Recompute those results with a small independent retained parser, separate from the implementation harness. Validate actual command exits, complete JSON, terminal package outcomes, run/pass/fail/skip sets, unexecuted descendants and required inventory. Count test paths, not package events or independent defects. Reconcile platform-dependent inventories rather than demanding equal Darwin/Linux totals: the supplied source has three Darwin-only custody tests and two Linux-only custody tests, but inspect the actual authenticated lists.
Verify the old 69-row required inventory is the exact prefix of the new 81, with no deletion/duplication. Inspect the twelve additions and all eight previously unexecuted golden negative controls. Verify local portable requirements and Darwin tests independently; Linux-only tests must not be counted as local passes.
Verify both native invocations used the same frozen 352-file source/archive, matching effective native architecture and explicit installed Go 1.26.5, offline/read-only module settings, physical native-local roots, actual existing / to /proc crossing, and no host-mounted source. Cross-target go list children of existing typed guardrails are structural checks, not evidence of another native execution.
For GOENV, independently check the actual helper delta and recorded process/output distinction: selected child environment GOENV=off, successful selected go env -json, exact required key set, and an explicitly present GOENV key with empty value. Missing keys/records must fail. Inspect the authenticated Go source excerpts and predicate negative controls; do not require a network lookup or rerun the old failed suite. Preserve the old helper and old raw boolean/history.
Review the rejected AMD64 transport attempt: corroborate argument-parsing failure before Go/source/cache activity, unchanged helper/candidate bytes, and exactly one complete accepted suite on each architecture. Also retain the earlier failed excerpt command as execution history. A pre-harness rejection is not a second test invocation, but its claimed boundary needs evidence. Do not launch another run solely to erase an invocation defect.
Verify returned-file identities, source/toolchain/module-cache pre/post comparisons, task-root cleanup records, ARM64 normal start/stop ordering and final Stopped/config equality, and final live-repo preservation. These support historical task closeout, not current live-host health or production deployment readiness. When underlying raw evidence is unavailable, state the exact unverified claim and decide materiality; do not claim to have authenticated absent files.
The retained earlier failed packet, only if needed for lineage checks, is:
/Users/ds/Downloads/ES-native-linux-validation-20261004T2315Z-mhwpie03.zip
(259237 bytes; fcb0a00e06687190072049707b9ec2e6520dc20a17190702b925a0d4618c33d1; internal manifest 236597f780be27fb0266a83f4d53077942c2767d2f48066d21f72ff6bcff2610). Its full private root is /private/tmp/ES-native-linux-validation-mhwpie03. Review only relevant authenticated lineage; do not reopen unrelated historical campaigns.
6. Fresh local validation on the audited bytes
This audit explicitly refreshes the full-repository and race evidence omitted from the localized repair. It consolidates the older repeated package-by-package full-suite ladder into one complete default-temp run, one complete physical-temp run, and one admission/app race run. Full-suite JSON must demonstrate coverage of the focused obligations; omission is not accepted merely because an aggregate command passed. No native rerun is required for unchanged, authenticated bytes.
After read-only inspection confirms test side effects stay within existing safe harnesses, use the installed local Go 1.26.5:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Reported executable SHA-256: 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Matching gofmt SHA-256: 3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81.
Authenticate both against retained records. No installation or fallback toolchain.
Preserve the normal host PATH and prepend the versioned Go bin; do not replace PATH with an overly narrow list that loses existing Python/OpenSSL/compiler tools. Use process-only GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, GOTELEMETRY=off, and explicit task-local build/Go-work caches. Use the existing local module cache, with no downloads or module edits. Unset outer GOOS/GOARCH and record effective native settings. Record only selected safe environment keys, not an inherited environment dump.
Preserve the inherited normal macOS TMPDIR for the default run. Allocate its scratch using that normal root; do not substitute /private/tmp or hide the host path spelling in this first invocation. Use /private/tmp only for the separately labeled physical run and race run. Do not globally inherit CGO_ENABLED=0 from the Linux harness into race validation. Record the ordinary native local CGO setting for non-race runs; race requires the explicitly enabled existing local C toolchain. Missing prerequisites are validation blockers, not permission to install or silently skip.
From the repository root, parent alone executes and captures real exits/stdout/stderr without a failure-masking pipeline:
# GO_BIN is the authenticated absolute executable above.
"$GO_BIN" version
"$GO_BIN" env -json GOOS GOARCH GOVERSION GOROOT GOMODCACHE GOCACHE GOTMPDIR GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS CGO_ENABLED
"$GO_BIN" mod verify
"$GO_BIN" list -m all

git -c core.fsmonitor=false diff --check

# Invoke authenticated gofmt -l once over each modified/untracked Go path,
# with safe argv handling. No -w. Any output is a formatting finding.
# Run bash -n on each candidate .sh file, also without executing it.

# 1. Inherited normal macOS TMPDIR; no physical-temp substitution.
"$GO_BIN" test -json ./... -count=1

# 2. Separate complete physical-temp validation.
TMPDIR=/private/tmp "$GO_BIN" test -json ./... -count=1

# 3. Separate synchronization-sensitive validation with existing tools only.
CGO_ENABLED=1 TMPDIR=/private/tmp "$GO_BIN" test -json -race ./es/admission ./es/app -count=1
Select and record environment/cache roots explicitly per invocation; commands above are the fixed test scopes. Do not add test filters, short mode, custom tags, a new timeout, retries, or assertion overrides. Root/admission/app coverage is included in ./...; no duplicate focused run is needed merely to reproduce another output layout. Extract explicit pass events for the new fixture regression, the portable native-required inventory, Darwin-specific custody tests, resolved-plan/Go mutation guards, shell retirement/parser mutation guards, and relevant root doc contracts. Native Linux requirements remain satisfied only by their authenticated native logs.
For all packages report failures, skips, missing required paths, malformed streams, and terminal outcomes; distinguish legitimate platform exclusions from skips/missing execution. Do not demand an invented fixed full-repository total. Do not run live/manual smokes, helper installation, database migrations against real state, or broad scripts outside existing test-controlled behavior.
Retain every initial failure. A later physical-root pass does not erase a default-root failure. If a command fails, classify source defect, test-harness defect, environment/toolchain deficiency, or genuine unrelated baseline issue with evidence. Do not repair or rerun it. Other already-authorized independent validations may proceed only when safe and meaningful; none can turn a failed required gate into ACCEPT. If a confirmed earlier semantic blocker makes expensive validation non-useful, it may be left unexecuted with an explicit BLOCK and exact skipped commands. All three fresh validation gates are required for ACCEPT.
7. Closeout, verdict, and proposed commit gate
Reproduce the exact full-source/candidate/diff/status/index/branch/HEAD/worktree identities at closeout and require equality with the audited opening. Audit-created scratch must remain outside repositories. Clean only authenticated task-created disposable caches; retain report/log evidence. Never clean pre-existing or unrelated state. Unexpected repository changes invalidate the unchanged-audit claim; report rather than deleting them to manufacture equality.
Return one primary verdict:
- ACCEPT: exact provenance, complete substantive coverage, independent evidence adjudication, all mandatory fresh local gates, coherent commit boundary, no critical/high/commit-blocking medium finding, and preserved bytes.
- BLOCK: bounded repair, missing required validation/evidence/coverage, or unresolved authority/contract decision prevents acceptance. Identify which and why.
- REJECT: the candidate is fundamentally incompatible with the selected governing contract and cannot be repaired within the stated bounded approach; justify precisely.
- AUDIT_PROVENANCE_MISMATCH: qualifying source/evidence/recipe identity is absent, mismatched, unstable, or changed by the audit. Stop correctness acceptance.
Secondary disposition should distinguish ES_ACTIVE_CANDIDATE_FINAL_AUDIT_PASS_COMMIT_READY, ES_ACTIVE_CANDIDATE_FINAL_AUDIT_REPAIR_REQUIRED, ES_ACTIVE_CANDIDATE_FINAL_AUDIT_VALIDATION_BLOCKED, or ES_ACTIVE_CANDIDATE_FINAL_AUDIT_CONTRACT_DECISION_REQUIRED as appropriate. No success label for partial work.
Every material finding needs severity/type, exact current path:line/symbol, governing rule, evidence, impact, patch-versus-pre-existing classification, repair owner/surface, and necessary validation. Keep strategic observations separate from current-contract defects. Do not inflate formatting/transport history into production defects or treat hashes/tests as a security proof.
Return a consolidated report with:
- exact target/recipe identities and opening/closing equality;
- all 75 paths classified and reviewed, relevant unchanged dependencies, actual reviewer coverage and disagreements;
- M1–M4 and Linux fixture issue closure or remaining defect;
- semantic ownership, custody/retention, finite inventories, oracles, operator/privacy and artifact findings;
- independent native-evidence results and transport/GOENV adjudication;
- exact fresh validation commands/environments/exits/coverage, failures/skips/unexecuted work;
- no hidden authority/security/platform/publication widening, or exact findings where present;
- an exact proposed stage set and coherent commit boundary/subject, without staging;
- required future staged-blob/mode/size equality and post-stage review against this same accepted candidate, without treating it as authorization to commit;
- explicit uninspected areas and separate provenance, validation, and implementation confidence.
An accepted audit permits a later commit-gate handoff only. It does not perform or authorize staging, commit, push, deployment, live validation, a planning-document status edit, or another tranche. Do not require repetition of every identical native/full suite during that future gate by habit; state which existing source-bound evidence remains applicable and what additional validation is genuinely required by owning policy. Any changed candidate bytes need revalidation/re-audit rather than automatic publication.
Retain the full audit report and a compact safe review packet under /Users/ds/Downloads/, using unique names. Include the report, complete candidate/path classification, exact verified manifest/recipe references, relevant source findings, independent evidence-parser output/source, fresh test logs and coverage summaries, and opening/closing comparisons with a simple self-excluding per-file size/SHA-256 manifest. Reuse authenticated prior packet references rather than copying toolchains, module caches, source archives, private configs, secrets, VM disks, or indiscriminate historical logs. Return exact packet path, size, SHA-256, manifest digest, and report path.
Stop. No repair or publication effect in this audit conversation.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
