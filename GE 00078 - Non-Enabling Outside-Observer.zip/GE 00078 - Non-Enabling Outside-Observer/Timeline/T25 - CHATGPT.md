**Proceed with a bounded assurance-integration repair, leaving the nsfs production implementation unchanged.** Codex correctly preserved the failed freeze, but the next task must close **two issues**, not just update three numbers: the stale semantic-call inventory and the returned required socket-test skip. Neither calls for another architecture round or environment-restoration cycle. :chatgpt-content-reference{index="0"}

**Send this to the same implementation/repair Codex conversation: :chatgpt-content-reference{index="11"}[Assurance repair and integrated validation prompt](sandbox:/mnt/data/ES_NSFS_Assurance_Continuation/ES_NSFS_Assurance_Repair_and_Validation_Prompt.md).**

## 1. The guardrail failure is an integration omission—not an evaluator defect

The report identifies the exact mismatch:

| Linux call inventory | Expected | Observed | Addition |
|---|---:|---:|---:|
| `builtin.len` | 47 | 54 | +7 |
| `fmt.Errorf` | 132 | 134 | +2 |
| `strings.HasPrefix` | 5 | 6 | +1 |

It attributes those additions to the bounded nsfs parsing logic and explicitly says the guardrail operated as designed. Updating `workstream_c_guardrails_test.go` was already authorized as a contingent surface; it was simply omitted before freeze. **This was not blocked on permission to touch another file.** :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The repair must therefore **justify and update the expected inventory**, not change production code to recover the old counts. Codex must trace the ten additional call sites to their enclosing functions, resolved call objects, and roles in the guarded closure, then verify that the rest of the inventory remains unchanged. The expected values must remain independently specified—not generated from whatever the current implementation happens to contain.

The existing mutation and helper-indirection controls must still reject unapproved changes. No removal of Linux views, relaxed comparisons, excluded helpers, or weakened traversal is authorized.

There is also a straightforward prevention measure. In the authenticated historical source, `TestTrancheB1FiniteSemanticShapeGuardrails` loads **Darwin/ARM64, Linux/AMD64, and Linux/ARM64 production views during its local invocation**. Its Linux inventory can therefore be checked before a final Darwin freeze; it does not require waiting for the complete native suite. The relevant anchors are `es/admission/workstream_c_guardrails_test.go:249–289,2217–2229`. :chatgpt-content-reference{index="12"}[Inspected source excerpts](sandbox:/mnt/data/ES_NSFS_Assurance_Continuation/ES_NSFS_Assurance_Review.md)

The new prompt makes that guard and its mutation controls **mandatory pre-freeze checks**. The previous focused checks covered the Tranche A guard, but did not catch this B1 omission. :chatgpt-content-reference{index="3"}

## 2. The required socket skip cannot be accepted as a non-claim

The latest report records an applicable required-path nonpass for:

```text
execution-substrate/es/app
TestProofCodexShimAcquiresCredentialAndMutatesWorkspace
```

It calls this the known default-`TMPDIR` Unix-socket skip. However, the preceding accepted local-validation record explicitly states that this formerly skipped identity **passed**, with 37 full-suite skips and 36 race skips. Its required-pass obligation was not subsequently waived. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

**“Known” explains a limitation; it does not satisfy a required test.** Merely changing the inventory counts would leave this second local-completion blocker.

The latest raw stream, attempted path, child environment, and runner must establish exactly why it returned. I have not inferred that attribution from the older path-length incident.

The historical source nevertheless shows the fragile dependency clearly: `proof_codex_shim_test.go:40–42` places the socket beneath `t.TempDir()`, while lines 190–196 turn every listener error into a skip. :chatgpt-content-reference{index="13"}[Source excerpts](sandbox:/mnt/data/ES_NSFS_Assurance_Continuation/ES_NSFS_Assurance_Review.md)

The selected repair is a **fixture-owned short physical socket directory**, independent of the caller’s test name and ordinary `TMPDIR`, where inspection confirms that dependency remains. This is preferable to repeatedly adjusting unrelated runner-directory names.

The prompt authorizes the narrow change in `es/app/proof_codex_shim_test.go`: unique private allocation, actual socket use, precise error handling, and cleanup of only the test-owned objects. It preserves the ordinary default-lane `TMPDIR`, all other workspace paths, and the credential-flow and mutation assertions. An invalid generated socket path must not be converted into a successful capability exemption.

The **actual proof-shim test**, not merely a generic short socket probe, must pass under default, physical-temp, and race environments before freeze.

## 3. Keep the production progress—but do not overcredit it

The focused AMD64 result is useful: the report records **54/54 passes**, including all four new nsfs regression parents, 25 static children, and the eight previously missing golden children. It also records observation of four live non-path nsfs records. That supports the bounded development correction on that host. It is not a complete native gate or actual mounted-alias proof. :chatgpt-content-reference{index="6"}

There is no reported reason to change the parser again in this continuation. The production distinction between accepted opaque metadata and pathname-coordinate eligibility remains intact, as do descendant-mount checks and refusal of a descriptor-selected opaque root. :chatgpt-content-reference{index="7"}

Accordingly, repository writes are confined to the two test files above and, where needed, a short `PLANS.md` scope/status entry. All production bytes must remain equal to the opening candidate. A newly discovered production defect stops the task rather than silently expanding that scope.

**The failed default lane cannot be salvaged by replaying it through a corrected evaluator.** Its Go test actually failed, and its required socket test skipped. Repairing repository test source creates a successor candidate that needs fresh execution. :chatgpt-content-reference{index="8"}

## 4. Complete one integrated validation sequence

After both issues pass their pre-freeze checks, the prompt freezes the successor source, test expectations, runner, evaluator, and required inventory, then executes:

**Default full suite → physical-temp full suite → admission/app race → complete AMD64 admission suite → complete ARM64 admission suite.**

The existing 267-row inventory and its historical prefix remain preserved. Any missing guard or regression identities are appended with source-derived applicability. Every test/package failure blocks, even outside the selected required inventory; every applicable required skip or missing child also blocks. The number **38 is not a target skip allowance**. :chatgpt-content-reference{index="9"}

There is no automatic repeat of the already-passing focused AMD64 development transfer. The forthcoming complete native suites supply the outstanding final evidence for the successor.

I have also changed one operating rule: **an in-scope test or runner defect stops its validation generation, but need not automatically end the entire engineering task.** The prompt permits one explicitly closed and superseded generation for a causally demonstrated defect within the authorized scope. All failed records remain unchanged; source changes require a new freeze and the full successor sequence. Production defects, authority conflicts, unexplained drift, inadequate access, and unsafe cleanup still stop the task.

This preserves exact-byte evidence without making another routine inventory or fixture correction require another user relay.

## Inspection boundary and remaining gates

I fingerprinted the attached report and checked the cited historical source members against their supplied manifest. **The latest review ZIP, current parser/test bytes, runner, and raw streams were not attached**, so their execution and preservation claims remain Codex-reported. The next task authenticates those retained files before editing.

The next return should include the **review ZIP alongside the report**, so the cumulative production repair can finally be reviewed directly here rather than through successive summaries.

Successful completion still means **local and native validation complete; external gates pending**. Actual mounted-helper cases, running-deployment compatibility observation, the bounded supported-local consumer/operator proof, fresh independent audit, and the exact-byte commit gate remain open. None is authorized or waived by this continuation. :chatgpt-content-reference{index="10"}

**Sources:** attached nsfs report, preceding local-completion report, and :chatgpt-content-reference{index="14"}[manifest-checked historical source excerpts](sandbox:/mnt/data/ES_NSFS_Assurance_Continuation/ES_NSFS_Assurance_Review.md). No repository code, tests, hosts, or VMs were executed here.

**Confidence: 0.96 in this continuation.** The inventory correction and required-skip objection are strongly supported. Current implementation correctness, live provenance, and complete native acceptance remain unestablished.
