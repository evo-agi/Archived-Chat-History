ES mounted helper — SB-4 witness, historical lineage, and engineering-closeout correction
Objective and decision
Continue in the existing implementation/preparation conversation, not the independent audit conversation. Complete one narrow, external-only successor correction of the two owner-disclosed blockers and the handoff decision that failed to detect them.
The prior task's final human closeout explicitly rejected the successful value in final/HANDOFF.json. Preserve that contradictory artifact as historical evidence of an unearned engineering-success projection. Do not overwrite, delete, reseal, rename, or retroactively correct the old report, source, matrix, records, packet, companions, or handoff.
Latest independent endpoint, unchanged:
ES_MOUNTED_HELPER_ACTION_CUSTODY_RECEIVER_REAUDIT_INCOMPLETE.
Current owner disposition: engineering closeout blocked. This is not a new independent audit and not a claim that its recorded passing tests failed. The missing SB-4 case is an unfulfilled assurance obligation, not yet a newly demonstrated production defect. The historical matrix mismatch is a preservation violation in the external source, not evidence that the ES repository changed.
Selected continuation:
1. Add the exact missing SB-4 control: channel failure with stdio demonstrably acquired and released.
2. Restore the historical matrix byte-for-byte in the NEW successor from the independently authenticated historical source. Keep all new owner responses separate.
3. Integrate both obligations into the existing pre-freeze/pre-package/handoff checks; do not let successful packaging and invocation completeness alone produce engineering success.
4. Run fresh affected local validation against the corrected test/source generation, then publish the acyclic packet and accessible companions.
5. Stop for a fresh cumulative independent re-audit. No audit, runtime gate, or product acceptance is performed automatically.
This is a new bounded authorization, not permission to continue editing the exhausted prior generation in place.
1. Authority and effects
Authorized: sole-parent ordinary-user authoring in one fresh private external directory under /Users/ds/Downloads; inspection of named retained inputs; read-only ES guidance and provenance; local external-tooling unit/race/vet/compile and recorder/checker controls; task-owned ordinary-file/socket tests within the previously inspected scope; evidence authoring and packet construction.
Not authorized: any ES repository write, script, test or build; changing retained roots; external non-test runtime implementation changes; internal/safemech, safe-control entry or dependency changes; changing proof drivers or diagnostic instrumentation; host/network/SSH access; privilege/sudo probing; device or ioctl access; formatter, live supervisor/worker, safe executable, Linux test binary, normal proof or diagnostic proof execution; loop, namespace, mount, real signal experiment, UID/GID/capability transition; installation/download; policy approval; gateway/signer/watchdog/lease work; services, Docker/Lima/VM operations; Git writes, staging, commit, fetch, push, deployment, or cleanup of old/user state.
Ordinary local test processes and bounded ordinary-file/socket fixtures are permitted. Their execution is not privileged/Linux-runtime evidence. No subagents may write. Normal owner source/test review is not independent audit. No new architecture, generic acceptance service, attestation hierarchy, or expanded resource framework is selected.
2. Authenticate the two baselines before edits
A. Preserved rejected five-block generation
Root:
/Users/ds/Downloads/ES-mounted-helper-five-block-repair-Vtpm8n
- Report: ES_MOUNTED_HELPER_FIVE_SOURCE_BLOCKS_REPAIR_REPORT.md, 33,144 bytes, SHA-256 83c39004f75053fc7fcf1ba99326987be1d0e5375a7e10c3d5ebcce8c4d5127f.
- ZIP: final/ES_MOUNTED_HELPER_FIVE_SOURCE_BLOCKS_REPAIR_REVIEW.zip, SHA-256 e09a514e35daf5ae03c5ccca04a23545cb2ddde0bc196486b75da448b0b7b374.
- Manifest: final/ES_MOUNTED_HELPER_FIVE_SOURCE_BLOCKS_REPAIR_MANIFEST.tsv.
- Actual final/HANDOFF.json, stage D/E/F invocation envelopes, raw streams and final/companions/packet-verification.json. Read and hash their actual contents; no full identities for these objects were supplied in the latest closeout.
- Reported source: 125 members; manifest 19,426 bytes, SHA-256 597d96698606aa36948de07760e654753b70b47042ffe0655573ecd791b779fd.
- Reported selected inputs: 105 members; record 21,567 bytes, SHA-256 587375166d0db0a9682986468b5daab5c3cba1db7990cff223cae2ca3a71fa8b; canonical-row digest c00675e67452de9b0fd7329fd176f292c25f957591267fe74dcb5f51c318f25a.
- Reported final validation decision: 18,517 bytes, SHA-256 c5e6d5078d616411acd93091a4f592071cffed062d3f856cfe48ceef6b679aef.
The supplied owner correction says:
- the required channel error with stdio released control is missing; the existing channel-error case leaves stdio unknown;
- the report overstates the cross-product coverage;
- four rows in the protected historical matrix changed;
- the historical matrix digest has prefix/suffix d9a7c54c…f8fa2a, while the rejected generation has bb7b7e26…ef60d3;
- C–F completed mechanically, but the successful handoff value is unearned;
- both permitted final-source generations were exhausted and no third was created.
These are a supplied post-seal owner correction. Preserve it in the new task's predecessor-disposition record, labeled as a relayed owner statement. Confirm its source/evidence facts from the actual packet. Do not silently treat the earlier pre-packaging narrative as the controlling closeout. Do not expand abbreviated matrix hashes by guesswork.
B. Historical matrix source and latest independent audit
Historical engineering root:
/Users/ds/Downloads/ES-mounted-helper-action-custody-receiver-repair-9AMkPq
- ZIP: ES_MOUNTED_HELPER_ACTION_CUSTODY_AND_RECEIVER_REPAIR_REVIEW.zip, 1,627,466 bytes, SHA-256 4bcd12e4661f58b84a5c4f0a9ac9ab4a7c3f3bc127b1d6f5eb14faff5e9880da.
- Report: 13,222 bytes, SHA-256 dda3cdf87fe2438910097b417626c109ca216a0aaf17ce48b91d23a30e57737d.
- External/embedded manifest: 52,139 bytes, SHA-256 485f113e3d6cbf891dde82d3edbf5e5b0889892ac5440fa4d6a6b857f81b857c.
- Historical source: 119 members; manifest 18,496 bytes, SHA-256 962a05ad558fb222c02cf3592ad9df90c942d93d7fc182e415e113dd4ddea22a.
Latest independent audit root:
/Users/ds/Downloads/ES-action-custody-independent-audit-a9ijy52q
- CONSOLIDATED_AUDIT_REPORT.md, 17,386 bytes, SHA-256 a16654e8bf6413e656ee04e7738f366f9bd28427a943d2237ac85aeb0f3687f8.
- ES_ACTION_CUSTODY_RECEIVER_INDEPENDENT_AUDIT.zip, measured and reported as 296,029 bytes, SHA-256 0d69816e983d1d64405984078e1efa7c781ff2f745340caecd250e98c4d837a2.
- Relevant exact SB-4 source excerpts, specialist findings, immutable historical matrix, and evidence-gap records.
Authenticate archive membership, CRC, safe unique relative paths, regular types, stored modes, sizes and hashes before extraction. Reconcile ZIP, source-authoring and private-extraction modes rather than normalizing historical objects. Locate the actual historical source/docs/FINDINGS_CLOSURE_MATRIX.md member through the authenticated manifest, derive its FULL digest and raw bytes, and bind that exact original for restoration. Distinguish it from any separately authored current audit matrix with legitimately different judgments.
Do not guess the four altered row IDs. Produce the exact original/rejected delta, classify each changed row, and locate the authoring/checker path that allowed the change. If the reported anchors or historical target cannot be reconciled, stop before adopting an arbitrary baseline.
Derive the new authoring source from the authenticated 125-member rejected generation, NOT the 119-member predecessor: preserve the other five-block repairs. Use a fresh /Users/ds/Downloads/ES-mounted-helper-sb4-closeout-correction-<unique> root. Record exact old artifact fingerprints and the two disqualifying conditions without altering the old root.
3. ES preservation and governing scope
Repository: /Users/ds/Repositories/Execution Substrate/ (read only).
Read current AGENTS.md, relevant PLANS.md and owning capability/lifecycle guidance for the product boundary. This is not a new ES architecture pass. Read external owner/specification files, relevant source and tests, required inventory, validation/evaluation/capture scripts and C–F caller paths together.
Expected preserved ES target:
- branch/upstream: trunk_dev / origin/trunk_dev;
- HEAD: b92bd9884106154d25342e1573dcc4c312311436;
- tree: cdd4e44bac15c1952d70997143040644361f0bb1;
- parent: 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- source: 358 rows, e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e;
- candidate: 83 rows, 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2;
- status: 83 rows, a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c;
- tracked diff: 2,407,274 bytes, 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1;
- index: 39,949 bytes, 9ca13234f248fccb29e8136168bb577c49c3fcf3c23b3f0d23b2bc1bd3aac569;
- empty cached diff; zero staged/conflicted paths; no active operation; six worktrees.
Reuse the inspected narrow preservation serializer with optional locks, fsmonitor, external diff/textconv and filter execution disabled as required. Record exact opening/closing source and repository facts. Precisely report same-object historical app-owned ref-name changes; no blanket ref exemption. Target-bearing mismatch blocks inherited target claims.
4. Add the missing control without altering runtime behavior
Primary inspected anchor in rejected source:
source/tooling/internal/proof/worker_start_linux_test.go:16-197.
Relevant SB-4 production anchors from the report:
worker_linux.go:122-279, process_custody.go:42-45,244-418, and the existing controller/receiver projection. Confirm current lines before use.
Add one clearly identified case that exercises the real worker-start sequence with primitive effects substituted. Select a genuinely reachable channel-failure boundary after stdio acquisition; do not assert that an earlier pre-stdio failure has already released a never-acquired descriptor.
Independent assertions must establish:
- parent stdio was actually acquired under the test's substituted acquisition step and its identity recorded;
- its numeric ownership is invalidated before exactly one close attempt;
- that close succeeds, and returned custody says released, not unknown, not-held, held, or release-uncertain;
- the distinct channel failure remains the primary/error history and its actual custody/release outcome remains visible;
- known released stdio does not erase channel uncertainty, and channel failure does not erase the known stdio release;
- child stdio references follow whether start actually succeeded and whether child/group absence was separately established; do not create or release fictional child references;
- terminal absence follows the complete actual custody predicate. Do not demand universal absence or universal nonabsence from an error alone;
- later projection/cleanup cannot retry the released stdio number or replace its state with an unobserved value.
Retain the reciprocal stdio-close-error/channel-released control and the existing failed-start -> controller/freeze -> rehashed receiver-refusal witness. Map the exact predecessor-prompt SB-4 obligations individually (before/after acquisition, closing call sites, both cross directions, nil/partial worker, later cleanup/inventory/serialization, and no numeric retry). This is a finite existing obligation set, not all imaginable state combinations.
Do not satisfy the missing case by directly assigning final custody in a fake return object, renaming the existing unknown-stdio test, lowering required coverage, or suppressing its assertion. Inspect the actual setup and assertions; a test name is not semantic evidence.
Keep applicability honest. If this worker-start case is Linux-selected, add it to the explicit Linux required declaration/build set and compile it; this local-only task does NOT execute it. Portable shared-custody/projection assertions may execute locally, but cannot be presented as execution of the Linux startup test. Do not authorize remote Linux merely to label the new row passed. Evidence labels must distinguish run/pass, compiled-selected, source-bound, and unexecuted.
No non-test runtime source edit is authorized. If the missing case reveals a genuine implementation defect, retain the exact failing source and result and stop with that defect. Do not weaken the control to remain inside scope.
5. Restore historical lineage; keep current interpretation separate
In the NEW successor only, restore source/docs/FINDINGS_CLOSURE_MATRIX.md to the complete authenticated historical bytes and declared authoring mode. Preserve all 64 historical rows and their order, punctuation and meaning; do not merely preserve row count or IDs.
Place current SB-1…SB-5 owner responses in the existing source/docs/FIVE_SOURCE_BLOCK_OWNER_RESPONSE.md and current coverage/response records. Those are owner responses pending independent review. Historical immutability does not freeze future independent judgments; it preserves what the prior records actually said.
Remove or redirect any current authoring operation that rewrites protected historical rows. Do not edit any original input root. Verify restoration against the original independently authenticated packet member, not a manifest regenerated from the modified successor.
Correct the NEW report's preservation and SB-4 coverage claims. Preserve the old false claims verbatim as history, identified in the predecessor-disposition record. There is no need for a new lineage schema, another expanded findings matrix, or a new documentation hierarchy.
6. Make the existing acceptance checks detect this exact false success
Inspect why the existing evaluator/handoff could emit the success token despite these two unfulfilled obligations. Treat this as an engineering-gate integration defect; do not redesign the privileged runtime receiver or its authority protocol.
Before source freeze and again before payload closure, existing checks must bind:
1. the independently pinned historical matrix to the actual successor matrix bytes;
2. the fixed SB-4 requirement to an explicit source-mapped witness, its assertion review, applicable declaration/build selection, and applicable recorded execution or compilation evidence;
3. all other existing required controls and previously selected composed witnesses without loss;
4. the exact source/test/requirement/validator generation, so a result for the rejected source cannot satisfy the successor;
5. current invocation completeness, preservation and packet/companion checks.
Do not derive the required obligation away from whatever tests happen to exist. The independently fixed requirement must remain required when its test or mapping is deleted. Machine checks establish binding and declared coverage; they do not replace review of what the assertions actually prove.
Exercise the actual existing completion predicate on disposable copies before expensive final validation. Required adversarial inputs:
- all structural/package checks pass but the SB-4 witness is missing;
- the obligation is deleted from a discovered inventory;
- matrix has the same 64 IDs/order and four content mutations, with regenerated current hashes;
- each condition alone, and both together;
- a coverage/check result from the wrong source/test generation;
- purported pass bodies without a required completed invocation;
- a valid restored matrix plus the genuine witness and complete bound evidence.
Use prepackage synthetic records only as checker controls, never as validation observations. The actual sealed rejected packet may be replayed as DATA for a negative; do not execute its old handoff producer or overwrite it.
The final existing handoff decision must require both engineering-acceptance checks and C–F integrity/invocation checks. A clean CRC, complete manifest, accessible companions or old status: pass value alone is insufficient. Reconfirm the exact selected source/matrix/witness bindings from the closed packet before issuing engineering success. Keep the completed postpackage invocation records external to avoid a hash cycle.
HANDOFF.json remains an evidence/decision projection. Its location does not grant correctness, independent acceptance, policy or execution authority. No new downstream consumer, signer, registry, gate daemon or generic assurance platform is required.
7. Allowed touched surfaces and freeze discipline
Before edits, record a compact intended delta:
- the actual existing worker-start test file and, only if needed, existing portable test/fixture file for its projection assertions;
- historical matrix restoration in the successor;
- existing current owner-response/coverage/status documentation and new report;
- the smallest existing inventory/evaluator/handoff integration and their tests needed for section 6;
- exact task-root rebinding in already inspected validation/recording scripts where unavoidable.
All external runtime .go files other than _test.go remain byte-identical to the rejected 125-member source. Protect ES, safemech, safe entry, modules, drivers, overlays, product unions and all historical inputs. Do not reopen SB-1/SB-2/SB-3/SB-5 code, receiver policy, budgets, eighty-action successful language or nineteen-case grammar.
Normal in-scope development controls may run before freeze with failure records retained. Confirm both known blockers are closed before final execution. Permit one initial and at most one causally corrected final-source generation in THIS fresh task. Never keep editing a sealed generation in place. A newly discovered production defect or scope/authority conflict stops; a versioned pure analysis/packaging correction may replay unchanged valid execution and must itself be recorded. No unchanged failed test retry, indefinite generations, or automatic audit.
8. Fresh affected validation, not a product-validation restart
Pinned Go:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
SHA-256 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Reuse the inspected recorder and offline runner. Before first Go invocation establish task-private HOME/config/telemetry/cache/temp/GOPATH, with authenticated read-only dependencies. First Go invocation is recorded go telemetry off in that isolated context. Require effective off/private telemetry, empty effective GOENV, GOTOOLCHAIN=local, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly. No global settings or old telemetry inspection, no download.
Freeze complete source and incremental/cumulative deltas, current selected input recipe, requirement crosswalk, scripts/recorder/evaluator/checker and exact absolute command plan. From the new external tooling directory only:
"$GO" version
"$GO" env -json <retained explicit native allowlist>
"<pinned-gofmt>" -d <exact touched Go test files>
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" env -json <retained explicit Linux allowlist>
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" test -c -o <fresh Linux proof unit-test artifact> ./internal/proof
"$GO" version -m <fresh Linux proof unit-test artifact>
Resolve placeholders into the frozen plan from authenticated current contracts. Do not execute the Linux test artifact. Preserve normal no-test package terminals; every applicable required test/child/package must have the appropriate terminal. Linux-only requirements require verified selection/compilation, not fabricated Darwin runtime passes. Crosswalk the prior 1,016 terminals/166 named requirements, older meaningful requirements, all five composed witnesses, and the explicit added SB-4 obligation; counts are observations, not targets.
Record evaluator rejected-argument, self-test and final calls; checker controls; preservation captures; packaging and reopening through the existing outer recorder with actual argv/cwd/environment/times/exits/timeouts/streams and input/output identities. Do not reconstruct events from planned commands.
Selective artifact treatment:
- Authenticate the prior supervisor A/B (6,406,024 bytes, SHA-256 a7640595e94e4cd08b75043afd246510f7e7f1e1ed1b7286efe38be1f65d9032) and its selected non-test build inputs. If they remain identical, inherit its compile-only evidence explicitly; a new test/document manifest does not itself require a new production binary.
- Safe executable: 4,497,174 bytes, c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75; exact safe import closure: 2,023 bytes, 739a10de46f4ccf3e2d341d764d651c80462c9cde53c1e6d4726c1c4c1adbbe3.
- Verify the unchanged safe entry/safemech/dependencies and actual retained bindings; inherit its seven old Linux observations only for those same bytes. No remote rerun.
- Normal proof: 23,583,914 bytes, bc4ff667d9280ee8ec671fc60bc23ec4e32e256b5084436588bcfb78292f4d0d; diagnostic: 23,605,547 bytes, e2fc7baf9a7a9286f97dc3dbb95b74bba44c0b1d14d75c544b1f466d3d81edfb. Preserve their historical compile-only level and unavailable-current-body qualification. Do not rebuild them to erase that limitation.
If an affected supervisor/safe compile-input binding truly changes or required current binary bodies cannot be authenticated, do not invent an inheritance claim. A local compile-only deterministic A/B rebuild using the exact retained recipe is permitted where necessary to establish the artifact relationship; explain the need. Unexpected protected-source drift stops. No compiled runtime artifact is executed here.
9. Publication, supersession, and completion
Retain the existing A–F shape rather than adding stages or nested packets:
A. source and exact validation/semantic obligations frozen;
B. new applicable execution, current evaluator, semantic/lineage checks, invocation completeness and closing preservation accepted;
C. corrected report and exact payload frozen only after these obligations pass;
D. externally recorded packet/manifest creation;
E. externally recorded reopen verification;
F. existing handoff verifier checks the actual closed contents, source-bound semantic and lineage decisions, and accessible completed companions before emitting an endpoint.
No future invocation is inserted into the earlier ZIP. D/E/F completed envelopes and original streams remain accessible external companions. No record hashes itself. Do not create invocation-of-invocation chains. Freeze the recorder/tooling identities and retain the actual event records.
New report must explicitly state that the Vtpm8n success flag was disqualified by the supplied owner correction. Reference the old report, packet, actual handoff and mismatch identities without changing them. Distinguish its reported passing execution from its insufficient coverage and erroneous overall success. Do not promote its matrix or old semantic decision into the new baseline.
Required handoff outputs:
- current report and complete source-containing ZIP with current tests, exact incremental delta, frozen selections, requirement/coverage crosswalk and accessible raw streams;
- restored historical matrix and independently anchored equality result, exact four-row old mismatch record, separate current owner response;
- explicit missing-control setup/assertion/source/selection/evidence record and fixed final-gate positive/negative controls;
- genuine invocation records and external D/E/F companions, final identities and completed verification;
- predecessor disqualification record and unchanged latest independent endpoint;
- artifact reuse/new build classification and exact ES opening/closing preservation.
Exclude binaries, caches, full ES source unions, secrets, device contents, images, nested archives and unrelated history. Do not clean historical/user objects. Packet integrity remains separate from semantic adequacy and independent acceptance.
Successful owner endpoint, only after all conditions actually pass:
ES_MOUNTED_HELPER_SB4_LINEAGE_AND_CLOSEOUT_CORRECTED_CURRENT_EVIDENCE_COMPLETE_REAUDIT_REQUIRED.
Otherwise return a precise current blocked result, completed observations and missing obligations. Do not emit success merely because the remaining failures were discovered after packaging. A late contradiction is retained as a separate disqualification; no historical artifact is altered.
Still pending: fresh independent cumulative exact-source review of all SB repairs and historical obligations; actual administrative/trust/storage establishment; residual policy decision; target/formatter qualification; external containment/confirmation; eleven normal/eight diagnostic mounted cases; deployment and supported-local proof; unconditional whole-candidate ES audit; separate exact-byte Git/publication authorization. None follows automatically.
For the next return, provide the report, source-containing ZIP, final handoff and named postpackage companions together, not just a success summary. This is one narrow assurance-closeout correction, not another infrastructure tranche.



















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Drag to reorder pinned navigation items


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
