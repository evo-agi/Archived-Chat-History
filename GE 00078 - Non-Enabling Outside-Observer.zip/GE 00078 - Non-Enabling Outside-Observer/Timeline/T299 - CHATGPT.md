## Verdict

The survey is strong enough to **cancel the ES implementation attempt and reopen the implementation-ownership decision**.

It is not evidence that the whole-R6J design should be implemented in `es/admission`, `es/runtimehelper`, or any other existing package. Codex found no maintained ES owner for the whole join; the accepted map assigns the twenty implementation coordinates to an external proof tree, while M23 explicitly says “no ES change.” Pasted text

The more consequential finding is provenance: the accepted M23 full-file and range identities generally match the **dirty working tree rather than HEAD or the index**. Several governing custody passages are uncommitted; only the cancellation rule was found committed elsewhere at different line coordinates. Pasted text The accepted artifact is therefore a valid artifact-design result, but it is **not a repository-baselined implementation contract**.

Do not return to Codex implementation yet.

## The missing review ZIP

I inspected the one ZIP you attached to Codex. It contains the accepted owner, checkpoint, task, identities, report, receipt, exact selected tree, and README. It does **not** contain the independent fresh-review ZIP.

Codex nevertheless reports authenticating the 30,948-byte review ZIP. Pasted text That is acceptable only if the review ZIP was already present in the Codex conversation from an earlier turn. Otherwise, that one authentication claim is unsupported.

This does **not materially weaken the main owner-survey conclusion**, which rests on the accepted map/owner and direct repository inspection. But the eventual survey evidence package must state exactly where the review bytes came from.

The response also says you clarified that no package should be created. Pasted text If you did not give that instruction, treat that sentence as an unsupported process claim and correct it in the follow-up.

## Architectural decision

The earlier “proceed with ES implementation” decision was premature. The corrected target should be:

> **The external proof tree remains reference and conformance evidence. Production ownership is decomposed across repository-native fact owners; no existing ES package owns the whole join.**

The target split should be frozen before another implementation prompt:

| Surface | Target authority |
|---|---|
| Admission intent, host staging, retained-result facts, lifecycle projection | Existing ES admission owners, limited to facts they actually observe |
| In-task launch, process and Wait facts | Runtime helper, limited to its process boundary |
| Scheduler lifecycle | Nomad/runtime lifecycle source, not reinterpreted as proof evidence |
| Outside-parent observation | A newly and explicitly named owner; currently absent |
| G/B/confirmation assembly, pair/map validation, profile interpretation | A separately named derived-evidence assembler/receiver; it derives facts but does not become their raw writer |
| External proof Go sources | Reference implementation and source evidence only—not maintained production code |
| Normative contract | ES-owned lifecycle-contract placement selected explicitly; not the external `source/docs/` path |

This is closest to the survey’s split-ownership alternative, but with an important constraint: **do not assign the whole join to `runtimehelper` or `admission` by proximity**. The survey found that current ES behavior is much narrower: no pair validator, no complete source coverage, no 421-operation ledger, no outside-parent observer, and no P01/P02/CLOSE contract. Pasted text

The external-only option is the best description of **current reality**, not the desired production target. The split architecture is the strategic target that now needs a governed map and contract migration.

## The dirty working tree is a separate gate

The survey reports 66 tracked modifications and 17 untracked files, with no staged changes. Pasted text The untracked and modified admission work appears to be coherent Workstream C/B1/B2 custody and lifecycle work, but it contains no accepted R6J implementation. Pasted text

That means the ownership correction must distinguish:

1. **Committed repository authority:** HEAD/index.
2. **Provisional current-tranche overlay:** the dirty working-tree docs and source.
3. **Accepted external artifact design:** the whole-R6J proof contract.
4. **New strategic target:** repository-native split ownership.

The artifact correction must not silently promote the current working tree into a committed baseline. Conversely, it should not discard the working-tree custody design if that tranche is intended to become current authority.

## Critical path

### 1. Export the survey evidence

The chat report is sufficient for direction, but the next artifact owner should receive a compact, source-grounded survey package. Ask the same Codex session to export what it already inspected—without reopening implementation or changing the repository.

Send:

```text
Export the completed implementation-owner survey as a compact read-only
evidence package.

Do not rerun the ownership analysis, change its findings, modify the
repository, run tests/builds, or begin implementation. Use the retained
survey evidence and exact opening/closing captures where available.

The package must contain:

- SURVEY_REPORT.md
- REPOSITORY_OPENING_STATE.json
- REPOSITORY_CLOSING_STATE.json
- ACCEPTED_ARTIFACT_IDENTITIES.json
- M23_BASELINE_PROVENANCE.json
- EXTERNAL_SOURCE_COORDINATE_MATRIX.json
- MAINTAINED_OWNER_RESPONSIBILITY_MATRIX.json
- DIRTY_WORKTREE_CLASSIFICATION.json
- IMPLEMENTATION_OWNER_ALTERNATIVES.json
- SELECTED_REPOSITORY_EXCERPTS.md
- COMMAND_LEDGER.json
- MANIFEST.json
- a fresh external reopen receipt

Preserve the report’s exact distinction between HEAD/index, working-tree
bytes, external proof bytes, current repository contracts, and
inspection-based recommendations.

Clarify the provenance of the accepted fresh-review ZIP. The delivery ZIP
does not contain it. State whether its exact bytes were already mounted in
this Codex conversation and identify the measured path. If those bytes were
not actually available, correct the authentication record without changing
the repository-owner findings.

The prior response says I clarified that no package should be created.
If that instruction was not actually present in the conversation, remove
that claim from the packaged method record. Do not infer user instructions.

If the retained survey outputs are no longer available, package the exact
chat report, command outputs and bounded excerpts that do survive, and
state the missing evidence. Do not reconstruct unobserved command results.

Return:

ES_R6_GENERAL_NATIVE_SOURCE_JOIN_IMPLEMENTATION_OWNER_SURVEY_PACKAGED

Report the package path, bytes, members and SHA-256.

No repository effect, implementation, test, commit, push, deployment or
publication is authorized.
```

If Codex can no longer export the package, proceed with the chat report as **Codex-reported inspection evidence**, not as independently inspectable repository evidence.

### 2. Correct the artifact architecture

After the survey package—or the report with its limits—is available, start a **fresh ChatGPT artifact-design owner conversation**, not Codex.

Attach:

- the accepted whole-R6J delivery;
- the accepted fresh review, when available;
- the survey package or pasted survey report.

Send:

```text
Continue as the artifact-only design owner for the repository-native
implementation-ownership correction of the accepted whole-R6J design.

Read the accepted owner and review, then the complete Execution Substrate
implementation-owner survey. Treat the survey as repository inspection,
not as an ownership decision.

The previous implementation decision is withdrawn. The accepted artifact
design is not currently an ES implementation map:

- its twenty Go coordinates belong to an external proof tree;
- M23 says “no ES change”;
- no maintained ES package owns the whole join;
- several M23 repository anchors match uncommitted working-tree bytes rather
  than HEAD;
- the current admission/runtime/result implementations are narrower and do
  not collectively implement whole-R6J.

Freeze a repository-native target ownership model before implementation.

SELECTED TARGET DIRECTION

1. Preserve the external proof tree as reference/conformance evidence only.
   It is not the maintained production owner.

2. Preserve existing raw-fact authority:
   - admission owns only admission, host staging, retained-result and
     lifecycle-projection facts it actually observes;
   - runtimehelper owns only in-task launch/process/Wait facts it actually
     observes;
   - scheduler/runtime sources retain their own lifecycle truth.

3. Define a new explicit owner for outside-parent acquisition and
   observation. Do not assign it implicitly to admission or runtimehelper.

4. Define a separately named derived-evidence assembler/receiver for
   G/B/confirmation composition, pair/map validation and profile
   interpretation. It may derive facts but must not become the hidden writer
   of raw runtime facts.

5. Select an ES-owned normative-contract placement consistent with current
   repository conventions. Supersede the external source/docs placement
   explicitly.

6. Reopen and supersede M23’s “no ES change” boundary through a named,
   versioned migration. Do not merely replace source paths.

7. Separate:
   - committed HEAD/index contracts;
   - provisional dirty-working-tree custody/lifecycle overlays;
   - accepted external artifact semantics;
   - the strategic repository-native target.

Do not silently treat uncommitted working-tree text as current committed
authority. Record which target decisions depend on that overlay and what
must become committed/reviewed before implementation.

REQUIRED OUTPUT

Produce a corrected complete contract/map owner package containing:

- an authority and fact-writer matrix;
- exact repository package/component ownership;
- outside-observer and receiver boundaries;
- normative contract placement;
- current-versus-target classification;
- supersession treatment for M23;
- migration stages and compatibility treatment;
- security and authority consequences;
- source/test/doc ownership;
- implementation tranche boundaries;
- acceptance evidence for each tranche;
- a dirty-baseline reconciliation plan;
- exact changes from the accepted owner;
- complete pair, profile and active-map rebinding;
- preservation evidence;
- a fresh-review task.

The implementation plan should be staged:

A. contract/docs/tests and repository-native schemas;
B. raw-fact producer interfaces under their owning components;
C. outside-observer implementation;
D. derived assembler/receiver and profile semantics;
E. integrated source/profile/runtime qualification.

Do not author runtime code, launch Codex, access repositories or hosts, or
claim repository adoption. Do not preserve external-only ownership by
inertia, and do not pretend a current maintained owner already exists.

Return:

OWNER_R6J_ES_NATIVE_IMPLEMENTATION_OWNERSHIP_CORRECTED_READY_FOR_FRESH_REVIEW
```

A different ChatGPT reviewer must examine that correction. Only after it passes should Codex receive a new implementation prompt—and that prompt should target a **stable, explicitly authenticated repository baseline**, not the current dirty worktree by implication.

## What not to do

Do not:

- reuse the prior implementation prompt;
- ask Codex to choose a package;
- copy the external proof tree into ES;
- map all facts to `es/admission`;
- map all facts to `es/runtimehelper`;
- treat the 17 untracked files as adopted source;
- regenerate the artifact against the dirty working tree without naming it as a provisional overlay;
- interpret “artifact design accepted” as “repository ownership accepted.”

## Bottom line

The survey is a successful stop and a useful architecture result. It establishes that the accepted artifact answered **what the proof means**, but not **which maintained product components must own and implement it**.

That ownership decision now belongs in the artifact architecture, not in Codex.

**Sources:** Codex survey report: owner conclusion and method Pasted text; M23 working-tree provenance Pasted text; external-proof classification Pasted text; current maintained responsibilities Pasted text; working-tree classification and alternatives Pasted text.

**Confidence:** **0.99** in the implementation stop and the need to reopen ownership; **0.95** in the split-ownership target direction. Exact repository package placement remains intentionally unselected until the corrected artifact is freshly reviewed.
