**Retain `BLOCK`, but carry forward the closures this audit has earned.** The five named repairs, the reciprocal SB-4 witness, historical-matrix restoration, and current invocation chain now have scoped independent closure. The next task is a bounded correction of **NS-CUST-01 and LIVE-LOG-01**, not another repair of the evidence machinery or the ES candidate. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="9"}[Namespace custody and empty-log repair prompt](sandbox:/mnt/data/ES_Namespace_Custody_Empty_Log_Repair/ES_Namespace_Custody_and_Empty_Log_Repair_Prompt.md).**

The handoff keeps ES unchanged. It explicitly permits the necessary correction to the previously protected shared namespace helper, plus narrowly bounded revalidation of the affected safe executable.

## What the two findings actually mean

Neither finding establishes a reproduced kernel failure, descriptor leak, or accepted unsafe mounted proof. The audit distinguishes the source defects from those unobserved consequences. That precision should survive the repair and subsequent reports. :chatgpt-content-reference{index="1"}

| Finding | Established defect | Required correction |
|---|---|---|
| **NS-CUST-01 — Medium** | A namespace descriptor is acquired, later qualification fails, and the helper discards the close outcome. Subsequent custody projections can lose the unresolved release. | Return and propagate finite partial-acquisition and release evidence, including on error. |
| **LIVE-LOG-01 — Medium** | The producer permits and publishes an empty `mkfs-ext4.log`, but the receiver cannot reconstruct and accept it. | Align the exact supplemental member’s size, accounting, and bounded-read contract with its permitted contents. |

These are two different problems: **preserving truthful failure evidence** and **accepting a permitted successful history**. They should not be repaired through a common relaxation of the receiver. :chatgpt-content-reference{index="2"}

## 1. Preserve namespace custody before qualification succeeds

The decisive path is below the previously repaired worker projection:

```text
namespace open succeeds
→ type, metadata, link, or process-identity qualification fails
→ close outcome is discarded
→ caller receives no acquired-object evidence
→ later cleanup can report complete represented custody
```

The audit traces this through `internal/safemech/linux.go:157–184`, the worker’s success-only custody update, its absence predicate, and the live adapter. **The primary startup failure remains, so this is lost residual truth—not a demonstrated successful false acceptance.** :chatgpt-content-reference{index="3"}

The selected repair must distinguish never acquired, acquired but incompletely qualified, successfully transferred, released after failure, and release-uncertain after failure. Facts unavailable because qualification failed must remain unknown; acquisition cannot be erased merely because a complete namespace identity was never established.

The helper must invalidate ownership before its one close attempt, retain both the original qualification error and any close error, and return enough evidence for the caller to absorb **before** deciding that no worker or namespace resource remains. A descriptor number retained in an error snapshot is evidence, not permission to close that number again. This follows the audit’s stated minimum correction. :chatgpt-content-reference{index="4"}

The new controls must exercise the **actual lower-level acquisition sequence**, with primitive operations substituted—not start with a fake `HoldNamespace` that already returns the desired complete snapshot. The important paired cases are acquired-then-error with a successful close, and acquired-then-error with close uncertainty. Both must preserve the primary failure; only the latter retains unresolved release state.

The composed witness must carry that result through worker custody, later cleanup, controller freeze, and receiver refusal. Successful cleanup of the process group or other descriptors must not erase uncertainty about this descriptor.

### This requires a narrow change to the protection boundary

The affected implementation is in `internal/safemech`, which previous tasks deliberately preserved. **I am explicitly reopening only its namespace acquisition/result/release contract and directly affected consumers.** Copying the defective helper elsewhere merely to preserve an old hash would be the wrong repair.

Unrelated raw-FD classification, thread, RPC, signal, and other safe-mechanics behavior remains protected. The corrected namespace-type handling, identity checks, and ordinary-file no-follow rules are not being relaxed.

## 2. Accept an empty log without making evidence optional

The empty-log finding crosses three receiver layers. The audit identifies rejection of the zero-size declaration, rejection during aggregate accounting, and a later read that passes zero as the maximum to a helper that rejects that limit. **Changing only `Size <= 0` would leave the path broken.** :chatgpt-content-reference{index="5"}

The selected contract is narrow:

**`mkfs-ext4.log` may contain zero bytes, but the exact member remains mandatory.**

Its empty-content digest, stable object identity, type, mode, ownership, and membership must still verify. Empty is not missing. It is also not evidence that formatting succeeded; formatter outcome and custody remain separate requirements.

The reader must distinguish an **expected length of zero** from an invalid or unbounded read limit. It still needs finite oversize detection and the existing stability checks. A zero declaration must not let a nonempty or changed file pass without reading and checking it.

The existing 16 MiB aggregate limit and member-count protection remain intact. Structured records retain their positive-size and parsing requirements. There is no generic “empty members allowed” flag, fabricated newline, omitted supplemental, formatter-argument change, or increased budget. Those would alter the contract rather than repair the contradiction. :chatgpt-content-reference{index="6"}

The positive test must use a real task-owned empty file through the **actual supplemental selection, publisher, receipt carrier, held reconstruction, and public receiver**, with all nineteen case records and their real adjudicators. Privileged/root-custody and independent-trust facts may be explicitly modeled; the log’s selection and reconstruction may not be bypassed by a standalone policy test.

The corresponding negatives cover missing logs, wrong digests, declared-zero/nonempty contents, empty structured records, wrong member roles, and over-limit evidence. Matching hashes and synthetic authentication must still fail when case or operational semantics are invalid.

## 3. Rebind the affected safe evidence

This continuation differs from the recent test-only correction. A change to the shared namespace implementation affects code used by the safe executable. **The seven historical Linux observations cannot automatically validate its successor, even if the import-package names remain identical.** The latest audit permits inheritance only for unchanged safe bytes and their original scope. :chatgpt-content-reference{index="7"}

The prompt therefore applies this treatment:

| Artifact or validation | Next treatment |
|---|---|
| External tooling | Fresh local unit/race validation, formatting, native/Linux vet, and required-control crosswalk |
| Linux-selected tests | Fresh compilation and source-selection evidence; no execution of the proof test binary |
| Supervisor | Fresh deterministic builds; remains unexecuted |
| Safe executable | Fresh deterministic builds and one complete seven-control Linux record on the repaired executable |
| Normal/diagnostic proof artifacts | Retain unaffected compile-only bindings and the existing unavailable-current-body qualification |
| ES candidate | Unchanged; no ES-suite rerun |

The remote permission is explicit and limited to the **existing seven ordinary-user controls on `host_to_remote_linux_m75q`**. The task must inspect the new executable’s actual initialization, imports, dispatch, child processes, and effects before transfer. It may query existing namespace handles for self or owned harmless children; it may not create or enter a namespace, access loop devices, run a formatter, invoke the supervisor, start a service, or execute an ES proof.

This is renewed validation authority for the changed safe component—not a promotion of the audit into host-execution authority. Access, identity, or cleanup uncertainty stops the task without remediation or an alternate target.

## Preserve the completed closeout mechanism

The audit now authenticates the current completed invocation chain, including the external packaging companions. It also independently accepts the fixed reciprocal assertion and the restored historical matrix. **There is no remaining reason to redesign A–F, search again for old evaluator calls, or rewrite historical rows.** :chatgpt-content-reference{index="8"}

The new task reuses that machinery, adds the two fixed obligations independently of test discovery, and keeps current owner responses separate from the protected historical matrix. It preserves SB-1…SB-5 and their meaningful controls, including retrospective verification and conditional live-policy acceptance.

The intended engineering endpoint is:

```text
ES_MOUNTED_HELPER_NS_CUSTODY_EMPTY_LOG_REPAIRED_LOCAL_AND_SAFE_LINUX_VALIDATED_REAUDIT_REQUIRED
```

Fresh independent cumulative review follows. This does not approve residual policy, establish administrative entry or containment, execute mounted cases, or satisfy the unconditional whole-candidate ES audit and exact-byte publication gates.

## Inspection boundary and confidence

I read the complete attached audit and computed its fingerprint: **19,168 bytes**, SHA-256:

```text
ec82e64dc262b43c7512126c79ef0720ff90849752d75891e2dc713f646f388e
```

I also inspected the prior safe-control and SB-4 handoffs to make the protection and validation changes explicit. The latest audit ZIP, current implementation, specialist bodies, and raw companions were not attached here; their detailed authentication and source findings remain **independent-auditor-reported**. The new prompt directs Codex to inspect those retained artifacts before editing. No repository code, tests, host commands, or privileged operations were executed here.

**Sources:** attached cumulative SB-4 audit and the preceding correction/validation handoffs. **Confidence:** **0.98** in retaining the block; **0.94** in this bounded continuation. Attachment identity is verified; repaired-source correctness, privileged readiness, and whole-candidate acceptance remain unestablished.
