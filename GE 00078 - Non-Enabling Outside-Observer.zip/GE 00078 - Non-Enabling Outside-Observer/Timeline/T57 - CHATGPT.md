**Retain `BLOCK`. The current validation evidence is complete; the remaining problem is the implementation, not missing provenance.** The next task should repair the eight actual lifecycle and receiver defects without reopening the validated ES candidate or adding another proof infrastructure layer. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="11"}[Per-effect authority, channel custody, and receiver repair prompt](sandbox:/mnt/data/ES_Action_And_Receiver_Repair/ES_Action_Custody_And_Receiver_Repair_Prompt.md).**

The handoff authorizes local, external-only repair and validation. It authorizes no privileged execution, host contact, mounted work, gateway installation, or ES repository change.

## What should carry forward

The audit resolves the previous coverage question. All **269 historical required identities and all 530 predecessor terminal identities** remain present and passing; the current generation adds 98 identities without renaming, excluding, or superseding any. The 123 current top-level controls therefore did not represent a reduction to 123 total test obligations. Current command, evaluator, selected-input, and package records also authenticate. **There is no justification for another historical-record recovery task.** :chatgpt-content-reference{index="1"}

Three narrow static closures also survive: original scratch-root custody, establishment of the export parent, and delivery of the exact persisted receipt. Their runtime and external-establishment qualifications remain, but the next repair should not redesign those mechanisms merely because other findings remain open. :chatgpt-content-reference{index="2"}

The current eight defects comprise **three unfinished lifecycle findings and five receiver findings, DRA-01…05**. They should be repaired together while retaining their individual acceptance criteria.

## 1. Move authorization and custody to the actual effect boundaries

The lifecycle failures are now quite specific:

| Finding | Actual gap | Repair boundary |
|---|---|---|
| **LNX-LIFE-01** | One entry check precedes several deliberate effects. Cancellation between them does not stop the later effects. | Check the original owner immediately before each named pre-controller effect. |
| **LNX-LIFE-03** | Socket endpoints exist before returnable custody; error paths lose release facts; the retained channel is recorded using the original descriptor’s identity rather than the duplicate. | Record both endpoints immediately, track ownership transfers and duplication, and return partial observations on every failure path. |
| **LNX-LIFE-04** | One authorized closure can issue more than one signal syscall, including fallback after an observation or error. | Make each actual signal syscall a separately checked dispatch under the same original authority. |

These are the audit’s live-source findings—not demands for stronger hypothetical guarantees. :chatgpt-content-reference{index="3"}

**A correct wrapper is insufficient when the wrapper contains several independently interruptible actions.** The same issue applies to custody: a controller cannot preserve facts that the actual acquisition producer never records.

For the worker repair, the prompt requires inspecting the pinned ownership semantics of the file wrappers and connection duplication. It must distinguish the original endpoints, their release outcomes, and the connection actually retained. Closing the original endpoint must not be represented as releasing the duplicate; neither may uncertain release permit another close of a potentially reused descriptor number.

The controls must inject failure **between those actual producer substeps**, rather than begin with a fake that already supplies a perfect partial identity. Likewise, signal controls must cancel or expire authority between the first syscall and its fallback—not merely before entering the enclosing closure.

The final check-to-one-syscall scheduling interval remains an explicit qualification. This repair does not promise atomic cancellation or implement the absent external containment mechanism.

## 2. The receiver must evaluate the case evidence—not authenticated success labels

**DRA-01 is the most consequential testing gap in this report.** The supposedly successful composed receiver fixture supplied ledger/sample payloads, declared the subjects, and used an always-success `Review`. The actual receiver checked committed waits without replaying the raw case semantics. Thus the positive composition bypassed an essential part of the operation it was intended to validate. :chatgpt-content-reference{index="4"}

My selected repair direction is to **reuse the existing case adjudicator over the complete persisted `ProcessRecord` evidence**. That avoids creating another layer of producer-issued success certificates.

The receiver must independently reconstruct the exact eleven normal and eight supplementary diagnostic subjects, their roles, process/test outcomes, artifact bindings, and case-specific assertions. A normal rejection case succeeds by demonstrating the intended refusal; it does not require ES to accept that topology. Diagnostic success cannot rescue a failed normal case.

The new positive composition must therefore contain a complete, schema-faithful set of constructed records and run the actual case predicate. Kernel observations and external trust remain visibly synthetic in local tests; **the case-review decision may not be replaced by unconditional success**.

The decisive negatives must remain internally well formed: mutate a case’s semantic evidence, recompute the graph hashes, supply matching test authentication, and require rejection for the semantic defect. Missing payloads, failed normal tests, wrong-role records, duplicate completions, and all waits committed without the corresponding proof must not pass merely because authentication succeeds.

**Authentication answers who supplied the statement and whether its bytes match. It does not make a failed statement describe success.** That distinction is the design requirement underlying the repair.

## 3. Validate complete terminal states, one deadline, and a fixed profile

The remaining receiver defects are not variations of checksum validation.

### Complete terminal-state consistency

DRA-02 shows that successful status labels can coexist with contradictory scratch, process, loop, image, or ledger facts. The current receiver does not validate their complete relationship. :chatgpt-content-reference{index="5"}

The prompt requires one complete terminal-state validator derived from the actual schema and lifecycle. It must distinguish truthful failure evidence from successful proof acceptance, and specify which recovered states the existing contract permits.

It must not simply reject every record containing an earlier error. A permitted recovered state needs its required fresh observations and accurate classification. Conversely, a held or release-uncertain descriptor, inconsistent image state, poisoned ledger, or unproved removal cannot be concealed by setting `Cleanup` and `Inventory` to successful values.

### One independently bound pre-effect deadline

DRA-03 identifies a mismatch between the producer’s actual deadline and the one the receiver authenticates. The producer proposes one value, the owner may choose an earlier inherited value, and the receipt carries only a completion boolean. The positive fixture then creates a different deadline after production. :chatgpt-content-reference{index="6"}

The handoff makes the correction explicit:

**One independently authenticated deadline is selected before effects and bound to the owner, receipt, receiver expectations, and confirmation.**

The original typed deadline remains internal control state; its canonical serialized value is the cross-record binding. There must be no silent narrowing followed by a claim that a different timestamp was the original.

For this continuation, a parent context already imposing an earlier deadline makes that episode ineligible before effects unless the independently authenticated input already names that earlier limit. Later cancellation still stops work without rewriting or extending the approved deadline. Shorter phase budgets do not become replacement episode deadlines.

This is a bounded interface correction, not authorization to build an approval service or watchdog.

### A valid profile, not merely matching expectations

DRA-04 demonstrates that actual evidence and caller expectations can agree on an **invalid subset, scope, path, or mode** and still pass. Equality between two invalid descriptions is not contract conformance. :chatgpt-content-reference{index="7"}

The repair must enumerate the supported profile and derive its exact subjects and roles. It must enforce the fixed path relationships and selected live base mode `0711`, with other modes taken from their owning contract—not apply `0711` indiscriminately.

The ordinary-user synthetic profile remains separate and explicit. Its necessary custody/trust substitutions must not relax case semantics, deadline equality, terminal consistency, or resource limits, and evidence must not select the synthetic profile for a production acceptance path.

## 4. Bound the receiver’s total work

DRA-05 is an independently important resource defect: separate 4 MiB file limits do not enforce the **16 MiB aggregate export contract**, and the current reconstruction finishes with unbounded directory enumeration. :chatgpt-content-reference{index="8"}

The prompt requires overflow-safe aggregate and member-count preflight, actual-read metering, and bounded enumeration. Manifest sizes are preliminary claims, not substitutes for measuring the held files actually read.

The aggregate’s domain must be explicit, including the applicable payload and terminal records. Any retained legacy verification path must share the same bounded acquisition discipline rather than reopen the tree through an unmetered second path.

The existing budget is not increased. Nor is a quota or cgroup subsystem selected. This is enforcement of the receiver’s existing finite contract.

## The completion test must be harder to bypass

The previous repair prompt asked for a composed path, but the reported composition still substituted the semantic decision and missed several live acquisition boundaries. **My instruction to test composition was not precise enough about which decisions could remain substituted.**

The new handoff fixes that distinction. It requires the actual orchestration, case adjudicator, terminal validator, publisher, receipt carrier, and receiver. Only explicitly identified privileged/kernel primitives and independently configured test trust may be substituted.

The combined controls include cancellation between entry effects, descriptor duplication followed by bookkeeping failure, expiry between signal attempts, complete wait records with missing case evidence, matching-invalid profiles, differently bound deadlines, and individually valid files exceeding the aggregate limit. Each negative must fail for its intended predicate, not an incidental stale hash.

The task still stops short of privileged Linux behavior. Source assertions and substituted effects retain their stated limits; passing them does not establish the future mounted run.

## Validation and the next gate

After those controls pass, Codex freezes the successor and runs the external tooling’s local unit/race suites, native and Linux vet, formatting/environment checks, and deterministic supervisor builds. New source requires new validation; **628 is not a target count**.

The safe executable and selected closure are rebuilt and compared locally. Identical bindings permit the seven authenticated ordinary-user Linux observations to carry forward without another remote run. They do not validate the changed supervisor. Normal and diagnostic proof artifacts remain unchanged compile-only evidence. :chatgpt-content-reference{index="9"}

The current complete evaluator-recording mechanism should be reused. No additional historical search, packet ceremony, or unchanged-suite replay is needed merely to re-establish what this audit already authenticated.

The intended engineering endpoint is:

```text
ES_MOUNTED_HELPER_ACTION_CUSTODY_AND_RECEIVER_REPAIRED_LOCAL_VALIDATION_COMPLETE_REAUDIT_REQUIRED
```

Fresh independent review follows. Residual policy, administrative/trust/storage establishment, target and formatter qualification, external containment, mounted cases, deployment observation, supported-local proof, the unconditional whole-candidate ES audit, and exact-byte publication authority remain outstanding. :chatgpt-content-reference{index="10"}

### Sources, limits, and confidence

I verified the attached report’s **17,579 bytes** against SHA-256 `b38b427d…de31cb5`. The engineering ZIP, current source, specialist bodies, and raw streams were not attached here; their detailed authentication and findings remain **independent-auditor-reported**. The prompt requires inspecting those retained artifacts before editing. No repository code, tests, host commands, or privileged operations were executed in this review.

**Sources:** attached independent re-audit and preceding engineering report. **Confidence:** **0.98** in retaining the block; **0.91** in this repair handoff. Report-byte identity is verified; successor correctness, privileged readiness, and whole-candidate acceptance remain unestablished.
