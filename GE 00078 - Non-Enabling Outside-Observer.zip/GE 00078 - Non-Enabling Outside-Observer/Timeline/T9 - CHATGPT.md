**The `BLOCK` stands. These are substantive repair findings; the audit-runner mistake does not invalidate them.** We should repair the candidate before spending another validation cycle on it. The report explicitly classifies this as a bounded repair within the selected architecture, not rejection of the architecture. :chatgpt-content-reference{index="0"}

**Next handoff: :chatgpt-content-reference{index="13"}[Repair-design freeze prompt](sandbox:/mnt/data/ES_Final_Audit_Repair_Design_Prompt.md).** Send it to the existing **implementation/repair Codex conversation**, not the independent audit conversation.

This next task is narrowly read-only. The reason is specific: **CUST-2 leaves the supported filesystem-alias topology to be decided.** That must be settled before authorizing a production repair; “compare the two directory inodes” would address equal roots but would not, by itself, close the nesting problem identified by the audit. :chatgpt-content-reference{index="1"}

## Assessment of the findings

I checked the relevant mechanisms against the supplied source archive. That archive predates the latest one-file hermetic-fixture repair, but it contains the production, operator-test, and documentation surfaces implicated here. Twenty inspected members matched their supplied manifest entries. This corroborates the source-level findings; it is not a reproduction of the audit’s runtime observations. Exact excerpts and the inspection boundary are in the :chatgpt-content-reference{index="14"}[source-review notes](sandbox:/mnt/data/ES_Final_Audit_Findings_Source_Review.md).

### CUST-1: repair the algorithm, not the accepted input limits

The diagnosis is concrete. `es/admission/mounts.go:335–354,447–463` repeatedly traverses parent prefixes and scans the accumulated name map for descendants. The report derives **8,390,656 prefix checks for 4,097 flat files**, with substantially larger work possible inside the documented stream limits. It correctly distinguishes these source-derived counts from an unperformed wall-clock benchmark. :chatgpt-content-reference{index="2"}

The selected direction is an invocation-local namespace representation with work bounded by processed name bytes and path-segment occurrences. The design must also account for memory and deep traversal: replacing repeated string scans with cumulative-prefix storage or deep recursive calls would merely move the problem.

**Do not restore a 4,096-entry or 4,096-byte-name limit.** The current policy deliberately uses whole-stream bounds instead. The repair must preserve that decision, PAX/GNU support, pre-freeze validation, and the absence of post-freeze archive reparsing. :chatgpt-content-reference{index="3"}

One detail I added to the handoff: derive and preserve the existing distinction between repeated directory headers, implicit parents, duplicate files, and normalized aliases. “Reject duplicates” is not a sufficiently precise replacement specification.

### CUST-2: physical separation must cover every result-side effect

This is the critical design issue. The report traces how different path spellings can reach the same directory, allowing result retention to reconcile metadata and publish files inside staging. That contradicts the existing result/staging separation and non-mutation contracts. The attribution is appropriately mixed: the lexical configuration check is pre-existing, while the candidate strengthens custody and its documented guarantees without closing that inherited hole. :chatgpt-content-reference{index="4"}

My source inspection adds an important scope constraint: **the repair cannot stop at `retainTerminalResult`.** In the supplied source:

- `readRetainedResultBundle` calls `openRetainedResultDirectory(..., false)`;
- that helper still performs `Fchown` and `Fchmod`;
- retained reads can also reconcile normalization evidence.

Those paths are visible at `es/admission/results.go:195–215,273–329`. A function named “read,” or a `create=false` argument, does not make this path effect-free. :chatgpt-content-reference{index="15"}[Exact source excerpts](sandbox:/mnt/data/ES_Final_Audit_Findings_Source_Review.md)

The design must therefore establish where physical separation is checked, which operation owns the checked descriptors, and how the subsequent effects remain bound to them. It must also preserve legitimate retained-bundle-first lookup rather than accidentally requiring a live runtime lookup or an original staging run tree.

There is a compatibility trap here: **blanket rejection of all mounted roots is not a neutral bug fix.** The supplied configuration documentation retains a same-path host/container staging mount constraint, and configured-root traversal currently permits mount crossings while qualifying the root. The repair must explicitly distinguish supported mounted-root deployment from unsafe aliasing; it cannot silently solve the finding by removing an existing deployment path. See `.docs/system_overview/configuration.md:342–367` and `es/admission/staging_custody.go:315–326` in the :chatgpt-content-reference{index="16"}[source notes](sandbox:/mnt/data/ES_Final_Audit_Findings_Source_Review.md).

The prompt requires one recommended topology policy, an accepted/rejected/unprovable topology table, exact effect ordering, and corresponding tests. It prohibits resurrecting the rejected A3 registry, lease, or process-global root-pair machinery.

I have also **not preselected an edit to `es/config/config.go`**. Its lexical check may remain useful as structural validation while physical enforcement belongs to admission custody. Codex must justify the actual touched set rather than treating every suggested audit surface as mandatory.

### M3-1: close the assurance gap without misreporting a current script exploit

The audit distinguishes two facts that we should preserve: the current retired routes remain privacy-first and effect-free, but the source guard accepts an inserted executable effect. The disagreement between reviewers was resolved using that concrete escaping mutation, rather than treating the problem as prose alone. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

The repair needs a bounded semantic inventory of both scanners, including executable constructs inside assignments, substitutions, and redirections. Adding a check for the particular injected `printf` would not close the class.

The prompt requires a small, fail-closed accepted grammar—not a general Bash analyzer—and preserves the demonstrated tolerance for formatting, comments, and genuinely inert literals. It also requires the documentation to describe the actual enforceable guarantee, rather than continuing to claim complete scanner-text comparison.

**CUST-3 and DOC-2 belong in the same repair**, not separate workstreams: correct the missing direct test caller, and replace implementation-absence wording with precise public/runtime nonwiring language for the private reliable-submit parsers. Their matching assertions must change with the prose; reliable-submit runtime remains unwired. :chatgpt-content-reference{index="7"}

## The umask failure needs a runner correction, not a product workaround

Both full-suite failures are explained in the report by the runner’s imposed `077` umask interacting with an unchanged fixture that requests and expects mode `0755`. The race lane passed. The failed streams remain failed validation records; they are not evidence that the candidate itself introduced this mode defect. :chatgpt-content-reference{index="8"}

For the next validation runner, the handoff requires preservation and recording of the ordinary inherited child umask. Private evidence directories and files should receive explicit restrictive modes **without changing the test process’s creation environment**. It must not silently force `022`, alter the user’s shell configuration, or patch the runtimehelper assertion merely to hide the runner mistake.

There is no value in rerunning the rejected candidate now just to clear those two failures: the production repairs will change the validation target anyway. Preserve the old runner and streams, then validate the repaired bytes under the corrected runner.

## What carries forward, and what happens next

This audit did close useful obligations. It reports M1, M2, the exact-byte native evidence, and the latest hermetic fixture repair closed. It also independently authenticated the old failed AMD64 run without rewriting that failure. Those conclusions remain historical evidence; this repair should not restart those completed investigations. :chatgpt-content-reference{index="9"}

The continuation is:

1. **Freeze the repair design.** Settle CUST-2 topology and effect ownership, CUST-1’s complexity argument, M3’s accepted grammar, the exact touched surfaces, and adversarial acceptance evidence.
2. **Implement the combined repair with one writer.** Update governing docs and tests with the code, fold in both Low corrections, and correct the external runner. Do not run separate full validation cycles for each finding.
3. **Validate the repaired candidate, then independently re-audit it.** Run the default-temp full suite, physical-temp full suite, and admission/app race suite; then validate the same frozen source on AMD64 followed by ARM64.

New native Linux evidence is justified here because production admission/custody bytes will change—not merely because another audit occurred. The report identifies that distinction explicitly. :chatgpt-content-reference{index="10"}

The later independent audit should authenticate complete same-byte validation records rather than automatically duplicate every expensive suite. Missing evidence, changed bytes, or a new obligation can justify additional execution. The existing environment-dependent application skips must remain explicit non-claims, not be confused with successful live Docker/Nomad integration testing. :chatgpt-content-reference{index="11"}

**No staging or commit is authorized.** The eventual repaired candidate will need a new exact identity; the rejected 75-path manifest cannot authorize publication of its successor. :chatgpt-content-reference{index="12"}

**Sources and limits:** attached audit report and the :chatgpt-content-reference{index="17"}[manifest-checked source excerpts](sandbox:/mnt/data/ES_Final_Audit_Findings_Source_Review.md). The compact audit ZIP, raw streams, specialist reports, and runner source were not attached here. No repository code, tests, remote commands, or VM operations were executed in this review.

**Confidence:** **0.97** in retaining `BLOCK`; **0.94** in the repair direction and design-first sequencing. Supplied-source provenance is strong; live-candidate provenance and execution results remain audit-reported. Physical-topology closure and repaired implementation correctness remain to be established.
