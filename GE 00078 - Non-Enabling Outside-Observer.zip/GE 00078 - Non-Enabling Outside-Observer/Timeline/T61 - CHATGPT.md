**Preserve the audit’s `INCOMPLETE` endpoint, with the source separately classified as blocked. Proceed with one external correction task covering SB-1…SB-5 and the missing invocation capture—not another audit of unchanged code or a runtime attempt.** The report establishes that recovering the records alone would not make this successor acceptable. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="17"}[Five source blocks and evidence repair prompt](sandbox:/mnt/data/ES_Five_Block_Correction/ES_Five_Source_Blocks_and_Evidence_Repair_Prompt.md).**

The ES candidate remains frozen. This handoff authorizes local repair and validation of the external tooling only.

## What this audit closes—and what it does not

The audit gives qualified static closure to the action-adjacent entry checks, per-syscall signal authorization, complete case-semantic replay, and bounded receiver reconstruction. It also preserves the earlier narrow scratch-root, export-parent, and receipt-carrier closures. **Those mechanisms should carry forward, not be redesigned merely because other paths remain defective.** :chatgpt-content-reference{index="1"}

The validation results also retain their actual meaning. The auditor reproduced all sixteen corrected command records and both **959-pass streams**, including the 151 named controls. What remains missing is the invocation evidence for the current evaluator, self-tests, packager, and verifier. The audit found that their source writes decision bodies without capturing the invocation envelopes. This is therefore a current recording/integration defect—not merely an absent ZIP attachment in this chat. :chatgpt-content-reference{index="2"}

The most important source conclusion is equally precise: **the receiver cannot accept the actual successful live producer, even under hypothetical valid prerequisites.** One path loses the formatter’s release summary; another rejects every possible value of the required live residual flag. These are not consequences of the real policy still being unapproved. :chatgpt-content-reference{index="3"}

## The five corrections

| Finding | Required correction |
|---|---|
| **SB-1 — High: formatter release summary disappears** | Carry the actual release observation through the controller and serialized residual into the receiver. Do not make the test supply the summary that production omits. |
| **SB-2 — High: live residual predicate is contradictory** | Implement a fail-closed accepting branch conditioned on independent approval of the existing disposition, while retaining the possible residual fact. |
| **SB-3 — Medium: later verification rejects timely evidence** | Judge authenticated completion and delivery against the original deadline—not the wall clock when someone later reviews the evidence. |
| **SB-4 — Medium: stdio close uncertainty vanishes** | Track `/dev/null` acquisition and its one-close outcome through partial worker state and final absence checks. |
| **SB-5 — High: leader reap substitutes for group absence** | Retain candidate/group custody after pidfd acquisition failure until a fresh bounded observation establishes exact group absence—or report uncertainty. |

These are the audit’s five source-specific corrections. They do not require a new supervisor architecture, receiver layer, allocator, or administrative service. :chatgpt-content-reference{index="4"}

### SB-1 needs a test of the actual producer’s output

The report pinpoints why the current composed test passes: its model supplies `DescriptorReleased`, while the real successful formatter return omits that field. The controller consequently serializes a different state from the one the receiver requires. :chatgpt-content-reference{index="5"}

The next positive witness must run the **actual formatter observation construction and controller propagation**, substituting only the underlying kernel observations and close operation. It must then serialize and verify the resulting state.

The correction must preserve the distinctions between never acquired, held, released, and release-uncertain. Weakening the receiver to treat `not-held` as equivalent to a confirmed release would hide the mismatch rather than repair it.

### SB-2 is a conditional implementation fix—not policy approval

The current receiver requires `PossibleUnboundEffect=true`, then rejects that value for every non-synthetic profile. Neither Boolean value can pass `live-complete/v1`. The documentation also conflicts: one page specifies universal refusal while another names independent policy approval as a future prerequisite. :chatgpt-content-reference{index="6"}

The handoff resolves that implementation contract:

> A live result may retain the possible single-`GET_FREE` unbound-object effect and be semantically acceptable **only when the existing exact disposition was independently approved for that episode before its effects**, and every other acceptance condition passes.

The disposition remains:

```text
accept-single-get-free-possible-unbound-without-removal
```

**That policy is not approved by this response or by a passing synthetic test.** Missing, wrong, unestablished, substituted, or retrospectively invented approval must still refuse. The accepted evidence must retain the possible effect; local cleanup must not imply global loop-object absence.

The test must exercise the actual live-profile decision under explicitly synthetic independent prerequisites. Routing the positive through synthetic-only policy logic would leave the live contradiction untested. No root-owned fixture, real approval, removal authority, loop lease, or device operation is authorized.

### SB-3 separates execution time from review time

The audit’s example is a correctly completed and delivered episode rejected solely because independent review happens after its deadline. The current tests encode that mistaken refusal. :chatgpt-content-reference{index="7"}

The required witness is simple and discriminating: **the same timely evidence, with the same original deadline and authenticated completion facts, verifies both before and after that deadline.**

This does not extend the episode. New effects after expiry remain prohibited; late completion, late delivery, false containment, cancellation, or mismatched deadline evidence still reject. The receiver’s own processing budget also remains separate. No system-clock change or new timing service is needed.

### SB-4 and SB-5 concern honest residual state

For SB-4, the primary error already prevents clean proof. The auditor does **not** claim a demonstrated descriptor leak or successful false acceptance. The defect is that a known close uncertainty survives only as error text while the resource projection can report absence. :chatgpt-content-reference{index="8"}

For SB-5, a candidate has started before pidfd acquisition fails. The current path can ignore the group-signal result, wait for the leader, clear ownership, and report absence without observing the group. Later cleanup can then skip it. :chatgpt-content-reference{index="9"}

The repair must retain acquired facts before the next fallible step, preserve every release or signal error, and distinguish **continuing responsibility for unresolved resources** from **permission to issue another syscall**. Expired authority must not be renewed merely because cleanup still has work to resolve. Neither a successful signal dispatch nor leader exit establishes group absence.

## Make invocation capture a tested completion requirement

This evidence gap has recurred despite explicit recording instructions. Another sentence in the report promising complete capture is not enough.

The prompt makes the recording integration a **pre-freeze implementation gate**. Before the broad validation lanes, Codex must exercise the actual recorder-to-evaluator path, including rejected arguments, a self-test, and a successful small input. The handoff-completeness check must then reject a deliberately missing invocation envelope.

The final sequence is finite and acyclic:

```text
Frozen source and validation tools
→ recorded validation and evaluator invocations
→ finalized report and packet payload
→ recorded packager invocation
→ recorded completed reopen verification
→ external handoff identities and companion records
```

The completed packager and reopen-verifier invocations necessarily come after the ZIP they describe. **Their actual records may remain outside the ZIP, but they must be retained, accessible, and bound by the handoff—not replaced with decision bodies or hashes of unavailable files.**

The task permits a bounded check for genuinely existing omitted current records. It does not authorize reconstructing historical arguments or timestamps from plans, or rerunning old commands to pretend to recover their history. The audit’s current `INCOMPLETE` endpoint remains intact; a repaired successor can nevertheless have independently complete new evidence. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

One smaller coverage correction belongs in the same pass. The audit identified a predecessor negative that had been reduced from a fully rehashed graph attack to direct tuple refusal. The prompt requires restoring that graph-level test at its meaningful boundary, rather than using the larger passing-test count as evidence that nothing was lost. :chatgpt-content-reference{index="12"}

## What the next task runs

After the five production-shaped tests and recorder controls pass, Codex freezes the successor and runs the external tooling’s local unit/race suites, native and Linux vet, formatting/environment checks, Linux test compilation, and deterministic supervisor builds. The complete successful trace remains the already source-derived eighty-action grammar; this is not another trace redesign. :chatgpt-content-reference{index="13"}

Artifact reuse stays selective. The changed supervisor receives new identities and remains unexecuted. An identical safe executable and unchanged selected dependencies permit inheritance of the seven original ordinary-user Linux observations without another remote run. The audit could authenticate the normal and diagnostic proof identities from retained records, but their current raw binary bodies were unavailable; the next report must preserve that limitation rather than claim a fresh measurement. :chatgpt-content-reference{index="14"}

No ES suite, host contact, real signal experiment, device access, mounted test, policy acquisition, gateway work, or Git mutation is authorized.

The intended endpoint is:

```text
ES_MOUNTED_HELPER_FIVE_SOURCE_BLOCKS_REPAIRED_CURRENT_EVIDENCE_COMPLETE_REAUDIT_REQUIRED
```

It leads to a fresh exact-source cumulative review. Administrative establishment, residual-policy selection, target qualification, containment, mounted cases, deployment observation, supported-local proof, the unconditional whole-candidate ES audit, and exact-byte publication authority remain separate. :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}

### Sources, inspection boundary, and confidence

I read the complete attached report and fingerprinted its **17,386 bytes** as SHA-256:

```text
a16654e8bf6413e656ee04e7738f366f9bd28427a943d2237ac85aeb0f3687f8
```

The audit ZIP, current implementation, specialist bodies, and raw invocation records were not attached here. Their detailed findings and authentication remain **independent-auditor-reported**. The prompt directs Codex to inspect those retained artifacts before editing. No repository code, tests, host commands, or privileged operations were executed here.

**Sources:** attached consolidated audit, preceding engineering report, and the previous repair/audit handoffs. **Confidence:** **0.98** in withholding progression; **0.93** in this bounded correction task. Attachment identity is established; successor correctness, privileged readiness, and whole-candidate acceptance remain unestablished.
