ES final-audit repair — focused design correction and feasibility gate
Objective and next effect
Continue in the existing implementation/repair Codex conversation that produced ES_FINAL_AUDIT_REPAIR_DESIGN_READY.
Correct two material gaps before that design becomes an implementation instruction:
1. CUST-2's Linux mount-source coordinate comparison does not establish that configured path spelling is canonical under the backing filesystem's lookup semantics. Its visible-component identity check does not, by itself, cover ancestry hidden behind a separately presented subtree.
2. CUST-1's proposed near-16 MiB PAX/GNU name and roughly 4 MiB shared-prefix archive tests have not been shown to reach the ES namespace validator through the pinned standard-library tar parser. Published Go source contains a smaller special-header limit.
Also resolve the closely related topology-snapshot scheduling and deployment-evidence-subject ambiguities below. Preserve the sound design work; do not repeat the entire final audit or rewrite a new general architecture proposal.
Return one concise successor amendment and a corrected complete touched-surface/acceptance matrix. Preserve the original design and matrix unchanged. No repository implementation is authorized in this turn. Do not claim the original candidate repaired or accepted.
Effects authorized and prohibited
Authorized:
- Read-only repository, source, documentation, installed-toolchain source, and retained-evidence inspection.
- Safe read-only Git identity/diff inspection with the retained serializers and command-selection protections.
- A small standalone standard-library-only tar feasibility probe, written, compiled, and executed entirely in fresh task-owned local scratch outside every repository, using the authenticated installed Go executable below. This is explicitly authorized limited local execution; it is not a repository test or independent audit.
- External report, source-excerpt, probe-log, and corrected-matrix creation. Give directories/files explicit restrictive modes without changing process umask.
Not authorized:
- Repository edits, formatting, tests, benchmarks, repository scripts, imports of ES code into the probe, or execution of copied ES functions.
- Installing/downloading dependencies, public-network access, SSH/host contact, Lima or Docker operations, service queries/starts/stops, namespace entry/creation, mount/remount/unmount, privilege escalation, or tracing.
- Editing historical evidence; staging, committing, pushing, fetching, switching branches, rebasing, resetting, cleaning, or changing worktrees.
One parent owns this bounded correction. No subagents or parallel writers are needed. Do not combine this with independent audit or conditional repository implementation.
Authenticate only the inputs needed for this correction
Repository: /Users/ds/Repositories/Execution Substrate/.
Original design directory:
/Users/ds/Downloads/ES-final-audit-repair-design-20261005T023141Z/
Authenticate:
- ES_FINAL_AUDIT_REPAIR_DESIGN.md: 47,288 bytes, SHA-256 a5252f40d899556baa5cd3000f8b5d94ebc81cda3c3a2076211d30cdb94d8128.
- touched-surface-acceptance-matrix.json: SHA-256 71ec19d62275e23e88fb1a43643ec7d2b7799ea43ed549ae580cd99c169d6648.
ChatGPT authenticated the attached design report, but the matrix was not attached to ChatGPT. Read its actual retained bytes; do not infer its rows from the report. This is not a request for another file-collection round when those bytes are already available locally.
Expected unchanged live baseline:
- branch/upstream: trunk_dev / origin/trunk_dev;
- HEAD: b92bd9884106154d25342e1573dcc4c312311436;
- tree: cdd4e44bac15c1952d70997143040644361f0bb1;
- sole parent: 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- 0 behind / 1 ahead, without fetch; six preserved worktrees;
- 64 modified tracked + 11 untracked regular files; no staged/conflicted files or active Git operation;
- status: 3,511 bytes, SHA-256 adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93;
- complete source serialization: 352 rows, 66,503 bytes, SHA-256 7e48b9407da4117bc22c862802f94d324e5b216394b78f040b3ba4087eb6ca5c;
- candidate serialization: 75 rows, 9,109 bytes, SHA-256 2fa0cd9f49bacf98727b109362ca8514d780b9a4ddb8c6d01e94ba1cc0fe071f;
- retained tracked binary/full-index diff: 2,246,275 bytes, SHA-256 c8d68d2eb71a4482c1cf2e66209d32d8fdf83b0f7fdc55f299b31277b315b54e.
Relevant audit report remains:
/Users/ds/Downloads/ES-final-independent-audit-20261005TXXXXXXZ-p860xwkf/REPORT.md
(29,923 bytes; SHA-256 3c62d3c08fbbd0968fdedc52e0dda1064298d51dd771b6ad0b0c227f412c6a28). XXXXXX is literal.
Inspect the retained safe serializers before reproducing their read-only semantics. Inspect Git config/attributes before the retained diff command; do not implicitly execute selected external diff/textconv/filter programs. Reproduce opening/closing source and candidate identities; stop on mismatch rather than resetting or absorbing unrelated work. Do not reprocess the complete historical environment-preparation chain or regenerate prior artifacts.
Governing sources and retained decisions
Read AGENTS.md, current PLANS.md, .docs/system_overview/configuration.md, .docs/system_overview/capability_probing.md, and the relevant lifecycle ownership/invariant sections before amendment. Source anchors in the supplied historical snapshot (verify live line positions):
- es/admission/mounts.go:278-337,447-487: standard tar Reader precedes ES namespace checks; current prefix/descendant behavior.
- es/admission/results.go:27-41,91-130,195-215,273-329: retained-first route, retention order, and result-directory mutation on reads.
- es/admission/staging_custody.go:283-350: configured-root qualification and allowed root mount traversal.
- scripts/internal/control_plane.sh:196-229,307-323: selected container mount construction/checks.
- .docs/system_overview/remote_supported_host_alpha.md:4734-4755: historical service posture, not live-state authority.
- go.mod:1-11: pinned Go/toolchain and already-present x/sys dependency.
Preserve:
- CUST-1 compressed-radix direction, iterative traversal, byte-keyed branching, substring labels, error precedence, namespace semantics, and production-site instrumentation. The dependency-feasibility correction is not permission to weaken the algorithm or add ES entry/name caps.
- CUST-2 operation-local descriptor ownership, no global registry/lease/scanner, descriptor-bound effects, startup requalification, explicit result-side effects, retained-first lookup with missing staging support, fixed topology errors without Nomad fallback, and explicit trusted/stable-namespace non-claims.
- M3's bounded fail-closed accepted grammar and independent mutation tests; no operator-script rewrite or new dependency.
- CUST-3 exact typed caller inventory and DOC-2 precise runtime/public nonwiring correction.
- Explicit evidence-file modes without child-umask contamination; original failed validation stays failed.
- Default/physical full suites, race, native AMD64 then ARM64, applicable required-path coverage, and later fresh independent audit for the future repaired bytes. Do not execute those gates now.
This remains a design refinement over current ES custody/resource invariants. The report/matrix is planning evidence, not owning-repo authority. CP's launcher compatibility does not become an enduring core architecture requirement, and it cannot be silently removed either.
Correction A — descriptor-backed coordinate semantics, not another lexical proof
Original design sections 3.1–3.3 use:
mountRecord.root + relative(configuredPath, mountRecord.mountpoint)
then component-prefix comparison on that derived string. A held mount ID establishes which mount record applies; it does not establish that the spelling copied from configuration is the backing object's canonical name.
Analyze this modeled counterexample, without creating a mount or claiming a native reproduction:
- One case-insensitive/casefolded backing filesystem has /pool/Area/child/out.
- /s-view presents a bind of /pool.
- Staging is configured as /s-view/area and resolves to the actual /pool/Area object.
- /r-view presents a bind of /pool/Area/child.
- Results is configured as /r-view/out and resolves to /pool/Area/child/out.
- The two terminal objects differ. The visible results chain is / → /r-view → out, so it does not contain staging's terminal object Area. Neither configured root visibly contains the other, and neither has a mount strictly beneath it.
- The written formula derives /pool/area for staging and /pool/Area/child/out for results. A case-sensitive component-prefix test reports disjoint strings even though results is physically below staging.
This counterexample does not need hostile concurrent mutation, hidden remote storage, or namespace changes. It challenges the stated static algorithm within its claimed Linux topology class.
Required correction:
1. Work through the example using the exact proposed records and comparisons. Either provide a concrete existing step that rejects it (with a complete reasoning trace), or acknowledge the false acceptance and repair the rule. Merely restating fail closed when ambiguous is insufficient if ambiguity is never detected.
2. Select and specify one descriptor-bound canonical-presentation/identity method, or an explicitly enforceable refusal rule for cases that cannot be proved. The preferred direction preserves disjoint sibling bind presentations while refusing genuinely unprovable cases. Do not globally lowercase, Unicode-normalize using an assumed filesystem rule, trust raw configured spellings, resolve symlinks in configured paths, or add a string-only special case for this example.
3. Define how the held descriptor, mount record, canonical component spelling, and any missing suffix are bound together. Existing-component identity proof and absent-component intent are distinct obligations. Do not describe a hypothetical missing path as an already observed object.
4. Apply the same soundness rule to descendant-mount detection on each platform. A differently spelled configured root must not make a real descendant mount disappear from the check. Preserve the different Linux and Darwin evidence capabilities; do not infer one from the other.
5. Add exact regression obligations for separately presented case-alias ancestry, both directions, mixed case-sensitive/case-insensitive directory contexts, and the unchanged accepted sibling-bind shape. Label modeled classifier tests versus actual mounted-filesystem evidence. Do not manufacture a native pass from synthetic records.
6. Retain startup and retain/read/reconcile non-mutation ordering. The tested rejection must precede any result mkdirat, metadata reconciliation, temp/final/sidecar action, or cleanup.
As part of making the bounded Linux parser specification complete, explicitly state its treatment of valid namespace roots whose mount parent is outside the visible process root, unknown optional mountinfo fields, duplicate IDs, stacked/ambiguous records, returned statx mask validity, and descriptor/record device agreement. Consistent parent graph must not accidentally mean that every parent must appear in a container/chroot view. Keep this a bounded parser, not a generic host-topology service.
Do not silently ban all mounted or case-insensitive roots to obtain an easy proof. Any changed supported topology requires exact governing wording, a compatibility impact statement, and an enforceable failure condition. No migration, ownership change, deployment, or automatic cleanup is authorized.
Topology acquisition and per-effect cost
Original section 3 says one operation-local snapshot, while section 3.4 also says topology is refreshed immediately before effects. Resolve that ambiguity in the amendment:
- Name the operation/qualification episodes, number of metadata acquisitions, bounded parser/classifier work, and which checks use held state versus acquire fresh metadata.
- Distinguish visible-object revalidation, topology re-observation, and startup behavior probing.
- Give a simple work bound in snapshot bytes/records, configured path bytes/components, and number of checked effect boundaries.
- Do not introduce a full mount-table scan on every streaming tar/gzip Write merely by treating every byte-write as a new topology-validation boundary.
- Preserve the promised safety and non-claims; do not remove checks just to claim a smaller cost. If the original freshness wording is stronger than the chosen mechanism, correct the wording explicitly.
No new process-global cache or lease is permitted.
Correction B — prove tar input reachability before freezing acceptance shapes
Original section 4.3 requires a near-16 MiB PAX/GNU resolved name with more than eight million short segments, and two approximately 4 MiB shared-prefix names. Published Go source currently has maxSpecialFileSize = 1 << 20 for PAX and GNU metadata; its reader rejects larger special files before returning the affected regular header. PAX writing may reject oversized records even earlier.
ChatGPT could inspect public Go source but could not authenticate the exact public go1.26.5 tagged files through its web tool. Do not substitute that source for the installed dependency. Verify these facts in the actual authenticated installed Go 1.26.5 sources:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/
Inspect src/archive/tar/format.go, reader.go, and writer.go, especially maxSpecialFileSize, readSpecialFile, parsePAX, long-name handling, and writer refusal. Retain exact relevant excerpts, source hashes, and line references. No toolchain modification is permitted.
Then run the one bounded stdlib-only feasibility probe authorized here. It should report construction, parsing, and consumed-byte outcomes separately for:
- the original design's deep-name and shared-prefix shapes, including construction failures;
- one clearly reachable deeply segmented PAX name and GNU name;
- selected exact-limit and plus-one special-header shapes, including length-prefix/NUL/record overhead;
- the finite flat-header shape needed for the 16 MiB complete-stream boundary, distinguishing canonical footer from EOF termination.
If tar.Writer refuses a negative oversized input, retain that result. Only if necessary to distinguish writer from reader limits, the probe may construct a minimal in-memory tar special header explicitly with a documented correct checksum. It must not execute payloads, extract files, bypass limits in ES, or change standard-library behavior. Keep input buffers bounded and process cases sequentially. This probe does not exercise or validate the proposed radix implementation.
Use the exact executable:
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Previously authenticated binary SHA-256:
3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
From fresh external scratch, with tar-shape-probe.go retained there as source:
"$GO" version
"$GO" env -json GOVERSION GOOS GOARCH GOROOT GOMOD GOWORK GOENV GOTOOLCHAIN GOPROXY GOSUMDB GOFLAGS GOMODCACHE GOCACHE GOTMPDIR
"$GO" run ./tar-shape-probe.go
Set process-only GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, GOTELEMETRY=off; use the existing authenticated local module cache and fresh task-owned GOCACHE/GOTMPDIR. Do not set outer cross-target GOOS/GOARCH or silently alter CGO. Record requested child settings separately from go env output. Do not change process umask. Keep probe stdout/stderr in explicit 0600 files and scratch in explicit 0700 directories. Do not fetch missing dependencies/toolchains. A failed attempt stays in the record; any correction must be narrowly explained and distinguish source changes from results.
Required acceptance revision:
1. State the actual reachable PAX and GNU input shapes under the pinned reader, with exact record overhead. Use those in end-to-end ES validator tests.
2. Prove in the future production-counter tests that the intended entries reached and exercised the radix probe/commit sites. Construction or dependency-parser rejection is not a linearity pass for the ledger.
3. Separate three claims: successful archive-validator coverage, dependency refusal, and optional direct-ledger stress with strings larger than the dependency exposes. A direct-ledger test must not be mislabeled as a reachable PAX/GNU archive test.
4. Keep the 32,768 flat-entry maximum-shape analysis if the pinned reader confirms the EOF-terminated boundary. Preserve all stream/body/transport equality/+1 obligations and namespace/error precedence.
5. Do not raise/fork the tar reader's limits or add an ES name/count restriction. Clarify existing documentation only as necessary to distinguish ES's whole-stream policy from the dependency's inherited format-processing limits.
The CUST-1 defect remains substantive even if the dependency reduces the reachable single-name maximum. Do not dismiss quadratic scanning or deep-prefix work merely because the original test size was mistaken.
Deployment evidence and realistic next gate
Original sections 3.3/3.5/9 refer to a Remote Alpha ES mount namespace and exact-path sibling binds, while the cited launcher is scripts/internal/control_plane.sh. Do not equate a repository launcher shape with a currently running deployment.
Using source and retained evidence only in this turn, distinguish:
- the claimed Remote Alpha ES service/process namespace;
- the supported-local/container launcher namespace;
- the ordinary AMD64/ARM64 native admission-test namespaces;
- a future actual exact/subtree bind-alias fixture.
For each, state the owning contract, concrete known identity or missing identity, observation obligation, and required effect authority. Historical es.service descriptions are not current liveness; ordinary native admission-suite passes do not prove a bind-mounted deployment shape. No running container or pre-provisioned alias fixture is to be invented.
Prefer moving the minimum deployment-compatibility observation ahead of broad CUST-2 implementation when it could invalidate the selected topology. Distinguish that pre-implementation feasibility observation from later execution of the repaired helper on real alias fixtures. The latter necessarily needs repaired bytes. Do not create a circular gate requiring that helper before it exists.
Name the smallest follow-on observation/fixture operation and its prerequisites. If it would need a stopped service started, namespace created, mount made, or privilege escalation, report that boundary explicitly; none is authorized here. Do not turn unavailable topology evidence into another general infrastructure-restoration program. Do not silently waive mandatory native mounted evidence or conflate auditability with commit/rollout readiness.
Outputs and stopping point
Write a fresh external directory with:
1. ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDMENT.md: an amendment, not another copy of all 415 original lines. Preserve accepted sections by reference; give replacement wording/algorithms/tests only for changed obligations.
2. A complete corrected touched-surface/acceptance matrix, with a concise delta from the authenticated original. Do not change the historical matrix or treat the historical 75-path count as a quota.
3. The small stdlib probe source, source identity, exact commands/environment, outputs, and source-bound feasibility table. Distinguish modeled reasoning, source inspection, and observed probe results.
4. Minimal relevant source excerpts and opening/closing byte-preservation record.
Include finding IDs, old claim, evidence/counterexample, selected correction, affected governing docs/tests/source, compatibility impact, remaining empirical obligations, and explicit provenance/validation/implementation confidence. If any probe cannot run, report the source-supported conclusion and exact missing empirical evidence without fabricating a result.
Do not claim a fresh independent review, implementation pass, repaired native pass, or commit readiness. Finish with one of:
- ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDED_READY_FOR_IMPLEMENTATION — only if the proof rules and reachable acceptance tests are settled, and no pre-implementation topology compatibility question remains unresolved. Later new-byte/native/alias-fixture/audit obligations may remain explicitly pending.
- ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDED_TOPOLOGY_OBSERVATION_REQUIRED — the algorithm/test design is corrected, but a precisely identified compatibility observation must precede implementation.
- ES_FINAL_AUDIT_REPAIR_DESIGN_CORRECTION_BLOCKED — a concrete proof, provenance, or design issue remains.
No repository mutation follows in this turn.
External review basis — inspect installed dependencies first
The following public primary sources informed ChatGPT's review. They corroborate external semantics, not private repository or live-host state. The pinned installed Go sources are decisive for this task.
Go archive/tar constants:
https://go.dev/src/archive/tar/format.go
Go archive/tar reader:
https://go.dev/src/archive/tar/reader.go
Go archive/tar writer:
https://go.dev/src/archive/tar/writer.go
Linux ext4 case-insensitive lookup documentation:
https://cdn.kernel.org/doc/html/latest/admin-guide/ext4.html
Linux proc mount metadata:
https://www.kernel.org/doc/html/latest/filesystems/proc.html
Linux man-pages project, proc_pid_mountinfo(5):
https://man7.org/linux/man-pages/man5/proc_pid_mountinfo.5.html


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
