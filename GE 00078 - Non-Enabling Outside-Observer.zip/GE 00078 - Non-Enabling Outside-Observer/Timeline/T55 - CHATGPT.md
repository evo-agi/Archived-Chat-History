**Move this exact successor to a fresh, read-only cumulative re-audit. Keep both the ES candidate and the external helper frozen.** The report supports completing the engineering repair phase; it does not independently establish that the nine findings are closed or that privileged execution is ready. Its stated endpoint preserves that distinction. :chatgpt-content-reference{index="0"}

**Send this to a fresh Codex audit conversation—not the implementation conversation: :chatgpt-content-reference{index="18"}[Episode, delivery, and receiver independent re-audit prompt](sandbox:/mnt/data/ES_Episode_Delivery_Receiver_Reaudit/ES_Episode_Delivery_Receiver_Independent_Reaudit_Prompt.md).**

The handoff authorizes inspection and independent analysis of retained evidence. It authorizes no repairs, test reruns, builds, host contact, gateway work, mounted execution, or repository changes.

## What is stronger in this result

The most useful reported improvement is the **producer-to-receiver composition**, not the increase to 628 passing terminals.

The positive control now starts with only its declared synthetic approved base. The actual caller creates the export children, publishes the outcome, persists the exact receipt, and the receiver reacquires that receipt from disk before authentication and semantic adjudication. It no longer obtains the receipt by simply accepting the producer’s returned structure. That directly addresses the previous missing-parent and undeliverable-receipt findings. **The auditor must verify that the real Linux caller follows the same path.** :chatgpt-content-reference{index="1"}

The report also distinguishes what actually executed from what was inspected or substituted: ordinary directory creation, serialization, held-object reads, receipt persistence, and replacement attacks used real task-owned files; privileged/kernel effects and trust/containment actors were substituted; Linux-only bindings include source and AST checks. That distinction must survive the next review. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

The evidence remains:

| Evidence | Reported result | What it does not establish |
|---|---|---|
| External-tooling unit and race lanes | **628 passing terminals in each**, with all 123 named top-level controls present | Privileged Linux lifecycle behavior |
| Supervisor A/B | Identical deterministic Linux builds | Execution of the supervisor |
| Safe executable and import closure | Exact inherited identities | Validation of the changed supervisor |
| Normal and diagnostic proof artifacts | Unchanged, retained compile-only artifacts | Any mounted-proof result |

The local execution platform is Darwin/ARM64; Linux vet and builds are separate static/build evidence. No additional safe-control or mounted-proof execution occurred. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

## The historical evidence gap has the right treatment

The missing original evaluator records remain missing, and the predecessor’s `INCOMPLETE` endpoint remains intact. The report does not claim that new execution reconstructed those old calls. :chatgpt-content-reference{index="6"}

For the successor, it now identifies a separate **8,058-byte evaluator invocation record**, binding executable/script bytes, arguments, working directory, environment, timing, exit, streams, inputs, and the produced decision. It also reports a current 85-member selected-input record rather than relying only on the complete source manifest. These address the previous evidence deficiencies in the appropriate place: **the new generation**. Their actual contents still require authentication. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

The new audit therefore has two separate obligations: assess current evidence completeness and preserve the historical limitation. It must not demand recovery of unused predecessor records as a permanent prerequisite for accepting independently complete successor evidence.

There is one coverage comparison worth making explicit. The previous report counted **269 required controls**, whereas this one identifies **123 named top-level controls**. Those are not necessarily the same counting unit. The prompt requires a source-backed crosswalk of retained, added, renamed, superseded, and excluded requirements—including descendants. Neither the larger pass total nor the smaller top-level count settles whether coverage was preserved. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

## What the re-audit should concentrate on

### The real lifecycle callers

The report describes the right ownership changes: one episode owner, saved scratch identities, progressively recorded process custody, and sticky signal authority. But the preceding audit repeatedly found defects **between a correct shared helper and its real caller**. The re-audit must inspect those connections, not simply confirm that the new types exist. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

The critical checks are whether pre-cancelled entry reaches any deliberate effect; whether cleanup consumes the originally qualified parent/root rather than a replacement; whether actual worker, formatter, and candidate error returns contain every fact learned before failure; and whether every signal path preserves the original authority across timeout and cleanup reentry.

The prompt requires exact source traces and identifies which controls exercise the real producer, which use substituted effects, and which only assert source structure. **A fake returning a complete partial identity still cannot prove that the real producer records that identity before its next failure.**

### Independent trust and a reachable receiver

The new receiver reportedly obtains its expectations and verifier independently, rejects operational failure even with matching authentication, and binds its reads to approved storage relationships. These are substantial claimed corrections to TPA-02, TPA-04, and TPA-05. :chatgpt-content-reference{index="13"}

The audit must establish that this independence is enforced by construction and call sites—not just expressed in a type name. Evidence must not select its own trusted verifier, policy, approved parent, or synthetic test profile.

It must also distinguish **pre-effect approved intent** from **post-creation observations**. A newly created object’s identity can only be observed after creation. The interface must explain which independent actor supplies that observation without either requiring an unknowable future identity or copying the export’s own claims into its expected context.

The positive synthetic verifier is useful for exercising that interface. It is not an established production trust source. Conversely, the absence of an installed signer is not automatically a new source defect when the interface is complete, explicitly injected, and fail-closed. **This audit does not commission a signing service, gateway, watchdog, or routine human-confirmation step.**

### Exact delivery without self-attestation

The report now specifies a frozen receipt written once to the sibling `<episode>.receipt.json`, with delivery observations kept outside the receipt. The review must trace the actual bytes through publication, rereading, confirmation, and acceptance—especially partial writes, close/synchronization failures, cancellation, deadline expiry, duplicate publication, and failed failure-closeout. :chatgpt-content-reference{index="14"}

The receiver needs both a legitimate positive path and meaningful rejection paths. It must not always reject, accept merely because hashes agree, or allow external confirmation to rescue failed operations, uncertain cleanup, missing cases, unapproved residuals, or late delivery.

The new carrier also must remain compatible with the existing sealed bundle, ledger boundary, evidence limits, and scratch-removal scope. That is a review of the composed protocol—not permission to create another receipt hierarchy.

## Keep the next decision bounded

The report records **111 external source members**, with nine additions and 21 modifications, and a **59-row findings lineage** preserving historical judgments. The next audit covers that cumulative component while retaining narrow prior closures and disagreements; it should not reopen every historical finding indiscriminately. :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}

A satisfactory outcome may be:

```text
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_STATIC_REVIEW_SATISFIED_EXTERNAL_GATES_PENDING
```

That would establish scoped static adequacy and adequate current evidence—not privileged authorization or ES acceptance. Concrete source defects remain blocking; absent but adequately specified external establishment remains a separate prerequisite.

Residual policy, administrative entry and real approvals, target/formatter qualification, external containment and confirmation, actual mounted cases, deployment observation, supported-local proof, the **unconditional whole-candidate ES audit**, and exact-byte staging/commit authority remain outstanding. None is advanced automatically by this report. :chatgpt-content-reference{index="17"}

## Inspection boundary and confidence

I read the complete attached report and computed its fingerprint: **20,553 bytes**, SHA-256:

```text
588c8622bde95564d95869c26d012bcde89a2e75b8f2be550e599a5fdc14457e
```

The current ZIP, implementation, raw streams, and invocation records were not attached here. Their detailed authentication and execution remain **owner-reported**. The prompt supplies their retained paths and expected identities so the fresh Codex reviewer can inspect them directly without another collection task. No repository commands, tests, hosts, or privileged operations were executed in this review.

**Sources:** attached episode/delivery/receiver report, preceding cumulative re-audit, and the preceding repair handoff. **Confidence: 0.96 in proceeding to this re-audit.** Attachment identity is established; current source correctness and validation adequacy await independent inspection. Privileged readiness and whole-candidate acceptance remain unestablished.
