## Retain the block and repair only the poll prerequisite binding

The exact review supports the three R26.G04 repairs on their intended paths. The new blocker is narrower:

```text
R26-G05-FRESH-01
```

The poll request may reference actual owner instances, but those references must **not select replacement prerequisite producers**. The fixed session and peer relationships in `ADMISSION_PREREQUISITES.json` must govern dependency readiness and activation:

```text
session:
q-custodian-0133-accept4-owner
← q-custodian-0133-accept4

peer:
q-custodian-0212-peer-pidfd-owner
← q-custodian-0212-peer-pidfd
```

Do not return to Codex or resume general-join work yet.

### ES_R6J_R26_G06_POLL_ROLE_REPAIR_HANDOFF_20261024_34.zip[Download the R26.G06 poll-role repair handoff](sandbox:/mnt/data/ES_R6J_R26_G06_POLL_ROLE_REPAIR_HANDOFF_20261024_34.zip)

:chatgpt-content-reference{index="1"}[Handoff verification](sandbox:/mnt/data/ES_R6J_R26_G06_POLL_ROLE_REPAIR_HANDOFF_20261024_34_VERIFICATION.json)

```text
Bytes:             1,678,180
Members:           73
SHA-256:           b9365bb2e4d83ce1c106c826677ee1f7791f797258826570032554c6c5acc2ce
Verification:      PASS
```

The handoff includes:

- the complete blocked G05 review and finding;
- exact current admission, activation, premise, semantic, and entry sources;
- the prerequisite, native-scope, and registry tables;
- current positive G/B/C;
- the existing wrong-role and known-error poll specimens;
- their retained execution records;
- two newly constructed **inert static counterexamples**:
  - known poll error combined with the wrong fixed session role;
  - another arbitrary same-actor custodian acquisition substituted as the session role;
- the decision record and complete owner task.

The static counterexamples were not executed and are not acceptance evidence. They make the required regression concrete.

## Selected repair semantics

### Fixed producer edges remain authoritative

For both poll operands, the successor must validate:

1. the referenced owner exists;
2. its actor matches;
3. the referenced instance equals the fixed expected owner;
4. its producer equals the fixed producer in the prerequisite table;
5. responsibility exists by admission;
6. the fixed producer passed ordinary admission.

The request-selected acquisition must never replace `producer_request` for dependency readiness.

### Preserve predicate distinctions

The intended refusal ordering is:

| Condition | Predicate |
|---|---|
| Referenced acquisition absent | `POLL_CUSTODY` |
| Referenced acquisition has the wrong actor | `POLL_OWNER_ACTOR` |
| Existing same-actor acquisition has the wrong fixed owner or producer | `POLL_ROLE` |
| Exact fixed acquisition is late or its fixed producer is unadmitted | `ADMISSION_OWNER_PREREQUISITE` |

Do not add registry constants that cause these cases to stop at an unrelated grammar predicate.

The later `native_account` `POLL_ROLE`, custody, descriptor, and input-channel checks remain as defense in depth.

### Prevent first-failure masking

The review’s strongest case combines:

```text
known poll error
+
same-actor wrong session role
+
later same-scope recvmsg
```

Under the current reader, the invalid poll may be admitted through the substituted producer, install sticky state, and make the later request stop at `PHASE_STICKY_STOP` before `POLL_ROLE`.

The repaired successor must instead refuse the poll itself at:

```text
POLL_ROLE
```

It must activate no request, owner/result fact, or sticky error.

A separate exact-role known-error poll must remain admissible and may still cause a strictly later same-scope request to reach `PHASE_STICKY_STOP`. That preserves the legitimate sticky-error behavior.

## Message to send

Send the handoff to the **same ChatGPT artifact-owner conversation that produced R26.G05**, not to Codex or the reviewer:

```text
Repair R26-G05-FRESH-01 under NEXT_OWNER_TASK.md.

Read README_FIRST.md, DECISION_RECORD.md,
receiving/RECEIVING_INSPECTION.md,
receiving/POLL_PREREQUISITE_ANALYSIS.json, and the complete blocked review
before authoring. Authenticate the exact R26.G05 owner already present in
this conversation.

Bind both q-eof-0004-ppoll owner fields to their fixed prerequisite
relationships before readiness and activation:

- session owner q-custodian-0133-accept4-owner, produced by
  q-custodian-0133-accept4;
- peer owner q-custodian-0212-peer-pidfd-owner, produced by
  q-custodian-0212-peer-pidfd.

The actual owner fields remain typed B evidence, but they must not select a
replacement producer. Readiness must always use the fixed producer_request.

Preserve the predicate distinctions:
- missing owner -> POLL_CUSTODY;
- wrong actor -> POLL_OWNER_ACTOR;
- wrong existing same-actor owner or producer -> POLL_ROLE;
- exact fixed owner that is late or whose producer is unadmitted ->
  ADMISSION_OWNER_PREREQUISITE.

Change both readiness and prerequisite validation. Preserve atomic wave
commit, fixed graph edges, strict sticky causality, downstream POLL_ROLE and
input-channel checks, inherited C, and all prior G04 closures.

Save and reopen a substantive checkpoint before broad regression. It must
include actual successor-reader results for:

- current positive;
- unchanged repair__POLL_SAME_ACTOR_WRONG_ROLE;
- a fully rebound known-error plus wrong-fixed-role composition;
- an arbitrary same-actor wrong-role specimen;
- exact-role known-error sticky behavior;
- missing-owner and wrong-actor cases;
- exact-role wrong-input isolation.

The known-error/wrong-role case must refuse at POLL_ROLE and must not install
sticky state or mask the poll defect behind the later recvmsg admission.

Run the newly authored successor reader for all current full-reader
obligations and new controls. Reconcile the 393-row register, 180-state
table, companion, displacement ledger, historical controls, G05 controls,
checkpoints and rounds. Preserve every historical byte and evidence layer.

Return exact scoped reconstruction, preservation evidence and one verified
owner package. Do not amend the normative pair, expand general joins, launch
Codex, access repositories or hosts, execute uploaded predecessor/reviewer
programs, or claim independent acceptance.

Return the endpoint:

OWNER_R6J_R26_POLL_PREREQUISITE_ROLE_BINDING_REPAIRED_REVIEW_REQUIRED
```

If the original owner conversation is unavailable, start a fresh owner conversation and attach the two R26.G05 owner transport ZIPs with this handoff.

After delivery, a different ChatGPT reviewer must inspect the exact successor. General-join design remains paused until that review succeeds.

**Sources:** exact uploaded G05 blocked review; authenticated R26.G05 owner source and specimens; receiving-authored static counterexamples included in the handoff.  
**Confidence:** **0.99** in the blocking diagnosis and input identities; **0.98** in the fixed-producer repair direction. Successor correctness and independent acceptance remain unestablished.
