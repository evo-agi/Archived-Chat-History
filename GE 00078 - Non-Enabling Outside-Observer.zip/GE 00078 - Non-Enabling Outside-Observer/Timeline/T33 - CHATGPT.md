**Proceed to the independent v2 re-audit, in a fresh Codex conversation. Keep the ES candidate frozen; root execution remains unauthorized.** The report supports completing the external repair phase, but it does not independently establish that the sixteen findings are closed or that the fixture is ready to run. Its disposition preserves that distinction. :chatgpt-content-reference{index="0"}

**Send this to the fresh audit conversation: :chatgpt-content-reference{index="18"}[Mounted-helper v2 independent re-audit prompt](sandbox:/mnt/data/ES_Mounted_Proof_V2_Reaudit/ES_Mounted_Helper_V2_Independent_Reaudit_Prompt.md).**

The handoff reviews the actual replacement implementation and retained evidence. It does **not** authorize another repair, repeat the completed ES suites, execute the Linux binaries, or install the proposed privileged gateway.

## What carries forward

The reported preparation is materially stronger than v1’s compilation and shell-syntax checks. V2 has explicit resource owners, a compiled controller, strict event adjudication, and ordinary-user fault controls. But its evidence still has three distinct scopes:

| Evidence | What the report supports | What it does not establish |
|---|---|---|
| External tooling tests: 222 passing events in each ordinary and race run | Portable controller, adjudicator, and custody behavior under substituted effects | Linux mount, loop, privilege-transition, or kernel cleanup behavior |
| Three Linux/AMD64 binaries compiled | Buildability of the supervisor, normal proof, and diagnostic proof | Successful execution of any of them |
| Preserved 358-file source and 83-path candidate | Reported continuity of the previously validated ES target | Independent product acceptance |

Here, the “native” external control run means **Darwin/ARM64 on the Mac**, not another native Linux admission run. The report explicitly identifies the platform and says the Linux supervisor and proof binaries were never executed. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

There is therefore no reason to repeat the product-validation cycle merely to review this external successor. The re-auditor should authenticate the preserved source and evidence, then examine the new tooling on its own merits. The report records unchanged repository and ref captures; those remain claims to verify against the retained records, not assumptions to inherit. :chatgpt-content-reference{index="3"}

## Three issues deserve particular attention

### 1. The privileged gateway is still a design dependency

The report says owner review found no remaining static implementation seam. It also lists **“independent design/installation/exact-byte authorization”** of:

```text
/usr/local/sbin/es-proof-approved-exec
```

as an outstanding prerequisite. That is more than a runtime capability check. The component may be internally complete under an assumed entry contract, but the **whole privileged execution chain is not yet established**. :chatgpt-content-reference{index="4"}

This is not automatically an implementation violation: the preceding repair prompt allowed independently trusted bootstrap availability to remain a prerequisite. The important question is whether v2 defines that prerequisite concretely, or merely moves the original intake and first-execution defects into an unnamed trusted mechanism.

The re-audit must trace where trusted authority begins, who supplies the approved identities, how exact input bytes reach privileged execution, and what happens when a required manifest value is absent or still a placeholder. A fully specified upstream dependency can permit **scoped static acceptance of the downstream component**. It cannot establish that the dependency exists, is installed safely, or is authorized.

**I am not selecting a separate permanent gateway project merely because the report names that path.** The audit should identify the minimum independently trusted entry properties and whether that particular component is necessary. It must not implement a gateway, alter access policy, or turn the fixture into a general privileged execution service.

### 2. The diagnostic build needs an effective-source review

The diagnostic mechanism is a legitimate candidate for addressing F-12, but its interpretation must be precise. The report describes three separate source identities:

- The normal union contains the 358 original files plus the external driver.
- The diagnostic base union adds a supplemental diagnostic file.
- The diagnostic **effective** union also substitutes an instrumented copy of `results.go` through a compiler overlay. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

Go’s documented overlay behavior makes the build use replacement backing-file contents even when the original disk file remains unchanged. Consequently, **“the original source members were preserved” does not mean the diagnostic binary compiled the same effective source as the normal binary**. :chatgpt-content-reference{index="7"}

The new prompt requires review of the generator, overlay descriptor, exact diff, build tags, effective-source manifest, supplemental driver, and resulting binary binding. The reviewer must establish whether the inserted observations preserve the relevant control flow and distinguish the intended failure cause without changing the public error or bypassing production checks.

The historical F-12 disagreement also stays visible: one reviewer found the generic unavailable-result observation insufficiently discriminating; another gave narrower support from the exact source’s control order. V2 reports preserving both positions rather than rewriting the finding. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

**The normal binary must independently satisfy the normal behavior and protected-state requirements.** A successful instrumented trace may supply supplementary causal evidence; it must not rescue a failed normal case or be presented as runtime execution of the original effective source.

### 3. The live Go adapter—not just its portable model—needs scrutiny

The report’s 170 fault-injection points are useful preparation evidence. They are not proof that every failure window in the real Linux adapter is covered. The report itself limits these results to controller tests using a fake-effect adapter. :chatgpt-content-reference{index="10"}

The re-audit must derive the live-effect inventory from source and compare it with those controls. In particular, an adapter operation that performs several syscalls can acquire a resource and then fail before returning. A fake operation modeled as simply “succeeded” or “failed” may miss that interval. This is the same class of ownership question that made v1’s loop-association-before-ledger window dangerous. :chatgpt-content-reference{index="11"}

The move to compiled Go also introduces runtime-specific review obligations. Go documents that `LockOSThread` binds a goroutine to an OS thread, while its Linux `Pdeathsig` field refers to the death of the **creating thread**, which may precede process termination. Those distinctions make thread ownership, namespace transitions, credential changes, and child creation important source-review targets. They are not findings against the uninspected implementation. :chatgpt-content-reference{index="12"}

The prompt therefore requires the reviewer to trace the actual startup and transition sequence against the **pinned installed Go source**, not assume that public current documentation authenticates Go 1.26.5 or the named host. It also covers descriptor inheritance, complete credential observations, process supervision, partial acquisition, cleanup uncertainty, and formatter dependencies.

## Keep the final-audit obligation unconditional

One phrase in the new report needs tightening:

> “fresh whole-candidate audit after later source change”

The whole-candidate audit was already an outstanding pre-commit obligation. **It remains required even when no further ES source change occurs.** This external-tooling re-audit does not independently accept the combined ES implementation or replace that later audit. The earlier validation report preserves the obligation without making it conditional on another edit. :chatgpt-content-reference{index="13"} :chatgpt-content-reference{index="14"}

The re-auditor should inspect the actual remaining-gates document and report any inconsistent wording. It must not edit `PLANS.md`, rewrite historical reports, or create a new product freeze to correct an external report.

The same distinction applies to the gateway and runtime prerequisites: unspecified design, absent installation evidence, unbound target identities, and unexecuted behavioral checks are different categories. Calling them all “runtime-only” would obscure the next engineering decision.

## The next review should produce a bounded decision

The prompt retains an individual closure row for **F-1 through F-16**, adds review of the new v2 mechanisms, and requires three complementary read-only perspectives: lifecycle/Linux correctness, privileged input/output custody, and proof/oracle adequacy. The parent authenticates provenance and reconciles the results. Unlike the historical packet, the new packet must retain the actual specialist reports rather than only their synthesis. The v2 report explicitly discloses that the earlier raw specialist reports were unavailable. :chatgpt-content-reference{index="15"}

A successful result can be:

```text
ES_MOUNTED_HELPER_V2_STATIC_REVIEW_SATISFIED_ENTRY_AND_RUNTIME_GATES_PENDING
```

That means the reviewed component is statically suitable under explicitly stated prerequisites. It is **not** root authorization or a complete executable approval package. An unspecified dependency that conceals an unresolved custody defect must instead remain a blocking finding.

The next task after that review should be determined by its concrete result: a bounded external repair, or the minimum privileged-entry preparation needed before execution. Receipt checks and capability checks can later be internal stop gates of a properly authorized task; they do not inherently require a separate user relay for each step.

Actual mounted proof, deployment observation, supported-local consumer/operator proof, whole-candidate audit, and exact-byte commit authorization remain outstanding. Nothing in this report passes or waives them. :chatgpt-content-reference{index="16"}

## Inspection boundary

I verified the attached report’s **18,796 bytes** against SHA-256 `3efefaf0…855484`. Its five source/candidate/archive/member/inventory identities agree with the preceding attached preparation and assurance reports. That establishes attachment identity and cross-report consistency—not authentication of the underlying tooling.

The current ZIP, controller/live-adapter source, overlay, raw control streams, and compiled artifacts were not attached here. The new audit prompt supplies their retained paths and expected identities so Codex can inspect them directly without another collection task.

Include the **existing v2 review ZIP with the audit result**; no rebuild of that input packet is needed.

**Sources:** attached v2 repair, v1 audit, preparation, and ES assurance reports; official Go documentation for the narrow overlay/thread distinctions above. No repository code, tests, hosts, or privileged operations were executed in this review.

**Confidence:** **0.96 in proceeding to this re-audit.** Report-byte provenance is verified; control execution and repository preservation remain owner-reported pending artifact authentication. Privileged-entry completeness, live-adapter correctness, mounted behavior, and whole-candidate acceptance remain unestablished.
