Here is Codex's response:



## Verdict

`ES_NATIVE_LINUX_VALIDATION_FAILED_CANDIDATE_REPAIR_REQUIRED`

The authenticated AMD64 candidate failed its single complete native suite. Per the sequential gate, ARM64 was not started or tested.

### AMD64 results

| CommandExitResult                       |   |                                         |
| --------------------------------------- | - | --------------------------------------- |
| `go version`                            | 0 | Go 1.26.5 linux/amd64                   |
| governed `go env`                       | 0 | Native/offline task environment applied |
| `go mod verify`                         | 0 | All modules verified                    |
| `go list -m all`                        | 0 | 59 modules                              |
| `go test -json ./es/admission -count=1` | 1 | Package failed                          |

The well-formed 2,449-line JSON stream recorded:

- 607 test paths run
- 595 passed
- 12 failed
- 0 skipped
- 58 of 69 required paths passed
- All 19 staging-custody top-level tests and all 22 staging subtests passed
- Both Linux `openat2`/`renameat2` and mount-crossing tests passed

The 12 failing paths were the submit/golden cluster:

- `TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery`
- `TestSubmitAmbiguousNomadFailurePreservesPrimaryErrorAndRetainsRoot`
- `TestSubmitRejectsUnexpectedStagingChildBeforeNomadAndRetainsTree`
- `TestTrancheB1DefaultProfileLiteralNomadJobAndAuthorityHandoff`
- `TestTrancheB1PayloadDigestLineageIsDistinctPrivateAndPreEffect`
- `TestTrancheB1QualifiedHostCaptureNormalizesEquivalentConfiguration`
- `TestTrancheB2ControlPlaneNormalShellLiteralNomadJobAndAuthorityHandoff`
- `TestTrancheB2PreSubmissionOperationalCausesUseFixedPublicMessages`
- its `platform_owner` and `trust_capture` subtests
- `TestTrancheB2SubmitPublicNomadFailureIsFixedAndProviderBodyFree`
- `TestWorkstreamCSubmitReceiptRemainsBoundedAndHidesSchedulerIdentifiers`

The control-plane golden’s five `wrong_job_*` and three `wrong_handoff_*` required subtests were unexecuted because their parent failed first.

### Attribution

The shared test fixture sets `RuntimeSupportBinary` to `/bin/sh`. On governed Ubuntu, `/bin` and `/bin/sh` are symlinks. The candidate’s Linux custody implementation intentionally uses `RESOLVE_NO_SYMLINKS`, so the fixture is rejected before the intended Nomad/golden assertions.

This is a candidate test-harness portability defect. Custody was not weakened, the host was not altered, and the suite was not rerun.

The harness also incorrectly expected `go env GOENV` to print `off`; official Go 1.26.5 prints an empty value when process environment `GOENV=off` is effective. Raw evidence is preserved, and this analysis-predicate defect does not affect the package-failure verdict.

### Preservation and closeout

- Repository remained `trunk_dev` at `b92bd9884106154d25342e1573dcc4c312311436`.
- Opening/closing status, 2,242,910-byte tracked diff, 352-file source manifest, and 75-row candidate manifest were identical.
- Toolchain and module-cache manifests were identical before/after.
- AMD64 task root was removed after evidence return and observed absent twice.
- ARM64 remained `Stopped`, configuration digest unchanged, start count zero.
- No repository edits, staging, commit, push, fetch, worktree mutation, repair, deployment, final audit, sudo, installation, download, mount, or tracing occurred.

Returned AMD64 evidence registry: 41 authenticated files, 13,251,236 bytes, SHA-256 `e539fcb786c54a7fe9c30beaa9a6d1c6d198431aaeef92356b2b95cfc54d19b0`.

### Review packet

[Download the review ZIP](/Users/ds/Downloads/ES-native-linux-validation-20261004T2315Z-mhwpie03.zip)

- Size: `259237` bytes
- SHA-256: `fcb0a00e06687190072049707b9ec2e6520dc20a17190702b925a0d4618c33d1`
- ZIP integrity test: passed
- Per-file manifest SHA-256: `236597f780be27fb0266a83f4d53077942c2767d2f48066d21f72ff6bcff2610`

The full [validation report](/private/tmp/ES-native-linux-validation-mhwpie03/report/native-linux-validation-report.md) and raw private evidence remain under `/private/tmp/ES-native-linux-validation-mhwpie03`.
