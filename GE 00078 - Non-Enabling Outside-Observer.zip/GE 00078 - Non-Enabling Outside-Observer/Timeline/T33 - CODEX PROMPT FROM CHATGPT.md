ES mounted-helper v2 — independent source, proof, and privileged-entry re-audit
Objective and stopping point
Use a fresh Codex audit conversation, separate from the implementation/preparation conversation. Audit the exact external v2 successor identified below against all sixteen findings in the rejected v1 audit, the unchanged ES contracts, and the replacement implementation's newly introduced mechanisms.
Decide whether the v2 component is statically suitable to proceed to a bounded privileged-entry preparation decision, and identify exactly what remains outside that conclusion. Do not execute or authorize root work. Do not assume the owner's statement that there is no remaining static seam establishes end-to-end executable readiness.
This is the promised independent re-audit, not another architecture-design round. The selected finite supervisor/namespace-worker/candidate/adjudicator ownership model remains the implementation target. Do not prescribe a general privileged framework, standing service, platform migration, or additional product functionality merely to review it. Identify a concrete defect where a correction is required.
Two decision boundaries are particularly important:
1. /usr/local/sbin/es-proof-approved-exec is a proposed, unapproved entry dependency, not an authenticated installed capability or an automatically selected new project. Determine what exact independently trusted bootstrap properties v2 needs and whether its assumptions are complete and non-circular. No gateway design, installation, privilege policy change, or gateway execution is authorized here.
2. The diagnostic binary uses a compiler overlay. The original repository and original on-disk source members may be unchanged while the diagnostic effective compilation source is different. Review normal and diagnostic proof claims separately; diagnostic observations must not substitute for successful normal-binary behavior.
1. Effect authority for this audit
Authorized:
- Read local retained artifacts and current ES guidance/source; authenticate files, manifests, archives, evidence, and ELF metadata as data.
- Use narrowly scoped, nonmutating Git/provenance queries after inspecting configuration and attributes. Set optional locks off, disable fsmonitor for queries, and disable external diff/textconv/filter behavior for comparisons. Do not invoke repository hooks or helper scripts.
- Safely extract review packets into one newly created owner-only audit directory under /Users/ds/Downloads.
- Write audit-owned reports, independent data parsers, evidence comparisons, and compact packaging only under that directory. Independently replay retained JSON streams and arithmetic as data. Do not import or execute the reviewed tooling merely to verify it.
- Consult primary upstream documentation/source for actual interfaces used. Distinguish public-reference semantics from the exact installed compiler and future host facts.
- Use three bounded read-only specialists after authentication: (a) native lifecycle/Go/Linux mechanics; (b) entry/import/export custody and authority; (c) proof driver, diagnostic overlay, and adjudication. Parent owns provenance, integration, claim accuracy, and final judgment. No nested delegation or child writers; preserve disagreements and collect the actual specialist reports into the final packet. One failed-start retry is allowed; do not manufacture consensus or hide missing coverage.
Not authorized:
- Any mutation, formatting, test, compilation, build, staging, ref/index/worktree change, or status-document update in ES or another repository.
- Editing the v2 root, v1 artifacts, historical audit, validation records, source unions, manifests, or retained caches.
- Running the 17 preparation commands again; running external controller tests, reviewed generators, either proof binary, the supervisor, live adapters, old scripts, or repository scripts, including help/dry-run entry points.
- SSH/network contact with the target, metadata polling, transfers, root/sudo, gateway execution or installation, namespaces, loops, mounts, formatters, credential/capability changes, VM/Docker/service/workload operations, downloads or dependencies.
- Independent whole-candidate acceptance, final-audit readiness, mounted-proof acceptance, input-import authorization, stage/commit/fetch/push/PR/merge/deployment, or cleanup of historical material.
Do not discover whether an unauthorized effect "works." Runtime absence is not permission to change the environment. Limit ordinary audit output writes to the fresh audit root.
2. Authenticate the exact target before implementation judgment
V2 successor
Root:
/Users/ds/Downloads/ES-mounted-helper-v2-repair-j4Xz0AQK
Input	Expected identity
ES_MOUNTED_HELPER_V2_REPAIR_REPORT.md	18,796 bytes; SHA-256 3efefaf0a394caa706820029377f42ec6805e596c7401a0acabfb7107b855484
review/ES_MOUNTED_HELPER_V2_REPAIR_REVIEW.zip	SHA-256 5d888be91c4898783410cec3f0fa6cced305f366f1f6281d35caaf44ae02737f
review/MANIFEST.tsv	SHA-256 5de1b3baa22132bba6c8c7a8883b224976130871804b031ab97e501e90df29a6
FINAL_ARTIFACT_IDENTITIES.json	SHA-256 00f4e804337f9a67210e68dec94465e26c18593dbae442bed7437041245af48d
docs/preparation-commands.json	SHA-256 9f064f3226223aa2043f679e3c3adc3f9ee369e492b938810803948e27f59ddd


Read the real manifest schema and exact source path map. Do not assume a member count or reconstruct a missing source from this prompt. Authenticate ZIP CRCs, safe unique relative names, allowed regular-file types/modes, size/hash agreement, and complete self-excluding coverage. Read identities JSON as an acyclic binding record, not authority. Inspect its complete relationships, including report/ZIP/manifests and separate artifacts. Classify unregistered material rather than deleting or quietly incorporating it.
Read all v2 tooling, its tests, driver/instrumentation, generation sources, and relevant documentation directly. Specifically include:
- OWNER_STATE_EFFECT_TABLE.md;
- docs/FINDINGS_CLOSURE_MATRIX.md;
- docs/CASE_PERMISSION_RESOURCE_TABLES.md;
- docs/FUTURE_PRIVILEGED_EXECUTION_SPEC.md and docs/future-root-commands.json;
- the approved-manifest template, remaining gates, and v1–v2 deltas under docs/;
- records/final-safe-controls.json, every command record/stream supporting its conclusions, and all eleven preserved development-failure records;
- actual normal/diagnostic source-union manifests, extraction equality, overlay, generation diff, compiler/environment records, binary records, and code needed to reproduce those derivations by inspection;
- source excerpts and their whole-file bindings, not excerpts as a substitute for necessary surrounding code.
The following compiled artifacts are retained separately, and may be inspected as data only:
Artifact under v2 root	Size / mode	SHA-256
artifacts/es-mounted-proof-v2-supervisor-linux-amd64	5,325,174 / 0755	ecf1b43536d01b79a65b8a650b9586cce45bc7d389d385cc90f90730b2c7535f
artifacts/cust2-mounted-proof-v2-linux-amd64.test	23,584,746 / 0755	4ab09cadc6032b647b7c2b8b6bc65229569e9919e8add3db206521c537b4e9a1
artifacts/cust2-mounted-proof-v2-instrumented-linux-amd64.test	23,600,843 / 0755	66390b3b5de24443f4c41776ac1dc322bd6b7ed71a0623761e23cdb50dd0121b


Historical finding target
Audit root:
/Users/ds/Downloads/ES-mounted-helper-preexecution-audit-2tHGL4BU
- packet/ES_MOUNTED_HELPER_PREEXECUTION_AUDIT_REPORT.md: 33,252 bytes; 03eecb213038cd0b38064c126781172befd1327d8fc77314765b04c0542e4116.
- ES_MOUNTED_HELPER_PREEXECUTION_AUDIT.zip: 32ed49aa87407e256dd77891122b9250d55e09bd75d9a9f22824b5158d0e1b28.
- packet/MANIFEST.tsv: 4b2ae3229eb5f44a64d4bc65b47e3e8eca5e2ec6e577512b375be01b45fe04f1.
Rejected preparation:
/Users/ds/Downloads/ES-mounted-helper-proof-preparation-nFVwkJ
- review/ES_MOUNTED_HELPER_PROOF_PREPARATION_REVIEW.zip: 2ab1d48f478712953b415204f397a984eacbc5ff7cb97961486ec5cf532e939c.
- MANIFEST.tsv: 439 rows; 237ead1ac6c8ba931a7326c24aa90681847108274a5c2d3f6781e635758beca4.
Use the authenticated old report and old sources to check each original failure and the actual replacement. The v2 report explicitly says separately named raw historical specialist reports are absent. Preserve that limitation and the parent's recorded F-12 disagreement; do not invent missing text, and do not block solely to recover it where the authenticated parent report establishes the old finding adequately. The new specialist reports must be retained as actual outputs.
Preserved ES candidate and validation
Repo: /Users/ds/Repositories/Execution Substrate
Retained validation root:
/Users/ds/Downloads/ES-cust2-nsfs-assurance-validation-kgthnJ
Binding	Required identity
Branch / upstream	trunk_dev / origin/trunk_dev
HEAD	b92bd9884106154d25342e1573dcc4c312311436
HEAD tree	cdd4e44bac15c1952d70997143040644361f0bb1
Source	358 rows / 67,617 bytes / e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e
Candidate	83 rows / 10,037 bytes / 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2
Source archive	7,485,440 bytes / 12a8b8a626911d51dedf1b138b88deb314aff00d0de6ec063c96ac53d6146202
Archive-member manifest	358 rows / 79,414 bytes / 3e0195237c1b89fcb15242b886e17735c47d54b6710dd7ca8dafc1f6f63d4e5e
Product requirement inventory	327 rows / 141,680 bytes / 8b3ed6e32ba809bda751632292773c9adc28096691ad9307be32affa288515eb
Tracked diff	2,407,274 bytes / 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1
Complete integration diff	2,746,480 bytes / 38de7ecbcbb52252104710ddb6075a205a9c8a571590d96ed93247ba5a5501e0
Staged / conflicted / active Git operation	none
Worktrees	six; authenticate actual retained identity


Reproduce the relevant exact serializer semantics independently after reading their source. Include all original source bytes/modes, existing untracked members, index/status, refs and worktree state, not HEAD alone. Compare at opening and closing. Do not recursively reconstruct every historical generation or demand a new product snapshot.
V2 reports equal opening/closing 1,542-byte records at c0dbd33e46aad1124b6a9387f1b6e210f99552b492a5290a92d6e88c571e5995, and equal 23-row/2,369-byte refs at 54a0205eaf008a1aae52c396f5ebc3cd7cd6dd5b5eb6f78ef4e38d30f7a5f2f1. Verify actual coverage of those records, not just their length. Any later app-owned ref-name churn must be exactly disclosed and object-compared; no generic exemption. Source/target drift, unexplained ref/index changes, or unresolved recipe mismatch stops target acceptance.
3. Governing contracts and evidence classification
Read current AGENTS.md, the latest relevant PLANS.md, configuration/capability pages, and owning lifecycle contracts/design/implementation before code judgment. Read all six current execution-root files plus relevant integration in service, Submit, staging, and results. Include relevant tests, build constraints, init/TestMain, configs, examples, and retained validation evidence where needed for the driver and effect map. Do not substitute the historical 352-file archive for the current production implementation.
Preserve staging non-mutation, physical separation, descriptor-bound effects, fixed refusal/no-fallback, missing-root behavior, bounded metadata, and behavioral capability gates. Preserve the trusted-operator/stable-namespace threat limit; do not silently demand protection from an arbitrary hostile concurrently authorized root. Do not extend the threat limit to excuse accidental input replacement, process failure, or loss of custody already inside the fixture's claim.
External supervisor, gateway proposal, root manifest, ledgers and diagnostic traces are proof tooling/evidence. They do not become ES or Coordinator product authority. control-plane-normal-shell/v1 remains a bounded compatibility edge, not a reason to start CP/Temporal or broaden this fixture.
Prior ES local/native passes are source-bound historical evidence. The 222-event external control streams are not new ES validation and are not Linux-mounted proof.
4. Required substantive review
A. Privileged-entry completeness and custody — F-1/F-3/F-4/F-5/F-9/F-10
Trace the first root instruction to authenticated input import, executable publication, supervisor self-exec, namespace worker, formatter and candidate. Determine which checks are implemented here, which require an independently trusted gateway, and which remain unspecified.
- Review /usr/local/sbin/es-proof-approved-exec as an unimplemented/unapproved dependency unless actual authenticated evidence establishes otherwise. A pathname and a caller-supplied approved digest are not a trusted bootstrap. Determine its necessary interface, input authority, first-exec environment, FD handoff and replacement protection. If it simply inherits the old unreviewed custody problem, retain F-3/F-4 as unresolved.
- A fully specified upstream prerequisite can permit scoped static acceptance of a component; it cannot close end-to-end privileged entry or issue an executable authorization envelope. Distinguish those judgments. Do not force implementation of a permanent gateway merely because its name appears in the report. State whether a minimal already-trusted administrative entry could satisfy the required properties without designing or running it here.
- Enumerate every manifest placeholder by role and consumption point. Verify missing, dummy, malformed, unauthorized or caller-selected values cannot grant execution, destructive cleanup, or a pass. Distinguish immutable approval values from later observed target identities and checked receipts.
- Check no-follow component/leaf opening, held-object hash/copy identity, exclusive destinations, hardlink/nonregular refusal, stable input handling, quarantine, image paths, existing-base refusal and root-private control data. No read-back after a dangerous import excuses the initial disclosure or execution.
- Independently verify every binary/backing/view ancestor's permissions for UID/GID 1000, not just final leaves; keep control/evidence mutation inaccessible. Check exec mount properties, CWD, stdin and inherited FDs as well as modes.
- Verify absolute command resolution and complete formatter/runtime-input treatment. Direct mount syscalls do not remove the formatter's transitive executable/configuration/loader dependencies. Describe exactly what is approved versus a future identity slot; do not infer target identities from installed versions or historical host metadata.
B. Compiled Go and live-adapter correctness — new implementation surface
Compilation and fake-effect tests leave the actual Linux adapter unexecuted. Review the final build-selected implementation rather than assuming the old shell findings were closed by changing languages.
- Map every live syscall/exec/FD transition to its owning process and, where applicable, OS thread. Inspect raw-syscall versus runtime-coordinated credential changes, thread binding, namespace changes, fork/exec startup, and worker/candidate init order against the pinned installed Go source.
- Verify no goroutine scheduling or thread reuse causes observation/effect disagreement, mixed namespaces/credentials, or loss of the designated parent-death owner. Establish the actual process/thread identity observed by each /proc projection. Inspect the creation-thread lifetime underlying any parent-death signal and the recheck after credential transitions.
- Check credentials, groups, every claimed capability set, securebits, no-new-privs, limits, environment, CWD, stdin and descriptor closure are established before candidate/driver initialization can touch protected inputs. Verify which properties are inherited versus re-observed inside the candidate.
- Derive the actual live-effect inventory independently, including suboperations inside an adapter that can fail after acquiring a resource. Compare it with the reported 170 injected effect occurrences. Passing a fake atomic Acquire does not cover an unrecorded multi-syscall live acquisition.
- Inspect syscall return values, partial writes/reads, error precedence, Linux ABI structures, cancellation/signal paths, and any platform-specific stubs. A nonprivileged modeled test cannot excuse a concrete source defect in the live path.
Primary public review references, not evidence of pinned bytes or current host behavior:
https://pkg.go.dev/runtime#LockOSThread
https://go.dev/src/syscall/exec_linux.go
https://go.dev/src/cmd/go/internal/work/build.go
Use the installed source bound to the reported Go executable (3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19) for version-specific conclusions. No compiler or test execution is authorized to acquire that evidence.
C. Resource ownership and honest cleanup — F-2/F-6/F-7/F-11/F-15/F-16
Trace every success and partial-failure path from image creation through export. Explicitly revisit the v1 effect-before-ledger window.
- Pending intent precedes effects; held ownership or recoverable in-memory state precedes the next fallible bookkeeping. Inspect acquisition success followed by failed validation/receipt/write, not only clean success and pre-effect failure.
- Verify fresh image identity, bounded LOOP_CONFIGURE/autoclear, device/backing identity and all used offset/size/flag fields, descriptor transfer and last-release order. Do not invent an association-generation identifier. No stale loop number/backing pathname provides detach authority; available number is not exclusive ownership.
- Confirm private propagation before the first fixture mount; the fixed one ext4 plus 22 bind inventory; worker/supervisor namespace differences; recovery observer ability; reverse ordinary unmount; and exact resource identities before destructive operations.
- Follow candidate/worker/gateway/supervisor death, signal, deadline and transport-loss handling. Check pidfd/process-group ownership, forwarding/escalation, wait/reap and no cleanup while a candidate still owns references. Retaining namespace descriptors can affect destruction; identify every reference and its release.
- Every inventory must distinguish successful emptiness from permission/read/parse/timeout/truncation failure. Failure cannot become absence. Require source support for residual observations before image/run deletion and clean declaration.
- Simultaneous observer loss may remain explicitly uncertain under the selected threat model. Kernel release mechanisms are risk reduction, not an invented clean receipt; no autonomous later recovery outside declared authority.
- Verify resource bounds actually apply to all relevant logs, evidence, processes, FD capture, image/scratch and diagnostic runs. Separate OS-enforced from application-enforced ceilings and exclude unwarranted claims of hard containment. Inspect compatibility assumptions for prebuilt Go executables without executing them.
- Keep primary, cleanup, inventory and export outcomes independently persisted. Root-private originals and partial state must survive failed export. Export only authenticated allowlisted regular evidence to a new safe destination; no broad chown/delete, arbitrary path instruction, or untrusted child assertion authorizes root cleanup.
D. Normal proof, diagnostic overlay, and oracle adequacy — F-8/F-12/F-13/F-14
Reconstruct both compilation inputs, not only original on-disk member equality:
Binding	SHA-256
359-row normal union	770f3e8247be02ff0b0e6957f6c4c9b92fa90232dcb6600dcb17726f14102250
360-row diagnostic base union	d9469ac42f7b18b68fafa8d7ec9896fae5706a0392036f2e3492f622e11f158d
360-row diagnostic effective union	178a2d2c6e966c93b61cdb16241b4aa846765097f787f85a4b6e8a85811e1ddb
normal driver, 43,016 bytes	c4daf264476414f33429021fb33e4df8cfc78925c7677a0abc9319c872427f93
supplemental driver, 5,347 bytes	7d9e4da06d616d4e8879d22e7296f95d37ef2e63b1c1f175f97306f9a8f6698f
original es/admission/results.go	4a6de012b2f6d4fb0f0673599668847971c08fedc3be58013e659d8767cd54b7
generated overlay copy, 39,022 bytes	e0ada9ed6262d873ef5a66c5b6c0853d41cb9081f08d8670cec980e73b556061
overlay descriptor, 231 bytes	0431a17e13c7a2afe67c78567b05a85d12dda96f5c31a4fdd55ddc06345508cd
generated diff, 3,125 bytes	359c128c8f7391aef21c00e736aa682761d8fe4b9234e87743117910a826fb65


Resolve exact member paths through authenticated manifests. Verify complete original-member equality for both base unions and the precise effective replacement selected by the overlay/build tags. Review the generator as well as the generated diff. No extra overlay replacement, deleted original, alternative classifier, public hook/export, go:linkname, changed error condition or reordered effect may hide behind the word instrumentation.
- Independently establish whether each diagnostic insertion is observational and whether its trace is bound to the specific retained-read/public-result call. Inspect trace clearing, identities, ordering, duplicate/missing events, failure handling and stale/global state between calls. Describe any observational perturbation and limits; do not demand an impossible claim of zero instrumentation overhead.
- Preserve the historical F-12 disagreement. A separate direct qualifier result does not establish the later public call's cause. A diagnostic on different effective source supplies supplementary causal evidence, not runtime execution of the original bytes. The normal binary must independently satisfy every normal behavior and protected-state requirement.
- Preserve all eleven case identities and independently verify the eight diagnostic refusal counterparts. Verify case isolation, fixture preconditions, genuine casefold relationships, exact source/binary/run/namespace/credential binding, and reset/reobservation between normal and diagnostic processes. A setup failure, EACCES, unavailable capability, generic error, missing case, skip or parent-only pass is not a successful refusal case.
- Verify independently fixed sentinel values, per-node bounds and before/after checks, result artifact absence and zero provider fallback. State what post-state comparison establishes and what stronger source/diagnostic evidence supports; do not claim detection of every transient/idempotent mutation from equality alone.
- Verify exact parser/event/process/test-terminal requirements, full completeness and size bounds, duplicate JSON keys, wrong identity, fake successful exit, incomplete export and cleanup uncertainty controls. Trace expectation provenance so the same observed output cannot generate its own expected values.
- Positive primitive qualification is not a complete deployed Submit. reconcileRetainedResultArtifacts remains direct package-local helper coverage unless actual current source establishes a production caller; do not create one. All source-call maps and report labels must agree.
E. Validation evidence and acceptance sequencing
Independently parse the retained ordinary-user control streams and all 17 command records. Verify exact target, command, selected build files, requested/effective environment, exit, stderr, terminal completeness, counts and source binding. The reported 222 native-host and 222 race pass events refer to external tooling on the Mac, not mounted Linux runs. Native/race parent/subtest events are not 444 independent kernel scenarios. Preserve all development failures and outdated manifests; verify final evidence follows the actual final source versions.
Review all F-1…F-16 individually. Record static closure or remaining defect, exact path/lines, control adequacy, and runtime-only remainder. Add new v2-specific findings where justified. Do not keep a proven static repair open merely because the explicitly future mounted run has not occurred; do not close a static gap merely because a future behavioral probe is promised.
Correct the interpretation of the report's gate wording: fresh whole-candidate independent audit remains required before acceptance/commit even if no further ES source change occurs. The phrase "after later source change" must not make that obligation conditional. This audit is external-tooling review and cannot substitute for it. If the actual v2 remaining-gates text is inconsistent, report a documentation finding; do not edit it here.
Separate remaining items into:
- incomplete static implementation or unspecified interface;
- independently trusted entry/bootstrap design and installation;
- exact target/input/formatter identities still to acquire;
- runtime eligibility and behavioral checks;
- mounted proof execution;
- later deployment observation/supported-local proof and whole-candidate audit.
The categories must not be collapsed into "runtime-only." Enumerate the smallest next authorized task. Receipt/identity checks can later be internal stop gates of one bounded authorized phase; do not demand a user relay for each check. Do not combine gateway installation, import and mounted execution under this audit or fabricate standing permission for them.
5. Deliverables and dispositions
Write one consolidated report and compact self-contained audit ZIP under a new ES-mounted-helper-v2-independent-reaudit-<unique> directory. Include:
- exact opening/closing target/provenance and packet/binary/source-union bindings;
- F-1…F-16 closure table plus any new finding, with severity, type, source path/lines, concrete failure/limit, proposed correction and uncertainty;
- separate judgments for the v2 component, upstream privileged entry, normal proof, diagnostic inference, and whole-chain execution readiness;
- actual new specialist reports and parent resolution, including disagreements;
- raw-evidence re-adjudication results, safe command records and inspection boundaries;
- a bounded unresolved-prerequisite/placeholder register with owner, needed evidence and the first effect it gates;
- required source excerpts/diffs directly, without nested history archives; manifests and final identities with nonrecursive hashing.
Do not package secrets, arbitrary environment dumps, databases, private host data, caches, binaries, full source unions or entire historical roots. Classify these where present. Do not delete them. Supply separate binary identities rather than binary copies.
Use primary verdict ACCEPT, BLOCK, REJECT, or AUDIT_PROVENANCE_MISMATCH, explicitly scoped to this review. A suitable component with a fully specified but unestablished trusted-entry dependency may receive:
ES_MOUNTED_HELPER_V2_STATIC_REVIEW_SATISFIED_ENTRY_AND_RUNTIME_GATES_PENDING
This does not constitute root authorization or a complete executable envelope. If a prerequisite merely hides an unresolved custody/interface defect, use:
ES_MOUNTED_HELPER_V2_PREEXECUTION_REAUDIT_BLOCKED
An exact-target/provenance failure stops correctness acceptance. Missing critical review coverage is explicit, not inferred agreement. REJECT is reserved for a substantive incompatibility with the selected scope/model, not ordinary bounded defects or deliberately unexecuted future runtime checks.
Conclude with the concrete continuation point and separate provenance, validation, and implementation confidence. No repair, host contact, fixture run, execution authorization, staging or commit follows automatically. The next user return should include the existing v2 review ZIP alongside this new audit report; no rebuild of that input ZIP is required.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
