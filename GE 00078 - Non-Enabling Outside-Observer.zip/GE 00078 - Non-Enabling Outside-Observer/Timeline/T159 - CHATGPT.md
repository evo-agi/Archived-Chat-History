**Accept the scoped F-001/F-002 review and move to a representative-cohort expansion—not an eighteen-candidate clone.**

The next tranche adds exactly three lifetimes to the reviewed baseline:

1. `disjoint-sibling-binds-accept` — mounted-root normal acceptance.
2. `same-object-binds-reject` — normal expected-refusal path.
3. `same-object-binds-reject:diagnostic` — paired diagnostic path with separate effective-source obligations.

Together with the reviewed `ordinary-disjoint-roots-accept`, that forms a four-candidate cohort covering the material lifecycle classes: ordinary acceptance, mounted acceptance, normal refusal, and diagnostic refusal. The other fifteen lifetimes remain unchanged and uncredited.

### Owner handoff

ES_R6_REPRESENTATIVE_COHORT_OWNER_HANDOFF_20261015_01.zip[Download the representative-cohort owner handoff](sandbox:/mnt/data/ES_R6_REPRESENTATIVE_COHORT_OWNER_HANDOFF_20261015_01.zip)

:chatgpt-content-reference{index="1"}[Download its verification record](sandbox:/mnt/data/ES_R6_REPRESENTATIVE_COHORT_OWNER_HANDOFF_20261015_01_VERIFICATION.json)

```text
Bytes:             47,949,615
Members:           10
Manifest payloads: 9
SHA-256:           be8a597291254618aee7c0888a7848827f849fb3eb57b4a33d564c1c16622ff8
Verification:      PASS
```

The package is self-contained. It includes the corrected owner package, satisfied review, exact R05-repaired pilot with retained seed/source evidence, predecessor integrated delivery, candidate inventory, decision record, and complete authoring task.

## Message to send

Start a **new ChatGPT design-owner conversation** in this project—not Codex and not an independent-review conversation. Attach the single ZIP and send:

> Continue as the artifact-only design owner for the representative R6 candidate-flow cohort. Read `README_FIRST.md`, `instructions/EXPANSION_DECISION.md`, and `instructions/OWNER_TASK.md`, then authenticate every input ZIP before semantic authoring.
>
> First derive the exact nineteen-lifetime equivalence matrix required by the task. Proceed with normative integration only if the actual retained source, histories, ProcessRecords, source bindings, field types, and causal order support the existing closed 25-transition R01–R05 language for the three selected additions:
>
> - `disjoint-sibling-binds-accept`
> - `same-object-binds-reject`
> - `same-object-binds-reject:diagnostic`
>
> Extend R9.19 only to the exact explicit four-candidate cohort, including the already reviewed `ordinary-disjoint-roots-accept`. Preserve identity projection outside that cohort, the one-way `controller.receive → adapter.response-received` mapping, the reviewed field-local string exceptions, and all R01–R05 semantics.
>
> If any selected lifetime needs another transition, field type, causal order, authority rule, ownership rule, or string-limit exception, stop before normative authoring and return the evidence-grounded classification. Do not force it into the reviewed mapping.
>
> Produce the complete paired corpus/map, exact per-candidate specimens and results, meaningful rebound controls, preservation evidence for the other fifteen uncredited lifetimes, affected-consumer/scenario reconciliation, a substantive checkpoint, checked-before-image reconstruction, and completed package verification.
>
> Do not launch Codex, access repositories or hosts, execute uploaded programs, implement runtime code, expand beyond the exact cohort, or claim independent acceptance.
>
> The permitted owner endpoint is:
>
> `OWNER_R6_REPRESENTATIVE_COHORT_R01_R05_INTEGRATED_READY_FOR_FRESH_REVIEW`

## Why this is the right expansion unit

The fresh review closes only the exact one-candidate artifact/design integration. It does not show that every other case shares the same native lifecycle or candidate-flow schema.

This tranche avoids both failure modes:

- **Too narrow:** integrating eighteen candidates one at a time.
- **Too broad:** generalizing from one successful candidate without checking normal-refusal and diagnostic paths.

The required equivalence matrix also forces the owner to inspect all nineteen lifetimes without granting credit to the fifteen outside the cohort. If the cohort succeeds and passes a fresh review, the remaining candidates can then be expanded by evidence-backed equivalence class rather than repeated bespoke modeling.

**Sources:** the satisfied F-001/F-002 review, corrected owner package, exact R05-repaired pilot, and predecessor integrated delivery, all included unchanged in the handoff.

**Confidence:** **0.99** in the package integrity and scoped review closure; **0.95** in the four-candidate representative expansion strategy. Cohort compatibility and broader R6 correctness remain unestablished.
