**Retain the block. The next task is one bounded FRESH-01/FRESH-02 owner repair; general-join authoring stays paused.** The review supports the earlier repairs within their stated scope, but the current reader still lacks two necessary validation gates: exact context membership and safe request-stage construction.

### ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01.zip[Download the self-contained FRESH-01/FRESH-02 repair handoff](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01.zip)

:chatgpt-content-reference{index="1"}[Completed handoff verification](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01_VERIFICATION.json)

Send this **single ZIP to the existing ChatGPT joint-composition repair-owner conversation**, not Codex or the reviewer. It contains the original owner and fresh review unchanged, both counterexamples, the required nested source/evidence ancestry, and the complete repair task.

## What I corroborated

The delivered review and owner package match their stated identities and pass complete member-byte, manifest, hash, mode, path, and CRC checks:

| Artifact | Bytes | Members |
|---|---:|---:|
| Fresh blocked review | 1,546,477 | 30 |
| Repaired owner under review | 135,744,784 | 1,566 |

I also authenticated both new counterexamples and checked their differences from the immutable F00-positive model:

**FRESH-01:** The specimen retains the original nineteen accounts, 950 native events, 157 RPCs, and candidate projections. It has **twenty context creates but nineteen cancels**. The added `unlisted-context` has a valid creation-relative deadline. Only the resource-event file and manifest change; the other resource records differ only in their ordering index.

**FRESH-02:** The specimen removes the first account’s Start admission while retaining its submission and return. It has **949 native/projected events**, with the corresponding sequence and seal-bound updates. All RPC and resource bytes remain unchanged.

The selected account/native/body and RPC hashes reproduce for both. I read the cited reader paths and reproduced all twenty current fixed source-range identities. **I did not execute the uploaded reader:** the false acceptance and exception remain static predictions, not new observed runs. RECEIVING_INSPECTION.md[Receiving inspection](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01/receiving/RECEIVING_INSPECTION.md)

## 1. Close the context cohort without breaking diagnostics or prefixes

The correction must establish **both vocabulary and exact membership**. Accepting any valid `id256` is too broad; checking only that every account has a context leaves extra contexts invisible.

For the complete branch, require exactly one create and one cancellation for every independently fixed lifetime reference, with no extra, missing, duplicated, or mismatched context. Check creation, use, cancellation, and next-candidate order separately. Neither equal counts nor set equality alone proves all those relationships.

### One implementation trap needs explicit treatment

The resource-event `candidate` field contains **nineteen lifetime references**, including eight `:diagnostic` values. The current `typed(candidate-id)` helper instead checks the **eleven base-case IDs**.

**Blindly replacing `id256` with that helper would reject valid diagnostics.** The handoff requires exact membership in the existing nineteen-reference relation, while preserving the distinct base-case type where that type actually applies. This is not a new public schema or a general ID alias. SELECTED_SOURCE_AND_READER_EXCERPTS.md[Exact source and reader excerpts](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01/receiving/SELECTED_SOURCE_AND_READER_EXCERPTS.md)

The rule must also respect the saved prefix boundaries:

| Account | Context treatment to preserve |
|---|---|
| Full composition | Nineteen exact creates and cancellations, with complete source-order closure |
| P01 lost acknowledgement | One created context; **no observed cancellation at this cut** |
| Consuming-Close-error prefix | One created and cancelled context; still nonpassing |
| P02 incomplete poll | **No native context or account**; its external F00 calculation premise remains only a premise |

Requiring nineteen cancellations in P01 would fabricate future evidence. Treating P02’s calculation premise as a native context would fabricate an observation. Conversely, those prefix exceptions must not become input-selected waivers that allow additional contexts. PREFIX_SCOPE.json[Direct prefix inventory](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01/receiving/PREFIX_SCOPE.json)

## 2. Establish request stages before any consumer indexes them

The current `check()` records an error but continues. That is insufficient when later code assumes the failed premise:

```text
record UNADMITTED_REQUEST
→ build the operation map
→ index q["request.admit"]
→ unexpected exception
```

The repair must validate stage types, cardinality, and identities **before constructing or consuming the request index**. It must also fix the later RPC and resource consumers, not merely prevent the first demonstrated `KeyError`.

Duplicate detection needs the same discipline: recording a duplicate and then overwriting the earlier stage cannot produce a trustworthy index.

**Do not substitute empty dictionaries, zero values, inferred admissions, or broad exception-catching.** Missing evidence must receive a deliberate contradiction/refusal; an unexpected implementation error must remain `READER_ERROR`, without negative-test credit.

A genuinely pending return remains different from a missing admission. P01’s wait has admission and submission but no return. That is the supported outstanding-request shape and must remain nonpassing without becoming malformed.

Likewise, requiring an admission record for the modeled Close must **not** reintroduce fresh ordinary-A validity, a clock observation, or Q status as prerequisites for the inherited C release duty.

## Preserve the repaired inputs and make the new controls discriminate

The five F00 bases and both fresh counterexample archives remain immutable. **No further deadline rebasing is needed for these new specimens.** Their bindings and context-cap arithmetic already pass.

The new task requires controls for unlisted contexts with and without cancellation, legal-but-out-of-prefix references, missing/duplicate/wrong cancellations, diagnostic-reference confusion, and matched counts with wrong membership.

For request stages, it requires missing admission and missing submission across the eight selected operations, duplicate stages, wrong-request joins, and the valid outstanding-wait distinction. The full 105 prior model inputs and 21 rules-only fixtures must retain their appropriate evidence scope under the repaired interpretation.

The objective is not a larger check count. It is to establish that **the two complete validation gates and all their dependent callers agree**, while preserving F00–F04, R01–R05, the conditional 157-RPC branch, and truthful nonpassing custody.

## Message to send

Attach the handoff ZIP to the existing ChatGPT owner conversation and send:

> Repair FRESH-01 and FRESH-02 under `NEXT_OWNER_TASK.md`. Read the decision, receiving inspection, full review, actual counterexamples, fixed rules, complete reader/support, and accepted-source excerpts before authoring.
>
> Keep the five F00 bases and both new review specimens unchanged. Enforce exact lifetime-context membership and profile-specific create/cancel closure, preserving diagnostic references and the actual P01/P02/CLOSE boundaries. Establish typed request-stage cardinality and identity before every dependent lookup, while preserving legitimately outstanding returns and inherited-C duties.
>
> Save and reopen the first substantive repaired reader/results checkpoint before expanding controls. Complete the finite regression set, repeated results, scoped reconstruction, and preservation evidence. Return one actual downloadable repaired package.
>
> Do not launch Codex, access repositories or hosts, execute uploaded predecessor/reviewer programs, change the normative corpus/map, expand model scope, author general joins, or claim independent acceptance.

The intended owner endpoint is:

```text
OWNER_R6_JOINT_COMPOSITION_FRESH01_FRESH02_REPAIRED_REVIEW_REQUIRED
```

A **genuinely different ChatGPT reviewer** then examines the exact successor before general-join authoring resumes.

## Delivery and limits

The new handoff was closed and reopened successfully:

```text
Bytes:   130,768,260
Members: 16
SHA-256: 98001817526957e3bce1a88104441c1ceb80274729136f975a64e414ff6a229d
```

Some older indexed attachment links have expired, but all required owner, review, counterexample, and source bytes are readable and included. **No additional upload or recovery pass is needed.**

**Sources:** the REVIEW_REPORT.md[fresh review report](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01/review_context/REVIEW_REPORT.md), actual reader/source excerpts, and COUNTEREXAMPLE_CHECKS.json[receiving-side counterexample checks](sandbox:/mnt/data/ES_R6_FRESH01_FRESH02_REPAIR_HANDOFF_20261017_01/receiving/COUNTEREXAMPLE_CHECKS.json). I performed byte, source-text, and selected relationship checks—not a complete semantic audit or reader repair.

**Confidence:** **0.99** in measured identities and direct specimen relationships; **0.97** in the bounded repair direction. Successor correctness and independent acceptance remain unestablished.
