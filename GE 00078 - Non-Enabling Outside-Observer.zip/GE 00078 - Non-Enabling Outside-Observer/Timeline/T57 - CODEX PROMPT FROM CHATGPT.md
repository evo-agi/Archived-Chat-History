ES mounted-helper — per-effect authority, channel custody, and complete receiver repair
Objective and authorized effect boundary
Use the existing implementation/preparation Codex conversation, not the independent audit conversation. Be the sole writer of a fresh external successor. Repair the eight current findings together: LNX-LIFE-01, LNX-LIFE-03, LNX-LIFE-04, DRA-01, DRA-02, DRA-03, DRA-04, DRA-05. Preserve the narrower independent closures and the complete historical finding lineage. Produce exact-source ordinary-user engineering validation for a later fresh independent review.
The latest endpoint is ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REAUDIT_BLOCKED. Current evidence completeness is independently satisfied; this is NOT a new INCOMPLETE or provenance-mismatch episode. The historical endpoint ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REAUDIT_INCOMPLETE remains unchanged, and its missing historical records remain missing. Do not reopen the completed missing-record search or run an unchanged broad suite to address source defects.
Authorized here: local, ordinary-user external source/document/test repair; offline tests of the external tooling; actual task-owned ordinary-file controls; existing isolated telemetry configuration; compilation/vet; inspection and read-only provenance capture. All writes belong to a fresh private task root under /Users/ds/Downloads.
NOT authorized: any ES or other repository edit, test, script/help invocation, hook, stage, commit, fetch, push, branch/worktree mutation; network/SSH/host discovery; sudo/root probe; device/loop ioctl; namespace creation/entry; mount/unmount; formatter or production supervisor/worker/candidate execution; process-wide privileged configuration; live signals to unrelated processes; credential/capability transition; service, Docker, Lima or VM operations; administrative approval, key creation, signer/gateway/watchdog/allocator implementation or installation; real residual acceptance; mounted proof. The ordinary tooling test processes necessarily execute, but separately compiled Linux supervisor, safe-control and normal/diagnostic proof artifacts remain data only.
Retain the finite supervisor / namespace worker / candidate / adjudicator structure, exact eleven normal and eight supplementary diagnostic cases, fixed topology, existing resource ceilings, and no-foreign-cleanup rules. Do not add another receipt hierarchy, generic policy service, shared orchestration kernel, dependency or product feature. No independent audit or audit subagents in this implementation task.
Success endpoint:
ES_MOUNTED_HELPER_ACTION_CUSTODY_AND_RECEIVER_REPAIRED_LOCAL_VALIDATION_COMPLETE_REAUDIT_REQUIRED
Use it only after all eight findings have source-level responses and the actual-path, semantic-adversarial and final validation gates below pass. Otherwise return ES_MOUNTED_HELPER_ACTION_CUSTODY_OR_RECEIVER_REPAIR_BLOCKED with exact partial progress and unresolved findings. Neither endpoint authorizes privileged or mounted progression.
1. Authenticate the concrete input, then inspect the actual source
Latest independent audit
Root:
/Users/ds/Downloads/ES-mounted-helper-episode-delivery-receiver-independent-reaudit-Zqp7ny
Artifact	Expected bytes / SHA-256
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_INDEPENDENT_REAUDIT_REPORT.md	17,579 / b38b427d66d9b7d29940c4f56092e5b7a9ab5e44e42df605adc48a6b1de31cb5
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_INDEPENDENT_REAUDIT_PACKET.zip	319,273 / d1dd7cab919519e65826e4d496a6433d205affb80a9959d4a94eb9b82a7439b0
AUDIT_PACKET_MANIFEST.tsv	5,531 / 4ee7df55b29fe5f655eddc3699fd0ec50b2a18416d9766b4e9424289c72d6fd7
AUDIT_PACKET_COMPLETED_VERIFICATION.json	992 / b1103be7b077eead0fa7e304dcd47c8e28741c08df8314adda2de66450de4357
FINAL_AUDIT_ARTIFACT_IDENTITIES.json	2,225 / 9e033e04fe1eea92de3433ebd40a6442bd6c4951be90d5d3dee0d0d75fbf05c7


Expected audit membership: 49 members, 48 self-excluding payload rows. Read the actual three specialist bodies, material source excerpts, PREREQUISITE_REGISTER.md, and FINDINGS_CLOSURE_MATRIX_59.md at their authenticated packet paths. Discover those paths from the manifest; do not guess directory prefixes or replace their contents with the parent summary.
Current rejected engineering target
Root:
/Users/ds/Downloads/ES-mounted-helper-episode-delivery-receiver-repair-QR0TNsfd
Artifact / representation	Expected identity
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIR_REPORT.md	20,553 bytes / 588c8622bde95564d95869c26d012bcde89a2e75b8f2be550e599a5fdc14457e
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIR_PACKET.zip	1,774,859 bytes / 8f18466af1d457685798f6102987175b78353a40e1c3adc7eb20da06b57b4cda
FINAL_ARTIFACT_IDENTITIES.json	4,068 bytes / a10e1dd1ef0b6def63dc8c08d503fa8de9c53dbe448b1d26e442c3868e6c281e (independently measured in the latest audit)
external / embedded manifest	89,931 bytes / 56558dc38949fe65f87449e5733aca1c65b3184bd6b9da7f42ca8ab6e8a5c190
source manifest	111 regular members; 17,190 bytes / 8d0002488bc99fa8cf9cffd2a880e1855f4f92c673ca501409ff92fa89f2b3e8
selected-input record	17,424 bytes / 5817b1b135aeb3a5bf7aa543987078c14812b8356e370e547ecdbac75907c6cc
selected-input canonical rows / recipe	85 rows / c386c730b3d68878a79bbe6a93b130dcd58a2ed8ffa24c221ead8ab18813d660; recipe 0d23627443cfa42ae28d74d2caa9cbb13db4149924c3965e3d51fd6e5891e69b
current validation decision	11,529 bytes / 15e64576ab586ea814fb76cd63d080f5a64bd320d9836fb0a35ef1d804b25477
completed evaluator invocation	8,058 bytes / e3dbf4df3de23a261c6021cd15e038fe62e0dcdc7be77f0beb21a4cd9679ba60


Expected engineering ZIP: 650 regular members, 649 self-excluding payload rows. Check safe unique normalized relative paths, physical regular types, CRC, complete membership, sizes, digests and the appropriate recorded modes before extraction. Keep authoring modes, ZIP modes and private extraction modes distinct. Authenticate input bodies and build bindings; an identity record is evidence, not administrative authority. Preserve all old roots and artifacts unchanged; do not chmod them or overwrite their reports. Derive the successor from the authenticated 111-member source into the new task root.
ChatGPT inspected and fingerprinted the latest attached audit report, not the ZIP or source bodies. The engineering decisions below are a bounded handoff, not a substitute for your source inspection. A material contradiction with the actual authenticated source must be reported before implementing a workaround.
Preserve the ES repository
Root: /Users/ds/Repositories/Execution Substrate
- Branch/upstream: trunk_dev / origin/trunk_dev.
- HEAD: b92bd9884106154d25342e1573dcc4c312311436; tree: cdd4e44bac15c1952d70997143040644361f0bb1; parent: 4f797fb63d3c5b95275b1455af36ebc9b695f773.
- Source: 358 rows / e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e.
- Candidate: 83 rows / 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2.
- Status: 83 rows / a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c.
- Tracked diff: 2,407,274 bytes / 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1.
- Index: 39,949 bytes / 9ca13234f248fccb29e8136168bb577c49c3fcf3c23b3f0d23b2bc1bd3aac569.
- No staged/conflicted paths or active operation; six worktrees; cached diff empty.
Read current AGENTS.md, relevant latest PLANS.md, owning capability/configuration and execution-lifecycle guidance, then affected source/tests. Repository contracts own ES facts. External documents describe only this proof component. No CP/Temporal revival, product reclamation rule, milestone resequencing or governance change is selected here.
Use the inspected retained read-only provenance recipe before and after work. Disable optional Git locks, fsmonitor, external diff/textconv and filter execution; inspect config/attributes rather than running hooks. Capture source/candidate/status/diffs/index/refs/worktrees/branch/HEAD/tree/operation state. Disclose exact same-object app-owned ref-name churn between historical capture and opening; it is not a blanket exemption. Any current target-bearing drift blocks successor claims. No ES script or test runs.
2. Fix the implementation-to-control mapping before coding
Amend the existing external specification and owner/effect table before code changes. Record the exact touched set, actual source caller and primitive boundary, independent expected input, partial-state owner, and decisive regression for each current finding. Proceed to implementation within this task when consistent; do not return another general design-only proposal.
The chosen model remains:
independently validated finite entry intent and deadline -> per-effect authorization -> exact partial resource custody -> fixed normal/diagnostic processes -> bounded cleanup -> frozen operational outcome and raw case evidence -> sealed bundle and exact persisted receipt -> independently expected receiver context -> bounded reconstruction and semantic adjudication.
Two authoritative decisions must be explicit rather than chosen independently by producer and receiver:
1. The supported profile fixes subjects, roles, paths, modes and budgets. Caller input can select only a supported enumerated profile; it cannot redefine that profile.
2. A single authenticated pre-effect deadline is bound to the episode. It is not proposed independently by the producer, recomputed by the receiver, or replaced by whichever context happens to expire earlier.
Do not add a new service or recursive confirmation protocol. Repair existing types, finite tables, validators and direct callers. The external establishment of real approvals, confirmation trust and containment remains absent and fail-closed.
3. LNX-LIFE-01 — authorization at every deliberate entry effect
Inspect tooling/internal/proof/live_linux.go:94-144, the actual entry chain, episode_owner.go, and the controller. One owner check followed by several deliberate effects is insufficient.
Route the pre-controller sequence through owner-aware individual effect boundaries. Enumerate the actual thread lock/unlock custody, process-setting changes, descriptor acquisition, exclusive ledger creation, attachment, append and sync operations; identify which are active-work effects and which are separately authorized releases/evidence-reserve actions. Check episode, sticky cancellation/revocation and the original deadline immediately before each named active effect. Preserve partial custody before any later fallible operation or ledger write.
Do not claim ordinary runtime startup, every allocation or the final instruction-to-syscall scheduling interval is atomic or effect-free. The selected guarantee is one final check per actual deliberate effect, not a proof against external scheduling or uninterruptible kernel activity. Cleanup may use only the already defined original-bounded reserve for its own release actions; it cannot renew active-work or signal authority.
Required controls inject cancellation/revocation/expiry AFTER each live-sequence boundary, including after an earlier check succeeds and before the next primitive. Drive the actual sequence function with narrowly substituted primitive operations; do not replace the whole preamble with an already-correct fake. Assert no subsequent unauthorized effect, accurate partial state and correct release responsibility. Retain a positive in-budget sequence. An AST assertion that the constructor precedes the controller is supplemental only.
4. LNX-LIFE-03 — channel custody starts with socketpair and survives duplication
Inspect the real worker startup path at worker_linux.go:90-133, spawnWorker, ProcessCustody, the selected pinned implementations of os.NewFile, net.FileConn and the actual close paths. Do not assume the pointer/fd ownership semantics from names.
Prepare a returnable custody object before the first acquisition and populate BOTH socket endpoints immediately after successful acquisition, before wrapping, /dev/null acquisition, Start, observation or bookkeeping can fail. Track exclusive ownership and transfers between raw descriptors, file wrappers, child inheritance and the retained connection. Preserve acquisition and close outcomes even when the worker object is nil.
The retained net.FileConn channel is not the original endpoint number. Bind the actual retained duplicate and its owner using the existing/pinned safe mechanism; do not manufacture another duplicate merely to obtain an identity. Original endpoint release and retained connection custody are separate facets. Invalidate numeric ownership before each one-time release attempt; error means release uncertainty, not permission to close a reused number. Ensure the release policy matches the actual owning abstraction, rather than separately closing a wrapper's underlying number twice.
Controls must exercise the same producer sequence the Linux adapter calls, with failure between every relevant substep: either wrapper, null input, process start, child-end close, original-parent close, duplication/connection construction, retained-fd observation, handshake, identity observation and later ledger failure. Verify both endpoints, retained duplicate and child/process facets at each failure, exact-once close behavior, continued ownership after a second failure, and truthful serialized residual state. A fake that starts by returning a fully populated observation does not meet this requirement.
No real worker/namespace/privileged child or signal operation may be invoked in these controls. Ordinary file/connection control primitives may execute locally only where inspected as task-owned and already within the tooling's ordinary-user test boundary; otherwise substitute them narrowly and label the limit.
5. LNX-LIFE-04 — one authorized dispatch per actual signal syscall
Inspect the formatter closure at live_linux.go:680-697, candidate fallback at worker_linux.go:1115-1124, and all related signal sites. A dispatch callback must not contain a pidfd signal, intervening observation, and a second group signal under one check.
Each actual signal syscall, including fallback after ESRCH, is a distinct dispatch through the original per-subject sticky authority. Recheck immediately after any intervening observation or error and before the next syscall. Do not replace the subject/context with a later cleanup reserve or clear a revoked/expired decision. Observation is not new signal authority. Preserve the explicit last-check-to-one-syscall scheduling qualification.
Controls: cancellation, expiry and revocation between first attempt and group observation; between observation and second attempt; after ESRCH before fallback; and on cleanup reentry. Assert first/second syscall counts and exact target relationships. Include valid in-budget fallback and error preservation so an always-deny implementation cannot pass. Inventory the actual syscall sites and show which tested dispatch owns each. Do not run real privileged signals or add a new containment mechanism.
6. DRA-04 and DRA-03 — freeze valid profiles and one pre-effect deadline
Finite profile, not caller-defined grammar
Inspect spec.go, the fixture tables, producer selection, receiver expectations and all synthetic-profile branches. Enumerate the existing supported live profile and derive its exact UNIQUE subjects and roles: eleven normal cases plus eight supplementary diagnostic cases. Repeated, missing, extra, role-swapped, unknown or subset profiles fail even when actual evidence and caller expectations match one another. Successful negative-topology cases mean correct refusal, not ES accepting all eleven topologies.
Validate clean absolute fixed base/export/bundle/receipt relationships and the selected LIVE base mode 0711; derive other exact modes/ownership from the governing current contract, not a blanket chmod or a new guessed convention. Retain original saved-object custody, root-owned control separation and refusal of adoption. The already closed scratch and receipt-path predicates must stay closed.
Local tests may use an explicitly separate synthetic ordinary-user trust/custody profile. Its only necessary physical/trust substitutions must be enumerated; it must retain the SAME case, tuple, deadline and budget semantics. Test data, a receipt or arbitrary caller string must not enable that profile in a production acceptance path. Check matching-invalid actual-plus-expectation cases, not only mismatching claims. Do not add a general registry or arbitrary custom profile facility.
Exact deadline input
Fix live_linux.go:88-90, episode_owner.go:82-89, PublicationReceipt, independent run/receiver expectations and confirmation together. One exact authenticated deadline value is selected before the first deliberate task effect and bound to the approved episode/target/source/profile. Real trust establishment remains a prerequisite; synthetic fixtures must supply this value independently BEFORE running the producer.
Bind that value once to the in-process deadline representation before effects; carry the original typed/monotonic-bearing owner internally throughout execution and finalization. Serialize the canonical approved deadline and binding in the receipt/required records so the receiver and confirmation can check equality. Do not serialize and reparse control state between local phases or claim that a serialized timestamp contains Go's monotonic reading. Inspect the pinned source for the one-time binding and retain its uncertainty/clock/containment qualification.
Do not silently use min(parent deadline, proposed deadline) and then label a different externally supplied timestamp as the original. Selected treatment: a parent context already imposing an earlier limit is ineligible for this episode before effects, unless the separately authenticated input was already set to that exact earlier deadline. Later parent cancellation still stops work; it neither changes the approved deadline nor grants an extension. Phase and cleanup budgets may be shorter but never replace or exceed the original episode deadline. Check already-expired, missing or mismatched inputs before deliberate effects.
Controls must carry a single independently prepared deadline through actual construction, controller, publication, persisted receipt, receiver expectations and confirmation. Reject a different post-produced deadline even with matching synthetic authentication; earlier-parent silent narrowing; later/equal-shape substitutions; wrong epoch/episode bindings; late completion; and cancellation without timestamp change. Preserve the earlier typed-deadline/display-time-discontinuity controls. No system-clock change or runtime containment implementation is authorized.
7. DRA-01 — the receiver replays real case semantics
Selected repair: reuse the existing pure case adjudicator on the complete canonical ProcessRecord evidence already exported. Do NOT accept the producer's prior in-memory verdict or committed wait labels as the proof of case success. Do not introduce a parallel success-label validator or a new attestation layer merely to avoid replay.
Inspect live_linux.go:1218-1243,1314-1340, terminal_receiver.go:485-506, adjudicator.go, the actual process-record schema and normal/diagnostic driver output. Define a finite mapping from each expected subject/role to the exact payload, process/test terminals, binary/source binding and case-specific evidence. Parse under section 9's shared receiver budget and run actual semantic adjudication with independently fixed profile/fixture expectations.
Normal expected accepts/refusals, protected-state facts, provider counts, sentinels, root coordinates and process/test outcomes must satisfy the current normal-case contract. The eight diagnostic records remain required at their selected scope and supplementary: they must never rescue a failed normal result or be merged with the normal effective source. Missing/malformed/duplicate/wrong-role/wrong-case payloads, failed tests or expected-refusal predicates, and absent required child evidence block acceptance. Wait completion alone is not sufficient.
Replace the positive composition fixture's sample-only payload and unconditional successful Review with a complete schema-faithful set of all nineteen synthetic records and the actual case adjudicator. Synthetic raw observations are legitimate test input, but must be labeled as constructed data, not mounted execution. Choose independent fixed expected values, not values generated by asking the implementation what it accepts. Authentication/trust may be a separately configured test double; case semantics may not.
Negative controls change only one semantic facet, then rehash all affected graph members and generate matching test authentication. Require rejection at the semantic gate, not accidentally because a checksum or unrelated field is stale. Include absent/failed/malformed raw payload, normal failure plus diagnostic success, other-case payload, role swap, duplicate completion, zero-exit plus test skip, altered provider/sentinel/root facts, and all nineteen declared wait subjects with the actual evidence missing.
If the existing raw schema truly cannot supply a required fact, document that exact incompatibility. Do not silently fabricate data or broaden into an ES/driver rewrite. A source-level stop with the minimal required dependency change is preferable to another nominally successful composition that bypasses the real predicate.
8. DRA-02 — complete terminal-state consistency, not status labels
Derive the legal state/disposition table from ALL existing operational-result, ledger, process, descriptor, scratch, image and loop fields. Use one complete pure terminal validator in receiver acceptance; producer checks may reuse it, but the receiver must reconstruct its inputs from held persisted bytes rather than trust a producer valid=true bit.
The table must address expected/acquired/observed scratch identities and actual removal observations; positive process/group/start identities when the stage requires them; worker/candidate/formatter relationships; every descriptor's never-acquired/held/transferred/released/release-uncertain state; request/selection/candidate/configured/held/absent/uncertain loop facets; backing/image identity, held-descriptor and retained/removed pathname consistency; operational and cleanup completion; cancellation/revocation and deadline binding; evidence/resource status; and committed ledger rows versus failed, attempted or uncertain tails. Trace the existing field names and call sites rather than inventing unconnected checks.
Separate structural validity of a failure record from eligibility for successful proof acceptance. A truthful failed/uncertain record may be retained as evidence but is not an accepted proof. Likewise do not automatically reject every historical recovered error if the existing finite contract expressly permits a recovered state with fresh exact evidence. Specify which histories are recoverable, which status they must retain, and which contradictory or unresolved tuples can never pass. Do not erase a primary failure or fabricate positive inventory.
The only possible-unbound policy remains the existing exact unapproved disposition accept-single-get-free-possible-unbound-without-removal; synthetically exercising it does not approve it. Local clean status must never imply host-global absence. No lease/provisioner, retry, scan, detach/reset or removal authority is selected here.
Test each row with independently authored legal witnesses and rehashed contradictory witnesses: zero/negative process facts where presence is claimed; wrong scratch binding plus ScratchRemoved=true; held or uncertain descriptor plus released status; association absent while held/acquired is asserted; retained image inconsistencies; missing cleanup after acquisition; poisoned ledger plus success labels; failed case plus all waits committed; valid authentication of failure; and recovered-error claims lacking their required fresh observations. Preserve cause-specific rejection and reachable valid acceptance.
9. DRA-05 — one bounded receiver acquisition and reconstruction
Enforce the existing 16 MiB aggregate export contract in the receiver, not just independent 4 MiB per-file checks. Do not raise the budget to accommodate a fixture. Enumerate the exact aggregate domain (payloads and all applicable terminal/manifests/seal/carrier/failure records) from the governing producer contract. Any separately supplied approval/confirmation has an explicit existing or bounded input limit; it is not an unbounded side channel.
Before body allocation/read, validate a finite member-count bound derived from the fixed profile and permitted schemas, and perform overflow-safe declared-size accounting. Record the derived count and domains in the spec; do not invent an unexplained hard-coded limit. Unknown/duplicate/escaping members fail. Manifest declarations are not trusted actual lengths: check held regular objects and meter actual bytes while reading, including size disagreement/growth/truncation. Refuse oversized input using bounded reads, with any one-byte over-limit detection behavior explicitly accounted for.
Replace unbounded ReadDir(-1) with capped enumeration sufficient to detect one excess entry. Bound every retained legacy cross-check and nested parse by the same reconstruction discipline; a second verifier may not reopen an unmetered tree. Prefer acquiring each member once through held custody and reusing bounded immutable bytes for hash, decode and semantics. Distinguish stored-byte aggregate, cumulative read-work limit and bounded decoded structures; repeated passes must not silently reset limits or imply that a per-file bound is an aggregate bound.
Controls: valid complete profile; exact budget and +1 accounting where the schema permits the boundary; many individually valid near-limit members exceeding aggregate; count overflow; integer sum overflow; lying declared sizes; actual size change; over-limit directory entries; unknown members; truncated/malformed data; and legacy-path bypass attempts. Use deterministic counters/limited-reader fault points to assert early rejection before bulk allocation/read, not only a final error after consuming all oversized input. No benchmark or quota/cgroup subsystem is required. Retain the existing distinction between software work limits and unimplemented hard kernel containment.
10. Composition and anti-regression gates BEFORE broad final validation
The key acceptance test is not an injected already-successful result. Build one positive ordinary-user composed path using the real orchestrator and receiver functions with only explicit kernel/privileged primitives and independently established test trust substituted.
Start with only declared upstream base custody, profile and approved deadline. Let the actual producer create its children, retain exact partial observations, run synthetic canonical process evidence through the actual case review, clean task-owned ordinary files, freeze the outcome, publish the bundle and receipt, and let the receiver reacquire and verify everything. Use all eleven normal/eight diagnostic records and the same finite semantic rules as production. No sample-only graph, always-success Review, precreated hidden export parent, post-hoc expected deadline, custom subject subset, oversized bypass or synthetic profile leakage.
Cover at least these coupled paths:
- check passes -> cancellation before the next preamble effect;
- first signal attempt -> observation/ESRCH -> authority ends before fallback;
- socketpair/duplicate acquired -> identity/close/bookkeeping failure -> accurate final residual;
- all wait subjects committed but raw case evidence absent/failed and reauthenticated;
- clean status labels but contradictory custody/ledger/image facts and reauthenticated;
- matching invalid profile/path/mode in both actual evidence and expectations;
- valid independently approved deadline at entry but a differently confirmed/carried deadline at receipt;
- fully consistent hashes and per-file sizes but aggregate/member-limit breach.
Trace ordinary-file/runtime/shared-model/AST evidence separately. Where Linux-selected code cannot execute on Darwin, expose only the minimal shared sequence needed so real Linux callers use the tested routine, and retain a source-to-primitive map. Do not fake the whole producer or receiver decision. No new remote mechanics generation is authorized.
Require discriminating predecessor negatives for these eight actual predicates where the retained source is executable within this boundary. Preserve source and overlay identities; do not replace predecessor algorithms. Linux source assertions and fault models remain labeled as such. At minimum, demonstrate that the old successful composed receiver fixture is rejected by the new complete semantic/profile check, and that the new complete fixture passes. Record any old positive test intentionally corrected because it encoded the audited bug.
11. Touched surfaces and historical treatment
Likely primary surfaces, confirmed by inspection before editing: tooling/internal/proof/live_linux.go, worker_linux.go, episode_owner.go, process_custody.go, signal_authority.go, terminal_receiver.go, the receipt/terminal-protocol types and validators, spec.go/existing finite tables, existing adjudicator and direct tests. Small private shared sequence/validation helpers and matching ordinary-user stub changes are allowed when actually needed to connect the Linux caller to its tests. No broad unrelated refactor.
Amend the existing episode/delivery specification, owner/effect table, administrative interface/approval and receipt templates, finite case/resource tables, successor map, findings and remaining-gates text. Version a changed on-wire receipt/approval shape consistently across producer, receiver and test fixtures; stale or mixed generations must fail rather than silently fall back. Do not modify historical packets to make them match the new types.
Keep all 59 historical finding rows and their independent dispositions. LNX-LIFE-01/03/04 are existing IDs receiving new owner responses, not new rows. Add the five distinct DRA-01…05 rows and link their TPA parents: 64 unique lineage rows when combined. Preserve F-12 disagreement and the narrow closed-static results for LNX-LIFE-02, TPA-01 and TPA-03; verify interactions without relabeling their runtime remainder as completed.
The predecessor current evidence is independently complete. Its 628 terminal identities include every one of the 530 earlier terminals and all 269 earlier frozen requirements. Preserve the applicable requirements and crosswalk names/descendants, but do not retain a positive expectation that embodies a confirmed defect solely to keep a count unchanged. Any such expectation change must cite its finding, fail the bad case for the intended predicate, and add a legitimate full-profile positive. Counts are observations, never success targets.
Keep the older INCOMPLETE history exactly; do not search again for its unavailable invocation/fixture bodies. That gap does not invalidate the complete 111-member predecessor or require repetition of its tests.
No ES source, internal/safemech, safe-control entry, go.mod/go.sum, normal/diagnostic drivers, compiler overlay, product source-union body or historical artifact may change. A required change there is a scope conflict to report, not permission to broaden.
12. Exact ordinary-user validation and evidence recording
Use the existing pinned Go executable:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
SHA-256: 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Reuse the inspected task-owned HOME/config/cache/temp/GOPATH and telemetry isolation procedure before the first Go call. First call go telemetry off only inside that isolated configuration. Require effective telemetry off and the exact private telemetry directory, not merely a requested variable. Preserve GOTOOLCHAIN=local, GOENV=off (observed empty), GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, and the authenticated existing read-only module cache. No dependencies or tools are installed/downloaded; no user-global configuration or historical telemetry is inspected or cleaned.
After development/composition passes, freeze full source/delta, CURRENT selected build inputs and recipe, required-control inventory, plan, runner, evaluator and capture mechanism. Resolve every command to exact absolute argv/cwd/environment before execution. From the new external tooling directory, run sequentially:
"$GO" version
"$GO" env -json <frozen explicit allowlisted keys>
<pinned gofmt> -d <exact touched Go-file argv>
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" env -json <frozen keys>
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o <supervisor-A> ./cmd/es-mounted-proof-v2
<identical deterministic recipe to supervisor-B>
<exact retained safe build recipe to fresh safe-output>
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" list -deps -f '{{.ImportPath}}' ./cmd/es-mounted-proof-safe-controls
"$GO" version -m <each newly compiled artifact>
Preserve all applicable controls; append the new primitive-boundary/receiver/composed controls and their exact descendants. Derive complete run/terminal/package coverage from raw streams, reject failures/incomplete/unknown/required skips, and separate the known no-test command-package terminals. Do not substitute 628, 123, 530 or 269 for an inventory.
Record EVERY evaluator and packager/verifier invocation externally, including rejected argument/preflight calls. Capture script/executable identities, actual absolute argv/cwd/relevant environment, start/end, exit/timeout, raw stdout/stderr, input/output digests and whether a decision was produced. Plans or result bodies are not invocation records. Retain exact evaluator versions. Keep evaluation inputs distinct from future completed invocation/packaging records so nothing must authenticate its own future bytes. The proven current capture mechanism is to be reused, not rewritten gratuitously.
One initial and at most one causally corrected final-source generation are allowed. Stop dependent lanes on failure; preserve failed records and exact source delta. Changed source needs fresh affected execution and identities. Pure analysis defects may receive versioned replay of authentic unchanged records, without reinterpreting failed tests or rerunning successful suites merely to repair arguments. A second substantive final-generation failure returns blocked partial progress. Ordinary in-scope development before freeze is permitted; no indefinite trial loop or automatic subsequent audit.
13. Selective inheritance and closeout
Retained identities:
- Safe executable: 4,497,174 bytes / c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75.
- Safe import closure: 2,023 bytes / 739a10de46f4ccf3e2d341d764d651c80462c9cde53c1e6d4726c1c4c1adbbe3.
- Previous supervisor: 6,281,058 bytes / 0253168c3652a9a9b94bf9dbafb7adf2e0b1505e813fab68810ee392efdf4a86 (compile-only).
- Normal proof: 23,583,914 bytes / bc4ff667d9280ee8ec671fc60bc23ec4e32e256b5084436588bcfb78292f4d0d.
- Diagnostic proof: 23,605,547 bytes / e2fc7baf9a7a9286f97dc3dbb95b74bba44c0b1d14d75c544b1f466d3d81edfb.
The new supervisor has new identities and is never run here. Authenticate a byte-identical safe rebuild AND unchanged selected source/dependencies/import closure to inherit exactly the seven historical ordinary-user Linux observations. They do not validate changed internal/proof. Unexpected safe drift blocks inheritance; it does not authorize host contact.
Retain normal/diagnostic effective-source and artifact bindings without rebuilding when unchanged. Tightened receiver evaluation of their future output is not execution of either binary. Preserve the separately instrumented diagnostic's different effective source; no normal/diagnostic substitution.
Clean only exact new task-owned temporary objects where identity and absence of active use are established. Retain the required evidence and separately classified binaries/config/cache state. No historical root, user cache, foreign process/device, ES tree or deployment cleanup.
14. Deliverables and endpoint
Return the exact engineering report, complete directly inspectable source/evidence ZIP and external acyclic final-identity record. Include:
- complete successor source, exact incremental/cumulative deltas and authoring-mode-aware manifests; current full/selected build inputs and recipe;
- eight-row current repair matrix plus 64-row historical lineage; original three specialist reports/excerpts/registers unchanged;
- source-to-primitive and effect-to-control map, finite profile/acceptance tuple/deadline/budget tables; explicit assumptions and source/interface changes;
- real composed positive and intended-cause negative fixtures, synthetic/trust/kernel substitutions distinguished; raw predecessor discrimination where used;
- all actual command/stream/environment/evaluator/packager records, including rejected generations, fresh decision, control-retention crosswalk;
- deterministic compile identities, inherited evidence binding, ES opening/closing provenance and residual-state classification;
- exact not-executed list, unclosed defects, skipped validation and authority/security widening (expected none outside the defined external interface repair).
Independently reopen the final ZIP and verify CRC, safe unique normalized paths, types/modes/sizes/digests and exact self-excluding membership. Put final verification and identities outside the ZIP where necessary to avoid recursive hashes. No binaries, caches, full ES source unions, images, device content, credentials or nested historical ZIP chains inside. Do not multiply already-authenticated historical material beyond what the fresh reviewer needs; preserve referenced inputs for direct access.
The final report must distinguish owner-engineered closure from independent judgment and observed local behavior from Linux source checks, inherited safe mechanics and unexecuted privileged behavior. Include source paths/lines, exact commands/results and separate provenance, validation and implementation confidence. Attach the new report AND the existing-source-containing repair ZIP in the next handoff.
Still pending regardless of local success: fresh independent successor audit; actual administrative/trust/storage establishment; exact approval or rejection of the residual disposition; target/formatter/capability qualification; external hard-deadline containment and confirmation; all eleven normal and eight diagnostic mounted cases with cleanup; running-deployment and supported-local consumer/operator evidence; unconditional whole-candidate ES audit; and separate exact-byte staging/commit/deployment authority. No such effect follows from this task.
The goal is to close eight concrete defects in the existing finite implementation with tests of the actual boundaries and a receiver that decides from complete evidence. Do not answer an acceptance bug with more authenticated success labels, or a missed effect with another coarse wrapper.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
