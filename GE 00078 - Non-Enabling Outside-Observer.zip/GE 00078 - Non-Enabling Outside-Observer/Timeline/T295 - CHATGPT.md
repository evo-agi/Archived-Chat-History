## Accept the verdict

This closes the **artifact-design, reconstruction, preservation, and package-contract gates** for the whole R6J general native-source join design.

The supported boundary is now:

```text
Accepted design target:
R6_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_SATISFIED_IMPLEMENTATION_DECISION_PENDING

Implementation status:
Not started

Runtime/native qualification:
Not established

Repository adoption:
Not established
```

The implementation decision is **proceed**, but only as a fresh, conditional **Execution Substrate–only** tranche. The earlier implementation handoffs and blocked implementation packages are stale and must not be reused.

Attach these two artifacts to Codex:

1. ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip[Accepted delivery envelope](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip)  
   67,230,247 bytes · SHA-256 `18c3410b531b95fd93fb15995168fe49740074b7ccdd38efba5efd0456d75402`

2. ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip[Satisfied fresh review](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip)  
   30,948 bytes · SHA-256 `af2ef4f1c2f7bf177ac0165d81fe84c0b8f6e7ce5f0490fd70a9925536e51e7f`

The delivery contains the accepted successor owner:

```text
61,660,562 bytes
ce1cd7a5b73e2af8ad6acbaa414e5b9645abe1ad193de220c4b63e07ff111b27
```

## Codex prompt

```text
Implement the independently accepted whole-R6J general native-source join
design in the Execution Substrate repository.

Repository:
  /Users/ds/Repositories/Execution Substrate/

This task explicitly authorizes source edits, contract/test changes, commands,
builds and validation in that repository only. It does not authorize commits,
pushes, deployment, publication, changes to another repository, or claims of
operational acceptance.

ATTACHED AUTHORITATIVE ARTIFACTS

A. Accepted delivery envelope:
   ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip
   67,230,247 bytes
   SHA-256:
   18c3410b531b95fd93fb15995168fe49740074b7ccdd38efba5efd0456d75402

   It contains the accepted successor owner:
   ES_R6J_FRESH01_RECONSTRUCTION_REPAIRED_OWNER_20261025_10.zip
   61,660,562 bytes
   SHA-256:
   ce1cd7a5b73e2af8ad6acbaa414e5b9645abe1ad193de220c4b63e07ff111b27

B. Independent accepted review:
   ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip
   30,948 bytes
   SHA-256:
   af2ef4f1c2f7bf177ac0165d81fe84c0b8f6e7ce5f0490fd70a9925536e51e7f

   Accepted endpoint:
   R6_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_SATISFIED_IMPLEMENTATION_DECISION_PENDING

The independent review closes the artifact-design, reconstruction,
preservation and package-contract gates. It does not establish repository
implementation, native/runtime qualification, real authority issuance,
deployment or product acceptance.

ROLE AND AUTHORITY

- The accepted successor owner is the authoritative implementation target.
- The owning Execution Substrate repository remains authoritative for its
  current source, repository policy, build system and existing compatibility
  contracts.
- Treat any discrepancy between current repository source and the accepted
  artifact target explicitly. Do not silently rewrite either one.
- Do not use any earlier whole-R6J owner, blocked proposal, old implementation
  handoff, historical pair identity, or prior generated summary as current
  authority.
- Treat .pyc and __pycache__ entries in the accepted artifact as packaging
  residue only. Do not install or rely on them.

PRE-EDIT AUTHENTICATION AND REPOSITORY GROUNDING

Before source edits:

1. Read the repository’s current AGENTS.md or equivalent guidance, PLANS.md,
   architecture and contract documentation, relevant source, tests, schemas,
   scripts, examples and validation tooling.

2. Capture the repository’s guarded opening state under its own repository
   rules. Report:
   - current branch;
   - HEAD;
   - tracked modifications;
   - untracked files relevant to the task;
   - whether the working tree is safe for this tranche.

3. Authenticate both attached archives and the exact nested accepted owner.

4. Read, at minimum, from the accepted owner:
   - README_FIRST.md;
   - OWNER_REPORT.md;
   - STATUS.json;
   - normative/TEMPORAL_CONTRACT.md;
   - normative/TEMPORAL_CONTRACT_MIGRATION.json;
   - normative/PAIR_IDENTITY.json;
   - the R9.21 general-join rules;
   - fixed source-universe, operation, subject, resource and ownership tables;
   - POSITIVE, P01, P02 and CLOSE G/B/confirmation;
   - active-map reconciliation;
   - current reader and rule sources;
   - current closure matrix;
   - current reconstruction and preservation evidence.

5. Read the accepted review’s:
   - VERDICT.json;
   - REVIEW_REPORT.md;
   - REQUIREMENT_MATRIX.json;
   - FINDINGS.json;
   - METHOD_AND_LIMITS.md.

6. Compare every repository source file implicated by the accepted migration
   map with the accepted source copies or source coordinates in the owner.

Classify each implicated repository surface as:

- exact baseline match;
- compatible drift that does not affect the accepted semantics;
- material drift requiring a reviewed migration decision;
- unavailable or ambiguous.

If material drift would require a new semantic, authority, ownership,
chronology, evidence-domain, versioning, pair-identity or compatibility
decision, stop before edits and issue a source-grounded blocked report.
Do not infer the missing decision.

IMPLEMENTATION OBJECTIVE

Implement the accepted R9.21 whole-R6J general native-source join contract in
the maintained Execution Substrate source.

The implementation must preserve the already accepted candidate-flow,
temporal, authority, ownership and prefix semantics and must implement the
accepted whole general-join design, including:

- the inherited domain-separated, length-framed pair algorithm;
- the accepted noncircular pair/package/active-map binding chain;
- the independently fixed 421-operation / 179-resource universe;
- the exact subject and owner occurrence model;
- exact operation-specific result payload, status, error, return-time and
  consequence joins;
- complete source/source_ref/clock/epoch/sequence/interval/ack/loss coverage;
- exact outside-parent acquisition and supervisor Wait identity;
- admitted supervisor RunResult marshal/stdout relationships;
- closed stage/state/cardinality typing;
- validation before every dependent lookup;
- exact current-pair binding of active migration rows, callers, scenarios,
  effects, owners and sources;
- physically cut P01, P02 and CLOSE evidence without future-positive facts;
- the F-01 prohibition on full-POSITIVE-core hash commitments in prefix B,
  decoded prefix core, confirmation or G members;
- the accepted admission activation, sticky-state, poll-role, owner-slot,
  inherited-C and bounded-ingress semantics.

Preserve the accepted profile meanings:

- POSITIVE is a conditional design witness, not operational qualification.
- P01 retains outstanding Wait, possible child, held worker custody and
  unknown controller custody.
- P02 retains a source-possible incomplete poll and required next sequence
  without fabricating a completed candidate or later observation.
- CLOSE retains one consuming inherited-C Close with uncertain release,
  no retry and no success rescue.

PRESERVE CURRENT CONTRACTS UNLESS THE ACCEPTED DESIGN EXPLICITLY MIGRATES THEM

- Preserve current repository compatibility edges that remain active,
  including bounded CP/ES compatibility, until the accepted map explicitly
  changes them.
- Do not generalize proof-only, local-only, MVP, Remote Alpha or test-only
  behavior into production capability.
- Do not widen connector, Bridge, host, filesystem, process, authority,
  credential, signature or publication scope.
- Do not represent unissued modeled authority as real issuance.
- Do not report live feed, clock, target, storage, observer, reservation,
  signature or cryptographic qualification unless actual runtime evidence is
  produced by an authorized later gate.

IMPLEMENTATION STRATEGY

Use this critical path:

A. Governing contracts and tests

- Install or update the exact accepted normative contract and migration map at
  the repository paths selected by the accepted map.
- Preserve the accepted pair algorithm and exact pair identity treatment.
- Update governing docs and contract tests before or with implementation.
- Change tests that merely freeze the rejected model; do not patch around them.
- Add explicit regression tests for each accepted profile and each previously
  blocking counterexample.

B. Core source implementation

Implement the accepted source semantics at the actual owning boundaries,
including:

- source-instance and interval accounting;
- subject/custody/Wait relationships;
- operation/result joins;
- resource acquisition, wrapper transfer, borrow, invalidation and consuming
  release;
- terminal inventory;
- outside-parent acquisition and supervisor output;
- physically cut prefix construction and interpretation;
- current-pair and active-map binding.

Use one authoritative writer for each mutable runtime fact. Do not create
parallel truth in logs, reports, generated sidecars or test fixtures.

C. Validation-before-use and error handling

- Validate types, cardinality, membership, identities, source epochs,
  operation stages and owner occurrences before keyed lookups or dependent
  arithmetic.
- Preserve known acquisition duties through later qualification failure.
- Preserve unknown/error/partial outcomes without fabricating success,
  descriptor identity, release or retry permission.
- Distinguish syscall/operation error from nonzero child exit.
- Preserve truthful earlier outcome bytes when later publication or delivery
  fails.

D. Integrated profile and regression validation

Translate the accepted finite artifact controls into repository tests where
they exercise implementation behavior.

At minimum cover:

- current positive;
- P01;
- P02;
- CLOSE;
- source omission and interval gaps;
- cross-source union masking;
- duplicate membership and wrong epoch;
- wrong result payload/status/error/return time;
- wrong subject or terminal inventory;
- outside-parent identity and authority mismatch;
- supervisor RunResult/stdout mismatch;
- future-fact grafts;
- invalid stage state;
- stale pair/current-map binding;
- full-POSITIVE hash graft into each prefix surface;
- inherited-C error/unknown/no-retry;
- bounded ingress and cap-plus-one behavior;
- every previously accepted admission/sticky/poll-role regression.

VALIDATION

Derive exact commands from the current repository and report them verbatim.

Run, where available and applicable:

- focused unit tests for touched packages;
- contract/schema tests;
- the complete relevant Go test suites;
- static analysis, formatting and vetting required by repository policy;
- fixture and artifact regeneration checks;
- deterministic/repeat validation for generated evidence;
- repository-wide tests required by current PLANS.md for this migration.

Do not claim validation that did not run. Record skipped validation and why.

The implementation must preserve fail-closed behavior when qualification or
required evidence is absent.

SOURCE AUDIT AND DELIVERY

Produce one source-containing implementation review package suitable for a
fresh, separate artifact/source review. It must include:

- authenticated input identities;
- guarded opening and closing repository captures;
- baseline and successor copies of every touched source, test, contract,
  schema, script, config and fixture;
- exact patch/diff;
- touched-file inventory;
- implementation report;
- source-to-contract and source-to-test crosswalk;
- exact commands, stdout, stderr and exits;
- test and validation results;
- generated artifacts and identities;
- current contract/map/pair identities;
- preservation evidence;
- unresolved seams and skipped validation;
- authority, security, runtime or compatibility widening, expected to be none;
- package manifest and fresh reopen receipt.

The package must not contain secrets, API keys, private credentials, live
databases or unrelated build/cache output.

Classify generated .pyc, __pycache__, build products, databases, archives and
other non-source artifacts. Exclude them unless they are necessary evidence,
and explain every retained one.

Do not treat Codex’s implementation report as independent acceptance.

STOP CONDITIONS

Stop before or during implementation and issue a precise blocked endpoint if:

- current repository drift requires a semantic or authority decision not in the
  accepted design;
- the accepted source/map does not identify a required implementation owner;
- implementation requires a new event kind, evidence domain, authority class,
  version family, string exception, compatibility mode or pair algorithm;
- a required fact cannot be represented in the accepted G/B/confirmation or
  repository contract;
- a repository test establishes a contradiction with the accepted design that
  cannot be resolved by replacing a rejected historical contract;
- exact accepted profile behavior cannot be implemented without weakening an
  accepted invariant;
- sensitive or unrelated repository changes are present and cannot be safely
  separated.

Do not solve a stop condition by adding an undocumented alias, callback,
sidecar truth source, fallback mode or test-only exception.

DELIVERY ENDPOINTS

On successful source implementation and repository validation, return:

ES_MOUNTED_HELPER_R6_GENERAL_NATIVE_SOURCE_JOIN_IMPLEMENTED_READY_FOR_FRESH_SOURCE_REVIEW

On a source/design/repository conflict, return a precise blocked endpoint that
names the unresolved seam.

REPORTING REQUIREMENTS

Return:

- primary endpoint;
- exact repository opening and closing state;
- touched files;
- exact commands and results;
- implementation summary by accepted contract surface;
- source/test crosswalk;
- failed attempts and corrections;
- assumptions and unresolved seams;
- skipped validation;
- package path, bytes, members and SHA-256;
- whether any authority, security, compatibility or runtime scope widened;
- whether any commit, push, deployment or publication occurred.

No commit, push, deployment or publication is authorized in this task.
```

This is the first point in the sequence where returning to Codex is justified. The task still requires a fresh source review after implementation before any Git progression or runtime/product gate.

Some older intermediate files may have expired, but they are no longer required. The accepted delivery and accepted review are the authoritative implementation inputs.

**Sources:** ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip[accepted delivery](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip); ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip[accepted review](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip).  
**Confidence:** **0.99** in the implementation decision and accepted artifact boundary; implementation feasibility against the current repository remains conditional on Codex’s pre-edit source comparison.
