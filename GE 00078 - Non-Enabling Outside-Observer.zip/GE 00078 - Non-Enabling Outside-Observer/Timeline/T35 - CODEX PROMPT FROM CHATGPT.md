ES mounted-helper v2 successor — repair the external component and test safe Linux mechanics
Decision, objective, and execution role
Return to the existing implementation/preparation Codex conversation. You are the sole writer of a new external-artifact successor. This is implementation and engineering validation, not the independent auditor's conversation.
Retain ES_MOUNTED_HELPER_V2_PREEXECUTION_REAUDIT_BLOCKED for the rejected v2. Repair V2-01 through V2-16 from the authenticated independent re-audit, preserving the historical F-1 through F-16 closure distinctions. Keep the selected finite supervisor / namespace-worker / candidate / adjudicator model. Do not start a new architecture reset, general gateway project, or privileged execution framework.
Deliver corrected external source and documentation, a concrete upstream-entry interface, passing safe controls, compile-only privileged/proof artifacts, and a compact successor packet for fresh independent re-audit. The validated ES source, candidate, required-test inventory, and product-validation streams must remain unchanged.
Explicit change to the preceding preparation boundary: this prompt authorizes ordinary-user repair and control replay in one task, followed by a narrowly constrained Linux/AMD64 mechanics-control execution on the existing governed host. It does NOT authorize the privileged supervisor, importer, namespace worker in live mode, formatter, gateway, or either ES proof binary to execute. No namespace is created or entered, no mount or loop device is touched, and no credential/capability transition occurs. The safe Linux controls are defined in section 6. They are not mounted evidence or privileged-entry approval.
Proceed through the internal gates below without requiring a user relay for routine in-scope corrections. Record owner review as engineering review, never independent acceptance. A genuine scope, authority, source-target, or access conflict stops the affected execution; do not invent a fallback.
1. Fixed inputs and evidence classifications
Authenticate these inputs before changing successor source. Read actual files, scripts, tests, and all three specialist reports; the summaries here are navigation, not a replacement.
Independent re-audit
Root: /Users/ds/Downloads/ES-mounted-helper-v2-independent-reaudit-ZKiL8w6n
- ES_MOUNTED_HELPER_V2_INDEPENDENT_REAUDIT_REPORT.md: 38,747 bytes; SHA-256 048927a7b3fef715e814e39335685b90d271caa5d64695352741a92fe4229db1.
- ES_MOUNTED_HELPER_V2_INDEPENDENT_REAUDIT.zip: SHA-256 452b57c2c9be50643a8fbc76f7a3c3f21b5e4bbd04fd67345b8b64afd247ef36.
- Read the actual FINAL_ARTIFACT_IDENTITIES.json, packet/MANIFEST.tsv, source excerpts, complete finding register, and directly retained SPECIALIST_LINUX_LIFECYCLE_MECHANICS.md, SPECIALIST_ENTRY_CUSTODY_AUTHORITY.md, and SPECIALIST_PROOF_OVERLAY_ADJUDICATION.md at their manifest-selected locations. Resolve missing manifest identities through the authenticated packet, not guessed digests.
Rejected v2 implementation
Root: /Users/ds/Downloads/ES-mounted-helper-v2-repair-j4Xz0AQK
- review/ES_MOUNTED_HELPER_V2_REPAIR_REVIEW.zip: 309,931 bytes; SHA-256 5d888be91c4898783410cec3f0fa6cced305f366f1f6281d35caaf44ae02737f.
- review/MANIFEST.tsv: 15,349 bytes; SHA-256 5de1b3baa22132bba6c8c7a8883b224976130871804b031ab97e501e90df29a6.
- ES_MOUNTED_HELPER_V2_REPAIR_REPORT.md: 18,796 bytes; SHA-256 3efefaf0a394caa706820029377f42ec6805e596c7401a0acabfb7107b855484.
- FINAL_ARTIFACT_IDENTITIES.json: SHA-256 00f4e804337f9a67210e68dec94465e26c18593dbae442bed7437041245af48d.
The authenticated ZIP is the canonical v2 review target. Its 133 members include 132 payload members and the self-excluded manifest. The audit found 55 same-content authoring-root files with different modes and six packet-only members; it did not find a content-target mismatch. Do not demand fictitious root/ZIP equivalence, repair old modes, substitute a missing root file, or incorporate work/, binaries, __pycache__, or unrelated material into the target. Preserve those classifications. Derive the successor in a new directory; keep all rejected generations unchanged.
Unchanged ES baseline
Validation root: /Users/ds/Downloads/ES-cust2-nsfs-assurance-validation-kgthnJ
Binding	Required value
Repository	/Users/ds/Repositories/Execution Substrate
Branch / upstream	trunk_dev / origin/trunk_dev
HEAD	b92bd9884106154d25342e1573dcc4c312311436
Tree	cdd4e44bac15c1952d70997143040644361f0bb1
Source manifest	358 rows / 67,617 bytes / e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e
Candidate manifest	83 rows / 10,037 bytes / 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2
Original archive	final-snapshot/source-build-A.tar, 7,485,440 bytes / 12a8b8a626911d51dedf1b138b88deb314aff00d0de6ec063c96ac53d6146202
Archive-member manifest	358 rows / 79,414 bytes / 3e0195237c1b89fcb15242b886e17735c47d54b6710dd7ca8dafc1f6f63d4e5e
ES requirement inventory	327 rows / 141,680 bytes / 8b3ed6e32ba809bda751632292773c9adc28096691ad9307be32affa288515eb
Tracked diff	2,407,274 bytes / 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1
Complete integration diff	2,746,480 bytes / 38de7ecbcbb52252104710ddb6075a205a9c8a571590d96ed93247ba5a5501e0
Index / worktrees	zero staged/conflicted paths, no active operation; six worktrees


Use current AGENTS.md, latest PLANS.md, relevant configuration/capability and execution-lifecycle contracts, then source/tests in their owning order. In particular inspect the current whole-candidate gate at the reported PLANS.md:399-411, all six execution_roots*.go files and relevant result/service integration. Inspect the external live code, portable controllers, command dispatch, tests, schemas, overlay/generators, build selection, command plan, and raw records together.
Read the retained provenance recipe before reproducing it. Use narrowly scoped read-only Git queries, optional locks disabled, and no fsmonitor, hooks, external diff/textconv/filter execution. Do not run an archived helper merely because it has an expected digest. Authenticate necessary lineage once; do not rebuild every historical packet.
The re-audit records exact app-owned refs/codex/turn-diffs/... name changes pointing to the same object. Preserve any such individually demonstrated delta rather than claiming complete historical ref equality. This is not permission to ignore ref drift. HEAD, branch/upstream objects, source/candidate, index, meaningful refs, and worktree topology must remain preserved.
2. Mutation and execution boundary
Create one fresh 0700 directory under /Users/ds/Downloads, for example ES-mounted-helper-v2-successor-<unique>. All authoring, ordinary-user controls, task-specific configuration/cache, and final artifacts live there or in explicitly recorded task-owned ordinary scratch. Changes may cover the existing external Go tooling, drivers, instrumentation, scripts, tests, schemas, command plans, and docs needed for the findings. Limited extraction of shared safe OS primitives for testing is allowed; a second implementation of those primitives is not.
The authoring model has one writer and no audit subagents. Do not use concurrent test executions whose effects or observations can interfere. First record the exact repair map and amended owner/state/effect table, then implement in this task. Do not use a design-only stop for choices already fixed here.
Prohibited throughout:
- Any repository edit, formatting, test, build, status-doc update, index/ref/worktree mutation, fetch, staging, commit, PR, merge, push, or deployment; any change to the original 358 source members in either disposable base union.
- ES-suite reruns or execution of any ES proof binary, even an instrumented one. Compilation of the normal/diagnostic unions remains allowed after source authentication.
- Root/sudo, gateway installation or invocation, input import to privileged paths, live supervisor execution, live fixture-worker execution, formatter execution, loop access, mount/unmount, namespace creation or entry, filesystem formatting, capability/UID/GID changes, sysctl/AppArmor/sudoers/group changes, or cgroup/quota creation.
- VM/Lima/Docker/service startup, restoration or discovery, live workloads, target staging/results/security/config reads, credential use beyond the existing ordinary SSH connection, or any new dependency/toolchain installation/download.
- Historical evidence edits, historical-cache cleanup, telemetry-history discovery/deletion, or broad host inventory.
The only remote permission is section 6. All proposed future root commands remain data, not authorized commands.
Preserve the existing finite fixture: one selected AMD64 target, eleven normal cases, eight supplementary diagnostic cases, one 64 MiB ext4 image and one held loop association, the fixed mount set, and unprivileged candidate identity. Do not add another supervisor layer, permanent daemon, generic approval engine, alternate host, or broader product dependency. The implementation can be simplified within the existing owner model where the same obligations are demonstrated.
3. Required source and interface repairs
Retain a row for each V2 finding and its related historical F rows. Differentiate historical static closure, successor defect, implemented repair, executed safe control, and genuinely privileged/runtime-only remainder. Closed historical defects are regression obligations, not reasons to restart v1 design.
A. Reachable entry and namespace-object custody — V2-01, V2-02
The report's anchors are main.go:24-28,41-45, manifest_linux.go:268-337, and worker_linux.go:107-125; verify locations in the canonical ZIP.
1. Perform raw entry identity/CWD/environment/FD validation before explicit timer, signal, logging, poller, and child setup that can create descriptors. Inspect initialization and the validator's own enumeration side effects against the pinned runtime. Distinguish inherited descriptors from later runtime-owned descriptors. Do not allow arbitrary extras, allow every anon_inode, or close unidentified runtime FDs to make a count pass.
2. Retain the fixed privileged identity contract in real public modes. Safe tests may exercise the same raw-observation primitives against independently specified ordinary-user contexts; they must not introduce a runtime bypass flag into privileged entry or pretend an ordinary-user context is a root approval.
3. Add fresh-Linux-process regressions for clean raw entry, a deliberately inherited extra FD, later timer/poller creation, and enforcement of the correct sequence. A Go test process whose timers already ran is not evidence of the initial raw-entry state. Couple source-order controls to subprocess tests of the actual shared entry mechanics.
4. Open only the fixed namespace link beneath the owned child's authenticated proc entry. Retain child PID/start/pidfd custody, follow that specific kernel namespace link, verify namespace object identity and NS_GET_NSTYPE == CLONE_NEWNS, and bind the worker hello to the held object. This is an object-type-specific exception, not weakening no-follow custody for ordinary file inputs. O_PATH|O_NOFOLLOW holding the symlink itself is not a namespace handle.
5. Test wrong namespace type, child exit/identity disagreement, and arbitrary-path substitution refusal. Reading an existing own/child namespace handle does not establish new-namespace creation, private propagation, or mounting capability.
B. Child, thread, formatter, RPC, and deadline ownership — V2-04 through V2-07, V2-10, V2-11, V2-14
Inspect the reported live_linux.go:211-255,393-486,620-759, worker_linux.go:29-187,268-280,877-993, candidate_linux.go:225-305, and lifecycle.go:147-303,341-490.
- Keep a stable locked OS-thread owner from before each supervisor-created worker/formatter child through its required lifetime and reap. Preserve the already-locked worker-to-candidate path. Bind Pdeathsig to its actual creating-thread semantics, not merely a process PID. Do not unlock and return the owner thread to reuse while the child still depends on it.
- Observe current-thread credential/capability/fs-ID state through /proc/thread-self/status or an equivalently demonstrated coherent task view. Preserve complete UID/GID/groups/capability/no-new-privs/securebits checks. Nonprivileged read controls are not validation of the later privilege drop.
- Make formatter-acquired/alive/reaped/group-absent/uncertain state explicit in the controller. Retain pidfd, process-group and resource custody even when leader Wait completes or escalation is uncertain. Do not start loop association or destructive cleanup while formatter descendants or observations remain uncertain.
- Give every worker request and response a monotonic sequence, action, subject, and connection/phase binding. A timeout, truncated/invalid frame, mismatched reply, or unexpected response permanently poisons that connection. A late success cannot acknowledge cleanup or any later action. Do not reconnect/retry to erase ambiguous effects. Cleanup must use independently retained ownership/observations or record uncertainty; never assume the timed-out effect did not occur.
- Use absolute total/phase deadlines and reserve cleanup/export time before beginning further effects. Every subcall, acknowledgement, escalation and reap consumes its owning phase budget. A cleanup context may be independent of the canceled work signal only while remaining bounded by the original total/deadline contract; it may not reset the wall clock. Eliminate unbounded post-kill waits and abandoned wait goroutines as claimed closeout mechanisms.
- Be explicit about limits of bounded observation: signal delivery is not proof of process death, and inability to reap/observe within the budget is uncertainty, not a successful bounded shutdown. Preserve exact residual process/object state and evidence rather than claim clean. Do not add a generic autonomous recovery service.
- Skip getpgid failures only for the source-justified gone-process case (ESRCH). Other observation failures are uncertainty. Use an appropriate final existence observation without giving unrelated processes cleanup authority.
- Persist a root-private pre-effect episode/intention record before the first run-root mutation; account for failures between acquisition, in-memory custody, and durable attachment. Parent/bootstrap-established control storage is an explicit prerequisite, not an unrecorded first effect. Cleanup errors and unresolved termination cannot coexist with unqualified Cleanup:"succeeded"; a demonstrated recovery must have an explicit separate outcome and retained original error.
Derive tests from the real adapter's syscall/effect sequence, including resource acquisition followed by a failure before the adapter returns. The 170 old abstract fault occurrences are not a completeness target. Preserve them where valid and add the newly identified windows.
C. Minimal administrative entry and formatter interface — V2-03, related F-3/F-4/F-10
Repair downstream validation and fully specify the minimum upstream obligations; do not implement or install /usr/local/sbin/es-proof-approved-exec in this task.
- An independently trusted administrative entry must pin the reviewed policy/manifest digest, target, phase, permitted exact argv, source/build-to-binary binding, and accepted objects independently of the caller's payload. A caller-selected receipt digest or shape-valid object list is not authority.
- Separate approval, requested inputs, import observation, and run observation. Define receipt content/schema and an acyclic binding order. Import receipts may establish what was copied from an approved input; they cannot authorize their own creation or choose what approval to trust. Run-phase prerequisites must not make a manifest depend on its own future receipt.
- The supervisor's runtime digest labels attest only to matches against an independently approved manifest. Source derivation is established by authenticated build/effective-union records, not magically reconstructed from a binary label at runtime. Bind both statements honestly.
- Specify formatter executable, loader/library resolution, configuration/runtime inputs and their trusted ancestry and selection from the actual invocation and executable format. Nonempty dummy dependency/config arrays must fail the semantic contract. Inputs and environment that alter resolution require explicit treatment. Same-byte formatter custody must survive validation-to-exec; replacing a trusted execution object with a later path lookup is not closure.
- Keep a finite source-justified target-qualification procedure for unknown formatter identities/closure. Do not invent target hashes, execute ldd/a formatter, inspect private host state, or silently claim the upstream entry is implemented. Unknown target facts remain explicit; unspecified approval semantics are not a runtime-only remainder.
- Provide controls rejecting wrong phase/target/policy, receipt cycles, placeholders treated as approval, unrelated dependency objects, changed formatter selection and manifests approving themselves. Ordinary-user synthetic administrative fixtures are tests only, never installed authority.
D. Complete resource and evidence accounting — V2-08, V2-13, related F-13/F-15/F-16
- Inspect scratch before each spawn, after every candidate completion including immediate exit, after relevant evidence creation, and before cleanup/export/closeout. Include supervisor-private records, normal and diagnostic output, node manifests, final manifests, result records, closeout and failure evidence. No final-file loophole or uncharged self-excluding manifest is allowed; reserve bounded overhead where necessary.
- Preserve numeric ceilings and specify each as kernel-enforced, application/write-enforced, sampled observation, or acceptance ceiling. Polling plus post-exit inventory is not a hard aggregate filesystem limit. Select honest sampling/acceptance semantics where no hard mechanism exists; do not add cgroups, quotas or another filesystem to manufacture a hard-bound claim. Oversize/unknown final inventory must fail acceptance and block unsafe deletion even after exit zero. If an owning rule genuinely requires stronger hard containment, report that unresolved requirement rather than weaken it or expand effects.
- Export bounded canonical per-node before/after evidence for the synthetic protected trees. Preserve independent expected sentinels, exact identities/types/modes/owners/entry and byte observations, bounds, and reference hashes. The external adjudicator must validate the retained node records and recompute the bound hashes, not trust a child saying two hashes match.
- Keep distinct primary-process, test, case, cleanup, inventory, export and final outcomes. Complete error evidence must survive partial setup and failed export. Equality is not a claim against every transient/restored/idempotent mutation.
- Add equal/plus-one boundary controls and fast-exit oversize cases, final-export overhead, record-write failures, concurrent status/error combinations, unreadable inventory, and missing/tampered/duplicated node records.
E. Real parser behavior and exact claims — V2-12, V2-15, V2-16
- Repair parseGoTestTerminal itself. Require exact selected-test === RUN and --- PASS terminals; latch skip/fail; separately require package PASS. Reject prefix-name collisions, missing selected terminals, duplicate/conflicting terminals and truncation. A later bare package PASS must never overwrite --- SKIP or --- FAIL.
- Exercise the actual parser with real verbose Go control-test outputs as well as negative byte fixtures. Injecting a precomputed TestState field is not parser testing. The original raw-stream counterexample is preserved as a rejected control.
- Preserve all eleven normal and eight diagnostic cases. The normal binary must pass independently; supplementary diagnostic evidence cannot rescue it. Keep the one-file diagnostic overlay source/effective-union distinction, its observational timing effects, and the F-12 source-order versus nondiscriminating-public-error disagreement. Do not add product hooks, rewrite public errors or create a production reconciliation caller.
- Correct spec.go's independent artifact expectation to the source-grounded result.tar.gz; retain independent fixture expectations rather than generating them from observed output. Narrow build support to what is actually implemented; do not use a broad !linux claim for Darwin-only support.
- Distinguish no skipped command/test from a no-test package terminal. Required paths cannot skip. Deliberate child-stream SKIP controls are negative parser inputs, not mounted passes.
- State unconditionally that a fresh whole-candidate independent ES audit is required before acceptance/commit for this candidate. Any subsequent ES source change requires a new source-bound audit. External tooling audits never substitute. Correct successor documents, not old reports or repository PLANS.
4. V2-09: effective validation environment before any Go invocation
The old command records remain authentic; their telemetry-off and confined-write claims do not. Preserve original requested settings and observed GOTELEMETRY:"local". Do not infer upload, zero telemetry writes, exact private host delta, or corruption of previously validated ES bytes. Do not search or clean the user's historical telemetry directories.
This task explicitly authorizes task-local telemetry configuration and storage. Before invoking even go version, inspect the installed pinned Go source as data to determine its supported configuration/storage selection. Create isolated task-owned HOME/config/cache/telemetry locations and preselect the supported mechanism for all tool and compiler children. A pinned source-supported test-directory selector may be used with an explicit test-only classification; do not assume it exists or covers every Go child. Changing the command child's HOME/config is permitted here; changing the user's real HOME, global settings, or shell startup is not.
Use the supported go telemetry off command only under that already-isolated context. Any initialization counters created before the mode switch must be inside the authorized task root, disclosed, and never uploaded. Then require observed GOTELEMETRY == "off" and observed GOTELEMETRYDIR equal to the intended private location before builds/tests. These reported variables are not made effective by simply assigning similarly named environment variables. Preserve exact requested/effective facts separately. Read source to establish isolation before the first command; a post-write discovery that the real user directory was used is too late.
Pin:
GO=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Expected executable SHA-256: 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Use existing dependencies only; preserve the retained module graph. Set GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, and readonly module flags, with explicitly bound existing GOMODCACHE and task-local GOCACHE/GOTMPDIR. Record effective GOOS/GOARCH/CGO/GOROOT/module/cache/temp values. GOENV may correctly report an explicit empty value; a missing key is not an empty value. Do not use global go env -w, download, install, or modify the shared module/toolchain assets.
Test the runner's real effective-environment adjudicator against off/private-dir success, local instead of off, wrong directory, missing key, failed command, malformed/duplicate-key output, and compiler-child environment propagation. Repair cannot be merely a report-wording change.
5. Local implementation controls and compile-only artifacts
Freeze an exact preparation command plan after inspecting effects. Ordinary development corrections within this scope are allowed before final validation; retain each failed attempt and final-source relationship. Neither a predetermined command count nor 222 passing events is an acceptance criterion.
From the successor external tooling module, using the environment above:
"$GO" version
"$GO" env -json GOOS GOARCH CGO_ENABLED GOROOT GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS GOTELEMETRY GOTELEMETRYDIR GOMODCACHE GOCACHE GOTMPDIR
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/supervisor-linux-amd64" ./cmd/es-mounted-proof-v2
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/safe-controls-linux-amd64" ./cmd/es-mounted-proof-safe-controls
The last command selects the narrow control entry defined below, not a relaxed privileged mode. If actual package layout requires path adjustment, record the mapping before execution; do not change the effect boundary or omit a command silently. Run pinned formatting checks on all authored Go source. Use only already-installed race/C tool support; absence blocks that lane rather than authorizing installation.
Use the existing authenticated ES archive, not another repository snapshot, to reconstruct disposable normal and diagnostic bases. Verify all 358 original members unchanged before and after building. Preserve the normal union and independently represent the diagnostic base and actual effective-source replacement. Review regenerated overlay/diff before compilation. From the respective unions run:
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" test -c -o "$OUT/normal-proof-linux-amd64.test" ./es/admission
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" test -c -tags esmountedproofinstrumentation -overlay "$OVERLAY" -o "$OUT/diagnostic-proof-linux-amd64.test" ./es/admission
Inspect ELF/build metadata and hash all outputs. Do not execute these two proof binaries or the supervisor.
Portable controls must exercise the actual repaired controller/adjudicator/transport with substituted privileged effects, including partial success before error, late/misbound RPC replies, formatter-leader exit with surviving group, deadline exhaustion during cleanup, getpgid uncertainty, fast completion before polling, all final evidence accounting, node-manifest validation, entry/receipt negatives, and exact parser terminals. Mocked elapsed time and injected kernel effects must be labeled as such. Add source/selected-build coverage explaining which actual Linux functions remain unexecuted.
6. Explicitly authorized ordinary-user Linux mechanics controls
Target and constraints
Only host_to_remote_linux_m75q, using the existing ordinary ds SSH login with strict existing host-key checks, batch mode, no forwarding and no TTY. Expected machine-ID SHA-256 is a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6; expected UID:GID is 1000:1000, Linux/AMD64. Authenticate current identity; historical kernel/version observations are not current facts. Do not use raw machine identifiers in the shared packet.
Do not contact ARM64/Lima or any other host. No sudo availability test, alternate login, access repair, service command, global process-tree dump or private host discovery is permitted. On inaccessible/mismatched target, preserve local work and report Linux mechanics pending.
The host receives only the new source-bound safe-control executable, its fixed plan/binding data, and a minimal inspected ordinary-user transport/timeout wrapper when needed. It receives no ES archive, supervisor, formatter, proof binary or privileged manifest. No Go executable, compiler, telemetry setup, shared cache or dependency operation is needed remotely; the control binary is cross-compiled locally.
Required safety and source-coupling gate before transfer
The new cmd/es-mounted-proof-safe-controls entry must be fixed-purpose. It accepts only its enumerated control names, not arbitrary commands, paths, PID selectors or scripts. It must refuse root execution. It must call the same safe FD/proc/thread/child/RPC/parser routines used by the successor, not copies. No control may dispatch real import, privileged entry, namespace-worker live mode, formatter, mount, loop, setns/unshare, ES package tests, UID/GID/capability mutation or network behavior.
Inspect and retain a control-to-code/effect table including imports, init functions, subprocesses and failure cleanup. Arrange build selection or internal entry separation so forbidden dispatch is unavailable from the safe entry; a flag that disables a root check in the live supervisor is forbidden. Any mocks must replace only the privileged effects outside the safe primitive being tested. If this cannot be established, stop remote execution and report the exact source gap; do not treat the word safe as a guard.
Finite allowed controls
The control executable provides these exact names (source-coupled names may map internally to multiple bounded assertions):
1. raw-entry: fresh child process, actual raw FD observation before explicit timer/poller setup; expected ordinary-user context; deliberate inherited extra-FD rejection; later timer-created descriptors classified separately. Structural tests also establish real public entry ordering without running the public root mode.
2. namespace-handle: open the existing mount-namespace handle of an owned harmless child while retaining its PID/start/pidfd; verify namespace type and identity; reject an existing wrong-type handle. No namespace creation, entry, bind or other namespace mutation.
3. thread-child-owner: actual locked creator-thread and same-UID harmless child lifetime with parent-death binding; stable owner while alive and owned termination/reap. Child code is part of this fixed safe executable and creates no further processes except the bounded control-defined descendants.
4. rpc-correlation: actual task-owned pipes/socketpair and harmless peer; late/wrong/duplicate replies cannot satisfy the next action; timeout poisons the connection. No real worker or mounted operation.
5. process-observation: owned child/group exit and absence handling through actual nonprivileged inventory routines. Inject non-ESRCH errors where safely creating them is not possible; keep injected versus observed cases separate.
6. thread-observation: read current-thread identity/capability projections from a locked thread and bind its TID. Do not change identity, groups, capabilities or namespace. This is read-mechanics coverage, not a privilege-drop proof.
7. exact-terminals: exercise the actual parser with source-bound raw pass/skip/fail/package streams; correctly reject skipped selected tests followed by package PASS. Label stored streams as parser inputs, not current mounted events.
Allowed kernel effects are ordinary own-process/thread/FD/pipe/socketpair/process-group operations, pidfd observation of owned children, fixed read-only proc observations for self/owned children, namespace-type query on those existing handles, parent-death signal setting for owned children, signals/reap of owned processes, and task-owned ordinary files. A process group is not a namespace. No Unix listener outside scratch and no network listener is required.
Use at most eight concurrent owned control processes, bounded output (4 MiB total), and at most 32 MiB task scratch excluding the authenticated executable. Each control has a 30-second outer deadline; the complete remote control run has a 240-second outer deadline, including its ordinary cleanup. These are test-harness control limits, not a claim that arbitrary kernel waits always finish. If cleanup cannot be established, retain exact scratch/owned-process identities and return uncertainty; do not kill unrelated processes or delete an uncertain tree.
Create a fresh physical owner-only remote scratch root; bind path/device/inode/owner/mode and authenticate transferred bytes before execution. Freeze exact absolute argv, CWD, allowlisted environment, timeout wrapper and expected control inventory. Each command is:
<authenticated-remote-root>/safe-controls-linux-amd64 <one-exact-control-name>
Execute sequentially. Each applicable assertion must explicitly pass; no skip, empty output, missing child, or exit-zero-only acceptance. Preserve source/runtime/process observation boundaries. Source-authenticated inability to perform an allowed mechanism is an environment/scope block, not permission to invoke a privileged fallback.
A maximum of one in-scope safe-control/source correction and second remote generation is authorized. Authenticate and close the first generation, rebuild/refreeze locally, preserve its failure and exact delta, and rerun affected controls with a complete binding. This is development validation, not permission to repeat an unchanged failure. Further failure stops the remote track. Do not wait/poll indefinitely for access.
Return and authenticate evidence before exact scratch removal. Observe no owned survivor/reference and no unexpected mount beneath scratch before deletion; then record absence. Preserve both primary and cleanup failure. SSH/accounting and transient process effects are explicitly acknowledged, not described as zero host state change.
7. Freeze, engineering review and successor packet
After in-scope development, freeze final external source, driver/overlay effective unions, safe-control plan, runner/evaluator, schemas and binaries. Every credited final command must bind to those exact inputs; a source change invalidates affected control/build evidence and requires rerunning affected controls. ES validation is not rerun because ES source did not change. Preserve all failed generations and all historical evidence.
Engineering closeout must review the actual Linux live-effect path alongside portable controllers and controls, not only counts. For each V2-01…V2-16 and F-1…F-16 record source locations, causal repair, executed controls, unexecuted Linux/root remainder, authority prerequisites, and uncertainty. Preserve all specialist disagreements. Static closure may be claimed only within owner-review scope and never as independent acceptance.
Return a report plus one compact self-contained ZIP containing current external sources, docs, exact successor delta, all three historical specialist reports or exact authenticated input references with their actual text available, owner/effect table, V2/F closure map, command/source-selection records, requested/effective environment evidence, final safe-control streams, raw Linux control evidence, schemas/inventories, union/overlay identities and diff, preservation and cleanup, and remaining-gate register. Expose source directly, not another recursive ZIP chain.
The registered review target's per-file bytes and modes must be internally consistent. Classify authoring-root/packet representation differences explicitly. Exclude binaries, caches, full source unions, images, secrets, actual user configuration, and raw arbitrary host data; identify compile artifacts separately. Use a self-excluding member manifest and an acyclic external final-identities record; no file hashes itself. Do not impose old command/file/event counts as successor expectations.
Repeat opening-to-closing ES source/candidate/status/index/refs/worktree comparisons. The expected repository change count is zero. The diagnostic effective-source overlay remains external proof instrumentation and must never be confused with a repository edit or with normal execution of original bytes.
Success token:
ES_MOUNTED_HELPER_V2_SUCCESSOR_REPAIRED_SAFE_LINUX_CONTROLS_PASSED_REAUDIT_REQUIRED
If source/local controls are complete but permitted Linux mechanics cannot execute:
ES_MOUNTED_HELPER_V2_SUCCESSOR_LOCAL_CONTROLS_COMPLETE_LINUX_MECHANICS_PENDING
Otherwise report:
ES_MOUNTED_HELPER_V2_SUCCESSOR_REPAIR_OR_CONTROLS_BLOCKED
These are engineering results only. A fresh independent re-audit of the successor remains required. Independently trusted entry establishment, approved import/run, actual 11-case/8-diagnostic mounted execution, real formatter/loop/casefold/privilege behavior, running-deployment observation, supported-local consumer/operator proof, fresh whole-candidate ES audit, and separate exact-byte staging/commit authority remain pending. Do not automatically install, import, mount, deploy, or publish after this task.
Conclude with exact touched external paths, commands/exits, source bindings, failures/retries, residual state, unexecuted gates, authority/security deltas, inspection limits, and separate provenance/validation/implementation confidence. Return links to the successor report and compact ZIP; no input-packet rebuilding or separate collection task is needed.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
