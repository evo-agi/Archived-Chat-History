**Preserve the audit’s `INCOMPLETE` endpoint, but treat the current source as independently blocked.** Recovering the missing invocation records would not make this successor acceptable: the report establishes nine separate source/interface defects. The next task should repair those defects and produce complete **new-source validation**, not spend another cycle re-auditing unchanged code or trying to recreate historical execution records. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation, not the audit conversation: :chatgpt-content-reference{index="12"}[Episode ownership, delivery, and receiver repair prompt](sandbox:/mnt/data/ES_Producer_Receiver_Repair/ES_Producer_Receiver_and_Owner_Repair_Prompt.md).**

The handoff is external-only. It keeps the validated ES candidate unchanged and authorizes no host contact, privileged execution, devices, mounts, gateway installation, or ES-suite rerun.

## Separate the evidence gap from the implementation failure

The missing evidence is specific. The auditor authenticated the **17 recorded validation commands**, independently parsed both 530-pass streams, and checked all 269 required controls. It also independently recomputed the final predicate. What it could not authenticate was the exact execution of the failed relative-path evaluator call and its corrected successor: the retained note and output body do not establish their actual arguments, working directory, timing, exit, timeout, and streams. :chatgpt-content-reference{index="1"}

That distinction matters in both directions:

**The missing evaluator records do not turn the authenticated Go tests into failed tests. Nor does a successful independent recomputation prove how the owner’s earlier evaluator was invoked.**

The prompt permits one bounded search in the named retained record locations. Genuine records can be added as a separately identified supplement. Missing records must remain missing; a new call cannot reconstruct them.

I am also making the continuation rule explicit: **unrecoverable predecessor invocation history is not a prerequisite for independently complete validation of a repaired successor.** The old audit remains incomplete as history. The next generation must record its own commands—including evaluation and package verification—completely, and every inherited claim must have adequate evidence for its particular use.

The two secondary gaps receive similarly bounded treatment. The successor must retain a current selected-build-input record, rather than relying only on the complete-source manifest. The missing preliminary predecessor fixtures remain a limitation; their build-collision and AST-panic attempts must not receive credit for demonstrating all eight earlier defects. The third attempt has a retained fixture and separate, narrower credit. :chatgpt-content-reference{index="2"}

## The immediate engineering problem is a broken producer-to-receiver path

The strongest signal in this audit is not another test count. **The selected live caller cannot establish its export parent, and its exact receipt has no usable delivery channel.** The publisher expects `<ScratchBase>/exports` to exist, but the live path never creates it. The receipt is printed to stdout even though privileged entry directs stdout to `/dev/null`. Local tests concealed the first problem by preparing the parent themselves. :chatgpt-content-reference{index="3"}

These are basic integration failures beneath the more elaborate terminal graph. The next task must demonstrate a reachable path before claiming that the graph’s integrity makes the component adequate.

### Establish the parent and deliver the actual receipt

The prompt requires the actual caller to establish its required export children under independently approved, held base custody. Any directory genuinely supplied by an upstream actor must be an explicit input checked before operations—not an undocumented test setup.

For receipt delivery, **the handoff selects one bounded persisted receipt object in held episode-export custody, outside the already sealed bundle**. It does not widen the raw-entry descriptor allowance or rely on stdout. The receiver must consume the exact bytes recovered from that object, not a similar structure reconstructed from the producer’s return value.

That is a new repair direction, not a claim about current functionality. Its contract must distinguish the receipt’s contents from subsequent observations of its delivery: the receipt cannot establish that its own future write or synchronization succeeded. Missing, partial, late, or uncertain delivery remains a failure to complete the evidence path.

### Integrity, authority, and successful outcome are three different checks

The remaining terminal findings identify three independent deficiencies:

| Finding | Current deficiency | Required repair |
|---|---|---|
| **TPA-02** | Confirmation supplies an episode and matching receipt digest without an independent authentication or observation contract. | Validate it against independently supplied trust, approval, subject, target, source, export, containment, and terminal expectations. |
| **TPA-04** | A self-consistent failed or uncertain operational outcome can pass verification. | Require the actual success, cleanup, inventory, deadline, cancellation, scratch, residual-policy, and case predicates. |
| **TPA-05** | The receiver checks a caller-selected tree against claims inside that same tree. | Acquire and verify the objects against independently approved path, parent, identity, ownership, mode, and episode expectations. |

These are the audit’s demonstrated predicates—not additional speculative requirements. :chatgpt-content-reference{index="4"}

**An authenticated statement about a failed operation is still evidence of failure.** Confirmation must not rescue a failed primary result, unresolved cleanup, missing required case, unapproved residual, cancellation, or late publication.

The handoff defines an independently provisioned receiver context and a concrete authentication interface. It does **not** commission a signing service, create production keys, install an administrative entry, or make the user a routine synchronous confirmer. Synthetic trust inputs may exercise the interface, but their provenance and limitations must be explicit. A test that merely computes a matching digest from its own receipt does not establish authentication.

## Repair lifecycle ownership at the real acquisition and cleanup boundaries

The four Linux/lifecycle findings show the same integration pattern: an inner routine was repaired, but its caller or later reentry loses the property.

| Finding | Required boundary correction |
|---|---|
| **LNX-LIFE-01** | Bind the exact episode, cancellation, and original typed deadline before deliberate task effects. A pre-canceled entry must not create or append its ledger, and terminal processing must retain cancellation. |
| **LNX-LIFE-02** | Pass original expected parent/root identity—or the already-qualified descriptors—into destructive acquisition. Do not adopt whatever later occupies the pathname. |
| **LNX-LIFE-03** | Record each process/descriptor facet in the real producer as soon as it is learned, before the next fallible operation. Derive residual states from actual custody rather than hard-coded release claims. |
| **LNX-LIFE-04** | Preserve the original per-subject signal authority across cleanup reentry. A later detached reserve cannot revive an expired signal decision. Apply the checks to worker and candidate paths as well as the formatter. |

The report traces each defect through current caller behavior. :chatgpt-content-reference{index="5"}

The scratch case is particularly important. Descriptor-relative deletion **after opening a replacement tree** does not prove that the helper is deleting its originally owned tree. The repair must compare the acquired descriptors with the prior expected identities before removal. Rename-away and pathname absence also cannot establish that an originally held object ceased to exist. The next controls therefore exercise replacement between qualification and acquisition, not only failures during deletion. :chatgpt-content-reference{index="6"}

Similarly, the partial-acquisition repair cannot be validated solely with a fake that already returns a perfect partial identity. The audit found that the real worker learns facts before updating the observation it eventually returns. Tests must cover those producer substeps and verify the final residual facets after a second bookkeeping or cleanup failure. :chatgpt-content-reference{index="7"}

These changes remain within the external helper. They do not alter ES custody or grant helper cleanup authority over ES staging.

## Change the completion test, not merely the number of tests

The preceding composed tests were useful but still substituted the very actors that contained the defects: fully populated acquisition observations, a fake terminator, and a precreated publication parent. The audit documents those limitations directly. :chatgpt-content-reference{index="8"}

**The next completion gate is a composed local producer-to-receiver test using the actual orchestration, acquisition, publication, carrier, and verification functions.** Only privileged/kernel effects and the independently supplied test authority are substituted. Directory creation, serialization, publication, receipt delivery, and receiver reads use real task-owned ordinary files.

The positive case begins with only the declared upstream inputs. The same path must then reject pre-cancellation, wrong episodes, replacement roots, incomplete acquisitions, expired signal reentry, failed operational outcomes with matching confirmations, unapproved export trees, and failed receipt delivery.

This is still not privileged Linux execution. Where a Linux-selected function cannot run in the local lane, the record must identify the shared routine actually exercised and the inspected binding to its Linux caller. An AST check remains a source assertion, not a runtime experiment.

The narrowly closed predicates should survive: the original deadline reparse, numeric pidfd retry, absent-association continuation, and PV-01 coordinate binding have independent static closure at their stated scope. The new task preserves those gains while repairing their surrounding interactions. :chatgpt-content-reference{index="9"}

## Keep validation and infrastructure work bounded

After the composed controls pass, the task freezes the successor and runs the external tooling’s local unit/race suites, native and Linux vet, formatting/environment checks, and deterministic supervisor builds. Required coverage comes from the obligations—not a target of 530 passes.

The changed supervisor receives new identities and remains unexecuted. The safe executable is rebuilt locally; identical bytes and selected inputs permit the seven authenticated Linux observations to carry forward without another remote run. Normal and diagnostic proof artifacts remain unchanged compile-only evidence. The current audit supports that evidence-specific reuse, not validation of the changed supervisor. :chatgpt-content-reference{index="10"}

Every new evaluator invocation must have its own externally captured command record, including rejected arguments and preflight failures. The evaluator’s inputs, its output, and the later completed invocation record must be distinguished so that recording evaluation does not create a self-dependency.

The residual policy remains unapproved. Administrative establishment, containment, target/formatter qualification, mounted cases, deployment observation, supported-local proof, the unconditional whole-candidate ES audit, and exact-byte commit authority remain pending. **This repair must neither hide a present interface defect behind those prerequisites nor build those future mechanisms merely to claim completion.** :chatgpt-content-reference{index="11"}

The intended engineering endpoint is:

```text
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIRED_LOCAL_VALIDATION_COMPLETE_REAUDIT_REQUIRED
```

It leads to fresh independent review, not execution authorization.

### Sources, inspection boundary, and confidence

I read the complete attached audit and verified its **26,007 bytes** against SHA-256 `670d4e83…7763a8`. The engineering ZIP, current implementation, specialist originals, and raw streams were not attached here; their detailed authentication and source findings remain **independent-auditor-reported**. The prompt identifies the retained inputs for Codex to inspect before editing. No repository code, tests, host commands, or privileged operations were executed here.

**Sources:** attached cumulative re-audit, its retained-validation assessment, and the preceding engineering report. No external research was used to replace or extend their factual claims.

**Confidence:** **0.98** in withholding progression; **0.91** in this repair handoff. Report-byte provenance is verified. Successor correctness, trusted-entry completeness, privileged readiness, and whole-candidate acceptance remain unestablished.
