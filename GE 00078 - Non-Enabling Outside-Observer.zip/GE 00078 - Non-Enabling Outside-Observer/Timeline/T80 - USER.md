Here is Codex's response:

Completed the contract design. The reduced guarantee is explicit; versioned migration and independent review are required before live adoption.

- [Contract draft](/Users/ds/Downloads/ES-deadline-contract-rebaseline-8vxuelet/DEADLINE_CONTRACT_REBASELINE.md)
- [Migration and acceptance map](/Users/ds/Downloads/ES-deadline-contract-rebaseline-8vxuelet/TEMPORAL_CONTRACT_MIGRATION.json)
- [Verified review package](/Users/ds/Downloads/ES-deadline-contract-rebaseline-8vxuelet/ES_DEADLINE_CONTRACT_REBASELINE_REVIEW.zip)

Repository, accepted source and historical evidence remain unchanged. No implementation, host operation or policy adoption occurred.
