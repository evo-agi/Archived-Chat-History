**This is a real CUST-2 parser defect. Repair the governing grammar and production parser, then revalidate—not the fixtures, evaluator, or host.** Codex correctly stopped ARM64 after the AMD64 package failure. The reported failure occurs before selecting the records relevant to the execution roots, so an unrelated valid mount record can currently disable otherwise valid root qualification. :chatgpt-content-reference{index="0"}

**Send this to the same implementation/repair Codex conversation: :chatgpt-content-reference{index="11"}[Mountinfo repair and integrated revalidation prompt](sandbox:/mnt/data/ES_NSFS_Mountinfo_Repair_and_Revalidation_Prompt.md).**

The handoff combines the bounded repair and validation. It does not require another design-only round or an intermediate relay merely to authorize the already-defined suites.

## The faulty assumption came from our design

The earlier amendment explicitly required **every** mountinfo `root` and `mountpoint` to be absolute and component-clean. The implementation’s reported rejection therefore follows a mistaken design requirement, rather than simply failing to implement the selected design. **I approved that false universal; the correction needs to reach the docs and contract tests as well as the code.** :chatgpt-content-reference{index="1"}

I checked the Linux-specific claim against upstream source. Linux emits the mountinfo root through a filesystem-provided `show_path` callback where one exists. The `nsfs` callback produces a namespace-object label such as `mnt:[4026532502]`, not an absolute directory path. That behavior is present in the inspected upstream v6.8 and v6.17 sources. This corroborates the reported token class; it does not authenticate the exact Ubuntu kernel build or the user’s captured mount table. :chatgpt-content-reference{index="2"}

The distinction we need is:

> **A valid mount record is not necessarily usable as a pathname coordinate for an execution root.**

That is the repair—not making namespace-object labels look like paths.

## Preserve the records; restrict their use

The selected behavior is:

| Where the `nsfs` record participates | Required treatment |
|---|---|
| An otherwise valid record unrelated to either protected root | Parse and retain it without poisoning ordinary root qualification. |
| A mountpoint properly beneath staging or results | Retain it in descendant-mount detection and reject the protected topology. |
| The descriptor-selected record proposed as an execution-root coordinate source | Refuse: an opaque namespace-object label cannot establish directory ancestry. |

This avoids two opposite mistakes. Rejecting the entire snapshot is the current availability defect. **Dropping all `nsfs` records would be an unsafe repair**, because it could remove a descendant mount from the evidence used to protect staging or results.

The prompt therefore requires explicit separation between record integrity, root-value classification, and coordinate-proof eligibility. Ordinary path-valued roots retain their existing checks. The newly recognized non-path class is source-grounded `nsfs` namespace-object roots—not arbitrary unfamiliar strings, and not four hard-coded inode numbers.

Those records must still participate in mount-ID uniqueness, parent/cycle validation, stacking, snapshot budgets, and descendant detection. They must never be passed through a fabricated leading slash, a path join, or a normalization step that manufactures a backing coordinate. Selected opaque roots must fail before effects, including any different-device shortcut.

The existing descriptor binding, canonical-presentation checks, dual-missing refusal, result non-mutation boundaries, and fixed-error/no-Nomad-fallback rules remain unchanged. These are already central requirements of the amended proof; the repair changes the invalid global grammar assumption, not those protections. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

### What the regression must demonstrate

The new tests must exercise the **actual production parser and classifier**. A mixed snapshot should retain a valid opaque record while accepting ordinary disjoint roots. Moving that same record beneath either protected root must produce rejection. Selecting it as a coordinate source must fail explicitly rather than accidentally through some unrelated identity mismatch.

Malformed and unsupported inputs must remain fail-closed. Existing alias, subtree, casefold-model, missing-root, descriptor, and acquisition-count tests remain required. The old requirement that every root token is a path should be replaced explicitly—not preserved through host filtering or bypassed by weakening test assertions.

All **44 previously failing paths and the eight unstarted golden children** must explicitly pass in the applicable successor native runs. A passing parent is not sufficient evidence that its children executed. The current report distinguishes those failures and missing children correctly. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

## Get Linux feedback before another broad local cycle

The important sequencing improvement is a **focused pre-freeze AMD64 development check**.

After the bounded doc/code/test changes and local prechecks, Codex will transfer an authenticated development snapshot to the existing AMD64 environment and exercise the Linux parser regressions plus representative root, retention, and golden paths. That gives this Linux-specific correction native feedback before another complete Darwin validation cycle.

This check is development evidence, not a replacement for the final gate. In-scope corrections may occur before the final freeze, with every attempted snapshot and result retained. No remote source editing, mount creation, service restoration, or ARM64 preparation is authorized.

Once development succeeds, the prompt freezes one successor candidate and runs the existing final sequence:

**Default full suite → physical-temp full suite → admission/app race suite → AMD64 full admission suite → ARM64 full admission suite.**

The downloadable prompt supplies the pinned executables, offline environments, source-derived applicability rules, installed-asset identities, and cleanup boundaries. ARM64 becomes eligible only after the complete final AMD64 gate and closeout succeed.

The previous Darwin passes remain genuine observations of the previous bytes. They cannot establish validation of this successor. Likewise, the failed AMD64 stream remains failed; neither a code repair nor corrected postprocessing can retroactively turn it into a pass. The current source/candidate identities agree across the local-completion and native-failure reports, which supports that historical continuity without changing its meaning. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

Pure analysis defects can still be corrected through a separately versioned evaluator and replay of unchanged evidence. That exception does not permit retrying a failed final suite, changing frozen source, or relaxing coverage.

## Scope stays bounded

The primary implementation surfaces are:

```text
es/admission/execution_roots_linux.go
es/admission/execution_roots_linux_test.go
```

The prompt also authorizes the directly affected governing text and assertions. Common root representation or semantic-inventory files may change only where the actual implementation demonstrates that dependency. It does not reopen the radix implementation, app fixtures, shell-scanner repair, public interfaces, runtime profiles, or deployment configuration.

The source-referenced outstanding gates remain separate. Actual mounted-helper cases still have an execution-definition gap; deployment compatibility remains unobserved; and the report now identifies a concrete owning runbook and command for the bounded supported-local consumer proof. None is satisfied by this parser repair or by ordinary native admission tests. Fresh independent audit and the exact-byte commit gate remain afterward. :chatgpt-content-reference{index="9"}

**Successful completion should say “local and native validated; external gates pending”—not `FINAL_AUDIT_READY` or `COMMIT_READY`.**

## What I could verify from these attachments

I verified the report’s **17,044 bytes and supplied SHA-256**, and the manifest’s **18,904 bytes and supplied SHA-256**. The manifest contains 160 unique, safe relative paths with well-formed size, mode, and digest fields; its report entry matches the attached report. The preceding local report also matches its registered entry.

**That is not authentication of all 160 file bodies.** The review ZIP, current production source, original test stream, and mountinfo diagnostic were not attached. Their reported identities remain inputs for Codex to authenticate before editing. The older source archive cannot substitute for the newly added root-set implementation.

The inspection record and external-source distinction are retained in the :chatgpt-content-reference{index="12"}[failure review notes](sandbox:/mnt/data/ES_NSFS_Failure_Review.md). The new prompt requires the next review ZIP to expose the current repaired source directly, rather than burying it under another chain of historical packets.

**Sources:** attached native report and manifest; retained local report and design amendment; upstream Linux sources cited above. No repository code, tests, host commands, or VM operations were executed here.

**Confidence:** **0.96 in this repair direction and continuation.** Attachment identity is verified; the native attribution is strongly corroborated but remains report-based without its raw records. Whole-candidate implementation correctness and final acceptance remain unestablished.
