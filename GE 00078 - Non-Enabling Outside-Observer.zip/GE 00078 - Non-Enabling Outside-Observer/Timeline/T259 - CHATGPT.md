**Retain the block.** The direct NRC-FRESH-01 and NRC-FRESH-02 repairs remain supported; the new defect is in the **current evidence used to close displaced predecessor predicates**.

Eleven sticky-stop “isolators” were created by moving ordinary admissions earlier than the owner acquisitions or prerequisite results those calls require. That is not a valid way to bypass the sticky-stop gate.

The repair should not treat all eleven alike:

- **Seven** counterparts intended to isolate `INHERITED_C` need new, source-valid derivatives from the current positive. All unrelated ordinary admissions, acquisitions, and prerequisite results must remain valid; only the selected downstream C relationship should be corrupted.
- **Four** counterparts claiming full-reader `CARRIER_VALID_NONPASSING` should be retired. Their coherent known-error meaning already has **component-only state-shape evidence**, while their fixed 41-record full accounts correctly stop at the sticky-failure gate. No new failure-prefix profile is authorized.
- The **five unaffected sticky counterparts** remain at their current evidence scope.
- All eleven old invalid counterparts remain immutable historical inputs and should become admission-premise regression controls.

The successor reader also needs a common admission-time dependency gate: target-owner responsibility, required prior results, and session/peer ownership must exist by the admission check—not merely by later dispatch. C remains an inherited one-use release duty and must not acquire a fresh ordinary-admission prerequisite.

### Repair handoff

ES_R6J_R26_ADMISSION_PREMISE_REPAIR_HANDOFF_20261022_28.zip[Download the R26 admission-premise repair handoff](sandbox:/mnt/data/ES_R6J_R26_ADMISSION_PREMISE_REPAIR_HANDOFF_20261022_28.zip)

:chatgpt-content-reference{index="3"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_R26_ADMISSION_PREMISE_REPAIR_HANDOFF_20261022_28_VERIFICATION.json)

```text
Bytes:             1,070,147
Members:           18
Manifest payloads: 17
SHA-256:           8d490853521e3ee730b5f28b31f40be22a7d2a025c90a38136edb49f5fcf6f5b
Verification:      PASS
```

The package is intentionally compact. It includes the complete blocked review, the exact sixteen-row sticky-isolator analysis, the selected disposition for every affected row, current reader excerpts, and the full owner task. It does not duplicate the 363 MB owner.

## Message to send

Send the handoff to the **same ChatGPT owner conversation that produced R26**, not Codex:

```text
Repair R26-STATIC-01 under NEXT_OWNER_TASK.md. Authenticate the fresh
review and the exact reviewed owner, then inspect the complete current
reader, 393-row register, 180-state table and all sticky counterparts
before authoring.

Add admission-time owner/result prerequisite validation before sticky-stop
or dependent use. Keep C separate.

Preserve all old counterparts as history. Replace only the seven affected
downstream INHERITED_C isolators with source-valid positive-base
derivatives. Retire the four unsupported full-reader nonpassing isolators
and retain their component state evidence plus historical sticky-stop
results. Keep unaffected counterparts at their actual scope.

Save and reopen a substantive checkpoint before broad execution, then
complete the finite rerun, registers, reconstruction and verified
delivery.

Do not reopen the phase or direct NRC decisions, amend the normative pair,
expand general joins, launch Codex, access repositories or hosts, execute
uploaded programs or claim independent acceptance.
```

The intended owner endpoint is:

```text
OWNER_R6J_R26_ADMISSION_PREMISE_ISOLATORS_REPAIRED_REVIEW_REQUIRED
```

A different ChatGPT reviewer should then examine the exact successor. The complete finite rerun remains required because changing admission prerequisite evaluation can affect more than the sixteen named isolators. The original task already required admission to respect every applicable earlier bound and required full-reader regressions to reach their intended predicates rather than stale or wrong gates. NEXT_OWNER_TASK NEXT_OWNER_TASK

**Sources:** uploaded R26 fresh-review package; reassembled exact R26 owner; retained 393-row register, 180-state table, reader source, and review task.

**Confidence:** **0.99** in the blocking diagnosis and artifact identities; **0.96** in the selected evidence-layer repair. Successor-reader correctness and independent acceptance remain unestablished.
