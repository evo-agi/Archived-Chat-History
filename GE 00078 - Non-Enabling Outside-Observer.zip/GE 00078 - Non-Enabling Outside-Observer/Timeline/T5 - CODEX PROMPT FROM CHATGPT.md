ES native Linux fixture repair and revalidation
Objective and authorized sequence
Correct the shared admission-test runtime-support fixture, then validate the repaired candidate locally and natively on the two already-governed Linux environments. This is one bounded repair-and-validation task, not an architecture change or independent audit.
Use one foreground Codex executor and no subagents. You are the sole repository writer during the local repair phase. Proceed through these gates without another routine handoff: authenticate prior evidence and the live baseline -> implement the one-file test repair -> local admission validation -> freeze the new candidate -> AMD64 native validation -> ARM64 native validation only after AMD64 passes -> return evidence and stop. Once the new candidate is frozen, no further repository/source edits are authorized in this task. A native failure ends the attempt after safe evidence return and closeout; do not repair and retry.
Repository: /Users/ds/Repositories/Execution Substrate/.
No staging, commit, push, fetch, branch switch, worktree mutation, final combined audit, deployment, live ES/Nomad/Docker/SPIRE/Vault operation, A6, target audit, reliable-submit wiring, external schema-package work, or other-repository edits. No sudo, package/toolchain installation, dependency download, public-internet access, new VM/container/mount/namespace, tracing installation, host configuration change, or deletion of historical evidence or persistent maintenance assets.
Authorized effects: the single test-file repair below; local Go admission tests; a fresh private evidence directory outside repositories; fresh source packaging and task-local caches; existing governed transports; one normal start/stop of the exact stopped ARM64 instance after AMD64 success; guest-local testing; evidence return; and cleanup only of authenticated objects created by this task. Existing test-local loopback servers are authorized. Do not use writer or audit subagents.
Current diagnosis and boundary
The failed native run reported ES_NATIVE_LINUX_VALIDATION_FAILED_CANDIDATE_REPAIR_REQUIRED: 607 AMD64 test paths ran, 595 passed, 12 failed, none skipped; ARM64 was not started. Those counts include parents/subtests and are not a count of independent defects.
Source corroboration:
- es/admission/workstream_c_guardrails_test.go:5763–5795: newWorkstreamCTestService allocates physical staging/results roots but configures RuntimeSupportBinary: "/bin/sh".
- es/admission/resolved_execution_plan.go:479–486,593–598: Submit captures that source and maps capture failure to the existing fixed public error stage artifact payload failed.
- es/admission/staging_custody.go:1021–1098 and staging_custody_linux.go:7–20: no-follow stable single-link capture and Linux no-symlink opens are intentional.
- PLANS.md:347–349,382–397 and .docs/system_overview/configuration.md:379–387: preserve that bounded security contract and the two-architecture native gate.
- Existing test-owned runtime-support fixtures already exist at service_direct_test.go:70–84, writablestate_readiness_test.go:17–35, and resolved_execution_plan_test.go:632–674.
- staging_custody_test.go:13–35 supplies the physical test-temp helper. Canonicalizing an already allocated test directory is not permission to canonicalize production input paths.
The report attributes the failure to the governed AMD64 host's /bin and /bin/sh symlinks. ChatGPT inspected the supplied source and report, not that host or the raw test stream. Before editing, corroborate the failure against the retained original evidence below. Do not claim source inspection alone proves the native events.
Classifications: fixture = test-harness implementation detail; no-follow capture = current bounded ES security contract; control-plane-normal-shell/v1 = retained compatibility edge; validation reports/manifests = evidence/projection. No reopened architecture seam is being settled.
1. Authenticate the retained evidence and live baseline
Prior failed-run root:
/private/tmp/ES-native-linux-validation-mhwpie03
Prior report:
/private/tmp/ES-native-linux-validation-mhwpie03/report/native-linux-validation-report.md
Retained review ZIP:
/Users/ds/Downloads/ES-native-linux-validation-20261004T2315Z-mhwpie03.zip
- 259237 bytes
- SHA-256 fcb0a00e06687190072049707b9ec2e6520dc20a17190702b925a0d4618c33d1
- per-file manifest SHA-256 236597f780be27fb0266a83f4d53077942c2767d2f48066d21f72ff6bcff2610
Authenticate the ZIP, its retained manifest, and relevant records. Inspect the original AMD64 test JSON, failure output, source/candidate comparisons, path-topology observations, child-environment record, and GOENV adjudication. The original test stream identity is 600289 bytes, SHA-256 c7016df6fb075c51ec46e7dd78be0d3c7f5d6a6c3b19fb208331d93eb1d9eba2. The returned AMD64 registry was 41 files / 13251236 bytes, SHA-256 e539fcb786c54a7fe9c30beaa9a6d1c6d198431aaeef92356b2b95cfc54d19b0. Locate exact filenames from that packet/registry, not guesses. Preserve all originals.
Use non-mutating Git inspection with optional locks disabled. Before editing or contacting either host, require:
- branch trunk_dev, upstream origin/trunk_dev;
- HEAD b92bd9884106154d25342e1573dcc4c312311436;
- tree cdd4e44bac15c1952d70997143040644361f0bb1;
- sole parent 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- locally recorded divergence 1 ahead / 0 behind, without fetch;
- zero staged paths, 64 modified tracked regular files, 11 untracked regular files, no conflicts/active operation, six unchanged worktrees;
- status digest adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93;
- tracked binary diff 2242910 bytes, digest 10442400fe811003e6081afedc0930f9f3a0aa1d25d300a4c632432c0827c226, using the retained exact deterministic recipe;
- complete 352-file source-manifest digest b1d43619d4bd989fdf66e0254d11c8d38c8a05333f83072c2ede24f795bd6a89;
- complete 75-row candidate-manifest digest 7474bf8cd336421b56cf7e0f8b034280d9e01c92f25cb72464a700ba88313678.
The historical manifest/source comparison files also remain under:
/private/tmp/ES-native-linux-validation-56dhnrrs
(source-member-manifest.jsonl, candidate-manifest.txt, archive-authority.json, source-build-A.tar).
The exact opening bytes of the sole editable file are:
es/admission/workstream_c_guardrails_test.go, mode 0644, 239149 bytes,
SHA-256 e77463365f503425f6bb0349349f322d50398fdfa87efcabe583d24f0a2e1a46.
Compare actual paths, types, modes, sizes and bytes, including untracked source. Do not treat matching HEAD/status/counts as sufficient. Snapshot enumeration is git ls-files -co --exclude-standard -z. Preserve the retained serialization recipes. Specifically, the supplied candidate manifest contains sorted M rows followed by sorted ?? rows; do not replace that ordering with a single global path sort. Complete-source JSONL uses sorted paths and the existing kind,mode,path,sha256,size,tracked fields with canonical compact JSON and LF.
If identity/evidence is unavailable, inconsistent, or different, stop with the exact mismatch. Do not reconstruct historical evidence, adopt unrelated work, reset anything, or start environment preparation again.
Read current AGENTS.md, relevant PLANS.md, .docs/system_overview/{configuration,capability_probing,go_toolchain_baseline}.md, relevant lifecycle contracts, and the source/tests identified above. Confirm scope before editing. README and old milestone documents do not override the current plan.
2. Implement the one-file test repair
The only authorized repository edit is:
es/admission/workstream_c_guardrails_test.go.
Change newWorkstreamCTestService to create its own small deterministic runtime-support fixture in a separate test-owned physical temporary directory. Use the existing physicalTestTempDir(t) helper. Configure the service with that absolute path.
Requirements:
- Fresh regular single-link file, deterministic nonempty test-authored bytes, owner-only executable mode (0700), closed before capture. Check fixture-creation errors.
- Keep this source file outside both staging and results roots so early-failure emptiness assertions retain their meaning.
- The admission tests capture/stage this fixture and use fake Nomad clients; they do not thereby execute or qualify a real runtime supervisor. A small inert fixture is sufficient. Confirm the helper's callers do not require native executable semantics before making that choice.
- Do not read/copy a system executable, hard-code /usr/bin/dash, use LookPath, resolve /bin/sh into a host-specific replacement, add GOOS branches, or depend on a host shell's bytes.
- Do not normalize/relax production source paths, change openat2 flags, bypass capture, change public messages, alter literal goldens/token ledgers, skip a test, or change required coverage.
- Do not place fixture output or generated binaries in the repository. Let test-owned fixture cleanup use the existing test lifecycle; this adds no ES production reclamation authority.
- Avoid unrelated formatting or refactoring.
Add a focused behavior regression in this same file, named
TestWorkstreamCRuntimeSupportFixtureIsHermetic.
It must construct the actual shared fixture, verify that its configured runtime-support source is an absolute, regular, single-link test fixture separate from staging/results, and successfully capture exactly the independently specified fixture bytes through the unchanged production capture function. Check its executable/private mode, the expected content digest, and that staging/results remain empty before Submit. Do not derive expected content by simply reading whatever the configured path happens to contain. The test should fail for the old /bin/sh fixture rather than merely restate production validation.
Reuse existing narrow test utilities and standard-library primitives. Existing symlink/ancestry/collision/capture-identity tests remain unchanged; do not create a second filesystem framework or a source-text fingerprint test.
This is a fixture repair under an unchanged contract, not a new contract refinement. No governing-doc/status edit is authorized or needed to redefine behavior. If a genuine contract change, production change, golden change, or second repository file is necessary, stop and report why rather than widening scope.
3. Correct the external environment predicate, without rewriting history
The prior external harness expected go env GOENV to echo off. The report states that the authenticated Go binary instead printed an empty environment-file path while its actual child environment contained GOENV=off.
Reuse the retained native-validation helper in a new private task directory after inspection. Make only the necessary documented environment-output/predicate correction; preserve the old helper and all old raw/derived records unchanged. This is separate from the repository patch and is not permission to alter source/asset manifest serialization.
For this attempt, use go env -json with the explicitly selected keys. Require:
- recorded actual child process environment contains GOENV=off;
- go-env command exits zero;
- parsed JSON contains the GOENV key with empty-string value, consistent with the exact authenticated Go 1.26.5 implementation;
- all other required settings and native identity match.
An empty string alone, a missing key, malformed/truncated output, or an unrecorded child environment is not evidence that the environment file was disabled. Inspect the already-installed authenticated toolchain source's cfg.EnvFile / envcmd.MkEnv behavior; no download or persistent go env -w action.
Retain a few small analysis-only checks of the changed predicate: valid off/empty pair accepted; missing process setting, missing output key, nonempty output filename, nonzero command exit and malformed output rejected. Re-adjudicating preserved evidence must leave the old suite failure a failure. Do not rerun the old candidate to repair a reporting boolean, and do not turn this into a harness redesign.
4. Local validation and freeze
Resolve the existing local Go executable from the recorded local environment and verify exact Go 1.26.5. No installation/download or shell-startup change. Use the current cached modules with process-only GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, CGO_ENABLED=0, and GOTELEMETRY=off. Keep build/Go-work caches outside the repository. Do not replace the normal host TMPDIR with /private/tmp to mask fixture portability.
Format only the touched test file with the existing gofmt, then run from the repository root:
"$LOCAL_GO" version
"$LOCAL_GO" test -json ./es/admission -count=1
git -c core.fsmonitor=false diff --check
LOCAL_GO must be the authenticated absolute executable path, not a guessed installation. Capture exact argv, selected safe environment, cwd, exit, stdout and stderr. Do not dump secrets or the full inherited environment. Require the new regression and the formerly failing submit/golden paths to execute and pass. The local admission suite is a regression gate, not Linux evidence.
Local corrections may address only this fixture/regression implementation before the freeze. Preserve failures and explain corrections; no unrelated repair or pass-by-retry without a change. Stop on a failure needing broader scope.
After local success, compare against opening:
- only the authorized file's bytes may differ; it remains a tracked regular 0644 file;
- every other 351 source files and all existing untracked files match exactly;
- HEAD, branch, index, path classifications, complete path set and six worktrees are preserved;
- the candidate remains 64 modified + 11 untracked paths; new content means NEW source, candidate and tracked-diff digests.
Retain the complete one-file before/after repair diff separately from the complete integration diff. Produce the new full 352-row source manifest and 75-row candidate manifest twice, requiring byte-identical repeated outputs under the retained recipes. Retain exact recipe sources and their digests. Existing opening digests are comparison inputs only, never the new target digests.
Create a fresh deterministic source archive twice from the repaired live source: safe sorted repo-relative regular members, recorded modes, zero uid/gid/mtime, empty owner/group names. Builds must be byte-identical and all members must match the new manifest. No .git, ignored/private files, databases, caches, or unrelated artifacts. Preserve classified tracked example archive fixtures; do not exclude legitimate tracked source by suffix. Recheck source after packaging.
Freeze these new exact bytes before either Linux contact. This is the sole candidate for both native suites. No further repository/extracted-source edit, partial-archive replacement, or rebaseline is allowed in this task.
A new full-repository suite and race run are not part of this localized test-only repair; report them as not rerun rather than inheriting earlier results for the new bytes. They remain available to the later final audit's validation plan.
5. Native revalidation of the frozen candidate
Run AMD64 first. An AMD64 blocker/failure ends this attempt; leave ARM64 stopped. After AMD64 passes and evidence/preservation checks close successfully, start ARM64 normally once and validate the same frozen source. Do not merge results from different candidate digests.
Environment records:
/private/tmp/ES-native-linux-environment-readiness-completion-2sprt3mv/report/
- native-validation-environment-readiness-v2.json
- amd64-readiness-v2.json
- arm64-readiness-v2.json
- evidence-registry-v2.json
- persistent-maintenance-assets.txt
Authenticate relevant retained inputs against their registry. Reuse the installed assets; no new readiness/maintenance project. The recorded portable manifest recipe is the read-only portion of validation/install_and_probe.py, SHA-256 32cc8a2137f3b55e7dfe8405b93a3e7f5abe9c59461f54d6cb1985eafc8fe88e. The last native task retained its verification-only helper. Inspect/reuse those exact manifest semantics without importing or executing installation orchestration.
Field	AMD64	ARM64
Transport	existing SSH alias host_to_remote_linux_m75q	existing Lima instance es-lima-qemu-arm64
Native identity	x86_64 / dpkg amd64	aarch64 / dpkg arm64 / QEMU
Hostname	ds-ThinkCentre-M75q-Gen-2	lima-es-lima-qemu-arm64
UID/GID	1000/1000	501/1000
OS/kernel	Ubuntu 24.04.4 LTS / 6.17.0-23-generic	Ubuntu 24.04.4 LTS / 6.8.0-124-generic
Go root	/home/ds/.local/share/execution-substrate/native-validation/go1.26.5-linux-amd64	/home/ds.guest/.local/share/execution-substrate/native-validation/go1.26.5-linux-arm64
Module cache	/home/ds/.cache/execution-substrate/native-validation/modcache-dac662ea3274	/home/ds.guest/.cache/execution-substrate/native-validation/modcache-dac662ea3274


Machine-ID SHA-256:
- AMD64 a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6
- ARM64 36bcc652dc9e61ce61f7e19d839901c23db072c373355ac5f465226316171e6f
Portable installed-asset manifest digests:
- AMD64 Go: 5288dc5d51a05d539f02b9fb2cf7978deb995116f0adde7e628172212bdcbefa
- ARM64 Go: 3dd575df51039882df33ad80ef464986474f7df69676109d186e8507423ce625
- each module cache: 38d54157c700b13347d114af010cb204124ca65da5eb69c43411dddd0ebb7b02
Use existing transport configuration and host-key verification without bypass. Stop on unexpected identity/config drift. Recompute installed-asset manifests before and after tests, preserving exact recipe semantics. ARM64's older closing_read_only_reverification=false fields remain historical; they neither prove current identity nor justify a reinstall.
ARM64 must initially be Stopped with config SHA-256
1579f5a94c7c159ab8441e26c679cde65fd3a054e68ea47165cbfddb5662ecd0.
Start only this instance, normally once, after AMD64 success. No config edit, restart loop, new repository share, or test execution against host-mounted source. Preserve its default Ubuntu Go; invoke only the versioned toolchain above.
Each architecture gets a fresh physical private 0700 task root with recorded ownership/device/inode and separate source, build cache, Go-work temp, test-temp and log directories. Authenticate the archive before safe extraction and compare every source/member/candidate row before execution. Transfer files into native guest/host-local storage, not a mounted Mac checkout.
Use the explicit installed binary and process-only environment:
GOROOT and GOMODCACHE as above;
task-local GOCACHE, GOTMPDIR, physical TMPDIR;
GOTOOLCHAIN=local GOENV=off GOWORK=off GOPROXY=off GOSUMDB=off;
empty GOPRIVATE, GONOPROXY, GONOSUMDB;
GOFLAGS=-mod=readonly CGO_ENABLED=0 GOTELEMETRY=off.
Unset OUTER GOOS/GOARCH, record effective native values, and prepend the versioned Go bin to process PATH only.
From the extracted source root, capture these exact commands with their actual exit status, without a pipeline masking failure:
"$GOROOT/bin/go" version
"$GOROOT/bin/go" env -json GOOS GOARCH GOVERSION GOROOT GOMODCACHE GOCACHE GOTMPDIR GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS CGO_ENABLED
"$GOROOT/bin/go" mod verify
"$GOROOT/bin/go" list -m all
"$GOROOT/bin/go" test -json ./es/admission -count=1
Validate environment/module gates before starting the suite. Each architecture gets exactly one complete native admission-suite invocation for the frozen candidate. No filtered replacement, test skip, new timeout, retry, assertion change, or fallback toolchain. The existing admission guard's cross-target offline go list children remain authorized structural checks, not native evidence for their other targets.
Before running, preserve the previous 69 required test paths and extend the inventory with ALL previously failing paths, their relevant descendants, and the new fixture regression. Use the retained raw inventory and current unchanged test definitions, not the previous aggregate counts. Require explicit passing events for all original staging-custody tests/subtests, result/capture/retention tests and literal goldens, plus:
- TestWorkstreamCRuntimeSupportFixtureIsHermetic;
- all 12 prior failed JSON paths, including platform_owner and trust_capture;
- all eight previously unexecuted control-plane golden negative controls (wrong_job_* and wrong_handoff_*);
- TestRuntimeSupportMaterialIdentityMatchesCapturedBytes.
In particular preserve:
TestLinuxStagingCustodyUsesOpenat2AndRenameat2,
TestLinuxStagingCustodyRejectsMountCrossing,
the stable local capture/ancestor-replacement tests, pre-freeze non-effect tests, ambiguous Nomad failure retention, and both runtime-profile literal goldens.
The procfs crossing test uses the existing / -> /proc topology and expects EXDEV. Observe that topology read-only; create no mount or namespace. Missing capability/topology is an environment blocker, not a reason to skip/replace the test.
Require a complete well-formed JSON stream, zero failing paths, package terminal pass, and explicit pass (not missing/skip) for every required path. Record all other skips separately. Do not count absence of a skip event as proof that a subtest ran. Do not hard-code the old total of 607: successful parents and the new regression change the executed inventory.
Retain an evidence map to the unchanged production custody/capture/materialization boundaries. Label native tests as bounded source-bound evidence, not syscall tracing or proof of every flag/descriptor-close path. Earlier AMD64 custody passes remain historical and are not reused as acceptance of the repaired candidate.
6. Preservation, closeout, and report
After each native suite, compare extracted source to the frozen manifest and persistent assets to their opening manifests. Return evidence and authenticate returned files by size/digest before removing a task root. Close task-owned processes; remove only the authenticated task-created remote root when safe, then observe absence twice. If safe cleanup cannot be established, preserve and report the exact residual root. Do not remove retained ES production roots or any persistent maintenance asset.
If this task started ARM64, stop it normally once after evidence return and closeout; require two stopped observations and unchanged config. If AMD64 failed, verify ARM64's local stopped/config posture without starting/contacting the guest.
At final local closeout, require the frozen new source/candidate/diff bytes unchanged, unchanged index/HEAD/branch/worktrees, no extra path, and no repository-local build/evidence residue. The opening-to-closing difference is exactly the authorized test repair; the post-freeze-to-closing difference is zero.
Choose one primary verdict:
- ES_NATIVE_LINUX_FIXTURE_REPAIRED_AMD64_ARM64_VALIDATED_FINAL_AUDIT_READY: the one-file repair, local admission gate, both complete native gates, required coverage, evidence and preservation all pass.
- ES_NATIVE_LINUX_FIXTURE_REPAIR_LOCAL_VALIDATION_FAILED: the bounded repair/local gate cannot complete; no host contact.
- ES_NATIVE_LINUX_REPAIRED_CANDIDATE_VALIDATION_FAILED: a frozen repaired candidate fails on an adequate native environment; do not repair/retry.
- ES_NATIVE_LINUX_REVALIDATION_ENVIRONMENT_BLOCKED: identity/capability/toolchain/cache/transport prevents validation; no installation or maintenance.
- ES_NATIVE_LINUX_REPAIR_PROVENANCE_MISMATCH: evidence/source/transfer/frozen-byte mismatch or an unauthorized effect prevents acceptance.
- ES_NATIVE_LINUX_FIXTURE_REPAIR_SCOPE_BLOCKED: source/evidence requires a change beyond this one-file test repair.
State partial progress and unexecuted phases explicitly; never substitute a success verdict for a partial pass.
Return a concise self-contained report: actual touched file and exact repair; source-based failure attribution; opening/new/closing provenance and recipe identities; exact commands/exits/results; all failures/skips/missing work; old-to-new required-test coverage; GOENV requested-vs-observed evidence and helper delta; native candidate identities; asset/source preservation; cleanup; ARM64 posture; uncertainty/uninspected scope; full-suite/race validation not rerun; and explicit no-production-change/no-audit/no-stage/no-commit/no-push confirmations.
Retain a compact review ZIP in /Users/ds/Downloads/ containing the report, the exact repaired test file, the one-file repair diff, before/after source and candidate manifests, complete-integration diff digest (not unnecessary full diff bytes), exact safe recipe/helper sources and their change record, local/native test JSON and stderr, required-test inventory/results, safe environment/asset/source comparison records, and a simple per-file size/SHA-256 manifest. Include original failing test evidence once or bind it explicitly to the retained prior packet; do not relabel old evidence as new.
Exclude secrets, credentials, full inherited environment, private SSH/Lima configuration, raw host logs, caches, toolchains, test binaries, VM disks and databases. Distinguish safe excerpts from original raw records. No circular/self-hashing registry or new schema package.
Return the packet's exact path, size, SHA-256 and manifest digest. Do not perform the final independent audit or any commit/publication effect. Successful completion supplies the repaired candidate for a separate fresh read-only final combined audit.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
