Here is Codex's response:

Executed. The corrected outcome is:

`ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDED_TOPOLOGY_OBSERVATION_REQUIRED`

Key results:

- CUST-2 now uses held-descriptor canonical presentation plus `statx`-selected mount records, closing the case-folded bind ancestry hole.
- Unobserved path suffixes remain explicit intent and fail closed when lookup equivalence cannot be proven.
- Pinned Go limits were confirmed: maximum reachable PAX path is 1,048,562 bytes; GNU is 1,048,575 bytes.
- The 32,768-header EOF-terminated 16 MiB boundary was confirmed.
- The standalone probe exited 0 with empty stderr.
- Repository source, candidate, status, diff, refs, and worktrees remained byte-identical.
- No repository code or documentation was changed.

Artifacts:

- [Design amendment](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDMENT.md)
- [Corrected complete matrix](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/touched-surface-acceptance-matrix.corrected.json)
- [Tar feasibility table](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/tar-feasibility-table.md)
- [Probe source](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/probe-work/tar-shape-probe.go)
- [Raw probe results](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/probe-work/probe.stdout.jsonl)
- [Opening/closing preservation record](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/opening-closing-byte-preservation.json)
- [Artifact manifest](/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/ARTIFACT-MANIFEST.tsv)

The remaining pre-implementation gate is a read-only observation of one concrete, currently running, in-scope ES mount namespace. Launcher source and historical Remote Alpha evidence do not establish that live topology.
