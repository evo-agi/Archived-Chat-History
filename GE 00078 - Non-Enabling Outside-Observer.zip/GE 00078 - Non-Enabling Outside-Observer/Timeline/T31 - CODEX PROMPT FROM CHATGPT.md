ES mounted-helper proof v2 — repair the external execution tooling, not the ES candidate
Objective and decision
Return to the implementation/preparation Codex conversation. You are the sole external-artifact writer; this is not the independent auditor's conversation and not an independent audit.
Produce one coherent, reviewable v2 successor for the rejected mounted-helper proof. Address every finding F-1 through F-16 in the authenticated pre-execution audit. Preserve the eleven selected real mounted cases and the unchanged ES implementation. Deliver implemented external tooling, an exact future execution specification, nonprivileged engineering controls, compile-only Linux artifacts, and a source-referenced closure matrix. Stop before root, host, or mounted execution.
The engineering decision for this successor is one explicit task-scoped resource-ownership model, not sixteen disconnected additions to shell traps. Use a small compiled lifecycle owner for the operations that require held descriptor/process/loop custody. Thin fixed-command adapters may remain where justified; shell scripts must not remain the sole owner of an association or the sole recovery mechanism. This is a replacement of external proof implementation, not a new ES service, generic privileged framework, or change to product governance.
The accepted operating model for authoring is:
- A bounded host-side supervisor owns authenticated input custody, the private evidence/control state, the image/loop association, the namespace-worker lifetime, deadlines, and final export/closeout decisions.
- A namespace worker owns mount construction, in-namespace observations, and reverse unmounts. Its namespace identity and descriptors are explicitly related to the supervisor and recovery path. There is exactly one mutable owner for each fact; handoffs are recorded and acknowledged.
- Each case runs in a separate unprivileged candidate process, with the complete declared credential/capability projection checked inside that process. It receives only synthetic test data and required read-only inputs; it receives no privileged control descriptors or cleanup authority.
- An adjudicator interprets bounded case evidence against an independently fixed case manifest. It cannot turn an incomplete run or uncertain cleanup into success.
- The ledger records intent, acquisition, observation and disposition. It is evidence and recovery context, not a substitute for kernel objects, continuously held custody, or authorization.
Write the concrete owner/state/effect table first in this new external root, then implement it in this same task. No extra design-only handoff is needed for choices within this model. If a substantive proof/authority decision cannot be implemented within the constraints below, finish with the precise unresolved seam and blocked status; do not silently introduce a different host, VM, filesystem, privilege boundary, or production change.
1. Effect authority for THIS task
Authorized only on the Mac, outside every repository and historical evidence root:
- Read and authenticate the specified existing artifacts and current source; perform narrowly scoped local read-only Git/provenance comparisons using the already inspected serializer semantics.
- Create a new uniquely named owner-only output directory under /Users/ds/Downloads; author the successor external driver, supervisor, adapters, adjudicator, tests, manifests and documentation there.
- Use the existing pinned local Go toolchain and already-present module material, offline, to compile external helpers and the Linux/AMD64 proof source union. No downloaded/new dependency is authorized.
- Execute ordinary-user, external-only unit/negative/fault-injection controls after inspecting their effect paths. These may use bounded task-owned ordinary files and owned harmless child processes, but must not invoke real mount/loop/privilege/namespace adapters. Exercise the actual portable lifecycle/adjudication code with a substituted effect adapter, not a second model of the desired implementation.
- Run syntax/type/format/compile checks on new external source. Compile a Linux artifact; do not execute that artifact or the ES proof test binary.
- Clean up only newly created, authenticated ordinary-user scratch after owned processes close; preserve failed development evidence and final review artifacts.
NOT authorized:
- Any edit, formatting, test, build, patch, staging or status update inside /Users/ds/Repositories/Execution Substrate, including PLANS.md; any edit of the original 358 files in the disposable proof source union; any other repository change.
- Re-execution of ES local/full/race/native suites, the eleven mounted cases, repository scripts (including help), or old/new privileged scripts, even in a purported dry-run that reaches live adapters.
- SSH or any remote acquisition/transfer; Linux host contact; sudo or root execution; namespace/loop/mount/format/capability/UID operations; VM, Docker, service or workload operations; installs/downloads, package updates, group/sudoers/AppArmor/sysctl changes, or new persistent access.
- Any cleanup or repair of historical artifacts, including caches classified out of band.
- Any audit acceptance, execution authorization, stage/commit/push/fetch/PR/merge/deployment action.
Preparation commands and future commands must be separate machine-readable lists. Executable material describing future root work is an output, not permission to run it. No audit subagents or concurrent writers. Do not automatically convert engineering self-review into independent acceptance.
2. Authenticate the exact report, rejected tooling, and preserved candidate
Read the actual sources, not only these summaries. Use current owning guidance in order: AGENTS.md, relevant PLANS.md, configuration/capability and execution-lifecycle docs, current source/tests. The audit's path/line references are entry points; verify current locations.
Audit root:
/Users/ds/Downloads/ES-mounted-helper-preexecution-audit-2tHGL4BU
- packet/ES_MOUNTED_HELPER_PREEXECUTION_AUDIT_REPORT.md: attached copy is 33,252 bytes, SHA-256 03eecb213038cd0b38064c126781172befd1327d8fc77314765b04c0542e4116; require agreement with the retained manifest.
- ES_MOUNTED_HELPER_PREEXECUTION_AUDIT.zip: SHA-256 32ed49aa87407e256dd77891122b9250d55e09bd75d9a9f22824b5158d0e1b28.
- packet/MANIFEST.tsv: SHA-256 4b2ae3229eb5f44a64d4bc65b47e3e8eca5e2ec6e577512b375be01b45fe04f1.
- Read both specialist reports and the exact reviewed-artifacts/ and source-excerpts/ inputs. Preserve the reported F-12 disagreement.
Rejected preparation root:
/Users/ds/Downloads/ES-mounted-helper-proof-preparation-nFVwkJ
- Review ZIP: review/ES_MOUNTED_HELPER_PROOF_PREPARATION_REVIEW.zip, SHA-256 2ab1d48f478712953b415204f397a984eacbc5ff7cb97961486ec5cf532e939c.
- Root manifest: 439 rows, SHA-256 237ead1ac6c8ba931a7326c24aa90681847108274a5c2d3f6781e635758beca4.
- Driver: driver/es_mounted_helper_proof_v1_linux_test.go, 32,094 bytes, SHA-256 b60be787470d191895efc9b6d0a9a25ed2e8d0a0206c6cfae6a403e5ec512a6b.
- Launcher: recipes/fixture_launcher_v1.sh, 20,072 bytes, SHA-256 f4e319654d2bf509f90c05c2d2c710014590c3016182c37ba65c3f5b10faaa1d.
- Cleanup: recipes/fixture_cleanup_v1.sh, 5,071 bytes, SHA-256 763bd9ddc34c8e6aa29448259e71168ca5f64f7550348b5e37d437d6d5cb1fe3.
- Old source union: 359 rows, SHA-256 9e7a3b4c028093d304a8cab41223ff449f9375b5aa701c77b7cf3a6cc6f8b854.
- Old ELF, located through build/records/binary-identity.json: 23,552,153 bytes, SHA-256 e8b798ecfbf79089281728811a9cf905d5d1d68bd2acc3b163b118596f5cb813; data-only historical compile evidence, not the executable for a changed driver.
Preserved ES validation root:
/Users/ds/Downloads/ES-cust2-nsfs-assurance-validation-kgthnJ
Binding	Required identity
Repository	/Users/ds/Repositories/Execution Substrate
Branch/upstream	trunk_dev / origin/trunk_dev
HEAD	b92bd9884106154d25342e1573dcc4c312311436
Tree	cdd4e44bac15c1952d70997143040644361f0bb1
Source manifest	358 rows / 67,617 bytes / e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e
Candidate manifest	83 rows / 10,037 bytes / 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2
Source archive	final-snapshot/source-build-A.tar, 7,485,440 bytes / 12a8b8a626911d51dedf1b138b88deb314aff00d0de6ec063c96ac53d6146202
Archive-member manifest	358 rows / 79,414 bytes / 3e0195237c1b89fcb15242b886e17735c47d54b6710dd7ca8dafc1f6f63d4e5e
ES required inventory	327 rows / 141,680 bytes / 8b3ed6e32ba809bda751632292773c9adc28096691ad9307be32affa288515eb
Tracked diff	2,407,274 bytes / 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1
Complete integration diff	2,746,480 bytes / 38de7ecbcbb52252104710ddb6075a205a9c8a571590d96ed93247ba5a5501e0
Staged/conflicted/active operation	none
Worktrees	six, compare exact retained topology


Authenticate each necessary current input once, with unique safe path coverage and actual bytes, not counts alone. Do not recursively rebuild every historical evidence generation or create a new ES source snapshot. Extract the existing archive safely into new external scratch and verify all members against it.
The audit disclosed two app-owned refs/codex/turn-diffs/... name replacements pointing to the same object while HEAD, branches, remote refs and semantic objects stayed unchanged. Read that exact record. It is not a blanket exemption for ref drift: disclose any new changes, require stable meaningful repository identity, never normalize/mutate refs, and stop on unexplained target changes. Classify out-of-band .pyc/OS metadata without executing, deleting or absorbing it.
Retained source-bound local/native passes remain historical validation of the SAME ES bytes, not validation of your replacement supervisor. There is no reason to repeat those suites for an external-only change.
3. Preserve the fixture's scope; implement one ownership chain
Future target remains host_to_remote_linux_m75q, ordinary account ds, anticipated UID:GID 1000:1000, expected machine-ID SHA-256 a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6. This is a future selector, not permission to contact it or claim current capabilities. Historical kernel/tools are support observations only.
Retain one fresh 64 MiB image, one newly owned loop association, one new private mount namespace, and the eleven cases represented by the selected 23 mounts (one ext4 plus 22 fixed binds). Do not change the effect envelope merely to simplify a repair. Fixed relative leaves or layout beneath the task bases may change to correct permission/custody defects; enumerate every changed path in the successor. No pre-existing base may be chmod/chown-normalized. No live ES, repository, home, secrets, deployment staging/results, or host security tree may become a fixture source.
The intended future bases remain scoped beneath /var/tmp/es-mounted-helper-proof-v1 and /var/lib/es-mounted-helper-proof-v1, unless a concrete safe-layout issue requires a differently versioned task-only basename. A basename change is external tooling, not product architecture; document it exactly. Every existing component is checked before any effect, and unexpected objects block instead of being repaired. The recipe must distinguish newly created run objects from pre-existing verified ancestors and state which harmless parents, installed inputs and evidence persist afterward.
No general command plugin, arbitrary mount specification, arbitrary root path, policy engine, daemon, installer service, or orchestration API. The helper is finite and one-shot. Root/transport loss cannot imply success or authorize unrestricted recovery. The threat model must distinguish mutable ordinary-user intake and candidate-writable synthetic data from trusted privileged actors; do not claim protection against a hostile concurrently authorized root or automatic observed cleanup after all observers die.
4. Required repairs and their acceptance evidence
Maintain individual F-1…F-16 rows; the groups below are integration order, not consolidation that loses findings.
A. Executable permission topology and object custody — F-1, F-3, F-4, F-5, F-9, F-10
1. F-1: distinguish private control paths from traversable test paths. Define the owner, mode, required search/read/write/execute access, and creator for every ancestor of the binary, backing source and visible case root, not just leaves. Root-owned ancestry needed by UID 1000 may grant narrowly necessary search access while remaining non-writable. Keep input mutation, ledger, image control and privileged evidence root-only. Create all synthetic intermediate components explicitly; never rely on mkdir -p plus a leaf chmod under inherited umask. Bind the binary's executable mount/path attributes and candidate CWD as well as mode bits. A modeled permission checker must reject the exact v1 0700 ancestry and intermediate-parent failures. Label modeled permission checks as models until observed on the future host.
2. F-3: held-object import and installation. Define an independently trusted privileged entry. Acquire only the exact allowlisted ordinary-user input objects with no-follow component/leaf handling, type/owner/link/size checks and held identity. Import into a newly created root-private, non-executable quarantine; validate the exact copied/held bytes before allowing executable publication. Concurrent input mutation, source replacement, symlinks, nonregular or multiply linked objects, short reads, post-copy digest mismatch and destination pre-existence must reject without disclosure or execution. Install exclusively/atomically from those same authenticated objects. The externally approved manifest must bind supervisor/bootstrap/driver/cleanup/adjudicator bytes as applicable; the running program must not choose its own expected digest or accept caller-selected hashes as authorization. Bootstrap trust must not be circular: a newly authored unverified importer cannot establish its own initial authority.
3. F-4: define the first privileged executable and every exec boundary. Specify the trusted privilege gateway/interpreter or statically linked entry, fixed invocation, environment before loader/interpreter startup, CWD, stdin and explicit FD allowlist. Clearing variables after Bash or another privileged interpreter has already started is insufficient. Root outer, namespace worker, utility, recovery/export and candidate contexts each need their own fixed environment/FD/command-resolution contract. Prefer direct fixed argv and syscall operations; no unqualified chmod or other command, shell expansion of control input, sourced user files, inherited startup hooks, caller-controlled PATH or uncontrolled import paths. No environment dump. Trusted bootstrap/gateway availability may remain an explicit runtime precondition, not a fabricated installed capability.
4. F-5: existing objects are not this task's repair scope. No-follow inspect ancestors before create/open/use. Exclusive creation must fail on unexpected existence, type, owner, mode or identity. Do not apply install -d, chmod/chown, recursive cleanup, or automatic adoption to an existing base. Descriptor-relative operations must stay beneath the proven run/control objects; a pathname prefix alone is not ownership proof.
5. F-9: verify the complete candidate identity. Under the candidate process, observe real/effective/saved/fs UID and GID, supplementary groups, effective/permitted/inheritable/bounding/ambient capability sets, no-new-privs and the selected securebits policy. State the expected securebits mask and meaning explicitly rather than assuming all bits should be zero. Verify the privilege-transition order and parent-death behavior across credential changes from authoritative API/tool semantics. Record only allowlisted projections. Enforce the declared identity or fail capability setup; do not reduce the declaration to match whatever ran.
6. F-10: transitive commands are part of the envelope. Use fixed internal mount/unmount operations or authenticated internal-only tool invocations. No implicit filesystem helper resolution, fstab processing, or host-dependent helper discovery. Every formatter, attribute utility, interpreter and shared-loader dependency selected must have a concrete trust/identity treatment. Missing tools are a future blocked precondition, not installation authority.
B. Resource transactions, lifecycle and honest closeout — F-2, F-6, F-7, F-11, F-15, F-16
7. F-2/F-7: no unowned loop interval. Persist a cleanup-capable pending acquisition record BEFORE the effect, identifying the exclusive backing file held by the owner. Prefer the bounded Linux LOOP_CONFIGURE API to associate a held image and set LO_FLAGS_AUTOCLEAR in the same configuration operation; do not use a successful LOOP_SET_FD followed by a later status update as though the gap were closed. Hold the necessary device/image custody until the worker, candidate, mounts and references are accounted for. An available loop number is a candidate for acquisition, not a lock. Do not silently reuse an existing association via --nooverlap.
   Verify the owned block device identity, backing file device/inode, size, offset, size limit, relevant flags and effective autoclear state from the actual kernel interface. Explicitly state how ownership survives each handoff. Do not invent a kernel association-generation token: continuous custody, fresh backing identity and bounded no-conflicting-privileged-actor assumptions must carry the argument. Lost custody or ambiguous reuse remains uncertainty; a /dev/loopN name or backing path is insufficient for detach authority.
   Autoclear is a last-reference mechanism, not a cleanup receipt. Identify every retained FD, mount and namespace reference that can delay release, including the supervisor's own. Record effect success/failure before the next fallible bookkeeping step. If a post-effect observation or ledger write fails, a pending state plus owned handles must still permit safe recovery or an explicit unresolved record.
8. Mount acquisition has the same transaction obligation. Every intended mount has a pre-effect fixed target/source identity record and a post-effect mount-ID/context observation. A successful mount followed by a failed ledger append cannot disappear from cleanup's resource inventory. Only the owning namespace and exact task subtree are eligible for inventory/recovery. Keep private propagation validation before the first mount and reverse ordinary unmount order. No lazy/forced unmount, detach-all, global kill, broad path scans, or mount-table filtering to hide residue.
9. F-6: supervise children rather than relying on traps. Define exact processes, parent/child relationships, stable PID/handle and process-group ownership, namespace descriptors, signal forwarding, bounded grace/escalation, wait/reap and descriptor close order. Enforce an independent supervisor deadline for setup, each case, cleanup and export. Treat SSH/transport loss independently from child completion. Candidate termination must be observed before destructive cleanup. A worker or supervisor crash must not leave an invented clean result. Specify which remaining owner can recover using authenticated handles/state and which simultaneous-loss cases require separately authorized later inspection. No trap, Pdeath setting, process-group ID or watchdog name alone proves this; show mechanism and failure transitions.
10. F-11: acquisition failure is not absence. Every mount/loop/process/reference inventory has separate acquisition, parse and adjudication results. Only a successful, complete bounded inventory can support absence. Empty stdout paired with a nonzero tool result, inaccessible /proc, malformed data, truncation, timeout or partial reads is uncertainty. No recursive deletion or clean declaration follows uncertainty. Image unlink is forbidden until the relevant association/reference absence has been established; a failed query must preserve the object and evidence.
11. F-15: preserve both failures and partial evidence. Preserve primary test/setup status before cleanup, and record cleanup and evidence-export results independently. Use monotonic, bounded private state sufficient to retain each partial acquisition before deletion. A cleanup error must not overwrite the primary error with an unexplained exit 97. Specify a root-mediated export that materializes only allowlisted regular evidence with exact modes/sizes/digests into a new nonprivileged destination, without recursive chown of private evidence, symlink following, raw secrets or caller-defined source paths. Retain the private original and distinguish no runtime resources from retained evidence. Failed export never upgrades execution/cleanup or causes deletion of the only evidence.
12. F-16: enforce resource ceilings. The 64 MiB image and prior 256 MiB scratch/16 MiB evidence limits are maxima for their stated scopes, not printed budgets. Specify enforcement for file/log sizes, aggregate evidence/scratch, CPU, memory/address-space, processes, FDs and core output, accounting for prebuilt binary/input storage separately and explicitly. Check limits are compatible with the compiled Go binary rather than selecting an arbitrary address-space cap. Enforce bounded capture and an external deadline with termination/reaping; overflow or evidence truncation blocks. State whether a limit is OS-enforced or application-enforced and its exact scope. Do not claim cgroup isolation without a separately permitted cgroup effect; adding such an effect is outside the current envelope.
C. Evidence that distinguishes the intended behavior — F-8, F-12, F-13, F-14
13. F-8: zero exit plus complete valid event, not zero exit alone. For each fixed case require exactly one complete bounded ES_MOUNTED_PROOF_EVENT or explicitly versioned successor event, plus the expected Go test start/terminal and process exit. Validate schema/version, candidate/driver/run binding, unique case ID, expected accept/refuse, fixture and capability states, actual candidate-call/effect observations, test_failed=false, required fields/types, and zero provider calls where required. Reject duplicate keys, unknown ambiguous fields, wrong case/run/binary, omitted/duplicated/malformed/truncated/oversized event, incomplete stage, unexpected outcome, missing test, skip, timeout, signaled child or nonzero exit. Event write/flush failure must be a real failure. Adjudication must be outside candidate trust for overall resource/cleanup claims. Eleven zero exits are not sufficient.
14. F-12: distinguish the retained-read/public-result refusal cause. Preserve the auditor's disagreement: exact-source control order supports the intended refusal, but the parent audit still found the generic codeResultUnavailable observation non-discriminating. Do not waive it silently. Use an existing safe private diagnostic, discriminating fixture/observation, or explicitly source-bound compiler instrumentation to connect each actual read/public-result invocation to the intended topology-refusal path. A separate prior direct qualification is not independent proof of the later call's cause. Do not weaken the production public error, add a production hook/export, patch source, stub the classifier, or use go:linkname.
   If supplementary toolchain-generated coverage/branch evidence is needed, keep all original source bytes intact, identify the instrumented binary/build and exactly what it can demonstrate, and distinguish that evidence from the normal proof binary. Implement and compile the mechanism now, but claim no runtime observation before the authorized run. If the required distinction cannot be provided inside this external-only scope, leave F-12 explicitly unresolved and report the precise missing mechanism; do not solve it by changing product bytes or overstating static evidence.
15. F-13: independently specified sentinel state. The fixed case manifest must specify expected names, contents or literal hashes, types, modes, owner relationships and artifact absence before candidate action. Do not derive expected values from the same observed tree. Verify real backing/alias/casefold relations independently of the ES classifier, then validate the constructed tree against those fixed expectations and take bounded per-node before/after observations (preserve the 128-entry/1 MiB bound unless a smaller explicit bound suffices). A stable missing or wrong sentinel must fail. Use discriminating metadata/content so attempted reconciliation cannot be excused by an initially convenient fixture. State which observations prove post-state equality versus stronger source-control-flow no-effect claims; no claim of detecting all transient/idempotent operations from equality alone.
16. F-14: correct evidence labels, not product wiring. Label Service.reconcileRetainedResultArtifacts as direct package-local helper coverage because the reviewed source has no non-test production caller. Preserve its useful coverage, but do not wire a production caller to make the label true. Retention, retained read and public Result have their own production-reachability evidence. Positive cases exercise actual provisioning/owner/reobservation primitives, not an end-to-end NewService/Submit deployment. Update every matrix, event, report and call map consistently.
5. Fixed eleven-case manifest
Preserve these identities or provide an explicit one-to-one versioned rename; do not drop cases:
Case	Required outcome
ordinary-disjoint-roots-accept	accept
disjoint-sibling-binds-accept	accept
same-object-binds-reject	refuse before protected effects
nested-staging-ancestor-reject	refuse before protected effects
nested-results-ancestor-reject	refuse before protected effects
descendant-under-staging-reject	refuse before protected effects
descendant-under-results-reject	refuse before protected effects
case-sensitive-siblings-accept	accept with genuinely distinct Area/area objects
casefold-alias-reject	refuse on an actual casefold alias
casefold-staging-ancestor-reject	refuse on actual casefold ancestry
casefold-results-ancestor-reject	refuse on reverse actual casefold ancestry


Real ext4/casefold availability remains a future behavioral gate. No model, parser-only input, generic EACCES, setup failure, absent helper, or unavailable mount capability is a successful negative case. No case reduction based on environment convenience.
6. Pre-review engineering evidence allowed now
First freeze a finite command/effect list for the following ordinary-user controls; keep live adapters unreachable from these tests. Do not accidentally run the ES package by using go test on the proof source union.
A. Actual external adjudicator controls. Valid complete case; zero exit/missing event; duplicates/duplicate keys; malformed/truncated/over-limit event; wrong candidate/case/run; missing or skipped Go terminal; nonzero/signaled exit; wrong identity/capabilities; provider fallback; sentinel mismatch; incomplete case stage; cleanup uncertainty; failed export. Require explicit expected results independent of the parser.
B. Actual external lifecycle-controller fault controls with fake effects. Inject before/after each acquire, each pending/committed record, loop configuration, mount observation, child spawn/drop/run/wait, signal/deadline, evidence write and export, unmount, detach/last close and inventory. Cover acquisition success followed by record failure, primary plus cleanup failure, device reuse/mismatch, inventory errors versus empty success, partial setup and transport/owner loss. Demonstrate no unrelated detach/delete, no destructive cleanup while a child is live, no clean result after uncertain inventory, and preservation of both errors. Report these as controller tests, not real kernel cleanup proof.
C. Input/permission controls. Using only task-owned ordinary-user files or modeled metadata, reject input replacement/symlink/hardlink/nonregular/size/hash races, pre-existing destination/parent mismatch, and the v1 inaccessible binary/scratch/intermediate ancestry. Verify the expected permission matrix without claiming real root/UID-1000 execution on macOS.
D. Compilation and source union. Add the repaired external Linux test driver to a new disposable union of the exact unchanged 358 files; normally this remains 359 source members. Any second supplemental proof file must be enumerated explicitly as instrumentation, with rationale and exact original-member equality. Do not let external lifecycle tooling enter the ES production module or assurance inventory. Compile the updated proof driver and separate Linux/AMD64 supervisor; do not run either Linux binary. Retain source, commands, environment, compiler identity, manifests and output identities.
Pinned compiler:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Expected SHA-256:
3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19
Use GOTOOLCHAIN=local GOENV=off GOWORK=off GOPROXY=off GOSUMDB=off GOFLAGS=-mod=readonly GOTELEMETRY=off, task-owned external GOCACHE/GOTMPDIR, and the authenticated already-existing module cache. Record requested and observed settings separately. Match exact needed dependencies to the retained module graph, or use standard library only. Do not mutate shared module cache or repository go.mod/go.sum. Compilation for Linux uses GOOS=linux GOARCH=amd64 CGO_ENABLED=0 where supported by the selected helper. Missing compiler/dependency/cross-build capability is a bounded block, not install authorization.
Proof build form, from the disposable source union only:
"$GO" test -c -o "$OUT/cust2-mounted-proof-v2-linux-amd64.test" ./es/admission
The separate portable controller/adjudicator test package may use "$GO" test -json ./... -count=1 ONLY from its own external directory after inspection of all init/TestMain/effect adapters. Package the exact final argv, selector and paths. A separate native-host race run of those external safe controls is optional only if useful and entirely inside the same nonprivileged effects; no ES test executes.
Do not represent bash -n, compile success, modeled failure transitions or source review as proof of mounted operation, UID transition, loop autoclear or signal cleanup. Explicitly list runtime-only kernel assertions remaining for future authorization.
7. No new product validation cycle; finite recovery
Existing ES local/native streams, source archive and 327-row inventory stay unchanged. Rebuild only external artifacts whose source/inputs changed. Do not rebuild or rerun the frozen product to correct external reporting.
Before final external freeze, normal in-scope development corrections are permitted in this task. Preserve failed controls and successor deltas. A local analysis-only defect can receive a versioned correction and replay of unchanged records without discarding those records. Do not extend into a general validation framework or pause for a relay over each ordinary in-scope control bug. No amount of external self-validation authorizes root execution or closes the independent audit.
If a current product defect is found, report it with exact source/lines and stop any claim that the product or proof is accepted; do not edit it here. If a required proof mechanism needs a new privilege/resource/host/service surface, stop and state that exact decision rather than inventing an implicit permission.
8. Review packet and final disposition
Create one new external repair report and compact review ZIP. Include directly, not through nested historical ZIP chains:
- complete successor bootstrap/supervisor/worker/recovery/export/adjudicator/driver sources and fixed case/permission/state/resource tables;
- exact v1-to-v2 deltas, including removed code, and F-1…F-16 closure matrix with old failure, new mechanism, new source path/lines, test/control evidence, remaining native obligation and confidence;
- exact future root entry/gateway, context, tool/loader identities, argument schema, source/binary hashes, resource maxima, process/FD handoffs, signal/deadline behavior, cleanup uncertainty rules and evidence export; mark it proposed and unapproved;
- final ordinary-user control streams, command/exit records, explicit compile-only logs and binary metadata, source-union manifest and equality to all original files;
- actual current root/result source excerpts needed to audit driver calls, with whole-file hashes and source line locations; do not substitute old pre-repair source;
- unchanged product source/candidate bindings, exact opening/closing repository comparisons, original audit report, both specialist findings/disagreement, and identity references to historical input packets;
- concise remaining-gate ledger preserving mounted execution, deployment observation, supported-local proof/hook, fresh whole-candidate audit, separate stage/commit authority.
Keep prebuilt binaries, caches, image contents, whole raw host state, credentials, keys, config secrets, databases and unrelated evidence out of the compact ZIP. Retain actual newly compiled binaries separately with exact identities. No root runtime record can exist from this task.
Verify safe unique members and exact manifest coverage, sizes, modes and digests. Keep ZIP/report/manifest hashing acyclic; do not turn packaging mechanics into a new multi-generation program. Preserve old evidence. Do not delete classified .pyc or OS metadata belonging to prior roots.
Final result, ONLY if all sixteen findings have implementation/control responses and no static blocker remains in owner review:
ES_MOUNTED_HELPER_V2_REPAIRED_PREEXECUTION_REAUDIT_REQUIRED
Otherwise:
ES_MOUNTED_HELPER_V2_REPAIR_BLOCKED
On both outcomes, state: repository changes zero; old validated ES bytes unchanged; no host/root/mount/test-binary execution; no independent acceptance or execution authorization; exact unresolved seams and runtime-only prerequisites. Give actual touched external files, exact commands/results, failed/skipped validation, all retained artifact identities and any proposed effect-boundary change. Do not call owner self-review independent audit or call modeled control passes mounted proof.
Return the report AND the compact repair ZIP for review. The next independent reviewer must inspect the actual sources before any exact-byte root authorization is considered.
External semantics used by the engineering lead (not host evidence)
The attached audit is the finding source. These primary references corroborate only the bounded API distinctions and must not substitute for the target's observed tools/kernel:
- Linux v6.17 loop UAPI: https://raw.githubusercontent.com/torvalds/linux/v6.17/include/uapi/linux/loop.h
- Linux v6.17 loop_configure, loop_clr_fd, lo_release: https://raw.githubusercontent.com/torvalds/linux/v6.17/drivers/block/loop.c
- util-linux v2.39.3 losetup: https://raw.githubusercontent.com/util-linux/util-linux/v2.39.3/sys-utils/losetup.8.adoc
- Linux no-new-privs: https://docs.kernel.org/userspace-api/no_new_privs.html
LOOP_CONFIGURE can configure supported flags with the association, but free-device selection is not itself exclusive ownership; autoclear takes effect on last reference, not at a conveniently printed cleanup line. The API does not supply the invented association-generation certificate that a pathname ledger might imply. Source-ground any additional API mechanism in primary documentation and state its assumptions. No website or compiler metadata proves remote runtime availability.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
