ES final-audit repair design freeze
Objective and effect boundary
Use the existing implementation/repair Codex conversation, not the independent audit conversation. Produce one implementation-ready, source-grounded repair plan for CUST-1, CUST-2, M3-1, CUST-3, DOC-2, and the external audit-runner umask defect from the latest final audit.
This turn is repository-read-only design. Do not implement or format files, run tests or benchmarks, execute mutation fixtures, run repository scripts, install dependencies, contact hosts/services/networks, start Lima/Docker, create mounts/namespaces, modify historical evidence, stage, commit, push, fetch, switch branches, or alter worktrees. Read-only Git inspection and in-memory analysis of supplied source/evidence are permitted. You may write the requested safe design report and supporting source excerpts to a fresh owner-only directory outside every repository. Do not let the report create a new source of product authority.
The next effect after an accepted design will be one parent-only implementation task covering the bounded repair and its validation. This turn must stop at a frozen plan. It is not another full audit, a request to reconsider the entire architecture, or permission to repair the evidence history.
Baseline, evidence, and authentication
Repository: /Users/ds/Repositories/Execution Substrate/
Expected rejected candidate:
- branch/upstream: trunk_dev / origin/trunk_dev;
- HEAD: b92bd9884106154d25342e1573dcc4c312311436;
- HEAD tree: cdd4e44bac15c1952d70997143040644361f0bb1;
- sole parent: 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- local divergence: 0 behind / 1 ahead, without fetching;
- 64 modified tracked plus 11 untracked regular paths; zero staged/conflicted paths; no active Git operation; six retained worktrees;
- status: 3511 bytes, SHA-256 adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93;
- complete source manifest: 352 rows, 66503 bytes, SHA-256 7e48b9407da4117bc22c862802f94d324e5b216394b78f040b3ba4087eb6ca5c;
- candidate manifest: 75 rows, 9109 bytes, SHA-256 2fa0cd9f49bacf98727b109362ca8514d780b9a4ddb8c6d01e94ba1cc0fe071f;
- tracked binary diff: 2246275 bytes, SHA-256 c8d68d2eb71a4482c1cf2e66209d32d8fdf83b0f7fdc55f299b31277b315b54e;
- retained diff recipe: GIT_OPTIONAL_LOCKS=0 git -c core.fsmonitor=false diff --binary --full-index.
Latest audit root (the XXXXXX is literally part of its reported name; do not substitute a guessed timestamp):
/Users/ds/Downloads/ES-final-independent-audit-20261005TXXXXXXZ-p860xwkf
Primary report: REPORT.md in that root. The copy inspected by ChatGPT is 29923 bytes, SHA-256 3c62d3c08fbbd0968fdedc52e0dda1064298d51dd771b6ad0b0c227f412c6a28.
Audit packet:
/Users/ds/Downloads/ES-final-combined-independent-audit-20261005T013514Z-p860xwkf.zip
- ZIP: 709828 bytes, SHA-256 28feca46c8f52b51a007099ac8d7248b5a8084679bc4a752d05b991805d9ba1e;
- internal manifest SHA-256: 48bd1d78101ecb5e9ee90aa749d254f5faddf00500bebd54fb2530dc086d2487;
- reported manifest/member counts: 92 / 93.
Retained preceding implementation/native evidence:
/private/tmp/ES-native-linux-fixture-repair-revalidation-1G6rj3Sg
with review ZIP:
/Users/ds/Downloads/ES-native-linux-fixture-repair-revalidation-20261005T002620Z-1G6rj3Sg.zip
ZIP SHA-256 6fd48d67c5afbba2f088dfe15f265847b431624091e70b5894f7541c7fbd7d29; 530305 bytes. The audit already adjudicated this native evidence. Inspect the relevant retained records and recipes; do not reprocess every old environment-preparation artifact as a new workstream.
Before substantive design:
1. Authenticate the audit packet and internal file inventory, rejecting unsafe or special paths. Inspect its exact provenance recipe sources before use. Never execute arbitrary archived helpers merely because their hashes match.
2. Reproduce the opening live repository/source/candidate/diff identity with the retained safe serializers and compare exact bytes, not counts alone. Inspect Git attributes/configuration before the retained diff recipe; do not allow external diff/textconv/filter commands to run implicitly. On changed external-command selection, stop rather than substitute a new diff hash.
3. Read candidate-path-classification.tsv/.json, relevant specialist reports and the retained fresh_validation.py source. Distinguish the auditor's conclusions from raw evidence and your own source conclusions.
4. Preserve all reports, failed streams, old manifests, helpers, and source snapshots unchanged. Do not manufacture a missing raw record from a summary.
5. On live-byte mismatch or missing authentication inputs, report the exact blocker. Do not reset, clean, regenerate historical outputs, or absorb unrelated changes.
ChatGPT inspected the earlier 352-file source archive. Its relevant production, documentation, and operator-test members predate only the latest one-file hermetic-fixture repair; that newer fixture itself was supplied here only through reports. Authenticate the current candidate from the live repository and retained final-audit records, not by treating the older archive as current.
Governing sources and classifications
Read AGENTS.md, current PLANS.md, applicable nested guidance, and the relevant owning documentation before code. Use README.md only for navigation.
Primary source anchors (confirm current line positions):
- PLANS.md:306–397: expected-tree ownership, resource budgets, custody, capability policy, retained roots, native validation, and still-open seams;
- .docs/system_overview/configuration.md:342–387: staging/results roots, same-path host/container constraint, result independence, runtime-support capture;
- .docs/system_overview/capability_probing.md: validation boundaries, no runtime OS-label fallback, no central registry;
- .docs/execution_lifecycle/contracts.md:689–701,1179–1203;
- .docs/execution_lifecycle/implementation.md:593–618;
- .docs/execution_lifecycle/es_execution_admission_model.md:681–694,755–849;
- .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:685;
- .docs/system_overview/remote_supported_host_alpha.md, relevant safe source-owned runbooks/examples/configuration generators, and existing operator retirement contracts;
- es/admission/mounts.go, mounts_test.go, resource_limits.go, resource_limits_test.go;
- es/admission/staging_custody.go, its platform files/tests, service.go, results.go, results_test.go, ownership.go, writable-state validation and relevant tests;
- es/config/config.go, config_test.go;
- remote_alpha_operator_test.go, scripts/remote_alpha_operator.sh, docs_contract_test.go;
- es/admission/reliable_submit_contract.go;
- es/runtimehelper/supervisor_normalization_test.go as unchanged evidence of the runner problem, not a pre-authorized repair target;
- go.mod, go.sum, existing typed inventories and the native required-test inventory.
Keep these classifications explicit:
- CUST-1: candidate-added resource-bound defect in a Bounded slice rule.
- CUST-2: a pre-existing lexical configuration check interacting with candidate custody/results behavior; repair the Current invariant of staging non-mutation and the bounded retained-output independence contract.
- M3-1: candidate assurance closure defect protecting an effect-free/privacy-first Temporary compatibility edge; the current script is not reported to have performed an unauthorized effect.
- CUST-3: exact test-caller documentation drift.
- DOC-2: pre-existing ambiguous wording retained in a candidate-modified document; private reliable-submit parsers exist, public/runtime wiring does not.
- umask defect: external validation-harness implementation detail, not a newly established product defect.
- reports/manifests: evidence only. ES remains admission/runtime/result owner; no helper, CP, Coordinator, Bridge, IM, MA, or external schema artifact becomes a new authority.
No reliable-submit runtime, PlanBinding, replay/recovery, host-substitution, general reclamation, A3 namespace lease/registry/root-pair topology, external schema-package consumer, target-audit/A6, public protocol, or publication work is selected.
Selected direction and required design decisions
1. CUST-2 is the critical design path: physical separation before effects
The repair must enforce physical non-overlap of staging and results under the explicitly supported filesystem topology. Different cleaned strings and different owners are not the proof; different terminal object identities alone do not settle nesting. Reject equal objects and nesting in either direction before result-side reconciliation, creation, publication, or normalization can affect staging.
Do not turn ExecutionConfig.Validate into a filesystem mutator to repair an admission-owned problem. Prefer retaining its useful lexical shape check and placing physical checks in the existing admission custody owner. A config-file edit is justified only by the actual dependency/contract map, not because the audit listed it as a possible touched path.
The design must specify:
- Exact descriptor/identity/component-chain observations and which operation owns and closes each descriptor.
- Where pair qualification occurs at startup and at each result effect boundary; how handles used for the check remain bound to those used for the effect. A check followed by unrelated unchecked path reopening is not closure.
- Every route into openRetainedResultDirectory, including retainTerminalResult, readRetainedResultBundle, and reconcileRetainedResultArtifacts. In the audited source, create=false still reaches Fchown/Fchmod, and retained reads can reconcile normalization evidence. Do not classify a route as read-only from its name.
- What happens when staging or a staging run tree is absent. Preserve the retained-bundle-first behavior of Result and the no-runtime-lookup contract where applicable; do not silently require a live Nomad lookup or an original staging run tree to serve already retained output.
- Handling of missing roots at startup without creating result descendants inside staging before disjointness is established. Separate any already-authorized startup root provisioning from result mutation.
- Case aliases, equal objects with different spellings, physical nesting with disjoint lexical names, independent sibling roots, separate filesystem roots, and permitted mounted roots.
- Bind/alias topology: recommend one explicit supported topology and its enforceable boundary. Distinguish same-object aliases from separately presented nested source subtrees. Do not claim a visible ancestor chain establishes arbitrary host-source ancestry without a justified mechanism. Do not silently ban all mount crossings: current configured-root qualification intentionally passes noCrossDevice=false, and the documentation retains a host/container same-path staging mount constraint. Do not silently require both roots to be on the same device either.
- Whether existing syscall/static metadata is sufficient, any platform-specific additions needed, and their capability/compatibility implications. Platform helpers may be build-selected; no runtime OS-label fallback or silent best effort.
- Stable-namespace/trusted-operator assumptions and the exact drift/TOCTOU boundary. No claim to defeat an arbitrarily privileged concurrent namespace adversary unless an actual mechanism supports it.
- No durable/process-global pair registry, new lease, background scanner, filesystem-content enumeration, broad ancestor ownership rewrite, or staging cleanup.
Return exact proposed governing prose, a truth table of accepted/rejected/unprovable topologies, and the corresponding integration tests. Recommend the single best plan; do not leave a menu of unanswered options. Any unavoidable compatibility reduction must be named with its source impact and proposed migration treatment, not disguised as a bug-only edit. If the required topology cannot be settled from source/static reasoning, return a narrowly scoped decision or experiment requirement rather than inventing closure.
2. CUST-1: remove namespace-validation amplification without changing stream policy
Replace whole-map descendant scans and repeated cumulative-parent scans with an invocation-local namespace representation whose traversal work is linear in processed name bytes/segment occurrences, with its map/hash assumptions explicit. A trie/radix or equivalent is acceptable; choose the simplest source-justified design, not a new reusable framework.
Preserve:
- 8 MiB per-mount / 32 MiB aggregate compressed transport and regular-body bounds;
- 16 MiB per-mount / 64 MiB aggregate whole decompressed stream accounting, including extension records and trailing bytes;
- no new 4096-entry or 4096-byte-name limit;
- PAX/GNU support as currently documented;
- pre-freeze validation, no second archive parse during materialization, current entry ordering, and fixed public privacy/error boundaries;
- explicit versus implicit directories, existing permitted repeated directory headers, file duplicates, normalized aliases, both file/descendant collision orders, and refusal of links/special entries. First derive exact current behavior; do not reinterpret “duplicate rejection” as blanket rejection of currently permitted directory headers.
The design must account for deep names, shared prefixes, retained edge bytes, allocations, and traversal stack. Do not replace CPU amplification with cumulative-prefix memory amplification or unbounded recursive depth. Separate structural complexity from wall-clock/heap guarantees.
Specify deterministic work-measurement tests that exercise the production ledger/traversal, not a test-only imitation or a counter incremented only once at the entry point. Cover the maximum feasible flat-entry shape under stream bounds, deeply segmented legal PAX/GNU names, collision orders, and equality/+1 budget cases. Any cancellation threading is a separate justified scoped change; do not treat adding a timeout as a substitute for repairing the algorithm.
3. M3-1: close the protected scanner effect inventory
The target is an enforceable bounded semantic guarantee for the two protected scanners and their already-reviewed refusal/ordering boundary, not a general Bash security analyzer.
Inventory all executable constructs in reject_secret_args and reject_retired_operator_evidence_args: direct commands, compound/control structures, assignment evaluation, command/process substitutions, redirections, and allowed calls. Commands hidden in double quotes, local assignments, or unquoted heredoc evaluation must not become “inert text” through stripping. Preserve the reviewed local-variable and shopt behavior; “no external effects” does not mean forbidding the scanner's necessary local computation.
Choose a small fail-closed accepted grammar/semantic representation. Unknown executable syntax must not simply be ignored. Retain demonstrated formatting/comment/inert-literal tolerance and ensure inert additions cannot alter live scanner variables. Preserve exact routing, refusal text, exit/status/stdout/stderr, privacy-first order, and unrelated active routes.
Do not fix this by adding a denylist for printf, exact raw-function hashes, or a test expecting the current vulnerable validator to pass. Do not loosen documentation alone while still claiming effect-free closure. Do not add a shell-parser dependency or rewrite production scripts without explicitly surfacing necessity and impact first.
Tests must feed mutation strings into the guard, not execute injected effects. Include standalone effects before/between/after scanner branches, assignment command substitutions, substitutions inside double quotes, redirection-only effects, compound-command/inline forms, and additional relevant executable syntax accepted by the chosen grammar. Existing positive mutants must remain accepted; existing privacy/tombstone/exact-output/no-effect behavior vectors remain required.
Realign .docs/execution_lifecycle/es_execution_admission_model.md:843–847 and affected owning prose to the exact bounded semantic guarantee. Do not preserve the inaccurate claim that complete scanner raw text is compared.
4. Fold the two Low findings into the same repair
CUST-3: add TestPhysicalTestTempDirPreservesIntentionalSymlinkRefusal to the exact test-only claimStagingCustody caller inventory and account for any callers added by this repair. Reuse existing typed inventory machinery where appropriate; do not establish another count-only oracle.
DOC-2: replace “no handler or decoder implemented” with precise public/runtime nonwiring language consistent with private parseValidatedReliableSubmitRequest and decodeStrictReliableSubmitJSON. Update the affected docs-contract assertions. Private parsers stay unwired; this is not authorization to wire them.
5. Correct the next validation runner, not the recorded failure
Inspect the retained audit runner at the actual location reported by its inventory. Identify precisely how umask 077 reached Go children. The unchanged supervisor_normalization_test.go:249 fixture requests 0755; the failing assertion expects that input mode to have remained 0755.
For the next runner:
- preserve and record the inherited ordinary child umask; do not force 077, silently force 022, or change the user's shell configuration. If the genuine inherited mask is itself incompatible with an existing fixture, report that separate pre-existing assumption instead of claiming the runner correction has solved it;
- create evidence directories/files with explicit restrictive modes, independently of the environment given to tests;
- record relevant child environment and explicit inherited umask before starting full suites;
- retain the earlier GOENV requested-environment versus reported-output distinction;
- keep historical runner source and both failed streams unchanged, with a separate new runner identity and explanation;
- do not edit the runtimehelper test or production mode behavior merely to hide the external runner mistake.
Define a bounded runner preflight sufficient to prevent this exact environment contamination before expensive tests. Do not build another general environment-proof subsystem. This turn inspects/designs it only; no helper or tests are executed.
Exploration and integration
One foreground parent owns synthesis. Up to three read-only explorers may cover: (1) CUST-2 topology, custody, and compatibility; (2) CUST-1 algorithm/budget/coverage; (3) M3 grammar, low doc corrections, and test inventory. Give each the exact baseline and a self-contained scope. No nested delegation or child tests. Parent owns runner/provenance/validation integration. If a perspective is unavailable, the parent may inspect it explicitly; never claim a missing independent perspective was performed. Close explorers before finishing; no mutation follows in this turn.
Recommend integration order: freeze CUST-2 topology and all governing changes first; then parent-only CUST-1/CUST-2/M3 implementation plus both Low corrections; then one integrated local validation/freeze/native-validation cycle. No parallel repository writers. Do not request separate full suites or native cycles for each finding.
Map the exact proposed touched set, identifying already-dirty paths versus newly dirty paths. The current 75-path count is not a permanent quota. Conversely, do not add es/config/config.go automatically. Name all finite caller/helper/mutation inventories affected by any new helper or call edge. State why scripts, public DTOs, schemas/migrations, dependencies, examples, or fixtures do or do not need changes.
Acceptance and validation plan to freeze — do not execute in this turn
Choose concrete regression names and exact commands in the report. At final implementation closeout, plan these complete sequential local gates against one candidate under the authenticated installed Go 1.26.5 and existing offline module cache:
# Normal inherited macOS TMPDIR and inherited ordinary umask
go test -json ./... -count=1

# Physical TMPDIR, same inherited ordinary umask
TMPDIR=/private/tmp go test -json ./... -count=1

# Race gate; no silent CGO disabling
CGO_ENABLED=1 TMPDIR=/private/tmp go test -json -race ./es/admission ./es/app -count=1
Use the actual authenticated executable rather than trusting ambient PATH:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Retain known offline/read-only module settings, task-owned caches outside the repository, and explicit selected environment records. Prechecks include go version, selected go env -json, go mod verify, go list -m all, read-only formatting/shell-syntax checks on relevant paths, and git diff --check. Define any focused development tests separately from the final frozen-candidate gate; do not count an earlier run against later changed bytes.
The audit's old native passes are valid historical evidence for the rejected bytes. CUST-1/CUST-2 will change production admission/custody, so the repaired frozen candidate requires new native evidence:
go test -json ./es/admission -count=1
AMD64 uses host_to_remote_linux_m75q; ARM64 uses the existing Lima es-lima-qemu-arm64. The future execution task must use the retained authenticated installed toolchains/caches, one identical fresh source archive, and sequential AMD64 then ARM64 gates. A failing AMD64 final gate stops before ARM64. No preemptive reinstall, environment-restoration project, new VM/mount/namespace, privilege escalation, tracing, or live ES/Nomad/Docker/SPIRE/Vault operation is authorized by this design task.
Preserve the existing 81-row required inventory and add the new portable/native-specific obligations. Build-tag absence is not a pass, a parent passing is not proof of child execution, and required skips/missing paths block closure. The previous 37 Docker/Nomad app skips and deliberate helper-process skip are explicitly scoped non-claims, not a reason to start services or a license to ignore new skips. Define actual-filesystem versus modeled topology evidence honestly. A modeled bind-alias test alone cannot substantiate an asserted native mounted-topology guarantee; identify a required bounded follow-on observation if actual capability evidence is missing, without executing it now.
After implementation, a fresh independent audit must review all repaired bytes, changed call edges, claim/inventory alignment, and preserved integration boundaries. It may authenticate complete same-byte validation records rather than automatically rerun the identical expensive suites. Additional execution is justified by missing/stale evidence or a specific new obligation, not by the audit label alone. No staging or commit is authorized until a later accepted exact-bytes gate.
Required output and stop
Return one safe Markdown design report plus a compact machine-readable touched-surface/acceptance matrix outside repositories. Include:
- opening/closing identities and byte-preservation result;
- finding-by-finding confirmation, disagreements, pre-existing versus candidate attribution;
- one selected implementation plan, with exact proposed contract wording and CUST-2 topology truth table;
- exact owned handles/state, call/effect ordering, algorithmic bounds, M3 accepted grammar and refusal behavior;
- proposed touched files and inventory/schema/config/compatibility implications;
- exact test names, commands, positive/adversarial inputs, evidence owners, applicable architectures, and non-claims;
- validation-runner correction and how old failures remain preserved;
- unresolved seams, assumptions, smallest necessary unperformed experiment, and explicit stop conditions;
- sources as repo-relative paths/line references; provenance, design, and validation confidence separately.
Use ES_FINAL_AUDIT_REPAIR_DESIGN_READY only when the plan is implementation-ready and the topology, ownership, migration treatment, and acceptance evidence are explicitly settled. Otherwise use ES_FINAL_AUDIT_REPAIR_DESIGN_BLOCKED and identify the smallest missing decision/evidence. Do not claim all findings repaired, validated, independently accepted, or commit-ready.
Confirm: no repo edits, tests, installs, network/host/service operations, final re-audit, staging, commit, push, or historical-evidence mutation. Stop.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
