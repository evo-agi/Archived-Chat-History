ES final-audit repair — combined implementation and local validation
Objective
Continue in the existing implementation/repair Codex conversation. Implement the already-designed combined repair for CUST-1, CUST-2, M3-1, CUST-3, DOC-2, and the external validation runner. Apply the authenticated original design, corrected amendment, and mountinfo grammar addendum, subject only to the explicit sequencing decision below.
This is the implementation turn after completed design work, not a request for another general reconnaissance report. You are the sole repository writer. Spawn no subagents. Produce a locally validated, exact-byte successor candidate and a report that keeps all external acceptance gates pending. Do not perform independent audit, staging, commit, publication, deployment, or service restoration.
Repository: /Users/ds/Repositories/Execution Substrate/.
1. Explicit sequencing decision — defer, do not pass or waive
The last task returned ES_CUST2_TOPOLOGY_OBSERVATION_BLOCKED_ACCESS_OR_CONTEXT. It acquired no eligible ES process, root descriptors, or topology relation. Preserve that result unchanged. Neither incompatibility nor compatibility was observed, and a possible remote container was not ruled out.
This handoff explicitly supersedes ONLY the requirement to obtain a currently running deployment observation before repository implementation, including that timing in amendment section 5, the original design's implementation stop condition, the corresponding matrix rows, and the previous observation prompt. It does not override any owning repository invariant or permission boundary.
Selected order:
1. Record this sequencing decision in PLANS.md and the affected governing/acceptance text, clearly separating intended behavior from validation status.
2. Implement the frozen combined repair and its tests, doc-first.
3. Validate the repaired candidate locally under the corrected runner and freeze exact bytes.
4. Complete the still-required external evidence against that candidate under a subsequent specifically authorized task: sequential native AMD64/ARM64 admission validation; real mounted repaired-helper cases; and the deferred running-deployment compatibility observation.
5. Obtain fresh independent audit and only then a separately authorized exact-byte commit gate.
The running-deployment observation remains a pre-final-acceptance and pre-commit gate. The mounted-helper cases remain a separate pre-final-acceptance gate. No audit ACCEPT, commit readiness, deployment compatibility, or rollout readiness may be claimed while either is missing. A later decision to replace or remove an evidence obligation would require a separate explicit governance decision; this task does not make one.
This deliberately accepts bounded implementation rework risk if later observations expose incompatibility. It does not accept incompatible behavior into a committed/deployed candidate. Do not silently narrow mounted-root, architecture, runtime-profile, retained-result, or casefold support to obtain local success. Do not hard-code paths or assumptions from historical hosts into production.
Do not add a new runtime approval, observer receipt, external manifest dependency, or deployment certificate to ES. The observation is development/acceptance evidence, not runtime authority. ES itself must enforce the selected physical-separation proof at the documented boundaries.
If an actual owning-repository rule conflicts with this explicit sequencing change, identify its exact path/line and stop that conflicting work. Do not mistake a superseded external planning instruction for an immutable repository rule. The design and algorithm are otherwise frozen; no new topology design round is requested.
2. Authority, classifications, and effect ceiling
Read AGENTS.md, PLANS.md, relevant .docs/system_overview/ and .docs/execution_lifecycle/ contracts, and current source/tests before editing. Apply the repository hierarchy. Relevant supplied-snapshot anchors include:
- AGENTS.md:21–36,54–99,153–159;
- PLANS.md:333–397;
- .docs/system_overview/configuration.md:342–387;
- .docs/system_overview/capability_probing.md:141–178;
- .docs/system_overview/evolution.md:110–120;
- the source/doc/test anchors in the authenticated original audit and corrected matrix.
Verify current live positions. Source snapshots are inspection baselines, not substitutes for live provenance.
Classifications remain: CUST-1 is a bounded resource-rule refinement; CUST-2 refines staging non-mutation and independent retained-output custody; M3-1 closes bounded assurance for privacy-first/effect-free retired routes; CUST-3/DOC-2 are inventory/doc corrections; runner repair is external test-harness work. The supported-local launcher and control-plane-normal-shell/v1 remain temporary compatibility edges. Reports/manifests are evidence. Reliable-submit runtime and other reopened seams remain unwired/unsettled as documented.
Authorized:
- Parent-only edits to the corrected matrix's exact repair surfaces in ES, including governing docs and tests.
- Formatting touched Go files, source/diff inspection, local development tests, and the exact local final validation lanes below.
- Fresh local task-owned evidence/build/test scratch outside all repositories, explicit restrictive evidence modes, a corrected external runner, and a compact review ZIP.
- Existing test-local loopback/fake-provider fixtures and the suite's documented non-mutating capability checks. These are not live ES service operations.
Not authorized:
- SSH/remote operations, Lima start/stop, running-namespace rediscovery, topology-observer execution, live ES HTTP/operator routes, service restoration, Docker/VM/container lifecycle, mounts/namespaces, privilege escalation, user/group/socket permission changes, tracing, or installation/download/image pull.
- Deploying/replacing the ES executable, changing service configuration, accessing live staging/results/security trees, live Nomad/Docker allocations, or reviving CP/IM/MA/Bridge/Symphony.
- Dependency/version/public DTO/API/schema/migration changes, reliable-submit wiring, new root registry/lease/kernel, general cleanup, or historical-evidence edits.
- Index/ref/branch/worktree mutation, fetch, stash, reset, clean, staging, commit, push, PR, merge, or deployment.
An existing shell/test fixture may execute a reviewed repository script as part of the declared local suite. That is not permission to run the operational bringup/restoration paths directly or to mutate a real deployment.
3. Authenticate retained inputs and the opening candidate
Original audit (the XXXXXX is literal):
/Users/ds/Downloads/ES-final-independent-audit-20261005TXXXXXXZ-p860xwkf/REPORT.md
29,923 bytes; SHA-256 3c62d3c08fbbd0968fdedc52e0dda1064298d51dd771b6ad0b0c227f412c6a28.
Original design directory:
/Users/ds/Downloads/ES-final-audit-repair-design-20261005T023141Z/
- ES_FINAL_AUDIT_REPAIR_DESIGN.md: 47,288 bytes; SHA-256 a5252f40d899556baa5cd3000f8b5d94ebc81cda3c3a2076211d30cdb94d8128.
- Original matrix: SHA-256 71ec19d62275e23e88fb1a43643ec7d2b7799ea43ed549ae580cd99c169d6648.
Amendment directory:
/Users/ds/Downloads/ES-final-audit-repair-design-amendment-20261005T033001Z/
- ES_FINAL_AUDIT_REPAIR_DESIGN_AMENDMENT.md: 34,108 bytes; SHA-256 dc0ee29c3b2cb9c65895ec0679191c956a92e929eede405a55cb94ad19b20844.
- touched-surface-acceptance-matrix.corrected.json: 25,503 bytes; SHA-256 b7fa3e2c30f6c2f9d17c37b571b07fc8921fc8717826b1c8d918e97c322c630f.
- Its artifact manifest, retained tar feasibility table/probe output, preservation record, and exact provenance serializer sources. Read/authenticate the relevant evidence once; do not rerun the standard-library tar feasibility experiment.
Latest observation directory:
/Users/ds/Downloads/ES-cust2-topology-observation-20261005T214801Z-iFr1De/
- ES_CUST2_TOPOLOGY_OBSERVATION.md: supplied attachment fingerprint 12,080 bytes; SHA-256 ea4390d57f6b3dd8194ac3e20a906c5c06d3b62a2d55d8c121cef629b3feb181.
- ES_CUST2_MOUNTINFO_GRAMMAR_ADDENDUM.md and touched-surface-acceptance-matrix.delta.json, authenticated against the retained manifest.
- MANIFEST.tsv: 4,865 bytes; 42 rows; reported SHA-256 1c18ea5282343fdf0c21752790232a3b5d81e9b2c67d67290300b90fda0cbe37.
- The input-authentication/preservation records and modeled grammar controls, as needed. Do not recapture remote observations or indiscriminately copy private provenance/host material.
The report and manifest references above are authentication inputs, not a requirement to duplicate every historical archive and installation record. Obtain required native-test inventory and exact serializer source from their authenticated retained references. Do not reconstruct missing recipes approximately or run an archived script merely because its filename is familiar.
Expected opening ES identity:
- trunk_dev / origin/trunk_dev;
- HEAD b92bd9884106154d25342e1573dcc4c312311436;
- tree cdd4e44bac15c1952d70997143040644361f0bb1;
- sole parent 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- 0 behind / 1 ahead without fetch; six unchanged worktrees;
- 64 modified tracked plus 11 untracked regular files; zero staged/conflicted paths; no active Git operation;
- source serialization: 352 rows, 66,503 bytes, SHA-256 7e48b9407da4117bc22c862802f94d324e5b216394b78f040b3ba4087eb6ca5c;
- candidate serialization: 75 rows, 9,109 bytes, SHA-256 2fa0cd9f49bacf98727b109362ca8514d780b9a4ddb8c6d01e94ba1cc0fe071f;
- status: 3,511 bytes, SHA-256 adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93;
- tracked binary/full-index diff: 2,246,275 bytes, SHA-256 c8d68d2eb71a4482c1cf2e66209d32d8fdf83b0f7fdc55f299b31277b315b54e.
Inspect relevant Git config/attributes before diff commands; preserve read-only Git protections. Use the retained exact source/candidate/diff recipes and preserve their source identities. Reproduce opening canonical outputs twice. Do not substitute a new diff recipe and compare its different output to the historical digest. Additional explicitly labeled no-ext-diff/no-textconv inspections are permissible.
Stop before edits on mismatch, missing authoritative input, or unrelated concurrent changes. Do not reset or adopt a new baseline. Retain exact opening copies of every file you will edit outside the repo so the repair-only delta is recoverable separately from the complete integration diff.
4. Scope freeze and doc-first implementation
Read the actual corrected complete matrix and grammar delta. Materialize the concrete repair allowlist from those inputs before writing. They describe 27 future touched surfaces, including six new cohesive execution_roots* files. The historical 75-path dirty set is not a quota and will grow as designed.
The matrix plus this timing amendment defines the authorized scope; do not add arbitrary new files. Record the short supersession/timing note and a successor acceptance matrix in the new task evidence. Preserve the original plans, matrices, audit outputs, probes, and failed streams. Do not rewrite all design reports.
First update PLANS.md and the affected owning docs. Then add/update contract and regression tests and implement the selected code. Governing text must describe both the intended contract and the real acceptance status; local implementation is not proof of mounted compatibility. Do not leave a document saying “native validated,” “complete,” or “accepted” based on old bytes.
Retain all unrelated pre-existing changes and every untouched source member exactly. No edit is selected for es/config/config.go, dependency files, public DTOs/routes/schemas, reliable-submit private parsers, operator script, or launcher. The existing lexical configuration check remains an early shape check, not physical proof.
CUST-1 — exact bounded namespace algorithm
Implement the original design's invocation-local path-aware compressed byte-radix ledger in the mount validator. Keep iteration, byte-keyed branching, substring labels, entry-bounded nodes, constant-depth traversal, and commit after all fallible per-entry validation. Remove repeated shrinking-prefix walks and accumulated-map descendant scans.
Preserve the actual namespace behavior and error precedence: repeated explicit directories and implicit-parent completion remain accepted; duplicate files, file/directory conflicts, normalized aliases, ancestor/descendant conflicts in both orders, malformed input, type refusals, and size precedence keep their specified results. Slash-boundary semantics must distinguish a/ab from a/a/b.
Retain existing compressed/body/decompressed-stream and aggregate budgets. Add no ES name/entry cap, cancellation redesign, parser fork, dependency change, or post-freeze reparse. Do not replace quadratic CPU with per-segment nodes, copied cumulative prefixes, deep recursion, or a second full-name index.
Use the corrected, parser-reachable PAX/GNU acceptance shapes and exact EOF/canonical-footer boundaries from the amendment. Instrument the real production comparison/lookup/commit/allocation sites with the optional private work ledger. Assert returned-header and actual probe/commit counts. A construction refusal or reader refusal does not count as radix coverage. Explicitly distinguish inherited pinned-parser metadata limits from ES policy.
CUST-2 — complete operation-local root custody
Implement the original design as corrected by the amendment and grammar addendum, not its superseded configured-spelling formula.
- Qualify staging/results as one operation-local root set with explicit descriptor ownership and idempotent closure. Keep lexical validation as an early non-mutating check.
- Bind canonical presentation to the held descriptor and platform identity. On Linux use returned statx masks, mount-ID-selected bounded mountinfo, device/inode/type cross-checks, nofollow canonical rewalk, source coordinates, and canonical descendant-mount checks. No configured-spelling or lowercase/Unicode shortcut may replace the proof.
- Apply the grammar addendum's justified single top-of-tree self-parent terminal and valid missing-parent treatment. Reject duplicate IDs, nontrivial cycles, unjustified non-top self-parent, malformed/over-limit/ambiguous records, and required identity-mask/record disagreements.
- Keep the conservative Darwin F_GETPATH/fstatfs/getfsstat proof and its explicitly documented compatibility limits. Linux evidence does not prove Darwin behavior.
- Preserve existing-object proof versus missing-suffix intent. Ambiguous dual-missing roots fail closed; no inference of lookup equivalence from unequal strings. Canonicalize/requalify after each provisioned component before later effects. Preserve existing retained-bundle reads with staging root/run absent.
- Startup qualifies before provisioning and probes both selected filesystems in the documented order. Submit qualifies after freeze and binds the actual exclusive claim to the qualified staging descriptor.
- Cover all result-side effects, including read-named paths that reconcile ownership/mode or normalization evidence. Check before directory creation/reconciliation, temp creation, final/sidecar publication, and exact cleanup, using the descriptor that participated in the check. Missing results on a read must not provision; topology failure must not become Nomad fallback. Cleanup that loses custody retains its exact temporary.
- Implement the amendment's named acquisition schedule and assertions. Do not rescan the mount table per streaming read/write. Do not omit effect-boundary checks to reduce cost. Preserve the explicit stable-namespace/trusted-operator non-atomicity limitation.
- Keep no process-global root map/cache/lease, no general content enumeration, no recursive staging cleanup, no automatic migration, and no runtime dependence on this chat or external evidence.
Implement the modeled/platform/portable tests in the complete matrix, including both case-alias ancestry directions, true case-sensitive sibling controls, bound mask/record identity, replacement, missing roots, retained-first behavior, sentinel staging preservation, and scan-count assertions. Label modeled records as modeled. No actual bind/casefold proof is claimed from these tests.
Preserve distinct Linux sibling-bind support when the proof can establish it; do not reject every mounted root. Actual mounted repaired-helper obligations remain pending, with no new mount operation authorized here.
M3-1, CUST-3, DOC-2, and inventories
Implement the test-local fail-closed scanner grammar exactly as designed, with full protected-body token consumption and independently specified expected semantics. Do not execute negative mutation strings. Reject executable effects in assignments, quoted expansions, substitutions, redirections, and unknown/trailing syntax; preserve the reviewed control flow and privacy-first two-call entry prefix. Keep allowed comments/formatting/equivalent literals/fresh inert locals. Do not grow a general Bash analyzer or change the operator script to accommodate the parser.
Add the missing direct test caller and its typed, object-identity-based exact inventory. Distinguish the new descriptor-taking production claim constructor from the path-taking test wrapper; do not substitute source counts or fingerprints for semantic checks. Update all affected root/effect/probe/read/caller inventories in source tests and governing prose.
Use the exact corrected reliable-submit wording: no public/runtime handler or route decoder is wired; private parsing helpers remain present and unwired. Update matching docs assertions without wiring them.
Preserve the old hermetic runtime-support fixture, literal default/control-plane goldens, direct literal ledger independence, eight wrong-job/handoff controls, M1/M2 closure, public fixed errors, privacy classifications, one-registration bound, cancellation retention, and all unrelated current contracts.
5. External runner and local validation
Create a new external runner; preserve the old runner and both umask-contaminated failure streams unchanged. The original runner path/hash and failed stream identities are in design section 8. Do not change the runtimehelper mode assertion to hide the harness defect.
Use the installed pinned local Go executable:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Expected Go SHA-256: 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Expected matching gofmt SHA-256: 3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81.
Use process-only GOTOOLCHAIN=local, GOENV=off, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, and GOTELEMETRY=off, the existing authenticated module cache, and fresh external GOCACHE/GOTMPDIR. Preserve ordinary inherited macOS TMPDIR for the default lane. Record ambient architecture/CGO settings; do not silently cross-target or disable CGO.
The runner must not change the inherited umask. Record /bin/sh -c umask; validate the value and the existing fixture's 0755 & ~umask == 0755 assumption before expensive suites. Use one exact task-owned requested-0755 child probe in the same child environment and remove only that probe. An unsuitable inherited mask blocks validation; do not force 022 or alter shell state. Evidence directories/files must be created restrictively and explicitly verified/fchmod/chmod to 0700/0600 independently of the child mask.
Record requested GOENV=off separately from successful, well-formed go env -json with an explicitly present empty GOENV value. Missing key/output, nonempty environment-file path, malformed JSON, or nonzero exit is not accepted. Preserve negative predicate controls. No historical failed suite becomes a pass.
Bound the test effect surface
The existing app tests probe Docker availability and can proceed to real test containers/Nomad harnesses when it is available (es/app/submit_integration_test.go:1600–1629; es/app/operator_scripts_integration_test.go:3797–3829 in the supplied snapshot). A full ./... invocation is therefore not unconditionally service-free.
Before a broad lane, verify the unchanged test capability gates and ensure the selected endpoint remains within the reported unavailable-substrate posture. One bounded read-only local endpoint-availability check is authorized for this validation-scope check, not topology discovery; do not change context, start the provider, inspect containers, contact a remote engine, or grant socket access. Repeat only if a later lane could otherwise rely on stale availability evidence. If the selected endpoint is remote/ambiguous or becomes usable such that prohibited live integration effects would run, stop before that lane and report the scope conflict. Do not deliberately point at a dead socket, mock the capability check, filter out tests, or relabel the unfinished lane as passing. Existing safe test-loopback and local fixture effects remain authorized.
Development phase
Run required prechecks: exact version, selected go env -json, go mod verify, go list -m all, read-only git diff --check, gofmt -l for every candidate Go path, and /bin/bash -n for every candidate shell file. Format only authorized touched Go paths. Record exact results.
Use the following focused development commands, with $GO equal to the explicit executable above:
"$GO" test -json ./es/admission -run '^(TestRuntimeMountArchiveCompressedRadix|TestResolvedExecutionPlanPostFreezeConsumerGuardrails)' -count=1
"$GO" test -json ./es/admission -run '^(TestQualifiedExecutionRoots|TestStartupProvisioning|TestExecutionRootCapability|TestSubmitRejectsRootTopology|TestRetainedResultRoutes|TestResultServesRetained|TestRetainTerminalResultMissingStage|TestReadRetainedResultBundle|TestDarwinExecutionRoot|TestAdmissionTestOnlyStagingCustodyClaimInventoryIsExact|TestWorkstreamCRuntimeSupportFixtureIsHermetic)' -count=1
"$GO" test -json . -run '^(TestRemoteAlphaOperatorProtectedScannerGrammar|TestRemoteAlphaOperatorSemanticInventory|TestESExecutionAdmissionModel|TestReliableSubmit)' -count=1
Other narrowly selected local regression commands within the matrix are allowed when needed for in-scope development; record why and the exact bytes. Zero matched tests is not success. Linux build-tag absence on Darwin is not a pass. In-scope engineering repair/test iterations are allowed before final freeze; retain failed runs and byte identities, with no unchanged-candidate retry for a lucky outcome. Stop for a real design/authority conflict or out-of-scope fix, rather than changing the contract to appease a test.
Before final lanes, extend the authenticated historical required-test inventory without dropping or renaming away obligations. Retain its 81-row prefix; add the new paths with precise package/platform/lane applicability. Preserve existing 69-to-81 lineage. Identify every required parent and statically named child. Fixture setup or a passed parent is not proof of missing child execution.
One local final freeze and validation cycle
Freeze one complete source/candidate identity after focused success. Do not edit repository bytes after this point during this task. Sequentially run:
# Inherited ordinary TMPDIR and ordinary umask.
"$GO" test -json ./... -count=1

# Physical TMPDIR, same ordinary umask.
TMPDIR=/private/tmp "$GO" test -json ./... -count=1

# Race evidence, explicit CGO requirement.
CGO_ENABLED=1 TMPDIR=/private/tmp "$GO" test -json -race ./es/admission ./es/app -count=1
Parse complete JSON streams, commands/exits, package terminals, required test parents/children, failures/skips, and source identity. Applicable new required tests must explicitly run/pass. The known Docker/Nomad-dependent app skips and deliberate helper-process skip remain named environment non-claims; compare exact paths/reasons instead of blindly allowing a count of 37/38. New/changed unexpected skips or missing obligations block local closeout. Build-tag exclusions remain explicit applicability, not success.
On a final-lane failure, unexpected mutation, incomplete stream, or harness defect: retain evidence, stop the remaining final lanes, make no post-freeze repair/rerun, and report the exact blocked gate. Do not use an earlier focused pass or prior candidate's native/race result to clear it. A final failure is not permission to expand into service recovery.
This task does not execute native Linux suites, mount fixtures, or deployment observation. Record these as pending, not skipped-success. The mounted test/effect authority will be specified separately; do not manufacture a pre-provisioned fixture from design prose.
6. Provenance, artifacts, and handoff
After authorized task-owned scratch cleanup, reproduce closing identity and exact source/candidate serialization twice using the retained rules. Verify:
- HEAD/upstream/index/refs and all six worktrees remain unchanged;
- opening-to-closing repository changes are exactly the allowed repair;
- every source outside the touched set remains byte/mode-identical;
- no post-freeze source mutation occurred;
- the complete integration candidate includes old and new dirty paths, with actual counts;
- no generated evidence/cache/build product or sensitive material entered the repository.
Keep the complete integration manifest/diff separate from the repair-only touched-path manifest/diff. Include untracked opening source in the repair delta, not merely tracked Git differences. A count or aggregate hash is not a substitute for recoverable bytes and exact recipe source.
Create a fresh owner-only evidence directory under /Users/ds/Downloads/ES-final-audit-combined-repair-<actual-UTC>-<unique>/ containing:
- one implementation/validation report with per-finding status, exact touched paths, real local results, remaining external gates, assumptions, limits, and no independent-audit claim;
- the short explicit sequencing supersession and successor acceptance matrix, preserving all algorithm/compatibility/evidence obligations;
- exact before/after repair-only diff and touched-file identities plus safely shareable changed source/doc/test bytes;
- complete source/candidate manifests, original serializer source identities, opening/closing/freeze comparisons, and recoverable safe diff evidence;
- corrected external runner source, command/environment/mode records, full local test JSON/stderr, parsed test-event coverage, and extended required-test inventory;
- a safe source archive/member registry for the frozen successor, using the retained deterministic packaging rules, if all local final lanes pass. This is packaging, not Linux validation; verify every regular member against the final manifest. Do not include .git, ignored/security state, builds, caches, databases, or raw historical evidence;
- a compact review ZIP with safe relative regular members, no duplicate/escaping/special members, and a self-excluding per-file size/mode/SHA-256 manifest.
The review ZIP must contain the actual report, repair diff, changed source, runner, and raw local test streams needed for review—not only links. Keep full unsafe/private outputs locally if necessary; derived/redacted records must be labeled and cannot replace unchanged raw evidence for audit. Do not duplicate distribution archives/module caches, credentials, raw deployment configuration, logs, or staging/results trees.
In the final reply report one primary disposition:
- ES_FINAL_AUDIT_REPAIR_IMPLEMENTED_LOCAL_VALIDATION_COMPLETE_EXTERNAL_GATES_PENDING — all authorized local gates passed against one frozen candidate; external gates and independent audit remain outstanding.
- ES_FINAL_AUDIT_REPAIR_IMPLEMENTATION_OR_LOCAL_VALIDATION_BLOCKED — name the exact failure/conflict, current byte identity, partial completion, and validation not performed.
- ES_FINAL_AUDIT_REPAIR_BLOCKED_PROVENANCE — required input/live identity/recipe unavailable or mismatched before authorized editing.
Give exact artifact paths, sizes and hashes, touched-file list, command outcomes, skipped/unexecuted validation, source/candidate/repair diff identities, any effect or authority widening, and separate provenance/validation/implementation confidence. Do not call a local-pass result FINAL_AUDIT_READY, ACCEPT, or COMMIT_READY.
Stop. No staging, commit, native host work, service restoration, topology observation, or independent audit follows conditionally in this task.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
