## Retain the block and repair F‑01 only

The review’s finding is decisive and narrowly scoped:

```text
R6_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_BLOCKED
```

The current contract is already correct. **Do not amend the contract, migration map, or governed pair.** The defect is that the generated prefix evidence violates the existing R9.21.3 prohibition.

Every `P01`, `P02`, and `CLOSE` profile commits to the full POSITIVE-core digest:

```text
62dd674ff6026f0a31ac5d3e80d9c316f38fe0a7b8ca6410b64e4d8c7b923da3
```

It occurs in:

- decoded prefix core: `projection_origin_sha256`;
- prefix confirmation:  
  `preserved_r26_g06_confirmation_identity.observation_body_sha256`.

The entire historical identity object should be removed from current prefix confirmations—not merely its `observation_body_sha256` leaf. Otherwise the next reviewer may reasonably ask whether its carrier and manifest hashes still transitively commit to the full positive evidence.

### ES_R6J_F01_PREFIX_HASH_BINDING_REPAIR_HANDOFF_20261025_05.zip[Download the F‑01 repair handoff](sandbox:/mnt/data/ES_R6J_F01_PREFIX_HASH_BINDING_REPAIR_HANDOFF_20261025_05.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_F01_PREFIX_HASH_BINDING_REPAIR_HANDOFF_20261025_05_VERIFICATION.json)

```text
Bytes:             16,794,155
Members:           40
SHA-256:           04b4b689be429dd2fd1c309a8a4d109b7d46fe1c509f2f19416efa12bf8fc512
Verification:      PASS
```

The handoff is self-contained. It embeds:

- the exact rejected owner;
- its direct connected checkpoint;
- the complete F‑01 blocked review;
- current POSITIVE/P01/P02/CLOSE G/B/confirmation;
- the contract, map, pair record, reader, active-map reconciliation, package binding and controls;
- the governing decision and complete owner task.

No additional upload is needed for this repair.

## Selected correction

For `P01`, `P02`, and `CLOSE`:

1. Remove `projection_origin_sha256` and `projection_origin_use` from the decoded prefix core.
2. Remove `preserved_r26_g06_confirmation_identity` entirely from the current prefix confirmation.
3. Do not replace either with another digest, pointer, carrier identity, manifest identity, or indirect reference to the full positive core.
4. Keep historical provenance only in immutable owner-history artifacts that the current reader does not consume and current profile evidence does not reference.
5. Preserve the POSITIVE profile unchanged; it is allowed to contain the complete accepted core and historical identity.
6. Add profile-specific exact schemas and an explicit refusal such as:

```text
PREFIX_POSITIVE_CORE_HASH_BINDING
```

The reader should compute the current POSITIVE-core digest and reject its occurrence anywhere in a prefix’s parsed B, decoded core, confirmation, or decoded G members.

### Pair and rebinding boundary

The following remain byte-identical:

- `TEMPORAL_CONTRACT.md`;
- `TEMPORAL_CONTRACT_MIGRATION.json`;
- `PAIR_IDENTITY.json`;
- the 421-operation / 179-resource universe;
- POSITIVE G/B/confirmation;
- accepted source and candidate semantics.

Therefore the authoritative framed pair stays unchanged.

The repair must nevertheless regenerate every dependency of the three changed prefix profiles:

- prefix core and G members;
- B and confirmation;
- member manifests;
- all current profile bindings in the 429 active records;
- binding-record hashes;
- active-map reconciliation;
- package binding and core manifest;
- checkpoint, controls, results, reconstruction and owner manifest.

## Message to send

Send the ZIP to the **same ChatGPT artifact-owner conversation that produced the rejected whole-R6J owner**, not Codex or the independent reviewer:

```text
Repair F-01 under NEXT_OWNER_TASK.md.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md,
receiving/RECEIVING_INSPECTION.md,
receiving/POSITIVE_CORE_BINDING_ANALYSIS.json, and the complete blocked
review before authoring. Authenticate the embedded rejected owner,
checkpoint and review.

Keep the normative contract, migration map, pair identity, fixed universe
and POSITIVE profile byte-identical.

For P01, P02 and CLOSE:

- remove projection_origin_sha256 and projection_origin_use from each
  decoded prefix core;
- remove preserved_r26_g06_confirmation_identity entirely from each current
  prefix confirmation;
- do not replace those fields with another hash, pointer, carrier identity,
  manifest identity or indirect full-positive reference;
- retain historical provenance only in immutable owner history that is not
  read or referenced by current prefix G/B/confirmation.

Update the reader to enforce closed, profile-specific core and confirmation
schemas. Compute the current POSITIVE-core digest and deliberately refuse
any occurrence of it in parsed prefix B, decoded prefix core, prefix
confirmation or decoded prefix G members.

Preserve the POSITIVE profile’s permitted full core and historical identity.

Rebuild all dependent prefix, active-map, package, checkpoint, control,
result, reconstruction and manifest bytes while keeping the governed pair
unchanged.

Save and reopen a substantive checkpoint before broad execution. Include
the corrected current profiles and six fully rebound F-01 controls:

- a positive-core digest graft into the decoded core of P01, P02 and CLOSE;
- a historical-identity/digest graft into the confirmation of P01, P02
  and CLOSE.

Each control must pass unrelated pair, profile, graph and map bindings and
refuse specifically at the F-01 predicate—not through a stale hash,
unexpected key error or later map mismatch.

Rerun all 35 historical and 32 existing current controls plus the six new
controls twice on one final reader/input generation. Preserve actual
commands, stdout, stderr, exits and reached predicates.

Provide exact rejected-owner-to-successor and R26.G06-selected-tree-to-
successor reconstruction with wrong-before, wrong-removed-span and
wrong-after guards.

Do not launch Codex, access repositories or hosts, execute uploaded
programs, amend the normative pair, expand general joins, implement runtime
code, create an implementation handoff or claim independent acceptance.

Return only:

OWNER_R6_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW
```

## Required next sequence

```text
F-01 corrected owner
→ fresh artifact-only whole-R6J review
→ implementation decision
→ only then consider a regenerated Codex implementation handoff
```

The review accepted R6J‑01, R6J‑02, R6J‑03, and R6J‑05 through R6J‑08. The owner should not repeat those constructions. It should update the R6J‑04 and R6J‑09 closure records only after the corrected bytes and discriminating controls exist.

**Sources:** ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_BLOCKED_20261025_02.zip[F‑01 blocked review](sandbox:/mnt/data/ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_BLOCKED_20261025_02.zip); ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW_20261025_03.zip[rejected owner](sandbox:/mnt/data/ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW_20261025_03.zip); exact current contract, profiles and reader embedded in the repair handoff.

**Confidence:** **0.999** in the current-byte defect and package identities; **0.98** in the narrow no-pair-change correction. Successor correctness and independent acceptance remain unestablished.
