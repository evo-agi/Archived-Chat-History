**The stop decision was correct. The next step is a one-file test-fixture repair, followed by a fresh AMD64 → ARM64 validation attempt—not another environment-preparation cycle.**

I checked the reported cause against the supplied source. The fixture defect is sufficiently grounded to proceed with that bounded repair. The actual Linux results and preservation claims remain **Codex-reported**: this turn supplied the report, not the review ZIP or original test stream. :chatgpt-content-reference{index="0"}

**Send this to the existing Codex conversation: :chatgpt-content-reference{index="9"}[Fixture repair and native revalidation prompt](sandbox:/mnt/data/ES_Native_Linux_Fixture_Repair_and_Revalidation_Prompt.md).**

## What the failure establishes

The reported run reached the native Linux admission suite on the intended AMD64 environment. All staging-custody tests passed, including the Linux no-follow/no-replace and actual procfs mount-crossing tests. That is useful bounded runtime evidence; it does not make the complete candidate pass. The suite still failed, and ARM64 correctly remained untested under the sequential gate. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The **12 failing test paths are consistent with a shared fixture failure**, not twelve independently established production defects. The source chain is concrete:

| Supplied source | Finding |
|---|---|
| `es/admission/workstream_c_guardrails_test.go:5763–5795` | The shared helper creates physical staging/results directories but still sets `RuntimeSupportBinary` to `/bin/sh`. |
| `es/admission/resolved_execution_plan.go:479–486,593–598` | Submit captures that file before reaching the later assertions and maps capture failure to `stage artifact payload failed`. |
| `es/admission/staging_custody_linux.go:7–16` | The production open helper explicitly requests `RESOLVE_NO_SYMLINKS`. |
| `.docs/system_overview/configuration.md:379–387` | The configured runtime-support source must be a stable, no-follow, single-link regular file. |

Those source observations align with Codex’s reported `/bin` and `/bin/sh` symlinks. The report appropriately limits its attribution to source-and-environment evidence rather than claiming syscall tracing. The exact inspected excerpts are in the :chatgpt-content-reference{index="10"}[source review](sandbox:/mnt/data/ES_Native_Linux_Failure_Source_Review.md). :chatgpt-content-reference{index="3"}

I should have caught that remaining `/bin/sh` dependency in the earlier fixture-portability review. Fixing the temporary directories did not remove the shared helper’s dependency on the host filesystem layout.

One coverage distinction must survive the repair: **zero skips did not mean complete required execution**. The control-plane golden failed before its eight negative-control subtests, so those tests were absent, not passed. The next run must demonstrate their explicit execution and success. :chatgpt-content-reference{index="4"}

## The repair should remove the host dependency

The selected repair is to make `newWorkstreamCTestService` create a small, deterministic runtime-support fixture in its **own physical temporary directory**, outside both staging and results roots.

That follows patterns already present in the supplied tests: `service_direct_test.go:70–84`, `writablestate_readiness_test.go:17–35`, and `resolved_execution_plan_test.go:632–674` create test-owned regular files for runtime-support validation or capture. These tests do not need `/bin/sh` to serve as an actual runtime supervisor. :chatgpt-content-reference{index="11"}[Source excerpts](sandbox:/mnt/data/ES_Native_Linux_Failure_Source_Review.md)

The prompt therefore confines repository changes to **`es/admission/workstream_c_guardrails_test.go`**: repair the helper and add a focused regression that captures independently specified fixture bytes through the unchanged production function.

It does **not** permit replacing `/bin/sh` with `/usr/bin/dash`, resolving a system-shell path, changing production custody, adjusting the literal goldens, or weakening error assertions. The point is to give the existing contract valid, self-contained test input—not make the contract accommodate an unsuitable fixture.

### The GOENV issue is separate

The external harness’s incorrect expectation should also be corrected, without rewriting its historical output. Published Go source supports the distinction in the report: the configuration function returns an empty environment-file path for `GOENV=off`, and `go env` exposes that computed path rather than simply echoing the process variable. This corroborates the explanation, but does not independently authenticate the installed Go 1.26.5 binary. :chatgpt-content-reference{index="5"}

The next harness will record the requested child environment separately from selected `go env -json` output. It must distinguish an **explicit empty value** from a missing key or missing evidence. The old `go_environment_passed=false` record and failed suite remain unchanged; correcting the predicate does not turn that run into a pass. :chatgpt-content-reference{index="6"}

## How the next task advances

The prompt combines repair and revalidation, with a firm boundary between them:

1. **Authenticate and repair locally.** Codex checks the retained raw failure evidence and unchanged opening candidate, makes the one-file repair, and runs the complete local admission suite.
2. **Freeze the repaired candidate.** It records the exact repair diff and new source/candidate identities, proving that the other 351 source files remain unchanged. After this point, no further source edits are authorized.
3. **Run AMD64, then ARM64.** Each receives the same frozen candidate and one complete native admission-suite attempt. An AMD64 failure stops the task without starting ARM64. Both must pass the preserved and expanded required-test inventory.

This avoids an extra handoff merely to approve running the already-defined validation after a successful local repair. It does not combine implementation with independent audit.

The prompt also preserves the installed environments and maintenance assets, retains the original failure evidence, and requires a compact returned packet containing the repaired file, repair diff, manifests, and test results. A new full-repository suite and race run are explicitly **not rerun in this localized repair scope**; their previous results must not be presented as validation of the new bytes.

**Successful completion leads to the separate final combined read-only audit. It still does not authorize staging, commit, publication, or deployment.** The report itself preserves that boundary, and the supplied `PLANS.md:387–397` retains native validation before the final combined audit and commit. :chatgpt-content-reference{index="7"}

**Sources:** attached validation report; supplied ES archive, with inspected excerpts linked above; published Go source for the GOENV distinction. No repository tests, remote commands, or VM operations were performed here.

**Confidence:** source-packet identity **0.99** for the inspected members; fixture-repair direction **0.96**; native attribution and preservation **0.88**, pending inspection of the raw execution evidence. Overall candidate correctness remains unestablished.
