ES mounted-helper — episode ownership, exact delivery, and receiver repair
Objective and authority
Use the existing implementation/preparation Codex conversation, not an audit conversation. Be the sole writer of one fresh external successor. Repair LNX-LIFE-01…04 and TPA-01…05 together, retain the incomplete historical evaluator-invocation record honestly, and produce completely recorded new-source validation for a subsequent independent review.
The latest audit endpoint remains ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REAUDIT_INCOMPLETE. Its essential invocation-history gap and its nine independently blocking source/interface defects are separate facts. Neither finding recovery nor a new evaluator invocation can make the rejected source adequate. Do not relabel the historical endpoint, manufacture missing records, or run another audit of unchanged source merely to repeat its block.
This prompt authorizes ordinary-user LOCAL external source/document/test repair, offline tooling tests/builds, and ordinary task-owned temporary-file controls. It authorizes no ES repository mutation or test, network/SSH, host discovery, privileged entry, device access/ioctl, namespace operation, mount, formatter, credential transition, service/container/VM activity, administrative approval, installation/import, mounted proof, or Git mutation. Compiled Linux supervisor/safe/proof artifacts remain data, not executables to invoke in this task.
Before implementation, document the selected owner/effect/delivery/receiver path and exact touched set. Proceed within this task when it is consistent with the decisions below; do not return another general design-only proposal. A genuine unresolved authority/design conflict must be reported rather than silently decided in code.
Success endpoint:
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIRED_LOCAL_VALIDATION_COMPLETE_REAUDIT_REQUIRED
Use it only if all nine current defects have source-level repairs and the required composed controls and newly recorded final validation pass. Otherwise use ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIR_OR_VALIDATION_BLOCKED, preserving partial work and exact remaining causes. This is engineering validation, never independent closure or privileged suitability.
1. Authenticate the inputs; preserve ES
Latest independent audit
Root: /Users/ds/Downloads/ES-mounted-helper-terminal-lifecycle-reaudit-2aZ9ECLy
Artifact	Expected identity
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_CUMULATIVE_REAUDIT_REPORT.md	26,007 bytes; SHA-256 670d4e83214e6a0d24637fad9829006c17ffd87d8e5cf6672237ed77597763a8
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_CUMULATIVE_REAUDIT_PACKET.zip	204,145 bytes; SHA-256 c38a8baa8f589dba519da3c8da92e215b3d51437f279a3ed472750ce107cf84e
FINAL_ARTIFACT_IDENTITIES.json	3,039 bytes; SHA-256 ae79d507f4bfaedf0eb93cb9934121cfa0b6c9fb647d627ef0f93c02528b96cc


Read all three actual specialist reports and the relevant excerpts, not only the parent summary. In particular read records/EVALUATOR_INVOCATION_EVIDENCE_GAP.md, records/TERMINAL_GRAPH_RECEIVER_ADJUDICATION.md, records/FINDINGS_LINEAGE_50.md, and excerpts/LIFECYCLE_LINUX_MATERIAL_SOURCE_EXCERPTS.md. Follow verified packet paths for other records; do not invent paths or missing source.
Current rejected source
Root: /Users/ds/Downloads/ES-mounted-helper-terminal-lifecycle-repair-B19bsGkZ
Artifact	Expected identity
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REPAIR_REPORT.md	14,957 bytes; SHA-256 649a2dac99ed315cddae0c991935de1491bb454d48307a93b2984304dfedcb45
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REPAIR_PACKET.zip	1,221,421 bytes; SHA-256 29abfa2c902e88494f63d53af6ad9dc7c6430350e15f8b02814a17f7c3fa0969
FINAL_ARTIFACT_IDENTITIES.json	3,047 bytes; SHA-256 bde93300776f96415cec8edf47369c8dd858db85b3375f86fcbc2ee3bdff959f
Packet manifest	382 payload rows, 75,146 bytes; SHA-256 d6057a3e00a671525492f090c702dcc4633d4f2f721b55cb65c98373d05109f1; 383 ZIP members including manifest
External source manifest	102 regular members, 15,760 bytes; SHA-256 e72db661c908493d82c41f6f8f2d29c374ec2f35a4338549fc410f3274fbbf4b
Rejected supervisor A/B	6,175,611 bytes each; SHA-256 7ea169f753c97b10a0d82e67c37608624b55b325bb2c3bb709b2b773ef607840; never executed


Authenticate safe unique normalized relative paths, physical regular types, sizes, digests, CRC, permitted modes and complete self-excluding coverage before extraction. Distinguish authoring, ZIP and private extraction modes. All authoring goes into a fresh owner-only external root under /Users/ds/Downloads; never modify or chmod historical roots. Read authenticated material as needed; do not repeatedly rebuild the entire history.
The ChatGPT review verified the attached audit report only, not the ZIP or source bodies. Its directions below are engineering decisions, not an independent source audit.
ES: strictly preservation-only
Physical root: /Users/ds/Repositories/Execution Substrate
- Branch/upstream: trunk_dev / origin/trunk_dev.
- HEAD: b92bd9884106154d25342e1573dcc4c312311436.
- Tree: cdd4e44bac15c1952d70997143040644361f0bb1.
- Source: 358 rows; e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e.
- Candidate: 83 rows; 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2.
- Status: 83 rows; a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c.
- Tracked diff: 2,407,274 bytes; 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1.
- Index: 39,949 bytes; 9ca13234f248fccb29e8136168bb577c49c3fcf3c23b3f0d23b2bc1bd3aac569.
- Zero staged/conflicted paths; no active operation; six worktrees.
Read current AGENTS.md, latest relevant PLANS.md, configuration/capability and execution-lifecycle owning docs. Repository contracts own ES facts; external fixture documents own only this selected proof component. Do not restore an old milestone sequence or infer that CP's compatibility role is a permanent architectural authority.
Capture opening/closing source, candidate, status, tracked/cached diff, index, refs, worktrees and branch/HEAD/tree/operation records using the inspected retained read-only provenance method. Disable optional Git locks, fsmonitor, external diff/textconv/filter execution; inspect relevant config/attributes first. Do not run repository scripts, hooks, tests, help paths, fetch or writes. Disclose exact historical app-owned same-object ref-name churn; it does not waive arbitrary drift. Task opening-to-closing differences require explicit classification and block claims of exact preservation.
2. Record integrity without historical reconstruction
At opening, perform one bounded search for the two missing original evaluator invocation records, current selected-build-input record and attempt-01/02 fixture bodies. Search only the named engineering root, its authenticated package records, and explicitly referenced retained record locations. Do not search private shell histories, unrelated chats, telemetry, credentials, or broad filesystem history.
If genuine records exist, preserve their bytes in a separately identified supplement with actual source location, discovery provenance and consistency checks. Do not rewrite the prior packet/manifest or claim discovery retroactively changed the audit. If they do not exist, record that limit and proceed with the source repair: do not recreate argv/timestamps/exits from memory, the plan or stdout. A new invocation is new evidence, not recovery of the old call.
Retain the independent auditor's recomputation as an independent retrospective decision over authenticated data. Do not present it as authentication of the owner's historical invocation. Likewise preserve authenticated original test streams as historical observations; do not relabel them failed tests because the evaluator records are absent.
The predecessor attempt-01/02 results establish only build-collision and AST-panic harness failures at their available evidence level. Correct successor descriptions that credit all eight findings to those attempts. Attempt 3 has a retained fixture and distinct credit. Preserve every historical document unchanged.
This continuation deliberately does not make recovery of unavailable predecessor invocation history a prerequisite for acceptance of independently complete NEW successor validation. The old audit remains incomplete as history. Any evidence inherited as load-bearing for the successor must have its own adequate binding; otherwise produce new evidence within the authorized scope or report the dependency blocked.
3. Frozen operating decisions for this repair
Retain the finite supervisor / namespace-worker / candidate / adjudicator model, original topology/case count, selected target, resource ceilings and no-foreign-cleanup rules. Do not add a daemon, database, general recovery system, allocator/lease/provisioner, gateway implementation, watchdog implementation, signing service, new dependency or cross-repo component.
Before writing code, document one actual path:
validated entry intent -> episode owner -> partial acquisitions -> cases -> bounded cleanup -> frozen operational outcome -> published bundle + exact receipt carrier -> independently supplied receiver context -> decision
Identify the actual source caller for each edge, authority before each effect, minimum independently provided input, expected descriptor/object identity, failure/residual owner, and evidence emitted. No positive test may silently precreate a child directory, inject completed identity facets, or manufacture trust that the declared actor is supposed to establish.
Keep the repaired ledger tail/freeze/acyclic graph, exact-once close, exact association check, and role-bound PV-01 predicates unless a demonstrated integration dependency requires a precise change. Do not refactor unrelated working surfaces to match a new vocabulary.
4. Lifecycle repairs: LNX-LIFE-01…04
A. LNX-LIFE-01 — one episode, cancellation and original deadline owner
Bind the exact validated episode and relevant approval/source/target context, original typed monotonic-capable deadline, active cancellation and terminal cancellation observation in one internal owner before deliberate task effects. Display strings remain evidence only. An independently supplied operations.Episode cannot relabel an outcome; reject mismatches before effect dispatch and again before terminal use.
Check already-canceled/expired entry before creating/appending the ledger, making run/export directories, changing deliberate process settings, or dispatching setup. Preserve the existing raw-FD validation ordering; do not reintroduce timers/poller setup before raw entry inspection. Runtime startup itself is not claimed to be effect-free. Read-only input qualification does not confer mutation authority.
Active phases retain cancellation; cleanup/evidence reserves are explicitly bounded exceptions established by the original owner. Cancellation after the operational controller returns must still reach final classification and receiver-visible state. Do not create a fresh owner or renew a budget during finalization.
Controls must traverse the real composed entry/owner/caller path under substituted low-level effects: pre-canceled entry with zero deliberate writes/dispatch; wrong nonempty episode; cancellation at entry, after an acquisition, between controller return and freeze/publication, and before receipt delivery; expired owner and display-time changes. Specify exactly which cleanup-only work remains permitted and why.
B. LNX-LIFE-02 — destruction consumes original held custody, not a newly adopted pathname
Carry the independently saved expected parent/root identity into descriptor acquisition, or transfer the already-held qualified descriptors to the remover. Verify the acquired descriptors against those expectations before the first removal. A fresh observation cannot replace the expected identity merely because it occupies the same name.
Use descriptor-relative postorder removal under that authenticated custody. Recheck the original parent/name relationship where needed for root unlink. If the original has moved, a replacement is present, or the old name disappears while the owned object may survive, stop destructive work and retain explicit residual/uncertainty; do not scan for it, adopt a replacement, or declare owned-object absence from pathname ENOENT alone.
Add ordinary-file tests using the actual acquisition/remover path: rename-away, replacement-at-name, parent replacement, missing name with still-held original, plus the existing first/middle/final Nth-removal and failed follow-up-inventory controls. Sentinels in replacement/outside trees must be independently specified and untouched. Do not claim protection beyond the selected trusted-parent/concurrency contract; expose any remaining check/effect limitation.
C. LNX-LIFE-03 — partial identities are recorded by the real acquisition producer
Update known process, start, pidfd, namespace, channel, group and descriptor facets immediately as each is learned, before the next fallible operation. Error returns must contain all then-known facets; the controller absorbs them before error or ledger handling. Do not test this solely with a fake that returns a fully qualified identity the real producer never recorded.
Final residual records derive from actual custody/release observations, not hard-coded released values. Unknown/release-uncertain states remain distinct. Numeric descriptors/PIDs in evidence do not grant later targeting authority.
Extract only the minimum shared control sequence needed to test the same worker/formatter/candidate producers with syscall/process effects substituted. Exercise each post-start/pre-facet and post-facet/pre-next-operation failure followed by a second ledger, cleanup or inventory failure. Inspect all Linux-selected callers and early returns; include exact final facets in assertions, not only booleans/counts.
D. LNX-LIFE-04 — signal authority is not renewed on cleanup reentry
Define per-subject/action authority before process creation/termination: exact episode and retained subject, expiry and cancellation/revocation rules. Cleanup reentry may not replace an expired signal decision with a later detached context. Recheck authority immediately before TERM/KILL on formatter, worker and candidate paths, including timeout arms, force-close paths and deferred cleanup.
Reserve contexts can authorize their already-defined observation/evidence/owned-FD operations, not silently regrant revoked signals. Once internal containment authority is exhausted, preserve identities and unresolved state for the separately established external owner. Do not leave an old policy ambiguous about this: update docs/tests and all callers together without implementing that external owner.
Required composed tests include setup termination expiry followed by cleanup reentry; worker ctx.Done and force-close paths; candidate timer-arm expiry; cancellation between readiness and dispatch; plus valid in-budget containment. No actual signal experiment or privileged child is authorized here. Preserve the check-to-syscall scheduling qualification; do not claim atomic preemption.
5. Producer, carrier and receiver: TPA-01…05
A. TPA-01 — establish the actual export parent
The live selected <ScratchBase>/exports/<episode> path currently requires an uncreated parent. Specify and implement the exact owner and stage that establish each required directory beneath an already independently approved base. Use held/no-follow/exclusive identity-bound custody and recorded permissions; do not blanket-create/chmod/adopt pre-existing ancestry.
Choose one finite source-defined directory layout in the doc-first pass. A parent that is genuinely an upstream prerequisite must be explicit in the input contract and checked before operations, not a hidden positive-test setup. The helper-created export children must actually be created by the tested caller. Keep export/receipt storage disjoint from removable run scratch and account for their retention and byte limits.
Start composed positive tests with only the explicitly documented independent base/inputs. Do not precreate exports or the episode directory behind the caller's back. Cover absent, conflicting, replaced, wrong-owner/mode/type and unwritable parents and intermediate creation failure.
B. TPA-03 — persist an exact receipt carrier without broadening entry FDs
Retain privileged stdin/stdout/stderr as /dev/null; stdout is diagnostic only, not the receipt carrier. Use one explicitly specified, exclusively created, bounded receipt object in held episode-export custody outside the already sealed bundle. Pin its name/location in the delivery contract and independent receiver expectations. It is additional finite evidence, not a new service or generic transport.
Freeze the exact receipt bytes once after the observations they describe. Persist those same bytes under the original authority/budget. The receipt cannot attest its own future write/sync/delivery success. Keep carrier completion/error observations separate; partial, missing, late or uncertain receipt publication cannot become a valid receipt by reserializing an in-memory equivalent. No overwrite/retry of an uncertain published object, recursive receipt chain or hidden stdout fallback.
The next actor reads the actual carrier bytes and binds their digest. Tests must obtain them from disk/custody, not by passing the producer's returned struct directly. Confirm receipt digest equality, path/object binding, duplicate refusal, truncated and partial-write rejection, cancellation/deadline behavior and bounded failure closeout. Failure to deliver is a failed/incomplete episode, not a reason to invent a receipt.
C. TPA-02 — independently supplied receiver trust and expectations
The receiver gets its approved expectation set and trust policy from an independently provisioned caller/entry context, never from the candidate export, receipt or confirmation itself. Specify the actual interface, construction boundary and enforcement points. Bind at least protocol/schema/domain, exact episode, approved subject/target/source/supervisor/proof identity, export/base/parent/object identity and ownership/modes, applicable policy, original authority/deadline, and normal versus diagnostic scope.
Raw confirmation bytes have no authority because their digest matches. Define authentication against an independently pinned issuer/verifier/policy and semantically bind the exact receipt and export to the required pre-effect ownership/containment and terminal observations, operational outcome and residual disposition. The alleged issuer or a verified=true field inside evidence cannot select its own trust root. A verifier error, missing trust, wrong key/issuer/phase/target/source/episode/export or stale/substituted receipt refuses.
Do not install a signer, create a production key, implement a gateway/watchdog, or make a synthetic test fixture a real approval. The trusted verifier boundary may be dependency-injected only from independently configured code/context; its live unestablished state must fail closed. Specify the missing establishment mechanism concretely enough for review, without asserting it exists. Positive tests use visibly synthetic, independently fixed trust/expectations, with negative attacker-controlled confirmations and contexts. A raw test helper computing a matching digest is not a positive authentication control.
One already-qualified independent parent could eventually supply several observations; no permanent confirmation service or per-case human-approval requirement is selected here.
D. TPA-04 — the receiver checks semantics as well as integrity
Decode the exact operational-outcome schema and explicitly adjudicate all source-defined success requirements: Primary/Cleanup/Inventory, OperationalComplete, original deadline/containment requirement, scratch disposition, resource/descriptor residuals and uncertainty, cancellation/revocation, exact applicable residual policy, case evidence and failure-closeout consistency. Map required fields and provenance in one table. Do not hard-code a target test count or allow unknown status to default to success.
A matching authenticated confirmation is necessary evidence where the contract requires it, not permission to override an operational failure, unresolved cleanup, missing case, cancellation, unapproved residual or late/partial publication. The exact policy for a possible unbound loop object remains unapproved in live use. Synthetic acceptance under a fixed test policy must be distinguished from real residual acceptance; never require host-global absence if the contract explicitly permits a separately approved, recorded possible effect.
A blanket confirmation cannot stand in for actually observed containment or mutate the producer's frozen outcome. Resolve any split between helper-observed deadline fields and external observations explicitly in the normative predicate; do not set a boolean true to create a positive test. Preserve failure evidence, but do not accept it as a successful proof.
Add well-formed, fully rehashed adversarial graphs whose only change is each failing semantic field. Include genuine failing Primary/Cleanup/Inventory, incomplete operations, missing scratch removal, unknown/unapproved residual, cancellation, false/missing deadline observation, contradictory failure closeout and normal failure plus successful diagnostic. All must reject even with a synthetically authenticated matching confirmation.
E. TPA-05 — expected object custody is external to the selected tree
Receiver acquisition must use the approved expected base/parent/export/receipt path and object relationships from section C. After no-follow held acquisition, compare the SAME descriptors to independently expected identities, uid/gid/modes and episode/source/target, then use them for reading/verification. Self-consistency between an envelope and a caller-selected user-owned tree is not approval.
Test a copied/rehashed bundle under an unapproved parent, a user-owned substitute, wrong root identity/mode, pre-open replacement, post-open name substitution and correct-looking different-episode source. Do not weaken real ownership expectations for Darwin: a synthetic ordinary-user environment uses a separately declared test expectation profile and does not establish root-owned production custody.
6. Composition gate before broad final validation
The decisive test is a reachable producer-to-receiver path, not the number of helper tests. Construct it from the actual orchestration, identity-acquisition, publisher, carrier and receiver functions. Substitute only the low-level privileged/kernel effects and the independently supplied test trust/containment actor. Ordinary files, exact serialization, directory creation, receipt delivery and receiver reads are real task-owned filesystem operations.
Demonstrate all of the following before final freeze:
1. With only documented upstream test prerequisites, the caller creates its own export children, emits a complete normal synthetic outcome, publishes the graph and exact receipt, and the receiver accepts through separately fixed synthetic trust/custody/semantic expectations. No mounted or real authority claim follows.
2. The same complete path rejects each of the nine current findings' attack/failure cases. For source-exclusive Linux boundaries, use the minimum shared producer/control routine with an inspected actual Linux caller binding; explicitly label AST/source checks rather than claiming execution.
3. Pre-canceled entry produces no deliberate episode effect; cancellation after operations prevents success; expired signal decisions stay expired on cleanup reentry.
4. Actual rename/replacement and Nth-delete failures preserve original/foreign identities and leave explicit residuals; no pathname-absence shortcut declares an unaccounted held object destroyed.
5. Raw producer outcome, published artifacts and receiver decision remain consistent across partial acquire + bookkeeping failure, termination expiry + cleanup reentry, partial deletion + inventory failure, operational failure + valid confirmation, and successful operations + receipt-delivery failure.
Record which concrete function actually ran, which actor was substituted, original input and source binding, expected effect/order/state, observed evidence and remaining Linux-only obligation. Do not call a fake-returned complete identity or precreated export parent an integration test.
Use narrowly bounded predecessor negatives where safe. Preserve exact fixture bodies and command records for every attempt; compile/panic failures receive no finding credit. Do not rebuild a vast historical matrix or run privileged predecessor code. Do not add driver instrumentation or product hooks to make these tooling controls pass.
7. Writes, lineage and independent-review boundary
Author only in the fresh external successor. Expected surfaces are the current lifecycle/owner, live/worker/candidate producers, termination/custody, scratch remover, terminal publisher/receipt/receiver, corresponding tests, external authority/terminal/future-effect documentation/templates, and runner/evaluator/packager where required for exact invocation retention. Discover their actual paths in the authenticated source and freeze the minimal set before edits. Add small files only for the selected ownership/interfaces/controls, not a new framework.
Preserve the historical 50 rows and append LNX-LIFE-01…04 and TPA-01…05 as distinct rows: 59 lineage rows. Do not erase independent judgments with owner closure language. Carry the four narrowly accepted static predicates forward with their limits, verify interactions, and retain the historical F-12 disagreement and normal/diagnostic distinction.
The ES repository, internal/safemech, safe-control entry, module files, normal/diagnostic drivers/overlay and old inputs remain unchanged unless a precise, unavoidable dependency is demonstrated. A required safe-mechanics/product/driver change exceeds this repair's scope and must be reported rather than silently widening it. The known supervisor/receipt interfaces are within scope.
No active subagent during mutation; no independent audit in this task. Engineering source/diff inspection is permitted and must be labeled owner validation.
8. Exact new-source validation and command recording
Use the already installed pinned Go 1.26.5 executable:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
Expected executable SHA-256:
3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19
Before the first Go invocation, reuse the inspected isolated configuration/storage procedure. First invoke go telemetry off within task-owned configuration. Observe effective mode/directory and required keys; requested variables alone are insufficient. Preserve GOTOOLCHAIN=local, GOENV=off (effective empty), GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, existing authenticated read-only module cache and task-owned HOME/config/cache/temp/GOPATH. Do not alter user global state or inspect historical telemetry. No dependency downloads or installs.
After composed development controls pass, freeze source/delta, full and selected build-input manifests, requirement inventory, plan, runner and evaluator. Derive the CURRENT selected build inputs from the actual selection recipe; do not refer only to the broader complete-source manifest or a stale predecessor record. Record modes and bytes, recipe and executable identity. Linux-selection metadata is static evidence, not runtime validation.
From the new external tooling directory, run sequentially with complete argv/cwd/env records:
"$GO" version
"$GO" env -json <the exact frozen allowlisted keys>
<pinned gofmt> -d <exact changed Go file list>
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" env -json <exact frozen keys>
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o <supervisor-A> ./cmd/es-mounted-proof-v2
<identical deterministic recipe to supervisor-B>
<retained exact safe build recipe to fresh safe-output>
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" list -deps -f '{{.ImportPath}}' ./cmd/es-mounted-proof-safe-controls
"$GO" version -m <each newly built artifact>
Resolve placeholders to absolute explicit argv in the frozen machine plan before invocation. Reuse the exact safe recipe, including any existing fields omitted from the schematic above; do not silently rebind historical evidence to a new command. No supervisor/safe/proof binary runs.
Independently derive run/pass/skip/fail/package/incomplete identities from the streams. Preserve previous applicable requirements and add named direct/composed controls for the nine findings; do not use 530/269 as the success oracle. Missing applicable tests, test failure or unexplained skips block. Package-level no-test terminals remain distinct.
Record evaluation itself
The external recorder must capture EVERY evaluator and package-verifier invocation, including rejected argument/preflight calls: exact executable/script bytes, absolute argv/cwd, relevant environment, start/end, exit, timeout, actual stdout/stderr and hashes, input bindings, output identity and whether any decision was produced. Plans, prose and output bodies are not substitutes. Exercise the recorder on rejected-arguments and success cases before final evaluation. The recorder is external to the evaluated predicate; no evaluator validates the existence of its own future completed record.
Retain the exact versioned evaluator source for every credited or superseded decision. Separate its decision-input manifest from later invocation/output/packet records to avoid a self-dependency. Include the original selected-build record, raw tests, evaluator input set, invocation and decision in the new packet.
Permit ordinary in-scope development repair before freeze. On a final-generation failure, stop dependent lanes and preserve everything. At most one corrected successor final generation is allowed for a causally demonstrated in-scope defect; changed source needs new affected tests/builds and exact identities. A pure evaluator defect may replay authentic unchanged execution with a separately recorded evaluator version/invocation; it cannot reinterpret a failed test as pass. Further failure returns the blocker; no indefinite audit/retry loop or invented history.
9. Selective reuse and preservation
Authenticate inherited artifact bodies as data, with their selected input bindings:
- Safe executable: 4,497,174 bytes; c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75.
- Safe selected import closure: 2,023 bytes; 739a10de46f4ccf3e2d341d764d651c80462c9cde53c1e6d4726c1c4c1adbbe3.
- Normal proof: 23,583,914 bytes; bc4ff667d9280ee8ec671fc60bc23ec4e32e256b5084436588bcfb78292f4d0d.
- Diagnostic proof: 23,605,547 bytes; e2fc7baf9a7a9286f97dc3dbb95b74bba44c0b1d14d75c544b1f466d3d81edfb.
A byte-identical safe rebuild and selected-source/dependency closure permit inheritance of its seven authenticated ordinary-user Linux observations. No remote replay is authorized; those observations never validate changed internal/proof. Unexpected safe/build drift is a blocker to inheritance, not permission to transfer another executable.
Normal and diagnostic artifacts remain unchanged compile-only history; do not rebuild them when their effective inputs/recipe binding remain identical. The diagnostic overlay is different effective source and historical absolute paths are build provenance, not a portable current recipe. No ordinary or mounted ES suite is rerun.
Preserve old failures, missing-history qualifications and all original artifacts. Clean only exact task-owned temporary trees whose identities and absence of use are established; retain evidence/binaries/configuration storage under explicit classifications. Do not clean old roots, devices, user caches or global configuration.
10. Deliverables and final decision
Return one complete new engineering report and a directly inspectable compact ZIP plus an acyclic external final-identity record. Include:
- complete current external source, incremental and cumulative delta bindings, source and CURRENT selected-build manifests;
- doc-first owner/effect/delivery/receiver specification and independently expected trust/custody/semantic table;
- 59-row lineage with precise owner status, direct source lines, controls and remaining obligations;
- all three actual latest specialist reports, source excerpts and audit conclusions unchanged;
- actual composed positive/negative controls, predecessor fixture bodies where used, exact raw records and all rejected attempts;
- original test/build command records and evaluator/verifier invocation records, raw outputs and decision; no missing selected-input serialization;
- new compile identities and unchanged safe/proof reuse bindings, provenance and temporary-state disposition;
- historical evidence-gap supplement or explicit absence ledger; no fabricated reconstruction;
- precise runtime/policy/establishment limitations.
Verify the final ZIP independently by reopening it, checking CRC/safe normalized path/type/mode/size/hash and exact self-excluding membership. Bind the report, manifest and ZIP in an external identity record after their bytes are final. Exclude binaries, caches, full ES unions, images, credentials, device contents and nested packet chains; retain binaries separately with exact references. Do not recursively require the verification record to certify its own final bytes.
Report exact touched paths, command results, source generation, any unapplied assumption or conflict, skipped execution, authority/security changes, effects, scope of source inspection, and separate provenance/validation/implementation confidence. Include the current ZIP and exact report for the subsequent independent reviewer; another standalone packaging tranche should not be necessary.
Still mandatory and unestablished: fresh independent successor re-audit; residual-policy establishment; independently trusted administrative entry and real approvals; target/formatter qualification; external hard-deadline containment and terminal confirmation; all normal/diagnostic mounted cases; running-deployment and supported-local consumer/operator evidence; unconditional whole-candidate ES audit; and separate exact-byte stage/commit authorization. This repair neither implements nor waives those gates. A future source change invalidates its source-bound acceptance, not historical observations themselves.
The goal is one reachable, internally coherent finite helper and complete NEW validation provenance. Do not use absence of future mechanisms to hide current interface defects, and do not build those future mechanisms merely to make this local task appear complete.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
