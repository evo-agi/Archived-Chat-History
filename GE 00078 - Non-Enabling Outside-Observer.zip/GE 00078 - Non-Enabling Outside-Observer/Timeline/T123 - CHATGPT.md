**CP04 contains real new draft work, but the correction is still incomplete. Missing inputs are no longer the problem; the unfinished work is integration and verification.**

I would **not** send another broad “finish everything” continuation. The next owner pass should complete one concrete authority-to-failure-record chain, with its actual map consumers and checked bytes. That gives us a substantive result to build on rather than another preservation-only checkpoint.

**Send this to the same ChatGPT design-owner conversation—not Codex and not a new reviewer:**

### :chatgpt-content-reference{index="1"}[CP04 inspection and focused continuation ZIP](sandbox:/mnt/data/ES_CP04_INSPECTION_AND_FOCUSED_CONTINUATION_20261011_01.zip)

It contains the inspection, exact comparison deltas, and `NEXT_OWNER_TASK.md`. No primary archives need to be uploaded again to that conversation.

## What I verified in CP04

The actual uploaded archive is internally consistent:

```text
ES_AR01_AR03_PAIRED_OWNER_DRAFT_20261011_02_CP04_b8d29e.zip
Bytes:   613,103
Members: 10
SHA-256: 57b7bf06518b73a0ed465a20bfc1c660a953782db7ad44201257bf91c0859234
```

All nine payload members match the self-excluding manifest’s sizes, hashes, modes, and CRCs. The selected map correctly binds the selected corpus.

| Selected member | Bytes | Change from the received six-member pair |
|---|---:|---:|
| Normative corpus | **197,105** | +51,802 |
| Full migration map | **1,709,707** | +55,568 |

The preserved received corpus/map are byte-identical to the previous six-member checkpoint. No recovery or historical reconstruction is needed to use CP04 as the latest draft.

**There is substantive new material.** The type dictionary grows from 21 to 29 definitions, adding the full run-approval/request/entry types, their object records, residual policy, failure cause, and `FailureCloseoutV2`. New R9.11–R9.14 sections address their relationships, chronology, and evidence limits. Both embedded transport/type tables exactly match their map copies.

The E51 and E53 families also contain changes to 13 existing nested records and eight additions. These are saved draft changes—not merely newly calculated hashes.

## Where the integration still stops

Compared with the received working pair, these collections remain unchanged:

| Collection | Unchanged records |
|---|---:|
| M migration rows | 30 |
| Prospective scenarios | 96 |
| Affected caller inventory | 176 |
| Owner classes | 54 |

The `authority_flow`, `source_projection`, and AR-01 relationship table also remain unchanged.

**Unchanged does not mean wrong, and those records should not be rewritten gratuitously.** It means the delivered increment does not itself demonstrate that the new definitions have been reconciled with those consumers. That is exactly the qualification in `CURRENT_STATE.json`.

The ten-member ZIP contains **no complete unissued authority/failure specimens, semantic conformance-result files, or A-to-final reconstruction**. The external final-verification file named in the relay is not included either; the measurements above are my new checks of the delivered object, not a reproduction of that external record.

I derived exact received-pair-to-CP04 comparisons: **51 map operations and 30 corpus hunks**, both replaying to the delivered bytes. They are included in the supplement as inspection artifacts—not recovered owner deltas or the eventual A-to-final reconstruction.

## Make the next pass constructive and bounded

The attached task asks the owner to finish this particular chain:

```text
Complete modeled run-v4 approval
→ exact request
→ exact entry observation
→ Q1 exchange and consumed F Open result
→ complete immutable failure-closeout prefix
→ Q2 challenge bound to that prefix’s actual bytes
```

This is a useful next slice because CP04 now contains the necessary proposed type definitions, but not the complete specimens or evidence that their consumers agree.

The owner must **reconcile the affected active map records while constructing the chain**. It must not produce another isolated encoding appendix and leave contradictory consumer rules untouched. The output includes a full paired corpus/map, the actual specimen files, a producer/consumer crosswalk, meaningful negative checks, and exact CP04-to-result deltas.

The decisive properties remain concrete:

**Every container digest comes from complete constructed bytes**, not a synthetic seed standing in for a missing approval or entry record.

**The failure prefix is fixed before Q2.** It cannot contain Q2’s later response, the Write result, later synchronization, or its own future completion.

**Negative checks must reach the intended semantic rule.** A wrong approval binding, swapped source order, contradictory acquired-file identity, or future fact in the prefix must not be rejected only because some unrelated hash was left stale.

Signatures remain visibly **unissued placeholders**. These are inert encoding and semantic checks—not cryptographic authentication, a receiver execution, or a mounted proof.

The existing full AR-01–AR-03 objective remains authorized. This partitions the work; it does not reduce its final acceptance criteria or add another independent-review gate between internal slices.

## Message to send

Attach the supplement to the **existing ChatGPT owner conversation** and send:

> Continue from the selected CP04 corpus/map, using the complete primary-input handoff already available here. Read `CP04_INSPECTION.md`, then execute `NEXT_OWNER_TASK.md`. Complete the bounded authority-to-failure-prefix slice with actual unissued specimens, reconciled active consumers, meaningful checks, a full paired corpus/map, and exact CP04-to-result deltas. Do not restart recovery or return an unchanged preservation packet as completion. Keep the remaining whole-correction obligations explicit. Do not launch Codex, access my repositories or hosts, execute uploaded code, or claim independent acceptance.

There is no reason to transfer ownership again or rebuild the complete-input bundle. I rechecked that bundle and its four primary archive bodies against their expected identities; they remain available.

**Independent review still waits for the complete successor.** The last completed artifact review’s AR-01–AR-03 block is not displaced by a larger draft or a passing manifest. :chatgpt-content-reference{index="0"}

### Sources and limits

The :chatgpt-content-reference{index="2"}[detailed inspection](sandbox:/mnt/data/ES_CP04_Integration_Direction_20261011_01/CP04_INSPECTION.md) records the actual CP04 members, comparisons, and limits. I inspected the selected new text and embedded definitions, but did **not** perform a complete semantic audit, validate the Linux/API choices, execute uploaded checkers, or change the design.

**Confidence:** **0.99** in the measured identities and direct comparisons. Integrated design correctness remains unestablished. The next-step recommendation is to replace another all-remaining-work pass with one demonstrably complete integration slice.
