**Retain the block. The next task is one bounded NRC-01–NRC-06 carrier repair—not complete-source integration or Codex implementation.** The review does not reject the flat same-record representation. It identifies missing checks within the language the carrier already promises to interpret.

### ES_R6J_NATIVE_RESULT_CARRIER_NRC01_NRC06_REPAIR_HANDOFF_20261020_08.zip[Download the self-contained NRC-01–NRC-06 repair handoff](sandbox:/mnt/data/ES_R6J_NATIVE_RESULT_CARRIER_NRC01_NRC06_REPAIR_HANDOFF_20261020_08.zip)

:chatgpt-content-reference{index="1"}[Completed handoff verification](sandbox:/mnt/data/ES_R6J_NATIVE_RESULT_CARRIER_NRC01_NRC06_REPAIR_HANDOFF_20261020_08_VERIFICATION.json)

Send this **single ZIP to the existing ChatGPT native-result-carrier owner conversation**, not Codex or the reviewer. It contains the exact owner and review archives unchanged, the original representation decision, the complete repair task, and my receiving-side evidence.

## What I verified

Both delivered archives match their reported identities:

| Artifact | Bytes | Members |
|---|---:|---:|
| Native-result carrier owner | 76,467,171 | 5,438 |
| Fresh blocked review | 1,697,478 | 65 |

Every payload in both archives matches its manifest, actual size, SHA-256, CRC, encoded regular-file mode, and safe unique path. I also authenticated the owner’s original decision envelope and first carrier checkpoint.

The current corpus/map pair recomputes correctly:

```text
8e62fd593a09bec807d954bec97b992b63a41186495e4e7f6bcdc356dcdd3838
```

I independently replayed the declared changes for **all eight review specimens**, reproducing their complete B and confirmation bytes from the owner’s positive. Their raw bindings and unchanged G references agree.

The decisive contradictions are present in those bytes:

- CE01’s custodian poll names **supervisor-owned** descriptors.
- CE02’s partial-output poll names a **nonexistent owner**.
- CE03 declares **zero Write-input bytes** against the actual **126,259-byte outcome**.
- CE04 declares slot invalidation before the subsequent poll and recvmsg dispatches.
- CE05 declares the freeze return after Write dispatch while retaining an earlier observation.
- CE06–CE08 contain the reported invalid origin, outside-source digest, and namespace string.

**I did not execute the uploaded reader.** The predicted old-reader classifications remain static findings; my checks establish the actual specimen relationships and relevant source paths. RECEIVING_INSPECTION.md[Receiving inspection](sandbox:/mnt/data/ES_R6J_NRC01_NRC06_REPAIR_20261020_08/package/receiving/RECEIVING_INSPECTION.md) · COUNTEREXAMPLE_CHECKS.json[Exact counterexample checks](sandbox:/mnt/data/ES_R6J_NRC01_NRC06_REPAIR_20261020_08/package/receiving/COUNTEREXAMPLE_CHECKS.json)

## Repair the validation structure, not just eight examples

The common defect is that **result interpretation sometimes controls whether invocation prerequisites are checked at all**. A failed or unavailable result can be valid evidence of a nonpassing call—but cannot make an impossible input, wrong owner, or unavailable payload valid.

The selected repair keeps those concerns separate:

| Finding | Required correction |
|---|---|
| **NRC-01 — poll custody** | Validate both exact session/peer owners, actor, role, descriptor, responsibility time, and usable lifetime for every supported result state—not only complete output. |
| **NRC-02 — Write input** | Establish the actual raw-G input, length/offset, wrapped target, and knowledge cut before interpreting success, error, short count, or unavailable return. |
| **NRC-03 — invalidation** | Reconcile ordinary uses against the entire admitted owner-slot lifetime, including invalidation reported by a later Close record. |
| **NRC-04 — freeze knowledge** | Validate the complete selected freeze pair and producer relationship before exporting a knowledge time to Write. |
| **NRC-05 — grammar/parsing** | Enforce origin-specific envelope rules and parse the exact namespace grammar before conversion or dependent use. |
| **NRC-06 — ingress** | Bound actual input acquisition before whole-file loading or parsing; retain separate credit for ingress, parser, and semantic checks. |

These are corrections to the existing carrier contract and its affected consumers. The task does not commission a new result family, evidence domain, authority, transport, or public receiver. REVIEW_REPORT.md[Full blocked review](sandbox:/mnt/data/ES_R6J_NRC01_NRC06_REPAIR_20261020_08/package/review/REVIEW_REPORT.md)

### Error evidence must retain valid invocation facts

For Write, the accepted source passes the actual payload to the operation **before** examining `writeErr` or the returned count. An error with count zero does not mean the supplied payload had length zero. The current reader’s success-only input join loses that distinction. ACCEPTED_SOURCE_WRITE_EXCERPT.md[Accepted-source excerpt, `terminal_protocol.go:637–663`](sandbox:/mnt/data/ES_R6J_NRC01_NRC06_REPAIR_20261020_08/package/receiving/ACCEPTED_SOURCE_WRITE_EXCERPT.md)

The repair must therefore demonstrate both sides:

> Correct invocation plus error or uncertainty → coherent nonpassing evidence.

> Contradictory invocation plus error or uncertainty → deliberate refusal.

The same principle applies to poll operands and other selected interfaces with input prerequisites. **Rejecting every adverse result would not repair the promised language.**

### Slot invalidation is not kernel closure

NRC-03 concerns whether the actor still possesses a usable owner slot when it dispatches an ordinary operation. It does not assert that the kernel had already closed the descriptor.

The complete account must reconcile responsibility, wrapper transfer, ordinary uses, invalidation, and the one consuming release. A later-observed invalidation cannot be ignored merely because earlier records saw `consumed=False`.

Conversely, C must retain its reviewed meaning: an existing release duty can survive ordinary cancellation or expiry without a fresh A/Q/status prerequisite. A failed or unobserved Close leaves uncertainty and a consumed slot—not retry permission. The repair must not fix ordinary-use timing by accidentally disabling inherited release.

### The freeze dependency cannot remain an unchecked legacy shortcut

The carrier’s Write depends on an earlier pure-G freeze result. That dependency is inside the carrier’s declared scope even though other general joins remain deferred.

The reader must validate its request identity, stages, return/observation relationship, actual G role, and producer completion before using it. Selecting the favorable outer timestamp while ignoring a contradictory declared return is not a knowledge-order check.

This does **not** require completing all publication chronology now. It requires validating the specific relationship the carrier already uses to support its Write.

## NRC-06 needs real ingress evidence

The existing caps remain unchanged:

```text
G raw evidence:  16,777,216 bytes
B:               16,777,216 bytes
Confirmation:        65,536 bytes
Combined:        33,554,432 bytes
```

The task also preserves the reader’s existing G-transport guard and distinguishes it from the uncompressed G evidence count.

**Testing an already allocated oversized buffer does not prove bounded acquisition.** The successor must exercise its actual entry path, recording bounded read requests and returned bytes, cap-plus-one refusal, and whether parsing began. G transport and member decompression, individual inputs, and the shared raw budget all need their appropriate checks.

The prior boundary set retains its documented credit: **four full-reader cases, eighteen component cases, and one syntax case**. Add the missing ingress evidence; do not relabel those component results as proof of it.

This remains inert artifact-reader work. No memory-pressure experiment, service, operational host, or runtime implementation is required. Nor should a raw-input cap be advertised as a universal Python heap guarantee.

## Preserve the originals and avoid stale-binding “repairs”

The eight review specimens remain immutable historical inputs. The original positive, registry, first checkpoint, controls, and retained results also remain preserved.

Where the existing normative rules already determine the required checks, there is no reason to rewrite the corpus merely to obtain a new digest. Where clarification is genuinely necessary, the owner must change the affected corpus/map and consumers together.

**Any new contract digest requires an explicitly rebound current authority/graph/body/confirmation counterpart.** Historical specimens may then need narrowly rebased current derivatives, but their adverse mutations must remain intact. Refusal caused only by an obsolete contract hash earns no NRC regression credit.

The first substantive repaired-reader checkpoint must be saved and reopened before expanding the controls. It should include the current positive, coherent nonpassing examples, and actual results for all eight counterexamples or their documented current counterparts—not just a plan or another authentication-only package.

## Message to send

Attach the single handoff ZIP to the existing ChatGPT carrier-owner conversation and send:

> Repair NRC-01–NRC-06 under `NEXT_OWNER_TASK.md`. Read `README_FIRST.md`, `DECISION_RECORD.md`, `INPUT_IDENTITIES.json`, the receiving inspection, and the complete fresh review. Authenticate both input archives and inspect the actual reader, registry, fixed scope, eight counterexamples, admitted G/B/C, and relevant source before authoring.
>
> Preserve the flat same-record carrier and its declared bounded language. Separate invocation prerequisites from result-state interpretation; reconcile owner-slot validity across the full account; validate the pure-freeze dependency; enforce closed envelope and namespace parsing; and implement bounded acquisition at the actual reader entry path.
>
> Preserve coherent error, partial, unavailable, outstanding, and inherited-C evidence. Keep the original specimens unchanged, and make any required current-contract rebinding explicit so controls reach their intended predicates rather than stale hashes.
>
> Save and reopen the first substantive repair before expanding controls. Return a complete paired corpus/map, newly authored inert successor reader, meaningful state and ingress checks, repeated results, exact scoped reconstruction, preservation evidence, and one actual downloadable repaired package.
>
> Do not launch Codex, access repositories or hosts, execute uploaded programs, expand the carrier, complete deferred whole-R6J work by assumption, or claim independent acceptance.

The intended owner endpoint is:

```text
OWNER_R6J_NATIVE_RESULT_CARRIER_NRC01_NRC06_REPAIRED_REVIEW_REQUIRED
```

A **genuinely different ChatGPT reviewer** follows the completed repair. All nine original R6J findings remain independently open at whole scope.

## Delivery and limits

The new handoff was closed and reopened successfully:

```text
Bytes:   78,236,425
Members: 21
SHA-256: 7b9503a453b01d884bdb020deb5e3c32271884eea979b5af812ffb943a2cc7cb
```

Some older attachment references have expired, but the exact required owner/review bytes and their available source ancestry are included. **No re-upload or recovery pass is needed for this repair.** Local verification does not establish client-side download success.

**Sources and limits:** the authenticated review and owner archives, selected contract/reader and accepted-source excerpts, and receiving checks linked above. I performed byte, data-replay, source-text, and selected relationship checks—not a complete semantic audit, carrier repair, or uploaded-program execution.

**Confidence:** **0.99** in measured integrity and reproduced specimen relationships; **0.97** in the bounded repair direction. Successor soundness, full general-join completeness, and independent acceptance remain unestablished.
