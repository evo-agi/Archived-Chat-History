ES mounted-helper — episode, delivery and receiver cumulative independent re-audit
Objective, role and effect boundary
Use a fresh read-only Codex audit conversation, not the implementation conversation. Independently audit the exact external successor below. Determine whether LNX-LIFE-01…04 and TPA-01…05 are repaired in the actual composed implementation, whether the cumulative component is internally statically adequate under its declared qualified contract, and whether its NEW validation evidence is independently complete.
The owner reports nine repairs, 628 passing test/subtest terminals in each local unit/race lane, 123 required named top-level controls, a current selected-build-input record, and a newly externally recorded evaluator invocation. These are claims to authenticate and assess, not your acceptance oracle. The prior audit remains historically ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REAUDIT_INCOMPLETE; a successor result must not rewrite it.
This is review of external proof tooling, not whole-candidate ES acceptance. Keep the ES candidate, external source, input packets, original records and all retained binaries unchanged. No implementation, formatting, repository tests, external-tooling tests, Go commands, builds, benchmark, reviewed evaluator/packager/generator execution, receiver/control execution, network/SSH, host discovery, device/ioctl, signals experiment, namespace, mount, credential change, formatter, privileged probe, gateway/approval/import, service/container/VM, cleanup of retained state, Git mutation or publication is authorized. Do not execute compiled artifacts, including the safe executable.
Permitted work: ordinary-user source/text/binary-as-data inspection; audit-authored offline parsers, hashers and independent evidence adjudication; safe extraction into your own new private audit root; and narrowly inspected read-only Git/provenance acquisition. Audit-owned outputs belong in one fresh owner-only directory under /Users/ds/Downloads. Inspect retained recipes as data and independently implement their needed read-only semantics; do not run target scripts to certify themselves. Record every audit command and its effect boundary. No dependency installation or download.
Judge the selected finite contract, not an invented general-purpose privileged service. An actual lost effect, inconsistent producer/receiver interface, false acceptance, unrecorded current execution or impossible prerequisite is a current finding. An explicitly deferred, adequately specified independent actor is an establishment gate, not automatically an implementation defect. No new allocator, lease, signer, gateway, watchdog, daemon, database or standing policy is selected by this audit.
1. Authenticate the exact target before specialist review
Current root:
/Users/ds/Downloads/ES-mounted-helper-episode-delivery-receiver-repair-QR0TNsfd
Object	Expected binding
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIR_REPORT.md	20,553 bytes; SHA-256 588c8622bde95564d95869c26d012bcde89a2e75b8f2be550e599a5fdc14457e
ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REPAIR_PACKET.zip	1,774,859 bytes; SHA-256 8f18466af1d457685798f6102987175b78353a40e1c3adc7eb20da06b57b4cda
FINAL_ARTIFACT_IDENTITIES.json	Read its actual existing bytes, independently calculate identity and reconcile with the anchored report/ZIP. No separate digest was supplied; do not invent one.
AUTHENTICATED_PACKET_MANIFEST.tsv	Inspect actual format and compare with the packet's actual self-excluding member registry. Do not inherit an old count, filename, format or mode assumption.
Complete external source	111 regular members; manifest 17,190 bytes; SHA-256 8d0002488bc99fa8cf9cffd2a880e1855f4f92c673ca501409ff92fa89f2b3e8
Incremental delta	102 predecessor members -> 111 current members: 9 additions, 21 byte modifications, 0 removals; verify actual paths and authoring modes, including the 81 unchanged predecessor members
Current selected inputs	Report identifies an 85-member selection and SHA-256 5817b1b135aeb3a5bf7aa543987078c14812b8356e370e547ecdbac75907c6cc. Establish whether this digest names the recipe, record or canonical rows; retain and bind all actual representations separately.
Current decision	records/final-local-validation.json, 11,529 bytes; SHA-256 15e64576ab586ea814fb76cd63d080f5a64bd320d9836fb0a35ef1d804b25477
Current evaluator invocation	Reported 8,058 bytes; SHA-256 e3dbf4df3de23a261c6021cd15e038fe62e0dcdc7be77f0beb21a4cd9679ba60. Locate via authenticated records, not a guessed filename.
Supervisor A/B	Each 6,281,058 bytes; SHA-256 0253168c3652a9a9b94bf9dbafb7adf2e0b1505e813fab68810ee392efdf4a86; compile-only
Safe executable	4,497,174 bytes; SHA-256 c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75
Safe import closure	2,023 bytes; SHA-256 739a10de46f4ccf3e2d341d764d651c80462c9cde53c1e6d4726c1c4c1adbbe3
Inherited normal proof	23,583,914 bytes; SHA-256 bc4ff667d9280ee8ec671fc60bc23ec4e32e256b5084436588bcfb78292f4d0d; never executed
Inherited diagnostic proof	23,605,547 bytes; SHA-256 e2fc7baf9a7a9286f97dc3dbb95b74bba44c0b1d14d75c544b1f466d3d81edfb; different effective source, never executed


The ChatGPT pass inspected and fingerprinted the attached report only. Current ZIP/source/evidence/binary bodies were not attached to that pass. All other bindings above are owner-reported targets for your independent authentication.
Require CRC, safe unique normalized relative paths, supported physical types, bounded extraction, exact membership, sizes, hashes and recorded modes. Reject escaping paths, symlink/special/encrypted members and duplicates. Reconcile source authoring modes, stored ZIP modes and normalized private extraction modes without chmodding retained objects or conflating them. The authenticated ZIP is the review representation; classify any authoring-tree-only caches, binaries, OS metadata or packet-only members instead of silently adding/deleting them. Do not invoke LFS filters, external diff, textconv or hooks. Binaries are retained outside the ZIP and may be read only as data through exact authenticated references.
Read the actual complete current source/ tree, not only changed functions or the report. Mandatory navigation anchors include:
- source/docs/EPISODE_DELIVERY_RECEIVER_SPEC.md, source/OWNER_STATE_EFFECT_TABLE.md;
- administrative interface/templates, future execution, case/resource, remaining-gates and successor/closure documents;
- source/tooling/internal/proof/episode_owner.go, process_custody.go, signal_authority.go, terminal_receiver.go, and their tests;
- actual entry, authority_contract.go, controller/lifecycle, Linux live/worker/candidate producers, formatter termination, scratch removal, terminal protocol, finalization and adjudicator, including relevant unchanged callers;
- all changed runner/freezer/adjudicator/packager source and current schemas/templates/fixtures;
- records/input-authentication.json, records/HISTORICAL_EVIDENCE_ABSENCE_LEDGER.md, incremental/cumulative source deltas, exact current selected-build recipe/record, current requirements, plans, raw command streams, generation and invocation records, compiler metadata and current closeout;
- all three actual preceding specialists and their source excerpts, supplied in the packet or available through anchored exact references.
Immediate preceding audit root:
/Users/ds/Downloads/ES-mounted-helper-terminal-lifecycle-reaudit-2aZ9ECLy
- report: 26,007 bytes, 670d4e83214e6a0d24637fad9829006c17ffd87d8e5cf6672237ed77597763a8;
- ZIP: 204,145 bytes, c38a8baa8f589dba519da3c8da92e215b3d51437f279a3ed472750ce107cf84e;
- final identities: 3,039 bytes, ae79d507f4bfaedf0eb93cb9934121cfa0b6c9fb647d627ef0f93c02528b96cc.
Read records/EVALUATOR_INVOCATION_EVIDENCE_GAP.md, records/TERMINAL_GRAPH_RECEIVER_ADJUDICATION.md, records/FINDINGS_LINEAGE_50.md, and the exact lifecycle excerpts. Authenticate embedded bodies against the original audited packet; do not replace specialist text with a parent summary.
Rejected source root:
/Users/ds/Downloads/ES-mounted-helper-terminal-lifecycle-repair-B19bsGkZ
- report: 14,957 bytes, 649a2dac99ed315cddae0c991935de1491bb454d48307a93b2984304dfedcb45;
- ZIP: 1,221,421 bytes, 29abfa2c902e88494f63d53af6ad9dc7c6430350e15f8b02814a17f7c3fa0969;
- final identities: 3,047 bytes, bde93300776f96415cec8edf47369c8dd858db85b3375f86fcbc2ee3bdff959f;
- source: 102 members, 15,760-byte manifest, e72db661c908493d82c41f6f8f2d29c374ec2f35a4338549fc410f3274fbbf4b.
Authenticate the necessary historical dependency chain once. Do not reconstruct every prior packet or start a historical-artifact repair project. An identity mismatch is not a correctness verdict; stop judgment on the mismatched target and report the exact boundary. An evidence gap within an otherwise authenticated target must be classified by the claim it prevents, without hiding independently supportable source findings.
2. ES remains preservation-only
Repository: /Users/ds/Repositories/Execution Substrate
Expected target:
- branch/upstream trunk_dev / origin/trunk_dev;
- HEAD b92bd9884106154d25342e1573dcc4c312311436;
- tree cdd4e44bac15c1952d70997143040644361f0bb1;
- parent 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- source: 358 rows, e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e;
- candidate: 83 rows, 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2;
- status: 83 rows, a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c;
- tracked diff: 2,407,274 bytes, 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1;
- index: 39,949 bytes, 9ca13234f248fccb29e8136168bb577c49c3fcf3c23b3f0d23b2bc1bd3aac569;
- zero staged/conflicted paths; no active operation; six worktrees; no fetch.
Read current AGENTS.md, latest relevant PLANS.md, owning capability/configuration and lifecycle docs, and relevant actual product source/tests/fixtures for the helper-to-ES binding. ES facts come from those owning contracts. Keep Current invariant / Bounded slice rule / Temporary compatibility edge / Reopened redesign seam classifications visible. Do not restore stale milestone sequencing or treat CP compatibility as enduring orchestration authority. The helper does not gain admission, Submit, result, staging deletion, reclamation, runtime, Git or policy authority.
Inspect the retained provenance source and relevant Git config/attributes before independently reproducing opening/closing records. Use GIT_OPTIONAL_LOCKS=0 and disabled fsmonitor, attributes-driven external diff/textconv/filters and hooks. Capture source/candidate/status, tracked/cached diff, index, refs, worktrees, branch/HEAD/tree/parent and operation facts. Only the declared envelope phase label may differ. Classify exact historical same-object app-owned capture/checkpoint ref-name churn; do not use it as permission to ignore arbitrary drift. Opening-to-closing target changes block an exact-preservation claim.
No repository edits or PLANS status update. The full source union and previous product local/native evidence stay unchanged; their retention does not constitute whole-candidate acceptance.
3. Review the actual composed path, not the report's function list
Reconstruct the selected path from real entry through receiver:
raw/validated entry -> immutable episode owner -> acquisitions -> cases -> cleanup/inventory -> frozen operational outcome -> sealed bundle -> exact persisted sibling receipt -> independently expected held acquisition -> authentication + semantic verification -> receiver decision.
For every edge record the real production caller, independently supplied input, authority before effect, held object/subject, temporal bound, state/observation produced, failure exit and next consumer. Compare this with the positive composed test. Name precisely where it executes shared production code, uses real ordinary files, substitutes an effect/authority actor, or only checks Linux-selected source/AST. Do not accept a list of function names as execution evidence.
Use the actual declared threat/concurrency/scheduling contract. A source finding needs an exact reachable predicate and effect under that contract; do not invent a universal hostile-root or filesystem guarantee. A concrete contradiction within the selected contract remains a blocker even when the nominal path or injected controls pass. Scope/test/document precision gaps should have proportionate severity rather than being promoted automatically to security defects.
LNX-LIFE-01 — one owner from entry through delivery
Inspect the real ordering before ledger creation, export/run-directory changes and deliberate process settings; preserve raw-FD-before-poller ordering. Check already canceled/expired entry, exact episode/source/target/administrative/residual policy binding, original typed deadline, active context and sticky terminal cancellation. Verify EpisodeOwner cannot be substituted, mutated through aliases, relabeled by an operations argument, or renewed during finalization/delivery. Follow cancellation after controller return and immediately before/after carrier publication and receiver-visible classification. Distinguish allowed bounded cleanup/evidence reserves from renewed active authority. Runtime startup itself is not claimed effect-free; read-only input qualification is not write authority.
LNX-LIFE-02 — original root custody at destructive acquisition
Trace saved parent/root identity into the descriptors actually used by scratch_removal.go, and verify all live callers consume that same relationship. Inspect the check/open interval, rename-away, replacement-at-name, parent replacement, substitution after acquisition, root unlink and ENOENT-with-held-original. Determine what remains known after an Nth remove or follow-up inventory error. No newly observed replacement may become the expected original; no pathname absence proves destruction of an unaccounted original. Verify replacements/outside sentinels remain outside cleanup authority. Retain trusted-parent/check-to-effect qualifications rather than claiming an atomic defense the contract does not select.
LNX-LIFE-03 — facts originate in the real acquisition producer
Walk every worker, formatter and candidate acquisition and release substep, not only ProcessCustody's unit model. Each learned PID/start/pidfd/group/namespace/channel/descriptor facet must enter the returned partial state before the next fallible action; failures and a subsequent bookkeeping/cleanup failure must preserve it into final evidence. Review early returns, candidate rollover, pidfd release uncertainty, exact-once invalidation and all default/hard-coded released values. A controller preserving a perfect fake observation is insufficient. Check real producer source bindings and the assertions' final facets, not only counts/booleans. Evidence numbers are not authority for later targeting.
LNX-LIFE-04 — no signal-authority revival through another caller
Inventory actual signal dispatches in supervisor, worker, candidate, formatter, timeout/force-close and deferred cleanup paths. Check episode/subject/action/context/expiry binding before spawn and immediate checks before TERM/KILL. Inspect sticky expiry/cancellation/revocation across reentry with a later cleanup context and across the worker revoke transport. A genuinely new qualified subject must not overwrite or reauthorize uncertain predecessor custody. Prove the tested common routine controls the live syscall edge; a check elsewhere or a selected fake is insufficient. Preserve the non-atomic check-to-syscall qualification and absent independent external containment mechanism.
4. One reachable producer, carrier and receiver protocol
TPA-01 and TPA-03 — path establishment and exact byte delivery
Starting with ONLY the documented independently approved base/inputs, trace the actual live caller creating and holding exports, its bundle and the fixed sibling <episode>.receipt.json. Verify directory/object types, owner/modes, exclusive creation, saved identities and no-follow relationships through errors. Do not credit a test-precreated intermediate or an unused helper as live setup. Relate the layout to the declared single-run/base lifetime; report contradictions, but do not invent a requirement to make the fixture a reusable service.
Export and receipt storage must remain outside removable scratch and within declared evidence budgets. Inspect permissions and availability for the intended observer, whether carrier reads use the correct parent, and how input installation, run and receiver contracts agree. Keep raw stdio /dev/null and no stdout receipt dependency.
Follow the receipt bytes from one canonical freeze through the actual exclusive persistence and held read. Inspect partial writes, sync/close/mode errors, duplicate/name collisions, cancellation, deadline expiry, failed delivery and failure-closeout. The receiver must read exactly the produced disk bytes, not a reserialization of a returned struct. Receipt content cannot attest its own later publication/durability; separate those observations without circular hashes or an unbounded receipt chain. Check actual terminal manifests, seal order, ledger boundary, durability qualifiers and payload membership remain compatible with the new carrier. Do not let a publication status mutate the frozen operational outcome. A missing/uncertain carrier must not be replaced or accepted through a fallback.
TPA-02 and TPA-05 — independent expectations and trust
Inspect construction and all call sites of TerminalReceiverExpectations and ConfirmationVerifier, schemas and normative examples. Determine who independently supplies protocol/domain/phase/episode/scope, authority/policy identities, ES source/supervisor/proof/target identities, original deadline, approved storage relationships and ownership/modes. Evidence must not choose its own issuer, verifier, trust root, residual disposition, approved parent or synthetic profile.
Make a time-of-knowledge table. Pre-effect approval binds intent and prerequisites; newly created inode/digest observations can only be bound after creation by the independently authorized actor. Do not demand unknowable future inode values before creation, and do not accept merely copying claims from the untrusted bundle into the expected context. An observation digest supplies integrity, not authorization to choose its own context.
Check malformed/nil/unestablished/error verifier behavior and authenticated-but-wrong subject/phase/source/target/policy/deadline/receipt/export cases. Determine exactly what the positive synthetic verifier authenticates, which input is fixed independently, and what semantics remain checked by the receiver. A test stub's success is not establishment of a production trust source. Conversely, an explicitly injected and fully specified verifier boundary is not defective solely because installing a production signer was outside scope.
The ordinary-user synthetic profile must be selected only by trusted test configuration, never an attacker-controlled receipt/manifest flag or default fallback. Review non-synthetic root ownership, expected parent/base/bundle/carrier identities, no-follow descriptor acquisition, same-object reading and post-read name checks. A self-consistent copied tree under another parent is not the approved export. Check source-selected effects and held-object lifetime, with bounded reads/reconstruction under existing resource contracts.
This audit neither implements nor selects a signer, gateway, watchdog, lease/provisioner or permanent confirmation service. A later independent parent may satisfy multiple specified roles, but a role name is not evidence that it exists. Current impossible/circular or unenforced interface promises are findings; adequate deferred establishment is an external gate.
TPA-04 — authenticity cannot rescue a failed operation
Independently derive the acceptance predicate from actual code and contract. Check exact outcome schema and success values, complete operations and required cases, Primary/Cleanup/Inventory, original deadline/containment, cancellation/revocation, scratch removal, process/descriptor/loop residuals and uncertainty, publication/carrier completion, normal-versus-diagnostic roles, failure-closeout consistency and the independently approved residual policy. Unknown/missing statuses must not default to success.
Verify both a reachable positive decision under explicit synthetic trusted prerequisites and rejection of fully rehashed, self-consistent failed/uncertain graphs with matching synthetic authentication. Require correct rejection cause where a different early failure could hide the named defect. Confirmation may prove an observation; it cannot override operational failure or invent an absent case/cleanup/containment observation. Check the unchanged driver's actual output vocabulary and the producer/receiver split for a realizable positive path, not an always-reject implementation.
The exact live residual disposition accept-single-get-free-possible-unbound-without-removal remains UNAPPROVED. Do not infer global absence from local release or grant remove/detach/reset/retry/scan authority. A synthetic test accepting a separately fixed example policy does not adopt that policy for the host. The unimplemented loop lease remains a recommendation outside this selector, not a prerequisite that this audit silently introduces.
5. Independently review controls and NEW evidence completeness
Parse all retained data with audit-authored logic; do not run the owner's evaluator, packager, freezer or controls. Recompute the intended predicate from the inspected source and raw records, and label it your independent replay rather than an original owner invocation.
1. Authenticate the current plan, recorder/runner/freezer/evaluator bytes, current complete source manifest and actual selected build inputs before reconstructing the accepted generation. Distinguish recipe, row and record hashes and the 111-member source from its reported 85-member build selection. Confirm every selected source/dependency and current artifact binds correctly; inspect unchanged safe/driver/overlay/module members and declared 9-add/21-change delta.
2. Derive exact package/test run/pass/skip/fail/incomplete identities and required descendants from both local streams. Check all selected failures, not only the selected requirement subset. The report says 628 terminals and 123 named TOP-LEVEL controls in each Darwin lane, with two no-test command packages. Independently reconcile that with the predecessor's 269 required controls/descendants and this task's requirement to preserve prior applicable obligations. Produce a mapping for retained, added, renamed, superseded and excluded identities with source rationale. A change in counting granularity is not itself lost coverage; unexplained deletion of a live obligation is not accepted. Never use a total as the oracle.
3. Verify the positive and negative composition controls' real actors and source correspondence. Name actual filesystem calls versus substituted kernel effects/trust and Linux AST checks. Review every named finding's attack, coupled failure, expected side effect/non-effect, residual state and receiver disposition. Do not overcredit modeled success as Linux runtime, mounted behavior, crash durability or independently established policy.
4. The report's freezer preflight rejected mismatched representation modes before final commands; a later aborted generation ran only command 1 before a mistyped cwd prevented command 2 from launching. Inspect those original records and the corrected generation separately. A missing child-process invocation must not be fabricated. Determine whether any missing prelaunch wrapper event affects the credited generation, boundary compliance or only rejected-attempt history; state the classification explicitly. Do not silently credit aborted records or normalize representations in place.
5. Authenticate every current evaluator invocation, including rejected arguments, adversarial self-test and successful decision: executable/interpreter/script bytes, absolute argv/cwd, relevant environment, start/end, exit/timeout, stdout/stderr, input set and output identities. Specifically locate and verify the reported 8,058-byte invocation and 11,529-byte decision. A positive output body is not the invocation. Check external recorder independence from the predicate and that recorded inputs were the frozen accepted records.
6. Independently check package-verifier/packager invocations and their adversarial controls. Distinguish the records embedded before package construction from the final verifier/identity records necessarily outside the finished ZIP. Require an acyclic binding; do not demand that a packet contain its own future completed verification. Inspect the actual existing final-identity and external verifier records, rather than crediting future-tense report prose as an observation.
7. Confirm effective pinned Go 1.26.5 environment and isolated telemetry storage from raw records, not requested variables alone. The installed executable is reported as /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go, SHA-256 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19; inspect as data, do not invoke. Check offline/module-read-only settings, task-owned HOME/config/cache/temp and absence of downloads. Code needed for version-specific semantics may be read from authenticated installed/preserved sources, not executed.
8. Rebind deterministic supervisor A/B as artifacts-as-data. Confirm byte-identical safe executable and selected source/import closure before inheriting its seven original Linux observations and cleanup. Those observations do not execute the changed internal/proof. Normal and diagnostic artifacts and 359/360/360 source unions remain unchanged compile-only evidence; diagnostic is different effective source and supplementary. Historical absolute overlay paths are build provenance, not a portable recipe or normal behavior.
Historical evidence gap is retained, not inherited automatically as a successor blocker
Read the absence ledger; do not repeat a broad search. Original failed/corrected evaluator command records, the old selected-build record and attempt-01/02 fixtures were not recovered. Preserve the earlier INCOMPLETE endpoint and that absence. Attempt-01/02 only establish their build-collision/AST-panic failure classes; attempt 3's present fixture can receive its actual limited credit.
A new invocation cannot repair history. Equally, fully recorded new-source validation need not wait forever for unused historical invocation records. Independently assess current completeness. An inherited claim still requires adequate binding for that claim; identify exactly what cannot be reused if an essential dependency is missing. Do not relabel authentic old test observations as failed tests because invocation evidence elsewhere is absent.
6. Cumulative scope and external prerequisites
Preserve and individually adjudicate all 59 lineage rows: F-1…16, V2-01…16, LIO-01, MH-CUM-01…09, LNX-NEW-01…07, PV-01, LNX-LIFE-01…04 and TPA-01…05. Preserve previous narrow closures and specialist disagreements, including F-12's different source-order/causal-evidence judgments. New findings get new IDs and precise current paths; owner status never overwrites independent historical judgment.
Review current cross-cutting interactions, not just a checklist of the nine edits. State for each current finding: severity/type; normative obligation; exact source path:line; reachable trigger and assumptions; intended/observed effect or false decision; tests that did/did not reach it; static/model/runtime evidence; minimal correction; remaining uncertainty. Do not average a concrete adverse path away because another specialist accepted its nominal counterpart.
Classify remaining prerequisites into: present source/interface defect; incomplete CURRENT evidence; policy choice; mechanism not established; exact target identity/qualification; runtime observation. Current independently supplied trust, parent storage, containment and terminal confirmation may be unestablished, but their interfaces must be reachable and internally consistent. No privileged or mounted empirical claim follows from synthetic trust.
The external containment/temporal owner still must be in force before the first privileged effect, cover the complete episode including evidence/delivery, and supply authenticated observations required by the acceptance contract. No helper flag creates it. Do not demand a new mechanism in this read-only task or give a generic promise unconditional credit. Preserve ordinary synchronous-I/O and check-to-syscall qualifications; elapsed-time observation is not necessarily effect termination.
Remaining product gates stay unconditional where specified: actual 11 normal and 8 supplementary diagnostic mounted cases with qualified cleanup; running-deployment observation and bounded supported-local consumer/operator proof; fresh whole-candidate ES audit before acceptance/commit; separately authorized exact-byte staging/commit. No CP/Temporal restoration, loop lease project, residual-policy approval or adjacent-repo work follows from this review.
7. Review organization, endpoints and output
After shared target authentication, use exactly three bounded independent read-only specialist perspectives where the available Codex capability supports them:
1. Lifecycle/Linux: actual entry-to-terminal owner, partial acquisitions/releases, signals/reentry, scratch custody and Linux/shared control correspondence.
2. Delivery/receiver/authority: live parent establishment, sealed graph/carrier, receipt delivery, independent trust/custody, acceptance predicate, temporal/residual interfaces and normal/diagnostic evidence.
3. Validation/provenance: fresh current invocations and selected build record, command/stream adjudication, required-control crosswalk, predecessor limitations, actual composed controls, artifacts and safe-evidence inheritance.
The parent independently authenticates and reviews the decisive cross-cutting caller transitions, owns synthesis, and preserves disagreements. Supply bounded capsules with exact roots/hashes/contracts/effects; no nested delegation or shared report writer. Retain all actual specialist reports, not just a synthesized summary. If a specialist cannot start, follow the established one-retry rule; disclose missing coverage rather than manufacturing a three-specialist result. Keep the task read-only.
Decisions:
- ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_STATIC_REVIEW_SATISFIED_EXTERNAL_GATES_PENDING only when the exact component and current evidence are adequate under the qualified contract; it is NOT execution authorization or ES acceptance.
- ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REAUDIT_BLOCKED for concrete present defects; name them rather than deferring them under policy/runtime labels.
- ES_MOUNTED_HELPER_EPISODE_DELIVERY_RECEIVER_REAUDIT_INCOMPLETE for essential current evidence or review gaps. State any independently established source BLOCK in parallel. Unused missing predecessor invocation history alone does not force this endpoint.
- AUDIT_PROVENANCE_MISMATCH for mismatch of the claimed target, with no acceptance judgment about unauthenticated bytes.
Produce a concise main decision report and a directly inspectable audit packet with: all three real specialist reports; 59-row closure matrix; exact source excerpts and composed actor/effect/receiver map; independent current invocation/stream/selected-input replay; requirement crosswalk; input/mode/delta/artifact/inheritance authentication; historical absence treatment; prerequisite register; and opening/closing preservation plus audit commands. Include all audit-authored parsers needed to understand your recomputation. No binaries, full product tree, caches, secrets, private telemetry, device data or nested engineering packet.
Reopen your audit ZIP, verify safe paths/types/modes/sizes/hashes/CRC/exact self-excluding membership, and bind report/ZIP/manifest and completed verification using one acyclic external final-identity record. Retain failure/uncertainty honestly; do not repair target evidence. Report all uninspected/unexecuted areas and separate provenance, evidence/validation, implementation and runtime confidence.
Return exact artifacts, full sizes/hashes and a source-specific next decision. The existing engineering ZIP remains unchanged and should accompany the audit report for direct source review in ChatGPT; no rebuilding of that input is required. Stop without implementation or automatic follow-on effect.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
