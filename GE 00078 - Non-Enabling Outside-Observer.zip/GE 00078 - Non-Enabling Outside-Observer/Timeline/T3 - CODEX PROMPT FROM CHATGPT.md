ES native Linux validation — resumed task
Objective and effect boundary
Validate the unchanged Execution Substrate integration candidate on the two already-governed Ubuntu 24.04 Linux environments. This is the native-runtime gate before the final combined read-only audit; it is not implementation, deployment, final audit, or commit authorization.
You are the sole foreground executor. Do not create subagents. Do not edit repository files or an extracted source copy, weaken assertions, change dependencies, stage, commit, push, fetch, switch branches, alter worktrees, or start another tranche. No external schema-package repair/promotion, target audit, reliable keyed-submit wiring, A6, live ES/Nomad/Docker/SPIRE/Vault actions, or other-repository work.
Authorized effects are limited to: a fresh local private evidence directory outside repositories; a fresh deterministic source snapshot; the existing governed transports; one normal start and one normal stop of the exact stopped ARM64 Lima instance; isolated task directories/caches, test-fixture loopback servers, native Go tests, evidence return, and cleanup of exact task-owned objects. No sudo, system/package/toolchain installation, public-internet access, dependency downloads, tracing installation, new VM/container, mount creation, remount, namespace creation, configuration repair, or persistent-asset removal. Preserve the four installed maintenance assets.
Finish this execution attempt with evidence and a verdict. Do not enter an unattended retry, maintenance, repair, or audit loop.
Baseline and inputs
Repository: /Users/ds/Repositories/Execution Substrate/.
Expected live baseline, to be reauthenticated before any host contact or VM start:
- Branch trunk_dev; upstream origin/trunk_dev.
- HEAD b92bd9884106154d25342e1573dcc4c312311436.
- Tree cdd4e44bac15c1952d70997143040644361f0bb1.
- Sole parent 4f797fb63d3c5b95275b1455af36ebc9b695f773.
- Local upstream comparison: one ahead, zero behind; do not fetch to refresh it.
- Zero staged paths; exactly 64 modified tracked regular files and 11 untracked regular files; no conflict or active Git operation.
- Six existing worktrees, preserved without visiting them to run commands or tests.
- Canonical 75-row candidate manifest SHA-256:
  7474bf8cd336421b56cf7e0f8b034280d9e01c92f25cb72464a700ba88313678.
Historical review snapshot root:
/private/tmp/ES-native-linux-validation-56dhnrrs
Files and exact identities:
File	Bytes	SHA-256
source-build-A.tar	7290880	518f05cf1b7b851d8e0801ed3f5db10d835efe7d6a86632a3731d43f8a4ac36c
source-member-manifest.jsonl	66503	b1d43619d4bd989fdf66e0254d11c8d38c8a05333f83072c2ede24f795bd6a89
archive-authority.json	1658	162fec3201f0da4aeaecf1b366ee64c4ca074856566aeac6802fc7b35f94f77e
candidate-manifest.txt	9109	7474bf8cd336421b56cf7e0f8b034280d9e01c92f25cb72464a700ba88313678


These are historical comparison inputs, not permission to execute that old archive without live source authentication. The source manifest contains 352 regular files, 341 recorded tracked and 11 untracked. ChatGPT checked every supplied tar member against that manifest and all 75 candidate rows against the tar; this is attachment inspection, not live Git or runtime validation.
Latest environment evidence root:
/private/tmp/ES-native-linux-environment-readiness-completion-2sprt3mv
Required records under its report/ directory:
File	Bytes	SHA-256
native-validation-environment-readiness-v2.json	2512	fb1a128f2de9fb1c50cb126f84cf49e219109edcdf635ccce4b245aa1786864a
amd64-readiness-v2.json	7001	53abae365e65fcc45824c84276354d6b4b0e46de86b7e04889eb74406de042e0
arm64-readiness-v2.json	8365	2a769f8948374ce5d5fca0dc78ce5b1709eda9853d014a01afd9edc81b436ace
evidence-registry-v2.json	32195	defcf01c7c7c6bee7b124e4138d9aa050f9ba08a704e155a81d11ca033d693dd
persistent-maintenance-assets.txt	1326	731a9eb8dbedd599b19e6787595c6986c60824d470d778ac193a2c95ae18ecab


The records report both environments ready, no ES source transferred/compiled/tested, and ARM64 stopped. ARM64 explicitly records closing_read_only_reverification=false for both persistent assets. Its registry lists equal before/after manifests from the readiness run; do not change that flag or claim a later closing recomputation occurred. Authenticate the installed assets again as part of this task's ordinary opening gate. Do not launch a retrospective maintenance repair solely because the flag is false.
Missing or mismatched comparison inputs are a bounded blocker. Do not reconstruct missing historical evidence, replace it silently, rewrite prior reports, or request a wholesale export of other repositories.
Governing contracts and inspection
Read current AGENTS.md and relevant current PLANS.md, not old milestone files or README as design authority. In the accepted candidate, the native two-architecture pre-final-audit/pre-commit gate is PLANS.md:387–397; current unkeyed Submit and the unwired private reliable-submit foundation are distinguished at PLANS.md:295–304. This task advances that gate, not a global reprioritization.
Consult the relevant sections of:
- .docs/system_overview/boundaries.md, configuration.md, capability_probing.md, go_toolchain_baseline.md;
- .docs/execution_lifecycle/contracts.md, implementation.md, es_execution_admission_model.md;
- es/admission/submit.go, staging_custody.go, staging_custody_linux.go, results.go, and their relevant tests;
- es/admission/resolved_execution_plan_test.go, resource_limits_test.go, writablestate_readiness_test.go, permission_fixture_test.go, and workstream_c_guardrails_test.go.
Classification: execution admission/custody rules are current bounded ES contracts; control-plane-normal-shell/v1 is a preserved compatibility edge; native validation is bounded evidence; machine reports/manifests are evidence/projection, never product authority. Reclamation, reliable-submit runtime, and broader autonomous-development integration remain separate seams. No architectural change is authorized.
1. Authenticate local source and create the fresh snapshot
Use non-mutating Git inspection with optional locks disabled. Capture branch, HEAD/tree/parent, upstream/local divergence, complete status/index state, worktree list, and active-operation/conflict posture. Do not invoke repository scripts or Git hooks. Record an opening deterministic tracked binary diff for closing comparison; do not infer untracked content from that diff.
Authenticate the historical input files against the values above. Recompute the 75 candidate rows from live source, using the supplied manifest's exact serialization: rows in repo-relative path order; M|MODE|SIZE|SHA256|PATH for modified tracked paths and ??|MODE|SIZE|SHA256|PATH for untracked paths; four-digit octal mode; UTF-8, LF, final newline. Include every changed/untracked path. Reject unexpected types, statuses, path-set differences, staged changes, or byte/mode differences. Compare the complete output bytes, not just the row count.
Independently enumerate the complete current source using:
git ls-files -co --exclude-standard -z
Compare every path, tracked/untracked classification, kind, mode, size, and SHA-256 with the historical 352-row source manifest, including paths outside the 75-path candidate. No ignored files, .git, credentials, caches, state databases, or unrelated evidence may enter the source snapshot. Three recorded tracked .examples/.../*.tar.gz files are existing example fixtures, not incidental build residue; preserve their exact bytes rather than excluding them by suffix. Stop rather than copy unexpectedly sensitive content.
Create a fresh physical private local evidence root outside all repositories with mode 0700. Record its ownership and filesystem identity. Capture two deterministic tar builds from the authenticated live source, with sorted safe repo-relative regular-file members, recorded modes, zero uid/gid/mtime and empty owner/group names. Reject duplicate/escaping/special/link members. Require Build A = Build B byte-for-byte and every member = the live source manifest. Recompute source/candidate manifests after building. The fresh tar must bind the same source; a documented packaging representation difference from the historical tar is not by itself source drift, but the two fresh builds must be identical. Never overwrite the historical archive.
Retain the exact small snapshot/manifest helper source used outside the repository. Do not create a framework, new schema package, self-modifying harness, or replacement authority chain.
2. Use only the recorded environments and installed assets
Run architectures sequentially, AMD64 then ARM64. An AMD64 blocker or failure should end the attempt after evidence preservation/cleanup; do not start ARM64 as an unreviewed recovery experiment. Partial results remain explicit and never satisfy the gate.
Field	AMD64	ARM64
Transport	existing SSH alias host_to_remote_linux_m75q	existing Lima instance es-lima-qemu-arm64
Expected machine	x86_64, dpkg amd64	aarch64, dpkg arm64, QEMU
Expected hostname	ds-ThinkCentre-M75q-Gen-2	lima-es-lima-qemu-arm64
Expected UID/GID	1000/1000	501/1000
Recorded kernel	6.17.0-23-generic	6.8.0-124-generic
Machine-ID SHA-256	a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6	36bcc652dc9e61ce61f7e19d839901c23db072c373355ac5f465226316171e6f
Go root	/home/ds/.local/share/execution-substrate/native-validation/go1.26.5-linux-amd64	/home/ds.guest/.local/share/execution-substrate/native-validation/go1.26.5-linux-arm64
Module cache	/home/ds/.cache/execution-substrate/native-validation/modcache-dac662ea3274	/home/ds.guest/.cache/execution-substrate/native-validation/modcache-dac662ea3274


Authenticate existing transport configuration and host identity without discovery or bypassing host-key checks. Use only the named destinations; obtain connection details from the existing configuration, not guessed addresses. The recorded OS is Ubuntu 24.04.4 LTS on each. Report and stop on unexpected identity/configuration drift rather than altering the environment to match.
ARM64 opening state must be Stopped and its existing Lima configuration SHA-256 must be 1579f5a94c7c159ab8441e26c679cde65fd3a054e68ea47165cbfddb5662ecd0. Start this instance normally once, authenticate the guest, and keep its configuration unchanged. No repair/restart loop. Existing read-only host shares are not the test workspace: transfer the archive into a fresh guest-local physical directory, rather than running tests against the mounted Mac checkout. No new dedicated repository mount.
For portable installed-asset identity, use the exact retained verification recipe and registered manifests in the readiness evidence. The recorded helper is validation/install_and_probe.py, SHA-256 32cc8a2137f3b55e7dfe8405b93a3e7f5abe9c59461f54d6cb1985eafc8fe88e. Inspect it before reuse; use only its read-only manifest semantics, never its installation/probe orchestration or importing a module that runs installation at import time. Preserve the existing serialization; do not approximate an unavailable recipe. A small external verification-only wrapper may be retained as task evidence.
Expected portable manifests:
- AMD64 toolchain: 5288dc5d51a05d539f02b9fb2cf7978deb995116f0adde7e628172212bdcbefa.
- ARM64 toolchain: 3dd575df51039882df33ad80ef464986474f7df69676109d186e8507423ce625.
- Each module cache: 38d54157c700b13347d114af010cb204124ca65da5eb69c43411dddd0ebb7b02.
Recompute before testing and after testing while that environment is reachable. Check exact Go 1.26.5 via the explicit versioned binary; do not use AMD64's absent default Go or ARM64's preserved Ubuntu Go 1.22.2. Do not reinstall or mutate persistent assets on mismatch.
3. Transfer and run native validation
Create a fresh private physical task root in each Linux environment, recording UID/GID, mode and device/inode. Put source, Go build cache, Go temporary work, test temporary files and logs in separate task-owned subdirectories. Authenticate the transferred archive before extraction; extract safely; compare all 352 members and the 75 candidate rows before executing tests. Source bytes and modes must remain unchanged throughout.
Use the explicit installed Go binary and a task-scoped environment:
GOROOT=<the exact architecture-specific root above>
GOMODCACHE=<the exact architecture-specific cache above>
GOCACHE=<fresh task-local build-cache directory>
GOTMPDIR=<fresh task-local Go temporary directory>
TMPDIR=<fresh task-local physical test-temporary directory>
GOTOOLCHAIN=local
GOENV=off
GOWORK=off
GOPROXY=off
GOSUMDB=off
GOPRIVATE=
GONOPROXY=
GONOSUMDB=
GOFLAGS=-mod=readonly
CGO_ENABLED=0
Unset outer-process GOOS and GOARCH; record their effective native values, not just the absence of overrides. Do not dump the full inherited environment or credentials. Put the versioned Go bin first in the task's PATH without changing shell startup files or system PATH. Suppress external Go telemetry in this task's process environment where applicable; do not change persistent telemetry configuration.
From the extracted source root, record exact argv, selected safe environment, cwd, timestamps, actual exit status, stdout and stderr for:
"$GOROOT/bin/go" version
"$GOROOT/bin/go" env GOOS GOARCH GOVERSION GOROOT GOMODCACHE GOCACHE GOTMPDIR GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS CGO_ENABLED
"$GOROOT/bin/go" mod verify
"$GOROOT/bin/go" list -m all
"$GOROOT/bin/go" test -json ./es/admission -count=1
The final command is the previously required complete go test ./es/admission -count=1 gate with JSON event output added for test/skip evidence. This output-only refinement does not narrow the package, change assertions, or substitute a filtered run. Do not rerun the complete suite merely to obtain the non-JSON spelling. Capture its actual process result without a pipe hiding the exit status. Retain the original JSON stream even on failure. Do not add a timeout/rerun/skip workaround to obtain a pass; distinguish test failure, Go's timeout, process/transport loss and environment inadequacy.
The suite's existing structural guard at workstream_c_guardrails_test.go:2217–2229,2337–2360 intentionally invokes offline go list -deps -export -json for darwin/arm64, linux/amd64 and linux/arm64. Those child compilation/type-checking views are authorized existing test behavior and are not native evidence for those other targets. Do not disable the guard or misclassify those child overrides as an outer native-test architecture substitution.
Before running, record the exact relevant test names from the unchanged source. After running, require explicit passing events for every top-level test and subtest in staging_custody_test.go and staging_custody_linux_test.go, plus the relevant source-selected result publication, stable capture, pre-freeze failure, ambiguous-registration retention and two literal runtime-profile goldens. In particular include:
- TestLinuxStagingCustodyUsesOpenat2AndRenameat2;
- TestLinuxStagingCustodyRejectsMountCrossing;
- TestRetainedResultPublicationConcurrentWinnerAndValidatedLoser;
- TestRetainedResultPublicationValidatesExistingFinal;
- TestRetainedResultPublicationFaultsBeforeCommitAndDuringValidation;
- TestRetainedResultCustodyRefusesConfiguredRootReplacementBeforeRead;
- TestResultPublicationConflictRetainsStageRoot;
- TestStableLocalCaptureEnforcesExactLimitNoFollowSingleLinkAndLeafIdentity;
- TestStableLocalCaptureDetectsAncestorReplacement;
- TestSubmitStopsBeforeFreezeWithoutRunOrFilesystemEffects;
- TestSubmitAmbiguousNomadFailurePreservesPrimaryErrorAndRetainsRoot;
- TestTrancheB1DefaultProfileLiteralNomadJobAndAuthorityHandoff;
- TestTrancheB2ControlPlaneNormalShellLiteralNomadJobAndAuthorityHandoff;
- the two unreadable-result tests in writablestate_readiness_test.go:502–535.
The Linux crossing test opens / and attempts to open proc through the production helper, requiring EXDEV (staging_custody_linux_test.go:56–66). It uses the existing procfs mount. Record existing mount topology without changing it. No privileged mount experiment, bind mount, sudo or namespace setup is required or authorized. If the expected topology/capability is unavailable, report an environment blocker; do not skip or replace the test.
Run tests as the recorded unprivileged user. Permission-fixture skips are real skipped evidence, not passes. Inventory every skip from the complete JSON stream; any skip within the required inventory, missing required execution, malformed/truncated stream, or nonpassing package result prevents success. Do not exclude Darwin-only build-tagged tests as though they had run; correctly classify them as non-applicable to this Linux task.
Retain a compact evidence map from actual native passing tests to production source: Openat2 and its configured resolution flags (staging_custody_linux.go:7–16), no-replace Renameat2 (:19–20), expected-object device/identity/owner/link checks, collisions, root retention, result winner/loser behavior and operation-local cleanup. Label this as source-bound native test evidence, not independent syscall tracing or universal filesystem assurance. Do not fabricate a claim that every flag had an isolated negative test or that process exit proves every descriptor close path. No tracer or extra general-purpose analyzer is needed.
4. Closeout and verdict
After execution, independently compare extracted source paths/types/modes/sizes/digests with the pre-test source manifest, and compare the 75-row submanifest. Also compare installed-asset manifests and preserve default toolchain/configuration state. Retrieve logs, commands, results, manifests and the evidence map; verify returned files by size and digest.
For success, close task-owned processes, authenticate and remove only the exact task-owned remote root after evidence return, then record two absence observations. Test-fixture cleanup and removal of this harness's isolated task root do not authorize ES production staging reclamation. Never remove retained historical evidence or the four persistent maintenance assets. On failure, retain complete diagnostics before any task-root cleanup; when safe cleanup cannot be proved, preserve the exact root and report the residual state instead of claiming clean closeout.
If this task started ARM64, stop it normally after evidence retention, record two stopped observations and task-related process absence, and verify its configuration digest unchanged. Do not stop an instance that was unexpectedly already running; that fails the opening gate. Do not force-kill unidentified processes or retry a failed VM boot.
Repeat local repository identity, index/status, tracked diff, worktree list, full source manifest and 75-row manifest checks. Require opening = closing with no repository-local test/build/evidence residue. Do not run local repository tests as part of this closeout.
Choose one primary verdict:
- ES_NATIVE_LINUX_AMD64_ARM64_VALIDATION_PASSED_FINAL_AUDIT_READY: both complete native admission suites pass; all required tests/subtests pass without skips; evidence is intact; source/persistent assets remain unchanged; local/remote closeout succeeds.
- ES_NATIVE_LINUX_VALIDATION_FAILED_CANDIDATE_REPAIR_REQUIRED: authenticated source fails in an adequate governed environment, with source-grounded attribution to the candidate. No editing here.
- ES_NATIVE_LINUX_VALIDATION_BLOCKED_GOVERNED_ENVIRONMENT_REQUIRED: unavailable or drifted environment/toolchain/cache/capability, required host-dependent skip, or an unresolved execution condition prevents the gate. Do not label an unexplained timeout a product defect without evidence.
- ES_NATIVE_LINUX_VALIDATION_PROVENANCE_MISMATCH: source/repository/input/transfer identity mismatch, source mutation, lost or untrustworthy acceptance evidence, or an unauthorized effect defeats the chain. No re-baseline in this task.
A passing runtime suite is not a passing final combined audit. After reporting, stop without final audit, edits, staging, commit, push, deployment, target audit or A6.
Required report and review packet
Give a self-contained inline report with: primary verdict; opening/closing Git and candidate identities; exact environment identities; architecture-by-architecture command/exit/test-count/skip results; required-test evidence map; all failed, skipped or unexecuted work; returned evidence identities; source/persistent-asset preservation; cleanup and ARM64 closing posture; assumptions and unresolved uncertainties; any authority/security widening or scope deviation; explicit no-edit/no-stage/no-commit/no-push confirmation.
Retain detailed raw evidence and exact task helper sources outside repositories. Produce one collision-safe ZIP in /Users/ds/Downloads/ containing the concise report, safe command records, both test JSON streams and stderr, required-test result inventory/evidence map, opening/closing source/candidate manifests, fresh snapshot identity, environment/asset comparison records and a simple per-file size/SHA-256 manifest. Return its exact path, size and SHA-256. Do not include module caches, Go distributions, test binaries, VM disks, private configuration, credentials, or indiscriminately collected host logs. Preserve raw sensitive evidence privately and state any safe-excerpt treatment; never present redacted bytes as an unchanged raw log. No circular/self-hashing registry or external schema promotion is needed.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  







  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
