**Keep the design migration blocked. Correct B1–B6 in the contract and migration map before touching implementation.** The review supports the selected weaker deadline model in principle; it identifies six unresolved rules in this particular draft, not a reason to return to universal physical containment or reopen the accepted helper’s source repairs. :chatgpt-content-reference{index="0"}

**Send this to the original design/preparation Codex conversation: :chatgpt-content-reference{index="10"}[B1–B6 temporal-contract correction prompt](sandbox:/mnt/data/ES_Temporal_Contract_Correction/ES_Temporal_Contract_B1_B6_Correction_Prompt.md).**

This is another **design correction**, not the coupled code migration. The prompt makes the choices below explicit so Codex can produce one coherent successor rather than leave the same decisions for implementation.

## 1. Use one uniform successful-completion cutoff

**For the corrected draft, I am selecting the simpler alternative:**

```text
D = the independently authorized original deadline
S = D − 8 seconds

Successful episode completion must occur before S.
The final eight seconds are reserved for an already nonpassing episode.
```

The current conflict is real: the draft permits successful publication through D while requiring teardown of a still-live supervisor by D−8. The review’s D−7 carrier example cannot satisfy both rules without an unstated exception. :chatgpt-content-reference{index="1"}

Under the selected correction, required operations, cleanup, success-bearing publication, carrier delivery, and the required outside terminal observations must finish **strictly before S**. A carrier completed at D−7 is explicitly late for success, even though it precedes D. S is derived from D and the contract; nobody independently chooses or renews it.

This deliberately gives up the last eight seconds of the successful-work window. It avoids a special publisher exception with a different stopping policy.

At S, an incomplete episode becomes nonpassing. Any subsequent stopping, observation, or failure-retention work must fit its existing, separately established authority and the original D. A parent that resumes late cannot invent the missed TERM grace or observation interval. A signal request still does not prove termination.

Conversely, reaching S does not justify signaling subjects already proved resolved. The corrected draft must define the observing parent’s finite terminal-coverage boundary without demanding an endless chain of observers proving their own future exits.

**Retrospective verification remains permissible after D.** It interprets observations completed within the successful window; it does not continue the original episode or manufacture missing timely evidence.

These are selected successor semantics—not current operational authorization.

## 2. Map the one-close duty separately from compound effects

B2 and B3 are related, but their corrections must remain distinct.

**B2 preserves an existing duty.** The review identifies actual callers that must discharge an already-acquired ledger or descriptor exactly once, even when general action authority has expired. Guarding that release indiscriminately with `now < D` would drop the duty; exempting an entire write/sync/close routine would authorize too much. :chatgpt-content-reference{index="2"}

The corrected map must identify the exact covered callers and object types. The rule is invalidation before one close attempt, with release uncertainty and the primary error retained. It grants no write, sync, reacquisition, numeric-descriptor retry, signal, or successful-proof upgrade.

It must also distinguish a close admitted earlier but completing late from the narrowly permitted discharge admitted after expiry. The name `Close` alone cannot establish that a wrapper performs only that permitted action.

**B3 requires checks at the actual deliberate sub-effects.** An outer check before a create/write sequence cannot authorize a later write merely because the create began in time. The report specifically identifies publisher, finalization, candidate, and worker paths missing from the migration map. :chatgpt-content-reference{index="3"}

The next map must therefore enumerate the relevant create, write, sync, mode, publication, preparation, and signal edges, with their authority, phase bound, pre-dispatch check, post-return observation, and partial-failure treatment.

The accepted non-atomic interval remains: a process may be descheduled between its final check and **one** dispatch. That is different from knowingly admitting a **second** deliberate operation after the first returns and the bound has expired. The contract must not conflate them.

## 3. Make the contract digest identify complete normative bytes

**I am selecting one standalone normative file**, authored in the new planning root as:

```text
contract/TEMPORAL_CONTRACT.md
```

Its proposed migration destination is `source/docs/TEMPORAL_CONTRACT.md`. It must contain the complete temporal rules—including the observation, reservation, version, and receiver semantics—not merely a summary that depends on mutable clauses elsewhere.

The review’s counterexample is important: every approval and receipt can agree on the same digest while an unhashed governing teardown rule changes. Internal hash agreement would then authenticate an incomplete definition. :chatgpt-content-reference{index="4"}

The selected representation is raw UTF-8 without a byte-order mark, LF line endings, and exactly one final LF. The digest and byte count are computed after the complete text is frozen and recorded outside that file. Received bytes are checked, not normalized into a match.

The corrected map and explanatory report are derivative. They cannot add another normative temporal rule outside the hashed corpus. Non-temporal ES and artifact contracts retain their own authority and bindings; this does not require hashing the whole repository into the temporal document.

The proposed version family otherwise remains: run-only v4 authority records, outcome-v4, receipt-v4, expectations-v3, and confirmation-v4. **Import-v3 canonical bytes remain unchanged.** The correction must preserve the phase-specific encoding treatment rather than append zero-valued run fields to a shared import encoding. The review explicitly retains those migration boundaries. :chatgpt-content-reference{index="5"}

## 4. Define what the independent observation actually proves

B5 is not solved by renaming containment flags. The draft requires independently observed supervision, clock, scope, release, and timeliness facts, but does not yet define enough underlying evidence to determine whether those facts are true. An authenticated binding containing favorable booleans can still be semantically unsupported. :chatgpt-content-reference{index="6"}

The correction should specify **one bounded parent-observation body backing confirmation-v4**, not another hierarchy of per-effect attestations. For each claim, the normative contract must identify the observer, exact source records, subject/object bindings, acquisition and completion times, clock basis, required coverage interval, loss/unknown treatment, and consistency with the helper’s outcome, ledger, custody, and receipt.

It must distinguish direct outside observations from authenticated producer-origin facts and declared qualification premises. Copying a helper’s success flag does not turn it into an independent observation.

Two acceptance examples are essential. A complete modeled positive must traverse the intended public receiver semantics. A fully rehashed, issuer-authenticated negative must still fail when the underlying observation is false or incomplete—not merely because its signature or digest is stale.

The B1 decision must also propagate here. Parent loss **before required terminal coverage finishes** leaves the relevant facts unknown. Parent loss after complete, timely coverage has been retained does not automatically invalidate those historical facts; it also cannot supply missing authentication or release authority.

This remains a finite qualified observation contract. **It must not recreate universal physical quiescence or a perfect observer under different field names.** Actual observer, signer, protected storage, clock qualification, and target establishment remain later gates.

## 5. Reserve the collision domain before the loop number exists

B6 exposes a genuine ownership gap. Reserving known paths and PIDs cannot cover the dynamically selected loop object when `GET_FREE` has not returned. An unresolved request can overlap another actor’s allocation even though both parties’ path-based records appear consistent. :chatgpt-content-reference{index="7"}

**For the corrected design, I am selecting conservative custodian-enforced exclusion of conflicting loop allocation and reconfiguration on the approved target**, together with the episode’s finite path, backing-resource, process, and mount scope. This does not reserve every host activity or introduce a lease selector.

Before effects, the independent custodian must serialize the non-conflict decision over that collision domain. Actual loop, process, and mount identities are added when acquired; they are not fabricated beforehand. Unknown outcomes retain the conservative scope rather than silently shrinking it to whatever identity happened to be observed.

Release requires its own qualified custodian decision, supported by resolved requests and resources or an explicitly demonstrated noninterference disposition. Deadline expiry, process exit, receipt production, and even proof acceptance do not automatically release the reservation.

A record saying “held” is not enforcement. The eventual custodian must actually constrain conflicting work under the declared operating assumptions. When it cannot, live authorization remains unavailable.

This selects the **required contract**, not a reservation service or actual host policy. No allocation, removal, reset, foreign detach, or new consent occurs now. The separately proposed possible-unbound-object disposition remains narrow and cannot excuse an outstanding request of unknown outcome.

## The review procedure also needs correction

The report discloses both the initial unguarded `git status` query and use of the design conversation instead of the requested fresh parent conversation. :chatgpt-content-reference{index="8"}

**Treat this as a useful, specialist-supported blocked review with those qualifications—not completion of the intended fresh-parent independent gate.** The six concrete findings remain actionable. There is no benefit in reviewing the unchanged rejected draft again solely to repair the session label.

After the correction, the independent review must use a genuinely separate Codex parent conversation. Two specialists inside the authoring conversation do not replace that boundary.

The new prompt also requires inspection of the guarded preservation recipe and configuration boundary before **any** Git subprocess. Later matching captures cannot retroactively make the first query guarded. The correction task itself remains owner work and must not call its own design checks independent acceptance.

## The next deliverable is a corrected design, not code

The handoff requires the standalone normative file, complete revised migration map, individual B1–B6 responses, source-grounded effect inventory, and finite positive/refusal timelines. Original drafts, review records, accepted source, and historical matrices stay untouched.

Its intended endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_B1_B6_CORRECTED_CONTRACT_AND_MAP_READY_FOR_FRESH_REVIEW
```

A successful correction leads to fresh design review, then separately authorized coupled documentation/schema/predicate/assurance migration. The entry foundation follows the resolved migration—not vice versa.

The old helper’s scoped closure remains valid for its old bytes and contract. Remote scratch and survivor/observer state remain unknown. No recovery, risk consent, reservation, administrative establishment, mounted execution, whole-candidate ES acceptance, or Git progression follows from this task. The latest review preserves those limits explicitly. :chatgpt-content-reference{index="9"}

### Inspection boundary and confidence

I read the complete attached review and the preceding review prompt. The attached review is **15,141 bytes**, with computed SHA-256:

```text
7d9a20690ed0b73fb2e56e21efd92de66cf516580aa07b15e42bf45f18c24c9d
```

The review ZIP, full migration map, specialist originals, and accepted implementation were not attached here. Their detailed authentication and source findings remain review-reported; the correction prompt directs Codex to those exact retained inputs. No repository commands, tests, hosts, or cleanup were executed here.

**Sources:** attached temporal review, rejected temporal draft, and preceding review handoff. **Confidence: 0.97 in retaining the implementation block; 0.92 in this bounded correction direction.** Attachment identity is established. Corrected-contract coherence, independent acceptance, operational consent, and privileged readiness remain unestablished.
