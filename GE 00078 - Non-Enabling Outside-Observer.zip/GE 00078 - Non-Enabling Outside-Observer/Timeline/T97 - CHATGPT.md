**Proceed to a fresh, separate-parent affected design review. Keep implementation blocked until that review accepts the exact corpus and map.** The report now supplies a concrete proposed status path, corrected release prerequisites, and explicit treatment of the insufficient emergency target. Those are owner corrections—not independent closure or installed capabilities. :chatgpt-content-reference{index="0"}

**Send this to a new Codex review conversation—not the design/correction conversation: :chatgpt-content-reference{index="14"}[Status-acquisition and release independent-review prompt](sandbox:/mnt/data/ES_Temporal_Status_Acquisition_Release_Review/ES_Temporal_Status_Acquisition_Release_Independent_Review_Prompt.md).**

Place this directly before the attachment:

> Read the entire attached task before choosing any command. No Git command or repository bootstrap is authorized. Work outside all checkouts. A prohibited command stops this task; it is not a permitted disclose-and-continue step.

The handoff authorizes inspection and independent data checks only. No implementation, socket experiment, host contact, cleanup, or live adoption follows.

## What materially changes in this proposal

The correction makes the previously missing relationships explicit:

| Area | Reported correction | What the reviewer must establish |
|---|---|---|
| **T2 — status acquisition** | A distinct preissued **Q** scope obtains validity evidence; **F** remains limited to seven filesystem-publication effects. | The complete two-sided channel, authority, timing, and failure path is finite and nonrecursive. |
| **T3 — release responsibility** | C depends on a live, unconsumed acquired owner—not on ordinary authority remaining current. Fresh read-source Opens receive acquisition edges. | The actual callers, raw/wrapped alternatives, aliases, and every active prerequisite agree. |
| **T1 — emergency target** | The canonical predicate and caller use the same alternatives; the inspected numeric-only identity-failure route is explicitly unsupported. | The migration refuses that route without inventing targeting facts or erasing unresolved child custody. |

The report describes these distinctions directly. In particular, Q cannot issue or renew F, expiry cannot erase an established release duty, and parent T cannot substitute for local L. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

**No additional design change is justified from the report alone.** The next review should examine the actual corrected corpus and full map, rather than start another speculative correction.

## The new socket path is the main review target

The owner has selected one approval-pinned abstract `AF_UNIX SOCK_SEQPACKET` listener, a supervisor socket acquired under ordinary A before S, peer qualification, per-message credentials, and signed responses. The listener, responder, key, channel, and qualification mechanisms remain future establishments. :chatgpt-content-reference{index="3"}

This is more concrete than an unspecified `GetStatus` operation. It also introduces actual setup, message, credential, and handle boundaries that the review must follow.

### Bootstrap must work on both sides

The reviewer must trace the proposed sequence from independent approval through listener establishment, raw supervisor entry, pre-S connection and qualification, post-S Q exchanges, and individual F admissions.

The key question is whether **every necessary operation already has an appropriate authority and owner before it occurs**. That includes the custodian’s receive, status lookup, and reply—not only the supervisor’s request.

A future actor may legitimately await installation. An undefined operation cannot be excused merely by calling its actor “qualified.” The prompt requires that distinction without commissioning a responder service or an entry implementation.

The same scrutiny applies to peer qualification. Any process-identity reads, socket options, acquired handles, or session-binding steps must fit the declared setup and observation paths. The approval must not require an unknowable future process/session identity, while later evidence must not choose its own trusted peer.

### Message rejection is not automatically resource release

The report requires per-message credentials and describes truncation/ancillary refusal. The precise receive grammar therefore matters. :chatgpt-content-reference{index="4"}

As **limited external corroboration**, Linux documentation describes credentials carried as ancillary data, and upstream Linux v6.17 processes descriptor delivery during receive. Depending on the exact selected options and control-buffer path, resources may be acquired before user-space rejects a message. That makes the expected credential metadata, disallowed control messages, truncation, and ownership consequences a necessary review boundary. It does **not** establish a defect in the unseen current corpus. :chatgpt-content-reference{index="5"}

The reviewer must determine what the proposed configuration actually permits. If it prevents unexpected descriptor installation, that prevention needs an exact basis. If installation is possible, bounded rejection must preserve the resulting release duties. “Reject ancillary” and “CLOEXEC” cannot stand in for that analysis.

This remains static review. No descriptor-passing experiment or socket execution is authorized.

### Seven polling budgets are not a complete-duration guarantee

The report now limits **attempts**, not just favorable samples: at most seven exchanges, each consuming its role and nonce before one send, at most one 250 ms poll, and one bounded receive. Partial, malformed, lost, or replayed exchanges stop F without retry. :chatgpt-content-reference{index="6"}

The review must check admission immediately before each distinct operation and again before the filesystem effect. A bounded poll does not account for all preceding work, response verification, scheduling delay, or later synchronization. Nor does readiness guarantee that the one receive succeeds.

A valid early-failure timeline should demonstrate seven complete Q/F pairs under the specified premises. An ordinary-success timeline should demonstrate **zero F attempts and proper disposition of the already acquired Q session**. A socket held “just in case” must not disappear from the successful resource account.

## The release and targeting corrections have important consequences

### C must survive without requiring another observation

The report says all 47 predecessor canonical C rows and five aliases now use the current-holder relation. Cancellation, S, D, F revocation, and status or clock loss no longer erase an already established duty. :chatgpt-content-reference{index="7"}

The decisive review trace remains:

> Valid F creates a file; F is revoked before Write; Write refuses; the acquired owner still permits one primitive close—even after D.

The release cannot require a new status response, fresh path lookup, or renewed clock qualification. A failed close consumes that owner slot and retains uncertainty; it does not authorize a retry after numeric reuse.

The new E40/E50 read acquisitions and E52 raw-wrap alternatives also need source-derived inspection. **A purpose described as “inspection” does not make its Open nonacquiring, and a wrapper failure does not eliminate the raw owner.** The reported map now distinguishes those stages; the reviewer must verify the actual caller coverage and mutually exclusive release paths. :chatgpt-content-reference{index="8"}

### Numeric-only emergency refusal is a proposed behavior change

The report identifies an important limit honestly: at the selected failed-identity point, the accepted source has returned PID/group information but no held pidfd or independently qualified no-reuse anchor. The successor proposal therefore refuses that numeric-only route until a separately sufficient construction exists. :chatgpt-content-reference{index="9"}

**That does not mean the unchanged current implementation already refuses it.** The review must verify that the migration and affected tests actually select this refusal, rather than preserve a positive that assumes the failed identity fact becomes available.

It must also preserve known child/group custody and the primary failure. Refusing to signal is not proof of absence, and neither the refusal nor a later parent action creates targeting authority. Other emergency branches with genuinely sufficient facts should retain their own treatment.

## Check the chronology of failed-history evidence

The report replaces seven favorable samples with seven complete attempted-exchange records, each capped at 16,384 encoded bytes, while preserving the existing G/B/confirmation and combined limits. Partial failed history need not fabricate the 27-role success graph and cannot become accepted proof. :chatgpt-content-reference{index="10"}

The reviewer must recompute the actual schema’s encoded bound, including raw prefixes, metadata, authentication representation, and relevant control-message results. The arithmetic in the report is a starting point, not a substitute for checking which fields it covers.

**It must also establish where each record can be retained when it becomes known.** Later exchanges cannot appear in an earlier immutable failure-file write by assumption. Complete transcript retention must not require an eighth F publication operation, an undeclared post-D write, or a record claiming its own future synchronization.

Some failure paths may retain only in-memory or returned facts. That limitation is acceptable when explicit; guaranteed durable failure logging is not selected.

The prior local C1, projection, C2, and R7 judgments carry forward only where unchanged. New Q terms, session owners, attempt history, and authority encoding require their own affected review.

## Scope, method, and endpoint

The owner reports 30 inert traces, 21 expected mutation refusals, recoverable corpus/map deltas, and matching closing fingerprints for 893 selected originals. It explicitly does not claim a fresh full Git/index/ref/worktree comparison. Those results should be independently checked at their actual scope; neither 700 verification checks nor the increased map size proves semantic completeness. :chatgpt-content-reference{index="11"}

The prompt uses two complementary read-only specialists with parent reconciliation. A satisfactory result may be:

```text
ES_MOUNTED_HELPER_TEMPORAL_STATUS_ACQUISITION_RELEASE_DESIGN_REVIEW_SATISFIED_IMPLEMENTATION_AND_LIVE_ADOPTION_PENDING
```

That would support separately authorizing the coupled migration—not installing the channel, issuing grants, or running mounted cases.

Remote scratch, survivor, and possible disconnected-observer state remain unknown. Actual issuer/channel/clock/feed/storage/target qualification, custodian enforcement, mounted proof, supported-local evidence, the unconditional whole-candidate ES audit, and exact-byte publication remain separate gates. :chatgpt-content-reference{index="12"}

## Inspection boundary and confidence

I read the complete attached report and the preceding correction prompt. The report’s measured identity is:

```text
11,655 bytes
SHA-256 3417b59e7ecf692473dd79762022b8aaf7b5fa2039fcefe6d809ef5ac262f4dd
```

The current **69,940-byte corpus, 1,420,104-byte map, review ZIP, and owner-check bodies were not inspected here**. Their detailed contents remain owner-reported. The handoff supplies their retained paths and known anchors; it requires measuring the current ZIP rather than inventing an absent digest.

**Sources:** attached correction report, preceding blocked review and correction handoff; limited primary Linux references for the explicitly separated socket-receive question. No repository commands, reviewed code, tests, sockets, hosts, or cleanup were executed here.

**Confidence: 0.96 in proceeding to this affected review.** Report-byte identity is measured; complete design coherence, implementation readiness, operational consent, and privileged readiness remain unestablished.
