## The exact-owner block is now authoritative

Keep:

```text
R6J_R26_ADMISSION_PREMISE_ISOLATORS_ARTIFACT_REVIEW_BLOCKED
```

The prior repair preserved its evidence correctly, but it did not fix the shared admission semantics. The next pass must repair the common reader logic—not add another layer of isolators.

### ES_R6J_R26_G05_ADMISSION_ACTIVATION_REPAIR_HANDOFF_20261024_31.zip[Download the R26.G05 admission-activation repair handoff](sandbox:/mnt/data/ES_R6J_R26_G05_ADMISSION_ACTIVATION_REPAIR_HANDOFF_20261024_31.zip)

:chatgpt-content-reference{index="1"}[Handoff verification](sandbox:/mnt/data/ES_R6J_R26_G05_ADMISSION_ACTIVATION_REPAIR_HANDOFF_20261024_31_VERIFICATION.json)

```text
Bytes:             1,107,551
Members:           29
SHA-256:           b886f2b6f52cec9281ba94fe62129268c7c2e19b30419dc71d3045baa241aff7
Verification:      PASS
```

The compact handoff includes the complete blocked review, exact current source files and fixed tables, current positive G/B/C, the 393-row register, 180-state table, dependency-graph analysis, a decision record, and the full repair task. It does not duplicate either large owner.

## Selected repair semantics

The handoff freezes three connected rules.

### 1. Sticky errors require an admitted, causally prior producer

The current reader computes known errors from all typed ordinary records before determining whether those records are admissible.

The successor must instead require:

```text
producer’s own ordinary admission succeeds
→ its error return becomes an admitted fact
→ that error is causally available before the later admission
→ only then may it contribute sticky state
```

For this bounded profile, an equal timestamp alone does not establish “before.” Absent an explicit causal relationship, the sticky error must satisfy:

```text
error_returned_at < later_admitted_at
```

A premise-invalid or unestablished request cannot poison another request’s scope.

### 2. Equal-time dependencies resolve through the explicit graph

The fixed table has:

```text
22 ordinary requests
20 producer-must-pass dependency edges
0 cycles
```

The successor must resolve each timestamp bucket by dependency closure or an equivalent topological fixed point. Request IDs may be used for stable report ordering only—not as a semantic tie-break.

This directly covers the two review examples:

```text
terminal-parent → terminal-directory
terminal-directory → retained-01-open
```

When producer and dependent share an admission timestamp, the explicit edge determines activation. Lexical spelling must not.

### 3. Candidate facts are not activated owner facts

`derive_prerequisite_candidates` may continue validating typed evidence. Its output must be divided into:

- candidate facts;
- activated ordinary owner/result facts;
- separately validated nonordinary wrapper/freeze facts.

An ordinary producer activates its facts only after its own complete admission succeeds. Ordinary wrapper/use semantics must consume the activated set—not all typed acquisition candidates.

Inherited C remains a one-use release authority and receives no new A/R/Q/clock requirement. In this selected profile, however, it must name an exact acquisition occurrence activated by its valid producer. An unestablished acquisition candidate cannot silently become a positive wrapper/C owner.

The repair does **not** invent a new profile for cleanup after an unauthorized-but-physically-observed acquisition. Such a profile would need an explicit future design decision rather than hidden reuse of the current owner map.

## The evidence requirement changes

The preceding R26.G04 rounds had:

```text
target-reader child invocations: 0
```

They were mixtures of retained G03 execution and static G04 predictions. The next owner must run its newly authored successor reader for the current full-reader obligations. Static continuation can remain historical evidence, but cannot establish the repaired reader’s behavior.

The handoff requires an early substantive checkpoint containing:

- the new activation/sticky/dependency rules;
- the successor reader;
- the current positive;
- the three review counterexamples;
- equal-time producer controls;
- a genuine earlier admitted sticky-error control;
- the seven current C replacements;
- actual successor-reader results.

After that save, the owner should complete the 393-row and 180-state reconciliation, preserving each control’s real evidence layer and historical purpose.

## Message to send

Send the handoff ZIP to the **same ChatGPT artifact-owner conversation that produced R26.G04**, not Codex:

```text
Repair the exact-owner R26.G04 block under NEXT_OWNER_TASK.md.

Read README_FIRST.md, DECISION_RECORD.md,
receiving/RECEIVING_INSPECTION.md,
receiving/DEPENDENCY_GRAPH.json, and the complete blocked review before
authoring. Authenticate the exact current owner already available in this
conversation.

Implement the bounded admission-activation model:

- only successfully admitted ordinary requests activate owner/result facts;
- sticky known errors must originate from an admitted producer and be
  causally prior to the later admission;
- equal-time producer dependencies must resolve through the explicit
  prerequisite graph, never lexical request order;
- ordinary wrapper/use/dispatch semantics must consume the same activated
  owner set as admission;
- inherited C remains one-use and independent of fresh ordinary authority,
  but cannot promote an unactivated candidate into a positive owner.

Preserve the normative pair, phase and direct NRC decisions, candidate
facts, historical counterpart bytes, seven C replacements, four
retirements, five unaffected controls, registers, state table and
displacement ledger.

Save and reopen the substantive repaired reader/results checkpoint before
broad regression. Run the newly authored successor reader for the actual
full-reader obligations; do not substitute static G04 predictions or
retained G03 execution for current reader execution.

Complete the finite regression, exact scoped reconstruction, preservation
evidence and verified delivery. Do not expand general joins, launch Codex,
access repositories or hosts, execute uploaded predecessor/reviewer
programs or claim independent acceptance.

Return the endpoint:

OWNER_R6J_R26_ADMISSION_ACTIVATION_REPAIRED_REVIEW_REQUIRED
```

If the original owner conversation is unavailable, start a fresh artifact-owner conversation and attach the two current-owner transport ZIPs together with this handoff. The predecessor transports are needed for the later independent review, not for ordinary successor authoring.

Codex remains premature. A different ChatGPT reviewer must inspect the repaired exact bytes before general-join design resumes.

**Sources:** exact current and predecessor owners; completed exact-owner blocked review; current `premises26.py`, `admission26.py`, `semantics26.py`; fixed prerequisite table and evidence registers included in the handoff.  
**Confidence:** **0.99** in the three confirmed defects and input identities; **0.96** in the selected shared-semantics repair. Successor correctness and independent acceptance remain unestablished.
