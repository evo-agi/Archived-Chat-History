## Retain the block; repair the seven defects in one R9.25 successor

The R9.24 review is decisive. The topology and ownership architecture largely survived, but repository adoption remains blocked by:

- two authority/protocol binding defects;
- one unrecoverable journal-commit boundary;
- incomplete canonical byte rules;
- an unnecessarily broad receiver capability;
- controls that mostly test precomputed conclusions rather than source facts;
- stale reconstruction-spec provenance.

These should be corrected together because they affect the same contract, wire schemas, profiles, controls, bindings, checkpoint, and evidence chain. Do **not** return to Codex.

### ES_R6J_R925_PROTOCOL_CLOSURE_REPAIR_HANDOFF_20261026_02.zip[Download the self-contained R9.25 repair handoff](sandbox:/mnt/data/ES_R6J_R925_PROTOCOL_CLOSURE_REPAIR_HANDOFF_20261026_02.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_R925_PROTOCOL_CLOSURE_REPAIR_HANDOFF_20261026_02_VERIFICATION.json)

```text
Bytes:             69,903,402
Members:           39
Manifest payloads: 38
SHA-256:           4386844889bcabad89788c5705502690843ab6a4531b30f84757f7de114cd2fa
Verification:      PASS
```

The handoff embeds the exact blocked R9.24 owner, the complete blocked review, frozen R9.25 decisions, selected current files, and the complete owner task. No other attachment is required.

## Selected R9.25 corrections

### 1. One exact P action vocabulary

The third action is frozen as:

```text
emit-authenticated-outside-observation-evidence
```

The complete allowed-actions value becomes one exact ordered tuple:

```text
observe-runtimehelper-supervisor-identity
wait-runtimehelper-supervisor
emit-authenticated-outside-observation-evidence
```

There are no aliases and no inferred set semantics. Wrong spelling, order, duplicates, or unknown actions refuse.

### 2. `endpoint_nonce` becomes part of signed consumption authority

The endpoint nonce must now appear in:

- the consume request;
- the issuer’s durable consumed row;
- the immutable signed receipt;
- the receipt signature input;
- observer and receiver receipt verification;
- the receipt wire schema;
- the handshake and endpoint-manifest joins.

A receipt bound to another endpoint must refuse at the permit-binding predicate, not at a later transport or profile check.

### 3. Replace the ambiguous state-file commit with an append-only commit record

The R9.24 rename-plus-directory-`fsync` model is replaced by an append-only source journal:

```text
JournalFrameV2
→ JournalCommitV2
→ fdatasync journal
→ re-read and validate transaction
→ publish committed state
→ send AckV1
```

Recovery classifies a transaction as committed **only when a complete valid frame-and-commit pair survives and extends the prior valid commit chain**. It no longer tries to infer whether a directory-`fsync` call returned before a crash.

`SOURCE_STATE.json` becomes a regenerable cache, not durable authority.

`final_ack_sequence` is removed from durable receiver state. Receiver durability cannot prove that the observer received an ACK. Final success instead requires:

- receiver’s durable COMPLETE commit;
- observer receipt of the matching final ACK;
- terminal process and namespace conditions;
- successful outsideobserver exit.

### 4. Fully specify canonical JSON bytes

The handoff selects `r6j-canonical-json/v2`, including:

- valid shortest-form UTF-8 only;
- Unicode scalar values only;
- no surrogate code points or surrogate escapes;
- exact UTF-8-byte key ordering;
- no whitespace;
- no floats, exponent notation, leading zeros, plus signs, or negative zero;
- exact escaping for quotation mark, reverse solidus, controls, and short escapes;
- solidus must remain unescaped;
- printable ASCII and non-ASCII scalars must not be represented with `\u` escapes;
- lowercase hex for required control escapes;
- re-encoding must match the received bytes exactly before signature or hash use.

The control plan explicitly includes alternate slash, Unicode, surrogate, hex-case, key-order, duplicate-key, integer, whitespace, and invalid-UTF-8 forms.

### 5. Remove `CAP_DAC_OVERRIDE`

The receiver no longer receives any capability.

The selected endpoint-root model is:

```text
/run/governed-execution/r6j
owner: root:es-r6j-endpoint
mode: 2770
```

The receiver is a member of `es-r6j-endpoint`. Per-run directories inherit that group, while only the exact per-run directory is mounted into the task.

The receiver unit has:

- empty capability and ambient-capability sets;
- `NoNewPrivileges`;
- strict filesystem and kernel hardening;
- `AF_UNIX` as its only address family;
- write access only to the endpoint root and receiver journal root.

This removes the process-wide privilege rather than relying on an unenforceable “use it only under this path” rule.

### 6. Replace assertion-toggle controls

The control model may no longer contain `derived_assertions` as input.

Every predicate must be derived from:

- architecture fields;
- raw canonical bytes;
- event traces;
- state transitions;
- cross-record identities and chronology.

All **65** controls that currently flip a precomputed assertion must be replaced by actual semantic mutations. The remaining **39** exact-field controls must be revalidated.

A negative receives credit only when:

1. unrelated package, pair, schema, and binding checks pass;
2. the named semantic predicate is the first failure;
3. no stale hash, parser exception, expected-output toggle, or later gate supplies the result.

The constructor and checker must use separately authored rule sources.

### 7. Regenerate reconstruction evidence from the exact spec

The delivered reconstruction specification is:

```text
3,243 bytes
SHA-256:
171ee9faf941b9d18de930554d77146688499ac3a3d7f2e8235e2457d2c26a74
```

The old result incorrectly declared:

```text
16e8aebf3659092ad1ce63490da631a4d7a6e9973fa549c80cb16daee9c0dd27
```

The successor checker must hash the exact spec file it parses, refuse stale or substituted bytes before evaluating controls, and compare reconstructed output with the exact final-owner manifest—not merely route-owned expected rows.

## Message to send

Send the handoff ZIP to a **fresh ChatGPT artifact-design owner conversation**, not Codex or the blocked-review conversation:

```text
Continue as the artifact-only design owner for the R9.25 outside-observer
protocol correction.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md, every
record under analysis/, receiving/RECEIVING_INSPECTION.md, the complete
blocked review, and NEXT_OWNER_TASK.md before authoring.

Authenticate the embedded exact R9.24 owner and blocked review.

Preserve the accepted R9.21/R9.22 ownership model and the reviewed
R9.23/R9.24 topology, PID1, Wait/reap, SPIFFE, endpoint-authentication,
stage-gating, modeled-profile, active-map and nonclaim semantics except
where the frozen R9.25 records explicitly replace a conflicting protocol,
durability, privilege, validation or reconstruction rule.

Author the complete successor under:

R6J-ES-NATIVE-OUTSIDE-P-PROTOCOL-CLOSURE/v1
R9.25

Implement every frozen decision in the handoff:

- one exact ordered P action tuple using
  emit-authenticated-outside-observation-evidence;
- endpoint_nonce in the durable consumption row, signed receipt, signature
  input, wire schema and receipt verification;
- r6j-canonical-json/v2 with complete string, Unicode, integer and
  byte-equality rules;
- append-only JournalFrameV2 and JournalCommitV2 recovery semantics;
- SOURCE_STATE.json as a regenerable cache only;
- removal of final_ack_sequence from durable source state;
- a capability-free receiver with the selected setgid endpoint root and
  systemd confinement;
- no derived_assertions in dynamic control input;
- replacement of all 65 assertion-toggle controls with source-field,
  raw-byte, event-trace or state-transition mutations;
- exact reconstruction-spec hashing and final-owner comparison.

Update every normative, frozen, architecture, migration-map, profile,
active-map, binding, control, checkpoint, validation, reconstruction and
package surface consistently.

Save and reopen a substantive checkpoint before broad control expansion.
The checkpoint must include representative actual artifact-reader results
for all seven blocker families.

Run the final frozen suite twice using one final reader/input generation.
Retain exact commands, stdout, stderr, exits, structured results and
byte-repeat comparisons. No parser error, stale hash, expected-result
toggle or unrelated gate may receive semantic-negative credit.

Produce both checked-before reconstruction routes, stale-spec and
final-owner guards, complete preservation evidence, one verified owner,
direct checkpoint, validation-evidence ZIP, delivery envelope, external
receipt, identities and fresh-review task.

Keep all implementation, repository-adoption, authority-issuance,
credential-qualification, production-wiring, runtime and independent-
acceptance flags false.

Do not launch Codex, access repositories or hosts, execute uploaded
programs, implement source, issue credentials, adopt the proposal or claim
live qualification.

Return actual downloadable artifacts only under:

OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_COMPLETED_READY_FOR_FRESH_REVIEW
```

## Next gate

```text
R9.25 corrected owner
→ different fresh artifact review
→ repository-adoption decision
→ authenticated clean/stable baseline
→ Stage A contracts/docs/schema/tests only
```

The five architectural surfaces that passed R9.24 should not be reconstructed again unless the R9.25 changes expose a concrete contradiction.

**Sources:** `R6J_ES_NATIVE_OUTSIDE_OBSERVER_PROTOCOL_ARTIFACT_REVIEW_BLOCKED_20261025_01.zip`; exact blocked R9.24 owner embedded in the linked handoff; review `FINDINGS.json`, `REQUIREMENT_MATRIX.json`, `CONTROL_ADEQUACY.json`, and `SOURCE_INDEX.md`.

**Confidence:** **0.999** in the seven blocking findings and package identities; **0.97** in the selected R9.25 corrections. Independent architectural acceptance remains pending.
