**Proceed to a fresh, read-only independent re-audit of the cumulative lifecycle successor. Keep both the ES candidate and the external tooling frozen.** The report supports completing the engineering repair phase—not independent closure of all findings or readiness for privileged execution. :chatgpt-content-reference{index="0"}

**Send this to a fresh Codex audit conversation, not the implementation conversation: :chatgpt-content-reference{index="15"}[Lifecycle successor independent re-audit prompt](sandbox:/mnt/data/ES_Lifecycle_Repair_Reaudit/ES_Lifecycle_Repair_Independent_Reaudit_Prompt.md).**

No further implementation, test rerun, device provisioning, gateway installation, or host operation is authorized by that handoff.

## What this result establishes

The reported repair addresses the actual failure paths identified by the previous audit: cancellation now reaches active work; partial loop-request state survives later failures; formatter escalation follows group liveness; finalization retains the original deadline; approval relationships are acyclic; node evidence is bound to its reported identities; and ambiguous cleanup invalidates post-state until fresh observations resolve it. Those are the correct mechanisms to inspect independently—not merely a larger collection of passing tests. :chatgpt-content-reference{index="1"}

The evidence remains divided into distinct categories:

| Evidence | Reported result | Scope |
|---|---|---|
| Local tooling unit and race suites | **344 run/pass events in each**, with 37 required top-level MH-CUM regressions | Darwin execution of the external tooling and its substituted-effect controls |
| Linux/AMD64 vet and supervisor builds | Passed; deterministic A/B binaries matched | Static/build evidence; supervisor never executed |
| Seven ordinary-user Linux controls | Inherited for the identical safe executable and selected import closure | Previously observed safe mechanics—not the changed supervisor |
| Normal and diagnostic proof binaries | Unchanged and retained | Compile-only; no mounted case executed |

The report distinguishes selected-test skips from the two command packages that contain no tests. The audit should preserve that distinction and derive coverage from the actual streams, rather than accept the totals as its oracle. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

**There is no reason to rerun the seven Linux controls simply because `internal/proof` changed.** Their reuse is justified only for the unchanged safe executable and its selected dependencies; it supplies no execution evidence for the repaired supervisor. The report explicitly maintains that boundary. :chatgpt-content-reference{index="4"}

The reported change remains external-only: six additions and 23 modifications in the helper’s source, with no driver, instrumentation, safe-mechanics, dependency, or ES repository change. The independent review must verify that exact delta. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

## Two qualifications must survive the re-audit

### 1. Deadline-aware finalization is not yet a hard completion guarantee

The report says finalization now uses the original absolute deadline and separates primary outcome, adjudication, publication, durability, and late completion. It also expressly leaves **hard wall-clock acceptance blocked**, because the current mechanism cannot preempt every synchronous write, synchronization, close, or kernel wait. :chatgpt-content-reference{index="7"}

The reviewer must therefore make separate judgments about:

- whether the previously unbounded finalization path now obeys the selected deadline and status contract;
- whether late, incomplete, or missing evidence can still be misreported as success;
- what external observation or enforcement is actually required for the stronger completion claim.

**Recording that a deadline was exceeded would not, by itself, satisfy a requirement to stop effects by that deadline.** Nor does naming an external owner establish that such an owner exists.

This does not require another watchdog implementation before reviewing the current code. The preceding repair scope deliberately permitted this stronger claim to remain unresolved. The audit should determine whether the component is internally correct under that qualification, while keeping the unfulfilled execution requirement blocked—not mark MH-CUM-04 wholly closed or reject the permitted scope merely because it did not implement a new subsystem.

### 2. The proposed loop-object lease is a recommendation, not an adopted design

The report recommends a separately governed, pre-provisioned exact loop-object lease, with provisioning, exclusivity, retirement ownership, approval binding, and revalidation outside the helper. It states that this recommendation was **neither implemented nor acted on**. The current live allocation path remains fail-closed without an independently established residual policy. :chatgpt-content-reference{index="8"}

**I am not adopting a lease/provisioner subsystem through this handoff.** The reviewer must first establish how the recommendation relates to the current request-and-selection implementation.

In particular, it must determine whether the existing interface can consume that exact resource arrangement, whether a selector or handoff change would be necessary, and whether the proposal resolves the residual problem rather than transferring it to another unspecified actor. A claim that an object was pre-provisioned must not substitute for proving that the helper actually used the authorized object.

The next audit may recommend the smallest sufficient treatment. It may not accept a persistent host effect, create removal authority, or treat the recommendation as an installed capability.

These unresolved questions do **not** prevent review of the repaired code. They do prevent that review from becoming an execution authorization.

## What the independent review must do

The prompt covers the complete **42-row lineage**—F-1…F-16, V2-01…V2-16, LIO-01, and MH-CUM-01…09—with individual dispositions. That is not a demand to reopen every historical defect. Previously accepted subclaims should carry forward where their dependencies remain sound; new interactions and unresolved portions still need judgment. The owner’s report preserves this same distinction. :chatgpt-content-reference{index="9"}

The highest-value review is the connection between the portable helpers and the **actual Linux adapter**. For partial acquisition, the auditor must inspect failure windows inside multi-operation methods—not accept an all-or-nothing fake acquisition as proof that intermediate custody survives. For formatter termination, it must inspect the real caller of the shared decision routine. For cleanup, it must examine independently reported substatuses, not only aggregate `Clean`.

The administrative repair also needs source, validator, template, and documentation review together. The selected relationship is now reported as:

```text
Import approval → completed import observation
                → run approval binding that exact observation
                → run request that cannot substitute another episode
```

That is the intended interface. Synthetic positive controls establish neither a real approval source nor an installed trusted entry. The report explicitly says those remain absent. :chatgpt-content-reference{index="10"}

Finally, tightening the adjudicator must remain compatible with the unchanged driver. The reviewer must check both that required normal evidence cannot be omitted and that an intentional refusal is not required to supply facts it legitimately never observed. Diagnostic instrumentation remains supplementary, different effective source; it cannot fill missing normal-binary evidence. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

### Preserve the generation history without another validation cycle

Generation 1 reportedly had no command or test failure. It was superseded because the evaluator used `bytes` instead of the binary inventory’s `size` field. Generation 2 then completed the permitted full sequence under the corrected evaluator. The audit should authenticate that account, retain both decisions, and credit the designated generation—not turn the first generation into a source failure or request another rerun. :chatgpt-content-reference{index="13"}

## The next decision remains scoped

A satisfactory result may be:

```text
ES_MOUNTED_HELPER_LIFECYCLE_STATIC_REVIEW_SATISFIED_POLICY_ENTRY_RUNTIME_PENDING
```

That means the current component is statically satisfactory under explicit prerequisites. A lost effect, contradictory contract, false cleanup status, or late-success path must instead remain a blocking finding; it cannot be filed under “policy pending.”

Administrative establishment, target and formatter qualification, hard-deadline support, privileged mounted execution, deployment observation, supported-local consumer/operator proof, the **unconditional whole-candidate ES audit**, and exact-byte commit authority remain outstanding. This external-tooling review substitutes for none of them. :chatgpt-content-reference{index="14"}

### Sources, limits, and confidence

I verified the attached report’s **19,523 bytes** against SHA-256 `c73a0cff…417605`. The current ZIP, implementation, effect-to-control matrix, and raw streams were not attached here; their detailed authentication and execution remain owner-reported. The prompt names their retained local paths and expected identities, so the fresh Codex auditor can inspect them without another collection task.

Include the **existing engineering ZIP with the audit result** for direct source review here; it does not need rebuilding.

**Sources:** attached lifecycle repair report and preceding cumulative audit. No repository code, tests, host commands, or privileged operations were executed in this review.

**Confidence: 0.96 in this handoff.** Report-byte provenance is verified; implementation closure and validation acceptance await independent review. Residual-policy sufficiency, privileged readiness, and whole-candidate acceptance remain unestablished.
