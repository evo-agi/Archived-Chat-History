**Proceed to a fresh artifact-only review of the exact four-member cohort. Keep expansion to a fifth lifetime paused.**

### Review handoff

ES_R6_REPRESENTATIVE_COHORT_FRESH_REVIEW_HANDOFF_20261015_01.zip[Download the self-contained representative-cohort review handoff](sandbox:/mnt/data/ES_R6_REPRESENTATIVE_COHORT_FRESH_REVIEW_HANDOFF_20261015_01.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification record](sandbox:/mnt/data/ES_R6_REPRESENTATIVE_COHORT_FRESH_REVIEW_HANDOFF_20261015_01_VERIFICATION.json)

```text
Bytes:             6,136,219
Members:           9
Manifest payloads: 8
SHA-256:           04f391f275565233a6e1db3b91a2fcb14f858da9c9805763aad3e0a7527c3a64
Verification:      PASS
```

The package contains:

- the exact current delivery wrapper;
- the direct inner owner package for byte comparison;
- the prior one-candidate corrected owner package;
- the prior fresh review that satisfied F-001/F-002;
- the independent review task;
- receiving-side measurements and exact-delta checks.

No additional upload is needed.

## What I verified

The uploaded identities match the owner’s report:

```text
Delivery ZIP
1,611,347 bytes
1ea26a8f38cd7c542652114a2911ebc2cde7343c78e86ed9a6ffb914e01656b2

Inner owner ZIP
1,693,560 bytes
19ddc664af989992d1610687c4602ad42d7eb9288b70522c8c7b2034887dcaf1
```

The delivery’s nested owner ZIP is byte-identical to the direct upload. Both manifests reproduce their exact payload membership, bytes, hashes, encoded modes, and CRCs.

The current pair is internally bound:

```text
TEMPORAL_CONTRACT.md
346,599 bytes
0ec5c64d74b84bd18cad1f2c719d4befd38ce60d232a8d469c3688e1aa8cf4d1

TEMPORAL_CONTRACT_MIGRATION.json
2,173,863 bytes
4e150f637854d75492535a981b790ec5bcf861225b56babdc67e2211c9873427
```

I independently replayed the checked-before-image changes from the reviewed predecessor:

- contract: **19 operations**, exact successor bytes;
- migration map: **59 operations**, exact successor bytes.

The matrix contains exactly nineteen ordered references and the declared exact cohort:

```text
ordinary-disjoint-roots-accept
disjoint-sibling-binds-accept
same-object-binds-reject
same-object-binds-reject:diagnostic
```

The other fifteen rows remain uncredited and retain default identity projection in the supplied preservation records.

The ordinary specimen’s native stream and projected body are byte-identical to the prior reviewed one-candidate package. RC01 and RC02 are likewise byte-identical to their prior historical versions.

## The main review risk

The first candidate uses **actual retained reviewed native/body bytes**. The three additions use **owner-modeled 50-record histories**, derived from retained ProcessRecords, source bindings, measured field values, and the reviewed causal template.

That modeling may be valid, but it is the principal issue the fresh reviewer must decide. In particular:

- whether each candidate’s retained evidence really supports the same causal sequence;
- whether no candidate-specific transition, error form, knowledge cut, authority rule, or ownership rule is missing;
- whether `same-object-binds-reject` is correctly treated as a successful expected refusal rather than an operational failure;
- whether the diagnostic account remains supplementary, separately source-bound, and never successor-eligible by itself;
- whether the specialization and string exceptions remain confined to the exact four-member cohort.

The owner’s four positive results, 44 controls, and preservation records are authenticated **owner evidence**. I did not execute the projector/checker or independently reproduce its semantic decisions.

## Message for the fresh reviewer

Start a **new ChatGPT conversation that did not author the cohort package**. Do not use Codex. Attach the single handoff ZIP and send:

> Perform the fresh artifact-only representative-cohort review defined in this handoff. Read `README_FIRST.md` and `REVIEW_TASK.md`, then authenticate every input ZIP before semantic inspection.
>
> Review whether the exact four-member R9.19 cohort is supported by the retained ProcessRecords, source bindings, measured field values, modeled native histories, and the previously reviewed R01–R05 causal language.
>
> Pay particular attention to the evidence distinction between the actual retained `ordinary-disjoint-roots-accept` history and the three source-derived modeled additions; normal expected-refusal versus operational-failure semantics; the distinct diagnostic-effective source and non-rescue rule; the closed 25-transition union; the one-way `controller.receive → adapter.response-received` mapping; candidate-scoped string exceptions; and preservation of the other fifteen lifetimes without semantic credit.
>
> Treat owner results and the receiving inspection as evidence to check, not acceptance. Independently replay the pair changes and inspect the actual matrix, specimens, ProcessRecords, controls, and preservation registers.
>
> Do not execute uploaded programs, launch Codex, access repositories or hosts, repair the package, implement runtime code, or expand any candidate lifetime.
>
> Return the supported scoped verdict and actual downloadable review artifacts, with method and evidence limits explicit.

The permitted verdicts are defined in `REVIEW_TASK.md`, including:

```text
R6_REPRESENTATIVE_COHORT_R01_R05_ARTIFACT_REVIEW_SATISFIED_EXPANSION_CLASSIFICATION_PENDING
R6_REPRESENTATIVE_COHORT_R01_R05_ARTIFACT_REVIEW_BLOCKED
R6_REPRESENTATIVE_COHORT_R01_R05_ARTIFACT_REVIEW_INCOMPLETE
```

A satisfactory review should lead to an **expansion-classification decision** for the remaining fifteen lifetimes—not automatic expansion.

**Sources:** the two uploaded cohort ZIPs, the prior corrected one-candidate owner package, and the prior satisfied fresh review, all included unchanged in the handoff.  
**Confidence:** **0.99** in archive integrity, pair binding, matrix counts, exact predecessor comparisons, and reconstruction; **0.96** in proceeding to fresh review. Cohort semantic correctness and broader R6 acceptance remain unestablished.
