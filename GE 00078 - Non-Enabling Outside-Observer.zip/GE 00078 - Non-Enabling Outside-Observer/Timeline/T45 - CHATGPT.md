**Retain `BLOCK`. The next step is one combined external lifecycle repair—not another ioctl tweak, gateway installation, or ES-validation cycle.** The audit independently accepts the narrow ioctl correction but demonstrates failures in cancellation, partial resource acquisition, termination, final accounting, and evidence binding. Those are source defects, not merely unexecuted runtime checks. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation, not the audit conversation: :chatgpt-content-reference{index="18"}[Cumulative lifecycle repair prompt](sandbox:/mnt/data/ES_Cumulative_Lifecycle_Repair/ES_Cumulative_Lifecycle_Repair_Prompt.md).**

The task keeps the ES candidate frozen and authorizes only local, ordinary-user repair and validation of the external tooling. It authorizes no host contact, device access, privileged execution, gateway implementation, or mounted work.

## What this audit settles

The completed ioctl repair and retained validation should not be reopened indiscriminately. The auditor independently reproduced the source/build/artifact bindings, accepted the actual `IoctlRetInt` call and valid-zero handling, and replayed both the local control streams and the seven inherited ordinary-user Linux controls. None of that establishes execution of the privileged supervisor or either proof binary. :chatgpt-content-reference{index="1"}

**The remaining problem is the complete lifecycle around those correct primitives.** For example, the request wrapper can return the right loop number while the caller subsequently loses that selection and its descriptors when opening or configuring the candidate fails. Likewise, correctly implemented cancellation primitives do not help when the controller deliberately disconnects active work from their cancellation signal. :chatgpt-content-reference{index="2"}

This calls for reviewing and testing the actual transitions from entry through final result—not adding another count of isolated passing controls.

One scope correction is necessary: the report defines **MH-CUM-01 through MH-CUM-09**, but its continuation list names only 01–06. The new prompt includes all nine. It preserves the historical 33-row matrix rather than treating these as 42 unrelated defects or claiming every previously repaired finding has reopened. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

## The repair must follow ownership through failure

The substantive work is grouped around the affected transitions:

| Findings | Required correction |
|---|---|
| **01 and 04 — cancellation and total deadline** | Active work inherits cancellation; cleanup has an explicit reserve; ledger closure, adjudication, export, and closeout remain inside the original lifecycle budget. |
| **02 and 07 — partial acquisition and cleanup status** | Request, selection, opened descriptors, association, and residual uncertainty remain separate state. Post-effect inventory cannot inherit a pre-effect success. |
| **03 — formatter termination** | Escalation depends on surviving owned-group state, not merely whether the leader was reaped. |
| **05 and 06 — administrative and evidence bindings** | One authoritative approval selects the import episode; exported root-node and source-coordinate evidence must agree with the identities it claims to represent. |
| **08 and 09 — result precision** | Separate occupied-device refusal from syscall failure, and remove the unsupported claim about the loop-number ceiling. |

These are the audit’s concrete defects and corrections, not a proposed replacement architecture. :chatgpt-content-reference{index="5"}

### Partial acquisition must remain visible even when no association was acquired

MH-CUM-02 is more specific than “cleanup might fail.” The current adapter stores the control descriptor and selected pathname, but can return an empty observation after a later failure. The controller records custody only when `Acquired` is true. Cleanup can consequently remove the image pathname while owned descriptors remain open until process exit. **The primary result still fails, but its cleanup and image-state representation can be false.** :chatgpt-content-reference{index="6"}

The successor must therefore track, independently:

```text
request intent
→ request outcome or uncertainty
→ selected candidate
→ opened/qualified candidate
→ configured association
→ observed release
```

Descriptor ownership cannot depend solely on reaching the association stage. Nor can closing the helper’s descriptors establish that global loop-object inventory has returned to its original state.

The prompt requires failures at the real internal boundaries: after the request’s possible effect, after selection, during bookkeeping, open, status, configuration, close, inventory, and scratch removal. An all-or-nothing fake `Acquire` operation would conceal the same problem again.

### A deadline argument is not an interruption mechanism

The cancellation correction itself is straightforward: use cancellation-preserving contexts for setup and cases, and deliberately uncancelled contexts only for the named cleanup/evidence reserve. Go’s documented `WithoutCancel` behavior corroborates the audit’s diagnosis: it removes inherited cancellation and deadline information. :chatgpt-content-reference{index="7"}

MH-CUM-04 requires more care. Passing a context into closeout does not automatically make every file write or synchronization operation interruptible. Go documents that ordinary files generally do not support file deadlines. **The repair must distinguish deadline enforcement for dispatch, computation, and cancellable waits from potentially noninterruptible I/O.** :chatgpt-content-reference{index="8"}

The handoff prohibits three shortcuts: resetting the clock after failure, declaring success for completion after the acceptance deadline, or abandoning an untracked goroutine that may continue writing after the parent reports completion.

Where the existing mechanism cannot establish a claimed hard bound, that particular claim must remain qualified or blocked. Merely threading `ctx` through the signatures is not sufficient closure.

## Two operating decisions are explicit in the handoff

### Run approval selects the completed import observation

The audit found conflicting normative statements: one gives the run request responsibility for selecting the import observation, while another says run approval binds it; the approval type does not contain the corresponding field. That is an unresolved authority relationship, not just inconsistent wording. :chatgpt-content-reference{index="9"}

**My selected direction is that the independent approval/policy owner selects the exact import episode.** The sequence becomes:

```text
Import approval: approved bytes, destination intent, required pre-state
→ Import observation: actual installed objects
→ Run approval: exact completed import-observation digest
→ Run request: references that approval without substituting another episode
→ Run observation: execution evidence
```

The successor must align types, validators, templates, examples, and prose with that relationship. Import approval cannot reference evidence that does not yet exist, and an observation of installed objects cannot be required before the import that creates them.

This decision defines the external interface. It does **not** implement an administrative gateway, create an approval, or require the user to manually approve each routine substep. The eventual trusted entry still needs its own implementation and review.

### The loop residual is neither implicitly accepted nor removable

The audit confirms that the helper cannot establish whether `GET_FREE` returned a pre-existing unbound object or created one. It also cannot derive removal authority from the returned index. Adding removal, scanning, resetting, or detaching would broaden the effect boundary and could touch foreign state. :chatgpt-content-reference{index="10"}

**I am not accepting that persistent host effect merely to clear this gate.** For the next repair, the treatment is fixed:

The possible effect must remain explicit in the result; owned descriptors must be released correctly; no global-restoration claim may be inferred; and missing or unresolved residual policy must block live allocation before its first possible effect. No removal authority is added.

This is a conservative interim rule, **not a final decision to permit the residual**. The prompt requires Codex to read the auditor’s actual residual-policy record and return one source-grounded recommended final treatment. That record was not attached here, so I will not pretend to have reviewed its alternatives.

There is no need to install the administrative entry or qualify a remote formatter before repairing these known local source defects. I am separating **interface consistency and honest state representation now** from **actual privileged establishment and effect authorization later**. That changes the audit’s proposed ordering without waiving its unresolved obligations. :chatgpt-content-reference{index="11"}

## Validation should target the branches the audit exposed

The next task must use the actual controller and the shared decision routines called by the live Linux adapter, with only their effects substituted.

The important controls are not another generic fault count. They include cancellation **after** an effect has started, a reaped formatter leader with a surviving group, successful pre-inventory followed by an ambiguous unmount, and node arrays whose hashes are valid but whose root identities disagree with the separately reported identities. Those cases directly address the audit’s demonstrated paths. :chatgpt-content-reference{index="12"}

The local execution scope is the external tooling’s unit/race suites, native and Linux vet, formatting/environment controls, and deterministic compilation. The isolated telemetry treatment stays intact; the audit has now verified the current effective settings rather than merely the requested environment. :chatgpt-content-reference{index="13"}

The rebuild policy remains selective:

**The supervisor gets new build identities and remains unexecuted.** The safe executable is rebuilt locally and compared with the previously executed bytes and selected dependency closure. When those remain identical, the seven Linux observations carry forward without another remote run. The normal and diagnostic proof artifacts carry forward only when their effective inputs remain unchanged; tightening the adjudicator does not automatically require changing or rebuilding the drivers.

That reuse is evidence-specific. The inherited controls do not validate the changed supervisor, and the diagnostic artifact remains supplementary instrumentation built from different effective source. The audit preserves both distinctions. :chatgpt-content-reference{index="14"}

## What success means

The next engineering endpoint is:

```text
ES_MOUNTED_HELPER_CUMULATIVE_LIFECYCLE_REPAIRED_LOCAL_CONTROLS_PASSED_POLICY_ENTRY_PENDING_REAUDIT_REQUIRED
```

That endpoint requires the known source defects to be repaired and the applicable local controls to pass. An unclosed implementation defect must not be hidden among the policy or runtime prerequisites.

The fresh independent successor review remains necessary afterward. Administrative establishment, target/formatter qualification, actual mounted cases, deployment observation, supported-local consumer/operator proof, the **unconditional whole-candidate ES audit**, and exact-byte commit authority remain outstanding. The external helper still owns no ES lifecycle, reclamation, publication, or Git authority. :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}

**The objective is one coherent repair of the remaining lifecycle paths—not another series of isolated fixes that each pass while the complete operation remains incorrect.**

### Sources, limits, and confidence

I read the complete attached audit and fingerprinted its **22,055 bytes** as SHA-256 `4ea398fd…2c5af2a`. The audit packet, current source, specialist reports, residual-policy record, and raw streams were not attached here. Their detailed findings and authentication remain independent-auditor-reported; the new prompt requires reading those retained artifacts before editing.

Sources are the attached cumulative audit and retained engineering records, with official Go documentation used only for the cancellation and file-deadline distinctions above. No repository code, tests, host commands, or privileged operations were executed here.

**Confidence:** **0.98** in retaining `BLOCK`; **0.93** in this continuation. Attachment identity is established. Successor correctness, residual-policy sufficiency, privileged readiness, and whole-candidate acceptance remain unestablished.
