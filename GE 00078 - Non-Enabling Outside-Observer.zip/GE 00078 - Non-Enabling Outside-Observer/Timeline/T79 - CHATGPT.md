**Codex is right to keep privileged progression blocked. I would not implement the proposed entry foundation yet. The next decision is the external proof’s timing contract—not another missing adapter.** Static closure remains preserved; the operational report identifies no new receiver defect. :chatgpt-content-reference{index="0"}

**My selected direction is to explicitly rebaseline that contract before more implementation:** preserve deadline-governed dispatch, independently supervised stopping, strict proof-acceptance conditions, and unresolved-resource custody—but stop requiring this finite same-host proof to guarantee that every already-issued kernel or device effect physically ceases at an exact cutoff.

**Send this to the implementation/preparation Codex conversation: :chatgpt-content-reference{index="11"}[External proof deadline-contract rebaseline prompt](sandbox:/mnt/data/ES_External_Deadline_Rebaseline/ES_External_Proof_Deadline_Contract_Rebaseline_Prompt.md).**

This is a **contract-and-migration design task only**. It does not change the accepted helper, waive its current gate, authorize host work, or approve the resulting operational risk.

## Why I am changing the direction

The report’s diagnosis is precise. The existing external specifications require hard containment across potentially uninterruptible operations, yet no concrete actor, mechanism, effect authority, clock assumptions, or qualification evidence establishes it. A call admitted before the deadline can remain inside a synchronous operation and complete an effect afterward. Rejecting its late evidence does not prevent that effect. :chatgpt-content-reference{index="1"}

However, the proposed sequence is:

> Implement the entry/observation foundation → audit it → select and qualify the containment mechanism.

I disagree with that ordering. The mechanism and its failure contract determine what the parent must own, what termination means, what confirmation may assert, and what happens when termination cannot be established. Building those interfaces first risks another substantial implementation-and-audit cycle around an unresolved premise. :chatgpt-content-reference{index="2"}

**My earlier handoffs left this obligation with an unspecified external owner instead of resolving it.** We should not preserve that abstraction merely because the helper has accumulated tests and audited interfaces around it.

The choice now is not between safety and “just use a timeout.” It is between a clearly bounded, supportable proof contract and a stronger physical guarantee that would require separately selected infrastructure, failure assumptions, and effect authority. The report recommends retaining the latter. **I am selecting the former as the next design target, with the reduction stated explicitly rather than hidden in terminology.**

## What the replacement must—and must not—promise

The new draft must separate four claims:

| Dimension | Selected target |
|---|---|
| **Effect authorization** | One original authenticated deadline; action-adjacent checks; no self-renewal or continued authorized helper work after expiry or revocation. Preserve the non-atomic check-to-syscall qualification. |
| **Successful proof** | Complete case, cleanup, custody, and delivery evidence must satisfy the original deadline and independent semantic checks. Later retrospective verification remains permissible. |
| **Stopping and observation** | A concrete parent owns bounded stopping attempts and records actual process/resource observations. A request to terminate is not proof of termination. |
| **Unresolved failure** | Late or uncertain effects cannot produce successful proof or automatic conflicting reuse. Known resources and unknowns remain assigned to an explicit recovery responsibility. This is not a claim of physical containment. |

These are **proposed successor semantics**, not current implementation facts.

The deliberate reduction is the fourth boundary around physical completion: **an operation already in progress may complete late, and some failure paths may leave resources unresolved beyond the proof deadline.** Rejecting the result does not undo a late write. An operational hold on reuse does not physically stop the write either.

That risk must be explicit in the eventual target authorization. A custodian requiring the original physical cutoff would still have to reject this proposed execution profile. No approval of that weaker failure model is issued here.

### A process-control mechanism does not settle the stronger claim by its name

As limited external corroboration, Linux v6.17 documents `cgroup.kill` as killing the subtree through `SIGKILL`, with handling for concurrent forks and migration. It separately reports live-process occupancy through `cgroup.events`; it does not specify a universal deadline by which all previously issued filesystem or device effects have ceased. Linux’s task-state definitions also distinguish ordinary uninterruptible waits from killable waits. These sources support keeping signal, process-exit, and physical-effect claims separate—not treating a cgroup as an automatic answer to the report’s stronger requirement. :chatgpt-content-reference{index="3"}

This is not a claim that no stronger arrangement could ever work. Such an arrangement would need a defined failure model, independently effective enforcement boundary, qualified timing, and explicitly permitted effects. **No cgroup, VM, reset, hardware watchdog, or out-of-host fence is selected by this handoff.**

## This must be a real contract migration

The accepted source currently has stronger containment expectations. Therefore, the next task must not simply remove an entry check, set an old containment flag to `true`, or describe the new guarantee as what the old one always meant.

The prompt requires Codex to trace the exact clauses, approval fields, receiver predicates, confirmation statements, templates, and tests that carry the existing meaning. The report locates the decisive obligation in the external future-execution and receiver specifications; the next task must inspect those actual clauses and distinguish them from any independent ES requirement. :chatgpt-content-reference{index="4"}

The migration must preserve several important boundaries.

**One deadline still means one deadline.** The helper cannot extend it after a failure. Phase reserves stay inside the original bound. An independent administrative teardown authority, where necessary, must be explicitly scoped; it cannot silently revive the helper’s right to run cases, import artifacts, or publish successful completion.

**Late review remains different from late execution.** A receiver may verify genuinely timely evidence afterward. It may not accept an episode that finished or delivered required evidence late simply because its signatures and hashes agree.

**Failure evidence remains failure evidence.** A stopped leader is not necessarily an absent group. A successful close request is not necessarily established release. Missing observations remain unknown. The new contract must retain the custody distinctions that the completed repairs established.

**Old and new claims cannot be interchanged.** Where an existing field promises hard physical prevention, a weaker interpretation needs an explicit version or claim treatment. The task should identify the minimum necessary changes—not reflexively version every record, and not silently recycle a stronger field.

The existing 135-member source and its audit remain an exact historical checkpoint. Any subsequently changed temporal or acceptance contract needs its own affected validation and independent review; that does not erase the earlier observations or automatically require another ES-wide validation cycle. :chatgpt-content-reference{index="5"}

## What the next task should produce

The immediate deliverable is **one precise replacement contract and its migration map**, not the proposed `episodeentry` implementation.

It must define the failure model, distinguish authorization from completion, specify what successful proof actually establishes, and identify who remains responsible when the parent or kernel does not complete. It must also state how conflicting reuse would be prevented. Merely recording `recovery-required` is not an implemented enforcement mechanism.

The acceptance scenarios should include the paths that decide this contract: an operation submitted before the deadline but completing afterward; a paused or crashed parent; acknowledged termination with a surviving group; timely operations with late receipt delivery; timely complete evidence verified later; and unresolved resources when teardown authority expires.

Those are design and future-test obligations. **No fault experiment, new test run, or source change is authorized now.**

The new handoff also requires one concrete follow-on implementation tranche after the contract is reviewed: the smallest coupled documentation, schema, predicate, and assurance migration. The entry foundation then follows the resolved contract—not the other way around.

If the source inspection finds that an owning **ES** clause independently requires the universal physical guarantee, Codex must identify that conflict and stop before presenting an external-only redesign as sufficient. The ES admission, custody, staging, retained-result, and cancellation contracts are not being reopened by this task.

## Keep the useful parts of the operational plan

The report provides useful structure that does not need another general planning pass: a phase-only administrative entry, independent import and run approvals, parent-private custody, a distinct offline receiver, and explicit separation between the helper’s exit/receipt and the later independent decision. Those remain the proposed arrangement to evaluate against the revised timing contract. The entry actor is still unestablished. :chatgpt-content-reference{index="6"}

Two other tracks stay separate.

**Residual-policy consent remains unissued.** The possible single-`GET_FREE` unbound object is one specific effect. Consent to it would not cover arbitrary late writes, surviving processes, failed mounts, or incomplete cleanup. The report expressly preserves that distinction. :chatgpt-content-reference{index="7"}

**The present-state recovery proposal remains a proposal.** It now avoids demanding unavailable historical facts and describes a conditional current-object/process observation path. It still grants no deletion authority and establishes no current remote state. There is no reason to rewrite that proposal or retry the old recovery during the timing-contract work. :chatgpt-content-reference{index="8"}

The original scratch, survivors, and possible disconnected observer therefore remain unresolved. Local design progress cannot convert them into absent or recovered objects.

## The resulting gate

The intended next endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_CONTRACT_REBASELINE_SPECIFIED_MIGRATION_REVIEW_REQUIRED
```

It means the engineering decision is precise enough to review and implement. It does **not** mean the existing operational block has disappeared.

Trusted entry/storage establishment, actual target and formatter qualification, explicit failure-model and residual-policy authorization, mounted cases, deployment observation, supported-local consumer/operator proof, the **unconditional whole-candidate ES audit**, and exact-byte Git progression remain pending. Already valid native observations should be preserved at their original scope, not repeated merely to improve chronology. :chatgpt-content-reference{index="9"}

**The objective is to finish a defensible finite proof—not build progressively more infrastructure to sustain an unspecified stronger guarantee.**

### Sources, inspection boundary, and confidence

I read the complete transition report and the preceding operational-planning prompt. The attached report is **24,336 bytes**, with computed SHA-256:

```text
91dd5918581de44c8314dd64b3943bce6b27ad0bfa27e15efbd098991c8a2249
```

The transition ZIP, effect/dependency table, specialist originals, and accepted implementation were not attached here; their detailed contents remain Codex-reported. The new prompt requires their direct inspection before finalizing the migration. No repository commands, tests, host operations, or cleanup were executed here.

**Sources:** attached transition report and prior independent closure; primary Linux v6.17 documentation used only for the explicitly separated process-control semantics. **Confidence: 0.97 in retaining the operational block and changing the sequencing; 0.90 in the proposed external-contract direction, pending exact-clause migration review.** Privileged readiness and whole-candidate acceptance remain unestablished.
