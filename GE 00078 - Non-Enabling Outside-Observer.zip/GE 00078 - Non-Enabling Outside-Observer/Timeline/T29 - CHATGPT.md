**Keep the ES candidate frozen. The next step is a focused independent pre-execution review of the mounted-proof driver and its privileged setup/cleanup scripts—not immediate root execution.** The reported preparation disposition is appropriate: the driver compiled and the recipes were authored, but no mounted case ran and no execution authority was granted. :chatgpt-content-reference{index="0"}

**Send this to a fresh, read-only Codex conversation: :chatgpt-content-reference{index="15"}[Mounted-proof independent pre-execution audit prompt](sandbox:/mnt/data/ES_Mounted_Proof_Preexecution_Review/ES_Mounted_Proof_Independent_Preexecution_Audit_Prompt.md).**

This review is deliberately narrower than the eventual whole-candidate audit. Its purpose is to examine the **new privileged proof tooling before it operates on the host**, without repeating the completed local/native suites or reopening CUST-2’s selected design.

## What the preparation establishes

The mounted-proof requirement now has a concrete implementation proposal rather than an undefined future fixture.

The report identifies a Linux-only, package-local driver added to a disposable source copy: **all 358 original members remain unchanged, with one additional test file**. It specifies eleven cases covering ordinary and separately mounted disjoint roots, exact aliases, nesting in both directions, descendant mounts, a genuinely case-sensitive control, and three casefold cases. The driver reportedly uses actual production qualification and result-effect paths rather than a copied classifier or synthetic mountinfo. Those are the right properties to verify in its source. :chatgpt-content-reference{index="1"}

The build result establishes only that this source union produces a Linux/AMD64 test binary. The command was `go test -c`; the binary was not executed. Likewise, `bash -n` established syntax acceptance for the launcher and cleanup scripts, not safe execution or correct recovery. :chatgpt-content-reference{index="2"}

The preparation also preserves the distinction between the original candidate and the added proof instrumentation. **The 359-member source union is not a replacement identity for the validated 358-file candidate.** The existing local/native results remain bound to their original source and are carried forward as retained evidence, not new runs. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

## Why the privileged execution needs this review

The proposed effect is substantially different from the admission suites already run: **root setup and cleanup, one fresh 64 MiB ext4 image, one loop association, and 23 mounts in a new private mount namespace**. The candidate binary is intended to run afterward as UID:GID `1000:1000`, without supplementary groups or capabilities and with `no_new_privs`. That is a sensible proposed split, but its enforcement resides in the scripts—not in the report’s description. :chatgpt-content-reference{index="6"}

The report, rather than the actual review ZIP, was attached here. I therefore have not inspected the roughly 20 KB launcher, 5 KB cleanup script, 32 KB driver, or their detailed permission matrix. **I will not treat their hashes and successful syntax checks as sufficient justification for root execution.**

The new audit reads those exact retained artifacts directly on your Mac. Another collection task is unnecessary.

### Privileged entry and control-data custody

The reviewer must trace the first privileged instruction, exact executable and argument selection, input verification, and the transition to the unprivileged test process. It must establish who can change the scripts, binary, image, mount ledger, and cleanup instructions between verification and use.

The important distinction is between **test-writable synthetic data** and **root-owned control data**. The test’s output may be evidence; it must not supply unchecked paths or commands that determine privileged cleanup.

The privilege transition also needs separate checks for identity, groups, capability sets, inherited descriptors, and environment. `no_new_privs` prevents certain privilege gains across `execve`; it does not replace the initial privilege drop or establish complete confinement. The audit will verify the actual transition rather than accepting the flag’s presence as the entire security argument. :chatgpt-content-reference{index="7"}

### Namespace isolation and partial-failure cleanup

The reviewer must confirm that private propagation is established **inside the intended new namespace before fixture mounts begin**. Linux namespace cloning can preserve shared-mount propagation; namespace creation alone does not establish the intended isolation. :chatgpt-content-reference{index="8"}

More importantly, cleanup must be correct after **partial setup**, not just after eleven successful tests. The audit will trace failures immediately after resource acquisition, interrupted ledger writes, test failure, signal/timeout, namespace-owner exit, and evidence-return failure. It must distinguish the namespace in which unmounts are valid from the parent host namespace.

One concrete external-tool detail belongs in that review: util-linux 2.39.3 documents that a successful loop-device detach can mark an in-use device for later destruction rather than synchronously eliminate the association. Therefore, **successful `losetup --detach` cannot by itself establish completed cleanup**. The recipe needs the identity-bound residual checks it claims to provide. This is a review obligation, not a finding that the uninspected cleanup script is defective. :chatgpt-content-reference{index="9"}

### Proof validity, not merely expected errors

Each negative case must demonstrate the intended mounted relationship and reach the relevant production refusal. A permissions error, inadequate metadata, or failed fixture setup must not count as successful alias rejection.

The reported assertions—zero provider calls, no result artifacts, and unchanged protected identity/ownership/mode/entries/bytes—are useful. The reviewer must inspect how those assertions are made and whether the test states distinguish prohibited effects. Before/after equality alone does not establish that no transient or idempotent mutation was attempted; stronger claims need the corresponding production control-flow evidence. :chatgpt-content-reference{index="10"}

The audit must also verify that all eleven cases execute under the intended credentials, that one case’s mounts do not confound another, and that missing cases or skips cannot be accepted through a successful parent test or process exit.

## Do not turn runtime preconditions into another preparation loop

The host acquisition was correctly limited to support metadata. It observed the ordinary login’s lack of effective capabilities and loop-control access; it did not demonstrate mount authority. The report also explicitly leaves `/usr/bin/setpriv` and `/usr/bin/chattr` as unqueried fixed-path preconditions. :chatgpt-content-reference{index="11"}

Those facts should remain **finite preconditions for a later authorized execution**, not reasons to poll the host again or begin access remediation now.

The audit can conclude that the scripts are suitable for a bounded execution while still leaving root authorization and runtime capability checks pending. It must not grant itself permission to change sudoers, groups, AppArmor, sysctls, or service state. Conversely, it should not call the static review incomplete merely because a future authorized mount has not yet occurred.

Its successful disposition is therefore:

```text
ES_MOUNTED_HELPER_PREEXECUTION_REVIEW_SATISFIED_AUTHORIZATION_PENDING
```

—not a mounted-proof pass, whole-candidate `ACCEPT`, or execution authorization.

## The deployment hook is a separate, real dependency

The preparation identified a useful opportunity: the canonical supported-local proof has a window after bring-up and checking, but before its first execution loop, in which a running-namespace observation could be collected. **It also identified that the current wrapper lacks both the observation hook and the pre-start configuration-byte witness.** That is a concrete follow-on requirement, not an implemented capability. :chatgpt-content-reference{index="12"}

Do not add that hook during this review or silently incorporate it into the current freeze. A repository change would create new candidate bytes; an external observation mechanism would be additional proof instrumentation. Either treatment needs an explicit source and validation relationship.

The intended sequence remains: review the privileged fixture, authorize and execute its bounded mounted cases, separately prepare and run the supported-local proof with the permitted deployment observation, then perform the fresh whole-candidate audit and exact-byte staging/commit gate. No wider CP/Temporal revival or remote service-restoration program is implied. :chatgpt-content-reference{index="13"}

## Inspection boundary

I fingerprinted the attached **13,490-byte report** and confirmed that its complete source, candidate, archive, member-manifest, and required-inventory digests agree with the preceding attached assurance report. That is cross-report consistency—not authentication of the underlying 439-file preparation root or executable artifacts.

The new prompt supplies the exact retained paths and expected identities, requires source-level findings, and prohibits repairs or host execution during the audit. Please attach the **existing preparation review ZIP alongside the audit result**; it need not be rebuilt.

**Sources:** attached preparation and assurance reports; upstream Linux and util-linux documentation for the specific isolation, privilege, and cleanup semantics cited above. No repository code, tests, hosts, or VMs were executed here.

**Confidence: 0.96 in this next step.** Report-byte provenance is established; preparation and prior runtime results remain owner-reported pending artifact review. Privileged-recipe safety, mounted behavior, and whole-candidate acceptance remain unestablished.
