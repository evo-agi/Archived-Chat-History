ES mounted-helper — integrated terminal-lifecycle and proof-binding repair
Objective, posture, and stopping point
Use the existing implementation/preparation Codex conversation, not an independent audit conversation. As sole writer, repair LNX-NEW-01 through LNX-NEW-07 and PV-01 in a fresh external successor of the authenticated mounted-helper. Preserve the validated ES candidate and all historical evidence.
The latest independent result is ES_MOUNTED_HELPER_LIFECYCLE_REAUDIT_BLOCKED. Its retained tests authenticate; they do not establish correctness of the paths the audit found defective. Do not treat a passing portable helper test as closure of a different Linux caller.
This task authorizes one combined ordinary-user LOCAL source/document/test repair and its engineering validation. Establish the concrete terminal protocol and touched set first, then implement within this same task. Do not return another general design-only proposal when the decisions below suffice. Do not bundle independent audit into this task.
Success endpoint:
ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REPAIRED_LOCAL_VALIDATION_PASSED_REAUDIT_REQUIRED
Use it only when all eight current implementation findings have source-level repairs, the specified caller-level controls pass, and remaining implementation gaps are not hidden among policy/runtime prerequisites. Otherwise return ES_MOUNTED_HELPER_TERMINAL_LIFECYCLE_REPAIR_OR_VALIDATION_BLOCKED, retaining completed work and exact unresolved findings.
No endpoint grants administrative entry, residual acceptance, import, privileged or mounted execution, whole-candidate acceptance, staging, or commit.
1. Authoritative basis and exact inputs
Latest independent audit
Root:
/Users/ds/Downloads/ES-mounted-helper-lifecycle-independent-reaudit-WG9wOo48
Authenticate before derivation:
Artifact	Expected identity
ES_MOUNTED_HELPER_LIFECYCLE_INDEPENDENT_REAUDIT_REPORT.md	31,971 bytes; SHA-256 264838b9113c02c1049424f024e8e055605b17447b5c4b4cba206427fe1b037a
ES_MOUNTED_HELPER_LIFECYCLE_INDEPENDENT_REAUDIT_PACKET.zip	229,907 bytes; SHA-256 73bc2ca331273b0cd8c35db9eea54aefe0a59ab7be3d85c7aa8cfb9aaa86d859
FINAL_ARTIFACT_IDENTITIES.json	3,105 bytes; SHA-256 e0b98e69f3434b46743351a3a0ef7efc1c013736588aeafc64a4eef8775e85a2


Read actual packet paths for:
- excerpts/INSPECTED_SOURCE_EXCERPTS.md;
- all three specialists/SPECIALIST_*.md reports, preserving their scope differences;
- records/FINDINGS_CLOSURE_MATRIX.md;
- records/PREREQUISITE_AND_NEXT_DECISION_REGISTER.md;
- ES integration-boundary, source/build/delta/representation, retained-evidence, and provenance records.
Do not reconstruct missing content from report prose. The ChatGPT pass authenticated only the attached main report, not the ZIP or current implementation bodies. Its recommendations are engineering direction, not an independent source audit.
Rejected but authenticated source to derive from
Root:
/Users/ds/Downloads/ES-mounted-helper-cumulative-lifecycle-repair-jVPLxaaF
Artifact	Expected identity
ES_CUMULATIVE_LIFECYCLE_REPAIR_REPORT.md	19,523 bytes; c73a0cfffbfcc4507ab9cae94d20e18c379e29123c774eba5ecf8f3c0e417605
ES_CUMULATIVE_LIFECYCLE_REPAIR_PACKET.zip	837,324 bytes; 8f081d4ee8d365ab6c9aab5de045fd1ebcdf3368eed9386309d0d5b5b986143d
FINAL_ARTIFACT_IDENTITIES.json	2,927 bytes; 6ee883e92ffa91599f27eb2c3ddf5970a40752a8a7b42c883446dac5d3bab5fe
Packet manifest	49,518 bytes; eeccda78631cf3cd76e50a91748eec0a3f88d086fa3b8a39be84c88b3be97637; 392 payload rows plus the self-excluded manifest
External source manifest	96 regular members; 14,804 bytes; c7dd86145389fb92f556d03189ec99c4d46cf00c62740fe21de8e1a8d6217fd0
Build-input row digest	71 rows; ef0dc860f7e9bb0fe7d8555aef17c6c3439811a83c510d4575c2706b0397fda4
Build-input record	14,267 bytes; a28543cb0c5e9da564a0d941be121fba930dba2a5d7c9667d6526e06c28be619
Supervisor A/B	5,999,214 bytes each; d3b48e94d84a7e72aa4428dd79aada628373b58cc3ada5206c8ff07b9bf71f13; compile-only
Executed safe binary	4,497,174 bytes; c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75
Safe import closure	2,023 bytes; 739a10de46f4ccf3e2d341d764d651c80462c9cde53c1e6d4726c1c4c1adbbe3
Normal proof binary	23,583,914 bytes; bc4ff667d9280ee8ec671fc60bc23ec4e32e256b5084436588bcfb78292f4d0d; compile-only
Diagnostic proof binary	23,605,547 bytes; e2fc7baf9a7a9286f97dc3dbb95b74bba44c0b1d14d75c544b1f466d3d81edfb; compile-only


Verify safe unique relative paths, physical regular member types, permitted modes, sizes, digests, CRC and self-excluding complete coverage before extraction. Canonical source authoring modes, stored ZIP modes and private extraction modes are separate representations. Reconcile them explicitly; do not modify old roots or silently normalize them. Use authenticated embedded history instead of repetitively exporting the entire chain.
ES repository — preservation only
/Users/ds/Repositories/Execution Substrate
- Branch/upstream: trunk_dev / origin/trunk_dev.
- HEAD: b92bd9884106154d25342e1573dcc4c312311436.
- Tree: cdd4e44bac15c1952d70997143040644361f0bb1.
- Source: 358 rows, e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e.
- Candidate: 83 rows, 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2.
- Status: 83 rows, a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c.
- Frozen archive: 7,485,440 bytes, 12a8b8a626911d51dedf1b138b88deb314aff00d0de6ec063c96ac53d6146202.
- Archive-member manifest: 358 rows, 3e0195237c1b89fcb15242b886e17735c47d54b6710dd7ca8dafc1f6f63d4e5e.
- Required ES inventory: 327 rows, 8b3ed6e32ba809bda751632292773c9adc28096691ad9307be32affa288515eb.
- Zero staged/conflicted paths; no active operation; six worktrees.
Read current AGENTS.md, relevant latest PLANS.md, capability/configuration and execution-lifecycle docs before editing external material. Owning repo authority remains distinct from external helper contracts. Use the inspected, retained read-only provenance recipe with optional Git locks/fsmonitor disabled, and no external diff, textconv, hooks or filters. No fetch or ref/worktree write.
Capture full opening and closing source/candidate/status/diff/index/ref/worktree identity. Precisely disclose any historical same-object app-owned ref-name rotation; it is not a general exemption for drift. Task opening-to-closing must match or be reported as a blocker. Do not update ES PLANS.md or any other repository file.
2. Fixed decisions and effect boundary
Keep the component finite
Retain the supervisor / namespace worker / candidate / adjudicator model. Repair the actual ownership and evidence transitions. Do not introduce a daemon, generic recovery engine, new allocator, lease/provisioner, gateway implementation, external watchdog implementation, database, cross-repo component, new dependency, or additional mounted cases.
The current phase-approval graph and narrow ioctl corrections have independent support; preserve them unless one of the eight findings has a demonstrated dependency. The proposed pre-provisioned loop lease is not adopted. The current selector does not implement that proposal, and this task must not make the docs imply otherwise.
The exact residual-policy disposition accept-single-get-free-possible-unbound-without-removal remains an unapproved prerequisite. Missing approval refuses before the request. No host-global absence, creator identity, reservation, or removal authority follows from selection, ENXIO, own-FD closure, or image-path absence. Synthetic policy fixtures are controls only.
One owner carries time and observations through final publication
The same local lifecycle owner must retain the original monotonic-capable deadline through finalization. Display timestamps and persisted observations do not become time authority. Do not reconstruct an in-process control deadline from JSON/RFC3339, refresh the full budget, or silently extend the cleanup reserve.
The repair must be centered on a complete call path from controller entry to the published/returned result, not eight disconnected helper patches. Before writing implementation, record that call path and a concrete terminal artifact graph in the external owner/state document. Proceed directly once it satisfies the following rules.
Terminal evidence protocol: acyclic, single-writer, no self-attestation
Select one finite protocol, with exact producer/consumer rules, for the operational ledger, immutable semantic outcome, publication/seal evidence, returned receipt and failure record. Reuse existing custodial export mechanisms where suitable; this is not a new general transaction system.
1. Give the operational ledger a precise final boundary. Close/freeze it after its last covered operational event and cleanup observation. Publication acknowledgements must either be included before the final hash or be explicitly represented in a separate hash-bound terminal envelope. Do not export an unlabeled prefix and later claim it is the complete operational log. Do not recursively append publication-of-the-log events to the log being published.
2. Distinguish attempted rows, known appended rows, known durably committed rows and uncertain partial append. An in-memory append before a failed durable append cannot be advertised as a committed row. Unknown tail state refuses positive terminal acceptance; do not silently retry a possibly completed append or truncate historical evidence.
3. Freeze the exact semantic outcome once at a defined point. All representations claiming to contain that same outcome must have the same canonical bytes or binding digest. Explicitly separate that immutable operational outcome from later transport/publication/durability observations. Do not serialize result and then mutate the same claimed semantic object in memory.
4. A result or seal cannot attest to the future success of its own write/sync. Define what a reader must additionally observe before accepting the bundle, and what a returned publication receipt does and does not prove. Self-hashing and circular receipt graphs are forbidden. Missing, incomplete, late, conflicting or unavailable terminal confirmation never produces an accepted clean success.
5. Construct privately and publish through the existing exact-object/exclusive/no-follow custody. Final payloads, their manifest/seal and intended file/directory modes must be established before the durability operations that purport to cover them. Include the actual relevant directory/parent publication metadata. Retain held custody through final checks; do not replace it with a later pathname lookup.
6. Recheck the original deadline around finalization effects and classify late completion honestly. A completed operational outcome may remain historically true while its publication fails or is late; it must not masquerade as timely accepted completion. Never rewrite a sealed success into failure or leave an already readable provisional success usable without the required terminal confirmation.
7. Define a recognizable bounded failure closeout for the receiver, tied to the episode, affected bundle/attempt and available evidence. Try to export it only through already authorized paths and while the owning budget permits. If that also fails, return explicit publication uncertainty and use only the specified external-owner handoff. No private-only fallback may be described as successfully exported failure evidence; no infinite fallback chain, post-expiry write, or second source of terminal authority.
8. The helper records evidence; it does not own ES run truth or policy. Its missing external hard-deadline/containment owner remains missing. Document the required pre-first-privileged-effect binding, permitted termination and residual disposition, and terminal-receipt interface. Do not implement or install that owner here, forge its observations, or treat ExternalHardDeadlineObserved as a self-issued capability.
If a terminal protocol detail cannot be implemented correctly within this bounded interface, identify that exact static gap. Do not claim it closed merely because external execution is currently disabled by absent approval.
Allowed work
One foreground parent, sole writer, no active subagents during authoring and no independent audit in this task. Derive a fresh owner-only root under /Users/ds/Downloads; all external source, test scratch, isolated configuration and outputs stay there.
Allow ordinary-user temporary-file/process controls with substituted privileged effects, local unit/race/vet/formatting, and compile-only Linux artifacts. Inspect init/TestMain/subprocess paths first. New tests must not make the live privileged adapter reachable through a test entry.
Prohibit network/SSH/host discovery; sudo/root checks; devices or real loop ioctl; formatter/supervisor/worker/proof or safe-control execution; namespace creation/entry; mount/unmount; credential/capability changes; service/Docker/Lima/VM/workload operations; downloads/installs; actual import/approval/signature; repository tests/scripts including help; Git writes; old-root cleanup; and foreign-object removal.
3. Source scope
Authenticate the exact current paths; audit line numbers are navigation anchors, not patch offsets. Primary surfaces:
- tooling/internal/proof/lifecycle.go, tests and its observation/result types;
- tooling/internal/proof/live_linux.go, with narrowly shared decision logic actually called by the Linux adapter;
- tooling/internal/proof/finalization.go, its real caller and tests;
- tooling/internal/proof/formatter_termination.go and tests;
- tooling/internal/proof/adjudicator.go, tests and directly needed case expectation types;
- exact externally owned schemas/templates/status/owner-state/future-execution/remaining-gate documentation and runner/evaluator bindings.
Record the exact intended touched set before edits. Minimal new private files for these responsibilities are permitted, not a package or framework reorganization. Preserve internal/safemech, the safe-control entry, modules/dependencies, all 358 ES originals, and normally both proof drivers and the diagnostic overlay. A driver change is contingent on demonstrating that PV-01 cannot be closed using existing independently obtained evidence; inspect that first. No ES production hook/export or copied root classifier is allowed.
Retain all 42 historical finding rows; append the seven LNX-NEW rows and PV-01, with cross-references (50 lineage rows, not 50 unrelated new defects). Keep independently accepted subclaims and specialist disagreements visible. Owner-corrected is not independently closed.
4. Eight required repairs and discriminating controls
LNX-NEW-01 — deadline must survive the real controller/caller boundary
Audit anchors: lifecycle.go:346-357, live_linux.go:113-119, finalization.go:84-116.
Carry the original time.Time/deadline-bearing owner context as internal typed state into the actual finalizer. Serialize timestamp text only for evidence. Inspect transformations that strip the monotonic component; no reparsing, timezone/rounding conversion or fresh duration calculation may supply control authority.
Run a real caller-composition regression, not only runFinalization in isolation. Separate wall-display and monotonic-decision inputs in safe test controls; demonstrate forward/backward display discontinuities do not change dispatch eligibility. Never adjust the host clock or use unsafe access to Go private time fields. Also test absent/wrong episode context, early cancellation, and late completion. An explanatory source assertion can supplement but not replace the caller test.
LNX-NEW-02 — ledger tail, immutable outcome, seal and failure path
Audit anchors: lifecycle.go:216-224,482-492; live_linux.go:143-165,1162-1169,1257-1285.
Implement the protocol in section 2 across the real order of operations. Test a successful whole local publication against actual temporary files and the same finalization/export code used by the live caller, with only privileged setup replaced. Independently reconstruct the ledger boundary/row count, outcome bytes, bundle manifest, terminal bindings and final modes from disk. Compare the declared semantics of persisted and returned records; do not require equality of separately defined delivery status.
Inject every append/write/sync/close/mode/directory-publication/final-seal/failure-export boundary, including partial writes and completion just after the deadline. Require each fault to produce the exact expected retained evidence and refusal of positive acceptance. Verify no in-memory attempted row is counted as durable. Explicitly test a prefix ledger, stale result, contradictory receipt, modified final mode, missing terminal confirmation, late readable artifact, primary-plus-fallback failure, and parent-observation absence.
Use adapters at the real low-level effect boundaries, not a fake Finalize() returning success. Neither a file checksum nor a successful chmod is proof that final metadata was durably committed. Local injected durability tests establish control order and error semantics, not crash-proof Linux storage behavior.
LNX-NEW-03 — partial removal must invalidate prior inventory
Audit anchors: live_linux.go:1123-1160, lifecycle.go:759-776.
Return structured progress/identity on partial scratch deletion. Before mutation, invalidate post-state that would otherwise carry forward. After an Nth deletion error, obtain a fresh bounded descriptor-bound inventory through retained parent/root custody while time and safety permit. Complete post-state may support a precise failed/recovered result, not historical success; an incomplete/error/expired observation remains uncertain. Retain the root when required and still present; do not recreate a removed root or resume deletion without authority.
Exercise the actual deletion method on task-owned nested test trees with failure on first, middle, final child and root removal, including follow-up inventory failure. Assert exact remaining members, root/parent identity, removal progress, independent cleanup/inventory statuses and no deletion outside the test root. Also cover cleanup after already-absent state without treating observation failure as absence.
LNX-NEW-04 — generic partial acquisitions and candidate spawn retain identity
Audit anchors: lifecycle.go:273-315,507-540; live_linux.go:521-558,904-920.
Absorb every returned partial observation into owner state before error/ledger handling. Record exactly known formatter/worker/candidate identities and lifecycle/custody facets; unknown fields remain explicitly unknown. Do not store only a boolean or replace a returned identity with an empty string.
Add faults after successful start but before pidfd acquisition, namespace/channel qualification or acknowledgement, followed by another cleanup or inventory failure. Assert the exact acquired identity remains in the committed/attempted evidence under its honest durability class and in the terminal residual record. Candidate spawn must use the same rule. Verify that preserved evidence does not by itself confer permission to target a stale/reused PID or descriptor.
LNX-NEW-05 — formatter pidfd close is an exact-once attempt
Audit anchor: live_linux.go:602-606; compare the already safer loop close pattern at :886-901.
Transfer the owned descriptor to a local, invalidate the owner's numeric handle before calling close, and retain release uncertainty on error. Never retry the old descriptor number through repeated cleanup/inventory. An uncertain close is not confirmed absence.
Use the real close-owning helper/caller with a substituted close that reports failure and immediately makes that number represent another object. Repeated inventory/cleanup must not close the replacement; assert exactly one close attempt, no live owner handle, retained error and honest resource-state uncertainty. Do not deliberately close unrelated real descriptors to implement the test.
LNX-NEW-06 — no new signal after phase authority expires
Audit anchors: formatter_termination.go:27-56, live_linux.go:640-655.
Budget TERM/grace/KILL/reap before entry and check the owning context/deadline immediately before each signal. A live context at function entry does not authorize KILL after grace consumes the deadline. Change the existing expired-context expectation rather than preserving that wrong behavior for test compatibility.
Test cancellation/expiry before TERM, during grace, after a surviving-group observation and before KILL, plus bounded in-budget escalation, syscall error and unresolved group state. No post-expiry signal may be intentionally dispatched. Keep unresolved containment and exact owned identity for the specified external owner; do not extend the deadline, implement a parent or invent a post-expiry cleanup authorization. State the check-to-syscall scheduling qualification honestly; this is not an atomic wall-clock/signal guarantee.
LNX-NEW-07 — configure success is not proven association
Audit anchors: live_linux.go:777-795,813-821, lifecycle.go:405-424.
Keep the historical configure-command outcome separate from the required current association observation. Continue only on complete, present, non-uncertain, exact candidate/backing/configuration identity with an actually held association. Identity equality plus observation completeness is insufficient when Absent is true or AssociationHeld is false.
After configure, ENXIO/absence, unknown status, wrong backing/device/configuration, lost ownership or incomplete observation must block worker/mount dispatch. Preserve any possible effect and close only owned objects; add no retry, scan, detach, removal or allocation policy. ENXIO before configure retains its distinct unassociated-prestate meaning.
Fault-test the live-method decision and controller together for successful configure followed immediately by ENXIO, disappearance on the next required observation, mismatched backing/configuration, status error, and the positive exact association. Assert both no later setup and the actual partial/residual/close evidence. No loop device is accessed.
PV-01 — bind accepted coordinates to independent fixture roles
Audit anchors: adjudicator.go:214-220,323-339, spec.go:61-94.
The actual CaseSpec source expectations and independently obtained fixture/device evidence must constrain each accepted observation. Exact presentation does not make another source path or an arbitrary canonical major:minor valid.
First map every accepted case's configured presentation, backing fixture source, expected kernel source coordinate and independently observed device. Account for the real fixture's mount-root-relative coordinate; do not compare unlike path representations or hard-code a host device number. Do not derive the expected value from the very production observation under adjudication, and do not copy the ES classifier as an oracle.
Prefer existing normal-driver fixture facts/root identities and fixed sources. Add only minimally necessary external observation fields if the current output lacks an independent binding; no new case, runtime effect, or production instrumentation. Hash consistency is necessary but cannot replace semantic role correspondence.
Keep presentations and arrays otherwise valid while testing source-path-only swaps, device-only substitutions, another case's clean path, wrong path/device pairing, shared-but-wrong devices, and correctly rehashed tampering. Valid controls must pass. Refusals must still not require acceptance-only fields. Preserve the F-12 normal/diagnostic separation and the point-in-time/non-transience limitation.
5. Validation method and generation rules
Before full lanes, require a composed caller-level scenario matrix that drives the actual lifecycle through setup, cases, cleanup, finalization, export and returned result, substituting only the forbidden effects. Include representative combinations: partial acquisition plus ledger failure; partial removal plus post-inventory failure; expiry during formatter grace plus finalization timeout; and successful operational work plus partial publication and failed failure-export. Do not require an unbounded Cartesian product; explain which transitions each chosen combination covers.
Each new regression must fail the authenticated predecessor for the intended reason and pass the successor where safely demonstrable. A test name, assertion count or literal source string is not enough. Preserve valid existing tests, but correct expectations that encode the audited wrong behavior. Independent expected values must not be automatically regenerated from current output.
On Darwin, execute shared control logic actually called by Linux-selected code; inspect and record the caller binding. Tests of a portable fake do not count as execution of a Linux method. Factor only the minimum necessary shared logic. All real Linux privileged/kernel behavior remains unexecuted.
Toolchain and isolated environment
Authenticate the already installed Go executable:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
SHA-256: 3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Dependency remains pinned golang.org/x/sys v0.46.0. Read relevant installed time/context/close/loop wrappers as source. Public Go/Linux documentation is corroboration, not proof of local version or target behavior.
Before the first Go invocation, create task-owned HOME/config/telemetry/cache/temp/GOPATH. Use the authenticated existing read-only module cache. First Go invocation is isolated go telemetry off; verify effective off and exact private GOTELEMETRYDIR, GOTOOLCHAIN=local, requested GOENV=off with explicit empty observed value allowed, GOWORK=off, GOPROXY=off, GOSUMDB=off, and GOFLAGS=-mod=readonly. No global configuration changes, telemetry investigation or dependency downloads.
Freeze exact absolute CWD/argv/environment/output paths in the command plan. From the external tooling module, never ES:
"$GO" telemetry off
"$GO" version
"$GO" env -json GOOS GOARCH CGO_ENABLED GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS GOTELEMETRY GOTELEMETRYDIR GOMODCACHE GOCACHE GOTMPDIR GOPATH
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/supervisor-A" ./cmd/es-mounted-proof-v2
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/supervisor-B" ./cmd/es-mounted-proof-v2
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/safe-controls" ./cmd/es-mounted-proof-safe-controls
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" list -deps -f '{{.ImportPath}}' ./cmd/es-mounted-proof-safe-controls
Observe Linux effective metadata before its commands. Use pinned gofmt on touched external Go files; final format difference must be empty. Inspect compiled files and Go build metadata only as data. Require deterministic supervisor equality, complete selected package/test terminals, all independently inventoried required controls and descendants, zero selected skip/fail/truncation, exact expected no-test-package treatment, and successful runner/evaluator adversarial controls. Do not use the historical count 344 as the new oracle.
Allow ordinary focused development within scope. Freeze source, schemas, runner, evaluator and required inventory before credited final lanes. Permit at most two final execution generations for causally demonstrated in-scope source or execution-harness corrections, retaining each target and failure. Do not rerun an unchanged failure. An analysis-only schema/evaluator mistake may instead be corrected through separately versioned replay of the same authenticated streams when execution bindings are unaffected; preserve the old decision and require the entire acceptance predicate to replay. It does not automatically require executing another suite. No analysis exception can erase a genuine failed test or change the bytes it tested.
6. Selective artifact reuse
Rebuild the changed supervisor A/B and retain new identities; never execute it.
Rebuild the safe executable locally and require the same byte identity and selected-source/import closure before inheriting its seven Linux observations. Retain actual original plans/evaluator/bootstrap/wrapper/streams/cleanup, not merely totals. No remote rerun. Unexpected inequality requires diagnosis and a precise limitation, not automatic host authority.
Keep normal/diagnostic driver and effective-source bindings unchanged when PV-01 can be closed in the adjudicator. Then inherit those artifacts explicitly as compile-only. If an essential external-driver change is demonstrated, rebuild only the affected normal/diagnostic artifact under its authenticated pinned recipe, without execution; reverify all 358 original ES members unchanged. Record separate base/effective unions and any compiler overlay replacement. Historical absolute overlay paths are not portable recipes. No diagnostic trace may stand in for normal-product success.
7. Owner review, packaging and next gate
Before closeout, perform owner engineering review of the real complete caller order against the eight findings and the terminal protocol. This is not independent audit. Produce:
- exact source/delta/build/runner/evaluator/required-control identities and touched paths;
- the concrete terminal record graph, freeze point, persistence/publication order, receiver acceptance rules and failure matrix;
- a source-effect-to-test map showing real caller coverage, effect substitutions and unexecuted Linux edges;
- the 50-row lineage with old decisions preserved and new owner dispositions separately stated;
- exact commands/exits/streams, actual failure generations, inherited-vs-new evidence, and separate outcome/cleanup/inventory/export/durability/late-completion statuses;
- unchanged ES source/candidate/Git/worktree comparisons;
- the still-missing policy/administrative/target/formatter/containment mechanisms and required first-effect gates.
Produce one self-contained compact ZIP with the complete current external source/docs, current and cumulative deltas, raw local validation records, actual latest three specialist reports, authenticated latest audit, exact new source excerpts, inherited safe bindings and raw evidence, schemas/templates and independent expected fixtures, failure history and final decision. Preserve missing historical bodies as limitations; do not fabricate the missing generation-1 evaluator or older v1 specialist reports. Avoid nested historical ZIP chains.
Use safe unique regular payloads, explicit source-versus-packet modes, a complete self-excluding manifest and an acyclic external final-identities record. Independently reopen and verify CRC/path/type/mode/size/digest/coverage. Exclude binaries, caches, full ES unions, images, device contents, private configuration, secrets and unrelated history; identify separate compile artifacts explicitly. Remove only authenticated task-created disposable ordinary scratch, or classify retained private validation storage. No old-root or repository cleanup.
Return the exact report and ZIP together. The next gate is a fresh independent cumulative successor review. Even a satisfactory static review does not supply residual policy, a trusted entry, formatter qualification, an external hard-deadline owner, or privileged/mounted results. All eleven normal and eight supplementary diagnostic processes remain unexecuted. Running-deployment observation, supported-local consumer/operator proof, unconditional whole-candidate ES audit and exact-byte staging/commit authority remain required.
No follow-on effect is automatically authorized.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
