**Proceed to a fresh, separate-parent, read-only design review of this exact contract and migration map. Keep implementation blocked pending that verdict.** The correction addresses the five requested areas, but its owner checks do not independently establish migration readiness. No further design change is justified from the attached material alone. :chatgpt-content-reference{index="0"}

**Send this to a new Codex review conversation—not the design/correction conversation: :chatgpt-content-reference{index="12"}[Temporal map-completion independent design-review prompt](sandbox:/mnt/data/ES_Temporal_Map_Completion_Review/ES_Temporal_Map_Completion_Independent_Design_Review_Prompt.md).**

The handoff authorizes document/source inspection and independent checks of retained data. It authorizes no implementation, reviewed-code execution, Git subprocess, host contact, reservation, cleanup, or live adoption.

## What the correction now specifies

The report and attached corpus give the reviewers concrete relationships to test:

| Finding | Proposed correction |
|---|---|
| **T1 — signal authority** | Case-local normal and emergency stopping remain separate from external-parent teardown. A primary failure does not itself revoke an already established emergency grant, but cannot create or extend one. |
| **T2 — failure closeout** | Failure-file, directory, and parent publication effects have separate admissions. Failure retention requires its own pre-established grant; close duties do not authorize omitted writes or synchronization. |
| **T3 — release owners** | The finite inventory now includes formatter closure and scratch-related handles, distinguishes borrowed handles, and replaces the false image-close anchor. |
| **C1 — receiver bounds and projection** | Three individually bounded input domains share a 32 MiB combined ceiling. Native source-record inclusion is explicit and separate from body sequence numbering. |
| **C2 — production ingress** | The map reportedly includes the actual authority constructor/parser, phase-specific compatibility, ordered normal/diagnostic source bindings, and affected receiver tests. |

These are owner-proposed corrections. Their actual source-to-map coverage—especially the reported 25 owner classes and 156 caller sites—remains to be independently verified. :chatgpt-content-reference{index="1"}

The report’s **419 rehashed ranges and 72 prospective scenarios** have the right stated evidence classification: structural, arithmetic, and proposed acceptance checks—not executed receiver, signal, or process tests. A source range can authenticate perfectly while still describing the wrong effect; the previous E09 error demonstrated that distinction. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

## The review should concentrate on three integration questions

### 1. Does each effect consume the right authority at the actual caller?

The corpus now distinguishes local stopping **L**, parent teardown **T**, failure-history effects **F**, and inherited one-close discharge **C**. It expressly prohibits transferring authority merely by naming an operation “cleanup” or “emergency.” :chatgpt-content-reference{index="4"}

**The important check is not whether those labels exist. It is whether every mapped caller can obtain and consume the stated authority without either losing a legitimate duty or gaining an unintended permission.**

For example, a source-selected emergency KILL must remain possible when its primary failure leaves sufficient exact targeting custody and a still-valid original grant. That does not permit guessing a target after identity qualification fails, borrowing the parent’s later deadline, or bypassing a revoked local authority.

Similarly, a failed ordinary operation cannot manufacture the F grant needed for later failure-history publication. The reviewer must trace that grant’s proposed independent establishment, binding, cancellation, and consumption. Its issuer may remain uninstalled, but the design cannot leave the relationship itself undefined.

For C, the reviewer must inspect actual ownership and release implementations. The expanded inventory now includes borrowed `ExtraFiles`, transient formatter handles, scratch views, and failure-closeout owners. **An inventory entry must not turn a compound wrapper into one primitive close or mistake borrowing for ownership.** :chatgpt-content-reference{index="5"}

### 2. Do the new receiver limits cover the complete path without rejecting legitimate evidence?

The selected budget is now explicit:

```text
Existing carrier + producer graph:  ≤ 16 MiB
Parent-observation body:             ≤ 16 MiB
Raw confirmation:                   ≤ 64 KiB
Combined admitted raw bytes:        ≤ 32 MiB
```

All limits apply together. The corpus places confirmation admission before receiver-owned copying or parsing and distinguishes that protection from allocation already performed by the caller. It also specifies held-object checks, actual-read accounting, bounded overrun detection, and structural/decoded-work limits. :chatgpt-content-reference{index="6"}

The review must follow the actual public ingress, verifier interface, graph reconstruction, and proposed body parser. In particular, it should establish that:

- references and fixed qualification inputs cannot fetch unmetered episode evidence;
- repeated verification cannot reset accounting or duplicate retained inputs without bounds;
- the new depth, token, array, and decoded-object rules remain compatible with the actual record schemas and a complete legitimate positive.

The corpus’s **27 canonical graph roles** also need derivation from the actual producer and receiver. That is a compatibility question—not a finding that the stated number is wrong. Raw-byte limits and a role count do not themselves prove the complete parsing and semantic-work boundary.

The source projection has likewise become concrete: each covered native record appears exactly once under its independently bound source instance, overlaps count once, producer-origin events cannot fill outside-source gaps, and body numbering cannot stand in for native completeness. :chatgpt-content-reference{index="7"}

**The reviewer must check native-record completeness and continuous temporal coverage separately.** Neither a gapless body sequence nor a zero-loss flag establishes both. The qualified finite feed remains an unestablished operational prerequisite; no feed technology is selected by this review.

### 3. Does the versioned authority graph reach the actual production ingress?

C2 now proposes a distinct v4 run-approval pathname while preserving the existing import pathname and import-v3 canonical encoding. It also defines the observation body’s normal and diagnostic source digests separately and requires their ordered binding through the approved request and independent expectations. :chatgpt-content-reference{index="8"}

The review must verify the actual constructor, loader, typed encoder, entry observation, immutable owner, outcome, receipt, confirmation, and receiver—not just the version table.

Two details deserve explicit checks. **Identical version numbers do not make administrative entry observations and publication receipts the same record.** Their distinct schemas and consumers must remain clear. And adding run-only fields must not change import-v3’s typed bytes through a shared zero-valued structure.

The reviewer must also reconcile the producer’s interleaved normal/diagnostic ledger with the body’s canonical normal-then-diagnostic ordering by exact case identity and digest. It must not reorder historical producer records to make the arrays agree. The owner report identifies that treatment, but the map and affected fixtures still need inspection. :chatgpt-content-reference{index="9"}

## Keep this review bounded

The handoff covers all five findings, the source-projection sub-obligation, and their R1–R8 interactions. It uses two complementary read-only specialists, with the parent responsible for authentication, cross-boundary reasoning, and the final judgment.

It does **not** reopen the selected weaker deadline model, require a universal fence, or commission an entry service, feed, registry, signer, or recovery mechanism. A blocker must identify an actual contradiction, missing necessary decision, or source-to-map omission with a finite counterexample and minimum correction.

The no-Git boundary also carries forward. The owner reports fingerprints of the consumed plain files and explicitly does not claim a fresh full ref/index/worktree comparison. That is the appropriate narrower preservation statement for this task; the independent review should use the same boundary rather than reintroduce the repeated initial-status-query problem. :chatgpt-content-reference{index="10"}

A satisfactory endpoint may be:

```text
ES_MOUNTED_HELPER_TEMPORAL_T1_T3_C1_C2_DESIGN_REVIEW_SATISFIED_IMPLEMENTATION_AND_LIVE_ADOPTION_PENDING
```

That would support separately authorizing the coupled external migration. It would not implement it or establish the target, observer, clock, custodian, storage, policy, or reservation.

Remote scratch, survivor, and disconnected-observer state remain unknown. The old accepted helper retains its original scoped closure and evidence qualifications. Mounted cases, deployment observation, supported-local proof, the unconditional whole-candidate ES audit, and exact-byte publication gates remain separate. :chatgpt-content-reference{index="11"}

## Inspection boundary and confidence

I read both complete attachments and the preceding correction prompt. Their measured identities are:

| Attachment | Bytes | SHA-256 |
|---|---:|---|
| `TEMPORAL_CONTRACT.md` | 48,687 | `ebc2fcf93ef5969c634b81d32eb7b44f6208f9d66708734c4867285222bb9a44` |
| Correction report | 10,169 | `3444cd74a76872700eecee167f3c7040c4c7dcfef81b5a44fd74e032088ace2b` |

The contract’s encoding and final-line representation match its declared raw-byte rules. The current migration JSON, ZIP, design-check records, and underlying implementation were not inspected here. Their detailed contents remain owner-reported; the prompt identifies their retained paths and requires measurement of the current map and ZIP rather than inventing absent hashes.

**Sources:** attached correction report and normative corpus, preceding blocked independent review, and prior correction handoff. No repository commands, reviewed code, tests, hosts, or cleanup were executed here.

**Confidence: 0.96 in proceeding to this fresh review.** Attachment identity is verified; complete design coherence and migration readiness remain review questions. Operational consent and privileged readiness remain unestablished.
