I'm not able to download the file.

The hyperlink behind `ES_R6J_OUTCOME_MATERIALIZATION_DELIVERY_REISSUE_REQUEST_20261019_09.zip` seems to be `sandbox:/mnt/data/ES_R6J_OUTCOME_MATERIALIZATION_DELIVERY_REISSUE_REQUEST_20261019_09.zip`, which is not accessible over web.
