**Proceed to a fresh, read-only independent review of the contract and migration map before implementation.** The draft makes the selected reduction explicit and identifies a coupled migration rather than proposing another adapter around an unresolved guarantee. The existing helper, its scoped audit closure, and the ES candidate remain unchanged. This is not live risk adoption or execution authorization. :chatgpt-content-reference{index="0"}

**Send this to a fresh Codex review conversation—not the design/implementation conversation: :chatgpt-content-reference{index="20"}[Temporal-contract and migration independent-review prompt](sandbox:/mnt/data/ES_Temporal_Contract_Review/ES_Temporal_Contract_and_Migration_Independent_Review_Prompt.md).**

The next review should decide whether this particular contract is coherent and implementation-ready. It should not restart the search for a perfect external cutoff mechanism or implement the entry foundation first.

## What the draft resolves

The proposed profile, `deadline-dispatch-supervised-observed/v1`, distinguishes **permission checked before an action, the eventual dispatch and completion, observed resource release, evidence delivery, and later verification**. It expressly allows an already-admitted operation—or a process descheduled after its final check—to produce an effect after the deadline. Rejecting that evidence does not prevent or undo the effect. That is the deliberate reduction we selected, not a renamed hard-containment guarantee. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The draft also locates the stronger requirement in the external helper’s specifications and accepting predicates. Codex’s bounded inspection found no independently owning ES clause that requires that universal cutoff for this proof. **That conclusion is source-reported here, not independently established by my inspection of the repository.** The review prompt requires checking the cited owning clauses and stopping on an actual product-contract conflict. :chatgpt-content-reference{index="3"}

Importantly, the proposal does not make failure harmless. It requires unresolved resources and possible late effects to remain assigned to a responsible custodian and held against conflicting reuse. The hold is explicitly operational, not physical containment, and it does not grant further syscall authority after expiry. :chatgpt-content-reference{index="4"}

Those are appropriate design boundaries. The remaining question is whether their detailed timing, authority, and record relationships agree.

## Three temporal relationships need explicit review

### 1. Finalization through D versus parent teardown by D−8

The draft permits export and finalization within the original deadline **D**, while requiring parent teardown to begin no later than **D−8 seconds**, with three seconds for TERM grace and five for KILL/observation. Impending-expiry teardown makes the episode nonpassing. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

That creates a concrete interaction the reviewer must settle:

> What happens when all case processes have finished, but the legitimate supervisor is still publishing at D−7?

An intentional earlier stop threshold can be valid. But it must be clear which subjects trigger it, whether the supervisor’s finalization is included, and where the effective success window ends. The implementation must not silently promise finalization through D while invariably terminating that path earlier—or silently waive the parent’s reserve to preserve a positive test.

**I am not classifying this as a proved defect from the narrative alone.** The review must derive the timeline from the actual migration map and current caller relationships, then either confirm a coherent rule or return a precise correction. It should establish at least one complete legitimate positive timeline, not only demonstrate that late paths refuse.

Likewise, the nineteen per-case maxima are caps, not a promise that nineteen worst-case durations all fit inside the total episode. Summing those caps alone would not establish a contradiction.

### 2. Qualified wall-clock authority is not a monotonic guarantee

The draft reports that the current production owner is constructed from `time.Unix(0,D)` and selects an immutable **wall-clock** model with explicit qualification, sticky observed expiry, and refusal when clock evidence becomes uncertain. It does not claim to reconstruct a monotonic component. :chatgpt-content-reference{index="7"}

The reviewer must reconcile this with the actual source rather than inherit stronger language from earlier descriptions of a “typed” deadline. The proposed success claim depends on a qualified, consistent clock basis; that qualification must have a defined observation contract without quietly requiring an omniscient clock-failure detector.

The migration also does more than remove containment fields. It identifies `Controller.apply`’s current reliance on `ctx.Err()` and proposes direct decision-clock checks at the action boundary. The review must verify that the map covers the actual dispatchers, sub-effects, fallbacks, and post-return handling—not just add another check around an adapter that performs several later operations. :chatgpt-content-reference{index="8"}

The non-atomic final-check-to-syscall interval remains admitted. A direct check must not be advertised as making physically late dispatch impossible.

### 3. The one-close duty must remain a bounded exception

R4 denies post-expiry work but preserves an owner-independent, exactly-once release duty for an already-acquired ledger or descriptor, including late/error accounting. :chatgpt-content-reference{index="9"}

The review must trace that exception to its actual existing ownership contract and make its priority unambiguous. In particular, it must distinguish an already-admitted close completing late from any separately permitted close admission after expiry.

It cannot become permission for a flush, sync, reacquisition, signal fallback, recursive cleanup, or numeric-descriptor retry. Conversely, an established release duty should not disappear merely to simplify the slogan “no work after D.” The required result is a precise authority boundary with truthful failure accounting.

## Review the migration as one protocol

The proposed version treatment is appropriately selective: new run-only authority schemas, outcome, receipt, expectations, and confirmation carry the changed claim, while import-v3 and neutral records retain their existing meaning where possible. The draft explicitly forbids conversion, containment-boolean aliases, compatibility defaults, and automatic relabeling of old evidence. :chatgpt-content-reference{index="10"}

The independent review needs to examine the **actual types, encoders, parsers, templates, and consumers together**.

The most important compatibility check is import-v3. Adding run fields to a shared typed encoder can alter its serialized bytes even when those fields hold zero values. The draft expressly prohibits that result; the reviewer must establish a concrete phase-specific treatment, not accept a prose promise that “import is unchanged.” :chatgpt-content-reference{index="11"}

The exact temporal profile and contract digest must also originate in independent run approval and remain bound throughout the new graph. The review should identify precisely which normative bytes the digest covers and when they become fixed. It must not hash an evolving report, omit governing semantics that live elsewhere, or introduce a dependency on a future receipt.

Finally, the new observation fields must not recreate the rejected guarantee under different names. The proposed confirmation includes `supervision_observed`, `clock_qualified`, `process_scope_resolved`, `resource_release_observed`, and `unresolved_episode_effects`. Those statements require concrete, independently bound evidence; correctly shaped true/false values are not sufficient. :chatgpt-content-reference{index="12"}

In particular, `unresolved_episode_effects=false` must mean the qualified interface-level condition the draft actually defines—not universal physical quiescence of every device or cache. At the same time, weakening the physical claim cannot erase a genuinely outstanding request, uncertain release, or missing process observation. The draft’s explicit distinction between qualified resource release and every possible future hardware effect needs to survive the predicates and tests. :chatgpt-content-reference{index="13"}

## Preserve the distinction between design approval and operational consent

The proposed finite parent and custodian responsibilities remain unimplemented and unestablished. A design review can find those interfaces sufficient for implementation without claiming that the actor, storage protection, clock qualification, or scope reservation already exists. It must also identify any internally missing decision that has merely been pushed into a future actor’s responsibilities. :chatgpt-content-reference{index="14"} :chatgpt-content-reference{index="15"}

Two forms of consent remain separate:

**Consent to the reduced late-effect failure model** concerns this episode’s supervision and unresolved-operation risk.

**Consent to `accept-single-get-free-possible-unbound-without-removal`** concerns the narrowly described possible unbound loop object. It does not cover arbitrary late writes, mounts, descendants, or failed association cleanup. Neither consent is issued by this handoff. :chatgpt-content-reference{index="16"}

The review also must keep timely observation separate from later verification. A genuinely timely complete episode may be verified afterward; a later confirmation cannot manufacture an observation that should have occurred before D. Recovery after failure cannot repair original timeliness. :chatgpt-content-reference{index="17"}

No gateway, watchdog, registry, signing platform, lease selector, or new recovery mechanism is commissioned by the review.

## The next gate

A satisfactory design-review result may be:

```text
ES_MOUNTED_HELPER_TEMPORAL_CONTRACT_DESIGN_REVIEW_SATISFIED_IMPLEMENTATION_AND_LIVE_ADOPTION_PENDING
```

That would make the next task the **coupled external documentation/schema/predicate/assurance migration**, in a fresh source generation. Its affected implementation review would then precede any entry foundation that consumes the new contract. The draft’s proposed order is now correct; its detailed migration remains to be independently checked. :chatgpt-content-reference{index="18"}

The review prompt covers all R1–R8 clauses and the migration map, with two complementary read-only specialists and parent reconciliation. It requires concrete counterexamples and minimum corrections for any block—not another broad architecture proposal.

Remote recovery remains untouched: the original failed inventory, failed recovery transport, last-known scratch, and unknown survivor/observer state remain distinct. The temporal redesign does not authorize reconnecting, deleting, or adopting a new recovery contract. :chatgpt-content-reference{index="19"}

Mounted cases, deployment observation, supported-local consumer/operator proof, the unconditional whole-candidate ES audit, and separately authorized exact-byte publication remain pending.

## Inspection boundary and confidence

I read the complete attached draft and the preceding rebaseline prompt. The draft is **29,557 bytes**, with computed SHA-256:

```text
334ffee8427121457bd092004f03ae5d0cee687802b3c2c1112f935f3f58663d
```

The current migration JSON, review ZIP, specialist originals, and underlying source were not attached here. Their detailed content and authentication remain Codex-reported. The review prompt supplies their retained paths and requires direct inspection; it does not invent a current package digest.

**Sources:** attached temporal-contract draft, prior operational plan, and the preceding rebaseline handoff. No repository commands, tests, hosts, or cleanup were executed here.

**Confidence: 0.96 in proceeding to independent design review.** Draft-byte identity is verified; full contract coherence and migration completeness remain review questions. Implementation readiness, operational consent, and privileged readiness are not yet established.
