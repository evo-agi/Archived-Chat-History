## The block stands

Do **not** return to Codex. The review identifies source- and contract-level defects in the artifact design, not implementation omissions.

The most important sequencing decision is:

> **Correct the governed pair identity and source-derived universe first. Then rebuild the profiles, semantic joins, active-map reconciliation, and controls against that corrected pair.**

Patching only `read_general_join.py` would leave every authority, graph, profile, map binding, and control tied to the wrong foundation.

### ES_R6J_R921_WHOLE_JOIN_REPAIR_HANDOFF_20261025_02.zip[Download the whole-join repair handoff](sandbox:/mnt/data/ES_R6J_R921_WHOLE_JOIN_REPAIR_HANDOFF_20261025_02.zip)

:chatgpt-content-reference{index="1"}[Download the completed handoff verification](sandbox:/mnt/data/ES_R6J_R921_WHOLE_JOIN_REPAIR_HANDOFF_20261025_02_VERIFICATION.json)

```text
Bytes:             17,116,570
Members:           63
SHA-256:           2065f13e08ea970a125ed3cc71713d11411da64a0bd4967c53387ffb26021c89
Verification:      PASS
```

The handoff is self-contained for owner work. It includes:

- the exact rejected owner;
- the direct connected checkpoint;
- the complete blocked review;
- the four fully rebound review counterexamples;
- the exact R26.G06 predecessor contract, map, pair record, and selected accepted source;
- the correction decisions, matrices, controls, and complete owner task.

## Selected repair structure

### 1. Restore the inherited pair algorithm

The successor must again use:

```text
SHA256(
  "R6-PAIRED-CORPUS-MAP" || NUL ||
  uint64be(contract_length) || contract ||
  uint64be(map_length) || map
)
```

The raw `SHA256(contract || map)` value may remain only as a diagnostic. It cannot remain the authoritative pair.

The handoff also defines a **noncircular** binding chain:

```text
freeze contract and map
→ compute framed pair
→ generate exact pair identity
→ generate pair-bound active-map reconciliation
→ bind both through a package-binding record and owner manifest
```

The map must not contain its own map hash, pair hash, or the hash of a reconciliation file that itself contains the current pair.

### 2. Correct the source universe to 421 operations and 179 resources

The missing source-derived occurrence is:

```text
retained-file-03-owner
OPERATIONAL-OUTCOME.json
```

with:

```text
retained-03-create
retained-03-write
retained-03-mode
retained-03-sync
retained-03-close
```

The current graph already contains the exact 126,259-byte outcome. The missing operations belong between `retained-02-*` and `retained-04-*`.

Adding them requires more than changing two counts:

- insert the five source sequence slots;
- shift every later terminal-materialization sequence by five;
- update per-source coverage;
- rebuild operation/result indexes, ownership inventories, profiles, controls, and dependent hashes.

### 3. Replace the prefix profiles’ full future core

`P01`, `P02`, and `CLOSE` must receive **profile-specific, physically cut G/B/confirmation evidence**.

They may not embed the full positive core and rely on:

```text
future_graph_admitted=false
```

while the reader still decodes and uses future events.

The corrected profiles must preserve:

- **P01:** outstanding Wait, held worker custody, unknown controller custody, possible child; no future Wait return or successful closeout.
- **P02:** incomplete poll and consumed sequence; the next sequence is an expectation, not an observed later event.
- **CLOSE:** one inherited consuming Close with uncertain release; no later successful terminal facts.

The prefix reader must not invoke full-positive candidate replay or canonical final-graph checks.

### 4. Close the semantic joins

The successor must enforce:

- exact typed result payload;
- status;
- error;
- exact return time;
- resource consequence;

for each operation and profile. A payload merely hashing to its own declared hash is insufficient.

The outside acquisition must match the Wait on:

```text
acquired instance
PID
start identity
namespace identity
wait duty
subject
owner occurrence
```

Coverage must match the fixed universe on:

```text
source
source_ref
clock_qualification_ref
epoch
sequence range
time interval
loss count
```

Operation stages must use a closed vocabulary, rather than arbitrary short ASCII strings.

### 5. Rebuild the active map against the exact current pair

All:

```text
30 migration rows
176 callers
96 scenarios
53 effects
54 owners
20 sources
```

must bind the exact successor contract, successor map, framed pair, algorithm, and successor section.

The predecessor-only binding plus `successor_section=R9.21` is not enough.

## Message to send

Send the handoff ZIP to the **same ChatGPT artifact owner that produced the rejected whole-R6J owner**, not to Codex or the independent reviewer:

```text
Repair the blocked whole-R6J general native-source join proposal under
NEXT_OWNER_TASK.md.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md,
receiving/RECEIVING_INSPECTION.md, all five analysis files, and the
complete blocked review before authoring. Authenticate the embedded
current owner, direct checkpoint, blocked review, and selected exact
R26.G06 predecessor pair/source files.

Follow the required order:

1. Correct the source-derived universe to 421 operations and 179 resources,
   including the missing OPERATIONAL-OUTCOME retained owner and
   retained-03 create/write/mode/sync/close sequence.

2. Amend the complete R6/R9.21 rules, schemas, map and consumers for:
   - the inherited length-framed pair algorithm;
   - physically cut P01/P02/CLOSE profile evidence;
   - exact operation result semantics;
   - exact outside acquisition/Wait identity;
   - complete source/reference/clock coverage;
   - closed stage/state typing;
   - noncircular current-pair binding of every active map record.

3. Freeze the final contract/map, compute the framed pair, and explicitly
   rebind all authority, graph, profile body, confirmation and active-map
   evidence.

Do not patch only the reader while leaving conflicting rules or stale
identity bindings.

Save and reopen a substantive checkpoint containing the corrected universe,
final pair/binding chain, positive and all three physically cut profiles,
current reader, actual results, and the review counterexamples before
expanding controls.

Preserve the supported R6J-01 and R6J-02 construction unless the corrected
bytes expose a new conflict. Re-adjudicate R6J-03 through R6J-09 from the
actual successor.

Preserve all historical controls and add the required current controls for
universe omission, pair drift, prefix future grafts, exact result mismatch,
outside identity mismatch, coverage drift, invalid stage state and stale
current-pair bindings.

Execute current-owner-to-successor and exact R26.G06-predecessor-to-successor
reconstruction. Do not claim original-seed reconstruction without the exact
seed bytes.

Do not launch Codex, access repositories or hosts, execute uploaded
programs, implement runtime code, create an implementation handoff or claim
independent acceptance.

Return actual downloadable artifacts only under:

OWNER_R6_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW
```

## Sequence after the owner result

```text
corrected whole-R6J owner
→ fresh artifact-only whole-R6J review
→ implementation decision
→ only then a regenerated Codex implementation handoff
```

The review’s supported R6J-01 and R6J-02 results remain useful. The repair should not repeat the normal-branch or canonical-graph construction unless the corrected universe exposes a direct conflict.

**Sources:** ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_BLOCKED_20261024_01.zip[blocked whole-R6J review](sandbox:/mnt/data/ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_ARTIFACT_REVIEW_BLOCKED_20261024_01.zip), ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW_20261024.zip[rejected owner](sandbox:/mnt/data/ES_R6J_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW_20261024.zip), and the exact R26.G06 predecessor pair/source included in the repair handoff.

**Confidence:** provenance and blocking diagnosis **0.99**; selected correction order **0.97**; corrected successor semantics remain unestablished until owner completion and fresh review.
