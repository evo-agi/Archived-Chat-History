## Proceed to a fresh artifact-only architecture review

This delivery is substantive and self-contained. I found no package-authentication defect or obvious reason to send it back to the owner before review.

The corrected owner authenticates as:

```text
OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_CORRECTED_READY_FOR_FRESH_REVIEW.zip

Bytes:             8,300,976
ZIP members:       87
Manifest payloads: 86
Payload bytes:     34,629,947
SHA-256:           d34deeb9627f1fc9ca37457d650e58fb55e41d81971240db5425a2a2051f50a4
Manifest errors:   0
```

Its embedded predecessor owner, blocked review, and repository-owner survey match their declared identities. All accepted R9.21 reference members remain byte-identical to the predecessor.

The new target pair also recomputes correctly:

```text
Contract SHA-256:
df8103449ea10bafe723efd77c831d0148508c4c131f5ffbf53ba36da3aa7a78

Migration-map SHA-256:
65afbcc6ca7568b428dc6652233aa67061748fc00099184c6009860154d040cc

Length-framed pair:
a051a8248a8b93f98df527e72156ed01d22ec1d605998387d283aefc1c0ae0e8
```

All 429 active records share the current target binding and retain false runtime, repository-adoption, authority-issuance, credential-qualification, live-qualification, and independent-acceptance flags.

### What is now genuinely selected

The owner no longer leaves Stage C to choose the central architecture. It now selects:

- `es/outsideobserver` as the Linux task/container PID 1, direct parent, process-safety owner, and sole Wait/reap owner of one runtimehelper supervisor;
- `OutsideObservationPermitV1` inside signed `RunEntryV4`, issued only by the existing RunEntry issuer;
- byte-identical admission transport with no P issuance or interpretation by admission;
- a private host-side `es/r6jreceiver`;
- a per-run Unix stream protected by mutual TLS using distinct SPIFFE identities;
- sequence, epoch, nonce, hash-chain, and peer-binding rules;
- evidence-custody transfer only after validation, append, `fsync`, and bound ACK;
- no observer spool, reconnect, or session resume in version 1;
- fail-closed launch and post-launch transport-loss handling;
- a new permit, source epoch, endpoint, and session for every retry;
- production wiring only at Stage E.

The four modeled profiles preserve their accepted semantic cores. The R9.23 change is topology and governance binding, not a reinterpretation of the accepted evidence model.

## Fresh-review handoff

### ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_FRESH_REVIEW_HANDOFF_20261025_03.zip[Download the self-contained review handoff](sandbox:/mnt/data/ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_FRESH_REVIEW_HANDOFF_20261025_03.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_FRESH_REVIEW_HANDOFF_20261025_03_VERIFICATION.json)

```text
Handoff bytes:   8,552,259
Members:         30
SHA-256:         9759ca37be671851a46b530b6e86cfe3bcc874d8796a9a230218676b1c7aa091
Verification:    PASS
```

The handoff embeds the exact corrected owner, receiving-side verification, focused review questions, and the complete review task. Because the owner itself embeds the predecessor owner, blocked review, survey, and original correction handoff, **no other attachment is required**.

## What the fresh reviewer must settle

The architecture is much stronger, but the following questions still need independent judgment rather than owner self-certification:

1. **Nomad/PID-namespace realization.** Does the intended task driver and namespace topology actually guarantee that outsideobserver is PID 1, the direct parent, and the sole reaper? Or is a driver-level choice still authority-defining?

2. **Permit-consumption authority.** Which single durable component owns nonce consumption and replay state, and exactly when is the permit irreversibly consumed? Independent verification by observer and receiver must not create competing replay registries.

3. **Endpoint lifecycle.** Who creates, binds, owns, mounts, closes, removes, and prevents reuse of the run-private socket and directory? Stale paths and path races must fail closed without turning pathname possession into authentication.

4. **SPIFFE identity acquisition.** Are workload selectors, Workload API access, trust-domain treatment, rotation, and prelaunch failure behavior sufficiently frozen for Stage C, rather than left for implementation to decide?

5. **Descendant teardown.** Does the process-group plus PID-1 model account for every runtimehelper descendant, including children that change process groups, before completion or failure can be reported?

6. **Durable custody.** Is append/`fsync`/ACK precise enough for directory durability, lost ACKs, receiver crashes, source-complete state, and durable orphan records when version 1 has no session resume?

7. **P versus execution authority.** Does giving P the action `launch-runtimehelper-supervisor` preserve the existing execution/admission split, or create a second launch authority?

8. **Stage independence.** Can Stages B, C, and D be implemented independently without creating a live unqualified endpoint, an unowned replay or custody fact, or a temporary authority leak?

The 54 packaged controls are **inert artifact adjudications**, not runtime tests. The reviewer must inspect their predicate coverage and internal consistency without treating them as executed proof.

## Message to send

Open a new ChatGPT conversation that did not author this correction. Attach only the review handoff and send:

```text
Perform the fresh artifact-only ES-native outside-observer topology review
defined in the handoff.

Read README_FIRST.md, INPUT_IDENTITIES.json,
receiving/RECEIVING_INSPECTION.md,
receiving/REVIEW_LEAD_QUESTIONS.json, and REVIEW_TASK.md before semantic
analysis.

Authenticate the handoff, the embedded corrected owner, its complete
manifest, and its embedded predecessor owner, blocked review, repository
survey, and original repair handoff.

Independently determine whether:

1. the accepted R9.21 reference bytes and reviewed R9.22 ownership split
   remain preserved;

2. R9.23 changes only the blocked topology, authority, custody and stage
   seam through R6J-ES-NATIVE-OUTSIDE-P/v1;

3. es/outsideobserver is unambiguously the task entrypoint, task/container
   PID 1, direct parent, process-safety owner and sole Wait/reap owner of
   exactly one runtimehelper supervisor under a realizable Nomad/container
   topology;

4. admission, outsideobserver, runtimehelper, nativeproof, receiver, Nomad,
   app, API, issuers, SPIRE, the private schema and the external proof tree
   have precise and nonoverlapping writer and nonwriter roles;

5. OutsideObservationPermitV1 is issued only by the existing RunEntry
   issuer, transported unchanged, single-use, and not a hidden policy or
   second execution authority;

6. one authoritative permit-consumption and replay state, including its
   exact prelaunch consumption transition, is selected;

7. observer and receiver SPIFFE identities, selectors, Workload API access,
   trust domain, rotation and prelaunch failure behavior are sufficiently
   frozen;

8. the per-run Unix endpoint has a complete creator, owner, bind, mount,
   teardown and reuse lifecycle while path possession remains
   non-authenticating;

9. handshake and record schemas are closed, typed, bounded and
   replay-resistant;

10. custody transfers only after a sufficiently precise durable append,
    fsync and ACK commit, including lost-ACK and receiver-crash behavior;

11. process teardown accounts for all descendants, transport loss,
    already-exited children, observer death, final-evidence failure and no
    double Wait or fabricated success;

12. no-spool, no-reconnect, no-resume and new-run-only restart rules are
    internally coherent;

13. the receiver remains a custodian and derived writer rather than the
    hidden writer of raw facts, policy, authority, credentials or scheduler
    state;

14. Stages A through D can be implemented independently without unowned
    mutable state, temporary authority leakage, production endpoint
    activation or premature compatibility change, and Stage E is the sole
    live-enablement gate;

15. the governed pair, governance and package bindings, modeled profiles
    and all 429 active records are exact and noncircular;

16. all 54 deliberate controls cover the required topology, writer, permit,
    identity, sequence, custody, failure, restart, stage, API and schema
    predicates without stale-hash or generic-parser credit;

17. dirty-baseline and M23/R9.22 preservation rules remain intact;

18. the report, status, basis, exact-change inventory, preservation,
    controls, self-check, target artifacts, bindings and manifest agree;

19. authoring flags do not imply independent authorship, repository
    adoption or live qualification.

Treat the owner and receiving checks as evidence to inspect, not
acceptance. Do not execute supplied programs, launch Codex, access
repositories or hosts, repair the owner, implement source, issue authority
or credentials, adopt the proposal or claim live qualification.

Return one supported endpoint:

R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_ARTIFACT_REVIEW_ACCEPTED

R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_ARTIFACT_REVIEW_BLOCKED

R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_ARTIFACT_REVIEW_INCOMPLETE

Return a compact downloadable review package without duplicating the owner.
```

## Gate after the review

A satisfactory result would freeze the target architecture. It would still **not** authorize all implementation stages.

The next sequence would be:

```text
fresh architecture acceptance
→ repository-adoption decision
→ clean/stable baseline selection
→ Stage A PLANS/.docs/schema/contract-test implementation
→ fresh source review
```

Codex remains premature until the topology review passes and the repository-adoption baseline is explicitly selected.

**Sources:** the uploaded corrected owner and its embedded predecessor owner, blocked review, repository-owner survey, R9.23 topology and governance artifacts, profile bindings, controls, and self-check.

**Confidence:** **0.999** in package identity, manifest integrity, preservation, pair recomputation, and handoff construction; **0.96** that the proposal is ready for this focused fresh review. Independent architectural acceptance remains pending.
