**Retain the block. The next correction must resolve status acquisition, read-handle acquisition, surviving release duties, and the emergency-target predicate—not reopen the deadline model or implement the helper.** The review distinguishes these present design defects from future operational qualification, and reports no missing essential input. :chatgpt-content-reference{index="0"}

**Send this to the original design/preparation Codex conversation—not the audit conversation: :chatgpt-content-reference{index="16"}[Status-acquisition and release-duty correction prompt](sandbox:/mnt/data/ES_Temporal_Status_Acquisition_Release_Correction/ES_Temporal_Status_Acquisition_Release_Design_Correction_Prompt.md).**

Place this boundary directly before the attachment:

> Read the entire attached task before choosing any command. No Git command or repository bootstrap is authorized. Work outside all checkouts. A prohibited command stops this task; it is not a permitted disclose-and-continue step.

The handoff authorizes **external design correction and inert-data checks only**. The accepted helper, ES candidate, and historical evidence remain unchanged.

## Preserve the parts that now agree

This review does establish progress. Local L versus parent T routing is coherent at the inspected family, nested, and alias levels. The preissued F term’s digest order and seven-operation filesystem scope are coherent. The previously duplicated scratch release and worker release aliases are also repaired at their inspected granularity. **Those relationships should carry forward.** :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The remaining problems sit immediately around those corrected relationships:

| Boundary | Remaining defect |
|---|---|
| **F status acquisition** | The supervisor needs a fresh response but has no defined permission or bounded path to obtain it after S. |
| **Read-source acquisition** | Some operations classified as pure observation actually open new handles. |
| **C release eligibility** | Active prerequisites still require ordinary authority to remain current, contrary to the surviving one-close duty. |
| **Emergency targeting** | The canonical gate requires the identity fact whose acquisition failed, while its caller permits a different qualified targeting basis. |

These are not reasons to add more status labels. They require the corpus and every active map level to use the same actual predicates. :chatgpt-content-reference{index="3"}

## 1. Give status acquisition its own finite, preissued permission

The fresh-status dependency is now the main unresolved operating-model decision. The reviewer demonstrates that **even a responsive hypothetical status source cannot produce the first compliant post-S F admission**: ordinary A has expired, C permits release only, and the seven F permissions do not include obtaining their own challenge/response. The entry descriptor and environment constraints do not supply an implicit transport. :chatgpt-content-reference{index="4"}

**My selected correction is a narrowly scoped status-observation companion in the same independently issued run/F approval relationship.** It permits obtaining validity evidence; it does not grant another filesystem-publication operation.

The proposed relationship becomes:

```text
Independent pre-effect approval
→ fixed status-observation scope and narrow F term
→ qualified episode-bound status channel
→ one bounded status exchange
→ fresh F admission for one exact publication effect
```

The status-observation permission must be established from the approval and qualified channel custody—not from the response it is trying to acquire. That removes the recursion.

This is an **explicit additional successor design permission**, not current functionality or live authorization. It does not make the helper an approver. Revocation of F remains capable of stopping publication; a status query may merely discover that revocation.

### Define one actual proposed path

The correction task must specify one finite, protected same-host path, preferably a peer-bound session acquired during ordinary A preparation before S. It must identify the actual proposed acquisition, send, wait/read, validation, partial-return, and release boundaries.

It must fit the existing raw-entry contract rather than silently add an inherited descriptor, an environment-selected endpoint, or an unregistered object inside an exact inventory. The future responder’s standing receive/status/reply authority also needs definition; otherwise the missing actor has merely moved to the other end of the channel.

**An opaque `GetStatus` callback is not sufficient.** Equally, this design task does not implement a socket, responder, signing service, or gateway. When no realization fits the protected interface, the owner must report that concrete conflict rather than claim the path is complete.

### Bound attempts, not just favorable responses

The report correctly notes that seven accepted 4 KiB samples do not bound failed requests, malformed replies, partial traffic, or retained challenges. :chatgpt-content-reference{index="5"}

For the correction, I am selecting **at most seven attempted exchanges total**, one per canonical E48 operation, with no retry or reconnect to obtain a better answer. Each challenge and response has a 4,096-byte raw ceiling; the complete encoded history needs its own explicitly derived bound inside the existing receiver budget.

A slot is consumed before its outward attempt. Failure, denial, partial response, or unknown outcome stops that F sequence. Copies of the holder cannot reset the sequence or reuse a nonce.

The response must bind **one role and exact target relationship**, not merely the episode and a fresh nonce. Exclusive file creation binds the held parent and fixed absent leaf; later operations bind the acquired file or directory. The correction must also enforce both ends of the validity interval and recheck immediately before the filesystem operation. A response obtained before D cannot authorize a separately admitted operation at D. These are specific gaps identified by the review. :chatgpt-content-reference{index="6"}

The existing non-atomic check-to-dispatch qualification remains. Freshness is not instantaneous revocation or guaranteed scheduling.

## 2. Make C depend on surviving ownership—not current ordinary authority

The strongest map-wide finding is quantitative but specific: **26 canonical C rows require current D/S/phase/revocation, and another 21 use ambiguous “original nonrevoked scope” wording.** The first set conflicts with the corpus; the second fails to identify which duty survives. :chatgpt-content-reference{index="7"}

The correction should use one canonical release-eligibility relation:

> An actual acquisition or transfer created this holder’s release responsibility; that exact owner slot remains live and unconsumed; the selected operation is its one qualifying primitive release.

Current permission to do ordinary work is not an additional prerequisite. Cancellation, expiry, F revocation, or loss of status access cannot erase responsibility for an already acquired handle.

The decisive example is the review’s own: a file is opened under valid F at S+1; F is revoked before Write. **Write must refuse, while the acquired file can still receive its one C discharge—even after D.** A close error leaves uncertainty and a consumed slot, not permission to retry a later descriptor that happens to reuse the number. :chatgpt-content-reference{index="8"}

This does not authorize closing a historical number, a borrowed handle, or an owner whose transfer is uncertain. Nor does it authorize a fresh lookup, status exchange, Write, Sync, signal, or protocol shutdown merely to make release convenient. The correction must identify the actual primitive and ownership transition at each caller.

**No post-D durable report is required to make the release duty executable.** Missing durable failure evidence remains missing; the surviving duty does not create publication authority.

## 3. Treat read-source Opens as acquisitions

The report identifies two routes omitted by the owner’s fixed source set:

- ledger inspection after finalization reaches a fresh Open/Close, although E40.01 classifies the review as P;
- the private-source reader opens a handle, although E50.01 explicitly calls that Open pure observation and E50.03 supplies C without its acquisition predecessor. :chatgpt-content-reference{index="9"}

**Reading is the operation’s purpose; acquiring a handle is still part of what it does.**

The new map must separate admission, successful acquisition, bounded reading, and release. After S, these run-path Opens cannot borrow F, the new status-observation scope, or the offline receiver’s retrospective authority. The future caller must refuse or skip the fresh acquisition and retain the resulting evidence limitation.

The correction also covers the loop-control, loop-candidate, and shared terminal helpers’ raw-open/wrap-failure branches. A successful raw Open establishes an owner before wrapping. Successful wrapping transfers it; failed wrapping leaves one raw release alternative. The wrapped and raw paths must not each grant a release for the same acquisition. :chatgpt-content-reference{index="10"}

The fixed checks must be derived from these actual callers—not limited to the existing 25 owner names. The review explains why the eight successful mutation refusals missed these defects: the checker covered its declared signal and scratch sets, not the terminal read acquisitions or contradictory C prerequisites. :chatgpt-content-reference{index="11"}

## 4. Resolve the emergency target premise at the canonical gate

The L/T split no longer needs redesign. The remaining conflict is narrower: after `ReadProcessIdentity` fails, the corpus and caller permit an emergency branch based on separately qualified current creation/group custody, but E36.04 still conjunctively requires the missing process/start identity. :chatgpt-content-reference{index="12"}

The selected correction is an explicit, branch-sensitive alternative—not a general weakening of targeting:

**Either** the normal qualified process/start and held-target relationship is available, **or**, only for the selected post-Start identity-failure branch, independently sufficient current creation/group custody establishes the exact just-created target.

The second alternative cannot mean merely “Start returned a PID.” Codex must identify its actual construction, lifetime, group relationship, and no-reuse premises. Where those cannot establish a sufficient target, the branch must refuse and retain uncertainty. A positive trace cannot simply assume the failed identity fact reappears.

Every alternative still consumes the original local authority and applicable cutoff. Parent T cannot repair it, and successful signaling cannot erase the primary failure or prove group absence.

## Keep the correction focused and the method honest

The prompt carries forward C1, projection, C2, and R7 **only where unchanged**. The new status-observation term, channel ownership, attempt history, and authority encoding need their own affected consistency checks. They do not inherit prior satisfaction automatically. :chatgpt-content-reference{index="13"}

The current review also disclosed another prohibited initial Git query, a specialist’s checkout working directory, and fingerprint measurements taken after preliminary reads. Its matching selected files do not establish full repository preservation or absence of transient effects. I retain the concrete findings while preserving those method limits. :chatgpt-content-reference{index="14"}

The next prompt therefore treats a prohibited command as a **task-stopping boundary failure**, rather than another qualified continuation. That is an instruction boundary, not a claim of technical enforcement.

The intended owner endpoint is:

```text
ES_MOUNTED_HELPER_TEMPORAL_STATUS_ACQUISITION_RELEASE_DESIGN_CORRECTED_READY_FOR_FRESH_REVIEW
```

It requires one corrected normative corpus, the full active map, source-derived acquisition/release relationships, a complete finite status path, and discriminating inert checks. Fresh separate-parent design review follows. Implementation and live adoption do not.

Remote scratch, survivor, and possible disconnected-observer state remain unknown. The accepted helper’s old closure, its bounded safe observations and failed closeout, and the pending whole-candidate ES audit remain unchanged. :chatgpt-content-reference{index="15"}

### Inspection boundary and confidence

I read the complete attached review and the preceding correction and review instructions. The attachment measures **20,021 bytes**, SHA-256:

```text
534cfe95fe65245ff0c5f36e396205c64da0ac59dc86935534131d27eae5902f
```

The current corpus, full map, specialist originals, and review ZIP were not inspected here. Their detailed authentication and source findings remain **independent-reviewer-reported**; the handoff requires Codex to inspect those retained inputs before authoring. No repository commands, reviewed code, tests, host operations, or cleanup were executed here.

**Sources:** attached independent review and preceding owner/review handoffs. **Confidence: 0.98 in retaining the block; 0.92 in this correction scope.** Report-byte identity is measured. Corrected-design coherence, implementation readiness, operational consent, and privileged readiness remain unestablished.
