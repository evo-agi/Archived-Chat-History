Chat 00068 unfortunately got way too long. We will resume the work here.

Please review the zip I've attached. It contains the chat history for the latest tranche we were working on in Chat 00068.

- The latest message (stored in `Timeline/T592 - USER.md` ) came from me.
- README.md describes how to make use of the zip.

As for the local files and repo(s) for the ES work, I'm not sure which ones to supply yet.
