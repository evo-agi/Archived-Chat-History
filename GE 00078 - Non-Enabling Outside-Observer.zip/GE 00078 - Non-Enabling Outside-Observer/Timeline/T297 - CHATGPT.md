## The stop is correct

Codex found a genuine **implementation-ownership gap**, not a coding problem.

The accepted artifact does **not** currently authorize implementation in the Execution Substrate repository:

- Migration row **M23** is classified as **“no ES change.”**
- Its producer is the **external proof author / finite parent component owner**, not an ES package.
- All twenty implementation-source coordinates point into the external `Downloads/.../source/tooling/internal/proof/` tree.
- The proposed normative contract placement is external: `source/docs/TEMPORAL_CONTRACT.md`.
- None of the seven mapped Go files exists in the maintained ES repository.

Selecting `es/admission`, `es/runtimehelper`, or another ES package now would silently create a new authority and ownership model. Codex was right to stop before edits.

There is a second, independent problem: Codex reports a heavily non-clean working tree—66 tracked modifications and 17 untracked `es/admission/` files. Even after the ownership question is resolved, implementation should not begin until the intended baseline is distinguished from unrelated or unadopted working-tree changes.

## Critical path

Do not send the artifact back for a blind path substitution. First obtain a **read-only repository ownership and baseline survey** from Codex. That survey should establish:

1. Which maintained ES packages currently own the relevant lifecycle, admission, evidence, retained-result, and publication responsibilities.
2. Whether the accepted M23 clause hashes match `HEAD`, the working tree, or only the modified working tree.
3. What the 17 untracked `es/admission/` files are, without treating them as accepted authority.
4. Whether the external proof source corresponds to historical ES code, an independent proof implementation, or functionality never implemented in ES.
5. The minimum repository-owned mapping alternatives and their contract consequences.

Then we can author a governed artifact correction that:

- preserves the external proof tree as source/reference evidence;
- names the maintained ES implementation owners;
- selects the repository placement for the normative contract;
- explicitly reopens and supersedes M23’s “no ES change” boundary;
- distinguishes implementation call-site owners from artifact/source evidence;
- regenerates the pair and bindings;
- receives a fresh artifact review before another implementation attempt.

This read-only survey is evidence gathering, not another approval gate.

## Prompt to send to Codex

Attach the same accepted delivery and accepted review used in the blocked implementation task, then send:

```text
Perform a read-only Execution Substrate implementation-owner and baseline
survey for the accepted whole-R6J general native-source join design.

Repository:
  /Users/ds/Repositories/Execution Substrate/

This task authorizes repository inspection and read-only commands only.
Do not edit, create, delete, stage, format, generate, build, test, commit,
push, deploy or publish anything.

AUTHORITATIVE ARTIFACT INPUTS

A. Accepted delivery:
   ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_DELIVERY_20261025_10.zip
   67,230,247 bytes
   SHA-256:
   18c3410b531b95fd93fb15995168fe49740074b7ccdd38efba5efd0456d75402

   Nested accepted owner:
   ES_R6J_FRESH01_RECONSTRUCTION_REPAIRED_OWNER_20261025_10.zip
   61,660,562 bytes
   SHA-256:
   ce1cd7a5b73e2af8ad6acbaa414e5b9645abe1ad193de220c4b63e07ff111b27

B. Accepted fresh review:
   ES_R6J_FRESH01_RECONSTRUCTION_FRESH_REVIEW_20261025_10.zip
   30,948 bytes
   SHA-256:
   af2ef4f1c2f7bf177ac0165d81fe84c0b8f6e7ce5f0490fd70a9925536e51e7f

PRIOR BLOCK

The preceding implementation attempt stopped at:

ES_MOUNTED_HELPER_R6_GENERAL_NATIVE_SOURCE_JOIN_BLOCKED_EXTERNAL_PROOF_TO_ES_OWNER_MAPPING

It reported that:

- all twenty selected Go coordinates belong to seven files under the
  external Downloads/.../source/tooling/internal/proof tree;
- none of those seven files exists in the ES repository;
- M23 says “no ES change” and assigns production to an external proof owner;
- the proposed normative contract placement is
  source/docs/TEMPORAL_CONTRACT.md;
- choosing es/runtimehelper, es/admission or another ES package would require
  a new ownership and architecture decision;
- the working tree had 66 tracked modifications and 17 untracked
  es/admission files.

Do not revisit implementation in this task. Establish the exact repository
facts needed for a governed ownership-map correction.

OPENING AUTHENTICATION

1. Read all repository guidance applicable to inspection, including AGENTS.md
   or equivalent, current PLANS.md, architecture documentation, lifecycle
   contracts/design, package documentation and relevant tests.

2. Capture:
   - branch;
   - HEAD;
   - full porcelain status including untracked files;
   - staged state;
   - worktree path;
   - any repository-local instructions affecting this task.

3. Preserve the opening and closing states and require them to match.

4. Authenticate both artifact inputs and the exact nested accepted owner.

BASELINE PROVENANCE ANALYSIS

For every repository file or range cited by M23:

- compare the accepted bytes/range hash with:
  a. HEAD bytes;
  b. current working-tree bytes;
  c. index bytes, where different;
- state exactly which baseline matches;
- identify whether an accepted artifact claim currently depends on
  uncommitted working-tree content.

Do this for:

- PLANS.md:399–424;
- PLANS.md:483–524;
- .docs/execution_lifecycle/contracts.md:1296–1319;
- .docs/execution_lifecycle/design.md:660–698.

Do not modify or normalize any file.

EXTERNAL PROOF SOURCE CLASSIFICATION

Inspect the accepted migration map’s twenty source coordinates and seven
external Go files:

- manifest_linux.go
- authority_linux.go
- terminal_protocol.go
- live_linux.go
- scratch_removal.go
- worker_linux.go
- process_custody.go

For each file and selected coordinate:

- authenticate the accepted external bytes;
- classify whether equivalent or successor behavior exists in ES HEAD,
  the current working tree, tests, generated fixtures, examples or history
  already present locally;
- do not infer equivalence from filenames alone;
- identify the exact repository symbol, file and tests when a relationship
  exists;
- otherwise classify it as absent.

Do not use network access or search outside the supplied artifacts and
repository.

MAINTAINED OWNER SURVEY

Build a source-grounded responsibility matrix for these accepted contract
surfaces:

- G/B/confirmation ingestion and bounded parsing;
- pair and current-map identity validation;
- source-instance, epoch and interval coverage;
- subject creation, custody, Wait and terminal inventory;
- operation-specific request/result joins;
- resource acquisition, wrapper transfer, borrow, invalidation and consuming
  release;
- inherited C;
- outside-parent acquisition and observation;
- supervisor RunResult marshal/stdout;
- canonical outcome, retained result and receipt projection;
- P01, P02 and CLOSE construction/interpretation;
- caller/scenario reconciliation and contract tests.

For each surface report:

- current authoritative repository package, file and symbol, if any;
- current contract/document assigning that responsibility;
- relevant tests;
- whether it is production, compatibility-only, proof-only, fixture-only,
  incomplete or absent;
- whether the current working-tree version differs materially from HEAD;
- whether adopting the accepted design would preserve, move, split or create
  ownership.

Do not choose an implementation owner merely because it is the nearest
package.

UNTRACKED AND MODIFIED ADMISSION WORK

Inventory the seventeen reported untracked es/admission files and all
relevant modified tracked admission/lifecycle files.

For each:

- path;
- size and SHA-256;
- source/test/doc/generated classification;
- relationship, if any, to the accepted design;
- whether it exists in HEAD;
- whether another tracked source imports or references it;
- whether it appears to be an unfinished implementation, generated evidence,
  unrelated work or cannot be classified.

Treat these files as unadopted working-tree evidence—not repository
authority. Do not execute them.

MAPPING ALTERNATIVES

Produce a finite repository-owner alternatives table. Each alternative must
identify:

- owning package or packages;
- normative contract placement;
- public/internal API boundary;
- authoritative writer for each mutable runtime fact;
- required migration-map changes;
- required documentation and contract-test changes;
- compatibility treatment;
- security/authority implications;
- whether the alternative conflicts with current repository contracts;
- evidence supporting and contradicting the alternative.

Include an explicit “no maintained ES owner currently exists” alternative
if supported.

Do not recommend an alternative solely from convenience. You may state which
alternative is best supported by current repository contracts, but label that
as an inspection-based recommendation rather than an accepted decision.

REQUIRED DELIVERABLE

Create one compact, source-containing, read-only survey package with:

- SURVEY_REPORT.md;
- REPOSITORY_OPENING_STATE.json;
- REPOSITORY_CLOSING_STATE.json;
- ACCEPTED_ARTIFACT_IDENTITIES.json;
- M23_BASELINE_PROVENANCE.json;
- EXTERNAL_SOURCE_COORDINATE_MATRIX.json;
- MAINTAINED_OWNER_RESPONSIBILITY_MATRIX.json;
- DIRTY_WORKTREE_CLASSIFICATION.json;
- IMPLEMENTATION_OWNER_ALTERNATIVES.json;
- SELECTED_REPOSITORY_EXCERPTS.md;
- exact hashes and line/symbol coordinates;
- command ledger with stdout, stderr and exits;
- self-excluding manifest;
- fresh reopen receipt.

Do not package secrets, databases, build output or unrelated working-tree
contents. Include only bounded source/document/test excerpts needed to
support the survey.

Return endpoint:

ES_R6_GENERAL_NATIVE_SOURCE_JOIN_IMPLEMENTATION_OWNER_SURVEY_COMPLETE

If inspection cannot establish a safe or finite owner survey, return a
precise blocked endpoint naming the missing evidence.

REPORTING

Return:

- exact endpoint;
- opening and closing repository states;
- whether they match;
- primary repository-owner findings;
- whether accepted M23 facts match HEAD or only working-tree bytes;
- classification of the untracked es/admission work;
- finite mapping alternatives;
- exact commands and results;
- skipped inspection and why;
- package path, bytes, members and SHA-256.

No repository effect, test execution, commit, push, deployment or
publication is authorized.
```

## What not to do

Do not:

- ask Codex to “pick `es/admission`”;
- copy the seven external proof files into ES;
- change only the paths in the migration map;
- treat the external proof tree as a maintained production package;
- make the dirty working tree the baseline by implication;
- reuse the prior implementation prompt.

Once the survey returns, the next work belongs to a **ChatGPT artifact-design owner**: resolve the implementation-owner split, update the map and placement, then submit that narrow correction for fresh review.

**Sources:** Codex’s blocked implementation report; accepted owner `normative/TEMPORAL_CONTRACT_MIGRATION.json`, especially M23, `normative_contract`, `selected_source_to_map_path`, and `source_root`.  
**Confidence:** **0.99** that the implementation stop is correct; **0.97** that a repository-owner/baseline survey is the necessary next step.
