**Proceed to one fresh, cumulative independent re-audit of the external mounted-helper successor. Keep the ES candidate frozen.** The report supports completing the bounded loop-wrapper repair; it does not close the remaining findings, approve the residual policy, or authorize privileged execution. That is also the report’s stated disposition. :chatgpt-content-reference{index="0"}

**Send this to a fresh, read-only Codex conversation—not the implementation conversation: :chatgpt-content-reference{index="11"}[Cumulative mounted-helper independent re-audit prompt](sandbox:/mnt/data/ES_Cumulative_Mounted_Helper_Reaudit/ES_Cumulative_Mounted_Helper_Independent_Reaudit_Prompt.md).**

The handoff covers the complete successor, including **F-1…F-16, V2-01…V2-16, and LIO-01**. It does not authorize another repair, build, remote-control run, ES-suite run, gateway installation, or mounted execution.

## What this repair establishes

The reported change matches the requested boundary: the actual `LOOP_CTL_GET_FREE` call now uses `IoctlRetInt`, and a private result handler separates successful selection from error and association custody. It accepts zero, preserves real errors, rejects invalid values, and adds no retry, fallback, reset, or detach authority. The existing namespace corrections and the pointer-output `FS_IOC_GETFLAGS` use were preserved. **This is the right repair shape; the auditor must now confirm it in the actual source.** :chatgpt-content-reference{index="1"}

The regressions are usefully discriminating. They include a nonzero result of `37`, valid zero, a numeric result accompanied by `EBUSY`, invalid results, and failures after selection. The report also records an AST-based check of the live call and a negative predecessor fixture that remains rejected despite containing the desired spelling in comments and a string. These are stronger than testing only a disconnected helper, but they remain **source-coupling and substituted-effect controls—not real loop operations**. :chatgpt-content-reference{index="2"}

The evidence now separates as follows:

| Evidence | Current status |
|---|---|
| External tooling unit and race suites | **274 passing test events each on Darwin/ARM64**, with no selected-test failure or skip. |
| Linux/AMD64 vet and supervisor builds | Passed as static/build evidence; the new supervisor was never executed. |
| Seven ordinary-user Linux controls | Inherited for the byte-identical safe executable and unchanged selected dependency closure; not rerun. |
| Normal and diagnostic mounted-proof binaries | Unchanged, inherited compile-only artifacts; neither has executed. |

Those distinctions are supported by the command and artifact records summarized in the report. The local test count is not another Linux runtime result, and identical safe-control bytes do not validate the changed supervisor. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

**There is no reason to rerun the seven controls merely because unrelated privileged code changed.** The appropriate independent task is to authenticate the unchanged executable, its selected inputs, the retained plan and raw observations, and the cleanup evidence.

## The unbound-device question must remain separate from wrapper correctness

The report explicitly retains a consequential distinction: its referenced Linux implementation may return an existing unbound loop number **or create a new unbound object** during `LOOP_CTL_GET_FREE`. A returned number or an unassociated status therefore does not, by itself, establish that global loop inventory remained unchanged. No such operation ran during this repair, so this is a **future residual-state question, not an observed leak**. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

The re-audit must trace that possibility through the actual controller, particularly failures after selection but before successful configuration. The important questions are whether the possible effect remains represented, whether uncertainty survives later failures, and whether the final status could misleadingly claim that the host was restored.

**The reported wrapper correction does not answer those questions. Equally, an unanswered residual-policy question does not justify another speculative source repair before reviewing the existing implementation.**

I have made the decision boundary explicit in the prompt:

- The auditor assesses the current state model, cleanup claims, and policy interface.
- It recommends the smallest sufficient treatment and identifies whether that requires a policy decision, a source/status correction, or a different bounded fixture arrangement.
- It does **not** accept a persistent host effect, add `LOOP_CTL_REMOVE` authority, or authorize blind cleanup by issuing its report.

That is a refinement of the report’s wording that “independent review must decide” the treatment. **Review should supply the evidence and recommendation; adopting a new effect or removal authority is a separate decision.** No implementation or historical document is being rewritten here.

The audit should distinguish two outcomes. A coherent component may be statically suitable while residual policy and privileged entry remain pending. A code path that loses an acquired effect or falsely reports cleanup success is a concrete implementation blocker—not something to defer under “runtime qualification.”

## What the cumulative review must close

The latest loop change is small, but the unreviewed cumulative successor is not just that change. It includes the broader lifecycle, entry, transport, evidence, telemetry, and oracle repairs, followed by the namespace and loop corrections. The latest report expressly preserves cumulative review of all three finding registers. :chatgpt-content-reference{index="7"}

The prompt assigns three complementary read-only perspectives: Linux lifecycle mechanics; privileged entry, custody, and residual policy; and proof, instrumentation, and evidence adequacy. The parent authenticates the target and reconciles their actual reports.

The review must examine the **live Linux implementation as well as the portable control model**. In particular, it must verify partial acquisitions inside multi-operation functions, thread and child ownership, poisoned RPC connections, deadline propagation, final resource accounting, and the distinction between failure, uncertainty, and successful cleanup. Passing substituted controls cannot close a live path they do not accurately represent.

It must also preserve the normal/diagnostic distinction. The diagnostic binary uses different effective compilation source and supplies supplementary causal evidence. It cannot rescue a failed normal case or establish that normal product bytes emitted its trace. The report keeps both binaries compile-only and unchanged. :chatgpt-content-reference{index="8"}

**This is the external-component re-audit, not the whole-candidate ES audit.** Actual mounted cases, administrative entry and formatter qualification, deployment observation, supported-local consumer/operator proof, the unconditional whole-candidate audit, and exact-byte staging/commit authority remain outstanding. :chatgpt-content-reference{index="9"}

A successful scoped result may therefore be:

```text
ES_MOUNTED_HELPER_CUMULATIVE_STATIC_REVIEW_SATISFIED_POLICY_ENTRY_RUNTIME_PENDING
```

It must not be presented as root authorization, mounted-proof success, or product acceptance.

## Inspection boundary

I fingerprinted the attached report: **16,898 bytes**, SHA-256:

```text
11f60ce75987028112eb27a34ffb850b9744be093d2dc43c52e73c025a141bea
```

That matches the supplied abbreviated identity. The current ZIP, implementation files, raw validation records, and binary bodies were not attached here, so their detailed authentication and execution remain **Codex-reported**.

The audit prompt supplies the retained paths and complete report-derived source/build/binary anchors. It also explicitly records that only an abbreviated current ZIP digest was supplied; the auditor must compute its full identity and verify the complete anchored contents rather than inventing the missing hash characters. The report says the current packet contains the source, cumulative deltas, historical findings, and inherited safe-control evidence needed for this review, so no new collection tranche is necessary to initiate it. :chatgpt-content-reference{index="10"}

**Sources:** attached loop-repair report and retained namespace/audit records. No repository code, tests, host commands, or privileged operations were executed here.

**Confidence: 0.97 in proceeding to this cumulative re-audit.** Report-byte identity is established; validation and preservation remain owner-reported pending independent authentication. Privileged lifecycle correctness, residual-policy sufficiency, and whole-candidate acceptance remain unestablished.
