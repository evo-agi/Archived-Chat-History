**No joint-episode checkpoint or general-join successor is established. Keep the reviewed nineteen isolated accounts as the baseline.** The latest response is an incomplete owner attempt—not a new design rejection and not evidence that the amended construction is impossible.

I am narrowing the next task to **joint composition only**. General-join normative authoring should not compete for the same pass before the joint records and their checks exist.

### ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01.zip[Download the self-contained composition-only restart ZIP](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01.zip)

:chatgpt-content-reference{index="1"}[Completed delivery verification](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01_VERIFICATION.json)

Use this single ZIP in a **fresh ChatGPT design-owner conversation**, not Codex or an independent reviewer. It includes the previous amended handoff unchanged, all its nested primary evidence, a new source-derived RPC inventory, and the narrower task.

## The 157-call plan has a source basis—but is conditional

I independently read the accepted source’s fixed mounts, case loop, worker initialization, poll loop, cleanup, and connection sequencing. The reported count is supported for this particular branch:

| Connection sequence | Component | RPCs |
|---|---|---:|
| **1–49** | Hello, prepare, 23 mount/observe pairs, fixture verification | **49** |
| **50–87** | Nineteen candidates, one spawn and one completed poll each | **38** |
| **88–157** | Twenty-three reverse-order inventory/unmount/inventory triples, then exit | **70** |

The first candidate’s spawn/poll uses **50/51**. The last diagnostic uses **86/87**. Each required diagnostic follows its normal base case in the source’s execution order; that differs from the canonical nineteen-reference index.

**157 is not an invariant of every legal execution.** The adapter polls again when the worker returns an incomplete observation. The selected count therefore requires each first poll to find the candidate completed and return its complete ProcessRecord, with the relevant finalization and storage treatment successful. It also assumes all mounts are present before their normal cleanup and no error invokes extra termination or recovery paths.

The owner must construct those timing and state premises explicitly. It cannot discard an incomplete poll or reset later counters merely to preserve 157.

The full SOURCE_RPC_SCHEDULE.json[source-derived schedule](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01/analysis/SOURCE_RPC_SCHEDULE.json) and SOURCE_CANDIDATE_ORDER.json[per-candidate sequence assignments](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01/analysis/SOURCE_CANDIDATE_ORDER.json) are saved. Their SOURCE_EXCERPTS.md[source excerpts](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01/analysis/SOURCE_EXCERPTS.md) identify the exact owning paths and lines.

**These files are control-flow analysis, not a constructed episode.** They do not supply native timestamps, returned custody, complete source coverage, or a receiver-positive result.

## The original inputs remain available

I reverified the previous handoff and **all twelve nested archive boundaries**, reconciled the 135 baseline source files with their manifest, and compared all 133 copied cohort members with the corrected owner package.

The governing pair remains unchanged:

```text
Contract: 352,107 bytes
7307a0f7014197752d7af02adece3e3ce8728d582a62b28f93f7ff1d7bfac5d5

Map: 2,188,680 bytes
6cf2a6b8b802590250fa5233c0dd234582124159bfc013f05bc84c44d103dfb0

Pair:
aa76023d139a00ccf218a3cf5897a4ed74f1d0389d96396ff3335911fc7eaed7
```

The original isolated accounts still contain their repeated initial sequence 17 and admissions 18/19. Their eighteen adjacent chronology conflicts also reproduce. **They remain valid preserved isolated witnesses—not the bytes to concatenate into the new episode.**

Some older indexed attachment references have expired, but the required mounted archive bytes are readable and included. **No primary-input re-upload or another draft-availability task is needed.** I have not recovered or inspected the unfinished work in the other conversation.

## Make the next deliverable actual joint records

The new task requires the owner to construct a separate modeled episode from the verified source, using one worker/connection and explicit new per-candidate sequence, time, request, and acquisition-instance relationships.

Its first substantive save must contain **two consecutive complete candidate counterparts and their preceding shared connection state**, with actual native/body bytes, fixed expectations, and a separately authored inert reader result. That establishes the cross-candidate boundary before the remaining seventeen accounts and controls are added. It is an internal checkpoint, not another approval gate.

The completed composition must then cover all nineteen accounts and the selected cleanup/exit branch, while preserving:

- R01–R05, including adapter treatment before controller absorption;
- exact case meanings and source/candidate/driver bindings;
- distinct acquired owners, transfers, and consuming releases;
- expected refusal and diagnostic non-rescue;
- truthful unresolved prefixes and lost acknowledgements;
- the difference between an exit reply, worker reap, group absence, and descriptor release.

A source-compatible sequence count alone cannot satisfy those obligations. Nor can favorable per-candidate results substitute for checking the relationships between candidates.

**The full normative corpus/map stay unchanged during this composition-only task.** General joins remain pending; the new internal construction records must not be presented as an already accepted public-R6 grammar.

## Message to send

Attach the single restart ZIP to a fresh ChatGPT owner conversation and send:

> Continue as the artifact-only owner for the joint-episode composition checkpoint. Read `README_FIRST.md`, `DECISION_RECORD.md`, `analysis/RECEIVING_INSPECTION.md`, and `NEXT_OWNER_TASK.md`. All required available primary bytes are included.
>
> Preserve the nineteen isolated witnesses unchanged. Independently check the supplied source-derived 157-RPC branch and its assumptions, then author a separate jointly instantiated episode with coherent worker/connection state, source execution order, per-candidate timing, request matching, custody, and native-to-body projection.
>
> Save and reopen the first substantive connected construction before expanding the controls. Complete the all-nineteen composition and its discriminating checks in this pass, but do not proceed to general-join normative authoring.
>
> Do not restart draft recovery, launch Codex, access repositories or hosts, execute uploaded programs, implement Go source, or claim independent acceptance. Return actual downloadable artifacts with the exact supported boundary.

The only composition-complete endpoint is:

```text
OWNER_R6_JOINT_EPISODE_COMPOSITION_CHECKPOINT_GENERAL_JOINS_PENDING
```

It is **not** the general-join READY endpoint.

## Delivery and limits

The new restart ZIP was built twice identically, then closed and reopened with every member checked:

```text
Bytes:   9,780,384
Members: 13
SHA-256: c4becf77aeb13de6838936a48e0f90957680d08c723ef4666d86f0ca200e9135
```

**Sources:** the authenticated amended handoff, selected accepted-source paths, and the RECEIVING_INSPECTION.md[receiving inspection](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_ONLY_RESTART_20261017_01/analysis/RECEIVING_INSPECTION.md). I authored the schedule and continuation instructions—not a joint episode or corrected join contract. No uploaded code, repository command, host, runtime, or cleanup operation ran.

**Confidence:** **0.99** in the input integrity and conditional source-call inventory. Joint composition, general-join correctness, implementation readiness, and independent acceptance remain unestablished.
