**Retain the block and repair F00–F04 before general-join authoring.** The review supports the selected 157-RPC branch, but the delivered positive has a timing defect and its composition reader does not preserve R01, R04, and R05 soundly.

This calls for **one bounded model-and-reader repair**, not another temporal-contract redesign, candidate expansion, or return to the partial Go implementation.

### ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01.zip[Download the self-contained F00–F04 repair handoff](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01.zip)

:chatgpt-content-reference{index="1"}[Completed handoff verification](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01_VERIFICATION.json)

Send this single ZIP to the **existing ChatGPT joint-composition design-owner conversation**, not Codex or the reviewer. It includes both original archives unchanged, the complete repair task, source excerpts, and my receiving-side checks.

## What I verified

The uploaded review matches its reported identity:

```text
ES_R6_JOINT_COMPOSITION_FRESH_REVIEW_20261017_01.zip
Bytes:   2,673,034
Members: 19
SHA-256: f17e62333ea9b270b4900dab25c198140a83bbc141cfaa2212603327c6bb3c4f
```

The original **37,771,220-byte composition checkpoint** also matches its established identity. Both archives and all four nested counterexample ZIPs pass actual-byte size, hash, CRC, encoded-mode, safe-path, and exact manifest checks.

I reconciled the **135 supplied baseline source bodies** against their retained manifest and reproduced the eighteen ranges in the owner’s fixed source-range table. I then inspected the decisive deadline, wire-error, adapter, controller, and reader paths.

For each counterexample, the nineteen account bindings and 157 request/response file hashes check out. Their actual discriminants are present—not merely described in the report. **I did not execute the uploaded reader or independently reproduce its predicted outcomes dynamically.** RECEIVING_INSPECTION.md[Receiving inspection](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01/review_support/RECEIVING_INSPECTION.md)

## F00: correct the origin without moving the execution

I independently reproduced the same **500,000 ns excess in all nineteen contexts**. The source computes the earlier of the creation-time sample plus 53 seconds and the original deadline minus the 150-second reserve.

For the first candidate:

```text
Declared context creation:       1,159,999,500,000 ns
Creation-relative maximum:      1,212,999,500,000 ns
Delivered deadline:             1,213,000,000,000 ns
Excess:                                   500,000 ns
```

All copies of an incorrect deadline agreeing with one another does not make its origin source-compatible. The reader currently checks that agreement, but not the source-relative cap. CONTEXT_DEADLINE_RECOMPUTATION.json[All nineteen calculations](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01/review_support/CONTEXT_DEADLINE_RECOMPUTATION.json)

**The selected repair keeps the recorded creation instants and event schedule.** It derives each deadline from the declared creation/decision origin under the existing source minimum. With the current modeled origin, that shortens each candidate deadline by 500,000 ns.

There is no apparent need to shift candidate execution: every named candidate-native event and associated RPC event, including the modeled uncertainty allowance, remains **more than 32 seconds before the stricter maximum**. The owner must still check context cancellation and every dependent binding.

The correction must propagate through native admissions, projected events, request/response deadline fields, context records, indexes, hashes, and current controls. It must not widen the cap, move the creation marker forward, introduce another clock offset, or reinterpret the marker as an undocumented pre-call observation.

The original positive and both historical checkpoints remain unchanged, with their F00 defect disclosed.

## F01–F04: restore the complete predicates

| Finding | Required correction |
|---|---|
| **F01 — return consistency** | Check status, error, and typed payload together for **all eight selected operations**, not just `wait-leader`. Distinguish contradictions from truthful failures and explicitly unsupported outcomes. |
| **F02 — wire-error conservation** | Validate and carry the worker envelope’s error through adapter treatment, controller absorption/error handling, and progression. Apply the boundary to both complete and pending-prefix paths. |
| **F03 — treatment identity** | Join the selected poll request and returned observation through receipt, adapter treatment, and absorption. Correct ordering cannot compensate for an adapter result naming spawn. |
| **F04 — validation order** | Finish recursive typing before set construction, hashing, indexing, inverse projection, or equality. Invalid typed evidence must produce deliberate nonacceptance—not an exception counted as a passing refusal. |

These are related integration failures: the reader checks some favorable facts while failing to check the relationships that give those facts their meaning. The repair should recover the complete fixed rules, not add four special cases for the saved counterexamples.

### Wire error is separate from useful partial custody

The accepted source’s response declares `error,omitempty`. **An absent error field is the normal emitted empty-error form**; the repair must not reject every existing positive for lacking an explicit empty string.

A nonempty error is different. The live adapter checks it **before** normal post-completion sampling and storage. It returns the observation and error; the controller may absorb that observation, then propagates the error rather than proceeding as a successful candidate.

Thus neither shortcut is valid:

> Ignore the wire error because the observation looks complete.

> Discard the observation because an error exists.

The new reader must retain both. SOURCE_AND_READER_EXCERPTS.md[Exact source and reader excerpts](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01/review_support/SOURCE_AND_READER_EXCERPTS.md)

### R05 requires identity and order

The valid interpretation remains:

```text
raw poll response
→ adapter-boundary receipt
→ matching adapter treatment
→ controller absorption after apply returns
```

Every participating record must join the **same poll request and response**. A result naming the same candidate’s spawn request is still wrong, even when its process digest, timing, and custody match.

Spawn remains free of a fictitious adapter-result prerequisite. Error treatment remains distinct from normal storage. A later correct result cannot repair earlier or misbound absorption.

## Do not let the deadline repair mask the reader regressions

**All four new counterexamples inherit F00.** I confirmed that their context-creation records are byte-identical to the defective positive.

Once F00 is enforced, those original specimens may be rejected for their old deadline before the reader reaches F01–F04. That would be a valid rejection, but **not evidence that the other defects are repaired**.

The handoff therefore requires two clearly separated layers:

- Preserve the original counterexample archives and static predictions unchanged.
- Create explicitly named current derivatives applying the same scoped deadline correction as the repaired positive, while retaining each counterexample’s adverse mutation and rebuilding its dependent hashes.

The current derivatives must pass the deadline-origin and binding checks, then refuse at the intended return, wire-error, request-identity, or typing predicate. Their results must not be described as execution against unchanged historical bytes.

The same treatment applies to affected earlier controls. **P01 needs a corrected-timing counterpart** that retains the outstanding Wait, possible child, worker-held resource, and unknown controller custody. P02 stays a worker-channel-only, source-possible incomplete-poll prefix—not a complete lifetime or a defective source execution.

C11’s existing error/status confounder must also remain visible rather than being recredited as complete error conservation. COUNTEREXAMPLE_RECEIVING_CHECKS.json[Counterexample receiving checks](sandbox:/mnt/data/ES_R6_JOINT_COMPOSITION_F00_F04_REPAIR_HANDOFF_20261017_01/review_support/COUNTEREXAMPLE_RECEIVING_CHECKS.json)

## Preserve scope while completing the repair

The complete normative corpus/map, closed 25-transition language, accepted source, nineteen isolated witnesses, case semantics, field-local limits, and historical evidence stay unchanged.

The repaired positive retains one worker and connection, the selected first-complete-poll branch, source execution order, reverse cleanup, and the **31-instance named ownership universe**. It does not become complete R6 resource coverage.

The task requires a substantive repaired construction and newly authored inert reader to be saved and reopened before expanding the control set. Final validation must check actual obligations and results—not target the old **83,014** count. Unexpected reader errors and wrong-predicate refusals cannot count as successful regression tests.

## Message to send

Attach the handoff ZIP to the existing ChatGPT owner conversation and send:

> Repair the joint-composition checkpoint under `NEXT_OWNER_TASK.md`. Read the decision and receiving inspection, authenticate both input archives, and inspect the actual review specimens, accepted source, model, and reader before authoring.
>
> Correct F00’s creation-relative deadlines throughout the active construction without moving the existing event schedule or widening the source cap. Repair F01–F04 through complete return/envelope consistency, exact poll-treatment joins, and type validation before semantic use.
>
> Preserve the original F00-defective checkpoint and counterexamples unchanged. Create separately identified deadline-corrected regression derivatives so F01–F04 are tested at their intended predicates rather than masked by F00. Preserve truthful nonpassing prefixes and the limited incomplete-poll profile.
>
> Return a complete repaired composition package, newly authored inert reader, fixed rules, meaningful controls, exact reconstruction, preservation evidence, and completed delivery verification. Keep the normative corpus/map and accepted source unchanged. Do not author general joins, launch Codex, access repositories or hosts, execute uploaded programs, implement runtime code, or claim independent acceptance.

The intended owner endpoint is:

```text
OWNER_R6_JOINT_COMPOSITION_F00_F04_REPAIRED_REVIEW_REQUIRED
```

A **different fresh ChatGPT reviewer** must then examine those exact bytes before general-join authoring resumes.

## Delivery and limits

The new handoff was closed and reopened with exact member and input equality:

```text
Bytes:   40,323,627
Members: 15
SHA-256: 42a2b857db0329569ca94f8be95019d7f7a8c3a4acc2d74f8c64f138cfabdd0b
```

Some older indexed references have expired, but all required checkpoint, review, and nested source bytes are included. **No additional upload is needed for this repair.** The four historical owning-ES clause gaps and remote scratch/survivor/observer unknowns remain unresolved.

**Sources and limits:** the actual uploaded review and checkpoint; selected accepted source; the linked receiving checks. I reproduced the deadline arithmetic and counterexample relationships, but did not execute uploaded programs, perform a complete semantic audit, or repair the model.

**Confidence:** **0.99** in measured integrity and the reproduced deadline defect; **0.97** in the source-supported bounded repair direction. Repaired-reader correctness and independent acceptance remain unestablished.
