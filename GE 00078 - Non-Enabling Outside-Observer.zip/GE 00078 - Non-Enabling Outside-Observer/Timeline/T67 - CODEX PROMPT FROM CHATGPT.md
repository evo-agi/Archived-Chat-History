ES mounted helper — namespace error custody and empty formatter-log repair
Objective and role
Continue in the existing implementation/preparation Codex conversation. You are the sole writer of a fresh external successor, not an independent auditor.
Repair exactly the two current Medium findings, NS-CUST-01 and LIVE-LOG-01, from the latest cumulative SB-4 audit. Preserve its qualified static closure of SB-1 through SB-5 and the immediate SB-4/history/closeout correction. Do not redo the architecture, the five repairs, the already-complete invocation mechanism, or the ES validation program.
The engineering strategy is:
1. authenticate the current 126-member external source and latest audit;
2. define the two narrow contracts and their fixed acceptance obligations before editing;
3. repair the real namespace producer/caller and the exact supplemental-log producer/receiver path;
4. run local engineering controls, compile the changed Linux-selected tests, rebuild affected executables, and replay the existing seven ordinary-user Linux safe controls on the repaired safe executable;
5. retain complete new-source evidence and package for a fresh independent cumulative review.
The shared namespace helper is an explicit, narrowly authorized exception to the preceding internal/safemech byte-preservation restriction. Old safe-control execution remains historical evidence for its original bytes. It must not be relabeled execution of the repaired helper.
Success after all gates in this prompt:
ES_MOUNTED_HELPER_NS_CUSTODY_EMPTY_LOG_REPAIRED_LOCAL_AND_SAFE_LINUX_VALIDATED_REAUDIT_REQUIRED
No result authorizes privileged entry, mounted execution, residual-policy acceptance, deployment, ES acceptance, or Git publication.
1. Effects and non-goals
Create one fresh physical owner-only task root under /Users/ds/Downloads. All authoring, caches, records, builds, and local test scratch belong there or in an explicitly recorded task-owned short temporary directory. Preserve every predecessor root and its actual contents/modes.
The repository /Users/ds/Repositories/Execution Substrate/ and all its worktrees remain read-only. No ES source, PLANS.md, .docs, public DTO, dependency, runtime profile, product-test inventory, original proof-source union, staging/results tree, index, branch, ref, or worktree registration may change. No ES script, suite, or build runs.
The only remote authorization is section 8: existing ordinary-user safe mechanics on the already-governed AMD64 host, with authentication and finite effects. No other network use, dependency download/install, host discovery campaign, alternate host/credential, root/sudo probe, administrative gateway, signer/key establishment, privilege transition, namespace creation/entry, loop device/ioctl, formatter, mount, live supervisor/worker, normal/diagnostic proof execution, service/Docker/Lima/VM action, deployment, or Git write is allowed.
Local tests may use ordinary task-owned files and sockets and finite substituted effect primitives. Close-error tests may close their own object successfully and inject an error to model conservative uncertainty; do not induce an actual kernel close fault or leak resources deliberately. Do not run the Linux proof test executable or privileged supervisor. No independent audit agents or concurrent writers operate during implementation.
Reuse the existing finite recorder, evaluator, and A–F packaging chain. Do not introduce a generic custody framework, new resource registry, watcher, confirmation hierarchy, allocator, or package-proof service.
2. Authenticate the exact current inputs
Latest independent audit
Root:
/Users/ds/Downloads/ES-sb4-cumulative-independent-audit-o6k6x_de
Read:
- CONSOLIDATED_AUDIT_REPORT.md — independently measured attachment: 19,168 bytes, SHA-256 ec82e64dc262b43c7512126c79ef0720ff90849752d75891e2dc713f646f388e;
- ES_SB4_CUMULATIVE_INDEPENDENT_AUDIT.zip;
- AUDIT_COMPLETED_VERIFICATION.json;
- AUDIT_FINAL_IDENTITIES.json;
- actual three specialist bodies, decisive excerpts, CURRENT_LINEAGE_JUDGMENTS_64.md, prerequisite records, and consumed-companion records referenced by that packet.
No independent full SHA-256 for this audit ZIP was supplied in the relay. Measure it, compare its actual contents/manifest/adjacent completed records and the independently pinned report, and state that provenance relationship. Do not invent an anchor or treat an adjacent self-consistent identity file as an independent authority source.
Current independent endpoint:
ES_MOUNTED_HELPER_SB4_CUMULATIVE_REAUDIT_BLOCKED.
Historical endpoint remains:
ES_MOUNTED_HELPER_ACTION_CUSTODY_RECEIVER_REAUDIT_INCOMPLETE.
The authentic Vtpm8n success flag remains disqualified. Neither that history nor an earlier missing-invocation episode is reopened for retrospective reconstruction.
Current external engineering source
Root:
/Users/ds/Downloads/ES-mounted-helper-sb4-closeout-correction-kRBufd
Anchors:
- report ES_MOUNTED_HELPER_SB4_LINEAGE_AND_CLOSEOUT_CORRECTION_REPORT.md: 24,515 bytes; 417789308a774207d15c933739b622667a0449de029e45f68ae3b6a47c21320c;
- final/ES_MOUNTED_HELPER_SB4_LINEAGE_AND_CLOSEOUT_CORRECTION_REVIEW.zip: 2,537,244 bytes; 6f38fbb6116612ff2185c817aef674d7e320d42b25809a153c46c66e2af35ab0;
- 384 total regular ZIP members, 383 payload rows plus self-excluding manifest;
- complete source: 126 members; 19,580-byte manifest; 3589c65617999dd405ec805673bf8d238e5be87819172f0119c0a063af428dd5;
- selected-input record: 106 members; 21,769 bytes; d8dfa53266c384949cdfdf0c21a34af6aed7a8dbb473b5614bfd2c4974125eca;
- protected historical source/docs/FINDINGS_CLOSURE_MATRIX.md: 24,949 bytes, authoring mode 0644; d9a7c54cd8410b51e276d176660e156b72fced746f77f968026601fc23f8fa2a.
Authenticate paths, regular types, uniqueness, modes by representation, sizes/digests, CRC, manifest coverage, current source and deltas before deriving the successor. Read the actual current final/HANDOFF.json, semantic/lineage decisions, evaluator/checker/recorder sources and completed D/E/F invocation triplets. Do not infer their completion from the pre-packaging report.
EA-01 is already a nonblocking report typo. The real terminal_receiver_test.go is 83,862 bytes with full digest 43ffa00e3a36f6ab2fa522e05a08ace226fd023dbb06f7b3766a2a99d3bdc38e. Preserve the old report's malformed literal; authenticate the real file through full manifests, and carry the correction separately. Do not republish historical evidence merely to fix that literal.
Use the 126-member current source, not an older 119- or 125-member rollback. Read all current producers, callers, return types, tests, scripts, profiles, and fixed requirement files implicated below. Audit line references are inspection anchors, not a substitute for inspecting the current source.
3. Governing boundaries and preservation
Read current owning AGENTS.md, relevant PLANS.md, capability/configuration and execution-lifecycle guidance, then the affected external contracts. Classify each change as a correction within the finite external custody/receiver contract, not an ES authority or architecture change.
Authenticate the live ES preservation baseline with the retained inspected read-only serializer, no optional locks, fsmonitor, external diff/textconv, or uninspected filters. Preserve source, status, candidate, tracked/cached diffs, index, branches, refs, operations, and six-worktree inventory.
Required anchors:
- branch/upstream trunk_dev / origin/trunk_dev;
- HEAD b92bd9884106154d25342e1573dcc4c312311436;
- tree cdd4e44bac15c1952d70997143040644361f0bb1;
- parent 4f797fb63d3c5b95275b1455af36ebc9b695f773;
- source 358 rows: e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e;
- candidate 83 rows: 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2;
- status 83 rows: a4c2337504cb9a1de6c42a6b319f3171d759a6a1fda87a750b78e0c7ee7af98c;
- tracked diff 2,407,274 bytes: 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1;
- cached diff empty; index 39,949 bytes: 9ca13234f248fccb29e8136168bb577c49c3fcf3c23b3f0d23b2bc1bd3aac569;
- six worktrees, zero staged/conflicted paths or active operation.
Disclose exact same-object app-owned ref-name churn if present; do not generalize it into permission to ignore arbitrary ref or source drift. No new preservation schema or provenance recipe is necessary.
Keep the protected historical matrix byte-for-byte intact. Put owner responses to the two new findings in a separate current response/coverage record; keep the latest independent 64 judgments immutable as audit evidence. Do not rewrite historical rows to reflect new signatures or current status.
4. NS-CUST-01: preserve namespace acquisition evidence on error
Source obligation
Audit anchors:
- tooling/internal/safemech/linux.go:157–184: acquired namespace file; ignored close error at 166–168; empty return;
- tooling/internal/proof/worker_linux.go:197–202: records namespace only on full success;
- worker absence/projection at 223–231,399–429 and live_linux.go:1009–1014.
The primary startup failure already causes refusal. Repair loss of local resource truth; do not relabel this as a demonstrated leak or accepted successful proof.
Selected contract
Use the existing handle/result model or the smallest finite partial-result extension needed. Preserve existing successful qualification semantics. Immediately after a successful open, record acquired descriptor custody before any type, metadata, link, or post-open process-identity operation can fail.
Separate:
- never acquired;
- acquired but incompletely qualified, with exactly the facts actually known;
- fully qualified and handed to the caller;
- acquired then released once after qualification failure;
- acquired then release-uncertain after a failed close attempt.
Qualification failure must not fabricate a valid namespace identity, erase acquisition, or turn observed type/path/process facts into targeting authority. Unknown fields stay unknown. A numeric descriptor retained as evidence never authorizes another close.
Keep the helper's existing close-on-qualification-error ownership unless exact source inspection demonstrates a narrower coherent alternative. Invalidate the owning handle before its one close attempt; retain the primary qualification error and the close outcome separately, including both error identities. Never retry an invalidated descriptor number. Make all callers absorb finite partial evidence even when error is non-nil, before nil-worker/terminal-absence/projection decisions. A compatibility wrapper that discards the new error evidence cannot be used by the live path.
Successful qualified handles remain usable as before. Wrong type is still refusal; NS_GET_NSTYPE still uses IoctlRetInt; narrow proc namespace-link handling, actual type/identity checks, held child/start/pidfd relationship, and no-follow rules for ordinary files remain unchanged.
Propagate the error snapshot through actual worker custody, descriptor summary, terminalAbsenceProven, live adapter, controller, frozen outcome, and receiver refusal. Fresh absence of the process/group or other descriptors cannot erase namespace release uncertainty. Conversely, confirmed one-close release must not be reported as an unresolved acquisition forever. No generic registry or new cleanup authority.
Fixed acceptance obligations (independent of discovered test counts)
Document and bind these as required source-mapped obligations before implementation:
1. pre-open error: no acquired namespace, no close;
2. success: exact qualified handle and owned transfer; no premature close;
3. acquired-then-error at each real remaining qualification stage: type query failure, wrong type, metadata failure, link failure, post-open process-identity failure;
4. for those error paths: one successful close gives released evidence; one failing close retains release uncertainty and both errors; no retry under later cleanup or numeric reuse;
5. a real production acquisition-sequence control, with only primitives substituted, feeds actual worker/controller/freeze logic; later otherwise-successful cleanup cannot yield false complete custody; the serialized uncertainty survives and the public receiver refuses;
6. a paired acquired-then-error/close-success case keeps truthful released evidence while retaining primary failure.
Do not satisfy these with a mock HoldNamespace that already supplies the desired final snapshot. Tests must reach the lower-level return-producing code implicated in the audit. Add private explicit operation parameters only where needed; no global mutable test hook or new runtime mode.
Safe-control consumers are in scope only to consume/release the revised result correctly and add bounded fixed assertions inside the existing namespace-handle control. No arbitrary PID/path/command selection or new live mode.
5. LIVE-LOG-01: exactly one supplemental may be empty
Source obligation
The selected live profile includes mkfs-ext4.log; no nonempty-output condition exists. Audit anchors are manifest_linux.go:148–150, live_linux.go:188–195,545–568,621–635, terminal_protocol.go:637–663,944–961, and terminal_receiver.go:354–357,433,468–479.
The audit establishes an allowed source-level history, not an observed formatter execution. Do not run a formatter to justify the correction.
Selected contract
Permit size zero for the exact profile-defined mkfs-ext4.log supplemental, with the empty-content digest and the existing stable file/type/identity/owner/mode/membership checks. The allowance comes from the fixed profile/member role, not a caller-supplied generic optional/empty flag.
Empty is not absent. Keep the exact member mandatory. Keep positive structured-record sizes and all other current membership/content requirements. Do not remove -q, fabricate a newline, synthesize bytes, omit the log, or treat empty output as formatter-success evidence. Formatter exit/custody, case evidence, policy, timing, and all other success conditions remain independently required.
Align the whole path: actual payload selection, publisher size/digest declaration, receiver manifest validation, aggregate accounting, safe acquisition/read, cached reuse, and final semantic replay. Simply replacing <=0 with <0 is not sufficient.
Separate an expected length of zero from an invalid/unbounded read limit. The held reader must perform the existing stability checks and demonstrate exact EOF with finite oversize detection. A zero declaration must not suppress reading/stability/hash verification or allow an actual nonempty file through. Count empty members against the existing member cap; retain overflow-safe 16 MiB aggregate accounting, tighter per-member limits, bounded enumeration, and the existing bounded overrun-detection treatment. No budget increase or generic receiver rewrite.
Required composed controls
Create a real task-owned zero-byte formatter log selected through the actual supplemental path. Use the real publisher, receipt carrier, held reconstruction and public receiver. The graph must include all nineteen schema-faithful normal/diagnostic records and the real case adjudicators. Model only privileged/kernel observations and explicitly independent test trust/root-custody facts. No always-success review, bypass of the exact supplemental role, or standalone policy-only positive.
An ordinary-user modeled live-shaped path may substitute the root-ownership qualification at a narrowly identified test seam; it must not alter the production profile or let evidence select synthetic trust. Record exactly what is modeled. Do not touch live export storage or run a formatter.
Require:
- the complete honest empty-log graph accepts under those explicitly synthetic valid prerequisites;
- the existing nonempty allowed log remains accepted;
- missing log, wrong digest, declared-zero/actual-nonempty, zeroed structured record, out-of-profile empty member, wrong object/mode, and ordinary over-limit inputs reject at the intended predicate;
- rehashed semantically bad case or operational evidence still refuses even with the empty log and matching synthetic authentication;
- the old audited source is demonstrably rejected by at least one new empty-log and one new namespace-uncertainty control at their actual evidence level. Use narrow temporary predecessor fixtures or source-backed witnesses, not a repeated broad old suite. Never label Linux source/compile checks as runtime reproductions.
6. Allowed source surfaces and scope discipline
Before editing, record the exact prospective changed-file set and two small state/dataflow maps. Proceed in this task; a separate general design round is not needed.
Primary surfaces:
- tooling/internal/safemech/linux.go, matching namespace result/handle declarations and tests;
- tooling/internal/proof/worker_linux.go, namespace custody projection in process_custody.go, directly affected controller/live adapter call sites and tests;
- tooling/internal/proof/terminal_receiver.go, terminal_protocol.go, narrowly affected payload selection/classification and tests;
- existing safe-control namespace-handle caller and tests only where its revised shared API/required fault assertions demand it;
- affected current external custody/log/profile/validation-status docs;
- existing freeze/requirement/evaluator/recorder/packet scripts only for necessary root, selection, requirement, and new evidence binding.
Narrow new private source/test files are allowed when needed to keep the finite result or fault seam reviewable. Do not broaden unrelated descriptor, signal, timing, loop, trust, terminal-graph, grammar, or receiver semantics. Audit every caller of the changed shared namespace API; compile accommodation must not discard partial evidence.
The prior blanket internal/safemech protection is relaxed ONLY for this namespace acquisition/result/release contract and consumers. Raw-FD classification, threads, RPC, signal, and unrelated safe mechanics remain protected. Dependencies, ES source, normal/diagnostic drivers and overlay, historical matrices, and old inputs remain byte/mode-identical. Do not duplicate the defective helper into internal/proof merely to retain an old safe-binary hash.
Preserve SB-1…5 and the fixed reciprocal obligation SB4-CHANNEL-FAILURE-WITH-STDIO-ACQUIRED-AND-RELEASED, original matrix anchor, earlier meaningful controls, and complete current invocation predicate. Add the two new requirements independently of test discovery. Use a separate current response file rather than editing docs/FINDINGS_CLOSURE_MATRIX.md.
7. Local validation and affected artifacts
Pinned Go executable:
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go
SHA-256:
3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19.
Authenticate installed sources/dependencies needed for namespace API and file-close/reading semantics. Use the already-correct recorder/offline runner. Before the first Go invocation, establish task-private HOME/config/telemetry/cache/temp/GOPATH. Record go telemetry off there, then require effective off/private telemetry, empty effective GOENV, GOTOOLCHAIN=local, GOWORK=off, GOPROXY=off, GOSUMDB=off, GOFLAGS=-mod=readonly, and authenticated read-only modules. Do not inspect/alter historical user telemetry or install anything.
Freeze a literal absolute command plan, complete source, command-selected build inputs, fixed obligations/crosswalk, runner/evaluator/checker identities, safe-control effect inventory, and all environment expectations.
From the external source/tooling module only:
"$GO" version
"$GO" env -json GOOS GOARCH CGO_ENABLED GOROOT GOTOOLCHAIN GOENV GOWORK GOPROXY GOSUMDB GOFLAGS GOTELEMETRY GOTELEMETRYDIR GOMODCACHE GOCACHE GOTMPDIR
"$GOFMT" -d <exact touched Go files>
"$GO" test -json ./... -count=1
CGO_ENABLED=1 "$GO" test -race -json ./... -count=1
"$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" vet ./...
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" test -c -o "$OUT/proof-linux.test" ./internal/proof
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" test -c -o "$OUT/safemech-linux.test" ./internal/safemech
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/supervisor-A" ./cmd/es-mounted-proof-v2
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/supervisor-B" ./cmd/es-mounted-proof-v2
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/safe-A" ./cmd/es-mounted-proof-safe-controls
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 "$GO" build -trimpath -buildvcs=false -ldflags=-buildid= -o "$OUT/safe-B" ./cmd/es-mounted-proof-safe-controls
Resolve placeholders and use the actual pinned formatter and current effective-environment allowlists in the frozen plan. Add recorded Linux environment, package/test selection, import-closure and go version -m inspections required to bind the artifacts. Every applicable test/subtest/package must complete correctly; no-test command packages remain separate. Test counts are observations, not the acceptance oracle. Preserve the 1,016/166 predecessor crosswalk and older meaningful obligations; label Linux-selected compile-only tests separately.
Supervisor A/B and safe A/B must each match within their pair. Do NOT require the repaired safe binary to equal historical c6ba7a7e0eb662ad8073d834a09f03ba1690a6f77b025b00e5c52138f6000b75. Selected shared source changes mean the old seven-control record cannot validate the new artifact, even if the import-package name listing stays identical. Section 8 creates the required new bounded runtime record.
Normal/diagnostic proof artifacts depend on a separate source union. Authenticate that it is unaffected and carry forward their prior compile-only identities and current-body-unavailable qualification. Do not rebuild them merely to erase that limitation. No original ES union or diagnostic effective-source change is authorized.
8. Narrow renewed authorization: seven safe Linux controls
This section is the sole permission to contact a host. It is deliberately distinct from the audit's non-execution posture and from privileged mounted proof.
Target: existing SSH alias host_to_remote_linux_m75q, existing ds login, expected UID:GID 1000:1000, Linux/AMD64. Historical machine-ID digest anchor is a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6; authenticate current identity without printing raw identifiers. Use batch mode, strict existing host-key checking, no forwarding, and no TTY. Access/identity failure stops; do not restore services, install tools, switch host, or contact ARM64/Lima.
Before transfer, inspect the safe command's entire initialization/import/dispatch/child/effect closure. It must refuse root and expose only the existing seven finite controls. Its actual closure must exclude internal/proof live dispatch, supervisor, formatter, mounts/loops, credential mutation, arbitrary commands/PIDs/paths, and a relaxed administrative mode. Keep raw-FD classification and the known safe action boundary intact. If it cannot be shown safe under this scope, stop before transfer.
Transfer only the locally built safe executable, exact fixed plan/identity data, and the existing inspected minimal transport/timeout wrapper when required. No source archive, compiler, module cache, supervisor, proof test binary, formatter, or privileged manifest goes to the host. No remote Go command or telemetry configuration is needed.
Create and bind fresh physical mode-0700 scratch; authenticate all transferred bytes before execution. Freeze exact argv/cwd/env/limits/assertions and local evaluator. Run sequentially on one binary:
<authenticated-task-root>/safe-controls raw-entry
<authenticated-task-root>/safe-controls namespace-handle
<authenticated-task-root>/safe-controls thread-child-owner
<authenticated-task-root>/safe-controls rpc-correlation
<authenticated-task-root>/safe-controls process-observation
<authenticated-task-root>/safe-controls thread-observation
<authenticated-task-root>/safe-controls exact-terminals
Preserve the actual selected contract of all seven controls. namespace-handle must still acquire/query only self or an owned existing child's mount namespace, require actual CLONE_NEWNS, and reject a genuine accessible PID-namespace handle with the observed wrong type. It must consume the new finite result/release contract correctly. Add bounded fixed post-open error/release assertions within this control where the shared seam allows; distinguish injected close-error/qualification outcomes from actual kernel observations. No runtime flag permits arbitrary fault or resource selection.
Permitted mechanics are finite own-process/thread/FD/pipe/socketpair/ordinary-file actions, owned same-UID harmless children, existing namespace-handle queries, fixed self/owned-child proc and pidfd observations, and the already-defined owned signal/reap/parent-death mechanics. They are not namespace creation/entry, a full worker experiment, arbitrary host process enumeration, or an ES workload. Each primitive remains tied to objects acquired in this control generation.
Use the existing enforced limits or stricter: at most eight concurrent control processes; 4 MiB aggregate output; 32 MiB task scratch excluding the authenticated executable; 30 seconds per control; 240 seconds per generation including ordinary cleanup. These are finite acceptance/dispatch budgets, not a guarantee of interrupting any kernel wait. Reap/cleanup uncertainty blocks progression.
On a control failure, stop later controls, retain all outputs and exact source/binary/plan identities, and close only authenticated task-owned resources. Return and authenticate evidence before deleting scratch. Require precise no-survivor/no-unexpected-mount checks and scratch absence. An inventory error means uncertainty, not absence. Report SSH accounting and transient process effects honestly; do not claim literal zero host writes.
Do not combine old passes with new results to manufacture an all-seven pass. The exact final safe binary must have one complete accepted seven-control record. The supervisor and Linux test artifacts remain unexecuted.
9. Correction discipline and evidence handoff
Ordinary in-scope development is allowed before freeze. After a final-source execution failure, close that generation and preserve it. At most one causally corrected final-source successor is permitted in this task, including at most two remote generations total. Corrections must stay inside the two selected findings and their direct test/recording bindings. Do not retry unchanged failures or broaden into a third defect. Source change requires fresh affected validation and an internally consistent final source/execution binding.
A purely analytical or packaging invocation defect may receive a separately recorded correction and replay against unchanged inputs, without re-executing successful tests. This cannot turn an actual failed test or missing observation into a pass. Missing real access/capability/authority, unrelated source drift, unsafe effects, or uncertain cleanup is a stop, not a reason for a fallback.
Reuse the authenticated A–F chain and complete actual invocation envelopes. Before the final freeze, require the two fixed new obligations, their assertion/source/evidence mappings, the original matrix identity, SB-4 reciprocal witness and all five prior composed obligations. Recheck the closed payload as well as its hashes. Keep declaration size, actual read size, and control coverage independently evaluated.
Record actual rejected and successful evaluator, checker, self-test, capture, packager, reopen-verifier, and handoff calls through the established outer recorder with original stdout/stderr and actual argv/cwd/env/timing/exit/timeout plus input/output identities. D/E/F post-package companions remain accessible outside the ZIP. An outer completed F envelope may bind F's already-produced handoff; do not require a file to hash its own future invocation. No fresh recorder service or recursive attestation chain.
Required outputs:
- exact successor report and source-containing review ZIP; full source and selected-input manifests; incremental/cumulative deltas; authoring/storage/extraction mode reconciliation;
- separate two-finding owner response, fixed obligations, acquisition-state table, member-size contract, actual source-to-control map, and requirement crosswalk;
- complete new local streams/decisions and Linux selection/compile evidence;
- affected supervisor/safe artifact identities, safe closure/effect inspection, new seven-control remote record, returned evidence and cleanup, with old safe results retained only at their original scope;
- exact matrix equality and SB-4/closeout preservation checks;
- invocation plan, actual envelopes/streams, completed packaging companions, final handoff and verification;
- exact ES opening/closing preservation, untouched protected-source assertion, failures/corrections and skipped-validation register.
No policy, key, signer, administrative entry, formatter qualification, containment mechanism, mounted case, deployment, whole-candidate acceptance, staging, or commit is established by these outputs. The next gate after a successful engineering return is a fresh independent cumulative review. If local work succeeds but renewed safe Linux observation cannot be obtained under this scope, report that exact pending gate; do not claim complete validation or automatically modify the host.
The audit's ES_MOUNTED_HELPER_SB4_CUMULATIVE_REAUDIT_BLOCKED remains historical. Report source repairs as owner findings pending re-audit, never as independent closure. Keep the two Medium findings' actual limits: lost namespace release truth is not a demonstrated leak/clean false acceptance, and empty-log refusal is not proof every live run is impossible.



















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Drag to reorder pinned navigation items


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
