## Retain the block; repair reconstruction evidence only

The semantic F‑01 correction has passed review. The sole blocker is that both checked-before reconstruction routes reproduce a stale 713-member selected tree rather than the exact delivered owner tree.

The stale member is:

```text
receiving/RECEIVING_INSPECTION.md

Route identity:
1,861 bytes
f632c3fcde78bc6d9711dfb27237912e7461f5d70c2f3299f597dedee3a3cd61

Exact delivered-owner identity:
2,514 bytes
0a9f44ba69a584a3e9b161b6f8efc1b2ba01e5c4c70c2ae251f18736f4fb597e
```

The exact current 713-member selected-tree digest is:

```text
10e0e23d76fa37fa6c07491da6e94c873e714f186bd4bbb246503f6c9dd19cf3
```

Do **not** reopen F‑01 semantics, rerun the 73-case semantic suite, amend the normative pair, or return to Codex. This is an evidence-only reconstruction repair.

### ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_HANDOFF_20261025_09.zip[Download the self-contained FRESH‑01 reconstruction-repair handoff](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_HANDOFF_20261025_09.zip)

:chatgpt-content-reference{index="1"}[Handoff verification](sandbox:/mnt/data/ES_R6J_FRESH01_RECONSTRUCTION_REPAIR_HANDOFF_20261025_09_VERIFICATION.json)

```text
Bytes:             84,375,745
Members:           28
SHA-256:           3bdb069a08166bf4e7b11d5ffba4c2903d222968878d16becf44c39c7542a3e6
Verification:      PASS
```

The handoff is self-contained. It embeds the exact repaired owner, unchanged direct checkpoint, complete FRESH‑01 blocked review, both route/delta pairs, the exact 713-member current-tree manifest, and the narrow owner task.

## Required correction

The next owner should:

1. Preserve all 713 selected paths byte-for-byte, especially the exact 2,514-byte receiving report.
2. Correct the rejected-owner route by adding that exact report to its delta instead of copying the stale predecessor member.
3. Correct the R26.G06 route by replacing its stale report payload.
4. Regenerate both `after_members` lists directly from the frozen exact owner bytes.
5. Require both normal routes to produce:

```text
713 members
10e0e23d76fa37fa6c07491da6e94c873e714f186bd4bbb246503f6c9dd19cf3
```

6. Add an independently authored verifier that compares every reconstructed selected member against the **exact final owner ZIP and its manifest**. The route list may not serve as both expected and actual evidence.
7. Add guards for a stale route row, stale delta payload, stale final-owner member, wrong before-image, wrong removed span, wrong after-image, missing path, and extra path.
8. Preserve the normative pair, profiles, reader, active-map bindings, six F‑01 controls, both 73-case rounds, and direct checkpoint unchanged.

New repair reports and reconstruction records should use new paths outside the frozen selected tree. The existing `receiving/RECEIVING_INSPECTION.md` must not be edited again.

## Message to send

Send the handoff to the **same ChatGPT artifact-owner conversation that produced the F‑01 repair**, not Codex or the reviewer:

```text
Repair FRESH-01 under NEXT_OWNER_TASK.md.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md,
receiving/RECEIVING_INSPECTION.md,
receiving/STALE_ROUTE_ANALYSIS.json,
receiving/EXACT_CURRENT_SELECTED_TREE.json, and the complete blocked
review before authoring.

This is reconstruction-evidence repair only. Preserve every one of the
713 selected semantic paths at the exact identities in
EXACT_CURRENT_SELECTED_TREE.json. In particular, preserve
receiving/RECEIVING_INSPECTION.md unchanged at:

2,514 bytes
0a9f44ba69a584a3e9b161b6f8efc1b2ba01e5c4c70c2ae251f18736f4fb597e

Correct both route/delta pairs:

- the rejected-owner route must add the exact current receiving report
  instead of copying the stale rejected-owner member;
- the R26.G06 route must replace its stale receiving-report delta member.

Generate both after-members lists from the frozen exact current owner
tree. Both normal routes must reconstruct:

713 members
10e0e23d76fa37fa6c07491da6e94c873e714f186bd4bbb246503f6c9dd19cf3

Author a separate final-owner verifier that compares every reconstructed
selected path—bytes, size, SHA-256 and encoded mode—against the exact
final owner ZIP and MANIFEST.json. Do not use the route list as both
expected and actual evidence.

Add deliberate guards for stale route identity, stale delta payload,
stale final-owner member, wrong before-image, wrong removed span, wrong
after-image, missing selected path and extra selected path.

Preserve the contract, migration map, pair identity, fixed universe,
all profiles, reader, active-map records, six F-01 controls, both 73-case
semantic rounds and the direct checkpoint byte-for-byte. Do not rerun or
rewrite the semantic suite.

Put all new repair narration, route execution records, final-owner
comparison, closeout analysis and package evidence under new paths outside
the frozen 713-member tree.

Build and reopen one successor owner. Return the unchanged direct
checkpoint, repair report, fresh external receipt and next-review task.

Do not launch Codex, access repositories or hosts, execute uploaded
programs, amend the normative pair, alter profile semantics, expand
general joins, create an implementation handoff or claim independent
acceptance.

Return only:

OWNER_R6_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW
```

After delivery, submit the exact successor to a different fresh artifact reviewer. If it passes, the next gate is the implementation decision—not automatic implementation.

**Sources:** ES_R6J_F01_FRESH_ARTIFACT_REVIEW_BLOCKED_20261025_08.zip[FRESH‑01 blocked review](sandbox:/mnt/data/ES_R6J_F01_FRESH_ARTIFACT_REVIEW_BLOCKED_20261025_08.zip), ES_R6J_F01_PREFIX_HASH_BINDING_REPAIRED_OWNER_20261025_06.zip[current repaired owner](sandbox:/mnt/data/ES_R6J_F01_PREFIX_HASH_BINDING_REPAIRED_OWNER_20261025_06.zip), and ES_R6J_F01_PREFIX_HASH_BINDING_CONNECTED_CHECKPOINT_20261025_06.zip[unchanged connected checkpoint](sandbox:/mnt/data/ES_R6J_F01_PREFIX_HASH_BINDING_CONNECTED_CHECKPOINT_20261025_06.zip).  
**Confidence:** **0.999** in the isolated reconstruction defect and exact selected-tree identity; **0.99** in the narrow evidence-only repair path.
