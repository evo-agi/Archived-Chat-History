**Do not rely on the success value in `final/HANDOFF.json`. This generation is blocked.** Codex correctly stopped and disclosed the contradiction instead of silently creating another generation. The next task is a narrow assurance and closeout correction—not another production repair or independent audit of unchanged code.

**Send this to the existing implementation/preparation Codex conversation: :chatgpt-content-reference{index="10"}[SB-4, lineage, and closeout correction prompt](sandbox:/mnt/data/ES_SB4_Closeout_Repair/ES_SB4_Lineage_and_Closeout_Repair_Prompt.md).**

The ES candidate stays frozen. The prompt also keeps the external helper’s non-test runtime code unchanged.

## What failed

Your relayed post-seal correction supersedes two claims still present in the attached report: complete channel/stdio cross-product coverage and preservation of historical matrices. The report expressly makes both claims, so it must now be read with that correction—not as an accepted engineering closeout. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

| Issue | Current meaning |
|---|---|
| Missing “channel error with stdio released” control | An explicit assurance obligation remains unmet. This alone does **not** demonstrate another production defect. |
| Four historical matrix rows changed | The external successor violated its preservation requirement. This is distinct from any change to the ES repository. |
| Successful machine handoff despite those conditions | The completion decision did not enforce all engineering obligations. Successful packaging cannot repair that omission. |

The reported **1,016 passing terminals in each local lane** remain observations of the tests that ran against that generation. They do not cover the missing case, establish historical preservation, or justify the successful endpoint. The new test bytes will require fresh affected validation. :chatgpt-content-reference{index="2"}

The latest independent endpoint remains:

```text
ES_MOUNTED_HELPER_ACTION_CUSTODY_RECEIVER_REAUDIT_INCOMPLETE
```

That historical audit result and the current owner’s blocked closeout are separate facts. Neither becomes successful because a later JSON file contains a success token.

## 1. Add the precise missing SB-4 witness

The existing channel-error case’s **unknown stdio state is not equivalent to a successfully released stdio descriptor**. The missing control must demonstrate acquisition, the one permitted close attempt, successful release, and preservation of that known release while the separate channel error propagates.

The prompt directs Codex to use the actual worker-start sequence with primitive effects substituted. It must select a genuinely reachable channel-failure point after stdio acquisition—not inject a final `released` field into a fake return value. The attached report identifies the relevant startup, custody, and absence-predicate surfaces at `worker_linux.go:122–279` and `process_custody.go:244–418`; their current source must be inspected before editing. :chatgpt-content-reference{index="3"}

The assertions must preserve both directions of independence: a channel failure cannot erase known stdio release, and released stdio cannot establish that an uncertain channel is absent. Child references must follow whether the child actually started and whether its absence was separately established.

**Keep the evidence classification honest.** The report places the worker-start controls in Linux-selected tests and gives them compilation—not execution—credit in this local task. The new case must be required and build-selected accordingly. Portable projection tests may run locally, but cannot be presented as execution of the Linux startup sequence. No remote operation is needed merely to restore this missing declared control. :chatgpt-content-reference{index="4"}

A genuine implementation failure exposed by the new test must stop the task. The prompt does not authorize weakening the test or silently expanding into another runtime-code repair.

## 2. Restore the historical matrix in the successor—not in history

The repair should derive from the latest **125-member source**, preserving the other five-block changes. Only the historical matrix is restored from its authenticated earlier source. Restarting from the 119-member predecessor would risk discarding completed repairs. The report distinguishes those two source generations and their manifests. :chatgpt-content-reference{index="5"}

Codex must obtain the original matrix’s **complete digest and bytes from the authenticated packet**, identify the four altered rows, and restore the complete file in the new authoring tree. The abbreviated hashes in the closeout are not enough to reconstruct an expected digest.

Current owner responses belong in the existing separate `FIVE_SOURCE_BLOCK_OWNER_RESPONSE.md` and coverage records. **Historical immutability preserves what was previously said; it does not prevent a later auditor from issuing different current judgments.** The preceding audit explicitly preserves that distinction. :chatgpt-content-reference{index="6"}

The rejected report, matrix, ZIP, companions, and `HANDOFF.json` remain untouched. The successor records their disqualification and exact identities; it does not rewrite them into a clean history.

## 3. Fix the completion predicate, not the packaging architecture

The important process correction is to test these two disqualifying conditions **before freeze and again against the closed payload**.

The existing handoff checks must require both engineering completeness and packaging/invocation integrity. Specifically, they must bind the historical matrix to its independent original, and the fixed SB-4 obligation to its actual source-mapped witness and applicable validation evidence.

The negative controls must include a structurally valid packet with the witness missing, a same-row-count matrix with changed content, and both conditions together. Removing the obligation from a discovered test inventory must not make the requirement disappear.

This is not a request for an automated system to infer arbitrary test meaning. Source inspection still establishes whether the assertions prove the intended case; the machine checks ensure that the reviewed witness, requirement, source generation, and evidence remain bound together.

**No new stage, receipt hierarchy, or acceptance service is needed.** The existing A–F flow can remain. Its final predicate needs the missing conditions. `HANDOFF.json` remains a decision projection, not an authority that can override contrary evidence. That follows the project’s explicit distinction between provenance and correctness. :chatgpt-content-reference{index="7"}

## Validate the changed surfaces and preserve useful evidence

The prompt authorizes fresh external-tooling unit/race validation, native and Linux vet, formatting/environment checks, and compilation of the changed Linux tests. It preserves complete evaluator and packaging invocation capture.

It does **not** automatically rebuild or rerun everything. When the supervisor’s non-test build inputs remain identical, its compile-only evidence may carry forward after authentication. The unchanged safe executable and dependency closure retain their seven historical Linux observations at their original scope. Neither validates the changed tests or establishes mounted behavior. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

Successful completion leads to a fresh cumulative independent re-audit. Privileged execution, policy establishment, mounted cases, whole-candidate ES acceptance, and Git effects remain pending. This continuation authorizes none of them.

## Inspection boundary

I read the complete attached report and verified its **33,144-byte** fingerprint:

```text
83c39004f75053fc7fcf1ba99326987be1d0e5375a7e10c3d5ebcce8c4d5127f
```

I also inspected the preceding repair prompt, including its explicit missing cross-product requirement and historical-preservation rule. The current ZIP, actual matrix, tests, invocation companions, and handoff body were not attached here. Their specific defects remain **owner-reported in your supplied correction**, rather than independently reproduced by me. The new prompt requires authenticating them before editing.

**Sources:** attached report; your relayed post-seal Codex correction; preceding repair prompt and independent audit; project provenance guidance. No repository code, tests, hosts, or privileged operations were executed here.

**Confidence:** **0.98** in withholding progression; **0.94** in this narrow continuation. Report-byte identity is verified. Successor correctness, independent closure, privileged readiness, and whole-candidate acceptance remain unestablished.
