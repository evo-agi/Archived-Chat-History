**Retain the block and repair NRC-FRESH-01/NRC-FRESH-02 before broader integration.** The review supports the original custody, Write-input, invalidation, freeze, parsing, and ingress repairs at their stated scope. The remaining gaps are two distinctions the current reader does not consistently enforce:

> **Late completion does not excuse invalid admission. Missing output does not excuse a contradictory known return.**

### ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12.zip[Download the self-contained NRC-FRESH-01/FRESH-02 repair handoff](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12.zip)

ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12_VERIFICATION.json[Completed handoff verification](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12_VERIFICATION.json) · NEXT_OWNER_TASK.md[Standalone owner task](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/NEXT_OWNER_TASK.md)

Send this **single ZIP to the existing ChatGPT carrier-repair owner conversation**, not Codex or the reviewer. It includes the current owner and fresh review unchanged, all six new specimens, the required source ancestry, and the complete repair task.

## What I verified

Both uploaded/current archives match their reported identities:

| Archive | Bytes | Members |
|---|---:|---:|
| Current repaired carrier | 118,207,134 | 2,483 |
| Fresh blocked review | 998,872 | 58 |

Every immediate payload member passes actual-byte size, SHA-256, CRC, encoded-mode, safe-path, and exact manifest checks. The unchanged normative pair independently recomputes to:

```text
8e62fd593a09bec807d954bec97b992b63a41186495e4e7f6bcdc356dcdd3838
```

My separately written data replayer reproduced **all twelve B/C documents across the six new specimens**, checking their typed before-values and exact final serialization. Their common G equals the owner’s current G, and each confirmation binds its actual B bytes. All 950 candidate facts and the selected native membership remain preserved.

I also matched twenty owner-source references from the review’s appendix and inspected the decisive admission and result-state branches. **I did not execute the uploaded reader.** Its predicted false-valid classifications remain static findings, not newly observed executions. RECEIVING_INSPECTION.md[Receiving inspection and limits](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/receiving/RECEIVING_INSPECTION.md)

## 1. Enforce admission before interpreting the result

The fresh-at-S Write specimens preserve the actual input domain: **126,259 outcome bytes**, offset zero, and the selected target and authority relationships. One reports a full Write; the other reports an error and zero written bytes. Both have:

```text
Ordinary A admission = S
Dispatch             = S + 200,000 ns
Return               = S + 400,000 ns
```

**Both must refuse because the fresh admission is invalid.** Changing the result from success to error cannot repair that prerequisite.

The repaired rule must cover ordinary A and independent-R calls under their existing applicable phase/S bounds, independently of whether their result is successful, erroneous, partial, unavailable, or outstanding. The source of any earlier phase limit must be explicit; the reader cannot derive a convenient bound from the returned outcome.

The detail field `phase=submit|return|unknown` is a **result-stage tag**, not the operational phase that determines the authority cutoff. The owner must keep those concepts separate.

### Preserve the valid late-history contrasts

The review’s separate contrast admits the Write at **S−1**, then dispatches and returns after S. Its actual dispatch and return are also shifted one nanosecond earlier than the offending specimen. **Do not reject that account merely because dispatch or completion is late.** R3 expressly admits the non-atomic interval after a valid check; the account remains nonpassing, not timely success.

The same distinction supports NR36. I located its actual retained B/C and checked that the Wait admission and dispatch precede S, the return equals S, and terminal retention follows in order. Its two saved successor results are byte-identical and classify it as valid nonpassing. Those results were not rerun here. NR36_CHECK.json[NR36 receiving check](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/receiving/NR36_CHECK.json)

**A blanket `dispatch < S` or `return < S` requirement would replace the present defect with a false refusal.** Likewise, applying fresh ordinary-authority prerequisites to inherited C would undo a previously supported repair.

## 2. Check known channels even when output is incomplete

The two result-state counterexamples contain different, already-known contradictions:

| Specimen | Known facts | Required treatment |
|---|---|---|
| Partial poll | Two input descriptors; known return **3**; errno zero; eight observed output bytes | Refuse the count contradiction without needing the missing suffix |
| Unavailable option output | Known `getsockopt` return **1**; errno zero; output absent | Refuse the wrong scalar return for the selected return-zero interface |

The partial-poll contrast has the same observed prefix but known return **1**. It remains coherent incomplete evidence—not complete readiness or qualification. SPECIMEN_AND_SOURCE_CHECKS.json[Exact specimen and replay checks](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/receiving/SPECIMEN_AND_SOURCE_CHECKS.json)

**The correction should separate five questions:** invocation validity, return-channel availability, known scalar/error constraints, observed-prefix constraints, and complete-output interpretation.

A `complete()` gate may protect a predicate that genuinely needs the missing bytes. It must not suppress a predicate already determined by the known return and invocation. The owner should inspect that separation across the existing **16 families and 20 interfaces**, not merely move two demonstrated checks.

That does not authorize a generic “successful native return must equal zero” rule. Descriptor returns, namespace-type returns, counts, output-buffer descriptors, library Write results, and Wait results have different declared meanings. Nor may incomplete output invent a descriptor or erase a responsibility independently known to exist.

## Keep the repair narrow and the controls meaningful

The handoff preserves the normative corpus/map, registry, original current G/B/C, prior counterexamples, six new specimens, and historical results unchanged. **These are enforcement gaps under the current contract; no new grammar or authority decision is selected here.**

The owner must freeze source-grounded admission and known-channel rule tables before constructing favorable outputs. Its first substantive checkpoint must include the new reader and actual results for the positive, four counterexamples, two contrasts, and NR36 before the expanded controls are added.

The existing evidence-credit distinctions also remain:

```text
284 full-reader cases
90 component cases
15 boundary cases
4 syntax-only cases
```

Those totals are the fresh reviewer’s reconciliation of the prior set, not coverage percentages or a new receiving-side execution claim. New controls must reach their intended predicates with valid bindings. A newly earlier refusal must be reported honestly and, where needed, accompanied by a separate discriminating counterpart—not relabeled as the old predicate.

Actual bounded ingress, closed parsing, owner-slot validity, pure-freeze knowledge, and coherent inherited-C/error/unknown histories must not regress. The repair does not complete general-source coverage, outside-observer authority, public P01/P02/CLOSE compositions, or any whole-R6J finding.

## Message to send

Attach the handoff ZIP to the existing ChatGPT carrier-repair owner conversation and send:

> Repair NRC-FRESH-01 and NRC-FRESH-02 under `NEXT_OWNER_TASK.md`. Read `README_FIRST.md`, `DECISION_RECORD.md`, `INPUT_IDENTITIES.json`, the receiving inspection, and the complete fresh review. Authenticate both inputs and inspect the actual six specimens, current reader/support, fixed rules, registry, pins, and relevant source.
>
> Enforce valid ordinary admission independently of result state, while preserving valid pre-S checks followed by delayed dispatch or return, NR36, and inherited C. Validate every applicable known return/error/count constraint independently of output completeness, without inventing missing output or rejecting all coherent partial/unavailable forms.
>
> Keep the normative pair, registry, current G/B/C, and historical specimens unchanged. Save and reopen the first substantive repaired checkpoint before expanding controls. Complete the finite regression, repeated results, exact scoped reconstruction, and preservation evidence, then return one actual downloadable repaired package.
>
> Do not launch Codex, access repositories or hosts, execute uploaded programs, expand the carrier, author general joins, or claim independent acceptance.

The intended endpoint is:

```text
OWNER_R6J_NATIVE_RESULT_CARRIER_NRC_FRESH01_FRESH02_REPAIRED_REVIEW_REQUIRED
```

A **different fresh ChatGPT reviewer** follows the completed repair before broader integration.

## Delivery and inspection boundary

The new handoff was closed and reopened with exact payload and input equality:

```text
Bytes:   115,356,542
Members: 17
SHA-256: 14a09429d6aae37dab4d31399458c39ceda6cc599b21a4217af207bdf31cc6c5
```

Some older indexed attachment references have expired, but both required current archives and their available ancestry are included. **No additional upload or recovery pass is needed.** Local verification does not establish client-side download success.

**Sources:** the REVIEW_REPORT.md[complete blocked review](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/review/REVIEW_REPORT.md), SELECTED_SOURCE_EXCERPTS.md[selected current contract/reader excerpts](sandbox:/mnt/data/ES_R6J_NATIVE_CARRIER_NRC_FRESH01_FRESH02_REPAIR_HANDOFF_20261020_12/receiving/SELECTED_SOURCE_EXCERPTS.md), and receiving checks linked above. I performed byte, reconstruction, source-text, and selected relationship checks—not a complete independent semantic audit, reader repair, or uploaded-program execution.

**Confidence:** **0.99** in measured integrity and exact specimen reconstruction; **0.97** in the bounded repair direction. Successor soundness and independent acceptance remain unestablished.
