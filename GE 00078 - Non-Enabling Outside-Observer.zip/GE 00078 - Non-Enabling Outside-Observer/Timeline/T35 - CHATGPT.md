**Retain `BLOCK`. Repair the existing external v2 component, keep the validated ES candidate frozen, and do not install or invoke the proposed gateway.** This is a source-correctness and readiness failure—not a provenance mismatch or rejection of the selected supervisor model. The audit makes that distinction explicitly. :chatgpt-content-reference{index="0"}

**Send this to the existing implementation/preparation Codex conversation, not the audit conversation: :chatgpt-content-reference{index="17"}[V2 successor repair and safe Linux-controls prompt](sandbox:/mnt/data/ES_Mounted_Proof_V2_Successor/ES_Mounted_Helper_V2_Successor_Repair_Prompt.md).**

The handoff covers all sixteen v2 findings in one external-only repair. It also changes the validation boundary: **safe, unprivileged Linux mechanics should be exercised before another re-audit**, rather than leaving everything Linux-specific at compile-only status.

## The two Critical fixes need precise boundaries

The audit supplies concrete source traces for both failures:

| Finding | Required repair |
|---|---|
| **V2-01: entry rejects its own runtime descriptors** | Validate the raw entry context before explicit timer/poller initialization, while retaining a separate policy for descriptors created afterward. Do not fix this by accepting arbitrary extra descriptors. |
| **V2-02: namespace custody rejects the namespace link** | Acquire the fixed, owned child’s namespace handle using namespace-specific semantics, verify its type and identity, and retain the child/PID/pidfd relationship. Do not remove no-follow protections from ordinary inputs. |

The exact reported anchors are `main.go:24–28,41–45`, `manifest_linux.go:308–337`, and `worker_linux.go:107–125`. These are auditor-derived findings against authenticated source and the pinned runtime; I have not independently executed or inspected those source files here. :chatgpt-content-reference{index="1"}

For V2-02, the distinction is particularly important: **a namespace handle is not an ordinary pathname input**. Linux documents opening `/proc/<pid>/ns/*` to obtain a descriptor referring to the namespace. That supports a narrow, object-specific acquisition rule—not a general symlink-following exception. :chatgpt-content-reference{index="2"}

Neither correction should touch ES’s production custody implementation. The defective paths belong to the external proof tooling.

## The larger gap is live-adapter validation

The 222 passing events in each retained control stream were genuine, authenticated results. But they exercised external tooling on Darwin, including abstract lifecycle faults—not the Linux entry path or 222 independent kernel scenarios. The audit verified their authenticity while rejecting the broader readiness conclusion. :chatgpt-content-reference{index="3"}

**My preceding preparation boundary was too restrictive in the wrong place.** It prohibited privileged execution appropriately, but also left safe Linux mechanics unexecuted. We should distinguish those categories rather than choose between “Mac mocks only” and “run the fixture as root.”

The new prompt therefore authorizes a dedicated, source-bound control executable on the existing governed AMD64 host. Its finite scope covers raw descriptor observation, opening an existing owned child’s namespace handle, locked-thread child ownership, request/reply correlation, owned-process observations, current-thread identity reads, and exact test-terminal parsing.

That executable must use the actual repaired shared routines. It cannot be a second implementation of the desired behavior, a relaxed root-entry mode, or a `dry-run` path that can reach the live adapter. Before transfer, Codex must inspect and record its reachable effects, initialization, child processes, and cleanup.

**No namespace is created or entered. No root, mount, loop, formatter, capability transition, ES test, live supervisor, gateway, or service operation is authorized.** Only the small safe-control executable and its bounded execution records go to the host; the privileged and ES proof binaries remain compile-only.

This is an explicit extension of the next task’s ordinary-user validation authority, not an inference that the preceding audit permitted host execution. Access failure remains a block; it does not authorize remediation or another target.

These controls still will not establish privileged-entry correctness or mounted behavior. They will give the next reviewer actual Linux evidence for the mechanics that can be tested safely without those effects.

## Repair the remaining findings as connected obligations

The successor should preserve the parts the audit found materially improved rather than restart the whole fixture. For example, it found the original permission design repaired statically, substantial closure of the loop-acquisition window, and a narrowly credible diagnostic overlay. Those conclusions retain explicit runtime and downstream qualifications. :chatgpt-content-reference{index="4"}

The remaining work falls into three connected groups.

### Lifecycle ownership must survive partial failure

The most consequential successor defect after startup is **V2-06**: a timed-out worker request leaves an uncorrelated response stream available for reuse. A late reply can then be mistaken for acknowledgement of a cleanup action. That is not fixed merely by adding a timeout or increasing one. :chatgpt-content-reference{index="5"}

The prompt requires sequence/action/subject binding and permanent rejection of an ambiguous connection. Cleanup must rely on independently retained resource ownership and observations—or report uncertainty—not consume the next convenient success response.

The same repair must keep formatter lifetime in controller state, distinguish leader reap from process-group absence, preserve the creating thread for `Pdeathsig` children, and make every acknowledgement and reap consume the owning phase deadline. These are linked ownership obligations, not separate cosmetic fixes. :chatgpt-content-reference{index="6"}

Go’s public source also documents that `Pdeathsig` is tied to the **creating thread**, corroborating the audit’s concern. The pinned installed source remains the version-specific basis for the repair. :chatgpt-content-reference{index="7"}

The revised controls must include failures **after a resource is acquired but before its adapter returns**. A mock operation represented only as “success” or “failure” can otherwise conceal precisely the interval that custody needs to cover.

### Evidence must include the final state—and preserve uncertainty

The audit identifies a fast-exit path that returns before storage inspection, incomplete accounting for private and final export records, discarded per-node observations, and cleanup success that can coexist with a termination error. :chatgpt-content-reference{index="8"}

The selected repair requires pre-spawn and post-completion checks, complete final-file accounting, retained canonical node manifests, and separate primary, cleanup, inventory, and export outcomes.

**Polling must be labeled as sampling, not hard containment.** I am not authorizing another cgroup, quota, or filesystem subsystem to close a wording gap. The successor must enforce its application-level limits, detect and reject observed oversize results, and state which ceilings are acceptance checks rather than kernel-enforced maxima. A genuinely stronger owning requirement must remain explicit instead of being silently weakened.

The test-terminal defect also needs a direct parser regression. A stream containing a selected-test `SKIP` followed by package `PASS` must remain a failed requirement. Changing a precomputed event field in a unit test does not exercise that parser. :chatgpt-content-reference{index="9"}

### The administrative entry needs a real contract, not another framework

The report is clear that `/usr/local/sbin/es-proof-approved-exec` is **unimplemented, unapproved, and incompletely specified**. A pathname and caller-populated digest do not establish an authority anchor. :chatgpt-content-reference{index="10"}

The next task defines and checks the minimum downstream interface: independently pinned approval, exact phase/target/manifest binding, acyclic receipt semantics, build-to-binary provenance, and the formatter’s actual executable/configuration dependency relationship. Dummy but shape-valid entries must not satisfy it.

It does **not** build or install a general gateway. Unknown target identities remain qualification inputs; unspecified approval semantics cannot be hidden among “runtime-only prerequisites.” The audit itself says a minimal independently trusted administrative entry may suffice. :chatgpt-content-reference{index="11"}

## Telemetry is an effective-environment defect, not just inaccurate prose

The retained commands requested `GOTELEMETRY=off`, but their own outputs reported `local`. The runner did not reject that contradiction. Consequently, the telemetry-off and fully confined-write claims are unsupported, even though the streams and compiled artifacts authenticate. The exact historical private-host delta was not inspected. :chatgpt-content-reference{index="12"}

Public Go documentation confirms the distinction: `GOTELEMETRY` and `GOTELEMETRYDIR` are **non-settable reported values**; telemetry mode is managed through `go telemetry`. Local mode writes counters without uploading them. Assigning an environment variable named `GOTELEMETRY` therefore cannot, by itself, establish the claimed effective mode. :chatgpt-content-reference{index="13"}

The new task explicitly permits isolated, task-owned configuration and telemetry storage. Codex must establish that isolation from the pinned source **before the first Go invocation**, configure off within that isolated context, and require both the effective mode and effective directory to match.

It must not change the user’s global settings, investigate or delete historical telemetry, or rewrite the old records. Nor should it treat this finding as evidence that the authenticated ES source changed or that the earlier tests did not execute.

## The continuation stays finite

The handoff combines source/document repair, ordinary-user controls, compilation, and the narrowly allowed Linux mechanics checks. It does not require another general design-only round. It allows bounded in-scope development corrections while retaining every failed generation and its source relationship.

It preserves both finding registers: historical **F-1…F-16** and successor **V2-01…V2-16**, without treating every historical item as newly broken. It also requires the next packet to distinguish the authenticated ZIP from its authoring-directory representation. The audit’s 55 mode differences and six packet-only members were disclosed representation differences—not a provenance failure. :chatgpt-content-reference{index="14"}

A successful next result should be:

```text
ES_MOUNTED_HELPER_V2_SUCCESSOR_REPAIRED_SAFE_LINUX_CONTROLS_PASSED_REAUDIT_REQUIRED
```

It is still an engineering result. The fresh independent re-audit remains mandatory, followed by any separately authorized entry/import/mounted work. Running-deployment observation, supported-local consumer/operator proof, **the unconditional whole-candidate ES audit**, and the exact-byte commit gate remain outstanding. The external-tooling review cannot substitute for that product audit. :chatgpt-content-reference{index="15"}

**The objective is to make this finite fixture correct and reviewable—not let its supporting machinery become another product.**

### Sources, inspection boundary, and confidence

I read the complete attached audit and verified its **38,747 bytes** against SHA-256 `048927a7…4229db1`. The audit ZIP, specialist files, live-adapter source, and raw control records were not attached here; their findings and authentication remain auditor-reported. The prompt directs Codex to inspect those retained artifacts before editing. No repository commands, tests, host operations, or privileged code were executed in this review.

Sources are the attached re-audit and retained implementation/validation reports, with official Go and Linux namespace documentation used only for the narrow external semantics identified above.

**Confidence:** **0.98** in retaining the block; **0.93** in this bounded continuation. Attachment provenance is verified; successor correctness, privileged-entry completeness, mounted behavior, and whole-candidate acceptance remain unestablished.
