External temporal contract — T1–T3 / C1–C2 bounded design correction
0. Task and endpoint
Return to the design/preparation parent. Correct the sole proposed normative temporal corpus and the complete migration map for the five findings in the latest fresh-parent review: T1, T2, T3, C1 and C2. Resolve the review's narrower R6 source-sequence projection ambiguity with C1. This is owner design work, not implementation or independent acceptance.
Keep the selected direction: deadline-dispatch-supervised-observed/v1; one original independently selected D; strict success cutoff S=D−8 seconds; qualified observations rather than universal physical containment; exact one-close duties; independent preselection collision reservation; versioned run semantics; import-v3 compatibility. Do not reopen these settled choices merely because the map needs repair. The current contract and map are blocked, not adopted. The historical 135-member implementation is still accepted only within its old scoped source review and old contract.
Produce one coherent successor contract/map and actual owner design checks. Then stop for a fresh separate-parent review. Do not implement migration code, an entry foundation, feed, verifier, reservation mechanism or recovery procedure.
Expected owner endpoint, only when all obligations are actually specified:
ES_MOUNTED_HELPER_TEMPORAL_T1_T3_C1_C2_CORRECTED_CONTRACT_MAP_READY_FOR_FRESH_REVIEW
A remaining contradiction, unsupported necessary input, unbounded receiver path or unclassified affected caller must instead be a specific blocked result. Packet integrity is not semantic completion.
1. Exact inputs and factual basis
Latest review — primary correction basis
Root: /Users/ds/Downloads/ES-temporal-b1-b6-independent-review-vgokn7ls/
- CONSOLIDATED_REVIEW.md: 19,189 bytes; SHA-256 15784c7617cee81a49f52ee60e16f52da4130000f08ab68fa3283f1d75084572. This attachment was independently measured in ChatGPT.
- ES_TEMPORAL_B1_B6_INDEPENDENT_REVIEW.zip: SHA-256 6e51c2a253db3b9063906e78d3a3ac2736bf30d8f193bbe10fba7b0762f5f646; 29 regular members reported. No ZIP size was supplied; measure it.
- Read the actual FINAL_IDENTITIES.json, METHOD_AND_PRESERVATION.md, both specialist reports and numbered excerpts, CROSSWALK.md, structural/authentication records and the modeled history/recheck through the archive's actual paths. Preserve the unguarded initial status-query departure and all original review qualifications.
Rejected proposed corpus/map — derive the design successor from these
Root: /Users/ds/Downloads/ES-temporal-contract-correction-1d370897/
- contract/TEMPORAL_CONTRACT.md: 36,197 bytes; ba36d3e70065aea6a04e04efbff5888b9561184f79a3be12899f5e441feab614.
- TEMPORAL_CONTRACT_MIGRATION.json: 634,434 bytes; 46df74d54f13fe7ecf0f4ae52a8acf453ea4c1bf219986ade0de564f2deed875.
- ES_TEMPORAL_CONTRACT_B1_B6_CORRECTION_REVIEW.zip: 146,885 bytes; 806c1e8493b89e5a374924a0faa2791dbaf8cc5246801073e458667ce90a9c95.
- Actual correction report, FAILED_ATTEMPTS.md, identities and author checks remain historical evidence. Read the full map, including active versus preserved historical M/S/E entries, not only the finding-response summary.
Accepted implementation — read as data, never edit or execute
Root: /Users/ds/Downloads/ES-ns-receiver-consistency-repair-snljvy01/
- final/REVIEW.zip: 4,480,523 bytes; 83192f806033f0b6129ad41611383dc1018a1dd4467ef5c733db23da8a7944b0.
- Full source manifest: 135 members, 21,007 bytes; b4a12fc77a140d35921abcccc3c9ecd5f8fad731164cc9aa63a34c52907bfdb7.
- Selected inputs: 113 members, record 22,831 bytes; e1eb9455eae0e6c2143d848cfecf69104fe8aa4c18434439ab668d781571014a.
- Protected historical matrix: 24,949 bytes, original authoring mode 0644; d9a7c54cd8410b51e276d176660e156b72fced746f77f968026601fc23f8fa2a.
- Scoped source audit: /Users/ds/Downloads/ES-ns-receiver-independent-reaudit-bk8dz3uz/CONSOLIDATED_AUDIT_REPORT.md, 36,560 bytes; e123c4eed7de041470abd24c45848b2b449da2dc3fead6732c9b67c3ee8737a0.
Owning repository: /Users/ds/Repositories/Execution Substrate/. Read AGENTS.md, current relevant PLANS.md and the exact owning .docs clauses as plain files for authority; the archive is the exact helper implementation basis. Preserve ES admission/runtime, physical root custody, staging non-mutation and retained-output invariants. The normal-shell compatibility edge and reopened reclamation seam are not redesigned. The external temporal profile is a proposed bounded-slice refinement, not ES authority.
Recovery remains untouched. Its historical supplement is /Users/ds/Downloads/ES-safe-cleanup-recovery-73eyc8be/final/ES_SAFE_CLEANUP_RECOVERY_SUPPLEMENT.zip, 1,555,085 bytes; dfa4f424205e0f0016f96c3ecc677d82dd9fbf2f459126d10c4f11f21e5f8fd9. Carry its retained unknown-state meaning; do not re-audit or execute it.
Authenticate actually consumed archives completely before private extraction: normalized unique safe relative regular members, modes, sizes, SHA-256, CRC and exact self-excluding manifest coverage. Preserve original, encoded and private-copy modes separately. Measure absent sizes/hashes; do not invent them or elevate adjacent self-consistency to an independent anchor. Reuse sound retained authentication for unchanged nonessential history instead of recopying every earlier collection.
2. Allowed work — no Git in this design correction
All writes go to one new mode-0700 root under /Users/ds/Downloads/ES-temporal-map-completion-<unique>/. Accepted source, every input root, prior proposal and review, historical evidence and all repositories remain unchanged.
This task deliberately authorizes no Git subprocess at all, including status, config, rev-parse, diff or a convenience discovery command. Do not run a preservation script that invokes Git. The repeated initial unguarded-query departure is not to be addressed by yet another promise to guard a later query. Use authenticated archives for implementation and plain-file reads for current governing guidance. Fingerprint the original files actually read at opening and closing. Carry the prior complete guarded repository captures as historical evidence; do not claim a fresh full live ref/index/worktree comparison that this task did not perform. If essential current authority cannot be read without a prohibited operation, report that precise gap.
Allowed execution is limited to new correction-owned inert-data tooling: parse JSON/text, hash and compare files, safely extract authenticated archives, compute finite arithmetic/timelines, and check the contract/map and final packet. Do not execute reviewed helpers, validators or prior authoring tools; inspect them as data. No Go, gofmt, tests, builds, compiled objects, network/SSH, target survey, signals, device/ioctl/namespace/mount/formatter, credential change, services/VMs, policy/key/approval issuance, installation, reservation or cleanup occurs. No deletion of historical scratch or old authoring roots.
The parent is the sole design writer. Two bounded read-only assistants may inspect temporal/effect ownership and receiver/authority/test coverage. Their findings are design assistance, not independent acceptance. No nested delegation or parallel artifact writers.
3. T1 — preserve the existing worker emergency authority, distinct from parent teardown
Selected correction: preserve the accepted case-local emergency KILL branches rather than redesign them to require the parent's TERM/grace sequence. Explicitly distinguish at least:
1. normal case-local stopping under its existing selected phase/signal rules;
2. existing case-local emergency KILL under the original exact candidate SignalAuthority;
3. proposed external-parent R5 teardown under independent administrative authority.
Read the actual source around worker_linux.go:1050–1087,1177–1182, candidate_pidfd_failure.go:56–65 and signal_authority.go:29–66, plus their callers/controls. These are review-reported anchors; verify them against the 135-member bytes before using them.
The local emergency branches are the actual qualified start-identity/pidfd-acquisition and process-ceiling failure paths, not a new caller-selectable emergency mode. No earlier TERM/grace is imposed solely by R5. Each concrete signal still needs original exact subject/custody, unrevoked action scope, the existing sticky cancellation/expiry rules and a fresh adjacent check at its actual dispatch. Its original applicable case cutoff and the ordinary-work S limit must remain explicit; parent D-bound authority cannot be borrowed to extend it. A fallback is a new dispatch/check. An error that prevents adequate exact targeting does not authorize a guess from a historical numeric PID.
Document precisely whether each original error affects signal revocation versus primary-result failure; do not let a blanket 'any error' rule silently forbid a source-selected emergency stop, and do not let cleanup reacquire revoked authority. Retain partial identities, primary/signal/observation errors and unresolved descendants. Signal success or leader wait never proves group absence. Failure paths remain nonpassing.
Amend R3–R5 where necessary, E35.01/E36.01/E38.03, linked M/S rows and R6 event actor/authority attribution. Every signal row names its real actor and original authority. Keep the parent reserve rules, conditional opportunity and no-post-D signal policy intact; do not impose them on a different actor by vocabulary alone.
Required inert traces: t0+100s start followed by qualified pidfd-failure emergency KILL; inadequate identity refusal; process ceiling; local fallback with expiry/revocation between syscalls; local authority expired while parent authority would still be valid; parent TERM/grace/KILL as a separate path; preserved partial/group uncertainty. These are future model/control specifications, not actual signals or observed process behavior.
4. T2/T3 — complete the actual failure path and acquired-owner inventory
Use one source-derived inventory to repair both omissions without duplicate normative authorities. Enumerate every directly owned acquisition, transfer, release and effect in the cited paths, including their success, error, defer and early-return branches.
T2 mandatory source: terminal_protocol.go:721–803. E48 must separately include failure-directory Chmod/Sync, parent Sync and every retained/private file, private-root, directory, parent and base owner release. E49's distinct fallback does not cover E48. Keep ordinary successful work, still-authorized nonpassing failure retention (F), and the inherited single-close duty (C) separate. Reuse actual map vocabulary and define it; do not assume every operation after failure acquires D-bound permission.
For an F operation after S, specify its exact standing authority, active bound/cancellation treatment and already-nonpassing status. At D a new Write/Chmod/Sync is barred. A subsequent qualifying one-close may discharge an owner but cannot repair the missed effect or upgrade success. No post-D durable report is guaranteed; returned/in-memory uncertainty may be all that exists.
T3 mandatory source: formatter_linux.go:27–32,43–68,75–100; scratch_removal.go:63–85,185–193; and image/loop release at live_linux.go:949–995. Extend the finite R4 owner inventory for actual formatter executable/dependency-closure files and scratch parent/root/inventory handles. Fix E09.04: live_linux.go:492–517 is open/truncate/sync, not image Close. Map the actual closeLoop/releaseLoopDescriptors release owner and single attempt separately from loop-detach or other effects. Amend E10/E20/M25 and all affected caller rows.
Each owner row needs: acquisition site/result, who currently owns it, transfer/duplication versus borrowed references, invalidation site, one primitive release site, error/uncertainty propagation, deferred/error branches, and linked proposed assertions. Determine the actual implementation behind every Close label; no whole compound callback is exempt. Preserve no numeric retry, no extra signal/write/sync/reacquisition, no absent/never-acquired success invented after partial acquisition.
Perform a bounded completeness walk of these affected call paths and their direct release consumers, not a general syscall/instrumentation project. A correct hash of the wrong range is still a wrong semantic anchor.
Required inert traces: advance through S/D between each failure-file and directory effect; complete file Sync with barred parent Sync; acquire closure file then refuse the next Open; partial scratch enumeration/removal; every omitted owner on error; invalidation followed by close error and later numeric reuse; actual image release versus image creation. Preserve all actual partial outcomes and label prospective execution evidence honestly.
5. C1 — selected combined receiver resource policy
These are new successor design numbers selected by the engineering lead, not historical receiver limits or permission to change the existing source now:
Domain	Maximum admitted raw bytes
Existing receipt-carrier plus held producer graph	16,777,216 (16 MiB), unchanged
One parent-observation body	16,777,216 (16 MiB), existing proposed per-body cap
Raw confirmation input	65,536 (64 KiB)
Combined producer graph + observation body + confirmation	33,554,432 (32 MiB), inclusive


All limits apply together. Both 16-MiB subdomains cannot be filled to their maxima while also admitting a nonempty confirmation. State that intentional consequence; do not turn the sum into 32 MiB plus another allowance. This explicitly enlarges the new profile's combined raw-evidence domain relative to the old graph-only boundary, without enlarging the old graph domain itself. It is not live risk adoption.
Keep the existing graph-member ceiling and stricter schema-specific limits. Bound the additional body and confirmation as two explicit objects, not new unbounded directories/sidecars. Every request-varying raw fact consumed by the public receiver/verifier is classified in this table; qualification references cannot trigger unmetered observation fetches. Independently pre-established trusted configuration/corpus has its own finite initialization boundary and must not be a caller-selected escape from accounting.
Map the public confirmationBytes path at terminal_receiver.go:211: length admission must precede receiver-owned copy, string conversion, parse and verifier invocation. A caller may already own the input slice; do not claim that this limit prevents its pre-call allocation. Reject oversized declared inputs cheaply, then enforce actual reads and overflow-safe running totals on held bodies. Declaration is not measured length. Enforce cap-plus-finite-detection-byte behavior explicitly; extra bytes are rejection probes, not admissible payload or a retry budget. Preserve acquired-object stability/identity/mode/hash checks and exact-byte cached reuse without reopening a second unmetered path.
Raw bytes are not an RSS guarantee. The corrected normative table/map must also specify finite JSON nesting, token/string/array cardinality, decoded live-object ownership/copying and semantic traversal/index bounds, derived from actual existing graph schemas plus R6. Give concrete values or source-derived finite formulas that a later implementation can enforce, including malformed JSON and early refusal. Keep materialized raw copies and decoded collections bounded; no uncontrolled recursion, expansion, per-reference fetch or repeated full decode. Do not invent a kernel-enforced memory/CPU guarantee or add a cgroup/quota/worker service. If a necessary bound cannot yet be specified, report it as a current design gap rather than claiming raw-byte admission closes C1.
Keep retrospective receiver processing limits separate from original episode D/S. Later review must not require D to become future again.
Amend R6 and M13/M14/M27 with all accounting and the public copy/admission sites. Required prospective controls: individually valid inputs exceeding the combined cap; exact combined boundary and +1; confirmation at cap and +1 with no verifier/copy for the latter; forged lengths; early parse/structural exhaustion; repeated cached references; malformed deeply nested/long-token inputs; missing/tampered observation body; and a complete modest positive. Structural arithmetic is performed now as inert data; receiver execution is later.
C1 precision — one selected source-sequence projection
Choose the simpler closed projection: every record of each independently qualified finite episode source stream within a claimed covered sequence interval must appear exactly once as its typed outside event. No optional relevance filter or episode/producer-selected omission is admitted by this version. The source stream's independently pinned qualification must define its scope and event semantics; ambient host telemetry is not silently substituted. A source that cannot supply that finite complete stream is an unestablished prerequisite, not permission to fill gaps or poll instead.
Specify a non-ambiguous source-instance/epoch binding to the approved episode/target/boot/observer and qualification. Add only the bounded field needed if existing keys cannot distinguish actual stream instances. Resets/restarts cannot be hidden by restarting global numbering. For each source instance, reconcile actual source_seq membership with coverage first/last and overlaps using checked arithmetic; a shared boundary record is represented once, not double-counted. All outside event source sequences must be covered, and every covered source sequence must have its typed event. Producer-origin rows remain separate and cannot fill outside-source gaps. Global body seq must not substitute for source completeness.
Retain the existing 8,192 event and 256 coverage limits unless source inspection reveals an explicit conflict requiring a reported decision. Excess events or unsupported source records refuse; no truncation, downsampling, invented gapless numbering or unbounded source_ref facts. Define positive two-interval/multiple-source reconciliation and negatives for a missing record with renumbered global seq/zero loss, duplicate/conflicting source_seq, wrong instance, reset, overlap double count, extra out-of-coverage event and producer-for-outside substitution. Preserve the stated continuous-coverage qualification without claiming polling proves every instant or selecting feed technology.
6. C2 — map the real authority ingress and affected assurance
The exact production constructor and parser must be in the current map, not only the type definition or receiver:
- authority_linux.go:38–68,98–114: literal EntryRequest creation, approval/entry acquisition and strict ingress. Reconcile proposed run-v4, exact temporal pair and original D through every consumer before effects; keep import-v3 byte-for-byte typed encoding and phase separation.
- loop_control_result_test.go:68,89,143,199,222,231: old ExternalHardDeadlineObserved assumptions.
- terminal_bundle_integrity_test.go:34: old cutoff.
- Direct public receiver callers in empty_log_test.go, namespace_custody_test.go, namespace_receiver_test.go, plus their directly shared fixtures.
Verify actual current sites and scan the selected source for every relevant constructor/parser/old field/direct receiver caller. The review's reported counts identify omissions; they are not the stopping condition for that bounded caller survey. Amend M02/M21/M26/M29 and M18/M19/M27 and linked templates/spec/examples. Mark each old-family control as intentionally retained historical behavior, successor to migrate, or irrelevant with source rationale. No blind search-and-replace of stronger fields and no test weakening to make counts remain fixed.
Supply an authority flow map from independent approval to phase-specific encoding/entry parser, immutable owner, outcome/receipt, body/confirmation and public receiver. Pair run-v4 exact-value positives with mixed family, missing/stale corpus, caller override, old-field alias and import-v3 typed-byte-equality scenarios. Do not run Go now; derive exact expected future controls from actual definitions and retained bytes. Typed JSON digests and raw file digests remain distinct. Old evidence/verifier retain old meaning; no upgrade or automatic compatibility default.
Keep producer ledger order distinct from the body's canonical eleven-normal/eight-diagnostic order. Reconcile by exact case ID and record digest; do not reorder the producer ledger to make arrays look equal. Every required case still reaches its actual future adjudicator. Empty-log allowance, NS acquisition/receiver consistency, scratch custody and received-byte immutability remain unchanged obligations.
7. Completion method and deliverables
Derive the corrections forward from actual named source paths. Keep all current map IDs stable where possible; revise erroneous active rows in the new file with explicit old/new or superseded links. Original artifacts remain immutable history. Do not preserve a wrong active row merely to keep its old JSON hash, append a contradictory second active rule, or confuse an immutable historical snapshot with an immutable current design. Counts of rows/steps/anchors are observations, not acceptance targets.
Every corrected row links the finding, verified actual source/range/body identity, real actor/owner and authority class, new sole-corpus rule, prior rule disposition, partial-result semantics, future test/caller, and evidence strength. Add only causally required rows. The map/report must not add unhashed normative temporal rules outside contract/TEMPORAL_CONTRACT.md.
Before the final design freeze, perform these owner-level checks using only inert records/source inspection:
- Individual T1/T2/T3/C1/C2 plus source-projection responses and full affected R1–R8/version crosswalk.
- Positive early full episode, explicit qualifications, all success facts strictly before S and meaningful later retrospective review.
- Worker emergency stop versus normal case stop versus parent teardown; missing identity, expiry/revocation, fallback and conditional grace opportunity.
- Each failure-closeout effect and each newly included close owner at S/D boundaries, with no success after late work and no post-D write/sync disguised as release.
- Exact corpus representation/digest and map agreement; every old/wrong source anchor corrected and independently re-read semantically.
- Combined receiver arithmetic, finite decode/work policy, source membership and public confirmation admission.
- Run-v4/import-v3 constructor/parser/test completeness and producer-order-to-body-case binding.
- Full current source-input preservation, exact historical matrix and no implementation change.
Keep the review's schematic 99,449-byte model at its actual strength: an inert example with simplified producer records, not a public receiver pass or qualified feed. New design examples likewise do not execute the receiver, original tests, signals, mounts or a host. Preserve failed correction-owned scripts/attempts; do not elevate structural checks to independent design acceptance.
Write:
1. contract/TEMPORAL_CONTRACT.md: the corrected sole complete proposed corpus, UTF-8/no BOM/no CR/LF/exactly one final LF; no self digest.
2. Complete TEMPORAL_CONTRACT_MIGRATION.json: new exact corpus digest plus active rows, historical relationships, caller/effect/owner/test/resource crosswalks.
3. TEMPORAL_T1_T3_C1_C2_CORRECTION_REPORT.md: decisions and source-derived minimum corrections, explicit C1 budget increase, projection rule, complete unexecuted scenario status, provenance and limitations.
4. Compact exact design/map deltas and design-check/source inventory records, actual assistant reports if used, input comparisons and failure history.
5. One safe regular-file review ZIP, self-excluding manifest, actual completed raw-byte reopen verification and external final size/hash identities. Reuse the modest planning-packet approach; no new A–F/receipt infrastructure, nested source archives, binaries, caches, full ES tree or secret material.
A second raw-byte parse of the closed corpus/map must agree with the designated root copies and their declared rules. Packaging success is necessary for a usable handoff, not a substitute for the five design corrections. Final report must say which checks actually ran and which are prospective, identify read-only source limits, and explicitly state that no Git subprocess or fresh full repository-state comparison occurred.
After delivery, request a fresh separate-parent design review. Only a later accepted contract/map and separately authorized coupled external migration may change implementation. Preserve old static closure, original 1,151/176 local records and qualifications, safe b1df...7008 seven/38 observations with incomplete closeout, and unknown original scratch/survivor/disconnected-observer state. No new as-now recovery authority, risk consent, policy/reservation establishment, feed/clock/trust/storage/formatter qualification, mounted proof, deployment or supported-local proof, whole-candidate ES audit, or exact-byte Git progression is granted.



















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Drag to reorder pinned navigation items


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
