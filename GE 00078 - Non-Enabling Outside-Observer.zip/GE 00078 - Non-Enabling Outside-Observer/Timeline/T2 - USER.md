Here are the requested files for 5A and 5B.
