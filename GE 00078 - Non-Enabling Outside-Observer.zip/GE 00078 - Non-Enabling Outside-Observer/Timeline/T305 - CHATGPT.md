## The block stands; the next correction is architectural, not implementation

The review passed every surface except requirements **6** and **13**. The remaining gap is precise: `es/outsideobserver` has a name and writer boundary, but the artifact does not yet freeze the process topology, P-authority path, authenticated transport, evidence custody, teardown, restart behavior, or failure ownership needed to implement it safely.

I selected one concrete target architecture rather than leaving Stage C another open design seam:

| Surface | Selected target |
|---|---|
| Process topology | `es/outsideobserver` is Linux task/container **PID 1** and the direct parent and Wait/reap owner of the `es/runtimehelper` supervisor |
| Observed finite parent | The runtimehelper supervisor—not an inferred process from Nomad status or a numeric PID |
| P authority | `OutsideObservationPermitV1` inside signed `RunEntryV4`, issued only by the existing RunEntry issuer |
| Admission role | Carries the signed entry unchanged; does not issue, interpret, or upgrade P |
| Receiver | Private host-side `es/r6jreceiver`; no public API |
| Transport | Per-run private Unix socket with mutual TLS using SPIFFE X.509 SVIDs |
| Credential custody | Each process obtains its own SVID; private keys remain in memory and never enter staged files, logs, or results |
| Evidence transfer | Receiver owns a durable record only after validation, journal append, `fsync`, and ACK |
| Failure behavior | No observer spool or session resumption in v1; transport or observer failure terminates/reaps the child and makes the source incomplete |
| Restart | New run, new P permit, new epoch, endpoint, and session nonce |
| Staging | A–D remain disabled/test-only; Stage E is the sole production-enablement gate |

This preserves the accepted fact-writer split. Runtimehelper still owns only the helper/workload children it actually launches. Outsideobserver cannot mint authority. Receiver cannot author raw facts. Nomad retains task-lifecycle truth.

### Owner-correction handoff

ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_REPAIR_HANDOFF_20261025_02.zip[Download the outside-observer topology repair handoff](sandbox:/mnt/data/ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_REPAIR_HANDOFF_20261025_02.zip)

```text
Bytes:             4,945,773
Members:           35
SHA-256:           6a9ac7c0a022568b800d29b7a08953a72ea0e93c55a943c1828d4123837d822a
Verification:      PASS
```

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_REPAIR_HANDOFF_20261025_02_VERIFICATION.json)

The package is self-contained and embeds:

- the exact current ES-native ownership owner;
- the complete blocked fresh review;
- the read-only repository-owner survey;
- the concrete topology, authority, transport, custody, failure, and stage-gating decisions;
- selected current contract and ownership artifacts;
- the complete next-owner task.

## Where to send it

Send the single handoff ZIP to a **fresh ChatGPT artifact-design owner conversation**.

Do not send it to Codex. Codex should return only after this architecture correction has passed a different fresh artifact review.

Use this message:

```text
Continue as the artifact-only design owner for the blocked ES-native R6J
implementation-ownership correction.

Read README_FIRST.md, INPUT_IDENTITIES.json, DECISION_RECORD.md,
analysis/OUTSIDE_OBSERVER_TOPOLOGY.json, analysis/STAGE_GATING.json,
receiving/RECEIVING_INSPECTION.md, the complete blocked review, and
NEXT_OWNER_TASK.md before authoring.

Authenticate the embedded current owner, fresh blocked review, and
repository-owner survey.

Preserve every review requirement that already passed. Correct only the
outside-parent topology and Stage C/E adoption seam.

Freeze the selected target architecture:

- Linux R6J task entrypoint is es/outsideobserver;
- outsideobserver is task/container PID 1 and the direct parent and sole
  Wait/reap owner of the runtimehelper supervisor;
- runtimehelper retains only its own helper/workload child facts;
- Nomad retains task-lifecycle truth;
- OutsideObservationPermitV1 is carried inside signed RunEntryV4 and issued
  only by the existing RunEntry issuer;
- admission transports the signed entry unchanged and issues no P authority;
- host-side es/r6jreceiver receives evidence over a per-run private Unix
  socket using SPIFFE mutual TLS;
- observer and receiver obtain their own SVIDs; private keys remain in
  process memory;
- the handshake binds run, complete entry digest, permit nonce, source
  instance, epoch, session nonce, and both SPIFFE identities;
- evidence custody transfers only after receiver validation, durable append,
  fsync, and ACK;
- v1 has no observer durable spool, reconnect, or session resume;
- missing/invalid P or transport authentication prevents child launch;
- transport loss after launch causes process-group termination, Wait/reap,
  source-incomplete refusal, and run failure;
- restart requires a new run, permit, epoch, endpoint, and session;
- Stages A through D remain disabled and test-only; Stage E alone may enable
  production wiring after repository adoption and live qualification.

Add a named R9.23 migration:

R6J-ES-NATIVE-OUTSIDE-P/v1

Preserve the accepted R9.21 reference corpus and the reviewed R9.22
ownership split except for the topology-specific correction. Rebuild the
target contract, map, framed pair, modeled profile bindings, package
binding, and all 429 active records.

Keep all runtime execution, authority issuance, credential qualification,
repository adoption, and independent-acceptance flags false.

Add deliberate artifact controls for wrong parentage, wrong namespace or
start identity, unauthorized fact writers, missing/wrong/replayed P,
SPIFFE identity mismatch, unauthenticated endpoints, sequence or hash-chain
failures, ACK-before-fsync, fabricated success after transport loss,
permit/epoch reuse, premature Stage B/C/D production wiring, public API
exposure, and private-schema policy widening.

Do not access repositories or hosts, launch Codex, execute uploaded
programs, author runtime source, adopt the proposal, or claim live
qualification.

Return actual downloadable artifacts only under:

OWNER_R6J_ES_NATIVE_OUTSIDE_OBSERVER_TOPOLOGY_CORRECTED_READY_FOR_FRESH_REVIEW
```

## Sequence after the correction

```text
corrected topology owner
→ different fresh artifact architecture review
→ repository-adoption decision
→ clean/stable baseline selection
→ Stage A docs/contracts/tests implementation
```

Even a satisfactory correction will not authorize all stages A–E at once. The first repository effect should remain Stage A: `PLANS.md`, governing `.docs/` contracts, target schemas, and contract tests on an explicitly authenticated baseline.

**Sources:** `R6J_ES_NATIVE_IMPLEMENTATION_OWNERSHIP_ARTIFACT_REVIEW_BLOCKED_20261025_01.zip`; `OWNER_R6J_ES_NATIVE_IMPLEMENTATION_OWNERSHIP_CORRECTED_20261025.zip`; `ES_R6_GENERAL_NATIVE_SOURCE_JOIN_OWNER_SURVEY_20261025.zip`; the generated decision and owner task inside the linked handoff.

**Confidence:** 0.99 in the blocking diagnosis and input identities; 0.96 in the selected topology and trust path as the appropriate narrow correction. Repository adoption and live feasibility remain subject to fresh review and later Stage E qualification.
