ES mounted-helper fixture — independent pre-execution safety and oracle audit
Objective, target and effect boundary
Use a fresh, read-only Codex conversation, not the conversation that authored this fixture. Independently review the prepared mounted-helper test driver, privileged setup/cleanup recipes, their inputs and acceptance logic. Decide whether these exact artifacts are suitable for a separately authorized bounded root execution on the named AMD64 host.
This is a narrow pre-execution audit of NEW external proof tooling. It is not the later whole-candidate final audit, a new CUST-2 design round, permission to run the fixture, or a request to repeat successful validation. Preserve the locally/natively validated 358-file source / 83-path candidate.
Repository for read-only comparison:
/Users/ds/Repositories/Execution Substrate/
Prepared evidence root:
/Users/ds/Downloads/ES-mounted-helper-proof-preparation-nFVwkJ
Retained validation root:
/Users/ds/Downloads/ES-cust2-nsfs-assurance-validation-kgthnJ
Authorized now: read source, docs, manifests, diffs, recipes and safe retained records; perform non-mutating local provenance checks and static analysis; write audit-owned reports/data outside repositories in a new private directory. Safe archive inspection/extraction into that directory is permitted. Inspect helper source before using any helper, and run only independently reviewed non-mutating evidence-analysis/provenance logic. Keep bytecode/cache output outside all input roots.
Not authorized: repository or input-artifact edits; executing or sourcing either fixture script, including help/dry-run paths; running any candidate/test binary, repository script, Go test, compile, benchmark or fixture; SSH, Docker, Lima, service/API/workload contact; sudo or other root acquisition, sudo-policy probing, mounts/unmounts, namespace operations, loop association/detach, filesystem format, chattr, setpriv execution; installing dependencies or downloading executables/distributions; dependency or security-policy changes; access/ownership changes; staging, commit, fetch, push, branch/ref/worktree operations. Describing a future command is not authorization to run it.
Use one foreground parent. Two non-overlapping read-only specialist perspectives may assist after provenance authentication: (1) privileged lifecycle/filesystem safety; (2) proof-driver/oracle adequacy. The parent owns complete source binding and synthesis. No nested delegation or writers. Close agents at completion and preserve disagreements. If delegation is unavailable, the parent may complete the same defined coverage and must report that fact; do not claim an independent second perspective that did not occur.
1. Authenticate this target, not every historical generation
Expected preparation identities (as reported, to verify):
Artifact relative to preparation root	Expected identity
review/ES_MOUNTED_HELPER_PROOF_PREPARATION_REVIEW.zip	SHA-256 2ab1d48f478712953b415204f397a984eacbc5ff7cb97961486ec5cf532e939c; reported 51 total members
MANIFEST.tsv	SHA-256 237ead1ac6c8ba931a7326c24aa90681847108274a5c2d3f6781e635758beca4; reported 439 registered files
ES_MOUNTED_HELPER_PROOF_PREPARATION_REPORT.md	Conversation attachment is 13,490 bytes, SHA-256 a3798f9d33303d65cc7578df98b35f9f08c1598ad3f982c3f51924596190cac8; also require its binding in the actual retained manifest
driver/es_mounted_helper_proof_v1_linux_test.go	32,094 bytes; SHA-256 b60be787470d191895efc9b6d0a9a25ed2e8d0a0206c6cfae6a403e5ec512a6b
recipes/fixture_launcher_v1.sh	20,072 bytes; SHA-256 f4e319654d2bf509f90c05c2d2c710014590c3016182c37ba65c3f5b10faaa1d
recipes/fixture_cleanup_v1.sh	5,071 bytes; SHA-256 763bd9ddc34c8e6aa29448259e71168ca5f64f7550348b5e37d437d6d5cb1fe3
build/source-union-manifest.jsonl	359 rows / 77,126 bytes; SHA-256 9e7a3b4c028093d304a8cab41223ff449f9375b5aa701c77b7cf3a6cc6f8b854
Retained binary, locate through build/records/binary-identity.json	23,552,153 bytes; SHA-256 e8b798ecfbf79089281728811a9cf905d5d1d68bd2acc3b163b118596f5cb813; intentionally excluded from the compact ZIP


Useful initial commands, strictly local and read-only:
ROOT='/Users/ds/Downloads/ES-mounted-helper-proof-preparation-nFVwkJ'
/usr/bin/shasum -a 256   "$ROOT/review/ES_MOUNTED_HELPER_PROOF_PREPARATION_REVIEW.zip"   "$ROOT/MANIFEST.tsv"   "$ROOT/ES_MOUNTED_HELPER_PROOF_PREPARATION_REPORT.md"   "$ROOT/driver/es_mounted_helper_proof_v1_linux_test.go"   "$ROOT/recipes/fixture_launcher_v1.sh"   "$ROOT/recipes/fixture_cleanup_v1.sh"
Digest checks are entry checks, not proof of correctness. Independently inspect the manifest format and self-exclusion rule, archive paths/member types and duplicates, exact registered membership, file modes/sizes/digests and report binding. Do not execute archived authentication scripts automatically. Classify any unregistered Python bytecode or OS metadata separately; do not delete it or silently absorb it. Verify the reported local/remote-support observations from retained records only.
Expected live repository: trunk_dev / origin/trunk_dev, HEAD b92bd9884106154d25342e1573dcc4c312311436, tree cdd4e44bac15c1952d70997143040644361f0bb1, six worktrees, zero staged/conflicted paths, no active Git operation, one ahead / zero behind without fetching.
Expected frozen identities:
- source: 358 rows / 67,617 bytes / e69e4d6a76b26ae097536536f95244b0ac9b05bfed46088af9cf0e0452781c3e;
- candidate: 83 rows / 10,037 bytes / 7fbec6629d7004b0c8da3b8069d7c1f95706f3b18302069e6a204f90f74807c2;
- archive: 7,485,440 bytes / 12a8b8a626911d51dedf1b138b88deb314aff00d0de6ec063c96ac53d6146202;
- archive-member manifest: 358 rows / 79,414 bytes / 3e0195237c1b89fcb15242b886e17735c47d54b6710dd7ca8dafc1f6f63d4e5e;
- required inventory: 327 rows / 141,680 bytes / 8b3ed6e32ba809bda751632292773c9adc28096691ad9307be32affa288515eb;
- tracked diff: 2,407,274 bytes / 2739dbb5994df13e6d9fa5487a63ff0ff1300359f65a5c21779b5f2580af2db1;
- complete integration diff: 2,746,480 bytes / 38de7ecbcbb52252104710ddb6075a205a9c8a571590d96ed93247ba5a5501e0.
Use the exact retained inspected provenance serialization. Independently reproduce opening and closing source/candidate identities; compare status, index, refs and six-worktree records. Disable optional Git locks/fsmonitor and external diff/textconv; inspect relevant configuration/attributes before commands. Do not silently convert non-Git modes to executable-bit equivalence. The earlier source manifest is not the new 359-member proof union: verify all 358 original members unchanged and ONLY the additional package-local Linux driver.
Read the compile command/environment/output and source-union equality records and bind the retained ELF to them. Hash/read binary metadata without executing it. No rebuild is required. Missing binary custody or source-union binding is an evidence gap, not grounds to accept a same-named binary. Do not reopen all 692 predecessor records or rerun old suites merely to review the new fixture; traverse a predecessor only to resolve an actual binding/contract ambiguity.
2. Re-ground current invariants and review scope
Read current AGENTS.md, relevant PLANS.md sections, .docs/system_overview/{configuration,capability_probing}.md and the owning .docs/execution_lifecycle/{contracts,design,implementation,es_execution_admission_model}.md clauses. Follow actual references where needed. Read:
- all six es/admission/execution_roots{,_linux,_darwin}{,_test}.go files;
- the real staging, service/startup, Submit and retained-result call paths reached by this driver;
- relevant ordinary and nsfs tests, test initialization/TestMain hooks, and fixture/helper dependencies;
- the complete external driver, launcher, cleanup and any embedded Python/shell or transitive external helper bodies;
- report/source-call-map.md, report/future-fixture-recipe.md, analysis/case-effect-permission-matrix.json, report/remaining-gate-order.md, report/inspection-and-authorship-inventory.md and the retained build/host-support records.
Use current path:line anchors, not old report line numbers. Treat the report's call map as a claim to verify. Preserve staging non-mutation/current root-set rules, nsfs metadata-versus-coordinate eligibility, fixed errors/no provider fallback, and control-plane-normal-shell/v1 as a temporary compatibility edge. External proof resources/ledgers are evidence and operation-local custody, not new ES/Coordinator/Git authority.
The prior full/race/native passes are historical exact-source validation. This audit neither reruns nor independently closes every prior CUST-1/M3/whole-candidate finding. Inspect adjacent code only as necessary to judge the mounted proof and its safety. A new substantive production defect encountered on that path must still be reported.
3. Privileged recipe review — exact mechanism, not reassuring labels
Trace from the first proposed privileged instruction through every success/failure exit. The reported envelope is one governed AMD64 host, one fresh 64 MiB ext4 image, one exact loop association, 23 task mounts, a new verified-private mount namespace, setup/cleanup as root and candidate execution as UID:GID 1000:1000 without supplementary groups/capabilities and with no_new_privs.
The target is host_to_remote_linux_m75q; expected machine-ID SHA-256 is a3c311774c7e5dfadb05c93280f2f69902954bec92fc1af77a332d28befbbca6. This task must not contact it. Reported tool/kernel availability is a dated support observation, not current root authorization or successful capability execution.
Assess at least the following, citing actual script/helper lines and classifying concrete defects separately from future preconditions:
A. Privileged entry and trusted input custody
- Exact first root command, executable/interpreter identity, argv/environment and operation token constraints. No broad privileged shell, arbitrary executable/command/source/mount target, eval, executable configuration or user-controlled cleanup path disguised as a parameter.
- Bound remote intake: root must consume the reviewed scripts, driver binary and immutable control data; a digest checked before a later writable-path lookup is not by itself byte custody. Examine no-follow parent/file checks, writable ancestors, hard links, replacement windows, root-owned private copy or equivalent held-object binding, and who can replace inputs after verification.
- All embedded helpers and subprocess command resolution are included. Environment/loader/shell-startup variables and inherited FDs must not select unreviewed behavior. A general sudoers or access-policy change is outside the proposed effect budget.
- Report any missing exact entry mechanism rather than inventing one and immediately approving it.
B. Namespace isolation and task resource scope
- Identify parent/child process and mount namespace before effects; prove private propagation is set and verified only in the new namespace before fixture mounts. Failure must stop before the first mount, not continue after an unchecked command.
- Recognize that fixture file writes and loop associations still require their own custody/cleanup; do not label a mount namespace a VM or whole-host filesystem sandbox.
- Reconcile every one of the 23 mounts with a fixed case and source/target identity. No live staging/results/security trees, repositories, service sockets, fstab or existing filesystem-image modification.
- Exclusive task root under /var/tmp/es-mounted-helper-proof-v1/run-<token> and evidence under /var/lib/es-mounted-helper-proof-v1/evidence/run-<token>: verify existing-parent treatment, ancestor permissions, no-follow creation, allowed modes, budgets and exact residual parent-directory treatment. Do not silently chmod/chown or delete pre-existing parent trees.
- Formatting must target only the exact new bounded regular image/its authenticated association. Check loop selection and reuse behavior, offset/size, major/minor plus backing-file identity, and protection against touching any existing image/device.
- Prove fixture casefold setup before claiming casefold behavior, and preserve a genuine case-sensitive control. No host directory flag change, policy/sysctl workaround, fallback filesystem or reduced case list.
C. Privilege drop and runtime containment
- Trace UID/GID transition, supplementary groups, effective/permitted/inheritable/ambient/bounding capabilities, securebits where relevant, and no_new_privs. Verify how the child will report effective state rather than merely echo requested options.
- The Go test binary and its package initialization/TestMain code must not execute as root before a later in-test drop. Hash/metadata inspection by root is not binary execution.
- Audit test selectors, flags, working directory, time/resource limits, inherited environment and file descriptors. No accidental whole-package suite, live provider/workload action, caller HOME/credential access, privileged control FD, or broad process cleanup.
- Distinguish writable synthetic roots/output from root-owned scripts, image, mount/cleanup ledger and authoritative custody data. A child result log may be evidence but must not choose root cleanup actions.
- Check that permissions permit the intended unprivileged test to traverse fixture parents and perform contract-valid positive effects, without weakening protection of root control data.
- Do not demand a new account, container or LSM policy by default. Expose actual trust assumptions and any concrete unjustified access; absence of a total hostile-code sandbox is not itself an invented product requirement.
D. Cleanup after every partial state
- Construct a compact failure-state table: before/after image creation, loop association, each mount acquisition/recording, casefold setup, privilege drop, test start/end, evidence acquisition and cleanup. Include signal/timeout/transport loss and the namespace-owner exit.
- Address resources acquired immediately before ledger-write failure. Ownership must not depend solely on successful final logging. A failed run may retain bounded resources when removal is unprovable; it must not misreport clean closeout.
- Cleanup must bind the SAME namespace and owned process identities, not use a recycled PID or run its mountpoint list in the parent host namespace. No global pkill, unmount-all, detach-all, lazy/forced unmount or recursive deletion through a live/uncertain mount.
- Reap/close only owned actors and references; unmount exact task mounts in reverse dependency order; verify the exact loop association before detach and actual association absence afterward; only then remove authenticated scratch. A successful detach command alone must not stand for completed destruction.
- Preserve candidate failure if cleanup succeeds; preserve cleanup uncertainty if tests pass. Neither exit trap nor final report writer may overwrite the primary failure with exit zero.
- Evidence custody/return must be defined before its source is removed. Root control ledger cannot be populated from untrusted test JSON. Shared parent directories and retained evidence must have an explicit end state; preserve old runs and unrelated state.
No actual cleanup or capability control may be executed during this audit. Use source inspection and inert data/case reasoning only; do not execute the fixture with mocked PATH utilities as a supposed safe shortcut.
4. Proof validity — validate the 11 oracles and effect claims
Preserve and independently map the existing fixed cases:
1. ordinary disjoint roots — accept;
2. disjoint sibling bind presentations — accept;
3. same-object bind presentations — reject;
4. staging-source ancestor — reject;
5. results-source ancestor — reject;
6. descendant mount under staging — reject;
7. descendant mount under results — reject;
8. genuine case-sensitive Area/area siblings — accept;
9. ext4 casefold Area/area alias — reject;
10. casefold staging-source ancestor — reject;
11. casefold results-source ancestor — reject.
For each, verify setup relationships independently of the production classifier (object identity/ancestry, mount IDs and actual casefold lookup behavior), real production entry points, expected outcome, refusal site, protected state and result record. Check case interference: one case's mounts must not make another fail for the wrong reason. Kernel metadata must be real; no copied classifier, fabricated mountinfo/statx, syscall stub or guard-bypass seam.
Positive tests must reach intended provisioning/owner/reobservation and qualify valid roots under the claimed runtime credentials. Negative tests must reach the actual root/effect refusal rather than pass because setup, permissions, dependencies, provider configuration, or metadata acquisition failed earlier. Verify which common early identity checks versus Linux source-coordinate checks each case truly exercises; do not demand a coordinate-refusal string where a legitimate earlier invariant is the intended owner.
The report claims actual reconciliation/retention/read/public result paths, zero provider calls, no result run/temp/final/normalization artifacts and unchanged bounded snapshots. Inspect all those call paths and independent assertions. State snapshots prove state equality, not automatically absence of attempted or transient effects: require the source/control-flow trace and deliberately discriminating fixture states to justify stronger no-effect claims, or qualify those claims. Do not invent syscall tracing that did not occur.
Take protected baselines AFTER fixture construction and BEFORE candidate action. Fixture setup/cleanup mutation must not be confused with a candidate mutation. Before/after identity/mode/ownership/entry/content evidence must cover both relevant presentations and bounded backing sentinels, with independent expected values. Do not let the program's own return text establish the fixture relation or expected pass.
Verify runner/adjudicator completeness: exact test selection; every expected case and required child executed; setup/environment error, test fail, required skip/missing case, malformed/truncated output and partial cleanup cannot become pass. Preserve both process exit and test outcomes. No parent-pass proxy, grep-only PASS check, arbitrary early-error success, uncontrolled retry or suppressed stderr.
Scope casefold applicability to the selected contract, not lab convenience. Unsupported capability is a future execution block, not permission to remove casefold rows. Compile success is not proof any case ran.
5. Keep deployment work and source-freeze changes outside this audit
Review report/remaining-gate-order.md only enough to confirm honest scope and evidence dependencies. The reported supported-local wrapper has no pre-start configuration witness or observation hook. Treat that as a separate defined follow-on; do not author it, run the wrapper, start services or amend repo docs here.
Check the assertion that the supported-local subject can meet the running-deployment clause against CURRENT owning lines. Do not replace an explicitly named Remote Alpha subject, or turn an internal control_plane helper into the separate CP/Temporal product. A new repository hook would create new candidate bytes and needs an explicit validation-impact plan; an external proof overlay is additional instrumentation, not the old source archive. Report that dependency without selecting a new implementation.
Leave full-candidate CUST-1/CUST-2/M3 acceptance, actual mounted runtime observations, running-deployment binding, supported-local consumer proof and exact-byte stage/commit gates open. Do not make this audit depend on a successful future mounted run: distinguish reviewable recipe safety from capabilities/results that legitimately can only be observed under a later bounded execution.
6. Deliver one scoped decision, not another generic design report
Create one new private audit directory outside repositories. Return:
- concise audit report with exact artifacts and current source reviewed;
- findings by severity/type, artifact path:line, concrete failure/effect trace, correction required, and whether blocker is a proven defect, missing static evidence or future capability/authorization precondition;
- complete 11-case coverage map and root/child permission and partial-failure cleanup assessment;
- exact-byte authorization-candidate envelope IF the scripts are suitable: host identity, code/input/binary hashes, fixed argv schema, root/child identities, namespaces, image/loop/mount resources, allowed persistence, evidence/cleanup boundaries and remaining runtime preconditions. This envelope is NOT execution authorization;
- unchanged opening/closing provenance and exact commands performed; no assertion of checking remote tools that were not contacted;
- a compact audit ZIP with self-excluding manifest, and separately surfaced existing preparation ZIP path/digest. Include actual reviewed launcher/cleanup/driver and the narrow current source excerpts used for material findings, with provenance. Do not include the ELF, full caches/source unions, raw secrets, full environments, or repeated historical ZIP chains.
Use one scoped disposition:
- ES_MOUNTED_HELPER_PREEXECUTION_REVIEW_SATISFIED_AUTHORIZATION_PENDING: no unresolved static safety or oracle blocker; all remaining preconditions are finite, explicit and enforceable BEFORE their dependent effects. No runtime pass or root authorization is inferred.
- ES_MOUNTED_HELPER_PREEXECUTION_REVIEW_BLOCKED: concrete safety, oracle, binding, or entry/cleanup-definition defect/gap. List ALL found blockers in this bounded surface; do not repair them.
- ES_MOUNTED_HELPER_PREEXECUTION_REVIEW_PROVENANCE_MISMATCH: exact target authentication fails; stop judgment for the mismatched target.
Do not return generic ACCEPT, FINAL_AUDIT_READY, COMMIT_READY or a mounted-proof pass. Do not grant yourself root authority or propose altering sudoers/AppArmor/groups/sysctls to satisfy a precondition. Runtime root access may remain unavailable even if the static review is sound.
Separate provenance, validation and implementation confidence. State where inspection stopped. Retained input caches/Trash items are not cleanup targets. Missing essential raw scripts or custody records cannot be replaced by the author's report, but optional absent records should not trigger an unrelated historical reconstruction program.
External technical references for the bounded review
These are public tool/kernel semantics, NOT observations of the user's host. Relevant installed behavior and current repo contracts still govern. Read locally retained documentation/source when available; external primary-source verification is permitted but not required for already-bound facts.
- Linux shared-subtree semantics: https://docs.kernel.org/filesystems/sharedsubtree.html — namespace cloning may preserve shared propagation; private state must be established in the intended child.
- util-linux v2.39.3 setpriv: https://raw.githubusercontent.com/util-linux/util-linux/v2.39.3/sys-utils/setpriv.1.adoc — identity, groups, capability sets, environment and no_new_privs are distinct controls.
- util-linux v2.39.3 losetup: https://raw.githubusercontent.com/util-linux/util-linux/v2.39.3/sys-utils/losetup.8.adoc — loop setup/reuse and lazy detach semantics require precise identity and closeout interpretation.
- Linux no_new_privs: https://docs.kernel.org/userspace-api/no_new_privs.html — prevents privilege gains across exec; not a replacement for initial privilege dropping or complete confinement.
No example root command from these references is authorized to execute.


















    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
  








  




Use the context menu to move a pinned navigation item up or down


    To pick up a draggable item, press the space bar.
    While dragging, use the arrow keys to move the item.
    Press space again to drop the item in its new position, or press escape to cancel.
