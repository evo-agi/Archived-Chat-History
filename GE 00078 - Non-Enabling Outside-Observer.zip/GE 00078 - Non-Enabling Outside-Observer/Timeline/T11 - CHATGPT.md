**Do not move this design into implementation yet.** Most of the repair direction is sound, but two concrete gaps remain: one in the physical-separation proof, and one in the proposed acceptance tests. They should be corrected before we create another candidate requiring full validation.

**Send this to the same implementation/repair Codex conversation: :chatgpt-content-reference{index="19"}[Focused design correction and feasibility prompt](sandbox:/mnt/data/ES_Repair_Design_Correction_and_Feasibility_Prompt.md).**

This is a bounded amendment—not another full audit or a restart of the repair program.

## What is sound and should remain

The design addresses the important ownership and ordering requirements: qualify staging and results together, bind effects to the checked descriptors, cover retained-result reads that reconcile metadata, preserve retained-first lookup when staging is absent, and avoid a durable or process-global root registry. Those are the right constraints for CUST-2. :chatgpt-content-reference{index="0"}

The compressed-radix direction for CUST-1 is also appropriate: iterative traversal, byte-keyed branching, path-boundary-aware ancestry, and structural work accounting at production operation sites. The M3 proposal correctly constrains both scanners through a fail-closed accepted grammar rather than adding a check for the audit’s particular injected command. Neither direction needs to be discarded. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The Low corrections and runner-umask correction should remain in the combined repair. The design still explicitly distinguishes planned work from implemented or accepted work; no audit finding is closed by this report. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

## 1. CUST-2 still contains a lexical step inside its physical proof

The proposed Linux algorithm derives a backing-source coordinate from:

```text
mountRecord.root + relative(configuredPath, mountRecord.mountpoint)
```

It then accepts same-device roots when those coordinates are component-disjoint. **The held mount ID identifies the applicable mount record; it does not establish that the configured spelling copied into that calculation is canonical under the backing filesystem’s lookup rules.** The preceding component-identity check does not cover every ancestry relationship concealed by a separately presented subtree. :chatgpt-content-reference{index="5"}

This matters on Linux, not only Darwin. Linux’s ext4 documentation explicitly supports case-insensitive lookup on selected directories. “Linux” therefore cannot serve as an implicit guarantee of case-sensitive path semantics. :chatgpt-content-reference{index="6"}

### A modeled counterexample

Consider this static topology on a case-insensitive backing directory:

| Item | Presentation |
|---|---|
| Actual backing tree | `/pool/Area/child/out` |
| First bind | `/pool` presented at `/s-view` |
| Configured staging | `/s-view/area`, resolving to the actual `Area` directory |
| Second bind | `/pool/Area/child` presented at `/r-view` |
| Configured results | `/r-view/out` |

Applying the written algorithm produces:

```text
staging source coordinate: /pool/area
results source coordinate: /pool/Area/child/out
```

A case-sensitive component-prefix comparison considers those strings disjoint, although results is physically beneath staging.

The other stated checks do not necessarily rescue this example. The terminal objects are different. The visible results traversal goes through `/r-view` directly to `out`, so it does not encounter staging’s `Area` object. Neither configured root visibly contains the other, and neither has a mount strictly below it. This is a counterexample derived from the proposed rules—not a claimed native reproduction. :chatgpt-content-reference{index="7"}

It does not require a privileged concurrent attacker, namespace changes, or hidden remote storage. Consequently, the design’s trusted-operator and stable-namespace qualifications do not resolve it. :chatgpt-content-reference{index="8"}

**Required correction:** establish descriptor-bound canonical presentation or identity semantics for the comparison, or specify an enforceable fail-closed rule for cases that cannot be proved. Lowercasing the strings, assuming a universal filesystem normalization rule, or merely repeating “ambiguity fails closed” is insufficient.

The same issue needs to be considered in descendant-mount detection: a differently spelled configured root must not make a real descendant mount disappear from the comparison. The correction prompt requires both nesting directions, distinguishes existing-object proof from missing-path intent, and preserves legitimate sibling-bind compatibility where it can actually be established.

## 2. CUST-1’s largest proposed archive tests may never reach the repaired validator

The design proposes end-to-end PAX/GNU tests containing a near-16 MiB resolved name with more than eight million short segments, plus tests using roughly 4 MiB shared-prefix names. Those are acceptance requirements, not merely illustrative stress inputs. :chatgpt-content-reference{index="9"}

Published Go source, however, defines:

```go
maxSpecialFileSize = 1 << 20
```

for PAX headers and GNU long-name/link metadata. Its reader rejects oversized special files with `ErrFieldTooLong`. That is a **1 MiB dependency-level metadata limit**, distinct from ES’s whole-stream budget. :chatgpt-content-reference{index="10"}

In the supplied ES source, `tar.NewReader` and `tarReader.Next()` precede the namespace checks (`es/admission/mounts.go:299–330`). A dependency-parser rejection therefore cannot demonstrate that the proposed radix ledger processed the giant name efficiently. The inspected source excerpts are retained in the :chatgpt-content-reference{index="20"}[review notes](sandbox:/mnt/data/ES_Repair_Design_Review_Source_Notes.md).

**Important qualification:** I could verify the published Go source, but not authenticate the exact public `go1.26.5` tagged source through the web tool. The installed, authenticated Go 1.26.5 source and executable must decide the pinned dependency’s actual behavior. I have not substituted current website source for that verification.

The next prompt therefore authorizes one small **standard-library-only feasibility probe outside every repository**, using the existing installed toolchain. It separates archive construction, parser acceptance, and the name actually returned to the caller.

The revised acceptance plan must distinguish:

- **Reachable archive tests:** dependency-accepted PAX/GNU shapes that demonstrably exercise the production radix probe and commit.
- **Dependency-refusal tests:** oversized metadata rejected before ES namespace validation.
- **Direct-ledger stress tests, where useful:** larger strings supplied directly, explicitly not represented as reachable PAX/GNU archive inputs.

This does **not** justify abandoning the algorithmic repair, shrinking ES’s stream budgets, adding an ES entry/name cap, or modifying Go’s parser. The original quadratic work remains a real finding even when the dependency constrains the largest reachable individual name. :chatgpt-content-reference{index="11"}

## Two related clarifications before implementation

### Make topology-check frequency explicit

The design specifies one bounded operation-local mount-topology snapshot, but later says topology is refreshed immediately before effects. It also places checks before a broad set of result-side mutations. The amendment must distinguish which checks reuse held state and which acquire fresh metadata. :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"}

This is not an instruction to remove safety checks. It is a requirement to state their actual freshness and cost. We should not accidentally introduce a full mount-table scan for every streaming tar/gzip write while repairing an availability defect elsewhere.

The parser specification also needs to accommodate valid namespace views. In particular, Linux mountinfo can legitimately omit a mount’s parent when that parent is outside the process root; “consistent parent graph” must not silently require every parent record to be present. :chatgpt-content-reference{index="14"}

### Identify the deployment being observed

The design cites `scripts/internal/control_plane.sh` to preserve a particular container bind-mount shape, then requires observation inside the actual Remote Alpha ES namespace. **A repository launcher shape does not establish the identity or topology of a currently running deployment.** :chatgpt-content-reference{index="15"} :chatgpt-content-reference{index="16"}

The next task must distinguish the Remote Alpha service namespace, the supported-local/container launcher, the ordinary native-test environments, and the future mounted-alias fixture. It must not invent a running container or a pre-provisioned fixture.

Where a deployment-compatibility observation could invalidate the selected design, it belongs before broad implementation. Actual rejection tests against the repaired helper necessarily come afterward. Those are different gates; neither should become a circular prerequisite for the other.

## The next handoff and its stopping point

The :chatgpt-content-reference{index="21"}[correction prompt](sandbox:/mnt/data/ES_Repair_Design_Correction_and_Feasibility_Prompt.md) requires one concise successor amendment and a complete corrected acceptance matrix. It preserves the original artifacts and all unaffected design sections.

It authorizes read-only source/evidence inspection and the small external tar feasibility probe. It does **not** authorize repository edits or tests, host contact, VM/container operations, mounts, installs, a final audit, staging, or commits.

The matrix was not attached here, but Codex has its exact retained path and digest. The prompt requires reading and authenticating that actual file; an additional upload round is unnecessary merely to continue.

After this correction, the next decision is either implementation against a genuinely settled design, or one precisely identified topology-compatibility observation. It is **not** another general environment-restoration cycle. The later new-byte full-suite, race, native Linux, mounted-topology, and independent-audit obligations remain pending. :chatgpt-content-reference{index="17"}

### Sources, inspection boundary, and confidence

I verified the attached design’s **47,288 bytes** against its reported SHA-256. I also matched ten relevant members of the supplied historical source archive to their manifest entries; their excerpts and inspection limits are in the :chatgpt-content-reference{index="22"}[source-review notes](sandbox:/mnt/data/ES_Repair_Design_Review_Source_Notes.md). The current matrix, live repository, installed Go source, and native topology were not independently inspected here. No repository code, tests, hosts, or VMs were executed.

**Confidence:** **0.96** in withholding implementation until these corrections are resolved. **Provenance:** high for the attached design and inspected archive members; live preservation remains Codex-reported. **Design:** high confidence in the identified proof/test gaps, but no corrected physical-topology algorithm is accepted yet. **Validation and implementation acceptance:** still outstanding.
