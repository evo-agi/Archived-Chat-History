**End the draft-recovery attempt here. No substantive R6 work was exported, and there is no reader failure to diagnose from the delivered files. The remaining work must be newly authored from the verified nineteen-case seed—not reconstructed from progress messages.**

I verified the availability ZIP and the surviving seed directly. I also prepared **one self-contained restart package**, so no further primary-input upload is needed.

### ES_R6_VERIFIED_SEED_AND_CANDIDATE_PILOT_RESTART_20261014_01.zip[Download the verified seed and one-candidate restart ZIP](sandbox:/mnt/data/ES_R6_VERIFIED_SEED_AND_CANDIDATE_PILOT_RESTART_20261014_01.zip)

Use it in a **fresh ChatGPT design-owner conversation**, not Codex and not an independent-review conversation.

## What the availability record establishes

The uploaded archive matches the reported identity:

```text
Bytes:   20,157
Members: 6
SHA-256: 20afd7111744fc4c3f644571b50151e10c50f451ae17334a80784f6220e155cb
```

All five payload members and the self-excluding manifest pass actual-byte checks. Its contents are precisely the status/index, path-availability observation, and copied export instructions. **There is no corpus, map, constructor, reader, model, semantic result, or semantic failure stream from the attempted R6 work.**

The recorded `ENOENT` is an observation about the named path in that session. It does not establish that drafts never existed, were deleted, or cannot exist elsewhere. I authenticated the observation’s bytes; I did not reproduce another conversation’s filesystem state. The INSPECTION.md[inspection](sandbox:/mnt/data/ES_R6_Availability_And_Candidate_Restart_20261014_01/INSPECTION.md) preserves that limit.

The detached export-verification receipt named in the status was not included. That does not prevent verification of the actual ZIP, which I performed independently.

**There is no reason to ask that conversation to export the same absent directory again.** Nor should the availability checkpoint be counted as another completed design slice.

## The real baseline is still intact

I reverified the complete nineteen-case archive: **35,076,877 bytes, 931 members**, with its established SHA-256 `cf9244b2…12b5372d`. All 930 payload rows match their actual bytes, modes, sizes, hashes, and CRCs. Its **323,851-byte corpus and 2,160,296-byte map** remain correctly bound.

The seed itself describes its 631 source records as a selected closeout construction, **not complete case/process/scratch coverage**. Its broader receiver-acceptance and runtime claims remain false. No new uncertainty has been converted into success.

Some older attachment references have expired, but the required seed and relevant instructions are directly readable here and included in the restart ZIP. **No re-upload of A/B/C/D or another recovery bundle is needed for the selected next task.**

## Change the work unit: one candidate lifecycle first

The previous “bounded” R6 task still combined source membership, coverage, all process lifetimes, request/result conservation, resource ownership, context changes, chronology, nineteen-case preservation, and whole-map integration. It did not produce deliverable draft bytes.

**The next pass should complete one actual candidate’s observation and custody chain before attempting that entire set again.**

I selected the first normal subject already present in the seed:

```text
ordinary-disjoint-roots-accept
```

Its existing serialized case result remains protected input. The new work is the explicit lifecycle account around it:

> Spawn intent and dispatch → worker Start result → PID/group and qualified start identity → pidfd acquisition → wait and test result → group-absence observation → consuming pidfd release → controller disposition.

This selection is grounded in the accepted source. `lifecycle.go:822–877` treats a dispatched spawn as potentially live until absence is established. `worker_linux.go:1032–1118` separates Start, identity, and pidfd acquisition; `:1186–1281` separates completion, group observation, and pidfd release. These relationships are available in the SELECTED_CASE_LIFECYCLE_SOURCE.md[verified source excerpts](sandbox:/mnt/data/ES_R6_Availability_And_Candidate_Restart_20261014_01/SELECTED_CASE_LIFECYCLE_SOURCE.md).

The task requires actual serialized records and a separately written inert reader—not another table of desired properties. It includes one coherent successful candidate construction, one truthful release-uncertainty history, and ten focused corruption families covering missing dispatch, mismatched returns, source omission, time/context gaps, unacquired or double-released handles, leader-only absence, and lost acknowledgements.

**A coherent failure account may pass consistency checking while remaining ineligible for successful proof.** The reader must preserve that distinction.

The other eighteen case results remain unchanged at their existing scope. The worker’s pre-existing context is an explicit premise, not newly proved setup. This pilot does not establish complete episode coverage, qualified observation, or full R6 acceptance.

## Save substantive bytes before expanding

The new brief requires the first actual construction, fixed expectations, reader source, and result—even a failing result—to be saved and reopened before expanding the mutation set.

It also avoids forcing unnecessary normative edits. If the existing grammar supports the pilot, it may remain byte-identical. If a required fact cannot be represented, the owner must identify the exact gap and make the minimum coupled proposal. **A larger corpus is not progress by itself.**

The immediate endpoint is deliberately narrower:

```text
OWNER_BOUNDED_R6_ONE_CANDIDATE_CONSERVATION_PILOT_COMPLETE
```

It is not `OWNER_BOUNDED_R6_SOURCE_CONSERVATION_SLICE_COMPLETE`. Full source conservation, whole-map reconciliation, A-to-final reconstruction, and independent review remain afterward.

## Message to send

Attach the **single restart ZIP** to a fresh ChatGPT owner conversation and send:

> Continue as the artifact-only AR-01–AR-03 design owner. Read `README_FIRST.md`, `NEXT_OWNER_TASK.md`, and `INSPECTION.md`. The missing R6 draft was not recovered; use the included verified nineteen-case seed.
>
> Complete the selected one-candidate request/custody conservation pilot, with independently fixed expectations, actual serialized records, a separate newly authored inert reader, a coherent normal history, truthful failure evidence, and the specified refusal controls. Save and verify the first substantive construction before expanding the checks.
>
> Do not repeat draft recovery, attempt the full R6 scope in this pass, launch Codex, access repositories or hosts, execute uploaded code, or claim independent acceptance. Return actual downloadable work with its precise completion boundary.

The restart ZIP was closed and reopened successfully: **35,181,578 bytes, 15 members**, SHA-256 `e82bb535293910015f120cb530d8c75377afc44cd66efb482add95d93b96e5a1`. It contains unchanged inputs and new instructions/inspection—not a recovered draft or newly completed semantic slice.

**Sources and limits:** actual availability and seed archives; selected authenticated B source; the prior R6 task. No uploaded reader, constructor, Go program, repository command, host, or cleanup operation ran here.

**Confidence:** **0.99** in the measured inputs and absence of draft material in the delivered archive; **0.94** in narrowing the next authoring unit. New R6 correctness and independent acceptance remain unestablished.
