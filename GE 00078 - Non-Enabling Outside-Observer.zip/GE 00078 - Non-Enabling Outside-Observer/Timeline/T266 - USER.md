I found the files. Should I send these instead? Or should we proceed with your alternative?
