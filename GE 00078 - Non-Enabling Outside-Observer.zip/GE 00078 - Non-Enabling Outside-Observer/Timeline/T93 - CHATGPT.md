**Proceed to a fresh, separate-parent affected design review. Keep implementation blocked until that review accepts the exact corpus and map.** The report supports completion of the owner correction, not independent closure of T1–T3. The accepted helper remains unchanged under its old contract. :chatgpt-content-reference{index="0"}

**Send this to a new Codex review conversation—not the design/correction conversation: :chatgpt-content-reference{index="13"}[T1–T3 authority and owner-closure independent-review prompt](sandbox:/mnt/data/ES_Temporal_Authority_Owner_Review/ES_Temporal_T1_T3_Authority_Owner_Independent_Review_Prompt.md).**

Paste this directly into the Codex message before the attachment:

> Read the entire attached task before selecting any command. Do not run Git or a repository bootstrap. Work outside all checkouts under `/Users/ds/Downloads/`; repository guidance may be read only as plain files.

The next review’s most important new question is **whether the per-effect F status exchange is a complete, bounded dependency—not merely whether the old map contradictions disappeared.**

## What this correction appears to resolve

The reported changes address the preceding review at the right level: canonical effects and acquired owners, rather than additional prose explaining away conflicting rows.

| Area | Reported correction | Independent question |
|---|---|---|
| **T1 — local signals** | Caller/stage rows now reference canonical local L primitives; parent T is no longer an alternative. | Do every reachable caller, fallback, family gate, and scenario agree with those primitives? |
| **T2 — failure publication** | Run-v4 approval carries a mandatory narrow F term into a separate immutable `FailureAuthority`; seven E48 effects consume it. | Is the complete issuance, current-status acquisition, custody, and per-effect consumption path coherent? |
| **T3 — release duties** | Each successful acquisition creates one owner-instance duty; repeated caller references become non-effect aliases. | Do actual acquisitions, transfers, duplication, borrowing, and alternative release branches support that accounting? |

For T1, the report now names the previously missing candidate and formatter call sites and says the enclosing family language derives from the canonical L rows. For T3, it distinguishes socketpair’s two original owners, wrapper transfer, possible `FileConn` duplication, and borrowed `ExtraFiles`. Those are substantive corrections to inspect—not evidence that every source path has already received independent closure. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The eight rejected map mutations are useful evidence that the owner’s fixed checks detect their selected corruptions. **They do not replace source-derived completeness checks.** A checker can reject a duplicated declared owner while still missing an undeclared acquisition. The report appropriately limits its claims to finite relationships and selected source interpretation. :chatgpt-content-reference{index="3"}

## F’s fresh status exchange needs explicit scrutiny

The preceding handoff selected a preissued F term and required a defined source of current validity. The owner has now chosen a specific realization: **one fresh authenticated challenge/response before each failure-publication effect**, with an increasing status sequence, one-effect nonce, qualified times, a 4,096-byte sample limit, and no reuse for the next effect. :chatgpt-content-reference{index="4"}

That makes the design more concrete, but also adds a live dependency to a failure path. **I am not treating that realization as independently accepted or as authorization to build a status service.** The review must answer three connected questions.

### Who authorizes obtaining the status?

The seven F operations are filesystem-publication effects. A challenge, response read, wait, or transport acquisition is not automatically one of those seven.

The reviewer must identify the proposed authority and owner for that exchange, including after S or ordinary caller cancellation. It must check its deadline, blocking behavior, resource limits, acquired-handle duties, and compatibility with the existing entry and storage boundaries.

Most importantly, **obtaining the sample must not require the very sample being obtained**. A separately defined bounded observation path could be coherent; an unexplained recursive admission requirement would not be.

This is a review question, not a proved defect in the unseen corpus. The report identifies the protected status source but does not provide enough detail here to settle its full effect boundary. :chatgpt-content-reference{index="5"}

### Does freshness bind one specific effect without renewing authority?

The review must establish that a favorable response is current-status evidence for an already issued grant—not a new grant, a refreshed deadline, or permission for another operation.

It should trace the actual effect and target binding, nonce consumption, sequence handling, copied-holder behavior, and partial-dispatch outcome. A response obtained before D cannot authorize a newly admitted operation at or after D merely because its signature remains valid.

The selected check-to-dispatch interval remains non-atomic. The new protocol must not reintroduce a claim of instantaneous revocation under the word “fresh.”

Nor should it put the user in a per-effect approval loop. The proposed custodian status source must operate within independently established standing terms; its implementation and qualification remain pending. :chatgpt-content-reference{index="6"}

### Is the whole exchange bounded, including failure?

Seven favorable samples are not necessarily the same as seven attempted exchanges. The review must check malformed or partial replies, rejected challenges, lost responses, replay, timeout, and any retry path—not only the successful sequence.

A lost or slow status source may correctly prevent failure-file publication. That is acceptable only with honest retained uncertainty and the appropriate one-close duties; it cannot trigger fallback to ordinary authority or a promise that durable failure evidence will always exist.

The filesystem effect ceiling stays narrow: exclusive file Open and Write, file Chmod/Sync, directory Chmod/Sync, and parent Sync. F does not create a missing parent or directory, complete ordinary cleanup, or turn post-D release into successful publication. :chatgpt-content-reference{index="7"}

## Recheck the affected receiver boundary—not all settled receiver design

The report adds a bounded representation for F history: up to three run-authority objects, seven status samples, and one failure file, for a maximum of 38 G roles when the original 27 success roles are also present. The existing domain and combined byte limits remain unchanged. :chatgpt-content-reference{index="8"}

The reviewer must distinguish **successful-proof acceptance** from **bounded interpretation of an already failed history**.

An early failure should not have to fabricate a complete successful graph merely to preserve its valid failure evidence. Conversely, allowing F-history members cannot relax successful membership or let current-status samples rescue failed operations, missing cleanup, or late delivery.

The status and authority records also must fit the claimed input domains. Challenge provenance, approval/request/entry bodies, and episode-specific validity evidence cannot disappear into “trusted configuration” to escape accounting. Seven 4 KiB response limits alone do not bound every input to the new path.

The earlier C1, projection, C2, and R7 judgments should carry forward where unaffected. **Their prior local satisfaction does not automatically cover these newly added F dependencies.** That is why the prompt includes an affected receiver/authority perspective alongside the temporal and owner-conservation perspective. The report itself identifies F accounting as the change to those carried judgments. :chatgpt-content-reference{index="9"}

## The owner correction must remain one coherent map

For T1 and T3, the independent reviewer should work forward from the accepted source and then compare the map—not discover the expected source set solely from the map’s rows.

The decisive distinctions remain:

**One primitive with several caller references does not gain several permissions.** Local caller aliases must preserve the actual local actor, original grant, target custody, and phase bound.

**One acquisition with several release paths does not create several close duties.** Normal close and force-close may be alternative consumers of one live owner slot. A genuine duplicate descriptor is a separate acquisition; a wrapper or borrowed handle is not automatically another owner.

**A repeated acquisition pattern creates separate runtime instances.** Canonicalizing its source row must not collapse a recursive or iterative sequence into one global close allowance. A failed close consumes the owner slot and leaves uncertainty; a later reused number cannot revive it. These distinctions are now reported explicitly and are appropriate targets for independent confirmation. :chatgpt-content-reference{index="10"}

No larger map framework is needed. The review should verify the existing aliases, branch relationships, fixed obligations, and full active gates, with concrete counterexamples for any remaining block.

## Preservation and the next gate

The owner reports no Git command in this correction. It also discloses that its selected-file opening snapshot was consolidated after some preliminary reads. The 161 matching closing fingerprints therefore support preservation over that recorded scope—not a literal first-byte snapshot of every input or a full repository-state comparison. That narrower claim should carry into the review. :chatgpt-content-reference{index="11"}

The fresh review must retain the no-Git boundary and record actual consumed-file comparisons. It should not repeat repository queries merely to make the preservation description broader.

A satisfactory endpoint may be:

```text
ES_MOUNTED_HELPER_TEMPORAL_T1_T3_AUTHORITY_OWNER_DESIGN_REVIEW_SATISFIED_IMPLEMENTATION_AND_LIVE_ADOPTION_PENDING
```

That would support separately authorizing the coupled external migration. It would not establish the F issuer or status channel, approve target risk, enforce a reservation, or authorize mounted execution.

Remote scratch, survivor, and possible disconnected-observer state remain unknown. The accepted helper’s old scoped closure, partial operational evidence, and failed closeout remain unchanged. The whole-candidate ES audit and exact-byte publication gates remain separate. :chatgpt-content-reference{index="12"}

## Inspection boundary and confidence

I read the complete attached closure report and the preceding correction prompt. The report matches the supplied identity exactly:

```text
13,302 bytes
SHA-256 66aa229f9a9f1ab2a42004b4e8dacf37f6eed5215a5716a94ef8d752c2e16734
```

The current **58,319-byte corpus, 1,188,465-byte map, review ZIP, and mutation records were not inspected here**. Their identities and results remain owner-reported; the new prompt supplies their retained paths and anchors for independent examination. No repository commands, reviewed code, tests, hosts, or cleanup were executed here.

**Sources:** attached closure report, preceding independent T1–T3 findings, and the prior correction handoff. **Confidence: 0.96 in proceeding to fresh affected review.** Report-byte identity is verified; complete design coherence, status-exchange sufficiency, implementation readiness, and privileged readiness remain unestablished.
