Here is Codex's response:

# `OWNER_R6_ONE_CANDIDATE_F001_F002_CONTRACT_RECONCILED_READY_FOR_FRESH_REVIEW`

The narrow artifact-only correction is complete. This is an **owner-ready result for fresh review**, not independent acceptance.

## Input authentication

Authentication completed before authoring:

| Input                      | Bytes     | SHA-256                                                            |
| -------------------------- | --------- | ------------------------------------------------------------------ |
| Integrated delivery ZIP    | 2,373,307 | `57ce9206a31428cd72df05cee6f992366f7c5fd42a57a735878512fe31e78e39` |
| Blocking fresh-review ZIP  | 62,574    | `5f9ea997b5f4096a37a1caf5eda3fb4a10ba15c4eec679d45dac261ddc31d861` |
| Nested prior owner package | 2,991,020 | `bbc01cd6e8c755a1546033ed7c742cf2c94769fe066647e66a646d2afc87765e` |

For each archive, membership, byte counts, SHA-256 identities, ZIP modes, CRC, path safety, regular-member posture, and absence of encryption were checked. No uploaded program was executed.

## Corrected paired corpus and map

| Artifact                           | Bytes     | SHA-256                                                            |
| ---------------------------------- | --------- | ------------------------------------------------------------------ |
| `TEMPORAL_CONTRACT.md`             | 344,067   | `7bcd100f257139603bcb3236646399537d797fddf1d62a922597e4dccbe6f74e` |
| `TEMPORAL_CONTRACT_MIGRATION.json` | 2,170,306 | `ea1197df7a5d2dd92713dc1544bf3b6c0e063907f77f45f9806cff70fffd768e` |
| Paired corpus/map binding          | —         | `16e29ba0913b6dfdd82f890a1397c787e858f628d7734884775e68fda67564ab` |

### F-001 reconciliation

The general R6 rule now states two coherent cases:

1. **Default identity projection:** a source family without a later exact specialization retains native kind and native payload.
2. **Exact named closed projection:** a later normative section may define a total, deterministic, one-to-one typed transformation for one named source family and candidate scope, while preserving source instance, native sequence, native time, and covered membership.

R9.19 is expressly the sole specialization in this tranche, for `ordinary-disjoint-roots-accept`. It requires every selected native record to project exactly once and every candidate-flow event to originate from exactly one selected native record. Its unchanged 25-row mapping reconstructs the native kind and all candidate-relevant payload facts.

The only historical label migration remains:
```
controller.receive -> adapter.response-received
```

It is historical-to-normative only. `controller.receive` remains invalid as a normative transition and is not a compatibility alias. No other candidate lifetime inherits the specialization.

### F-002 reconciliation

The general defaults remain:

- printable ASCII, at most 256 decoded bytes for detail/reference strings;
- at most 1,538 raw JSON-token bytes.

The only field-local exceptions are now explicit:

- `candidate-flow/test.capture.stdout_base64`: canonical base64 ASCII, at most 65,536 raw value bytes, exempt from both the ASCII/256 and raw-token/1,538 defaults;
- `error4096`: valid UTF-8, at most 4,096 decoded bytes, exempt only from ASCII/256 and still limited to 1,538 raw token bytes;
- each `error-array256` element: the same UTF-8 and token intersection, with at most 256 elements.

No exception transfers to another field, event kind, source family, or candidate. Body, event-count, source-count, graph, confirmation, and aggregate raw-evidence caps are unchanged.

## Constructive, refusal, and preservation results

The substantive checkpoint was saved and reopened before the expanded control suite. It directly demonstrates:

- native sequence `7045`, `controller.receive`, payload `{operation: poll, response_ref: repair-normal-record-44}`;
- normative `candidate-flow/adapter.response-received` with the same source instance, sequence, time, operation, and response reference;
- the actual canonical `stdout_base64` value of 5,632 raw ASCII bytes.

The completed evidence records:

- unchanged, closed 25-transition union;
- six parseable integrated specimens projecting exactly one-to-one;
- RC01 and RC02 still refusing specifically at `ADAPTER_RESULT_ORDER`;
- malformed ten-byte body still classified as a reader error;
- 28 new reconciliation checks, all matching their frozen expectations;
- the existing complete legacy-label, missing-record, and duplicate-record controls retained;
- one semantic relationship control that changes the claimed mapping while preserving all artifact hashes;
- 455 original files under the candidate specimens, 24 rebound controls, and historical controls byte-identical to the authenticated prior package;
- 96 scenarios, 176 affected-caller rows, 30 migration rows, 11 fixed cases, and the 19-entry case order exactly preserved;
- the other eighteen candidate lifetimes exactly preserved and explicitly uncredited.

Candidate native/body/result artifacts that do not embed a contract digest remain byte-identical and are rebound to the corrected pair through the exact artifact register and corrected integration expectations. Active digest-bearing representations, paired identities, controls, checkpoint, reconstruction evidence, and reports were regenerated.

Both the original-seed-to-result and blocked-pair-to-corrected-pair deltas replay to the exact final bytes. Wrong-before-image controls refuse.

## Package verification

The package was built twice deterministically, with byte-identical results, then reopened and verified separately:

- ZIP bytes: **3,500,750**
- SHA-256: `e23daca224b2f496fa1066b3d1ba8edbab02e7cae0632249187c01a82e502485`
- Members including manifest: **568**
- Manifested payloads: **567**
- Manifested payload bytes: **23,378,917**
- CRC, membership, paths, modes, hashes, corrected contract, and corrected map: **pass**

A separate final static cross-check independently re-authenticated the input archive chain, verified the delivered ZIP, replayed all four reconstruction paths, compared preservation directly against the authenticated prior owner package, and checked the key semantic witnesses. It passed with SHA-256 `3d5d9834fe53c7d33a73ab0d6342657a0a17938d9b8c973b04c571e292e2ea88`.

## Downloadable artifacts

- ES_R6_ONE_CANDIDATE_F001_F002_CONTRACT_RECONCILIATION_20261014_01.zip
- ES_R6_ONE_CANDIDATE_F001_F002_CONTRACT_RECONCILIATION_20261014_01.zip.sha256

No Codex, repository, Git, host, connector, network, runtime process, public receiver, or candidate expansion was used. No source/feed qualification, runtime implementation, A-to-final AR-01–AR-03 reconstruction, full R6 completion, or independent acceptance is claimed.

**Sources:** ES_R6_ONE_CANDIDATE_F001_F002_OWNER_CORRECTION_HANDOFF_20261014_01.zip, package-contained prior owner and blocking-review evidence, and the generated owner report and verification artifacts above.

**Confidence:** provenance and package identity 0.998; preservation and exact reconstruction 0.995; scoped semantic reconciliation 0.98. Independent acceptance remains pending fresh artifact-only review.
