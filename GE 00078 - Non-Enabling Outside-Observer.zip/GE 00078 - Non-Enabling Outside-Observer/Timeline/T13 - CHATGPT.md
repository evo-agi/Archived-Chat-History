**Proceed with the bounded topology observation.** The amendment addresses the two earlier design gaps sufficiently to move forward; it does not establish implementation readiness or deployment compatibility. One small mountinfo grammar correction should be folded into the observation task—not sent through another general design round. The amendment itself preserves that distinction. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

**Send this to the same implementation/repair Codex conversation: :chatgpt-content-reference{index="16"}[Running-namespace observation prompt](sandbox:/mnt/data/ES_CUST2_Running_Namespace_Observation_Prompt.md).**

## What the amendment resolves

**CUST-2 no longer derives physical separation from configured spelling.** The revised rule obtains the held descriptor’s kernel-rendered presentation, reopens that presentation without following symlinks, verifies object and mount identity, and derives the backing coordinate through the descriptor-selected mount record. That addresses the previously demonstrated *modeled* case-folded bind-ancestry counterexample. It is not yet a native demonstration or a review of implemented code. :chatgpt-content-reference{index="2"}

The missing-path treatment is also materially clearer. An absent suffix is now recorded as intent rather than an observed canonical object. Two missing roots sharing the same deepest existing parent can fail closed because unequal requested spellings alone do not establish distinct future objects. The amendment explicitly identifies this as a compatibility reduction rather than disguising it as unchanged behavior. That consequence must survive into the governing docs and tests. :chatgpt-content-reference{index="3"}

**CUST-1 now has reachable acceptance inputs.** The reported pinned-toolchain probe separates construction failure, reader refusal, and names actually returned by the parser. For the probed exact-limit forms, PAX returns a 1,048,562-byte path and GNU returns a 1,048,575-byte path; the 32,768-header EOF-terminated stream reaches exactly 16 MiB. Those results support the revised test shapes, not the correctness or complexity of the future radix implementation. :chatgpt-content-reference{index="4"}

The revised tests must demonstrate that intended headers reach the real production probe and commit sites. Dependency-refusal cases remain separate and cannot count as successful radix stress tests. No new ES entry/name cap or parser fork is selected. :chatgpt-content-reference{index="5"}

Finally, the topology acquisition schedule now distinguishes filesystem-effect boundaries from streaming writes. That removes the earlier ambiguity about whether every tar/gzip `Write` triggers another mount-table scan. The stated work bound is still a design claim requiring implementation and tests, not measured latency evidence. :chatgpt-content-reference{index="6"}

## One narrow correction remains

The amendment’s mountinfo grammar says present parent edges must not self-reference. Linux’s own `/proc` documentation permits a mount’s parent ID to refer to itself **at the top of the mount tree**. A blanket rejection could therefore reject valid metadata. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

The handoff requires a narrowly specified terminal-root rule: accept a justified top-of-tree self-parent, terminate traversal there, and continue rejecting nontrivial cycles, duplicate IDs, and unjustified or ambiguous self-parent records. It also preserves the amendment’s acceptance of parents outside the visible process root.

Codex should record that as a small external addendum and matrix delta, retaining the original artifacts. The observation task can include modeled parser controls for it; those controls are not repository tests or native mounted-topology proof. **This does not require another design-freeze turn.**

## What the observation must establish

The task is not “check whether the machine looks healthy.” It must bind one acquisition to **one concrete, already-running ES process**, its configuration evidence, and the filesystem view in which it operates. The amendment correctly distinguishes that subject from launcher source, an ordinary admission-test process, and a future mounted-alias fixture. :chatgpt-content-reference{index="9"}

The prompt adds three execution safeguards:

**Process and filesystem context must match.** A PID, container name, or host mount table alone is insufficient. The observer must bind the process’s start identity, mount namespace, and filesystem root to the descriptor observations. Linux exposes a process-specific root view, so matching namespace identity without checking the root view would leave an avoidable evidence gap. :chatgpt-content-reference{index="10"}

**Current configuration bytes must not be mislabeled as startup-loaded configuration.** In the supplied source, `cmd/es/main.go:14–23` selects the configuration file and `es/config/config.go:173–199` reads it at startup. A later file observation establishes current bytes; any claim that those are the bytes loaded by the running process needs its own supporting relationship. These inspected excerpts are retained in the :chatgpt-content-reference{index="17"}[review notes](sandbox:/mnt/data/ES_CUST2_Amendment_Review_Notes.md).

**Observation is not literally zero-effect execution.** The prompt permits bounded metadata queries, transient observer processes, and isolated task-owned scratch when necessary. An observer launched through `docker exec` is a new process inside an existing running container; the task must report that honestly while making no service, configuration, mount, ownership, or protected-data changes. :chatgpt-content-reference{index="11"}

Discovery is bounded: first an eligible already-running supported-local ES container, then—where needed—the already-known governed AMD64 host. There is no general host search, daemon startup, service restart, privilege escalation, namespace creation, or Lima restoration. A missing subject or insufficient access produces a precise blocked observation, not an environment-repair program.

The observation report must also identify **which topology was actually observed**. A direct-host sibling-directory result must not be presented as separately mounted sibling-bind evidence. One concrete layout is enough for this task; it is not evidence for every supported topology.

## What happens after that result

A compatible observation would satisfy this pre-implementation compatibility check **for the identified subject and observed layout**. It would not close CUST-2, validate the rejected candidate, or authorize staging. Actual mounted exact-alias, subtree-alias, and applicable case-folded cases must still exercise the repaired helper later; ordinary native suite passes and modeled records cannot substitute for them. :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"}

The next prompt therefore stops after observation and its evidence report. A supported result leads to the combined doc-first repair of CUST-1, CUST-2, M3-1, the Low findings, and the external runner. The repaired bytes then need the retained full-suite, race, two-architecture native, mounted-fixture, and fresh independent-audit gates. The amendment preserves those obligations; it does not replace them with this preliminary observation. :chatgpt-content-reference{index="14"}

An unsupported or unavailable subject instead leaves one explicit compatibility or access decision. **It is not a reason to restart the external schema work or revive a stopped demo stack merely to keep this tranche moving.**

### Sources, limits, and confidence

I inspected the attached amendment and eleven relevant historical source-archive members, all matching their supplied manifest entries. Exact excerpts and the amendment’s file fingerprint are in the :chatgpt-content-reference{index="17"}[review notes](sandbox:/mnt/data/ES_CUST2_Amendment_Review_Notes.md). The corrected matrix, raw tar-probe results, artifact manifest, and live repository were not supplied here; their authentication and execution remain Codex-reported. The next task reads those retained files directly, so another upload round is unnecessary.

No repository code, tests, host commands, or VM operations were executed here.

**Confidence: 0.95 in proceeding with this observation task.** Document-content provenance is strong; the amended topology proof remains design-level, live compatibility remains unobserved, and implementation acceptance remains outstanding.
