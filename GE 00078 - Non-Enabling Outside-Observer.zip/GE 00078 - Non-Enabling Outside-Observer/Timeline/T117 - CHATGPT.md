Send this to a **new ChatGPT conversation in this project**, with the :chatgpt-content-reference{index="0"}[consolidated ZIP](sandbox:/mnt/data/ES_AR01_AR03_CONSOLIDATED_AVAILABLE_HANDOFF.zip) attached.

**The four primary A/B/C/D archives still need to be uploaded separately for the correction to be completed.** Their exact filenames, locations, and expected hashes are in the ZIP’s `MISSING_PRIMARY_INPUTS.json`. The message below makes that limitation explicit.

```text
You are taking over as the fresh artifact-only design owner for the
AR-01–AR-03 correction. This is continuation and completion of existing
authoring—not an independent review, repository implementation, or a
request for another planning handoff.

First read these files from the attached consolidated ZIP:
- README_FIRST.md
- handoff/CONTINUE_FROM_RECEIVED_CHECKPOINT.md
- handoff/instructions/PRIOR_INTEGRATION_AND_AUTHORING_BRIEF.md

Follow their complete technical scope and evidence boundaries. Then
inspect and authenticate the actual uploaded bytes, including the nested
checkpoint archives. Do not rely on filenames, summaries, or earlier
progress messages as proof of their contents or completion.

Check whether the four primary A/B/C/D archives identified in
MISSING_PRIMARY_INPUTS.json are actually attached. They are not included
in the consolidated bundle. If any remain unavailable, identify all
missing archives in one response and request those exact files. Do not
substitute older Project snapshots, checkpoint excerpts, or report
summaries for required primary source. Preserve and inspect the available
work, but do not invent source-dependent corrections or claim completion.

Once the required inputs are readable, continue from the received
six-member full working-pair checkpoint. Treat its paired corpus and map
as incomplete owner drafts. Preserve the earlier checkpoints and the
documented discrepancy between the previously reported archive identity
and the actual delivered object. Do not restart from scratch or treat
unwritten later corrections as recovered work.

Complete the remaining obligations: reconcile the full active map with
the final normative corpus; finish the source/API checks and complete
authority-container and failure-payload encodings/specimens; reconcile
scenario, ownership, receiver, and evidence-bound requirements; and
produce exact A-to-final reconstruction and whole-packet verification.

Use only uploaded artifacts and isolated file tools. You may write and
run your own inert byte, ZIP, JSON, arithmetic, and consistency checks.
Read-only public primary-source research is permitted only within the
brief’s source/API scope. Do not execute uploaded code, launch or delegate
to Codex, access my computer or repositories, use operational connectors,
run Git, or perform host, socket, device, runtime, cleanup, or publication
operations. Historical /Users/ds paths are provenance labels, not access
targets.

Save concrete, paired corpus/map checkpoints after meaningful integration
steps, without waiting for routine approval. Use unique output filenames
and never overwrite an already linked ZIP. Reopen the exact deliverable
before quoting its size, member count, and hash.

Return actual downloadable deliverables, including the completed
ES_TEMPORAL_AR01_AR03_ARTIFACT_CORRECTION_REVIEW.zip when all owner
completion requirements are satisfied. If completion is blocked, return
the actual saved work and precise remaining obligations—not a completion
claim or another generic continuation prompt.

Your authoring and self-checks are owner work. Independent acceptance
remains pending and must be performed later by a different reviewer.
```

**Source:** the consolidated ZIP’s README and continuation brief, inspected here. **Confidence: high** that this message preserves the intended role, starting point, missing-input treatment, and completion boundary.
