**Retain the block and correct only F-001 and F-002. Do not expand to the remaining eighteen candidate lifetimes yet.**

The review otherwise supports the integration: the historical label meaning, one-way `controller.receive → adapter.response-received` mapping, 25-transition closed union, one-to-one selected-record projection, R01–R05 behavior, controls, and preservation claims all passed. The problem is that the new candidate-specific rules still contradict two unchanged general R6 rules.

### ES_R6_ONE_CANDIDATE_F001_F002_OWNER_CORRECTION_HANDOFF_20261014_01.zip[Download the self-contained owner-correction handoff](sandbox:/mnt/data/ES_R6_ONE_CANDIDATE_F001_F002_OWNER_CORRECTION_HANDOFF_20261014_01.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6_ONE_CANDIDATE_F001_F002_OWNER_CORRECTION_HANDOFF_20261014_01_VERIFICATION.json)

```text
Bytes:             2,441,279
Members:           7
Manifest payloads: 6
SHA-256:           b844fffbf027c00f1f836aee90fdd326513d4df1e3abe8b267107e34cf6284e4
Verification:      PASS
```

The ZIP contains the exact integrated delivery, the completed blocked review, and a detailed artifact-only correction task.

## Selected correction

### F-001 — make R9.19 an explicit projection specialization

The general R6 rule should remain **identity projection by default**: same native kind and payload.

It should also explicitly permit a later normative section to define an exact, total, one-to-one transformation for a named source family. R9.19 becomes that sole specialization for:

```text
candidate: ordinary-disjoint-roots-accept
event kind: candidate-flow
```

This keeps exact source-instance and native-sequence membership, prohibits omission and duplication, and preserves deterministic reconstruction of the selected native meaning. The only historical kind-label migration remains:

```text
controller.receive → adapter.response-received
```

No compatibility alias, inverse mapping, or inherited treatment for another candidate is introduced.

### F-002 — define field-local string exceptions

The general detail-string rule remains ASCII and at most 256 decoded bytes.

R9.19 receives exact field-local exceptions only for:

- `test.capture.stdout_base64`: canonical base64 ASCII up to 65,536 raw bytes, exempt from both the 256-byte scalar limit and the ordinary 1,538-byte raw-token limit;
- `error4096` and elements of `error-array256`: valid UTF-8 under their existing decoded limits, exempt from the ASCII/256 rule but still subject to the unchanged raw-token and enclosing body limits unless accepted source proves a broader allowance is necessary.

All other strings, candidates, event kinds, body limits, event counts, graph limits, confirmation limits, and aggregate evidence limits remain unchanged.

Because the normative contract digest will change, the owner must also rebind the candidate-scoped proposed bodies, confirmations, checkpoint, and controls. The native pilot streams and R01–R05 meanings remain unchanged. RC01 and RC02 must still refuse at `ADAPTER_RESULT_ORDER`, not at a stale digest or generic parse failure.

## Message to send

Send the handoff ZIP to the **existing ChatGPT integration-owner conversation**, not Codex and not the independent reviewer:

> Correct F-001 and F-002 under `instructions/OWNER_CORRECTION_TASK.md`. Authenticate both nested input ZIPs before authoring.
>
> Preserve the successful candidate integration, exact R01–R05 meanings, one-way historical label mapping, closed 25-transition union, all fixed inventories, and the other eighteen unchanged and uncredited candidate lifetimes.
>
> Reconcile the general R6 projection rule with the exact R9.19 candidate-flow specialization, and reconcile the general string-scalar rule with the exact candidate-scoped `stdout_base64`, `error4096`, and `error-array256` field types. Rebind all candidate-scoped artifacts affected by the new temporal-contract digest and return one complete paired corpus/map package with meaningful controls, exact reconstruction, preservation evidence, and completed verification.
>
> Do not expand candidates, launch Codex, access repositories or hosts, execute uploaded programs, implement runtime code, or claim independent acceptance.
>
> The target owner endpoint is:
>
> `OWNER_R6_ONE_CANDIDATE_F001_F002_CONTRACT_RECONCILED_READY_FOR_FRESH_REVIEW`

After that owner result, submit the exact corrected bytes to a **different fresh ChatGPT artifact reviewer**. Expansion remains paused until that review succeeds.

**Sources:** the uploaded blocked review package and exact integrated owner delivery, both included unchanged in the handoff.  
**Confidence:** **0.99** in the review-package and handoff identities; **0.97** in the bounded correction direction. Corrected-model acceptance and full R6 correctness remain unestablished.
