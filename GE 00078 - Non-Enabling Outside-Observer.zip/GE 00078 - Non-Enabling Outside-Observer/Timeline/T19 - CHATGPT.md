**Keep the candidate frozen. Correct the external applicability adjudicator, reassess the retained default-full stream, then run only the physical and race lanes.** There is no reported reason for another repository repair or for rerunning the successful default invocation.

**Send this to the same implementation/repair Codex conversation: :chatgpt-content-reference{index="12"}[Adjudication repair and local-completion prompt](sandbox:/mnt/data/ES_Validation_Adjudication_Repair_and_Local_Completion_Prompt.md).**

Codex correctly stopped under the preceding prompt. The continuation now distinguishes an execution failure from a mistake in interpreting execution evidence.

## What passed, and what remains blocked

The attached report records `default-full` exiting **0**, with **2,332 passing test events and 37 skips**, while also labeling the lane “failed.” Physical-full and race-admission-app were not executed. That can describe a blocked composite validation gate, but **“failed against the frozen candidate” misleadingly suggests that the Go command or tests failed**. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The correct separation is:

| Layer | Current evidence |
|---|---|
| Default-full execution | Reported exit 0; passing tests and skips, with no reported test failure. |
| Required-coverage adjudication | Blocked; your relayed Codex summary attributes this to two incorrect Darwin-applicability decisions. |
| Complete local validation | Incomplete; the physical and race final suites remain unrun. |

The report body does **not** identify those two adjudication errors or show the predicate that caused them. The next task must confirm that attribution in the retained runner, inventory, and `default-full-analysis.json` before crediting the default lane.

The fixture migration itself remains appropriately bounded: the report records only `PLANS.md` and `es/app/submit_integration_test.go` changing, with the production contract preserved. **Neither file needs another edit for this continuation.** :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

## The applicability correction is well grounded

The two identified tests are:

```text
TestLinuxStagingCustodyUsesOpenat2AndRenameat2
TestLinuxStagingCustodyRejectsMountCrossing
```

In the supplied historical source, both are defined in `es/admission/staging_custody_linux_test.go`, whose first line is `//go:build linux`. The earlier independent audit also explicitly treated their Darwin absence as legitimate and their Linux execution as mandatory. This is an already-established platform distinction, not a new exemption invented after a failure. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

I verified the historical file against its supplied manifest; exact excerpts and the inspection boundary are in the :chatgpt-content-reference{index="13"}[adjudication review notes](sandbox:/mnt/data/ES_Local_Validation_Adjudication_Review.md). The current frozen file and the actual erroneous runner predicate still require authentication by Codex.

**Do not simply delete two requirements or subtract two from the expected count.** The prompt requires source-backed applicability for the entire 214-row inventory before further suites. It must distinguish platform selection, package selection, and complete parent/subtest identities. In particular, root-package documentation and operator tests belong in the full suites but must not become false “missing tests” in the admission/app-only race lane.

The original inventory remains intact. Incorrect applicability metadata, where present, receives an explicit, separately recorded correction; Linux obligations remain mandatory for later native execution. The report already states that the 214 rows preserve the earlier inventory lineage and that Linux-only rows are future obligations rather than Darwin passes. :chatgpt-content-reference{index="7"}

## Reuse the observation; correct its interpretation

My previous blanket stop rule was too coarse for **pure postprocessing defects**. It protected the frozen records, but it also made an interpretation error force another handoff even when no test execution needed replacing.

The new prompt permits a narrowly versioned external correction, with regression controls, without changing repository bytes or historical artifacts. Codex must then replay **all** acceptance checks against the original default-full evidence—not merely ignore the two disputed rows.

Reuse is conditional on authenticating the complete stream, command, exit, environment, source binding, package terminals, required test events, and skip causes. A genuine failure, missing evidence, execution-side contamination, or source mismatch still blocks. A corrected interpretation cannot manufacture a pass.

If those checks succeed, the resulting record should say:

> The original default-full execution passed; its original coverage adjudication was defective; corrected source-backed adjudication accepts that same execution.

The old report and old analysis remain unchanged. This is neither a fresh test run nor an independent audit.

The socket improvement also carries forward only to the extent supported by evidence. The report records the short-scratch runner correction and successful focused socket checks under all three environments. Those checks are useful, but the focused physical/race results do not substitute for their still-unexecuted complete suites. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

## Finish only the missing execution

After corrected default adjudication and fresh environment eligibility checks, the prompt authorizes these two commands, sequentially, using the exact pinned toolchain and offline settings specified in the handoff:

```bash
TMPDIR=/private/tmp "$GO" test -json ./... -count=1

CGO_ENABLED=1 TMPDIR=/private/tmp \
  "$GO" test -json -race ./es/admission ./es/app -count=1
```

There is **no default-full rerun, fixture migration, production edit, `PLANS.md` update, or new source freeze**. The target remains the reported **358-file source / 82-path candidate**. The successor analysis and execution records receive their own identities without changing that target. :chatgpt-content-reference{index="10"}

The prompt also permits another demonstrably analysis-only correction within this same bounded task, with preserved versions and replay controls. It does **not** permit retrying failed suites, changing execution settings after a failure, or repairing the candidate. This should prevent another report-only defect from becoming another entire validation cycle.

Local success still means **external gates pending**. Native Linux validation, actual mounted-helper evidence, deployment compatibility observation, independent audit, and the exact-byte commit gate remain outstanding. No service restoration or publication is authorized. :chatgpt-content-reference{index="11"}

Attach the successor **review ZIP alongside its report** on the next return. The prompt carries forward the actual repaired production files and diffs so the subsequent review can inspect them rather than rely on summaries.

**Sources and limits:** attached report, prior independent-audit findings, and the :chatgpt-content-reference{index="14"}[manifest-checked historical source excerpts](sandbox:/mnt/data/ES_Local_Validation_Adjudication_Review.md). I verified the attached report’s digest, but the current runner, inventory, raw stream, and review ZIP were not supplied here. No repository code or tests were executed.

**Confidence: 0.97 in this continuation.** The applicability correction is strongly supported; acceptance of the retained default stream remains conditional on raw-evidence review. Whole-candidate implementation correctness remains unaudited.
