The review is **procedurally incomplete because the four transport ZIPs were not attached to that reviewer conversation**. The supplement alone could not authenticate either exact owner.

I reassembled both owners from the transport files available here:

```text
Current repaired owner
417,231,281 bytes
81bd7e88cd330abdd53cfdd55bf35c936716549aebaa5e68367d328c026bacbd

Reviewed predecessor owner
363,838,609 bytes
7eee8cb8937355aaabb404f068325667ee7e1148ffcdaee678518e19bfea649f
```

I also inspected the exact current owner—not merely the supplement copies. The three source-level concerns identified by the incomplete reviewer are present in the exact owner:

1. `admission26.py` builds each scope’s known-error collection **before** determining whether the error-producing request passes admission.
2. Producer admission is resolved incrementally after sorting by `(admitted_at_unix_nano, request_id)`, so equal-time dependencies can depend on lexical request order.
3. Candidate acquisition facts are returned wholesale and consumed by dispatch/C semantics rather than being filtered to the producer facts that actually passed admission.

Those findings are credible and likely to produce a formal `BLOCKED` verdict. However, the exact-owner review should complete before we author another repair.

## Continue in the same reviewer conversation

Attach these four missing files to the conversation that returned `INCOMPLETE`:

```text
ES_R6J_R26_ADMISSION_PREMISE_ISOLATORS_REPAIRED_OWNER_20261024_29_PART_1_OF_2.zip
ES_R6J_R26_ADMISSION_PREMISE_ISOLATORS_REPAIRED_OWNER_20261024_29_PART_2_OF_2.zip

ES_R6J_CLOSEOUT_26_PART_1_OF_2.zip
ES_R6J_CLOSEOUT_26_PART_2_OF_2.zip
```

The original supplement is already present in that chat. No new supplement or new reviewer conversation is required.

Send this message:

```text
The four required owner transport ZIPs are now attached. Continue the
existing R26.G04 review from its INCOMPLETE endpoint; do not restart the
supplement-only analysis.

Reassemble each owner by concatenating the raw numbered payload members,
not the outer ZIP files. Require:

Current repaired owner:
417,231,281 bytes
81bd7e88cd330abdd53cfdd55bf35c936716549aebaa5e68367d328c026bacbd

Reviewed predecessor owner:
363,838,609 bytes
7eee8cb8937355aaabb404f068325667ee7e1148ffcdaee678518e19bfea649f

Authenticate both complete owner manifests. Confirm that the selected
source copies previously inspected are byte-identical to the exact current
owner, then complete the raw-evidence review of the historical
counterparts, replacements, retirements, unaffected controls, checkpoints,
rounds, registers, state table, displacement ledger and reconstruction.

Adjudicate the three provisional source findings against the authenticated
exact owner:

1. whether a known error from a request that fails its own admission
   prerequisites can contaminate the sticky-failure state used for another
   request;

2. whether producer admission at equal timestamps depends on lexical
   request order rather than an explicit causal/dependency rule;

3. whether dispatch and inherited-C semantics consume candidate owner/result
   facts that were never activated by successful ordinary admission.

Do not merely repeat the INCOMPLETE verdict now that the transports are
available. Promote, narrow or refute each finding using the exact owner
bytes and actual specimens.

Do not execute uploaded programs, repair the owner, launch Codex, access
repositories or hosts, reopen the phase/NRC decisions, amend the normative
pair or expand general joins.

Return one of the original exact-owner endpoints and a compact downloadable
review package without copying either large owner.
```

## Expected continuation

Do **not** return to Codex or ask the artifact owner to patch the reader yet. If the exact-owner reviewer confirms the findings, the subsequent repair must address shared reader semantics rather than merely adding more isolators:

- sticky failures must originate only from requests whose own admissions are valid and whose failures are causally available;
- producer dependencies must resolve independently of lexical request names at equal timestamps;
- dispatch and inherited-C must consume an admitted/activated owner-fact set, while preserving C’s inherited one-use release semantics.

**Sources:** the exact current and predecessor transport ZIPs reassembled here; the uploaded incomplete review; exact current-owner `premises26.py`, `admission26.py`, and `semantics26.py`.

**Confidence:** **0.999** in the missing-input diagnosis and owner identities; **0.97** that the three source findings will survive exact-owner review.
