## Codex stopped at the correct boundary

I advanced the program one gate too early. The all-nineteen review closed **R9.19 candidate-flow projection and semantics**; it did **not** close the general R6 parent-observation joins required for public receiver acceptance.

The implementation handoff incorrectly treated those as the same design gate. Codex correctly refused to invent the missing evidence and ownership meanings in Go source.

The reviewed contract requires the receiver to reconcile outside events with the producer graph, but the active map still explicitly leaves general qualification pending:

- `/source_projection/candidate_flow_family/full_source_qualification = false`
- noncandidate source families remain under default identity projection;
- `/receiver_resource_policy/nineteen_case_semantics/R6_qualification` remains pending.

The partial receiver validates structure, coverage, internal conservation, and all nineteen candidate accounts, then deliberately refuses because these fields still lack exact reviewed joins:

```text
subject-create.custody
subject-state.wait_ref
subject-inventory.interface_ref
request.result_ref
resource.resource_class
resource.interface_ref
resource-inventory.interface_ref
producer-record.record_class
```

That is a **contract/design seam**, not merely unfinished implementation.

The focused development results remain useful evidence, but the partial source is not a completed or frozen successor:

- 135-file baseline authenticated;
- 301-file partial successor;
- 182 touched regular files;
- focused tests and Linux compilation passed;
- no source freeze;
- no final full/race/vet/build generation;
- no independent source audit.

## Next tranche: close the general R6 join contract

Do not send Codex back into the source yet. The next task is one bounded artifact-design correction that defines the complete noncandidate source-to-producer joins while preserving the accepted all-nineteen candidate-flow semantics.

### ES_R6_GENERAL_SOURCE_JOIN_DESIGN_HANDOFF_20261016_01.zip[Download the general source-join design handoff](sandbox:/mnt/data/ES_R6_GENERAL_SOURCE_JOIN_DESIGN_HANDOFF_20261016_01.zip)

:chatgpt-content-reference{index="1"}[Download the handoff verification](sandbox:/mnt/data/ES_R6_GENERAL_SOURCE_JOIN_DESIGN_HANDOFF_20261016_01_VERIFICATION.json)

```text
Bytes:             9,101,147
Members:           17
Manifest payloads: 16
SHA-256:           f61ac9fc1204ae03a01a77a93cf3129661a8b02b70720fdc1cac358950e0960c
Verification:      PASS
```

The package contains:

- the exact corrected all-nineteen owner delivery;
- the satisfied contract/map-binding review;
- the complete blocked source-review package;
- the current contract and map;
- the relevant partial receiver source;
- the receiving analysis and exact design task.

## Message to send

Start a **new ChatGPT artifact-design-owner conversation**. Do not send this to Codex or to an independent reviewer yet.

Attach the ZIP and send:

```text
Continue as the artifact/design owner for the general R6 native-source
join closure.

Read README_FIRST.md, INPUT_IDENTITIES.json,
analysis/RECEIVING_ANALYSIS.md, analysis/JOIN_SEAM.json,
analysis/SELECTED_EXCERPTS.md, the governing contract/map, and
instructions/OWNER_DESIGN_TASK.md. Authenticate all three ZIP inputs before
semantic authoring.

Preserve the accepted all-nineteen R9.19 candidate-flow integration,
closed R01–R05 language, authority boundaries, evidence budgets, exact
histories and controls.

Define one exact finite general-source join contract covering:

- subject creation, custody, state, wait and terminal inventory;
- request admission, return and exact result_ref binding;
- resource class/interface, acquisition, transfer, release and inventory;
- producer-record class and exact graph-role binding;
- cross-checks against the immutable outcome, ledger, ProcessRecords,
  custody records, carrier, reservation and independent expectations.

Use the existing parent-observation event kinds and current version family
unless the authenticated evidence proves they cannot express the required
joins. Select one canonical reference grammar; do not leave custody,
wait_ref, result_ref or interface_ref free-form or implementation-selectable.

Produce a complete modeled positive through the public-R6 semantic path and
fully rebound negative controls. Keep actual feed, clock, responder, signer,
storage and target establishment as later fail-closed gates.

Do not edit or implement Go source, run uploaded code, launch Codex, access
repositories or hosts, change candidate-flow, or claim implementation
completion.

Return actual owner artifacts under the endpoint:

OWNER_R6_GENERAL_NATIVE_SOURCE_JOIN_CONTRACT_READY_FOR_FRESH_REVIEW
```

## Selected design boundary

The correction should remain within the current observation body and evidence domains. It must not casually add:

- a top-level body field;
- another event kind;
- a fourth evidence domain;
- another authority class;
- another version family;
- another string exception;
- another candidate-flow transition.

A complete join profile should define, at minimum:

| Domain | Required exact relationship |
|---|---|
| Subjects | Approved role and creator; exact custody and wait references; producer/candidate corroboration; terminal inventory membership |
| Requests | Operation, phase and actor; one canonical result-reference grammar; exact result event or graph fact; unresolved-result treatment |
| Resources | Stable interface vocabulary; exact owner class; acquisition/transfer/borrowing; one release; terminal inventory |
| Producer records | Closed record-class vocabulary; exact graph role and raw digest |
| Independent scope | Evidence cannot choose its own subject, interface, operation, or join profile |

The owner must stop before partial normative authoring if these relationships genuinely require a new field or evidence domain.

## After the design review

The sequence is now:

```text
general source-join owner correction
→ fresh artifact-only review
→ regenerated implementation handoff
→ new complete source generation and frozen validation
→ independent source audit
```

The blocked partial source should be preserved as **non-authoritative implementation evidence**. After the join design is reviewed, a new implementation owner may reconcile it path by path against the immutable 135-member baseline. It should not simply resume from that partial tree as though the missing semantics had already been settled.

The absent live Q/F actors, qualified feed, clock, protected storage, and L target propagation remain later establishment or implementation gates. They may remain fail-closed; this design tranche must define how their evidence joins when independently qualified, not install those capabilities.

**Sources:** RECEIVING_ANALYSIS.md[receiving analysis](sandbox:/mnt/data/ES_R6_GENERAL_SOURCE_JOIN_DESIGN_HANDOFF_20261016_01/analysis/RECEIVING_ANALYSIS.md), Codex’s BLOCKED_IMPLEMENTATION_REPORT.md[blocked implementation report](sandbox:/mnt/data/ES_R6_GENERAL_SOURCE_JOIN_DESIGN_HANDOFF_20261016_01/blocked_source/BLOCKED_IMPLEMENTATION_REPORT.md), and the exact corrected governing pair contained in the handoff.

**Confidence:** 0.99 that Codex’s stop is required and that the missing general joins are a reviewed-design seam; 0.95 in this bounded design-closure tranche. Implementation correctness and public R6 acceptance remain unestablished.
