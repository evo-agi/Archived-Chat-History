**Retain the block and repair R01–R04 before expanding the pilot.** These are concrete defects in the selected reader’s accepting semantics—not objections to unfinished full R6 work.

The review also **did not establish fresh author/reviewer separation**. Treat it as a useful source-grounded examination, not satisfaction of the independent-review gate. Its specimens are actionable; repeating the review on unchanged bytes would not fix the reader.

### ES_R6_PILOT_R01_R04_REPAIR_HANDOFF_20261014_01.zip[Download the self-contained R01–R04 repair handoff](sandbox:/mnt/data/ES_R6_PILOT_R01_R04_REPAIR_HANDOFF_20261014_01.zip)

Send this **single ZIP to the existing ChatGPT design-owner conversation**, not Codex. It includes the original pilot unchanged, the complete review and six specimens, my inspection, and `NEXT_OWNER_TASK.md`. The required nineteen-case seed and accepted B source are already nested inside the pilot.

## What I verified

The delivered review matches its reported identity:

```text
ES_R6_ONE_CANDIDATE_PILOT_ARTIFACT_REVIEW_20261014_02.zip
Bytes:   440,471
Members: 65
SHA-256: 2818ceed5c041766cf80e15f026458e091f3fc23389cda37edf02596c8f945ed
```

Every member of both the review and original pilot passes actual-byte size, hash, CRC, encoded-mode, safe-path, and exact manifest checks. All **58 pilot source copies** match accepted B; the review’s **22 referenced source/instruction members** match their actual bodies.

I read the complete current pilot reader and its grammar, along with the decisive B acquisition, wait/group, and finalization paths. I also checked the six specimens directly. **I did not execute the uploaded reader or review checkers.** The predicted accepting paths and exception remain static findings, not newly observed runs. INSPECTION.md[Receiving inspection](sandbox:/mnt/data/ES_R6_Pilot_R01_R04_Continuation_20261014_01/INSPECTION.md)

The direct data checks corroborate the findings:

| Finding | Confirmed specimen property |
|---|---|
| **R01** | CE01 combines a wait error with favorable exit/reap fields. CE02 combines unknown group status with favorable absence fields. |
| **R02** | CE03 contains two distinct successful pidfd-open requests, but only the original acquisition/release account. |
| **R03** | CE04 contains three semantic records after finish, including a returned observation of a remaining group member. |
| **R04** | CE05 contains `members=[[]]`. CE06 leaves native `true` unchanged while replacing its body projection with integer `1`. |

For CE06, my data-only comparison reproduced ordinary Python equality between the projections while a type-preserving comparison rejected them. All six specimens retain their raw native bindings and original case/lineage bytes. SPECIMEN_AND_SOURCE_CHECKS.json[Exact specimen checks](sandbox:/mnt/data/ES_R6_Pilot_R01_R04_Continuation_20261014_01/SPECIMEN_AND_SOURCE_CHECKS.json)

## Keep the repair finite

**My selected direction is one pilot-local contract and reader correction, not a general resource framework or another expansion of the full corpus.**

### R01: validate the complete return, not its favorable fields

The owner must freeze an operation-specific table for each selected result: status, error, payload types, and the relationships to the case and custody facts.

The old wait branch does not inspect status or error before using its favorable payload; the group branch derives absence without consulting status. Correcting only the two demonstrated values would leave the same class of inconsistency elsewhere. The task therefore covers all eight existing operation branches, without adding new process or recovery paths. SELECTED_SOURCE_EXCERPTS.md[Reader and B excerpts](sandbox:/mnt/data/ES_R6_Pilot_R01_R04_Continuation_20261014_01/SELECTED_SOURCE_EXCERPTS.md)

**Do not solve this by rejecting every error.** The existing consuming-close failure must remain a consistent but noneligible account, and the lost-acknowledgement prefix must retain its possible child and unknown controller custody. Contradictory evidence, coherent failure, and an unsupported outcome are different classifications.

### R02: one selected acquisition, with no invisible successful return

For this bounded pilot, **permit only the selected pidfd-acquisition invocation and reject an additional one explicitly**. There is no need to introduce multi-candidate or general multi-resource accounting.

Separately, the selected successful return must immediately establish an accounting obligation. A later `descriptor.acquire` record joins that fact to its representation; omitting the record cannot make the successful Open disappear.

The controls should distinguish a second acquisition from a missing ownership record for the first. A second fully accounted acquisition still falls outside this selected pilot; a successful first acquisition with no corresponding duty still fails conservation. Neither refusal asserts that no real resource could have been created.

That scope restriction must be explicit in the repaired pilot rules—not inferred from the one favorable constructor output.

### R03: finish is the semantic boundary

**After `controller.finish`, only the final `scope.seal` is permitted.** A later request, observation, acknowledgement, acquisition, or release must refuse rather than change state beneath cached success.

The reader must still inspect the complete account. It cannot crop the suffix at finish or trust the finish record’s supplied eligibility.

This boundary should be checked before interpreting post-finish operations, so CE04 tests terminal finality rather than being credited merely as a duplicate group request. Final eligibility must agree with the final derived wait, group, request, descriptor, case, and controller facts.

The lost-ack prefix can still end with a noneligible disposition and seal. That closes the **recorded prefix**, not the unknown child’s actual lifetime.

### R04: preserve types and reject malformed input deliberately

Native/body comparison must distinguish Boolean `true` from integer `1`, recursively. Neither representation may silently repair the other.

Types must be validated **before** set construction, dictionary membership, indexing, arithmetic, or other operations with stronger prerequisites. Group-member elements need exact integer checks before duplicate detection; analogous selected entry points need the same treatment.

A malformed input should produce an intentional refusal with false eligibility. An unexpected implementation exception remains a reader error. **Catching every exception and relabeling it a successful refusal would conceal the defect rather than close it.**

## Preserve the original evidence while adding discriminating checks

The handoff requires the original three histories, twelve controls, first checkpoint, and same-witness C correction to remain unchanged. Their narrower credits also survive:

- C02 mixes wrong subject and wrong request, so a new request-only mutation must isolate the join.
- C09’s adverse payload does not test whether group status is honored.
- C08b tests another unowned instance with the same descriptor number, not observed operating-system reuse.
- The C regression remains a cancelled-ordinary-context case **before S**, not general post-D conformance.

The six review specimens must remain exact historical inputs. If clarified grammar or expectation bindings require current-profile derivatives, those must be explicit, narrowly rebound copies that preserve the defect. **Rejection solely because an old hash or schema no longer matches is not regression closure.**

The owner may execute a newly authored inert successor reader against the fixed rules and saved bytes. It must not run the uploaded predecessor or reviewer programs to manufacture dynamic evidence of the old findings. Actual successor results, errors, and repeats must be retained; crashes and unintended early refusals do not count as passing negative controls.

This remains one repair task. It does not require another collection, recovery, or unchanged-suite cycle.

## Message to send

Attach the handoff ZIP to the **existing ChatGPT owner conversation** and send:

> Repair the one-candidate pilot under `NEXT_OWNER_TASK.md`. Read the included review and inspect all six actual specimens and the retained reader/source before authoring. Complete R01–R04 with independently fixed pilot rules, a new inert successor reader, preserved original evidence, meaningful refusal controls, and exact changed-file reconstruction.
>
> Keep the full seed corpus/map and other eighteen case records unchanged. Do not expand to full R6, launch Codex, access repositories or hosts, execute uploaded programs, or claim independent acceptance. Save and verify the first substantive repaired construction before expanding the controls, then return one actual downloadable repaired-pilot package.

The intended owner endpoint is:

```text
OWNER_BOUNDED_R6_ONE_CANDIDATE_R01_R04_REPAIRED_REVIEW_REQUIRED
```

**After that result, use a genuinely different ChatGPT conversation for review.** Newly written checks in the authoring conversation do not satisfy that separation. No further expansion should precede the fresh review of the repaired pilot.

## Delivery and limits

The self-contained handoff was closed and reopened successfully:

```text
Bytes:   36,270,941
Members: 13
SHA-256: 087bef8f2117afdb5bb5564309a97568fc34d9f3565e987ea6f728412b9a780e
```

Some older indexed attachment references have expired, but the required review, pilot, seed, and B bytes are readable and included. **No additional upload is needed for this repair.**

I made no pilot correction, executed no uploaded code, and performed no repository, host, process-under-test, or cleanup operation. Remote uncertainty, the four historical owning-ES clause gaps, full R6 integration, A-to-final reconstruction, whole-candidate ES acceptance, and operational gates remain unchanged.

**Sources:** the PILOT_REVIEW\.md[delivered review](sandbox:/mnt/data/ES_R6_Pilot_R01_R04_Continuation_20261014_01/review_data/PILOT_REVIEW.md), actual pilot reader and selected B source, and the receiving-side checks linked above.  
**Confidence:** **0.99** in measured integrity and specimen relationships; **0.97** in the source-supported repair direction. Repaired-reader correctness and fresh independent acceptance remain unestablished.
