# 16: Audit of ES PR #51 at 669c796 (core dump check without an OS branch)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 09:45Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- **The fix is right and follows AGENTS.md section 12.**
  - The helper no longer looks at the OS name.
  - It always sets the core file limit to 0, always makes itself not dumpable through prctl, and reads both back.
  - If either step cannot be done, it stops before any prompt, SPIRE command or Vault request, with no fallback.
- **The manifest reproduces.** `afa30eae…91b0`, taken twice plus a closing run. The diff is byte-identical to the writer's `pr51.diff`.
- **Tests.** All pass at the head, as root (87 pass, 2 skip) and unprivileged (89 pass). The docs package passes too (604).
- **Simulated host without prctl.** I wrote my own simulation, independent of the writer's. It has 0 failures: the 4 refusal subtests pass, and every end-to-end test skips with the reason.
- **Mutants.** 12 of 12 killed: the writer's 7 and 5 more of mine.
- **No findings against this PR.** There are two observations.
  - **O16-1 (evidence only).** The writer's "simulated host" log came from an earlier working tree, not from the pushed head. My run at the head shows the same result, so nothing needs to change in the PR.
  - **O16-2 (older problem, not from this PR).** The helper, and about 29 other scripts, start Python without isolated mode (`-I`). Python then loads a module from the current folder before the standard one. A root run started from a folder another account can write would run that account's code. I recommend a separate, tracked follow-up.
- **Before merge.**
  - CI run 45364689146 on 669c796 was still running when I wrote this. The merge gate requires it to pass.
  - trunk_dev has moved to `3f1a84c` (#49), which changes this same helper and the docs. A trial merge is clean and the no-OS-name pin still holds. The sync that #51 needs before merge should get a short delta check.
- Nothing was pushed or posted, and the box was not touched.

## 1. Target and provenance

| Item | Value |
|---|---|
| PR | https://github.com/evo-agi/Execution-Substrate/pull/51, open, ready for review |
| Head | `669c796185460eda099a276d598db1e04d6cb19d`, one commit on `claude/project-thread-vmre16`, still the head at 09:40Z |
| Base | trunk_dev `f058d8a1f4c8e51c0a000b94ff2b9aa3f244dfe2` (the #35 squash; its tree `f09e4343…` equals the e73c69e tree I accepted in 13) |
| Writer's report | `15-dumpable-followup.md`, SHA-256 `563d483a9c13bef62cd233ce981f15405ceef72ab12cc8553d8d738c72cb8b0a` (matches the relay) |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest SHA-256 | `afa30eae6d7ca3a09cad98101f4597f7f65df2d2f4da44aef86a66091e8f91b0`. Fresh clone, umask 022, branch at the head, `git reset --mixed` to the base, upstream `origin/trunk_dev`. Taken twice with identical output; the closing run after all tests and mutants is equal |
| textual_diff_sha256 | `a39e28c5f07ce65cc34d99af3ecf2efbdd65e7b07713ab52a8df845cd6809a45` |
| Diff | `git diff` of the working tree against the base has SHA-256 `4bf2aa851a1c2e3bce553ac174835604d477dbe25fef6cb37d1a5faf72f8666b`, equal to the writer's `pr51.diff`. 4 files: the helper, its two test files and the Remote Alpha docs |

## 2. Review

**The helper** (`scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh`):

- **No OS branch.** `disable_core_dumps()` has no `sys.platform` test left. It sets `RLIMIT_CORE` to (0, 0) and reads it back, then always:
  - looks up `prctl` in `ctypes.CDLL(None, use_errno=True)`;
  - calls `PR_SET_DUMPABLE` (4) with 0;
  - reads `PR_GET_DUMPABLE` (3) back.
- **Fail fast.** Each failure raises `ProcessStillDumpable`:
  - the C library cannot be opened (`OSError`);
  - there is no `prctl` (`AttributeError`);
  - the set returns non-zero;
  - the read-back is non-zero.

  The read-back requires exactly 0, so a value of 2 ("suid dumpable") is refused as well.
- **No fallback.** `main()` maps `ProcessStillDumpable` to phase `disable_core_dumps`, class `core_dumps_not_disabled`, message class `process_still_dumpable`, and stops.
  - This runs before the config load, the prompts and every SPIRE or Vault call. I checked the order in `main()`, and B5 below confirms it.
  - A core file limit that does not hold keeps its old message class, `core_dump_limit_failed`.
- **Summary.** It records `dumpable=False` only on the path where both read-backs passed.
- **Help text and docs.** Both say "core file limit 0, and not dumpable through prctl" and that a host where this cannot be done is refused. Neither says "on Linux" any more.

This is what AGENTS.md section 12 asks for. The capability is proven by behavior: the call is made and read back. A missing capability stops the run, and there is no OS name check or fallback.

**The tests:**

- **The probe** (`requireBootstrapNotDumpableCapability`).
  - It runs the same ctypes calls in a separate `python3 -I -c`, once per test binary, and skips with the reason when they fail.
  - It sits in front of every run that reaches the core dump step: the terminal runner, the three runs without a terminal that get that far, and both real-Vault tests (before Vault starts, at `…real_vault_test.go:300` and `:499`).
  - Runs that stop before that step still run everywhere. In my simulation the argument checks, the source pins and the unseal-key authority failures all passed.
- **The refusal test.**
  - A `sitecustomize.py` on `PYTHONPATH` replaces `ctypes.CDLL` in the helper's python3. That works because the helper starts Python without `-I` (see O16-2).
  - The four modes each require: exit 1, the printed phase and class, no prompt text, no secret and no traceback, zero Vault requests, no SPIRE log, and the failure summary with `process_still_dumpable` and nothing started.
  - The `unchanged` mode proves the module alone does not stop a run. It uses the probed runner, so it skips where the capability is missing. That is correct.
- **The source pin.** It forbids nine OS-name strings in both helper files: the wrapper `scripts/remote_alpha_vault_workload_auth_bootstrap.sh` and the internal script. On Linux an OS branch behaves like no branch, so only the source can show it. M1 confirms the pin works.
- **`assertBootstrapCoreDumpsOff`.** It now also requires `dumpable: false`, so every end-to-end run checks the summary field.

## 3. Tests at 669c796

I built one test binary from the audit tree. Every run had SIGINT at its default. Logs are in `16-pr51-audit-evidence/logs/`.

| Run | Result |
|---|---|
| `TestRemoteAlphaVaultWorkloadAuthBootstrap` (real Vault 2.2.2 included), root | PASS: 87 pass, 0 fail, 2 skip (the existing non-root-only tests) (`r51-root-bootstrap.log`) |
| The same, unprivileged (user `ci`, `env -i`) | PASS: 89 pass, 0 fail, 0 skip (`r51-ci-bootstrap.log`) |
| The same on my own simulated host without prctl | PASS: 24 pass, 0 fail, 58 skip (`r51-noprctl-sim.log`). The 4 refusal subtests and the OS pin pass. `unchanged` and every end-to-end run skip with the reason, including both real-Vault tests before Vault starts |
| Root package (docs tests), root | PASS: 604 (`r51-root-package.log`) |

**How my simulation works** (`no-prctl-simulation/`):

- A `python3` wrapper on PATH removes `-I` and sets `PYTHONPATH` to a shim, unless the test has set its own.
- The shim makes `ctypes.CDLL(...).prctl` raise `AttributeError`, like a C library without prctl.
- So the probe's python3 and the helper's python3 both see a host without prctl. The refusal test's own shim still takes its place, as it would on such a host.

## 4. Mutants

The runner is `mutants/r51_mutants.py`: the writer's seven, plus five of mine. It used one prebuilt binary and the bootstrap tests named in the runner. The helper was restored after the run and its checksum matched (`r51-mutants-run.log`).

| Mutant | Result | Failing tests |
|---|---|---|
| M1 the `sys.platform` branch put back | killed | `DoesNotBranchOnTheOperatingSystem` |
| M2 a missing prctl falls back to running | killed | `no_c_library`, `no_prctl` |
| M3 the set result not checked | killed | `set_fails` |
| M4 the read-back not checked | killed | `still_dumpable` |
| M5 lookup failure not mapped to the refusal | killed | `no_c_library`, `no_prctl` |
| M6 the summary records `dumpable: true` | killed | `FakeVaultWrites…`, `unchanged` |
| M7 `main()` continues after the refusal | killed | all four refusal subtests |
| B1 the lookup catches only `OSError` | killed | `no_prctl` |
| B2 the `ProcessStillDumpable` handler removed, so the failure reaches the generic handler | killed | all four refusal subtests (message class) |
| B3 the read-back accepts 1 (only a negative result counts as an error) | killed | `still_dumpable` |
| B4 `PR_SET_DUMPABLE` set to 3, so the "set" is really a read | killed | `set_fails`, `unchanged`, `FakeVaultWrites…` |
| B5 a `return` right after the limit check, so prctl is skipped | killed | all four refusal subtests |

B5's label in the runner says "after the first prompt starts". That label is wrong; the replacement is the `return` described in the table.

## 5. CI, Codex and trunk_dev

- **CI.** Run 45364689146 (job "build, vet and test") on 669c796 started at 09:23:11Z and was still running at 09:40Z. On the GitHub runner (Linux) the probe passes, so no new test skips there. The repository requires this check to pass before merge.
- **Codex.** Its review of 669c796 finished with no findings.
- **trunk_dev has moved.** It is now `3f1a84c` (#49, RT-1/2/3). GitHub reports #51 as "behind".
  - #49 changes the same helper (no-follow reads of regular files, `NotARegularFile`, `fchown`/`fchmod`) and the Remote Alpha docs.
  - A trial `git merge-tree --write-tree 669c796 3f1a84c` is clean (tree `6bf4da6f33130815d38fd33a9fe82022131ef15b`).
  - In that tree both helper files still contain none of the nine OS-name strings.
  - The repository requires the branch to be up to date, so #51 must be synced. Because #49 touches the same helper, that sync should get a short delta check, like 13: a plain merge, and the PR's lines and trunk's lines each unchanged.

## 6. Observations (not findings against #51)

**O16-1. The writer's no-prctl log does not come from the pushed head.** Evidence only, no PR change needed.

- `15-dumpable-followup-evidence/validation/macsim.log` shows the real-Vault skips at `…real_vault_test.go:349` and `:561`. The unseal-key test ran for 9.44 s before it skipped, so Vault had started first.
- At 669c796 the probe is at `:300` and `:499`, before Vault starts.
- In the older tree the signal test skipped each of its 7 subtests inside a passing parent. At the head the whole test skips. That explains the writer's 25 pass / 64 skip against my 24 / 58 exactly.
- My run at the head shows the property the report claims: 0 failures, the refusals pass, and everything else skips with the reason. The writer may want to correct the line in 15.

**O16-2. The helper starts Python without isolated mode.** This is older than #51 (it was there at #35) and runs across many scripts, so I recommend a separate follow-up.

- Both of the helper's Python runs start as `python3 - …` (lines 196 and 224), without `-I`. In that mode Python puts the current folder first on `sys.path`. The helper does not change folder before it starts Python.
- I checked it here (`cwd-import-check.txt`). With a `base64.py` in the current folder, `python3 -` imports it, and `python3 -I -` does not. The helper's main Python imports `base64` at the top.
- So a root run started from a folder another account can write, such as `/tmp` or a service account's folder, would run that account's code inside the process that later reads the unseal key. `PYTHONPATH` and user site-packages also apply without `-I`. sudo's default environment reset removes `PYTHONPATH`, but nothing protects the current folder.
- The pattern is wide. A rough count on trunk_dev 3f1a84c finds about 200 `python3 -`/`python3 -c` runs without `-I` in 29 files under `scripts/`. They include the ARS/AGS/EGS hardening, the Vault migration, TLS renewal and deploy helpers. The firewall helper, the Nomad ACL scripts and the operator wrapper already use `-I`. Some of those 29 files never run as root.
- **My assessment, an inference:** Medium for the root helpers. It needs an operator to start a root script from a folder another account can write. That is not the documented way to run them, but nothing stops it.
- **Recommendation:** one follow-up PR that adds `-I` to every embedded python3 under `scripts/`, with a repository-wide pin that forbids a run without it.
  - #51's refusal test would then need another way in, because it relies on `PYTHONPATH`. A `python3` wrapper on the test's PATH would work, like my simulation.
  - The follow-up should be tracked, not left as "later", since this project allows no "revisit later" without a trigger.

## Findings

None against PR #51.

## Effects

- Read-only, in private clone `/opt/audit/ES51`. No commit, push, comment, PR change or merge. The box was not contacted.
- Delivered this file and `16-pr51-audit-evidence/`:
  - logs;
  - the three manifests;
  - the mutant runner and per-mutant output;
  - the no-prctl simulation;
  - the trial merge tree id;
  - the cwd import check.
- Scanned the evidence for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `669c796` (manifest `afa30eae…91b0`). Before merge:

- CI run 45364689146 must pass at the merge gate.
- The sync with trunk_dev `3f1a84c` (#49) needs a short delta check.
