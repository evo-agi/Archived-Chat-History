# 25: Delta check of ES PR #52's sync at 072e6ac (trunk_dev 30b241d merged, #51's refusal test moved to the venv hook)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 14:05Z.
Verdict: **BLOCK** (one Low finding, A25-1, with a tested fix diff)

## Plain summary (for relaying)

- **The merge is clean.** f820a21 is git's own merge of 7b911de (accepted in 20) and trunk_dev 30b241d, with no hand edit. The PR's lines in all 45 files and trunk's lines in all 26 files are unchanged. 30b241d has the same tree as #51's head 0a00f2a, which I accepted in 22.
- **The manifest reproduces:** `8f88a5ea…04b8`, 46 paths.
- **The hook move does what the writer says.**
  - At the head, root, unprivileged, layout and docs-package runs all pass.
  - #51's 12 helper mutants are all caught.
  - The hook mutants K1 and K3 behave as the writer's report 24 says. So the marker check is what keeps `unchanged` meaningful.
- **One Low finding, A25-1.** The new test helper finds the interpreter by following python3 on `PATH` through symlinks. When that python3 is a wrapper script rather than a link, the venv's python3 points at the wrapper. The real interpreter then starts outside the venv, and the hook never loads. This is how pyenv and asdf shims work.
  - On my wrapper-style host, #51's four refusal subtests fail at 072e6ac. They passed under the same setup at 0a00f2a, before the move.
  - es/app's ACL cases (from #52 itself) fail the same way. I missed that in 19 and 20.
  - The failure is loud, with no false pass, and it is test-only. CI uses Ubuntu's `/usr/bin/python3`, which is a symlink, so CI is not affected.
- **Fix:** `25-pr52-sync-check-fix.diff` (2 files). It asks python3 for its own `sys.executable` and builds the venv on that. With it, everything passes, with and without the wrapper. Per the "Low nits fixed in-PR" rule, this blocks until it lands.
- **CI on 072e6ac** (run 45405728557) was still running at 14:03Z.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `072e6ac09e537f1e19a8d38da1a6e995bc2efb8f`, tip of `claude/scripts-python-isolated` at 14:03Z. Parent `f820a21cdc916cce9a0e78314828a174ce361a4e`, whose parents are `7b911de` (20 ACCEPT) and trunk_dev `30b241d90435339b1981f0a5478b2cc45fcdfd4f`. trunk_dev was still `30b241d` at 14:03Z |
| Plain merge | `git merge-tree --write-tree 7b911de 30b241d` = `edb16548b872433c17ef69382d1765c7216d05b5`, equal to f820a21's tree |
| Base equals what 22 accepted | 30b241d's tree = 0a00f2a's tree = `c0317ef490d74d7195dd85fa44946f6dffc977e5` |
| The PR's lines | For all 45 PR files, the `-U0` added and removed lines of `8789662..7b911de` equal those of `30b241d..f820a21` |
| Trunk's lines | For all 26 files trunk changed since 8789662 (#45, #30, #51), the added and removed lines of `8789662..30b241d` equal those of `7b911de..f820a21` |
| The hook move | `f820a21..072e6ac` touches 1 file (+67 −13). My diff is byte-identical to the writer's `24-pr52-sync-evidence/hook-move.diff`, SHA-256 `4f22467055673fdecc9b0517c9ef7f89837712ffd75477178402fcff9e12dc91`. I left it out of my evidence because its context lines hold the repo's synthetic token fixtures |
| Manifest SHA-256 (072e6ac vs 30b241d) | `8f88a5eab11aa7d2029eddf787e61d00f53132e7c74f244b997bd5516a4904b8`. Taken twice in a fresh clone (umask 022, branch at the head, reset to the base, upstream `origin/trunk_dev`); the closing run at 14:00Z is equal. Recipe v2 `c08597e2…a3ca`. textual_diff `b15adbcb…ce00`. 46 paths: the 45 from 20 plus the bootstrap test file |
| New Python runs from trunk | None without `-I`. The guard passes with the allowlist unchanged |
| `gofmt -l scripts/ es/app/`, `go vet ./scripts/ ./es/app/` | clean, at the head and with the fix |

The merge checks are in `25-pr52-sync-check-evidence/merge-checks.txt`.

## The hook move (072e6ac)

- **`bootstrapPrctlHook`** is #51's `ctypes.CDLL` stand-in, chosen by `ES_TEST_PRCTL`. Each call through it first appends `CDLL` to the marker. In the merged helper, `ctypes.CDLL` is called only by the prctl lookup in `disable_core_dumps()`, so the marker proves that the lookup went through the stand-in.
- **The helper's Python runs.** All three python3 runs in the helper use `-I`, so `PYTHONPATH` is ignored there and #51's old `sitecustomize` could no longer load. That matches the writer's account of why the test had to move.
- **`writeBootstrapPythonHook`** builds the same minimal venv as es/app's `writeTestPythonHook`:
  - `bin/python3` is a link to the interpreter;
  - `pyvenv.cfg` sits in bin's parent;
  - a `.pth` in `lib/pythonX.Y/site-packages` imports the module;
  - files are 0644 and folders 0755;
  - the probe `exec.Command` sets `Dir`, as #39 requires.
- **`requireBootstrapPythonHookRan`** is called by every subtest, `unchanged` included.
- **The terminal runner's own python3** is resolved from the test process's `PATH`, not from the fake bin, so it does not load the stand-in. I confirmed this in the code: the runner is `exec.Command("python3", …)`, which Go resolves with the test process's `PATH`, not with the helper's `cmd.Env`.

## Finding A25-1 (Low): the venv hook needs python3 on PATH to be the binary or a link to it

**What.** Both hook writers find the interpreter as `filepath.EvalSymlinks(exec.LookPath("python3"))` and link `bin/python3` to the result:

- `writeBootstrapPythonHook` in `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go`, new in 072e6ac;
- `writeTestPythonHook` in `es/app/service_launchers_container_user_test.go`, from #52 since f862eb2.

Python finds a venv from `pyvenv.cfg` next to the executable it starts as. If python3 on `PATH` is a script that `exec`s the real interpreter, `bin/python3` runs that script, and the script starts the real interpreter by its own path. The venv is then never seen, and the `.pth` hook does not load. pyenv and asdf shims are scripts of this kind.

**Shown.** I used my no-prctl simulation from 16 and 22. Its `python3` is a bash script that `exec`s `/usr/local/bin/python3`. I put it first on `PATH`.

| Tree | Run | Result |
|---|---|---|
| 0a00f2a, before the move (22) | bootstrap tests | 24 pass, 0 fail, 58 skip |
| **072e6ac** | bootstrap tests | **19 pass, 5 fail, 58 skip**. The four refusal subtests fail with "the helper's prctl lookup did not go through the test's ctypes hook (marker … no such file or directory)". `unchanged` skips on a no-prctl host by #51's design |
| **072e6ac** | es/app ACL cases | **3 fail**: "the no-acl-reads python hook did not run in the launcher's python3". Without the wrapper they pass (3 pass, 3 skip) |

**Why it matters.**

- #51's point is that the refusals run and are checked on every host. After the move, they fail on any host whose python3 is a wrapper. Typical cases are a developer machine with pyenv or asdf. The same likely applies to some Mac setups, but I have not checked that.
- **Inference, not tested:** on such a host with a working prctl, `unchanged` fails too, from its marker check.

**Not affected.**

- The helper itself is not affected.
- There is no false pass: the marker check turns the missing hook into a failure.
- CI's `/usr/bin/python3` on ubuntu-24.04 is a symlink, so CI should pass. This is an inference from the workflow, which installs no other Python.

**Fix** (`25-pr52-sync-check-fix.diff`, SHA-256 `197b8b6520ba29d50d87ae0158af3915ada0e4ff8b179c7da44587a3022201c4`, 2 files, applies cleanly on 072e6ac):

- Run python3 from `PATH` once with `-I -c` and print `sys.executable` and the version.
- Require two lines, with the first an absolute path.
- Follow links from `sys.executable`, not from the `PATH` entry, and build the venv on that.
- In `scripts/`, the probe keeps `Dir = executionSubstrateRepoRoot`. In es/app, as before, there is no `Dir`.
- A short comment in each says why.

**Fix tested** (built from 072e6ac plus the diff exactly as delivered; logs are `fix-final-*`):

| Run | Result |
|---|---|
| Bootstrap tests on the no-prctl simulation, wrapper first on `PATH` | 24 pass, 0 fail, 58 skip: the same as 0a00f2a |
| Bootstrap tests as root, plus the 3 guard tests | 87 pass, 2 skip, and 3 pass |
| Bootstrap tests unprivileged (user `ci`, `env -i`) | 89 pass |
| es/app ACL cases with Docker, without and with the wrapper | 3 pass, 3 skip in both |
| `internal/testutil` (#39's layout checks) | 6 pass |

Two more checks ran on the fix with a comment-only difference from the delivered diff:

- the es/app launcher tests with Docker: 68 pass, 0 fail, 17 skip;
- hook mutants K1 and K3: the same as at the head (K1: all 5 subtests fail; K3: the 4 refusal subtests fail and `unchanged` passes with no stand-in).

## Tests at 072e6ac

Root, signals at default, Vault 2.2.2. The result lists are in `25-pr52-sync-check-evidence/logs/head-*`.

| Run | Result |
|---|---|
| Bootstrap, firewall, output-dir, guard and scripts docs tests, root | 181 pass, 0 fail, 5 skip. The skips are the 3 IPv6 subtests and the 2 non-root-only bootstrap tests |
| Bootstrap tests unprivileged (user `ci`, `env -i`) | 89 pass, 0 fail |
| `internal/testutil` | 6 pass |
| Root package (docs tests) | 608 pass, 0 fail |
| es/app ACL cases (Docker), plain | 3 pass, 3 skip |

The writer's 208/6 run selects more tests (its pattern adds, for example, #30's namespace tests), so the counts differ by selection, not by result.

## Mutants at 072e6ac

**#51's helper mutants.** These run against the test binary of 072e6ac (`probes/r51_mutants_at_072e6ac.py`, result lists in `mutants/helper-at-072e6ac/`). They are the writer's M1 to M7 from 15 and my B1 to B5 from 16: **12 of 12 killed**.

| Mutant | Caught by |
|---|---|
| M1 OS branch put back | `DoesNotBranchOnTheOperatingSystem` |
| M2 missing prctl falls back to running | `no_c_library`, `no_prctl` |
| M3 set result not checked | `set_fails` |
| M4 read-back not checked | `still_dumpable` |
| M5 lookup failure not mapped to the refusal | `no_c_library`, `no_prctl` |
| M6 summary says dumpable true | `FakeVaultWrites…`, `unchanged` |
| M7 `main()` continues after the refusal | all four refusal subtests |
| B1 lookup catches only OSError | `no_prctl` |
| B2 refusal handler removed | all four refusal subtests |
| B3 read-back accepts 1 | `still_dumpable` |
| B4 GET constant instead of SET | `set_fails`, `unchanged`, `FakeVaultWrites…` |
| B5 prctl step after the first prompt | all five subtests |

**Hook mutants** (`probes/boot_hook_mutants.py`):

- **K1, the stand-in through a `PYTHONPATH` sitecustomize with the marker kept:** all 5 subtests fail.
- **K3, the same with the marker checks removed:** the 4 refusal subtests fail, and `unchanged` passes with no stand-in.

Both match the writer's report 24. I did not repeat K2.

## CI

Check run 138485829782 ("build, vet and test", run 45405728557) on 072e6ac started at 13:39:45Z and was in progress at 14:03Z. The repository requires it to pass before merge. A push of the fix starts a new run.

## Findings

- **A25-1 (Low): the venv hook writers need python3 on `PATH` to be the binary or a link to it.** This is a regression for #51's refusal test on wrapper-python hosts, and es/app has the same issue. Fix diff above.

## Effects

- Read-only, in private clones and worktrees under `/opt/audit/` (ES52s, ES52t, ES52fix2). No commit, push, comment, PR change or merge. The box was not contacted.
- Docker was started for the es/app runs and stopped afterwards.
- Delivered:
  - this file;
  - `25-pr52-sync-check-fix.diff`;
  - `25-pr52-sync-check-evidence/`: manifests, merge checks, result lists, mutant results, probe scripts, and the simulation wrapper and shim.
- Scanned the evidence for token and key patterns: no matches. Result lists are used instead of full logs, and the fixture-bearing hook-move diff was left out.

## Verdict

**BLOCK** for head `072e6ac` (manifest `8f88a5ea…04b8`) on A25-1 (Low). Everything else in the sync is accepted.

When the fix lands, a short delta check is needed: the diff must match, and the simulation and ACL runs repeated. CI must also pass at the merge gate.
