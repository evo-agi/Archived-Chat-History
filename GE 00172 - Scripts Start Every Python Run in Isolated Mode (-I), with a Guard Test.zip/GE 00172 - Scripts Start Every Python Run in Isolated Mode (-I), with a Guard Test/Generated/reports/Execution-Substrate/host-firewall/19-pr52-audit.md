# 19: Audit of ES PR #52 at f862eb2 (every Python run in scripts/ in isolated mode)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 10:50Z.
Verdict: **BLOCK**, on three Low items. The fix is ready: `19-pr52-audit-fix.diff`, tested.

## Plain summary (for relaying)

- **The change is right.** All 260 changed lines in 39 scripts differ only by the added `-I`. No script needs anything that `-I` turns off. On trunk_dev the new guard flags exactly those 260 lines.
- **The sync with #50 is clean.**
  - The one conflict keeps both sides.
  - The PR's lines and trunk's lines are each unchanged.
  - The manifest `c636312b…04c6` reproduces.
- **Tests match trunk_dev:**
  - the full scripts suite has the same 200 environment failures on both;
  - the launcher and ARS storage tests pass with Docker;
  - the supported-local tests pass as an unprivileged user.
- **The new ACL hook works.** The "hook ran" marker is what makes those two cases meaningful. With the marker check removed and the old hook back, both cases pass with no hook at all.
- **Why BLOCK.** Three small items. The project fixes Low items in the PR, and one of them is a real hole in the guard:
  - **A52-1 (guard).** An allowed line covers every identical line in its file. So a new Python run in `70_linux_setup.sh` that starts with a line reading just `python3 \` passes the guard without `-I`. I checked this with a probe.
  - **A52-2 (docs).** The docs and the test comment say Python reads `PYTHONSTARTUP`. It does not for these runs; that variable applies only to interactive sessions.
  - **A52-3 (comment).** An es/app test comment still says "sitecustomize".
- **The fix.** One diff covers all three, 3 files, +34 −21. It applies cleanly to f862eb2.
  - Each allowed line must now appear exactly as many times as it is listed.
  - The probe that got through is now caught. Everything else passes.
- **Before merge.** Apply the fix and send it for a short delta check. CI on f862eb2 (run 45374241326) was still running at writing.
- Nothing was pushed or posted, and the box was not touched.

## 1. Target and provenance

| Item | Value |
|---|---|
| PR | https://github.com/evo-agi/Execution-Substrate/pull/52, open, ready for review |
| First target | `988dc6631a62298ad648183dde164e32bbdf23a2` on `claude/scripts-python-isolated`, base trunk_dev `3f1a84c` (#49). Manifest `511b39ff2a2d0172a3aeb2447c8dd2aaeeb87145556009386e16a05440f6460a` reproduced twice; textual_diff `dcb6775c…48a8`; diff byte-identical to the writer's `pr52.diff` (`fd57f249…0b77`). 45 files, +612 −296 |
| Final target | `f862eb2df80a42097edb6ff0b917b661db38edca`, a merge of 988dc66 and trunk_dev `8789662663190844b894638aa6fda6903a93b937` (#50). Tree `d5f32e00…`. Still the branch tip at 10:45Z, and trunk_dev still 8789662 |
| Manifest SHA-256 (f862eb2 vs 8789662) | `c636312b14d8c3d70927522c79dd671091ffc2aefe0bd50ec65e947ed50304c6`. Taken twice in a fresh clone (umask 022, branch at the head, reset to the base, upstream `origin/trunk_dev`); the closing run after all tests is equal. textual_diff `f060abc5…bf12`. 45 paths |
| Writer's report | `18-python-isolated-pr52.md`, SHA-256 `b225064e…519c` when I read it (before its section 6 was added) |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |

## 2. The sync with #50 (f862eb2)

- **Conflict.** `git show --remerge-diff f862eb2` shows one conflict, in `summary_field()` of `scripts/remote_alpha_reset_disposable_vault.sh` (`remerge-diff.txt`).
  - #50 added `remote_alpha_prepare_output_dir` and its comment before the Python run, and this PR added `-I` to that run.
  - The resolution keeps both.
- **The PR's lines.** For all 45 PR files, the added and removed lines (`-U0`) of `3f1a84c..988dc66` equal those of `8789662..f862eb2`.
- **Trunk's lines.** For all 22 files #50 touched, the added and removed lines of `3f1a84c..8789662` equal those of `988dc66..f862eb2`.
- **Changed paths.** f862eb2 differs from trunk_dev in exactly the PR's 45 paths.
- **#50's new Python runs.** All 14 already use `-I`. At f862eb2 the guard passes with no new allowlist entry.

## 3. Review

**The 260 script lines.** My `linecheck.py` pairs every removed line with its added line in the 39 non-test script files. Every pair is equal once the inserted `-I` is removed: 250 shell runs, 1 Python list (`73_supported_local_proof.sh`) and 9 shebangs. Nothing else changed, at 988dc66 and at f862eb2.

**Does `-I` change anything a script needs?** I checked what `-I` turns off.

- **The script's folder on `sys.path`** (for a file run).
  - All 13 Python files import only the standard library. No script touches `sys.path`.
  - The one file that loads another (`test_supported_local_execution_roots.py`) does it by path through `importlib.util`, which `-I` does not affect.
  - The `-m` runs are `json.tool` and `http.server`, both standard.
- **`PYTHON*` variables.** No non-test script sets or relies on one. The only mentions are the printed Infrastructure Manager commands, which are exceptions.
  - Every test that sets `PYTHONDONTWRITEBYTECODE` also passes `-B` to its own Python. Those runs are in Go test files, which the PR does not change.
  - In the scripts, `-I` makes Python ignore that variable, but no script imports a module file that would leave a cache. `__pycache__/` is in `.gitignore`.
- **User site-packages.** Nothing relies on it.
- **The shebang.** `#!/usr/bin/env -S python3 -I` needs `env -S`, which GNU coreutils has had since 8.30 (the box runs Ubuntu 24.04, coreutils 9.4) and BSD/macOS `env` also has. Every caller starts these files as `python3 -I <file>`, and only `canonicalize_json.py` is executable. So the shebang only matters for a run by hand.
- **Runs through a variable.** The two runs through a resolved interpreter path (`"${resolved}"` and `"${recovery_session_p0v_python3_path}"` in `remote_alpha_operator.sh`) already had `-I`.

**The guard** (`scripts/python_isolated_mode_test.go`):

- **What it does.**
  - It walks every regular file under `scripts/` except Go test files (no symlinks exist there).
  - It finds every word `python`, `python3` or `python3.N`, and requires `-I` as the first option, or `"-I"` as the next item in a list.
  - The only exceptions are `command -v`, `*require_command(s)` and exact lines from a list. Each listed line has its reason.
  - A floor of 50 files and 200 isolated runs stops an empty walk from passing.
- **On trunk_dev.** With the guard copied onto `8789662`, it flags exactly the 260 lines the PR changes (`guard/`). The sets are identical. It also reports the one allowlist line the base lacks, and the floor (34 isolated runs).
- **Probes.** I tried 11 changes against the head (`probes/guard_mutants*.py`).
  - **Caught:** a run that loses `-I` (G1), `-B -I` order (G2), the shebang put back (G3), a list without `"-I"` (G4), a stale allowlist entry (G5), `sudo -n env -i python3 -` (G7), and a non-test Go helper under `scripts/` running `python3 -c` (G8).
  - **Not caught: G6 (A52-1).** A new non-isolated run whose first line equals the allowed apt line `python3 \`. The second line is `-c 'print(1)'`.
  - **Not caught: G11.** One of the two identical `printf 'PYTHONPATH=src python3 …'` lines removed. This is the same cause as G6: the stale-entry check is only "found at least once".
  - **Not caught, limits of a text check (see O19-1):** G9, a run through a resolved interpreter variable that drops its `-I`, and G10, a child started with `sys.executable`.

**The es/app test changes:**

- **Fakes.**
  - The supported-local and launcher fakes now match `-I <helper>` and `-I -m http.server`, and read the helper's arguments one position later.
  - The recorded-call pins (`sudo -n python3 -I … provision`, `bind -I …`) include `-I`.
  - No other fake python3 dispatches on its arguments. The one in `scripts/remote_alpha_runtime_security_boundary_check_test.go` only forwards `"$@"`.
- **The ACL hook.**
  - `writeTestPythonHook` now builds a minimal virtual environment: `bin/python3` links to the real interpreter, with `pyvenv.cfg` beside `bin`. The hook loads through a `.pth` file in that environment's site-packages, and `-I` still reads those.
  - The hook writes a marker file, and each case requires it.
  - The hook mutants were run with Docker (`probes/hook_mutants.py`):

| Mutant | Result |
|---|---|
| H1 the hook loaded through `PYTHONPATH`, as at trunk_dev (marker write kept) | killed: both ACL cases fail, "the … python hook did not run in the launcher's python3" |
| H2 `pyvenv.cfg` not written, so python3 is not in a virtual environment | killed, same message |
| H3 as H1, with the marker check removed | survives: both cases pass with no hook. So the marker check is what makes these cases mean anything under `-I`. This confirms the writer's reason for the change |

**The docs.** The new section "Python In The Scripts" sits before "Non-Goals", and the firewall docs pin now ends at it. The section says Python "reads `PYTHONPATH`, `PYTHONSTARTUP` and the user's site-packages". That is inaccurate for these runs (A52-2).

## 4. Tests at f862eb2

Every run had its signals reset to default. Root unless stated. Test binaries were built from worktrees at f862eb2 and 8789662. Logs and result lists are in `19-pr52-audit-evidence/logs/`.

The full-suite logs are kept only as result lists. Two test subtest names are synthetic secret-like strings from the repository's redaction tests, and they are redacted in those lists.

| Run | f862eb2 | trunk_dev 8789662 |
|---|---|---|
| Guard and docs tests (`TestScriptsStartPythonInIsolatedMode`, `…CheckFindsEachForm`, `…Docs`) | 3 pass | n/a |
| `internal/testutil` (#39's layout checks) | 6 pass | n/a |
| Root package (docs tests) | 604 pass, 0 fail | n/a |
| `scripts`, full | 1968 pass, 200 fail, 10 skip | 1965 pass, 200 fail, 10 skip |
| | The failure sets are identical. The 3 extra passes are the new guard tests. The failures are this container's environment: the en_US.UTF-8 locale is missing, plus the fake-sudo-as-root and TLS operator fixtures seen in 15 and 16 | |
| es/app tests of the 3 changed files, no Docker | 236 pass, 5 fail, 53 skip | the same; identical result lists. The 5 failures need a Nomad agent or a non-root caller |
| es/app supported-local roots, full-readiness and launcher tests, unprivileged (`ci`) | 44 pass, 0 fail | 44 pass. This runs the provisioning-transport tests whose `-I` expectations changed; as root they stop before that point |
| es/app launcher and ARS storage tests with Docker 29.10 | 81 pass, 0 fail, 17 skip, both ACL hook cases included | the same; identical result lists |
| `gofmt -l`, `go vet ./scripts/ ./es/app/` | clean | |

## 5. Findings

**A52-1 (Low). The exact-line allowlist covers every identical line in its file.**

- `nonIsolatedPythonRuns` skips any line equal to an allowed line, and the stale-entry check only asks that each entry be found once.
- So in `scripts/70_linux_setup.sh`, which runs as root, a new run starts Python without `-I` and the guard passes, if its first line is just `python3 \`. Probe G6 shows this with `python3 \` followed by `  -c 'print(1)'`.
- Probe G11 shows the same cause from the other side: dropping one of the two identical printed Infrastructure Manager lines goes unnoticed.
- **Fix:** list a line once for each time it occurs, and require the file to hold it exactly that many times.

**A52-2 (Low). The docs and the guard's comment name `PYTHONSTARTUP`.**

- Python reads `PYTHONSTARTUP` only in an interactive session. None of these runs is interactive (`pythonstartup-check.txt` shows a startup file is not run for `python3 -`, `-c` or a file).
- The accurate statement is `PYTHONPATH`, the other `PYTHON*` variables and the user's site-packages.
- The commit message and report 18 say the same thing, but those are not in the tree.

**A52-3 (Low). A stale comment.** The `pythonHook` field comment in `es/app/service_launchers_container_user_test.go` still says the hook is "a sitecustomize". `writeTestPythonHook` now uses a virtual environment's site-packages.

**The fix:** `19-pr52-audit-fix.diff`, SHA-256 `94c806bfad58aa64921bd32737402e326545ee5791b19d58edebc003165273f8`. 3 files, +34 −21. `git apply --check` is clean on f862eb2.

- **The guard.**
  - `used` becomes `seen`, a count per line. Each entry's listed count must equal the count in the file, with a message that says so.
  - The two printed Infrastructure Manager lines in `remote_alpha_operator.sh` are listed twice, since each occurs twice.
  - The comment explains the rule and drops `PYTHONSTARTUP`.
- **The docs.** The `PYTHONSTARTUP` wording is corrected, and one sentence is added: "A line that occurs more than once is listed once for each occurrence." The pinned sentences are unchanged.
- **The es/app comment** is updated.

Validated in a scratch worktree at f862eb2 (logs in `probes/out-fix/`):

- The guard, form and docs tests and the firewall docs pin pass. gofmt and vet are clean.
- G6 and G11 are now caught. G1 to G5, G7 and G8 are still caught.
- G9 and G10 still pass (O19-1).

## 6. Observations (no change needed)

- **O19-1. Limits of a text guard.**
  - A run through a variable that holds an interpreter path has no Python word, and neither does a child started with `sys.executable`.
  - Today there are two runs of the first kind, both with `-I`, and none of the second.
  - Optional hardening: treat `sys.executable` like a Python word in the guard.
- **O19-2. Python outside `scripts/`.**
  - `.examples/` (example workloads, their entrypoints and `package.sh`) starts `python3` without `-I`. These are run by a developer or inside a workload container, not as root helpers on the box.
  - `.github/ci/` already uses `-I`.
  - Out of this PR's scope.
- **O19-3. Order with #51.**
  - Once #51 merges, this branch must sync. #51's refusal test injects its `prctl` stand-in through a `PYTHONPATH` `sitecustomize`, and its helper will then run with `-I`. H3 shows such a case can pass with no hook.
  - So the sync must move that test to the virtual-environment hook with a marker check, as the writer plans. That sync gets its own delta check.
- **CI and Codex.**
  - Run 45372514999 on 988dc66 was cancelled when f862eb2 was pushed.
  - Run 45374241326 ("build, vet and test", job 138376212364) on f862eb2 started at 10:23Z and was in progress at 10:45Z. The merge gate requires it, or its successor on the fixed head.
  - Codex reviewed 988dc66 with no findings. It has not reviewed the merge commit.

## Effects

- Read-only, in private clones `/opt/audit/ES52` and `/opt/audit/ES52m` and worktrees under `/opt/audit/`. No commit, push, comment, PR change or merge. The box was not contacted.
- Started a local Docker daemon in this container for the ARS storage tests.
- Delivered:
  - this file;
  - `19-pr52-audit-fix.diff`;
  - `19-pr52-audit-evidence/`: manifests, remerge diff, guard sets on trunk_dev, probes and mutant output, logs and result lists, the `PYTHONSTARTUP` check.
- Scanned the evidence for token and key patterns: no matches, after redacting the two fixture subtest names.

## Verdict

**BLOCK** for head `f862eb2` (manifest `c636312b…04c6`), on A52-1, A52-2 and A52-3, all Low. Everything else in the PR is accepted:

- the 260 lines;
- the guard's design and its exact match on trunk_dev;
- the ACL hook and its marker;
- the #50 sync;
- the test results.

Apply `19-pr52-audit-fix.diff` (or an equivalent) and send the new head for a delta check. CI must pass at the merge gate.
