# 17: Delta check of ES PR #51 at 37b13fd (CI fix for #39's layout rule)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 10:05Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- **The fix.** Commit 37b13fd changes only the capability probe in one test file (+3 −1). The probe now builds its command as a variable and runs it from the repository root, as #39's layout rule requires. Its diff is byte-identical to the writer's `ci-fix-37b13fd.diff`.
- **Before and after.** The layout test that failed in CI fails at 669c796 here with the same message, and passes at 37b13fd.
- **Nothing else changed.** The bootstrap tests give the same counts as at 669c796, as root, as an unprivileged user, and on my simulated host without prctl.
- **I missed this in 16.** I did not run `internal/testutil`, the package that holds #39's layout checks. From now on, I run it in every audit of a PR that adds Go test code.
- **Before merge.** CI on 37b13fd was still running at writing, and the merge gate requires it. The sync with trunk_dev 3f1a84c (#49) still needs its own short delta check at #51's merge turn.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `37b13fd0587becf3a0d0ded5354100b1a6e3621f`, tip of `claude/project-thread-vmre16` at 10:02Z. Its single parent is `669c796` (accepted in 16). Tree `bc8f33a5dfb1475d28cb4d12a43bb3dd61f2836c` |
| Delta | `git diff 669c796 37b13fd` touches one file, `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go`, +3 −1. SHA-256 `277e0a8cd5774899263aef239ff5fbbfbf44ff7f8757bd9a75e4f479668fb30f`, byte-identical to the writer's `ci-fix-37b13fd.diff` |
| What changed | `exec.Command("python3", "-I", "-c", probe).CombinedOutput()` became a variable `probe` with `probe.Dir = executionSubstrateRepoRoot` (`= testutil.Root`, `scripts/helpers_test.go:17`). The probe script, its arguments, the caching and the skip reason are unchanged. Python runs with `-I`, so the working folder does not change what it imports |
| Manifest SHA-256 (37b13fd vs base f058d8a) | `fe2aa545d2900ae5d9e46f6d8fa09d5c4a6e8c872cbf00a7ad50192c9d04fb24`, taken twice in a fresh clone with identical output. Method as before: umask 022, branch at the head, reset to the base, upstream `origin/trunk_dev`. textual_diff `4da06673…50ec`. The same 4 paths as at 669c796; only the test file's entry differs |
| `gofmt -l` on the changed file, `go vet ./scripts/` | clean |

## Tests

Test binaries were built from the audit tree. Every run had its signals reset to default (`sigdfl.py`). Logs are in `17-pr51-delta-evidence/logs/`.

| Run | Result |
|---|---|
| `internal/testutil` (#39's layout and path checks) at 669c796, `TestImportersNameRepositoryPathsFromTheRoot` | FAIL: "scripts/remote_alpha_vault_workload_auth_bootstrap_test.go:72: exec.Command is not assigned to a variable whose Dir is set", the CI failure (`f-root-testutil-at-669c796.log`) |
| `internal/testutil`, whole package, at 37b13fd | PASS, 6 of 6 (`f-root-testutil.log`) |
| Bootstrap tests (real Vault 2.2.2 included), root | PASS: 87 pass, 0 fail, 2 skip, as at 669c796 (`f-root-bootstrap.log`) |
| The same, unprivileged (user `ci`, `env -i`) | PASS: 89 pass, 0 fail, 0 skip (`f-ci-bootstrap.log`) |
| The same on my simulated host without prctl (16's wrapper and shim) | PASS: 24 pass, 0 fail, 58 skip, as at 669c796. The four refusal subtests and the OS pin pass. The probe still skips both real-Vault tests before Vault starts (`…real_vault_test.go:300`, `:499`) (`f-noprctl-sim.log`) |

The mutants from 16 are not affected: they change the helper, and the helper is byte-identical (same manifest entry).

## CI

- Run 45364689146 on 669c796 failed in `internal/testutil` only. I did not read the CI log myself: the failure comes from the writer's relay, and I reproduced it here (above).
- Check run 138363446957 ("build, vet and test", run 45370555593) on 37b13fd started at 10:00:29Z and was in progress at 10:05Z. The repository requires it to pass before merge.

## Lesson

In 16 I ran the bootstrap tests, the scripts docs tests and the root package, but not `internal/testutil`. In round 10 the writer had run it. #39's layout checks scan every test file under `scripts/`, so any PR that adds Go test code there needs that package in its audit.

## Findings

None.

## Effects

- Read-only, in private clones `/opt/audit/ES51` and `/opt/audit/ES51b`. No commit, push, comment, PR change or merge. The box was not contacted.
- Delivered this file and `17-pr51-delta-evidence/`: logs, manifests, the delta diff and the signal-reset helper.
- Scanned the evidence for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `37b13fd` (manifest `fe2aa545…fb24`). Before merge:

- CI run 45370555593 must pass at the merge gate.
- The sync with trunk_dev `3f1a84c` (#49) needs a short delta check at #51's merge turn.
