# 22: Sync check of ES PR #51 at 0a00f2a (trunk_dev 2c6847a merged)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 13:00Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- **A plain merge.** The sync is git's own merge of 37b13fd (accepted in 17) and trunk_dev 2c6847a, with no hand edit: the commit's tree equals `git merge-tree` of the two.
- **Nothing in #51 changed.** Its lines in all 4 files are identical to before, and trunk's lines in all 47 files trunk touched are identical too.
- **The manifest reproduces:** `13796af9…6934`.
- **#49, #50, #45 and #30 don't touch #51's fix.** In the merged helper, the core dump step still runs first, before the config, the prompts or any secret. #49's new file reads come after it, and neither helper file names an operating system.
- **Tests at the head:**
  - as root, 178 pass and 5 skip (IPv6 subtests and the two non-root-only tests);
  - unprivileged, 89 of 89 pass;
  - my simulated host without prctl has 0 failures;
  - the layout checks (6) and the docs package (608) pass.
- **Before merge:** CI on 0a00f2a (run 45396725951) was still running at writing, and the merge gate requires it.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `0a00f2aba7d5b72f48cfc86facec95ad9da8da36`, tip of `claude/project-thread-vmre16` at 12:58Z. Parents `37b13fd` (17 ACCEPT) and trunk_dev `2c6847a3df0cb4f31068e5e7fb067d07b67c1eb3`, still trunk_dev at 12:58Z |
| Plain merge | `git merge-tree --write-tree 37b13fd 2c6847a` = `c0317ef490d74d7195dd85fa44946f6dffc977e5`, equal to the head's tree. No conflict and no hand edit |
| trunk since f058d8a | #49 `3f1a84c`, #50 `8789662`, #45 `230954d`, #30 `2c6847a` (47 files) |
| The PR's lines | For all 4 PR files, the added and removed lines (`-U0`) of `f058d8a..37b13fd` equal those of `2c6847a..0a00f2a` |
| Trunk's lines | For all 47 files trunk changed, the added and removed lines of `f058d8a..2c6847a` equal those of `37b13fd..0a00f2a` |
| Changed paths | 0a00f2a differs from trunk_dev in exactly the PR's 4 paths. trunk touched two of them, the helper (#49) and the Remote Alpha docs |
| Manifest SHA-256 (0a00f2a vs 2c6847a) | `13796af95ee7b25f52d812bb0481a29d10bbc132bd2db94afeefa72442da6934`. Taken twice in a fresh clone (umask 022, branch at the head, reset to the base, upstream `origin/trunk_dev`); the closing run is equal. textual_diff `d6384ea5…0ca0`. 4 paths. The two test files' entries equal those at 37b13fd; the helper and docs entries differ only because trunk changed those files |
| `gofmt -l` on the two test files, `go vet ./scripts/` | clean |

## Cross-PR reading

- **Order in the merged helper.** `main()` runs the summary preflight, then `disable_core_dumps()` and its refusal handling. Only then come the choice checks, the config preflight, `load_config()`, the SPIRE bundle read and the prompts.
  - #49's `read_regular_file_no_follow()` is used in `preflight_temporary_generate_root_access()` and in the Vault config reload's enable and restore. All of them run after the core dump step.
  - `disable_core_dumps()` is unchanged: limit and read-back, prctl lookup, set, read-back, each failure raising `ProcessStillDumpable`.
- **No OS name.** Neither helper file contains any of the nine strings the pin forbids, and `TestRemoteAlphaVaultWorkloadAuthBootstrapDoesNotBranchOnTheOperatingSystem` passes.
- **#30's new CI root step.** "Listed tests pass as root" runs only the tests that `environment-only-tests.txt` marks `skips-itself` for the root step (the TLS status collector's PID-namespace tests). None is a #51 test, and on the Linux runner the probe passes, so no new test skips. The list needs no change.
- **#52 is not in trunk yet.** So the helper still starts Python without `-I` here, and #51's refusal test still loads its stand-in through `PYTHONPATH`. When #52 syncs after #51 merges, that test must move to the virtual-environment hook with a marker check (20, O19-3).

## Tests at 0a00f2a

The test binary was built from a worktree at 0a00f2a. Every run had signals at default. Logs are in `22-pr51-sync-check-evidence/logs/`.

| Run | Result |
|---|---|
| Bootstrap (real Vault 2.2.2 included), firewall, output-dir and scripts docs tests, root | PASS: 178 pass, 0 fail, 5 skip. The skips are the 3 IPv6 firewall subtests (no IPv6 kernel here) and the 2 bootstrap tests that need a non-root user (`t-root.log`) |
| Bootstrap tests, unprivileged (user `ci`, `env -i`) | PASS: 89 pass, 0 fail, 0 skip (`t-ci-bootstrap.log`) |
| Bootstrap tests on my simulated host without prctl (16's wrapper and shim) | PASS: 24 pass, 0 fail, 58 skip, the same as at 669c796 and 37b13fd. The four refusal subtests and the OS pin pass (`t-noprctl-sim.log`) |
| `internal/testutil` (#39's layout checks) | PASS: 6 (`t-testutil.log`) |
| Root package (docs tests, including #45's change) | PASS: 608, 0 fail (`t-root-package-results.txt`) |

These counts equal the writer's in `21-pr51-sync.md` (SHA-256 `fe65f755…10a3` when I read it).

## CI

Check run 138454362356 ("build, vet and test", run 45396725951) on 0a00f2a started at 12:46:15Z and was in progress at 12:58Z. It includes #30's root step. The repository requires it to pass before merge.

## Findings

None.

## Effects

- Read-only, in private clones `/opt/audit/ES51` and `/opt/audit/ES51s` and a worktree. No commit, push, comment, PR change or merge. The box was not contacted.
- Delivered this file and `22-pr51-sync-check-evidence/`: manifests, logs and the docs-package result list.
- Scanned the evidence for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `0a00f2a` (manifest `13796af9…6934`), subject to CI run 45396725951 passing at the merge gate.
