# 18: PR #52, every Python run in scripts/ starts in isolated mode (O16-2)

Writer: the PR #35 writer thread. Date: 2026-11-24, about 10:20Z.
Update 10:57Z: audit 19 (BLOCK, three Low items) is fixed at head `7b911de`, section 7.
For the auditor: a full audit of PR #52, head `988dc6631a62298ad648183dde164e32bbdf23a2`, base trunk_dev `3f1a84c8e637dbd233f43f1a0ce20aaae8033720`. #50 merged while this was going out, so the branch now also has a clean-up merge with trunk_dev `8789662` (head `f862eb2`, section 6); the PR's own changed lines did not change.

## Plain summary (for relaying)

- **What.** Every Python run that a script under `scripts/` starts now uses `python3 -I`: 260 runs in 39 files. The nine Python files start with `#!/usr/bin/env -S python3 -I`.
- **Why.** Without `-I`, Python puts the current folder (or the script's folder) first on its import path and reads `PYTHONPATH`, the other `PYTHON*` variables and the user's site-packages. A root run started from a folder another account can write would then import that account's `base64.py` in place of the standard module. The auditor showed this with a planted file (audit 16, O16-2).
- **Guard.** A new test fails on any mention of Python under `scripts/` that is not followed by `-I`. The only exceptions are mentions that run nothing, each listed with its reason. At trunk_dev the guard flags exactly the 260 lines this PR changes, no more and no fewer.
- **Tests that leaned on the old behaviour.** The es/app fakes now expect `-I` first. The two ARS storage ACL cases loaded their hook through `PYTHONPATH`, which `-I` ignores, so they would have passed with no hook. The hook now loads in a way `-I` still honours, and each case checks that it ran. With the old hook put back, both cases fail.
- **Results.** Every failure set matches trunk_dev in the same container. CI runs on the push.
- **Scope.** Scripts, tests and one docs section. The box is untouched.
- **Order.** It merges after #51. When #51 lands, this branch syncs and moves #51's refusal test to the same hook, since #51's helper will run with `-I` too.

## 1. Target

| Item | Value |
|---|---|
| PR | https://github.com/evo-agi/Execution-Substrate/pull/52 (ready for review) |
| Head | `988dc6631a62298ad648183dde164e32bbdf23a2`, one commit on `claude/scripts-python-isolated` |
| Base | trunk_dev `3f1a84c8e637dbd233f43f1a0ce20aaae8033720` (#49 squash) |
| Recipe | v2, SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` |
| Manifest SHA-256 | `511b39ff2a2d0172a3aeb2447c8dd2aaeeb87145556009386e16a05440f6460a`, taken twice with identical output. Method as before: fresh clone of the pushed head, reset to the base, upstream `origin/trunk_dev` |
| textual_diff_sha256 | `dcb6775c94574acfe8449e395282163cb8419f4c17acbe0b84e47c9bd33848a8` |
| Diff | `18-python-isolated-evidence/pr52.diff`, SHA-256 `fd57f249…0b77`. 45 files, +612 −296 |

## 2. The finding

Audit 16 of #51 recorded O16-2: about 29 scripts started Python without isolated mode. The full count is 260 runs in 39 files. The scripts' own Python imports only the standard library, and none of them relies on a `PYTHON*` variable, so `-I` changes nothing a script needs.

The coordinator's brief (09:38Z): `-I` on every Python run in scripts, plus a CI guard that fails on any new run without it, as its own scripts PR, merged after #51.

## 3. Changes

### 3.1 Scripts

- `python3` became `python3 -I` in 260 places across 39 files. That covers every `-`, `-c`, `-m`, `/dev/fd/3`, file and heredoc run, and the `sudo -n python3`, `exec python3` and `VAR=… python3` forms. `-I` is always the first option.
- `scripts/73_supported_local_proof.sh`, the one run started from Python: `subprocess.run(["python3", "-I", projector, ...])`.
- The nine `.py` files under `scripts/` with a Python shebang now start with `#!/usr/bin/env -S python3 -I`. Every caller already starts them as `python3 -I <file>`, and only `canonicalize_json.py` is executable, so the shebang only covers a direct run by hand.
- Lines that name Python but run nothing are unchanged: the apt package `python3 \` in `70_linux_setup.sh`, the `python:3.13-alpine` image name, the summary field `"python"`, the error message `python3 is required`, the remote interpreter constant `REMOTE_PYTHON = "/usr/bin/python3"` (always followed by `-I -S -B`), and the Infrastructure Manager commands printed for the operator to run on the Mac. Those need `PYTHONPATH=src`, which `-I` would ignore, and run that repository's code, not these scripts.

### 3.2 Guard: `scripts/python_isolated_mode_test.go` (new)

- **`TestScriptsStartPythonInIsolatedMode`** walks every regular file under `scripts/` except Go test files. A mention is any word `python`, `python3` or `python3.N` (word boundaries include `_`, `.`, `-` and alphanumerics, so `PYTHONPATH`, `pythonic` and `mypython3` are not mentions). Each mention must be followed by:
  - ` -I` and then the end of the line, a space, a tab, a quote or a backslash (so `-Im` and `-IB` do not count), or
  - `", "-I"` or `', '-I'` (a Python or Go list).
- **Exceptions**, all for mentions that run nothing:
  - an argument to `command -v`;
  - an argument to a function whose name ends in `require_command` or `require_commands`;
  - exact lines in `pythonMentionsThatRunNothing`, by file, each with a comment giving the reason. Every listed line must still be found, so the list cannot keep a line that has gone.
- **Sanity floor.** The walk must see at least 50 files and 200 isolated runs, so a walk that finds nothing cannot pass. At the head it sees 87 files.
- **`TestScriptsPythonIsolatedModeCheckFindsEachForm`** runs the check on 15 lines it must flag and 17 it must accept. The flagged lines include `-B -I` (not first), `-Im`, `python3.12`, `python`, a plain shebang, a list without `"-I"`, and `require_command python3 && python3 - <<'PY'` (the run after the `require_command` is still flagged).
- **`TestScriptsPythonIsolatedModeDocs`** pins the new docs section.

### 3.3 Docs

`.docs/system_overview/remote_supported_host_alpha.md`: new section "## Python In The Scripts" before "## Non-Goals". It states the rule, the shebang form, why (the import path and the planted module), the guard, and that the exceptions are listed in the test with their reasons. `scripts/remote_alpha_host_firewall_test.go` now ends its docs section at the new heading.

### 3.4 Tests that relied on non-isolated Python

- **es/app fakes.** `supported_local_execution_roots_test.go` and `es_launcher_container_user_test.go` faked `python3` by its first argument. They now require `-I` first, then the helper path, and read the helper's arguments from `$3`. The `http.server` fakes match `-I -m http.server`. The supported-local pins and recorded calls now include `-I`.
- **ARS storage ACL hook cases** in `service_launchers_container_user_test.go` ("…where Python cannot read ACLs" and "…where reading an ACL fails"). At trunk_dev the hook was a `sitecustomize.py` loaded through a `PYTHONPATH` wrapper. Under `-I` that file is never read, so both cases would pass with no hook at all.
  - `writeTestPythonHook` now builds a minimal virtual environment: `bin/python3` is a link to the real interpreter, `pyvenv.cfg` sits beside `bin` (`include-system-site-packages = false`), and `lib/pythonX.Y/site-packages/es_test_python_hook.pth` imports the hook module. `-I` still reads a virtual environment's own site-packages.
  - The hook module first writes a marker file, then applies the hook. Each case fails with "the … python hook did not run in the launcher's python3" if the marker is missing.

## 4. Validation

Cloud container, Linux, as root, with SIGINT at its default. Each failure set is compared with trunk_dev `3f1a84c` in the same container. The head runs used a worktree whose tree is identical to `988dc66` (tree `2c344867…`). Logs are in `18-python-isolated-evidence/validation/`.

| Run | trunk_dev | Head |
|---|---|---|
| Guard on trunk_dev (the final test file copied onto the base) | fails on 260 lines, plus the floor (20 isolated runs) and one allowlist line the base lacks | n/a |
| Lines flagged at trunk_dev vs lines this PR changes in `scripts/` (non-test) | 260 and 260, identical sets (`guard-flagged-lines-at-trunk_dev.txt`, `changed-lines-at-trunk_dev.txt`) | |
| `es/app`, full, no Docker | 571 pass, 14 fail, 97 skip | 571 pass, 14 fail, 97 skip; the same 14 (Nomad and privilege environment) |
| `es/app`, full, with Docker | 604 pass, 14 fail, 64 skip | 604 pass, 14 fail, 64 skip; the same 14 (`es_app-docker-*.fails`) |
| Launcher container tests with Docker (`TestESLauncherContainerUser`, `TestServiceLaunchersContainerUser`) | 68 pass, 17 skip | 68 pass, 17 skip |
| Mutant H1: the trunk_dev `PYTHONPATH` hook put back (marker kept) | n/a | both ACL cases fail, "the … python hook did not run" (`mutant-h1-pythonpath-hook.log`) |
| `scripts`, full | 1949 pass, 200 fail, 10 skip | 1952 pass, 200 fail, 10 skip; the same 200 (`scripts-*.fails`); the 3 extra passes are the new guard tests |
| `scripts` subset `TestScripts\|TestRemoteAlphaHostFirewall\|TestRemoteAlphaVaultWorkloadAuthBootstrap\|TestLinuxSetup\|Doc` | | 162 pass, 0 fail, 5 skip |
| Root package (docs tests) | 604 pass | 604 pass; identical result lists |
| `internal/testutil` | | ok |
| `gofmt -l`, `go vet` on the changed packages | | clean |

The 200 `scripts` failures at trunk_dev are host problems in this container (en_US.UTF-8 locale missing, fake sudo as root, TLS-status operator fixtures, no `/usr/bin/ssh`), as in reports 15 and 16.

One fault found and fixed before the push: the first rewrite also turned the apt package line `python3 \` into `python3 -I \`, which broke `TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup`. It was put back and listed as an exception.

**CI.** Run 45372514999 on `988dc66` was cancelled by the sync push, and run 45374241326 on `f862eb2` by the audit 19 fix push. The run that counts, 45379479081 on `7b911de`, passed at 11:36Z.

## 5. Effects

- New branch `claude/scripts-python-isolated` from trunk_dev `3f1a84c`, one commit pushed.
- PR #52 opened as ready for review, so Codex reviews it before merge. The thread watches its activity.
- No PR comment and no merge. The box was not contacted.
- **Order with #51.** #51 changes `remote_alpha_vault_workload_auth_bootstrap.sh`, which this PR also touches (two runs gain `-I`), and #51's refusal test injects its `prctl` stand-in through a `PYTHONPATH` `sitecustomize`. After both land, the helper runs with `-I` and that injection would no longer load. So when #51 merges, this branch syncs with trunk_dev and moves that test to the virtual-environment hook, with a marker check like the ACL cases. That sync gets its own delta check.

## 6. Sync with trunk_dev 8789662 (#50)

#50 merged into trunk_dev at about 10:15Z and GitHub reported a conflict. I merged trunk_dev into the branch (no rebase): head `f862eb2df80a42097edb6ff0b917b661db38edca`, parents `988dc66` and `8789662663190844b894638aa6fda6903a93b937`.

| Item | Value |
|---|---|
| Conflict | One, in `scripts/remote_alpha_reset_disposable_vault.sh` `summary_field()`. #50 added the artifact-folder check before the Python run; this branch added `-I` to that run. Both are kept (`sync-8789662/conflict-resolution.diff`) |
| The PR's changed lines | Identical before and after the sync: the `+`/`-` lines of `pr52.diff` and of `sync-8789662/pr52-after-sync.diff` match exactly; only hunk positions moved (`changed-lines-compare.txt`) |
| #50's own Python runs | Its 14 new runs (the copied `remote_alpha_prepare_output_dir` function) already use `python3 -I`; the guard passes with no new allowlist entry |
| Manifest at `f862eb2` vs `8789662` | SHA-256 `c636312b14d8c3d70927522c79dd671091ffc2aefe0bd50ec65e947ed50304c6`, taken twice with identical output; textual_diff_sha256 `f060abc58afdf403921a4f72f7059786fda3239288a4b8cb4248ac55f668bf12`; 45 files |
| Root package (docs tests) at `f862eb2` | 604 pass, 0 fail |
| `scripts` subset `TestScripts\|TestRemoteAlphaOutputDir\|TestRemoteAlphaHostFirewall\|TestRemoteAlphaVaultWorkloadAuthBootstrap\|TestLinuxSetup\|Doc` at `f862eb2` | 172 pass, 0 fail, 5 skip |
| `es/app` | #50 touches no file that `es/app` tests read, so the runs in section 4 stand |

PR #51 still merges cleanly with trunk_dev `8789662` (checked with `git merge-tree`).

## 7. Fixes for audit 19 (head 7b911de)

Audit 19 (`19-pr52-audit.md`) blocked `f862eb2` on three Low items and accepted the rest. One commit fixes them: `7b911defe52cbaf3baed233727d65932a24c7bfa` on `f862eb2`.

- **A52-1, A52-2, A52-3.** The auditor's `19-pr52-audit-fix.diff` (SHA-256 `94c806bf…73f8`) is applied as is:
  - each allowed line is listed once per occurrence, and the file must hold it exactly that many times;
  - the two printed Infrastructure Manager lines are listed twice;
  - the docs and the guard comment say "`PYTHONPATH`, the other `PYTHON*` variables and the user's site-packages" in place of `PYTHONSTARTUP`;
  - the es/app `pythonHook` comment describes the virtual-environment hook.
- **O19-1, the optional hardening, taken.** A child started with `sys.executable` does not inherit `-I`. The guard now requires `"-I"` as the next item after every `sys.executable` under `scripts/` (there are none today). The form test gains 3 flagged and 3 accepted lines, and the docs gain one sentence. The pinned sentences are unchanged.
- **What goes beyond the auditor's diff.** `fix-19/beyond-auditor-fix.diff` is the diff from "f862eb2 plus the auditor's diff" to `7b911de`. It holds only the `sys.executable` check, its form-test lines, the guard comment and the docs sentence.

| Item | Value |
|---|---|
| Delta | `fix-19/delta-f862eb2-7b911de.diff`, SHA-256 `b2dab21f…b006`; 3 files, +85 −28 |
| Manifest at `7b911de` vs trunk_dev `8789662` | SHA-256 `e782ec30e047652a9b3efc993c3da8d9f96df4053326e430991b96f391e801d1`, taken twice with identical output; textual_diff_sha256 `d75d5e3b72996534b8481d8247656fc61fcaa3709872447b6fc0dd00fd74ee51`; 45 files |
| Guard probes (`fix-19/probes.txt`) | G6 and G11 are now caught. A child started with `sys.executable` and no `-I` is caught, and the same with `-I` passes |
| `scripts` subset (guard, output-dir, firewall, bootstrap, Linux setup, docs) | 172 pass, 0 fail, 5 skip |
| Root package (docs tests) | 604 pass, 0 fail |
| `internal/testutil`, `TestServiceLaunchersContainerUser` | ok |
| `gofmt -l`, `go vet ./scripts/ ./es/app/` | clean |
