# 20: Delta check of ES PR #52 at 7b911de (audit 19 fixes plus the sys.executable check)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 11:10Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- **My fix landed unchanged.** The writer's commit 7b911de contains my `19-pr52-audit-fix.diff` byte for byte, which closes A52-1, A52-2 and A52-3.
- **The writer also took optional point O19-1.** The guard now also checks children that Python starts with `sys.executable`: `"-I"` must be the next item of the argument list. There are none today. I reviewed that addition and probed it.
- **Probes.**
  - The two probes that got through in 19 are now caught.
  - A `sys.executable` child without `-I` is caught, and so is one kept in a variable first.
  - An isolated child passes.
  - Every probe that was caught before is still caught.
- **Tests.** The guard, form and docs tests pass, as do the scripts subset (162 pass, 5 skip), the layout checks (6) and the docs package (604). gofmt and vet are clean.
  - The delta touches only the guard test, one docs paragraph and one es/app comment. So my full-suite and Docker results at f862eb2 in 19 still stand.
- **Before merge.**
  - CI has not finished on this PR yet. Run 45379479081 on 7b911de started at 10:56Z, and the merge gate requires it.
  - The sync after #51 merges needs its own delta check.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `7b911defe52cbaf3baed233727d65932a24c7bfa`, tip of `claude/scripts-python-isolated` at 11:00Z. Single parent `f862eb2` (audited in 19). Tree `88a62b52…`. trunk_dev still `8789662` |
| My fix | I applied `19-pr52-audit-fix.diff` to f862eb2 in a scratch worktree, then diffed that tree against 7b911de. The difference contains only the writer's additions, and none of my lines is reverted. That difference is byte-identical to the writer's `fix-19/beyond-auditor-fix.diff` (SHA-256 `0ecec243…a06`) |
| Whole delta | `git diff f862eb2 7b911de` touches 3 files (+85 −28) and is byte-identical to the writer's `delta-f862eb2-7b911de.diff` (SHA-256 `b2dab21f…b006`) |
| Manifest SHA-256 (7b911de vs 8789662) | `e782ec30e047652a9b3efc993c3da8d9f96df4053326e430991b96f391e801d1`. Taken twice in a fresh clone (method as in 19); the closing run is equal. textual_diff `d75d5e3b…ee51`. The same 45 paths as at f862eb2; only the entries of the 3 delta files differ |
| `gofmt -l`, `go vet ./scripts/ ./es/app/` | clean |

## The writer's addition (sys.executable)

- **`pythonExecutableWords`** finds `sys.executable` with the same word boundaries as the Python words. So `my_sys.executables` is not a match.
- **The required follow-on.** It must be followed by `, "-I"` or `, '-I'`, with optional spaces (`pythonExecutableIsolated`).
- **Counting and errors.** A line with any failing word is reported once. Isolated children count toward the floor.
- **Self-test.** The form test gained 3 lines it must flag and 3 it must accept. That includes a line with one isolated and one non-isolated child, which is flagged.
- **Docs.** The paragraph gained one sentence after the pinned guard sentence. The pinned sentences are unchanged, and `TestScriptsPythonIsolatedModeDocs` passes.

## Probes at 7b911de

The probes are `probes/guard_mutants2.py`, run against a binary built from 7b911de, with the tree restored afterwards (`probes/out/`).

| Probe | Result |
|---|---|
| G1 a run loses `-I`; G2 `-B -I`; G3 the shebang put back; G4 a list without `"-I"`; G7 `sudo -n env -i python3 -`; G8 a Go helper runs `python3 -c` | caught, as in 19 |
| G5 a stale allowlist entry | caught, with the new count message |
| G6 a new run whose first line is `python3 \` in `70_linux_setup.sh` (A52-1) | **now caught** ("listed 1 time(s), but the file has it 2 time(s)") |
| G11 one of the two identical printed Infrastructure Manager lines removed | **now caught** |
| G10 `subprocess.run([sys.executable, "-c", …])` | **now caught** |
| S4 `_py = sys.executable`, then a run of `_py` | caught (the assignment line is flagged) |
| S5 `[sys.executable,"-I","-c",…]` with no spaces | passes, as it should |
| G9 a run through a resolved interpreter variable without `-I` | not caught: a known limit of a text check. The two such runs today both use `-I` |
| S2 `from sys import executable`, then a run of it; S3 `os.sys.executable` | not caught: the same kind of limit, an aliased name. None exists today, and both would be unusual. I note it, and it needs no change |

## Tests at 7b911de

Logs are in `20-pr52-delta-evidence/logs/`. Root, with signals at default.

| Run | Result |
|---|---|
| `scripts` subset `TestScripts\|TestRemoteAlphaHostFirewall\|TestRemoteAlphaVaultWorkloadAuthBootstrap\|TestLinuxSetup\|TestRemoteAlphaPrepareOutputDir\|Doc` | 162 pass, 0 fail, 5 skip, including the 3 guard tests and the firewall docs pin |
| `internal/testutil` | 6 pass |
| Root package (docs tests) | 604 pass, 0 fail |

The delta changes no script, so 19's results for the rest still apply: the full scripts suite, the es/app tests with and without Docker, the unprivileged run and the hook mutants. The es/app file changed only in a comment, and `go vet` compiled it.

## CI

- Run 45374241326 on f862eb2 was cancelled at 10:56Z, when 7b911de was pushed. Run 45372514999 on 988dc66 had been cancelled the same way.
- No CI run on this PR has finished yet.
- Run 45379479081 ("build, vet and test", job 138394576960) on 7b911de started at 10:56:40Z and was in progress at 11:05Z. The repository requires it to pass before merge.

## Findings

None. A52-1, A52-2 and A52-3 are closed.

## Effects

- Read-only, in private clones and worktrees under `/opt/audit/`. No commit, push, comment, PR change or merge. The box was not contacted.
- Delivered this file and `20-pr52-delta-evidence/`: manifests, the delta and beyond-fix diffs, logs and the probe output.
- Scanned the evidence for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `7b911de` (manifest `e782ec30…01d1`). Before merge:

- CI run 45379479081 must pass at the merge gate.
- When #51 merges, the sync must move #51's `PYTHONPATH` refusal test to the virtual-environment hook with a marker check. That sync gets its own delta check.
