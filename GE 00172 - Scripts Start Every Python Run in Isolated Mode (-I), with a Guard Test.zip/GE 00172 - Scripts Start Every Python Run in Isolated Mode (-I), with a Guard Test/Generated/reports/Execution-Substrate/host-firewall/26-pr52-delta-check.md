# 26: Delta check of ES PR #52 at d7abaec (the A25-1 fix)

Writer of this report: the PR #35 audit thread (read-only). Date: 2026-11-24, about 14:25Z.
Verdict: **ACCEPT**

## Plain summary (for relaying)

- **My fix landed unchanged.** d7abaec is one commit on 072e6ac. Its delta is byte-identical to `25-pr52-sync-check-fix.diff`, which closes A25-1.
- **The manifest reproduces:** `71ff6a00…978c`, 46 paths. Compared with 072e6ac, only the entries of the two fixed test files differ.
- **The wrapper case now passes.** I used a pyenv-style python3 (a bash script that `exec`s the real interpreter) first on `PATH`:
  - **at 072e6ac**, #51's refusal test and all 5 of its subtests fail, `unchanged` included, and the 3 es/app ACL cases fail. That confirms the inference I left open in 25;
  - **at d7abaec**, all of them pass.
- **Other runs at d7abaec pass:** root, unprivileged, my no-prctl simulation, the es/app launcher tests with Docker, and the layout checks. gofmt and vet are clean.
- **Before merge:** CI on d7abaec (run 45411143459) was still running at 14:20Z, and the merge gate requires it. The run on 072e6ac was cancelled by the push.
- Nothing was pushed or posted, and the box was not touched.

## Checks

| Check | Result |
|---|---|
| Head | `d7abaecb0828d43bb6a2db1a65cc3ee5e28b2c8a`, tip of `claude/scripts-python-isolated` at 14:20Z. Single parent `072e6ac` (25). trunk_dev still `30b241d` |
| Delta = my fix | `git diff 072e6ac d7abaec` is byte-identical to `25-pr52-sync-check-fix.diff`, SHA-256 `197b8b6520ba29d50d87ae0158af3915ada0e4ff8b179c7da44587a3022201c4`. It is also equal to the writer's `24-pr52-sync-evidence/fix-25/delta-072e6ac-d7abaec.diff` |
| Same tree as tested in 25 | My 25 fix worktree (072e6ac plus the diff) has no difference from d7abaec |
| Manifest SHA-256 (d7abaec vs 30b241d) | `71ff6a00803faf8cdc76ec4c501b948f14bd40e0f5366f5c6bd026c77468978c`. Taken twice in a fresh clone (umask 022, branch at the head, reset to the base, upstream `origin/trunk_dev`); the closing run at 14:20Z is equal. textual_diff `5be9d503…f65`. The same 46 paths as at 072e6ac; only the entries of `es/app/service_launchers_container_user_test.go` and `scripts/remote_alpha_vault_workload_auth_bootstrap_test.go` differ |
| `gofmt -l scripts/ es/app/`, `go vet ./scripts/ ./es/app/` | clean |

## Tests

The binaries were built from a worktree at d7abaec, with signals at default. The 072e6ac rows use the binaries from 25. The result lists are in `26-pr52-delta-evidence/logs/`.

| Run | 072e6ac | d7abaec |
|---|---|---|
| Bootstrap tests, root, pyenv-style wrapper first on `PATH` (`probes/plain-wrapper-python3.sh`) | **81 pass, 6 fail, 2 skip**: the refusal test and its 5 subtests, `unchanged` included | 87 pass, 0 fail, 2 skip |
| Bootstrap tests on my no-prctl simulation (wrapper first) | 19 pass, 5 fail, 58 skip (25) | 24 pass, 0 fail, 58 skip |
| es/app ACL cases with Docker, real python3 | 3 pass, 3 skip (25) | 3 pass, 3 skip |
| es/app ACL cases with Docker, pyenv-style wrapper | **3 fail** | 3 pass, 3 skip |
| es/app ACL cases with Docker, no-prctl simulation wrapper | 3 fail (25) | 3 pass, 3 skip |

Other runs at d7abaec:

| Run | Result |
|---|---|
| Bootstrap, firewall, output-dir, guard and scripts docs tests, root | 181 pass, 0 fail, 5 skip: the same as 072e6ac. The skips are the 3 IPv6 subtests and the 2 non-root-only tests |
| Bootstrap tests unprivileged (user `ci`, `env -i`) | 89 pass |
| es/app `TestESLauncherContainerUser` and `TestServiceLaunchersContainerUser` with Docker | 68 pass, 0 fail, 17 skip |
| `internal/testutil` (#39's layout checks) | 6 pass |

The delta changes two test helpers only. So 25's results for the rest still apply: the merge checks, the root package (608), and the helper and hook mutants.

## CI

- Run 45405728557 on 072e6ac was cancelled at 14:10:44Z, when d7abaec was pushed.
- Run 45411143459 ("build, vet and test", check run 138505115464) on d7abaec started at 14:10:27Z and was in progress at 14:20Z. The repository requires it to pass before merge.
- The last finished run on this PR, 45379479081 on 7b911de, succeeded.

## Findings

None. A25-1 is closed.

## Effects

- Read-only, in a fresh clone `/opt/audit/ES52u` and a worktree `/opt/audit/ES52v`. No commit, push, comment, PR change or merge. The box was not contacted.
- Docker was started for the es/app runs and stopped afterwards.
- Delivered this file and `26-pr52-delta-evidence/`: manifests, the delta, result lists and the wrapper script.
- Scanned the evidence and the fix diff for token and key patterns: no matches.

## Verdict

**ACCEPT** for head `d7abaec` (manifest `71ff6a00…978c`), subject to CI run 45411143459 passing at the merge gate.
