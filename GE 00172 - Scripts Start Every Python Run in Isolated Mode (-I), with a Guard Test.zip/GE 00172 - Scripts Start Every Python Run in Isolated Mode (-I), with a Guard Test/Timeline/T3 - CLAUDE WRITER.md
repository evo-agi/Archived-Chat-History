Asked the project to choose an option

Where should long runs in this project go?

1. On GitHub, from a branch I push (recommended): Runs in the checks you already use, and results stay with the branch. May count toward your GitHub usage.
2. On your Mac: Your computer needs to stay on and have this repository.
3. In the cloud now: Starts right away, with nothing to set up.
4. In the cloud tonight: Starts this evening and is usually done by morning.

Why recommended: Runs in the checks you already use, and the results stay with the branch.
