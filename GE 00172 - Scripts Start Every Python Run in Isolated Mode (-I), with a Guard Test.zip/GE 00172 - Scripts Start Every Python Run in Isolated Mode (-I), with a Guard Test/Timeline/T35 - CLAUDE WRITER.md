PR #52 is merged into trunk_dev as `ed94a6b`. Every Python run in the scripts now starts in isolated mode (`-I`), and a guard test blocks new runs that don't.

- **Gate.** The merged head was `d7abaec`, the commit delta check 26 accepted, on an unchanged base `30b241d`. CI run 45411143459 passed, root step included.
- **After the merge.** trunk_dev's tree matches the checked head's tree, and all 46 changed files have the hashes in the manifest.

Per the quota plan, this thread stops here. Box run 4 waits until after Thursday's reset, and #53 is next in the merge queue.

STATUS: WAITING (box run 4 paused until after Thursday's reset)
