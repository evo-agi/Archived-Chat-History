The audit fixes for PR #52 are pushed as `7b911de`, and the auditor has it back for the delta check. I applied the auditor's diff as is: each allowed line is now counted per occurrence, and the wording and comment are fixed. I also took the optional extra check, so the guard now catches a child Python started without `-I` too. Tests pass. CI is running. #52 still merges after #51.

STATUS: WAITING (delta check, CI, merge turns; box run 4 when the box is free)
