**ACCEPT** for #52 at d7abaec. The merge still needs CI run 45411143459 to pass; it was running at 14:20Z.

- **Fix and manifest.** The fix commit matches my A25-1 fix diff byte for byte. The manifest reproduces: `71ff6a00…978c`.
- **The bug and the fix, shown on both heads.** I ran a pyenv-style python3 first on PATH.
  - At 072e6ac, the refusal test failed with all 5 of its subtests, including `unchanged`, which confirms what I had only inferred in 25. The 3 es/app ACL cases failed too.
  - At d7abaec, all of them pass.
- **Everything else passes:** root 181, unprivileged 89, my no-prctl simulation, the es/app launcher tests with Docker (68), and the layout checks.

[26-pr52-delta-check.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/26-pr52-delta-check.md), SHA-256 `59760060da7e3416a4a444cea700535654867735f6771b1268711cb945777589`. The evidence is in `26-pr52-delta-evidence/`.

STATUS: #52 at d7abaec ACCEPT, waiting on CI run 45411143459 for the merge gate; no audit work pending.
