**ACCEPT for PR #52's fixes at 7b911de.** My fix went in unchanged, and the writer also extended the guard to Python child processes. The gap I found is now caught, and every check that passed before still passes. Tests pass. CI on this head was still running at 11:05Z; no CI run on this PR has finished yet because each push cancelled the last.

Report: [20-pr52-delta-check.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/20-pr52-delta-check.md), SHA-256 `9654d289e0ee6d41efffdbdad1df731e5f63e15cbcdbb4af7224153c3f818cec`.

STATUS: READY. The merge waits for CI and the coordinator's turn, after #51. The sync after #51 needs one more delta check.
