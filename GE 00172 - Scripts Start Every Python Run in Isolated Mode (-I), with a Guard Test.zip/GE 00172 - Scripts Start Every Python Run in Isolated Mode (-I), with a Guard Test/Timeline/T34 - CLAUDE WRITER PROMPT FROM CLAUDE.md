Quota plan (David approved, attached): finish #52's merge on green CI, then stop. Box run 4 is paused until after Thursday's reset; don't start it even if the box is free.
