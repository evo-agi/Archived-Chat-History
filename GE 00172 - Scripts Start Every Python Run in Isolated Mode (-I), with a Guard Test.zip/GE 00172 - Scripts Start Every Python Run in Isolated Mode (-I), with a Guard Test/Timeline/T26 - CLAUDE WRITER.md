PR #51 is merged into trunk_dev as `30b241d` (squash). The sync check passed and CI was fully green, including the new root step. trunk_dev's tree is byte-identical to the checked head. I'm starting #52's sync now.

STATUS: WORKING (#52 sync, then its delta check, CI and merge; box run 4 when the box is free)
