PR #52 is open and ready for review: https://github.com/evo-agi/Execution-Substrate/pull/52. Every Python run in `scripts/` now starts in isolated mode (`python3 -I`, 260 places in 39 files). A new guard test fails on any run that drops `-I`; on trunk_dev it flags exactly the lines this PR changes. Local failure sets match trunk_dev, and CI is running. The auditor has it. It merges after #51.

STATUS: WAITING (audit, CI, merge turns; box run 4 when the box is free)
