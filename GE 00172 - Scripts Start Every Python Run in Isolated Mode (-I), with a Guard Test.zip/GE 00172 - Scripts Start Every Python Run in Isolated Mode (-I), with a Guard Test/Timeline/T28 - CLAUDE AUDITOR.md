**BLOCK** for #52's sync at 072e6ac, on one Low finding. I've written and tested the fix diff for it.

The sync itself is clean:
- f820a21 is git's own merge, and the base equals the #51 tree I accepted in 22;
- the PR and trunk lines are unchanged;
- the manifest reproduces, `8f88a5ea…04b8`;
- the tests pass (root 181, unprivileged 89, docs package 608), and #51's 12 helper mutants are all caught.

**A25-1 (Low).** Both venv hook writers point the venv's python3 at whatever python3 on PATH resolves to through symlinks. Those are the moved bootstrap test and es/app's ACL test. When that python3 is a wrapper script (pyenv or asdf style), the real Python starts outside the venv and the hook never loads.
- With a wrapper first on PATH, #51's four refusal subtests fail at 072e6ac. They passed at 0a00f2a.
- The es/app ACL cases fail too. I missed that in 19 and 20.
- It fails loudly and is test-only. CI's python3 is a symlink, so CI should be unaffected.

**The fix** asks python3 for its own `sys.executable`. With it, everything passes, with and without the wrapper.

CI run 45405728557 was still running at 14:03Z. After the fix lands, I'll do a short delta check.

Files:
- [25-pr52-sync-check.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/25-pr52-sync-check.md), SHA-256 `280deae6beb317230c21aa099089d5a9ed5e7c9a632b966581287ffd263992f6`
- [25-pr52-sync-check-fix.diff](/mnt/project-files/reports/Execution-Substrate/host-firewall/25-pr52-sync-check-fix.diff), SHA-256 `197b8b6520ba29d50d87ae0158af3915ada0e4ff8b179c7da44587a3022201c4`
- The evidence is in `25-pr52-sync-check-evidence/`.

STATUS: #52 sync 072e6ac BLOCK (A25-1 Low, fix diff tested); waiting for the writer to apply it, then a delta check.
