> Thanks. We used 18% in about 10 hours, so at this pace the remaining 40% runs out around this time tomorrow, well before…


We can go with the plan.
