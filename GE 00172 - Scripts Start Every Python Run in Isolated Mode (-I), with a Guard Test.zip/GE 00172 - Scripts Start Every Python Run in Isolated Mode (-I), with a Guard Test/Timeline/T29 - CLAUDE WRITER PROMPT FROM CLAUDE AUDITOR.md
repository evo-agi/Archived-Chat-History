Here is the response from CLAUDE AUDITOR:

Delta check 25 of #52 at 072e6ac: BLOCK on one Low finding, A25-1. The fix diff is ready and tested.

The sync is clean. f820a21 is git's own merge, and 30b241d has the same tree as 0a00f2a. The PR lines (45 files) and trunk lines (26) are unchanged. The manifest 8f88a5ea…04b8 reproduces. Tests pass: root 181, unprivileged 89, root package 608. #51's 12 helper mutants are all killed, and K1/K3 match your report.

A25-1 (Low): writeBootstrapPythonHook and es/app's writeTestPythonHook link bin/python3 to EvalSymlinks(LookPath("python3")). When python3 on PATH is a wrapper script (pyenv or asdf shim style), the real interpreter starts outside the venv and the .pth hook never loads. With my wrapper first on PATH, the 4 refusal subtests fail at 072e6ac with "did not go through the test's ctypes hook", though they passed at 0a00f2a. The es/app ACL cases fail too, which I missed in 19/20. It fails loudly and only in tests, and CI's /usr/bin/python3 is a symlink.

Fix: host-firewall/25-pr52-sync-check-fix.diff (SHA-256 197b8b6520ba29d50d87ae0158af3915ada0e4ff8b179c7da44587a3022201c4, 2 files, applies cleanly to 072e6ac). It probes python3 -I -c for sys.executable and the version, then resolves links from sys.executable. On the delivered diff:
- sim 24/0/58
- root 87+3 guard
- unprivileged 89
- ACL 3/0/3 with and without the wrapper
- testutil 6

Report: host-firewall/25-pr52-sync-check.md (SHA-256 280deae6beb317230c21aa099089d5a9ed5e7c9a632b966581287ffd263992f6). CI run 45405728557 was still running at 14:03Z. Once the fix is pushed, send me the head and manifest for a short delta check.
