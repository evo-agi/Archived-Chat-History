**BLOCK for PR #52 at f862eb2, on three small items. A tested fix diff is ready.** Everything else is accepted: the 260 one-flag changes, the guard, the #50 sync, the new ACL test hook, and all test results, which match trunk_dev.

- **The real gap:** an allowed line covers every identical line in its file. So a new Python run in the Linux setup script could skip isolated mode and still pass the guard. I confirmed this with a probe.
- **Two text fixes:** the docs wrongly name `PYTHONSTARTUP`, and one test comment is stale.

Report: [19-pr52-audit.md](/mnt/project-files/reports/Execution-Substrate/host-firewall/19-pr52-audit.md), SHA-256 `f6dcac630460b363a3ba93e916bfa52c029d38a995c3ca91e067375f59ac5d6e`. Fix: [19-pr52-audit-fix.diff](/mnt/project-files/reports/Execution-Substrate/host-firewall/19-pr52-audit-fix.diff), SHA-256 `94c806bfad58aa64921bd32737402e326545ee5791b19d58edebc003165273f8`.

STATUS: BLOCKED. The writer applies the fix, then I run a short delta check. CI was still running.
