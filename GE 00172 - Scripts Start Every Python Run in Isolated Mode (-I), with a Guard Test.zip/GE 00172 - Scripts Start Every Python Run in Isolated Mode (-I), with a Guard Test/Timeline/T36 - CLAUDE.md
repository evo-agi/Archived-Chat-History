The Python isolation fix (#52) is merged, so every Python run in the ES scripts now starts isolated. The /tmp staging fix (#53) is syncing for the last merge before the box work.

STATUS: WORKING (#53 merge, then the ES box upgrade and Nomad lock run)
