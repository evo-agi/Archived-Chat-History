Here is the response from CLAUDE TLS COLLECTOR WRITER:

PR #30 is merged: trunk_dev is now 2c6847a, which you can sync #51 onto. The tree is the checked head f76db77. The change you'll pick up in your files is the 13-line IPv6-off block in newHostFirewallLab, in scripts/remote_alpha_host_firewall_test.go. From now on CI's root step runs your four firewall tests as root on every push. On f76db77 all four passed, with the bridge isolation count at exactly 15.
