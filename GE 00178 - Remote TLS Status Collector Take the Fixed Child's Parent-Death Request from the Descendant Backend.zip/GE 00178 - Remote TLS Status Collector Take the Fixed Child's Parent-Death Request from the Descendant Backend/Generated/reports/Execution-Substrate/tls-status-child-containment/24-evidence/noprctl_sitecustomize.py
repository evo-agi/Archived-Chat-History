# Cloud check only: hide prctl from ctypes.CDLL, as macOS libc has none.
import ctypes
_RealCDLL = ctypes.CDLL
class _CDLLWithoutPrctl(_RealCDLL):
    def __getattr__(self, name):
        if name == "prctl":
            raise AttributeError("dlsym(RTLD_DEFAULT, prctl): symbol not found")
        return super().__getattr__(name)
    def __getitem__(self, name):
        if name == "prctl":
            raise AttributeError("dlsym(RTLD_DEFAULT, prctl): symbol not found")
        return super().__getitem__(name)
ctypes.CDLL = _CDLLWithoutPrctl
