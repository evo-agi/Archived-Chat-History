# MERGE: PR #58 into trunk_dev as bf5a760

**PR #58 is merged into trunk_dev as `bf5a760a2276f5d8b7600d7b64523e4ee32410d0`, a squash at 2026-11-25 ~03:20Z on the coordinator's instruction of 02:33Z. The merge commit's tree `9a4cf0943d5ec7c147ce78580fc9321fd77db13c` is the tree of the checked head `cdd768d`, which audit 26 pre-accepted, and its parent is `2ca76cd`. It changes the same 3 files, +111 −14. Next: the macOS CI PR, then the partial P30 rerun on a box turn.**

Written by the writer thread "Contain TLS status collector child processes".

## Gate

| Check | Result |
|---|---|
| Audit | Audit 26 (`26-pr58-audit.md`): ACCEPT `b396592`, no red-team needed. It accepted in advance an update that is git's own merge of trunk_dev `2ca76cd` with tree `9a4cf0943d5ec7c147ce78580fc9321fd77db13c` |
| Head equals the checked commit | Update merge `cdd768d6fe9e97deec199b9063432cc9c1053e6f` (parents `b396592`, `2ca76cd`), made with `git merge --no-ff origin/trunk_dev`, no conflicts, tree exactly `9a4cf094…`. Merged with `expectedHeadSha` set to `cdd768d` |
| Up to date | trunk_dev was still `2ca76cd` just before the merge, an ancestor of the head. GitHub showed `mergeable_state: clean` |
| Manifest | At the audit: v2 `7e2359e95553c39df3b648cf5d83f41053cf0f456ea66054e465be8528d2da1b` against `fd0529a` (`24-evidence/`). After the update: v2 `31a3bddd40929a11712fcd3a5c005aa0cd4d841d9fb281148fc09b9542589b9d` against `2ca76cd`, 3 files, taken twice byte-identical, recipe sum checked (`27-evidence/manifest-cdd768d-vs-2ca76cd.json`). The remote collector entry is unchanged (`b4722c83…1138`); the other two entries differ only by #56's own edits to those files, which the merge carries |
| CI | Run 45534019920 on `cdd768d` passed (02:35Z–03:18Z). The audited head's run 45527273383 also passed, root step 9 of 9 |
| Post-merge bytes | `bf5a760^{tree}` = `9a4cf094…` = `cdd768d^{tree}`. `git diff --stat 2ca76cd bf5a760`: 3 files, +111 −14. On trunk_dev: capability_probing.md `1253f41c…30e9`, remote collector `b4722c83…1138`, descendants test `6fabf2ce…3e27`, as in the post-update manifest |
| Codex review | None: Codex's usage limit was reached when the PR opened (PR comments 7149793717, 7149794434) |
| Head branch | Deleted by GitHub after the merge (auto-delete is on) |

## After the merge

1. **macOS CI PR** (coordinator, 01:20Z): a macOS job for the host-portable `./scripts` tests. Prepared as `../macos-ci/01-wip-5c586d4.patch`.
2. **Partial P30 rerun** at `bf5a760`, on its own box turn: Mac A4 (the four tests must pass) and box B3b, B4 and B5c, because the remote collector's sum is now `b4722c837949239c14067495ee6e67e281a7c759f646e79198b8634aa2d11138`. The root collector is unchanged, so B5 and B5b need not run again. Until it passes, no TLS status check from a commit that contains #30 runs on the box.
