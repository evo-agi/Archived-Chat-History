# ES PR #58, audit 26: the remote collector's parent-death request moves into the descendant backend

```
Target:   evo-agi/Execution-Substrate PR #58, branch claude/project-thread-wbmulu
Head:     b3965921a67509d9f66c4a65e61b0a6944c2dbf7 (one commit, tree 38d7675d…), base trunk_dev fd0529a
Report:   24-fix-macos-prctl.md (writer)
Posture:  auditor thread, read-only; nothing pushed, no PR comment. Cloud container
          (kernel 6.18.44 without IPv6, Go 1.26.5, user ci UID 1500, and root).
Verdict:  ACCEPT b396592. On Linux the fixed child still makes the same PR_SET_PDEATHSIG(SIGKILL)
          call, in the same place in its setup, and RealCollectorDeath still proves it by behaviour.
          A setup that cannot be prepared now fails closed as a runtime failure with no spawn.
          The root collector is unchanged. All 5 of the writer's mutants and 6 of my 7 are caught;
          the one survivor cannot be reached on any host (Info). CI: green, all steps,
          root step 9 of 9 (run 45527273383).
Red-team: not needed (section 8).
Merge:    trunk_dev moved to 2ca76cd (#56) after the PR opened. A trial merge onto it is clean and
          tests the same as trunk_dev (section 6). I accept in advance an update that is git's own
          merge of 2ca76cd with tree 9a4cf094…; only its CI remains. Any other tree, or a trunk_dev
          that moves again, needs a sync check.
```

## 1. Provenance

- The recipe's sha256 (`c08597e2…a3ca`) was checked before every run. With HEAD reset to the
  merge base `fd0529a`, upstream `origin/trunk_dev`, two runs at open and two at close all give
  `manifest_sha256 = 7e2359e95553c39df3b648cf5d83f41053cf0f456ea66054e465be8528d2da1b` (3 files) and
  `textual_diff_sha256 = db3ce1a0a4e57049f0f0c0dde773edd9d3f2919a3549729b71a1e726ad4e7b63`. The open and
  close files are byte-equal to each other and to the writer's `24-evidence/manifest-b396592-vs-fd0529a.json`.
  The staged tree is the head's tree `38d7675d…`, and the status after restore is empty.
- The 3 files are the remote collector, the descendants test and `capability_probing.md`, as the
  writer says. The PR head was still `b396592` at close.
- trunk_dev was `2ca76cd` at close (PLANS.md step 2, #56, merged after the PR opened). The merge base is
  still `fd0529a`, so the manifest above is the PR's own change. Section 6 covers the new trunk.

## 2. On Linux the real request is still made, in the same place

`scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py` at b396592:

- `_parent_death_request` (l.172) resolves `ctypes.CDLL(None, use_errno=True).prctl` in the collector
  and returns a call of `prctl(PR_SET_PDEATHSIG, SIGKILL, 0, 0, 0)`. The call and its arguments are the
  ones fd0529a made inline.
- `DescendantBackend` holds it as `parent_death_request` (l.212). Production code never replaces
  `DescendantBackend`; only test scripts assign `m.DescendantBackend`.
- `fixed_child_setup` (l.507) takes the request from `DescendantBackend()` before the fork, as fd0529a
  resolved `prctl` before the fork. In the child, the order is unchanged: the request (an `OSError` if it
  does not return 0), then `getppid() == parent`, then `RLIMIT_NPROC (limit, limit)`.
- `run_command` is unchanged: the flag is checked before any spawn, and the drain runs in `finally`.

**What proves it.** The shared stand-in, which now swaps in a request that does nothing, is used by
only three fixtures (PureFunctions, HardBounds, LifecycleOrdering, in the noninteractive test). The
real-kernel tests do not use it. RealCollectorDeath kills the collector and requires the fixed child,
which ignores TERM, to die with it, against a control case without the setup in which the same child
outlives the collector. Only a real PR_SET_PDEATHSIG(SIGKILL) passes. It passed 10 of 10 times as ci and
once as root. Three mutants that weaken the real request all fail it (section 5).

## 3. A setup that cannot be prepared fails with no spawn

`supervise_fixed_child` (l.531) now prepares the setup inside `try/except Exception` before `Popen`. A
failure returns `CommandResult(125, runtime_failed=True)`. `spawned` stays empty, and `run_command`'s
drain still runs. Before the change, an `AttributeError` (no `prctl`) escaped the runner after the drain,
and an `OSError` from `CDLL` became 127, the code for a missing command. Neither could pass as a
success then either, but now both fall into the documented class for runtime failures. The new RunCommand case checks
each of these: no spawn, 125, `runtime_failed`, only the drain's `waitid`. The flag stays set; only an
unproved drain clears it.

## 4. The macOS failure, reproduced and fixed

I hid `prctl` from `ctypes.CDLL` in both container Pythons with a `.pth` hook (`sim/sim.sh`).
`/usr/local/lib/python3.13/site-packages` is a symlink to `dist-packages`, which is where the hook lands
for both Pythons. With the hook on:

| Tree | The four Mac tests |
|---|---|
| fd0529a | 0 pass, 4 fail on the hidden `prctl` (8 tracebacks), as on the Mac |
| b396592 | 4 pass |
| b396592 with W3 (stand-in without the backend) | RunCommand passes; the 3 stand-in fixtures fail |

The hook was off for every other run (`sim.sh check`: `prctl-visible` in both Pythons), and no hook file
is left. This simulation covers only the missing `prctl`. Any other macOS difference can only show in
the Mac A4 rerun after the merge.

## 5. Mutants (Linux, hook off)

Each mutant applies exactly once. Each one was run against RunCommand, StandInIsWhole,
DocumentsContract, RealCollectorDeath and the three stand-in fixtures.

| Mutant | Caught by |
|---|---|
| W1 setup resolves `prctl` itself (writer M1) | RunCommand (both new cases), DocumentsContract |
| W2 no guard around preparing (M2) | RunCommand (the runner raises), DocumentsContract |
| W3 stand-in without the backend (M3) | StandInIsWhole |
| W4 setup skips the request (M4) | DocumentsContract, **RealCollectorDeath** |
| W5 an unprepared setup is 127 (M5) | RunCommand, DocumentsContract |
| N1 production request does nothing | DocumentsContract, **RealCollectorDeath** |
| N2 request asks for SIGTERM | DocumentsContract, **RealCollectorDeath** |
| N3 unprepared but not `runtime_failed` | RunCommand, DocumentsContract |
| N4 the request's result is ignored | DocumentsContract |
| N5 an unresolvable request becomes a no-op inside `_parent_death_request` | **survives** (I26-1) |
| N6 the guard catches only `AttributeError` | RunCommand (`OSError` escapes), DocumentsContract |
| N7 an unprepared setup spawns without the setup | RunCommand, DocumentsContract |

N4 is caught only by a source pin. `prctl(PR_SET_PDEATHSIG, SIGKILL)` does not fail on Linux, so no
behaviour test can see it. The new pin covers `!= 0` and the `raise`; at fd0529a the pin held only the
first line of the call.

**I26-1 (Info, no change needed).** N5 survives because no test calls the real `_parent_death_request`
with a C library that lacks `prctl`. It cannot be reached on any host. On Linux, `prctl` always
resolves. On a host without it, the capability probe fails first: `_set_child_subreaper` resolves
`libc.prctl` and raises, `validate_descendant_capability` reports `probe_failed`, the flag stays False,
and `run_command` refuses every command before `supervise_fixed_child`. The probe test covers that
refusal ("a refused child subreaper is unproved before any fork"). This rests on reading the code; it
is not a separate run.

## 6. Full tests, and the new trunk_dev

| Run | Result |
|---|---|
| `go vet ./...` linux/amd64 and darwin/arm64 | exit 0 |
| `gofmt -l` on the changed test, `ast.parse` on the collector | clean |
| Gate self-test | OK (workflow sha matches its pin) |
| CI root step, emulated | 9 of 9 |
| Collector family as ci | 29 tests (67 with subtests), all pass |
| Descendant family as root | 9 pass, 1 skip (RealProcessLimit skips itself as root) |
| RealCollectorDeath ×10 as ci | 10/10 |
| `.`, `./scripts/`, `./internal/testutil/` as ci, b396592 vs fd0529a | verdicts identical on all 2,920 names (2,704 pass, 20 skip, 196 fail; every failure is container-only and fails the same at the base) |
| Trial merge onto trunk_dev 2ca76cd: `git merge-tree` | clean, tree `9a4cf0943d5ec7c147ce78580fc9321fd77db13c` |
| Trial merge: root step, collector family, descendant family | root step 9 of 9; collector family 29 (67 with subtests) pass; descendant family 9 pass, 1 skip (as above) |
| Trial merge vs 2ca76cd, same three packages as ci | verdicts identical on all 2,922 names (2,706 pass, 20 skip, 196 fail); no new or missing names |

#56 also edited the descendants test: it moved one DocumentsContract section from PLANS.md to the route
rules file. Git merged that with the PR's edits without a conflict, and the contract passes on the
trial merge.

## 7. CI

Run 45527273383 (job 138913624167) on `b396592` was green in every step, 01:38:56Z to 02:29:54Z. That
includes "Vet for macOS", "Check the test gate", "Test", "Listed tests still fail" (all 17 still
fail) and "Listed tests pass as root" (**9 of 9**, BridgeIsolation included) (`ci/job-138913624167.txt`).
The gate reports `ok execution-substrate/scripts`, and its 14 self-skips are all listed. None of
them is a descendant test, so RealCollectorDeath ran and passed as the runner's unprivileged user.
CI tests only on Linux, so it cannot show the macOS fix; section 4 and the Mac A4 rerun cover that.

The run is for the `pull_request` event and started at 01:38Z, before #56 merged. It tested
`b396592` on `fd0529a`, not on `2ca76cd`. The branch rule needs an up-to-date branch, so the update
gets its own CI run.

## 8. Red-team

I do not think it needs one. The PR adds no input, no process start, no syscall and no privilege. On
Linux, it moves where the same `prctl` call is resolved, and adds one fail-closed branch. The property
a red-team would attack, that the real parent-death signal is still applied, is proved by behaviour
(RealCollectorDeath, which three mutants break) and pinned in source. The new branch is pinned and
checked by the RunCommand cases. The rest of the risk is on macOS, and the Mac A4 rerun will test it
on a real Mac.

## 9. Evidence

`26-pr58-audit-evidence/` (SHA256SUMS in that folder): `provenance-open/`, `provenance-close/`,
`review/` (the diff, collector sums, review notes with line references), `runs/`, `sim/`, `mut/`
(mutation script and outputs), `trial/`, `ci/`, `scripts/`.
