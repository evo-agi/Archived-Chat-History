# 24. Fix for the P30 Mac failures: PR #58

STATUS: PR #58 open, ready for audit; CI "build, vet and test" green on the head (run 45527273383, 02:29:54Z 2026-11-25). Head b3965921a67509d9f66c4a65e61b0a6944c2dbf7, base trunk_dev fd0529a206cf079b979129b6f533ea73dae9be17. Gate stays closed until #58 merges and the partial P30 rerun passes.

## What failed (from 23-box-run.md)

Four `./scripts` tests failed on David's Mac at fd0529a. The remote collector's `fixed_child_setup` resolved `ctypes.CDLL(None).prctl` in the parent before each spawn. macOS libc has no `prctl`, so the lookup raised before any child started. On Linux the lookup always succeeds, and CI runs tests only on ubuntu-24.04, so nothing caught it. The tests' shared stand-in claims the descendant capability on every host, so these tests are meant to run on macOS too.

The box itself was never at risk: the collector runs only on Linux, and the box passed every P30 check.

## The fix (one commit, b396592)

- `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`
  - New `_parent_death_request()` resolves `prctl` and returns a function that makes the PR_SET_PDEATHSIG(SIGKILL) call.
  - `DescendantBackend` now holds it as `parent_death_request`, next to the other kernel operations.
  - `fixed_child_setup` takes the request from `DescendantBackend()`; the child's setup order is unchanged (parent-death request, then the getppid proof, then RLIMIT_NPROC 0).
  - `supervise_fixed_child` turns a setup that cannot be prepared into a runtime failure (returncode 125, `runtime_failed=True`) without a spawn.
- `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go`
  - The shared stand-in also replaces `DescendantBackend` with a subclass whose only change is a parent-death request that does nothing.
  - The RunCommand test's Kernel model gains `parent_death_request`.
  - Two new RunCommand cases: an unresolvable request starts no child and is a drained runtime failure; and a C library without `prctl` does not stop the runner, because the runner takes the request only from the backend.
  - The guard and DocumentsContract pins are extended to the new lines.
- `.docs/system_overview/capability_probing.md`: three sentences on the backend's parent-death request and the stand-in.

Collector sums at b396592: remote b4722c837949239c14067495ee6e67e281a7c759f646e79198b8634aa2d11138 (changed). The root collector is unchanged.

## Provenance

Manifest recipe v2 (sha c08597e2…a1e3ca verified), run twice against base fd0529a, byte-identical:
`24-evidence/manifest-b396592-vs-fd0529a.json`, sha 7e2359e95553c39df3b648cf5d83f41053cf0f456ea66054e465be8528d2da1b, 3 files, textual diff sha db3ce1a0a4e57049f0f0c0dde773edd9d3f2919a3549729b71a1e726ad4e7b63. Tree 38d7675dc291e14c79dc7a3a578fc15dd890e499.

## Validation (cloud container, Linux)

- macOS simulation: `24-evidence/noprctl_sitecustomize.py` installed as sitecustomize in both container Pythons (`/usr/bin/python3` and `/usr/local/bin/python3`), so `CDLL(None).prctl` raises AttributeError as on macOS. Both originals restored after each run and checked by sha.
  - At fd0529a: exactly the Mac's 4 failures.
  - At b396592: 4/4 pass; collector test family 67/67.
- Without the simulation: collector family 67/67.
- Whole packages `.`, `./scripts/` and `./internal/testutil/` as the unprivileged ci user: 616 pass, 13 skip, 10 fail. 8 failures are `execution-substrate/scripts` entries of `environment-only-tests.txt` that fail in this container; the other 2 (`TestRemoteAlphaUpgradeESApply`, `…CheckRefusesWhatItWasNotWrittenFor`) are container-only (the ci user has no supplementary group) and fail the same at fd0529a. The 13 skips are the 5 PID-namespace and 4 firewall `skips-itself` tests and 4 real SPIRE/Vault tests (no binaries in the container).
- `go vet` clean for linux and darwin targets; gate self-test 132/132; root step 9/9.
- Mutants 5/5 caught, each against the RunCommand, StandInIsWhole and DocumentsContract tests: M1 setup resolves the request directly instead of through the backend; M2 the setup try/except removed; M3 the stand-in no longer replaces the backend; M4 the child setup skips the parent-death request; M5 an unprepared setup reported as an ordinary 127 failure instead of a runtime failure.

## Before merge

Fresh audit at b396592, red-team if the coordinator wants one, green CI, merge gate.

## After merge

1. Partial P30 rerun at the merge commit, in its own box turn: Mac A4 (the `./scripts` tests on macOS), and box B3b/B4/B5c because the remote collector sum changes. B5 and B5b need not rerun (root collector unchanged).
2. macOS CI PR (see 25 when written): a macOS GitHub Actions job running the host-portable `./scripts` tests, so the next Mac-only break is caught by CI.
