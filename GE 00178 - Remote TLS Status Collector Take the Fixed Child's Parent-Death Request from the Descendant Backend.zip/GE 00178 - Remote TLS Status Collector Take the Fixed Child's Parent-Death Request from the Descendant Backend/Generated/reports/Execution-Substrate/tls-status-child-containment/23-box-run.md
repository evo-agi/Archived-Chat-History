# P30 run at trunk_dev fd0529a: the box passes, the Mac fails 4 tests

Run on 2026-11-25 from 01:06Z to about 01:20Z, in one Remote Control session on David's Mac, with brief `22-mac-and-box-brief.md`. Written by the PR #30 writer thread. The gate and its pass criteria are in `p30-gate-moved-from-es-upgrade-plan.md`.

**Result: P30 did not pass.**

- **The box (criteria 2 to 6): passed.** Every check of the new collectors passed on the box: as root through `sudo -n` and as the SSH user, under the box's sudo, PAM and kernel 7.0. The `eed4c9b` collectors failed exactly the cases that the rehearsal predicted.
- **The Mac (criterion 1): failed.** A4 exited 1, because four tests in `./scripts` fail on macOS. The cause is PR #30: the remote collector looks up `prctl` in libc before it starts each fixed command, and macOS has no `prctl`.

The box was handed back in working order:

- all nine services were active before and after (`es ags ars egs nomad vault spire-agent spire-server docker`);
- no process of the run was left;
- the box folder was removed.

Nothing else on the box was touched. The Mac run folder is removed and nothing was downloaded.

Per the gate, no TLS status check from a commit that contains PR #30 runs on the box until a fix has its own audit and P30 passes for that commit. The fix proposed below changes only how the tests stand in for the kernel, and one function of the remote collector.

## 1. Pass criteria

| # | Criterion | Result |
|---|---|---|
| 1 | Mac A4 to A7 | **Failed.** A4 exit 1: 1,029 pass, 14 skip, **4 fail** (section 2). A5 (`go vet`) and A6 (`gofmt`) printed nothing. A7: patch sum matched on the first write, dump exit 0, all ten probe sums as in the brief. |
| 2 | Staging sums | Passed. Every sum in B3 and B3b matched. Every folder was 700 and every file 600, owned by `claude`. |
| 3 | B4, login user | Passed (lines below). |
| 4 | B5, root | Passed (lines below). |
| 5 | B5b and B5c with `new` | Passed. All ten probes: `"capability": true`, exit 0, `"failed cases": []`, no timeout. |
| 6 | B7 | Passed. No process line, the folder was gone, and the services were as in B1. |

The 14 skips:

- The eleven real-kernel and anchor tests that the brief listed.
- Three more: `…ProcessIdentityLiveProcesses`, `…ProcessIdentityThreadExecStaysPresent` and `…UnrelatedProcessNameDoesNotHoldCleanup`. Each prints "cannot open /proc/self/stat: ENOENT".
  - These three exist unchanged at `230954d`, before PR #30, and macOS has no `/proc`.
  - The brief's list of expected skips missed them. That is an error in the brief, not a finding.

## 2. The finding: four tests fail on macOS since PR #30

The four failing tests:

- `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRunCommand` (new in PR #30);
- `…NoninteractiveRemoteCollectorPureFunctions`, `…RemoteCollectorHardBounds` and `…RemoteCollectorLifecycleOrdering` (they exist at `230954d`).

Each fails with the same chain: `run_command` → `supervise_fixed_child` → `fixed_child_setup`, collector line 498, `prctl = ctypes.CDLL(None, use_errno=True).prctl` → `AttributeError: dlsym(RTLD_DEFAULT, prctl): symbol not found`. The first ran under `/usr/bin/python3` 3.9, the other three under python.org 3.13. The collector at `230954d` has no `prctl` at all.

Inference: the three older tests passed on macOS before PR #30. Not checked: the parent commit was not run on the Mac.

**Why CI and review missed it.**

- CI runs the tests only on ubuntu-24.04; for darwin/arm64 it runs `go vet` alone.
- The cloud runs are all Linux.
- All four tests use the shared stand-in `remoteCollectorDescendantStandIn`. That stand-in replaces the capability flag and the drain "so that the tests run on every host", but the command runner still needs Linux's `prctl` for the fixed child's parent-death signal.
- The brief's Mac expectation was an inference, and the Mac run was held until after the merge.

**Effect.**

- **None on the box.** In production, `run_command` refuses before any spawn unless the descendant probe set the flag, and that probe needs Linux, so the collector never reaches the lookup on a host without `prctl`.
- **On a Mac:** the ES test suite `./scripts` is red at `fd0529a`, which hides any other failure in that package there.

**Proposed fix (product code, small): one follow-up PR.**

1. In the remote collector, the parent-death request becomes one module-level function, resolved in the parent before the fork as now. `fixed_child_setup` calls it instead of resolving `prctl` itself. Nothing else in the setup changes: the parent check and the process limit stay.
2. The shared stand-in replaces that function too, with one that does nothing, and its guard test pins the rule that only the stand-in may replace the flag, the drain or that function.
3. The real-kernel tests keep proving the real parent-death signal on Linux (`…RealCollectorDeath`, and B4 on the box).
4. A docs contract line states that the deterministic group stands in for both kernel needs of the runner.

With this, the four tests run on every host again, as the stand-in's comment says they do. The alternative, skipping the four tests off Linux, would drop macOS coverage of the runner's bounds and ordering that existed before PR #30.

After the fix merges, P30 runs again for that commit. Only parts of it are needed:

- A4 on the Mac;
- B3b, B4 and B5c on the box, because the remote collector's sum changes;
- B5 and B5b only if the root collector changed, which this fix does not.

## 3. Box facts (information, not pass or fail)

| Fact | Value |
|---|---|
| Host, kernel, CPUs | `[test box name withheld]`, `7.0.0-42-generic`, 12 |
| Python, OpenSSL, sudo | 3.12.3, 3.0.13, 1.9.15p5 |
| Login user | `claude` (UID 1002), not root |
| `kernel.yama.ptrace_scope` | 1 |
| `kernel.pid_max` | 4194304 |
| `kernel.apparmor_restrict_unprivileged_userns` | 1 |
| Process limit of the SSH session | 54196 (soft and hard) |
| User slice | TasksMax 35769, TasksCurrent 40 |
| PAM | `pam_limits` in `/etc/pam.d/sshd` and `/etc/pam.d/sudo`; no `nproc` line in `limits.conf` or `limits.d` |
| sudo defaults | `env_reset, mail_badpass, secure_path=…, use_pty` |
| `sudo -n /usr/bin/tty` under `ssh -T` | `not a tty`, exit 1, with and without `</dev/null` |
| Memory | 15397 MB total, 3614 MB free |
| C compiler | none |

**Red-team 12, items 2, 5 and 6, answered:**

- `ptrace_scope` is 1. A process may trace only its own descendants, unless it is root.
- The SSH user is not root, so the process limit binds the fixed child.
- The fixed `sudo -n` commands run under the fixed child's `RLIMIT_NPROC (0, 0)` with this box's sudo, sudoers and PAM: B4, `id -u` → `0`, `stat` → `644:0:0:regular file`, both `runtime_failed: false`.

**B6, `pidfd_answers.py`:** identical as the login user and as root, and identical to the container on 6.18.

| Number given to `pidfd_open` | Answer |
|---|---|
| live child | `opened` |
| zombie child | `opened` |
| reaped child | `ESRCH` |
| reaped leader with a living group member | `ESRCH` |
| reaped session leader with a living member | `ESRCH` |
| TID of a live non-leader thread | `ENOENT` |
| leader thread exited while another lives | `opened` |
| numbers above `pid_max` | `ESRCH` |

**B6d (variant c):** not run. The box has no C compiler, and installing one is outside the box rules. The cloud rehearsal at `fd0529a` stands for it: with `new`, no run was held, and the fixed child ended 10 ms and 116 ms after the collector was killed; `old` was held 5 of 5. Variant c on the box's 12 CPUs stays un-run. It was optional.

## 4. Verbatim box lines

**B4** (exit 0):

```
{"RLIMIT_NPROC": [54196, 54196], "cgroup": "0::/user.slice/user-1002.slice/session-3198.scope", "children file": "", "part": "r2 facts", "pids.current": "3", "pids.max": "max", "process limit of the fixed child": 0, "python": "3.12.3", "sigchld": "0", "status": {"NoNewPrivs": "0", "Seccomp": "0", "Threads": "1"}, "uid": 1002}
{"flag": true, "part": "r2 descendant probe", "verdict": "accepted"}
{"bytes from stand-ins": 1, "flag": true, "part": "r2 fixed command that tries to start a descendant that ignores TERM", "process left after return": false, "returncode": 0, "runtime_failed": false, "stdout": "EAGAIN"}
{"flag": true, "part": "r2 fixed command through sudo -n under the process limit: /usr/bin/id -u", "returncode": 0, "runtime_failed": false, "stderr": "", "stdout": "0"}
{"flag": true, "part": "r2 fixed command through sudo -n under the process limit: /usr/bin/stat -c %a:%u:%g:%F /etc/hostname", "returncode": 0, "runtime_failed": false, "stderr": "", "stdout": "644:0:0:regular file"}
```

**B5** (exit 0):

```
{"cpus": 12, "euid": 0, "kernel.apparmor_restrict_unprivileged_userns": "1", "kernel.pid_max": "4194304", "kernel.yama.ptrace_scope": "1", "os.setns": true, "os.unshare": true, "part": "root facts", "pid_for_children": true, "python": "3.12.3", "status": {"CapEff": "000001ffffffffff", "NoNewPrivs": "0", "Seccomp": "0", "Threads": "1"}, "uid": 0, "user.max_pid_namespaces": "54196"}
{"part": "root capability probe (both parts)", "unproved": false, "verdict": "accepted"}
{"part": "real openssl version in its own PID namespace", "returncode": 0, "stderr_bytes": 0, "stdout": "OpenSSL 3.0.13 30 Jan 2024 (Library: OpenSSL 3.0.13 30 Jan 2024)"}
{"part": "stand-in fixed command, mode setsid", "process left after return": false, "raised": null, "reports": ["fixed", "escaped"], "result": "(0, b'fixed', b'')", "seconds": 0.033}
{"part": "stand-in fixed command, mode zombie", "process left after return": false, "raised": null, "reports": ["fixed", "held", "escaped"], "result": "(0, b'fixed', b'')", "seconds": 0.034}
{"part": "stand-in fixed command, mode zombie-run", "process left after return": false, "raised": "Incomplete('child_timeout')", "reports": ["fixed", "held", "escaped"], "result": "None", "seconds": 1.026}
{"part": "stand-in fixed command, mode slow", "process left after return": false, "raised": null, "reports": ["fixed"], "result": "(0, b'fixed', b'')", "seconds": 1.033}
{"part": "root end", "unproved": false}
```

**B5b (root) and B5c (login user).** Cases failed out of all cases; every exit was 0 and every probe had capability true.

| Probe | `new` | `old` (`eed4c9b`) |
|---|---|---|
| `ESServiceTLSStatusChildNamespaceRealKernel` | 0 of 10 (0.13 s) | 0 of 10 |
| `…ChildNamespaceRealDescendants` | 0 of 14 (5.61 s) | 2 of 14: the two "without the namespace" controls, `AttributeError: 'LocalChildNamespace' object has no attribute 'release'` (interface difference, as predicted) |
| `…ChildNamespaceRealCollectorDeath` | 0 of 4 (1.36 s) | 0 of 4 |
| `…ChildNamespaceRealSiblings` | 0 of 5 (0.36 s) | 3 of 5, two held 20.0 s (40.12 s in all): RT12-1 |
| `…ChildNamespaceRealDeafAnchor` | 0 of 5 (0.48 s) | 4 of 5, two held about 8 s (36.53 s in all): RT12-2 |
| `OperatorHealthcheckTLSStatusNoninteractiveDescendantRealKernel` | 0 of 10 (2.13 s) | 0 of 10 |
| `…DescendantRealProbeRefusesAChild` | 0 of 2 (0.28 s) | 0 of 2 |
| `…DescendantRealCrowd` | 0 of 4 (4.75 s) | 0 of 4 |
| `…DescendantRealProcessLimit` | 0 of 3 (0.11 s) | 2 of 3: RT12-3 |
| `…DescendantRealCollectorDeath` | 0 of 2 (1.26 s) | 1 of 2 (11.26 s): O12-1 |

## 5. Run notes

- **Mac:**
  - At A0, `en0` was [home network address withheld].
  - macOS 26.6.2, arm64, go1.26.5 from the module cache.
  - `fd0529a` with tree `964e105…`; `pull/30/head` = `f76db77`, and `eed4c9b` was reachable.
- **The session's own deviations:**
  - It wrote the patch and scripts with a file-write tool instead of heredocs; every sum matched on the first write.
  - It kept a copy of `head.log` in its own scratch folder on the Mac, outside Playground, before removing the run folder.
- **Box timings (UTC):** B5b ran 01:10:56 to 01:12:41, and B5c 01:12:53 to 01:13:36. Wi-Fi held for the whole run.
- **Brief errors to fix before the rerun:**
  - the expected skip list (add the three `/proc` tests);
  - the A4 expectation (the four tests must pass after the fix);
  - B6d needs a C compiler, which the box does not have.
