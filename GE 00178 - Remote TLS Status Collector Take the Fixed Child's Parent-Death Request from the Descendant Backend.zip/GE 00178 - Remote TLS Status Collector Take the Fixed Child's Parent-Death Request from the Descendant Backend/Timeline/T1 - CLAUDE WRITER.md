Claude started working in a folder on your device that is already approved for this project.
