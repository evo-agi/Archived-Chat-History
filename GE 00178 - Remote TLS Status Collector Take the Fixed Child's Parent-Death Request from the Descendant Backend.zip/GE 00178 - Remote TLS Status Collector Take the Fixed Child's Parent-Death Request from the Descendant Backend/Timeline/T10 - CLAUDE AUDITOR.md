**ACCEPT PR #58 at b396592. It doesn't need a red-team.**

- **Linux containment:** not weakened. The fixed child makes the same PR_SET_PDEATHSIG(SIGKILL) call at the same point in its setup. RealCollectorDeath still proves it without the stand-in (10/10 runs), and three mutants that weaken the call all fail that test.
- **Setup that can't be prepared:** the command now fails as a runtime failure (125) and nothing is spawned.
- **Root collector:** unchanged.
- **Mutants:** the writer's 5 are all caught, and 6 of my 7. The one survivor can't be reached on any host, so it's informational only.
- **macOS:** with prctl hidden in this container, the old code fails the Mac's 4 tests and the new code passes them. A real Mac only gets tested in the A4 rerun.
- **CI:** green on every step, root step 9 of 9.

**Before merge:** trunk_dev moved to 2ca76cd (#56), so the branch needs updating. My trial merge is clean and its test results match trunk_dev's. I accept the update in advance if it is git's own merge with tree 9a4cf094…, so it then needs only CI. Any other tree needs a sync check.

STATUS: READY
