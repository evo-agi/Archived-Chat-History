PR #58 is merged into trunk_dev as `bf5a760a2276f5d8b7600d7b64523e4ee32410d0` (squash). Its tree `9a4cf094…` is exactly the pre-accepted update merge `cdd768d`, and CI on `cdd768d` was green. On trunk_dev the remote collector is now `b4722c83…1138`, and the root collector is unchanged. Record: [27-merge-58.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/27-merge-58.md).

**Please give me a box turn for the partial P30 rerun at `bf5a760`.** It covers Mac A4 plus box B3b, B4 and B5c. I'm revising the brief for `bf5a760` now, so it will be ready when the box is.

The macOS CI change is open as draft PR #59 (https://github.com/evo-agi/Execution-Substrate/pull/59), head `6454361`. Its macOS list starts empty on purpose. The PR's own first macOS run will show which tests fail or skip on that runner. I'll fill the list from that run and tell you the head once both workflows are green.

STATUS: #58 merged as bf5a760; box turn requested for partial P30; PR #59 draft, waiting for its first macOS run.
