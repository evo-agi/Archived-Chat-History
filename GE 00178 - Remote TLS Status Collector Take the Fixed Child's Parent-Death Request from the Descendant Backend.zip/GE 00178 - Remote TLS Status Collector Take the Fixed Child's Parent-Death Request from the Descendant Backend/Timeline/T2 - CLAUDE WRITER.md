Handed the machine session instructions

Run a test check of one Execution-Substrate commit on this Mac and a check on the Remote Alpha box (ssh alias [test box name withheld]), and report the complete output. The commit holds pull request 30, which makes both Remote Alpha TLS status collectors contain every process that a fixed helper command starts. The root collector runs each command in a PID namespace of its own, and ends it by killing the namespace's first process. The noninteractive remote collector becomes a child subreaper, drains its descendants, and starts each fixed command with a process limit of zero.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-p30-run.XXXXXX) and print it. Then: touch "$T/start-marker".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it, not even briefly. Use git -C "$T/es" or a subshell such as ( cd "$T/es" && … ). (If the folder ever becomes the working directory, removing it at the end is refused.)
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not run sudo on the Mac. No git push. No installs and no downloads other than the git clone and fetch.
- For every go and gofmt command set:
    export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
  Outside the clone go version may print go1.26.1; that is expected. Inside the clone it must print go1.26.5. If it does not, skip A4 to A7, report, and go on with part B without the probes (then skip steps B3b, B5b and B5c).
- If a go command fails because a module is missing, report the exact error; do not download.
- If a test fails, do not fix any code. Record the output and go on.
- Shell variables may not survive from one of your commands to the next. After you print T (and later D), use their literal values wherever the steps say "$T" or "$D".

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] '<command>'. Below this is written BOX '<command>'; BOX is shorthand, so type the full ssh command each time. Do not open an interactive shell.
- Create exactly one folder there (step B3), write only inside it, and remove it in step B7.
- Use sudo on the box only in the exact commands below. Do not start, stop, restart or reconfigure any service. Do not install anything, do not reboot, do not touch Vault, Nomad, Docker, the firewall or any file outside that folder.
- If an ssh command fails with "No route to host" or a timeout (the box is on Wi-Fi, which may drop), run: route -n get [home network address withheld]; ping -c 2 [home network address withheld]; nc -vz -w 5 [home network address withheld] 22. Then wait five minutes and try the same command once more. If it still fails, stop part B: run no further box step except B7, try B7 once more after another five minutes if a box folder was created, report the diagnostics and the folder's path, and go on with part C. Never retry a box step more than once.

A0. The box firewall accepts SSH only from [home network address withheld]. Print:
      for i in en0 en1 en2; do printf '%s %s\n' "$i" "$(ipconfig getifaddr "$i" 2>/dev/null)"; done
    If no interface shows [home network address withheld], do part A, skip part B entirely, do part C, and report the addresses.

Part A, on the Mac:
A1. Print: sw_vers, uname -m, whoami, and the value of TMPDIR (printf '%s\n' "${TMPDIR-unset}"). Clone:
      git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
A2. git -C "$T/es" fetch origin trunk_dev 'refs/pull/30/head:refs/remotes/origin/pr30-head'
    Print: git -C "$T/es" rev-parse origin/trunk_dev origin/pr30-head
    (expected fd0529a206cf079b979129b6f533ea73dae9be17, trunk_dev when this brief was written, and f76db77d2cf59666e36318fb3b3c25f1cd824ffc, pull request 30's last head. If trunk_dev differs, say so and still test fd0529a.)
    Print: git -C "$T/es" merge-base --is-ancestor eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea origin/pr30-head && echo "eed4c9b reachable"
    (If it is not reachable, say so, skip the "old" runs in B5b and B5c and the B6d run with "old", and do not write the old collectors in B3.)
A3. git -C "$T/es" checkout --detach fd0529a206cf079b979129b6f533ea73dae9be17
    Confirm git -C "$T/es" rev-parse HEAD 'HEAD^{tree}' (expected tree 964e105094265e85408ba984e39215173a038acb).
    Inside the clone print: go version, and go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE.
A4. R='^(TestRemoteAlphaESServiceTLSStatus.*|TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive.*|.*Doc.*)$'
    K='^(TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal|TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody|TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution)$'
    ( cd "$T/es" && go test -count=1 -v -timeout 30m -run "$R" -skip "$K" . ./scripts/ ) > "$T/head.log" 2>&1; echo "exit $?"
    Report:
    - the exit status;
    - the package result lines (grep -E '^(ok|FAIL|PASS)' "$T/head.log");
    - the number of lines matching each of '^ *--- PASS', '^ *--- SKIP' and '^ *--- FAIL';
    - every '--- SKIP' line with the two lines after it (grep -E -A2 '^ *--- SKIP');
    - every line containing 'panic:';
    - for each failed test, its complete output from its "=== RUN" line through its "--- FAIL" line and the indented lines after it.
A5. ( cd "$T/es" && go vet ./... ); echo "exit $?"    (expected: no output, exit 0)
A6. ( cd "$T/es" && "$(go env GOROOT)/bin/gofmt" -l $(git diff --name-only --diff-filter=AM 230954d867dd29b60865965dce3d7d0a19bcdf16 2c6847a3df0cb4f31068e5e7fb067d07b67c1eb3 -- '*.go') ); echo "exit $?"    (expected: no output)
A7. The probes of the ten real-kernel tests, written out by a throwaway copy of the tests (never committed, never pushed):
      git -C "$T/es" worktree add --detach "$T/dump" HEAD
    Write the patch at the end of these instructions into "$T/pr30-probe-dump.patch", exactly the text between its BEGIN and END marker lines (a quoted heredoc such as cat > "$T/pr30-probe-dump.patch" <<'PR30_EOF' keeps tabs and text unchanged). Check:
      shasum -a 256 "$T/pr30-probe-dump.patch"    (expected e540169e776b30514c3bea2f792fac25ca1d74e1f67d85dfc5c2dff790604d9d. The patch holds tab characters, and the sum depends on them. If it differs, rewrite it once. If it still differs, go on with --ignore-whitespace added to both apply commands below; the ten probe sums decide.)
      git -C "$T/dump" apply --check "$T/pr30-probe-dump.patch" && git -C "$T/dump" apply "$T/pr30-probe-dump.patch"
    (If the patch does not apply, skip the rest of A7 and steps B3b, B5b and B5c.)
      mkdir "$T/probes"
      ( cd "$T/dump" && PR30_PROBE_DUMP="$T/probes" go test -count=1 -run '^(TestRemoteAlphaESServiceTLSStatusChildNamespaceReal.*|TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantReal.*)$' ./scripts/ ); echo "exit $?"
      ls "$T/probes"; shasum -a 256 "$T/probes"/*.py
    Expected: exit 0 (every one of these tests skips itself on macOS), and exactly these ten files with these sums:
      e58a0236c1853217b26e1352b7d915fc739642cb3e1408f7bcfc418c713fc619  TestRemoteAlphaESServiceTLSStatusChildNamespaceRealCollectorDeath.py
      ddb3b5017dceb22aefbbd447eaf41121818d0395ef26803144cf0052b6817ad9  TestRemoteAlphaESServiceTLSStatusChildNamespaceRealDeafAnchor.py
      9159e0545b6616eb899c429c24b05ee83bd83b5db8a201553a09c5197255da4e  TestRemoteAlphaESServiceTLSStatusChildNamespaceRealDescendants.py
      2ef371c98c06cb377814e636e39c5a05e78c7f972d8f7718425b8874d46e0790  TestRemoteAlphaESServiceTLSStatusChildNamespaceRealKernel.py
      1b78b0a24fe47c49702f2af439a87bb4b4c879b0350baf71569790cab95c0e8f  TestRemoteAlphaESServiceTLSStatusChildNamespaceRealSiblings.py
      d0a03105193616aa483e38fd53c501459a25fbcc9f8c8179f623195eade9cd62  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCollectorDeath.py
      6e817c3f1b6419d2364552d9662fb5d49c0dd0a588594f2389ef421bfb2e1a85  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCrowd.py
      955bd7ba937da6c76c0433eb7d7718c33e00037e1bba1ce496f51b333efc5dac  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealKernel.py
      114fa25f9b0941967d131ccac3482c839dd5539f341c3e568e9c183a95dd89f5  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealProbeRefusesAChild.py
      994307b450360a29d8f9353926d37271b931822c34466558f31d9110c51d982f  TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealProcessLimit.py
    If any sum differs or a file is missing, say which, skip steps B3b, B5b and B5c, and go on.

Part B, on the box (only if A0 showed [home network address withheld]):
B1. Baseline and facts, read only:
      BOX 'hostname; uname -r; nproc; /usr/bin/python3 --version; /usr/bin/openssl version; id -un; id -u; sudo -n true && echo "sudo -n: ok"; sudo -V | head -1; systemctl is-active es ags ars egs nomad vault spire-agent spire-server docker'
      BOX 'echo "ptrace_scope=$(cat /proc/sys/kernel/yama/ptrace_scope 2>&1)"; echo "pid_max=$(cat /proc/sys/kernel/pid_max)"; echo "ulimit -u=$(ulimit -u)"; grep "Max processes" /proc/self/limits; systemctl show -p TasksMax -p TasksCurrent "user-$(id -u).slice"; cat /proc/self/cgroup; grep -H pam_limits /etc/pam.d/sshd /etc/pam.d/sudo /etc/pam.d/common-session 2>&1; grep -H -v "^\s*#" /etc/security/limits.conf /etc/security/limits.d/* 2>/dev/null | grep -i nproc; free -m | head -2; command -v cc gcc || echo "no C compiler"'
B2. Whether sudo -n uses a pseudo-terminal, read only:
      BOX 'sudo -n -l 2>&1 | sed -n "/Matching Defaults/,/^\$/p"; sudo -n /usr/bin/tty </dev/null; echo "tty_exit=$?"; sudo -n /usr/bin/tty; echo "tty_exit=$?"'
B3. Stage. Write the five scripts at the end of these instructions into "$T/pr30_box_probe.py", "$T/pidfd_answers.py", "$T/pr30_storm.py", "$T/rt_storm.py" and "$T/storm.c", each with exactly the text between its BEGIN and END marker lines (not the marker lines themselves), with quoted heredocs as in A7. Check:
      shasum -a 256 "$T/pr30_box_probe.py" "$T/pidfd_answers.py" "$T/pr30_storm.py" "$T/rt_storm.py" "$T/storm.c"
    expected cf6dcadec4662c709ffe14503c0b05c0b23624422dfec3dedd18f30fb79aeb75, f22289dd4d93fe55fdd13429af0ca623d79f2e3ee2657ca45ab398af17b38dad, 93ff9349bab5f9793bc6fb5d893a1f46d1611b1ef614179dfebe4fc9a5db89b0, d4da66a87441abedfb4c4b58f9bcd68f633cef11b57a78d23f7310e818ecd722 and 2d709ed57636b41bea1cc75b43769175a15138785b53773631ceb49a33183ee4. If one differs, rewrite it once; if pr30_box_probe.py or pidfd_answers.py still differs, skip the rest of part B and report the sums; if one of the other three still differs, skip only step B6d.
    Write the eed4c9b collectors next to them (only if A2 found eed4c9b):
      mkdir "$T/old"; for f in remote_alpha_es_tls_status.py remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py; do git -C "$T/es" show eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea:scripts/internal/$f > "$T/old/$f"; done
    Then create the box folder and print it:
      D=$(BOX 'mktemp -d /tmp/pr30-box.XXXXXX'); printf '%s\n' "$D"
    It must match ^/tmp/pr30-box\.[A-Za-z0-9]{6}$; if not, stop part B.
      BOX "umask 077 && mkdir '$D/new' '$D/old' '$D/probes' '$D/storm'"
    Copy (every file is written with umask 077):
      put() { ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] "umask 077 && cat > '$D/$2'" < "$1"; }
      put "$T/es/scripts/internal/remote_alpha_es_tls_status.py" new/remote_alpha_es_tls_status.py
      put "$T/es/scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py" new/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py
      put "$T/old/remote_alpha_es_tls_status.py" old/remote_alpha_es_tls_status.py
      put "$T/old/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py" old/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py
      for f in pr30_box_probe.py pidfd_answers.py pr30_storm.py; do put "$T/$f" "$f"; done
      put "$T/rt_storm.py" storm/rt_storm.py; put "$T/storm.c" storm/storm.c
B3b. Copy the probes (only if A7 succeeded):
      for f in "$T/probes"/*.py; do put "$f" "probes/$(basename "$f")"; done
    Check everything (also when B3b was skipped):
      BOX "cd '$D' && sha256sum new/* old/* probes/* storm/* *.py; stat -c '%a %U %n' '$D' '$D'/* '$D'/*/*"
    Expected: new/remote_alpha_es_tls_status.py 5c356d9cdee8fda6ddd5643af4b2465229a1ca76e72c251d540954d59b76bcf4, new/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py 432366fad4572aa115fac1e341146bdf7ca40674d2573f3397d8bc9898986273, old/remote_alpha_es_tls_status.py b5a1344f1f0de75c13b7b1d2d54b27cc71630e7cd4b495408b7943f72771d474, old/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py 33e5f4d5bcfab7c5524703d14e9c97ec6e3f47d29fc18c0431ed6efaa16aa4c8, and the sums of A7 and B3. Every folder is 700 and every file 600, all owned by the login user. If any sum differs, go to B7.
B4. The noninteractive remote collector as the login user, in its real launch shape (the script goes on standard input):
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o RequestTTY=no [test box name withheld] "exec /usr/bin/python3 -I -S -B - r2 '$D'" < "$T/pr30_box_probe.py"; echo "exit $?"
B5. The root collector as root through sudo, as the operator route starts it:
      BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_box_probe.py' root '$D'"; echo "exit $?"
B5b. The five PID-namespace tests' probes as root, each against the new and then the old collector (only if B3b was done; each takes up to 150 s):
      for n in RealKernel RealDescendants RealCollectorDeath RealSiblings RealDeafAnchor; do for v in new old; do BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_box_probe.py' probe TestRemoteAlphaESServiceTLSStatusChildNamespace$n $v '$D'"; echo "exit $?"; done; done
B5c. The five remote collector tests' probes as the login user, each against the new and then the old collector (only if B3b was done):
      for n in RealKernel RealProbeRefusesAChild RealCrowd RealProcessLimit RealCollectorDeath; do for v in new old; do BOX "/usr/bin/python3 -I -B '$D/pr30_box_probe.py' probe TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendant$n $v '$D'"; echo "exit $?"; done; done
B6. pidfd answers, as the login user and as root:
      BOX "/usr/bin/python3 -I -B '$D/pidfd_answers.py'"; echo "exit $?"
      BOX "sudo -n /usr/bin/python3 -I -B '$D/pidfd_answers.py'"; echo "exit $?"
B6d. Optional, variant c of red-team 12. Do it only if all of these hold:
    - B1 printed a C compiler;
    - B1 shows at least 2 GB of free memory and a TasksMax of at least 10000 (or "infinity");
    - the B3 sums of pr30_storm.py, rt_storm.py and storm.c matched.
    It starts up to about 4,000 short-lived processes at a time as root in a PID namespace of its own, for about ten minutes in all; the kernel ends them with the namespace.
      BOX "umask 077 && cc -O2 -o '$D/storm/storm' '$D/storm/storm.c' && sha256sum '$D/storm/storm'"
      BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_storm.py' '$D' new"; echo "exit $?"
      BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_storm.py' '$D' old"; echo "exit $?"
B7. Leftovers and cleanup on the box (run this whenever a box folder was created):
      BOX "ps -eo pid,ppid,user,stat,args | grep -F '$D' | grep -v grep; ps -eo pid,ppid,user,stat,args | grep -E 'fixed-openssl|pidfd_answers|rt_storm' | grep -v grep"
    If any process line appears, run once: BOX "sudo -n pkill -KILL -f '$D/'", wait five seconds and list again; report both lists. Then:
      BOX "sudo -n rm -rf '$D'; ls -ld '$D' 2>&1; systemctl is-active es ags ars egs nomad vault spire-agent spire-server docker"
    Expected: no process line, "No such file or directory" for the folder, and the same service states as in B1.

Part C, on the Mac:
C1. ps -axo pid,ppid,stat,command | grep -E '\.test|remote_alpha_es_tls_status|es-p30-run' | grep -v grep    (expected: no output)
C2. git -C "$T/es" status --porcelain    (expected: empty; the throwaway copy of step A7 is a separate worktree)
C3. find /Users/ds/go/pkg/mod -newer "$T/start-marker" -print | head -5    (expected: no output)
C4. git -C "$T/es" worktree remove --force "$T/dump" (if A7 created it), then rm -rf "$T", then confirm "$T" is gone and /Users/ds/Repositories/Playground still exists. If the removal is refused, do not retry; say so and give David the one-line command.

Report back:
- the A0 addresses, the environment lines, the commit and tree hashes, and the go version lines;
- for A4 to A7, the items asked above;
- for B1 to B7 (with B6d if run), the complete output of every command, with every JSON line verbatim and every exit status.
Say plainly what passed and what failed. Do not summarize a failure away.

## Files to write (exact text between the marker lines)

----- BEGIN pr30-probe-dump.patch -----
diff --git a/scripts/pr30_probe_dump_test.go b/scripts/pr30_probe_dump_test.go
new file mode 100644
index 0000000..d938159
--- /dev/null
+++ b/scripts/pr30_probe_dump_test.go
@@ -0,0 +1,19 @@
+package scripts_test
+
+import (
+	"os"
+	"path/filepath"
+	"testing"
+)
+
+// For the PR #30 box run only, never committed: writes the probe of each
+// real-kernel test to $PR30_PROBE_DUMP/<test name>.py before it runs.
+func pr30DumpProbe(t *testing.T, argv []string) {
+	dir := os.Getenv("PR30_PROBE_DUMP")
+	if dir == "" {
+		return
+	}
+	if err := os.WriteFile(filepath.Join(dir, t.Name()+".py"), []byte(argv[3]), 0o600); err != nil {
+		t.Fatal(err)
+	}
+}
diff --git a/scripts/remote_alpha_es_service_tls_status_process_identity_test.go b/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
index 188d4ec..1bcc6c5 100644
--- a/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
+++ b/scripts/remote_alpha_es_service_tls_status_process_identity_test.go
@@ -18,6 +18,7 @@ func runRemoteAlphaESProcessIdentityProbe(t *testing.T, probe string, args ...st
 	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
 	defer cancel()
 	argv := append([]string{"-I", "-B", "-c", probe, remoteAlphaESServiceTLSStatusCollectorPath()}, args...)
+	pr30DumpProbe(t, argv)
 	cmd := exec.CommandContext(ctx, "/usr/bin/python3", argv...)
 	cmd.Dir = executionSubstrateRepoRoot
 	cmd.Env = append(os.Environ(), "PYTHONDONTWRITEBYTECODE=1")
diff --git a/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go b/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
index 90da4f3..a3554ea 100644
--- a/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
+++ b/scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go
@@ -55,6 +55,7 @@ func runRemoteCollectorDescendantProbe(t *testing.T, probe string, args ...strin
 	ctx, cancel := context.WithTimeout(context.Background(), 120*time.Second)
 	defer cancel()
 	argv := append([]string{"-I", "-B", "-c", probe, p0vRemoteCollectorPath()}, args...)
+	pr30DumpProbe(t, argv)
 	cmd := exec.CommandContext(ctx, "/usr/bin/python3", argv...)
 	cmd.Dir = executionSubstrateRepoRoot
 	cmd.Env = append(os.Environ(), "PYTHONDONTWRITEBYTECODE=1")
----- END pr30-probe-dump.patch -----

----- BEGIN pr30_box_probe.py -----
# PR #30 box probe: child containment of both Remote Alpha TLS status collectors.
# It loads the collectors from DIR, as staged from the pull request head (new/)
# and from eed4c9b (old/), and writes only below DIR. It starts and ends its
# own processes only.
#
#   root DIR  as root through sudo -n: facts, the root collector's whole
#             capability probe, one real "openssl version" through run_fixed,
#             and four stand-in fixed commands (an escaped descendant, an
#             escaped descendant that keeps an ended child unreaped in the
#             group, the same descendant while the fixed command still runs
#             at a time limit of one second, and a command that runs for one
#             second).
#   r2 DIR    as the SSH user, started as `exec /usr/bin/python3 -I -S -B - r2 DIR`
#             with this file on standard input: facts, the noninteractive
#             remote collector's descendant probe, and one fixed command whose
#             escaped descendant would ignore TERM, and two fixed commands
#             through sudo -n, all under the fixed child's process limit.
#   probe NAME VARIANT DIR
#             runs DIR/probes/NAME.py, the probe of one real-kernel test of the
#             pull request head, against the collector in DIR/VARIANT (new or
#             old), with the arguments that the test gives it, and reports its
#             JSON. As root through sudo -n for the TLS status collector's
#             tests, as the SSH user for the remote collector's tests.
import importlib.util, json, os, resource, signal, subprocess, sys, time

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def status_fields(*names):
    found = {}
    with open("/proc/self/status") as handle:
        for line in handle:
            key, _, value = line.partition(":")
            if key in names:
                found[key] = value.strip()
    return found

def proc_value(path):
    try:
        with open(path) as handle:
            return handle.read().strip()
    except OSError as exc:
        return "unreadable: " + type(exc).__name__

def watch(path):
    os.mkfifo(path, 0o600)
    return os.open(path, os.O_RDONLY | os.O_NONBLOCK)

def drain(reader):
    # Everything written so far, and whether a writer is still there.
    data = b""
    while True:
        try:
            chunk = os.read(reader, 65536)
        except BlockingIOError:
            return data, True
        if chunk == b"":
            return data, False
        data += chunk

def say(report):
    print(json.dumps(report, sort_keys=True), flush=True)

FIXED_CHILD = r'''#!/usr/bin/python3 -I
import os, signal, sys, time
mode, fifo, release = sys.argv[1:4]
out = os.open(fifo, os.O_WRONLY)
os.write(out, b"fixed\n")
def stay():
    end = time.monotonic() + 30
    while time.monotonic() < end and not os.path.exists(release):
        time.sleep(0.02)
if mode == "slow":
    time.sleep(1.0); sys.stdout.write("fixed"); sys.stdout.flush(); sys.exit(0)
ready_r, ready_w = os.pipe()
if os.fork() == 0:
    for fd in (0, 1, 2, ready_r):
        os.close(fd)
    if mode in ("zombie", "zombie-run"):
        held = os.fork()
        if held == 0:
            os.write(out, b"held\n"); os._exit(0)
        os.waitid(os.P_PID, held, os.WEXITED | os.WNOWAIT)
    os.setsid()
    signal.signal(signal.SIGTERM, signal.SIG_IGN); signal.signal(signal.SIGHUP, signal.SIG_IGN)
    os.write(out, b"escaped\n"); os.write(ready_w, b"r"); os.close(ready_w)
    stay()
    if not os.path.exists(release):
        os.write(out, b"lapsed\n")
    os._exit(0)
os.close(ready_w); os.read(ready_r, 1)
if mode == "zombie-run":
    stay()
sys.stdout.write("fixed"); sys.stdout.flush()
'''

def root_part(base):
    work = os.path.join(base, "root-work")
    os.mkdir(work, 0o700)
    say({"part": "root facts", "uid": os.getuid(), "euid": os.geteuid(), "python": sys.version.split()[0],
         "cpus": os.cpu_count(), "kernel.pid_max": proc_value("/proc/sys/kernel/pid_max"),
         "kernel.yama.ptrace_scope": proc_value("/proc/sys/kernel/yama/ptrace_scope"),
         "os.unshare": hasattr(os, "unshare"), "os.setns": hasattr(os, "setns"),
         "pid_for_children": os.path.exists("/proc/self/ns/pid_for_children"),
         "status": status_fields("NoNewPrivs", "Seccomp", "CapEff", "Threads"),
         "user.max_pid_namespaces": proc_value("/proc/sys/user/max_pid_namespaces"),
         "kernel.apparmor_restrict_unprivileged_userns": proc_value("/proc/sys/kernel/apparmor_restrict_unprivileged_userns")})
    module = load(os.path.join(base, "new", "remote_alpha_es_tls_status.py"), "pr30_root_collector")
    try:
        module.validate_process_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "root capability probe (both parts)", "verdict": verdict,
         "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})
    if verdict != "accepted":
        return
    module.PROCESS_CAPABILITY_READY = True
    try:
        result = module.run_fixed((module.OPENSSL, "version"))
        say({"part": "real openssl version in its own PID namespace", "returncode": result[0],
             "stdout": result[1].decode("ascii", "replace").strip(), "stderr_bytes": len(result[2])})
    except BaseException as exc:
        say({"part": "real openssl version in its own PID namespace", "raised": repr(exc)})
    child = os.path.join(work, "fixed-openssl")
    with open(child, "w") as handle:
        handle.write(FIXED_CHILD)
    os.chmod(child, 0o700)
    fixed, module.OPENSSL = module.OPENSSL, child
    limit = module.CHILD_TIMEOUT
    for mode in ("setsid", "zombie", "zombie-run", "slow"):
        module.CHILD_TIMEOUT = 1.0 if mode == "zombie-run" else limit
        fifo = os.path.join(work, "events-" + mode)
        release = os.path.join(work, "release-" + mode)
        reader = watch(fifo)
        started = time.monotonic()
        try:
            result = module.run_fixed((module.OPENSSL, mode, fifo, release)); raised = None
        except BaseException as exc:
            result = None; raised = repr(exc)
        took = round(time.monotonic() - started, 3)
        data, alive = drain(reader)
        if alive:
            open(release, "w").close()
            time.sleep(1.0)
        os.close(reader)
        say({"part": "stand-in fixed command, mode " + mode, "result": repr(result), "raised": raised,
             "seconds": took, "reports": data.decode().split(), "process left after return": alive})
    module.OPENSSL, module.CHILD_TIMEOUT = fixed, limit
    say({"part": "root end", "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})

def r2_part(base):
    work = os.path.join(base, "r2-work")
    os.mkdir(work, 0o700)
    module = load(os.path.join(base, "new", "remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py"),
                  "pr30_remote_collector")
    tid = os.listdir("/proc/self/task")
    cgroup = proc_value("/proc/self/cgroup")
    unified = [line[3:] for line in cgroup.splitlines() if line.startswith("0::")]
    say({"part": "r2 facts", "uid": os.getuid(), "python": sys.version.split()[0],
         "sigchld": str(signal.getsignal(signal.SIGCHLD)),
         "children file": proc_value("/proc/self/task/%s/children" % tid[0]) if len(tid) == 1 else tid,
         "status": status_fields("NoNewPrivs", "Seccomp", "Threads"),
         "RLIMIT_NPROC": resource.getrlimit(resource.RLIMIT_NPROC),
         "cgroup": cgroup, "pids.max": proc_value("/sys/fs/cgroup%s/pids.max" % unified[0]) if unified else "no cgroup v2",
         "pids.current": proc_value("/sys/fs/cgroup%s/pids.current" % unified[0]) if unified else "no cgroup v2",
         "process limit of the fixed child": module.FIXED_CHILD_PROCESS_LIMIT})
    try:
        module.validate_descendant_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "r2 descendant probe", "verdict": verdict, "flag": module.DESCENDANT_CAPABILITY_READY})
    if verdict != "accepted":
        return
    fifo = os.path.join(work, "events")
    reader = watch(fifo)
    # Under the process limit an unprivileged fixed child cannot fork, and it
    # says so; a fixed child that the limit does not bind (root) forks a
    # descendant that ignores TERM, which the drain must end.
    body = ("import errno,os,signal,time\nw=os.open(%r,os.O_WRONLY);os.write(w,b'x')\n"
            "signal.signal(signal.SIGTERM,signal.SIG_IGN)\n"
            "try:pid=os.fork()\nexcept OSError as exc:print(errno.errorcode[exc.errno]);raise SystemExit(0)\n"
            "if pid==0:\n    os.setsid();os.close(1);os.close(2);time.sleep(30);os._exit(0)\n"
            "print('forked')\n" % fifo)
    result = module.run_command(("/usr/bin/python3", "-I", "-c", body))
    time.sleep(0.2)
    data, alive = drain(reader)
    os.close(reader)
    say({"part": "r2 fixed command that tries to start a descendant that ignores TERM",
         "returncode": result.returncode, "stdout": result.stdout.decode("ascii", "replace").strip(),
         "runtime_failed": result.runtime_failed, "bytes from stand-ins": len(data),
         "process left after return": alive, "flag": module.DESCENDANT_CAPABILITY_READY})
    # The fixed sudo path runs sudo under the same process limit.
    for command in (("/usr/bin/sudo", "-n", "/usr/bin/id", "-u"),
                    ("/usr/bin/sudo", "-n", "/usr/bin/stat", "-c", "%a:%u:%g:%F", "/etc/hostname")):
        if not module.DESCENDANT_CAPABILITY_READY:
            break
        result = module.run_command(command)
        say({"part": "r2 fixed command through sudo -n under the process limit: " + " ".join(command[2:]),
             "returncode": result.returncode, "stdout": result.stdout.decode("ascii", "replace").strip(),
             "stderr": result.stderr.decode("ascii", "replace").strip()[-300:],
             "runtime_failed": result.runtime_failed, "flag": module.DESCENDANT_CAPABILITY_READY})

COLLECTORS = {"ESServiceTLSStatus": "remote_alpha_es_tls_status.py",
              "OperatorHealthcheckTLSStatus": "remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py"}

def probe_part(name, variant, base):
    # The arguments that the test gives its probe: the collector, then a new
    # empty directory, except for the namespace kernel test, which takes none.
    collector = os.path.join(base, variant, [f for k, f in COLLECTORS.items() if name.startswith("TestRemoteAlpha" + k)][0])
    argv = ["/usr/bin/python3", "-I", "-B", "-c", open(os.path.join(base, "probes", name + ".py")).read(), collector]
    if not name.startswith("TestRemoteAlphaESServiceTLSStatusChildNamespaceRealKernel"):
        work = os.path.join(base, "w-%s-%s" % (name, variant))
        os.mkdir(work, 0o700)
        argv.append(work)
    started = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    try:
        done = subprocess.run(argv, cwd=base, env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=150)
        code, out, err = done.returncode, done.stdout, done.stderr
    except subprocess.TimeoutExpired as exc:
        code, out, err = "timed out after 150 s", exc.stdout or b"", exc.stderr or b""
    took = round(time.monotonic() - started, 2)
    try:
        answer = json.loads(out)
    except ValueError:
        answer = {"unparsed stdout": out.decode("utf-8", "replace")[-2000:]}
    failed = sorted(label for label, passed in answer.get("cases", {}).items() if not passed)
    say({"part": "probe %s on %s" % (name[len("TestRemoteAlpha"):], variant), "exit": code, "seconds": took,
         "capability": answer.get("capability"), "reason": answer.get("reason"),
         "cases": len(answer.get("cases", {})), "failed cases": failed, "detail": answer.get("detail"),
         "unparsed stdout": answer.get("unparsed stdout"), "stderr tail": err.decode("utf-8", "replace")[-1500:]})

if __name__ == "__main__":
    if sys.argv[1] == "probe":
        probe_part(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        part, base = sys.argv[1], sys.argv[2]
        {"root": root_part, "r2": r2_part}[part](base)
----- END pr30_box_probe.py -----

----- BEGIN pidfd_answers.py -----
# What does pidfd_open(pid, 0) answer on this kernel for each kind of number?
import errno, os, signal, threading, time, subprocess, sys
def ans(pid):
    try:
        fd = os.pidfd_open(pid, 0)
    except OSError as exc:
        return errno.errorcode.get(exc.errno, exc.errno)
    os.close(fd); return "opened"
def sig0(fn, n):
    try: fn(n, 0); return "answers signal 0"
    except OSError as exc: return errno.errorcode[exc.errno]
print("kernel", os.uname().release, "python", sys.version.split()[0])
pid = os.fork()
if pid == 0:
    time.sleep(30); os._exit(0)
print("live child:", ans(pid))
os.kill(pid, signal.SIGKILL); os.waitid(os.P_PID, pid, os.WEXITED | os.WNOWAIT)
print("zombie child (terminal, not reaped):", ans(pid))
os.waitpid(pid, 0)
print("reaped child, number unused:", ans(pid))
# reaped group leader whose group still has a member
leader = os.fork()
if leader == 0:
    os.setpgid(0, 0)
    if os.fork() == 0:
        time.sleep(30); os._exit(0)
    time.sleep(30); os._exit(0)
time.sleep(0.3); os.kill(leader, signal.SIGKILL); os.waitpid(leader, 0)
print("reaped leader, group still has a member (group %s):" % sig0(os.killpg, leader), ans(leader))
os.killpg(leader, signal.SIGKILL); time.sleep(0.1)
# reaped session leader whose session still has a member in another group
r, w = os.pipe()
sl = os.fork()
if sl == 0:
    os.setsid()
    m = os.fork()
    if m == 0:
        os.setpgid(0, 0); time.sleep(30); os._exit(0)
    os.write(w, str(m).encode()); time.sleep(30); os._exit(0)
time.sleep(0.3); member = int(os.read(r, 20)); os.kill(sl, signal.SIGKILL); os.waitpid(sl, 0)
print("reaped session leader, session still has a member (member's sid %d, leader was %d):" % (os.getsid(member), sl), ans(sl))
os.kill(member, signal.SIGKILL)
# a live non-leader thread's TID
tid = []; ev = threading.Event(); stop = threading.Event()
t = threading.Thread(target=lambda: (tid.append(threading.get_native_id()), ev.set(), stop.wait()))
t.start(); ev.wait()
print("TID of a live non-leader thread of this process:", ans(tid[0]))
stop.set(); t.join()
# leader thread exited, another thread lives
code = "import os,threading,time,sys\nt=threading.Thread(target=lambda: time.sleep(5))\nt.start()\nsys.stdout.write('x');sys.stdout.flush()\nimport ctypes\nctypes.CDLL(None).syscall(60,0)\n"
p = subprocess.Popen([sys.executable, "-I", "-c", code], stdout=subprocess.PIPE)
p.stdout.read(1); time.sleep(0.3)
state = open("/proc/%d/stat" % p.pid, "rb").read().rsplit(b")", 1)[1].split()[0]
print("leader thread exited, another thread lives (stat state %s):" % state.decode(), ans(p.pid))
p.kill(); p.wait()
for n in (4194305, 2**31 - 1):
    print("number", n, "(above pid_max):", ans(n))
----- END pidfd_answers.py -----

----- BEGIN pr30_storm.py -----
# PR #30 box run, part D: variant c of red-team finding RT12-2 (fork-only capture of the
# namespace anchor) against the root TLS status collector, as root through sudo -n.
#   pr30_storm.py DIR VARIANT
# DIR holds new/ and old/ (the collectors), storm/rt_storm.py and storm/storm (the red-team's
# harness and stand-in, unchanged; storm is built from storm.c on the box). It writes only
# below DIR/storm and ends what it starts.
import json, os, signal, subprocess, sys, tempfile, time

base, variant = sys.argv[1], sys.argv[2]
collector = os.path.join(base, variant, "remote_alpha_es_tls_status.py")
harness = os.path.join(base, "storm", "rt_storm.py")

def say(report):
    print(json.dumps(report, sort_keys=True), flush=True)

def state(pid):
    try:
        with open("/proc/%d/stat" % pid) as handle:
            return handle.read().rsplit(")", 1)[1].split()[0]
    except OSError:
        return "gone"

def namespace(pid):
    try:
        return os.readlink("/proc/%d/ns/pid" % pid)
    except OSError:
        return None

def cmdline(pid):
    try:
        with open("/proc/%d/cmdline" % pid, "rb") as handle:
            return handle.read()
    except OSError:
        return b""

def children(pid):
    found = []
    try:
        for task in os.listdir("/proc/%d/task" % pid):
            with open("/proc/%d/task/%s/children" % (pid, task)) as handle:
                found += [int(word) for word in handle.read().split()]
    except OSError:
        pass
    return found

def start(sleepers, chains, seconds, shape):
    work = tempfile.mkdtemp(prefix="run.", dir=os.path.join(base, "storm"))
    return work, subprocess.Popen(["/usr/bin/python3", "-I", "-B", harness, collector, work, str(sleepers),
                                   str(chains), str(seconds), shape],
                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

def anchor_and_fixed(collector_pid):
    # The anchor is the collector's child in another PID namespace that runs Python;
    # the fixed child is the one that runs the stand-in.
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        anchor = fixed = None
        for pid in children(collector_pid):
            if namespace(pid) != namespace(collector_pid):
                line = cmdline(pid)
                if b"fixed-openssl" in line:
                    fixed = pid
                elif b"python3" in line:
                    anchor = pid
        if anchor and fixed:
            return anchor, fixed
        time.sleep(0.02)
    return None, None

say({"part": "variant c facts", "collector": variant, "cpus": os.cpu_count(),
     "kernel.pid_max": open("/proc/sys/kernel/pid_max").read().strip()})
for sleepers, chains in ((0, 0), (4000, 4)):
    for run in range(1, 6):
        work, proc = start(sleepers, chains, 5, "zombie")
        try:
            out, _ = proc.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            proc.kill(); out, _ = proc.communicate()
        lines = [json.loads(line) for line in out.decode().splitlines() if line.startswith("{")]
        result = lines[-1] if lines and "seconds" in lines[-1] else {"unparsed": out.decode()[-500:]}
        say({"part": "variant c hold", "collector": variant, "sleepers": sleepers, "chains": chains, "run": run,
             "seconds": result.get("seconds"), "result": result.get("result"), "raised": result.get("raised"),
             "lapsed reports": result.get("reports", {}).get("lapsed", 0),
             "process left after return": result.get("process left after return"),
             "held": (result.get("seconds") or 0) >= 5})
        subprocess.run(["rm", "-rf", work])
for sleepers, chains in ((0, 0), (4000, 4)):
    work, proc = start(sleepers, chains, 12, "run")
    anchor, fixed = anchor_and_fixed(proc.pid)
    time.sleep(1.5)
    before = (state(anchor) if anchor else None, state(fixed) if fixed else None)
    proc.kill(); proc.wait()
    killed = time.monotonic(); ended = None
    while time.monotonic() - killed < 30 and fixed:
        if state(fixed) not in ("S", "R", "D"):
            ended = round((time.monotonic() - killed) * 1000)
            break
        time.sleep(0.01)
    leftover = None
    if fixed and ended is None and anchor and state(anchor) != "gone":
        leftover = "the fixed child still ran 30 s after the collector's death; the anchor was ended by SIGKILL"
        os.kill(anchor, signal.SIGKILL)
    time.sleep(4)
    say({"part": "variant c killed collector", "collector": variant, "sleepers": sleepers, "chains": chains,
         "anchor and fixed child found": bool(anchor and fixed), "states before the kill": before,
         "fixed child no longer runs after ms": ended, "leftover": leftover,
         "anchor state 4 s later": state(anchor) if anchor else None})
    subprocess.run(["rm", "-rf", work])
----- END pr30_storm.py -----

----- BEGIN rt_storm.py -----
# Red-team harness: one run_fixed of the root collector with the fork-only stand-in "storm".
# argv: collector.py workdir sleepers chains seconds shape
import faulthandler, importlib.util, json, os, pathlib, shutil, signal, sys, time
spec = importlib.util.spec_from_file_location("rt_collector", sys.argv[1])
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
work = pathlib.Path(sys.argv[2]); sleepers, chains, seconds, shape = sys.argv[3:7]
child = work / "fixed-openssl"
shutil.copy(os.path.join(os.path.dirname(os.path.abspath(__file__)), "storm"), child); child.chmod(0o700)
fifo = work / "events"
os.mkfifo(fifo); reader = os.open(fifo, os.O_RDONLY | os.O_NONBLOCK)
def drain(reader):
    data = b""
    while True:
        try: chunk = os.read(reader, 65536)
        except BlockingIOError: return data, True
        if chunk == b"": return data, False
        data += chunk
module.validate_process_capability(); module.PROCESS_CAPABILITY_READY = True
module.OPENSSL = str(child)
print(json.dumps({"collector_pid": os.getpid()}), flush=True)
faulthandler.enable(); faulthandler.register(signal.SIGUSR1, all_threads=True)
if os.environ.get("RT_LATCH") == "1":
    for signum in module.SIGNALS:
        signal.signal(signum, module._latch)
started = time.monotonic()
try:
    result = module.run_fixed((module.OPENSSL, str(fifo), sleepers, chains, seconds, shape)); raised = None
except BaseException as exc:
    result = None; raised = repr(exc)
took = round(time.monotonic() - started, 3)
data, alive = drain(reader)
labels = {}
for line in data.decode().split("\n"):
    if line:
        labels[line.split()[0]] = labels.get(line.split()[0], 0) + 1
try:
    os.waitpid(-1, os.WNOHANG); child_left = True
except ChildProcessError:
    child_left = False
print(json.dumps({"sleepers": int(sleepers), "chains": int(chains), "shape": shape, "stand-in lapse": float(seconds),
                  "result": repr(result), "raised": raised, "seconds": took, "reports": labels,
                  "process left after return": alive, "collector still has a child": child_left,
                  "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)}), flush=True)
----- END rt_storm.py -----

----- BEGIN storm.c -----
// Red-team stand-in for the fixed OpenSSL command of the root collector. It uses fork only:
// no capability, no /proc, no ptrace. argv: storm <fifo> <sleepers> <chains> <seconds> <shape>
//   shape "zombie": the T7-1 shape (a living descendant outside the fixed child's group keeps
//                   an ended child unreaped inside it), "plain": none, "run": the fixed child stays.
// The sleepers become orphans, so they are children of the namespace's first process (the anchor).
// Every link of a chain ends as soon as it has forked the next one, so the anchor is handed one
// ended child per link.
#define _GNU_SOURCE
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
static int out;
static void say(const char *label) {
    char line[128];
    int n = snprintf(line, sizeof line, "%s %d %d %d %d\n", label, getpid(), getppid(), getpgid(0), getsid(0));
    if (write(out, line, n) < 0) {}
}
int main(int argc, char **argv) {
    if (argc != 6) return 2;
    int sleepers = atoi(argv[2]), chains = atoi(argv[3]);
    double end = now() + atof(argv[4]);
    const char *shape = argv[5];
    out = open(argv[1], O_WRONLY);
    say("fixed");
    int ready[2];
    if (pipe(ready)) return 3;
    pid_t holder = fork();
    if (holder == 0) {
        close(0); close(1); close(2); close(ready[0]);
        if (!strcmp(shape, "zombie")) {
            pid_t held = fork();
            if (held == 0) { say("held"); _exit(0); }
            siginfo_t info;
            waitid(P_PID, held, &info, WEXITED | WNOWAIT);
        }
        setsid();
        signal(SIGTERM, SIG_IGN); signal(SIGHUP, SIG_IGN);
        pid_t mid = fork();
        if (mid == 0) {
            for (int i = 0; i < sleepers; i++)
                if (fork() == 0) { while (now() < end) usleep(20000); _exit(0); }
            for (int c = 0; c < chains; c++)
                if (fork() == 0) {
                    setsid();
                    while (now() < end) {
                        pid_t next = fork();
                        if (next > 0) _exit(0);           // this link ends; the next one goes on
                        if (next < 0) usleep(200);         // no process number left: try again
                    }
                    say("lapsed");
                    _exit(0);
                }
            _exit(0);
        }
        waitpid(mid, NULL, 0);
        say("escaped");
        if (write(ready[1], "r", 1) < 0) {}
        close(ready[1]);
        while (now() < end) usleep(20000);
        say("lapsed");
        _exit(0);
    }
    close(ready[1]);
    char c;
    if (read(ready[0], &c, 1) < 0) {}
    if (!strcmp(shape, "run")) {
        close(0); close(1); close(2);
        while (now() < end) usleep(20000);
        _exit(0);
    }
    if (write(1, "fixed", 5) < 0) {}
    return 0;
}
----- END storm.c -----
