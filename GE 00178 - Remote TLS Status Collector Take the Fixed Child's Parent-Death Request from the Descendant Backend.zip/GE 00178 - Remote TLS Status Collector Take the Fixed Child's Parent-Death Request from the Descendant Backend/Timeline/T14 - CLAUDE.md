Everyone's fine. The work runs in the cloud, so the crash didn't touch it. Nothing was using your Mac at the time, and the Nomad HTTPS work is still going. When the next box run needs the Mac, please have the Claude app open again.

STATUS: WORKING (Nomad HTTPS; PR 58 merging)
