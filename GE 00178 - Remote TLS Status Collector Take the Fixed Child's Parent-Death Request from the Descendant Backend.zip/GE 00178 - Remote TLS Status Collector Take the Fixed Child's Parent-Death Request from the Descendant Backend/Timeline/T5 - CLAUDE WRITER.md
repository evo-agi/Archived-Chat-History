**P30 did not pass: the box part passed, but four tests fail on the Mac. The box is back to working.** After the run, all nine services were active as before, nothing from the run was still running, and its `/tmp` folder was gone.

- **Box: passed.** Every check of the new collectors passed, as root through `sudo -n` and as the SSH user, under the box's sudo, PAM and kernel 7.0. That includes the fixed `sudo -n` commands under the process limit of zero. The old collectors failed exactly the cases I predicted.
- **Mac: failed.** Four tests in `./scripts` fail with `AttributeError: ... prctl: symbol not found`. PR #30's remote collector looks up Linux's `prctl` before it starts each fixed command, and macOS has none. The test stand-in sets the capability flag on any host, so the tests reach that lookup even on a Mac. CI tests only on Linux, so it never saw this. Production on the box is not affected.

Per the gate, nobody runs a TLS status check on the box from a commit that contains #30 until this is fixed and checked again.

**Proposed fix:** a small follow-up PR. The parent-death request becomes one collector function, and the test stand-in replaces it as well. The four tests then run on every host again, and the Linux-only tests still prove the real signal. I'm drafting it now; it needs an audit when you schedule one. After that, a partial P30 rerun covers the Mac tests and the remote collector's box steps (about 10 minutes).

Optional variant c was skipped, because the box has no C compiler.

STATUS: P30 box passed, Mac failed; fix PR in progress (draft); box handed back.
