PR #58 is ready for audit: https://github.com/evo-agi/Execution-Substrate/pull/58

- Head `b3965921a67509d9f66c4a65e61b0a6944c2dbf7`, base trunk_dev `fd0529a`, one commit, 3 files.
- Manifest v2 `7e2359e95553c39df3b648cf5d83f41053cf0f456ea66054e465be8528d2da1b` (taken twice, identical; recipe sum checked).
- The fix: the fixed child's parent-death request is now a kernel operation of the descendant backend, which the tests already replace. A setup that cannot be prepared is a runtime failure with no spawn. The root collector is unchanged.
- Validation: I hid `prctl` from both container Pythons. That reproduced exactly the Mac's 4 failures at fd0529a, and all 4 pass at b396592. The collector family passes 67/67. Vet is clean for linux and darwin. Mutants: 5/5 caught. Details are in [24-fix-macos-prctl.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/24-fix-macos-prctl.md).
- CI is still running. I'll report only if it fails. Codex did not review this time because its usage limit was reached.

**macOS CI: cheap and feasible.**
- The repo is public, so GitHub's standard macOS runners cost nothing.
- My plan is a separate workflow file that runs the existing test gate on macOS for `./scripts/...` only, with its own macOS list of failing and skipping tests. go.yml stays unchanged.
- That needs a small optional package-pattern argument in `go_test_gate.py`, with self-test coverage.
- The macOS list comes from the CI PR's own first macOS run.
- This thread can push only one branch, so the CI PR opens after #58 merges. I'm preparing it locally now.
- Making the macOS job a required check is a ruleset setting only David can change.

After #58 merges, the partial P30 rerun needs its own box turn: Mac A4, plus box B3b, B4 and B5c.

STATUS: PR #58 at b396592 awaiting audit; CI running; macOS CI PR being prepared locally; P30 gate closed.
