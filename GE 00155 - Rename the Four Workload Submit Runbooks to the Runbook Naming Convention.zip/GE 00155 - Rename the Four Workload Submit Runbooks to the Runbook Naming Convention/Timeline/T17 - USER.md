> Good middle path, so I'm going with it and withdrew the card. All four runbooks stay in ES as the maintained versions, r…


FYI, I clicked "Skip" on the cards.
