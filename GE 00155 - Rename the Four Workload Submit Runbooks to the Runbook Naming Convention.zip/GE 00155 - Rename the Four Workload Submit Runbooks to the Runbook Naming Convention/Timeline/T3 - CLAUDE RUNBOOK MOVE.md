First I'll inventory ES's .runbooks folder and everything that links to it.
