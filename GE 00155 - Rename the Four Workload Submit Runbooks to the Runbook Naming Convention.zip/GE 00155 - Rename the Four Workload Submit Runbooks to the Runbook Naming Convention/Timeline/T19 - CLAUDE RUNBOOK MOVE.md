Done the way you described. ES keeps its runbooks, now named like the runbook repo's, and the runbook repo holds copies that point back to ES.

- **ES** ([PR #37](https://github.com/evo-agi/Execution-Substrate/pull/37), now renames only): the four `.runbooks/execution/` files become `Governed Execution ES <Topic>.md`, and their titles match. All links and the two paths printed by the Linux setup script follow the rename. Nothing is deleted. The bring-up runbook keeps its old name, because ES's scripts and tests and Infrastructure Manager read that exact path. CI is running, and the audit comes next.
- **Runbook repo** ([main 5b58000](https://github.com/evo-agi/Archived-Runbooks/commit/5b58000)): each copy matches its ES file word for word, which I checked byte for byte. A note at the top links the ES version and says that if they differ, ES wins. The copies' links to the new names go live when #37 merges.
- **Keeping them in step:** [Archived-Runbooks PR #4](https://github.com/evo-agi/Archived-Runbooks/pull/4) adds a daily check that fails, and emails you, when a copy no longer matches ES. Please merge it after #37 merges. Before that, its first run would fail.

STATUS: WAITING (CI and audit on ES #37; then your merge of runbook-repo PR #4)
