> The four ES runbooks are copied to the private runbook repo, and PR 37 (→ github.com) removes them from ES. That raised …


Not sure which card to choose.

If the concern is about showing outsiders how to use the system, we can rename ES's runbooks (please see runbook repo's naming convention), and duplicate them in the runbook repo, with disclaimers that the actively maintained version(s) are in ES, and with links that point to ES's counterparts.
