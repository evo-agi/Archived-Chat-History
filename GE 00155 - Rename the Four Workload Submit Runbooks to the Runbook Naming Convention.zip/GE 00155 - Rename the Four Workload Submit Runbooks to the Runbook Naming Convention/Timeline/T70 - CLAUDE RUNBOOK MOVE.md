The runbook rename is merged into ES trunk_dev. [ES #37](https://github.com/evo-agi/Execution-Substrate/pull/37) is in as 42db339, and the runbook repo's copy check now passes against it. [Runbook repo #4](https://github.com/evo-agi/Archived-Runbooks/pull/4) is ready for you to merge.

While merging, CI showed a flaky bring-up test: tests picked ports that another process could grab first. The fix is open as [ES #42](https://github.com/evo-agi/Execution-Substrate/pull/42) and is being audited.

STATUS: waiting on your merge of #4, and on the audit and CI for #42.
