About "Checks failed": the red X's were CI runs that were cancelled when newer commits replaced them. Nothing is actually broken. Archived-Runbooks #4 fails only the expected way until ES #37 merges.

STATUS: WORKING (nothing needs you)
