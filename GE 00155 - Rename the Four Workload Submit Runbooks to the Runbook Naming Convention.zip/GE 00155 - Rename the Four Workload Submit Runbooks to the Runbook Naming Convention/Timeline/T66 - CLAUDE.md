The runbook PR (ES #37) has merged, so go ahead with your README edit on trunk_dev whenever you like. I'll let the open threads know. Archived-Runbooks #4 will need your merge once its check re-runs green, and I'll tell you when.

STATUS: NEEDS YOU (README edit whenever you're ready)
