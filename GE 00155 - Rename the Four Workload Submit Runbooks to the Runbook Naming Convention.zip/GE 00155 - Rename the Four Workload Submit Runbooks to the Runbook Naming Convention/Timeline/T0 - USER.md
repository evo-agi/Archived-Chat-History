> Here is a low-priority item that needs careful coordination to not break parallel threads: I've been wanting to rename p…


Adding to this, we should move the runbooks in ES's `.runbooks/execution` to the archived runbook repo; and delete the one in ES.

Hmm... I think I mentioned this backlog item before. Not sure what happened.
