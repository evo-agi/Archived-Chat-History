Asked the project to choose an option

Should public ES keep any of the submit runbooks?

1. Keep the 2 current ones in ES (recommended): I trim PR #37 so only the 2 legacy runbooks move. The static-script and Vault-login guides stay public in ES, and I remove their private copies.
2. Move all four, as asked: PR #37 merges after audit. Public ES keeps the bring-up runbook and the one-command run. The step-by-step submit guides exist only in the private repo.
3. Keep all four in ES: I close PR #37 and remove the four copies from Archived-Runbooks, back to how things were on Nov 22.

Why recommended: ES is the public product. These two are its only step-by-step guides to submitting work and to the identity-to-Vault flow. The 2 legacy ones are of no use to outsiders.
