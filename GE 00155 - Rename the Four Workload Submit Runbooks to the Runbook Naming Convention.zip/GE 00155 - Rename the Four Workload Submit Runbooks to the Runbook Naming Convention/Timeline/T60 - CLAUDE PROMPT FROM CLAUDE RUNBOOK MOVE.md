Here is the response from CLAUDE RUNBOOK MOVE:

ES #37 CI on 4736803 failed one test, and I've re-run that job once. The failing test is es/app TestBringupScriptUpCheckDownFullProfile. Bring-up started ARS, EGS, AGS and ES, then Nomad never answered on its HTTP port 127.0.0.1:40347 ("curl: (7) Failed to connect … after 0 ms", then "nomad: leader request failed"). Every other package passed, root included.

Why I don't think it's #37's: the PR diff is docs, the root test file and two echo lines in 70_linux_setup.sh, and none of it touches bringup.sh or Nomad. The same PR diff passed this test on f942906 (run 45272615631). #33's content passed it on fb034ac (run 45277780405), and so did trunk_dev 400ff7f.

Likely cause (my inference; Nomad's log isn't in the CI output): the test reserves its seven ports by listening on 127.0.0.1:0 and closing right away. Those ports come from the kernel's ephemeral range, which outgoing connections use too. In the minute or so before Nomad starts, the test builds a Docker image and starts four services, so another socket can take the Nomad port first. That race is in the existing test, not in this PR. If you want it fixed properly, a small separate PR could keep each reservation open until just before its service starts, or have Nomad pick its own ports and read them back. Your call.

I'll report the re-run's result. If it fails again, I'll dig into it before doing anything else.
