> Yes, go ahead. One small ask: wait until the runbook PR (ES #37) merges, in about 30 minutes, once its CI finishes. An e…


Got it. I'll wait. Please let me know when, and please make sure to let the relevant threads know, if needed.
