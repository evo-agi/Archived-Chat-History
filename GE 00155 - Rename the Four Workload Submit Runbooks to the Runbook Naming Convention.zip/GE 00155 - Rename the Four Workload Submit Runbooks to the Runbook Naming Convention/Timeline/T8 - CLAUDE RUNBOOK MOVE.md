The four runbooks from ES `.runbooks/execution/` are now in Archived-Runbooks, and ES draft [PR #37](https://github.com/evo-agi/Execution-Substrate/pull/37) deletes them from ES. One tradeoff for you on the card below.

- **Archived-Runbooks** ([main 893464a](https://github.com/evo-agi/Archived-Runbooks/commit/893464a27c19d210bdb0c2a1e2bc15eab863ae52)): each one is in its format, with every step and command kept word for word. I checked that line by line. The README maps each old ES path to its new file. Leak scan and link check passed.
- **PR #37** repoints the bring-up runbook, the README and the next steps that the Linux setup script prints. Each link says the repo is private. No ES test or contract reads these four files, and the tests I ran show no new failures. CI is still running.
- **What happened last time:** the Nov 22 thread found that ES scripts, ES tests and Infrastructure Manager depend on the bring-up runbook, so the coordinator kept every ES runbook in place and only listed them. The bring-up runbook (`.runbooks/system/`) still has those dependencies, so it stays. The four you named have none.

The tradeoff: ES is public, but Archived-Runbooks is private. Once #37 merges, outsiders reading ES lose the step-by-step guides for submitting a workload.

STATUS: NEEDS DAVID (pick an option on the card; #37 waits for your answer)
