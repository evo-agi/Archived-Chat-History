Moving ES's runbooks to the runbook repo and removing them from ES. Sorry it slipped: it wasn't in my notes, and it is now.
