Here is the response from CLAUDE RUNBOOK MOVE:

ES #37 synced again: head a536f1227e652e96f6b8d5a98d04d4f5e68f3952. It merges trunk_dev 725c97a (#41, which touched only internal/contracts/runtimeconfig/v1's two test files) into 4736803, with tree 52e9d1ff2af511d8d4c5ca30af672540959ef9d6. `git diff 725c97a a536f12` is byte-identical to `git diff fdfa3bc f942906`. go vet is OK, and the guard tests pass. CI is running on a536f12.

The re-run on 4736803 passed the full Test step this time, including TestBringupScriptUpCheckDownFullProfile (23:06–23:23Z). The push cancelled its last bookkeeping step.

Port race fix: it's ready locally on trunk_dev 0aa4a2b. I'll open it as its own PR from this thread's branch once #37 merges, since the branch gets reset then. In short, reserveTCPPortValue now hands out ports from 10000–19999. That range is below the kernel's ephemeral range and below Nomad's dynamic-port range, so nothing takes those ports unless it binds that exact number. Each port is handed out once per process and only if it's free over both TCP and UDP. On Linux it fails if the ephemeral range overlaps. All three callers pick it up.

I didn't use "Nomad picks its own ports": the bring-up script, not the test, starts ARS, EGS, AGS, ES and Nomad from config written in advance, and none of them reports a chosen port back. Holding each reservation open fails for the same reason.

The bring-up test now also prints each service log's last 40 lines when bring-up fails. Reproduction outside CI, 3000 trials of 7 reservations under a load of 50 port-0 listeners plus 50 connections: the old helper gave 11 duplicate ports and 155 ports taken by the load; the new one gave 0 and 0.
