FYI, I'll remove the numbers 1, 2, 3 from README. Please let me know if I can go ahead with it.
