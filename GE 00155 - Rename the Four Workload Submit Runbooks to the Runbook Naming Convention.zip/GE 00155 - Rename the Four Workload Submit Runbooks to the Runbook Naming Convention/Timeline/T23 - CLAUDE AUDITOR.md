The runbook rename audit is written up in [runbooks-es-pr37-audit.md](/mnt/project-files/reports/docs/runbooks-es-pr37-audit.md). Both PRs need one small repair round.

- **ES #37 (REPAIR NEEDED, one Low):** the rename itself is correct. Nothing is deleted, every link and the two printed paths point at the new names, and the tests fail exactly as they do on base. What's missing is a guard: no test checks runbook links or the paths scripts print. That matters because #31 conflicts with #37 on those exact lines, and a careless resolution would bring back an old path while CI stays green. A small link test would be cheap: all of ES has only 2 broken relative links, both to the retired Control Plane repo.
- **Archived-Runbooks copies: MATCH.** Each copy equals its ES file once the top note is removed and the links are made relative again.
- **Archived-Runbooks #4 (REPAIR NEEDED, two Low):** if a copy's note is removed or reworded, that copy quietly drops out of the check. A probe reported "3 of 3 match" with exit 0. It also wouldn't notice a new ES runbook that has no copy. Merge it after #37.

Earlier today I re-checked the README repairs: ES #36 and IM #2 both passed (ACCEPT), and IM #2 has since merged.

STATUS: WAITING (on repairs to ES #37 and Archived-Runbooks #4, then a narrow re-check; nothing needed from you)
