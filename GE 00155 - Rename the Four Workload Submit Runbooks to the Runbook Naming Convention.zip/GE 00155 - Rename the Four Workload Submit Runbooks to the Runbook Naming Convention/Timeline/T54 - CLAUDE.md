Yes, go ahead. One small ask: wait until the runbook PR (ES #37) merges, in about 30 minutes, once its CI finishes. An edit to trunk_dev before then makes it update and re-run CI again. I'll tell you when it's in. If a README test complains about your edit, we'll adjust the test, not your text.

STATUS: WAITING (on the #37 merge, then you can edit)
