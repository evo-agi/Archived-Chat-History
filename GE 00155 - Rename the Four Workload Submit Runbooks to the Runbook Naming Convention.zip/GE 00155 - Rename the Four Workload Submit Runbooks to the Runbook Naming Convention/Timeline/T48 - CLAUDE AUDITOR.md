Both PRs are now **ACCEPT**. Each nit is closed, and nothing else changed.

**ES #37 at f942906:**
- The only change is the link test file.
- The test now checks every link form: inline, reference-style and HTML.
- A new test fails if any of those link patterns is narrowed. 21 probes behave as intended.
- CI is green: run 45272615631 finished with success at 22:12Z.

**Archived-Runbooks #4 at f7dde0f:**
- The .pyc file is gone, and `__pycache__/` is now ignored.
- Any carriage return in a copy now fails with its own message and line number.
- All 17 probes behave as intended.

trunk_dev moved again to 400ff7f, because #36 merged. So #37 needs one more trunk_dev merge, then a one-line provenance check from me. A trial merge is clean, and the tests pass on it. Merge order is unchanged. The verdicts are appended to the [report](/mnt/project-files/reports/docs/runbooks-es-pr37-audit.md).

STATUS: #37 and AR #4 ACCEPT. #37 needs a trunk_dev merge, then a one-line provenance check before merge.
