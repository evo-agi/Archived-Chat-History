Please withdraw your decision card yourself (close_decision with no option). I couldn't close it from here, and David's words above answer it.
