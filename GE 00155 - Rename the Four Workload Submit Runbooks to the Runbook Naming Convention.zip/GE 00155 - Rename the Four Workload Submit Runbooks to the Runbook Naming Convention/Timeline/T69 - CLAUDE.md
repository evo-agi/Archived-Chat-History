Archived-Runbooks [PR 4](https://github.com/evo-agi/Archived-Runbooks/pull/4) is green against ES trunk_dev and ready for you to merge on GitHub. It adds the daily check that keeps the runbook copies in sync with ES.

STATUS: NEEDS YOU (merge AR #4)
