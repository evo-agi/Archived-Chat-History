Thread `Move ES runbooks to Archived-Runbooks` said: "Checks failed."

The other threads that are supposedly waiting on me are just sitting there.
