Neither PR has a real CI failure. On ES #37, the red marks are runs that were cancelled when I pushed a newer commit, which ES CI does on purpose. The run on the current head has passed the full test step and is finishing its last steps. On runbook-repo #4, the failure is the expected one, and it clears once #37 merges.

STATUS: waiting for the ES run to finish, then the merge of #37.
