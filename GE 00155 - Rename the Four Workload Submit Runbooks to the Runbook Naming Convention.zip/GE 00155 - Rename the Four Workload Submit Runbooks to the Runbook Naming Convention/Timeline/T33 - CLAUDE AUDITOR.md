Both PRs fixed every Low finding. Each still has a small nit to fix in the PR before merge, so both verdicts read **REPAIR NEEDED, nits only**. A diff-only check is enough after that.

**ES #37 (a72cb7e, then 573d9de).** L1 is fixed, and the new guard works:
- The wrong #31 resolution fails the guard and the correct one passes, on both 7aaac66 and #31's newer head c3a94ae.
- Merges with #36, the other open PRs and trunk_dev pass.
- Root tests match the base.
- 573d9de checks out: its diff from trunk_dev is byte-identical to a72cb7e's diff from the old base, and its manifest against fdfa3bc is 6ed46e0c…720d.
- N5: the link test checks only inline links. Reference-style and HTML links are skipped. ES has none today.

**Archived-Runbooks #4 (25232ea).** L2, L3 and N1 to N4 are fixed, and 16 probes pass.
- N6: a compiled .pyc file is committed by mistake.
- N7: CRLF line endings get past the "even one byte" check.

Merge order is unchanged: #37 first, then re-run #4's check, then merge #4. CI on 573d9de was still running at 21:50Z. Details are in the [report](/mnt/project-files/reports/docs/runbooks-es-pr37-audit.md).

STATUS: re-check done. #37 and AR #4 need nit fixes (N5; N6, N7), then a diff-only check.
