# Audit: ES PR #37 (runbook renames), the Archived-Runbooks copies, and Archived-Runbooks PR #4 (drift check)

Auditor: fresh read-only audit thread, 2026-11-23 20:56Z to 21:25Z. Nothing pushed, no PR comment posted.

## Verdicts

| Target | Verdict |
| --- | --- |
| ES PR #37 at `83392bf` | **REPAIR NEEDED**, one Low test gap (L1). The patch itself has no defect: renames, links, printed paths and tests are all correct |
| Archived-Runbooks copies on `main` at `5b58000` | **MATCH**: each copy equals its ES file at `83392bf` byte for byte once the top note is removed and the rewritten links are made relative again |
| Archived-Runbooks PR #4 at `dcdbf11` | **REPAIR NEEDED**, two Low findings (L2, L3) and nits |

Merge order stays as the writer says: ES #37 first, then Archived-Runbooks #4 (before #37, every run fails with 404, shown below). ES #36 and #37 merge cleanly in either order. ES #31 conflicts with #37 on two neighbouring lines (see L1).

## Targets

| Field | ES PR #37 | Archived-Runbooks PR #4 |
| --- | --- | --- |
| Repo | evo-agi/Execution-Substrate (public) | evo-agi/Archived-Runbooks (private) |
| Branch | `claude/project-thread-alfs9u` | `claude/project-thread-alfs9u` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` | `main` `5b58000f0e3474e694b1a468121bd2650145659f` |
| Head | `83392bf688b6fca3de590c16dddb3275c8d011b5` (tree `22ef6ae7fddeb209f049dbe7ad4072e98465ffe5`) | `dcdbf11f61719229bea1adaeb801c7603bff7f59` |
| Paths | 4 renames, `.runbooks/system/v1_bringup.md`, `scripts/70_linux_setup.sh` | `.github/workflows/es-runbook-copies.yml`, `.github/scripts/check_es_runbook_copies.py`, `README.md` |

Heads and bases were re-checked at 21:22Z: unchanged.

### ES #37 provenance

The writer reported no manifest, so I took the base-relative v2 manifest under provenance §5.3 (fresh clone, `umask 022`, recipe SHA-256 `c08597e2…a1e3ca` verified before each run), twice: identical. Closeout run: identical.

- canonical-manifest SHA-256 `4d782c008f88077783acf5acb2be31016b07ca404d457449a8f6a9f393105055`
- textual_diff_sha256 `4e3cffc2959d1d8db8a5d14f5e563e08230598e43892796245b97117d6505b85`
- 10 entries: 4 `untracked` (new names), 4 `tracked_deleted` (old names), `v1_bringup.md` and `70_linux_setup.sh` `tracked_modified` (mode `0755` kept). Every committed blob at `83392bf` hashes to its manifest entry, and the 4 old paths are absent at the tip. Full JSON: `runbooks-es-pr37-audit-evidence/manifest-open.json`.

## Findings

### Low

**L1 (ES #37, test gap). Nothing keeps runbook paths valid, and the known conflict with #31 can quietly bring an old name back.**
- A trial merge of `83392bf` with #31's head `7aaac66` (`git merge-tree --write-tree`) conflicts in `scripts/70_linux_setup.sh`, in the "Next steps" lines. #37's side has the new quoted path, and #31's side has the old `v1_submit_runtime_identity_reference.md` path plus its new step 4. A correct resolution keeps #37's path line and #31's two step-4 lines. A resolution that takes #31's side prints a path to a file that no longer exists. No test reads those echo lines (searched `*_test.go` for `Next steps`, the old and new names, and `runbooks/execution`), so CI would stay green. Evidence: `trial-pr31.txt`.
- More generally, ES has no test that relative Markdown links, or `.runbooks/…` paths named in scripts, resolve. Today that guard would be cheap. Across all tracked `.md` files at `83392bf`, 60 relative links exist, and the only 2 broken ones point to the retired Control Plane repo outside ES (`all-md-links-head.txt`; one of them goes away when #36 merges). Scripts name `.runbooks/` paths in 5 places.
- Suggested fix, in this PR: one root-package test that (a) resolves every relative link in tracked `.md` files, allowing only the named cross-repo Control Plane links, and (b) requires every `.runbooks/<…>.md` path written in `scripts/**` to exist. If the coordinator judges that out of scope for a rename PR, the minimum is a merge-gate note on #31 that its conflict resolution must keep #37's path line, checked in #31's next audit.

**L2 (Archived-Runbooks #4). A copy whose note is changed or removed drops out of the check without any error.**
- `check_es_runbook_copies.py:28-29` finds copies only by the exact note text on line 3, and fails only when it finds none at all (`:30-32`).
- Probe (scratch copy of the PR tree, run against ES `83392bf`): with the note removed from one copy, the run says `3 of 3 copies match` and exits 0. With the note's wording changed and the copy's content changed too, it says `3 of 3` and exits 0. The unmodified control says `4 of 4`, exit 0.
- Suggested fix: treat every root file named `Governed Execution ES *.md` as a copy and fail if its note is missing or malformed, or pin the four names in the script.

**L3 (Archived-Runbooks #4). A new ES runbook with no copy is not noticed.** The check walks the copies, not ES's `.runbooks/execution/`. If ES renames or deletes a runbook, the 404 catches it. If ES adds one, nothing does, so the "every ES runbook has a copy here" promise in the README section can drift. Suggested fix: list ES `.runbooks/execution/*.md` (for example from a shallow, blob-filtered clone of the public ES repo, which also avoids the raw CDN cache, see N3) and fail on any ES runbook without a copy.

### Nit (Archived-Runbooks #4)

- **N1.** No `pull_request` trigger, so a PR that edits a copy is checked only after it lands on `main`. Adding `pull_request:` costs nothing.
- **N2.** A network failure raises `URLError`, which the script does not catch (`:46-52`), and any HTTP error, for example 429, is reported as "not found". Both still fail closed. Only the message misleads.
- **N3.** `raw.githubusercontent.com` caches for a few minutes (Inference: about 5, from GitHub's usual `Cache-Control: max-age=300`). If ES and a copy change at the same time, the push-triggered run can compare against stale ES bytes. The next daily run corrects it.
- **N4.** `runs-on: ubuntu-latest`, while ES pins `ubuntu-24.04` (`.github/workflows/go.yml:27`). Each file is opened twice at `:28-29`. Both cosmetic.

### Pre-existing / for the coordinator

- **P1. Archived-Runbooks `main` already points at names that don't exist yet.** At `5b58000` the README and the copies link to the four new ES names on `trunk_dev`, and those 4 links 404 until #37 merges. Everything else they link to exists on ES `trunk_dev` today. It is private and goes away when #37 merges.
- **P2. A procedure file is out of date.** `project-context/runbooks.md` says "Runbooks go in evo-agi/Archived-Runbooks" and does not cover the new arrangement: ES keeps its runbooks, Archived-Runbooks keeps checked copies. The coordinator owns that file.
- **P3. Who sees a failed scheduled run.** Inference from GitHub's documentation: notifications for scheduled-workflow failures go to the user who last changed the cron line, which will be whoever authors the merge commit. Worth confirming that this is David, or the failing check has no reader.

## What I checked

### ES PR #37

| Check | Result | Evidence |
| --- | --- | --- |
| Nothing deleted, only renamed | True | `git diff -M --name-status`: four `R093`–`R099` renames, and the four new blobs exist at the tip |
| Content beyond the H1 and links unchanged | True | The full rename diff touches only line 1 of each file, lines 12/14/16 of the reference runbook and line 255 of the local-validation runbook |
| H1 equals the file name | True, 4 of 4 | `head -1` compared with the name |
| Every reference updated | True | At the tip, `git grep -E "v1_submit_\|v1_runtime_identity_local"` finds nothing. At the base, the old names appear only in the 6 changed files. IM, MA, Coordinator and Bridge-Core `trunk_dev` and `project-context/` do not mention them |
| Links resolve | True | All 41 links in the 4 runbooks, `v1_bringup.md` and `README.md` resolve, apart from README's pre-existing Control Plane link (fixed by #36). `%20`-encoded links point at the new names |
| `v1_bringup.md` keeps its name | True | Read by `docs_contract_test.go:635`, `es/app/operator_scripts_integration_test.go:1019`, `scripts/internal/operator_failures.sh:5`, `scripts/70_diagnostics.sh:40`, and required by IM `src/infra_manager/config.py:30` |
| Printed paths in `70_linux_setup.sh` | Correct and copy-pasteable | `bash -n` OK. Evaluating the "Next steps" block with `CLONE_DIR=/home/op/execution-substrate` prints both new paths in double quotes |
| README | Unchanged, as stated | Not in the diff |
| Leak scan of the four runbooks and the script | Clean | No LAN address, user path, key or token |

Tests (Go 1.26.5, `GOFLAGS=-mod=readonly`, root in a cloud container):

```text
go vet . ./es/app                                   -> exit 0
go test ./es/app -run 'TestBringupRunbookTroubleshootingMatrixListsCurrentFailureCategories|TestLinuxSetup'
  -> 4 tests PASS (incl. TestLinuxSetupGoToolchainInstallerHermeticPreflightAndCleanup, which runs the script with fake commands)
go test -json .   on a clean committed checkout of 83392bf (git ls-files sees the renamed files as tracked)
  -> 2016 pass, 242 fail; failing set identical to base 76c030f (the same 34 TestRemoteAlpha* environment-only tests seen in the #36 audit)
```

I also ran the root package on the audit tree, where the new names are untracked. Same result. Because `artifact_hygiene_test.go:19` inventories tracked files with `git ls-files`, the committed-checkout run is the one that counts. GitHub CI on #37 (run 45263705229) was still in progress at 21:22Z.

Trial merges at `83392bf`: with #36's current head `3efe715`, clean. With #31's head `7aaac66`, one conflict (L1).

### Archived-Runbooks copies

I wrote an independent check (`copycheck.py`): it drops the 4-line note under each copy's title, turns every `https://github.com/evo-agi/Execution-Substrate/blob/trunk_dev/<path>` link back into a path relative to `.runbooks/execution/`, and compares bytes with the ES file at `83392bf`. Result: MATCH for all 4 (rewritten links per file: 3, 5, 8 and 1). So, strictly, the copies differ from ES in the note and in their links, which their note says outright ("except this note and the links"). Every ES link in the copies and in the Archived-Runbooks README resolves at `83392bf`.

### Archived-Runbooks PR #4

- Security: `permissions: contents: read`, `persist-credentials: false`, the same pinned `actions/checkout@3d3c42e5…` as ES, no secrets, and no `${{ }}` expression inside `run:`, so no injection surface. ES is public, so no token is needed.
- The writer's results reproduce: against ES `83392bf`, `4 of 4 copies match`, exit 0. Against ES `trunk_dev`, all 4 report 404, exit 1 (`pr4-check-vs-*.log`).
- Probes, each on a fresh scratch copy of the PR tree against ES `83392bf`:

```text
M0 unmodified                                      4 of 4 match, exit 0
M1 one word changed in a copy                      3 of 4 match, exit 1
M2 one trailing byte added to a copy               3 of 4 match, exit 1
M3 note removed from one copy                      3 of 3 match, exit 0   <- L2
M4 note wording changed and content changed        3 of 3 match, exit 0   <- L2
M5 one link retargeted                             3 of 4 match, exit 1
```

- README change: one sentence linking the workflow; the link resolves in the PR tree.
- Not run: the workflow on GitHub itself (the first run happens on the merge push).

## Report fields

- Touched files: none in any repo. Wrote this report and `runbooks-es-pr37-audit-evidence/` (SHA256SUMS.txt inside).
- Assumptions: "byte for byte apart from the top disclaimer" is read as the copies' own stated rule, note and links excepted. Under a literal reading, they differ in links too.
- Inferences: marked inline (N3 cache time, P3 notification recipient).
- Skipped validation: the GitHub runs of both PRs.
- Authority or security widening: none. #4 adds a read-only workflow to a private repo.
- Confidence: ES #37 correctness high. Copy match high (independent tool plus the PR's tool, same answer). #4 review high for the probed behaviour, medium for GitHub-side behaviour I could not run.

## Re-check 1: ES #37 at `a72cb7e`, Archived-Runbooks #4 at `25232ea` (2026-11-23 21:24Z to 21:45Z)

| Target | Verdict |
| --- | --- |
| ES PR #37 at `a72cb7e` | **REPAIR NEEDED, one Nit only (N5).** L1 is fixed and the guard works, including against the wrong #31 resolution |
| Archived-Runbooks PR #4 at `25232ea` | **REPAIR NEEDED, two Nits only (N6, N7).** L2, L3 and N1 to N4 are fixed |

Both nits are small, deterministic fixes (the project fixes nits in the PR). A diff-only check is enough afterwards. Merge order is unchanged: #37 first, then re-run #4's check (it should pass, per probe R0), then merge #4.

Heads re-checked at 21:44Z: ES `claude/project-thread-alfs9u` `a72cb7e`, Archived-Runbooks `claude/project-thread-alfs9u` `25232ea`, Archived-Runbooks `main` `5b58000`. **ES `trunk_dev` moved to `fdfa3bc` (#29) during the re-check**, so #37 must merge trunk_dev before it can merge, because ES requires up-to-date branches. A trial merge of `a72cb7e` with `fdfa3bc` is clean and the guard passes on it. The resulting head needs a short provenance check, like #36's.

### ES #37 at `a72cb7e`

**Provenance.**
- `a72cb7e7f13c090aa31defbb0b2710c37e094756` fast-forwards from the audited `83392bf` with one commit. That commit adds only `runbook_paths_contract_test.go` (+168).
- I took a fresh-clone base-relative v2 manifest against `76c030f` twice and once more at closeout, with the recipe hash verified before each run. All three are identical.
  - Manifest SHA-256: `5bbd8653358cf69773767fc64b19a26f7cc75c3bd8d646a29dc600154377026a`.
  - textual_diff_sha256: `4e3cffc2…5b85`, unchanged.
  - 11 entries: the earlier 10 plus the new test, sha256 `c8adf7f8…1ff7`.
- Every committed blob matches its entry, and the 4 old paths are absent.
- Copy: `runbooks-es-pr37-audit-evidence/recheck1/manifest-r1-a72cb7e.json`.

**L1: fixed.** The new test `runbook_paths_contract_test.go` has two parts.
- `TestMarkdownRelativeLinksResolve`:
  - Resolves every inline relative link in tracked `.md` files, with fenced blocks and code spans stripped first, `%20` decoded and the `#fragment` dropped.
  - Fails on a link that leaves the repo, unless the target is the one allowlisted Control Plane path.
  - Fails if that allowlisted path stops being used.
- `TestRunbookPathMentionsExist` requires every `.runbooks/…/*.md` path written in any tracked file, including scripts and Go, to exist. It fails if no mention is found at all, or none in `scripts/`.

| Check | Result |
| --- | --- |
| Guard on the exact tip | Both tests PASS; `go vet .` exit 0 |
| Root package on a clean committed checkout (`go test -json .`, Go 1.26.5) | 2018 pass, 242 fail. The failing set is identical to base `76c030f` and to `83392bf` (the same environment-only TestRemoteAlpha* set). The 2 new tests are the 2 extra passes |
| #31 conflict, **wrong** resolution (take #31's side), on #31's current head `c3a94ae` and on `7aaac66` | `TestRunbookPathMentionsExist` FAILS: `scripts/70_linux_setup.sh: .runbooks/execution/v1_submit_runtime_identity_reference.md`. The writer's claim reproduces, and it also holds on #31's newer head |
| #31 conflict, **correct** resolution (#37's quoted path line plus #31's two step-4 lines), on `c3a94ae` | Both tests PASS; `bash -n` OK |
| Merge with #36 `4382b71` (and with the earlier `3efe715`) | Clean; guard and the README pin test PASS. The allowlist stays in use through `.docs/supported_local_cp_consumer_runbook.md:72` after #36 removes README's link |
| Merge with trunk_dev `fdfa3bc` and with open PRs #38, #35, #34, #33, #30 | All clean, guard PASS on each |
| Merge with #12 `4416699` | Conflicts only in `PLANS.md`, which is pre-existing against trunk_dev. With either side taken, guard PASS |

Mutation probes on scratch copies of the tip (`recheck1/guard-probes.log`):

```text
G0  unmodified                                         exit 0
G1  README link to a missing file                      exit 1
G2  README link leaving the repo (../outside.md)       exit 1
G3  missing file with a #fragment                      exit 1
G4  correct %20 link to a runbook (control)            exit 0
G5  allowlisted CP target no longer linked anywhere    exit 1  (external target "is allowed but no longer linked")
G6  runbook renamed, mentions not updated              exit 1  (both tests name both stale references)
G7  script prints a missing .runbooks path             exit 1
G8  Go comment names a missing .runbooks path          exit 1
G9  [x](<does not exist.md>)                           exit 0  <- N5
G10 reference-style definition [ref]: missing.md       exit 0  <- N5
G11 <a href="missing.md">                              exit 0  <- N5
G12 [x](missing.md 'single-quoted title')              exit 0  <- N5
G13 a .runbooks mention wrapped across two lines       exit 0  <- N5 (comment only)
G14 link inside a code span                            exit 0  (skipped by design)
```

(The log's first G7 line came after an unclean reset following G6. It is re-run cleanly at the end of the log, with the result shown here.)

**N5 (Nit). The link test checks only one link form, but its comment says "every relative link".**
- The pattern `markdownInlineLink` (`runbook_paths_contract_test.go:26`) skips:
  - angle-bracket targets with spaces;
  - titles in single quotes or parentheses;
  - reference-style definitions (`[ref]: path`);
  - HTML `href`/`src`.
- A broken link in any of those forms passes (G9 to G12). None of the forms is used in ES today: 0 of each across the 52 tracked `.md` files. So this is a future gap, not a current miss.
- Suggested fix:
  - Widen the inline pattern to `<…>` targets and all three title styles.
  - Check reference definitions (`^ {0,3}\[[^\]]+\]:\s*(\S+)`) and relative `href`/`src` targets with the same resolution code, or make the test fail when it meets one of those forms.
  - Say in the mention test's comment that a mention must sit on one line (G13).

Not a finding: mentions built from variables, such as `filepath.Join(repoRoot, ".runbooks", "system", "v1_bringup.md")` in `es/app/operator_scripts_integration_test.go:1019`, are outside the guard. That test reads the file itself and fails if it is gone. Every other line in ES that says "runbooks" is prose with no path (19 lines, listed in the evidence).

CI: "build, vet and test" on `a72cb7e` (run 45267783465) was still in progress at 21:44Z.

### Archived-Runbooks #4 at `25232ea`

Delta from `dcdbf11`: `d469472`, "Fail the copy check on a missing or changed note and on an ES runbook with no copy", and `25232ea`, "Keep the drift check's diff output on separate lines". Files: the script (rewritten), the workflow, one README sentence, and a committed `.pyc` (N6).

| Earlier finding | Status at `25232ea` | Evidence |
| --- | --- | --- |
| L2 copy drops out when its note is removed or changed | Fixed | Every top-level `Governed Execution ES *.md`, and any top-level file whose line 3 starts the copy note, is a copy (`:94-100`). Each must have the note under the title, name its own ES file, say the ES version wins, and say which commit it was copied from (`:59-79`). R3, R4, R9, R10 and R11 exit 1 |
| L3 a new ES runbook with no copy is not noticed | Fixed | ES `.runbooks/execution/*.md` is listed from the fetched commit (`:46-56`), and each must have a copy (`:103-107`). R6, R7 and R8 exit 1 |
| N1 no `pull_request` trigger | Fixed | Workflow `:11` |
| N2 network errors give a traceback or "not found" | Fixed | Git errors exit 2 with git's message (`:85-89`); R14 |
| N3 raw CDN cache | Fixed | A shallow, blob-filtered `git fetch` reads the commit itself (`:49`) |
| N4 `ubuntu-latest`; files opened twice | Fixed | `ubuntu-24.04` (workflow `:21`); each file read once (`:95-97`) |

Security is unchanged: `permissions: contents: read`, `persist-credentials: false`, the pinned checkout, no secrets, and no `${{ }}` inside `run:`. The fetch URL is a constant.

Probes, each on a fresh `git archive` of `25232ea`, run against ES `a72cb7e` (`recheck1/ar4-probes-25232ea.log`, harness `ar4-probes.sh`):

```text
R0  unmodified                                    exit 0  4 runbooks, 4 copies, 0 problems
R1  one word changed in a copy                    exit 1  differs, diff printed
R2  one trailing byte added                       exit 1
R3  note removed (L2)                             exit 1  note missing
R4  note reworded + content changed (L2)          exit 1  note missing
R5  one link retargeted                           exit 1
R6  a copy deleted (L3)                           exit 1  ES runbook has no copy
R7  copy renamed outside the glob                 exit 1  ES runbook has no copy
R8  copy renamed outside the glob, note removed   exit 1  ES runbook has no copy
R9  extra glob-named file, no ES file             exit 1  note names another file
R10 "ES version wins" changed                     exit 1
R11 "Copied word for word" line removed           exit 1
R12 copy converted to CRLF line endings           exit 0  <- N7
R13 one stray CR at the end of one line           exit 0  <- N7
R14 ES ref that does not exist                    exit 2  git's message
R15 ES trunk_dev today (fdfa3bc)                  exit 1  8 problems (4 ES runbooks without copies, 4 copies without ES files)
```

The writer's 13 probes reproduce: R0 to R11, R14 and R15 cover each of them. The pull-request run on `25232ea` (job 138022795404) failed by design with the same 8 problems against trunk_dev `76c030f`. That shows the fetch and the lazy blob reads work on GitHub's runner.

**N6 (Nit). A compiled Python file is committed:** `.github/scripts/__pycache__/check_es_runbook_copies.cpython-313.pyc` (9235 bytes, added in `d469472`). It is a by-product of local runs, and the runner never uses it. Remove it, and add a `.gitignore` with `__pycache__/` (the repo has none).

**N7 (Nit). Carriage returns are invisible to the check, though its docstring says "by even one byte" (`:15`).** Both sides are read as text with newline translation: `open(..., encoding="utf-8")` at `:96`, and `subprocess.run(..., text=True)` at `:43`. So a copy with CRLF endings, or with a stray CR, passes (R12, R13). It renders the same on GitHub, so there is no reader impact today. Fix: read the copy with `newline=""`, and decode `git show` output from bytes (`text=False`, then `.decode("utf-8")`). Or narrow the docstring.

### Report fields (re-check 1)

- Touched files: none in any repo. Appended this section and wrote `runbooks-es-pr37-audit-evidence/recheck1/`. `SHA256SUMS.txt` was refreshed and covers both levels.
- Assumptions: "fails on the wrong conflict resolution" is read as "the side-taking resolution". I also checked the correct resolution and #31's newer head `c3a94ae`.
- Inferences: none new.
- Skipped validation: the GitHub CI result of #37 on `a72cb7e` (in progress). #4's GitHub run against a trunk_dev that already has #37 (possible only after #37 merges).
- Authority or security widening: none.
- Confidence: high for the guard's behaviour and the #31/#36/open-PR interactions (each run on the exact merge trees), and high for #4 (16 probes plus the GitHub run).

### Addendum: ES #37 at `573d9de` (merge of trunk_dev `fdfa3bc`, 2026-11-23 21:36Z to 21:50Z)

The verdict is unchanged: **REPAIR NEEDED, Nit N5 only.** Everything above for `a72cb7e` carries over to `573d9de`.

- **Parents and tree.** `573d9de947c984ebeed00f26788dbb013bb94f8a` has parents `a72cb7e` and `fdfa3bc` (#29). Its tree `becc8611…a169` is identical to my trial merge of `a72cb7e` with `fdfa3bc`, so the trial results above (clean merge, guard PASS) are results on this tree.
- **The writer's diff claim is true.** `git diff 76c030f a72cb7e` and `git diff fdfa3bc 573d9de` are byte-identical, with `--binary` SHA-256 `989ccd0d…5f64` for both. `a72cb7e..573d9de` touches exactly #29's 29 files.
- **Provenance.** A fresh-clone v2 manifest against `fdfa3bc`, taken twice, is identical both times.
  - Manifest SHA-256: `6ed46e0cc02b7ec1684fc63335b8f8247d77a241253b82bd85ace2c40599720d`.
  - textual_diff_sha256: `4e3cffc2…5b85`, unchanged.
  - 11 entries, each identical to the `a72cb7e` manifest's. Only the recorded head changes.
  - Every committed blob matches, and the 4 old paths are absent.
  - Copy: `recheck1/manifest-r2-573d9de.json`.
- **Tests.**
  - The guard passes on `573d9de`.
  - Root package on a clean checkout: 2021 pass and 242 fail. The base `fdfa3bc` gives 2019 pass and 242 fail. The failing sets are identical, and also identical to `a72cb7e`'s. The 2 extra passes are the new tests.
- **CI.** "build, vet and test" on `573d9de` (run 45271310961) was in progress at 21:50Z.

## Re-check 2: diff-only check, ES #37 at `f942906` and Archived-Runbooks #4 at `f7dde0f` (2026-11-23 21:46Z to 22:14Z)

| Target | Verdict |
| --- | --- |
| ES PR #37 at `f942906` | **ACCEPT.** N5 closed, nothing else changed, CI green |
| Archived-Runbooks PR #4 at `f7dde0f` | **ACCEPT.** N6 and N7 closed, nothing else changed. Its own check fails by design until #37 merges |

Merge order is unchanged: #37, then re-run #4's check (probe R0 passes against #37's head), then #4. **trunk_dev moved again while I checked: it is now `400ff7f` (#36 merged).** #37 must merge it before it can merge. A trial merge of `f942906` with `400ff7f` is clean, and the guard, the pin test and the new link-form test pass on it (`recheck2/trial-f942906-400ff7f.log`). The resulting merge head needs only the usual one-line provenance check.

### ES #37 at `f942906`

**Scope.** `f942906115c621be3be4fe2037aa0884856144ef` is one commit on `573d9de`, "Check every Markdown link form in the runbook link test". It touches only `runbook_paths_contract_test.go` (+70 −10). Diff: `recheck2/es37-delta-573d9de-f942906.diff`.

**Provenance.**
- I took a fresh-clone v2 manifest against `fdfa3bc` twice, with the recipe hash checked before each run. The two runs are identical.
  - Manifest SHA-256: `3b92eff3448ca245e70932c2f67e55aea9c4b14e08ed5c03adce4789e3207997`.
  - textual_diff_sha256: `4e3cffc2…5b85`, unchanged.
  - 11 entries.
- Compared with the `573d9de` manifest, only the test file's entry changed: it was `c8adf7f8…1ff7` and is now `463afb03…ea45`.
- Every committed blob matches, and the 4 old paths are absent.

**N5 closed.** The new function `markdownLinkTargets` reads four link forms:
- inline links and images, with `<…>` targets and titles in double quotes, single quotes or parentheses;
- reference definitions, with footnotes `[^…]:` excluded;
- HTML `href`/`src`, quoted or bare.

Code spans and fenced blocks are still stripped first. The new test `TestMarkdownLinkTargetsReadsEveryLinkForm` pins 16 cases. The mention test's comment now says that a mention must sit on one line, and that paths built from parts at run time are not seen.

Checks: `go vet .` exit 0, `gofmt -l` clean, and all three tests PASS on the exact tip. Probes on scratch copies of the tip (`recheck2/guard-probes-f942906.log`):

```text
H0  unmodified                                          exit 0
H1  inline link to a missing file                       exit 1
H2  link leaving the repo                               exit 1
H3  allowlisted CP target unused                        exit 1
H4  runbook renamed, mentions not updated               exit 1
H5  script prints a missing runbook path                exit 1
H6  [x](<does not exist.md>)            (was G9 gap)    exit 1
H7  [ref]: does-not-exist.md            (was G10 gap)   exit 1
H8  [ref]: <does not exist.md> "t"                      exit 1
H9  <a href="does-not-exist.md">        (was G11 gap)   exit 1
H10 <img src='missing.png'>                             exit 1
H11 [x](missing.md 'title')             (was G12 gap)   exit 1
H12 [x](missing.md (title))                             exit 1
H13 ![x](missing.png)                                   exit 1
H14 footnote text naming a missing file                 exit 0  (not a link, by design)
H15 link inside a code span                             exit 0  (by design)
Pattern mutations; each must be caught by the new pin test or the "no links found" guard:
H16 inline bare-target branch broken                    exit 1  ("found no relative Markdown links")
H17 HTML pattern dropped from the scan                  exit 1  (pin test)
H18 single-quoted titles dropped                        exit 1  (pin test)
H19 reference angle-bracket branch dropped              exit 1  (pin test)
H20 footnote exclusion dropped                          exit 1  (pin test)
H21 code spans no longer stripped                       exit 1  (pin test)
```

(The log's first H16 and H19 lines are invalid edits: one did not apply, and one left the regex unbalanced. Both are re-run with checked edits at the end of the log, and the table shows the valid results.)

Not findings, recorded for completeness: an HTML attribute such as `data-href=` also matches the `href` pattern, because of `\b`. HTML entities in targets are not decoded. Both fail closed (a false alarm, never a miss), and neither occurs in ES.

**CI.** "build, vet and test" on `f942906` (run 45272615631, job 138036231179) completed with **success** at 22:12:13Z. The earlier run on `573d9de` was cancelled when `f942906` was pushed, so it is not a failure.

### Archived-Runbooks #4 at `f7dde0f`

**Scope.** `f7dde0fa9ccf94fa0125b5c0bedb8e3f6cc7694a` is one commit on `25232ea`, "Catch carriage returns in the copy check and stop tracking the .pyc". It touches three things:
- the `.pyc` is deleted;
- `check_es_runbook_copies.py` gets +14 −4;
- `.gitignore` is new, with the single line `__pycache__/`.

The workflow and README are unchanged. The PR as a whole now adds only the script, the workflow and `.gitignore`, and changes one README sentence. No `.pyc` is in the tree. Diff: `recheck2/ar4-delta-25232ea-f7dde0f.diff`.

**N6 closed.** The `.pyc` is removed and `__pycache__/` is ignored.

**N7 closed.**
- Both sides are now read without newline translation. `git()` decodes stdout bytes as UTF-8, and copies are opened with `newline=""`.
- Any CR in a copy fails with its own message and line number (`::error file=…,line=N::has a carriage return (CR) on line N`).
- The docstring says the same.
- The `CalledProcessError` handler now decodes bytes stderr, and R14 still exits 2 with git's message.

Probes, each on a fresh `git archive` of `f7dde0f`, run against ES `f942906` (`recheck2/ar4-probes-f7dde0f.log`):
- R0 to R11, R14 and R15 behave as at `25232ea`: R0 has 0 problems with exit 0, every mutation exits 1, a bad ref exits 2, and trunk_dev gives 8 problems.
- R12 (CRLF copy), R13 (one stray CR on line 19) and the new R16 (one trailing CR) now exit 1, each with the CR message and the right line.

The pull-request run on `f7dde0f` (job 138036575688) failed by design with the same 8 problems against trunk_dev `fdfa3bc`.

### Report fields (re-check 2)

- Touched files: none in any repo. Appended this section and wrote `runbooks-es-pr37-audit-evidence/recheck2/`. `SHA256SUMS.txt` was refreshed.
- Assumptions: none new.
- Inferences: none.
- Skipped validation: #4's run against a trunk_dev that has #37, which is possible only after #37 merges.
- Authority or security widening: none.
- Confidence: high for both. Each fix is small, and each is covered by probes that failed before the fix and pass after it.

**Provenance re-check, ES #37 at `c774dec` (22:16Z): still ACCEPT.** `c774dec13f50de6b47a52a6e2918cfcc070fba27` merges trunk_dev `400ff7f` (#36) into `f942906`. Its tree, `6e9be013…`, is identical to my trial merge, on which the guard, the link-form test and the README pin test passed. `git diff fdfa3bc f942906` and `git diff 400ff7f c774dec` are byte-identical (`--binary` SHA-256 `c3d27554…d339`). A fresh-clone v2 manifest against `400ff7f`, taken twice, was identical both times: `9ba9df7855cf5745658c4155ee7a764d6820c39a63ae9639eb2bf11064c89216`, textual_diff `4e3cffc2…5b85`. Its 11 entries are identical to those in `f942906`'s manifest, and every blob matches (copy: `recheck2/manifest-r4-c774dec.json`).

**Provenance re-check, ES #37 at `4736803` (22:48Z): still ACCEPT.**
- **The merge.** `4736803b0ac864cb564792be3bdbaf2c9240c0bd` merges trunk_dev `0aa4a2b` (#33) into `c774dec`. Its tree, `6ebd4164…`, is identical to my trial merge.
- **The diffs.** `git diff 0aa4a2b 4736803` is byte-identical to `git diff fdfa3bc f942906` (`--binary` SHA-256 `c3d27554…d339`).
- **Tests on the exact tip.** The guard, link-form and README pin tests all pass (`recheck2/guard-4736803.log`).
- **Manifest.** A fresh-clone v2 manifest against `0aa4a2b`, taken twice, was identical both times: `794fef00a789c693a3a9699faffb18e7e74e20374ba99e364139344ce39802ce`, textual_diff `4e3cffc2…5b85`. Its 11 entries are identical to `f942906`'s, and every blob matches (copy: `recheck2/manifest-r5-4736803.json`).
- **CI.** The run on `4736803` was in progress at 22:48Z.

**Provenance re-check, ES #37 at `a536f12` (23:30Z): still ACCEPT.** `a536f1227e652e96f6b8d5a98d04d4f5e68f3952` merges trunk_dev `725c97a` (#41) into `4736803`.
- **Tree:** `52e9d1ff…`, identical to my trial merge.
- **Diff:** `git diff 725c97a a536f12` is byte-identical to `git diff fdfa3bc f942906` (`--binary` SHA-256 `c3d27554…d339`).
- **Tests:** the guard, link-form and README pin tests pass on the exact tip (`recheck2/guard-a536f12.log`).
- **Manifest:** a fresh-clone v2 manifest against `725c97a`, taken twice, gave identical results: `9b79447a53788340b5ec67eb7b5892ca771540ae36e8fb30d91b868b7acdd5c4`, textual_diff `4e3cffc2…5b85`. Its 11 entries are identical to `f942906`'s, and every blob matches (copy: `recheck2/manifest-r6-a536f12.json`).
- **CI:** the run on `a536f12` was in progress at 23:29Z.
