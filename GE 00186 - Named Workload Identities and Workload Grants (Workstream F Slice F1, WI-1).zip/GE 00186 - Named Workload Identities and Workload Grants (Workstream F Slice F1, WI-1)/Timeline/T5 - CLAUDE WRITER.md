I've opened the first pull request for workload identity and network approval: [ES PR #71](https://github.com/evo-agi/Execution-Substrate/pull/71). It contains docs and contract tests only, with no behavior change, so it merges after an audit without needing you.

I made one change to the approved design. I dropped the "off" switch for owner grants, because switching them off would bring back the gap where the publisher alone decides network access.

I'm now working on network grants and on refusing workload identities as callers.

STATUS: WI-1 in audit; WI-2 and WI-3a in progress.
