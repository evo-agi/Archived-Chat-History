**Verdict: BLOCK on ES PR #71** at 414cb72, with five Low findings. Each is a small docs or test edit, and under the "Low nits fixed in-PR" rule they go back to the writer. I pushed nothing and posted nothing on GitHub.

**The dropped "off" switch is a strict tightening, so you don't need to decide anything.** The design's sketch had `mode: enforce` and never said what any other mode would do. It looks copied from the literal-deny policy, which accepts `disabled` or `enforce`. Every config the PR accepts behaves exactly like the design's "enforce". The only configs it removes are ones that would let the publisher alone decide network access again. You were already told this in the writer's thread. One practical effect: with no switch to fall back on, WI-2 must make both ES setup and the Remote Alpha ES upgrade write today's grants. Otherwise the CP normal-shell profile breaks on the first upgrade.

**Other checks**
- No product code changed: 7 docs and 2 root test files only.
- Nothing widens supported-local or Remote Alpha behavior.
- Current-fact claims hold, for example: ES refuses the `workload_grants` key today (checked with a probe), and no shipped allowlist names a `workload` path.

**Tests, rerun on the exact bytes as an unprivileged user with Go 1.26.5**
- Root package: 622 pass at the tip and 618 at the base. The difference is just the 4 new tests.
- Scripts and internal packages: identical per-test results on tip and base. The 40 environment failures happen on both; the 9 failing tests are named in the report.
- I also ran 28 mutation probes against the new contract tests.

**Findings (all Low)**
1. A1: Section 11.9 says the response DTOs keep their shapes, then changes `authority_handoff`, which is part of those responses. It also covers CP but not IM.
2. A2: The readiness check on registered names covers one direction only. The design wanted both.
3. A3: The grants contract says granted runs sit "under the host firewall", but that firewall exists only on the Remote Alpha box.
4. A4: The "not yet implemented" honesty test checks a single sentence, so it stops guarding once WI-2 rewrites that sentence. Two mutants show it.
5. A5: The grants contract settles whether read-only receipt recovery re-checks policy, but the idempotency contract still calls that question open.

**Merge-order note:** merging this PR with draft #70 pushes PLANS.md over its size cap (150,128 bytes). Landing #69 first avoids that.

CI was still running when I published, so I haven't seen its result.

Report: [01-pr71-audit.md](/mnt/project-files/reports/Execution-Substrate/workload-identity/01-pr71-audit.md), SHA-256 dc1826b4efcaae55127b4ad2f9175a1401729668bcc9016586949b31f4159916. The evidence folder `01-pr71-audit-evidence/` has a SHA256SUMS file.

STATUS: READY (audit delivered; repair goes back to the writer, then a fresh re-audit)
