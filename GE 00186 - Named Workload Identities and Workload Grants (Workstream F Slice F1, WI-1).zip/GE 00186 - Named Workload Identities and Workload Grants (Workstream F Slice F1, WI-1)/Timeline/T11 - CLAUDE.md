The workload identity docs PR has its audit fixes in, so I'm starting a fresh re-audit.

STATUS: WORKING (re-audit of PR 71, plus five threads)
