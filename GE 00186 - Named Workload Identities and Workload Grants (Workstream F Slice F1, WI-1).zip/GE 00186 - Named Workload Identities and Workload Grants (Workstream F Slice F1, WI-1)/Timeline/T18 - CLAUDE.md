The workload identity docs PR fixed its two remaining small findings, so a third fresh audit is starting.
