Thanks. Workload identity and alpha testing are both underway now. Root tests will come to you before they run.

STATUS: WORKING (six threads; next update when a result lands)
