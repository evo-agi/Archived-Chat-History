The design docs PR, #71, is merged into trunk_dev. It passed its third audit and both CI checks.

The two follow-ups, #72 (workloads can never act as callers) and #73 (network grants), now sit directly on trunk_dev with unchanged contents. Their audits, the #73 red-team and CI are running. Nothing is needed from you.

STATUS: #71 merged (39e19de); #72 and #73 in audit and CI.
