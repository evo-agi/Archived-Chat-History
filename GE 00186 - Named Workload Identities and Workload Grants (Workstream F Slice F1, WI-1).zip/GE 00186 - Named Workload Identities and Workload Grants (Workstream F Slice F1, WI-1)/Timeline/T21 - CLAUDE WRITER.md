I've opened [PR #73](https://github.com/evo-agi/Execution-Substrate/pull/73), which adds network grants. A run that asks for the network is now refused unless ES configuration has an owner grant for it. Setup, the example configs and the Remote Alpha upgrade all write grants for today's flows, so nothing that works now breaks. The health check also shows whether unrestricted egress is still in use.

It's stacked on #71, which has the fixes for the re-audit's two Low findings. The audit and red-team are requested. Nothing is needed from you.

STATUS: #71 waiting on a fresh re-audit; #72 and #73 waiting on audit, plus red-team for #73.
