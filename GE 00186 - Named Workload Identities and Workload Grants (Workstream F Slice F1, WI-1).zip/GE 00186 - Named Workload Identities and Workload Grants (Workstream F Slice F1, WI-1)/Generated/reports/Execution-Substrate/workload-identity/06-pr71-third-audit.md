# Independent audit 06: ES PR #71 at 26cbd65 (WI-1, workload identity and workload grants docs), third round

Date: 2026-11-26, 22:59Z to 23:22Z (5:59 PM to 6:22 PM Eastern). Thread: "Third audit of workload identity docs". Auditor: a fresh, read-only thread that wrote none of this PR and ran neither audit 01 nor re-audit 03.

**Final verdict: ACCEPT.** R1 and R2 from re-audit 03 are fixed and pinned (every mutant that reverts them fails the root package). The repair changed only the three files it names and broke nothing: the root package passes 623 tests on the tip against 618 on the base, the difference is exactly the PR's five new tests, and the internal and scripts packages give identical per-test results on tip and base. A fresh read of the whole diff found no new Low or higher finding. Four observations follow for later briefs; none blocks. CI on the tip was still running when this report was written (section 5); the merge gate must see both required checks pass on `26cbd65` (O3).

## 0. Target identity

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #71, "Docs: named workload identities and workload grants (Workstream F slice F1, WI-1)", open, not draft, `mergeable_state` blocked (checks pending) |
| Base | `trunk_dev` = `923e9c3366775664c8a85f19273e3dd4fc04eb22` (unchanged at 23:00Z and 23:16Z) |
| Topic branch / tip | `claude/project-thread-4rhifh` = `26cbd653c1c4b5173c971d679fccb3d4c489a183`; PR head equals it (23:00Z and 23:17Z). Three commits on the base: `414cb72` (audit 01), `1479f40` (re-audit 03), `26cbd65` (this repair) |
| Tree | `178defa90f883644497e6fc97573ffdf35d3f39c` (matches the writer's report 04) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (`sha256sum -c` OK before the opening and the closing run) |
| Canonical manifest SHA-256 | `18f0b6dc013a0560c8968098c1b18dd7981bc236675ecf9dd8c51d00f4a6ae0d` |
| Textual diff SHA-256 (recipe) | `d6970d1d7bebe2ef1bae4dc374e51931ef5645a54440f6d1ef620fe74189dd5c` |
| Changed paths | 10 (9 `tracked_modified`, 1 `untracked` = new file), all mode `0644`, the same 10 paths as at `1479f40` |
| Writer's diff hashes | `git diff 923e9c3 26cbd65 \| sha256sum` = `f5ca82e1…78c5` and `git diff 1479f40 26cbd65 \| sha256sum` = `68af9c1d…bb40`: both reproduced exactly |

Inputs: re-audit 03 (`03-pr71-reaudit.md`), the writer's repair report 04 (`04-pr71-reaudit-repair.md`), audit 01 (`01-pr71-audit.md`), and the PR body at 23:00Z. Report hashes are in the evidence folder (`inputs.sha256`).

## 1. Audit posture

- Read-only. Nothing committed, pushed, commented or posted on GitHub. The PR body and Codex's review (of `414cb72` only, no findings) are external evidence.
- No subagents: the parent covered contract and authority, correctness, test adequacy, and security and artifacts itself (protocol §13.2 step 3 deviation, as in re-audit 03; the project instructions make subagents optional, and the scope is docs plus two test files).
- Tests ran as an unprivileged user `ci` (uid 1500, gid 1600), `runuser … env -i`, `umask 022`, Go 1.26.5 (`GOTOOLCHAIN=local`), `GOPROXY=off` after one `go mod download` per tree, HUP/INT/QUIT/TERM reset to default, on clean checkouts of the exact commits. Host packages added: uuid-runtime, openssh-client, acl, iproute2, and the en_US.UTF-8 locale.
- Audit-created artifacts live only under `/opt/audit` in this container. Nothing was written inside the provenance clone.

## 2. Provenance

- The writer's report 04 gives the tip, tree, both diff hashes and the 10-path list, but no v2 canonical manifest (protocol §5.5 asks for one on repair; this is O10 from re-audit 03 again, now partly addressed). This audit generated the target with the protocol §5.3 steps: fresh clone from GitHub, pushed tip equals `26cbd65`, base is an ancestor, `trunk_dev` still at `923e9c3`, `checkout -f -B` the topic, clean status, `reset --mixed 923e9c3`, upstream pinned to `origin/trunk_dev`, v2 run twice into a `0700` directory, `cmp` identical.
- Every per-file record the writer can be checked against matches: tree SHA, the two diff hashes, the path list.
- Compared with re-audit 03's manifest of `1479f40`, exactly three file records changed: `.docs/system_overview/runtime_identity_handoff.md`, `PLANS.md` and `workload_grants_docs_contract_test.go`. That equals the writer's repair manifest and `git diff --stat 1479f40 26cbd65` (3 files, +25/-9).
- Closing run at 23:16Z, after all tests, mutants and trial merges: byte-identical to the opening manifest. Open = close.
- Scope: 8 Markdown files and 2 root-package `_test.go` files. No product code, script, config example, CI file or generated artifact.

## 3. Re-audit 03 findings: both fixed

| Finding | What the tip says (path:line at `26cbd65`) | Pinned by | Mutants (all killed) | Result |
| --- | --- | --- | --- | --- |
| R1 "Today:" list in 11.1 goes stale | `runtime_identity_handoff.md:236-244`: "Before F1:" and three bullets in the past tense ("received", "logged in", "could read", "matched", "decided … got"). The same defect in the PLANS F1 entry is fixed too: `PLANS.md:939-942`, "It closes two gaps that existed before F1: … shared … could read … decided …" | `workload_grants_docs_contract_test.go:30-36` ("F1 starting point", all three bullets) and `:171` (PLANS sentence) | M01 "Today:" back; M02, M03, M04 each bullet back to the present tense; M05 PLANS loses "that existed before F1"; M06 PLANS back to "shares" | Fixed. The list is now timeless, so landing WI-2 or WI-3 leaves it true and it needs no status tracking |
| R2 two repair sentences unpinned | 5B temporary-edge clause, `.docs/execution_lifecycle/contracts.md:893-896`; system `contracts.md:73`, the "From WI-2, workload grants … read one of them …" sentence | `:140` (clause, in "workload grants temporary edge and its removal condition"); `:189-193` (a new check scoped to system `contracts.md` section 3, from "## 3. Shared Cross-Service Kernel" to "## 3A.", both headings present exactly once) | M07 clause back to "through the host firewall only." (03's P22); M08 only the supported-local half made wrong; M09 section 3 sentence deleted (03's P15); M10 sentence widened to "other publication claims may reach ES admission"; M11 sentence moved from section 3 into 3A | Fixed |

The section 3 sentence is both pinned for presence and listed as a network-part status sentence (`:283`). When WI-2 puts a network marker into ES Go code, `TestF1StatusSentencesSayNotYetLandedOnlyWhileTrue` fails while the sentence stands, and the presence pin fails if the sentence is simply deleted. So WI-2 has to rewrite the sentence and its pin together, which is the machine trigger the project rules ask for, and what the writer's report says WI-2 will do.

Regression mutants on the rest of the PR (all killed): M12 a section inserted between 5B and section 6 (both ARS order tests fail); M13 a WI-2 marker (`workload_grants`) in a comment in `es/config/config.go`; M14 the WI-3a marker in the same place; M15 an unlisted status sentence ("Network grants are not yet implemented and land with WI-2.") added to 11.1. The control (no change) passes the fast set and the whole root package. Each mutant ran in a tree reset with `git reset --hard && git clean -fdqx`, first against the five new tests plus the three ARS docs tests, and against the whole root package only if that set passed (none did). Harness and results: `mutants.py.txt`, `mutants-results.json`.

## 4. Fresh read of the whole diff

Scope as briefed: the PR's stated purpose (docs and doc-contract tests for the approved F1 design). No exhaustive vocabulary guards were asked for beyond the limits the PR states (status phrases inside blocks that mention F1, presence pins).

Current-behavior claims the diff makes, checked against the code at the base `923e9c3`:

| Claim (tip) | Checked against | Holds |
| --- | --- | --- |
| `configuration.md:326-327`: ES refuses `admission_policy.workload_grants` until WI-2 | `es/config/config.go:213` (`DisallowUnknownFields`), `:78-80` (`AdmissionPolicyConfig` has only `configured_static_script_literal_deny`) | Yes |
| 5B rule `id`: at most 64 bytes, alphanumeric ends, letters, digits, `.`, `_`, `-` (the literal deny entry ID rule) | `es/config/config.go:98`, `:418-443` | Yes |
| System `contracts.md` 3A: until WI-3a, no shipped allowlist or `id.conf` names a `workload` path, and workloads receive only JWT-SVIDs for the workload-vault audience | Every `allowed_spiffe_path_prefixes` in `.examples/config/*.json` and `scripts/72_supported_local_setup.sh:1319-1407` (`operator/local`, `service/control-plane`, `service/execution`, `service/artifact-governance`); `cgs/policy/id.conf` principals are `service/execution` and `script/…`; the helper calls only `FetchJWTSVID` (`es/runtimehelper/helper.go:316`) with the configured audience | Yes |
| 11.1 "Before F1": the shared ID, `unix:uid:0` plus `unix:gid:0`, signed `network_access` alone deciding | `scripts/72_supported_local_setup.sh:831-832`; the Remote Alpha checkers (`remote_alpha_vault_workload_auth_check.sh:1461`); system `contracts.md` section 7 mapping | Yes |
| 11.7: role defaults `15m`, `30m`, workload bridge subnet | `scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh:67-69` (`15m`, `30m`, `172.17.0.0/16`) | Yes |
| 11.5 and 5B: CP profile is the one that needs a credential; "no grants admits only runs that need no network and no credential" | `es/admission/runtimeprofile.go:59` (CP profile requires `network_access=true`) | Yes |
| 5B Status: sections 5 and 6 describe the current mapping and the shared identity | lifecycle `contracts.md` section 6, "Current authority handoff is structurally present and unconditional for every successful current Submit" | Yes |

Internal consistency: the 5B evaluation order (network policy first, identity only with a Vault-reaching lane, refusal codes and safe messages), the startup refusals, 11.5, 11.9 and the PLANS block agree. The ARS order test change checks 5A, then 5B, then section 6, and is killed by an inserted section (M12). No status sentence claims anything is implemented. No other Go package reads the changed docs except through comments (`es/app/submit_integration_test.go:949`, `es/admission/nomad_request_strings_redteam31_finding_test.go:59`, `internal/callerauth`, `internal/callerallowlist`); the scripts tests that read docs ran (section 5).

No new finding of Low or higher severity.

### Observations (not blocking; route as noted)

- **O1 (no action now; WI-3 when it edits section 11).** Relative-time words remain in section 11, the target text: 11.7 "The defaults are those of the current shared role: `15m`, `30m`, and the workload bridge subnet" (`runtime_identity_handoff.md:343-347`) and 11.9 "that run's response loses fields it carries today" and "it keeps every field it carries today" (`:396-402`). After WI-3 retires the shared role, "current" and "today" read as "before F1". Unlike R1, neither states a current fact that becomes false: the values are written out, and section 11 frames itself as the target. WI-3 could say "the pre-F1 shared role" when it moves 11.7 to current text.
- **O2 (WI-2 brief).** 5B says "Until WI-4, the only accepted lane is `unrestricted` with `reaches_workload_vault=true`" (`.docs/execution_lifecycle/contracts.md:821-822`), but the startup refusal list (`:843-848`) names only "a lane other than `unrestricted` before WI-4". It does not name `unrestricted` with `reaches_workload_vault=false`. The list is not exhaustive anyway (it also omits malformed names in `workload_identities`, which the name rule covers), so the contract still reads as "refuse it". WI-2 should refuse that case at startup and test it. Fail-closed either way: with `false`, a rule cannot grant an identity, so nothing widens.
- **O3 (merge gate).** The Linux "build, vet and test" job has never finished on any commit of this PR: the runs on `414cb72` and `1479f40` were cancelled by the next push (runs 45901404930 and 45905224856). The macOS job passed on `414cb72` and was cancelled on `1479f40`. On `26cbd65` both jobs started at 22:57Z and were still `in_progress` at 23:18Z. The merge gate must see both required checks ("build, vet and test" and "test on macOS") pass on `26cbd65`; branch protection on `trunk_dev` requires them anyway.
- **O4 (process).** Report 04 still carries no v2 canonical manifest; it now gives the tree and diff hashes, which this audit reproduced. Section 0 holds the manifest.
- **Merge order (carried from audit 01 O7 and re-audit 03 O9).** Trial merges of the tip with every open PR head merge cleanly. Heads at 23:00Z: #72 `a3710c0` (stacked on the tip, contains it), #70 `a0e86ea`, #69 `4f4f597`, #68 `1e3ec7c`, #66 `84da2da`, #63 `59f1f56`, #67 `69d53de`. Root package on each merge: #72 623 pass; #69 626 pass; #68 686 pass; #66 623 pass; #63 623 pass. With #70 (PLANS.md 150,155 bytes) and with #67 (150,133 bytes), only `TestPlansStaysWithinItsSizeCap` fails (cap 150,000, `plans_docs_contract_test.go:49`). #67 is new in this round: it adds 1,008 bytes to PLANS.md, and #71 adds 3,275. #69 first brings PLANS.md to 130,525 bytes with #71, which leaves room for both. So #69 should land before #71 shares `trunk_dev` with #70 or #67; otherwise whichever of the pair lands second fails the cap. This is a shared size budget, not a defect of this PR.
- **Carried, still valid at `26cbd65`, for the WI-2 to WI-5 briefs:** re-audit 03 O1 (three Workstream A guard tests to narrow by AST node; canonical versus raw principal; startup refusal of a non-canonical `publisher_principal`), O2 (`shared_kernel.md` 4B pointer), O3 (the ES caller allowlist as the bound, for the red-team), O5 and O6 (classification by containment; presence pins cannot catch an added contradiction), O7 (the Remote Alpha firewall still called a "short-term bridge"), O8 (IM does not read `authority_handoff` today); audit 01 O1, O3, O5, O6, O9, O10.

## 5. Validation (rerun on the exact bytes)

| Command (as `ci`, Go 1.26.5) | Tree | Result |
| --- | --- | --- |
| `go vet .` | tip `26cbd65`, base `923e9c3` | exit 0 on both |
| `go test -count=1 -json .` | tip | 623 pass, 0 fail, 0 skip (181 top-level tests) |
| same | base | 618 pass, 0 fail (176 top-level). The per-test difference is exactly the 5 new tests: `TestF1StatusSentencesAreAllClassified`, `TestF1StatusSentencesSayNotYetLandedOnlyWhileTrue`, `TestWorkloadGrantsContractIsDocumented`, `TestWorkstreamFF1IsPlannedAndPointedTo`, `TestWorkstreamFF1NamedWorkloadIdentityDecisionIsDocumented`. Every base test passes on the tip |
| `go test -count=1 -json ./internal/testutil ./internal/callerauth ./scripts` | tip and base | identical per test (the two TSVs are byte-identical, SHA-256 `553e07aa…94a1`): testutil 6 pass; callerauth 179 pass; scripts 2269 pass, 21 skip, 40 fail |

The 40 scripts failures are environment-only, the same on both trees, and the same 9 top-level tests audit 01 and re-audit 03 listed:

- `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`
- `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`
- `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
- `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`
- `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`
- `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`
- `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`

- Not run: `es/admission`, `es/app` and the other product packages. No Go source outside the two root test files changed, and those packages mention the changed docs only in comments.
- Mutants: 15 plus a control (section 3). All 15 killed.
- Trial merges: section 4, merge order.
- CI on `26cbd65`: "build, vet and test" (run 45907931634) and "test on macOS" (run 45907931582) started at 22:57Z and were `in_progress` at 23:18Z. This audit did not see their results. Neither job has finished on any earlier commit of this PR except macOS on `414cb72` (success); see O3.

## 6. Sensitive material

None read or copied. The manifest holds only paths, modes, sizes and hashes. Mutants used placeholder strings only.

## 7. Confidence

- Provenance: high (0.99). Manifest reproduced twice, open equals close, and every hash the writer gave matches.
- Validation: high for the root, internal and scripts packages on these bytes. CI results on the tip not seen at writing time.
- Implementation (docs and tests match the approved design and the code): high. No authority widening; the one publication-claim read stays bounded as re-audit 03 found.

## 8. Effect status

Repair, commit, push, PR comment and merge: **not performed**. Nothing posted outside this thread.

## 9. Report delivery

`/mnt/project-files/reports/Execution-Substrate/workload-identity/06-pr71-third-audit.md`. Evidence: `06-pr71-third-audit-evidence/` with `SHA256SUMS`. The report's SHA-256 is in the thread reply.

**Final verdict: ACCEPT** (R1 and R2 fixed and pinned; no new finding of Low or higher).
