# Independent re-audit 03: ES PR #71 at 1479f40 (WI-1, workload identity and workload grants docs)

Date: 2026-11-26, 22:33Z to 22:55Z (5:33 PM to 5:55 PM Eastern). Thread: "Re-audit workload identity docs PR". Auditor: a fresh, read-only thread that wrote none of this PR and did not run audit 01.

**Final verdict: BLOCK** (two Low findings, R1 and R2, no Medium or higher). All five audit 01 findings (A1 to A5) are fixed. The publication-claim addition is consistent with Workstream A, correctly bounded, design-approved, and enforceable in WI-2, and it widens nothing today. The two Lows are one-line docs or test edits; under David's standing rule Lows are fixed in the PR.

## 0. Target identity

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #71, "Docs: named workload identities and workload grants (Workstream F slice F1, WI-1)", open, not draft |
| Base | `trunk_dev` = `923e9c3366775664c8a85f19273e3dd4fc04eb22` (unchanged at 22:34Z and 22:51Z) |
| Topic branch / tip | `claude/project-thread-4rhifh` = `1479f40b467c1d8b0feaffd122d36b9d761f3503` (PR head equals it at 22:51Z). Two commits on the base: `414cb72` (audited in 01) and `1479f40` (repair) |
| Tree | `bcf81be3d5deb38309b886a9cfb07e0c846a39be` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked with `sha256sum -c` before the opening and closing runs) |
| Canonical manifest SHA-256 | `4237e70e734cb82cd7fcc5644cde29ea6443f7516c2c57a44af5540418a442dd` |
| Textual diff SHA-256 | `b02d289378c64cf29f1f5274aab5afc41e2584cd47a15df6d31a0f6c52c6c290` |
| Changed paths | 10 (9 `tracked_modified`, 1 `untracked` = new file), all mode `0644` |

Inputs: audit 01 (`01-pr71-audit.md`, SHA-256 `dc1826b4…9916`), the writer's repair report (`02-pr71-repair.md`, SHA-256 `4b83cf7a…7ef1`), the approved design (`reports/Execution-Substrate/workload-identity-network-design.md`, SHA-256 `5665179f…81da`).

## 1. Audit posture

- Read-only. Nothing committed, pushed, commented or posted on GitHub. The PR body and Codex's review are external evidence only.
- No subagents. The parent covered contract and authority, correctness, test adequacy, and security and artifacts itself (protocol §13.2 step 3 deviation; the project instructions make subagents optional).
- Tests ran as an unprivileged user `ci` (uid 1500, gid 1600), `env -i`, `umask 022`, Go 1.26.5, `GOPROXY=off` after one `go mod download`, HUP/INT/QUIT/TERM reset to default, on clean checkouts of the exact commits. Host packages: uuid-runtime, openssh-client, acl, locales (en_US.UTF-8), iproute2.
- Audit-created artifacts live only under `/opt/audit` in this container. Nothing was written inside the provenance clone.

## 2. Provenance

- The repair report carries no manifest, tree SHA or textual-diff hash (protocol §5.5 asks for new provenance on repair; audit 01 noted the same as O8). This audit generated the target with the protocol §5.3 steps: fresh clone, pushed tip equals `1479f40`, base is an ancestor, `checkout -f -B` the topic, clean status, `reset --mixed 923e9c3`, upstream pinned to `origin/trunk_dev`, v2 run twice into a `0700` directory, `cmp` identical.
- Closing run at 22:51Z, after all probes: byte-identical to the opening manifest. Open = close.
- The 10 paths: `.docs/execution_lifecycle/contracts.md`, `.docs/execution_lifecycle/es_execution_admission_model.md`, `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md`, `.docs/system_overview/configuration.md`, `.docs/system_overview/contracts.md`, `.docs/system_overview/remote_supported_host_alpha.md`, `.docs/system_overview/runtime_identity_handoff.md`, `PLANS.md`, `ars_blob_verification_docs_contract_test.go` (all `tracked_modified`), `workload_grants_docs_contract_test.go` (`untracked`). Full JSON in the evidence folder.
- Scope: 8 Markdown files and 2 root-package `_test.go` files. No product code, script, config example, CI file or generated artifact. The repair commit touches 5 of the 10 (`git diff --stat 414cb72 1479f40`), matching the repair report.

## 3. Audit 01 findings: each one is fixed

| Finding | What the tip says (path:line at `1479f40`) | Checked against | Pinned (mutant killed) | Result |
| --- | --- | --- | --- | --- |
| A1 `authority_handoff` keeps and changes shape | 11.9 bullet 4 excludes `authority_handoff` from the "keep their shapes" list (`runtime_identity_handoff.md:381-385`). Bullet 5 says F1 changes its shape, cites admission model section 4C, requires a replacement vocabulary and a compatibility and versioning plan "for CP and IM consumers alike", and says default-profile runs without an identity lose the endpoint and Vault fields | `es/admission/types.go:61`, `:73`, `:102-130`; admission model 4C row "Current `authority_handoff` field names" (`es_execution_admission_model.md:574`) has exactly that removal condition. `outcome_evidence` (`types.go:90-96`) and the producer contract DTOs (`types.go:195-230`) do not contain `authority_handoff`, so "keep their shapes" holds for them | P18, P19 | Fixed |
| A2 readiness one direction | 11.7: names compared "in either direction" (`runtime_identity_handoff.md:333-338`) | Design §7 line 442 ("differ") | P20 | Fixed |
| A3 firewall overstated | 5B config bullet (`contracts.md:823-826`), temporary-edge bullet (`:893-896`) and guardrail (`:911-914`) all scope the firewall to the Remote Supported Host Alpha box and call supported-local `unrestricted` the full `bridge` network | `scripts/remote_alpha_host_firewall.sh` exists; no `nft`/`iptables`/`DOCKER-USER` in the supported-local scripts (audit 01 grep) | P21 yes; P22 **no** (see R2) | Fixed in all three places; one place unpinned |
| A4 status honesty narrow | Table-driven per part: `f1PartMarkers` (network WI-2, identity WI-3, caller refusal WI-3a) and `f1StatusSentences` (16 entries). Two tests: one fails while a listed sentence remains and its part's marker is in non-test Go under `es/`, `internal/`, `cmd/`; one scans PLANS.md and `.docs/**/*.md` for unlisted status sentences (`workload_grants_docs_contract_test.go:213-418`) | Audit 01's surviving mutants M14b and M15b, rebuilt as P06 and P07 | P01-P04, P06, P07, P08 | Fixed for the three tracked parts. Limits in R1, O4, O5, O6 |
| A5 receipt recovery open vs settled | Idempotency §11 (`submit_idempotency_correlation_and_recovery.md:1111`) points to 5B for workload grants and keeps the question open for other policy; 5B cites it back (`contracts.md:886-891`) | Design §6.1 | P23, P24 | Fixed |

The WI-3a marker (`workload identities are never callers`) is a natural-language phrase, which would be fragile if it had to be remembered. Stacked PR #72 (head `a55d8bb`) already carries it in the error values `internal/callerauth/callerauth.go:51` and `internal/callerallowlist/callerallowlist.go:32` (both scanned), and its root package passes (623 tests). So the marker fires for the real WI-3a change.

## 4. The publication-claim addition (special attention)

What the tip says: 5B, rule field `publisher_principal`: "The publisher principal is the one `claims.package.publication` claim ES admission reads, and only as this match fact: it does not become ES request or response grammar, and no other publication claim reaches admission" (`contracts.md:837-840`, pinned, P16 and P17 killed). System `contracts.md:73` adds a "From WI-2" sentence saying the same, listed as a network-part status sentence (not pinned for presence, see R2).

**Consistent with Workstream A: yes.**
- The Workstream A rule, in every place it is stated, forbids treating publication claims as ES public admission grammar: system `contracts.md:73`, `shared_kernel.md:84`, `es_execution_admission_model.md:816` ("must not make ES public grammar depend on AGS publication fields"), `shared_kernel.md:33-34` ("ES must not inherit AGS publication grammar ... as public ES grammar"). Grammar here means ES request and response vocabulary. Reading one signed claim as an internal match fact, with fixed safe refusal messages and decision metadata that records only rule ID, identity name and lane name (`contracts.md:883-885`), adds nothing to that vocabulary.
- System `contracts.md:40-42` says a contract becomes kernel-level only when the Workstream A decision explicitly classifies it so, and the service-owned class "may cross boundaries" (`shared_kernel.md:64`). So ES reading an AGS-owned claim keeps it AGS service-owned. No doc says ES ignores or never reads publication claims (grep of PLANS.md and `.docs/` for every `publication` claim statement).

**Correctly bounded and not a widening: yes.**
- The read is design-approved: design §3.4 option (i) (line 235) keys grants on the publisher principal, and line 397 states the trust basis. The addition records a consequence the design did not spell out; it does not add a fact the design did not approve.
- The trust it rests on is an AGS invariant that is already tested: AGS fills `invoker.principal` only from the authenticated caller (`ags/publish/service.go:311-321`), refuses a request-supplied invoker (`ags/app/app_integration_test.go:336`, `TestPublishRejectsLegacyPublicationInvokerField`), and its app tests pin the derived principal (`:153`, `:210`). The grant also pins `signer_key_id`, so the claim is trusted only as signed by that key. ES verifies evidence with one configured provenance key today (`es/admission/service.go:680`).
- A principal can only narrow what a run gets: no rule matched means no network and no identity.

**Machine-enforceable in WI-2: yes, but WI-2 must change three existing guard tests, and the docs do not name them.** Routed as O1.

## 5. Findings

### R1. The F1 decision's "Today:" list goes stale when WI-2 lands, and no test ties it to a part

- Type: doc accuracy and test gap (status text with no machine trigger). Severity: **Low**. Patch defect (added by `414cb72`, unchanged by the repair).
- Path: `.docs/system_overview/runtime_identity_handoff.md:234-244` (section 11.1).
- Evidence: 11.1 opens "Today:" and lists three current facts: one shared SPIFFE ID and Vault role, the root-wide SPIRE entry, and "the publisher's signed `network_access` alone decides whether a run gets a network". The third is false once WI-2 lands, the first two once WI-3 lands. The section's own rule says each landing PR "moves the matching current-behavior text to the new rule in the same change" (`:231-232`). `f1StatusSentences` lists no sentence of this file. The scanner never sees 11.1: its blocks contain none of the F1 terms and none of the status phrases. Probe P12b (a test inside the package that calls `scanF1StatusSentences`) passes, confirming that neither the scan nor the table holds any sentence of this file.
- Impact: after WI-2 the decision record states a false current fact, and the A4 repair's claim that the status tests cover "every F1 status sentence in PLANS.md and .docs/" does not hold for this list. This is the "revisit later without a machine trigger" pattern the project rules forbid.
- Required correction: make the list timeless, for example "Before F1:" instead of "Today:" (P26: all 623 root tests pass with that change). Listing the three bullets in `f1StatusSentences` with their parts would also work, but timeless wording needs no later edit. Not required: a broader scanner (see O4).

### R2. Two sentences the repair relies on are not pinned

- Type: test gap. Severity: **Low**. Patch defect (both added or changed by the repair commit).
- Path and evidence:
  - The A3 temporary-edge clause (`.docs/execution_lifecycle/contracts.md:893-896`, "through the host firewall on the Remote Supported Host Alpha box and through the full `bridge` network on supported-local hosts"). P22 rewrote it back to "through the host firewall only", which is the A3 defect itself. All 623 root tests passed. The repair report lists A3 as "Pinned by `TestWorkloadGrantsContractIsDocumented`"; that holds for the config bullet and the guardrail, not for this clause.
  - The system contracts section 3 publication sentence (`.docs/system_overview/contracts.md:73`, "From WI-2, workload grants ... read one of them ..."). P15 deleted it, and all 623 root tests passed. The honesty test only checks a listed sentence while it is present, so deleting it passes. The 5B version is pinned, so deleting this one leaves the live Workstream A contract silent on the read, not contradictory.
- Impact: either text can regress unnoticed. The first brings A3 back in one of its three places.
- Required correction: add both phrases to existing `assertContainsAll` calls: the clause to "workload grants temporary edge and its removal condition", the sentence to a system `contracts.md` section 3 check in `TestWorkstreamFF1IsPlannedAndPointedTo`.

### Observations (not blocking; route as noted)

- **O1 (WI-2 brief: enforcing the one publication read).** Three existing guard tests in `es/admission/workstream_a_guardrails_test.go` stop WI-2 as written, and each needs a narrow change:
  - `TestWorkstreamAESImplementationDoesNotExposeAGSPublicationGrammar` (`:645`) and its mirror `TestWorkstreamAPublicationAllowRuleJudgesTheCodeNotTheLine` (`:662`) flag any identifier that *contains* `Publication`, `Invoker`, `Publisher` or `publisher` in `es/admission`, `es/api` and `es/app` (`:1218`, `:1291`). The read `….Claims.Package.Publication.Invoker.Principal`, and any `PublisherPrincipal` field access or `publisher…` local in those packages, trips it. WI-2 should allow the one selector chain by AST node in one named function and file, the way `PolicyDecision` is allowed (`:1356-1367`). An allow by spelling would reopen the guard for every `Publisher*` identifier. `es/config` is outside the guard's file set, so the config field itself is not caught.
  - `TestWorkstreamAAdmissionTreatsPublicationAsSignedButNotESGrammar` (`:107-145`) varies `Invoker.Principal` together with the other publication fields and requires an identical prepared result. With grants that is no longer the contract: a principal change can turn an admit into `403 network_access_not_granted`. Split it: with grants configured and network requested, every other publication field still changes nothing, and the principal changes only the grant outcome.
  - Evidence canonicalization trims `invoker.principal` before signing (`internal/contracts/evidence/v1/package_claims.go:171`), so a raw record with surrounding white space verifies. WI-2 should say which value it matches. The canonical value carries the signed meaning; the raw value fails closed.
  - 5B describes `publisher_principal` as "a SPIFFE ID that the caller authentication contract ... accepts, written in that form", but the startup refusal list does not include a non-conforming value, which would silently never match (fail closed). WI-2 should either refuse it at startup with the `callerauth` parser or say it is not checked.
- **O2 (WI-2): the Workstream A classification table.** `shared_kernel.md:84` (section 4B row for `claims.package.publication`) is not updated. It stays true under the grammar reading, but a reader of the classification table will not learn that ES admission reads one sub-field from WI-2 on. WI-2 could add a pointer there and list it as a network-part status sentence.
- **O3 (WI-2 red-team).** Grants do not key on the ES caller. Any caller the ES allowlist admits can submit a CP-published artifact with the CP profile annotation and receive CP's grant. This is the approved four-fact design, and it is no wider than today, where every run shares one identity. The red-team should confirm the ES caller allowlist is the intended bound.
- **O4 (stated limits of the status scan).** P09 ("Network grants are not yet implemented." has no F1 term), P10 ("pending"), P11 (README.md) and P14 ("before WI-2") pass the whole root package. These are within the code comment's stated scope (a status phrase, in a block that mentions F1, in PLANS.md or `.docs/`). The PR body says more: "another fails on an F1 status sentence the table does not list". Narrow that sentence to the phrases. WI-4 and WI-5 status text ("Until WI-4, ...", "From WI-4, ...") is outside the three tracked parts. That matters for the one temporary edge, `unrestricted`, whose removal has no machine trigger (audit 01 O9, for the WI-2 audit).
- **O5.** Classification matches by containment, so a new sentence that embeds a listed fragment takes that fragment's parts. P13b: "Workload grants for the network are not yet implemented, and It lands with WI-3 for identities." in `configuration.md` was classified as identity-only and passed. Theoretical, because a writer would have to embed the fragment verbatim; exact sentence matching would close it.
- **O6.** Presence pins cannot catch an added contradicting sentence (P25, "A `mode` of `disabled` turns grants off.", survived the whole package). This is a known limit (audit 01 O4).
- **O7.** The Remote Alpha firewall is still called "a short-term bridge until ... F1 ... land" (`remote_supported_host_alpha.md:7026-7028`, `PLANS.md:1142-1144`), while F1 now keeps it as a second wall. Read together, the text means the firewall stops being the only egress control. Clearer wording would say so; no behavior is affected.
- **O8.** 11.9 says the `authority_handoff` field names are an edge "that CP and IM consume". Admission model 4C says "CP/IM-consumable". IM `trunk_dev` `9623f5c` does not read `authority_handoff` (grep for `authority_handoff`, `identity_handoff`, `endpoint_env`, `jwt_svid_target`; its support bundle reads other summary keys). Harmless, since the rule binds WI-3 either way.
- **O9 (merge order, unchanged from audit 01 O7).** Trial merges with the current heads: #69 `4f4f597`, #70 `a0e86ea`, #68 `1e3ec7c`, #66 `84da2da`, #63 `59f1f56`. All merge cleanly. Root package results: with #69, 626 pass; with #68, 686; with #66, 623; with #63, 623. With #70 it fails only `TestPlansStaysWithinItsSizeCap` (PLANS.md 150,128 bytes > 150,000). #69 first gives 130,498.
- **O10 (process).** The repair report delivers no manifest, tree SHA or diff hash (protocol §5.5, §11). This audit's target is in section 0.
- **Carried from audit 01, still valid at `1479f40`:** O1 (ES install and the Remote Alpha upgrade write today's grants in WI-2), O3 (TTL defaults unpinned), O5 (reserve lane name `none` in WI-4), O6 (identity-name change under re-evaluation, WI-5), O9 (machine trigger for `unrestricted`, WI-2 audit), O10 (`docker:image_id`, WI-3 brief).

## 6. Fresh read of the whole diff (beyond the repair)

Re-checked against the code at the base, with no new findings: CP profile requires `network_access=true` today (`es/admission/runtimeprofile.go:58-59`), so "no grants admits only runs that request no network and need no credential" (`configuration.md:334-335`, 5B) is accurate even between WI-2 and WI-3. The 5B evaluation order, startup refusals, and re-evaluation rule are internally consistent with 11.5 (identity only with a Vault-reaching lane). PLANS edits keep every compatibility-edge row and only add F1 pointers. The `ars_blob_verification_docs_contract_test.go` change checks 5A, then 5B, then section 6, in order. No status sentence claims anything is implemented.

## 7. Validation (rerun on the exact bytes)

| Command (as `ci`, Go 1.26.5) | Tree | Result |
| --- | --- | --- |
| `go vet .` | tip `1479f40`, base `923e9c3` | exit 0 on both |
| `go test -count=1 -json .` | tip | 623 pass, 0 fail, 0 skip |
| same | base | 618 pass, 0 fail. The per-test difference is exactly the 5 new tests: `TestF1StatusSentencesAreAllClassified`, `TestF1StatusSentencesSayNotYetLandedOnlyWhileTrue`, `TestWorkloadGrantsContractIsDocumented`, `TestWorkstreamFF1IsPlannedAndPointedTo`, `TestWorkstreamFF1NamedWorkloadIdentityDecisionIsDocumented`. Every base test passes on the tip |
| `go test -count=1 -json ./internal/testutil ./internal/callerauth ./scripts` | tip and base | identical per test (the two TSVs are byte-identical): testutil 6 pass; callerauth 179 pass; scripts 2269 pass, 21 skip, 40 fail |

The 40 scripts failures are environment-only and the same on both trees. They are the same 9 top-level tests audit 01 listed:

- `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`
- `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`
- `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
- `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`
- `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`
- `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`
- `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`

- Not run: `es/admission` and `es/app`. No Go source outside the two root test files changed, and those packages mention the changed docs only in comments.
- Mutation and probe runs: 28 (`mutants.py.txt`, `mutants2.py.txt`). Each ran in a pristine tree reset with `git reset --hard && git clean -fdqx`, with `git add -A` before testing. The five new tests ran first, and every survivor then ran against the whole root package.
  - Killed: P01-P04, P06-P08, P12, P13, P16-P21, P23, P24.
  - Survived as expected: P05 (a marker in a `_test.go` file must not count) and P26 (control for R1's fix).
  - Survived as findings: P15 and P22 (R2). P12b passes, which confirms R1.
  - Survived as stated limits: P09, P10, P11, P14 (O4), P13b (O5), P25 (O6).
  - P12 and P13 were killed by other listed sentences, not by the property they were written for; P12b and P13b replace them.
- CI on `1479f40`: "build, vet and test" and "test on macOS" were `in_progress` at 22:51Z (started 22:30Z). This audit did not see their results.

## 8. Sensitive material

None read or copied. The manifest holds only paths, modes, sizes and hashes. Probes used placeholder strings only.

## 9. Confidence

- Provenance: high (0.99). The manifest was reproduced twice and open equals close. With no writer manifest, the binding is to the commit SHA.
- Validation: high for the root, internal and scripts packages on these bytes. CI results not seen.
- Implementation (docs and tests match the approved design and the code): high. Two Low gaps, no authority widening. The publication read is design-approved, bounded, and enforceable in WI-2 with the guard changes in O1.

## 10. Effect status

Repair, commit, push, PR comment and merge: **not performed**. Nothing posted outside this thread.

## 11. Report delivery

`/mnt/project-files/reports/Execution-Substrate/workload-identity/03-pr71-reaudit.md`. Evidence: `03-pr71-reaudit-evidence/` with `SHA256SUMS`. The report's SHA-256 is in the thread reply.

**Final verdict: BLOCK** (R1 and R2, both Low; A1 to A5 fixed).
