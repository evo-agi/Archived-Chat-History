# Addendum 06a to audit 06 of ES PR #71: CI on the audited tip, and the merge

Date: 2026-11-26, 23:45Z (6:45 PM Eastern). Same thread and auditor as report 06 (`06-pr71-third-audit.md`, SHA-256 `4b0b2f4181719b3f5df47a9fab15454d26b241cba96a6ba3b90f8741afea6f7a`). Report 06 is unchanged; this file closes its O3 (CI not seen at writing time).

| Check on `26cbd653c1c4b5173c971d679fccb3d4c489a183` | Run / job | Started | Completed | Conclusion |
| --- | --- | --- | --- | --- |
| build, vet and test | run 45907931634, job 140209161172 | 22:57:12Z | 23:42:31Z | success |
| test on macOS | run 45907931582, job 140209184524 | 22:57:17Z | 23:27:23Z | success |

- PR #71 was merged at 23:43:09Z (GitHub reports `merged_by` SeritArbores) with head `26cbd65`, the audited commit. The merge commit is `39e19defb0ea6c0bda30a14f88452b24f9bd9cdf` on `trunk_dev`; its tree is `178defa90f883644497e6fc97573ffdf35d3f39c`, the same as the audited tip's, and every one of the 10 manifest paths has the same blob as at `26cbd65` (checked with `git rev-parse` on both commits).
- This audit did not perform or approve the merge. The merge record (protocol §15) belongs to whoever ran the merge gate.
- Merge-order note from report 06 still applies to the remaining open PRs: with #71 now on `trunk_dev`, #70 or #67 exceed the 150,000-byte PLANS cap unless #69 lands first.
