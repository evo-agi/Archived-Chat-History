# Independent audit 01: ES PR #71 (WI-1, workload identity and workload grants docs)

Date: 2026-11-26, 21:56Z to 22:35Z (4:56 PM to 5:35 PM Eastern). Thread: "Audit workload identity docs PR". Auditor: fresh read-only thread that wrote none of this PR and has not audited it before.

**Final verdict: BLOCK** (five Low findings, A1 to A5, no Medium or higher). Under David's standing rule, Low findings are fixed in the PR. Each one is a small docs or test edit. Nothing in the PR changes behavior, and the dropped "off" switch is a strict tightening that David does not need to decide (section 4).

## 0. Target identity

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| PR | #71, "Docs: named workload identities and workload grants (Workstream F slice F1, WI-1)", not draft, author account SeritArbores (commit author "Claude") |
| Base | `trunk_dev` = `923e9c3366775664c8a85f19273e3dd4fc04eb22` (unchanged at 21:57Z and again at 22:33Z) |
| Topic branch / commit | `claude/project-thread-4rhifh` = `414cb72179d88afca9db8749ce06f4251051ced6` (one commit, parent `923e9c3`; unchanged at 22:33Z) |
| Tree | `1ed34555c39a3154c6fe5f2e0708b7352bd6bc68` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified with `sha256sum -c` before each run) |
| Canonical manifest SHA-256 | `83b685c4167e621d30459e0eea18aa40bd714ffd17bf2e6a7bcf30850118d3da` |
| Textual diff SHA-256 | `9bd5f1a6ef93860c5093564bb4c99aeb058ad019dc72c0bd7afe8272af34a43f` |
| Changed paths | 9 (8 tracked_modified, 1 untracked = new file) |

Design compared against: `/mnt/project-files/reports/Execution-Substrate/workload-identity-network-design.md` (approved by David 2026-11-23 16:29Z), cited below as "design §N".

## 1. Audit posture

- Read-only. Nothing committed, pushed, commented or posted outside this thread. Codex's bot review on the PR (no findings, 21:57Z) is external evidence only.
- No audit subagents were used. The parent covered the four protocol perspectives (contract and authority, correctness, test adequacy, security and artifacts) itself. Deviation from operating protocol §13.2 step 3, which the project instructions make optional ("may use").
- All tests ran as an unprivileged user `ci` (uid 1500, gid 1600), `env -i`, `umask 022`, Go 1.26.5 (`go.mod` pin), `GOPROXY=off` after one `go mod download`, signals HUP/INT/QUIT/TERM reset to default, on clean checkouts of the exact commits (not the provenance working tree, because the root docs tests list files through git).
- Audit-created artifacts: `/opt/audit/*` in this container only. Nothing written inside the provenance clone.

## 2. Provenance reproduction

- The writer delivered no implementation report and no manifest (the writer thread's last reply, 21:55:59Z, links the PR only; nothing new under `reports/`). So there was no reported manifest to compare against. This audit generated the target itself with the protocol §5.3 steps: fresh clone, `origin/claude/project-thread-4rhifh` = `414cb72` checked, base is an ancestor, checkout `-B` the topic, clean status, `reset --mixed 923e9c3`, upstream pinned to `origin/trunk_dev`, v2 run twice to two absent paths in a `0700` directory, `cmp` identical.
- Closing run (22:33Z): v2 again, byte-identical to the opening manifest. Open = close.
- The commit SHA binds the bytes, which is the lighter provenance tier the procedures allow for docs and localized tests. Observation O8 records the missing writer report.
- Manifest file list: `.docs/execution_lifecycle/contracts.md`, `.docs/execution_lifecycle/es_execution_admission_model.md`, `.docs/system_overview/configuration.md`, `.docs/system_overview/contracts.md`, `.docs/system_overview/remote_supported_host_alpha.md`, `.docs/system_overview/runtime_identity_handoff.md`, `PLANS.md`, `ars_blob_verification_docs_contract_test.go` (all `tracked_modified`, `0644`), `workload_grants_docs_contract_test.go` (`untracked`, `0644`). Full JSON in the evidence folder.

## 3. Scope and "no product code" check

- 7 Markdown files and 2 root-package `_test.go` files. No file under `es/`, `internal/`, `cmd/`, `ags/`, `ars/`, `egs/`, `cgs/`, `scripts/`, `.github/`, no config example, no generated or binary artifact, no `.pyc`, cache or database. GitHub's file list for #71 shows the same 9 files.
- **No product code change: confirmed.**
- The two test files are in package `executionsubstrate_test` at the repo root. They read docs and walk `es/`, `internal/`, `cmd/` source text. They start no service and touch no network.

## 4. The dropped "off" switch: strict tightening, not a decision David must make

What the design said:

- The config sketch in design §4.4 (line 313) has `"mode": "enforce"`. No other value and no semantics for one are given anywhere, and the evaluation rules 1 to 7 (lines 334-342) never mention `mode`.
- The field copies the existing configured literal deny policy, whose `mode` accepts `disabled` or `enforce` ([F] `es/config/config.go:84-87`; `.docs/execution_lifecycle/contracts.md:203` at `414cb72`). So an "off" value was implied by analogy, not specified.

What the PR says:

- No `mode`. "No setting turns grants off. A configuration without `workload_grants`, or with no rules, admits only runs that request no network and whose runtime profile needs no credential" (`.docs/execution_lifecycle/contracts.md:813-815`). The admission-model guardrails forbid "a switch that turns grants off" (`es_execution_admission_model.md:764-769`). PLANS says the policies "cannot be turned off" (`PLANS.md:642-646`).

Judgement:

- Every configuration the PR accepts behaves exactly as the design's `mode: enforce` does, under the same evaluation rules. The only configurations removed are ones with a non-enforcing mode. The design never defined their behavior, and they would bring back the publisher-only network decision (gap 5, threat T4) with none of the readiness reporting the design requires for its one sanctioned widening (`unrestricted`). No run is admitted under the PR that the design would refuse. **This is a strict tightening of the accepted configuration space.**
- It removes nothing the approved design relied on. The box rollback in design §8 restores backed-up config and binaries; it does not use a mode switch.
- The cost is operational: once WI-2 lands there is no single switch to fall back on. Recovery is the existing ES upgrade rollback, or writing a grant. So **every path that installs or upgrades ES must write today's grants in the same change as WI-2**, or the CP normal-shell profile and the identity proof stop working on the first upgrade. The PR's WI-2 row says "setup scripts that write grants for today's flows" (`runtime_identity_handoff.md`, 11.10). It does not name the Remote Alpha ES upgrade path (`scripts/internal/remote_alpha_upgrade_es.py`). Routed to the WI-2 brief as O1.
- David has already been told: the writer's reply in its thread at 21:55:59Z ("I dropped the 'off' switch...") and the PR body's "Refinements" list. Recommendation: the coordinator repeats it in the merge report. No decision card is needed.

## 5. Match against the approved design

| Design item | PR | Result |
| --- | --- | --- |
| Option B named identities, ID `spiffe://execution.internal/workload/<name>` (§3.2, §14.1) | 11.2, PLANS F1 | Match |
| Per-run path reserved, `/workload/<name>/run/<run_id>` (§14.1) | 11.2, and "every other path under `workload/` is reserved" | Match, slightly stricter |
| Name rule `[a-z0-9-]{1,48}`, "Guess at the limit; set in the brief" (§3.2) | 1 to 63, must start with a letter or digit | Within the latitude the design left (O2) |
| SPIRE entry per name: label selector plus `unix:uid:0`; broad entry removed (§3.1, §3.2) | 11.7 | Match |
| Vault role and policy `workload-<name>`, exact `bound_subject`, explicit TTLs (§3.2) | 11.7, defaults 15m/30m/bridge subnet | Match. Defaults equal `PLANS.md:1180-1182` (line numbers at the tip; text unchanged from the base) |
| Owner rule picks the name, four exact match fields, no publisher claim, Workstream A removal kept (§3.4) | 11.3, 5B | Match |
| ES has no SPIRE or Vault admin rights (§3.5, §13.5) | 11.3 | Match |
| No grant means no handoff; helper checks expected ID (§3.1, §14.3) | 11.5, 11.6 | Match |
| `network_access` request AND grant; `403 network_access_not_granted` on `:prepare` and `:submit` (§4.2, §4.4) | 5B evaluation 1-6 | Match |
| `unrestricted` as the only lane before lanes land, reported as `workload_egress_unrestricted=true`, removed by the lanes PR with a startup refusal (§4.3) | 5B, PLANS F1 | Match |
| Startup refusals: unknown names or lanes, duplicate match fields, identity with a non-Vault lane (§4.4, §7) | 5B config | Match, plus refusals for white space and empty fields (stricter) |
| `mode: enforce` in the sketch (§4.4) | Dropped | Strict tightening (section 4) |
| Readiness refuses when "the registered names differ from the configured names" (§7) | One direction only | **A2** |
| Decision log records rule ID, name, lane (§4.4 rule 7) | "internal decision metadata" | Match |
| Grant denial is deterministic denial; zone blob fetch failure is unavailable (§6.1) | 5B | Match |
| Re-evaluate on every effect-causing delivery, not on read-only receipt recovery (§6.1) | 5B | Match, but see **A5** |
| Workload identities never callers (§6.2, T10) | 11.2, system contracts 3A pointer | Match |
| Scheduler neutrality: decide in names, one translation place, guard test, no plug-in (§5.3) | 11.4, 5B guardrails | Match |
| Firewall: N3 "may be used inside N2 as a second wall" (§4.3) | Kept as a second wall under lanes | Match (refinement narrows the earlier "replace" wording) |
| Hooks for per-run later (§14: ID layout, one seam, expected-ID string, realized ID in formats, `<name>/shared/`) | 11.2, 11.4, 11.6, 11.8, 11.10 WI-5, 11.7 | All five present |
| Delivery WI-1 to WI-5 and gates (§15.2) | 11.10 | Match |
| Optional `docker:image_id` hardening, "decide in the brief" (§3.2) | Not mentioned | Left open for WI-3 (O10) |
| `authority_handoff` | Not in the design. PR adds a shape plan (11.9) | New detail. Internal contradiction, **A1** |

## 6. Silent widening of supported-local or Remote Alpha behavior

- Behavior: none. No code, script, config example or CI file changed.
- Claims: every behavior statement in the PR is marked as a target ("decided and not yet implemented", "lands with WI-n"). The statements of current fact that I checked hold:
  - ES refuses the `workload_grants` key today: probe `TestAuditProbeWorkloadGrantsKeyRefused` gave `decode config: json: unknown field "workload_grants"`, while the unmodified example loads cleanly (`es/config/config.go:212-213`, `DisallowUnknownFields`).
  - No allowlist or `id.conf` the repo ships names a `workload` path: `.examples/config/*.json`, `scripts/72_supported_local_setup.sh:1319-1407` and `cgs/policy/id.conf` name only `operator/local`, `service/...` and `script/...`.
  - Workloads receive only JWT-SVIDs: `es/runtimehelper/helper.go:232`, `:316`.
  - The C6 rule ID limit and entry-ID rule copied from literal deny match `es/config/config.go:95-99`, `:419-438`.
  - `static-script/default` is the default profile name (`es/admission/runtimeprofile.go:13`).
- One protection claim is too broad: the host firewall exists only on the Remote Alpha box, but the grants contract states it as if it applied everywhere. **A3**.
- Firewall wording moves from "replaces its container rules" to "keeps them as a second wall": a narrowing.

## 7. Findings

### A1. `authority_handoff` is said to keep its shape and to change shape

- Type: contract/authority drift (internal inconsistency). Severity: **Low**. Patch defect.
- Path: `.docs/system_overview/runtime_identity_handoff.md:379-393` (section 11.9).
- Evidence: bullet 4 says "The ES public execution request and response DTOs, `GET /v1/executions:contract`, `outcome_evidence`, CP compatibility, and M6 support-bundle inputs keep their shapes." Bullet 5 then says `identity_handoff` gains `workload_identity` and `spiffe_id`, and that for a run without an identity `identity_handoff.mode` is `none` and the endpoint and Vault fields are absent. `authority_handoff` is a field of the submit and status response DTOs ([F] `es/admission/types.go:61`, `:73`). `endpoint_env`, `endpoint_uri` and `jwt_svid_target` are not `omitempty`, and `workload_vault` is a non-pointer struct (`types.go:102-130`), so "absent" is a shape change. The repo treats those field names as a compatibility edge: `.docs/system_overview/contracts.md:675` keeps them "unless a coordinated migration/versioning note says otherwise", and `es_execution_admission_model.md:574` says to change them "only after a documented replacement handoff vocabulary and explicit compatibility/versioning plan exist", calling them "CP/IM-consumable". Section 11.9 speaks only of CP.
- Impact: WI-3's writer and auditor get two contradicting sentences in one section. IM consumers are not covered. "Every field CP reads today stays present" holds for `control-plane-normal-shell/v1` runs only. Unknown: whether CP reads `authority_handoff` on default-profile runs, which lose those fields under F1. That needs the CP consumer's source.
- Required correction: scope bullet 4 so it excludes `authority_handoff`. State that WI-3 changes `authority_handoff` under the `es_execution_admission_model.md:574` rule (replacement vocabulary plus a compatibility/versioning plan) for both CP and IM consumers, and that default-profile runs without an identity lose the endpoint and Vault fields.

### A2. The readiness check on registered names covers one direction only

- Type: departure from the approved design (acceptance check narrowed, and not listed among the PR's refinements). Severity: **Low**. Patch defect.
- Path: `.docs/system_overview/runtime_identity_handoff.md:333-336`, pinned at `workload_grants_docs_contract_test.go:62`.
- Evidence: design §7 (line 442), "New machine-enforced checks": readiness refuses `submit-ready` if "the registered names differ from the configured names". The PR refuses only an entry that "names an identity that ES configuration does not list". A name ES lists but nobody registered passes readiness. ES startup checks only that grants name listed identities (5B), not that listed names are registered in SPIRE and Vault.
- Impact: fail-closed (a granted run's helper finds no matching SVID, and the task dies before the workload starts), but late. One of the design's machine checks is lost without saying so.
- Required correction: "...or the registered names differ from the names ES configuration lists" (both directions), with the pin updated. Or keep one direction and list it under the PR's refinements with the reason.

### A3. The grants contract says "under the host firewall" where no firewall exists

- Type: doc accuracy (overstated protection outside Remote Alpha). Severity: **Low**. Patch defect.
- Path: `.docs/execution_lifecycle/contracts.md:821-824`, `:884-885` ("a granted run reaches the internet through the host firewall only"), `:900-902`. Pinned at `workload_grants_docs_contract_test.go:106`.
- Evidence: the firewall is the Remote Alpha box's (`scripts/remote_alpha_host_firewall.sh`; `PLANS.md:1136-1145`). `scripts/70_linux_setup.sh`, `scripts/72_supported_local_setup.sh` and `scripts/01_bringup.sh` contain no `nft`, `iptables` or `DOCKER-USER` (grep count 0). The CP normal-shell profile has supported-local realizations (`.docs/execution_lifecycle/contracts.md:456`).
- Impact: on supported-local hosts, `unrestricted` is the plain `bridge` network, which reaches the LAN and host services. The contract describes the risk of the temporary edge as smaller than it is there.
- Required correction: scope the firewall sentences to the Remote Alpha box, and say that supported-local hosts have no host firewall, so there `unrestricted` is the full bridge network. Update the pin.

### A4. The status-honesty test guards one sentence, and only until the first part lands

- Type: test adequacy (the guard is narrower than its comment and the PR body claim). Severity: **Low**. Patch defect.
- Path: `workload_grants_docs_contract_test.go:201-247`.
- Evidence: the test returns early unless 5B contains exactly "This contract is decided and not yet implemented." (`:206-210`). Mutants with every doc pin updated the way a WI-2 writer would update them:
  - **M14b survived:** code names `network_access_not_granted`, `workload_grants` and `workload_identity_not_granted`, while 5B says "The identity part is decided and not yet implemented."
  - **M15b survived:** code names `workload_grants`, 5B is updated, and `configuration.md:326-327` still says "ES refuses the key until WI-2 lands". `TestWorkstreamFF1IsPlannedAndPointedTo` (`:190`) even requires that stale sentence.
  - The other status sentences the PR adds are not tied to code markers at all: `contracts.md:218-219`; `es_execution_admission_model.md:289-296`; `configuration.md:108-110`, `:326-331`; `PLANS.md:642-646`, `:936`; system `contracts.md:208-215`, `:932-936`, `:1295-1302`.
  - The test comment (`:201-204`) and the PR body ("so WI-2 and WI-3 must update the docs in the same change") claim more than this.
- Impact: WI-2's docs move is enforced. WI-3's is not, and neither is any status sentence outside 5B.
- Required correction: make the check table-driven per part. Each status sentence names its part (network: `network_access_not_granted`, `...network-grant/v1`, `workload_grants`; identity: `workload_identity_not_granted`, `...workload-identity-grant/v1`). The test fails when a sentence is still present and its part's marker appears in ES code. At minimum, narrow the comment and the PR body claim to what the test enforces.

### A5. Grants settle a question the idempotency contract still calls open

- Type: doc consistency (cross-doc gap). Severity: **Low**. Patch defect.
- Path: `.docs/execution_lifecycle/contracts.md:880-882` versus `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md:1111` (unchanged by the PR).
- Evidence: 5B says "Read-only receipt recovery does not evaluate them." The idempotency contract still says "Whether mutable admission policy is re-evaluated for read-only receipt recovery remains open." Neither cites the other. The design §6.1 answer was meant to settle exactly that line.
- Impact: two authoritative docs disagree on whether the question is open, for the grant policies at least.
- Required correction: in the idempotency contract §11, say that workload grants decide this in lifecycle `contracts.md` section 5B and that it stays open for other mutable admission policy. Or cite that line from 5B.

### Observations (not blocking; route as noted)

- **O1 (WI-2 brief):** with no off switch, the ES install paths and the Remote Alpha ES upgrade path must write today's grants in WI-2 itself (section 4).
- **O2:** name limit 63 versus the design's guessed 48 is within the latitude the design left. The 63 is a deliberate choice, not drift.
- **O3:** the TTL defaults sentence (11.7, "`15m`, `30m`, and the workload bridge subnet") is not pinned: mutant M25 survived. WI-3's code tests should pin the values.
- **O4:** presence pins cannot catch an added contradicting sentence (mutant M03, "A `mode` of `disabled` turns grants off.", survived). This is a known limit of phrase pins, not a finding.
- **O5 (WI-4):** the lane name rule allows a lane literally named `none`, while 5B uses "none" for "no network". WI-4 should reserve it. Today only `unrestricted` is accepted, so nothing is affected.
- **O6 (WI-5):** "refuses when a grant was removed or narrowed" does not say what a change of identity name is. Define it with the format revision. "No replay may create a wider second effect" still governs.
- **O7 (merge order):** #71 alone leaves `PLANS.md` at 149,098 bytes (cap 150,000). Trial-merged with draft #70 it is 150,128 bytes, and `TestPlansStaysWithinItsSizeCap` fails. With #69 first, it is 130,498 (and 131,528 with #70 as well). The cap test catches it, so whichever lands second trims.
- **O8 (process):** no implementation report or manifest was delivered for #71 (protocol §11). This audit generated the target. The coordinator may want the writer to deliver one with the repair.
- **O9 (WI-2 audit):** the `unrestricted` edge's trigger is readiness visibility plus WI-4's acceptance test. Nothing fails if WI-4 never lands. That is the approved design. WI-2's audit should judge whether it meets the project's machine-enforced-trigger rule.
- **O10 (WI-3 brief):** the optional `docker:image_id` selector (design §3.2) is not mentioned. The design left it to the brief.
- **O11:** PR #72 (WI-3a) is already open and stacked on #71's branch, so a repair of #71 means rebasing #72 and the writer's WI-2 branch.

## 8. Validation (rerun on the exact bytes)

| Command (as `ci`, Go 1.26.5) | Tree | Result |
| --- | --- | --- |
| `go vet .` | tip `414cb72`, base `923e9c3` | exit 0 on both |
| `go test -count=1 -json .` | tip | 622 pass, 0 fail, 0 skip (13.6 s) |
| same | base | 618 pass, 0 fail. The per-test difference is exactly the 4 new tests: `TestWorkloadGrantsContractIsDocumented`, `TestWorkloadGrantsDocsSayNotYetImplementedOnlyWhileTrue`, `TestWorkstreamFF1IsPlannedAndPointedTo`, `TestWorkstreamFF1NamedWorkloadIdentityDecisionIsDocumented`. Every base test, including the changed ARS ordering tests, still passes |
| `go test -count=1 -json ./internal/testutil ./internal/callerauth ./scripts` | tip and base | identical per test on both: testutil 6 pass; callerauth 179 pass; scripts 2269 pass, 21 skip, 40 fail |

The 40 scripts failures are environment-only, identical on base and tip (container, not the CI runner). The 9 failing top-level tests:

- `TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal`
- `TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody`
- `TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusRemoteWrapperTrap`
- `TestRemoteAlphaOperatorRecoverySessionESTLSStatusStageFIFORefusal`
- `TestRemoteAlphaP0tGrammarDiagnosticBootstrapLifecycleComposition`
- `TestRemoteAlphaP0tGrammarDiagnosticPriorReaderCloseSuppression`
- `TestRemoteAlphaP0tGrammarDiagnosticV2VersionedBootstrap`
- `TestRemoteAlphaUpgradeESCheckRefusesWhatItWasNotWrittenFor`

The full list with subtests is in the evidence TSVs.

- Not run: `es/admission` and `es/app`. They mention the changed docs only in comments (grep of `*_test.go` for the 7 doc names), and no Go source outside the two root test files changed.
- Trial merges (`git merge-tree --write-tree`) of `414cb72` with every open PR into `trunk_dev`: #70 `003e09c`, #69 `a0c844e`, #68 `1e3ec7c`, #66 `84da2da`, #63 `59f1f56`. All merge cleanly. The root package passes on the merges with #69 (625), #68 (685), #66 (622) and #63 (622). It fails only `TestPlansStaysWithinItsSizeCap` with #70 (O7).
- Mutation probes: 28 mutants on docs and code markers (harness in evidence). 24 killed, each by the test named in the results. Survivors: M03 and M25 (O4, O3), M14b and M15b (A4).
- CI on `414cb72`: "build, vet and test" and "test on macOS" were still `in_progress` at 22:33Z (started 21:55Z and 21:57Z). This audit did not see their results.

## 9. Sensitive material

None read or copied. The manifest holds only paths, modes, sizes and hashes. The probe used the repository's own example config with placeholder values.

## 10. Confidence

- Provenance: high (0.99). The manifest was reproduced twice and open equals close. With no writer manifest, the binding is to the commit SHA.
- Validation: high for the root, internal and scripts packages on these bytes. CI results were not seen at publish time.
- Implementation (docs and tests match the approved design and the code): medium-high. Five Low gaps, no authority widening, the off-switch removal is a tightening.

## 11. Effect status

Repair, commit, push, PR comment and merge: **not performed**. Nothing posted outside this thread.

## 12. Report delivery

`/mnt/project-files/reports/Execution-Substrate/workload-identity/01-pr71-audit.md`. Evidence: `01-pr71-audit-evidence/` with `SHA256SUMS`. The report's SHA-256 is given in the thread reply.

**Final verdict: BLOCK** (A1 to A5, all Low).
