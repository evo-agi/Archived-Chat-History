# ES PR #31 — Nomad submit lock: red-team

```
Target:            evo-agi/Execution-Substrate, draft PR #31 ("only ES can submit to Nomad")
Head:              6d1346fa792c6a4f78589c86d97835832ce610ac
                   tree 865e74d1545461acebe5f6b1c494b85187a5882d
                   recipe governed-execution.audit-patch-manifest.v2, source sha256
                   c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca (verified)
                   manifest_sha256 a0ce1b2fbc6e3ec40b7412cd99a0529025624e8ee13522b03998624c3ac5a654
                   textual_diff_sha256 e7d5c261353eb7dd3035ae4bc23066e1e976add82b9337d2bedda2e8e1e76008
                   52 paths
Prior reports:     01-implementation, 02-audit (BLOCK, fixed), 03 (fixes + part 2a),
                   04-re-audit (BLOCK on 4 Lows, fixed), 05-repair, 06-re-audit (ACCEPT).
                   This is the narrow red-team they each recommend.
Posture:           separate thread from writer and auditor; read-only on the repo; nothing
                   pushed; no PR comment, review or merge; nothing run on the Linux box.
                   Real Nomad 2.1.1 (the CI pin) and 2.0.0 (the box's version), ACLs on, lock
                   provisioned by the PR's own scripts/internal/nomad_acl.py, all in one
                   cloud container.
Provenance:        REPRODUCED. Two v2 runs with HEAD at base 42db339, byte-identical and equal
                   to the writer's and auditor's a0ce1b2f… (section 6). Close == open.
Final verdict:     ACCEPT with one Low finding (RT-1, doc completeness). Goals 1–3 closed.
```

## 1. What I tried to do

The brief set four goals. I tried, on real Nomad of both supported versions, to:

1. submit or modify a Nomad job without going through ES admission;
2. escalate from ES's token or the observer's token;
3. make `check` or `provision` report a safe posture that is not safe;
4. escape the Docker limits beyond the options audit INF-02 documents as still open.

I could do none of 1–3. Goal 4 yields one Low, documentation-completeness finding
(RT-1): two host-namespace modes are open on Nomad 2.0.0 and are not in the
documented-open list. It does not widen the worst case and does not block merge.

## 2. The lock, as provisioned and tested

`scripts/internal/nomad_acl.py provision` built, on each agent:

- namespace `es-submit-v1`;
- policy `es-submit-v1` = `namespace "es-submit-v1" { submit-job, read-job, read-logs }`;
- policy `es-observer-v1` = `agent{read} node{read} namespace "es-submit-v1" { read-job, read-logs }`;
- one client token per policy; the management token is root-only.

I read the live policies back with the management token; they are exactly the above
(`probes/acl-escalation.txt` header, confirmed against the provisioner).

## 3. Goal 1 — submit without ES admission  → CLOSED

With no token, and with a random token, a well-formed job register
(`POST /v1/jobs`, namespace `es-submit-v1`) is refused **403** on both Nomad 2.1.1
and 2.0.0 (`probes/acl-escalation.txt`, bottom block). ACLs are enforced and there
is no anonymous policy, so there is no unauthenticated path to the job API.

## 4. Goal 2 — escalate from the ES or observer token  → CLOSED

Every probe below used a **well-formed request body**, so a rejection is a real ACL
verdict (403), not a 400 from a malformed body. Same result on 2.1.1 and 2.0.0 for
the ES token (`probes/acl-escalation.txt`):

| attempt (ES token)                              | result |
|-------------------------------------------------|--------|
| `GET /v1/acl/tokens`                            | 403 |
| `POST /v1/acl/token` (mint management token)    | 403 |
| `POST /v1/acl/policy/*` (write a policy)         | 403 |
| `GET /v1/agent/self`, `/v1/agent/members`       | 403 |
| `GET /v1/nodes`, `GET /v1/operator/raft/configuration` | 403 |
| `POST /v1/namespace/*` (create a namespace)     | 403 |
| `PUT /v1/var/...` in `es-submit-v1`             | 403 |
| `POST /v1/jobs` / `job/plan` in `default` ns    | 403 |
| `GET /v1/acl/token/self`                        | 200 (own token only) |
| `POST /v1/job/.../plan` in `es-submit-v1`       | 200 (by design) |

The ES token can act **only** inside `es-submit-v1`, and only to submit/read/log
jobs. It cannot mint a token, write a policy, create a namespace, write a variable,
read cluster topology, or touch any other namespace.

The **observer** token: every write and every plan is 403 (including a plan in
`es-submit-v1`). Its 200s are reads of the agent, members and node list — granted
by the audited `es-observer-v1` policy's `agent{read} node{read}`, i.e. read-only
topology, not an escalation. It cannot submit or modify anything.

## 5. Goal 3 — make `check`/`provision` report an unsafe posture as safe  → CLOSED

The **full** check (`check --management-token-file …`, which `provision` also runs)
refuses, with a specific reason and rc=1, each way I tried to seat a second writer
(`probes/acl-posture-check.txt`):

- a competing **policy** on a glob namespace (`es-*`) → refused (names the policy);
- a competing **role** that bundles `es-submit-v1` → refused (names the role);
- an **auth method** whose binding rules could issue a submitting token → refused.

It restores to `ok` once each is removed. I could not get a false `ok` from the full
check.

Observation **O-RT1** (not a finding): the **plain** check (no management token),
which readiness/bring-up run as the observer, returns `ok` (rc=0) even when a
competing `es-*` writer policy exists; only the full check proves exclusivity
(`probes/plain-check-vs-competing-writer.txt`). This is **not an exploitable bypass**:
creating that policy — and a token bearing it — requires the management/root token,
which the lock already documents as outside its model; and the plain `ok` line
deliberately omits the exclusivity clause the full check adds ("it is the only token
with that policy, and no other grant holds capabilities there"). The only risk is an
operator misreading the narrower `ok`. Optional hardening (coordinator's call): have
the plain check name that exclusivity was not verified without the management token.

## 6. Goal 4 — escape the Docker limits beyond INF-02's documented-open set

Plugin block as the PR ships it: `allow_privileged=false`;
`allow_caps=[chown,dac_override,fowner,kill,setgid,setuid,setpcap]` (7);
`volumes.enabled=true`. Submitted through the ES token into `es-submit-v1`.
Full matrix in `probes/docker-escape-matrix.txt`.

Refused on **both** 2.1.1 and 2.0.0:

- `privileged = true` → "Docker privileged mode is disabled on this Nomad agent";
- `cap_add = ["sys_admin"]` → "driver does not allow the following capabilities: sys_admin".
- A baseline container's `CapEff` is `00000000000001eb` — exactly the seven allowed
  capabilities, nothing more.

Runs, and **is already documented** as open (INF-02, `configuration.md` lines 709–713):

- bind mount of a host path (`/`) with the task user `0:0` (read `/etc/shadow` line
  observed);
- `network_mode = "host"`;
- `security_opt` (`seccomp=unconfined`) — container `Seccomp: 0` observed.

### Finding RT-1 (Low — documentation completeness)

On **Nomad 2.0.0** (the box's version), in addition to the documented
`pid_mode = "host"`, two more host-namespace modes are accepted despite
`allow_privileged=false`:

- `ipc_mode = "host"` — the container joins the host IPC namespace. Verified: the
  container's `/proc/self/ns/ipc` is `ipc:[4026531839]`, the host's IPC namespace.
- `userns_mode = "host"` — accepted; the task runs (alloc complete).

On **Nomad 2.1.1** all three host-namespace modes are refused at container-config
creation ("cannot apply \"ipc_mode\"/\"pid_mode\"/\"userns_mode\" configuration").

The documented-open list names only `pid_mode = "host"` for 2.0.0, in two places:

- `.docs/system_overview/configuration.md:714`;
- the comment above `TestRealNomadOffersOnlyTheLimitedDockerDriver`
  (`es/app/nomad_supported_config_test.go:202-204`).

So the docs under-state what is open on 2.0.0 by two options. This is the same class
as the auditor's A4-3 (INF-02 docs incomplete) and is **Low**:

- it needs ES's own submit token, i.e. a job ES's admission already chose to run —
  the same precondition as every other option on the open list;
- it does not widen the worst case: a bind mount of `/` as root (already documented)
  is already total host compromise, and host IPC/user-ns are weaker than that;
- on the CI pin (2.1.1) all three are refused.

**Fix** (`rt1-doc-completeness.patch`, applies cleanly at 6d1346f): extend
`configuration.md:714` and the test comment to list `ipc_mode="host"` and
`userns_mode="host"` alongside `pid_mode="host"` as 2.0.0-only, and add two rows to
the test's `refusals` table pinning that Nomad 2.1.1 refuses `ipc_mode`/`userns_mode`
host (both strings observed live; the table runs on the 2.1.1 CI agent, so the rows
pass in CI and keep the "2.0.0 only" claim honest).

## 7. Observations (no change required beyond RT-1)

- **O-RT1** — plain vs full `check` exclusivity, section 5.
- **O-RT2** — the observer policy grants cluster-wide `agent:read` and `node:read`
  (topology beyond the namespace), by the audited design; read-only, no write path.
- **O-RT3** — the lock governs Nomad's API, not Docker or root; root and the `docker`
  group start containers directly and are outside it. Already documented.

## 8. Provenance (reproduced)

```
manifest clone        HEAD at base 42db33920d9a402e28f4f7c2344c66d8f1115215, working tree =
                      6d1346f (git checkout 6d1346f; reset --mixed to 42db339), upstream
                      origin/trunk_dev, branch claude/project-thread-9slgp8
python3 v2 (recipe tool c08597e2… verified): manifest_sha256 a0ce1b2f…a654,
                      textual_diff_sha256 e7d5c261…6008, 52 files; close == open, byte-identical,
                      and byte-equal to the writer's 05-evidence/manifest-v2-6d1346f.json and
                      the auditor's 06 figure.
tree at 6d1346f       865e74d1545461acebe5f6b1c494b85187a5882d (matches audit 06)
```

Copies: `provenance/manifest-v2-open.json`, `manifest-v2-close.json`. The files I
tested appear in the manifest with their sha256:
`scripts/internal/nomad_acl.py` a4fcaa88…, `es/app/nomad_supported_config_test.go`
6c0d1cf…, `.docs/system_overview/configuration.md` 5741fdc1…,
`.examples/config/nomad.hcl` ec28a9bb…, `es/admission/nomad_access.go` a4cb83d7…,
`es/admission/submit.go` 68707e2a….

## 9. Confidence

- Provenance: high (reproduced byte-for-byte, open == close, equal to the writer's and
  auditor's).
- Goals 1–3 closed: high — tested against two real Nomad versions with well-formed
  bodies, and the full `check` refuses every competing-writer shape I built.
- Goal 4 / RT-1: high — the open/refused behaviour was observed directly on both
  binaries, and the namespace join was confirmed by the matching ns inode.
- That I found every break: medium-high. Four adversarial passes (02, 04, 06, this)
  converge; the lock confines each goal to a small, tested surface.

## 10. Merge

- **Not blocked by the red-team.** Only RT-1 (Low, docs) stands; its fix is the
  attached patch. The product and test code behave as the audit found.
- At the merge gate, bring in the current `trunk_dev` (`725c97a` at this close; its
  trial merge is clean per audit 06 §5) and re-run the provenance check on the new
  head. If PR #39 (root-test move) lands first, move the new test files with it.
- RT28-style live checks on the actual box (Nomad 2.0.0 there) still wait on David's
  go; this thread did nothing on the box.

## 11. Compliance / scope

Red-team only: no repair commit, push, PR comment, review, merge or box action by this
thread. The only changes outside the repo are this report and `07-redteam-evidence/`.
Real Nomad and all probes ran in this container; the Nomad agents and all tokens were
ephemeral and local, and the one live token value an endpoint echoed back has been
redacted from the evidence. The competing policy/role/auth-method used in section 5
were created and deleted in the test agent; the live state is the two designed policies
only. No token, key, box data or personal data is in the evidence (scanned).

## 12. Evidence

| file | what |
|------|------|
| `probes/acl-escalation.txt` | goals 1 & 2, well-formed bodies, ES + observer, both versions |
| `probes/acl-posture-check.txt` | goal 3, full check refuses competing policy/role/auth-method |
| `probes/plain-check-vs-competing-writer.txt` | O-RT1, plain vs full check |
| `probes/docker-escape-matrix.txt` | goal 4, full escape matrix on 2.1.1 and 2.0.0 |
| `rt1-doc-completeness.patch` | the RT-1 fix (docs + test comment + two refusal rows) |
| `provenance/manifest-v2-open.json`, `manifest-v2-close.json` | the two reproduced manifests |
| `SHA256SUMS.txt` | sha256 of every evidence file |

## 13. Re-check recipe

- Provenance: in a clean clone, `git checkout 6d1346f`, `git reset --mixed 42db339`
  with upstream `origin/trunk_dev` and branch `claude/project-thread-9slgp8`, run the
  v2 tool (hash c08597e2…) → `a0ce1b2f…a654`, 52 paths.
- Nomad: real 2.1.1 and 2.0.0, ACLs on; `nomad_acl.py provision`; the probe scripts
  are the three under `probes/` (regenerate with the ES/observer/management token files
  the provisioner writes). Container only; nothing on the box.
