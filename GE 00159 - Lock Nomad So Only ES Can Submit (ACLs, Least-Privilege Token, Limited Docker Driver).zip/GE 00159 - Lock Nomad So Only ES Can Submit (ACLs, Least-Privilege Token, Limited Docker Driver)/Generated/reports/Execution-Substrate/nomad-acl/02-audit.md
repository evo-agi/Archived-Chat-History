# Independent audit of ES draft PR #31 (Nomad lock, part 1) at 78fd064

Verdict: **BLOCK** (one Medium patch defect, A2-8, introduced by the repair;
everything the first pass found is fixed).

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`02-audit-evidence/`. Evidence for the repair is under `repair-78fd064/`;
the first pass on 6270d7d is in the other folders and in
`02-audit-draft.md`, which this report supersedes.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #31, branch
  `claude/project-thread-9slgp8`.
- Base: `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (origin/trunk_dev after
  PR #26).
- Topic: `78fd0647643dc80b8c520a42fb8a5e22e8dd9d62`, tree
  `734ac772bd7c8cf175e1066499db0add4e12aaaa` (PR head confirmed by the
  GitHub API at about 20:00Z).
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified before use).
- textual_diff_sha256
  `887660f30e2ed9e8892515c353d09b9caedde49dd35fe0ae645afd11da50dab0`;
  manifest_sha256
  `8b7b1605e20c3112dca5242966b6c401b4aa7724ede04b6ec01d14c166a7e86c`;
  46 changed paths.
- Audited together, as the coordinator asked (18:37Z): the first commit
  range up to `6270d7d` (first pass), and the repair `70dd636`, `8c4b1bf`,
  merge `a68e44d` (trunk_dev 8ba1edb), `78fd064`.
- Writer's reports: `01-implementation.md`; `02-repair.md` sha256
  `57ae7ffcc7f9468cff9d0b99f422ef5a52a991cedc1959c24c4df4c8cb9a4a58`.

## Audit posture

Read-only towards the repository and the PR: nothing committed, pushed or
commented. No subagents. The box and all live services were untouched. All
execution was in this container: local clones, disposable Nomad 2.1.1 (CI
pin) and 2.0.0 (box version) dev agents on loopback ports 24646 and 25646,
and the local Docker daemon. Mutants were applied one at a time in a
scratch clone and restored after each run. One trial merge with PR #12 was
made locally and never pushed. A request to give the container's test user
passwordless sudo (to mirror the CI runner) was refused by the session's
permission policy, so I ran the root-only tests as root directly instead.

## Provenance reproduction (Ran)

- Fresh clone, `umask 022`: the pushed tip equals the reported tip, base is
  an ancestor, clean checkout, `reset --mixed` to base, upstream pinned to
  origin/trunk_dev, recipe run twice. The two runs are byte-identical, and
  byte-identical to the writer's `02-repair-evidence/manifest-v2-78fd064.json`
  (`repair-78fd064/provenance/`). The committed path set is 46.
- Merge `a68e44d`: its tree equals a fresh automatic merge of 8c4b1bf
  with 8ba1edb (`d196a8f9582d123a62f7e89a3b4e3d2cb7e10412`).
  trunk_dev's own move (036d507 to 8ba1edb) touched only 4 test files
  (producercontract and the workstream A, B, C guardrails), none in this
  PR's scope.
- Closing run, after all tests, probes and mutants (which ran in other
  copies): two runs, byte-identical to each other and to the opening run
  (`repair-78fd064/provenance/manifest-close.json`).
- The branch moved after this target was fixed (Read, at about 20:25Z):
  `c27e33a` (part 2a: Docker-only driver, Docker plugin limits, root-owned
  Nomad config) and `7aaac66` (merge of trunk_dev `76c030f`, PR #27). Those
  are outside this audit and need their own delta audit. The files behind
  A2-8, A2-9 and the G1 and U1 parts of A2-10 (nomad_acl.py,
  nomad_acl_setup.sh, submit.go, nomad_access_test.go) are byte-identical
  at `7aaac66`, so those findings still apply there (Ran: `git diff
  --quiet`). nomad_acl.sh and 72 did change in part 2a, so the S5 and S6
  parts of A2-10 need a fresh look there.

## Coverage

- Read: every change from 6270d7d to 78fd064 (19 files, +1232/-70, plus
  the one-file `a68e44d..78fd064` delta); for the first pass, the whole
  42-file change at 6270d7d (`02-audit-draft.md`). That covers Go product
  code (es/admission, es/config), the provisioning tool and its shell
  helpers, setup, bring-up, proof and Remote Alpha scripts, the
  configuration docs, the CI gate list and all new tests.
- Ran: build, vet, darwin vet, es/admission and es/config with and without
  `-race`, the full es/app package, the root package against base, the
  root-only tests as root, real-Nomad probes on both Nomad versions, Go and
  script mutants, and a trial merge with PR #12.
- Not inspected: Nomad's RPC port (O2-5); the full-profile bring-up
  locally (needs an offline image recipe this container lacks); PR #12's
  own code beyond the three Nomad request sites the guard names.

## Findings

### Patch defects

```text
AUDIT FINDING
ID / Type / Severity: A2-8 / security risk (fail-open exclusivity check), regression introduced by the repair / medium
Current contract or strategic target: "ES must be the only client writer in es-submit-v1"
  (.docs/system_overview/configuration.md:648; nomad_acl.py docstring; PR body); the
  coordinator's brief: any way to submit or ALTER jobs without the ES token.
Path and line: scripts/internal/nomad_acl.py:443-480 (grants_that_can_submit),
  :536-550 (require_exclusive_writer), used by provision and by check --management-token-file.
Evidence:
  Ran (Nomad 2.1.1 and 2.0.0, repair-78fd064/probes/competing2-*.txt, execgrant-2.1.1.txt):
  - The new probe asks only whether a grant can PLAN in es-submit-v1, i.e. holds submit-job.
    Grants of other job-changing capabilities pass both provision and check (rc 0):
    namespace "es-submit-v1" { capabilities = ["scale-job"] } (HCL and JSON),
    ["read-job","alloc-lifecycle"], ["dispatch-job"], and namespace "*" { capabilities = ["read-job","alloc-exec"] }.
  - What those tokens did to a job ES registered with its own token (es-victim, running):
    the scale-job token scaled it from Count 1 to 2 (HTTP 200; the job is now version 1, and
    Nomad schedules a second allocation of ES's workload without ES admission); the alloc-lifecycle token restarted and
    then stopped ES's allocation (HTTP 200 each); the alloc-exec token opened an exec session
    inside ES's workload container (HTTP 101; the container runtime attempted the command,
    /bin/id, which that image lacks).
  - The 6270d7d tool's text match refused the three I ran it against (scale-job in HCL,
    alloc-exec through "*", alloc-lifecycle in JSON; nsread-*.txt, "refused (text match)").
    By its code (nomad_acl.py:430-443 at 6270d7d) it refused any rules naming es-submit-v1
    or a namespace glob, so the dispatch-job policy too (Read). So the
    repair closed the escaped and JSON submit-job bypasses (A2-2) but narrowed what counts
    as a competing writer.
  - A Nomad-evaluated fix exists. With the same short-lived probe token,
    GET /v1/namespace/es-submit-v1 answered 200 for each of the grants above and for ES's
    and the observer's policies, and 403 for a policy limited to "default", for node read
    only, and for namespace "*" write with an explicit deny on es-submit-v1 (nsread-*.txt,
    both versions).
Impact: a second principal that can change, rerun, stop or exec into ES's jobs in
  es-submit-v1 exists while provision and check report "no other grant can submit there".
  Creating such a policy needs the management token, so this is not a tokenless path; it is
  the operator's proof of exclusivity giving a false pass, and the box run relies on it.
Required correction: for every policy other than the tool's two, and every role, refuse any
  grant that Nomad says holds any capability in es-submit-v1 (for example: the namespace read
  above answers 200 with the probe token), keeping the plan probe or replacing it. Treat the
  observer policy as allowed only when its rules equal the tool's OBSERVER_POLICY_RULES (see
  A2-9). Tests on real Nomad: scale-job only, alloc-lifecycle in JSON, alloc-exec through a
  "*" glob, and dispatch-job must be refused by provision and check; a policy limited to
  "default", and a "*" write shadowed by a deny on es-submit-v1, must pass. Update
  configuration.md:648-656 to say what is refused.
Uncertainty: Inference that namespace read is Nomad's "any capability in this namespace"
  test (AllowNamespace); observed for the 8 cases above on both versions, not proven for
  every capability. If the writer prefers another Nomad-evaluated probe, that is fine as
  long as the four refusal cases above are tested.
Patch defect or pre-existing issue: patch defect (introduced in 70dd636/78fd064).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-9 / incomplete drift check / low
Current contract or strategic target: `nomad_acl_setup.sh check` verifies the lock;
  configuration.md:644-658.
Path and line: scripts/internal/nomad_acl.py:619-668 (command_check).
Evidence (Ran, both versions, competing2-*.txt section C, policydrift.txt):
  - A second client token holding es-submit-v1 (name not-es) registered a job (HTTP 200)
    and check --management-token-file still passed (rc 0). Provision deletes it (keep rule),
    but check does not notice it.
  - Widening the observer policy with scale-job, alloc-exec and alloc-lifecycle in
    es-submit-v1, or widening es-submit-v1 with alloc-exec, alloc-node-exec and host_volume
    write: check passed (rc 0) each time. Provision restored both policies' rules.
Impact: check is the read-mostly verification an operator runs after provisioning; it can
  report the lock intact while ES's policy is wider than designed (more INF-02 surface) or
  while the read-only observer token can alter ES's jobs.
Required correction: in check with the management token, require that the es-submit-v1 and
  es-observer-v1 policies' rules equal the tool's constants, and that exactly one live token
  holds each (the ones in the token files). Tests for each deviation.
Uncertainty: none on behaviour; severity is Low because changing policies or tokens needs
  the management token.
Patch defect or pre-existing issue: patch defect (the check command is new in this PR).
```

```text
AUDIT FINDING
ID / Type / Severity: A2-10 / test gaps in repair fixes / low
Current contract or strategic target: PR body "ES client never follows a redirect or uses
  a proxy (mutation-checked)"; 02-repair.md table rows A2-4 and A2-5.
Path and line: es/admission/submit.go:263 and nomad_access_test.go:294-333;
  scripts/nomad_acl_setup.sh:82-86; scripts/internal/nomad_acl.sh:48;
  scripts/72_supported_local_setup.sh preflight_supported_local_setup_nomad_acl.
Evidence (Ran, repair-78fd064/mutants/): these mutants SURVIVE their focused tests:
  - G1: the real client built on the default transport (WrapRoundTripper(..., nil), proxy
    from the environment). The test asserts newNomadTransport().Proxy == nil, not that
    newNomadClient uses that transport. (G2, no CheckRedirect, and G3, Proxy kept in the
    helper, are killed.)
  - U1: `nomad_acl_setup.sh check` without --management-token-file, which silently drops
    the exclusive-writer probes from the operator's check.
  - S5: nomad_api_get without --noproxy (the fix is tested by review only, as 02-repair.md
    says; my probe shows the current code is right).
  - S6: 72's ACL-directory check without the SPIRE socket directory (only the message
    text in an existing test changed).
Impact: a later edit can undo these fixes without a failing test. For a loopback base_url,
  Go's proxy selection skips loopback anyway (Inference from net/http
  ProxyFromEnvironment), so G1 matters for any other host.
Required correction: assert on the client's actual transport (unwrap the logging round
  tripper, or send a request with HTTP_PROXY set to a listener and require it gets
  nothing); a test that the setup wrapper's check passes the management token file (or
  runs the exclusive-writer probes); a proxy-listener test for nomad_api_get; a 72 case with
  the ACL directory inside the proof's SPIRE socket directory.
Patch defect or pre-existing issue: patch defect (fixes and tests added by the repair).
```

### First-pass findings: status at 78fd064

- **A2-1 (High, CI and report): fixed.**
  - Read (GitHub API): CI run 45248467696, job 137951512389 ("build, vet and
    test") on head 78fd064 concluded **success** at 19:52:30Z
    (`repair-78fd064/ci/`). `.github/ci/environment-only-tests.txt` is
    unchanged from base, so no test was listed to get green. The gate fails
    on any self-skip that is not listed (go_test_gate.py:60), and the only
    `skips-itself` entries are the 4 pre-existing ones. So the two owner
    tests and the real supported-local setup test ran in CI rather than
    skipped (Inference from the gate rule plus success).
  - Ran: full `go test ./es/app/` as the non-root test user: 602 pass,
    2 fail, 8 skip (`repair-78fd064/tests/head-78fd064-es-app-full-summary.txt`).
    The 5 proof tests that failed on 6270d7d pass, with a real, custody-checked
    observer token file in their env.sh (`writeProofEvidenceEnv`), not a
    bypass. The 2 failures are the CI-listed
    `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`
    and the full-profile bring-up, which needs an image build this container
    cannot do (same on 6270d7d). The skips are the 7 pre-existing
    `TestServiceLaunchersContainerUser` subtests and the setup test, which
    skips only without root or passwordless sudo.
  - Ran as root: both owner tests pass (they kill M15/M16 below). The setup
    test now starts its own ACL-enabled, unbootstrapped Nomad on a free port
    (`SUPPORTED_LOCAL_NOMAD_PORT`). Run as root here, setup bootstrapped and
    provisioned it and its lock check printed "ok ... no other grant can
    submit there". The test then failed later, at the SPIRE server or Vault
    dev listener, and base 8ba1edb fails the same way here as root, so that
    is this container (`head-root-setup-*.log`, `base-8ba1edb-root-setup.log`).
  - The skip-or-rerun pattern for the owner tests
    (`continueNomadTokenTestAsRoot`, nomad_access_test.go:224) re-runs the
    test as root through `sudo -n` and requires `--- PASS: <name>` in the
    child's output, so a skip in the child cannot pass (Read).
  - Report: 02-repair.md section 2 corrects the earlier §6 claim (Read).
- **A2-2 (Medium, text-matched competing policies): fixed for submit-job.**
  Ran on both Nomad versions: JSON glob, JSON escaped name, HCL escaped name,
  HCL escaped star, HCL glob, JSON partial glob and a role holding a granting
  policy or ES's own policy are each refused by provision and check. A
  second management token is refused. A policy bound to a job's workload
  identity (JobACL) is refused too. No probe token is left behind
  (`competing2-*.txt`). The narrowing to submit-job is A2-8.
- **A2-3 (Low, ES client redirects and proxy): fixed.** Ran: my earlier
  probe test now records 0 requests reaching the redirect target; mutants G2
  and G3 are killed. Test gap in A2-10.
- **A2-4 (Low, script proxies): fixed.** Ran: with `http_proxy`,
  `HTTP_PROXY` and `ALL_PROXY` pointing at a listener, `nomad_api_get` and
  `nomad_acl_state_check` send nothing to it (`proxy-probe-78fd064.txt`).
  Read: every token-carrying curl in 70_linux_setup.sh, bringup.sh and
  nomad_acl.sh has `--noproxy '*'`, and every embedded Python uses
  `ProxyHandler({})` with a no-redirect handler (70, bringup.sh, the Remote
  Alpha security check). The `nomad` CLI uses Go's transport, which does not
  proxy loopback (Inference).
- **A2-5 (Low, token next to the SPIRE socket): fixed.** Ran: the same
  placement probe is now refused ("must be outside the directory of
  execution.spire_workload_api_socket_path"); mutant G4 is killed. Read: 72's
  directory check also excludes the proof's SPIRE socket directory.
- **A2-6 (Low, check refusals untested): fixed** for the cases the tool
  checks. `TestNomadACLToolCheckRefusesEachDeviation` has one case per
  refusal plus redirect and proxy subtests, and kills all 8 script mutants
  that survived on 6270d7d (Ran; Validation assessment below). New gaps
  from the repair are A2-10.
- **A2-7 (Low, PR #12 seam without a trigger): fixed.** Ran: a local trial
  merge of 78fd064 with PR #12's current head
  `44166998d4ef0d7b86152f3f66265b906f7d612a` (one PLANS.md conflict, both
  sides kept) builds and vets. `TestEveryNomadRequestPathGoesThroughTheTokenBuilder`
  fails there, naming the three tokenless request paths
  (reliable_submit_operational_handoff.go:666 and
  reliable_submit_operational_provider.go:622 and :657)
  (`repair-78fd064/trial-merge/`). Whichever of #31 and #12 lands second
  cannot pass CI until the provider sends ES's token. The guard is a static
  aid with known limits (O2-7); Nomad refuses tokenless requests anyway.

### Observations (no change asked in this PR)

- O2-1 to O2-5 from the first pass stand (submit-job powers are INF-02; the
  observer token reads job specs including the invocation environment; 72
  with `ES_USER=root` on a box that uses `ES_USER=es`; the root-run
  "locked Nomad" subtest; Nomad RPC not probed).
- O2-6 (Inference): grants outside namespaces can still affect ES's jobs,
  for example `node { policy = "write" }` can drain the node and stop ES's
  allocations. Neither the old nor the new check looks at node, operator or
  agent write. That is operator power rather than a second job writer;
  worth a line in the docs.
- O2-7 (Ran): the static guard misses a path assembled without a string
  literal that names it, for example `"/" + path.Join("v1", "jobs")`
  (mutant G6 survives). Such a request would carry no token and Nomad would
  refuse it, so this fails closed.
- O2-8 (Read): `check --management-token-file` now writes to Nomad (it
  creates and deletes 5-minute probe tokens). That is fine, but "check" is
  no longer read-only, which an operator may assume.

## Validation assessment

Re-run on 78fd064 (Ran; logs under `repair-78fd064/tests/`):

| Command | User | Result |
|---|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet ./...` | ci | pass |
| `go test ./es/admission/ ./es/config/` and the same with `-race` | ci | pass (admission 46 s, race 108 s) |
| `go test ./es/app/` (full) | ci | 602 pass, 2 known environment failures, 8 skips (above) |
| owner tests and the setup test | root | owner tests pass; setup's Nomad lock part passes, the rest fails here as on base |
| `go test .` (root package), head vs base 8ba1edb | ci | the same 27 container-only failures on both; the new `TestRemoteAlphaRuntimeImageNomadMetaUsesTheObserverToken` passes |
| real-Nomad grant, drift, exec, redirect, proxy and placement probes | root | as cited in the findings, Nomad 2.1.1 and 2.0.0 |
| trial merge with PR #12 4416699, token guard | root | guard fails on the 3 provider paths (intended) |

Mutants on 78fd064 (Ran; `repair-78fd064/mutants/`):

- Go (focused es/admission and es/config tests): 19 of 23 killed.
  M15/M16 (owner checks) are killed as root, and run as root in CI through
  `sudo -n`. Survivors: M6 (a non-200 token/self that still echoes ES's
  secret; close to equivalent), M19 (redundant: the open uses O_NOFOLLOW
  anyway), G1 (A2-10) and G6 (O2-7).
- Scripts (focused es/app tests): 23 of 27 killed. Every check refusal
  that survived on 6270d7d (P3, P4, P5, P6, P7, P12, P13, P15) is now
  killed, as are the new ones: no grant found (P2'), roles not probed
  (P16), auth methods, other management tokens and expiry (P17 to P19),
  the ES-token plan probe (P20), proxy honoured (P21), and check skipping
  the exclusivity probe (P22). Survivors: U1, S5 and S6 (A2-10), and S1,
  which is equivalent (with ACLs off the anonymous-policy lookup gives 400,
  which the same function refuses).

Not re-run: the full-profile bring-up (no offline image recipe here; it is
not among the CI failures); the gate script itself (CI ran it).

## Sensitive-material handling

No secret was printed, logged or written to the evidence. Probe scripts
print only HTTP statuses, return codes and refusal texts; token files were
read by the scripts, never echoed. Logs contain Nomad accessor IDs of
disposable local agents (accessors cannot authenticate) and synthetic test
tokens only. The evidence folder was scanned for UUID-shaped strings and
the word "SecretID" before writing SHA256SUMS. No personal data left the
container.

## Remaining uncertainty and stop conditions

- A2-8's suggested probe relies on Nomad's namespace read meaning "any
  capability here"; observed, not proven for every capability.
- The real setup test and the owner tests' `sudo` path were not run end to
  end here; CI's success is the evidence for them.
- Part 2 (HTTPS, driver allowlist, root-owned config) is not committed yet
  and needs its own delta audit.

## Confidence

- Provenance: high (two identical runs, equal to the writer's, closing run
  equal).
- Validation: high for Go and the tool on both Nomad versions; medium for
  the setup and bring-up scripts end to end (container limits, CI evidence).
- Implementation: high that the lock holds against tokenless callers and
  that A2-1 to A2-7 are fixed; A2-8 and A2-9 are concrete and reproduced.

## Effect status

No repair, commit, push, PR comment, review or merge was performed. Nothing
outside this container was changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/02-audit.md`;
sha256 in the delivery message. Evidence checksums in
`02-audit-evidence/SHA256SUMS.txt`.

## Final verdict

**BLOCK**

Fix A2-8 (Medium) before merge, with the tests named there. A2-9 and A2-10
(Low) are small and fit the same repair. Per §14, a fresh audit then takes
the repaired head.
