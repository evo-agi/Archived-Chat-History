# Lock Nomad so only ES can submit: implementation report, part 1 (ACL lock)

Thread: Lock Nomad so only ES can submit. Source: gap 4 of
`reports/Execution-Substrate/python-poc-reconciliation.md`. Prerequisite P1 of
the workload-identity design.

> [Edit 2026-11-23, repair: section 6 wrongly said the touched tests passed.
> CI on 6270d7d failed. The causes, the fixes, the five early audit findings
> and the token guard are in [02-repair.md](02-repair.md). Section 8 gains
> item 7 (the token guard).]

## 1. Outcome in plain words

Before this change any program on the host that could reach Nomad's API
(127.0.0.1:4646) could start a container job and skip ES's admission checks
entirely, because Nomad accepted jobs without any credential.

After this change:

- Nomad runs with access control (ACLs) on in every supported path: the Linux
  host setup, the full-profile bring-up, the supported-local proof setup, the
  example config and CI's real Nomad.
- ES holds its own narrow Nomad token, read from a protected file at startup.
  It can submit, read and read logs in one namespace (`es-submit-v1`) and
  nothing else. Requests without a token, or with any other token, are refused
  by Nomad.
- Before every submit ES checks that Nomad really enforces this (ACLs on, no
  policy for anonymous requests, its own token is a client token). If not, ES
  refuses the submit and creates nothing.
- Nomad's all-powerful bootstrap ("management") token stays in a root-only
  file and never reaches ES or the operator checks. Checks use a separate
  read-only "observer" token.
- One script provisions everything: `sudo scripts/nomad_acl_setup.sh`
  (`provision`, `check`, `rotate`).

What it does not do yet (part 2, same PR): Nomad HTTPS with a server key ES
pins, a docker-only driver allowlist, explicit Docker plugin limits, and
root-owned Nomad config files (audit item D2). See section 9.

## 2. Target identity

Filled in at the end of this report (section 11) after the single closeout
commit and manifest.

## 3. What changed

### ES (product code)

- `es/config/config.go`: new `nomad.token_file` (required when submit is
  enabled; clean absolute path).
- `es/admission/nomad_access.go` (new):
  - `loadNomadToken`: custody like the retained-result key. Parent directory
    owned by ES's user or root and not group/world-writable; file opened
    without following links, regular, one link, owned by ES's effective user,
    mode 0400 or 0600; content one canonical lower-case Nomad token with an
    optional newline. Errors never name the path or the token.
  - the Nomad HTTP client sends `X-Nomad-Token` on every request and scopes
    every job, allocation and log request to namespace `es-submit-v1`;
  - `verifyAccessControl`: GET `/v1/acl/token/self` with ES's token must
    return ES's own SecretID (constant-time compare), `Type=client` and an
    AccessorID; GET `/v1/acl/policy/anonymous` without a token must be 404.
    Any other answer or transport failure refuses with
    `503 execution_runtime_unavailable` and the fixed message "execution
    runtime access control check failed".
- `es/admission/service.go`: the token is loaded at startup right after the
  retained-result key and before any execution root is provisioned, so a
  missing or unsafe token refuses startup with no side effects.
- `es/admission/submit.go`: jobs carry `Namespace: es-submit-v1`; the access
  check runs right after the execution plan is frozen and before run
  assignment or staging, so admission refusals (4xx) keep their precedence and
  a refused check leaves no run, staging or job.
- Frozen guardrail inventory updated deliberately
  (`es/admission/workstream_c_guardrails_test.go`).

### Provisioning and operator scripts

- `scripts/internal/nomad_acl.py` (new): `provision` and `check`. Talks only
  to a loopback Nomad address, with no proxy and no redirects, bounded
  responses. Provision: requires ACLs on, bootstraps with an operator-made
  secret written 0600 before the call (refuses if Nomad was already
  bootstrapped and the file is missing), refuses an anonymous policy, refuses
  if another policy could grant the namespace (names it or uses a namespace
  glob), upserts namespace and policies, keeps a working token or issues a new
  one (written 0400 atomically with the right owner), deletes stale tokens of
  the same name or policy. Check: ACLs on, no anonymous policy, ES's token is
  the `es-submit-v1` client token, and four refusal probes (anonymous plan in
  `es-submit-v1`, ES's token planning in `default`, ES's token on
  `/v1/nodes`, observer token planning) must all get 403.
- `scripts/nomad_acl_setup.sh` (new, root): wrapper with defaults
  (`/etc/execution-substrate/nomad-acl/`, `ES_USER` default root,
  `OBSERVER_USER` default the sudo caller); provision/rotate run the check
  afterwards and print next steps.
- `scripts/internal/nomad_acl.sh` (new): shared shell helpers. Tokens are read
  from their file and handed to curl through a configuration on a file
  descriptor, never on a command line; `nomad_acl_state_check` refuses
  ACLs-off and an anonymous policy; `nomad_acl_validate_dir_placement` keeps
  the token directory out of proof scopes.
- `scripts/70_linux_setup.sh`: the managed `nomad.hcl` gets `acl { enabled =
  true }`; Nomad is restarted when the config changed; new
  `bootstrap_nomad_acl` (bounded leader wait, secret generated and written
  root 0600 before the bootstrap call, reuse on rerun, refusal when the file
  was lost); qualification reads Nomad with the management token.
- `scripts/01_bringup.sh`, `scripts/internal/bringup.sh`,
  `scripts/10_health_check.sh`: the full profile now starts Nomad, provisions
  ACLs, then starts ES (ES needs its token at startup); readiness requires
  `nomad.token_file` (metadata-only check: clean absolute, regular file, mode
  0400/0600) and reads Nomad with the observer token; refuses ACLs-off and an
  anonymous policy.
- `scripts/72_supported_local_setup.sh`: refuses before any effect unless the
  host's Nomad enforces ACLs and the token directory
  (`SUPPORTED_LOCAL_NOMAD_ACL_DIR`, default
  `/etc/execution-substrate/nomad-acl`) lies outside the proof, staging and
  results directories; runs `nomad_acl_setup.sh provision` through `sudo -n`
  (ES token owned by root because ES runs as root in `service-root-v1`;
  observer token owned by the setup user); writes `nomad.token_file` into
  `es.json` and `NOMAD_TOKEN_FILE` into `env.sh`.
- `scripts/73_supported_local_proof.sh`: evidence capture reads Nomad with
  the observer token; the nomad CLI reads ES's job in `es-submit-v1` with the
  token in its environment only; passes `SUPPORTED_LOCAL_NOMAD_ACL_DIR`
  through.
- `scripts/internal/supported_local_proof_projection.py`: node details are
  fetched with the observer token from `NOMAD_TOKEN_FILE` (no-follow open,
  regular file, canonical token).
- `scripts/internal/remote_alpha_normal_shell_runtime_image_check.sh` and
  `scripts/internal/remote_alpha_runtime_security_boundary_check.sh`: read
  Nomad with the observer token.
- `.examples/config/nomad.hcl`: `acl { enabled = true }` with a comment.

### Docs

- `.docs/system_overview/configuration.md`: `nomad.token_file`; new section
  "Nomad access control" (config, management token, ES token custody,
  per-submit check, observer token, provisioning, rotation needs an ES
  restart, bring-up and proof paths, known limits).
- `.docs/execution_lifecycle/contracts.md`: submit precondition, namespace,
  and the fixed access-control message in the cause table.
- `.docs/execution_lifecycle/es_execution_admission_model.md`: the check's
  place right after the freeze.
- `.docs/system_overview/supported_linux_host_qualification.md`: ACL
  requirement and token-carrying qualification steps.
- `PLANS.md`: status entry and a current-state fact.

## 4. Tests

New:

- `TestRealNomadRefusesJobsWithoutTheESToken` (real Nomad 2.1.1 in CI): no
  token, an unissued token, and the observer token cannot register; ES's
  token cannot act outside its namespace or read nodes; ES's token can.
- `TestNomadACLToolKeepsRotatesAndRefusesUnsafeStates`,
  `TestNomadACLToolRefusesANomadWithoutACLs`: the provisioning tool keeps a
  working token, rotates, refuses a lost management token, an anonymous
  policy, a competing policy, and ACLs off.
- `TestSubmitRefusesANomadThatDoesNotEnforceACLs` (real ES + real Nomad):
  anonymous policy present, then removed (submit succeeds), and ACLs off: the
  submit is refused with the fixed message and no job exists in any
  namespace.
- `TestNomadTokenIsAStartupPrerequisiteBeforeAnyRootIsProvisioned`,
  `TestSubmitRefusesBeforeRunAssignmentWhenNomadAccessControlFails` (ES unit;
  a mutation check showed the second fails without the gate).
- `TestSupportedLocalSetupLocksNomadBeforeProofEffects`: setup refuses ACLs
  off, an anonymous policy and a token directory inside the proof before any
  effect; stops on failed provisioning; calls the root wrapper with the
  expected owners on a locked Nomad.
- `TestSupportedLocalProofNodeDetailsSendTheObserverToken`,
  `TestRemoteAlphaRuntimeImageNomadMetaUsesTheObserverToken`: the token goes
  only in the header or CLI environment, never into output; symbolic-link
  token files are refused before any request.

Updated fixtures: every es/app real-Nomad harness now runs an ACL Nomad
provisioned by the real tool; fakes answer the ACL check like a locked Nomad;
readiness fixtures carry token files.

## 5. Nomad behaviours verified on the CI pin (2.1.1)

- ACL on, anonymous: `/v1/status/leader` 200; `/v1/jobs`, `/v1/agent/self`,
  `/v1/nodes` 403; `/v1/acl/token/self` 200 with AccessorID `anonymous`.
- ACL off: `/v1/acl/token/self` 200 with AccessorID `acls-disabled`, even
  with a token header.
- `/v1/acl/policy/anonymous`: 404 absent, 200 present, readable anonymously.
- Invalid UUID token: 403; a non-UUID token: 500, so tokens are validated
  before they are sent.
- Second bootstrap: 400 "already done".
- Policy `namespace "es-submit-v1" { capabilities = ["submit-job",
  "read-job", "read-logs"] }`: register, read, allocations, logs and
  stop/purge work in that namespace; `default`, nodes, agent, namespace
  writes, policy writes and token creation are 403.

## 6. Validation (cloud container, Go 1.26.5, Nomad 2.1.1, Docker 29)

- `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`: pass.
- `go test ./es/admission/ ./es/config/`: pass, also under `-race` (section 11).
- ~~`go test ./es/app/` (full, as an unprivileged user 1500:1600 in group
  docker): every failure was one of the 2 known environment-only tests
  (`TestBringupScriptUpCheckDownFullProfile` without the offline image recipe,
  `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`
  without its witness envelope; both listed in CI's environment-only file),
  after fixing 6 fixtures that needed tokens.~~ [Edit: wrong for the committed
  tree. That full run (17:31 to 17:39Z) came before later changes to the proof
  wrapper (observer token) and the supported-local setup (ACL lock); after
  those I re-ran only selected tests. CI on 6270d7d then failed: 5
  supported-local proof tests, the real supported-local setup test, and 2
  owner tests that skipped themselves unlisted. See 02-repair.md section 2.]
  The bring-up test passed with the offline control-plane image recipe
  (32.9 s), exercising Nomad with ACLs, provisioning before ES, and ES's token
  custody.
- `go test .` (root package): 28 failures, all also failing on the base
  (29 on base; the extra one is base-copy git metadata). No new failure.
- ~~New and touched tests pass individually as listed in section 4.~~ [Edit:
  not true for every touched test on 6270d7d; see 02-repair.md section 2.]

## 7. Known limits and non-claims

- Nomad's HTTP API is plain HTTP on loopback. A local process that binds
  127.0.0.1:4646 while Nomad is down could receive ES's token. Part 2 (Nomad
  HTTPS with a server key ES pins) closes this.
- The lock governs Nomad's API, not Docker. Root and members of the docker
  group can start containers directly.
- ES's token still expresses job shape: with Docker volumes enabled and the
  current task user `0:0`, a stolen ES token can mount host paths as root
  (audit INF-02). Not solved here; recorded for a later design call.
- Token rotation needs an ES restart (token read once at startup; a container
  bind mount pins the old file).
- A lost management token after bootstrap needs Nomad's ACL bootstrap reset
  by hand; the scripts refuse rather than guess.
- `remote_alpha_runtime_security_boundary_check.sh`'s Nomad read uses fixed
  port 4646; its token use is covered by review, not by a test.
- PR 12's reliable-submit operational provider is not covered (section 8).
- No box change yet; the box still runs Nomad with ACLs off (read-only check
  16:53Z).

## 8. Change list for PR 12's reliable-submit operational provider

PR 12 (draft PR #28 head 2c8bf35) was read, not edited. Its provider
(`es/admission/reliable_submit_operational_provider.go`) talks to Nomad only
over HTTPS to a loopback address, verifies the chain and pins the leaf's
SPKI, uses namespace `es-operational-v1`, and calls `POST /v1/jobs`,
`GET /v1/job/<id>` and `GET /v1/job/<id>/evaluations`. It sends no token.

1. **Token header.** `prepareExchange` (around line 441) must set
   `X-Nomad-Token` from the same startup-loaded token custody as the current
   client (`nomad.token_file`, loaded by `loadNomadToken`), passed into
   `newOperationalLoopbackProvider`; never in the query string, never logged.
2. **Namespace and grants.** When the provider is wired, extend
   `scripts/internal/nomad_acl.py` in the same change: create namespace
   `es-operational-v1`; grant ES's policy `submit-job` and `read-job` there
   (`read-logs` too if lifecycle reads follow); extend the competing-policy
   refusal and the `check` probes to that namespace. Not done now, so ES's
   token does not hold grants for an unwired path (least privilege).
3. **Access-control gate.** The operational register path must run the same
   check as `verifyAccessControl` before `POST /v1/jobs`, over the provider's
   own pinned HTTPS transport, with the same fixed refusal.
4. **403 classification.** With ACLs on, a 401/403 on `POST /v1/jobs` means
   Nomad did not accept the job. The provider's failure mapping
   (`operationalExchangeFailure` and the register result handling) should
   classify it as a definite non-acceptance, not as write uncertainty.
5. **Exclusive writer.** The provider's doc asks for exclusive-writer
   qualification of `es-operational-v1`. The ACL tool's refusal of any other
   policy that names the namespace or uses a namespace glob, plus the
   management token never being used for job writes, gives that; `check`
   should assert it for the operational namespace too.
6. **TLS inputs.** Part 2 of this change defines Nomad's server certificate
   and ES's pin. The provider's realm (`host`, `port`, `spki`, roots) should be
   built from the same ES config fields, so one Nomad TLS identity serves both
   paths.
7. **Token guard (added in the repair).** `es/admission/nomad_request_guard_test.go`
   fails when any non-test Go file in the module names a Nomad API path
   (`/v1/job...`, `/v1/allocation...`, `/v1/client/...` and the other Nomad
   prefixes, also inside a full URL or as a leading `/v1/` fragment) anywhere
   except as the path argument of `nomadClient.newJobRequest` or
   `nomadClient.get` called on a `*nomadClient` method's receiver, and when a
   `*nomadClient` method builds an HTTP request by hand. A second test checks
   that `newJobRequest` sets `X-Nomad-Token` from the client's token and that
   `get` uses `newJobRequest`. Copied into PR 12's tree (draft PR #28 head
   2c8bf35), the guard fails on the provider's three tokenless request paths
   (`reliable_submit_operational_handoff.go:666` `POST /v1/jobs`;
   `reliable_submit_operational_provider.go:622` and `:657` `GET /v1/job/...`),
   plus the old `lifecycle.go` and `submit.go` request lines that this PR
   already replaces. So PR 12 cannot merge after this PR without adding the
   token. The fix for PR 12: build the provider's requests through a function
   that sets `X-Nomad-Token` from ES's token custody; either route them
   through `nomadClient` or extend the guard to accept that function (today
   the guard's `nomadTokenRequestBuilders` table accepts only `*nomadClient`
   methods); and add a runtime check like
   `TestEveryNomadJobRequestCarriesTheTokenAndTheSubmitNamespace` for the
   provider's three requests.

## 9. Part 2 plan (audit item D2), same PR, follow-on commits

1. Nomad HTTPS on loopback: a Nomad server certificate (generated by the
   setup scripts, key root-only), `tls { http = true ... }`, ES config for
   HTTPS with a pinned server key (aligned with PR 12's realm), all scripts and
   the ACL tool moved to HTTPS with the CA, CI real Nomad with TLS.
2. Driver allowlist: docker only.
3. Explicit `plugin "docker"` block: `allow_privileged = false`, minimal
   `allow_caps` checked against ES's real jobs, `volumes { enabled = true }`
   and image GC stated on purpose; readiness checks move from
   `client.options` to the plugin block.
4. `/etc/nomad.d` and its files `root:root` (0644, 0640 once it names TLS key
   paths).

The box gets one run after part 2.

## 10. Box run plan (needs David's "go ahead" in the thread)

The box's `/etc/nomad.d/nomad.hcl` is hand-written (no managed marker; it has
`addresses`, `network_interface` and `cni_path` the repo file lacks), so the
box run edits it in place rather than replacing it: add the ACL (and, with
part 2, TLS, driver and plugin) blocks, restart Nomad (0 jobs on the box),
bootstrap and provision with `ES_USER=es`, set `nomad.token_file` in
`/etc/execution-substrate/es.json`, restart ES, run `nomad_acl_setup.sh check`
and the readiness checks, and record everything in the runbook. A tested,
re-runnable script will be given to David if any step needs his sudo.

## 11. Target identity, manifest and race results

- Repository: evo-agi/Execution-Substrate
- Base: `036d50724b499b020c5149c55ad902cfcb1482c0` (origin/trunk_dev, unchanged at closeout)
- Topic branch: `claude/project-thread-9slgp8`
- Topic commit: `6270d7d008a35286d4aa38315f0a035fc12df6df` (three commits on the
  branch; the first was pushed as work in progress, so the closeout used the
  repair-style recipe: manifest with HEAD reset to the base, then a
  fast-forward commit and push, no force)
- Tree: `2c121088ac19d1d548a08f75dbbc94dce6aba108`
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified)
- Textual diff sha256: `48849a2816dfad2f44c5907108cd55ff9619240970b827913c2c1a5c65dfffd2`
- Canonical manifest sha256: `2bea085838dbe331681ba2b3286e5d7f42f69da4e002bb43cbee80e2e94495d0`
- File count: 42
- Two manifest runs byte-identical; upstream pinned to origin/trunk_dev before
  each run; committed path set (`git diff --name-only base HEAD`) equals the
  manifest path set (42 = 42); `git status --porcelain` empty after commit.
- Full canonical manifest: [01-evidence/manifest-v2-6270d7d.json](01-evidence/manifest-v2-6270d7d.json)
- Race: `go test -race -count=1 ./es/admission/ ./es/config/` passed
  (admission 181.8 s, config 1.0 s).
