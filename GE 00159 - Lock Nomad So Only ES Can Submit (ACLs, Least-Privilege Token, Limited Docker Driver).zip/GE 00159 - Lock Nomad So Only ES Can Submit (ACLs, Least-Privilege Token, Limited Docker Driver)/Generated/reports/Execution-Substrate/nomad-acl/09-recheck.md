# Diff-only re-check of ES draft PR #31 (Nomad lock) at 0f596c0

Verdict: **ACCEPT**.

- RT-1 is fixed. The docs and the test comment now list `pid_mode`,
  `ipc_mode` and `userns_mode = "host"` as open on Nomad 2.0.0 only. The
  real-Nomad test reads the agent's version and pins both sides: refused on
  2.1.1, run to completion on 2.0.0. It passes on both versions, and
  flipping its version switch fails it on both.
- O6-1 is closed. The new fake-Nomad case is the only test that fails when
  the observer token's SecretID comparison is removed (mutant R7, which
  survived in round 06, is now killed).
- The trunk_dev sync is sound. Both merges equal a fresh merge of their
  parents, plus a pure rename of the PR's one root test into `scripts/`,
  which PR #39 requires. `0f596c0` fixes that file's package line. No other
  PR file changed beyond the four the writer names.
- CI run 45304003382 on `0f596c0` is green ("build, vet and test",
  01:18Z to 01:49Z).
- trunk_dev has since moved to `6ce0034` (PR #42, es/app test ports), and
  the repository requires an up-to-date branch. A trial merge is clean, but
  that merge needs the same byte check before the gate.

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`09-recheck-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #31, branch
  `claude/project-thread-9slgp8`.
- Base: `523648cc9880c63d7e6592c2ae0754582d32f169` (trunk_dev after PR #43;
  the merge-base).
- Topic: `0f596c05e4e7cef473be424214ca072af0151956`, tree
  `e8ff965447a527dab9f5d2f9a954d0a9bbddddbc`. It is the PR head (Ran,
  GitHub API, 01:31Z).
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified).
- textual_diff_sha256
  `fe8b35386ae36ce56d3a3491e634ce7e3994d02af0cff171def18049b772d37c`;
  manifest_sha256
  `c1806ff58f505f5a4499e7c84e9195df73b3ae66f86f7342b4b29da301420e67`;
  52 changed paths.
- Accepted predecessor: `6d1346f` (re-audit 06 ACCEPT; red-team 07 ACCEPT
  with RT-1, Low, docs).
- Scope (coordinator, 01:20Z), the delta `6d1346f..0f596c0`:
  - `4e81758`: O6-1, one fake-Nomad case;
  - `97622e5`: RT-1, docs, test comment and version-aware test rows;
  - `7336dba`: merge of trunk_dev `4c991ba` (PR #39), with the PR's root
    test moved into `scripts/`;
  - `41df7cd`: merge of trunk_dev `523648c` (PR #43, README);
  - `0f596c0`: the moved test's package name.
- Writer's report: `08-repair.md`, sha256
  `5ea2b92a7995bacd909cf089c31590b603b539e13c77bb5a44381c881b9eb3c3`.

## Audit posture

I made no change to the repository or the PR: nothing was committed,
pushed or commented. I used no subagents. I did not touch the box or any
live service. Everything ran in this container: local clones, the PR's own
disposable test Nomad agents (2.1.1 and 2.0.0) and the local Docker daemon.
Mutants ran one at a time in a scratch clone, which was restored after each.

## Provenance reproduction (Ran)

- I fetched the branch and trunk_dev from GitHub into my audit clone, which
  was clean. The pushed tip equals the reported tip. Base `523648c` is the
  merge-base.
- With HEAD at base (`reset --mixed`), upstream `origin/trunk_dev`, the
  recipe ran twice at `umask 022`. The two runs are byte-identical and equal
  to the writer's `08-evidence/manifest-v2-0f596c0.json`
  (`provenance/manifest-open-run{1,2}.json`).
- Each merge against a fresh `git merge-tree --write-tree` of its parents
  (`provenance/facts.txt`):
  - `7336dba` (`97622e5` + `4c991ba`): the committed tree differs from the
    fresh merge only by `R100 remote_alpha_nomad_acl_test.go ->
    scripts/remote_alpha_nomad_acl_test.go`, a pure rename;
  - `41df7cd` (`7336dba` + `523648c`): equal to the fresh merge;
  - `0f596c0` (one parent, `41df7cd`): changes one line, the moved file's
    `package` line.
- No `.github` path differs between base and head.
- Closing manifest: see "Validation assessment".

## Coverage

- Read: the whole delta in the four changed files; the whole
  `TestRealNomadOffersOnlyTheLimitedDockerDriver`; the observer token check
  in `nomad_acl.py`; the moved test and the `scripts/` helpers it now uses;
  PR #39's renames and its CI-list change; every mention of the
  host-namespace modes in the head tree; `08-repair.md`, `07-redteam.md`
  and the PR body.
- Ran: provenance; per-file comparison of the PR's added and removed lines
  at `6d1346f` and `0f596c0`; build and vet; the focused es/app set on
  Nomad 2.1.1; the Docker limits test on Nomad 2.0.0; the doc-link tests;
  the moved test; the root, `scripts/`, `internal/testutil/` and
  `internal/callerauth/` packages at head and base; three mutants.
- Read through the GitHub API: CI run metadata and the PR.
- Not inspected: PR #39 and #43 themselves (trunk_dev, audited in their own
  threads); the product code, which this delta does not change.

## Findings

### Delta checks

**RT-1 (host IPC and user namespaces open on 2.0.0, undocumented): fixed.**

- Docs (Read): `configuration.md:714-716` now reads "on Nomad 2.0.0 only,
  `pid_mode = "host"`, `ipc_mode = "host"` (the container joins the host IPC
  namespace) and `userns_mode = "host"` (Nomad 2.1.1 refuses all three)".
  This matches the red-team's observations on both versions. The test
  comment and the PR body's "Known limits" say the same. No other file in
  the head tree names these modes (Ran, grep).
- Test (Read): the test reads `config.Version.Version` from
  `/v1/agent/self` and fails if it is empty. On a version starting `2.0.`
  the three host-mode jobs must reach alloc `complete` within 60 s, and any
  `failed` alloc fails the test. On any other version they are refusal rows
  that must show Nomad's `cannot apply "<mode>" configuration` task event
  and must never complete.
  - The writer changed the red-team's patch, which expected refusal on
    every version and so would fail on 2.0.0. The version switch is the
    right fix: the docs make a two-sided claim, and the test now pins both
    sides (Inference).
  - Any version other than 2.0 is held to the refusal side, so a future
    Nomad that runs these modes again fails the test until the docs change
    (Inference). CI's pin, 2.1.1, exercises only the refusal side; the 2.0
    side runs where the real-Nomad set runs on 2.0.0 (writer's and my runs).
- Ran: passes on 2.1.1 (`tests/focused-211.txt`) and on 2.0.0
  (`tests/rt1-200.txt`). Mutant M1 (flip the switch) is killed on both versions: on 2.1.1
  "host-pid failed on Nomad 2.1.1, which the configuration docs say runs
  it", on 2.0.0 "host-pid ran" (`mutants/mut9.txt`).

**O6-1 (observer token SecretID comparison untested): closed.**

- The new case answers token-self for the observer token with ES's secret,
  type `client` and only the observer policy, so every other clause of the
  observer check passes and only `SecretID != observer` can refuse it
  (Read, `nomad_acl.py:754-764`). It expects "does not hold the observer
  client token".
- Ran: passes. Mutant R7 (that clause removed) is now killed, and the new
  subtest is the only one that fails (`mutants/mut9.txt`). Without the
  clause, check still refuses later, on the accessor of the live token that
  holds the observer policy, so the clause stays defensive; the case pins
  that check names the right reason.

**trunk_dev sync and the PR #39 move: sound.**

- PR #39 moved 31 root tests into `scripts/`, renamed three more, and
  added shared helpers. None of its renames touched a PR file (Ran). It changed
  `docs_contract_test.go`, which the PR also changes, and the merge of that
  file is the automatic one (`7336dba` equals the fresh merge apart from
  the rename).
- The PR's own root test `remote_alpha_nomad_acl_test.go` needs
  `writeExecutable`, `envWithPath` and `runSourcedRuntimeImageHelper`, which
  PR #39 moved into package `scripts_test`. At `0f596c0` the file is in
  `scripts/`, package `scripts_test`, otherwise byte-identical to the root
  file at `6d1346f` (Ran). It names no repository path itself; the helper
  finds the script through `testutil.Root`, so the move changes nothing it
  runs (Read). It passes there
  (`tests/moved-test.txt`).
- For each of the 52 PR files, the added and removed lines against base are
  identical at `6d1346f` and `0f596c0`, except in the four files above
  (Ran). This matches `08-repair.md` §6.
- The broken intermediate commits `7336dba` and `41df7cd` (package
  `scripts` does not build there, as the writer reports) do not reach
  trunk_dev if the PR is squash-merged. trunk_dev has no merge commits and
  every recent commit is a single "(#NN)" commit, so squash is the practice
  (Read, `git log`). See O9-1.

### New findings

None.

### Observations (no change required)

- **O9-1, squash at the merge gate.** `7336dba` and `41df7cd` do not build
  package `scripts`. A squash merge, as trunk_dev's history shows is the
  practice, leaves no trace of them; a merge commit or rebase merge would
  put two unbuildable commits on trunk_dev.
- **O9-2, what the 2.0 rows prove.** On 2.0.0 the host-mode rows prove that
  Nomad accepts and runs the job, not that the container joined the host
  namespace (the red-team checked that for IPC by namespace inode).
  `userns_mode = "host"` changes nothing on a Docker daemon without
  user-namespace remapping, so its row mainly pins acceptance. Neither
  makes the docs wrong: they list what still runs (Inference).

## Validation assessment

All runs in this container (Go 1.26.5, `GOTOOLCHAIN=local`), as user `ci`.
Evidence: `tests/`, `mutants/`, `ci/`.

| Run | Head | Result |
| --- | --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | 0f596c0 | pass (Ran) |
| focused es/app set on Nomad 2.1.1: `TestNomadACL*`, `TestRealNomad*`, `TestSupportedNomad*`, posture, `TestLinuxSetup*`, `TestSupportedLocalFullReadiness*`, `TestSupportedLocalSetupLocks*` | 0f596c0 | 21 pass; the root-only wrapper test skips as `ci` (unchanged since round 06, where it passed as root) (Ran) |
| `TestRealNomadOffersOnlyTheLimitedDockerDriver` on Nomad 2.0.0 | 0f596c0 | pass (Ran) |
| `TestMarkdownRelativeLinksResolve`, `TestRunbookPathMentionsExist`, `TestMarkdownLinkTargetsReadsEveryLinkForm` | 0f596c0 | pass (Ran) |
| `TestRemoteAlphaRuntimeImageNomadMetaUsesTheObserverToken` in `scripts/` | 0f596c0 | pass (Ran) |
| root, `scripts/`, `internal/testutil/`, `internal/callerauth/`, head vs base `523648c` | 0f596c0 | the same 27 failures at both, all in `scripts/` and the same names as round 06's root-package set; none new. The moved test passes at head. Root package 159 pass, testutil 6 pass, callerauth 25 pass at both (Ran, `tests/packages-head-vs-base.txt`) |
| CI run 45304003382 | 0f596c0 | completed, success: job "build, vet and test", every step green, 01:18Z to 01:49Z; no `.github` change against base (Read via the GitHub API, `ci/run-45304003382.txt`) |

Mutants, one at a time in a scratch clone at `0f596c0` (Ran,
`mutants/mut9.txt`):

| Mutant | Result |
| --- | --- |
| M1 flip the version switch, Nomad 2.1.1 | killed: "host-pid failed on Nomad 2.1.1, which the configuration docs say runs it" |
| M1 flip the version switch, Nomad 2.0.0 | killed: "host-pid ran" |
| R7 check ignores the observer token's SecretID | killed: only `observer_token_answers_for_another_secret` fails (survived in round 06) |

Not re-run: the full es/app suite and the full-profile bring-up. Since
`6d1346f` (whose es/app run I accepted in round 06), the delta changes no
product code, and the trunk_dev side is tests, CI config and README
(Inference from the per-file comparison above).

Closing manifest (Ran): after the batch, the recipe ran twice more with
HEAD at `523648c`. Both runs are byte-identical to the opening runs. The
audit clone is back at `0f596c0`, and every test clone is clean
(`provenance/`).

## Sensitive-material handling

The real-Nomad tests keep their tokens in the test agents' temporary
directories. The evidence holds only test names, results, refusal texts and
manifests. Before I wrote SHA256SUMS I scanned the evidence for UUID-shaped
strings and "SecretID": no UUIDs; "SecretID" appears only as a field
name, in test code and in mutant names. No personal data left the container.

## Remaining uncertainty and stop conditions

- CI exercises only the 2.1 side of the version switch. The 2.0 side rests
  on local runs (the writer's and mine) and the red-team's.
- The full-profile bring-up does not run in this container; CI covers it.

## Confidence

- Provenance: high. Two identical runs equal to the writer's manifest;
  closing equal; each merge matches a fresh merge-tree or differs only by
  the explained rename.
- Validation: high for the delta's tests on both Nomad versions and for the
  moved test and packages against base.
- Implementation: high that RT-1 and O6-1 are fixed and the sync changed
  nothing else in the PR.

## Effect status

No repair, commit, push, PR comment, review or merge was performed. Nothing
outside this container was changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/09-recheck.md`;
sha256 in the delivery message. Evidence checksums in
`09-recheck-evidence/SHA256SUMS.txt`.

## Final verdict

**ACCEPT**

For the merge gate:

- The PR head must equal `0f596c0`, or a trunk_dev merge on top of it
  that passes the byte check below.
- CI must be green on it. Run 45304003382 is green.
- trunk_dev is now `6ce0034` (PR #42), so the branch is behind and the
  repository's up-to-date rule blocks the merge. PR #42 touches two files
  this PR also changes (`es/app/operator_scripts_integration_test.go`,
  `es/app/submit_integration_test.go`); `git merge-tree` of `0f596c0` and
  `6ce0034` is clean (Ran). The writer's merge of it gets the same byte
  check as this one (fresh merge-tree equality, per-file PR lines
  unchanged), plus green CI on the new head.
- Squash-merge (O9-1).
