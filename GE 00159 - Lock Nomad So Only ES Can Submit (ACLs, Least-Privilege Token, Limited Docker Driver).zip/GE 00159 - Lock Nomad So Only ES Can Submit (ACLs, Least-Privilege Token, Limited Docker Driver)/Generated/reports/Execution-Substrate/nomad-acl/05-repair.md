# Nomad lock: repair of re-audit round 04 (A4-1 to A4-4)

Draft PR #31, branch `claude/project-thread-9slgp8`. This repairs the four
Low findings of `04-re-audit.md` (sha256 `c2cbed34…e6ee3`) on top of the
audited head `c3a94ae`, takes trunk_dev up to `0aa4a2b` (PR #29, #36, #33),
and also covers O4-1 and O4-2. Part 2b (Nomad HTTPS) is not in this head;
it stays local and follows after this narrow re-audit.

Every statement is **Ran** (executed, output seen), **Read** or
**Inference**.

## 1. Commits

| Commit | What |
|---|---|
| `e323533` | Merge of origin/trunk_dev `400ff7f` (PR #29 ARS blob digests, PR #36 README). No conflicts (Ran: `git merge`, then a fresh `git merge-tree` of the parents gives the same tree). |
| `2b0d712` | The repair below. |
| `4e2bdad` | Fix for a test the `e323533` merge broke (section 4). |
| `b150657` | Merge of origin/trunk_dev `0aa4a2b` (PR #33, es/config tests only), which landed while this ran. No conflicts; a fresh `git merge-tree` of the parents gives the same tree `083fd0a` (Ran). |

## 2. Repairs

### A4-1: job ACL on the lock's policies (Ran, real Nomad 2.1.1 and 2.0.0)

`scripts/internal/nomad_acl.py`:

- `policy_rules` became `policy_document`, which returns the stored policy.
- `require_designed_policy` refuses a policy whose `JobACL` is not null:
  "the es-submit-v1 policy has a job ACL, which gives its capabilities to
  the workloads of the job it names; rerun provision
  (scripts/nomad_acl_setup.sh) to clear it". Rules are checked first, with
  the existing message.
- `grants_in_namespace` exempts the observer policy only when
  `is_designed_policy` holds: the tool's rules and `JobACL` null.
- `upsert_policy` writes `"JobACL": null` explicitly. Nomad already replaces
  the whole policy on a write, so this is equivalent on both versions
  (mutant A1c survives on 2.1.1 and 2.0.0, Ran); it documents the intent.

Tests:

- `TestNomadACLToolAsksNomadWhichGrantsCanSubmit` (real Nomad): for each of
  ES's and the observer's policy, a JobACL naming `es-jobacl-victim` is
  stored (asserted), `check` refuses with the message above, `provision`
  clears it (the stored policy's `JobACL` is null again), and `check`
  passes. Then the observer policy with a JobACL is not exempt: a provision
  without the observer token file refuses with "other ACL grants hold
  capabilities in es-submit-v1 (policy es-observer-v1)".
- `TestNomadACLToolCheckRefusesEachDeviation` (fake Nomad): three new cases,
  the JobACL as ES's token, the observer's token and the management token
  read it. The fake's normal answers now carry `"JobACL": null`, as Nomad's
  do.

### A4-2: roles on the lock's tokens (Ran, real Nomad 2.1.1 and 2.0.0)

- `check` refuses an ES token with roles ("the ES token file does not hold
  the ES client token with only the es-submit-v1 policy and no roles").
- `check` refuses an observer token that has roles or is not a client token,
  and compares its `SecretID` like ES's ("…the observer client token with
  only the es-observer-v1 policy and no roles").
- `ensure_client_token` keeps a token only without roles, so provision
  replaces such a token and deletes the old one in Nomad.

Tests:

- Real Nomad: a role `es-acl-test-wider` (write in `default`, so the role
  probes pass it, as the audit observed) is added to the ES token and then
  to the observer token by updating each token in place. Each time `check`
  refuses with the message above; `provision` writes a new token, deletes
  the old accessor, and the token file changes; `check` passes again.
- Fake Nomad: ES token with a role; observer token with a role; observer
  token file holding a management token.

### A4-3: what the Docker limits leave open (Read)

`.docs/system_overview/configuration.md` (known limits) and the comment on
`TestRealNomadOffersOnlyTheLimitedDockerDriver` now say that the limits
refuse only privileged containers, capabilities beyond the seven, and other
drivers, and list what still runs for any holder of ES's token: host bind
mounts (`/` included, task user `0:0`), `network_mode = "host"`, `devices`,
`security_opt` (for example `seccomp=unconfined`), and on Nomad 2.0.0
`pid_mode = "host"`. The PR body's known limits say the same. The INF-02
record in `reports/infra-security-audit.md` is outside the PR; per the
audit, the coordinator adds these there.

### A4-4: readiness refuses a loosened agent (Ran)

New `TestSupportedLocalFullReadinessRefusesALoosenedNomadAgent`. The full
readiness fixture's stand-in agent gets `allow_privileged` from
`ROOT_AGENT_ALLOW_PRIVILEGED` (default false). With `true`, each of these
fails with "the Docker plugin must refuse privileged containers
(allow_privileged = false)", prints no `submit-ready: true`, runs no Docker
command and changes nothing:

- `scripts/01_bringup.sh check`;
- `scripts/10_health_check.sh`;
- `scripts/10_health_check.sh` with `WAIT_FOR_READY=1` (the
  `wait_for_nomad_ready` loop that bring-up's `up` uses).

### O4-1 and O4-2

- O4-1: "any capability" is now "any job capability" in the tool's
  docstring, its `--management-token-file` help and `configuration.md`. The
  probe docstring and the docs add that variables capabilities are not
  judged and that ES's jobs read no Nomad variables.
- O4-2: fake-Nomad case "another management token whose expiry is
  unreadable" (`ExpirationTime: "next Tuesday"`): check refuses, so an
  unreadable expiry counts as live. It kills T10 (mutant O2 below).

O4-6 (P5 duplicate docker entries, P12 case-sensitive names) needs no
change, as the audit says.

## 3. Mutants (Ran)

One at a time in the test copy, against the tests named, then reverted.
Runner `05-evidence/mutantsA4.py`, output `05-evidence/mutantsA4.txt`.

| Mutant | Change | Result |
|---|---|---|
| A1 | `require_designed_policy` ignores `JobACL` | killed (real and fake Nomad tests) |
| A1b | observer exemption compares only the rules | killed (`TestNomadACLToolAsksNomadWhichGrantsCanSubmit`) |
| A1c | provision omits `"JobACL": null` | survived, equivalent: Nomad rewrites the whole policy (also run on 2.0.0) |
| A2 | check ignores roles on the ES token | killed (both) |
| A2b | check ignores roles on the observer token | killed (both) |
| A2c | check ignores the observer token's type | killed (`TestNomadACLToolCheckRefusesEachDeviation`) |
| A2d | provision keeps a token with roles | killed (`TestNomadACLToolAsksNomadWhichGrantsCanSubmit`) |
| O2 | an unreadable expiry counts as expired (T10) | killed (`TestNomadACLToolCheckRefusesEachDeviation`) |
| A4 | `check_nomad_ready_once` ignores a posture refusal (P13) | killed (`TestSupportedLocalFullReadinessRefusesALoosenedNomadAgent`) |

## 4. Validation

Runs in this container (Go 1.26.5, user `ci`, Nomad 2.1.1 unless noted).
"Repair before reflow" is the repair commit before a docstring-only reflow
in `nomad_acl.py` (then amended into `2b0d712`). Logs: `05-evidence/`.

| Run | Tree | Result |
|---|---|---|
| full-profile bring-up, Nomad 2.1.1 and 2.0.0, offline image rebuilt from this tree | repair before reflow | pass on both (Ran) |
| full `go test ./es/app/` | repair before reflow | 2 failures, both known environment-only: the full-profile bring-up without the image recipe, and the CI-listed `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` (Ran) |
| every other package | repair before reflow | `es/admission`: `TestSubmitRefusesBeforeRunAssignmentWhenNomadAccessControlFails` failed (see below, fixed in `4e2bdad`). `reliablesubmit`: two tests need a production-source probe; they fail the same way on a base `76c030f` copy (Ran) |
| real-Nomad set (`TestRealNomad`, `TestNomadACL`, `TestSupportedNomad`, platform identity, proof validation) on Nomad 2.0.0 | repair before reflow | pass (Ran) |
| root package `go test .` | repair before reflow | 27 failures, the same set as the `c3a94ae` run, none new; `TestRemoteAlphaESConfigTLSPrepRecordsDSSecurityWarningsWithoutFailing` now passes (Ran) |
| `go test -race ./es/admission/ ./es/config/ ./internal/observability/` | `4e2bdad` | pass (Ran) |
| focused es/app: ACL tool (real and fake), readiness, real Nomad, posture, setup-locks | `4e2bdad` | pass (Ran) |
| `go test -race ./es/config/` (PR #33's guard included) | `b150657` | pass (Ran) |
| `go vet ./...`; `GOOS=darwin go vet ./...` | repair before reflow; `go vet` of es/config and es/admission again at `b150657` | pass (Ran) |
| CI "build, vet and test", run 45286938875 | `b150657` | success, 23:14Z to 23:46Z (Read via the GitHub API) |

**Merge interaction found and fixed (`4e2bdad`).** PR #29 makes ES check
every ARS blob against its digest. Part 1's
`TestSubmitRefusesBeforeRunAssignmentWhenNomadAccessControlFails` served a
policy payload whose digest the fixture did not name, so after the merge
the submit refused earlier ("admission policy input unavailable") than the
access-control check it tests. The test now sets the fixture's payload with
`fixture.withPayload`, as PR #29's own tests do. Nothing in product code
changed.

## 5. Identity and manifest

- Repository: evo-agi/Execution-Substrate, branch
  `claude/project-thread-9slgp8`, pushed (fast-forward from `c3a94ae`).
- Base: `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (origin/trunk_dev, the
  merge-base; unchanged at manifest time).
- Head: `b15065754d986ae546cb0fe65f9204cb30aec699`, tree
  `083fd0a122a2d077fee28955a4136042a1287d36`.
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified).
- textual_diff_sha256
  `b631a3f126ba61e199738203421fa074a786f25103a4d012d5b5b44ad08d81a9`.
- manifest_sha256
  `ecdd778af0591acfed80d710ae50c930c1767b336e4cd504c762c5e92b3fe241`;
  52 files.
- Two runs byte-identical; upstream pinned to origin/trunk_dev before each;
  path set equals `git diff --name-only base HEAD` (52 = 52); 0 blob
  mismatches; clean tree afterwards. Manifest:
  `05-evidence/manifest-v2-b150657.json`.
- Delta for the narrow re-audit: `c3a94ae..b150657`. Without the two
  merges, the repair is `e323533..4e2bdad` (5 files in `2b0d712`, 1 in
  `4e2bdad`).
- After the manifest, trunk_dev moved to `725c97a` (PR #41, workload-zone
  Vault config JSON). It touches none of this PR's files and merges cleanly
  (Ran: `git merge-tree`); updating the branch is left to the merge gate, as
  O4-5 says.

## 6. Notes

- PR #39 moves root script tests into `scripts/`. This PR changes two root
  test files (`docs_contract_test.go`, `remote_alpha_nomad_acl_test.go`).
  Whichever lands second resolves the move; nothing here depends on the
  files' location.
- Part 2b (Nomad HTTPS, ES pins Nomad's server key) is finished locally on
  top of the previous head and will be rebased onto this one after the
  re-audit, then sent as its own delta audit.

## 7. Addendum: conflict with PR #37 resolved (head `6d1346f`)

After this report, trunk_dev moved to `42db339` (PR #37, runbook rename),
and GitHub marked PR #31 as conflicting.

- `6d1346f` merges origin/trunk_dev `42db339` (which includes `725c97a`).
  One conflict, in `scripts/70_linux_setup.sh`'s next-steps echo lines:
  step 3 takes trunk_dev's renamed, quoted runbook path, and step 4 keeps
  this PR's Nomad lock instructions. No other file conflicted (Ran).
- `b150657..6d1346f` is exactly trunk_dev's `0aa4a2b..42db339` (same 9
  files, same stat), and the PR diff's added and removed lines are
  identical to those of `0aa4a2b..b150657`; only context lines moved (Ran).
- Tests at `6d1346f` (Ran): the es/app tests that run or read the setup
  script (`TestLinuxSetup*`, `TestSupportedNomadDockerLimitsMatchSetupExampleAndTests`,
  `TestNomadRuntimePostureCheckRefusesLoosenedDockerLimits`,
  `TestRealNomadOffersOnlyTheLimitedDockerDriver`) pass; the root package
  has the same 27 failures as the A4 run, none new, and PR #37's
  `TestMarkdownRelativeLinksResolve` and `TestRunbookPathMentionsExist`
  pass. Logs: `05-evidence/run-m37-app.log`,
  `05-evidence/run-m37-root-summary.log`, `05-evidence/root-m37-fails.txt`.
- Manifest (same recipe and checks as section 5): base
  `42db33920d9a402e28f4f7c2344c66d8f1115215`, head
  `6d1346fa792c6a4f78589c86d97835832ce610ac`, tree
  `865e74d1545461acebe5f6b1c494b85187a5882d`, textual_diff_sha256
  `e7d5c261353eb7dd3035ae4bc23066e1e976add82b9337d2bedda2e8e1e76008`,
  manifest_sha256
  `a0ce1b2fbc6e3ec40b7412cd99a0529025624e8ee13522b03998624c3ac5a654`,
  52 files; two runs byte-identical, path set 52 = 52, 0 blob mismatches.
  Manifest: `05-evidence/manifest-v2-6d1346f.json`.
- The narrow re-audit can stay on `c3a94ae..b150657`; `b150657..6d1346f`
  adds only trunk_dev and the one resolved echo line.
