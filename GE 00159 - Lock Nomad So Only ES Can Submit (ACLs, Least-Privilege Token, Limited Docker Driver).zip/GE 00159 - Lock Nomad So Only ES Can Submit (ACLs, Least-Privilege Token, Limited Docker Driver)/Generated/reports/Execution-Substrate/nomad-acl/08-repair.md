# Nomad lock: red-team RT-1, O6-1 and trunk_dev sync (head `0f596c0`)

Draft PR #31, branch `claude/project-thread-9slgp8`. This applies red-team
finding RT-1 (`07-redteam.md`, Low, docs) and the re-audit's observation
O6-1 (`06-re-audit.md`) on top of the accepted head `6d1346f`, and takes
trunk_dev up to `523648c` (PR #39, #43). It is for a diff-only check.

Every statement is **Ran** (executed, output seen), **Read** or
**Inference**.

## 1. Commits since `6d1346f`

| Commit | What |
|---|---|
| `4e81758` | O6-1: fake-Nomad case "observer token answers for another secret" in `TestNomadACLToolCheckRefusesEachDeviation` (2 lines). |
| `97622e5` | RT-1: docs and test comment list `pid_mode`, `ipc_mode` and `userns_mode = "host"` as open on Nomad 2.0.0 only; the test pins both versions (section 2). |
| `7336dba` | Merge of origin/trunk_dev `4c991ba` (PR #39). No textual conflicts. This branch's new root script test `remote_alpha_nomad_acl_test.go` moves to `scripts/`, as PR #39 moved the others. |
| `41df7cd` | Merge of origin/trunk_dev `523648c` (PR #43, README only). No conflicts. |
| `0f596c0` | Gives the moved test the package name `scripts_test`. `7336dba` had committed it with its old root package name, so package `scripts` did not build at `7336dba` and `41df7cd` (section 4). |

## 2. RT-1 (Ran, Nomad 2.1.1 and 2.0.0)

- `.docs/system_overview/configuration.md`: the red-team's docs hunk,
  applied as given. The 2.0.0-only item now names `pid_mode = "host"`,
  `ipc_mode = "host"` and `userns_mode = "host"` (Nomad 2.1.1 refuses all
  three).
- `es/app/nomad_supported_config_test.go`, comment on
  `TestRealNomadOffersOnlyTheLimitedDockerDriver`: says the same.
- **Test: changed from the red-team's patch.** The patch adds two refusal
  rows (`ipc_mode`, `userns_mode`) that expect a refusal on any version. On
  Nomad 2.0.0 those jobs run, so the test would fail there. This PR's
  validation runs the real-Nomad set on 2.0.0 too (the box's version), so
  instead:
  - the test reads the agent's version from `/v1/agent/self`
    (`config.Version.Version`, fails if empty);
  - on Nomad 2.1, `pid_mode`, `ipc_mode` and `userns_mode = "host"` are
    refusal rows, each expecting Nomad's task event
    `cannot apply "<mode>" configuration`;
  - on Nomad 2.0, the same three jobs must run to completion (alloc
    `complete`, fail on `failed`, 60 s).
  So the test fails on either version if Nomad stops matching what the docs
  say. `pid_mode` is added as well, since the docs make the same claim
  about it.
- Results: passes on 2.1.1 and on 2.0.0. Mutant "flip the version switch"
  is killed on both: on 2.1.1 "host-pid failed on Nomad 2.1.1, which the
  configuration docs say runs it", on 2.0.0 "host-pid ran". Logs:
  `08-evidence/run-rt1-{211,200}.log`, `run-rt1-mut-{211,200}.log`.

## 3. O6-1 (Ran)

The new case answers the observer token's token-self with ES's secret and
expects "does not hold the observer client token". It passes; with mutant
R7 (the `document.get("SecretID") != observer` clause removed) exactly
that subtest fails. Logs: `08-evidence/run-o61.log`, `run-o61-mut.log`.

## 4. The PR #39 move, and a broken intermediate commit

- `scripts/remote_alpha_nomad_acl_test.go` at `0f596c0` equals the root
  file at `6d1346f` except its first line (`package scripts_test`). At the
  root it would no longer build: `writeExecutable`, `envWithPath` and
  `runSourcedRuntimeImageHelper` moved to `scripts/` in PR #39 (Ran).
- My error: the `git add` after the package-line edit failed (its pathspec
  also named the removed root file), so `7336dba` holds the moved file with
  the old package line. The tests ran on the working tree, which had the
  edit, so they passed. I found it after pushing `41df7cd`, from a dirty
  working tree, and pushed `0f596c0` with the fix. Package `scripts` does
  not build at `7336dba` or `41df7cd`; it does at `0f596c0` (Ran). Then I
  checked that `git archive 0f596c0` is byte-identical to the tested copy
  (Ran: `diff -rq`, no differences).

## 5. Validation at `0f596c0` (Ran, Go 1.26.5, user `ci`)

| Run | Result |
|---|---|
| root, `scripts/`, `internal/testutil/`, `internal/callerauth/` | root, testutil and callerauth pass; the 27 failures are the same 27 names as before the move (`root-m39-fails.txt` equals the A4 run's set), now in package `scripts`, none new |
| PR #37's `TestMarkdownRelativeLinksResolve`, `TestRunbookPathMentionsExist` after PR #43's README | pass |
| es/app: `TestNomadACL*`, `TestRealNomad*`, `TestSupportedNomad*`, posture, `TestLinuxSetup*`, `TestSupportedLocalFullReadiness*`, `TestSupportedLocalSetupLocks*` (22 tests) | pass |
| `TestRealNomadOffersOnlyTheLimitedDockerDriver` on Nomad 2.0.0 | pass |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | pass |

Not re-run: the full es/app suite and the full-profile bring-up. Since
`6d1346f`, nothing outside tests and docs changed in this PR's files, and
trunk_dev's PR #39 and #43 are tests, CI config and README (Read: their
diffs).

## 6. Delta for the diff-only check

- The PR diff (base to head) differs from the accepted one in exactly four
  files: `.docs/system_overview/configuration.md`,
  `es/app/nomad_acl_tool_test.go`, `es/app/nomad_supported_config_test.go`,
  and the moved `scripts/remote_alpha_nomad_acl_test.go` (one line). For
  every other file in the PR, the added and removed lines are identical to
  those at `6d1346f` (Ran). That delta:
  `08-evidence/pr-delta-6d1346f-0f596c0.diff`.

## 7. Identity and manifest

- Base: `523648cc9880c63d7e6592c2ae0754582d32f169` (origin/trunk_dev, the
  merge-base).
- Head: `0f596c05e4e7cef473be424214ca072af0151956`, tree
  `e8ff965447a527dab9f5d2f9a954d0a9bbddddbc`.
- Recipe `governed-execution.audit-patch-manifest.v2`, tool sha256
  `c08597e2…a3ca` (verified).
- textual_diff_sha256
  `fe8b35386ae36ce56d3a3491e634ce7e3994d02af0cff171def18049b772d37c`.
- manifest_sha256
  `c1806ff58f505f5a4499e7c84e9195df73b3ae66f86f7342b4b29da301420e67`;
  52 files.
- Two runs byte-identical; path set equals `git diff --name-only base HEAD`
  (52 = 52); 0 blob mismatches; clean tree afterwards. Manifest:
  `08-evidence/manifest-v2-0f596c0.json`.
- CI on `0f596c0`: run 45304003382, running at the time of writing; the gate must see it green.
