# Lock Nomad so only ES can submit: repair report (CI fix and early audit findings)

Draft PR #31, evo-agi/Execution-Substrate. Repairs commit 6270d7d, which is
described in [01-implementation.md](01-implementation.md). The auditor's
interim notes are in [02-audit-draft.md](02-audit-draft.md) (findings A2-1 to
A2-7). This report covers commits 70dd636 and 8c4b1bf, the merge of the
current trunk_dev (a68e44d), and 78fd064 (truly escaped policy tests).

## 1. Outcome in plain words

- CI failed on 6270d7d for three reasons. All three are fixed properly: no
  test is skipped, bypassed or newly listed as environment-only.
- The report's claim that the touched tests passed was wrong. It is struck
  through and corrected in 01-implementation.md.
- The five early audit findings are fixed. The most important one: the
  provisioning tool no longer decides by reading policy text whether another
  grant can submit jobs in ES's namespace. It asks Nomad itself, so every way
  of writing a policy, every role and every auth method is covered.
- A new guard fails the build if any Go code talks to Nomad's job API without
  going through the one request builder that adds ES's token. Applied to PR
  12's code, it fails on exactly the three requests that lack the token, so
  PR 12 cannot land after this PR without fixing them.
- Following the auditor's optional point, a second live Nomad management
  token now also counts as a lock breach.
- The branch now includes trunk_dev's latest commit (PR #26, test-only),
  merged without conflicts.

## 2. Why CI failed on 6270d7d, and why the report said otherwise

CI run 45234772309 (job 137903440643) failed on:

| Test | Cause | Fix |
|---|---|---|
| `TestSupportedLocalProofLogAssertionProjection`, `...SequentialCapturesAndLineage`, `...ResultValidationFinalizerContinuation`, `...AllocationExactCount`, `...SequentialAllocationFailureFinalizer` | proof capture now needs `NOMAD_TOKEN_FILE`, and the fixtures' `env.sh` set none | the fixtures write a real observer token file and export it (`writeProofEvidenceEnv`) |
| `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` | the new ACL preflight found no Nomad at the fixed 127.0.0.1:4646 | the test now starts a real, not yet bootstrapped ACL Nomad on a free port; the setup script takes `SUPPORTED_LOCAL_NOMAD_PORT` (default 4646, validated); the test then checks the lock itself: es.json and env.sh name the right files, the observer token reads nodes but gets 403 on submit, and a request without a token gets 403 |
| `TestLoadNomadTokenRefusesAFileOwnedByAnotherUser`, `...AParentOwnedByAnotherUser` | need root to set another owner; skipped themselves without a list entry | when not root they rerun their own test binary as root through `sudo -n` (the repo's existing pattern) and require that run's PASS line; they skip only where no passwordless sudo exists (not on the CI runner) |

Why the report was wrong: my last full `go test ./es/app/` run was 17:31 to
17:39Z. After it I changed the proof wrapper (observer token) and the
supported-local setup (ACL preflight), then re-ran only selected tests, and
wrote the report from the earlier full run. Lesson recorded in project
memory: re-run every affected package in full after the last edit before
claiming a pass.

## 3. Audit findings and what changed

| Finding | Change | Test |
|---|---|---|
| A2-1 (High) CI and report | section 2 above; report struck and corrected | CI on 78fd064 (section 8) |
| A2-2 (Medium) competing-policy refusal by text | `scripts/internal/nomad_acl.py`: for every ACL policy other than ES's, and every role, create a client token with only that grant (`ExpirationTTL` 5m, name `es-acl-probe`), plan a probe job in `es-submit-v1` with it, and count anything but 403 as a grant; delete the token in a `finally`. Any ACL auth method is refused (binding rules can issue tokens). Runs in `provision` (after the namespace exists) and in `check` when given `--management-token-file` (`scripts/nomad_acl_setup.sh check` always passes it) | `TestNomadACLToolAsksNomadWhichGrantsCanSubmit` (real Nomad 2.1.1): HCL glob, JSON, HCL with a `\u002d` escape in the name, JSON with escapes, partial glob and JSON glob policies, a role holding ES's policy, a JWT auth method are each refused by both provision and check; a harmless policy passes; no probe token survives |
| A2-2 (optional) other management tokens | refuse a live management token other than the one in the management token file; expired ones do not count (Go's zero time counts as no expiry) | real Nomad: a second management token is refused; fake: an expired one passes, two live ones are named |
| A2-3 (Low) ES client redirects and proxy | `newNomadTransport()` clones the default transport with `Proxy = nil`; the client's `CheckRedirect` returns `http.ErrUseLastResponse`, so a 3xx is a non-200 and fails closed | `TestNomadClientNeverFollowsARedirectOrUsesAProxy`: access check and submit fail against a redirecting Nomad, the redirect target gets no request; mutation (removing `CheckRedirect`) fails the test |
| A2-4 (Low) scripts' proxy | `--noproxy '*'` on every token-carrying curl (70_linux_setup.sh token curl, leader waits, bootstrap POST; nomad_acl.sh; bringup.sh); every embedded Python uses an opener with `ProxyHandler({})` and a no-redirect handler (70, bringup.sh, remote_alpha_runtime_security_boundary_check.sh); no `urlopen` remains on a token path | tool: redirect and proxy subtests below; shell paths by review |
| A2-5 (Low) token placement | `nomad.token_file` must lie outside the SPIRE socket's directory (Go config check), and 72's ACL directory check also excludes it | config cases `/run/spire/sockets/es-token` and `/run/spire/sockets/nomad/es-token` refused; 72 ordering test message updated |
| A2-6 (Low) check refusals untested | fake-Nomad test with one deviation per case; real-Nomad keep-rule test | `TestNomadACLToolCheckRefusesEachDeviation` (15 deviation cases plus redirect and proxy); provision replaces and deletes an ES token holding a wider policy set |
| A2-7 (Low) PR 12 seam without a trigger | the static guard (section 4) | guard tests; applied to PR 12's tree it fails on the provider's three tokenless requests |

Mutation checks on the new tests (run in the container, user ci): removing
the tool's no-redirect handler fails the redirect subtest; removing
`ProxyHandler({})` fails the proxy subtest; dropping the keep rule's policy
condition fails the keep-rule test; dropping the token header in
`newJobRequest` fails both the runtime and the static guard test.

One fixture changed because the placement rule is stricter:
`newExecutionRootStartupTestConfig` (es/admission/service_direct_test.go)
had its SPIRE socket in the same directory as the token file, which the new
rule rightly refuses. The socket moved to its own subdirectory.

## 4. The token guard (also in 01-implementation.md section 8, item 7)

`es/admission/nomad_request_guard_test.go`:

- `TestEveryNomadRequestPathGoesThroughTheTokenBuilder` parses every
  non-test Go file in the module. It fails on any string literal that names a
  Nomad API path (`/v1/job...`, `/v1/allocation...`, `/v1/client/...` and the
  other Nomad prefixes, also inside a full URL or as a leading `/v1/`
  fragment) unless it is the leftmost part of the path argument of
  `newJobRequest` or `get` called on the receiver inside a `*nomadClient`
  method. Access-control paths are allowed only in `verifyAccessControl`. It
  also fails on a hand-built `http.NewRequest*` inside any other
  `*nomadClient` method.
- `TestNomadTokenRequestBuildersSetTheToken` checks that `newJobRequest` sets
  `X-Nomad-Token` from the client's token, that `get` uses `newJobRequest`,
  and that no code deletes the token header.
- `TestNomadRequestGuardCatchesEachBypass` and
  `TestNomadTokenBuilderCheckCatchesALostToken` prove each bypass is caught:
  another client's builder, a hand-built request, a path in a constant, in a
  URL literal, a split fragment, a full URL, a raw string, a builder on
  another value or from a free function, an access-control path elsewhere, a
  path that is not leftmost; and that the current forms pass.
- The runtime half stays `TestEveryNomadJobRequestCarriesTheTokenAndTheSubmitNamespace`.

Copied into PR 12's tree (draft PR #28 head 2c8bf35), the guard fails on
`reliable_submit_operational_handoff.go:666` (`POST /v1/jobs`) and
`reliable_submit_operational_provider.go:622` and `:657` (`GET /v1/job/...`),
plus that tree's old `lifecycle.go` and `submit.go` request lines, which this
PR already replaces.

Known limit of the guard (Inference): it reads source text, not types. A path
assembled entirely at run time from pieces that are not Nomad-looking
literals would pass it. The runtime test and review cover that; no such code
exists today.

## 5. Validation

Cloud container, Go 1.26.5, Nomad 2.1.1, Docker 29.

- `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...`: pass (on
  a68e44d).
- `go test ./es/admission/ ./es/config/`: pass; also under `-race`
  (admission 116.5 s, config 1.0 s) on a68e44d.
- `go test ./es/app/` in full as user ci (1500:1600, group docker) on the
  70dd636 tree: every failure accounted for. 4 were part 2a tests from a file
  I had set aside that was still in the test copy (not in this commit; the
  copy step now refuses stale files). 1 was
  `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`,
  listed environment-only. 1 was the supported-local setup test, which
  refuses on purpose when `CONTROL_PLANE_DOCKERFILE` points elsewhere (I had
  set it for the bring-up recipe); run without it, it passes (9.7 s).
  `TestBringupScriptUpCheckDownFullProfile` passed with the offline image
  recipe, and again after the management-token change (32.0 s).
- 70dd636's "escaped" policy case was not escaped (it named the namespace in
  plain text); 78fd064 writes it with `\u002d` and adds a JSON form with
  escapes. Nomad decodes both, and provision and check refuse both (Ran).
- After 8c4b1bf: every ACL tool, Nomad, setup, health-check, Remote Alpha,
  operator and readiness test in es/app passes (105 s run).
- Root package `go test .`: no failure that does not also occur on the base
  in this container (the base itself varies between runs, 29 and 34
  container-only failures; CI runs this package green).
- Each new or touched test was checked for PASS, not SKIP.

## 6. Target identity and manifest

- Repository: evo-agi/Execution-Substrate, draft PR #31
- Base: `8ba1edb8af52214ec1bfbb5b93e5a4dc4e51b1ce` (origin/trunk_dev at
  19:22Z; it moved from 036d507 when PR #26 merged, and the branch merged it
  without conflicts)
- Topic branch: `claude/project-thread-9slgp8`
- Head: `78fd0647643dc80b8c520a42fb8a5e22e8dd9d62` (tree
  `734ac772bd7c8cf175e1066499db0add4e12aaaa`). Commits since 6270d7d:
  70dd636 (repair), 8c4b1bf (management tokens and tool tests), a68e44d
  (merge of trunk_dev), 78fd064 (escaped policy tests). Fast-forward pushes
  only.
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified)
- Repair-style run: HEAD reset `--mixed` to the base, upstream pinned to
  origin/trunk_dev before each of two runs, then back to the head.
- Textual diff sha256: `887660f30e2ed9e8892515c353d09b9caedde49dd35fe0ae645afd11da50dab0`
  (tracked files only, so unchanged by 78fd064, which touches a file new in
  this PR)
- Canonical manifest sha256: `8b7b1605e20c3112dca5242966b6c401b4aa7724ede04b6ec01d14c166a7e86c`
- File count: 46. Two runs byte-identical. Committed path set
  (`git diff --name-only base HEAD`) equals the manifest path set (46 = 46);
  every committed blob matches its manifest sha256; `git status` clean.
- Full manifest: [02-repair-evidence/manifest-v2-78fd064.json](02-repair-evidence/manifest-v2-78fd064.json).
  Superseded intermediate manifests kept beside it for the record: 70dd636
  against the old base (`02b26578c7d2b94c626e4fab5467c0b70e79369351b841e77c909425bbdb2e30`)
  and a68e44d (`fd615ad13a47b2c86dfd7bb8b46ab466b5d89c40337b68ff4eae26b4738c400a`).
- CI on 78fd064: see section 8.

## 7. Not changed here

- Audit observations O2-1 to O2-5: no change asked. O2-1 (ES's token can
  express any job shape) is INF-02, recorded for a later design call. O2-3
  (72 provisioning with `ES_USER=root` into the same default directory that
  Remote Alpha uses with `ES_USER=es`) fails closed; it is worth a decision
  before supported-local runs on the box (Inference: setting
  `SUPPORTED_LOCAL_NOMAD_ACL_DIR` per profile avoids it).
- Part 2 (audit item D2): the Docker-only driver allowlist, explicit Docker
  plugin limits and root-owned Nomad config (part 2a), and Nomad HTTPS with a
  server key ES pins (part 2b) follow as further commits on this PR with a
  delta audit.

## 8. CI

GitHub CI "build, vet and test" on 78fd064 (run 45248467696, job
137951512389, 19:23:51Z to 19:52:30Z): **success**. All steps passed,
including "Check the test gate" (every test that skips itself is listed, so
the two owner tests now run rather than skip), "Test" and "Listed tests still
fail". The runs on 70dd636 and a68e44d were cancelled by the newer pushes.
