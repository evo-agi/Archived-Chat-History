# Nomad lock: fixes for audit A2-8 to A2-10, and part 2a

Draft PR #31, branch `claude/project-thread-9slgp8`. This round has two
parts for one narrow audit:

- the fixes for the audit of 78fd064 (`02-audit.md`, BLOCK): A2-8 (Medium),
  A2-9 and A2-10 (Low), and one part 2a fix found on Nomad 2.0.0, in commit
  c3a94ae;
- part 2a (commit c27e33a, infra audit INF-02 (a) and (b), INF-16) and the
  merge of trunk_dev 76c030f (PR #27, caller authentication, commit
  7aaac66), which the auditor has not seen yet.

INF-02 itself is recorded, not solved (section 9). Part 2b (Nomad HTTPS
with a pinned server key) is started but not committed; it waits for this
audit round.

## 1. Outcome

- **A2-8 fixed.** The exclusive-writer check no longer asks only whether a
  grant can submit. For every policy other than ES's and the observer's, and
  every role, a short-lived probe token holding only it now reads the
  `es-submit-v1` namespace and plans a job there; any answer but 403 to
  either is a grant and is refused. Nomad answers the namespace read with 200
  for any capability in the namespace, so `scale-job`, `dispatch-job`,
  `alloc-lifecycle`, `alloc-exec` and `read-job` grants are refused, by
  provision and by check, on real Nomad 2.1.1 and 2.0.0.
- **A2-9 fixed.** check refuses a second live token with ES's or the
  observer's policy, and either policy with rules other than the tool's.
- **A2-10 fixed.** Each of the four undone fixes now fails a test (16 of 16
  mutants killed, section 4).
- **Part 2a** (unchanged since c27e33a): the supported Nomad offers ES's jobs
  only the Docker driver, refuses privileged containers, allows only the
  seven capabilities ES's runtime helper uses, and keeps its configuration
  and data root-owned; setup, bring-up readiness and supported-local setup
  refuse a Nomad that does not report these limits.

## 2. A2-8: Nomad judges every other grant by any capability

`scripts/internal/nomad_acl.py`:

- `grants_in_namespace` (was `grants_that_can_submit`): per policy and role,
  probe token (5 minute TTL, deleted in `finally`), then
  `GET /v1/namespace/es-submit-v1` and the plan probe; `statuses != (403,
  403)` is a grant. A 500 or any other answer counts as a grant (fails
  closed).
- Exempt: `es-submit-v1` by name (its rules are restored by provision before
  the probes and checked by check, section 3), and `es-observer-v1` only
  while its rules equal `OBSERVER_POLICY_RULES` exactly (read with the
  management token).
- provision now writes the namespace and both of its policies before
  `require_exclusive_writer`, so a widened copy of either is restored before
  the probes judge every other grant (previously the ES policy was written
  after them).
- Refusal text: `other ACL grants hold capabilities in es-submit-v1 (policy
  …, role …): only ES may submit or change jobs there and only the read-only
  observer may read them; narrow or delete them and rerun`.

Tests (`es/app/nomad_acl_tool_test.go`,
`TestNomadACLToolAsksNomadWhichGrantsCanSubmit`, real Nomad): the six earlier
forms plus `scale-only`, `lifecycle-json` (read-job and alloc-lifecycle in
JSON), `exec-glob` (alloc-exec through `"*"`), `dispatch-only` and
`another-reader` (read-job only) are each refused by provision and check;
`readers` (default namespace only) and `shadowed` (`"*"` write with a deny on
`es-submit-v1`) pass both; a provision run without the observer token file
refuses a widened `es-observer-v1` policy as an ordinary grant. Fake-Nomad
cases: namespace read answering 200, and answering 500, for the probe token
are both refused.

Note on the auditor's uncertainty (namespace read as "any capability"): the
plan probe is kept as a second, independent Nomad-evaluated question, so a
capability that Nomad's namespace read ever missed would still be caught if
it can submit.

## 3. A2-9: check verifies tokens and policy rules

`command_check`:

- ES policy rules must equal `ES_POLICY_RULES`, read with the ES token
  itself (Nomad lets a token read the policies it holds; checked on 2.1.1
  and 2.0.0), so this holds without the management token too.
- With the observer token file, the observer policy rules must equal
  `OBSERVER_POLICY_RULES`, read with the observer token; with the
  management token, they are read again with it (and must be absent or
  equal when no observer file is given).
- With the management token: the live tokens (expired ones skipped, Go's
  zero time counts as live) that list `es-submit-v1` must be exactly the ES
  token, and those that list `es-observer-v1` exactly the observer token.
- Success line now: `nomad acl: ok (ACLs enforced, no anonymous policy, ES
  token is the es-submit-v1 client token, policies as designed, it is the
  only token with that policy, and no other grant holds capabilities
  there)`.

Tests: real Nomad (a `not-es` token with the ES policy is refused by check
and deleted by provision; a widened `es-observer-v1` with scale-job,
alloc-exec and alloc-lifecycle, and a widened `es-submit-v1` with alloc-exec,
alloc-node-exec and host_volume write, are each refused by check and
restored by provision, after which check passes). Fake Nomad: ES policy
widened, missing; observer policy widened as the observer token reads it and
as the management token reads it; a second ES-policy token; a second
observer-policy token; an expired ES-policy token in the default list is
ignored.

Docs: `.docs/system_overview/configuration.md` provisioning bullet now says
what is refused (any capability, the observer exemption, other tokens with
the two policies, widened rules), that check with the management token
writes to Nomad (probe tokens, O2-8), and that grants outside namespaces,
such as `node` write, stay operator power the check does not judge (O2-6).

## 4. A2-10: tests that fail when the fixes are undone

| Auditor mutant | New test | Result |
|---|---|---|
| G1: client on the default transport | `TestNomadClientNeverFollowsARedirectOrUsesAProxy` now unwraps the client's real transport (new `Unwrap()` on the logging round tripper in `internal/observability`) and requires a non-default `*http.Transport` with no proxy | killed |
| U1: wrapper `check` without `--management-token-file` | `TestNomadACLSetupWrapperChecksWithTheManagementToken` runs a copy of `nomad_acl_setup.sh` as root (re-runs itself through `sudo -n`, requires PASS) with a stand-in tool that records its arguments; `check`, `provision` and `rotate` must pass the management and observer token files to every tool call | killed |
| S5: `nomad_api_get` without `--noproxy` | `TestNomadACLShellHelpersIgnoreProxySettings`: every proxy variable points at a listener, the Nomad address does not resolve; `nomad_api_get` and `nomad_acl_state_check` must fail with no request at the listener | killed (also for `nomad_acl_state_check`) |
| S6: 72 without the SPIRE socket scope | new 72 subtest (token directory inside `proof/spire-agent/public`), plus `TestNomadACLDirPlacementRefusesEveryScope`, which checks each scope alone | the 72-level mutant is equivalent: 72's socket directory is always inside its proof directory, so the proof scope refuses the same paths. The function-level mutant (overlap check removed) is killed |

All mutants run against the focused tests, one at a time, in the test
copy, restored after each:

| Mutant | Result |
|---|---|
| namespace probe removed | killed |
| plan probe removed | killed |
| only 200 counts as a grant | killed |
| observer exempt by name, not rules | killed |
| probes before the policies are written | killed |
| no ES-policy holder check | killed |
| no observer-policy holder check | killed |
| holder check counts expired tokens | killed |
| no ES policy rules check | killed |
| no observer rules check (observer token) | killed |
| no observer rules check (management token) | killed |
| G1, U1, S5 (both helpers), S6 (function) | killed |

## 5. Part 2a: what changed (commit c27e33a, 18 files)

**Nomad configuration** (`scripts/70_linux_setup.sh` writes
`/etc/nomad.d/nomad.hcl`; `.examples/config/nomad.hcl` matches):

- client options: `"driver.allowlist" = "docker"`. The old
  `docker.cleanup.image` and `docker.volumes.enabled` client options are gone.
  exec and raw_exec are no longer offered.
- an explicit `plugin "docker"` block: `allow_privileged = false`;
  `allow_caps = ["chown", "dac_override", "fowner", "kill", "setgid",
  "setuid", "setpcap"]`; `volumes { enabled = true }` (ES's bind mounts);
  `gc { image = false }` (runtime profile images survive completed
  allocations).
- `/etc/nomad.d` root:root 0755, `nomad.hcl` root:root 0640 (was
  nomad:nomad 0644), Nomad data directory root:root 0700 (was nomad:nomad
  0755). `install -d` re-owns an existing directory (checked in the
  container: an existing 1500:1600 0755 directory became root:root 0700).
  Files already inside the data directory keep their owner; Nomad runs as
  root, so that does not stop it.

**Refusals** (`scripts/internal/nomad_acl.sh`, new
`nomad_runtime_posture_check <agent-self-json>`): reads a `/v1/agent/self`
answer (observer token) and refuses unless the client allowlist is exactly
`docker`, there is exactly one `plugin "docker"` block, `allow_privileged` is
`false` (unset counts as not refused), and `allow_caps` is a non-empty list of
strings that is a subset of the seven (absent means Docker's default set and
is refused). On success it prints
`nomad: drivers=docker docker_privileged=refused docker_caps=chown,dac_override,fowner,kill,setgid,setpcap,setuid`.
Callers:

- `scripts/internal/bringup.sh` `check_nomad_ready_once`, after the agent
  self read, so `check` and readiness fail on a loosened Nomad.
- `scripts/72_supported_local_setup.sh`
  `verify_supported_local_nomad_runtime_posture`, right after token
  provisioning and before the image build and any proof effect.
- The bring-up runtime-profile image durability check now reads
  `gc.image` from the Docker plugin block instead of the removed client
  option. Note for the box: a Nomad that still has only the old client
  option now fails readiness (deliberate; the box run rewrites its config).

**Tests** (`es/app`):

- `nomad_supported_config_test.go` (new):
  `TestSupportedNomadDockerLimitsMatchSetupExampleAndTests` (setup script,
  example and test harness carry the same client options and plugin block);
  `TestLinuxSetupKeepsNomadConfigAndDataRootOwned`;
  `TestNomadRuntimePostureCheckRefusesLoosenedDockerLimits` (accepts the
  supported agent, refuses nine loosenings: exec also enabled, no allowlist,
  no plugin block, privileged allowed, privileged unset, extra capability,
  Docker default capabilities, empty list, unreadable answer);
  `TestRealNomadOffersOnlyTheLimitedDockerDriver` (real Nomad: the posture
  line passes on the real agent; the fixture's fields match the real agent's
  Docker plugin config; the node offers only a healthy Docker driver; with
  ES's own token, a privileged container, `cap_add = ["sys_admin"]`, an exec
  task and a raw_exec task are each refused by the client).
- `submit_integration_test.go`: the real Nomad harness writes the same
  client options and plugin block, so every real submit test runs inside the
  limits.
- `operator_scripts_integration_test.go`: the bring-up test asserts the
  posture line in its `check` output; fixtures carry the agent config.
- `nomad_acl_integration_test.go`: supported-local setup subtest "Docker
  driver not limited" (privileged allowed: setup refuses before the first
  proof effect).
- `mounted_source_identity_test.go`, `supported_local_execution_roots_test.go`:
  fixtures updated.

**Docs**: `.docs/system_overview/configuration.md` (Nomad requirements list,
submit-ready bullets, reworded INF-02 known limit),
`supported_linux_host_qualification.md`, `execution_lifecycle/contracts.md`,
`execution_lifecycle/implementation.md`,
`supported_local_cp_consumer_runbook.md`, `.runbooks/system/v1_bringup.md`,
`PLANS.md` (status entry and the plan section). The merge commit's PLANS.md
resolution keeps both status entries (Nomad lock and PR #27's caller
authentication) and adds the part 2a sentence to the Nomad lock entry.

## 6. Part 2a: why these seven capabilities

Each capability was removed in turn from the harness's plugin block (a
temporary environment override, not committed) and the four real submit
tests were run (`TestSubmitFlowRunsStaticScriptInNomadDocker`,
`...InjectsWorkloadIdentityEndpointAndLifecycleStillWorks`,
`...HelperDeathIsTaskFatal`, `...MountsGovernedArtifactAndLifecycleStillWorks`):

| Removed | Result |
|---|---|
| none (all seven) | all 4 pass |
| chown | all 4 fail |
| fowner | all 4 fail |
| setgid | all 4 fail |
| setuid | all 4 fail |
| setpcap | all 4 fail |
| kill | helper-death test fails, other 3 pass |
| dac_override | all 4 skip: the substrate capability probe itself fails with `PermissionError` |

**Fix in c3a94ae, found on Nomad 2.0.0 (the box's version).** Nomad 2.0.0's
`/v1/agent/self` reports the Docker plugin's nested blocks as a list holding
one object (`"gc": [{"image": false}]`, `"volumes": [{"enabled": true}]`),
where 2.1.1 reports an object. The posture check reads only the top-level
`allow_privileged` and `allow_caps`, so it passed on 2.0.0, but bring-up's
runtime-profile image durability check read `gc` as an object only and would
have refused the box's Nomad whenever a runtime profile image is enabled.
`bringup.sh` now accepts both shapes; the fixture-shape check in
`TestRealNomadOffersOnlyTheLimitedDockerDriver` normalises a one-element list;
`TestRuntimeProfileImageReadinessAcceptsNomadDockerImageCleanupDisabled` runs
both shapes. On Nomad 2.0.0: the real-Nomad Docker limit test, two real
submit tests and the full-profile bring-up (with the posture line) pass.

Correction to the c27e33a commit message, which says removing any one
"breaks the real submit tests": for dac_override the tests skip rather than
fail. CI would still refuse it, because the CI gate requires the set of
self-skipping tests to be exactly the listed ones, and these four are not
listed. Logs: `/home/ci/capexp-*.log` in the writer's container (not kept
after the container ends).

## 7. Validation

Container: Go 1.26.5, Nomad 2.1.1 (CI pin) unless stated, Docker; tests as
user `ci` (1500:1600) under `env -i`; the root-only tests rerun themselves
through `sudo -n`.

| Run | Head | Result |
|---|---|---|
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | c3a94ae | pass |
| `go test -race ./es/admission/ ./es/config/ ./internal/observability/` | c3a94ae tree | pass |
| `go test ./es/api/ ./internal/callerauth/ -race` (PR #27 packages) | 7aaac66 | pass |
| `go test ./es/admission/internal/reliablesubmit/` | 7aaac66 | 2 failures that need an externally built probe binary (`ES_REPLAY_SCHEMA3_PROBE`, PB1); untouched package |
| full `go test ./es/app/` | c3a94ae tree before the Nomad 2.0 shape fix | all pass except the two known environment failures: `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity` (CI-listed) and the full-profile bring-up without its offline image recipe |
| full `go test ./es/app/` | c3a94ae | the same two known environment failures, plus `TestSubmitFlowUsesPlatformOwnedIdentityForVaultLoginAndSecretRead` (its test Nomad lost a port race: "bind: address already in use" on 127.0.0.1); that test passes when rerun alone |
| full-profile bring-up with the offline image recipe | c3a94ae, Nomad 2.1.1 and 2.0.0 | pass on both |
| focused real-Nomad ACL tool tests and the Docker limit test | c3a94ae, Nomad 2.0.0 | pass |
| `go test .` (root package) | c3a94ae | 28 failures. 27 also fail in this container's earlier run of a trunk_dev checkout without this PR (036d507; for example no `ds` user and no `uuidgen` here). The 28th, `TestRemoteAlphaESConfigTLSPrepRecordsDSSecurityWarningsWithoutFailing`, hit a root-owned `/var/tmp/execution-substrate-remote-alpha` left by this container's earlier root runs; with that directory moved aside it passes as user `ci`. No failure is new against the base |
| mutants (section 4) | c3a94ae tree | 16 of 16 killed |

CI on the pushed head: pass. Workflow `go`, run 45267764672 (attempt 1), job "build, vet and test" on c3a94ae: success, 21:15Z to 21:45Z UTC, including the test gate, Test, and "Listed tests still fail" steps (https://github.com/evo-agi/Execution-Substrate/actions/runs/45267764672).


## 8. Identity

| | |
|---|---|
| PR head | `c3a94aee5d82d82752a09f1903e7ea6e5ee9c019` |
| tree | `021777f5d0a6cd9f16c9899b6247cd25e4acb971` |
| base (trunk_dev, merge-base) | `76c030fa7872dd22dda731591878ef284c01bd9b` |
| manifest v2 sha256 | `0336e0bf2687686bcff1f86426682939664d0954bcb42eef7db1b3e28fe8cbb7` |
| textual diff sha256 | `f55803c822d886bcddb1bb9605795eb413b9fd04592abff77bc39b8a82dd2241` |
| files | 52 |

Commits since the audited 78fd064: c27e33a (part 2a), 7aaac66 (merge of
trunk_dev 76c030f, PR #27; PLANS.md conflict resolved by keeping both status
entries), c3a94ae (A2-8 to A2-10 and the Nomad 2.0 shape fix). The earlier
manifest of 7aaac66 (`fff7d35a…`, 50 files) is kept for reference.

Manifest tool sha256 c08597e2…a3ca (verified), run twice with identical
output; the path set equals `git diff --name-only --no-renames 76c030f HEAD`
and every blob sha256 matches HEAD; origin/trunk_dev is 76c030f and the
merge-base. Evidence: `03-evidence/manifest-v2-c3a94ae.json` (and
`manifest-v2-7aaac66.json`).

## 9. Not done here

- INF-02 stays open: the lock does not cover the Docker socket, and ES's
  token still expresses job shape (host bind mounts, task user). The
  configuration docs record this.
- Part 2b (Nomad HTTPS on loopback, ES pins the server key, aligned with PR
  12's realm) is next on the same PR, with its own delta audit. Its ES-side
  config and client code are written but not committed.
- Auditor observations kept as they are: O2-1 to O2-5 and O2-7 (no change
  asked); O2-6 and O2-8 are now in the configuration docs.
- The box (Nomad 2.0.0, hand-written config) is untouched. Its run waits for
  David's "go ahead" in the thread.
- PR 12's operational provider: no new change-list item. Its job spec at
  4416699 (`es/admission/submit.go` `buildNomadJobSpec`,
  `resolved_execution_plan.go` `defaultResolvedJobEnvelope`) uses the Docker
  driver, `privileged: false`, `security_opt: ["no-new-privileges"]` and no
  `cap_add`, so it fits the limits, and Nomad applies them on its side.
  Inference, not run: its real-submit tests will pass inside the limits once
  PR 12 takes trunk_dev after this PR, because they use the same runtime
  helper the ablation above exercised.
