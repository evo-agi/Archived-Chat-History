# Independent re-audit of ES draft PR #31 (Nomad lock) at c3a94ae

Verdict: **BLOCK**. Nothing is Medium or higher. A2-8, A2-9 and A2-10 are
fixed for everything they named. Part 2a's Docker limits hold on Nomad
2.1.1 and 2.0.0, and the PR #27 merge is clean. The re-audit found four new
Low findings. Two are drift that `check` passes, in the same family as
A2-9. One is a docs gap and one is a test gap. The project fixes Low
findings in the PR, so the verdict is BLOCK. All four fixes are small
(section "Findings").

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`04-re-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #31, branch
  `claude/project-thread-9slgp8`.
- Base: `76c030fa7872dd22dda731591878ef284c01bd9b` (trunk_dev after PR #27;
  the merge-base of the head).
- Topic: `c3a94aee5d82d82752a09f1903e7ea6e5ee9c019`, tree
  `021777f5d0a6cd9f16c9899b6247cd25e4acb971`. The GitHub API reports this
  as the PR head (Ran, about 22:10Z).
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified before use).
- textual_diff_sha256
  `f55803c822d886bcddb1bb9605795eb413b9fd04592abff77bc39b8a82dd2241`;
  manifest_sha256
  `0336e0bf2687686bcff1f86426682939664d0954bcb42eef7db1b3e28fe8cbb7`;
  52 changed paths.
- Scope (coordinator, 21:46Z): the A2-8, A2-9 and A2-10 fixes, part 2a
  (`c27e33a`, plus the Nomad 2.0.0 list-shape fix in `c3a94ae`), and the
  trunk_dev merge `7aaac66`. Part 2b (HTTPS) is not committed yet and is
  out of scope.
- Writer's report: `03-audit-fixes-and-part2a.md`, sha256
  `7c94ea20…faad`.

## Audit posture

I made no change to the repository or the PR: nothing was committed,
pushed or commented. I used no subagents, as in round 02. I did not touch
the box or any live service. All execution ran in this container:

- local clones;
- two disposable Nomad dev agents on loopback, 2.1.1 (the CI pin) on port
  24646 and 2.0.0 (the box's version) on port 25646, both with ACLs and the
  supported client and Docker plugin settings;
- the local Docker daemon.

I applied mutants one at a time in a scratch clone and restored the file
after each run. The tree was clean afterwards (Ran).

The container's test user `ci` has no sudo, so I ran the root-only tests as
root directly, as in round 02.

## Provenance reproduction (Ran)

- Fresh clone at `umask 022`. The pushed tip equals the reported tip. Base
  `76c030f` is an ancestor and the merge-base. The checkout was clean.
  Then `reset --mixed` to base, upstream pinned to `origin/trunk_dev`,
  recipe run twice.
- The two runs are byte-identical and equal the writer's manifest (sha256
  above). The path set equals the committed `76c030f..c3a94ae` path set
  (52). Evidence: `provenance/`.
- Merge `7aaac66` (parents `c27e33a` and `76c030f`). A fresh
  `git merge-tree --write-tree` of the parents conflicts only in
  `PLANS.md`. The committed merge tree differs from it only in `PLANS.md`:
  - the conflict markers are removed;
  - both sides' entries are kept;
  - one sentence about part 2a is added to the Nomad lock entry (O4-3).

  The trunk_dev side brings PR #27 (caller identity, 41 files). No `.github`
  file changes between base and head, so the CI configuration and the
  environment-only test list are trunk_dev's.
- Closing manifest: see "Validation assessment".

## Coverage

- Read: `scripts/internal/nomad_acl.py`, `scripts/internal/nomad_acl.sh`,
  the posture check callers (`scripts/internal/bringup.sh`
  `check_nomad_ready_once`, which `10_health_check.sh` also uses;
  `scripts/72_supported_local_setup.sh`
  `verify_supported_local_nomad_runtime_posture`), `scripts/70_linux_setup.sh`
  (plugin block, root-owned paths), `scripts/nomad_acl_setup.sh`,
  `.examples/config/nomad.hcl`, `internal/observability/observability.go`
  (`Unwrap`), `es/admission/submit.go` and `lifecycle.go` (job shape, no
  Nomad templates), the new and changed tests, the configuration docs'
  Nomad sections, the PR body and the writer's report.
- Ran: the round 02 probes again on both Nomad versions, new probes
  (policy drift, JobACL, token roles, variables, Docker job shapes, each
  narrow grant alone), 34 mutants, build and vet, focused and full test suites, the root package
  against base, and the CI run's metadata and log tail.
- Not inspected: PR #27's own code beyond the merge (audited in its own
  thread). Part 2b. The box.

## Findings

### A2-8 (round 02, Medium): fixed (Ran)

`grants_in_namespace` now gives each other policy and each role a 5-minute
probe token. The token reads `GET /v1/namespace/es-submit-v1` and plans the
probe job. Any answer but 403 to either counts as a grant. On both versions
(`probes/competing3-*.txt`), provision and check refused all of these:

- the six submit forms (HCL glob, escaped name, escaped star, JSON glob,
  JSON escaped name, JSON partial glob);
- a role with glob write, and a role holding ES's policy;
- `scale-job`, `alloc-lifecycle`, `alloc-exec` through `"*"`,
  `dispatch-job`, JSON `scale-job` and `read-job` alone. I tested each of
  these with no other extra policy present, and each refusal names exactly
  that policy (`probes/narrow-*.txt`);
- a JobACL policy with write rules;
- a second management token.

These pass on both versions, as designed (`probes/drift4-*.txt`):

- default-only write;
- node write;
- a glob write shadowed by a `deny` on `es-submit-v1`;
- host-volume write.

No probe token is left behind. The final provision and check pass.

### A2-9 (round 02, Low): fixed for what it named (Ran)

- A second token holding ES's policy is refused by check ("live tokens
  holding the es-submit-v1 policy…") and deleted by provision
  (`probes/competing3-*.txt`).
- Check refuses each of these (`probes/drift4-*.txt`), and provision
  restores the rules after each:
  - observer rules widened with `scale-job`, `alloc-exec` and
    `alloc-lifecycle`;
  - ES rules widened with `alloc-exec`, `alloc-node-exec` and `host_volume`
    write;
  - a whitespace-only change.
- Two neighbouring paths are still open: A4-1 (a JobACL on the tool's own
  policies) and A4-2 (a role on the tool's own tokens).

### A2-10 (round 02, Low): fixed (Ran)

I re-ran G1, U1, S5 and S6 myself. All four are killed:

- G1 by `TestNomadClientNeverFollowsARedirectOrUsesAProxy`;
- U1, run as root, by `TestNomadACLSetupWrapperChecksWithTheManagementToken`;
- S5 by `TestNomadACLShellHelpersIgnoreProxySettings`;
- S6 (the function-level overlap check) by
  `TestNomadACLDirPlacementRefusesEveryScope`.

The writer says the 72-level S6 is equivalent. I agree (Read: 72's socket
directory is always inside its proof directory).

The U1 test skips when it runs as a user without passwordless sudo. In CI
it runs through `sudo -n`, and CI's skip gate would fail an unlisted skip
(Read: `.github/ci/go_test_gate.py`). Mutant table: "Validation assessment".

### Part 2a: the limits hold (Ran)

On both versions, with ES's own token (`probes/jobprobe-*.txt`):

- effective capabilities are exactly the seven;
- `privileged` is refused ("Docker privileged mode is disabled on this
  Nomad agent");
- `cap_add sys_admin` is refused;
- exec and raw_exec tasks are not placed ("missing drivers");
- the node offers only docker.

`nomad_runtime_posture_check` accepts both live agents. Nomad 2.0.0
reports `gc` and `volumes` as one-element lists; Config is an object on
both (`probes/posture-live.txt`).

What still works under these limits is A4-3.

### New findings

```text
AUDIT FINDING
ID / Type / Severity: A4-1 / correctness (lock drift check) / low
Current contract or strategic target: "ES is the only client writer" in
  es-submit-v1; check with the management token reports "policies as
  designed, it is the only token with that policy, and no other grant
  holds capabilities there".
Path and line: scripts/internal/nomad_acl.py:604-614 (require_designed_policy
  compares only Rules); :495 (observer exemption compares only Rules).
Evidence (Ran, Nomad 2.1.1 and 2.0.0, probes/jobacl-*.txt, drift4-*.txt):
  A management-token holder sets JobACL {Namespace: es-submit-v1,
  JobID: es-jobacl-victim} on the es-submit-v1 policy and leaves the rules
  unchanged. Then:
  - check rc=0;
  - ES registers es-jobacl-victim;
  - that job's task, using its own workload identity (NOMAD_TOKEN),
    registers a new job in es-submit-v1: HTTP 200, job created.
  Control without the JobACL: HTTP 403, no job. Provision clears the JobACL,
  and afterwards the task gets 403. The same JobACL on the observer policy
  also passes check.
Impact: the named job's workloads become a second writer in es-submit-v1
  and bypass ES admission. With INF-02 (host bind mounts), a workload could
  then reach host root. Precondition: someone with the management token sets
  the JobACL, by mistake or on purpose. That is the drift check's job to
  report, as in A2-9.
Required correction: require_designed_policy, and the observer exemption in
  grants_in_namespace, refuse a policy whose JobACL is set (Nomad returns
  null when unset). Add a check test for ES's and the observer's policy, and
  a test that provision clears it.
Uncertainty: none for the behaviour; severity follows A2-9.
Patch defect or pre-existing issue: patch defect. The A2-9 repair checks
  the rules but not the JobACL.
```

```text
AUDIT FINDING
ID / Type / Severity: A4-2 / correctness (least-privilege token check) / low
Current contract or strategic target: ES holds a least-privilege client
  token with only the es-submit-v1 policy; check says "ES token is the
  es-submit-v1 client token"; provision keeps only a token of the
  designed shape.
Path and line: scripts/internal/nomad_acl.py:696-703 (check: Type, Policies,
  SecretID; Roles not read); :728 (observer: Policies only, no Type or
  Roles); :409-416 (ensure_client_token keep rule ignores Roles).
Evidence (Ran, both versions, probes/rolewiden2-*.txt):
  - A role is created with write in another namespace plus operator write.
  - It is added to ES's token: Policies stay [es-submit-v1], and the token
    now plans in the other namespace (HTTP 200).
  - check rc=0.
  - provision rc=0 and keeps the same token with the role. check passes
    again.
  - The same happens for the observer token.
  The role itself grants nothing in es-submit-v1, so the role probes
  rightly pass it.
Impact: ES's token, or the observer's, can quietly hold more than designed,
  and check and provision both report the designed state. Inference: a
  stolen ES token already reaches host root through INF-02, so this breaks
  the documented least-privilege claim more than it raises the worst case.
Required correction:
  - check refuses unless token-self has no Roles, for ES and for the
    observer, and the observer token's Type is client.
  - ensure_client_token keeps a token only if it has no Roles, so provision
    replaces such a token.
  - Add a test for each.
Uncertainty: none.
Patch defect or pre-existing issue: patch defect, present since part 1
  (round 02 missed it).
```

```text
AUDIT FINDING
ID / Type / Severity: A4-3 / documentation accuracy (part 2a known limits) / low
Current contract or strategic target: the docs' known limits of the lock,
  INF-02's record of what ES's token can do.
Path and line:
  - .docs/system_overview/configuration.md:699-704 ("…but with Docker
    volumes enabled and the task user 0:0 a stolen ES token can still mount
    host paths into a container as root");
  - es/app/nomad_supported_config_test.go:198-202 (comment);
  - the PR body's "Known limits".
Evidence (Ran, both versions, probes/jobprobe-*.txt): with ES's token and
  the supported limits, all of these are placed and run:
  - network_mode = "host" (the container sees the host's interfaces,
    including loopback services such as Nomad's own API; the A4-1 demo
    used it);
  - security_opt = ["seccomp=unconfined"] (Seccomp: 0);
  - devices (a host device node mapped into the container);
  - a read-only bind of /;
  - pid_mode = "host", on Nomad 2.0.0, the box's version. Nomad 2.1.1
    refuses it ("cannot apply pid_mode configuration").
Impact: the docs say the remaining exposure is host-path mounts, so a reader
  plans INF-02's long-term fix around mounts. Inference: INF-02's option (a),
  host volumes with volumes.enabled = false, would close mounts but leave
  host networking, devices, seccomp and (on 2.0.0) the host PID namespace.
Required correction: in these three places, list the job-shape options the
  Docker limits do not refuse (host network, devices, security_opt, host PID
  on Nomad 2.0, host bind mounts), or say that only privileged mode, extra
  capabilities and other drivers are refused. Outside the PR, the
  coordinator adds these to the INF-02 record.
Uncertainty: I checked only whether each shape runs, not how far each one
  reaches. Nomad's Docker plugin has no allowlist for these options
  (Inference from its configuration; not verified for every version).
Patch defect or pre-existing issue: patch defect (part 2a's docs). The
  exposure itself is pre-existing (INF-02).
```

```text
AUDIT FINDING
ID / Type / Severity: A4-4 / test coverage (part 2a readiness) / low
Current contract or strategic target: configuration.md:589 says readiness
  (10_health_check.sh, bring-up and supported-local setup) refuses a Nomad
  without the supported limits.
Path and line: scripts/internal/bringup.sh:302-303 (check_nomad_ready_once
  calls nomad_runtime_posture_check; 10_health_check.sh:78 and bring-up
  use it).
Evidence:
  - Ran, mutant P13: check_nomad_ready_once ignores a posture refusal
    (`nomad_runtime_posture_check … || true`). It survives every focused
    test.
  - Ran, mutant P14: the same mutant against a wide set (TestHealthCheck,
    TestBringup, Posture, Readiness, Nomad, NomadACL). Its only failure is
    the full-profile bring-up, which fails in this container on the
    unmutated tree too, at the control-plane image build.
  - Read: the full-profile test and TestHealthCheckScriptRejectsPreManagedDevNomad
    both use an agent with the supported limits, so neither can see this
    mutant. The full-profile test's posture-line assertion
    (operator_scripts_integration_test.go:396) catches the call being
    removed (mutant P6), not its refusal being ignored.
  - Only supported-local setup's refusal is tested (P7 and P8 killed by
    TestSupportedLocalSetupLocksNomadBeforeProofEffects).
Impact: a later change could make bring-up and the health check accept a
  Nomad that allows privileged containers, and no test would fail.
Required correction: a test that check_nomad_ready_once, or
  10_health_check.sh against a stand-in agent, refuses an agent with
  allow_privileged = true (one loosened case is enough; the posture check's
  own test covers the rest).
Uncertainty: none.
Patch defect or pre-existing issue: patch defect (part 2a test gap).
```

### Observations (no change required)

- **O4-1. Variables are outside the probe (Ran, Read).** A policy that
  grants only `variables` write in `es-submit-v1` passes provision and
  check. Its token gets 403 on both probes, yet writes a variable there
  (HTTP 200; `probes/drift4-*.txt`). ES's job specs read no Nomad
  variables: `es/admission/submit.go` and `lifecycle.go` build tasks with
  no templates. So today this does not touch ES's jobs. Three places say
  "any capability", which is broader than what the probe covers:
  `nomad_acl.py:21`, `nomad_acl.py:782` and `configuration.md:655`. If the
  writer is in these lines for A4-1 and A4-2, "any job capability" would be
  accurate.
- **O4-2. One defensive branch is untested (Ran).** Mutant T10 survives: an
  unreadable token expiry treated as expired, which fails open. Nomad
  always sends RFC 3339, so the branch is defensive. A one-line test would
  pin it.
- **O4-3. The merge carries one extra edit (Read).** Merge `7aaac66` adds
  one docs sentence beyond the conflict resolution, in `PLANS.md`. It is
  harmless, and recorded here so the merge tree is fully explained.
- **O4-4. The capability-ablation claim holds under CI (Read).**
  `configuration.md:585` and `nomad_supported_config_test.go:25` say
  removing any capability fails the tests. The writer's §6 shows that
  removing `kill` fails one test and removing `dac_override` makes the tests
  skip. CI's skip gate fails an unlisted skip, so the claim holds in CI.
- **O4-5. trunk_dev has moved (Ran).** It is now at `fdfa3bc` (PR #29), and
  GitHub reports PR #31 as "behind". Updating the branch is the merge gate's
  step. The PR #12 line must re-run its guards when it takes trunk_dev.
- **O4-6. Two posture-check mutants survive, harmlessly (Ran).**
  - P5: duplicate `docker` plugin entries are accepted. Nomad reports one
    entry per plugin (Inference), so the case cannot happen.
  - P12 compares capability names case-sensitively. No test uses
    upper-case names, and the mutant is stricter, not weaker.

## Validation assessment

All runs at `c3a94ae` in this container (Go 1.26.5, `GOTOOLCHAIN=local`),
as user `ci` unless marked root. Evidence: `tests/`, `mutants/`, `ci/`.

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | pass (Ran) |
| `go test -race ./es/admission/ ./es/config/ ./internal/observability/` | pass (Ran) |
| focused tests (ACL tool, posture, real Docker limits, setup-locks, readiness, script guards; G1's transport test) | all pass; the sudo-reruns test skips as `ci` (Ran) |
| full `go test ./es/app/` | 191 pass, 2 fail, 2 skip (Ran). The failures are the full-profile bring-up (its control-plane image build fails in this container, as on earlier heads) and the CI-listed `TestSubmitFlowMountsGovernedArtifactAndLifecycleWithInstalledSourceIdentity`. Both skips need root |
| the two root-only tests, as root | `TestNomadACLSetupWrapperChecksWithTheManagementToken` passes. `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` gets through Nomad ACL provision, check and the posture check (prints the supported posture line), then fails at the Vault dev listener, a container limit seen on base in round 02 (Ran) |
| root package `go test .`, head vs base `76c030f` | 27 failures at both, the same 27; none new; one new test passes (Ran) |
| CI run 45267764672, head `c3a94ae` | job "build, vet and test" success; all 16 listed tests still fail as listed; no `.github` change against base (Read via the GitHub API) |
| probes on Nomad 2.1.1 and 2.0.0 | see "Findings" (Ran) |

Mutants, one at a time in a scratch clone, against focused tests (Ran,
`mutants/mut3.txt`, `mutants/mut3b.txt`). The tree was clean after each
batch.

| Mutant | Result |
| --- | --- |
| T1 namespace probe removed; T2 plan probe removed; T3 only 200 counts as a grant | killed |
| T4 observer exempt by name; T5 roles not probed; T6 probe token not deleted | killed |
| T7 no ES-policy holder check; T8 no observer-policy holder check; T9 holders count expired tokens | killed |
| T10 unreadable expiry counts as expired (fails open) | **survived** (O4-2) |
| T11 no ES rules check in check; T12 no observer rules check with the observer token | killed |
| T13 no other-management-token check; T14 no auth-method check; T15 check skips exclusivity | killed |
| T16 provision probes before writing its policies; T17 provision skips exclusivity | killed |
| G1 default transport; U1 wrapper check without the management token (root); S5 `nomad_api_get` without `--noproxy`; S6 placement overlap removed | killed |
| P1 privileged unset accepted; P2 any capability accepted; P3 allowlist ignored; P4 Docker default capabilities accepted | killed |
| P5 duplicate docker entries accepted | **survived** (O4-6, unreachable) |
| P6 readiness does not call the posture check | survived the focused tests. Killed in CI by the full-profile bring-up's posture-line assertion (Read), which cannot run here |
| P7 setup 72 skips the posture check; P8 setup 72 ignores a posture failure | killed |
| P9 setup 70 allows privileged; P10 `nomad.hcl` 0644; P11 gc list normalisation removed | killed |
| P12 case-sensitive capability names | **survived** (O4-6, stricter) |
| P13/P14 readiness ignores a posture refusal | **survived** (A4-4) |

Not re-run: Nomad 2.0.0 for the full es/app suite (the writer ran its
focused tests and the bring-up on 2.0.0, and my probes cover the lock and
the limits there). The `reliablesubmit` package (untouched by this PR).

Closing manifest (Ran): after the audit artifacts were removed (probe
agents stopped, their directories and leftover containers deleted), the
recipe ran three more times with HEAD at base. The third run came after a
last short probe run on fresh agents, which were then removed too. All
three are byte-identical to the opening manifest (`0336e0bf…e8cbb7`).
HEAD is back at `c3a94ae` with a clean tree
(`provenance/manifest-close-*.json`).

## Sensitive-material handling

The probe agents' management, ES and observer tokens stayed in their
mode-0600 files in the container. Probes print only HTTP statuses, return
codes and refusal texts. The JobACL task printed only an HTTP status and
whether a token was present, never the token.

Before I wrote SHA256SUMS, I scanned the evidence folder for UUID-shaped
strings and for the word "SecretID". Every Nomad secret is UUID-shaped, so
the first scan covers them all. I deleted the probe agents' token files
before this scan, so I did not also search for each secret by value.

- The only UUIDs found were one evaluation ID and one accessor ID in each
  `competing3-*.txt` file. Neither is secret, and both are now replaced
  with `<uuid>`. The same was done for the accessor IDs in
  `tests/root-only-as-root.txt`.
- "SecretID" appears only as a field name in two probe scripts, which read
  it into memory and never print it.
- Agent configuration dumps are not included.

No personal data left the container.

## Remaining uncertainty and stop conditions

- The namespace-read probe relies on Nomad answering 200 for any job
  capability in the namespace. I observed this for every capability tried,
  on both versions. Variables are the known exception (O4-1).
- I did not run the real setup test end to end here. As root it gets
  through the Nomad lock and the posture check, then stops at the Vault dev
  listener. The CI run is the evidence for the rest.

## Confidence

- Provenance: high (two identical opening runs equal to the writer's;
  three closing runs equal).
- Validation: high for the tool, the posture check and the Go packages on
  both Nomad versions. Medium for setup scripts end to end (container
  limits, CI evidence).
- Implementation: high that A2-8, A2-9 and A2-10 are fixed and part 2a's
  limits hold. A4-1, A4-2 and A4-3 are reproduced on both versions, and
  A4-4 by mutation.

## Effect status

No repair, commit, push, PR comment, review or merge was performed. Nothing
outside this container was changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/04-re-audit.md`;
sha256 in the delivery message. Evidence checksums in
`04-re-audit-evidence/SHA256SUMS.txt`.

## Final verdict

**BLOCK**

Fix A4-1, A4-2, A4-3 and A4-4 (all Low), with the tests named there. O4-1's
wording fix is optional. Per §14, a fresh audit then takes the repaired
head. A narrow one covers it: the token and policy checks in
`nomad_acl.py`, their tests, the readiness test and the doc lines.
