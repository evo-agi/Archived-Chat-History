# Byte check of ES draft PR #31 (Nomad lock) at c5115b4

Verdict: **ACCEPT**. `c5115b4` adds only trunk_dev `6ce0034` (PR #42) to
the head I accepted in recheck 09 (`0f596c0`), so that verdict carries
over to it.

- The merge's tree equals a fresh `git merge-tree` of its parents, with no
  conflicts (Ran).
- For all 52 PR files, the added and removed lines against base are
  identical to those at `0f596c0` against `523648c` (Ran).
- The v2 manifest reproduces twice, equal to the writer's (Ran).
- Build, vet, 35 focused es/app tests on Nomad 2.1.1 (the 09 set plus
  PR #42's port tests and its log-tail test), the Docker limits test on
  2.0.0 and the access-control submit test all pass (Ran).
- CI run 45308238907 on `c5115b4` (started 01:52Z) was still running when
  I closed this check at 02:00Z; the gate must see it green.

Statements are marked **Ran**, **Read** or **Inference** as in 09. Evidence
paths are relative to `10-byte-check-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Target

- Repository: evo-agi/Execution-Substrate, draft PR #31, branch
  `claude/project-thread-9slgp8`.
- Base: `6ce00347c6d3d90d8d11649e925927f539437f74` (trunk_dev after PR #42;
  the merge-base).
- Topic: `c5115b488ac22da1d39c37bf7f4bf85b0f6d1d4d`, tree
  `8d180f258efd9eb14a6beb6c0ead4ae8f9821591`, parents `0f596c0` (accepted
  in 09) and `6ce0034`. It is the pushed branch tip (Ran, fetch).
- Recipe `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2…a3ca` (verified). textual_diff_sha256
  `7498b2f4b0eb364a5dc1f7873a5c8b49abcc210e0b1d308c3abde4796eeba06d`;
  manifest_sha256
  `41190b10ab963f5690bff54f7f9bd7ab45e08f9fa5304168e856e2bc6579448b`; 52
  paths.
- Scope: the writer's request (01:52Z) for the byte check that recheck 09
  set for a later trunk_dev merge. At 02:00Z the writer said the
  coordinator does not need it; the checks were already done, so this
  records them for the gate. Writer's manifest:
  `08-evidence/manifest-v2-c5115b4.json`.

## Checks

**Merge (Ran).** `git merge-tree --write-tree 0f596c0 6ce0034` gives
`8d180f25…`, the committed tree. No conflicts. No `.github` path differs
between base and head.

**PR lines (Ran, `provenance/pr-lines-compare.txt`).** The PR path set is
the same 52 paths at both heads, and no file's added or removed lines
differ between `523648c..0f596c0` and `6ce0034..c5115b4`.

**Manifest (Ran).** With HEAD at `6ce0034` (`reset --mixed`), upstream
`origin/trunk_dev`, two runs at `umask 022` are byte-identical and equal
to the writer's copy (`provenance/manifest-open-run{1,2}.json`). After the
tests, two closing runs were byte-identical to the opening ones, and every
clone is clean.

**What PR #42 brings into the PR's files (Read).** PR #42 changes two
files this PR also changes:

- `es/app/operator_scripts_integration_test.go`: the bring-up test's
  failure messages now append `bringupLogTails`, the last 40 lines of each
  `*.log` directly under bring-up's `logs/`, plus that helper's own test;
- `es/app/submit_integration_test.go`: the socket test root path.

Its other file, `es/app/test_ports_test.go`, changes how test ports are
reserved; this PR's tests call `reserveTCPPortValue`, whose signature did
not change (writer's commit message; Read).

`bringupLogTails` could print bring-up's service logs into CI's public log
on a failure. This PR's ACL material does not go there: bring-up keeps the
token files in `BRINGUP_DIR/nomad-acl` (`bringup.sh:469-471`), not in
`logs/`; the provisioning tool prints accessor IDs only (09 and earlier);
and a grep of ES's Nomad access code and es/app's non-test code finds no
log or print of the token (Ran). So the two PRs together print no
token (Inference from those reads).

## Validation (Ran, as user `ci`, at c5115b4)

| Run | Result |
| --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | pass (Ran, `tests/build-vet.txt`) |
| focused es/app on Nomad 2.1.1: the ACL tool, real-Nomad, posture, readiness and setup-lock tests from 09, `TestSubmitRefusesANomadThatDoesNotEnforceACLs`, PR #42's port tests and `TestBringupLogTailsShowsTheEndOfEachLog`, and the PR-touched readiness tests in the shared file | 35 pass; the root-only wrapper test skips as `ci` (Ran, `tests/focused-211.txt`) |
| `TestRealNomadOffersOnlyTheLimitedDockerDriver` on Nomad 2.0.0 | pass (Ran, `tests/rt1-200.txt`) |
| the access-control submit test in es/admission | `TestSubmitRefusesBeforeRunAssignmentWhenNomadAccessControlFails` passes (Ran, `tests/admission-gate.txt`) |
| CI run 45308238907 | in progress at 02:00Z (Read, GitHub API; `ci/run-45308238907.txt`) |

Not run: the full-profile bring-up (its control-plane image build fails in
this container; the writer ran it with an image rebuilt from this tree, and
CI runs it); the full suites, since PR #42 changes test code only.

## Sensitive material

The evidence holds test names, results and manifests. Scan for UUID-shaped
strings and "SecretID": none. No personal data left the container.

## Effect status

No commit, push, PR comment, review or merge. Nothing outside this
container changed.

## Final verdict

**ACCEPT**

For the merge gate: the PR head must equal `c5115b4`, CI must be green on
it, and the PR is squash-merged (09, O9-1). If trunk_dev moves again, the
next merge gets this same check.
