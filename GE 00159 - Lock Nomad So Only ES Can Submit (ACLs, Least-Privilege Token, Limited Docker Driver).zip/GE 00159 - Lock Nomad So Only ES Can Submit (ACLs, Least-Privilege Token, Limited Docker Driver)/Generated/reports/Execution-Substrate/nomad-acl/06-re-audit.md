# Narrow re-audit of ES draft PR #31 (Nomad lock) at b150657

Verdict: **ACCEPT**.

- A4-1, A4-2, A4-3 and A4-4 are fixed, and the round 04 observations they
  touched are addressed.
- Each fix was checked on Nomad 2.1.1 and 2.0.0 where it applies, and
  pinned by tests that kill its mutants.
- The writer's fix to its own access-control test is sound: the test
  still guards the gate.
- Both trunk_dev merges are clean, and there are no new findings.
- The head pushed during the audit, `6d1346f`, adds only trunk_dev, with
  one conflict resolved correctly, so this verdict covers it too. Its CI
  run was still running when I wrote this.

Every statement is marked **Ran** (I executed it and saw the output),
**Read** (I read code, docs or logs) or **Inference** (reasoned from cited
facts, not observed directly). Evidence paths are relative to
`06-re-audit-evidence/`.

```text
INDEPENDENT AUDIT REPORT
```

## Repository / audit target

- Repository: evo-agi/Execution-Substrate, draft PR #31, branch
  `claude/project-thread-9slgp8`.
- Base: `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` (trunk_dev after PR #33;
  the merge-base).
- Topic: `b15065754d986ae546cb0fe65f9204cb30aec699`, tree
  `083fd0a122a2d077fee28955a4136042a1287d36`. It was the PR head when I
  started (Ran, GitHub API). The head is now `6d1346f`, a trunk_dev merge
  the writer pushed during this audit. I checked it in its own section,
  "Head 6d1346f", so this verdict can bind it.
- Recipe: `governed-execution.audit-patch-manifest.v2`, source sha256
  `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`
  (verified).
- textual_diff_sha256
  `b631a3f126ba61e199738203421fa074a786f25103a4d012d5b5b44ad08d81a9`;
  manifest_sha256
  `ecdd778af0591acfed80d710ae50c930c1767b336e4cd504c762c5e92b3fe241`;
  52 changed paths.
- Scope (coordinator, 23:47Z), the delta `c3a94ae..b150657`:
  - `2b0d712`: the repair of A4-1 to A4-4, plus O4-1 and O4-2;
  - `4e2bdad`: the writer's fix to its own access-control submit test,
    which broke when PR #29 merged in;
  - two clean trunk_dev merges: `e323533` (PR #29, #36) and `b150657`
    (PR #33).

  The coordinator is updating the INF-02 record in
  `infra-security-audit.md` itself.
- Writer's report: `05-repair.md`. The sha256 was
  `db1db660cb025d844d621943cbef916557b68c49305315f1104bfd37c09e87a9`. After
  the writer added section 7 for `6d1346f`, it is
  `a8cb9e0d700cfeffd89f30872d8876d7e331b5ea903a2b7deba418ea3d441a46`.

## Audit posture

I made no change to the repository or the PR: nothing was committed,
pushed or commented. I used no subagents. I did not touch the box or any
live service. Everything ran in this container:

- local clones;
- disposable Nomad dev agents, 2.1.1 on port 24646 and 2.0.0 on port 25646,
  with ACLs and the supported Docker limits;
- the local Docker daemon.

I ran mutants one at a time in a scratch clone and restored the file after
each run. The container's test user `ci` has no sudo, so root-only tests
ran as root directly, as in earlier rounds.

## Provenance reproduction (Ran)

- I reused my audit clone. It was clean, and I fetched the branch and
  trunk_dev from GitHub into it.
  - The pushed tip equals the reported tip.
  - Base `0aa4a2b` is an ancestor and the merge-base.
  - The checkout was clean. I ran `reset --mixed` to base with upstream
    `origin/trunk_dev`, then ran the recipe twice at `umask 022`.
- The two runs are byte-identical, and equal to the writer's
  `05-evidence/manifest-v2-b150657.json`. The path set equals the
  committed `0aa4a2b..b150657` path set (52).
- Both merges equal a fresh `git merge-tree --write-tree` of their parents,
  with no conflicts:
  - `e323533` (`c3a94ae` + `400ff7f`), tree `c2f6c169…`;
  - `b150657` (`4e2bdad` + `0aa4a2b`), tree `083fd0a1…`.
- No `.github` file changes between base and head.
- Closing manifest: see "Validation assessment".

## Coverage

- Read:
  - the repair diff `e323533..2b0d712`: `nomad_acl.py`, the ACL tool
    tests, the readiness test in
    `es/app/supported_local_execution_roots_test.go`, the comment in
    `nomad_supported_config_test.go`, and `configuration.md`;
  - `4e2bdad`, and the whole adapted test;
  - the writer's report and the PR body.
- Ran:
  - the round 04 probes again on both Nomad versions (JobACL with a live
    workload, token roles, policy drift, each narrow grant alone, the
    competing-grant set);
  - 12 mutants;
  - build and vet, and the race tests for es/admission, es/config and
    observability;
  - full es/app, and the root package against base.
- Read through the GitHub API: the CI run's metadata.
- Not inspected: the trunk_dev changes themselves (PR #29, #33 and #36 were
  audited in their own threads). I checked only that the merges are clean.
  Part 2b.

## Findings

### Round 04 findings: all fixed

**A4-1 (JobACL on the lock's own policies): fixed (Ran, Nomad 2.1.1 and 2.0.0).**

- `require_designed_policy` now refuses a policy whose `JobACL` is set
  (`nomad_acl.py:633-637`). The observer exemption requires no JobACL
  (`is_designed_policy`, `:487`). `upsert_policy` writes `"JobACL": null`.
- Live replay (`probes/jobacl-*.txt`):
  - without the JobACL, the workload's own identity gets 403;
  - with it set, check refuses ("the es-submit-v1 policy has a job ACL…");
  - provision clears it, and the workload gets 403 again.

  While the JobACL is set the workload can still register a job (HTTP 200).
  That is Nomad's behaviour. check reports the drift and provision repairs
  it, as for the other drift A2-9 covers.
- The same holds for the observer policy (`probes/drift4-*.txt`).
- Mutants R1 (check ignores the JobACL) and R2 (the exemption ignores it)
  are killed.

**A4-2 (roles on the lock's own tokens): fixed (Ran, both versions).**

- check refuses an ES or observer token with roles, and an observer token
  that is not a client token (`nomad_acl.py:719-729`, `:754-765`).
- `ensure_client_token` keeps a token only if it has no roles (`:424`).
- Replay (`probes/rolewiden3-*.txt`): the role gives ES's token write in
  another namespace (plan HTTP 200), and check refuses. provision writes a
  new token with no roles and deletes the old one (lookup 404); check then
  passes. The same holds for the observer token.
- Mutants R4, R5, R6 and R8 are killed.

**A4-3 (Docker limits docs): fixed (Read).**

- `configuration.md:705-718`, the comment above
  `TestRealNomadOffersOnlyTheLimitedDockerDriver` and the PR body's known
  limits now list:
  - host bind mounts (with `/` and task user 0:0);
  - `network_mode = "host"`;
  - `devices`;
  - `security_opt`;
  - `pid_mode = "host"` on 2.0.0 only.

  The docs say the limits refuse only privileged containers, extra
  capabilities and other drivers. This matches my round 04 job probes.

**A4-4 (readiness test): fixed (Ran).**

- New `TestSupportedLocalFullReadinessRefusesALoosenedNomadAgent`
  (`es/app/supported_local_execution_roots_test.go:393`) runs three paths
  against a stand-in agent that allows privileged containers:
  - `01_bringup.sh check`;
  - `10_health_check.sh`;
  - `10_health_check.sh`'s wait loop.

  Each must refuse with the posture message, before any Docker step and
  without changing anything.
- Mutants R10 (readiness ignores a posture refusal, round 04's P13) and R11
  (readiness does not call the posture check, round 04's P6) are both
  killed by it.

**O4-1 and O4-2: addressed (Read, Ran).**

- O4-1: the tool and the docs now say "any job capability", and that
  variables are not judged because ES's jobs read none. A variables-only
  grant still passes (`probes/drift4-*.txt`), as now documented.
- O4-2: a fake-Nomad case pins an unreadable expiry as live, and mutant R9
  is killed.

**`4e2bdad` (the writer's fix to its own test): sound (Read, Ran).**

- PR #29 makes ES verify every ARS blob against its digest. The test's
  fixture now carries the served policy payload's digest, so the submit
  reaches the access-control check instead of refusing earlier at the
  policy input.
- The assertions are unchanged:
  - the exact 503 access-control message;
  - no result;
  - zero job requests;
  - an empty staging root.
- The test passes. Mutant R13 removes the access-control gate from
  `Submit`, and this test kills it, so it still guards the gate.

**Regression (Ran, both versions).** No regressions: every grant form from
rounds 02 and 04 is still refused, each narrow grant alone is refused and
named, widened rules are still caught, and the designed exceptions still
pass. No probe token is left behind (`probes/competing3-*.txt`,
`narrow-*.txt`, `drift4-*.txt`).

### New findings

None.

### Observations (no change required)

- **O6-1. The new observer SecretID comparison is untested (Ran).** The
  repair also added `document.get("SecretID") != observer` to the observer
  check (`nomad_acl.py:760`). Mutant R7, which removes it, survives. The
  line is defensive: `require_acl_enabled` runs first, and Nomad's
  token-self answer carries the secret it was asked with. The ES-side twin
  is tested (R12 killed). One fake-Nomad case would pin this one too.
- **O6-2. The writer's equivalent mutant is confirmed equivalent (Ran).**
  A1c (R3 here) has provision omit `"JobACL": null`, and it survives. My
  round 04 run at `c3a94ae`, whose provision did not send the field,
  already showed provision clearing a JobACL on both versions
  (`04-re-audit-evidence/probes/drift4-*.txt`). Nomad replaces the whole
  policy on write, so the explicit null documents intent and changes no
  behaviour.

## Head 6d1346f (trunk_dev merge pushed during this audit)

The writer merged trunk_dev `42db339` (PR #41 and PR #37) and pushed
`6d1346fa792c6a4f78589c86d97835832ce610ac`, tree
`865e74d1545461acebe5f6b1c494b85187a5882d`. The writer asked me to keep the
re-audit on `c3a94ae..b150657`. I did that, and I also checked this merge
so the merge gate has an audited head (Ran, `provenance/6d1346f-*`):

- **Manifest.** I ran the recipe twice with HEAD at base `42db339` (the
  merge-base). Both runs equal the writer's
  `05-evidence/manifest-v2-6d1346f.json`: manifest_sha256
  `a0ce1b2fbc6e3ec40b7412cd99a0529025624e8ee13522b03998624c3ac5a654`,
  textual_diff_sha256
  `e7d5c261353eb7dd3035ae4bc23066e1e976add82b9337d2bedda2e8e1e76008`, 52
  paths. The path set equals the committed one.
- **What changed from b150657.**
  - The files changed in `b150657..6d1346f` are exactly trunk_dev's
    `0aa4a2b..42db339` (9 files).
  - Against its own base, the PR's added and removed lines are identical
    at both heads.
  - Comparing the two manifests, only two of the PR's 52 files differ in
    bytes: `.runbooks/system/v1_bringup.md` and
    `scripts/70_linux_setup.sh`. In both, the only difference is trunk_dev's
    renamed runbook paths.
- **The one conflict.** It is in `scripts/70_linux_setup.sh`'s next-steps
  echo lines. The committed resolution takes trunk_dev's quoted, renamed
  runbook path for step 3 and keeps this PR's step 4 (lock Nomad). That is
  the only difference from a fresh `git merge-tree` of the parents, and it
  is the correct resolution (Read).
- **Stale paths.** Nothing in the head tree, `PLANS.md` aside, still
  names the old runbook paths. The PR adds none.
- **Tests at 6d1346f, all pass** (`tests/6d1346f-tests.txt`):
  - PR #37's runbook-path tests (`TestMarkdownRelativeLinksResolve`,
    `TestRunbookPathMentionsExist`, `TestMarkdownLinkTargetsReadsEveryLinkForm`);
  - the setup-script tests;
  - the ACL tool tests;
  - the readiness tests.
- **CI.** Run 45295052462 on `6d1346f` (started 00:11Z) was still running
  at 00:30Z (Read, GitHub API; `ci/run-45295052462.txt`). No `.github` path
  differs between `b150657` and `6d1346f`, or between `42db339` and
  `6d1346f` (Ran). The merge gate must see it green.

So the A4 repair verdict carries over to `6d1346f` (Inference from the byte
comparison above, plus the tests run there).

## Validation assessment

All runs in this container (Go 1.26.5, `GOTOOLCHAIN=local`), as user
`ci` unless marked root. Evidence: `tests/`, `mutants/`, `ci/`.

| Run | Head | Result |
| --- | --- | --- |
| `go build ./...`, `go vet ./...`, `GOOS=darwin go vet ./...` | b150657 | pass (Ran) |
| `go test -race ./es/admission/ ./es/config/ ./internal/observability/` | b150657 | pass (Ran) |
| focused tests: ACL tool, readiness (including the new test), posture, Docker limits, setup locks, script guards | b150657 | 23 pass. The sudo-reruns test skips as `ci` and passes as root (Ran) |
| the adapted `TestSubmitRefusesBeforeRunAssignmentWhenNomadAccessControlFails` | b150657 | pass, both cases (Ran) |
| full `go test ./es/app/` | b150657 | 192 pass, 2 fail, 2 skip (Ran). The failures are the two known environment failures here: the full-profile bring-up's control-plane image build, and the CI-listed mount witness. Both skips need root |
| root package `go test .`, head vs base `0aa4a2b` | b150657 | the same 27 failures at both; none new; one new test passes (Ran) |
| runbook-path, setup-script, ACL tool and readiness tests | 6d1346f | all pass (Ran) |
| CI run 45286938875 | b150657 | job "build, vet and test" success; no `.github` change against base (Read via the GitHub API) |
| CI run 45295052462 | 6d1346f | in progress at 00:30Z (Read via the GitHub API) |
| probes on Nomad 2.1.1 and 2.0.0 | b150657 | see "Findings" (Ran) |

The container restarted once during the full es/app run. I restarted the
Docker daemon and ran the full suite and the root package again from the
start. The build, vet and race results from before the restart were
complete and are kept.

Mutants, one at a time in a scratch clone at b150657 (Ran,
`mutants/mut4.txt`, `mutants/mut4b.txt`). The tree was clean after each
batch.

| Mutant | Result |
| --- | --- |
| R1 check ignores a JobACL on its policies | killed |
| R2 observer exemption ignores a JobACL | killed |
| R3 provision omits `"JobACL": null` (writer's A1c) | survived; equivalent (O6-2) |
| R4 check ignores roles on the ES token; R5 on the observer token | killed |
| R6 check ignores the observer token's type | killed |
| R7 check ignores the observer token's SecretID | **survived** (O6-1, defensive) |
| R8 provision keeps a token with roles | killed |
| R9 unreadable expiry counts as expired (O4-2) | killed |
| R10 readiness ignores a posture refusal (A4-4); R11 readiness does not call the posture check | killed |
| R12 check ignores the ES token's SecretID | killed |
| R13 `Submit` skips the access-control gate (the `4e2bdad` test) | killed |

Not re-run: the full suites on Nomad 2.0.0 (the probes cover the lock
there, and the writer ran the real-Nomad set on 2.0.0). The full-profile
bring-up (container limit). The full suites at `6d1346f`, whose bytes
differ from b150657 in the PR's files only by trunk_dev's runbook paths.

Closing manifests (Ran): after the probe agents were stopped and their
directories removed, the recipe ran twice more for each head with HEAD at
its base:

- `b150657` at `0aa4a2b`;
- `6d1346f` at `42db339`.

Every closing run is byte-identical to its opening run. The audit clone is
back at `6d1346f`, clean (`provenance/`).

## Sensitive-material handling

The probe agents' tokens stayed in mode-0600 files in the container. The
probes print only HTTP statuses, return codes and refusal texts. The
JobACL task printed only an HTTP status and whether a token was present.

Before I wrote SHA256SUMS, I scanned the evidence folder for UUID-shaped
strings (every Nomad secret is one) and for the word "SecretID":

- The only UUIDs were non-secret accessor and evaluation IDs. I replaced
  them with `<uuid>`.
- "SecretID" appears only as a field name in probe scripts.

No personal data left the container.

## Remaining uncertainty and stop conditions

- The namespace-read probe judges job capabilities only. Variables are not
  judged; the docs now say so, and ES's jobs read none.
- I did not run the full-profile bring-up here: the control-plane image
  build fails in this container. The writer's offline run and CI cover it.

## Confidence

- Provenance: high. Both heads: two identical opening runs equal to the
  writer's manifest, closing runs equal, merges match a fresh merge-tree or
  are fully explained.
- Validation: high for the tool and the readiness checks on both Nomad
  versions and for the Go packages. Medium for setup scripts end to end
  (container limits; CI evidence).
- Implementation: high that A4-1 to A4-4 are fixed and nothing regressed.

## Effect status

No repair, commit, push, PR comment, review or merge was performed. Nothing
outside this container was changed.

## Report delivery

`/mnt/project-files/reports/Execution-Substrate/nomad-acl/06-re-audit.md`;
sha256 in the delivery message. Evidence checksums in
`06-re-audit-evidence/SHA256SUMS.txt`.

## Final verdict

**ACCEPT**

For the merge gate:

- The PR head must equal an audited commit: `b150657`, or `6d1346f`
  (covered by the section "Head 6d1346f").
- CI must be green on that head. Run 45295052462 for `6d1346f` was still
  running when I wrote this.
- trunk_dev may have moved again. A later trunk_dev merge gets the same
  byte check as `6d1346f`.

The red-team, where the project requires one, and David's go come next.
