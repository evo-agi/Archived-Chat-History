# Audit of ES draft PR #31 (Nomad lock, part 1): DRAFT on 6270d7d, no verdict yet

SUPERSEDED: the final report is `02-audit.md` in this folder (target
78fd064, verdict BLOCK). This draft stays as the record of the first pass.

STATUS OF THIS FILE: interim. The coordinator asked (18:37Z) that 6270d7d be
audited together with the writer's coming CI repair commit. This draft records
what was checked on 6270d7d so far. The final report, with exactly one verdict,
will be `02-audit.md` in this folder, after the repair commit has its own
manifest and audit. Nothing here is a verdict.

Every finding is marked **Ran** (I executed it and saw the output), **Read**
(I read code, docs or logs) or **Inference** (reasoned from cited facts, not
observed directly).

## 1. Target

- Repository: evo-agi/Execution-Substrate, draft PR #31
- Base: `036d50724b499b020c5149c55ad902cfcb1482c0` (origin/trunk_dev, unchanged at 18:14Z)
- Topic: `claude/project-thread-9slgp8` at `6270d7d008a35286d4aa38315f0a035fc12df6df`, tree `2c121088ac19d1d548a08f75dbbc94dce6aba108`
- Recipe: v2, source sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (verified before use)
- Writer's report: `01-implementation.md`, sha256 `7fb42d71b1c9960c16e17f1a9a74da9b200f69662304b581c2f15b6a6503ac7a` at 18:43Z

## 2. Provenance (Ran)

Fresh clone, `umask 022`, the §5.3 recipe: pushed tip equals the reported tip,
base is an ancestor, clean checkout, `reset --mixed` to base, upstream pinned to
origin/trunk_dev, two runs.

- textual_diff_sha256 `48849a2816dfad2f44c5907108cd55ff9619240970b827913c2c1a5c65dfffd2`
- manifest_sha256 `2bea085838dbe331681ba2b3286e5d7f42f69da4e002bb43cbee80e2e94495d0`, 42 files
- The two runs are byte-identical, and byte-identical to the writer's
  `01-evidence/manifest-v2-6270d7d.json`. Committed path set = 42.
- Closing run (after all probes, which ran in other copies) is byte-identical
  to the opening one. Evidence: `02-audit-evidence/provenance/`.

## 3. Findings so far (on 6270d7d)

### A2-1. High. Test/CI gap and report accuracy. Patch defect.

- **Ran / Read:** GitHub CI "build, vet and test" on 6270d7d (run
  45234772309, job 137903440643, 18:06:20Z to 18:20:17Z) **failed**: 6 es/app
  tests fail and 2 new es/admission tests skip themselves without a list entry
  (excerpt: `02-audit-evidence/ci/`). My full `go test ./es/app/` on 6270d7d
  (user ci 1500:1600, Nomad 2.1.1) reproduces the same 6 failures plus the 2
  known environment-only ones (`tests/head-es-app-full-summary.txt`).
- The 6: `TestSupportedLocalProofLogAssertionProjection`,
  `...SequentialCapturesAndLineage`, `...ResultValidationFinalizerContinuation`,
  `...AllocationExactCount`, `...SequentialAllocationFailureFinalizer`
  (proof capture now refuses an unset `NOMAD_TOKEN_FILE`), and
  `TestSupportedLocalSetupScriptBootstrapsRealSPIREAndVaultDevTarget` (the new
  ACL preflight finds no Nomad at the fixed 127.0.0.1:4646).
- On base 036d507 the first five pass in my container; the sixth fails there
  only for a container reason (no sudo for the test user), and passes on
  trunk_dev CI (`tests/base-036d507-six-ci-failures.log`).
- The 2 skips: `TestLoadNomadTokenRefusesAFileOwnedByAnotherUser` and
  `...AParentOwnedByAnotherUser` need root. As root they pass, and they kill
  mutants M15/M16 (owner checks removed); in any non-root run those mutants
  survive (`mutants/`).
- Report §6 says the full es/app run failed only the 2 known
  environment-only tests. That is not true of 6270d7d.
- The writer has said a repair commit for exactly these three causes is
  coming. **To check on the repair:** the fixtures give real tokens or a real
  ACL Nomad, not a bypass; no test is skipped or listed to make CI pass where
  it can be fixed; the owner checks still run somewhere in CI (a root step, or
  a seam that needs no root); report §6 is corrected.

### A2-2. Medium. Security risk (a fail-open check). Patch defect.

- **Ran:** `scripts/internal/nomad_acl.py` refuses "other ACL policies may
  grant access" by text matching only (`policy_names_that_may_grant_the_namespace`,
  lines 430-443: the literal `es-submit-v1` or `namespace "<…*…>"`). On real
  Nomad 2.1.1 and 2.0.0, I created five policies, each accepted by Nomad, and
  checked that a token holding it could register a job in `es-submit-v1`.
  Provision refused only the plain HCL glob. It accepted, without refusal:
  JSON `{"namespace":{"*":{"policy":"write"}}}`, JSON
  `{"namespace":{"es-*":{"capabilities":["submit-job"]}}}`, HCL
  `namespace "*"` and HCL `namespace "es-submit-v1"`
  (`probes/competing-*.txt`).
- Impact: the docstring says the check "never misses a plain grant", and
  configuration.md says provision refuses "when another policy could grant the
  namespace". Report §8 item 5 relies on it for the exclusive-writer qualification of
  PR 12's operational namespace. A second writer in `es-submit-v1` can exist
  unnoticed. Creating such a policy needs the management token, so this is not
  a tokenless path.
- Required: decide by Nomad's own evaluation, not by text. For example, for
  every policy (and role) other than the tool's two, mint a short-lived token
  that holds only that policy, plan the probe job in `es-submit-v1`, require
  403, then delete the token. Add tests for the JSON and escaped forms.
  Consider also reporting other management tokens, if "only client writer" is
  meant to cover them.

### A2-3. Low. Security risk. Patch defect.

- **Ran:** ES's real Nomad client (`newNomadClient`, submit.go:243-265) uses
  `http.DefaultTransport` behind the logging wrapper and no `CheckRedirect`.
  Against a Nomad address that answers 307 to another host, all 3 requests
  (token/self, job read, stop) reached the other host **with
  `X-Nomad-Token`** (`probes/redirect-probe.log`, probe test
  `probes/zz_audit_redirect_test.go.txt`). `nomad.base_url` accepts any host
  and http (config.go:462-471), and the default transport uses the environment
  proxy for a non-loopback host.
- Real Nomad does not redirect these API paths. So this matters with an
  impostor, a proxy or a load balancer at `base_url` (Inference). The repo's own
  tool (nomad_acl.py:88-93) and the mounted-source test harness already refuse
  redirects and proxies.
- Required: `CheckRedirect` returning `http.ErrUseLastResponse` (and treating
  3xx as a failure), no proxy for the Nomad transport, a regression test. The
  loopback restriction of `base_url` can land with part 2's HTTPS pinning, in
  this PR.

### A2-4. Low. Security risk. Patch defect.

- **Ran:** with `http_proxy` set, curl 8.5.0 and Python 3's default
  `urllib.request.urlopen` both send a request for `http://127.0.0.1:<port>`
  to the proxy, `X-Nomad-Token` header included. The tool's
  `ProxyHandler({})` opener does not (`probes/proxy-probe.txt`).
- **Read:** the token-carrying helpers without a proxy guard are
  70_linux_setup.sh `nomad_token_curl` and the bootstrap POST (management
  token and bootstrap secret), its embedded Python `urlopen` with the
  management token, scripts/internal/nomad_acl.sh `nomad_api_get` (observer),
  scripts/internal/bringup.sh `check_nomad_ready_once` Python (observer), and
  remote_alpha_runtime_security_boundary_check.sh `urlopen` (observer).
  `supported_local_proof_projection.py` already uses `ProxyHandler({})` and no
  redirects.
- Impact needs an operator environment with a proxy set (Unknown for the box).
- Required: `--noproxy '*'` on every token-carrying curl, `ProxyHandler({})`
  (and no redirects) in every embedded Python, a test.

### A2-5. Low. Security risk (incomplete guard). Patch defect.

- **Ran:** `validateNomadTokenFilePlacement` (config.go:491-500) accepted
  `/run/spire/sockets/es-token` with the SPIRE socket at
  `/run/spire/sockets/agent.sock` (`probes/placement-probe.log`).
- **Read:** every workload gets `filepath.Dir(spire_workload_api_socket_path)`
  as a read-only bind mount (executionpackage.go:283-288,
  resolved_execution_plan.go:404). Workloads run with task user `0:0`.
  **Inference:** with Docker's default capabilities, root in the container
  can read a 0400 file owned by `es`, so a token placed there would reach the
  workload. With INF-02, that reaches host root. 72's
  `nomad_acl_validate_dir_placement` has the same gap.
- Needs a misplacement by the operator (defaults use
  /etc/execution-substrate/nomad-acl). The guard's own stated purpose is to
  keep the token away from workload-visible paths.
- Required: add the SPIRE socket directory (and any other host path that is
  mounted into workloads) to both checks, with tests.

### A2-6. Low. Test gaps. Patch defect.

- **Ran:** mutants on 6270d7d (`mutants/`). Go, focused tests: 15 of 19
  killed. Of the 4 survivors, M15/M16 are the root-only owner checks (killed
  as root, see A2-1). M19 is redundant (the open uses O_NOFOLLOW anyway). M6
  (a non-200 token/self that echoes ES's secret) is close to equivalent. M3
  rewritten to compile: killed. Scripts: 10 of 19 killed. Survivors: `check`
  ignoring the ES token's policies (P3) or Type (P15), skipping its
  anonymous-plan (P4, redundant with the anonymous-policy check), ES-default
  (P5), nodes (P6) and observer-plan (P7) probes; provision keeping an existing
  token whatever its policies (P12); the tool following redirects (P13); S1 is
  equivalent.
- Impact: `nomad_acl_setup.sh check` is the operator's proof of the lock
  (and the box run will rely on it), yet none of its refusals is tested.
- Required: negative tests for `check` (a wider ES token, an observer that
  can plan, an ES token that reads nodes or plans in `default`), for
  provision's keep rule, and for the no-redirect opener.

### A2-7. Low. Reopened seam without a machine-enforced trigger.

- **Read:** PR 12's operational provider (PR #28 head 2c8bf35,
  `reliable_submit_operational_provider.go`) sends no `X-Nomad-Token` and
  registers in `es-operational-v1`, which the tool does not provision. It is
  built only in tests today. Report §8 lists the needed changes in prose. Once
  it is wired, an ACL Nomad would refuse it.
- **Ran:** a trial merge of 6270d7d with 2c8bf35 has one conflict (PLANS.md,
  both entries kept). Build and vet pass, `go test ./es/admission/` passes,
  with the combined guardrail inventories. Only the 3 historical-probe tests of
  reliablesubmit fail, which need probe binaries (`trial-merge/`).
- Required (coordinator decides where): a check that fails while any
  non-test Nomad request builder in es/admission omits the ACL token, so the
  §8 list cannot be skipped when the provider is wired. For example, a typed
  guard that routes every Nomad request through the token-setting helpers.

## 4. Verified and holding on 6270d7d

- **Ran, real Nomad 2.1.1 (CI pin) and 2.0.0 (box version), provisioned by
  the PR's own tool:** anonymous, unknown-token and observer callers got 403
  on every job-changing request I sent, in `es-submit-v1` and `default`:
  register by POST /v1/jobs and /v1/job/<id>, plan, evaluate, scale, revert,
  stable, dispatch, periodic force, alloc stop, restart and signal, variable
  write and job stop. They also got 403 on namespace, policy and token writes,
  system GC, scheduler config and node eligibility or drain. Alloc exec over a
  real websocket was refused with "Permission denied" for all three, and for
  ES's token (the management token reached the container, positive control).
  ES's token was refused everything outside `es-submit-v1` and dispatch, alloc
  lifecycle, exec and variables inside it (`probes/sweep-*.txt`,
  `probes/wsexec-*.txt`).
- **Ran:** the ACL behaviours ES's check relies on are the same on 2.0.0 as on
  2.1.1: ACL off gives token/self AccessorID `acls-disabled` with empty
  SecretID, and the anonymous policy lookup gives 400. ACL on gives anonymous
  `anonymous` and 404. A non-UUID token gives 500. A second bootstrap gives
  400 "ACL bootstrap already done (reset index: N)", which the tool matches
  (`probes/nomad-2.0.0-behaviours.txt`).
- **Ran:** `TestRealNomadRefusesJobsWithoutTheESToken`,
  `TestSubmitRefusesANomadThatDoesNotEnforceACLs` (real ES), and both
  `TestNomadACLTool*` pass on Nomad 2.1.1 and on 2.0.0
  (`tests/head-acl-tests-nomad-2.0.0.log`).
- **Ran:** `go build ./...`, `go vet ./...`, `GOOS=darwin GOARCH=arm64 go vet
  ./...`, gofmt on changed files, and `go test ./es/admission/ ./es/config/`
  all pass (admission 77.4 s).
- **Ran:** the pre-submit gate is fail-closed under mutation. Removing it,
  moving it after the staging claim, dropping the Type, AccessorID, secret or
  anonymous-policy conditions, or accepting 403 for the anonymous lookup is
  each killed by a test.
- **Read:** every Nomad request ES makes goes through `newJobRequest`
  (token header, namespace forced) or `verifyAccessControl`. No other Nomad
  call site exists in es/admission non-test code at 6270d7d. Errors never name
  the token or its path.
- **Ran:** root package `go test .` as ci: head 6270d7d and base 036d507
  fail the same 27 container-only tests (identical name sets). The one new
  test, `TestRemoteAlphaRuntimeImageNomadMetaUsesTheObserverToken`, passes
  (`tests/root-package-head-vs-base.txt`).
- **Read (CI log):** the full-profile bring-up test is not among the CI
  failures. The gate requires a verdict for every test, so it passed on the
  runner. I could not run it here (no offline image recipe, no /sbin/ip).

## 5. Observations (no change asked in this PR)

- O2-1 (Ran): inside `es-submit-v1`, `submit-job` lets ES's token register
  any job shape, plan, evaluate, scale, revert, mark stable, force periodic
  runs and stop. This is the INF-02 surface already recorded for a later
  design call.
- O2-2 (Read): the observer token can read ES job specs, including the
  invocation environment (read-job). That is narrower than before, when ACLs
  were off. Worth keeping in mind for the workload-identity design.
- O2-3 (Inference): 72 provisions with `ES_USER=root` into the same default
  directory that Remote Alpha uses with `ES_USER=es`. Run on such a host, it
  would issue a new root-owned `es-token` and delete the working one
  (ensure_client_token deletes other tokens of that name), so ES refuses
  submits until it is reconfigured. That fails closed, but it is an
  availability trap.
- O2-4 (Read): the "locked Nomad" subtest of
  `TestSupportedLocalSetupLocksNomadBeforeProofEffects` asserts nothing when
  run as root. CI runs it as non-root.
- O2-5 (not covered): Nomad's RPC port was not probed. That ACLs are
  enforced there is Inference from Nomad's design.

## 6. Not covered yet

The repair commit; `-race` on the final head; the full-profile bring-up
locally.
