Handed the machine session instructions

Read-only check of David's Linux test box (reached with `ssh [test box name withheld]`). David approved this read-only check. Nothing may be changed on the box or on the Mac beyond one temporary folder.

Rules (repeat of the project's standing rules): stay in /Users/ds/Repositories/Playground as the working directory and NEVER `cd` into the temp folder (use full paths). No sudo on the Mac. No installs or downloads. No git push. Do not run anything on the box other than the script below. Do not fix or edit anything. Playground itself must still exist at the end.

Steps:
1. Create the temp folder /Users/ds/Repositories/Playground/nomad-acl-readonly-check (if it already exists, use /Users/ds/Repositories/Playground/nomad-acl-readonly-check-2).
2. Write the script below, byte for byte, to <temp folder>/check.sh (everything between the BEGIN and END marker lines, not including the marker lines; end the file with a single newline). Then print `shasum -a 256 <temp folder>/check.sh` (expected 53cb270e468fa811ff891484daf08bffb692f0789507eee67ed75eb47aba049b; if it differs, still continue, but report the value you got).
3. Run: `ssh -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] 'bash -s' < "<temp folder>/check.sh" > "<temp folder>/output.txt" 2>&1; echo "exit=$?"`
4. Print the WHOLE of <temp folder>/output.txt verbatim in your final reply (do not summarize, do not shorten). If the ssh step failed, print its error output and stop.
5. Delete the temp folder with `rm -rf "<temp folder>"` and confirm /Users/ds/Repositories/Playground still exists.

-----BEGIN check.sh-----
#!/usr/bin/env bash
# Read-only check of the Remote Alpha box for the Nomad lock and the
# workload-identity design. It changes nothing: no writes, no restarts,
# no Nomad/Vault/SPIRE/Docker mutations. Secret-looking values are redacted.
set -u
export LC_ALL=C
redact() {
  sed -E 's/((token|secret|encrypt|password|passwd|join_token|unseal|private_key|api_key|hmac)[A-Za-z0-9_]*["]?[[:space:]]*[=:][[:space:]]*).*/\1<redacted>/I'
}
section() { printf '\n===== %s =====\n' "$1"; }
N=http://127.0.0.1:4646
code() { curl --noproxy '*' -s -o /dev/null -w '%{http_code}' --max-time 5 "$@" 2>/dev/null || echo "curl-failed"; }

section "host"
hostname; date -u +%Y-%m-%dT%H:%M:%SZ; uname -r
. /etc/os-release 2>/dev/null && echo "${PRETTY_NAME:-unknown}"
uptime -s 2>/dev/null
echo "sudo -n: $(sudo -n true 2>/dev/null && echo ok || echo unavailable)"

section "services (user, state, unit file)"
for s in nomad vault es ags ars egs docker spire-server spire-agent; do
  printf '%s: ' "$s"
  systemctl show "$s.service" --property=User,Group,ActiveState,SubState,FragmentPath,MainPID --no-pager 2>/dev/null | tr '\n' ' '
  echo
done

section "nomad version and unit"
command -v nomad && nomad version 2>&1 | head -3
systemctl cat nomad.service 2>/dev/null | redact

section "nomad config files"
sudo -n ls -la /etc/nomad.d 2>&1
for f in $(sudo -n find /etc/nomad.d -maxdepth 2 -type f \( -name '*.hcl' -o -name '*.json' -o -name '*.env' \) 2>/dev/null); do
  echo "--- $f"
  sudo -n stat -c '%U:%G %a %s bytes' "$f"
  sudo -n cat "$f" | redact
done
echo "managed marker present: $(sudo -n grep -Fqs 'Managed by Execution Substrate scripts/70_linux_setup.sh' /etc/nomad.d/nomad.hcl && echo yes || echo no)"

section "listeners (nomad, vault, spire, es services)"
sudo -n ss -ltnpH 2>/dev/null | awk '{print $4, $6}' | grep -E 'nomad|vault|spire|"es"|"ags"|"ars"|"egs"|:4646|:4647|:4648|:8200|:8201|:8081' | sort -u

section "nomad ACL state (anonymous, read-only requests)"
echo "GET /v1/status/leader: $(code $N/v1/status/leader)"
echo "GET /v1/jobs (default ns): $(code $N/v1/jobs)"
echo "GET /v1/jobs?namespace=*: $(code "$N/v1/jobs?namespace=*")"
echo "GET /v1/agent/self: $(code $N/v1/agent/self)"
echo "GET /v1/nodes: $(code $N/v1/nodes)"
echo "GET /v1/acl/policies: $(code $N/v1/acl/policies)"
echo "GET /v1/acl/policy/anonymous: $(code $N/v1/acl/policy/anonymous)"
echo "token/self AccessorID: $(curl --noproxy '*' -s --max-time 5 $N/v1/acl/token/self 2>/dev/null | python3 -c 'import json,sys
try: print(json.load(sys.stdin).get("AccessorID"))
except Exception as e: print("unparsed", type(e).__name__)')"
echo "ACL block from agent/self (if readable):"
curl --noproxy '*' -s --max-time 5 $N/v1/agent/self 2>/dev/null | python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); c=d.get("config",{})
    print(" ACL.Enabled =", (c.get("ACL") or {}).get("Enabled"))
    print(" TLS.EnableHTTP =", (c.get("TLSConfig") or {}).get("EnableHTTP"))
    print(" Version =", (c.get("Version") or {}).get("Version"))
    print(" DevMode =", c.get("DevMode"))
    print(" Region/Datacenter =", c.get("Region"), c.get("Datacenter"))
except Exception as e: print(" not readable:", type(e).__name__)'
echo "namespaces visible anonymously:"
curl --noproxy '*' -s --max-time 5 $N/v1/namespaces 2>/dev/null | python3 -c 'import json,sys
try: print(" ", [n.get("Name") for n in json.load(sys.stdin)])
except Exception as e: print("  unparsed", type(e).__name__)'
echo "jobs by namespace/type/status (counts only):"
curl --noproxy '*' -s --max-time 5 "$N/v1/jobs?namespace=*" 2>/dev/null | python3 -c 'import json,sys,collections
try:
    jobs=json.load(sys.stdin); c=collections.Counter((j.get("Namespace"),j.get("Type"),j.get("Status")) for j in jobs)
    print("  total", len(jobs)); [print("  ",k,v) for k,v in sorted(c.items(), key=str)]
except Exception as e: print("  not readable:", type(e).__name__)'

section "es service unit and config (nomad block only, no secrets)"
systemctl cat es.service 2>/dev/null | redact
sudo -n ls -la /etc/execution-substrate 2>&1 | head -60
for cfg in /etc/execution-substrate/es.json; do
  echo "--- $cfg"
  sudo -n stat -c '%U:%G %a' "$cfg" 2>&1
  sudo -n python3 -c 'import json,sys
d=json.load(open(sys.argv[1]))
print(" top-level keys:", sorted(d))
print(" nomad:", json.dumps(d.get("nomad")))
e=d.get("execution") or {}
print(" execution keys:", sorted(e))
print(" authorization:", json.dumps(d.get("authorization")))' "$cfg" 2>&1
done
pid="$(systemctl show es.service -p MainPID --value 2>/dev/null)"
[ -n "$pid" ] && [ "$pid" != 0 ] && ps -o user=,group=,pid=,args= -p "$pid"

section "docker"
docker version --format 'server {{.Server.Version}} client {{.Client.Version}}' 2>&1 || sudo -n docker version --format 'server {{.Server.Version}}' 2>&1
sudo -n docker info --format 'cgroup-driver={{.CgroupDriver}} cgroup-version={{.CgroupVersion}} security-options={{.SecurityOptions}}' 2>&1
echo "docker group: $(getent group docker)"
sudo -n stat -c 'docker.sock %U:%G %a' /var/run/docker.sock 2>&1

section "cgroup layout"
stat -fc 'cgroup fs type: %T' /sys/fs/cgroup
cat /proc/self/cgroup
ls /sys/fs/cgroup/system.slice 2>/dev/null | grep -E '^docker' | head -3
cid="$(sudo -n docker ps -q 2>/dev/null | head -1)"
if [ -n "$cid" ]; then
  cpid="$(sudo -n docker inspect -f '{{.State.Pid}}' "$cid" 2>/dev/null)"
  echo "sample running container cgroup:"; sudo -n cat "/proc/$cpid/cgroup" 2>&1
else
  echo "no running containers"
fi

section "spire agent config (redacted)"
systemctl cat spire-agent.service 2>/dev/null | redact
for f in $(systemctl cat spire-agent.service 2>/dev/null | grep -oE '(-config|--config)[= ][^ ]+' | sed -E 's/^-+config[= ]//'); do
  echo "--- $f"; sudo -n cat "$f" 2>&1 | redact
done
spire-agent --version 2>&1 | head -1

section "vault listener (redacted)"
systemctl cat vault.service 2>/dev/null | redact
for f in $(systemctl cat vault.service 2>/dev/null | grep -oE '(-config|--config)[= ][^ ]+' | sed -E 's/^-+config[= ]//'); do
  echo "--- $f"; sudo -n sh -c "if [ -d '$f' ]; then cat '$f'/*.hcl; else cat '$f'; fi" 2>&1 | redact
done
vault version 2>&1 | head -1

section "local login users (uid >= 1000)"
getent passwd | awk -F: '$3>=1000 && $3<65534 {print $1, $3, $7}'

section "done"
echo "read-only check finished"
-----END check.sh-----
