The PR #31 auditor sent early findings on 6270d7d. Please fold all five into your repair, before any part 2 commit:
(1) Medium: nomad_acl.py's competing-policy refusal is text matching and misses JSON or escaped-HCL policies; 4 of 5 forms passed provision. Ask Nomad itself instead: a short-lived token for each other policy and role, a planned probe in es-submit-v1, and require 403. Add a JSON-form test.
(2) Low: ES's Nomad client follows redirects, forwards X-Nomad-Token to other hosts, and uses the env proxy. Set CheckRedirect to ErrUseLastResponse, use no proxy, and add a test.
(3) Low: curl and urlopen calls to 127.0.0.1 that carry tokens go through http_proxy. Affected: 70_linux_setup.sh, check_nomad_ready_once in bringup.sh, nomad_api_get and remote_alpha_runtime_security_boundary_check.sh. Add --noproxy '*' and ProxyHandler({}).
(4) Low: the token placement checks (config.go and 72's dir check) ignore the SPIRE socket directory, which is bind-mounted into every workload.
(5) Low: add negative tests for the check command's probes and policy checks (6 mutants survive). Make the owner tests run as root in CI rather than listing them as skips, so the owner checks actually get tested.
Then send the repair id and manifest to the auditor thread.
