Part 1 of the Nomad lock is up as draft [PR 31](https://github.com/evo-agi/Execution-Substrate/pull/31), so I'm starting its audit.
