Starting the Nomad lock now, since the identity work waits on it. It begins with the repo side and a read-only check of the test box, which will need your "go ahead" on the Mac later.
