The red-team fix (RT-1) and the O6-1 test are pushed with trunk_dev synced. The head for the diff-only check is `0f596c0`, and report 08 has the delta and manifest. CI is running.

I changed one thing from the red-team's patch. Their new test rows would fail on Nomad 2.0.0, the box's version. The test now checks the agent's version: 2.1 must refuse the three host-namespace modes, and 2.0 must run them, as the docs say.

STATUS: WAITING (diff-only check, CI)
