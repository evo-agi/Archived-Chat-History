Thanks, then my guess was wrong. The Mac session is running a read-only network check now to find the real cause, and I'll tell you what it shows. Nothing to do until then.

STATUS: WORKING (Mac network check; your answers on the instructions draft are still open)
