Handed the machine session instructions

Follow-up for the same read-only box check. David can reach the box from his own Terminal (`ssh ds@[home network address withheld]` works), so the box and the LAN are up. Guess: macOS Local Network privacy is blocking this app's processes from LAN addresses. First collect a short diagnostic on the Mac, read-only, no sudo, nothing written:

1. `route -n get [home network address withheld]`
2. `ping -c 2 -t 3 [home network address withheld]; echo "ping exit=$?"`
3. `nc -vz -G 5 [home network address withheld] 22; echo "nc exit=$?"`
4. `ssh -G [test box name withheld] | /usr/bin/grep -E '^(hostname|user|port|identityfile|proxyjump|proxycommand) '`
5. `ssh -v -o BatchMode=yes -o ConnectTimeout=10 [test box name withheld] true 2>&1 | head -25; echo "ssh exit=${PIPESTATUS[0]}"`
6. The parent app of this session, for the Local Network setting: `ps -o pid,ppid,comm -p $$ -p $PPID`

Report all six outputs verbatim.

Then: only if step 5 shows the ssh connection now succeeds (exit 0), rerun the read-only check exactly as before: same temp folder rule under /Users/ds/Repositories/Playground (never cd into it), the same check.sh byte for byte (expected sha256 53cb270e468fa811ff891484daf08bffb692f0789507eee67ed75eb47aba049b), the same ssh command, print the WHOLE output verbatim, then delete the temp folder and confirm Playground still exists. If ssh still fails, stop after the diagnostic. Same rules as before: no sudo on the Mac, no installs, no push, nothing else run on the box, do not change any macOS settings yourself.
