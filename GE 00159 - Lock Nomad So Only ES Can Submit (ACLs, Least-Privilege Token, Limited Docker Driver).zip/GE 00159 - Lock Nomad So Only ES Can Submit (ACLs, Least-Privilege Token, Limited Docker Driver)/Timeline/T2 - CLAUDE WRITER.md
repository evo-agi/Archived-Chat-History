I've started on the Nomad lock in Execution-Substrate, on top of `trunk_dev` at `036d507`.

**One ask:** please write **go ahead** in this thread, and I'll do a read-only check of the Linux box from your Mac (`ssh [test box name withheld]`). It changes nothing and restarts nothing. It reads:
- whether Nomad's access control is on, and how Nomad is configured
- which user ES runs as
- the Docker version, cgroup layout, SPIRE agent settings and Vault listen address (the workload-identity design needs these too)

It prints no secrets.

While I wait I'm building the change itself:
1. Nomad's access control turned on in every repo config, in bring-up and in CI.
2. ES gets its own token, which can only submit and read jobs in ES's own Nomad namespace. The token sits in a file, not in the repo.
3. Requests without a token are refused. ES refuses to submit if Nomad would take jobs without one.
4. Tests, including one in CI's real Nomad that shows a submit with no token is refused.

STATUS: NEEDS DAVID (write "go ahead" for the read-only box check; the repo work continues meanwhile)
