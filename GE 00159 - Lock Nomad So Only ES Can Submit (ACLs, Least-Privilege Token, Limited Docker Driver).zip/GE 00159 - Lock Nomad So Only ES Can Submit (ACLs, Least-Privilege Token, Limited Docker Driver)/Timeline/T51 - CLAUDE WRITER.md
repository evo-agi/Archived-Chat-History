The Nomad lock repair is pushed, CI is green, and it has gone to the auditor (PR #31, head 78fd064).

- **CI fix:** all three causes are fixed properly, with no skipped or newly excused tests.
- **My earlier report was wrong.** It said the touched tests passed, but my last full test run came before my final edits. That claim is now struck through and corrected.
- **Audit findings:** all five early findings are fixed. The main one: when checking whether anything besides ES can start jobs, the setup tool now asks Nomad directly instead of reading policy text. That catches every way of writing a policy, plus roles and login methods.
- **Token guard:** a new check fails the build if any code talks to Nomad without ES's token. It already catches the three requests in PR 12 that lack the token, so PR 12 must fix them before it can land.
- **Extra hole closed:** a second Nomad master token now also counts as a hole in the lock.

Next I'm adding part 2 to the same PR: Docker-only jobs, no privileged containers, and Nomad over HTTPS. I've noted the box firewall for the later box run.

STATUS: WORKING
