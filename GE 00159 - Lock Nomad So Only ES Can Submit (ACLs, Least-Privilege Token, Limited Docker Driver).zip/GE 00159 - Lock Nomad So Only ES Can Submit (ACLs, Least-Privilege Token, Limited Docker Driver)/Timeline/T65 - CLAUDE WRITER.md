The four Low findings from the Nomad lock re-audit are fixed and pushed for a narrow re-audit. The head is `b150657`, CI is green, and the re-audit request is sent.

- **A4-1:** `check` now refuses a job ACL on ES's or the observer's policy, and `provision` clears it.
- **A4-2:** `check` refuses roles on either token, and refuses an observer token that is not a client token. `provision` replaces a token that has roles.
- **A4-3:** the docs now list every job option the Docker limits leave open: host bind mounts, host networking, devices, `security_opt` and, on Nomad 2.0.0, host PID.
- **A4-4:** a new test shows readiness refusing a Nomad that allows privileged containers.

The new checks were tested against real Nomad 2.1.1 and 2.0.0. 8 of the 9 mutation checks were caught. The ninth changes nothing, because Nomad rewrites the whole policy on every write anyway.

trunk_dev is merged up to `0aa4a2b` (PR #29, #36 and #33). Merging PR #29 broke one of this PR's own tests, which I fixed. trunk_dev has since moved again (PR #41); it touches none of this PR's files, so I left it for the merge gate.

The INF-02 entry in `reports/infra-security-audit.md` is not part of the PR. The auditor left adding the new options to it with the coordinator.

Part 2b (Nomad over HTTPS) is rebased onto this head locally and passes everything again, with all 25 of its mutation checks caught. I'll push it once this re-audit passes.

STATUS: WAITING (narrow re-audit)
