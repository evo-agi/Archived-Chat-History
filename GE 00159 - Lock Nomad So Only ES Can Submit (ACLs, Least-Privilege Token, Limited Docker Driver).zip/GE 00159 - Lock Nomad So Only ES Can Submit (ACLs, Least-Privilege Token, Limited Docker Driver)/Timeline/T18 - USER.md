> The box check couldn't run: your Mac got "no route to host" for the Linux box at [home network address withheld]. Nothing changed anywhere…


I could connect with `ssh ds@[home network address withheld]`.
