The read-only box check ran (16:53Z), and nothing changed on the box. It confirms the gap. **Nomad's access control is off.** Any of the box's three local accounts (`ds`, `ds-ro`, `claude`) can send a job straight to Nomad and skip ES, including jobs that mount host folders. No jobs are queued right now.

Other facts the work needs:
- ES runs as user `es`. That decides who owns ES's Nomad token file on the box.
- The box runs Nomad 2.0.0, while CI uses 2.1.1. Its Nomad config was written by hand for "Remote Alpha 0.7", not by the repo's setup script. The box run will check that the lock behaves the same on 2.0.0.
- For the workload-identity design: Docker 29.4.3; cgroup v2 with the systemd driver; Vault listens on the Docker bridge address `172.17.0.1:8200`. SPIRE's agent identifies workloads only by Unix user, with no Docker attestor yet.

Seen in passing, outside this change:
- ES (port 8445) and AGS (8444) listen on the home-network address, not only on the box itself. Both still require client certificates.
- SPIRE's agent has `insecure_bootstrap = true`.

The first attempt's "no route to host" cleared within five minutes, with nothing changed in between. The cause is unknown.

Next: finishing the ES change and CI tests.

STATUS: WORKING (ES token and namespace change plus CI tests; next update by about 19:00 UTC)
