The writer merged trunk_dev again (`c5115b4`), and the byte check on that merge also passed. The merge adds only trunk_dev's PR #42, and the PR's changes are identical to the head I accepted earlier. The affected tests pass on both Nomad versions. Its CI was still running at 02:00Z, so the writer checks it before squash-merging. The report is [10-byte-check.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/10-byte-check.md).

STATUS: PR #31 byte check 10 ACCEPT at c5115b4; CI pending at 02:00Z; gate and squash-merge next.
