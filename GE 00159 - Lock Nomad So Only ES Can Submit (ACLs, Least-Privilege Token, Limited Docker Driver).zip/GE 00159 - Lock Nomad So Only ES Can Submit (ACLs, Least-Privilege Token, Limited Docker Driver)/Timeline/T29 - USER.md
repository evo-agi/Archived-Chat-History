> The box check ran, and nothing changed on the box. Answering your earlier question: ES runs as its own unprivileged user…


Can we turn on Nomad's access control?

Good findings, by the way. And I can say with certainty that the more we dig into the infra setup, e.g. SPIFFE/SPIRE, Nomad, Docker, etc., the more you will find out we left many gaps unfilled, because I didn't put in the effort to learn the technologies. A comprehensive audit would be warranted, alongside analysis on short-term and long-term solutions, because, well, we obviously can't address everything within a meaningful period of time, now that we ran out of Fable reset and soon the weekly reset.
