> The Nomad lock needs a read-only look at the test box from your Mac. It checks whether Nomad's access control is on and …


Please go ahead, and do let me know if I need to run commands and what commands with sudo.
