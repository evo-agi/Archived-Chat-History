The box check ran, and nothing changed on the box. Answering your earlier question: ES runs as its own unprivileged user "es", not root. It also confirmed the gap. Nomad's access control is off, so any local account on the box can send jobs straight to Nomad and skip ES. The lock fixes that.

Two more things it noticed are going on the security list. SPIRE's agent bootstraps without verifying its server, and ES and AGS listen on your home network as well as locally, though both still require client certificates. The "no route" error cleared on its own, cause unknown.

STATUS: WORKING (Nomad lock; your two answers on the instructions draft are still open)
