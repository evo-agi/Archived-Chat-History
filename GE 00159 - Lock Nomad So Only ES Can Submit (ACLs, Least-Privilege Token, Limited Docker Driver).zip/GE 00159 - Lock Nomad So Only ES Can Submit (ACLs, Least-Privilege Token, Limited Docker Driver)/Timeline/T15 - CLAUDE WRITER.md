Thanks. The Mac session is already running the read-only check, and I'll report what it finds.
