> Good, so the box is fine. Guess: macOS is blocking the Claude app itself from your home network, while Terminal is allow…


Local Network is already on for Claude (no Claude Code).
