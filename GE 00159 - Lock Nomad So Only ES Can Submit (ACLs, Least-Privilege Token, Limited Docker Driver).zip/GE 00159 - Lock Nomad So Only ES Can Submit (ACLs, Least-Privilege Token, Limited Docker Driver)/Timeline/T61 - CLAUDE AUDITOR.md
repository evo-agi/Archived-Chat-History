**The re-audit of PR #31 at c3a94ae comes back BLOCK, on four Low findings only.** Nothing is Medium or higher. Report: [04-re-audit.md](/mnt/project-files/reports/Execution-Substrate/nomad-acl/04-re-audit.md), sha256 `c2cbed34ab87ca06bcc9f028db4647250d2d178590d53779181bf71d041e6ee3`. I tested on Nomad 2.1.1 and 2.0.0.

**What holds**
- The v2 manifest reproduces exactly (`0336e0bf…e8cbb7`, 52 files). The closing manifest equals the opening one, and CI run 45267764672 is green.
- The trunk_dev merge is clean.
- A2-8, A2-9 and A2-10 are fixed. Every narrow grant, tested alone, is refused by both provision and check.
- Part 2a's Docker limits hold: privileged mode, extra capabilities, exec and raw_exec are all refused.
- No test fails that doesn't also fail on base.

**What needs fixing (all small)**
- **A4-1:** check passes when a JobACL is set on ES's policy and the rules are left unchanged. In that state, a workload of the named job registered a new job using its own identity, which bypasses ES admission. Provision clears the JobACL.
- **A4-2:** neither check nor provision looks at roles on the ES or observer token. ES's token was given a role with write access in another namespace, and both passed. This gap has been there since part 1.
- **A4-3:** the docs say ES's token can still mount host paths. They leave out host networking, seccomp off, host devices, and host PID on 2.0.0 (the box's version), all of which ran. The INF-02 record should list these too.
- **A4-4:** if bring-up and the health check ignored a refusal from the posture check, no test would fail.

The fix and a narrow re-audit should be short. I pushed nothing and touched nothing outside this container.

STATUS: BLOCK delivered; repair of A4-1 to A4-4 needed, then a narrow fresh audit.
