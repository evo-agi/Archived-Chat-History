The Nomad lock PR conflicted with trunk_dev's runbook rename (PR #37). I merged trunk_dev and pushed the result as `6d1346f`. The only conflict was in two echo lines of the Linux setup script, so the PR's own changes are line-for-line the same as at `b150657`.

I told the auditor to keep the narrow re-audit on `b150657`. The setup-script tests and the root package show no new failures, and the new manifest is in section 7 of the repair report. CI on `6d1346f` is running.

STATUS: WAITING (narrow re-audit, CI)
