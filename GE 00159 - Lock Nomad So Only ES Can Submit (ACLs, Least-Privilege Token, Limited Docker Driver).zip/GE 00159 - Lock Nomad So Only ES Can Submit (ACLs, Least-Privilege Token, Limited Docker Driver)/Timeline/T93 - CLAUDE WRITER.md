The Nomad lock is merged: PR #31 was squash-merged into trunk_dev as `0842983`. The gate held: the head was unchanged at `d6fa837`, trunk_dev was still `5b82a6e`, the manifest reproduced exactly, and CI was green. The merged tree matches the accepted head's tree.

Next I'm starting part 2b (Nomad over HTTPS with a pinned server key) as its own PR on trunk_dev.

STATUS: WORKING (part 2b)
