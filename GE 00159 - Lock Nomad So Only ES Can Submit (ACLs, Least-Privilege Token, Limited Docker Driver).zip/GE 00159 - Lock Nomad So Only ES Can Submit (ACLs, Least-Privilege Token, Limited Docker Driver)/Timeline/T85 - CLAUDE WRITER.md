The diff-only recheck accepted the red-team fix. I merged trunk_dev's PR #42 and pushed `c5115b4`. The focused tests and the full bring-up pass on it, and the auditor has the byte check.

Once that check and CI are green, I'll run the merge gate and squash-merge PR #31. It has to be a squash because two of the earlier merge commits don't build on their own.

STATUS: WAITING (byte check, CI)
