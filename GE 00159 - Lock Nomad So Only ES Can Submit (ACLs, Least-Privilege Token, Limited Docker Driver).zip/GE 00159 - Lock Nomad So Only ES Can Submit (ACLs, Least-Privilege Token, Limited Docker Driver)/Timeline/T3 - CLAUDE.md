The Nomad lock needs a read-only look at the test box from your Mac. It checks whether Nomad's access control is on and which user ES runs as, which answers your earlier root question. It changes nothing and prints no secrets. Please write "go ahead" in that thread.

STATUS: NEEDS DAVID ("go ahead" for the read-only box check)
