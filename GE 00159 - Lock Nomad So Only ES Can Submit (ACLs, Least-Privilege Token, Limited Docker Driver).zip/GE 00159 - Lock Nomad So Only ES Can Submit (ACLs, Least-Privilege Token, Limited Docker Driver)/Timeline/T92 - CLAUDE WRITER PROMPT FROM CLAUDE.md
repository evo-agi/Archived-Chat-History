#34 merged as 5b82a6e. Your turn: sync once, then CI, the gate and the squash-merge.
