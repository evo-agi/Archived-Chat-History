Yes. It's part of the Nomad lock now being built, and the box run will turn it on. It can't be switched on by itself first: ES doesn't send a token today, so every submission would start failing. ES gets its token in the same change.

Thanks, and no blame needed. Finding these is the point. The full infrastructure audit just started, read-only, and it ranks quick mitigations against proper long-term fixes so we spend the limited budget where it counts.

STATUS: WORKING (infra audit, Nomad lock, PR audits; your two answers on the instructions draft are still open)
