Part 1 of the Nomad lock is up as draft [PR #31](https://github.com/evo-agi/Execution-Substrate/pull/31). Build, vet, race and the new tests all pass, and the provenance manifest matches.

**What it does:**
- Nomad now refuses any request that has no token.
- ES gets its own token, read from a locked-down file. It can only submit and read jobs in its own namespace. The management token never reaches ES.
- Before every submit, ES checks that Nomad really enforces this. If it doesn't, ES refuses the submit.
- Setup, bring-up and CI all turn the lock on. A test proves that CI's real Nomad refuses an unauthenticated submit.

**Known limits:**
- Nomad still speaks plain HTTP on the local machine. Part 2 fixes this next, in the same PR, by moving Nomad to HTTPS with a server key that ES pins.
- Part 2 also allows only the Docker driver and makes the Nomad config root-owned.
- If ES's token is stolen, it can still mount host folders as root. This is recorded for a later design call and not solved here.

The box inventory you approved ran cleanly and is saved for the infra audit. The PR is now with the audit.

STATUS: WORKING (part 2)
