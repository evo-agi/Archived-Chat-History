Good, so the box is fine. Guess: macOS is blocking the Claude app itself from your home network, while Terminal is allowed. Please open System Settings → Privacy & Security → Local Network and switch on Claude, or Claude Code if it's listed separately. Then write "go" in [Lock Nomad so only ES can submit](#cmsg_01Un4xQgjBAczV8DABQvcLrx7qaBgesL513RdQXm7D49pW). The rerun will confirm whether that was the cause.

STATUS: NEEDS DAVID (Local Network switch, then "go" in the Nomad thread)
