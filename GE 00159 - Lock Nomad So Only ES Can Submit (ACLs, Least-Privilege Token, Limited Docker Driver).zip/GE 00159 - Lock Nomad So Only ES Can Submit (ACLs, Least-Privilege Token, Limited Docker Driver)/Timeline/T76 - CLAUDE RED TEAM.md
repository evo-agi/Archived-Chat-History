**PR #31 (Nomad submit lock) red-team: ACCEPT, one Low finding. Not blocked on the red-team side.**

Ran against real Nomad **2.1.1** (the CI pin) and **2.0.0** (the box's version), ACLs on, lock provisioned by the PR's own `nomad_acl.py`. Provenance reproduced: manifest `a0ce1b2f…a654`, byte-equal to the writer's and auditor 06, 52 paths. Nothing touched the box; nothing pushed.

- **Goal 1 — submit without ES admission: closed.** No-token and random-token job registers = 403 on both versions.
- **Goal 2 — escalate from the ES or observer token: closed.** Re-ran every escalation with well-formed bodies (the earlier 400s were bad-body rejections, not ACL verdicts): the ES token gets 403 on minting tokens, writing policies, creating namespaces, writing variables, reading topology, and any other namespace — 200 only on its own token and a plan inside `es-submit-v1`. The observer can read topology (by its audited policy) but write/plan nowhere.
- **Goal 3 — make `check` report unsafe-as-safe: closed.** The full check (the one `provision` runs) refuses a competing policy, a role bundling the namespace, and an auth method, each by name. One observation, not a bug: the *plain* check readiness runs doesn't prove exclusivity, but seating a competing writer needs root, which is already outside the lock's model.
- **Goal 4 — RT-1 (Low, docs).** On Nomad 2.0.0 two more host-namespace modes run that the docs don't list — `ipc_mode="host"` (verified: container joins the host IPC namespace) and `userns_mode="host"`; the documented-open list names only `pid_mode`. 2.1.1 refuses all three. It needs ES's own submit token and doesn't widen the worst case (a bind mount of `/` as root is already total compromise). Fix is a docs/comment patch plus two test rows, attached — applies clean at `6d1346f`.

Report SHA-256 `4bc1727efedb44eba9f5707a2dc39e0de8a546759c0a5afa514b684bd8de09c6`. At the merge gate, bring in current `trunk_dev` (`725c97a`) and re-run the provenance check.

The PR #30 re-check is still mine to do once that writer's repair lands.

STATUS: WAITING — PR #31 red-team delivered; PR #30 re-check pending the writer's repair. 8:08 PM Eastern.
