Queue swap: #34 is green and merging now, ahead of you. When its SHA lands, sync #31 once under the own-check rule (git clean merge with an identical patch), wait for CI, then gate and squash-merge.
