Here is Codex's response:

**V8 repair validated.** The sole live edit is [tests/test_rw0_d1_offline_integration.py (line 49)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:49>). Production, documents, schemas, and migrations are unchanged. Exact model and reasoning-effort settings were not visible; this was a GPT-6-based Codex task with `danger-full-access` and approval policy `never`. No subagents or network access were used.

### Repair and causal evidence

The test-local observer calls through to the supervisor’s real [\`subprocess.Popen\` (line 173)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:173>). It records every attempted launch, actual child PID or start failure, and argv-derived planner or worker role. It separately records caller-facing C1 returns, effective recovery returns, and writer-close completion ([observer and assertions (line 72)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:72>)). Its assertions use fixed launch expectations and run after the real invocation; the observer does not gate a launch.

The strengthened [normal test (line 232)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:232>) requires exactly planner → worker, with the worker after effective C1 success and the relevant writer close. The strengthened [unresolved C1 test (line 883)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:883>) requires one planner and **zero worker attempts or PIDs**, despite an underlying `fresh_committed` phase whose response is lost. The [four-site response-loss test (line 487)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:487>) and [unresolved pre-phase cases (line 526)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:526>) use the same observation. Phase `committed_exact` recovery was followed by exact replay, recovery-writer close, then worker launch.

| Final-clone trace                      | Actual planner / worker attempts and created PIDs | Result                                                       |
| -------------------------------------- | ------------------------------------------------- | ------------------------------------------------------------ |
| Normal                                 | 1 / 1 — 22230, 22231                              | `capsule_ready`; C1 return → close → worker                  |
| Phase response loss, `committed_exact` | 1 / 1 — 22235, 22241                              | recovery return → exact replay → close → worker              |
| Program / author unresolved            | 0 / 0 each                                        | stopped before any child                                     |
| Selection unresolved                   | 1 / 0 — 22258                                     | stopped before C1 and worker                                 |
| Phase unresolved                       | 1 / 0 — 22262                                     | physical C1 commit, effective unresolved recovery, no worker |

An external opening mutant (`bef9371a…f95d443`) launched an unreported real worker before C1. **Both original named tests passed**. Its happy trace was planner 14002 → extra worker 14003 → C1 → reported worker 14004; its unresolved trace was planner 14007 → extra worker 14008 → response loss → unresolved recovery, while the handback reported no worker.

With final test bytes unchanged, all three external one-module mutants parsed, imported, and collected the same 39 integration nodes:

| Mutant                 | Actual effect and permanent-test result                                                                                                                                                                                                                                                               |
| ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| L01 `bef9371a…f95d443` | Extra pre-C1 worker retained alongside the later worker. Both named tests failed at the complete launch-sequence assertion after created PIDs were checked. Happy PIDs: 14589, 14593, 14594; unresolved: 14597, 14601.                                                                                |
| L02 `34f8ea42…f28ac4`  | Sole worker 14608 moved before C1, after a real writer close; planner was 14604. The two-child count passed, then the normal test failed specifically because no effective C1 return preceded the worker. The external transformation was corrected before execution to preserve that close boundary. |
| L03 `061b0e85…61`      | Worker 14613 launched after physical C1 commit and response loss, before unresolved recovery; planner was 14611. The unresolved test failed on the forbidden real launch.                                                                                                                             |

All 20 children in the separate opening, mutant, and final characterization traces were reaped and their groups were clear. No observer emergency cleanup was needed. Returned process PIDs matched observed PIDs where a handback reported them; discarded mutant workers remained visible to the lower hook. This hook observes the fixed Python supervisor call site, not arbitrary native process creation.

### Validation and preservation

The opening record was made **before Git** at `2026-10-17T20:31:08.117670Z` (record SHA-256 `ad3aeb4c…aaa198`). It authenticated HEAD `0d0926e3a483a3ab1a4fd597ac0495927352bf35`, tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`, parent `630414faa07f4ac39c4a870a9cc44c7f92d46b80`, `trunk_dev`, upstream 0/0, and one worktree. The index remained byte- and metadata-exact: SHA-256 `709d48a8…74b401a4`, inode `191034980`, size `27882`, mode `0644`, mtime-ns `1792193153121124693`. The cache directory and all 37 member records remained exact; canonical cache-record SHA-256 was `75f70d1c…a26d02c`. The same helper passed immediately before its owned root was removed.

The only endpoint transition was the created integration test: **33,136 bytes**, SHA-256 `a4abd723…85e4b` → **47,176 bytes**, SHA-256 `0f38baa2…00b4518b4b3`; its encoded component is 47,251 bytes. It remains absent from HEAD/index, OS `0644`, Git representation `100644`. The 25-byte prefix plus 4,538,330 encoded row bytes gives **4,538,355 bytes**, SHA-256 `173adda1a4d1cab3a0056a5156339e1fd1f059533a4f11e915894ddb21ea0ce0`, reproduced by two fresh reads. All other 45 candidate endpoints and 217 noncandidate tracked files were exact. Status remains 29 M / 17 C; tracked `git diff --check` and all 17 addition no-index whitespace checks were clear. The two V7 capsule-verifier test bodies are byte-for-byte unchanged.

Each group used the requested serial `python3 -B -m pytest -q -p no:cacheprovider --basetemp=<owned-path>` collection and run, with `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, owned `TMPDIR`, and umask `022`. Group paths were exactly `tests/test_<token>.py` for the tokens supplied in Section 9 of the request; Group 12 used no path arguments.

| Group              | Files | Collected / passed | Test-file inventory SHA-256                                        |
| ------------------ | ----- | ------------------ | ------------------------------------------------------------------ |
| 1 D1               | 7     | 112 / 112          | `78c117f24c7f9ec9e17434806e41ad900e6afd5e89d96e0f4358aa76d18b152d` |
| 2 program          | 9     | 218 / 218          | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author           | 4     | 46 / 46            | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41       | 6     | 168 / 168          | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1               | 8     | 109 / 109          | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4     | 135 / 135          | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire             | 7     | 135 / 135          | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability       | 4     | 60 / 60            | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard  | 1     | 289 / 289          | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards   | 8     | 1,783 / 1,783      | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners  | 6     | 679 / 679          | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124   | 8,984 / 8,984      | `c6eba3d75348c16265280ea07a0520fa4bb36d39ffc5f2f7b5498fe0cd98f274` |

Group 2/3 overlap was 46 nodes; Group 7/11 overlap was 31; the Group 1–11 union was 3,657 nodes, all present in Group 12. Groups 10 and 12 each reported the same three existing Python 3.13 multithreaded-fork `DeprecationWarning` records in `test_sqlite_b2c_writer_session.py`; there were no new warning classes or suppressed warnings. The normal final clone had zero remotes and the same 263 exact endpoints before and after execution. The owned external root was removed after final preservation checks.

The prior independent audit’s V7 verifier, B1 controls, four durable-family readbacks, 29-diff review, and Groups 1–10 remain **prior evidence**. Its interrupted Group 11 and absent Group 12 were completed here as implementation validation. The remaining independent P/N/R/W/B and finite acceptance campaign remains open; this repair does not grant acceptance, executable authority, or publication.

**Continuation capsule:** An independent read-only auditor can assess this exact 46-endpoint candidate, especially whether the permanent Popen-level assertions causally reject L01–L03 while preserving legitimate committed-exact recovery. No staging, commit, publication, D2, or physical C2 action was performed.

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V8_VALIDATED_READY_FOR_REAUDIT`
