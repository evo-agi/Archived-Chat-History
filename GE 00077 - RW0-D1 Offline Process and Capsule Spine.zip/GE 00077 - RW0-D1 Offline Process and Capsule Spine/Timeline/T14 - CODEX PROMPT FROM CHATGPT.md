# Governed Execution Coordinator — RW0-D1 Offline Process and Capsule Spine: Audit Repair V1

## Mandate

Resume the implementation conversation that owns the exact uncommitted
46-path RW0-D1 candidate below.

Repair the candidate after the fresh independent audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

The audit independently reproduced exact candidate provenance and confirmed:

- the normal invocation uses the current guarded program, author-effect,
  Section 41, and RW0-C1 owners in the required order;
- unresolved durable recovery prevents later child launch;
- writer/state-authority resources are closed before the planner and worker;
- tested child channels exclude database, state, lock, and credential sentinels;
- timeout/cancellation TERM→KILL and reap work in the normal path;
- workspace containment and capsule tamper controls work;
- the parent constructs and independently verifies the capsule;
- D2/C2/live-provider/Git/public-runtime boundaries remain absent;
- the bounded governance guards remain effective.

It found four bounded runtime/evidence defects:

1. Medium: `RW0D1HandbackV1` accepts arbitrary `object` fields and does not
   enforce status/reason/evidence invariants, allowing `capsule_ready` without
   required evidence and allowing a raw live `Path` to enter the handback;
2. Medium: the parent-only run owner has no creating-process fence, so a forked
   child can call `close()` and delete the disposable database;
3. Medium: selector cleanup failure escapes before a process outcome is
   finalized, and the offline layer misclassifies it as
   `stopped/durable_conflict` with lost process evidence instead of
   `cleanup_unresolved`;
4. Low: a malformed planner frame with a non-string enum field can raise raw
   `TypeError` before the closed `D1FrameError` vocabulary.

This is an EIGHT-FILE repair of the existing D1 runtime and direct tests. It is
not a new architecture, contract, D2, C2, or publication tranche.

Parent is the sole writer. No subagents. Use the highest exposed reasoning
setting; report visible model, reasoning setting/effort, and permission posture,
or `not visible`. Do not seek more access merely to reveal hidden settings.

Return one substantive INLINE closeout and a continuation capsule no longer
than 1,000 words. Do not deliver a report, manifest, patch, snapshot, archive,
or evidence package. Do not issue a D2/C2 prompt.

## 1. Exact committed baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- no staged or unmerged paths
- exactly the 46 candidate paths below as modified/untracked state
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  lock.

Read `AGENTS.md` first. Verify with non-mutating Git inspection and optional-lock
suppression. Do not fetch, normalize, clean, change configuration, or discard
another actor's work.

Stop before editing on any baseline, path-set, type, mode, byte-size, SHA-256,
baseline blob, or replacement-recipe mismatch:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V1_BLOCKED`

## 2. Exact opening 46-path candidate

Require exactly 29 modified tracked paths and 17 created untracked paths. All
candidate paths are regular files represented by Git mode `100644`. Created
paths are absent from HEAD and index. Every noncandidate tracked path remains
byte- and Git-mode-identical to HEAD.

| Change | Repository-relative path | Bytes | SHA-256 | Baseline blob | Component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,153 | `d58c9c882a2c9c2a07c652c095f69ad49cced30b6cc170ff17d04daf0f7e6f51` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,221 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 4,293 | `8e1523775a1b9144758ec13882cfc8a4501db4afdc1450bf8d1c4664e1f6149c` | `absent` | 4,370 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,194 | `1a4c2f0ec67755b934c09d933e457b49367b272ca3384082100b1631af2589be` | `absent` | 22,270 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,440 | `d9304c6bd25b89b780c2c9e524261a82c7c2327740b09cfc35333299a62f40cf` | `absent` | 5,523 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 7,692 | `5fcee759d6d3371538a13bdc07fa9826724144fbc6b6676f8158677e642a5cef` | `absent` | 7,779 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 39,069 | `2dbb15ee10d7155c4255ae01f1499ae50acd6e43f666efef633737f9a466f679` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 39,135 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 30,703 | `2de0fb039733846bc416dbd4858cc07e66f6e97f4698416b2770a9701c7bd8a7` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 30,774 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 1,560 | `3b5cc33305643d7d6b373858a3f5109181b57b41f5059d9b58cd7f7c15f604eb` | `absent` | 1,631 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 8,374 | `f28fc897c850b982e79cd851e0f74c6aed6999428ad3be46f90e6b4a3cbbf4f7` | `absent` | 8,449 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 2,906 | `ed1015f5598fdff7ca58dbcdc992a52654d719022a911a77903963ff234bae1f` | `absent` | 2,976 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 4,804 | `9875671c0c67450dd84459e4739f05483f387c5f45a18f3fba2f979a659be242` | `absent` | 4,878 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 174,623 | `78b47b119f88e1642599e350cd95d217b1a4056621301012dc52ed5c8f6beee5` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 174,711 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Applicable text files must be strict UTF-8 with one final LF, no BOM, no CR,
and no trailing whitespace. Investigate established exceptions rather than
normalizing unrelated files.

### Exact opening replacement identity

Reconstruct twice from fresh reads.

Start with the 25 bytes:

```text
RW0-D1-BINARY-REPLACE-V1\0
```

For each row in UTF-8 path order append:

```text
u16be(path_utf8_length)
path_utf8
one ASCII byte M or C
u32be(0o100644)
20-byte baseline blob OID, or twenty zero bytes for C
u64be(payload_length)
exact final file bytes
```

Require:

```text
rows: 46
modified: 29
created: 17
sum(row components): 4,422,215 bytes
prefix: 25 bytes
total: 4,422,240 bytes
SHA-256:
c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef
```

Do not invent a different identity recipe.

## 3. Exact repair ceiling

Only these eight candidate paths may change:

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_offline.py

tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_offline_integration.py
```

The other 38 candidate paths must remain byte-identical to the opening table.
Every noncandidate tracked path remains HEAD-exact.

No new path is authorized. Do not modify documents, package exports, migrations,
schemas, current durable owners, fake child modules, workspace/capsule modules,
or governance guards.

No staging, commit, push, PR, merge, branch switch, reset, rebase, network,
installation, provider, supplier, credential, D2, C2, terminal, ES, Bridge,
RW0-E, sibling-repository, or subagent action.

If a real fix requires another owner/path, stop without widening:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V1_REPLAN_REQUIRED`

## 4. Preserve independently confirmed D1 behavior

Read all eight repair paths fully and the D1 owner in context. Preserve:

- actual current guarded program initialization/replay/recovery;
- actual current author-effect establishment/replay/recovery;
- planner child before Section 41;
- parent-built Section 41 bundle and actual guarded disposition;
- C1 phase establishment before worker launch;
- no child after unresolved durable recovery;
- writers/state-authority resources closed before each child;
- separate fake planner and fake worker;
- D1O1/D1W1 and existing NWPF semantics;
- bounded environment, FDs, timeout, cancellation, process group, reap, and
  normal cleanup;
- bounded workspace and parent-owned capsule verification;
- no D2/C2/terminal/provider/Git/public-runtime behavior;
- all governance/status guards.

Do not redesign the durable call chain, protocol, workspace, capsule, fixture,
or D1/D2 boundary.

## 5. Finding 1 — typed handback and status/evidence invariants

### Remove arbitrary evidence slots

Inspect every `RW0D1HandbackV1` field and construction site.

No field may be typed as, validated as, or semantically accept:

- `object` or `Any`;
- `Path`, `PurePath`, or `os.PathLike`;
- raw database/workspace path;
- `SQLiteWriterSession`, connection, descriptor, state location, or lock;
- writer proof, lease, operation capability, or run owner;
- arbitrary mutable mapping/list as an evidence escape hatch.

Use exact existing private semantic/process/capsule types and closed immutable
built-in container shapes. Optional fields are `None` or the exact declared
type. Reject bool-as-int and forbidden subclasses where exact built-ins are
required. Do not add a generic public serializer.

### Freeze field inventory

Add fixed independent expectations for field names, order, exact accepted types,
repr participation, and status-dependent required/forbidden fields. A later
`state_path`, `workspace_path`, generic `metadata`, or `object` field must fail.

### Enforce status/reason/evidence matrices

Derive the existing closed vocabulary from the owner and actual call sites.
Do not invent new domain semantics.

At minimum:

- `capsule_ready` requires successful planner and worker process evidence,
  existing Wire evidence, candidate capture, verified capsule, required durable
  program/author-effect/selection/C1 coordinates, and proved cleanup; it carries
  no stopped/cleanup reason;
- `stopped` uses only non-cleanup reasons, cannot claim a verified ready capsule,
  and cannot contain stage evidence before its prerequisite;
- `cleanup_unresolved` uses only cleanup-uncertainty reasons, retains evidence
  already observed, and never claims ready status.

Do not drop already observed evidence merely to satisfy the matrix.

### Sensitive representation

`repr()` and existing diagnostics must not expose raw WorkSpec/planner content
where classified sensitive, captured bytes, database/workspace paths,
authority/proof material, or run-owner/cleanup objects.

### Direct and integrated tests

Reject:

- ready status with each required evidence field missing;
- raw `Path` or live state/workspace root in every former generic slot;
- stopped with cleanup-only reason;
- cleanup-unresolved with non-cleanup reason;
- stopped carrying ready capsule evidence;
- extra/wrong exact container or value types.

Run one real successful invocation and walk only the known closed handback graph.
Prove no path-like value, state/workspace-root text, writer/session/connection/
lock/proof/capability/run-owner type, or extra field exists.

A transformed copy that inserts the live state root into every success handback
must fail.

## 6. Finding 2 — creating-process fence on run owner

`RW0D1OfflineRun` records the exact creating PID at construction.

Before every method/property that exposes or mutates retained-state custody,
require `os.getpid() == creator_pid`, including `close()`, context entry/exit,
and any state-location/database access for D2. Immutable `.handback` may remain
readable if it carries no live authority.

In a noncreator process:

- raise one private closed ownership error;
- do not remove/mutate state;
- do not change closed state;
- do not expose the retained path;
- do not rely on finalizers.

The PID/path must not appear in handback, repr, child input, logs, or public
errors.

### Real fork test

On POSIX, create a successful run and fork. The child calls every custody-
affecting method. Require the ownership error and no state removal. After child
exit, parent remains open, state exists, parent close succeeds, second close is
idempotent, state is removed, and no `FileNotFoundError` escapes.

A transformed copy removing the PID check must fail semantically.

## 7. Finding 3 — cleanup uncertainty preserves process evidence

A selector/stream cleanup failure must not escape before process facts and
process-group cleanup observations are finalized.

Refactor bounded cleanup so it:

1. retains start/PID/group, I/O, deadline/cancel, signal, exit, and reap facts;
2. attempts group-clear observation even if selector close fails;
3. captures selector/stream cleanup uncertainty in the private process outcome;
4. uses a closed sanitized cleanup reason;
5. returns a typed outcome instead of raising.

Cleanup is a separate dimension from process semantic classification.

The offline layer maps unproved planner or worker cleanup to:

```text
status = cleanup_unresolved
```

with stage-specific cleanup reason and the corresponding non-`None` process
outcome. It must not map to `stopped/durable_conflict`.

Planner cleanup uncertainty stops before Section 41. Worker cleanup uncertainty
never returns `capsule_ready`; retain already observed safe evidence subject to
the handback matrix.

### Direct tests

Inject selector-close failure after real planner and worker PIDs. Require no raw
exception, retained process facts, attempted group-clear observation, exact
cleanup-unresolved handback, no later advancement, reap, and no surviving group.

Also combine timeout/cancellation with selector cleanup failure: primary process
classification remains observable while cleanup remains unresolved.

Transformed copies that re-raise selector close, erase process evidence, map to
durable conflict, or skip group-clear observation must fail.

## 8. Finding 4 — closed frame-error normalization

For every D1O1/D1W1 field used in membership or lookup:

1. validate exact built-in type;
2. validate closed value;
3. raise `D1FrameError` for malformed input.

No canonical malformed JSON may leak raw `TypeError`, `KeyError`,
`AttributeError`, or unhashable-value errors.

Cover planner response `{{"action":[]}}` and wrong types for every closed enum/
membership field in planner request, response, and worker-launch envelope.

The offline layer maps malformed planner output to the existing planner-frame
reason before Section 41, not generic durable conflict. Worker malformed-frame
cases remain in their existing worker-frame vocabulary.

Require direct decoder `D1FrameError`, typed process outcome, no Section 41 after
malformed planner output, and no raw exception in handback/repr.

Transformed copies restoring membership-before-type or generic-conflict mapping
must fail.

## 9. Immediate compositions

Add bounded compositions:

1. success-handback mutant inserts live state root;
2. forked child attempts close while parent has ready handback;
3. planner selector cleanup failure after valid frame;
4. worker selector cleanup failure after valid NWPF result;
5. timeout plus selector cleanup failure;
6. malformed planner action type with existing durable state;
7. cleanup-unresolved handback attempted with ready status/reason;
8. normal successful handback remains valid.

Keep expected outcomes outside candidate helpers.

## 10. Transformed-copy evidence

Against final repaired bytes create at least these disposable mutations:

1. restore an `object` handback field;
2. permit ready status without worker/Wire/capsule evidence;
3. insert raw state path into actual success handbacks;
4. remove run-owner PID fence;
5. let selector-close escape;
6. erase process evidence on cleanup failure;
7. map cleanup to `stopped/durable_conflict`;
8. skip group-clear observation;
9. restore membership-before-type in frame decoding;
10. map `D1FrameError` to generic durable conflict.

Each must parse/import/collect normally and fail semantically at a fixed
permanent test. Credit no syntax/import/collection failure. Report permanent
tests, direct specimens, transformed copies, and outside-oracle evidence
separately.

## 11. Validation

All executable validation occurs in fresh local-only external clones of exact
HEAD overlaid with the current candidate. Remove remotes. Do not run repository
code, pytest, compilation, subprocess children, or SQLite from the live
checkout.

Use task roots mode `0700`, test-process `umask 022`,
`PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, `-p no:cacheprovider`,
precreated distinct basetemps, no xdist/overlap, and collection before execution.

After the last edit, build one final clone from final bytes and run the exact
12 groups. The exact file inventories are:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
12: architecture_contracts,autonomous_software_development_operating_model,b2a_writer_session_contract,b3_coherent_transition_fixture,b3a_persistence_contracts,b3b1_pure_row_contracts,b3b2a_read_scope_and_query_contracts,b3b2b_select_readers,b3b_reader_prerequisite_contracts,b3c0a_transition_authority_contract,b3c0b_transition_event_replay_contracts,b3c1_prerequisite_contract,b3c1a_writer_session_authority,b3c1b_rollback_only_writer_fencing,b3c2_transition_event_readers,b3c3_prerequisite_contract,b3c3_rollback_only_transition_dry_run,b3c4a_transition_write_contracts,b3c4b_private_atomic_transition_persistence,b3c4c_prerequisite_contract,b3c4c_public_transition_delegation,b4a_global_stop_persistence_contracts,b4a_global_stop_preflight_contracts,b4a_global_stop_readers,b4a_global_stop_write_contracts,b4b_private_atomic_global_stop_persistence,b4c_public_global_stop_delegation,c2a_effects_and_recovery,c2a_first_slice_semantic_protocol_contract,c2a_nonimplementation,c2a_relations,c2b0_durable_state_contract,c2b2_development_decision_row_values,c2b2_development_effect_row_values,c2b2_development_program_row_values,c2b2_development_reader_contracts,c2b2_development_row_value_boundaries,c2b2_field_level_contract,c2b2_private_development_readers,c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation,c2b_pre_io_vs1a_shared_cleanup_foundation,codex_agent_config,finite_backlog,global_stop,global_stop_store_contract,lease_identity,p1_1_event_algebra_docs,post_execution_pure_owner_boundaries,post_execution_pure_owner_relations,post_execution_pure_owner_values,post_execution_pure_owner_vectors,remote_worker_pre_execution_planning_contract,report_projection,runtime_non_authority,rw0_b1_boundaries,rw0_b1_phase_values,rw0_b1_relations,rw0_b1_vectors,rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors,rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values,rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation,rw0_c2_bootstrap_acceptance_guard_semantic_contract,rw0_c2_durable_progression_decision_semantic_contract,rw0_c2_first_live_proof_posture_contract,rw0_c2_private_value_versioning_contract,rw0_c2_scope_admission_provisioning_contract,rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule,rw0_remote_contact_phase_entry_contract,section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation,software_development_progression_boundary,sqlite_b1_connection_posture,sqlite_b1_filesystem_security,sqlite_b1_migrations,sqlite_b1_runtime_boundary,sqlite_b2b_lock_integration,sqlite_b2c_writer_session,sqlite_backend_b0_contract,sqlite_c2b1_migration_framework,sqlite_c2b2_migration_0002,sqlite_rw0_c1_migration_0004,sqlite_section41_migration_0003,state_authority_lock,state_machine,state_store_contract,transition_command,worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
```

### Expected group behavior

Group 1 opening reference is 57 tests; final count may increase. Recompute and
report its inventory digest.

Groups 2–11 test files are outside the repair ceiling and must retain these
counts/digests:

```text
2 program: 9 files / 218 passed
  1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10
3 author effect: 4 / 46
  90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8
4 Section 41: 6 / 168
  522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55
5 C1: 8 / 109
  22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825
6 worker semantics: 4 / 135
  779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346
7 Wire: 7 / 117
  53ccc8874d06f47f4eab42f13c20de874bd91035359bd4ad57bda2675ccd374e
8 Capability: 4 / 60
  b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00
9 bootstrap guard: 1 / 289
  236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736
10 legacy guards: 8 / 1,754
  f0c8037a97d99ac77e81099c190b75c4f3e346988bde515913c2fb00a6236a45
11 remaining changed owners: 6 / 656
  95430563d25048a351e903fa0b7819434785d9b00149d8f0e4d87cb2a658e428
```

Group 12 runs with no path arguments. Opening reference:

```text
124 modules / 8,877 passed
inventory digest:
0c390a48b930b698f4b037e718ce044572c8bf8b021b1d730ea48bdbfe8ec7fe
```

Only four D1 test files may change, so require:

```text
final full count = 8,820 + final Group 1 count
```

Recompute the full test inventory digest. Reconcile actual unique node IDs and
group overlaps.

Only the three known Python 3.13 multithreaded-fork warnings are accepted.
Inspect structured warnings.

Run:

- `git diff --check`;
- no-index whitespace checks for every created file;
- UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- exact 46-path/type/mode checks;
- all 38 protected candidate paths against opening bytes;
- all noncandidate tracked paths against HEAD;
- package export/script preservation;
- source and migration inventories;
- migration `0005` absence;
- before/after external clone equality;
- live-cache opening/closing member equality including nanosecond mtimes from
  the true opening capture.

External scans use `lstat`; hash regular files only; never follow symlinks or
open FIFOs/sockets/devices. Remove only task-owned roots after all processes end.

## 12. Closeout and stops

Opening and closing committed coordinates must match. Final status remains the
same 29 modified and 17 created paths, unstaged and unmerged.

Only the eight repair paths may differ from the opening candidate.

Recompute twice all 46 endpoint receipts and the exact replacement recipe.
Return the eight transitions plus proof the other 38 receipts are unchanged,
and report final component lengths, total bytes, and SHA-256.

Return:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V1_REPLAN_REQUIRED`

if another authority owner, document, guard, production module, public surface,
schema/migration, D2/C2 behavior, or frozen worker/Wire/capsule semantic change
is required.

Return:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V1_BLOCKED`

for baseline drift, concurrent work, validation failure not safely correctable
within the eight paths, or cleanup uncertainty.

Success:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V1_VALIDATED_READY_FOR_REAUDIT`

Success requires all four findings closed, preserved D1 behavior, all transformed
defects detected, all 12 groups/full repository passed, and the exact candidate
left unstaged/uncommitted.

Closeout must include:

1. verdict and visible settings;
2. opening/closing Git coordinates;
3. exact eight-file transitions and 38-file preservation;
4. final replacement identity;
5. handback field/status invariants and direct specimens;
6. run-owner process fence and fork evidence;
7. supervisor cleanup classification and process-evidence preservation;
8. frame-error normalization and integrated mapping;
9. transformed-copy results and evidence limits;
10. validation commands, inventories, counts, warnings, failed trials,
    corrections, skipped work, and cleanup;
11. source/export/migration/cache preservation;
12. remaining D2/C2 work and continuation capsule.

Success authorizes only a fresh independent read-only re-audit. It authorizes no
commit, publication, D2, C2, migration `0005`, live provider/supplier work, Git
effects, ES/Bridge integration, or RW0-E.
