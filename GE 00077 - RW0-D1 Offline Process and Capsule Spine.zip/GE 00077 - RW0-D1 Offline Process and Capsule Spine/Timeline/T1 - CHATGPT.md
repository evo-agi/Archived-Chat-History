# Decision

**RW0-D offline message-bus-free vertical slice comes first. RW0-C2 durable-state implementation comes second.**

Do not start them as parallel implementation programs. The next observable capability should be:

> **One supplied intent enters Coordinator once; Coordinator drives planning, process-separated fake worker execution, capsule creation, validation, independent review, model review, and returns one typed handback—without the user relaying intermediate messages.**

That directly attacks the current product bottleneck. Implementing C2 persistence first would add important safety and recovery machinery, but it would leave the user carrying plans, worker results, capsules, validation, review, and model proposals between components.

The recent semantic work has established enough logical boundaries to implement the offline path. More standalone contract freezing now has lower value than exercising those boundaries in an actual process flow.

## Current implemented capability

The repository currently has substantial **internal state and semantic foundations**, but no operating autonomy loop:

- Guarded SQLite mutation, `WriterSession` fencing, transitions, global stop, program genesis, author-effect establishment, pre-execution proposal admission/selection, and RW0-C1 phase/evidence persistence with receipt-first replay and three-way recovery are implemented.
- C2A, RW0-B1, RW0-B2-Wire, RW0-B2-Capability, and post-execution owner modules provide private pure values, canonical identities, codecs, relations, and evaluators.
- The current executable boundary ends at typed pre-execution proposal admission and Coordinator selection/non-selection.
- There is still no model/provider invocation, dispatcher, subprocess launcher, worker, supervisor, capsule builder/store, validation executor, independent-review executor, model-review invocation, durable C2 decision writer, terminal-outcome runtime, service, queue, or autonomous loop.

The repository says this directly in `.docs/autonomous-software-development-operating-model.md:43–70`, `.docs/worker-execution-boundary.md:32–56`, `.docs/c2b-durable-development-state.md:24820–24826`, and `AGENTS.md:101–110`.

The public package also still describes itself as intentionally providing no worker runner, background runner, network client, or CLI entry point: `src/ge_nwp_coordinator/__init__.py:1–7`.

## Target-only contract debt

The merged target contracts now exceed the implemented operating path in several areas:

- **RW0-C2 decision:** five-branch reduction, acceptance-family semantics, replay, and whole-family recovery are frozen but have no command, reducer, writer, reader, transaction integration, or callable runtime.  
  `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:3–34`
- **Private C2 values and graph profile:** frozen, but no physical representation, reader, writer, provisioner, production caller, or runtime exists.  
  `.docs/rw0-c2-private-value-versioning.md:556–567`
- **Scope-admission provisioning:** accepted target semantics exist, but no source verifier, SQL representation, provisioner, or recovery implementation exists.  
  `.docs/rw0-c2-scope-admission-provisioning-contract.md:305–315`
- **First-live custody:** a single-realization posture is selected, but no supplier has passed the platform-conformance gate.  
  `.docs/rw0-c2-first-live-proof-posture.md:150–198`
- **RW0-D mechanics:** supervisor, transport plumbing, fake model/worker processes, capsule custody, validation, review, and typed orchestration are unimplemented.  
  `.docs/rw0-remote-worker-contact-phase-entry.md:467–500`
- **Terminal outcome:** semantic role exists, but no durable identity, representation, writer, receipt, or recovery runtime exists.  
  `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:486–496`

This debt should no longer be paid one semantic seam at a time. The next implementation should consume multiple already-frozen interfaces together.

## Why RW0-D must precede RW0-C2 implementation

| Question | RW0-D first | RW0-C2 first |
|---|---|---|
| Removes the user as routine message relay | **Yes, directly** | No |
| Produces an observable end-to-end behavior | **Yes** | Only durable state operations |
| Needs a real authority/custody supplier | No; fake sources and disposable state are explicitly allowed | A meaningful live path eventually does |
| Exercises model/worker/capsule/validation interfaces | **Yes** | No |
| Reduces risk of persisting the wrong evidence shape | **Yes** | No; it would persist mostly fixture-derived inputs |
| Required for RW0-E | Necessary process proof, but not sufficient | Necessary durability, but not sufficient |
| Current implementation distance | Process/orchestration work | Migration, transaction, reader, writer, recovery, and guard integration |

The strongest repository support for this order is the first-live contract itself: RW0-D may repeat with artificial source observations, fake transport and model processes, isolated temporary state, no real enrollment, no production credentials, and no network. It still requires actual offline process and custody mechanics, but it is not blocked by the live supplier. `.docs/rw0-c2-first-live-proof-posture.md:200–219`

There is one sequencing ambiguity to correct. The older tranche map lists RW0-C before RW0-D at `.docs/rw0-remote-worker-contact-phase-entry.md:467–479`, while the newer first-live owner explicitly makes offline RW0-D independent of real continuity and physical C2 implementation. The **RW0-D implementation tranche should amend that sequencing in the same commit**:

- RW0-C1 and the existing pure semantic contracts are prerequisites.
- RW0-C2 physical persistence is **not** a prerequisite for the non-recoverable disposable RW0-D proof.
- RW0-C2 implementation remains mandatory before RW0-E.

That is a bounded sequencing clarification inside source work, not another standalone contract tranche.

# Selected next capability

## RW0-D offline closed loop

One invocation should perform this sequence without an intermediate user message:

```text
supplied intent
→ deterministic fake model-planning process
→ typed pre-execution plan/proposal
→ Coordinator plan selection
→ process-separated fake coding worker/Codex process
→ candidate capture
→ immutable capsule manifest and portable digest
→ validation process
→ independent-review process
→ deterministic fake model-review process
→ typed handback
```

The handback should state what happened and bind the exact evidence, for example:

- run/attempt/candidate identities;
- capsule manifest ref and portable digest;
- worker outcome;
- validation outcome;
- independent-review outcome;
- model recommendation;
- failure or stop reason;
- evidence references required for inspection.

It is a **handback of evidence and proposal**, not a durable C2 decision.

The acceptance criterion is simple and product-relevant:

> The user provides one intent and receives one terminal typed result. The user does not copy a plan into a worker, copy worker output into validation, relay validation into review, or relay review into another model interaction.

## Interfaces that must remain stable between RW0-D and RW0-C2

The offline slice should implement against the existing logical interfaces rather than create a disposable parallel protocol.

1. **Worker command and delivery identity**

   Preserve semantic attempt, program/version, command digest, fences, repository/base identity, path scope, and delivery correlation.  
   `.docs/worker-execution-boundary.md:168–198`

2. **Worker observation**

   Use the existing `WorkerObservationV1` identity and finite outcome model for worker, process, capsule, validation, and review evidence.  
   `.docs/c2a-first-slice-semantic-protocol-contract.md:495–531`

3. **Candidate capsule**

   Use `CandidateCapsuleManifestV1`, its portable digest, exact authorized path entries, before/after bytes, and modes.  
   `.docs/c2a-first-slice-semantic-protocol-contract.md:533–577`

4. **Validation and independent-review roles**

   Validation, independent review, model proposal, and Coordinator decision remain distinct. No successful tool result or model response becomes acceptance.  
   `.docs/c2a-first-slice-semantic-protocol-contract.md:1239–1271`

5. **Model-review proposal and C2 input vocabulary**

   RW0-D should emit the existing post-execution proposal/evidence vocabulary and five recommendation classes so the later C2 writer consumes the same logical inputs rather than a translated second format.

6. **Authority/currentness provider seam**

   RW0-D uses a fake provider implementing the same narrow observation interface that a later qualified source will implement. The fake provider may assert synthetic premises; it must not be embedded in worker or model logic.

7. **One-way authority flow**

   Worker, validator, reviewer, and model produce evidence. Coordinator alone can later turn admitted evidence into durable progression. That separation is already the governing target.  
   `.docs/worker-execution-boundary.md:307–320`

The stable interfaces are logical values and roles—not SQL layout, migration number, transport wrapper, provider vendor, or process-management technology.

# Implementation-bearing tranches

## Tranche 1 — RW0-D offline message-bus-free vertical slice

This should be one end-to-end implementation tranche, not a series of value-contract tranches.

It should implement:

- one private offline run entry point accepting one supplied intent and bounded fixture configuration;
- fake authority/currentness sources;
- process-separated fake planner/model executable;
- process-separated fake coding worker/Codex executable;
- bounded supervisor with stdout/stderr, timeout, cancellation, reap, and cleanup;
- typed wire framing using the existing RW0-B2 protocol;
- real candidate file production in an isolated temporary workspace;
- canonical capsule construction and immutable manifest;
- validator and independent reviewer as distinct roles;
- fake post-execution model-review proposal;
- one typed handback;
- disposable state and deterministic cleanup;
- no manual stage-to-stage user relay.

Where practical, it should reuse the existing program/pre-execution semantic and persistence machinery in a disposable database rather than inventing a second program truth. It must not widen current SQLite authority merely to make the proof convenient.

A narrow conformance check should also prove that the final RW0-D evidence bundle can be projected into the already-frozen RW0-C2 decision inputs. That check belongs in the same tranche; it is not a parallel C2 implementation program.

### Observable exit evidence

- One command or private entry invocation takes one intent through every stage.
- Planner, worker, validator, reviewer, and review-model processes are visibly separate.
- No worker or model process can access Coordinator SQLite or writer authority.
- A real capsule is independently materialized and verified.
- At least one successful candidate and several typed failure paths complete without user relay.
- All temporary processes and workspaces are accounted for and cleaned.
- The final handback can be consumed by the frozen C2 input projection without semantic translation.

## Tranche 2 — RW0-C2 durable admission and decision slice

Start this only after Tranche 1 has demonstrated the actual evidence shapes and bindings.

It should implement, in one bounded physical/transaction program:

- the exact bounded-hybrid representation;
- migration `0005` only where the accepted logical family cannot truthfully fit the existing schema;
- program-independent scope-admission provisioning;
- guarded five-branch progression decision;
- atomic immutable acceptance fact on the acceptance branch;
- exact replay;
- readback-only three-way recovery;
- readers and collision probes;
- integration with the existing mutation controller and `WriterSession`.

Its inputs should be the exact capsule, worker, validation, review, model-proposal, authority, and currentness values exercised by RW0-D.

It should not reopen their semantics.

## Parallelism

**Do not run both implementation tranches concurrently.**

That would create two active programs, two audit/repair loops, and more—not less—user relay.

The only bounded parallel work worth allowing is non-mutating interface reconciliation inside the RW0-D tranche: prove that its outputs satisfy the frozen C2 input projections. No migration, writer, or C2 runtime branch should begin until the offline run completes end to end.

# Exact nonclaims

After Tranche 1:

- The system proves internal orchestration, not competent autonomous coding.
- The planner and review model are fake deterministic executables.
- The worker/Codex process is fake and uses no live subscription or credentials.
- There is no live authority, supplier, remote host, network, or ES route.
- There is no durable C2 decision, acceptance fact, or terminal outcome.
- There is no restart-safe orchestration or commit recovery.
- There is no Git commit, push, PR, merge, or publication.
- Typed handback is evidence/proposal, not durable progression truth.
- A successful offline proof does not authorize RW0-E.

After Tranche 2:

- Durable admission and C2 decisions exist, but terminal-outcome runtime may still be absent.
- A real currentness/custody supplier remains unqualified.
- Live credentials, qualified-host execution, and RW0-E remain blocked.
- ES integration remains separate.
- No Git/publication effect follows merely from acceptance.

# Evidence that would force replanning

Replan before or during RW0-D if any of these occur:

1. The end-to-end run requires changing the frozen C2A command, observation, capsule, or recommendation meanings rather than implementing them.
2. The user still must relay any intermediate plan, worker output, validation result, review result, or model proposal.
3. The worker or model process requires Coordinator database access, writer authority, or hidden shared mutable state.
4. The capsule cannot be recreated from the authorized base and verified independently of the worker workspace.
5. Validation or review cannot be represented by the existing finite observation model without losing a safety-critical fact.
6. The post-execution bundle cannot be projected into the frozen RW0-C2 input grammar without changing identities or digests.
7. The current pre-execution selection implementation cannot be composed into disposable offline execution without creating a second authoritative program state.
8. Process cleanup, cancellation, or result framing cannot be made bounded and deterministic without live credentials or network access.

Replan before or during C2 implementation if:

1. The complete decision/acceptance family cannot be made atomic under the existing transaction controller.
2. Migration `0002` plus a bounded supplemental representation cannot truthfully preserve replay and recovery.
3. Migration `0005` would require changing existing v1 canonical meanings.
4. Provisioning and decision recovery require competing writers or a second recovery authority.
5. Actual RW0-D evidence reveals a read set materially different from the frozen C2 contract.
6. Terminal storage turns out to be transactionally inseparable from the acceptance family; in that case terminal work must be brought into the same implementation program rather than patched afterward.

## Recommendation

**Begin with RW0-D.**

It is the first tranche that changes the operating experience rather than only the specification surface. It removes you from the internal relay loop in a controlled, offline proof and supplies real integration evidence for the subsequent durable-state implementation.

RW0-C2 follows immediately after, using the interfaces and evidence that RW0-D actually exercised.

### Sources

Current merged snapshot, tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`, principally:

- `.docs/autonomous-software-development-operating-model.md:43–109`
- `.docs/worker-execution-boundary.md:32–56, 168–215, 307–360`
- `.docs/rw0-remote-worker-contact-phase-entry.md:24–75, 180–276, 386–441, 467–524`
- `.docs/rw0-c2-first-live-proof-posture.md:118–219`
- `.docs/c2a-first-slice-semantic-protocol-contract.md:471–577, 1239–1271`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:322–375, 418–519`
- `.docs/rw0-c2-private-value-versioning.md:533–567`
- `.docs/rw0-c2-scope-admission-provisioning-contract.md:305–315`
- `.docs/c2b-durable-development-state.md:24510–24529, 24820–24826`
- `AGENTS.md:74–110, 885–930`
- `src/ge_nwp_coordinator/__init__.py:1–7`

**Confidence:** High on the current capability and debt assessment. High on RW0-D-first as the shortest path to removing the user’s message-bus role. Medium-high on the two-tranche boundary; actual process/capsule integration may reveal a small interface correction, but that correction should occur inside the implementation tranche rather than as another standalone contract program.
