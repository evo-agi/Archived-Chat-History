Here is Codex's response:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

The V4 repair is complete and remains **unstaged and uncommitted**. All 12 required validation groups passed in a remote-free clone of the final 46-file candidate. This is implementation validation; fresh independent read-only acceptance remains outstanding.

**Settings and Git state.** Visible model: GPT-6-based Codex; exact model ID and reasoning effort: not visible. Permissions: `danger-full-access`, approval policy `never`. I used no subagents or network access. The opening and closing Git coordinates are identical: `trunk_dev`, HEAD `0d0926e3a483a3ab1a4fd597ac0495927352bf35`, tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`, sole parent `630414faa07f4ac39c4a870a9cc44c7f92d46b80`, subject `docs: freeze RW0-C2 scope admission provisioning`. Local `origin/trunk_dev` remains 0 ahead / 0 behind; one worktree, index equal to HEAD, no unmerged path or active Git operation. Local tracking equality was not treated as remote verification.

### Repair and invariant

[The capture owner](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_workspace.py:39>) now validates direct construction, replacement, and a forged exact instance at consumption. Its complete graph is:

| Value | Required contents |
|---|---|
| `D1CandidateCapture.entries` | Exact tuple of three exact `D1CapturedEntry` records, in the fixed `PATHS` order |
| Entry `path` / `mode` | Exact strings: the path at that ordinal and `"100644"` |
| Entry `before` / `after` | Exact bytes, each at most 1,048,576 bytes |
| `changed_path` | Exact allowed path string naming the **one** entry whose bytes changed |

Types are checked before comparison or iteration over entry data. Bytes remain opaque; legitimate repository-relative path strings remain allowed. `blobs()` revalidates. [Handback admission](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:123>) invokes the same owner validation on every status carrying a capture; [capsule build and independent verification](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_capsule.py:18>) do likewise. Invalid values produce content-free private errors without opening the injected resource.

The handback still has exactly 16 fields. `status` and `reason` are exact closed strings; `workspace_cleaned` is an exact Boolean. Each of `program_result`, `author_result`, `author_command`, `planner_process`, `selected_bundle`, `section41_result`, `phase_basis`, `phase_result`, `worker_process`, `wire_result`, `wire_classification`, `capture`, and `capsule_manifest` must be either `None` or its exact existing record type. The [finite prefix and reason checks](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:47>) also bind author command digest, selected proposal, Section 41 disposition, phase basis/result identities, process facts, and usable Wire classification without I/O.

For the matrix below, the evidence prefix is ordered `P,A,C,p,B,S,b,r,w,W,K,X,M`: program result, author result, author command, planner process, selected bundle, Section 41 result, phase basis, phase result, worker process, Wire result, Wire classification, capture, manifest. Prefix number *n* requires precisely its first *n* values; every later value is forbidden.

| Reason | Permitted prefix and necessary facts |
|---|---|
| `complete` | 13, `capsule_ready`; both processes started, `ok`, clean; Section 41 selected, Wire usable, workspace cleaned |
| `invalid_input` | 0, `stopped` |
| `durable_commit_unresolved` | 0, 1, 5, or 7, `stopped`: the four guarded recovery sites |
| `durable_conflict` | Enumerated 0–11, `stopped`, with normal prior-stage process and selection predicates |
| `planner_start` | 4, `stopped`; exact failed/invalid launch observation with no PID, process group, exit code, output, or cleanup claim |
| `planner_frame` | 4, `stopped`; started, `ok`, clean planner observation |
| `planner_limit`, `planner_exit`, `planner_deadline`, `planner_cancelled` | 4, `stopped`; respectively output/stderr limit, nonzero exit, deadline, or cancellation, with proved cleanup |
| `nonselection` | 6, `stopped`; nonselected Section 41 result, no phase |
| `c1_phase_failure` | Retained vocabulary, but no current producer site; no fabricated handback is admitted |
| `worker_start` | 9, `stopped`; exact failed/invalid launch observation; preceding phase retained and workspace cleaned |
| `worker_frame` | 9 with a clean `ok` worker and no decoded result, or 11 with nonusable classification |
| `worker_limit`, `worker_exit`, `worker_deadline`, `worker_cancelled` | 9, `stopped`; matching process reason, proved cleanup, workspace cleaned |
| `unsafe_candidate`, `missing_candidate`, `excessive_candidate` | 11, `stopped`; usable Wire classification, no capture, workspace cleaned |
| `capsule_mismatch` | 12, `stopped`; validated capture retained, no manifest, workspace cleaned |
| `process_cleanup_unresolved` | Enumerated 0–8, cleanup status; prior observations retained |
| `planner_cleanup_unresolved` | 4, cleanup status; started planner, cleanup unproved, no selection |
| `worker_cleanup_unresolved` | 9, cleanup status; started worker, cleanup unproved, no Wire result |
| `workspace_cleanup_unresolved` | 8–13, cleanup status; `workspace_cleaned=False`, including legitimately reached capture or manifest |

From prefix 5 onward the planner must be `ok` and clean; from 7 onward Section 41 must be selected; from 8 onward the phase result must match its basis; from 10 onward the worker must be `ok` and clean; from 12 onward Wire classification must be usable. [The runner](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:326>) now classifies failed starts before the cleanup predicate, retaining the supervisor’s failed-start observation. If handback construction fails, it removes its newly owned state root and re-raises rather than fabricating another result ([line 485](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:485>)).

[The Wire consumer guard](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b2_wire_boundaries.py:638>) now independently rejects module-level admitted-class value exports and direct, aliased, and nested `importlib`/`__import__` loading. Its positive retained handback consumer and prior import-permission controls pass. This closes the reported **Low guard-adequacy gap**; it was not a demonstrated production dynamic loader.

### Behavioral evidence

Direct tests reject an open `RW0D1OfflineRun`, an arbitrary object, and its actual live state-root `Path` across capture container, entry, and leaf roles. They cover normal construction/replacement and forged exact wrappers at handback and capsule boundaries ([workspace tests](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_workspace_capsule.py:82>), [handback tests](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_handback_values.py:414>)). Actual-run injection of each reported object under an emitted nested entry rejects the handback, removes the new state root, and leaves the original run available for its normal close ([integration test](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_offline_integration.py:427>)). Healthy capture bytes and modes and independent manifest reconstruction still pass.

Actual returned handbacks cover input rejection, malformed planner, nonselection, unresolved durable recovery, failed planner/worker launch, worker failures, timeout/cancellation, selector cleanup uncertainty, workspace cleanup uncertainty, and normal `capsule_ready`. The [fixed test-side reason matrix](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_d1_handback_values.py:336>) checks every reason and permitted prefix, neighboring evidence, missing predecessors, and stopped/cleanup mixing. Creator-PID custody, process cleanup, frame normalization, B1/Wire permissions, guarded durable writers, and capsule reconstruction remain covered.

Six transformed copies of the **final bytes** parsed and collected normally, then each failed semantically at its fixed test:

| Removed behavior | Observed failure boundary |
|---|---|
| Capture constructor validation | Invalid direct capture no longer raised `D1WorkspaceError` |
| Handback deep consumption | Forged nested resource no longer raised `ValueError` |
| Stopped-stage table | Impossible neighboring prefix no longer raised `ValueError` |
| Truthful worker-start observation | Actual failed launch returned `durable_conflict` instead of `worker_start` |
| Wire value-export guard | `D1WireExport = RW0WireWorkerResultV1` was accepted by that helper |
| Wire dynamic-load guard | `importlib.import_module(...)` was accepted by that helper |

An early development-clone trial had 75 passes and one **test assertion** failure: it incorrectly demanded rejection when removing the sole program result legitimately changed a broad failure from allowed prefix 1 to allowed prefix 0. I corrected that assertion, reran it successfully, then ran the final groups after the last edit. There was no production-code failure in that trial.

### Final receipts

Only the eight permitted paths changed from opening; each remains regular, nonsymlink, mode `0644`. The other 38 candidate endpoints are opening-exact, and all 217 noncandidate tracked files are HEAD-exact. All 46 pass UTF-8, no BOM/CR, one final LF, and trailing-whitespace checks; `git diff --check` and all 17 addition no-index checks pass. No document, B1 version-3 owner/projection, schema, migration, export, or other source path changed.

| Permitted path | Opening bytes → final bytes | Opening SHA-256 → final SHA-256 |
|---|---:|---|
| `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 → 3,985 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` → `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` |
| `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 9,698 → 14,451 | `76ef6a902733a0790da927b4881ad4bef6d2555d6b63be12517d347ea4f46802` → `b79198c472fa7d9cf69edec8aa26c755db3511b5ea8d81b34731b688d34a5af6` |
| `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,193 → 22,561 | `29e1dfb51e09941acea43ff907440f171a023d46a2de9bdce002d88f9088bc9f` → `34d8eabb5d8e0e5e3fc1296c63399cb33218c426856348069b6eee7c554e12bf` |
| `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 → 8,893 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` → `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` |
| `tests/test_rw0_b2_wire_boundaries.py` | 34,490 → 37,866 | `8d600d1044947964b74786f1bfa59326d79541d0ace74d57d4ccd97e82c68cc9` → `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` |
| `tests/test_rw0_d1_handback_values.py` | 11,665 → 20,535 | `20470ec086cbad881c6d4687100905d4670b7f14cc53f3966e342585f1e4bda4` → `2b86472ca052cca0f17cd0d48161eae3fe1e58081f7892adf3372552230013d7` |
| `tests/test_rw0_d1_offline_integration.py` | 13,881 → 19,715 | `fab122192528cdd0f668bc63181bea2e4a2fc70d3d1f42bd92061ff8532ffa79` → `a866af81fcae94c48b8f5bb24e932d0afcbaa1d5c9758a14e08f9beb24e3f78a` |
| `tests/test_rw0_d1_workspace_capsule.py` | 2,781 → 6,129 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` → `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` |

The unchanged 46-row replacement recipe was recomputed twice from fresh reads: **4,494,151 component bytes + 25-byte prefix = 4,494,176 bytes**, SHA-256 `a79100018f014351a18cf5fb21464c6b26ac0e9bd2de94f1268d57e66857a236`. Opening identity was `b82b43fc4da2e5f258436cec351dcc2a561057b9edb64d7bffbbb35003c84974`.

### Twelve serial validation groups

For each numbered group, I ran collection and execution separately in the final clone with `umask 022`, `TMPDIR=/tmp/rw0-d1-v4-final-yu6ygh28`, `PYTHONDONTWRITEBYTECODE=1`, and `PYTHONPATH=.:src`:

```text
python3 -B -m pytest -q -p no:cacheprovider --basetemp=/tmp/rw0-d1-v4-final-yu6ygh28/groups/N/collect --collect-only <group paths>
python3 -B -m pytest -q -p no:cacheprovider --basetemp=/tmp/rw0-d1-v4-final-yu6ygh28/groups/N/run <group paths>
```

For groups 1–11, `<group paths>` was the sorted, deduplicated expansion of the exact `test_<token>.py` memberships in the V4 request; group 12 had **no path arguments**. The clone’s remote was removed before execution. Each row below reports collected nodes and passes; every run exited zero.

| Group | Files | Inventory SHA-256 | Collected / passed |
|---|---:|---|---:|
| 1 D1 | 7 | `ad607169bab63d557cd1a8b1dc1b6a0378aee9c18e2120c40d620e5293d64e00` | 104 / 104 |
| 2 program | 9 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` | 218 / 218 |
| 3 author effect | 4 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` | 46 / 46 |
| 4 Section 41 | 6 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` | 168 / 168 |
| 5 C1 | 8 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` | 109 / 109 |
| 6 worker semantics | 4 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` | 135 / 135 |
| 7 Wire | 7 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` | 135 / 135 |
| 8 Capability | 4 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` | 60 / 60 |
| 9 bootstrap guard | 1 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` | 289 / 289 |
| 10 legacy guards | 8 | `1c4f3fc6edc6b3561d426d52d2cd8b4ea8c65ea979311cf151f906d0f4190e8e` | 1,773 / 1,773 |
| 11 changed owners | 6 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` | 679 / 679 |
| 12 full repository | 124 | `fa28bc5ac85a1abe53fe8aea949e711fda6f3acdcab508e4f5214fef53fd575d` | **8,966 / 8,966** |

Groups 2/3 overlap by 46 nodes; groups 7/11 by 31. The full count reconciles as `8,942 + (104−92) + (135−123) = 8,966`. Groups 10 and 12 each reported only the three expected Python 3.13 multithreaded-fork `DeprecationWarning`s at the named writer-session tests; no other group reported warnings. Before/after content and mode matched for all **263 clone file endpoints**.

The live `__pycache__` directory and its 37 regular members match opening path, type, mode, size, nanosecond mtime, and SHA-256 exactly. No task-owned fake child process or D1 state/workspace/planner directory remained. Both identified external validation roots were removed; no other root was deleted.

**Continuation capsule.** The final candidate identity is `a79100018f014351a18cf5fb21464c6b26ac0e9bd2de94f1268d57e66857a236` on the unchanged `trunk_dev` HEAD, still 29 M / 17 C and unstaged. The next independent read-only audit must verify the new 46 endpoint receipts and complete the previously unperformed durable-readback/recovery and wider hostile-copy acceptance campaign. These implementation tests do not confer independent acceptance or commit eligibility. No D2/C2, live worker/provider, Git effect, ES/Bridge integration, migration 0005, publication, or deployment authority was added.
