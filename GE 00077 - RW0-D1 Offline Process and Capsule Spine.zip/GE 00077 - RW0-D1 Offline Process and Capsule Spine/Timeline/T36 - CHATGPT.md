## Disposition

**Accept the audit block. Preserve the retained V6 runtime and repair the permanent integration test. Do not stage, commit, or begin D2.**

The finding is precise: **the current runner performs independent capsule verification, but the tests do not protect that step from removal.** The auditor deleted only the call, kept the module importable, and still obtained 108 passing D1 tests and a `capsule_ready` result.

This is not an observed omission in the retained runtime. It is nevertheless acceptance-blocking because detecting bypassed independent verification was an explicit, existing safeguard—not a new coverage requirement introduced by this audit. Coordinator_RW0_D1_Offline_Proc…

**No production-source change or architecture replan is indicated.**

## Why the existing test is insufficient

These are different claims:

```text
The returned capsule can be independently verified.
```

```text
The runner independently verified this capsule before declaring it ready.
```

A test that calls the verifier after receiving the handback can establish the first while completely missing the second. That explains the reported mutant: the test supplies the verification that the altered runner omitted.

The repair must protect the **runner’s use of the safeguard**, not add another test-side verification of the final artifact.

## Selected one-file repair

Only this existing candidate file may change:

```text
tests/test_rw0_d1_offline_integration.py
```

The other **45 candidate endpoints** remain byte-identical, including all nine D1 production modules, the capsule tests, every document, and the repaired B1/Wire guards. All **217 noncandidate tracked files** remain HEAD-exact.

The selected permanent tests establish two complementary properties.

### Verification actually precedes readiness

A real D1 invocation should use a test-local wrapper around the verifier reference that the runner actually calls. The wrapper must **call through to the original verifier**, retain its actual arguments, and record successful completion only after that verifier returns successfully.

The test must establish that the current single-candidate invocation verifies the actual manifest and capture, with their corresponding lineage, **before the first `capsule_ready` handback is constructed or exposed**.

It must not satisfy the assertion by calling the verifier itself after return, replacing verification with a successful mock, checking a source-code substring, or merely counting calls without checking their inputs and order.

The existing requirement is already that parent capsule construction and independent verification precede the handback; no new runtime state or verification receipt is needed. Coordinator_RW0_D1_Offline_Proc…

### Verification refusal actually prevents readiness

A separate real-run test must exercise a genuine refusal from the existing verifier—for example, a structurally valid capture that no longer matches the accompanying manifest.

The specimen must reach the **real independent verification boundary**. Rejection by the capture constructor before that boundary would not prove the runner honors verifier refusal.

The runner must then produce its existing appropriate negative outcome, preserve the evidence that outcome permits, and clean up its owned workspace and processes. The test must not accept “any exception,” invent a new Boolean-return convention, or quietly relabel the failure as a generic durable conflict.

The retained handback contract identifies `capsule_mismatch` as a capture-bearing, non-ready outcome. Codex must confirm its actual producer and failure convention before writing the assertion. If the runtime does not honor its own existing convention, that becomes a specific production finding—not permission to weaken the test or edit source in this repair. Coordinator_RW0_D1_Offline_Proc…

## Bounded causal controls

The handoff requires three external-only defect classes:

| Deliberate defect | What the permanent tests must detect |
|---|---|
| Delete the runner’s verifier call | Missing runner-owned verification before readiness |
| Leave the call but replace verification with its neutral-success behavior | An inconsistent capsule relation no longer causes rejection |
| Let the runner continue successfully after a genuine verification refusal | Refusal no longer prevents readiness |

The first reproduces the actual audit finding. The other two prevent a superficial call-counter repair from passing while verification has become ineffective.

These are small, disposable transformed copies—not another general mutation framework. They must parse, import, and collect normally. Syntax errors, unrelated source-inventory failures, and test-side calls that manufacture the missing event receive no causal credit.

## Preserve the progress from this audit

**The opening mechanism worked this time.** The report establishes this attempt’s pre-Git opening and closing index/cache equality. There is no reason to reset the index, recreate the candidate, or repeat the earlier procedural restart.

The report also supplies useful focused evidence for the B1 repair: 23 selected tests, both full-module alias refusals, and both acquisition-predicate regression checks. Nothing here calls for another B1 amendment.

The remaining limitations are unchanged: the focused D1 runs were not final Group 1 acceptance; row presence and selected digests were not complete four-family readback; the wider process/Wire/FD/workspace, mutation, semantic-diff, and final twelve-group obligations remain unperformed.

Those omissions must remain explicit. The audit mandate requires complete readback of the **four used durable families**, not merely a table count, and distinguishes permanent-test protection from an audit-only observation. Coordinator_RW0_D1_Offline_Proc… Coordinator_RW0_D1_Offline_Proc…

## Validation treatment

Only the integration-test file changes, so:

```text
Groups 2–11:
preserve exact test-file inventories and rerun their regressions

Groups 1 and 12:
recompute inventories and execute from final repaired bytes

Count reconciliation:
final full count = 8,872 + final D1 Group 1 count
```

The equation is bookkeeping, not a target to achieve by changing test selection.

The repair must execute all twelve implementation-validation groups after its final edit. It must then return for independent acceptance; its own passing tests cannot fill the auditor’s omitted work.

## Complete repair handoff

Resume the **same implementation Codex conversation**, preserving the current retained checkout.

:chatgpt-content-reference{index="5"}[Download the complete RW0-D1 audit-repair prompt V7](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V7_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V7_Prompt.txt

Bytes:
48,957

SHA-256:
1cfdbf8e63973124f603c6708a1be126574db8857d2d36422d38efbcfd83e46d

Lines:
725

Final newline:
present
```

It starts from the unchanged retained identity:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,514,611 bytes
9e1244f91b0a78350928715e3de1b9da5861e29ef92f777e032ec59d370b5fc9
```

The sole repair endpoint opens at:

```text
tests/test_rw0_d1_offline_integration.py

23,432 bytes
e5250a4921d1d441716fa356c742dbc886a0d13f7386c90e8409094c733f2109
```

The prompt includes the complete 46-path receipt table, the successful forced-environment opening mechanism, the one-file ceiling, call-through and rejection requirements, three bounded defect controls, and all twelve exact validation memberships.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V7_VALIDATED_READY_FOR_REAUDIT
```

It supports only a **fresh independent read-only acceptance audit**. It authorizes no staging, publication, D2, physical C2, migration `0005`, live authority/provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read your latest closeout and the complete restart mandate. I corroborated the 29 baseline blob identities and 17 additions’ absence against the mounted snapshot, checked the receipt arithmetic and twelve inventory hashes using baseline bytes plus supplied candidate hashes, and reopened the generated prompt. Its embedded opening/helper code was syntax-checked, not executed against your Mac.

I did **not** inspect the live D1 source, reproduce the deletion specimen, or run repository tests. The current runner call and the surviving 108-test mutation remain the auditor’s reported observations.

Some older uploads have expired. Re-upload a specific original when a later comparison requires its bytes; this handoff needs no historical attachment.

**Sources:** Your latest audit closeout; the issued Restart 01 mandate cited above; October 15 Coordinator snapshot for baseline corroboration.

**Confidence:** High on the one-file integration-test boundary and preserving the runtime. The repair’s causal adequacy and complete independent acceptance remain unproved.
