# Governed Execution Coordinator — RW0-D1 Audit Repair V5: Process-Outcome Consistency

## Mandate

Continue the RETAINED uncommitted 46-path D1 candidate. Do not recreate D1,
roll back its capture/stage/Wire fixes, or use an earlier replacement identity.

The latest independent re-audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

It independently reproduced every endpoint and the replacement identity, read
all nine D1 source modules and seven D1 test modules, and passed a preliminary
104-test D1 selection. It demonstrated one Medium defect:

- replacing the worker process evidence in an actual successful handback with
  reason="ok", exit_code=99, or exit_code=None was still accepted as
  capsule_ready; negative PID/process-group values were also accepted;
- the supervisor itself classifies a nonzero exit as nonzero_exit;
- an injected exit 99 in an actual runner invocation instead stopped at
  worker_frame with unusable Wire classification and no capture.

The defect is inconsistent TRANSIENT EVIDENCE accepted by the handback. The audit
found no durable-writer or executable-authority bypass and did not show that the
normal successful run emitted these contradictory facts.

Repair the process-value invariant once in its existing owner and enforce it at
handback consumption. Do not add only a success-label check, make a second Wire
classifier, or start a standalone contract/schema tranche. Preserve the current
D1 -> D2 -> physical C2 sequence and all retained repairs.

The critical path is:

exact retained provenance -> inspect process producer/consumer and Wire relation
-> one owned process-value validator plus consuming checks -> direct and actual
failure/success specimens -> final twelve-group validation -> independent audit.

Parent is the sole writer; no subagents. Use the highest exposed reasoning
setting. Report visible model, reasoning effort and permission posture, or
`not visible`; do not seek additional account or computer access to expose
hidden settings.

Return operative findings INLINE with exact repo-relative path:line evidence,
full provenance/validation and a continuation capsule of at most 1,000 words.
No delivered report, manifest, patch, snapshot, archive, architecture package,
or freeze artifact. This prompt is complete; no historical attachment is needed.
Do not issue the next audit, publication, D2, or C2 prompt.

## 1. Required baseline and retained candidate

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: trunk_dev
- HEAD: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
- tree: 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4
- sole parent: 630414faa07f4ac39c4a870a9cc44c7f92d46b80
- subject: docs: freeze RW0-C2 scope admission provisioning
- upstream: origin/trunk_dev, locally 0 ahead / 0 behind
- one worktree; index equal to HEAD; zero staged/unmerged paths
- exactly 29 modified tracked files plus 17 untracked creations below
- no active Git operation, sequencer or unexpected lock.

Read AGENTS.md first. Inspect local Git/files non-mutatingly with optional locks
suppressed where appropriate. No fetch, refresh, normalization, reset, clean,
branch switch, configuration changes or overwriting concurrent work. Local
tracking equality is not fresh remote verification.

M means tracked modification; C means untracked creation, not a Git copy or
commit status. Require regular nonsymlink candidate files with Git mode 100644.
The report says candidate OS modes are 0644; verify and preserve actual modes,
including any noncandidate nonexecuting 0600 files. Never chmod unrelated files.
Require strict UTF-8, no BOM/CR, one terminal LF, and no trailing whitespace.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,451 | `b79198c472fa7d9cf69edec8aa26c755db3511b5ea8d81b34731b688d34a5af6` | `absent` | 14,528 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,561 | `34d8eabb5d8e0e5e3fc1296c63399cb33218c426856348069b6eee7c554e12bf` | `absent` | 22,637 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 9,502 | `5d47b82d8b24f38f4a2c54825405f0370e308159908a104fdd9bc73c1ab970d9` | `absent` | 9,589 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 47,819 | `b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 47,885 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 20,535 | `2b86472ca052cca0f17cd0d48161eae3fe1e58081f7892adf3372552230013d7` | `absent` | 20,606 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 19,715 | `a866af81fcae94c48b8f5bb24e932d0afcbaa1d5c9758a14e08f9beb24e3f78a` | `absent` | 19,790 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 8,476 | `890c0717fcb1f5f9b53919d3c73b10dc54c98d53d1f1473e52a75108831ce9aa` | `absent` | 8,550 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read each of the 29 M baseline blobs directly from HEAD. Verify each C path is
absent from HEAD/index. All 217 noncandidate tracked paths must equal HEAD
content/type/Git-relevant mode. There are 246 baseline plus 17 created = 263
repository endpoints. No extra path, deletion, rename, symlink, submodule,
executable change, export, schema or migration.

### Exact opening replacement identity

Reconstruct twice with fresh reads, without importing repository code:

```text
prefix: ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw bytes of HEAD blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact current file bytes
```

Required retained opening:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,494,151
prefix: 25 bytes
total: 4,494,176 bytes
SHA-256: a79100018f014351a18cf5fb21464c6b26ac0e9bd2de94f1268d57e66857a236
```

A concatenated and a streaming calculation are suitable. These receipts do not
prove correctness. Earlier 4,465,502-byte and older recipes are historical only.
On any mismatch, preserve actual work and stop without replacing expected hashes
or reconstructing bytes from them.

## 2. Eight-path ceiling; six primary repair paths

Primary production paths:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
```

Primary direct tests:

```text
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
```

The following two direct process-consumer test files are also permitted ONLY
where a necessary positive/negative fixture or regression must be aligned with
the strengthened outcome constructor. Prefer leaving them byte-exact:

```text
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_worker_process.py
```

No new path. These eight files are already untracked additions within the
46-path candidate. All 29 tracked candidate modifications and nine other
untracked additions remain unchanged: 38 protected candidate endpoints total.
All 217 noncandidate HEAD files remain exact. The candidate remains 29 M / 17 C.

The supervisor path is opened for its process VALUE validation and truthful
construction/return boundaries only. Do not redesign launch, pipe draining,
process groups, signals, deadlines, cancellation, FD policy or cleanup.

The handback consumes the validated process values and checks readiness/evidence
consistency. The offline path is opened only for its existing process-consuming,
Wire-classification and failure-return sites where required by this invariant.
Preserve it if no change is necessary.

Preserve specifically:

- all documents, AGENTS/README identities, D1 implementation owner;
- B1 version-3 registry, both fixed projections and importer guard;
- Wire source, consumer guard, permitted symbols and classifier behavior;
- workspace, deep capture validation and capsule construction/verification;
- process frames, fake child executables and pre-execution composition;
- current program/author-effect/Section 41/C1 writers, readers, recovery and
  private semantic source;
- package root, pyproject.toml, .gitignore, StateStore, exports and scripts;
- migrations 0001-0004, all schemas/configuration; no 0005;
- nine-module D1 inventory and one subprocess owner.

No new B1/Wire import, re-export, helper alias or consumer permission is needed.
Use methods of the already imported D1 process value rather than adding an
indirect dependency to evade a guard. Do not hide invalid fields in annotations,
coercions or an arbitrary object slot.

No staging, commit, push, PR, merge, branch change, network, dependency install,
provider/supplier, credential, live launch, D2, physical C2, terminal, ES, Bridge,
or RW0-E effect. Only fixed fake children and temporary test processes/databases
in the external validation environment are authorized.

## 3. Inspect the complete process invariant before editing

Read all three production repair paths and their tests fully. Consult the
CURRENT candidate's D1 owner, process-frame/capsule/handback consumers and
relevant source guards as data. Follow the unchanged Wire owner and classifier.

Reported inspection coordinates, which must be re-resolved from actual bytes:

- _rw0_d1_handback.py:89, :187 — process/readiness checks;
- _rw0_d1_process_supervisor.py:214 — nonzero-exit classification.

Before editing, provide one compact inline implementation table:

1. every field of D1ProcessOutcome: exact runtime type, optionality, owned meaning,
   legitimate producer sites and current validator;
2. every process reason/outcome and the compatible start/PID/group/exit/output/
   signal/deadline/cancellation/reap/cleanup combinations actually emitted;
3. every planner/worker consumer and the handback stages requiring ordinary clean
   completion versus allowed failure/cleanup evidence;
4. the worker exit observation passed to the EXISTING Wire classifier and how
   its returned value reaches handback;
5. actual imports/calls, finite guards or source pins indirectly affected by a
   method added to the already owned value.

This is local implementation reconnaissance inside the repair, not another
standalone map. It must expose the whole reason-to-fact relation rather than
patching only the currently demonstrated exit_code=99 example.

An invariant must come from existing producer behavior and selected D1 contracts,
not a table invented to make synthetic fixtures pass. Do not impose a new OS PID
namespace, public outcome schema, or arbitrary exit range. Preserve legitimate
negative signal return codes in FAILURE outcomes; they are not negative PIDs.

## 4. One owned process-value validator

### Ownership and use

Keep D1ProcessOutcome in _rw0_d1_process_supervisor.py with its existing record
shape. Add/refine one pure no-I/O full-value validation method owned by that
class. Use it at normal construction/replacement where supported and explicitly
at handback consumption of either planner_process or worker_process. The
runner must consume valid values at its existing boundaries; it must not trust
only the reason label or cast a malformed record into a supported result.

The validation method must inspect only the closed known record. It must not
launch, signal, poll, wait, call getpgid/kill, query current process existence,
open files, access SQLite or invoke the Wire classifier. It checks retained
facts; it does not certify that a process historically existed.

No alternate process wrapper, new evidence field, stage marker, validated flag,
new schema, public serializer, or second authoritative process/program ledger.
A frozen outer type is insufficient; consumption revalidates an exact wrapper
whose fields were forged in a controlled test.

### Exact types before comparisons

Validate exact built-in field/container types and then their owned relationships.
For example, any present PID, process-group ID and exit code must be exact ints,
not bool or int subclasses. IDs must be strictly positive when a launch occurred.
None is permitted only where the existing outcome meaning allows an absent fact.
An ok completed outcome cannot use None or a negative/zero PID or group.

Use existing field names and exact types; do not invent attributes from these
examples. Check every existing process field, including reason, byte-output and
cleanup/signal flags, with the smallest explicit immutable value grammar the
current owner requires. Reject malformed types before equality, ordering,
membership, hashing, decoding or normalization can invoke a hostile method.
Do not coerce with int(), str(), bytes(), JSON, tuple() or deep copy first.
Keep opaque stdout/stderr bytes opaque; do not add path-looking-text heuristics.

### Reason-to-fact consistency

At minimum enforce these distinctions, using the exact current vocabulary:

- ordinary ok completion requires an actual started observation, positive exact
  PID/group, and exact integer exit_code=0;
- a normal nonzero_exit result requires the corresponding observed nonzero
  return code, including supported signal-negative values; it cannot claim ok;
- failed/invalid start retains the existing no-process observation, not a fake
  positive PID or successful exit. Validate absent fields and any permitted
  diagnostic fields against the current producer;
- timeout, cancellation, I/O/limit and cleanup outcomes retain their actual
  observed return code and facts. A child can respond to cancellation by exiting
  zero, so do NOT require every failure/cancellation reason to have nonzero
  exit, nor require every record to have a completed exit;
- signal-request/delivery, direct-child reap, group-clear and selector/stream
  cleanup are separate facts. Apply only the relationships guaranteed by the
  existing supervisor and selected proof process model;
- cleanup uncertainty can coexist with a known zero exit. Do NOT force the
  process reason to change or erase known exit facts merely because cleanup
  failed. It cannot support capsule_ready.

For the fixed fresh-session launch, inspect and enforce the PID/group relation
that the existing implementation actually owns. Do not query a reaped process
or introduce a broader process-group identity contract. If an accepted relation
is narrower than positive IDs (for example the initial owned group equals the
launched PID), bind it only from the actual launch/owner evidence and test it.

A process record's reason, exit and cleanup cannot contradict one another. An
incomplete but legitimate observation remains valid failure/cleanup evidence;
it is not required to look like completed success.

Private rejection must be content-free and must not expose child output,
filesystem paths or authority material. Use the smallest existing private error
convention; no new durable reason taxonomy.

## 5. Handback and Wire consistency without authority widening

### Validate both process fields, on every admitted status

Require exact D1ProcessOutcome type followed by its complete owned validation
for any non-None planner_process or worker_process, before stage/readiness checks.
Do not validate only ready or only worker. A broad stopped reason cannot conceal
an internally contradictory ok outcome.

Whenever the existing reason/prefix matrix requires an ordinary successful
planner/worker, require genuine clean completion: reason ok, exact integer zero
exit, valid process identities, and the existing proved reap/group/stream cleanup
conditions. Use the owned validation/predicate, not another divergent process
reason grammar in handback.

Preserve the sixteen handback fields, exact durable identities, selected/phase
relations, deep capture validation and finite reason/prefix set. Valid
planner_frame after a clean zero-exit process is still possible if its output is
malformed; failed-start records remain legitimate; workspace_cleanup_unresolved
may retain a reached manifest but is not ready. Do not conflate process success,
frame validity, candidate validity, capsule verification or cleanup.

### Existing Wire boundary

The unchanged Wire contract states:

- RW0WireProcessResultClassificationV1 carries classification and reason only;
- usable/usable requires a valid result and exactly one zero process exit, with
  its current higher-priority invalid/resource/deadline/signal/cancellation rules;
- classification alone implies no teardown, durable fact, execution permission
  or acceptance.

Baseline references (verify against actual current source):

- .docs/rw0-b2-wire-protocol.md:53,94-98
- src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:560-576,1861-1913

Do NOT add a Wire classifier import or classifier execution to handback. Its
permitted Wire dependencies remain exactly the two existing evidence classes.
The offline runner is still the existing classifier caller; verify it supplies
an observation derived from the actual worker return code and related command/
fences/delivery, never a hard-coded zero or a value inferred only from reason.

At handback admission, retained usable classification cannot override a nonzero
or missing worker exit or otherwise invalid process record. Conversely, a
valid zero-exit process alone cannot make an unusable/missing Wire result ready.
All existing command/result/capsule relations remain necessary.

Do not claim the two-field classification proves which arguments historically
produced it. These checks establish internal consistency, not authenticated
execution or a new classification receipt. Do not create a second Wire algebra
or change any Wire status/priority/domain/digest rule.

### Truthful runner failures

Preserve real nonzero planner/worker exits as their correct existing typed
failure paths; preserve timeout/cancel/limit/cleanup observations and no later
unsafe progress. The reported injected (ok,99) -> worker_frame result is evidence
of the OLD defensive classifier behavior, not a requirement to keep a malformed
process record admissible after this fix.

If an internally forged/contradictory process result is rejected before a
supported typed handback can be formed, clean only that invocation's owned
resources and fail with the existing private safe error. Do not zero its exit,
rename it ok, drop its evidence, close another run, or emit a fabricated generic
stopped/durable_conflict to conceal the contradiction. Do not loosen handback
rules to carry impossible facts.

Any necessary runner alignment is confined to these existing consuming/error
sites. No supervisor lifecycle redesign or new runtime owner.

## 6. Fixed direct and actual-run evidence

### A. Start with independent real positive evidence

Use one real successful D1 run in an external test root. Retain its original
handback and own its cleanup explicitly. Reuse the same immutable good evidence
for finite constructor specimens instead of repeating costly DB setup per cell.

Prove normal success still has positive process IDs, zero exit codes, actual
current durable lineage, usable Wire evidence, valid capture/manifest and proved
cleanup. Verify handback construction performs no I/O or additional C1 write.

### B. Demonstrated and neighboring process mutations

For BOTH planner and worker fields, retain the good handback's other evidence
(including worker's usable Wire classification) and try:

1. reason ok with exit_code 99;
2. reason ok with exit_code None;
3. reason ok with a signal-negative exit code;
4. reason ok with False as an exit code or an int subclass equal to zero;
5. negative, zero, None, Boolean and integer-subclass PID values where a launched
   process is required;
6. the same invalid process-group values;
7. any inconsistent PID/group relation owned by the selected launch contract;
8. contradictory cleanup/reap/group/signal fields identified in the actual
   producer matrix.

Require normal construction/replacement rejection and consuming-boundary
rejection of a forged EXACT record that bypassed only constructor validation in
test code. Keep hostile objects intact until the type/relationship check. Do
not replace the class identity or monkeypatch the consumer away.

Exercise every handback category permitting a process value, including ready,
worker/planner frame failures, broad stopped prefixes and cleanup uncertainty.
A wrong independent stage invariant must not mask the missing process validation.

A valid nonzero_exit process record is not invalid by itself. Pairing it with
capsule_ready or contradicting usable Wire evidence must fail at the appropriate
handback relation. Distinguish malformed process values from valid negative
outcomes.

### C. Positive failure cases and Wire interaction

Run actual relevant paths using existing fixed fake modes and bounded fault
injection:

- ordinary planner and worker success;
- actual nonzero child exit; supervisor classifies it truthfully, no ready;
- genuine failed launch; retain a no-process failed-start observation;
- malformed planner/worker frame after otherwise valid zero-exit process;
- timeout and cancellation, including a zero-exit response if the selected
  supervisor can legitimately observe one;
- valid zero exit plus selector/stream cleanup uncertainty, preserving known
  process facts and cleanup_unresolved;
- valid worker process with unusable Wire classification, no ready;
- synthetic stale usable classification kept beside an altered process record,
  rejected without a new classifier call in handback.

Use actual existing classifier execution in the runner tests. Derive expected
classification from the unchanged owner, not from the returned value itself.
No redundant full-slice execution for every equivalent primitive mutation.

### D. Actual-return substitution and resources

Wrap the actual runner's process-return or final-handback boundary in a
controlled test and insert the demonstrated invalid outcome while retaining
otherwise genuine evidence. The corrected path must never return capsule_ready.
Test constructor and consumer enforcement separately so earlier rejection does
not falsely credit a later predicate.

Prove only the failing invocation's new roots are removed; the original run
used as the specimen remains open and its creator closes it normally. No new
child launch after the contradiction and no orphaned fake child/group/state.
No raw path or output payload leaks through the rejection.

### E. Independent invariant tests

Keep an explicit small test-side process reason/field matrix or independent
assertions derived from actual producer sites. Do not generate expectations by
asking the production validator whether each row is valid. Preserve the current
stage-prefix test oracle and its legitimate broad-prefix cases.

If old test fixtures intentionally represented malformed records, keep their
negative purpose and use bounded forged-wrapper injection at the intended
consumer. Do not turn all formerly invalid fixtures into positive data and call
that coverage. Justify changes in the two optional process-consumer test files.

## 7. Finite causal regressions

Use six focused transformed-copy CLASSES against final candidate bytes, with
fixed expectations unchanged. One specimen can cover overlapping assertions;
no universal fuzzer or dozens of duplicate full-suite runs.

| ID | Deliberate regression | Required discriminating test |
|---|---|---|
| P01 | omit owned constructor value validation | direct inconsistent ok/exit or PID record is wrongly accepted |
| P02 | handback validates only outer process type | forged exact ok/99, ok/None or invalid-ID record crosses consumer |
| P03 | omit zero-exit / exact integer / positive-ID predicate | fixed corresponding planner and worker specimens become accepted |
| P04 | validate only worker, only ready, or lose success prerequisite at later prefixes | valid-stage bad planner/stopped/cleanup specimen crosses the same boundary |
| P05 | trust retained usable classification or synthesize zero exit for classifier input | actual classifier/handback contradiction control fails; no inherited label credit |
| P06 | erase/relabel bad process evidence or skip rejection cleanup | actual-return test observes fabricated result or task-owned residue |

P03 may use a few separate substitutions for its distinct primitive predicates;
report their exact number and boundaries. Do not claim a removed consumer check
was detected only by constructor rejection: forge the exact input in that test.

Each credited copy must parse/import/collect normally and fail an intended
semantic assertion. A syntax/import error or unrelated global inventory failure
is not runtime mutation evidence. Credit all cases truthfully; no mandatory
survival hiding behind another global guard.

Retain and run permanent regression for deep capture/reason-stage/Wire fixes,
creator-PID real fork custody, selector/stream cleanup and frame normalization.
No re-audit acceptance is implied by these implementation-run controls.

## 8. Implementation and validation order

1. Authenticate retained endpoints, baseline, index and complete cache metadata.
2. Finish the compact process field/reason/site/consumer/guard inventory.
3. Strengthen the owned value, then consuming/readiness checks and direct tests.
4. Align only necessary runner/test construction sites, with no synthetic facts.
5. In a remote-free development clone, run process, handback, integration, Wire,
   B1 and runtime/scoped guards FIRST to expose a coupled check before a long run.
6. Complete the direct actual-return, legitimate failures and finite mutations.
7. After the LAST edit, build one fresh final remote-free clone and run all twelve
   groups below serially, even those passed during development.
8. Recompute final endpoint/aggregate identity, preserve retained candidate and
   clean only this task's external resources. Report ready only on complete gates.

Do not create another architecture package or separate contract step. If an
actual existing owner/closed importer requires another path, preserve work and
name the exact contradiction instead of weakening or bypassing that guard.

## 9. Exact final validation

All executable work is confined to task-owned external local-only clones of
exact HEAD with all 46 current candidate endpoints overlaid and remotes removed.
Use installed dependencies only. No live-checkout repository imports, scripts,
compilation, pytest, subprocess probes or SQLite connections.

BEFORE executable work, lstat the known live __pycache__ DIRECTORY and all 37
regular members. Record path/type/actual mode/size/st_mtime_ns and SHA-256 for
regular files. Directory metadata is mandatory; mere presence is insufficient.
Do not open unrelated ignored state or secrets. Do not claim to reconstruct any
prior audit's missing historical metadata.

Create external roots mode 0700; set TMPDIR inside the owned root. Preserve
actual source OS modes; test-process umask 022. Precreate distinct collection/
execution basetemp parents. Disable bytecode and pytest cache. No xdist, overlapping
runs or parallel suites.

Exact command form from the external clone:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Collect then execute each group. Each token below expands to
tests/test_<token>.py; sort/deduplicate only within its group:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12: NO path arguments, complete repository. Still 124 test modules; no new
module is authorized. Do not select tests to manufacture a preferred count.

Opening implementation-reported reference inventories:

| Group | Files | Reported collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 104 / 104 | `ad607169bab63d557cd1a8b1dc1b6a0378aee9c18e2120c40d620e5293d64e00` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,773 / 1,773 | `1c4f3fc6edc6b3561d426d52d2cd8b4ea8c65ea979311cf151f906d0f4190e8e` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,966 / 8,966 | `fa28bc5ac85a1abe53fe8aea949e711fda6f3acdcab508e4f5214fef53fd575d` |

Inventory encoding for each sorted repository-relative test path:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

Only five permitted D1 test files can change. Groups 2-11 therefore retain exact
file bytes, memberships and inventory hashes; their regressions must pass.
Group 1 and Group 12 must be recomputed after edits. Preserve every existing
behavioral test's intent; no removal, weakening or warning suppression to make
counts fit. Reconcile actual unique node additions/removals.

Useful bookkeeping, NOT a pass claim:

```text
final full count = 8,966 + (final Group 1 count - 104)
                 = 8,862 + final Group 1 count
```

The unchanged overlaps are Group 2/3 = 46, Group 7/11 = 31, with any additional
actual overlap explicitly reported. Require every Group 1-11 node to occur in
full collection. Do not sum overlapping passes as unique coverage.

Groups 10 and 12 historically emit the same three Python 3.13 multithreaded-fork
DeprecationWarnings from:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warnings. Investigate new ones and unsupported mandatory
POSIX/fork probes; do not suppress or claim them passed. Repeated warnings from
shared tests in different groups are not additional warning classes.

Require:

- git diff --check;
- seventeen addition no-index whitespace checks;
- strict UTF-8/BOM/CR/final-LF/trailing-whitespace checks;
- exact 46-path file/type/mode inventory;
- all 38 protected candidate receipts and all 217 HEAD-exact noncandidate files;
- all 29 modified tracked candidates unchanged from this opening;
- unchanged imports/exports/module count, sole subprocess owner, two fixed child
  entry modules, package root, pyproject and current source/migration inventories;
- no migration 0005;
- pre/post content/mode equality for all 263 final-clone endpoints;
- complete live cache directory and member equality including nanosecond mtimes.

Correct only identified external-harness errors outside the live checkout and
rerun affected gates from exact final bytes. Any late candidate edit requires
fresh final-candidate validation; superseded or interrupted runs get no final
pass credit.

### Cleanup and retained work

Account for owned child PIDs/groups and all disposable database/workspace/planner
roots, including deliberately leaked mutant resources. Observe termination
before guarded removal. Use lstat; open/hash only regular files; never follow
symlinks or open FIFOs/sockets/devices. Remove only positively identified task-
owned roots, not an injected original run or unrelated temporary state.

Preserve the retained opening work and identifiable new changes on a stop. Do
not reset, revert unrelated work, recreate D1 from hashes, or discard the entire
candidate. Report actual residue/partial effects and exact endpoint identities.

## 10. Evidence limits and final closeout

The latest independent audit ran 104 D1 tests as a PRELIMINARY selection. It did
not run final Groups 1-12, complete independent SQLite readback/four-site recovery,
full process/FD/workspace campaigns, B1 one-sided probes or the wider finite
mutation matrix. Do not inherit the older 8,966 implementation pass count as
independent acceptance.

This repair must complete its own final twelve-group implementation validation.
A later fresh independent audit must still finish those previously omitted
acceptance obligations after inspecting the new exact candidate. This repair
is not that audit and must not label its own controls independent acceptance.

At closeout committed coordinates remain unchanged; index equals HEAD; no staged
or unmerged paths; same 29 M / 17 C candidate. Recompute all 46 endpoint receipts
and the SAME binary replacement stream twice from fresh reads. Report each of
the eight permitted paths' before/after size, SHA-256, mode, baseline absence and
component length, including unchanged paths. Prove the other 38 rows preserved
and report final encoded-row, prefix, total byte counts and aggregate SHA-256.
A full 46-row table is optional only when the eight exact deltas plus 38-row
preservation are unambiguous. No additional receipt grammar or attachment.

Return inline:

1. Verdict, settings and opening/closing Git coordinates.
2. Actual process field/reason/producer/consumer invariant table and exact owner.
3. Constructor/forged-consumer outcomes for exit 99, None, negative exits, zero/
   negative IDs, wrong built-ins and the finite reason/cleanup relationships.
4. Exact clean-success predicate and usable-Wire consistency, without classifier
   relocation, new import authority or invented provenance.
5. Real success, failed start, nonzero exit, malformed frame, timeout/cancellation
   and cleanup uncertainty, including which original paths remain unchanged.
6. Actual-return substitution, content-free refusal and resource-safe cleanup.
7. Preserved capture/stage/PID/cleanup/frame/B1/Wire/durable-owner constraints.
8. Eight-path identity transitions, 38 protected/217 noncandidate preservation,
   and final 46-row identity calculated twice.
9. Exact twelve final command/path inventories/hashes/nodes/overlaps/warnings,
   preliminary trials/corrections, skipped work and final-copy identity.
10. Direct, permanent and transformed-copy evidence distinguished with actual
    semantic failure boundaries and uncredited syntax/collection failures.
11. Cache/process/root cleanup and remaining independent acceptance obligations.
12. Continuation capsule <=1,000 words. No next prompt.

Provenance/validation/platform/cleanup block:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V5_BLOCKED`

Concrete essential outside-scope owner/contract/path requirement (state exact
path, symbol, required effect; no silent widening):

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V5_REPLAN_REQUIRED`

Success only when the complete value/consumer consistency is repaired, genuine
failure and cleanup outcomes preserved, finite controls discriminate, all twelve
final groups pass and preservation/cleanup is proved:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT`

Success supports only a fresh independent read-only re-audit of the new exact
bytes. No staging, commit, publication, D2, physical C2, migration 0005, qualified
source/supplier, enrollment, live provider/worker, Git effect, ES/Bridge,
deployment or RW0-E authority is added.
