# Governed Execution Coordinator — RW0-D1 Audit Repair V4: Deep Capture Values, Stage-Correct Handback, and Wire Guard Closure

## Mandate

Continue the RETAINED uncommitted 46-path D1 candidate. Do not recreate D1,
roll back its existing fixes, or resume from an earlier identity.

The latest independent audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

It verified all endpoint receipts and replacement identity. It passed the 92
D1 tests and a separate 29-test B1/Wire selection, but demonstrated:

1. Medium: an exactly typed D1CandidateCapture can carry unchecked nested
   entries, including a live RW0D1OfflineRun, arbitrary object, or state-root
   Path, and still be accepted in a capsule_ready handback.
2. Medium: stopped handbacks accept early failure reasons with impossible
   later-stage evidence. Replacing a real success with invalid_input,
   planner_frame, or worker_start while retaining planner/worker/capture
   evidence was accepted.
3. Low: the Wire consumer guard accepts the demonstrated module-level value
   re-export and dynamic importlib loading forms when exercised independently.
   Current handback source has neither. Another B1 guard can reject importlib;
   this does not close the Wire guard's own causal gap.

This is a bounded SOURCE-BEARING repair of those existing invariants, not
another target-contract tranche, importer-registry expansion, or D1/D2 replan.
Keep the existing runtime repair, B1 registry version 3, and Wire value-consumer
permissions. Do not hide the new defects with repr, path-name blacklists,
annotations alone, sanitized output after acceptance, or renamed failure labels.

The critical path is: authenticate retained bytes -> inspect the complete
capture data shape and handback exits -> fix the producer/consumer invariants
and finite stage matrix -> close the two Wire guard holes -> focused causal
checks -> final twelve-group validation -> fresh independent re-audit.

Parent is the sole writer; no subagents. Use the highest exposed reasoning
setting. Report visible model, effort, and permissions or `not visible`, without
seeking additional access merely to reveal hidden settings.

Return operative findings INLINE with repo-relative path:line evidence and a
continuation capsule <=1,000 words. No delivered report, manifest, patch, ZIP,
snapshot, architecture package, or freeze file. No subsequent audit, publication,
D2, or C2 prompt. This prompt contains all operative paths and identities; no
historical attachment transport is required.

## 1. Exact opening baseline and retained candidate

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`, locally `0 ahead / 0 behind`
- exactly one worktree; index equal to HEAD; no staged or unmerged paths
- exactly 29 modified tracked files and 17 untracked created files below
- no active Git operation, sequencer, or unexpected lock.

Read AGENTS.md first. Inspect Git and files non-mutatingly with optional locks
suppressed where appropriate. Do not fetch, normalize, reset, switch branches,
or discard retained/concurrent work. Local tracking equality is not current
remote verification.

`M` denotes a tracked modification; `C` denotes an untracked creation, not a
commit/copy status. Require regular nonsymlink candidate files represented by
Git mode 100644. Preserve actual OS modes, including nonexecuting 0600 files
where present. Do not chmod unrelated files to satisfy a blanket expectation.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Component bytes |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 9,698 | `76ef6a902733a0790da927b4881ad4bef6d2555d6b63be12517d347ea4f46802` | `absent` | 9,775 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,193 | `29e1dfb51e09941acea43ff907440f171a023d46a2de9bdce002d88f9088bc9f` | `absent` | 22,269 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 9,502 | `5d47b82d8b24f38f4a2c54825405f0370e308159908a104fdd9bc73c1ab970d9` | `absent` | 9,589 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 47,819 | `b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 47,885 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 34,490 | `8d600d1044947964b74786f1bfa59326d79541d0ace74d57d4ccd97e82c68cc9` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 34,561 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 11,665 | `20470ec086cbad881c6d4687100905d4670b7f14cc53f3966e342585f1e4bda4` | `absent` | 11,736 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 13,881 | `fab122192528cdd0f668bc63181bea2e4a2fc70d3d1f42bd92061ff8532ffa79` | `absent` | 13,956 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 8,476 | `890c0717fcb1f5f9b53919d3c73b10dc54c98d53d1f1473e52a75108831ce9aa` | `absent` | 8,550 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Verify each row by fresh file reads, each M baseline blob by reading HEAD, and
each C path's absence from HEAD and index. All 217 noncandidate tracked paths
must match HEAD content and Git-relevant mode. Baseline 246 plus 17 additions
means exactly 263 repository file endpoints. No new path, rename, deletion,
symlink, submodule, or executable-mode change.

### Exact retained replacement identity

Reconstruct twice, independently, without importing candidate code. Use exactly:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte
prefix length = 25 bytes
for each table row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20-byte baseline blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact file payload
```

Required opening:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,465,477
prefix: 25 bytes
total: 4,465,502 bytes
SHA-256: b82b43fc4da2e5f258436cec351dcc2a561057b9edb64d7bffbbb35003c84974
```

This is the latest repaired V3 candidate, not the earlier 4,453,900-byte or
pre-repair identities. Byte identity does not establish correctness.
On mismatch, preserve the actual state and stop before editing. Do not replace
expected hashes or reconstruct source bytes from them.

## 2. Exact eight-path repair ceiling

Only these EXISTING candidate paths may change from opening:

```text
src/ge_nwp_coordinator/_rw0_d1_workspace.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_capsule.py

tests/test_rw0_d1_workspace_capsule.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_b2_wire_boundaries.py
```

Responsibilities:

- workspace: the closed immutable D1CandidateCapture value and its nested entry
  validation; no redesign of workspace allocation, containment, or cleanup.
- handback: invoke that value's owned validation and enforce finite
  status/reason/stage/evidence relationships across all sixteen existing fields.
- offline: only align actual construction/error sites with those invariants,
  preserving true observed evidence and existing outcomes/custody.
- capsule: only reuse the capture owner's validation at existing construction/
  verification entry points when needed. Independent reconstruction, manifest
  semantics, and authority remain unchanged. Preserve this file if no edit is
  needed; do not use the allowance for unrelated capsule changes.
- the three D1 tests: direct value, actual-return, stage-failure, and regression
  evidence for these changes.
- Wire boundary test: make its own finite guard detect the demonstrated re-export
  and dynamic-loading forms, without widening or revising permitted consumers.

The other 38 candidate endpoints remain opening-exact, and all 217
noncandidate tracked paths remain HEAD-exact. No new file is authorized.

Specifically preserve all documents, AGENTS/README identities, B1 version-3
owner and both fixed projections, existing private source values and durable
writers/readers, supervisor, frames, fake children, pre-execution composition,
package root, pyproject.toml, .gitignore, StateStore, migrations 0001–0004,
schemas, configuration, public exports, and source-file inventory. No 0005.
No new Wire or B1 symbols, consumer paths, aliases, re-exports, or protocol
versions are authorized by the production changes.

No staging, commit, push, PR, merge, branch change, network, dependency install,
supplier, credential, enrollment, launch of live software, D2, physical C2,
terminal, ES, Bridge, or RW0-E action. Existing fixed fake child execution is
permitted only in the external validation environment described below.

## 3. Close the local invariant/dependency set before editing

Read the current workspace, handback, capsule, and offline modules fully and
inspect their direct tests and Wire guard. Read these candidate owners as data:

- .docs/rw0-d1-offline-process-and-capsule-spine.md
- .docs/rw0-b2-wire-protocol.md
- .docs/rw0-b1-pure-phase-values.md (consumer/custody compatibility only)
- existing Worker/Capsule, Wire-result, process-outcome, and phase value contracts
  actually consumed by the handback.

The latest auditor located the shallow handback check near handback.py:94,
unchecked capture entries near workspace.py:38, permissive stopped check near
handback.py:131, and the Wire helper near its boundary test:612. Re-resolve
actual lines; those references are reports, not substitutes for reading bytes.

Before editing, produce a compact implementation table INLINE:

1. every field/container/leaf of D1CandidateCapture and nested D1-owned entry
   values, including exact type, shape, bounds, source owner and current validator;
2. the sixteen handback fields and how each is validated without I/O;
3. each current reason and every legitimate handback construction site that emits
   it, with possible present/required/forbidden evidence and process state;
4. any import/source-content guard touched indirectly by the chosen helper calls.

This is a local implementation check within the repair, not another broad map
or independently frozen schema. Follow the actual current shape. Do not invent
member names or change accepted WorkSpec/capsule/Wire meanings.

Use the capture owner's own pure validation method or existing private type
access; do not introduce a new consumer/import permission to hide the repair.
Exact field inspection should expose coupled constraints before expensive tests.
Stop for a genuine outside-scope owner contradiction, not by weakening a guard
or changing an import spelling to evade it.

## 4. Medium A — validate the complete capture value, not just its wrapper

### Ownership and admissible contents

D1CandidateCapture owns the validity of its complete retained data structure.
Enforce its existing closed shape on ordinary construction, including direct
construction and dataclass replacement if supported. Validate every D1-owned
nested entry/container and every scalar leaf before relying on equality,
digests, encoding, or iteration over unvalidated arbitrary objects.

The accepted graph must contain only the precise immutable data the current
capture format requires: exact bytes, exact allowed scalar values, exact
ordered immutable containers, and exact existing validated record types.
Check actual field types first; then existing path/mode/count/size/digest rules.
No Any/object escape slot, mutable list/dict/bytearray/memoryview, Path/PathLike,
run owner, session, connection, descriptor, lock, proof, capability, or arbitrary
object may occupy a data leaf or container.

Do not coerce bad values using str, bytes, tuple, dict, pickle, JSON round-trip,
repr, or deep copy before validation. Reject them without inspecting/opening any
resource they reference. Keep errors private and content-free.

Allowed repository-relative capsule path strings are legitimate data; do not
ban them. File content bytes remain opaque bytes and may happen to contain
path-looking text. Do not implement a heuristic filesystem-path string scanner
or interpret captured file contents as live authority.

Preserve existing immutable base/after bytes, entry order, mode meanings,
changed-path accounting, and capsule canonical identities. Enforce content/
digest or capture-to-manifest consistency already required by those owners;
do not add a second digest language or hash the fixture as a real Git commit.

### Producer and consuming boundaries

Constructor validation alone is not the handback contract. At handback admission
(and the existing capsule boundaries as needed), require the exact capture type
AND invoke the capture owner's same pure full-value validation before retaining
or using it. A forged exact wrapper with malformed leaves must not cross the
boundary merely because the caller skipped normal construction.

Do not create two divergent schemas: the workspace module owns this capture
validation; consumers use it. Test expectations must be independently fixed, not
derived from the validating helper's output.

Keep the sixteen handback fields; no new generic metadata, alternate capture
wrapper, validation-only cache, stage state object, or serializer.

### Required direct and actual-return evidence

Use a real successful D1 run in an external test root to obtain valid baseline
capture/handback evidence. Keep the real run open while exercising the three
reported injected values:

- that open RW0D1OfflineRun;
- an arbitrary object;
- its actual live state-root Path.

Place them at the concrete nested positions used by the audit, and at each
materially distinct D1 capture leaf/container role. Use bounded parameterized
cases over the explicit inventory, not a general object fuzzer.

Prove both:

A. normal capture construction/replacement rejects malformed nested contents;
B. an externally forged exact capture wrapper containing those contents is
   rejected by handback/capsule consumption even when producer validation was
   bypassed solely by test fault injection.

Fault injection may use low-level object construction in TEST copies to retain
the real hostile object until the intended boundary. This is not a claim of
security against arbitrary code that can rewrite the parent interpreter after
validation, and it does not justify production reflection.

Cover success, stopped and cleanup-unresolved handback paths wherever capture is
permitted. The value must be validated on every admitted path, not only ready.

A permanent actual-return test must catch a transformed implementation that
inserts the live run/path/object under a nested capture entry in every emitted
handback. Hiding it from repr is not success. Check the closed expected object
graph, not an unbounded __dict__/asdict walk, and do not dispose of/delete the
injected live resource through validation. The parent must remain able to close
normally after rejection.

Also preserve positive cases: canonical healthy capture is accepted unchanged,
real independent capsule reconstruction still succeeds, repr does not leak
private bytes/locations, and D2-required bytes/modes remain available.

## 5. Medium B — bind reasons to the actual stage and evidence prefix

### One finite data invariant; no shadow runtime authority

Use the existing statuses/reasons and sixteen evidence fields. Derive a small
explicit matrix from the current owner and every actual construction site.
For each (status, reason), state:

- possible execution stage(s), if an existing broad reason spans several sites;
- required evidence;
- optional evidence and why it can exist at that point;
- forbidden evidence;
- necessary process facts such as not-started versus started/exited;
- expected selection/phase prerequisites;
- cleanup predicates that must be true or unresolved.

A broad reason may have several explicitly enumerated valid stage prefixes; it
must not become an unconstrained wildcard. Unknown reasons/combinations fail.
There must be no default path that accepts every non-ready combination.

This matrix checks a transient projection. It is not an additional program
state machine or durable stage ledger. SQLite's current owners remain the only
program/selection/phase truth. Do not add a new stage field to make the matrix
self-authorizing; check the existing evidence and its owned relationships.

### Reported counterexamples and important distinctions

At minimum reject replacements of a real successful handback that remove its
manifest but retain incompatible evidence under:

- stopped/invalid_input: no later planner/worker/capture or selected/phase
  evidence may be fabricated under an initial input rejection;
- stopped/planner_frame: retain any planner process facts legitimately observed
  by that failure path and committed earlier program/author facts, but no later
  Section 41 selection, C1 phase, worker, Wire result, or capture;
- stopped/worker_start: legitimate preceding program/author/selection/phase
  facts remain, but no successfully started/completed worker, Wire result, or
  captured candidate.

A worker_start outcome may legitimately carry the supervisor's exact failed-to-
start observation. Do not forbid that object merely because the stage has a
worker-related field. Distinguish a failed launch attempt from a successful
worker process and from an observation that could only exist afterward.

Likewise retain valid planner-frame failure process facts instead of requiring
planner_process=None universally. Derive exact pre-start encoding versus post-
start decode possibilities from existing call sites.

Preserve cleanup-unresolved as distinct: keep safely observed prior facts,
including worker/capture evidence when actually reached, without claiming a
verified ready handback. A cleanup failure is not an early input failure,
durable conflict, or reason to erase a real process observation.

### Construction sites and failure behavior

Update offline construction/error paths only when required to produce truthful
existing combinations. Do not strip late evidence or relabel errors simply to
make an impossible specimen fit a weaker rule. Do not catch constructor failure
and issue a fabricated empty success or generic stopped result.

Use narrow existing private errors; preserve creator-PID custody checks,
explicit state close, and cleanup even when handback construction fails. Any
required change in supported status vocabulary or owner semantics outside the
current contract is a bounded stop with the exact contradiction, not silent
scope expansion.

### Evidence

Keep a fixed expected per-reason matrix in direct tests, separate from the
production predicate/table. It must cover every current reason and legitimate
prefix, not merely the three examples. Use focused neighboring-stage mutations:
append evidence from the next unexecuted stage, replace failed-start observations
with successful process facts, remove necessary prior evidence, and mix stopped
and cleanup reasons.

Exercise actual integration paths for input rejection, malformed planner,
nonselection, phase/durable unresolved stop, failed worker start, worker failure,
timeout/cancellation, selector cleanup uncertainty, workspace cleanup uncertainty,
and normal capsule_ready. Wrappers may inject the specific fault, but actual
current durable methods and real children must run wherever that stage is claimed.
Do not run every negative case through costly duplicate durable setup when a
shared isolated real result and constructor specimen covers the same predicate.

Every actual emitted handback must satisfy the same matrix. A success object
with an early reason substituted must be rejected rather than repaired by the
constructor. Independent values are evidence, not proof that historical execution
actually occurred; this repair does not create an authenticity service.

## 6. Low C — close the Wire guard's own two demonstrated bypasses

Keep the existing exact importer set, symbol sets, direct-relative/unaliased
handback import, and existing Capability/C1/D1 restrictions. Handback still gets
only RW0WireWorkerResultV1 and RW0WireProcessResultClassificationV1 for evidence
fields. B1 version 3 and its guards stay byte-exact.

In tests/test_rw0_b2_wire_boundaries.py, strengthen the SAME finite
_assert_private_wire_consumers path so it independently rejects:

1. a module-level value re-export/alias of an admitted Wire class, including the
   exact source-text pattern used by the auditor;
2. dynamic importlib loading of the Wire module, including that exact pattern.

Cover direct and simply aliased import_module / __import__ forms and nested use
within the existing finite guard grammar where relevant. An explicit prohibition
of dynamic-loading constructs in this one closed handback consumer is preferable
to pretending a static helper solves arbitrary Python reflection. Do not build
a universal import resolver or expand unrelated parser/language contracts.

Preserve legitimate annotations and exact type-validation uses of the admitted
classes; those are not re-exports. Inspect current handback text before defining
any assignment restriction. Keep expectations fixed, not computed from whichever
imports/aliases are present.

Positive control: actual retained handback consumer still passes.
Negative controls: the two independently supplied source-text specimens must
fail THIS helper without invoking B1 or depending on the rest of the suite.
Preserve previous nested-import, extra-symbol, wildcard/module alias, unapproved
consumer and prior-C1-permission controls.

The auditor did not show a full-suite dynamic-import escape, and current source
contains neither malicious form. Retain that Low/guard-adequacy classification;
do not misreport it as a demonstrated production loader or live authority bug.

## 7. Bounded mutation and regression evidence

Create six focused transformed-copy classes against FINAL candidate bytes,
keeping fixed direct/integration expectations unchanged:

1. skip deep validation in normal capture construction;
2. make handback consumption outer-type-only again, supplying a malformed exact
   capture independently of constructor validation;
3. replace stage-dependent stopped checks with the old broad rule;
4. erase or relabel observed evidence at an actual failure construction site to
   conceal an impossible reason/stage combination;
5. re-allow the reported Wire value re-export in its own helper;
6. re-allow the reported dynamic import in that same helper.

The actual nested-live-resource injection is a permanent direct/integration
specimen and must be tested against cases 1/2. Use additional subtype specimens
inside those tests rather than starting another large mutation framework.
Each transformed copy must parse/import/collect normally and fail semantically
at an identified fixed test. No credit for import, syntax or collection failure.

Retain and run the existing creator-PID fork, selector/stream-cleanup,
timeout/cancellation composition, malformed-frame, B1 and Wire consumer tests.
No repair permission is given for their otherwise unaffected production owners.

The previous audits' unperformed durable-readback/recovery and wider hostile-copy
acceptance campaign remains unperformed. Implementation validation here is not
independent completion of that campaign. Carry the exact limit into the closeout;
a subsequent independent audit must finish its acceptance obligations before
commit eligibility.

## 8. Execution order and retained-work rule

1. Verify the retained 46-row basis and complete new opening cache metadata.
2. Finish the capture field/handback exit/import dependency table.
3. Implement owned deep validation and the reason/stage matrix together with
   their direct tests; preserve the existing public shape and private type edges.
4. Make the bounded Wire helper/test correction.
5. In a remote-free development clone, run D1 handback/workspace/integration,
   Wire, B1, post-execution, runtime and scoped-C2 guards first. Discover no
   known importer/content pin by waiting for the full suite.
6. Run real nested-resource and reason/stage specimens and six transformed-copy
   classes, including normal success and prior repaired paths.
7. After the LAST edit, rebuild one final remote-free clone and complete every
   final group below from those bytes.
8. Recompute final receipts/identity, preserve the candidate, clean only owned
   temporary resources, and report ready only if all final gates pass.

Do not roll back the retained opening repair on any stop. Preserve opening work
and identifiable new changes and report their exact state. Do not overwrite
concurrent changes, reset, reconstruct source from hashes, or delete unrelated
temporary state. A newly reproduced independent authority contradiction requires
review; ordinary validation fixes within these owners do not create a new tranche.

## 9. Validation environment and exact groups

No live-checkout repository execution/import/test/database connection. All
executable work occurs in task-owned local-only clones of exact HEAD with all
46 candidate endpoints overlaid and remotes removed. Use installed dependencies;
no network. The parent may execute fixed offline planner/worker/probe children
and temporary SQLite fixtures only within that external validation scope.

Before executable work, capture the known live __pycache__ DIRECTORY and its
37 regular members using lstat: path, type, actual mode, size, st_mtime_ns, and
SHA-256 for regular files. Do not replace directory metadata with mere existence.
Preserve complete opening/closing equality for THIS run; do not claim historical
omissions from older reports were retrospectively repaired.

Create an external root mode 0700; set TMPDIR to that root. Preserve source OS
modes in clones; use test-process umask 022. Precreate separate collect/run
basetemp parents. Collect then execute serially, no xdist or concurrent groups:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <group-paths>
```

Each token below expands to tests/test_<token>.py. Sort/deduplicate within each
group without changing its membership:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12 uses NO path arguments and still comprises the same 124 test modules;
no new module is authorized.

### Opening file inventories and reported reference counts

| Group | Test files | Reported unique nodes / passes | Inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 92 / 92 | `2beb9ecda4ce8636339f5d3fe8f93526c0242cae9c1e498cf27f15a01da76acf` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 123 / 123 | `b604716da90279bfed0435ca559476723ba760cf4f2e8341b8e01ff39c9d678b` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,773 / 1,773 | `1c4f3fc6edc6b3561d426d52d2cd8b4ea8c65ea979311cf151f906d0f4190e8e` |
| 11 remaining changed owners | 6 | 667 / 667 | `735184692416af1ce727d3a8d2add0b7e4fe2eb1218a294194602503220d7ea8` |
| 12 full repository | 124 | 8,942 / 8,942 | `ee5f6ca268c6f9f1e61ecfa86e6a9415b1e6b6b1f758228a93a94e8d9a6d8ef4` |

These reference counts are earlier implementation-reported results. The latest
independent audit ran Group 1 only (92/92), plus a separate selected B1/Wire set
(29 passed). It verified all twelve FILE hashes, but did not collect or execute
Groups 2–12, prove their node counts/overlaps, or complete the wider transformed
campaign. Do not turn an inventory digest into test-result evidence.

For inventories hash the concatenation, for each sorted repo-relative path:

```text
u32be(path_utf8_length) + path_utf8 + raw_sha256(file_bytes)
```

Groups 2–6 and 8–10 contain no allowed modified test files. Their inventories
must remain exact and their regressions pass. Group 1 changes when its three
admitted D1 test files change. Groups 7 and 11 both include the Wire boundary
test, so recompute BOTH; do not require their obsolete hashes. Recompute Group
12 inventory and run the entire repository after final edits.

Reconcile actual node IDs/additions/removals; do not weaken or remove behavioral
coverage to preserve a preferred total. At this opening, Group 2/3 share 46 nodes,
and Group 7/11 share 19 Wire-boundary nodes. Reconcile the new overlap rather
than summing pass counts as unique coverage.

With this exact eight-path ceiling, useful arithmetic is:

```text
final_full = 8,942 + (final_D1_group - 92) + (final_Wire_group - 123)
final_Group11 = 667 + (final_Wire_group - 123)
final_Group10 = 1,773
```

These are bookkeeping checks, not collected/pass claims. All final groups must
be completed; an earlier clone or an interrupted run gets no final credit.

Expected existing warnings are the three Python 3.13 multithreaded-fork
DeprecationWarnings associated with:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warnings; investigate new warnings or unsupported mandatory
POSIX/fork evidence instead of suppressing them. Duplicate warnings from
multiple groups are not new warning kinds.

### Final preservation and cleanup

Require git diff --check; seventeen addition no-index whitespace checks; strict
UTF-8/no BOM/no CR/final-LF/trailing-whitespace checks; exact path/type/mode sets;
38 protected candidate receipts; 217 noncandidate HEAD entries; no new source,
export, script, schema, migration or public effect; no 0005; and before/after
content/mode equality for all 263 clone endpoints.

Use lstat before opening external artifacts; hash regular files only. Never
follow symlinks or open FIFOs/sockets/devices. Account for all owned child PIDs,
process groups and state roots, including deliberate leaks from negative copies.
Remove only identified task-owned roots after children terminate. Do not allow
an injected live run to be orphaned when its handback is rejected. Record actual
cleanup residue if any; never claim an unproved resource is gone.

Correct identified harness errors only outside the live checkout and rerun the
affected gates from exact candidate bytes. A late edit invalidates inherited
final validation. Complete live cache-directory/member equality afterward,
including opening/closing nanosecond mtimes.

## 10. Closeout and outcomes

Keep the same unstaged/uncommitted 29 M / 17 C state and committed baseline.
Report every allowed file's opening-to-final identity, even when unchanged,
and prove the other 38 candidate and 217 noncandidate receipts preserved.
Recompute all 46 endpoint receipts and the SAME replacement recipe twice from
fresh reads; report component bytes, prefix, total and SHA-256. Do not introduce
a delivered manifest, extra receipt grammar, or attachment requirement.

Return inline:

1. verdict, visible settings, opening/closing Git coordinates;
2. actual capture field/container/leaf inventory and owner/consumer validation;
3. exact reason/stage/evidence matrix and construction-site reconciliation;
4. direct nested live-run/object/Path and impossible-stage outcomes, including
   actual returned-handback tests and private no-leak failures;
5. Wire helper positive cases and independent re-export/dynamic-load rejection;
6. preservation of fork custody, process cleanup, frame normalization, B1/Wire
   permissions, durable path, capsule independence, and no-shadow-truth rule;
7. exact eight-file transitions and preservation proof, final 46-row identity;
8. all twelve final commands/inventories/nodes/overlaps/warnings, failed trials,
   corrections and any omissions;
9. direct specimens, permanent tests, transformed copies and their actual
   semantic failure boundaries, clearly distinguished;
10. process/state-root/cache cleanup and evidence limitations;
11. continuation capsule <=1,000 words with remaining independent audit gates.

If baseline/provenance drifts, required validation cannot pass within the ceiling,
or cleanup is unproved, preserve retained work and use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V4_BLOCKED`

For an actual existing-owner contradiction or essential dependency requiring a
path/symbol/contract outside the ceiling, preserve work, name exact path:line
and effect, and use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V4_REPLAN_REQUIRED`

No stage/commit/publication or scope bypass is allowed on either stop.

Success requires both Medium fixes, the bounded Wire guard correction, unchanged
operating model and private interfaces, all final groups completed, and exact
preservation/cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

Success supports only a fresh independent read-only audit of the new exact
candidate. It establishes no independent acceptance, commit/publication gate,
D2/C2 implementation, migration 0005, qualified source/custody, enrollment,
live model/worker, supplier, Git effect, ES/Bridge integration, or RW0-E.
