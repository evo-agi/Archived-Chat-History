## Disposition

**Accept the audit block. Preserve the retained D1 candidate and repair process-outcome consistency at its owner and handback boundaries. Do not stage, commit, or begin D2.**

The report establishes a specific evidence-integrity defect: a handback can claim `capsule_ready` while retaining process facts that the supervisor and runner would reject. It does **not** establish a normal-run acceptance, durable-writer, or executable-authority bypass.

The previous repair closed capture structure and stage presence, but left “successful process” insufficiently tied to its underlying facts. **Adding only `exit_code == 0` to the ready branch would be too local a fix.** The process record needs one owned consistency check, and every handback consumer must use it.

## Selected repair

### 1. Validate the process value completely, then consume it

Keep `D1ProcessOutcome` in its existing owner:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
```

Add or strengthen one **pure, no-I/O validation method** for its existing fields. Apply it during normal construction or replacement and explicitly when the handback consumes either `planner_process` or `worker_process`.

The minimum success relationship is:

```text
an actually-started observation
+ positive exact-integer PID and process-group identities
+ reason == "ok"
+ exact-integer exit_code == 0
```

The existing cleanup requirements must then hold before that process can support readiness. Neither a success label nor a retained usable Wire classification can override a missing or contradictory exit observation.

Validate exact types before comparison: `False` is not an acceptable substitute for integer zero, and an integer subclass must not pass where the existing value contract requires an exact built-in integer.

**Consumption must revalidate the value.** Constructor checks alone would leave the same hole when a controlled test supplies an exact wrapper whose fields bypassed construction. This follows the already selected handback requirement to validate underlying process facts rather than merely accept an outer class. Coordinator_RW0_D1_Offline_Proc…

This check must not poll a PID, signal a group, open a resource, or attempt to prove that a process historically existed. It validates retained evidence; it does not authenticate execution.

### 2. Preserve legitimate failure and cleanup observations

The new invariant must distinguish contradictory records from valid negative outcomes:

| Observation | Required treatment |
|---|---|
| `ok` with exit `99`, `None`, or a signal-negative return code | Internally inconsistent; cannot support a handback |
| A genuine nonzero-exit outcome with its observed nonzero code | Valid failure evidence; never readiness |
| A failed launch with no PID or process group | Valid failed-start evidence under the existing reason |
| Timeout or cancellation followed by a zero exit | Preserve when legitimately observed; zero alone does not make it successful |
| Known zero exit with unproved selector, stream, or group cleanup | Preserve the known process facts; no `capsule_ready` |
| Negative, zero, Boolean, or missing process identity where a launched process is claimed | Reject |

In particular, **negative exit codes and negative process IDs are different cases**. A supported signal-negative return code can be valid failure evidence. A negative PID cannot satisfy the launched-process identity check.

The implementation must inspect every actual process-result construction site before changing these rules. It must not make all failure records resemble completed success, erase observations, or relabel contradictions as `durable_conflict`.

### 3. Keep Wire classification in its current owner

I checked the unchanged Wire contract and implementation. `RW0WireProcessResultClassificationV1` retains only `classification` and `reason`; usable classification requires a valid result and a zero process exit, subject to its existing higher-priority conditions. A nonzero exit with a valid result is classified as `process_result_contradiction`.

References:

```text
.docs/rw0-b2-wire-protocol.md:53,94–98
src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:560–576,1861–1913
```

**Do not move or duplicate that classifier in the handback.** The handback’s Wire imports remain the same two evidence classes. The runner remains responsible for calling the existing classifier with an exit observation derived from the actual worker result—not a hard-coded zero or a value inferred from `reason`.

At handback admission, both sides must agree:

```text
consistent successful worker process
AND usable Wire evidence
AND the remaining stage, capsule, and cleanup requirements
```

A stored `usable` label does not prove which inputs produced it. The repair establishes consistency between the retained values without inventing a classification receipt or new authority.

## Repair boundary

The primary work is confined to three existing runtime files and their direct tests:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py

tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
```

Two existing process-consumer test files are also available **only for necessary fixture or regression corrections** arising from the strengthened outcome constructor:

```text
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_worker_process.py
```

That is an **eight-path ceiling**, not a requirement to change all eight. The other **38 candidate files remain byte-identical**. All documents, B1/Wire registries and guards, capture/capsule repairs, frame decoder, current durable owners, package exports, and migrations remain protected.

No new module, process field, handback field, stage ledger, consumer permission, protocol, or standalone contract tranche is selected.

## Required evidence

The repair must reproduce the audit’s substitutions using a real successful D1 handback, then cover the same invariant for **both planner and worker**. Normal construction and forged-exact-wrapper consumption must be tested separately so an earlier rejection does not falsely credit a later check.

The direct controls cover `ok` paired with nonzero or absent exit, invalid PID/group values, wrong built-in types, and the actual reason/cleanup relationships. They must also show that valid failed starts, nonzero exits, malformed frames after zero exit, timeouts, cancellations, and cleanup uncertainty still produce truthful outcomes.

An actual-return substitution must never yield readiness. Rejection must clean only the failing invocation’s owned resources, preserve any original run used as the specimen, and leak no path or output payload.

The prompt includes six bounded transformed-defect classes for constructor validation, consumer revalidation, primitive success predicates, planner/status coverage, stale usable-classification reliance, and evidence-erasure or cleanup regressions. These are implementation controls—not substitutes for the later independent audit.

## Validation and remaining acceptance work

The latest audit’s **104 passing D1 tests were preliminary**. It did not execute the fresh-final validation groups or finish the independent recovery, process/FD, workspace, B1, and transformed-copy campaigns. Stopping expensive work after reproducing a Medium defect was permitted; the remaining acceptance obligations are still outstanding. Coordinator_RW0_D1_Offline_Proc…

After the final repair edit, all twelve implementation-validation groups must run from a fresh, exact, remote-free clone.

Only D1 test files may change in this repair. Therefore:

```text
Groups 2–11:
retain their exact test-file inventories and regression expectations

Groups 1 and 12:
recompute inventories and execute from final bytes

Count reconciliation:
final full count = 8,862 + final D1 Group 1 count
```

The formula is bookkeeping, not an expected pass count manufactured by changing test selection.

## Complete repair handoff

Resume the **same implementation Codex conversation**, preserving the current retained candidate.

:chatgpt-content-reference{index="2"}[Download the complete RW0-D1 audit-repair prompt V5](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V5_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V5_Prompt.txt

Bytes:
44,762

SHA-256:
4ee26fc7043226395ea90646cae505b238565f03fe6d0fd302e3f463af494f5c

Lines:
730

Final newline:
present
```

The prompt contains the complete **46-path opening receipt table**, the eight-path ceiling, the owner/consumer invariant, legitimate-failure preservation, Wire separation, exact validation groups, and retained-work rules.

It starts from:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,494,176 bytes
a79100018f014351a18cf5fb21464c6b26ac0e9bd2de94f1268d57e66857a236
```

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT
```

Success supports only a **fresh independent read-only re-audit**. It grants no staging, commit, publication, D2, physical C2, migration `0005`, qualified-source or supplier work, ES/Bridge integration, or RW0-E authority.

## Evidence boundary

I read your latest audit and the operative re-audit mandate, inspected the unchanged Wire owner and classifier in the mounted snapshot, corroborated all **29 baseline blob identities**, verified the **17 additions’ absence** from that baseline, and checked the generated prompt’s receipts, component arithmetic, scope, and validation paths.

I did **not** inspect the live D1 source or reproduce the latest process specimens. The candidate-specific locations in handback `:89/:187` and supervisor `:214` remain the auditor’s reported coordinates.

Some older uploads have expired; re-upload a specific original for a later byte-level comparison. This handoff is self-contained.

**Sources:** Your latest independent re-audit; the issued repaired-V4 audit mandate cited above; October 15 Coordinator snapshot, particularly the Wire owner and classifier references above.

**Confidence:** High on accepting the block and selecting a shared process-owner/consumer repair. Final runtime correctness, full independent validation, and commit readiness remain unproved.
