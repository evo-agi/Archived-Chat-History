## Disposition

**Accept the block, but do not replan RW0-D1. This was a mutation-ceiling defect in the implementation prompt.**

Codex reached integrated source testing and passed the D1, program, author-effect, Section 41, RW0-C1, and worker groups before encountering an intentionally protected status surface. Nothing in the report indicates that the current durable authority chain, process boundary, workspace model, capsule construction, or D1/D2 split is unworkable.

The checkout was restored to the exact clean baseline, so the implementation must be recreated from that baseline using a corrected complete prompt.

## Why the block occurred

The D1 prompt correctly required `AGENTS.md` and `README.md` to stop claiming that no worker/process/capsule runtime exists after D1 is implemented. It failed to authorize every test that owns those documents’ exact identities.

The first blocker is:

```text
tests/test_rw0_b2_capability_boundaries.py
```

Its `PROTECTED_CONTENT_ROWS` pins the complete byte length and SHA-256 of:

```text
P11 — AGENTS.md
P12 — README.md
```

See `tests/test_rw0_b2_capability_boundaries.py:118–145,642–690`.

That test also owns a synchronized RW0-B2-Capability status block projected into five documents:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

See `tests/test_rw0_b2_capability_boundaries.py:30–53,548–557`.

The previous prompt allowed only three of those five documents to change. A truthful D1 status update therefore requires adding:

```text
.docs/authority-boundaries.md
.docs/durable-state-model.md
tests/test_rw0_b2_capability_boundaries.py
```

There is also a **second exact-identity guard** that Codex had not yet reached:

```text
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

Its independent capability-replacement evidence pins the current replacement identities of `AGENTS.md` and `README.md` and validates that those identities remain tied to the guard’s semantic markers. See:

```text
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:138–170
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:777–821
```

That test must also enter the mutation ceiling.

## Correct treatment of the protected tests

These guards should **advance with the truthful D1 status**, not be weakened or bypassed.

The implementation must:

- retain every protected row ID, path, ownership class, purpose, old identity, and hostile integrity check;
- calculate the final `AGENTS.md` and `README.md` sizes and SHA-256 values twice after the final documentation edits;
- place those new identities into the two owning tests as fixed literals;
- never derive the expected hashes dynamically from the files under test;
- keep RW0-B2-Capability itself pure, no-I/O, non-authoritative, and incapable of proving physical process behavior;
- update only the repository-level status sentence to distinguish:
  - implemented **RW0-D1 artificial offline process/capsule mechanics**;
  - future **RW0-D2 evidence/review closure**;
  - future **RW0-C2 physical decisions**;
  - future live provider, credentials, custody, and RW0-E runtime.

This is coordinated implementation-status maintenance, not a new contract tranche or authority expansion.

## Revised mutation-boundary additions

Relative to the original D1 prompt, the corrected ceiling additionally permits:

### Documents

```text
.docs/authority-boundaries.md
.docs/durable-state-model.md
```

### Direct owning tests

```text
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

No Capability source module, bootstrap-guard owner document, frozen semantic owner, migration, schema, package export, or public surface is newly opened.

## Corrected D1 implementation handoff

Resume the **same Codex implementation conversation**. The previous task restored all edits, so the corrected prompt starts again from the clean merged baseline.

:chatgpt-content-reference{index="0"}[Download the complete corrected RW0-D1 implementation prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt_V2.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt_V2.txt

Bytes:
42,591

SHA-256:
d79b5eb3648f2c67a7f1c258321b8e55974af63b111af9c17e0382de274e8543

Logical lines:
1,166

Final newline:
present
```

The baseline remains:

```text
Branch:
trunk_dev

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Sole parent:
630414faa07f4ac39c4a870a9cc44c7f92d46b80
```

The corrected prompt retains the entire D1 implementation mandate and adds a dedicated protected-status coordination section. It requires Codex to:

1. inspect both exact-identity guards before editing;
2. implement D1 again through its internal A/B/C stages in one uncommitted candidate;
3. synchronize the five Capability status projections;
4. update both tests’ literal `AGENTS.md`/`README.md` identities only after final documentation bytes are fixed;
5. prove the hostile anti-bypass controls in both tests still work;
6. run the Capability group and bootstrap-guard semantic test explicitly;
7. run all focused durable/process/capsule/status groups and the complete repository suite;
8. stop rather than silently widen if another full-file identity pin is found outside the now-expanded ceiling.

The main success token remains:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

The replan token is reserved for an actual authority or implementation-boundary contradiction—not another ordinary status-test dependency.

## Exact nonclaims

This correction does not:

- validate or recover the discarded implementation candidate;
- claim the D1 source was complete or independently correct;
- authorize incremental commits for D1a/D1b/D1c;
- authorize D2, C2, migration `0005`, provider work, supplier qualification, live credentials, Git effects, or RW0-E;
- weaken the Capability or bootstrap-guard protection surfaces;
- make documentation hashes the source of implementation truth.

It only corrects the prompt’s incomplete ownership set so the integrated D1 implementation can be recreated and validated truthfully.

**Sources:** Codex’s blocked implementation closeout supplied in your message; current snapshot inspection of `tests/test_rw0_b2_capability_boundaries.py`, `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`, and the five synchronized RW0-B2-Capability status projections.

**Confidence:** High that this is a prompt-scope defect rather than a D1 architecture failure. High that the four added paths are the directly owning surfaces needed to clear the reported blocker and the next known exact-identity blocker.
