# Revised RW0 implementation program

**RW0-D remains one implementation program, split into two source-bearing tranches: D1 then D2. RW0-C2 physical implementation starts only after D2 is complete and audited.**

The split is now:

```text
RW0-D1  durable pre-execution authority + offline process/capsule spine
    ↓
RW0-D2  offline validation/review/model evidence closure + C2 projection
    ↓
RW0-C2  durable provisioning and five-branch decision implementation
```

D1 and D2 must not become independent user-relay-heavy programs. D1’s output is the machine-consumable input to D2; D2’s output is the machine-consumable input to RW0-C2.

The current repository already implements the durable program initialization, author-effect establishment, Section 41 pre-execution selection, and RW0-C1 phase/evidence foundations. It still has no worker supervisor, worker process, model process, capsule builder, validation/review executor, or autonomous loop. `AGENTS.md:46–62,91–110,547–575`; `src/ge_nwp_coordinator/__init__.py:1–7`.

# 1. RW0-D1 capability boundary

## Observable result

One private invocation performs:

```text
accepted WorkSpecV1 / bounded private fixture input
→ disposable Coordinator database through migration 0004
→ current durable program initialization or exact replay
→ current durable author-effect establishment or exact replay
→ deterministic fake planner process
→ Coordinator reconstruction of the planner proposal
→ current durable Section 41 pre-execution selection
→ current RW0-C1 phase establishment before worker contact
→ exact WorkerCommandV1 construction
→ deterministic fake coding-worker process
→ bounded mutation of one authorized workspace path
→ worker/process observations
→ parent-owned candidate capture
→ parent-owned immutable capsule construction
→ independent capsule reconstruction and verification
→ typed D1 handback
```

The user provides the initial bounded input once and receives one handback. No plan, selection, worker command, worker output, candidate, or capsule is manually relayed.

### Required durable path

D1 must use the current private Coordinator authority path, not merely reproduce equivalent values in an orchestration object:

- `SQLiteWriterSession._initialize_development_program(...)`
- the current private author-effect establishment path;
- `SQLiteWriterSession._prepare_pre_execution_plan_disposition_recovery_probe(...)`;
- `SQLiteWriterSession._record_pre_execution_plan_disposition(...)`;
- `SQLiteWriterSession._establish_rw0_phase(...)`.

The exact call chain and prerequisites remain subject to the read-only map, but those current owners cannot be replaced by a D1-only program or selection state. The existing private entry points are visible in `sqlite_writer_session.py:5608–5694,5811–6035,6052–6231,6429–6448`.

The fake planner authors planning content and a model proposal. It does **not**:

- select its proposal;
- author program, version, attempt, effect, fence, delivery, or disposition identities;
- write SQLite;
- receive a `WriterSession`;
- become the current-program source.

Coordinator binds the planner output to the existing program/effect lineage, constructs the current `PreExecutionProposalSelectionBundleV1`, and records the selection through Section 41.

## Process and capsule boundary

The fake coding worker is a separate OS process. It receives only the bounded worker command, wire input, and isolated workspace information needed to perform the fake operation.

It must not receive or inherit:

```text
Coordinator database path
SQLite connection/file descriptor
state-authority lock descriptor
WriterSession or mutation lease
writer proof or operation capability
standing-policy credentials
live authority material
hidden mutable orchestration state
```

The parent supervisor owns launch, deadline, cancellation request, signals, exit observation, stdout/stderr bounds, reap, and cleanup. Those are process facts, not progression decisions.

The worker may mutate only the authorized workspace path. The worker does not author the accepted capsule manifest. A parent-owned capsule builder must independently compare the immutable base with the observed candidate, construct `CandidateCapsuleManifestV1`, and verify independent reconstruction. The existing manifest and relation semantics remain in `_worker_execution_semantic_values.py:1889–2025,4169+`.

## Typed D1 handback

The smallest D1 handback should bind:

- durable program, version/head, WorkSpec, author-effect, selection, and phase coordinates;
- planner process outcome;
- selected proposal/disposition coordinates;
- worker command, attempt/effect fences, delivery, and wire result coordinates;
- supervisor start/exit/timeout/cancellation facts;
- candidate-capture status;
- exact capsule manifest on success;
- workspace and capsule cleanup status;
- one closed D1 status/reason.

It is a transient typed projection. It is not another program state machine, durable decision, terminal outcome, or acceptance receipt.

## D1 nonclaims

D1 does not provide:

- a competent planning model or real Codex worker;
- live credentials, network, standing authority, or custody supplier;
- a service, API, queue, CLI, MCP interface, or public intent grammar;
- restart-safe orchestration;
- validation or independent review;
- post-execution model review;
- durable C2 progression or acceptance;
- a terminal outcome;
- migration `0005`;
- Git or publication effects;
- ES or Bridge integration;
- permission to run RW0-E.

# 2. RW0-D2 capability boundary

## Observable result

D2 consumes the exact D1 handback and capsule:

```text
D1 capsule and durable lineage
→ process-separated validator
→ typed validation evidence
→ process-separated independent reviewer
→ typed independent-review evidence
→ process-separated fake semantic-review model
→ typed model recommendation/proposal
→ current RW0-C1 evidence admission as applicable
→ Section 41 post-execution family projection
→ frozen RW0-C2 input projection
→ typed final offline handback
```

No user relay occurs between those stages.

D2 owns the **evidence and cognitive-review closure**, not the candidate-production spine. It should reuse D1’s process supervisor and framing rather than introducing a second process runtime.

The validator and independent reviewer are distinct sources and must not share an authority-bearing result. The review model is also a proposal source; it cannot choose the authoritative C2 branch.

D2 should use the existing RW0-C1 evidence boundary where its fixed inventory applies. That boundary already includes worker observations, wire results, and the Section 41 post-execution proposal family, while explicitly remaining non-decisional. `.docs/rw0-c1-durable-evidence.md:51–70,93–109,253–260`.

The final handback must be directly consumable by the frozen RW0-C2 input projections. It must not translate one D2-specific success vocabulary into a second C2 vocabulary.

## D2 nonclaims

D2 does not provide:

- a durable five-branch C2 decision;
- an acceptance fact;
- terminal-outcome persistence;
- migration `0005`;
- live model/provider calls;
- Git or publication effects;
- live authority or supplier proof;
- restart-safe autonomous orchestration;
- RW0-E authorization.

# 3. Existing modules and contracts consumed

## D1

| Existing surface | D1 use |
|---|---|
| `_worker_execution_semantic_values.py` | `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`, `DeliveryEnvelopeV1`, `WorkerObservationV1`, `CandidateCapsuleManifestV1` |
| `_development_program_initialization_contracts.py` / `_sqlite_development_program_initialization.py` | Current program genesis, replay, and readback |
| `_development_author_effect_establishment_contracts.py` / `_sqlite_development_author_effect_establishment.py` | Current attempt/effect/fence/delivery lineage needed before selection and worker launch |
| `_cognitive_proposal_semantic_values.py` / `_cognitive_proposal_row_values.py` | Planner artifact, safe projection, model proposal, evidence set, and selection bundle |
| `_development_pre_execution_plan_disposition_contracts.py` / `_sqlite_development_pre_execution_plan_disposition.py` | Current Section 41 selection, conflict, replay, and recovery |
| `sqlite_writer_session.py` / `sqlite_transition_transaction.py` | Sole current writer, operation guard, transaction, and private mutation entry |
| `_rw0_phase_entry_semantic_values.py` | Phase-basis validation before worker contact |
| `_rw0_c1_*` and `_sqlite_rw0_c1.py` | Current durable phase establishment; D1 should not yet expand into D2’s evidence closure |
| `_rw0_wire_protocol_values.py` | Existing worker command/result frames and process/result classification |
| `_rw0_worker_mechanism_capability_values.py` | Fake bounded mechanism declaration/observation/qualification where required |
| `sqlite_migration.py`, migrations 0001–0004 | Disposable current-schema database |
| `state_authority_lock.py` and writer-session mechanics | Parent-only database authority; must not cross process boundary |

Current WorkSpec fields and identity are frozen in `_worker_execution_semantic_values.py:724–812`. The current worker command is defined at `:1434–1585`; capsule semantics at `:1889–2025`; worker observations at `:2451–2585`.

## D2

D2 consumes the D1 surfaces plus:

| Existing surface | D2 use |
|---|---|
| `_post_execution_evidence_values.py` | Capsule projection, validation/review dispositions, result sets, model input and support values |
| `_post_execution_policy_values.py` | Standing-policy and risk-lane evidence/projections |
| `_section41_post_execution_role_resolution.py` | Exact role-source resolution |
| `_section41_post_execution_proposal_family_projection.py` | Existing post-execution proposal-family projection |
| `_rw0_c_decision_input_values.py` | Frozen currentness, authority, source-ceiling, and recommendation-consistency inputs |
| `_rw0_c1_mutation_contracts.py`, `_sqlite_rw0_c1.py` | Admission of typed D1/D2 evidence without converting it into a decision |
| `_rw0_c2_*` documents and pure tests | Compatibility target only; no durable C2 writer in D2 |

# 4. State and authority ownership

| State or evidence | Sole owner | Explicit non-owner |
|---|---|---|
| Program, version/head, WorkSpec binding | Existing Coordinator SQLite program path | D1 orchestrator, planner, worker |
| Author effect, fences, delivery | Existing C2B3D durable path | Planner and supervisor |
| Planner output | Fake planner process | Not selection or program truth |
| Pre-execution selection | Existing Section 41 durable writer and receipt | Planner, orchestration handback |
| RW0 phase basis | Existing RW0-C1 phase establishment | Supervisor |
| Process lifecycle | Parent supervisor | Not progression truth |
| Candidate bytes | Worker in bounded workspace | Not acceptance or selected program state |
| Capsule manifest | Independent parent-owned builder | Worker-supplied manifest |
| Workspace | Ephemeral custodian/evidence source | Not hidden durable state |
| D1 handback | Transient typed projection | Not a durable decision |
| Validation evidence | Validator source | Reviewer/model cannot rewrite it |
| Review evidence | Independent reviewer | Validator/model cannot author it |
| Model recommendation | Fake review model | Cannot select C2 branch |
| Durable evidence membership | RW0-C1 | Does not imply completeness or acceptance |
| Future C2 decision | Later RW0-C2 writer | D1/D2 cannot author it |

The key invariant is:

> **No in-memory run object, fixture controller, process supervisor, workspace marker, or handback may become a second authoritative program, selection, phase, or decision state.**

# 5. Dependency and audit order

1. **D1 read-only implementation map** — the prompt below.
2. Review that map for source placement, current private-call composition, and authority conflicts.
3. **D1 implementation tranche** — source, tests, and bounded current-status amendments in one candidate.
4. Independent audit of:
   - current durable-path reuse;
   - process isolation;
   - absence of child database/writer access;
   - supervisor lifecycle;
   - candidate/capsule independence;
   - one-intent/one-handback behavior.
5. Commit, merge, and refreshed snapshot.
6. **D2 read-only implementation map**, grounded on the actual D1 handback and process modules. This is implementation planning, not another target-contract freeze.
7. **D2 implementation tranche**, independent audit, commit, merge, and refreshed snapshot.
8. **RW0-C2 physical implementation map and implementation**, consuming the exact evidence shapes demonstrated by D1/D2.

Do not start RW0-C2 implementation while D1 or D2 still requires the user to relay intermediate results.

# 6. Evidence that forces replanning

## D1

Replan if the map or implementation shows that:

1. current program, author-effect, Section 41, or phase paths cannot be composed without a second harness-owned lifecycle;
2. production code would have to import test fixtures to construct mandatory values;
3. the fake planner must author durable identities or select its own proposal;
4. a child must receive SQLite path, open database/lock descriptor, or writer authority;
5. timeout, cancellation, reap, or cleanup cannot be bounded without a new broader runtime owner;
6. the capsule cannot be reconstructed independently of worker assertions;
7. existing wire/worker values cannot represent actual process results without changing their frozen meaning;
8. D1 requires a schema/migration, public CLI/service, live credential, network, Git effect, or D2 logic;
9. D1’s handback cannot feed D2 without semantic translation;
10. current contracts require validation/review completion before a capsule handback, collapsing the approved split.

## D2

Replan if:

1. actual validator/reviewer results cannot fit the existing finite dispositions;
2. the existing post-execution role inventory cannot represent distinct evidence sources;
3. RW0-C1 cannot admit the demonstrated evidence without changing its fixed inventory or semantics;
4. the Section 41 post-execution projection cannot be built from the D1/D2 values;
5. the C2 input projection requires renamed identities, changed digests, or a translation layer;
6. the fake review model must acquire branch or acceptance authority;
7. D2 requires terminal or durable C2 implementation to produce its handback.

# 7. D1 read-only implementation-map handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="1"}[Download the complete RW0-D1 implementation-map prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Map_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Map_Prompt.txt

Bytes:
25,213

SHA-256:
b0025129d4446b300a100df2d569c63ef89bde6e1c314af7c970506da408d860

Logical lines:
609

Final newline:
present
```

The prompt binds the current merged baseline:

```text
Branch:
trunk_dev

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Sole parent:
630414faa07f4ac39c4a870a9cc44c7f92d46b80
```

It requires the mapping pass to return:

- the actual current private call graph;
- the proposed D1 call graph;
- exact planner, supervisor, worker, workspace, capsule, and handback boundaries;
- exact persistence entry points;
- package-private executable placement;
- minimum created/modified files;
- current nonimplementation tests and docs requiring bounded status updates;
- process and database-isolation strategy;
- test and audit plan;
- D2 handoff compatibility;
- concrete authority conflicts and stop conditions.

Possible dispositions are:

```text
RW0_D1_IMPLEMENTATION_MAP_READY
RW0_D1_IMPLEMENTATION_MAP_REPLAN_REQUIRED
RW0_D1_IMPLEMENTATION_MAP_BLOCKED
```

The mapping pass is prohibited from mutating the repository, running tests, importing repository modules, creating an architecture package, or issuing the D1 mutation prompt.

**No D1 mutation prompt is authorized until this map has been reviewed.**

## Sources

Current merged Coordinator snapshot: Governed Execution Coordinator - Snapshot - 2026-10-15.zip[Governed Execution Coordinator — October 15 snapshot](sandbox:/mnt/data/snapshot_check/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-15.zip), tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`. [Governed Execution Coordinator - Snapshot - 2026-10-15.zip](https://chatgpt.com/library/d/file_00000000eafc81f6a0d8d8f7b4aa0ef0)

Principal repository references:

- `AGENTS.md:46–110,547–575,885–930`
- `src/ge_nwp_coordinator/__init__.py:1–7`
- `src/ge_nwp_coordinator/sqlite_writer_session.py:5608–5694,6052–6233,6429–6469`
- `.docs/rw0-c1-durable-evidence.md:8–28,44–70,93–109,253–260`
- `.docs/rw0-remote-worker-contact-phase-entry.md:280–342,467–524`
- `.docs/worker-execution-boundary.md:32–56,168–230,307–360`
- `.docs/c2a-first-slice-semantic-protocol-contract.md:471–577,1239–1271`
- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py:724–812,1434–1585,1889–2025,2451–2585`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py:1457–1585,1637–1896`
- `pyproject.toml:1–12`

**Confidence:** High on the D1/D2 split, authority model, and sequencing. Medium-high on the exact minimum D1 touched surface until Codex maps the current private constructors and Section 41/phase prerequisites end to end.
