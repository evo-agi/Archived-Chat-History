# Governed Execution Coordinator — RW0-D1 Offline Process and Capsule Spine: Read-Only Implementation Map

## Mandate

Produce one repository-first, implementation-oriented READ-ONLY map for the
first source-bearing RW0-D tranche:

`RW0-D1 — offline process and capsule spine`

Do not mutate the repository. Do not create a patch, architecture package,
freeze manifest, JSON evidence bundle, or implementation prompt. Do not run
tests, import repository modules, execute repository scripts, open SQLite
databases, install dependencies, contact a network or provider, access sibling
repositories, or spawn subagents.

Return operative findings inline with exact repository-relative `path:line`
evidence. The output must be concrete enough to support a later bounded D1
mutation prompt without asking the user to choose files, process APIs, workspace
layout, test commands, or ordinary implementation boundaries.

Use the highest exposed reasoning setting. Record the visible model, reasoning
setting/effort, and permission posture, or `not visible`. Do not seek additional
account or computer access merely to reveal hidden settings.

## Exact baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required current baseline:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- locally expected divergence: `0 ahead / 0 behind`
- one worktree
- clean tracked, untracked, staged, and unmerged state
- no active Git operation or unexpected lock.

Read `AGENTS.md` first. Verify baseline with non-mutating Git inspection and
optional-lock suppression where appropriate. Do not fetch or normalize the
checkout. Local tracking equality is not fresh remote truth.

If the repository is not at this baseline, stop with:

`RW0_D1_IMPLEMENTATION_MAP_BLOCKED`

## Product decision already made

Do not reopen this sequencing decision:

1. RW0-D1 offline process and capsule spine comes first.
2. RW0-D2 offline evidence and cognitive-review closure follows D1.
3. RW0-C2 physical/durable decision implementation follows D2.
4. D1/D2 and C2 are not concurrent implementation programs while the user is
   the manual handoff layer.
5. No standalone semantic-contract tranche may be inserted before D1 source
   work merely because another value, envelope, read-set, currentness, or
   recovery seam can be specified.
6. A concrete authority contradiction discovered by implementation mapping may
   require replanning; ordinary engineering choices do not.

This pass maps D1 only. It must identify the exact D2 handoff but must not map
or implement all of D2.

## Fixed D1 observable capability

One private offline invocation must eventually perform, without intermediate
user relay:

```text
accepted private WorkSpec/program input
→ current durable program initialization or exact replay
→ current author-effect lineage as required by the existing selection path
→ process-separated deterministic fake planner
→ current Coordinator Section 41 pre-execution selection
→ current RW0-C1 phase establishment before worker contact, if required by the
  governing phase-entry contract
→ process-separated deterministic fake coding worker
→ one bounded candidate mutation in an isolated temporary workspace
→ candidate capture
→ independent immutable capsule reconstruction and verification
→ typed offline D1 handback
```

The map must determine the exact existing durable prerequisites and call order.
It must not silently remove author-effect or phase-entry steps if the current
selection/worker contracts require them.

The initial input is an accepted private `WorkSpecV1` or exact bounded fixture
projection using existing private identities. D1 does not create:

- a public natural-language intent API;
- a generic task grammar;
- a service, daemon, queue consumer, CLI, MCP, or network endpoint;
- a new public package export;
- a second program lifecycle;
- a harness-owned durable selection;
- a durable C2 decision, acceptance fact, or terminal outcome.

## Fixed D1 implementation boundary

D1 must implement and demonstrate:

- one private offline entry invocation;
- a deterministic fake planner in a separate OS process;
- the current durable program and Section 41 selection path in a disposable
  Coordinator SQLite database;
- the current private author-effect path when required by the Section 41 bundle;
- the current private RW0-C1 phase-establishment path before worker contact when
  required by the governing contract;
- a process-separated fake coding worker/Codex executable;
- bounded supervisor lifecycle: launch, exact stdin/stdout framing, bounded
  stderr, deadline, cancellation request/signal handling, exit observation,
  reap, and cleanup;
- one real mutation of an authorized path in an isolated temporary workspace;
- candidate capture from observed workspace bytes;
- capsule construction by a parent-owned builder that does not trust a
  worker-authored manifest;
- independent reconstruction from the authorized base plus captured candidate
  and exact verification of `CandidateCapsuleManifestV1`;
- one typed D1 handback containing exact durable lineage coordinates and
  transient process/candidate/capsule evidence;
- no user message relay between planner, selection, worker, capture, capsule,
  and handback.

The worker and planner processes must not receive or discover:

- Coordinator SQLite path;
- open database connection or inherited database descriptor;
- WriterSession, mutation lease, writer proof, state-authority lock, or
  operation capability;
- standing-policy credentials or live authority;
- hidden shared mutable state.

The map must identify how process inheritance, environment, cwd, open file
descriptors, and arguments will enforce this.

## Fixed D1 nonclaims

D1 will not establish:

- competent autonomous planning or coding;
- live Codex or model/provider use;
- production credentials, network, external authority, or supplier conformance;
- restart-safe orchestration;
- durable worker/capsule truth beyond existing current durable owners;
- durable C2 decision, immutable acceptance fact, or terminal outcome;
- migration `0005`;
- Git commit, push, PR, merge, or publication effect;
- Execution Substrate or Bridge integration;
- public service/API/CLI behavior;
- permission for RW0-E.

Fake authority/currentness and fake planner/worker processes are explicit
offline fixtures. A typed handback is evidence/projection, not durable
progression truth.

## Fixed D2 boundary for handoff only

D2 starts from the exact D1 capsule and D1 handback and later adds:

```text
process-separated validator
→ process-separated independent reviewer
→ process-separated fake semantic-review model
→ typed validation/review/model evidence
→ typed post-execution proposal
→ C2-compatible final handback
```

D2, not D1, owns validation, independent review, model review, post-execution
proposal-family construction, and final projection into the frozen RW0-C2 input
vocabulary.

D2 may reuse the D1 supervisor and process framing, and must consume the exact
D1 capsule and durable lineage. It must not require semantic translation to
produce frozen C2 input values.

Do not move validator, reviewer, fake review model, C2 recommendation reduction,
or post-execution closure into D1.

## State and authority invariants

The map must preserve this ownership model:

| Fact/material | Owner in D1 | Forbidden shadow authority |
|---|---|---|
| Program, version/head, accepted WorkSpec binding | Existing Coordinator SQLite program initialization path | No orchestration object or in-memory run record may become a second program truth |
| Author effect, attempt/effect fences, initial delivery lineage | Existing C2B3D durable path | Planner/supervisor may not mint replacements |
| Pre-execution proposal | Fake planner process authors proposal content only | Planner may not select or write SQLite |
| Pre-execution selection | Existing Section 41 Coordinator writer and receipt | No harness-selected boolean or copied proposal result |
| RW0 phase basis, if required before contact | Existing RW0-C1 phase establishment | Supervisor may not substitute an in-memory phase |
| Process launch/exit/timeout/cancel observations | Parent supervisor | Process facts do not become semantic progression |
| Candidate bytes | Fake worker in bounded workspace | Candidate bytes do not become acceptance or program head |
| Capsule manifest | Parent-owned independent builder from observed base/candidate | Worker-supplied manifest is not authoritative |
| Workspace | Ephemeral custodian/evidence source | Filesystem markers are not hidden program state |
| D1 handback | Typed transient projection | It is not a C2 decision, receipt, terminal outcome, or acceptance fact |

If current source cannot compose the durable program/author-effect/selection/
phase path without creating a second harness-owned lifecycle, return
`RW0_D1_IMPLEMENTATION_MAP_REPLAN_REQUIRED`.

## Required inspection

Inspect exact source placement, imports, packaging, private APIs, tests, and
persistence entry points. Read relevant files fully or in sufficient owning
context.

### Guidance and status

- `AGENTS.md`
- `README.md`
- `pyproject.toml`
- `.gitignore`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/worker-execution-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/c2a-first-slice-semantic-protocol-contract.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-b2-wire-protocol.md`
- `.docs/rw0-b2-capability.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/rw0-c2-first-live-proof-posture.md`
- `.docs/c2b-durable-development-state.md`, current program, author-effect,
  Section 41, and RW0-C1 implementation-status sections.

### Packaging and public boundary

- `src/ge_nwp_coordinator/__init__.py`
- package discovery implied by `pyproject.toml`
- any `__main__.py`, project scripts, entry points, or executable packaging
  currently present
- tests pinning package-root exports, production file inventory, and absence of
  process/runtime modules.

Confirm whether private `python -m ge_nwp_coordinator.<module>` executable
modules can be packaged without a public console-script or package-root export,
or identify a better bounded placement.

### Current durable program and selection path

- `src/ge_nwp_coordinator/_development_program_initialization_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_program_initialization.py`
- `src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py`
- `src/ge_nwp_coordinator/_cognitive_proposal_semantic_values.py`
- `src/ge_nwp_coordinator/_cognitive_proposal_row_values.py`
- `src/ge_nwp_coordinator/_cognitive_proposal_value_support.py`
- `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_effect_row_values.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- migration `0002` and `0003` definitions.

Inspect the exact private `SQLiteWriterSession` methods and transaction
delegates for:

- program initialization/apply/recovery;
- author-effect establishment/apply/recovery;
- Section 41 recovery-probe preparation;
- Section 41 disposition recording and recovery.

Determine the exact required command/bundle/value construction path. Identify
which current constructors are production-private and which usable builders
exist only under tests.

### Current RW0 phase path

- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`
- migration `0004`
- private `SQLiteWriterSession._establish_rw0_phase(...)` and recovery entry.

Decide from current authority whether D1 must commit the C1 phase basis before
worker launch. If yes, map the minimum exact phase command inputs and state that
D1 does not yet admit D2 validation/review/model evidence. If no, identify the
specific current owner text that permits offline worker contact without phase
establishment.

### Worker, wire, and capability values

- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_wire_protocol_values.py`
- `src/ge_nwp_coordinator/_rw0_worker_mechanism_capability_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`

Map exact use of:

- `WorkSpecV1`
- `AttemptFenceV1`
- `EffectFenceV1`
- `WorkerCommandV1`
- `DeliveryEnvelopeV1`
- `WorkerObservationV1`
- `CandidateCapsuleManifestV1`
- wire command/result frame encode/decode
- process/result classification
- fake mechanism declaration/observation/qualification, if D1 needs them.

Do not widen pure semantic modules with subprocess, filesystem, SQLite, or
environment access.

### Process and filesystem mechanics

Search all production source for existing:

- `subprocess`, `Popen`, `posix_spawn`, `asyncio` process APIs;
- process-group/session management;
- signal/timeout/cancellation utilities;
- stdout/stderr framing or bounded capture;
- temporary-workspace utilities;
- file-mode, symlink, path-ceiling, and candidate-diff utilities;
- capsule construction or storage utilities.

Report explicitly when none exists. Test-only subprocess helpers are evidence,
not reusable production utilities unless moved into a properly owned private
source module in D1.

Inspect platform assumptions and Python-version support from `pyproject.toml`.
Do not choose a cross-platform abstraction unsupported by the repository.

### Persistence controller and isolation

- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_connection.py`
- `src/ge_nwp_coordinator/sqlite_location.py`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/state_authority_lock.py`
- `src/ge_nwp_coordinator/state_store.py`

Determine how a private D1 entry can create a disposable database, migrate it
through `0004`, acquire one writer session, execute the current private durable
operations, and close all database/writer resources before any child process is
launched or at least prevent all database/writer descriptors and paths from
crossing the child boundary.

Map exact ownership of the temporary database path and cleanup. The child
process must not receive that path via argv, env, cwd, stdin payload, inherited
file descriptor, or Python object.

### Existing tests and current contradictions

Inspect at minimum:

- program initialization contract, private atomic persistence, delegation, and
  recovery tests;
- author-effect contract, private atomic persistence, delegation, and recovery
  tests;
- Section 41 proposal semantic/row/disposition, private atomic persistence,
  delegation, and recovery tests;
- RW0-C1 phase/evidence mutation, reader, persistence, delegation, and recovery
  tests;
- `tests/test_worker_execution_semantic_*`
- `tests/test_rw0_b2_wire_*`
- `tests/test_rw0_b2_capability_*`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_architecture_contracts.py`
- `tests/test_autonomous_software_development_operating_model.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_sqlite_backend_b0_contract.py`
- `tests/test_b2a_writer_session_contract.py`

Identify exact tests and docs that currently pin:

- no worker supervisor/process;
- no subprocess call;
- no capsule builder/store;
- no private entry point;
- exact production-file inventory;
- package exports;
- current RW0-C-before-D sequencing.

These are expected implementation-status amendments inside D1, not reasons for
another standalone contract tranche. Distinguish status assertions that should
change from authority invariants that must remain.

## Required implementation-map judgments

### A. Exact D1 call graph

Return one exact proposed call graph from private entry to typed handback,
naming current private functions/methods and where new functions are required.

At minimum settle:

- whether D1 always initializes a program or may accept an exact already
  initialized disposable program;
- the current author-effect prerequisites required before Section 41;
- how planner output becomes a `PreExecutionProposalSelectionBundleV1` without
  letting the planner author durable lineage, selection, or preassigned
  Coordinator identities;
- how Section 41 recovery-probe and disposition recording are invoked;
- whether and where RW0-C1 phase establishment occurs;
- how the exact selected durable lineage is reconstructed before worker launch;
- how `WorkerCommandV1`, fences, delivery, and wire frames are built;
- how process and capsule evidence become one typed D1 handback.

### B. Planner process boundary

Specify:

- exact child input and output values;
- whether existing RW0 wire framing can truthfully carry planner traffic;
- if not, the smallest private D1-only framing needed without freezing a new
  durable/public protocol;
- which fields the planner may author;
- which fields Coordinator must supply or bind after child output;
- malformed output, timeout, cancellation, stderr, and exit behavior.

The fake planner may author plan content and a model proposal only. It may not
select, mutate SQLite, mint program/effect/fence identities, or author current
authority.

### C. Worker process and supervisor boundary

Specify:

- exact worker input and output framing;
- current semantic/wire constructors reused;
- child executable placement and invocation;
- sanitized environment, cwd, inherited FD policy, stdin close, stdout frame,
  bounded stderr, deadline, process group/session, cancellation and signal
  ordering, reap, and cleanup;
- typed handling of start failure, malformed result, deadline, cancellation,
  nonzero exit, missing candidate, and cleanup uncertainty.

The supervisor owns process facts only. It cannot make a progression decision.

### D. Workspace and capsule boundary

Specify:

- base fixture source and immutable base identity;
- authorized path materialization;
- symlink and path traversal policy;
- worker-visible workspace and writable scope;
- candidate capture rules;
- before/after bytes and mode handling;
- parent-owned capsule builder;
- independent reconstruction/verification;
- immutable retention only for the duration of the D1 handback;
- cleanup ordering and unresolved-cleanup result.

The worker must not author the accepted capsule manifest. It may emit candidate
status/observations; the parent builder derives the manifest from observed
bytes.

### E. Typed D1 handback

Define the smallest private handback needed by D2, using existing values where
possible. It must bind:

- durable program/version/work and selected Section 41 coordinates;
- semantic attempt/candidate/effect/command/fence/delivery coordinates;
- phase basis if established;
- planner process outcome;
- worker process and wire outcome;
- candidate capture outcome;
- exact `CandidateCapsuleManifestV1` on success;
- workspace/capsule cleanup status;
- one closed D1 status/reason vocabulary.

It is transient evidence, not a durable decision. Do not create a second
program state machine in the handback.

### F. Minimum touched surfaces

Return a path-level implementation plan with four classifications:

- `create`
- `modify`
- `inspect only`
- `must remain unchanged`

For each created/modified path state:

- exact responsibility;
- why the path is necessary;
- principal classes/functions to add or change;
- authority or public-surface impact;
- tests that cover it.

Choose the minimum coherent surface. Do not return alternatives unless one is a
genuine authority fork. Select one recommended placement and sequence.

Pay particular attention to:

- private source modules for orchestration, process supervision, workspace,
  capsule, and handback values;
- whether fake child executables belong in package-private modules invoked with
  `python -m`, another package-private mechanism, or test fixtures;
- `__init__.py`, `pyproject.toml`, and package-root exports;
- current status docs and tests whose nonimplementation claims must be updated;
- exact durable modules that should not be edited.

### G. Tests and validation map

Design the later D1 implementation evidence without running it now.

Require:

- focused pure tests for private handback/status values;
- subprocess tests proving separate PIDs/process groups;
- planner happy path, malformed frame, nonzero exit, timeout, cancellation,
  stderr bound, and reap;
- worker happy path and corresponding failures;
- proof child argv/env/cwd/stdin do not contain the database path or writer
  material;
- proof inherited descriptors do not include Coordinator SQLite/lock resources;
- current program initialization, author-effect, Section 41 selection, and C1
  phase paths are actually invoked;
- proof no harness-selected shadow truth exists;
- bounded candidate mutation and path/symlink escape rejection;
- independent capsule reconstruction and hostile worker-manifest rejection;
- typed success and failure handbacks;
- cleanup and no surviving child/workspace;
- package export and no-CLI/service checks;
- owning regression groups and full repository.

Identify the exact existing tests likely to require amendment and the exact new
test modules recommended. Do not invent historical test counts.

### H. D2 handoff

Return the exact D1 artifacts and durable coordinates D2 will consume.

Confirm that D2 can later reuse:

- the D1 supervisor/process utility;
- `CandidateCapsuleManifestV1`;
- worker/wire observations;
- current RW0-C1 evidence admission, where applicable;
- `_post_execution_evidence_values.py`;
- `_post_execution_policy_values.py`;
- `_section41_post_execution_role_resolution.py`;
- `_section41_post_execution_proposal_family_projection.py`;
- `_rw0_c_decision_input_values.py`.

Identify any missing D1 output that would force semantic translation in D2.
That is a replanning finding, not permission to add D2 implementation to D1.

## Replanning conditions

Return `RW0_D1_IMPLEMENTATION_MAP_REPLAN_REQUIRED` if any of these are true:

1. current program/author-effect/Section 41/phase paths cannot be composed
   without a second harness-owned authoritative lifecycle;
2. required D1 input can only be constructed by importing test fixtures into
   production;
3. Section 41 selection requires planner-authored durable identities or selection
   authority;
4. worker launch requires exposing Coordinator SQLite path, open descriptors,
   WriterSession authority, or hidden shared mutable state to a child;
5. no bounded process strategy can guarantee timeout/cancellation/reap/cleanup
   on the repository's supported platform without a broader runtime owner;
6. a capsule cannot be derived independently from authorized base/candidate
   bytes without trusting worker-authored manifest data;
7. existing wire/worker values cannot express D1 process results without
   changing frozen semantic meaning;
8. D1 handback cannot feed D2 and frozen C2 inputs without semantic translation;
9. D1 requires schema/migration changes, a public service/CLI, live credentials,
   network, Git effects, or C2/terminal implementation;
10. the current authority contracts require validation/review/model closure
    before a capsule handback, collapsing D1 and D2.

Return `RW0_D1_IMPLEMENTATION_MAP_BLOCKED` for baseline drift, unavailable
primary source, or an unresolved source contradiction that prevents a reliable
map.

Otherwise return:

`RW0_D1_IMPLEMENTATION_MAP_READY`

## Required inline output

Return:

1. primary disposition and visible settings;
2. exact baseline and inspection scope;
3. current implemented call graph and missing runtime owners;
4. selected D1 capability boundary and exact call graph;
5. D2 boundary and exact handoff;
6. state/authority ownership table proving no shadow program truth;
7. planner, supervisor/worker, workspace/capsule, and handback designs;
8. exact minimum path-level touched-surface map;
9. implementation sequence with dependency order;
10. test/audit plan;
11. concrete current contradictions and how the D1 implementation tranche
    should amend them;
12. explicit nonclaims;
13. evidence that would force replanning;
14. continuation capsule no longer than 1,000 words.

No mutation prompt. No code patch. No architecture package. No freeze manifest.
No request for user choices about ordinary engineering boundaries.
