## Disposition

**Proceed to a fresh independent read-only re-audit of the exact repaired 46-path D1 candidate. Do not stage or commit it.**

The closeout resolves the known consumer-boundary coordination and reports a complete final validation run. Only the B1 owner and its two test projections changed during this continuation; the retained runtime and Wire repairs stayed byte-identical. No further repair or mutation-ceiling expansion is indicated by this report. **That is readiness for independent inspection—not acceptance of the implementation.** Pasted text Pasted text

## The B1 correction matches the selected boundary

The reported registry now distinguishes:

```text
RW0-D1-pre-execution
    constructs the phase basis for the guarded C1 command

RW0-D1-handback
    validates and retains the exact established phase evidence

RW0-C1
    establishes and verifies the durable phase
```

The handback receives only the direct, relative, unaliased `RW0PhaseEntryBasisV1` import needed for its `phase_basis` field. The registry advances to version 3; **the B1 value schema and its authority do not change**. Both test projections remain independently fixed. Pasted text

The positive evidence is appropriately targeted: the reported real D1 case matched the handback’s basis reference and digest to the C1 result, retained both exact Wire result types, and showed that constructing another handback caused neither basis construction nor a C1 write. The negative controls reportedly preserve the closed importer and symbol restrictions. These are the right claims for the auditor to reproduce. Pasted text

This completes the **known dependency correction**. It does not independently close the original handback, fork-custody, cleanup-classification, or frame-error findings.

## Provenance and validation reconcile

The final candidate remains:

```text
29 modified tracked paths
17 untracked additions
46 candidate paths total

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Final replacement identity:
4,465,502 bytes
b82b43fc4da2e5f258436cec351dcc2a561057b9edb64d7bffbbb35003c84974
```

The latest three changes add **476 + 8,750 + 2,376 = 11,602 bytes**, taking the preceding 4,453,900-byte replacement stream to 4,465,502 bytes. I checked that arithmetic and every encoded component length when constructing the handoff. That corroborates the reported identity structure; it does not reproduce the aggregate hash without the live candidate bytes. Pasted text

The significant final validation results are:

| Gate | Codex-reported result |
|---|---:|
| D1 runtime and integration | 92 passed |
| Wire | 123 passed |
| Legacy guards, including B1 | 1,773 passed |
| Remaining changed owners, including phase-entry projection | 667 passed |
| Complete repository | **8,942 passed, 3 existing warnings** |

All twelve groups reportedly completed serially from one fresh final clone. Groups 1–11 contain 3,615 distinct nodes after accounting for the two reported overlaps, and the full collection contains them all. The count change also reconciles to the original D1 candidate:

```text
8,877
+ 35 runtime-repair tests
+  6 Wire tests
+ 19 B1 tests
+  5 phase-entry tests
= 8,942
```

These are consistency checks, not substitutes for independent execution. Pasted text

The latest continuation also recorded complete opening and closing cache **directory and member** metadata, including nanosecond mtimes. It correctly leaves the previous continuation’s missing historical directory metadata unproved rather than claiming to reconstruct it. Pasted text

## What the re-audit must close

### The four original runtime findings

**Handback invariants.** The auditor must verify the actual sixteen-field contract, not just annotations: exact accepted types, stage-dependent evidence, status/reason compatibility, and rejection of live paths or resource objects. The previously surviving mutant that inserts the actual state root into returned handbacks must now fail a permanent test.

**Creating-process custody.** A real forked child must be unable to expose or remove the retained disposable state. The parent must remain open, close successfully, and tolerate a second close. A mocked PID check alone is insufficient.

**Cleanup uncertainty.** Selector or stream cleanup failures after real planner and worker launches must preserve process observations, attempt group-clear observation, and produce `cleanup_unresolved`. They must not erase evidence or become `stopped/durable_conflict`.

**Closed frame errors.** Malformed canonical enum fields, including `action: []`, must produce `D1FrameError` and the corresponding stage-specific handback reason before later durable progression.

Those were concrete findings in the original independent audit. The subsequent passing repair tests are evidence of a proposed fix, not independent closure. Pasted text

### Wire/B1 coordination and the unfinished original acceptance checks

The re-audit must verify that the handback’s two Wire types and one B1 type are **evidence dependencies only**. It must check both fixed B1 projections, preserve existing consumers, and reject extra symbols, aliases, dynamic imports, unauthorized consumers, or construction authority in the handback.

It must also finish the material acceptance checks left incomplete by the first blocked audit. That audit stopped its full run after 1,405 passes and did not claim groups 2–11 or the complete transformed-copy campaign. The new implementation report does not retroactively complete those independent checks. Pasted text

The handoff therefore includes a fresh actual durable-call trace, child-isolation and process-cleanup checks, independent capsule verification, retained-state lifetime checks, and the scoped governance safeguards. It reuses overlapping evidence where appropriate rather than multiplying identical tests into another open-ended audit program.

## Independent re-audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="9"}[Download the complete repaired-V3 D1 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V3_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V3_Independent_Reaudit_Prompt.txt

Bytes:
45,742

SHA-256:
e19059440b5ffa778153d37621cc73c5becd9923cfaf561f364637521d46101e

Lines:
729

Final newline:
present
```

The prompt includes the **complete final 46-path receipt table**, not a delta requiring earlier attachments. It binds the latest replacement identity, the version-3 B1 roles, the retained Wire extension, all four runtime repairs, and the exact twelve validation inventories and hashes.

It permits executable audit work only in disposable, remote-free external clones. The live checkout remains read-only. It prohibits candidate repair, stage/commit/publication, D2 or C2 implementation, supplier work, enrollment, deployment, and live effects.

Possible verdicts remain:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

An acceptance would support only a **separately issued commit/publication gate for these exact files**. It would not authorize D2, physical C2, migration `0005`, qualified-source or supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the latest closeout and the issued V3 continuation in full. I corroborated all **29 baseline blob identities** against the mounted October 15 snapshot, verified that the 17 additions are absent from that baseline, checked the receipt and test-count arithmetic, and reopened the generated prompt.

I did **not** inspect the live repaired source, reproduce its final endpoint hashes, or run repository code or tests. The candidate’s behavior and full-suite results remain Codex-reported until the independent re-audit reproduces them.

**Sources:** Latest V3 repair closeout and its issued continuation, cited above; the original independent audit’s findings and evidence limits; October 15 Coordinator snapshot for baseline-blob corroboration.

Some older uploads have expired. Please re-upload an expired original only when a later comparison needs its bytes; this handoff requires no historical attachment.

**Confidence:** High on readiness for this re-audit and on the bounded B1/Wire ownership treatment. Final runtime correctness, complete independent validation, and commit readiness remain unresolved.
