# Governed Execution Coordinator — RW0-D1 Audit Repair V9
# Four test-causality gaps; five existing tests; production unchanged

## FIRST ACTION — live guidance as text, never Git first

The first repository-related tool action after receiving THIS instruction must
read live AGENTS.md as plain text, from a neutral working directory. Do not run
status, rev-parse, a repository bootstrap or a settings command that invokes Git
first. This is a new, explicitly authorized REPAIR interval, not a continuation
of the auditor's observation interval and not permission to reconstruct history.

```sh
python3 -I -B -S - <<'PY'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY
```

Read all returned guidance, using further text reads if output truncates. Then
establish the pre-Git record/helper below BEFORE any Git command. Once opening
and authentication pass, complete the bounded repair without per-phase user
approvals. No intermediate architecture or standalone contract handoff.

## Mandate — close the four named test-causality gaps; preserve all runtime

Resume the IMPLEMENTATION conversation owning the retained, uncommitted D1 V8
candidate. This is ONE bounded test-only repair interval inside the existing D1
program. Do not recreate the implementation, restart architecture planning,
insert a standalone semantic tranche, or begin D2/physical C2.

Latest independent audit verdict:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

The audit completed a valid opening/preservation interval and all twelve normal
validation groups, including 8,984 full-suite passes. It nevertheless found four
permanent-test causality gaps. The retained production implementation rejected
the direct bad specimens or did not produce the forbidden behavior; the described
regressions occurred in external transformed copies. Preserve that distinction.

| Severity/type | Reported surviving regression | Selected correction |
|---|---|---|
| High, acceptance evidence | A two-production-file copy supplied the actual parent SQLite path in BOTH real child environments; the named normal integration and direct supervisor isolation tests passed and the run was ready | Strengthen the real invocation's lower-boundary input observation in the integration test, rather than trusting a separate direct-supervisor fixture |
| Medium, handback test causality | Removing the later-prefix planner clean-success check left all owning handback tests passing; a valid worker_start prefix with a valid but unsuccessful earlier planner was admitted by the copy | Add discriminating cross-stage process specimens that satisfy outer/process/other-stage checks and fail specifically on the earlier planner prerequisite |
| Medium, workspace test causality | Removing both hard-link checks remained invisible because the current hardlink specimen also created an extra workspace path and that other guard rejected it | Use a real hard link OUTSIDE the workspace but INSIDE an owned test root, preserving the exact allowed workspace path set and one legitimate edit |
| Low, protected-content guard causality | A second dynamic table assignment derived protected AGENTS/README hashes from current bytes; selected fixed checks and 312 owning Capability/bootstrap tests passed | Protect the single literal definition and reject the demonstrated subsequent rebinding in the Capability owner and its independently fixed bootstrap source checker |

These findings do not establish a current credential leak, incorrect normal
handback, accepted hard-linked workspace, dynamic production identity policy, or
current durable/executable-authority bypass. Their reported survival is limited
to the named tests/selections, not a claim that each mutant passed all 8,984 tests.
Do not generalize the severity of an acceptance-evidence gap to an unobserved
production exploit.

The missing specific 'skip process reap/group cleanup' negative copy remains an
independent acceptance obligation. Neighboring cleanup and R08 checks do not
supply it. This repair does not silently add a process-runtime repair or claim to
complete that unperformed independent experiment.

Parent is sole writer; no subagents or live model/provider calls. Use highest
exposed reasoning and report visible model/effort/permissions or not visible.
Do not access accounts/computer settings merely to expose hidden settings. No
network, installation, siblings, live credentials, supplier or publication work.
Return operative findings INLINE, exact path:line references and commands/results,
full final hashes (no ellipses), plus a continuation capsule <=1,000 words. No
user-delivered patch, manifest, ZIP, snapshot, report or architecture package.

All observations below are requirements to verify against owning files. Report
coordinates and hashes are evidence bindings, not correctness or authority.

## 1. Exact baseline and existing pre-Git mechanism

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

- branch trunk_dev;
- HEAD 0d0926e3a483a3ab1a4fd597ac0495927352bf35;
- tree 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4;
- sole parent 630414faa07f4ac39c4a870a9cc44c7f92d46b80;
- subject: docs: freeze RW0-C2 scope admission provisioning;
- upstream origin/trunk_dev, locally 0 ahead / 0 behind;
- one worktree, index equal to HEAD, zero staged/unmerged paths;
- exactly 29 modified and 17 created candidate paths below;
- no active Git operation, sequencer or unexpected lock.

After reading AGENTS, execute this block from a neutral directory. It invokes no
Git, repository module, SQLite or test. It captures the index and known cache
then creates a forced-environment inspection helper under a mode-0700 external
root. It retains the successful Restart 01 mechanism, with this engagement's
labels. Do not substitute historical timestamps, inodes or hashes for fresh
opening observation. The helper is temporary instrumentation, not product truth.

```sh
python3 -I -B -S - <<'PY'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env

import datetime
import shutil
import tempfile

# This block does not run Git or import repository modules.
guarded_environment()
for key, value in GUARDS.items():
    os.environ[key] = value
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_does_not_match_the_fixed_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_not_found')
root = Path(tempfile.mkdtemp(prefix='rw0-d1-v9-repair-'))
print('AUDIT_OWNED_ROOT=' + str(root), flush=True)
os.chmod(root, 0o700)
record = {
    'schema': 'rw0-d1-v9-repair-opening-observation',
    'phase': 'recorded-before-first-git-in-this-repair-attempt',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents,
    'index_path': str(index), 'index': index_before, 'cache': cache_before,
    'git_environment': GUARDS, 'git_executable': git,
    'historical_limit': 'older audits lack pre-first-Git metadata; this record covers only this repair',
}
wrapper_text = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\nimport subprocess\nimport sys\n\nopening_path = Path(__file__).with_name('opening.json')\nopening = json.loads(opening_path.read_text(encoding='utf-8'))\n\ndef verify_preservation():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('live_index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('live_index_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('live_guidance_drift')\n\nargs = sys.argv[1:]\nverify_preservation()\nenv = guarded_environment()\nif args == ['--check']:\n    print('RW0_D1_V9_REPAIR_OPENING_PRESERVATION_OK')\n    raise SystemExit(0)\n\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_git_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'],\n                                                               ['--quiet', 'HEAD']):\n    raise RuntimeError('only_readonly_head_symbolic_ref_allowed')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('only_worktree_list_allowed')\nfor arg in args[1:]:\n    if (arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec')\n            or arg.startswith(('--output=', '--exec='))):\n        raise RuntimeError('unapproved_git_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager',\n           '-c', 'core.fsmonitor=false', '-c', 'gc.auto=0',\n           '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=env, check=False)\nfinally:\n    verify_preservation()\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(payload)

try:
    write_private(root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(root / 'live_git.py', wrapper_text.encode('utf-8'))
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_any_git_command')
    print('LIVE_GIT_HELPER=' + str(root / 'live_git.py'))
    print('OPENING_RECORD=' + str(root / 'opening.json'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_V9_REPAIR_PRE_GIT_OPENING_RECORDED')
except BaseException:
    # Only known regular files written by this invocation are removed.
    for name in ('live_git.py', 'opening.json'):
        owned = root / name
        if owned.exists():
            if not stat.S_ISREG(owned.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            owned.unlink()
    root.rmdir()
    raise
PY
```

Use the ACTUAL emitted helper/root paths. Do not assume shell variables persist,
guess a temporary root, or rerun the opener to replace its record. Every LIVE
Git inspection goes through the helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> rev-parse HEAD
```

The helper enforces GIT_OPTIONAL_LOCKS=0, GIT_NO_LAZY_FETCH=1 and noninteractive
inspection per subprocess, disables external diff/textconv/fsmonitor and checks
index content/metadata and cache before/after. --check invokes no Git. It does
not wrap pytest, edit the test or prove correctness. It checks AGENTS/index/cache,
not the permitted tests' opening hashes, so it remains valid after the permitted test edits.

Local-only external clone creation is separately permitted with equivalent
command-local suppression; no live index/config change, fetch or maintenance.
Remove clone remotes before execution. Missing objects/unsupported inspection
are a stop, not raw-Git fallback permission. No live Git write is authorized.

Authenticate baseline and complete candidate before editing; provide one compact
inline opening acknowledgement, then proceed automatically. If any Git preceded
this interval's opening, stop before clones, probes or edits. Do not reset the
index, reconstruct prior history, restore metadata or silently rebaseline.
The recent valid audit interval does not replace this repair's own record.

## 2. Complete authenticated opening subject

The latest auditor supplied the FULL integration-file hash after authenticating
it against the pre-fixed replacement stream and Group 1/12 inventories:

`0f38baa211673feef6a0e499f28ffc2a7256439b39a9b1b9cf10800b4518b4b3`

The table now has 46 complete endpoint receipts; there is no MEASURE placeholder,
abbreviated hash, guessed digit or new provenance scheme. Reproduce every receipt
from current bytes. The auditor's old observation is not this interval's opening.

M = tracked modification; C = untracked creation, not a commit/copy. Candidate
files are regular nonsymlink OS-mode 0644, Git representation 100644, strict
UTF-8 with no BOM/CR, one terminal LF and no trailing whitespace. Preserve the
known noncandidate nonexecuting 0600 file and all other actual noncandidate modes.
Do not normalize every repository file to 0644.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 25,215 | `dde79042a7640571493f882b5130b8650c7a52ebd2fc28a6956799a261fa6d4c` | `absent` | 25,286 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 47,176 | `0f38baa211673feef6a0e499f28ffc2a7256439b39a9b1b9cf10800b4518b4b3` | `absent` | 47,251 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read all 29 modified baseline blobs directly from HEAD and verify their OIDs.
The 17 created paths must be absent from HEAD and index. All 217 noncandidate
tracked files remain HEAD-exact. Complete candidate = 246 baseline + 17 created
= 263 endpoints. No new/deleted/renamed path, executable bit, symlink or submodule.

Reproduce twice from independent fresh reads, without importing repo modules:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw HEAD blob bytes, or twenty zero bytes for C
    u64be(payload_length)
    exact payload bytes

46 rows: 29 M / 17 C
encoded row bytes: 4,538,330
prefix: 25
total: 4,538,355
SHA-256: 173adda1a4d1cab3a0056a5156339e1fd1f059533a4f11e915894ddb21ea0ce0
```

The full payload stream, not an inventory of digests, is the replacement identity.
Do not skip a row, accept a new aggregate, recreate files from hashes or request
historical payloads. A mismatch stops this repair before editing.

## 3. Exact FIVE-file mutation ceiling

Only these existing candidate test files may change:

```text
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_workspace_capsule.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

The other 41 candidate endpoints remain BYTE-IDENTICAL to the opening table.
All 217 noncandidate tracked files remain HEAD-exact. No new test module,
conftest, plugin, production module, helper package or dependency is authorized.

ALL production source stays unchanged, including all nine D1 modules, fake
children, supervisor, runner, handback/capture/capsule validators and current
program/author/Section 41/C1 writers/readers/recovery. The direct supervisor
isolation test module stays unchanged; it correctly tests its own direct call,
and does not substitute for the real-run boundary under repair.

Keep every document, AGENTS.md, README.md, owner registry, B1 version 3, both B1
projections, Wire allowance, public/package export, pyproject, configuration and
migrations 0001-0004 unchanged. No migration 0005. Protected identity literals,
row IDs, paths, modes, class lists, purposes, original/replacement identities and
semantic markers MUST NOT be rehashed, weakened or widened.

Retain all existing permanent node names and behaviors. Necessary local helpers,
parameterized cases and strengthened assertions may be added inside these five
files. Do not remove cases, skip/xfail, lower coverage, loosen a real invariant,
patch source to ease observation, or turn observer code into a production gate.

No staged/index/Git-ref changes, commit/push/PR/merge, source branch changes,
reset/rebase, network, provider/supplier, live authority/credentials, enrollment,
deployment, D2/C2/terminal/ES/Bridge/RW0-E or sibling work.

If unchanged production actually violates the specified behavior, report the
source-backed defect and stop. This test-only mandate is not permission to alter
production or weaken expectations. A dependency outside the five files also
requires a bounded stop, not another silently opened path.

## 4. Focused dependency inspection and sequencing

Read each of the five allowed files completely as text. Inspect relevant owning
source and tests, including:

- _rw0_d1_offline.py: actual disposable location creation, supervisor calls,
  all launch/recovery/close/stop sites and the existing V8 observer's hookups;
- _rw0_d1_process_supervisor.py: current seven-key allowlisted environment,
  real Popen lookup and argument handling, process outcome construction;
- tests/test_rw0_d1_process_supervisor.py: existing named direct isolation test,
  its actual child-input/descriptor probe and limits (INSPECT ONLY);
- _rw0_d1_handback.py: all non-None process consumption, later-prefix planner
  clean_success requirement, reason/prefix matrix and worker_start path;
- _rw0_d1_workspace.py: both actual link-count checks and path enumeration,
  type/mode and captured-content checks;
- current _rw0_d1_capsule.py, capture test fixtures and fake worker behavior;
- both allowed protected-identity tests: actual table definition, observed-file
  hashing, expected literals, source AST checker and fixed comparison callers;
- applicable D1/B1/Wire/Capability/bootstrap owner sections and exact test-file
  dependency protections. Do not edit the owner documents.

Report pointers from the latest audit, to re-resolve in authenticated bytes:

```text
supervisor.py:163        environment and launch
integration.py:232       named normal D1 integration
supervisor test:111      direct isolated child probe
handback.py:185          later-prefix planner clean_success check
handback test:451        named process revalidation test
workspace.py:181,:200    two hard-link count checks
Capability test:120      literal protected rows
```

The mounted baseline's bootstrap source checker used the FIRST matching
PROTECTED_CONTENT_ROWS assignment via next(...); inspect the actual retained
candidate rather than assuming that baseline implementation is still exact.
The reported external regression is a SECOND dynamic assignment, so finding one
literal definition somewhere is not the invariant being tested.

Before editing, produce one compact INLINE map: actual interception points,
fixed input expectations, exact handback specimen prerequisites, workspace link
ownership, protected table/AST callers and any implicated dependencies. Then
continue without a user checkpoint. Do not commission another broad recon pass.

Sequence within this ONE repair:

1. guidance/pre-Git opening and exact candidate authentication;
2. narrow owning-source/test dependency inspection;
3. reproduce the FOUR named opening survivors in external copies and record
   actual behaviors separately from permanent-test survival;
4. write the bounded five-file test correction;
5. check all four corrected boundaries and finite controls before long suites;
6. after the last edit, one fresh normal final clone, all twelve groups;
7. complete preservation/cleanup and full endpoint transition closeout.

Exact original mutant bytes were not delivered. Source hashes below identify the
reported copies, not material available to execute. Construct equivalent bounded
copies, retain reviewable diffs and record YOUR full copy hashes. Never claim to
reproduce historical mutant byte identity or PIDs merely from its hash.

## 5. High acceptance-evidence gap: test the REAL invocation's child inputs

### Actual environment boundary, not an unrelated direct supervisor fixture

Strengthen test_full_d1_through_guarded_writers_and_parent_capsule and reuse the
existing test-local V8 observer as appropriate. It must intercept the actual
supervisor Popen lookup BELOW the runner's result assignments throughout the
real invocation. Keep its launch-count/role/order, effective C1/recovery, close
and cleanup assertions. Do not replace or duplicate its runtime ownership.

The observer must call through with ORIGINAL arguments and environment. It must
not sanitize or drop the leaked key, raise before the child is launched, replace
Popen with a fake child, or serve as an extra permission check. Capture a stable
test-local snapshot of the actual argv/env/cwd and descriptor launch options at
the call boundary, and retain each real handle/PID or actual start failure.
Assertions run after a safe invocation boundary, with finally-based cleanup.

Derive the actual parent disposable SQLite file and state root from THIS run's
real private location/custody creation, through existing test-local call-through
hooks or actual retained parent owner. Do not use an unrelated temporary path
and call its absence isolation. Do not derive forbidden coordinates solely from
whatever child arguments the observer sees or from the path-free handback.

Keep the parent DB/state root distinct from the outer pytest/audit root that
legitimately contains planner/workspace siblings. Rejecting every path beneath
that outer root would break valid input rather than prove isolation.

Freeze the currently admitted seven environment KEY names as explicit expected
test literals after reading their owner and source. Assert the actual launch
mapping has exactly those keys, not keys obtained by invoking the supervisor's
own environment builder. For fixed values use the selected current contract;
for per-run values compare to independently observed legitimate child scratch,
workspace, interpreter/package input and current framing. Do not invent a new
public/environment protocol or move these expectations into production.

For EVERY observed actual launch, including an ignored or unreported one:

- require the correct existing planner/worker command and current safe options;
- require exact allowed env keys and independently bound valid values;
- prove the actual Coordinator SQLite file and its state root do not occur in
  any child env key/value, argv entry or resolved cwd;
- preserve current close_fds=True, pass_fds=(), fresh-session, no-shell and
  writer-close-before-child assertions;
- preserve direct child stdin/inheritable-FD tests already present elsewhere;
  do not claim checking Popen flags is itself an OS-level descriptor census.

Inspect the actual environment even when its keys are allowed: a legitimate key
must not become a slot carrying the DB/state coordinate. A focused test-local
negative case may change a captured env VALUE to the actual DB path to prove
this assertion separately from unknown-key rejection. This case is detector
coverage, not proof a real child accepted that altered value.

Use exact artificial parent-only sentinels where existing tests plant credentials
or lock context. Never read or expose real account secrets. All test-local raw
path/argv/env observations remain nonprinting except content-free failure reasons;
do not dump an ambient environment on failure. Do not scan capsule file bytes
or arbitrary stdout for path-looking text: those remain opaque content.

### Real two-file regression and positive control

Reported external hashes:

```text
_rw0_d1_process_supervisor.py:
714902f870352aa2db8bf76da4ebdc7abf3069cf4ebc5111a3634b1409f09e9a
_rw0_d1_offline.py:
ec9f7a0c437e23aa02e800979055a2feb7c9b7d3cd7c1b1e9ceec2fe78a622ca
```

In an external opening copy construct the smallest equivalent change carrying
this invocation's actual parent DB path from runner to supervisor and into BOTH
real children via an added child environment entry. Keep source parsing,
importing, normal frame/process execution and eventual ready behavior intact.
Do not merely leak a hard-coded irrelevant sentinel in a standalone supervisor
call or give the test its own expected bad event.

Run the two named opening tests separately:

```text
tests/test_rw0_d1_offline_integration.py::test_full_d1_through_guarded_writers_and_parent_capsule
tests/test_rw0_d1_process_supervisor.py::test_child_observes_sanitized_argv_env_cwd_and_no_parent_fd
```

Characterize actual Popen envs independently: both real child creations carry
that DB path; their groups clear; the corrupted invocation may still be ready.
Report each selected survivor; do not infer full-suite survival.

Against FINAL test bytes, the same equivalent source mutation must fail the
STRENGTHENED INTEGRATION test on actual child input, even while the direct
supervisor test legitimately still tests/passes its own separate invocation.
Do not credit a global inventory guard, unrelated frame or phase failure,
observer prevention of launch, or a test that silently strips the leaked key.
Normal and legitimate committed_exact-recovered runs must pass and retain the
V8 count/order checks. No production source changes remain in the live candidate.

## 6. Medium handback gap: valid process value, invalid earlier-stage success

The existing later-prefix planner clean_success predicate is implemented; only
its permanent causal protection is under repair. Do not change the predicate,
process type, reason vocabulary, handback fields or prefix matrix.

Create a discriminating specimen using actual successful/failed-start D1 values
or the current production constructors. At minimum:

- a correct worker_start handback at its allowed prefix, with exact failed worker
  launch evidence, committed prior program/author/selection/C1 values and permitted
  cleanup state;
- replace ONLY its earlier planner process by an INTERNALLY VALID unsuccessful
  process record, for example a genuine supported nonzero_exit with consistent
  positive IDs, exit, reap, group-clear and cleanup facts;
- independently establish the process owner's validator accepts that record;
- require the handback to reject the incompatible LATER-stage history specifically
  because the prerequisite planner was not a clean success.

A malformed planner record, extra field, wrong prefix, missing C1 value, wrong
worker-start record or unrelated capture error would mask the predicate. The
negative specimen must reach the current later-prefix clean-success check.
Preserve evidence classes; do not fake a class identity or merely change a reason
on an otherwise internally contradictory process.

Add bounded adjacent coverage of the actual later-prefix compositions admitting
a planner: include one broad stopped/cleanup form and ready as supported by the
current owner. Use the smallest existing fixture/parameter matrix, not a new
lifecycle model. Explicitly distinguish individually valid failure records from
causally incompatible later-stage evidence.

Positive controls must preserve BOTH:

- valid worker_start with a genuinely clean earlier planner;
- that same kind of valid unsuccessful planner in its own legitimate earlier
  planner-failure handback, rather than globally prohibiting negative outcomes.

Reported handback deletion copy:
`f2b6ed2a2c06b77d34dd8d4c8f1ebb786cdc8e0456c38bc34aca235efb36ea29`.
Reproduce equivalent removal of ONLY the later-prefix planner clean_success
check in a disposable source copy. Leave process-value validation and all other
handback predicates intact. The new permanent test must fail because the bad
history is admitted. Normal owning tests and valid negative-outcome positives
must pass on the unmodified candidate. Constructor rejection at another layer
cannot be credited as closing this omitted consumer predicate.

## 7. Medium workspace gap: isolate the real hard-link invariant

The current hardlink fixture also adds an extra IN-workspace path, so it cannot
establish that the link-count guards are active. Preserve it as a composition
case, but add a discriminating real-filesystem case with no extra workspace path.

Use an audit/test-owned root on one filesystem containing:

```text
owned_root/
    workspace/       # exactly the three current authorized fixture paths
    external_alias/  # owned sibling OUTSIDE workspace, not product state
```

Materialize the current exact valid base. Produce the normal single authorized
content edit. Then hard-link one of the other unchanged authorized regular files
to a name under external_alias, or use an equivalent construction that preserves
the link at validation time. Link no live checkout, database, cache, secret,
fixture owned by another invocation or pre-existing arbitrary file.

At the actual workspace consumption boundary independently verify:

- the complete workspace-relative path set is STILL exactly the allowed set;
- entries are ordinary regular files, with accepted modes and byte ceilings;
- exactly one authorized content change exists;
- there is no extra path, symlink, deletion, rename, unsupported mode or malformed
  capture that could reject first;
- the linked authorized inode has st_nlink > 1 because of the owned OUTSIDE alias;
- the alias and workspace file share the observed device/inode;
- the link is not accidentally detached by an atomic replacement before the check.

Call the actual current workspace consumer. It must reject through its existing
unsafe/hard-link boundary. The test may not accept any unrelated exception or
only inspect nlink itself without invoking the owner.

Positive counterpart: the identical workspace and legitimate edit WITHOUT the
outside alias is accepted and its capsule relations remain valid. Authorized
repository-relative paths and opaque bytes retain their existing semantics.

Reported omission copy:
`ce40074aeb32509dbc6d7183a4735e0e1c8948e0edbd775a2151aac346e4166`.
In one external module omit BOTH actual nlink checks and leave path/type/mode/
content checks untouched. The new permanent outside-alias test must fail because
the previously forbidden workspace is admitted. The existing extra_path case
cannot provide that credit. This demonstrates the combined link invariant; do
not claim either redundant check alone is independently proved by the same
specimen if the other check still rejects first.

Do not create a race campaign, adversarial filesystem sandbox, no-follow library,
new candidate grammar or source fix. Real hard-link support on the selected POSIX
proof platform is required for this evidence; unsupported execution is a limit,
not a skip credited as success. Unlink the exact outside alias and clean only
owned roots in finally even when the omission copy admits the workspace.

## 8. Low protected-content gap: one literal definition, no later dynamic reset

The selected invariant is unchanged: observed document hashes are compared with
FIXED expected identities. Calculating observed hashes is allowed. Computing the
expected table from those same current documents is forbidden, even when current
values happen to equal the approved literals.

Read the actual primary and independent checker. Keep existing literal values,
semantic-evidence collection, comparisons, row IDs/order, paths/classes/purposes,
old/replacement identities, semantic markers and positive source checks intact.
Do not rehash AGENTS/README or pin the entire changing test module to a new hash.

Current fixed document endpoints are:

```text
AGENTS.md
62,778 bytes
076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6
README.md
46,898 bytes
dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff
```

### Primary and independent owning checks

In tests/test_rw0_b2_capability_boundaries.py protect the ACTUAL
PROTECTED_CONTENT_ROWS binding read by its existing owning test. Require exactly
one approved literal initialization in the complete module, not merely the first
matching assignment. Reject an additional direct/annotated/augmented rebinding
of that exact table name, including straightforward rebinding in module-executed
conditionals/loops. Ordinary read-only local uses of the table remain legal.

The initializer must remain structurally literal and its full protected row
shape/identities must agree with the already fixed expectations. Do not derive
expected permissions or identities from the runtime table being inspected.
A later dynamic assignment that produces identical values MUST still be rejected.

In tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py strengthen
its independently owned Capability-source check to reject the same second-table
assignment. Preserve its distinct fixed expectation, actual document identity
checks and all bootstrap guard semantic controls. Do not replace them with a
call to the primary helper or derive them from the primary parsed result.

Keep the existing required helper/caller ordering and comparisons where the
independent checker explicitly protects them. Add only the narrow definition/
rebind assertion and directly owning fixed controls. Neither checker may select
next(first matching literal) while ignoring a later executable assignment.

The finite syntax requirement is assignment/rebinding of this named table, not
universal Python alias/exec/reflection analysis. Comments and string literals
containing the table name or example assignment text are harmless; a read-only
iteration for observed comparison is legitimate. Do not ban hashlib/read_bytes
in the module: the OBSERVED evidence collector needs them.

### Exact causal target and fixed negative controls

Reported transformed Capability module hash:
`14ff75072207a4c17a60142e145789373a086d8da197ee152ed7102fd7da95d6`.

In an external copy keep the approved literal definition and append/insert a
SECOND assignment deriving P11/P12 sizes and SHA-256 values from the current
external-copy AGENTS/README payloads. Preserve other row fields and identities.
The bad copy must still parse/import normally and its runtime table can equal the
approved one on these unmodified documents. Do not change documents to force a
simple identity mismatch. This is exactly why equality checks alone were weak.

The actual primary owning test and the independent bootstrap source test must
now fail on the forbidden dynamic/repeated definition, not a new whole-test-file
hash mismatch. Also pass fixed in-memory source variants for legitimate literal
and harmless-text positive controls, missing/literal-replaced cases as appropriate,
and the specified secondary definition. Expectations remain outside the checker.

Use a bounded helper-regression copy to omit the new uniqueness/rebind predicate
while fixed negative source specimens remain unchanged: the owning negative case
must fail semantically, while the legitimate positive remains accepted. Verify
the independently fixed source checker separately; a failure from the other
module cannot falsely prove its own new predicate works.

Do not require resistance to coordinated edits that remove both all checkers and
all fixed specimens. Independent review and exact candidate identity remain that
trust boundary. This repair enforces the named literal/rebinding rule only.

## 9. Finite causal campaign and preserved earlier repairs

The four finding classes above define the NEW work. Use small external copies,
not a generic mutation harness or full-suite-per-mutant. Produce full identities
and precise source deltas for each; supplied old hashes are attribution only.

| ID | External-only target | Required permanent-test signal |
|---|---|---|
| E01 | Real runner -> supervisor -> both child envs carry actual parent DB path | Strengthened actual-run integration fails on observed child inputs; real launches still occurred and are cleaned |
| S01 | Remove only later-prefix planner clean_success requirement | Individually valid unsuccessful planner is wrongly admitted at the valid worker_start/later prefix; fixed specimen fails |
| H01 | Remove both workspace nlink checks, keep all other guards | Valid-edited exact-path workspace with owned outside hard-link alias is admitted; new permanent test fails |
| G01 | Second dynamic protected-table assignment tracks live external document bytes | Primary and independent source controls reject, despite equal runtime values |

Where useful, one in-memory env-value detector control and finite definition
variants can cover adjacent cases without multiplying real process copies. Record
which checks are direct owner tests, full transformed modules, actual process
effects, permanent discrimination or repair-authored characterization.

For every credited mutant require normal parse/package import and normal selected
collection. Tests/expectations stay fixed. No syntax/import/collection shrinkage,
unrelated inventory error, explicit false assertion or premature observer refusal
receives credit. Characterize actual child creations before/after assertions and
retain cleanup handles for unreported ones.

Retain and rerun the latest V8 L01/L02/L03 protections and legitimate recovered
success with the existing observer after integrating the child-input assertions.
A path-sensitive early-copy input failure must not be falsely credited as L02's
count-preserving C1-order detection: arrange each selected specimen to isolate
its named invariant, reporting any overlap instead of double credit.

Likewise retain the V7 verifier-order/authentic-refusal tests and their V01-V03
controls, current deep capture, creator-PID custody, process consistency,
reason-prefix, cleanup/frame behavior, B1/Wire consumer and scoped-C2 boundaries.
The targeted normal groups provide regression of unchanged controls; they do not
retroactively run an omitted independent experiment.

Do not add another standalone semantic package or require the user to route any
intermediate specimen. One integrated test-only candidate and one closeout.

## 10. What prior independent evidence now exists

The latest independent restart had a VALID pre-Git opening, current candidate
identity, all 46 receipts and the formerly abbreviated integration-file hash,
index/cache preservation and full normal validation. Preserve these observations
as PRIOR evidence, not results executed by this repair:

- all twelve groups passed, including 112 D1 and 8,984 full-suite nodes;
- V8 all-launch/effective-C1/recovery/close observation and L01-L03 discrimination;
- V7 real capsule verifier order, authentic refusal and V01-V03;
- actual four-family readback of 58 physical rows (9 program, 10 author-effect,
  22 selection, 17 C1), owner-planned refs/digests/receipts/members/heads;
- exact replay with no changed original row/time, four response-loss/unresolved
  paths and rejected program/selection fixture substitutions;
- real normal child/FD probe with four artificial parent sentinels and an
  inheritable FD, no normal leak, bounded launch flags/session;
- selected P/N/R/W/B source-copy controls, with the named planner-prefix survivor;
- all 29 tracked semantic diffs inspected; current/source/public/migration limits;
- exact cleanup and closing candidate/index/cache identity for that interval.

Do NOT again call full-suite execution, used-family readback or the 29-diff review
'unperformed'. However, none of these passes grants acceptance while the four
named permanent-test gaps remain. No current production defect was established
by those regressions.

Specific omission: the standalone 'skip process reap/group cleanup' negative
copy was not run. Nearby real cleanup and R08 evidence does not automatically
cover it. It remains a named independent acceptance obligation after this repair;
this mandate does not open the supervisor/source or add an unrequested fifth
repair. Also, the four survivors were not each run against the entire suite:
report their survival only for the identified selections.

An independent next audit must authenticate the repaired subject, close these
four exact gaps, examine affected compositions and finish that remaining selected
copy and acceptance gates. Implementation-validation results cannot be relabeled
as that audit's experiments.

## 11. Final validation in external clones only

No live-checkout repository imports, pytest, child processes, compiler, SQLite
or product/operator state access. Executable work occurs in task-owned local-only
external clones/copies of exact HEAD plus the 46 verified endpoints. Remove clone
remotes before execution. Installed dependencies only; no network.

Keep the opening helper/record until final comparisons. Use mode-0700 external
roots, test-process umask 022, owned TMPDIR, disabled bytecode and pytest cache,
precreated distinct collection/run basetemp parents, serial groups and no xdist.
Preserve source modes; do not copy the 37 live opaque cache files into the normal
clone or count them among the 263 endpoints.

After the LAST edit rebuild one fresh NORMAL final clone, not a reused mutated
copy. Verify all 263 endpoints before/after. Run collect then execute every group:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-root> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Tokens below expand to tests/test_<token>.py; sort/deduplicate ONLY within each
group. Group 12 uses NO selector and includes all 124 test modules.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Compute inventory hashes with, for each sorted repo-relative module path:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

Exact OPENING V8 inventories and independently reported normal-run references:

| Group | Files | Opening collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 112 / 112 | `78c117f24c7f9ec9e17434806e41ad900e6afd5e89d96e0f4358aa76d18b152d` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,984 / 8,984 | `c6eba3d75348c16265280ea07a0520fa4bb36d39ffc5f2f7b5498fe0cd98f274` |

Only the FIVE ceiling test files may change. Consequently:

- Groups 1, 8, 9 and 12 need new measured inventories and collected/run counts.
- Groups 2-7, 10 and 11 retain EXACT test-file bytes/memberships/hashes and their
  listed regression expectations. Their runtime dependencies still see the full
  final candidate; rerun, do not credit old results as this run.
- No new module, removed node, count-driven skip/xfail or changed selector.
  Additions/parameterization may change counts; strengthen old tests in place.

Bookkeeping only, if the unchanged collections retain their meanings:

```text
final full count = 8,984
    + (final G1 count - 112)
    + (final G8 count - 60)
    + (final G9 count - 289)

G2/G3 overlap = 46
G7/G11 overlap = 31
G1-G11 union = 3,657 + the three deltas above,
              if those remain the only overlaps
```

Record full unique node IDs including parameter text with spaces. Every G1-G11
node belongs to G12. Measure actual intersections, not only count arithmetic.
Inventory equality is not execution and passing groups do not sum to distinct
coverage. Do not alter expected hashes to make a mismatching inventory pass.

The existing three Python 3.13 multithreaded-fork DeprecationWarnings occur in
Groups 10 and 12 at:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warnings. Overlap repetition is not a new warning class.
Investigate and report new warnings, failed/unsupported required POSIX cases,
interruptions and external-driver corrections; no suppression or inherited pass.
An identified external harness error may be corrected only outside the live
checkout and all affected gates rerun on unchanged final candidate bytes.

Also require:

- live diff --check using the helper;
- all 17 addition no-index whitespace checks (ordinary difference status 1 is
  not a whitespace failure without diagnostics);
- full 46-path encoding/type/mode/size/hash receipts and all baseline blobs;
- other 41 candidate endpoints unchanged, 217 noncandidate paths HEAD-exact;
- unchanged nine D1 source modules, two fake child entries, sole subprocess owner;
- unchanged source/public exports/scripts/StateStore/schema/migrations 0001-0004;
- migration 0005 absent;
- unchanged document hashes, registry values, owner roles and literal protected
  identities, including P11/P12 and independently fixed replacement expectations;
- all 263 final clone endpoints exact and no extra repository artifacts;
- opening/closing live index content AND recorded metadata;
- cache DIRECTORY plus all 37 member metadata/hash equality including mtime_ns.

Use lstat for external artifact scans; hash only regular files; do not follow
symlinks or open FIFOs/sockets/devices. Clean after all owned processes terminate.
Track exact alias paths, extra mutant workers, returned runs and all roots in
finally. Do not delete another invocation's injected original run or sweep by
process name. Distinguish runtime cleanup from test emergency cleanup.

Run final live comparisons using the SAME helper/opening record, then remove
only the positively identified external roots/helper. No index/cache/source
metadata normalization or historical reconstruction is authorized.

## 12. Final receipts, retained work, verdict and next boundary

Preserve retained work on every stop. Do not reset/recreate the whole candidate
or restore index timestamps. Final baseline HEAD/tree/parent/branch/index remains
unchanged, with 29 M / 17 C and at most these five test endpoints changed from
this repair's authenticated opening.

Recompute all 46 endpoint receipts and the SAME full replacement stream twice.
Provide the five before/after rows, including unchanged targets if no edit was
necessary; prove the other 41 exact. Include full sizes, SHA-256, baseline blob
or absence, OS/Git mode and component length. No abbreviated hashes.

```text
final replacement bytes = 4,538,355
    + sum(final_bytes(path) - opening_bytes(path) for the five allowed paths)
```

Report actual final row/prefix/total length and measured hash; do not invent an
expected final hash or new manifest format. A complete five-row transition plus
unambiguous 41-row preservation is sufficient for the inline closeout.

Return:

1. Verdict, visible settings, actual first-action/opening order and baseline.
2. Narrow source/test dependency findings and exact five-file change accounting.
3. E01 actual parent-path/child-env observations, test independence, original and
   final mutant survival/failure, preserved direct supervisor and L controls.
4. S01 valid process/invalid later-prefix specimen, masking checks and positive
   earlier-failure/later-success controls.
5. H01 actual outside hard link, exact path-set/valid edit, isolated rejection,
   combined omission result and owned alias cleanup.
6. G01 literal/second-assignment checks, unchanged identities and separate primary/
   independent enforcement, source variants, parser/collection/semantic results.
7. Complete finite-copy hashes/deltas/named nodes, outcomes, evidence classes and
   overlaps. No full-suite mutant survival claim unless actually executed.
8. All twelve final commands, memberships, inventory hashes, node counts and
   intersections, warnings, failed trials/corrections/omissions and clone equality.
9. Final five-row transitions, 41/217 preservation and full replacement identity.
10. Process/root/index/cache cleanup/preservation, prior independent evidence and
    the specifically still-unperformed skip-reap/group-cleanup negative copy.
11. Continuation capsule <=1,000 words. No publication or next-task prompt.

For baseline drift, unproved opening/preservation, unavailable exact bytes,
unfinished required validation or unsafe cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V9_BLOCKED`

For an actual production/authority contradiction or indispensable dependency
outside these five files:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V9_REPLAN_REQUIRED`

That is a bounded review stop, not new architecture permission. Name the exact
path and conflict; keep work intact. Do not ask the user to select ordinary
implementation details or accept weaker source semantics to finish this task.

Success requires all FOUR test-evidence gaps closed by discriminating permanent
controls, real negative and positive behavior preserved, no production/docs or
permission changes, all final validation passed, exact preservation and cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V9_VALIDATED_READY_FOR_REAUDIT`

Success supports ONLY an independent read-only acceptance audit of the new exact
candidate. It grants no staging, commit/publication, D2/physical C2/migration
0005, provider/supplier/live authority/enrollment/deployment, Git effect,
ES/Bridge or RW0-E. Implementation validation is not independent acceptance.
