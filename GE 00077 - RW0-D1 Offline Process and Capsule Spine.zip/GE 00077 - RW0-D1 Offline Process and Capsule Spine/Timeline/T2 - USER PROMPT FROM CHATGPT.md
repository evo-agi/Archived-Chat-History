Your strategic decision is accepted:

- RW0-D comes before RW0-C2 physical implementation.
- RW0-D should directly reduce my routine message-relay burden.
- RW0-C2 follows after the offline evidence shapes have been exercised.
- No further standalone semantic-contract tranche should precede source work.

Revise the implementation plan before issuing any Codex implementation prompt.

The currently proposed single end-to-end RW0-D tranche is too broad. It combines
multiple new runtime owners and failure domains: planning, Coordinator
selection, process supervision, worker execution, workspace custody, capsule
construction, validation, independent review, model review, typed handback,
cancellation, timeout, and cleanup.

Treat RW0-D as one implementation program with two implementation-bearing
tranches.

## RW0-D1 — offline process and capsule spine

Observable result:

existing bounded program/WorkSpec input
→ process-separated fake planner
→ current Coordinator pre-execution selection
→ process-separated fake coding worker
→ bounded workspace mutation
→ candidate capture
→ immutable capsule construction
→ typed offline handback

D1 must implement and demonstrate:

- one private offline entry invocation;
- a deterministic fake planner process;
- reuse of the current Coordinator program and Section 41 selection path in a
  disposable database;
- a process-separated fake worker/Codex executable;
- bounded supervisor lifecycle, stdout/stderr, timeout, cancellation, reap, and
  cleanup;
- one real bounded candidate mutation in an isolated temporary workspace;
- independent capsule reconstruction and verification;
- no child process access to Coordinator SQLite, database path, writer proof,
  or WriterSession authority;
- no user relay between planning, selection, worker execution, candidate
  capture, and capsule handback.

Do not make use of the existing durable program/selection path merely “where
practical.” It is the required authority path. If it cannot be composed without
creating a second authoritative in-memory or harness-owned program lifecycle,
stop and replan.

The initial input must reuse an accepted private program/WorkSpec or bounded
fixture projection. Do not invent a new public intent API, generic task grammar,
service, CLI, or natural-language product contract in D1.

## RW0-D2 — offline evidence and cognitive-review closure

Observable result:

D1 capsule
→ process-separated validator
→ process-separated independent reviewer
→ process-separated fake review model
→ typed post-execution proposal
→ C2-compatible final handback

D2 must implement and demonstrate:

- validator and independent reviewer as distinct evidence sources;
- fake semantic-review-model invocation;
- typed success, repair, replan, reject, block, cancellation, timeout, and
  malformed-result treatment where applicable;
- no user relay between capsule, validation, review, model review, and final
  handback;
- final evidence and proposal values projectable into the frozen RW0-C2 input
  vocabulary without semantic translation;
- no durable C2 decision, acceptance fact, terminal outcome, migration 0005,
  Git effect, publication effect, or live authority claim.

D1 and D2 are source-bearing implementation tranches. Do not insert another
standalone value, protocol, or target-contract tranche between them unless an
implementation attempt exposes one concrete authority contradiction that
cannot safely be resolved inside the owning tranche.

RW0-C2 physical implementation follows D2.

Do not run D1/D2 and C2 as concurrent implementation programs while I remain
the manual handoff layer.

Now return:

1. the revised D1 and D2 capability boundaries;
2. their exact observable results and nonclaims;
3. the existing modules and contracts each consumes;
4. the state/authority ownership model, explicitly ruling out shadow program
   truth;
5. the dependency and audit order;
6. evidence that would force replanning;
7. one complete, bounded, read-only Codex implementation-map prompt for D1.

The Codex mapping pass must be implementation-oriented:

- inspect exact source placement, packaging, process utilities, private APIs,
  tests, and current persistence entry points;
- identify the minimum touched surfaces and implementation sequence;
- identify concrete conflicts;
- issue no architecture package or freeze manifest;
- create no repository mutation;
- return its operative findings inline.

Do not issue the D1 mutation prompt until that map has been reviewed.
Do not ask me to choose files, process APIs, workspace layout, test commands, or
ordinary implementation boundaries.
