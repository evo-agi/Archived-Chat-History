## Disposition

**Accept the audit block. Preserve the V8 production implementation and repair the four permanent-test gaps together, within five existing test files. Do not stage, commit, or begin D2.**

This audit established more than the previous attempts: it completed all twelve normal validation groups, independently compared the four used durable families, and reproduced the earlier launch-order and capsule-verification protections. Nevertheless, four named regressions survived the tests intended to detect them. Passing **8,984 tests** does not close those demonstrated gaps. Pasted text Pasted text

The severity distinction must remain precise. The **High finding is an acceptance-evidence gap concerning a child database-path regression**. The unmodified candidate did not leak that path. The other three findings likewise concern missing regression protection, not newly observed failures in the retained production behavior. Their survival was demonstrated against identified test selections—not against the entire transformed 8,984-test suite. Pasted text Pasted text Pasted text

No production rewrite, registry expansion, or standalone semantic tranche is indicated.

## 1. Test the real invocation’s child inputs

The direct supervisor test and the integration test establish different things. The former exercises its own isolated supervisor invocation. It cannot establish that the **actual runner** passes only permitted inputs when composing that supervisor with disposable SQLite state.

The auditor demonstrated the distinction: a two-file copy propagated the actual parent database path into both real child environments, yet the direct isolation test and normal integration test passed. The existing V8 observer saw the launches but did not assert their environment boundary. Pasted text

**Extend the existing integration observer; do not introduce another supervisor or launch gate.**

For every actual launch during the invocation, it should retain a test-local snapshot of the real `Popen` arguments and environment, then call through unchanged. The permanent assertion must compare those inputs with the independently known parent database/state location and the fixed permitted child environment.

That means checking the actual seven-key environment and its values—not deriving the expected key set from the supervisor’s own builder. A permitted key must not become a slot carrying the database path. The assertion must also distinguish the Coordinator state root from the outer test directory that legitimately contains planner and worker-workspace siblings.

The observer must not remove the leaked key, reject the launch before it occurs, or infer isolation from the path-free handback. The external regression must still create both real children, and the strengthened integration test must then fail on the actual input violation.

The existing direct child/descriptor test remains unchanged and useful. It simply no longer substitutes for this missing composition check.

## 2. Isolate the planner-success prerequisite

The handback already rejects a later-stage history whose earlier planner was unsuccessful. Its tests failed to protect that specific predicate: deleting the later-prefix `clean_success` check left the owning module green. Pasted text

The new permanent specimen must distinguish:

```text
an internally valid failed-planner observation
```

from:

```text
a valid prerequisite for later selection, phase establishment, and worker start
```

Use a valid `worker_start` handback with its correct failed-launch observation, prior durable values, and cleanup state. Substitute only an **individually valid but unsuccessful planner record**. Its process-value validator should accept the record; the handback should reject the later-stage history.

That avoids masking the missing predicate with an invalid process record, wrong prefix, missing C1 value, or unrelated capture error.

The positive controls must preserve both a legitimate `worker_start` with a clean earlier planner and a legitimate earlier planner-failure handback containing that kind of unsuccessful process evidence. This is a test of an existing prerequisite—not permission to reject all negative outcomes or add another stage ledger.

## 3. Make the hard-link specimen independent of the extra-path guard

The current hard-link specimen also creates an extra path inside the workspace. It therefore proves that *something* rejects the workspace, but not that the link-count checks do. The audit’s outside-link specimen exposed that masking. Pasted text

**Add a real hard link outside the workspace but inside the test-owned root.**

The workspace must retain exactly its three authorized paths, accepted modes and byte limits, and one legitimate content edit. Link one of its other unchanged files to an owned sibling location outside the workspace. At validation time, the workspace path set is still valid, but the linked inode has more than one link.

The current owner must reject that specimen through the hard-link boundary. Removing both link-count checks in an external copy must make the permanent test fail because the workspace is wrongly admitted.

The identical workspace without the outside alias must pass. The existing extra-path/hard-link composition test can remain; it cannot provide the new discrimination.

This does not commission filesystem race testing, a sandbox, or new workspace semantics. It tests the already-required link invariant without allowing a different guard to reject first.

## 4. Protect the literal table against subsequent dynamic replacement

The Low finding is not solved by finding a literal table somewhere in the module. The transformed module retained that literal definition and later replaced the table with values derived from current document bytes. Those values happened to match, so ordinary identity comparisons remained green. Pasted text

The correction must enforce:

```text
one approved literal definition
AND no subsequent dynamic rebinding of that protected table
```

Both the Capability owning test and the independently fixed bootstrap source checker belong in this repair. The baseline bootstrap checker selects the first matching `PROTECTED_CONTENT_ROWS` assignment at `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:803–809`; the live retained implementation must be inspected before editing.

The new checks should reject the demonstrated second assignment even when it computes exactly the current approved identities. They must preserve all literal hashes, row IDs, paths, purposes, ownership classes, historical identities, and semantic markers.

**Hashing observed document bytes remains legitimate. Deriving expected identities from those same bytes does not.** Do not prohibit `read_bytes` or `hashlib` broadly, rehash `AGENTS.md`/`README.md`, or replace the independent checker with the primary helper’s answer.

This is a finite definition/rebinding rule for the named table—not a general Python reflection analyzer or a claim that mutable tests authenticate arbitrary coordinated changes to themselves.

## Exact repair boundary

Only these five existing candidate files may change:

```text
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_workspace_capsule.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
```

The other **41 candidate endpoints** remain byte-identical. All **217 noncandidate tracked files** remain HEAD-exact.

Every production module, document, schema, migration, public export, B1/Wire permission, and protected document identity remains unchanged. The repair should retain the existing tests and strengthen their discrimination—not remove cases or relax source behavior.

The handoff requires reproducing all four named gaps and checking the repaired boundaries **before** the expensive final suite. They are one coordinated test repair, not four additional programs or user handoffs.

## Preserve the completed independent evidence

The latest audit’s completed work should not again be described as unperformed.

It independently matched **all 58 physical rows** in the four used families—9 program, 10 author-effect, 22 Section 41, and 17 C1—against the owners’ planned values, including references, digests, receipts, members, and heads. Replay preserved those rows and original timestamps. It also inspected all 29 tracked semantic diffs and completed all twelve validation groups. Pasted text Pasted text

The V8 launch controls, V7 verifier controls, and selected B1/Wire, process, capture, custody, and cleanup checks also produced useful independent evidence. Those results remain applicable prior observations on the authenticated V8 bytes, not a blanket acceptance verdict. Pasted text

One specific omission remains: **the “skip process reap/group cleanup” negative copy was not run**. Neighboring real cleanup and R08 checks do not automatically satisfy it. It remains a named obligation for the subsequent independent acceptance audit; this repair does not silently open the supervisor for a fifth issue. Pasted text

## Validation treatment

The five edited tests affect Groups **1, 8, 9, and 12**. Those inventories and counts must be recomputed. Groups **2–7, 10, and 11** retain their exact test-file inventories and must still be rerun against the final candidate.

The bookkeeping check is:

```text
final full count =
    8,984
    + (final D1 count − 112)
    + (final Capability count − 60)
    + (final bootstrap-guard count − 289)
```

That is not a target to manufacture through selectors, removals, or skipped tests.

All twelve implementation-validation groups must run after the last edit. Their success will support independent re-audit, not replace it.

## Complete repair handoff

Resume the **implementation Codex conversation**, preserving the retained checkout.

:chatgpt-content-reference{index="14"}[Download the complete RW0-D1 audit-repair prompt V9](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V9_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V9_Prompt.txt

Bytes:
66,346

SHA-256:
b62f4707bc5020e250c22fbc2aa629aff0942c988c5e85469e64dd5e74f15b60

Lines:
1,011

Final newline:
present
```

It binds the exact retained opening:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,538,355 bytes
173adda1a4d1cab3a0056a5156339e1fd1f059533a4f11e915894ddb21ea0ce0
```

The audit has now supplied and authenticated the integration test’s **complete** endpoint hash:

```text
47,176 bytes
0f38baa211673feef6a0e499f28ffc2a7256439b39a9b1b9cf10800b4518b4b3
```

The new handoff therefore contains 46 full endpoint receipts, with no abbreviated or measurement-placeholder row. Pasted text

It includes the existing pre-Git mechanism, five-file ceiling, four causal repairs, precise validation memberships, preservation requirements, and retained-work rules. No historical attachment is required.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V9_VALIDATED_READY_FOR_REAUDIT
```

It supports only an **independent read-only acceptance audit**. It authorizes no staging, publication, D2, physical C2, migration `0005`, live authority/provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the new audit, reviewed the relevant mandate and baseline guard dependencies, corroborated all 29 baseline blob identities and the 17 additions’ absence against the mounted snapshot, and checked the replacement arithmetic and all twelve inventory hashes using baseline bytes plus supplied candidate hashes. I reopened the generated prompt and syntax-checked its embedded opening/helper code without executing it.

I did **not** inspect the live D1 source, reproduce the four mutants, or run repository tests. Those observations remain attributed to the independent auditor.

Some older uploads have expired. Re-upload a specific historical original when a later comparison needs its bytes; none is required for this repair.

**Sources:** Latest independent audit, cited above; issued V8 restart/acceptance mandate; October 15 Coordinator snapshot, particularly the Capability protected-row test and bootstrap source checker.

**Confidence:** High on the five-file, test-only repair boundary and preserving the production candidate. The repaired tests’ causal adequacy and final independent acceptance remain unresolved.
