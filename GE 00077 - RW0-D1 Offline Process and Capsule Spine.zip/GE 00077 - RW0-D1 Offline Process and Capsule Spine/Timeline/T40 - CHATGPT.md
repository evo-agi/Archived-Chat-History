## Disposition

**Accept the audit block. Preserve the retained V7 runtime and strengthen the permanent integration tests in one file. Do not stage, commit, or begin D2.**

The retained runner’s observed order was correct. The defect is that an additional, unreported worker could be inserted before C1 without either of the two tests intended to protect that boundary failing. This is a **Medium test-causality gap**, not a demonstrated pre-C1 launch in the retained implementation. Pasted text

No production change, registry amendment, or architecture replan is indicated.

## The missing distinction: reported evidence versus actual effects

The mutant exposed why checking the final handback is insufficient:

```text
planner
→ unreported worker
→ C1 commits, but its response is lost
→ recovery returns unresolved
→ handback contains no worker observation
```

The final handback can correctly describe the permitted evidence prefix while failing to reveal an earlier forbidden effect. The audit observed the real extra worker PID, yet both unchanged permanent tests passed. Pasted text

**“No worker in the handback” must not stand in for “no worker was launched.”**

The repair must observe all process-creation attempts during the invocation, including early, duplicate, ignored, and unreported workers. Observing only the supervisor result assigned to `worker_process`, or only the last worker launch, would preserve the same hole.

## Selected one-file repair

Only this existing candidate file may change:

```text
tests/test_rw0_d1_offline_integration.py
```

The other **45 candidate endpoints** remain byte-identical, including every production module, document, registry, and governance guard. All **217 noncandidate tracked files** remain HEAD-exact.

### Observe the actual launch boundary

Add a small, test-local, call-through observer at the actual `Popen` lookup used by the existing D1 supervisor. It must be installed before the private invocation and remain active through its recovery, stop, and return paths.

It should record each launch attempt, the actual command’s planner/worker identity, and the resulting real process handle/PID—or genuine start failure. It must not derive its inventory from the returned handback.

The observer is **not a new launch gate**. It must delegate to the real process implementation rather than prevent the mutant’s early launch with a test assertion. The permanent assertion then evaluates what actually occurred, with cleanup guaranteed even when that assertion fails.

This remains bounded instrumentation for the fixed proof children, not a new runtime ledger or a claim to monitor every possible native process-creation mechanism.

### Strengthen both named tests

The repair keeps and strengthens:

```text
test_full_d1_through_guarded_writers_and_parent_capsule

test_unresolved_phase_recovery_retains_only_prior_prefix
```

For the successful invocation, the test must establish **exactly one planner and one worker**, with every worker attempt occurring after the caller receives a valid C1 result—or `committed_exact` recovery—and after the relevant writer closes.

Both count and order matter. A correct final worker cannot excuse an earlier extra worker; conversely, a two-child total cannot excuse moving the sole worker before C1.

For unresolved C1 recovery, the test must establish **zero worker attempts and zero worker PIDs throughout the invocation**, not merely an empty worker field at return.

The recovery distinction must remain explicit:

```text
The underlying write physically committed.
```

is not equivalent to:

```text
The runner received a confirmed result or committed_exact recovery.
```

A test must not mark C1 resolved at method entry, from row presence alone, or from a successful internal result subsequently replaced by the fault injector’s `unresolved` response.

### Reuse the observer across the existing recovery cases

The same small observer should strengthen the existing four-site cases rather than create another recovery framework:

| Scenario | Expected actual children |
|---|---|
| Ordinary success | One planner, then one worker after C1 resolution and writer close |
| Committed response loss recovered as `committed_exact` | One planner and one worker; no duplicate delivery |
| Program or author-effect recovery unresolved | No children |
| Section 41 or C1 recovery unresolved | One planner; no worker |

A positive C1 response-loss/recovery case must still work. The repair must not “solve” the negative case by preventing all worker execution after any response loss.

These are tests of the existing operating contract. They add no production latch, permission token, phase marker, handback field, or second program-state owner.

## Three bounded causal controls

The handoff requires three external-only defect classes:

| Mutation | Required discrimination |
|---|---|
| **L01:** Add an unreported worker before C1, preserving the normal later launch | Both named tests detect the extra/early effect despite plausible handbacks |
| **L02:** Move the sole worker before C1 while preserving the two-child total | The success test detects ordering, independently of total count |
| **L03:** Launch on the C1 response-loss path after physical commit but before effective unresolved recovery | The unresolved test detects the worker; physical commit cannot substitute for resolved admission |

Each copy must parse, import, and collect normally, and fail at the intended permanent assertion. An unrelated frame, capsule, source-inventory, or syntax failure receives no causal credit.

The report’s exact mutation bytes were not supplied. Codex must construct equivalent, source-grounded specimens and label them accordingly—not claim to replay the auditor’s original bytes or PIDs.

Every actual child must remain accounted for during cleanup, including a worker absent from the handback. The new observer’s process handles make that possible without process-name sweeps.

## Preserve the substantial progress from this audit

This audit completed work that earlier reports had left open. **The next handoff must not describe it as though it never happened.**

The auditor reports complete reconstruction and comparison of the four used durable families:

| Family | Independently reported readback |
|---|---|
| Program | 9 rows / 8 graph entries |
| Author effect | 10 rows / 9 graph entries |
| Section 41 | 22 rows / 14 evidence bindings |
| C1 | 17 rows / 14 operands |

The owners returned `committed_exact`; replay added no family rows or changed original times. Response-loss checks passed at all four sites, and direct unresolved faults stopped at the expected boundaries in the **retained** runner. Pasted text

The audit also completed the V7 verifier-call/refusal controls, selected B1/Wire checks, and all **29 tracked semantic diffs**. Its child-channel observations support the stated fixed-child launch configuration and absence of the tested sentinels from arguments, environment, and working directory—not an adversarial same-user sandbox claim. Pasted text

Its final validation reached:

```text
Groups 1–10:
collected and passed at the supplied counts and inventory hashes

Group 11:
679 collected; execution deliberately interrupted after 233 passes

Group 12:
not collected or run
```

No Group 11 failure was reported. The interruption and missing Group 12 still prevent a completed final-suite claim. The remaining finite mutation campaign likewise remains unperformed, rather than being supplied by the completed direct checks. Pasted text

The opening mechanism and preservation interval also passed. No procedural restart or index correction is needed for this finding. The repair will establish its own fresh opening using the same mechanism. Pasted text

## Validation treatment

Only the integration-test file may change, so Groups **2–11 retain their exact test-file inventories**. Groups **1 and 12** require recomputed inventories and actual execution from the final repaired bytes.

The count reconciliation remains:

```text
final full count = 8,872 + final D1 Group 1 count
```

Strengthening existing assertions may leave the count unchanged; additional bounded cases may increase it. Neither outcome justifies removing tests or changing selectors to manufacture a target count.

All twelve implementation-validation groups must run after the last edit. Their success would support a new independent audit, not replace it.

## Complete repair handoff

Resume the **implementation Codex conversation**, preserving the retained checkout.

:chatgpt-content-reference{index="7"}[Download the complete RW0-D1 audit-repair prompt V8](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V8_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V8_Prompt.txt

Bytes:
61,116

SHA-256:
800bba75fc4dcf06e2e528ce4c7be910e4be13431d5e8579a8b2d9319f955984

Lines:
954

Final newline:
present
```

It binds the unchanged retained opening:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,524,315 bytes
b0d6c1192120ea0482617d2eb6ed7bfe779f6664a14de694b0a23949a5200a99
```

The sole repair endpoint opens at:

```text
tests/test_rw0_d1_offline_integration.py

33,136 bytes
a4abd7236764b74c758bfbc133b4a1ecedef410801a0c39ce7a89ed0b1e85e4b
```

The prompt includes the complete 46-path table, successful pre-Git mechanism, one-file ceiling, actual-launch observation requirements, recovery distinctions, three causal controls, all twelve validation memberships, and retained-work rules. It requires no historical attachment.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V8_VALIDATED_READY_FOR_REAUDIT
```

It supports only an **independent read-only acceptance audit**. It authorizes no staging, publication, D2, physical C2, migration `0005`, live authority/provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the latest audit and its complete operative mandate. I corroborated all 29 baseline blob identities and the 17 additions’ absence against the mounted snapshot, checked the replacement arithmetic and all twelve inventory hashes using baseline bytes plus supplied candidate hashes, and reopened the generated prompt. Its embedded opening/helper code was syntax-checked, not executed against your Mac.

I did **not** inspect the live D1 source, reproduce the speculative-worker mutation, or run repository tests. Those observations remain attributed to the independent auditor.

Some earlier uploads have expired. Re-upload a specific original when a later comparison requires its bytes; the current report and operative mandate were available.

**Sources:** Latest independent audit, cited above; issued V7 acceptance mandate, including its pre-existing worker-before-C1 and unresolved-recovery safeguards; October 15 Coordinator snapshot for baseline corroboration. Coordinator_RW0_D1_Offline_Proc…

**Confidence:** High on the test-only repair boundary and preserving the runtime. The repaired tests’ causal adequacy and complete independent acceptance remain unproved.
