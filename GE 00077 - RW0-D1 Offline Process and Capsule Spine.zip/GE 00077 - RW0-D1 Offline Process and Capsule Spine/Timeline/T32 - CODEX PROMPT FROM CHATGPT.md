# Governed Execution Coordinator — RW0-D1 Repaired V6: Independent Read-Only Acceptance Audit

## Mandate and acceptance boundary

Independently audit the exact RETAINED, uncommitted 46-path D1 candidate below.
This is ONE parent-only READ-ONLY acceptance task, not repair, a new design
program, publication, or permission to begin D2. Preserve the selected sequence:
D1 process/capsule spine -> D2 evidence/cognitive-review closure -> physical C2.

Reported latest repair closeout:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V6_VALIDATED_READY_FOR_REAUDIT`

V6 changed ONLY tests/test_rw0_b1_boundaries.py. All nine D1 source modules, all
seven D1 test modules, all documents and the other consumer/governance guards are
reported byte-identical to V5. The repair targets one LOW-severity but required
B1 consumer-guard defect: acquiring builtins.__import__ through a callable alias
or a builtins module alias escaped the helper and its owning permanent test.
There was no observed dynamic loader in retained production and no demonstrated
executable-permission or durable-authority bypass. Do not inflate this finding.

V6 reports syntax-level loader-acquisition rejection, nine new negative cases,
one harmless-text positive control, two complete-module/owning-test reproductions,
and two final-byte guard-regression copies. All twelve implementation validation
groups reportedly passed, including 8,980 repository tests. Verify those claims;
implementation validation is not independent acceptance.

The preceding independent V5 audit reproduced the complete prior candidate and
passed 108 D1 tests plus 32 selected B1/Wire tests. It independently observed:
process constructor/consumer consistency and legitimate negative outcomes;
actual-return rejection with safe resource custody; guarded program/author/
Section 41/C1 call-through ordering; current Wire exit input; and committed
response-loss plus unresolved-recovery stops at all four durable sites. Preserve
that as LABELED prior evidence. It does not prove complete row-by-row identity/
digest readback, all 29 tracked diffs, complete independent FD/process/workspace
campaigns, the finite P/N/R/consumer mutations, or final Groups 2–12; those were
explicitly unperformed. An independent fresh Group 1 and complete final Groups
1–12 are required here before acceptance, not inherited from either report.

That audit also ran its first git status before AGENTS.md and without optional-
lock suppression. It could prove later index content but not original index
metadata. V6 records complete opening/closing index metadata for its own run.
Neither later record repairs the earlier missing history. Follow the precise
fresh opening procedure below; do not reset the index or reconstruct old proof.

Critical path:

exact identity and read-only opening -> close B1 alias guard first -> complete
remaining bounded D1 acceptance obligations and reconfirm affected compositions
-> fresh final twelve-group validation -> preservation/cleanup -> inline verdict.

Do not commission another reconnaissance or semantic tranche. Do not expand the
finite import tests into arbitrary reflection, eval/exec or a universal Python
security analysis. No new public task grammar, provider/supplier mechanism,
D2 capability, physical C2 implementation, or hostile-same-UID sandbox proof is
an acceptance requirement for this selected artificial offline slice.

Use the highest exposed reasoning setting. Record visible model, effort and
permission posture or `not visible`; do not infer hidden settings or seek extra
account/computer access. No subagents, real model/provider calls, repository
network contact or sibling-repository access. Only fixed fake children and
bounded external audit/test probes are permitted.

Return operative findings INLINE with exact repo-relative path:line references,
a completed/unperformed evidence matrix, and a continuation capsule <=1,000
words. No delivered report, patch, ZIP, snapshot, architecture package, freeze
manifest or receipt attachment. This prompt includes all final endpoints and
validation memberships; no historical attachment or another prompt is needed.

## 1. Exact baseline and read-only opening

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`, locally `0 ahead / 0 behind`
- exactly one worktree
- index equal to HEAD; zero staged or unmerged paths
- exactly 29 tracked modifications plus 17 untracked creations below
- no active Git operation, sequencer, or unexpected lock.

Before ANY Git command, including status:

1. Read live AGENTS.md as TEXT first, and follow applicable instructions.
2. Establish GIT_OPTIONAL_LOCKS=0 and GIT_NO_LAZY_FETCH=1 in every live Git
   inspection subprocess. Do not modify Git configuration. Suppress interactive
   prompts and external diff/textconv; missing local objects are a stop, not
   fetch permission.
3. Resolve .git/index using only filesystem data. If .git is a pointer file,
   read its gitdir target and locate the per-worktree index without first invoking
   Git. Do not scan unrelated credentials or secret Git material. Capture index
   lstat type, device/inode, mode, UID/GID, size, st_mtime_ns and SHA-256 before
   the first Git command. Atime is not an equality gate. Record unsupported
   metadata explicitly rather than fabricate it.
4. Capture the known live cache DIRECTORY and its 37 regular members as described
   below before executable repository work. Preserve actual modes and metadata.

Then inspect baseline, index CONTENT and status with the above environment.
Do not fetch, refresh/update the index, normalize, reset, clean, stage, switch
branches or change configuration. Local tracking equality is not remote truth.

Require closing index content AND recorded metadata to equal this true opening.
V6 reported index SHA-256 709d48a8d9229dab4de8c58be5630c044135843aba8b8e9d2886f92b74b401a4;
that is historical corroboration, not permission to substitute a receipt for
fresh pre-command observation. If the opening order is missed or metadata drifts,
report the actual procedure limit and BLOCK acceptance; do not silently rebaseline,
restore metadata, infer damage, or retry history. Preserve retained work.
On baseline, candidate path-set, type, mode, endpoint, baseline-blob, or aggregate
identity mismatch, preserve actual state and return AUDIT_PROVENANCE_MISMATCH
before correctness acceptance. Do not replace expected coordinates or recreate
source from hashes.

## 2. Complete final 46-path identity

M is a tracked modification. C is an untracked creation, not a commit/copy
status. All candidate files are regular, nonsymlink and represented by Git mode
100644. Record and preserve actual OS modes; the V6 repair path reports
0644. Do not normalize unrelated nonexecuting 0600 files. Verify strict UTF-8,
no BOM or CR, one final LF and no trailing whitespace.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 25,215 | `dde79042a7640571493f882b5130b8650c7a52ebd2fc28a6956799a261fa6d4c` | `absent` | 25,286 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 23,432 | `e5250a4921d1d441716fa356c742dbc886a0d13f7386c90e8409094c733f2109` | `absent` | 23,507 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read the 29 modified paths' baseline blobs directly from HEAD; verify the 17
created paths are absent from HEAD and index. All 217 noncandidate tracked
paths must be HEAD-exact in content/type/Git-relevant mode. Baseline 246 plus
17 creations = 263 repository file endpoints. No extra file, rename, deletion,
submodule, symlink, executable-bit change, public export, or migration 0005.

Existing production source, private semantic values, current durable writers,
readers, migrations 0001-0004, `__init__.py`, `pyproject.toml`, `.gitignore`,
`state_store.py`, and package/script inventories must remain HEAD-exact. The
nine D1 modules are exactly the nine `_rw0_d1_*.py` source paths in the table.
No D2/E, terminal, provider, or durable-C2-runtime module may be introduced.

### Exact endpoint replacement identity

Reconstruct twice using independent fresh file reads, without importing
candidate code. A concatenating calculation and a streaming calculation are
suitable. Use the established recipe, not an additional manifest:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte
prefix length = 25 bytes, not the literal backslash-zero characters
for each table row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw bytes of HEAD blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact final file payload
```

Required final identity:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,514,586
prefix bytes: 25
total bytes: 4,514,611
SHA-256: 9e1244f91b0a78350928715e3de1b9da5861e29ef92f777e032ec59d370b5fc9
```

The immediately preceding V5 candidate was 4,511,038 bytes, SHA-256
`e0221e5d67ed3091ead541c314163b49964ec298411f4c29a6d11a572434d1ed`.
The only V6 transition is:

```text
tests/test_rw0_b1_boundaries.py
payload: 47,819 -> 51,392 bytes (+3,573)
SHA-256:
  b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de
  -> 88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967
encoded component: 47,885 -> 51,458 bytes
HEAD blob unchanged: 06266f08770b3d4efa77f26aff0b1e7ecadf46f1
```

All other 45 candidate endpoints are reported unchanged. The aggregate increase
is exactly 3,573: 4,511,038 + 3,573 = 4,514,611. This and matching recorded
receipts corroborate transition arithmetic, not a direct historical diff without
historical payloads. Read the final bytes above as the audit subject; do not
recreate source from hashes or require old payloads. Every current baseline blob
must still be read from HEAD.

## 3. Execution ceiling and preservation

Live checkout: read-only Git, text, metadata, hashing only. Enforce the pre-Git
AGENTS/index procedure and optional-lock/lazy-fetch suppression from section 1. No repository
imports, processes, pytest, scripts, compilation, SQLite access, file edits,
configuration writes, network, supplier, credentials, or unrelated ignored
operator/product-state inspection.

Executable audit work is permitted in audit-owned, local-only external clones
of exact HEAD with all verified 46 candidate files overlaid and configured
remotes removed. Verify all 263 endpoints before execution and after. Use
installed dependencies only. No network or dependency installation. The only
new processes are fixed fake planner/worker and bounded test/audit probes.
No D2/C2, real Codex/provider, live authority, enrollment, deployment, ES/Bridge,
Git publication, public service, or RW0-E effects.

BEFORE any executable work, lstat the known live cache DIRECTORY
`src/ge_nwp_coordinator/__pycache__/` and all 37 regular members. Capture relative
path, type, actual mode, size, st_mtime_ns and SHA-256 of regular files. Do not
hash the directory, substitute presence for directory metadata, or reconstruct
older missing metadata retrospectively. Require complete equality at close, alongside the opening index record.
Do not import, move, regenerate, or clean this cache.

Use audit-owned mode-0700 external roots, preserve source OS modes, umask 022
for tests, TMPDIR inside the owned root, disabled bytecode/pytest cache, distinct
precreated collection/execution basetemps, and serial non-overlapping runs.

Inventory external artifacts with lstat; open/hash only regular files. Never
follow symlinks or open FIFOs/sockets/devices. Record owned PIDs/process groups
and disposable-state/workspace roots so fault injection cannot orphan them.
Clean only positively identified audit resources after owned processes end.

## 4. Inspection and evidence order

1. Authenticate final bytes and record opening index/cache preservation.
2. Inspect the one changed B1 helper and its actual named owning-test caller.
   Verify the bounded alias/acquisition correction in section 5 FIRST. A
   required guard survivor is a finding, not permission to repair it here.
3. Read all nine D1 production modules, seven D1 tests and the D1 owner. Inspect
   all 29 tracked diffs against HEAD; the one-file V6 delta does not replace the
   still-unfinished semantic review of the complete original D1 candidate.
4. Build an INLINE obligation table identifying prior observations, new direct
   confirmations, incomplete original checks and planned exact tests. Prior
   observations are not erased, but not relabeled as this run's execution.
5. Complete the already selected durable row/digest readback, four-site recovery,
   process/FD/workspace/capsule and finite P/N/R/consumer/guard obligations below.
   Reuse one real positive run and discriminating specimens where safe; map
   overlaps explicitly. No duplicate full-suite run per mutant and no growth
   into a new open-ended parser or architecture campaign.
6. Build one fresh unmodified final clone and collect/run all twelve groups.
7. Reconfirm preservation and cleanup, and return the supported disposition.

Follow the actual unchanged program initialization, author-effect, Section 41,
RW0-C1, writer/session close/recovery, worker/capsule semantic, Wire and B1 owners
where D1 consumes them. Tests, response labels, hashes and synthetic premises do
not outrank these contracts.

The latest V5 audit performed all four response-loss/unresolved call-through
recovery probes, but described them as ordering/stop evidence rather than complete
row-by-row identity/digest acceptance. Preserve that exact distinction. All other
explicit omissions remain to be completed. Reuse overlapping evidence within
THIS audit, but do not inherit implementation pass counts or report-only runtime
facts as fresh independent execution.

A reproduced material defect may justify stopping expensive remaining tests;
that yields BLOCK with a full omissions list, never ACCEPT. No candidate repair
is authorized in this task.

## 5. V6 B1 guard: close the exact dynamic-loader acquisition gap

### Owner, caller and unchanged permissions

Read tests/test_rw0_b1_boundaries.py in full, including its original protections,
independently fixed registry expectation, new acquisition check, negative cases,
positive control and named caller:

`test_private_module_has_no_package_exports_or_production_importer`

Reported V6 coordinates are helper :524, checks :629–640, caller :674, and new
cases :707–780. Re-resolve exact lines from authenticated bytes. These pointers
are report evidence, not proof of implementation.

Require the SAME helper to enforce the restriction in the existing named test.
The correct source still has exactly the admitted B1 dependency:

```text
consumer: src/ge_nwp_coordinator/_rw0_d1_handback.py
supplier: src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
symbol: RW0PhaseEntryBasisV1
field: phase_basis
```

Registry version stays 3 and both fixed projections stay unchanged. Pre-execution
constructs the basis; C1 establishes/verifies the durable phase; handback checks
and retains evidence. B1 source authentication, executable permission, durable
persistence and semantic acceptance remain none. Confirm unchanged consumers,
roles/symbols, direct relative unaliased imports and all non-D1 restrictions.
Capability R18 retains its path/mode/purpose meaning; no new full-file content pin
or runtime permission is introduced by this test-only repair.

### Independently reproduce the two demonstrated families

In separate disposable copies of the COMPLETE current handback module, preserve
its normal source and insert these representative forms at a syntactically valid
location. These are finite representative forms, not the unavailable original
auditor mutation bytes.

A. Imported loader alias:

```python
from builtins import __import__ as _b1_import_probe
_B1_PROBE_MODULE = _b1_import_probe(
    "ge_nwp_coordinator._rw0_phase_entry_semantic_values",
    fromlist=("RW0PhaseEntryBasisV1",),
)
_B1_PROBE_VALUE = _B1_PROBE_MODULE.RW0PhaseEntryBasisV1
```

B. Module alias:

```python
import builtins as _b1_builtins_probe
_B1_PROBE_MODULE = _b1_builtins_probe.__import__(
    "ge_nwp_coordinator._rw0_phase_entry_semantic_values",
    fromlist=("RW0PhaseEntryBasisV1",),
)
_B1_PROBE_VALUE = _B1_PROBE_MODULE.RW0PhaseEntryBasisV1
```

Verify each complete module parses and ACTUALLY imports in package context in a
fresh external process. Only the existing pure B1 class is loaded/retained; do
not construct a phase, write C1, start a D1 run or contact anything during this
module-level probe. Disable bytecode. Then exercise the helper directly and
collect/run the unchanged-named permanent owning test. Both must reject at:

`b1.handback.dynamic_import_acquisition`

The normal retained handback must pass. Do not credit a syntax/import/collection
error, an unrelated source-count check, Wire rejection or another global guard.
Report helper, full-module import and owning-test outcomes separately.

A historical before-repair survivor is already reported; no historical payload
is required for this audit. Do not manufacture a before-run claim from a hash.

### Check the selected finite AST rule, not arbitrary Python reflection

Require rejection of acquisition/reference before alias-call spelling matters:

- ImportFrom builtins importing __import__, aliased or unaliased;
- attribute __import__ acquisition/reference, including builtins module aliases;
- direct __import__ reference/assignment and direct call;
- straightforward assignment aliases and nested uses reached by the same
  whole-module AST traversal.

An explicit syntactic __import__ attribute prohibition in this closed handback
consumer was selected. Confirm it scans applicable nested functions/classes/
conditionals, not only top-level calls. Vary aliases in fixed specimens. Keep
existing importlib, exact-import, symbol-count, unauthorized-consumer and
re-export checks. Expected permissions must remain fixed independently of the
observed source; do not use a runtime import to determine the allowed imports.

Comments and exact string literals merely mentioning these names must not be
mistaken for acquisition. Exercise the retained legal import, evidence retention
and harmless comment/string positive control. The closeout reports nine new
negative tests and one positive; inspect their actual discrimination, not only
that count.

This audit does NOT require a general resolver for getattr with computed names,
eval/exec, arbitrary alias chains, bytecode changes, all reflection or coordinated
rewrites of every source and expectation. Stay within the selected finite
from/module/direct-reference/assignment/nested forms. Do not create a new guard
architecture or ask the owner to implement it during this read-only task.

### Causal test protection

Make two final-byte helper-regression copies with all fixed specimens unchanged:

- omit the imported-loader acquisition check;
- omit the attribute acquisition check.

Each copy must parse/import/collect. Its corresponding permanent negative case
must fail semantically (for example DID NOT RAISE), while the genuine positive
owning test still passes. If predicates overlap, explain actual discriminating
coverage; do not count another check's refusal as proof of the omitted predicate.
Check direct-reference and nested coverage with the existing fixed cases as well.
These copies discharge the applicable B01–B03 obligations below, not an extra
independent quota. Do not rerun an entire suite for each mutant.

V6 reports replacing an introspected assertion with an explicit content-free
raise after an initial reason-check mismatch. Inspect that the predicate still
runs and that its error contains only the closed reason; a stable error string
must not replace actual detection. The earlier nine focused failures were a
trial, not final passing evidence.

This is guard-coverage acceptance, not an observed malicious loader or a proof
that any production permission was bypassed. A surviving required form blocks
acceptance at its actual Low severity without redesigning the runtime.

## 6. V5 process consistency: owned validation and both consuming boundaries

### Derive the invariant from actual producer sites

Read D1ProcessOutcome, its complete field inventory, validate()/constructor/
replacement paths, the clean-success predicate, every supervisor return, and
all planner/worker consumers. The closeout reports twelve existing fields; do
not invent field names or a new public record. Build an independent compact
field/reason/producer table from the actual code and selected D1 owner before
using the production validator or test-side matrix as evidence.

Reported coordinates (re-resolve against authenticated source):

- _rw0_d1_process_supervisor.py:52 — owned pure validator;
- _rw0_d1_process_supervisor.py:262 — return-code classification;
- _rw0_d1_handback.py:145 — both process records revalidated;
- _rw0_d1_handback.py:185 — later-prefix clean-success condition;
- _rw0_d1_offline.py:441 — real worker return-code input to Wire;
- test_rw0_d1_process_supervisor.py:231 — independent field/reason matrix;
- test_rw0_d1_handback_values.py:451 — forged consumer cases;
- test_rw0_d1_offline_integration.py:42,:482 — real paths/substitutions.

These are report pointers, not verified source facts until inspected.

One existing owner must define the complete process-value invariant. Normal
construction and dataclass replacement call it. The handback must explicitly
revalidate every non-None exact planner_process AND worker_process before any
status/stage check, including broad stopped and cleanup paths. A frozen outer
record or a success label is not sufficient. The runner must not consume a
forged outcome by coercing it, clearing its error, or fabricating a replacement.

The validator/predicate is pure: no launch, signal, wait, process-existence/PGID
query, path lookup, file open, SQLite access, Wire classifier call or authority
change. It checks retained data, not whether a process historically existed.
No additional state marker, new evidence field, validation cache, wrapper,
serializer or shadow program/process ledger is authorized by this audit.

Check exact built-in types BEFORE any membership, comparison, equality,
normalization or decoding. In particular, present PID/group/exit values are
exact ints, never bool or int subclasses; reason/error flags use their exact
existing types; stdout/stderr are opaque exact bytes. Do not require pathname
scanning of outputs. No str/int/bytes conversion may erase an injected bad type.

### Reported reason/fact table is a hypothesis to verify

| Reported reason | Claimed compatible facts |
|---|---|
| invalid_input / start_failed | No PID, group, exit, output, signal, reap, group-clear or cleanup-success claim |
| ok | Started; positive exact PID/group; initial owned group equals launched PID; exact exit 0; clean success additionally proves reap, group clear and absence of cleanup error |
| nonzero_exit | Observed nonzero exact int, including signal-negative values; reported producer excludes process-control exception and supervisor TERM-delivery claim |
| output_limit / stderr_limit / deadline / cancelled | Retain actual exit/stream/signal/cleanup observations; limit reasons have corresponding stream evidence; cancellation and its request flag agree; exit may be zero or unresolved |
| cleanup_unresolved | Reportedly a process-control failure or unproved reap; known zero exit can coexist with control or selector/stream cleanup uncertainty; unreaped form cannot claim known exit under this implementation |

Reconcile EVERY restriction with actual producer control flow and the existing
proof model, including the five reported closed cleanup reasons. Do not elevate
this report table to new authority. Reject both under-validation of impossible
facts AND over-validation that prevents a legitimate existing failure outcome
from being retained. If a supported real branch constructs a record rejected
by the new invariant, that is a finding, not permission to change the producer
or weaken a test during this audit.

Do not conflate:

- exact nonzero/signaled return code with an invalid negative PID;
- zero exit with process success when deadline/cancellation took precedence;
- successful exit with proved stream/group cleanup;
- group-clear with direct-child reap;
- signal request with delivered signal;
- outcome consistency with authenticated historical process evidence.

The PID=initial-group relation must be grounded in the existing fresh-session
launch, not obtained by querying a reaped process or generalizing to unselected
platforms/process strategies. Retain the supported fixed POSIX proof boundary.

### Direct constructor and forged-consumer specimens

Use genuine successful planner/worker records and handback from one actual D1
run. Keep fixed expected outcomes outside the validator and predicate under test.
For BOTH process fields independently test, without changing other evidence:

1. ok with exit 99;
2. ok with exit None;
3. ok with signal-negative exit such as -15;
4. ok with Boolean False or an int subclass equal to zero;
5. zero, negative, missing, Boolean or int-subclass PID/group;
6. positive but inconsistent PID/group for the owned initial group relation;
7. each materially distinct contradictory reason/output/cancel/signal/reap/
   group-clear/cleanup combination in the finite source-derived table.

Normal construction/replacement must reject invalid records. Separately use a
TEST-only forged exact instance that bypasses only constructor validation and
prove the real handback consumer rejects it. Leave the original evidence class
identity intact. Constructor rejection cannot count as consumer-test coverage.

Apply these specimens to otherwise valid ready, planner-frame, worker-frame,
broad stopped and cleanup handbacks where that process field is allowed. Avoid
masking missing process validation with an unrelated stage/capture defect.
Retained usable Wire classification must not rescue the contradictory worker.

Also test a VALID nonzero_exit record (99 and a supported negative return code):
it must remain constructible as failure evidence, but must not support ready or
an ordinary-success prerequisite. The validation fix must not reject all
negative outcomes merely to prevent false success.

### Real producer paths and failure preservation

Run real fixed child scenarios for clean success, Popen/start failure, nonzero
exit, malformed frames after zero exit, timeout, cancellation, output/stderr
limits, and selector/stream cleanup uncertainty. Record actual supervisor branch
and returned fields. For reachable zero-exit-after-cancellation/deadline and
process-control-error cases, use bounded faults or existing fake behavior to
reach the real producer path, not only a synthetic valid record.

Known exit 0 plus unproved cleanup remains negative evidence, never ready.
A failed launch retains its exact no-process observation, not invented IDs or
reap claims. Process facts already observed must not be erased to satisfy the
validator. Valid broad-prefix handbacks remain valid; contradictory ok records
cannot hide under a broad stopped/cleanup reason.

Required latest counterexample closure is paired: prove malformed evidence is
rejected AND prove genuine negative observations still reach their typed
failure/cleanup outcomes without raw parser/constructor leakage or fabricated
empty durable_conflict results.

### Wire relation stays separate

Handback may import ONLY its already admitted two Wire evidence classes; it
must not execute or duplicate classify_wire_process_result. The runner remains
the classifier caller. Observe its actual inputs with a call-through wrapper:
worker return code and related command/fences/delivery must come from the real
retained outcome, not literal zero or inference from reason="ok".

Read the unchanged Wire contract and implementation (baseline owner: .docs/
rw0-b2-wire-protocol.md:94-98; source: _rw0_wire_protocol_values.py:1861-1913).
Its two-field classification is not a receipt of classifier inputs. Validate
internal agreement: clean valid zero-exit worker AND usable, valid Wire evidence
are both needed for ready; neither is sufficient alone. Preserve higher-priority
Wire failure/cancellation/deadline semantics and no teardown/acceptance authority.

Test a stale usable label next to invalid/missing/nonzero process evidence, and
a genuine clean zero-exit worker with unusable/missing Wire evidence. Neither
may produce ready. Do not introduce a new classification hash/receipt or another
consumer/import permission.

### Actual-return rejection and resource ownership

Reproduce the report's planner PID -1 and worker ok/99 substitutions in actual
runner invocations. They must not yield capsule_ready or advance to a later
child. In the worker case the already executed planner/worker must still be
reaped and cleaned; "no later child" does not mean no earlier process existed.

If the internal process value cannot form any valid typed handback, the current
private content-free invalid_d1_process_outcome error may escape after safe
cleanup; that is distinct from a normal supported child-failure outcome.
Only the failing invocation's newly owned roots may be removed. An original
successful run used as injected evidence remains under its creator's custody
and closes normally. Inspect returned/raised errors and repr for path/output
leakage. Do not adopt a future unselected error/status vocabulary.

Prove repeated pure validation/handback construction does not query the OS,
mutate the disposable database or change its bytes/mtime. Keep current durable
owners and the parent run owner separate from this evidence-only invariant.

## 7. Retained capture invariant: owner and consumer boundaries

### Source of truth and reported shape

Independently confirm the actual capture classes, fields, constructors, owned
validator, blobs() operation, and all handback/capsule consumers. The closeout
reports this unchanged shape:

| Member | Expected admissible data |
|---|---|
| D1CandidateCapture.entries | exact tuple of three exact D1CapturedEntry records, in fixed PATHS order |
| each entry.path | exact string equal to its authorized ordinal path |
| each entry.mode | exact string `100644` |
| each entry.before / entry.after | exact bytes, each at most 1,048,576 bytes |
| changed_path | exact authorized path of the single changed entry |

Validate the report against the actual current owning code and capsule contract;
do not substitute report assertions for source inspection. Require every nested
container and leaf to be checked before relying on arbitrary-object iteration,
equality, hash, encoding or a mutable wrapper. No coercion through str/bytes/
tuple/dict/repr/JSON/deepcopy may erase the malformed value before the boundary.

Normal construction and dataclass replacement, where supported, must reject
malformed captures. Consumers must also revalidate a forged EXACT capture
wrapper whose malformed contents bypassed construction solely by test injection.
The workspace module owns the complete pure value check; handback, blobs(),
capsule construction and independent verification must not use divergent,
weaker schemas. Verify the check is active whenever those paths consume capture.

Repository-relative capsule paths are valid data. Exact file-content bytes are
opaque, even when they contain pathname-looking text. Do not demand filesystem
path string blacklists, scanning file contents, arbitrary reflective object
walks, or a guarantee against code that rewrites the parent interpreter.

### Independent specimens

Use one real successful D1 run under an audit-owned root as valid input. Keep
that run open and identify only its audit-owned state path. Independently inject:

- that open RW0D1OfflineRun;
- an arbitrary object;
- its actual state-root Path;

into each materially distinct capture container/entry/leaf position. Include
ordinary construction/replacement and forged exact-wrapper consumption. Keep
bad objects intact until validation; do not stringify or serialize them.

Also exercise wrong exact container/scalar/entry types, subclasses where exact
built-ins are required, missing/extra/reordered entries, wrong path/mode, invalid
changed_path, zero/multiple changed entries and over-ceiling bytes. Use the fixed
finite inventory, not a general fuzzer. Healthy captures and exact opaque bytes
remain accepted without mutation.

Require rejection at the capture owner or consuming private boundary with a
content-free error, no resource opening/closing, and no inserted live object
retained inside any accepted handback or capsule. Test every status permitting a
capture, including capsule_mismatch and workspace cleanup uncertainty, not ready
alone. Do not credit an earlier unrelated invariant rejection as proof that deep
capture validation ran.

A direct capsule-consumer specimen must reach the capsule check without first
relying on the handback's validator. A forged capture must not be accepted by
blobs(), builder, or independent verifier merely because its outer type matches.
Preserve independent reconstruction and existing manifest relation validation.

### Actual returned-handback injection and resource safety

Reproduce the reported actual-return substitution with the live object nested
inside an emitted capture. The permanent integration test must now fail a copy
that removes deep handback consumption, even though the ordinary capture
constructor still validates.

Observe failure cleanup: only the failing invocation's newly owned state root
may be removed; the original injected run/state is untouched and can still be
closed by its creator. No fabricated generic stopped/success handback is allowed
to conceal constructor failure. Retain and inspect the safe error and observed
cleanup facts; no raw resource/path disclosure through repr or errors.

Positive controls: normal D1 produces the same immutable byte/mode semantics,
independent capsule verification succeeds, and the typed handback still carries
the exact D2-required data without a live-resource escape slot.

## 8. Retained handback: reason, stage and producer consistency

The sixteen fields remain closed. Independently check actual declared types,
runtime validation, optional None rules, order, repr behavior and cross-value
bindings. A frozen outer dataclass or matching class name is not sufficient.
No new authoritative stage ledger or handback-written program state is allowed.

The closeout describes thirteen evidence fields in logical prefix order:

```text
P,A,C,p,B,S,b,r,w,W,K,X,M
program_result, author_result, author_command, planner_process,
selected_bundle, section41_result, phase_basis, phase_result,
worker_process, wire_result, wire_classification, capture, capsule_manifest
```

A prefix n requires exactly its first n values and forbids the later values.
The other fields are status, reason and workspace_cleaned. Do NOT assume this
logical prefix order is the dataclass declaration order; independently inspect
the exact fixed field inventory.

The report's matrix is a claim to verify against actual current call sites and
owning contracts, not a newly authorized semantic specification:

| Reason | Reported prefix / status and predicates |
|---|---|
| complete | 13, capsule_ready; successful started clean planner and worker, selected Section 41, usable Wire, workspace cleaned |
| invalid_input | 0, stopped |
| durable_commit_unresolved | 0, 1, 5, 7; stopped at the four durable recovery sites |
| durable_conflict | finite 0-11; stopped, with valid prior-stage process/selection predicates |
| planner_start | 4; stopped with exact failed/invalid launch observation, no PID/group/exit/output/cleanup success |
| planner_frame | 4; stopped with started ok/clean planner |
| planner_limit / planner_exit / planner_deadline / planner_cancelled | 4; matching limit/nonzero/deadline/cancel process result and cleanup |
| nonselection | 6; nonselected Section 41, no phase |
| c1_phase_failure | retained vocabulary, no current producer/admitted fabricated combination |
| worker_start | 9; failed/invalid launch observation, valid earlier phase, workspace cleaned |
| worker_frame | 9 with ok/clean worker and no decoded result; or 11 with nonusable classification |
| worker_limit / worker_exit / worker_deadline / worker_cancelled | 9; corresponding result, process/workspace cleanup |
| unsafe_candidate / missing_candidate / excessive_candidate | 11; usable Wire, no capture, workspace cleaned |
| capsule_mismatch | 12; validated capture, no manifest, workspace cleaned |
| process_cleanup_unresolved | finite 0-8; cleanup status, retained prior observations |
| planner_cleanup_unresolved | 4; started planner, cleanup unproved, no selection |
| worker_cleanup_unresolved | 9; started worker, cleanup unproved, no Wire result |
| workspace_cleanup_unresolved | 8-13; workspace_cleaned false, retaining genuinely reached capture/manifest |

Reported cross-prefix rules: planner ok/clean from 5 onward, selected Section 41
from 7, matching phase result/basis from 8, worker ok/clean from 10, usable Wire
from 12. V5 says the ordinary-completion predicates now use the owned clean-
success check; all present process values are revalidated even at earlier
prefixes. Inspect this composition rather than treating the older prefix table
as an alternate, weaker process grammar. Verify exact command digest, selected
proposal, disposition and phase ref/digest relationships using independent values.

### Independence of the matrix

Read every actual return, stop, catch, recovery and handback construction site.
Build the audit's own mapping of reason -> possible sites -> required/forbidden
fields -> process and cleanup predicates. Compare production predicates to
that map and to fixed tests. Expected rows must not be read out of the
production table or generated merely from its accepted cases.

For broad durable_conflict and process_cleanup_unresolved reasons, account for
each admitted prefix and actual legitimate failure position. Reject catch-all
acceptance of any nonready object. Conversely, do not reject a shortened object
merely because it changes one valid broad-reason prefix into another valid
prefix: the repaired test's prefix-1 -> prefix-0 correction needs inspection,
not automatic condemnation or acceptance. A consistency invariant cannot
authenticate a past execution by itself.

Verify retaining c1_phase_failure without a producer does not conceal removal
of a required real failure path or introduce an undocumented success/refusal.
Do not invent a new reason or require a mutation to change the vocabulary.

### Direct and integrated specimens

Obtain a real successful handback. After removing its manifest, substitute
invalid_input, planner_frame and worker_start while retaining later evidence.
All three prior counterexamples must be rejected. Exercise neighboring-stage
additions, missing necessary predecessors, stopped/cleanup mixing, unknown
reasons, wrong exact types, identity/digest mismatches and successful-process
substitution for failed-start observations.

Test every reported reason and permitted stage, using actual-return evidence
where a producer exists and bounded constructor specimens for predicate
coverage. Required actual paths include initial input refusal, malformed planner,
nonselection, unresolved durability at each owner, failed planner/worker launch,
worker failure/frame/classification, timeout/cancellation, selector cleanup,
workspace cleanup and normal capsule_ready. Call through to real current owners
and real children wherever such a stage is claimed.

Failed-start evidence is legitimate. A worker_start may retain an exact failed
launch observation, but not a PID/successful worker/Wire/capture claim. Inspect
the repaired start-before-cleanup ordering and prove it does not turn a genuinely
started-but-unclean child into a harmless start failure. No dropping observed
facts to satisfy a matrix, relabeling process failures as durable conflict, or
fabricated empty handback after constructor rejection.

This is projection validation, not a second in-memory program lifecycle. Every
accepted handback must bind evidence from current SQLite owners in the actual
runner; constructor consistency by itself does not authenticate those records.

## 9. Retained Wire helper: independently enforce its stated restriction

Inspect `_assert_private_wire_consumers` and test the actual helper directly,
without invoking B1 or crediting an unrelated whole-source guard.

Keep the selected handback consumer exactly:

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
RW0WireWorkerResultV1 -> wire_result
RW0WireProcessResultClassificationV1 -> wire_classification
```

Require direct relative unaliased runtime imports, exact existing importer/symbol
sets and old Capability/C1/D1 permissions. Legitimate annotations and exact type
checks are not value exports. No new import permission is authorized.

At minimum reproduce the module-level value export
`D1WireExport = RW0WireWorkerResultV1` and the report's dynamic importlib call.
Exercise their finite direct, simply aliased and nested importlib/__import__
forms as claimed by the amended helper. Each must fail that helper in isolation.
The normal retained handback must pass. Keep prior extra-symbol, wildcard/module
alias, nested unauthorized import, unapproved consumer and prior-C1 restriction
controls. Expected permissions are fixed, not derived from observed sources.

Classify this as guard-adequacy evidence. The old specimen was not an observed
production dynamic loader nor proof that all other guards would permit it.
Do not demand a universal static solution to arbitrary Python reflection.

## 10. Independently reconfirm retained runtime and consumer repairs

### Creating-process custody

Inspect every custody-affecting method/property of RW0D1OfflineRun: creator PID
must be checked BEFORE exposing state, mutating closed status, cleanup, or
opening retained resources. The immutable path-free handback may be readable
without granting custody. Repr/serialization must not expose a usable live handle.

Use a real successful D1 run and an actual POSIX fork. In the child, attempt
custody operations; require private content-free refusal without path exposure,
state deletion or parent-visible state change. Wait/reap; parent remains open,
state exists, parent close succeeds, second close is idempotent and root is gone.
No mocked PID-only substitute or finalizer-dependent cleanup. This is not a
hostile same-UID or arbitrary-interpreter security claim.

### Process cleanup and framing

Inject selector-close failure after a REAL planner PID and separately after a
REAL worker PID, one supported stream-close failure and one cleanup+timeout or
cancellation composition. Preserve start/PID/group/I/O/cancel/deadline/signal/
exit/reap facts; attempt group-clear despite cleanup exceptions. Planner cleanup
stops before Section 41; worker cleanup never yields capsule_ready. No erased
process field or stopped/durable_conflict substitution. Prove actual reap and
cleanup of test processes, not only the returned label.

Supply otherwise canonical D1O1/D1W1 frames with wrong built-in enum/membership
fields, including action: []. Require D1FrameError, not raw TypeError/KeyError,
and the integrated stage-specific stop before later durable progress. Preserve
unknown-key, duplicate-key, wrong magic, truncation, trailing/extra-frame and
ceiling protections. No new framing grammar.

### B1 evidence-only role and independently fixed registry

Verify the exact handback import is RW0PhaseEntryBasisV1 from
`_rw0_phase_entry_semantic_values.py`. Registry version 3 remains the consumer
registry, not a B1 value-schema version. Primary B1 and phase-entry tests retain
independently fixed projections of:

```text
current_bounded_runtime_phase_construction_consumer = RW0-D1-pre-execution
current_bounded_runtime_phase_evidence_consumer = RW0-D1-handback
```

Pre-execution constructs; C1 establishes/verifies the durable phase; handback
checks/retains already established evidence. Source authentication, executable
permission, durable persistence and semantic acceptance of B1 remain none.
Preserve all existing non-D1 consumer/symbol/form restrictions and helper scope.

Compare actual handback basis ref/digest to current C1 output. Forming another
handback must cause no basis construction or C1 write. Instrument calls without
replacing the evidence class identities. Reject unapproved consumers, extra or
nested helper/value imports, aliases/wildcards/module/dynamic/typing-only or
re-export substitutions, construction behavior in handback, singular/missing
roles, role swaps and one-sided version/projection drift. Neither fixed oracle
may derive its expectation from the owner's parser or the other test.

## 11. Complete the independent durable and process/capsule acceptance path

Re-run one independent successful invocation trace in the external clone. Wrap
ACTUAL private current methods and call through to their original implementations:

```text
disposable DB initialization through 0004
-> current guarded program initialization
-> current guarded author-effect establishment
-> writer/lock close -> distinct fake planner PID
-> current Section 41 probe/disposition -> selected_for_dispatch_gates
-> current guarded C1 phase commit
-> writer/lock close -> distinct fake worker PID
-> capture -> parent capsule -> independent reconstruction/verification
-> workspace removal -> handback and separate parent-only state lifetime
```

Inspect actual disposable database state through existing readers or appropriate
read-only audit inspection, not D1's summary object alone. Check program/head/
WorkSpec, author command/fences/delivery, selection/head, phase and receipts
against the handback. Do not stop at row presence or a count of user tables.
For the actual program, author-effect, Section 41 selection and C1 families,
identify each owner-required member/key, compare retained refs, exact digests,
command/receipt/result bindings and head/version relations with the independent
input and observed call-through result, and verify replay creates no second
family or changed original time. Use unchanged current owner validation/canonical
functions where authoritative; do not define a new digest or persistence grammar.

This is a complete readback of the FOUR USED durable families and their required
linked members, not a general audit of all 62 reported user tables, every unused
migration row, or future D2/C2 state. Any member/readback not proved remains a
named limit. An observed recovery call and final success label alone do not
prove its original family is exact. No direct SQL shortcut in D1, planner-authored
identity, harness selection boolean, replacement delivery, or shadow lifecycle.

Inject committed response loss at all four durable operations and prove exact
recovery via the current owner before advancement. Inject unresolved recovery
at each: program/author stops launch no child; selection/phase may retain the
planner but never launch worker. Nonselection stops before C1. These runtime
observations must agree with the new handback reason/prefix matrix. No automatic
retry or duplicate author delivery.

Verify one bounded supplied WorkSpec/fixture produces the entire handback
without manual relay or stage-to-stage external input. The proof is private and
artificial, not a public natural-language intent API.

### Child channels and supervision

Check every production launch and the sole subprocess owner. Verify absolute
interpreter, -B -m private modules, no shell/preexec hook, fresh session/group,
closed descriptors, allowlisted environment, bounded pipes and monotonic
deadline. Before BOTH launches, writers/connections/state locks/capabilities are
closed; uncertain close must prevent launch.

Use unique state/database/lock/credential sentinels and an explicitly inheritable
parent FD. Observe actual child argv/environment/cwd/stdin/open descriptors;
none may contain parent database path or writer authority. The legitimate
bounded planning/command input remains allowed. No claim that same-UID fixed
children are an adversarial sandbox.

Exercise start failure, malformed/nonzero/over-limit output, blocked input,
deadline, cancellation, TERM/grace/KILL, child reap and group-clear. Observe no
owned survivors. Unsupported required platform tests are a limit, not a pass.

### Workspace and capsule

Verify exact three-file artificial base, one bounded replacement, full capture,
independent reconstruction and existing manifest relation. Reject traversal,
absolute selections, links, special files, mode changes, additions/deletions/
renames, excess mutations and byte ceilings. Parent derives the manifest from
observed bytes; worker metadata cannot authorize it. Verify base/work/program/
attempt/candidate/command/fence/path/mode/hash/length/portable-digest relations.

The supplied base Git OID is a fixture coordinate, not authenticated Git truth.
No Git repository or command is needed for D1. Mutable workspace must be gone
before capsule_ready; the only remaining state lives under explicit parent-only
custody with no open writer session. D2-required immutable data and lineage must
remain available in that same parent lifetime. Do not implement D2 to check it.

## 12. Scope and coordinated governance guards

Inspect all 29 candidate diffs against HEAD for bounded status and authority
changes. No report or test registry makes target C2 behavior implemented.

Verify literal protected identities in both owning tests:

```text
AGENTS.md: 62,778 bytes
076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6
README.md: 46,898 bytes
dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff
```

No dynamically observed expected hashes, ignored observations, changed ownership
classes or no-op comparisons. Five Capability status projections stay normalized;
Capability remains pure/no-I/O/non-authoritative while named D1 owners implement
the artificial process mechanics. Capability protection rows that are path/mode/
purpose checks must retain those meanings.

The temporary complete-source C2 manifest is explicitly superseded by scoped
nonimplementation checks; these must still detect C2 persistence/writer/reader
runtime, forbidden production callers, exports, acceptance/terminal runtime,
activation and migration 0005. Do not restore a whole-source barrier just to
freeze D1's new file count by inertia.

Exactly nine D1 source modules, one subprocess owner, and two private fake-module
executable entries are permitted. Existing semantic modules remain pure; package
root, exports and pyproject script/service inventory stay unchanged. B1/Wire
value consumer permissions confer no decoding, qualification or mutation
execution role on handback.

No validator, independent reviewer, fake review-model, post-execution closure,
D2 evidence admission, durable C2 decision/acceptance/terminal, migration 0005,
live source/provider/supplier, network, public CLI/service, ES/Bridge, Git or
publication effect. Typed handback is evidence/projection, never program truth.

## 13. Finite causal and transformed-copy acceptance evidence

Keep independent expectations outside altered subjects. Every credited mutation
must parse, import and collect normally, and fail an intended semantic assertion;
no syntax/collection failure, unrelated global inventory error or injected false
assertion is credit for a runtime defect.

Do not create an open-ended mutation framework. Use the following closed
obligation set; one discriminating specimen may satisfy overlapping rows, with
that mapping recorded rather than double-counted.

### V6 B1 acquisition correction

The two representative full modules, helper/owning-test refusals, finite syntax
positives/negatives and two acquisition-regression copies in section 5 are the
latest focused work. Cross-reference them to B01–B03 below. Do not duplicate them
as another mutation campaign or expand into unselected reflection syntax.

### Retained V5 process consistency obligations

| ID | Deliberate regression | Required discriminating evidence |
|---|---|---|
| P01 | omit process constructor validation | inconsistent direct process construction is wrongly accepted |
| P02 | handback keeps only outer process type | forged exact invalid process crosses the real consumer |
| P03 | omit zero-exit, exact-int, positive-ID or owned PID/group check | independently fixed corresponding primitive specimen fails |
| P04 | validate only worker, only ready, or omit later-prefix ordinary-success check | valid-stage bad planner/stopped/cleanup evidence crosses the boundary |
| P05 | trust retained usable Wire label or feed synthetic zero to classifier | actual call-through input/handback relation test fails |
| P06 | erase/relabel contradictory process facts or omit rejection cleanup | actual-return specimen detects fabricated evidence or owned residue |

The implementation reports nine copies: P01, P02, four P03 omissions, worker-only
P04, usable-Wire P05 and cleanup P06. Reproduce the named protection, not that
number as a quota. Exercise the other P04 status/prefix and P05 actual-classifier
input obligations through bounded direct/negative copies where the reported
copy does not discriminate. Do not falsely credit a constructor rejection for
P02: provide the exact forged record independently. Retain tests' fixed
expectations and identify any audit-only oracle separately.

P03's distinct primitive predicates may need several small copies, not full-suite
runs. One actual-return/root-cleanup specimen may cover P06 and retained cleanup
rows; map that shared coverage explicitly. No new generic mutation framework or
additional unselected behavior is requested.

### Retained V4 obligations

| ID | Deliberate regression | Required evidence |
|---|---|---|
| N01 | omit constructor capture validation | malformed direct capture/replacement test fails |
| N02 | handback checks only the outer capture type | independently forged nested live resource crosses the boundary and fixed actual-return test fails |
| N03 | replace reason-stage checks with the old broad stopped rule | early reason plus later evidence or wrong process facts fails |
| N04 | erase/relabel a failed worker-start observation | real failed launch is misclassified; fixed stage-specific integration test fails |
| N05 | allow module-level admitted Wire value export | Wire helper's own fixed negative specimen fails |
| N06 | allow the demonstrated dynamic Wire loading | the same helper's isolated fixed negative specimen fails |

Additionally exercise capture consumer validation directly at blobs(), capsule
build and independent verification. No added architecture or wrapper is needed.

### Retained repair and consumer obligations

| ID | Deliberate regression | Required evidence |
|---|---|---|
| R01 | arbitrary object/extra generic handback slot | independent fixed field/type inventory rejects |
| R02 | ready without mandatory process/Wire/capsule/durable evidence | fixed ready invariants fail |
| R03 | actual live state root retained in returned handback | actual closed-graph test fails (nested N02 may cover this) |
| R04 | remove creating-PID fence | real fork custody probe/test detects unauthorized access/deletion |
| R05 | selector close escapes | real-process cleanup test observes wrong exception/outcome |
| R06 | erase process evidence during cleanup | retained observation assertion fails |
| R07 | cleanup maps to durable_conflict | exact cleanup classification fails |
| R08 | omit group-clear after cleanup failure | observed cleanup trace fails |
| R09 | enum membership before type checking | malformed canonical frame raises wrong error |
| R10 | frame error maps to durable_conflict | integrated planner-frame test fails |
| W01-W03 | remove Wire handback allowance, widen symbols/form, widen consumers | independent positive/negative finite Wire controls fail |
| B01-B03 | remove B1 handback allowance, widen symbols/form, widen consumers | fixed B1 controls fail |

The B1 owner and both fixed projections also receive direct one-sided
version/row/role specimens. Do not let a common parser response substitute for
two independently fixed expectations.

### Material original safeguards still required for acceptance

Complete bounded negative-copy evidence for these named categories left
unfinished by prior audits:

- substitute fixture/harness values for actual program writer or Section 41
  selection;
- worker launch before C1, or after unresolved durable recovery;
- parent database path/inheritable FD passed to child;
- skip process reap/group cleanup;
- trust a worker manifest or bypass independent capsule verification;
- admit extra/link workspace mutation;
- allow a second subprocess owner or additional D1/D2 module;
- admit a prohibited C2 module/call/export after manifest supersession;
- dynamically derive the protected AGENTS/README expected identities.

Use an unchanged permanent test when it is the claimed safeguard. Its survival
for the named defect is a test-causality finding even if an audit-only oracle
would notice. Direct audit faults can establish implementation behavior but must
not be mislabeled permanent mutation protection. Cross-reference overlaps with
R/N rows and keep copies minimal; no duplicated full-suite runs per mutant.

State which results are permanent-test, independent direct specimen, finite
source-text helper, transformed copy, static inspection, or audit-only oracle.
No arbitrary coordinated rewrite of every source and expected value is claimed
to be self-authenticated by the candidate.

## 14. Exact final validation

After provenance and focused checks, create one fresh final remote-free local
clone of exact HEAD overlaid with the exact table. Verify all 263 endpoints
before/after tests. Keep transformed copies separate. Never credit final
validation from a superseded or fault-injected clone.

From this clone, collect and then execute each group serially:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Use umask 022, TMPDIR under the owned root, distinct collect/run parents, no
xdist, overlap, warning suppression, test removal, network or live import. These
tokens expand to `tests/test_<token>.py`. Sort/deduplicate only within a group:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12 has NO path arguments; full repository collection must include all
124 current test modules. No selector may be invented to manufacture a count.

For inventory hashes, concatenate for each sorted repo-relative module path:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

The final implementation report supplies these exact candidate-specific
coordinates to reproduce:

| Group | Files | Reported collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 108 / 108 | `c768d282a219e67d89800643373e1c4ab7bad9a248949933f7beacfcdda3c7d6` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,980 / 8,980 | `9be322d172fccc745a5dd5ac0e448b5f73217edf537a0ffca28b2b7f27e94687` |

Require unique node IDs within each collection; each Group 1-11 node belongs to
Group 12. Reported overlaps are Group 2/3 = 46 and Group 7/11 = 31. Calculate
actual overlaps, not just aggregate counts; their expected union is 3,653 if
those are the only overlaps. Do not sum group passes as unique coverage.

V6 count arithmetic: 8,970 + (1,783 - 1,773) = 8,980. Its only changed test
file belongs to Groups 10 and 12; Groups 1–9 and 11 retain their recorded V5
file identities. This is arithmetic, not execution. Do not alter bytes or
selectors to force any expected count.

The V6 report records two opening table-parser failures before tests, nine
initial focused assertion-reason failures, and a Group 4 collection parser that
excluded valid node IDs containing spaces. These were corrected before the
claimed final successful gates. Do not reproduce their harness assumptions:
preserve complete pytest node IDs including parameter spaces; use a reliable
collection record rather than whitespace splitting. Report trial failures and
corrections truthfully. No old interrupted or superseded run is final credit.

Groups 10 and 12 report the same three existing Python 3.13 multithreaded-fork
DeprecationWarnings from:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect structured warning records. Repetition in overlapping groups is not a
new warning class. New warnings, failures or unsupported mandatory fork/process
execution must be investigated and reported, not suppressed or marked passed.

Also run read-only git diff --check, all seventeen addition no-index whitespace
checks (difference status 1 is ordinary without whitespace diagnostics), strict
encoding/final-LF checks, complete type/mode/path receipts, opening/closing index content AND metadata,
unchanged package/
export/script/current-owner/migration inventories, migration 0005 absence and
pre/post equality of the final clone's 263 endpoints.

An audit-runner mistake may be corrected only outside live checkout; rerun every
affected gate from the same exact bytes and record the correction. Candidate
defects are findings, never audit repair permission. An interrupted run carries
no final pass claim.

## 15. Early block, cleanup and live preservation

A reproduced Medium/High defect, or a survivor of the specifically required
Low B1/Wire consumer checks, can justify ending expensive remaining work.
That disposition is BLOCK with exact completed/interrupted/unperformed gates,
not ACCEPT based on implementation reports or hashes. Similarly, a still-open
required Low B1/Wire-guard correction or material acceptance-evidence gap must be
reported rather than silently omitted.

Account for owned child PIDs/groups and every owned state/planner/workspace
root, especially those leaked deliberately by broken validation/close mutants.
Reap/observe termination before guarded removal. Do not sweep arbitrary
processes or delete a caller's original run because it was used as an injected
resource. Record actual residue and do not call unproved cleanup complete.

After cleanup, recompute live baseline and index CONTENT AND opening-recorded
metadata (including nanosecond mtime and SHA-256), all 46 endpoint receipts and
replacement identity, all 217 HEAD-exact noncandidate paths, and cache directory
AND member metadata including true-opening nanosecond mtimes and hashes.
Preserve retained candidate bytes; no output evidence attachment is required.
The previous audit's missing pre-status index metadata remains historical. This
run's opening/closing record can establish only this run's preservation. Never
claim a current hash proves that an earlier status command had no metadata effect.
An unproved mandatory opening/preservation procedure blocks this acceptance;
report it separately from candidate defects, without resetting or normalizing.

## 16. Verdict and inline closeout

ACCEPT requires exact provenance/preservation and the correct pre-Git opening;
independent closure of the V6 B1 loader-acquisition guard with its owning test;
independent reconfirmation of the V5
process owner/consumer and Wire-consistency finding, without over-rejecting real
failure/cleanup observations; independent closure of retained deep capture,
reason-stage and Wire findings; independent reconfirmation of retained
fork/cleanup/frame and B1/Wire fixes; actual guarded durable trace and recovery;
child isolation and supervisor/workspace/capsule custody; path-free typed
handback and parent-only resource lifetime; narrow status/governance changes;
completion of the finite material acceptance evidence; all twelve final groups
passing; and no unresolved High/Medium in-scope defect, required Low B1/Wire
correction, or material acceptance-evidence/procedure gap.

Use exactly one final token:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
```

ACCEPT is eligibility for a separately issued commit/publication gate for these
exact 46 files. It grants no edit, stage, commit, publication, D2/C2 work,
migration 0005, source/supplier qualification, enrollment, deployment, live
provider, ES/Bridge or RW0-E action in this task.

Return inline:

1. Verdict, visible settings, exact baseline, true pre-Git opening order and
   inspection scope. Distinguish procedural limits from candidate findings.
2. Complete 46-endpoint and aggregate reproduction, one-file V5->V6 transition
   evidence/limits, 45-row preservation and 217 unaffected HEAD files.
3. B1 changed-helper/caller inspection, both complete alias-module parse/import
   and owning-test results, finite negatives/positives and two regression copies;
   exact unchanged version-3 permissions, both fixed projections and roles.
4. Retained process field/reason invariants, constructor/forged-consumer checks,
   genuine negative/cleanup outcomes, actual Wire inputs and safe rejection.
5. Complete capture/handback-stage, actual nested-resource, creator-PID fork,
   process-cleanup, frame-error and Wire consumer safeguards.
6. Actual guarded durable-call trace AND complete identity/digest/receipt/head
   readback of the four used families, response-loss recovery, unresolved stops
   and replay/no-duplicate evidence; identify any unproved member.
7. Child channels/FD isolation, supervisor fault outcomes, workspace/capsule
   independence, parent-only state lifetime, no-shadow truth and D2 limits.
8. All 29 tracked semantic diffs and scoped governance/nonimplementation guards.
9. Finite direct/permanent/transformed/static evidence matrix with exact tests,
   failures, survivors, overlaps and omissions. No inherited report is relabeled
   as an experiment performed here.
10. Twelve final command/membership/inventory/node/overlap/warning results;
    collection parsing, failed trials/corrections and final clone endpoint equality.
11. Actual process/root cleanup, opening/closing index and cache directory/member
    equality, with prior missing metadata explicitly left historical.
12. Severity-ranked findings or no remaining material findings; continuation
    capsule <=1,000 words with exact candidate and next permitted gate.

Do not issue a repair, implementation, publication, D2 or C2 prompt. Do not
mutate the retained checkout or deliver an evidence package. End with exactly
one supported verdict token.
