# Governed Execution Coordinator — RW0-D1 Repaired V3: Independent Read-Only Re-audit

## Mandate and acceptance boundary

Audit the exact RETAINED, uncommitted RW0-D1 candidate below. This is one fresh,
parent-only independent re-audit, not a mutation task or a new design program.

Reported closeout:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

That report is evidence to verify, not acceptance. The final candidate has not
been independently accepted. The first D1 audit found three Medium runtime/
evidence defects and one Low frame-error defect. Subsequent implementation
repairs retained the runtime fixes, admitted the exact Wire evidence consumers,
and coordinated the B1 owner/importer/projection dependency. The latest step
changed only the B1 owner document and two tests, and reports all twelve final
validation groups passing. Audit the repaired runtime AND those consumer changes.

Preserve the already selected program: D1 process/capsule spine, then D2 evidence
and cognitive-review closure, then physical C2 implementation. No new semantic
tranche, generalized parser/framework, supplier qualification, or D2 expansion.

Return operative findings INLINE with exact repository-relative `path:line`
evidence and a continuation capsule of at most 1,000 words. No delivered report,
manifest, recipe file, package, patch, snapshot, or other evidence attachment.
Everything necessary to identify the candidate and run the gates is in this
prompt. Do not request historical attachments or the original repair prompts.

Use the highest exposed reasoning setting. Record visible model, reasoning
setting/effort and permission posture, or `not visible`; do not infer hidden
settings or seek additional account/computer access to reveal them. No subagents
or live model/provider invocation. Executing the fixed fake planner/worker and
bounded audit probes in external test copies is expressly permitted below.

## 1. Exact opening local baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`, locally observed `0 ahead / 0 behind`
- exactly one live worktree
- index equal to HEAD; no staged or unmerged paths
- exactly 29 modified tracked paths and 17 untracked additions listed below
- no active Git operation, sequencer, or unexpected lock.

Read `AGENTS.md` first. Inspect local Git/files read-only, suppress optional locks
where appropriate, and do not fetch, refresh, normalize, clean, repair, or reset.
Tracking equality is not fresh remote evidence. No network is authorized.

A baseline, endpoint, path-set, baseline-blob, type, mode, or identity-recipe
mismatch requires `AUDIT_PROVENANCE_MISMATCH` before correctness acceptance.
Preserve actual work; do not substitute a different expected identity.

## 2. Complete final 46-path identity

`M` is a tracked modification; `C` is an untracked creation, not a Git copy or
commit status. Every candidate path must be regular and nonsymlink with Git
mode `100644`; the 17 additions must be absent from HEAD and index. Record and
preserve actual OS modes, including pre-existing nonexecuting `0600` files;
do not normalize unrelated files. Verify strict UTF-8, one terminal LF, no BOM,
CR or trailing whitespace against the reported candidate.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 9,698 | `76ef6a902733a0790da927b4881ad4bef6d2555d6b63be12517d347ea4f46802` | `absent` | 9,775 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,193 | `29e1dfb51e09941acea43ff907440f171a023d46a2de9bdce002d88f9088bc9f` | `absent` | 22,269 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 9,502 | `5d47b82d8b24f38f4a2c54825405f0370e308159908a104fdd9bc73c1ab970d9` | `absent` | 9,589 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 47,819 | `b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 47,885 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 34,490 | `8d600d1044947964b74786f1bfa59326d79541d0ace74d57d4ccd97e82c68cc9` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 34,561 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 11,665 | `20470ec086cbad881c6d4687100905d4670b7f14cc53f3966e342585f1e4bda4` | `absent` | 11,736 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 13,881 | `fab122192528cdd0f668bc63181bea2e4a2fc70d3d1f42bd92061ff8532ffa79` | `absent` | 13,956 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 8,476 | `890c0717fcb1f5f9b53919d3c73b10dc54c98d53d1f1473e52a75108831ce9aa` | `absent` | 8,550 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Verify each modified path's baseline blob by reading HEAD. Verify all 217
noncandidate tracked paths against HEAD content/type/Git mode. There are 246
baseline files plus 17 additions = 263 candidate repository file endpoints.
No new path, deletion, rename, submodule, symlink, or executable-mode change is
permitted. Keep the index equal to HEAD throughout.

The nine D1 production modules are precisely the nine `_rw0_d1_*.py` source
paths in this table. Existing production source, pure values, current durable
writers/readers, migrations, package exports, `__init__.py`, `pyproject.toml`,
`.gitignore`, and `state_store.py` remain HEAD-exact. No migration `0005`.

### Endpoint replacement recipe — no new format

Reconstruct twice from independent fresh file reads, without importing candidate
code. One concatenating and one streaming calculation is suitable.

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte
prefix length = 25 bytes (not the characters backslash and zero)
for each table row in UTF-8 path-byte order:
    u16be(len(path_utf8))
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw bytes of HEAD blob OID, or twenty zero bytes for C
    u64be(len(final_payload))
    exact final_payload bytes
```

Required FINAL identity:

```text
46 rows: 29 M / 17 C
encoded components: 4,465,477 bytes
prefix: 25 bytes
total: 4,465,502 bytes
SHA-256: b82b43fc4da2e5f258436cec351dcc2a561057b9edb64d7bffbbb35003c84974
```

The immediately preceding retained identity was 4,453,900 bytes, SHA-256
`66eea37eb17621aafa1b55e1cda250a1a11477612d0d97041cdef7c6781806b9`.
The last three reported payload increases are 476 bytes for the B1 document,
8,750 for the B1 boundary test, and 2,376 for the phase-entry test. They total
11,602 bytes; all other endpoints were retained. This corroborates arithmetic,
not a historical byte diff. Do not require historical payloads, reconstruct
files from hashes, or claim a direct historical comparison without their bytes.
The current 46 endpoints and exact final recipe are the acceptance target.

## 3. Read-only live ceiling; bounded external execution

In the live checkout permit only read-only Git, text, metadata, and hashes. Do
not import modules, run tests/scripts/processes, compile, open SQLite, alter
files or configuration, stage, commit, push, switch, reset, or contact remotes.
Do not inspect unrelated ignored operator state, credentials or secret files.

Executable work is permitted only in audit-owned external local-only clones of
exact HEAD overlaid with these verified 46 files and with configured remotes
removed. Preserve source OS modes and verify all 263 endpoints before execution.
Use installed dependencies, no installation/network. No supplier, live source,
enrollment, live Codex/model, D2/C2, ES, Bridge, publication, or RW0-E effects.

BEFORE any executable work, capture the known live cache directory
`src/ge_nwp_coordinator/__pycache__/` AND its 37 regular members with lstat:
relative path, type, actual mode, size, `st_mtime_ns`, and SHA-256 for regular
files. Do not hash the directory. Require complete opening/closing equality,
including after external cleanup. Do not copy a historical digest whose
serialization is unspecified or infer omitted earlier metadata retroactively.
The latest implementation report captured complete metadata for its own run;
the preceding report's missing directory-opening metadata stays a historical
limit, not a fact repaired by this audit.

Create private mode-0700 external roots. Use `umask 022` for test processes,
`TMPDIR` inside the audit root, bytecode/cache disabled, distinct precreated
collect/run basetemps, serial execution, and no xdist/overlap. Classify artifacts
with lstat before opening: hash regular files only, never follow symlinks or
open FIFOs/sockets/devices. Account for every test-owned process/group and
mutant-leaked state root before guarded removal of only audit-owned resources.

## 4. Scope, history, and inspection order

The original D1 audit independently traced the normal durable chain, stopped
advancement for unresolved recovery at each current owner, checked child
inheritance and TERM/KILL cleanup, and rejected unsafe workspaces and capsule
tampering. It then blocked on:

1. handback arbitrary-object slots and missing status/evidence invariants;
2. forked child removing the parent's retained SQLite state via `run.close()`;
3. selector-close failure erasing process evidence and becoming
   `stopped/durable_conflict` instead of cleanup uncertainty;
4. canonical planner `action: []` escaping as TypeError rather than D1FrameError.

The original audit did NOT finish validation groups 2–11, stopped its full run
after 1,405 passes, and left parts of its independent hostile campaign undone.
The implementation's final 8,942 passes do not retrospectively complete that
independent audit. This pass must close the four findings, verify the Wire/B1
coordination, and complete the material D1 acceptance evidence before ACCEPT.

Read all nine D1 source modules and seven D1 test modules completely. Read the
D1 implementation owner completely. Inspect ALL 29 tracked candidate diffs
against HEAD, focusing on actual source/status/authority effects, not merely
hash equality. For large unchanged documents, read changed sections with enough
owning context rather than rereading unrelated history.

Read the B1 owner and both fixed registry projections in full owning context;
read the Wire consumer guard including old consumers; follow current program,
author-effect, Section 41, C1, writer-session close/recovery, worker semantic,
Wire, Capability, and capsule contracts/source wherever the new runtime depends
on them. No test assertion or synthetic premise outranks its owning contract.

Do not reopen the accepted D1/D2 split, broaden fake-child support into a generic
execution service, or demand hostile same-UID sandboxing. Missing behavior
inside the named D1 contract is a finding; an unselected future feature is not.

## 5. Four runtime findings: independent closure evidence

### A. Typed transient handback

Independently derive and check the exact field order, accepted runtime types,
optional-field rules, repr behavior, and status/reason/stage relationships.
The reported closed inventory has SIXTEEN fields (order must follow the actual
fixed constructor/test contract, not this grouped presentation):

```text
status, reason, workspace_cleaned
program_result
author_result, author_command
section41_result, selected_bundle
phase_basis, phase_result
planner_process, worker_process
wire_result, wire_classification
capture, capsule_manifest
```

Use the actual existing private types, not class-name equality, `Any`, `object`,
mutable generic metadata, wrappers that conceal a path/session, or
`TYPE_CHECKING`-only annotations. Check exact types where the owner requires
exact types, including built-ins and optional `None` handling.

The B1 value is `RW0PhaseEntryBasisV1`; Wire evidence is exactly
`RW0WireWorkerResultV1` and `RW0WireProcessResultClassificationV1`. Resolve every
other field to its owning existing result/process/capture class and compare
constructor enforcement with the independent fixed test expectations.

Require:
- `capsule_ready` has the documented ready reason, full required committed
  program/author/selection/C1 lineage, successful planner and worker process
  evidence, exact Wire evidence, capture and verified capsule, and proved
  process/workspace cleanup;
- `stopped` and `cleanup_unresolved` enforce their separate closed reasons;
- no evidence can pretend an unexecuted later stage occurred;
- cleanup uncertainty preserves already observed process facts rather than
  converting them to durable conflict or dropping them;
- the field inventory is closed to later `state_path`, `workspace_path`,
  generic metadata, or live-resource slots.

Direct constructor and actual-run probes must reject missing ready fields,
wrong types and reason/status pairs, raw Path/PathLike values, live state roots,
sessions/connections/locks/proofs/capabilities/run owners, and arbitrary objects.
Inspect the actual success AND stopped/cleanup handback graphs via their closed
known dataclass/tuple/value structure. Include repr/error surfaces. Do not
confuse permitted repository-relative capsule paths with forbidden raw temporary
state/workspace locations. Do not traverse arbitrary objects with uncontrolled
reflection or replace typed values with a generic serialization layer.

A copy that inserts the actual state root into the real returned handback must
fail the unchanged permanent guard/integration test; it survived the first audit.
A valid handback remains usable without constructing another phase basis or
writing another durable fact.

### B. Parent-process resource custody

Inspect all custody-affecting methods/properties of the separate run owner,
including close, context management, and retained-state access for D2. Require a
creating-PID check BEFORE path exposure, closed-flag mutation, cleanup, or use of
state authority. The immutable path-free handback may remain readable; it must
not grant custody. Repr/nonserialization must not disclose a usable live handle.

Use one actual successful D1 run in an audit-owned root. In an actual forked
child, exercise each exposed custody operation and require a private content-free
ownership refusal without path exposure, database deletion, or parent-state
mutation. Do not replace this test with a mocked PID alone.

After wait/reap, verify the parent remains open and state exists, then parent
close succeeds and a second parent close is idempotent. Confirm state-root
removal and no surviving child. Reject finalizer-dependent cleanup. Do not
require general hostile Python-object security; test the selected process-custody
contract and its actual APIs. The same-UID proof is not a sandbox.

### C. Cleanup uncertainty retains process facts

Inject selector-close failure after a REAL planner PID and separately after a
REAL worker PID. Also exercise a supported stream-close failure and one
cleanup-failure-plus-timeout or cancellation composition.

Require observed start/PID/group/I/O/deadline/cancel/signal/exit/reap facts to
survive, group-clear observation to be attempted despite the close failure,
and a sanitized typed process outcome rather than a raw exception. An attempted
cleanup is not proof of complete cleanup.

The integrated planner path must produce `cleanup_unresolved` with planner
process evidence and must not reach Section 41. The worker path must preserve
worker process evidence and never return `capsule_ready`. Neither may become
`stopped/durable_conflict` or set the corresponding process evidence to `None`.
All safely observed earlier-stage facts must remain consistent with the handback
matrix. Close/reap all test-owned processes even in deliberately broken copies.

### D. Malformed frames have closed stage-specific errors

Supply canonical full D1O1/D1W1 payloads with each closed enum/membership field
set to an invalid built-in type, including planner `action: []`. Keep the frame
otherwise structurally valid so the actual decoder boundary is reached.

Type validation precedes set/dict membership; decoder errors remain
`D1FrameError`, not raw TypeError/KeyError/AttributeError. An actual integrated
malformed planner response yields the existing planner-frame stop BEFORE
Section 41, not generic durable conflict. Test unknown keys, extra/truncated
frames and ceilings as regression cases without expanding the selected grammar.

## 6. Wire and B1 consumer ownership

### Wire: result evidence only

`_rw0_d1_handback.py` may directly import exactly these existing Wire classes:

```text
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
```

They serve only `wire_result` and `wire_classification` exact field validation
and evidence retention. No handback codec calls, process-classifier invocation,
Wire mutation, transport, launch, cancellation, or new execution authority.
Preserve all existing Capability/C1/other-D1 consumer path/symbol/form constraints.
Check nested imports, direct relative unaliased form, no wildcard/module alias,
no dynamic import or re-export escape, and fixed expectations independent of the
observed import graph. No blanket `_rw0_d1_*` allowance.

### B1: consumer registry version 3, not a new value schema

The only newly admitted direct B1 handback dependency is:

```text
supplier: src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
consumer: src/ge_nwp_coordinator/_rw0_d1_handback.py
field: phase_basis
symbol: RW0PhaseEntryBasisV1
```

Verify the two role rows in the B1 owner and BOTH independent fixed projections
in `tests/test_rw0_b1_boundaries.py` and
`tests/test_rw0_remote_contact_phase_entry_contract.py`:

```text
current_bounded_runtime_phase_construction_consumer = RW0-D1-pre-execution
current_bounded_runtime_phase_evidence_consumer = RW0-D1-handback
```

Version 3 applies to this consumer registry only. Pre-execution constructs the
basis for the current guarded C1 command. Handback validates and retains the
already established evidence. C1 alone establishes/verifies the durable phase.
Keep existing non-D1 consumers and their exact symbols/forms, including the
qualified-host helper's restricted use. Keep B1 value schemas, domains/digests,
retrieval budgets, legacy-latch nonproof, no-I/O and no-public-export rules.

Preserve owner facts:

```text
source_authentication = none
executable_permission = none
durable_persistence = none
semantic_acceptance = none
```

Neither registry metadata nor possession of a phase basis grants execution
permission, phase write, acceptance, or source authentication.

Verify the actual handback type, its ref/digest equality to current C1 output,
and zero basis construction or C1 mutation merely from forming a handback.
Instrument existing constructors/methods without replacing the evidence class
identities themselves. Test both literal registry projections independently;
neither may derive its expected value from the owner parser or the other test.

Reject extra/nested B1 helpers or values, wildcard/module/aliased imports,
re-export, dynamic or typing-only substitution, unapproved consumer, widening
of pre-execution's symbol set, singular/missing consumer rows, wrong role,
version drift, and adding construction behavior to the evidence-only handback.
Capability R06/R18/R26 remain path/mode/purpose protections, not excuses for
another source-identity or AGENTS/README reset.

## 7. Integrated D1 authority and capability regression

Re-run an independent one-call trace in the external clone, wrapping ACTUAL
current private methods with calls through to the originals. Observe:

```text
DB initialization through 0004
-> guarded program initialization
-> guarded C2B3D author-effect establishment
-> writer/lock close -> separate planner PID
-> current Section 41 probe/disposition -> committed selected_for_dispatch_gates
-> current guarded C1 phase commit
-> writer/lock close -> separate worker PID
-> capture -> parent capsule -> independent verification -> workspace removal
-> typed handback plus separate parent-only state lifetime
```

Read actual disposable database state through appropriate current readers or
read-only audit inspection, not D1-created summary values alone. Verify the
program/head/WorkSpec, author command/fences/planned delivery, selection head,
phase and their receipts match the returned lineage. No direct-SQL shortcut,
harness-owned selection Boolean, planner-authored durable identity, replacement
command/fence/delivery, or shadow program lifecycle.

Induce committed response loss at all four current durable operations and verify
exact recovery through the existing owner before advancement. Induce unresolved
recovery at each: program/author failures launch no child; selection/phase
failures may retain the planner but never launch the worker. Nonselection stops
before C1/worker. No automatic retry or extra author delivery.

Prove one supplied bounded WorkSpec/fixture drives the sequence without manual
stage input or user message relay. This remains a private artificial offline
proof, not a new public intent API or production-authority flow.

### Child boundary and supervision

Inspect all launch sites; the supervisor is the sole production subprocess
owner. Verify fixed absolute interpreter and private `-B -m` children, no shell
or preexec hook, fresh process group/session, closed descriptors and allowlisted
environment, bounded streams and one monotonic deadline. Writers/connections/
state locks/capabilities must be closed before BOTH child launches; uncertain
close blocks launch.

Use unique database/state/lock/credential sentinels and an explicitly inheritable
parent FD. Observe actual child argv/env/cwd/stdin/open descriptors: none may
contain parent state/writer authority. Child stdin still legitimately contains
its bounded planning or worker-command projection. These fake children are
same-UID deterministic proof machinery, not hostile-code isolation.

Exercise real start failure, nonzero exit, malformed/over-limit output, blocked
stdin, deadline, cancellation, TERM/grace/KILL, direct-child reap and group-clear
for supported fixed children. Observe no survivors; do not infer cleanup merely
from a label. No unsupported host may be reported as having passed POSIX tests.

### Workspace, capsule, and D2 handoff

Verify exact three-file artificial base and one permitted replacement. Reject
traversal/absolute selections, symlinks, hardlinks, special files, mode drift,
addition/deletion/rename, extra changes and byte ceilings. Capture all exact
before/after bytes and modes without trusting worker claims.

Parent must construct the manifest and a separate verification path must
reconstruct from immutable base plus capture, check lineage/fence/path/mode/
hash/length/portable-digest bindings, and invoke the existing capsule relation.
A worker-authored manifest or forged output field is rejected. The artificial
base Git OID remains a supplied WorkSpec coordinate, not authenticated Git truth.
No Git operation is needed for this proof.

Workspace is removed before `capsule_ready`. Only parent-owned disposable state
outlives handback until explicit close; no open writer is retained. D2 must be
able to consume the exact manifest, bytes/modes, selection/phase lineage and
process evidence in that same parent lifetime. Do not implement D2 to prove this
shape. No validator, independent reviewer, review model, post-execution closure,
C2 decision/acceptance/terminal write, migration 0005, live provider/supplier,
network, public CLI/service, ES/Bridge or publication effect is permitted.

## 8. Remaining status and governance acceptance checks

Inspect all 29 candidate diffs against their owning HEAD contracts. Scope status
claims to D1; do not mistake all RW0-D or autonomy for implemented behavior.
The accepted implementation amendments supersede historical global absence
assertions only for named D1 owners, not their substantive authority limits.

Verify literal protected identities in BOTH owning tests:

```text
AGENTS.md: 62,778 bytes
076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6
README.md: 46,898 bytes
dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff
```

No dynamic expected-hash derivation, ignored observations, no-op comparison, or
changed ownership class. Five Capability status projections stay normalized;
Capability remains pure/no-I/O/non-authoritative while D1 mechanics have their
own owner. The temporary C2 full-source manifest is explicitly superseded, with
scoped guards still detecting prohibited C2 writers/callers/exports, acceptance,
terminal runtime, activation and migration 0005. Do not reintroduce another
whole-source manifest to freeze D1 by inertia.

Require exactly nine D1 modules and one subprocess owner. Preserve pure-module
no-I/O, package-root nonexports, no console script/service, current durable
owners and existing migration bytes. An authorized B1/Wire value import is not
permission to execute a writer, decoder or authority relation in handback.

## 9. Finite causal and transformed-copy evidence

Do not replace the audit by a larger generic fuzz/mutation framework. Keep
independent expectations outside mutated subjects, preserve normal parse/import/
collection, and record exact selected tests and their failure boundary. A syntax,
import, collection, unrelated inventory, or simply injected false assertion is
not credit for a runtime semantic regression.

Reproduce the sixteen reported repair controls against FINAL bytes:

| ID | Deliberate regression | Required discriminating evidence |
|---|---|---|
| R01 | arbitrary object/extra metadata handback slot | fixed inventory/type guard rejects |
| R02 | ready without mandatory stage/Wire/capsule evidence | ready invariant fails |
| R03 | raw live state root inserted into ACTUAL returned handback | actual-run closed-graph test fails |
| R04 | creator-PID fence removed | real fork custody test detects deletion/access |
| R05 | selector close escapes | integrated cleanup test detects wrong error/result |
| R06 | process evidence erased during cleanup failure | recorded process field/trace fails |
| R07 | cleanup becomes stopped/durable_conflict | exact cleanup classification fails |
| R08 | group-clear observation omitted on close failure | causal cleanup trace fails |
| R09 | frame membership precedes exact type | malformed canonical action test fails |
| R10 | frame error becomes durable conflict | integrated planner-frame test fails |
| W01 | remove Wire handback allowance | actual exact Wire dependency fails guard |
| W02 | widen Wire symbols/import form | fixed forbidden-symbol/form control fails |
| W03 | widen Wire consumer set | independent unapproved consumer control fails |
| B01 | remove B1 handback allowance | actual exact basis dependency fails guard |
| B02 | widen B1 symbols/import form | fixed forbidden-helper/form control fails |
| B03 | broaden B1 importer set | independent unapproved consumer control fails |

Direct owner/projection controls additionally reject each one-sided version/row/
role drift in the primary B1 expectation and phase-entry expectation. Do not
claim that a common parser returned the same value constitutes two independent
expectations.

Complete the material safeguards left unfinished by the original blocked audit.
For each category below, use one bounded transformed candidate copy and an
unchanged permanent test where one exists. A single copy may cover two closely
related checks; record that mapping rather than multiply identical work:

- replaced program writer/Section 41 result with fixture/harness truth;
- worker contact before C1, or advancement after unresolved durable recovery;
- database path/inheritable descriptor exposed to a child;
- process reap/group cleanup removed;
- worker manifest trusted or independent capsule verification removed;
- extra/link workspace mutation allowed;
- second subprocess owner or additional D1/D2 module admitted;
- prohibited C2 module/call/export admitted after manifest supersession;
- dynamic derivation of protected AGENTS/README identities.

Some categories overlap R01–R10 or prior direct fault specimens. Cross-reference
real evidence where the same check discriminates; do not count it twice as
independent coverage. State explicitly which probes are candidate-permanent,
audit-authored, controlled source-text guards, transformed copies, or static
inspection. A required permanent guard that remains green for its named defect
is a test-causality finding even when an audit-only oracle detects that defect.
The audit cannot authenticate arbitrary coordinated rewrites of all mutable
sources and expected values; exact provenance and the independently fixed
acceptance obligations provide that boundary.

## 10. Exact final validation

After provenance passes, prepare one fresh remote-free local-only clone of exact
HEAD overlaid with all 46 FINAL candidate endpoints. Verify all 263 repository
files before tests. Keep fault-injected copies separate so the final normal-run
clone is never credited after a late edit or mutation. All execution is external.

Command shape from that clone:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-group-paths>
```

Use separate collect/run basetemps and serial groups. No warning suppression,
xdist, test removal, overlap, network, dependency installation or live import.
Each token below expands to `tests/test_<token>.py`. Sort and deduplicate ONLY
within its group, preserving group membership.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12: NO path arguments; full repository collection, currently 124 test
modules. Do not find a selector merely to reproduce a preferred count.

For each sorted repo-relative test-module path, inventory serialization is:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file bytes)
```

Required reported final coordinates to reproduce:

| Group | Test files | Reported unique nodes / passes | Inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 92 / 92 | `2beb9ecda4ce8636339f5d3fe8f93526c0242cae9c1e498cf27f15a01da76acf` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 123 / 123 | `b604716da90279bfed0435ca559476723ba760cf4f2e8341b8e01ff39c9d678b` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,773 / 1,773 | `1c4f3fc6edc6b3561d426d52d2cd8b4ea8c65ea979311cf151f906d0f4190e8e` |
| 11 remaining changed owners | 6 | 667 / 667 | `735184692416af1ce727d3a8d2add0b7e4fe2eb1218a294194602503220d7ea8` |
| 12 full repository | 124 | 8,942 / 8,942 | `ee5f6ca268c6f9f1e61ecfa86e6a9415b1e6b6b1f758228a93a94e8d9a6d8ef4` |

These are candidate-specific test evidence, not a demand to alter tests until a
number fits. Reconcile actual node IDs and any platform failure honestly.
Groups 1–11 report 3,615 DISTINCT nodes; only group 2/3 overlap (46 nodes) and
7/11 overlap (19 nodes). All must be in full collection. Never sum overlapping
passes as unique repository coverage. Useful arithmetic from the initial D1
candidate is 8,877 + 35 runtime-test additions + 6 Wire + 19 B1 + 5 phase-entry
= 8,942. The latest 92 D1 tests were unchanged during the B1 coordination step.
Only actual collection and execution establish results.

Groups 10 and 12 each report the same three existing Python 3.13 multithreaded
fork DeprecationWarnings, attached to:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Inspect structured records; repeated warnings in overlapping selections are not
new warning kinds. Additional warnings or unsupported required POSIX/fork tests
must be investigated, not suppressed or called passed.

Also require read-only `git diff --check`, all 17 addition no-index whitespace
checks (ordinary difference status 1 is expected without diagnostics), strict
encoding/final-LF checks, exact candidate path/type/mode inventory, package/
export/script preservation, migration 0005 absence, unchanged current source
owners, and pre/post equality of all 263 clone endpoints.

A clearly identified audit-harness error may be corrected outside the live
checkout; rerun every affected probe/gate from the same exact candidate and
state the correction. No candidate repair is authorized. No claim of final
validation may use a superseded copy or interrupted run.

## 11. Early block, cleanup, and preservation

An immediately reproduced material defect can justify stopping expensive tests,
but not an ACCEPT result. State exact completed, interrupted, and unperformed
gates; never reuse implementation passes as this audit's results. A finding is
not permission to repair or to widen the operating model.

Account for every audit-owned child PID/group and disposable state root,
including roots intentionally leaked by broken close/handback mutants. Observe
termination before guarded cleanup; never sweep arbitrary processes or temporary
paths. Use lstat for artifacts, hash only regular files, do not follow symlinks or
open FIFOs/sockets/devices. Remove only positively identified audit-owned roots.
If cleanup cannot be proved, report the actual residue without claiming success.

After cleanup, recompute live baseline coordinates/index, all 46 endpoints and
replacement identity, all 217 noncandidate HEAD entries, and complete live cache
directory/member metadata including nanosecond mtimes. Historical omissions
remain explicitly unproved; this audit's complete opening record is mandatory.
No retained report/package is needed or authorized.

## 12. Verdict and inline closeout

ACCEPT only if exact final provenance and preservation pass; all four original
runtime defects are independently closed; Wire/B1 consumer extensions and both
fixed B1 projections are narrow and causal; actual guarded durable flow, child
isolation, supervisor cleanup, independent capsule, handback/state custody and
D1/D2 boundaries hold; material originally unfinished audit obligations are
completed; all twelve final validation groups pass; and no unresolved High or
Medium in-scope finding remains.

Use exactly one final token:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
```

The expected meaning of ACCEPT is eligibility for a separately issued commit/
publication gate for these exact 46 files. It grants no edit, stage, commit,
publication, D2/C2 work, migration 0005, supplier/live-source qualification,
enrollment, deployment, ES/Bridge action or RW0-E execution in this task.

Return inline:

1. Verdict and visible settings; exact baseline and inspected scope.
2. Final 46-endpoint/recipe reproduction and noncandidate/cache preservation.
3. Closure or remaining defect for each of the FOUR original findings, with
   actual direct specimens, traces and path/line evidence.
4. Wire and B1 field/type/role mappings; exact version-3 projections; retained
   permissions and permanent negative-control results.
5. Actual one-invocation durable trace, replay/recovery stops, child boundary,
   capsule independence, state lifetime and remaining D2 capability gap.
6. Original broad guard/status obligations, scope changes versus HEAD, and
   explicit absence of further domain/public/runtime authority widening.
7. Permanent/direct/transformed/static evidence matrix with exact selected
   tests, discriminating failures, survivals and limitations. No double credit.
8. All twelve exact commands, module hashes, node counts and overlaps, warnings,
   failed trials, harness corrections, omissions, process/root cleanup.
9. Severity-ranked findings or explicit no remaining material in-scope finding.
10. Continuation capsule <=1,000 words naming the exact candidate and next gate.

Do not deliver a mutation or implementation prompt. Preserve the retained work.
