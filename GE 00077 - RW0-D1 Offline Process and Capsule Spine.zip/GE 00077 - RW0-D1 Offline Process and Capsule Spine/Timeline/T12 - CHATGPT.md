## Disposition

**Proceed to a fresh independent read-only audit of the exact 46-path RW0-D1 candidate. Do not stage or commit it.**

Codex returned the intended implementation outcome:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

There is no deterministic pre-audit blocker in the closeout. The candidate now claims one private invocation that uses the existing guarded program, author-effect, Section 41, and RW0-C1 paths before launching separate planner and worker processes; the parent then captures the candidate, constructs and independently verifies the capsule, and returns a typed handback. Pasted text

This is the first candidate in this sequence that materially advances operating autonomy rather than only freezing target semantics. It is also the highest-risk candidate so far: nine new production modules, process execution, workspace mutation, resource custody, and coordinated changes to multiple historical assurance guards. Independent audit is mandatory.

## Why the candidate is audit-ready

### It appears to use the existing durable authority chain

The reported invocation order is:

```text
program initialization
→ author-effect establishment
→ separate fake planner
→ parent-built Section 41 bundle and durable selection
→ durable RW0-C1 phase establishment
→ separate fake worker
→ candidate capture
→ parent-built and independently verified capsule
→ typed handback
```

The closeout states that writer and state-authority resources are closed before each child launch and that unresolved durable recovery prevents later process execution. Planner content remains non-authoritative; existing Coordinator writers retain ownership of program, effect, selection, and phase facts. Pasted text

That is the correct authority model. The auditor must still verify the actual code path rather than accepting matching output values.

### The process and capsule split is coherent

The supervisor is reportedly the sole production `subprocess` owner and implements bounded I/O, deadline, cancellation, process-group termination, reap, and cleanup. Neither child receives the database path or writer authority. Pasted text

The worker mutates a bounded artificial workspace, but the parent—not the worker—constructs the accepted capsule. A separate verifier reconstructs the candidate from immutable fixture bytes plus captured after-bytes and invokes the existing capsule relation. The mutable workspace is removed before a successful handback. Pasted text

### Typed evidence and live resource ownership are separated

The handback reportedly carries typed lineage and evidence without carrying a database path, workspace path, session, descriptor, or authority proof. A distinct nonserializable parent-only owner retains disposable SQLite custody for D2 and removes it on explicit close. Pasted text

That is the right correction to the earlier map: evidence projection and resource lifetime are separate responsibilities.

### The broad guard changes are at least explicitly accounted for

The candidate advances:

- the protected `AGENTS.md` and `README.md` identities;
- the five normalized Capability status projections;
- the B1 consumer registry;
- the C2 temporary complete-source manifest into a scoped nonimplementation guard;
- the sole-subprocess-owner rules;
- the exact nine-module D1 inventory.

It continues to claim no validator, reviewer, review model, durable C2 decision, acceptance or terminal outcome, live provider, Git effect, or public service. Pasted text

These changes are justified only if the independent audit proves that the guards were **narrowed truthfully**, not weakened to accommodate arbitrary runtime code.

## Provenance and validation reconciliation

The reported candidate consists of:

```text
29 modified paths
17 created paths
46 total candidate paths
```

The endpoint-replacement identity is:

```text
4,422,240 bytes

SHA-256:
c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef
```

The component lengths sum to 4,422,215 bytes; together with the 25-byte recipe prefix, that reconciles exactly to 4,422,240 bytes. The closeout supplies all 46 endpoint sizes, hashes, baseline blobs, and component lengths. Pasted text

The final validation reports twelve successful groups:

| Group | Result |
|---|---:|
| New D1 tests | 57 passed |
| Program initialization | 218 passed |
| Author effect | 46 passed |
| Section 41 | 168 passed |
| RW0-C1 | 109 passed |
| Worker semantics | 135 passed |
| Wire | 117 passed |
| Capability | 60 passed |
| Bootstrap guard | 289 passed |
| Legacy guards | 1,754 passed |
| Remaining changed owners | 656 passed |
| Complete repository | **8,877 passed** |

The complete-suite increase over the prior merged baseline of 8,812 is 65 tests. The seven new D1 test modules account for 57; the remaining increase can come from the modified owning/guard modules. The independent auditor must reconcile actual node identities rather than infer correctness from the arithmetic. Pasted text

Codex also reports that the final validation was rebuilt from the final bytes after development corrections, that no required group was skipped, and that package exports, scripts, existing source owners, and migrations remained unchanged. Pasted text

## Critical audit questions

### Actual durable ownership

The auditor must independently trace `run_rw0_d1_offline(...)` and prove that it invokes the current guarded private methods and recovery owners. Matching values assembled by the D1 harness are not enough.

It should instrument a real external-clone run and establish:

```text
actual program initialization
actual author-effect establishment
planner child
actual Section 41 selection
actual RW0-C1 phase commit
worker child
```

The worker PID must appear only after committed or exact-replay C1 phase establishment. Any unresolved durable operation must prevent the next child from launching.

### Child isolation

The strongest risk is not merely whether the child receives a variable named `database_path`; it is whether any authority-bearing channel survives.

The auditor should inject unique sentinel values and inspect:

```text
argv
environment
cwd
stdin
open file descriptors
```

No child may receive the SQLite path, state root, lock descriptor, writer session, writer proof, mutation lease, operation capability, credentials, or parent-only run owner.

### Supervisor cleanup

The audit must exercise blocked input, excessive stdout/stderr, timeout, cancellation, TERM/KILL escalation, direct-child reap, and group-clear observation. A returned timeout label is insufficient if a descendant remains alive.

### Workspace and capsule independence

The auditor should test symlinks, hardlinks, traversal, additions, deletions, renames, mode changes, multiple mutations, excessive bytes, and a forged worker manifest.

It must prove that the parent reconstructs the capsule independently from the artificial base and captured candidate, rather than revalidating a structure originally supplied by the worker.

### Handback and retained state

The typed handback must contain no live authority or location. The separate run owner must:

- retain the disposable database only for parent-side D2 use;
- hold no second program truth;
- have no open writer session after D1 returns;
- support idempotent explicit close;
- remove the state root on close;
- avoid relying on finalizers.

### Governance guards

The audit must aggressively test the changes that allowed this source tranche:

- Add a second subprocess importer: the historical guards must fail.
- Add a tenth D1 module or a D2 module: the inventory guard must fail.
- Add another B1 importer or imported symbol: the registry guard must fail.
- Add a C2 writer, caller, export, terminal owner, or migration `0005`: the scoped C2 guard must fail.
- Replace fixed `AGENTS.md`/`README.md` identities with dynamic derivation: the protected-identity controls must fail.

A green full suite is not sufficient if the candidate achieved it by weakening the relevant guards.

## Independent audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="11"}[Download the complete RW0-D1 independent-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Independent_Audit_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Independent_Audit_Prompt.txt

Bytes:
27,293

SHA-256:
a99edabf2505a9d95fca4516f5672205816621829fca80da909f3c7645c49eb0

Logical lines:
502

Final newline:
present
```

The audit prompt binds:

```text
Baseline HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,422,240 bytes
c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef
```

It includes the complete 46-path table and requires independent verification of:

- the actual durable call chain and recovery gates;
- process framing, supervision, cancellation, and reap;
- database/writer isolation across child boundaries;
- bounded workspace mutation;
- parent-owned capsule construction and independent reconstruction;
- typed handback and parent-only state custody;
- the D1/D2/C2 boundary;
- all coordinated governance and identity guards;
- independent causal specimens;
- fourteen transformed defect copies;
- all twelve validation groups and their inventory hashes;
- exact live-cache and checkout preservation.

Possible verdicts:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would authorize only a separately issued commit and publication gate for the exact 46 audited files. It would not authorize D2, RW0-C2 physical implementation, migration `0005`, live provider or supplier work, Git effects, ES/Bridge integration, or RW0-E.

Some older project uploads have expired. They are not needed for this audit; re-upload an older original only if a later task requires its exact bytes.

**Source:** Codex’s D1 implementation closeout supplied in this turn. Pasted text Pasted text  
**Confidence:** High that the candidate is ready for independent audit. Commit readiness remains unresolved until the actual durable authority path, process isolation and cleanup, capsule independence, handback custody, and narrowed governance guards survive independent adversarial verification.
