# Disposition

**Accept the operative implementation map, but reject its formal `RW0_D1_IMPLEMENTATION_MAP_REPLAN_REQUIRED` disposition.**

The map found no authority contradiction requiring product replanning. On the contrary, it concluded that the current guarded program, author-effect, Section 41 selection, and RW0-C1 phase paths can be composed, and it supplied an exact call order through them. The suggested D1a/D1b/D1c split is useful **internal implementation sequencing**, not a reason to create three additional tranches, branches, PRs, audits, or user handoffs. Pasted text Pasted text

The approved structure remains:

```text
RW0-D1 — one integrated source-bearing tranche
    internal Stage A: process spine and fake planner
    internal Stage B: fake worker, workspace, and capsule
    internal Stage C: durable composition and typed handback

RW0-D2 — evidence and cognitive-review closure

RW0-C2 — physical durable-state implementation
```

D1’s internal stages will be implemented and validated sequentially in one uncommitted candidate. Current-status documentation changes occur once, after the integrated D1 capability exists.

# Map findings accepted

The map correctly established the current runtime boundary:

```text
WorkSpec
→ guarded program initialization
→ guarded author-effect establishment
→ Section 41 selection
→ RW0-C1 no-contact phase
→ no process, workspace, capture, or capsule owner
```

Pasted text

It also correctly selected these implementation decisions:

- Always invoke the current program-initialization path; an arbitrary pre-existing database cannot become program truth.
- Establish the current author-effect lineage before planning.
- Close the writer and state-authority resources before every child launch.
- Let the fake planner author content and recommendation only; Coordinator constructs identities and records the Section 41 decision.
- Commit RW0-C1 phase establishment before worker contact.
- Use the existing author command, delivery, fences, and NWPF result grammar for the fake worker.
- Build the capsule in the parent from observed bytes, then reconstruct and verify it independently.
- Resolve durable commit uncertainty through the existing recovery owner before advancing; an unresolved durable operation blocks the next process. Pasted text

The proposed process boundary is also sound for this proof: package-private `python -m` children, absolute interpreter, no shell, new process session, closed file descriptors, allowlisted environment, bounded pipes, deadline, cancellation, signal escalation, reap, and no claim that this is a hostile-code sandbox. Pasted text

# Boundary corrections applied

## 1. D1a, D1b, and D1c are internal stages—not separate tranches

The map proposed three source-bearing increments because process supervision, workspace/capsule custody, and durable composition have distinct failure domains. That decomposition is useful, but it does not satisfy any of the original replan conditions by itself.

They are now internal stages of one D1 implementation candidate:

```text
A must pass before B is integrated.
B must pass before C is integrated.
Only integrated C may claim D1 implemented.
```

There will be no intermediate commit, PR, user relay, or standalone contract freeze.

## 2. The typed handback will not carry a raw state path or live authority handle

The map proposed putting a “parent-only disposable state custody handle” into the typed handback. Pasted text

That would blur evidence with resource ownership. The implementation prompt instead requires:

```text
RW0D1HandbackV1
    immutable, path-free, transient evidence projection

RW0D1OfflineRun
    separate parent-only, nonserializable resource owner
    owns disposable SQLite lifetime
    exposes .handback
    implements explicit close()/context management
    never enters child input, logs, capsule, JSON, or public errors
```

The handback contains no database path, workspace path, connection, writer session, lock, proof, lease, or capability. D2 will later consume the private run owner in the same parent process. Standalone D1 closes it explicitly.

## 3. The artificial fixture does not pretend to derive a Git commit OID

The map proposed computing a “Git base identity” from the artificial fixture bytes and modes. Pasted text

A Git commit identity is not derivable from file bytes and modes alone without the full canonical commit object. The implementation will instead:

- reuse the exact preassigned fixture `base_git_oid` already bound by the accepted `WorkSpecV1`;
- independently verify the artificial fixture’s exact files, modes, and bytes;
- verify capsule relations against that bound coordinate;
- make no claim that those fixture bytes authenticate or reconstruct a real Git commit;
- invoke no Git command and create no temporary Git repository.

## 4. Architecture status is part of the bounded status update

The map identified broad “no worker/no process/no capsule” assertions across status documents and owning tests. Pasted text

The implementation ceiling includes `.docs/architecture.md` as well as the map’s other status owners. That file currently contains repository-level no-worker and no-supervisor claims and must be narrowed once D1 is actually implemented. This is a source-bearing status correction, not a separate architecture tranche.

# Final D1 observable result

The integrated private invocation will execute:

```text
accepted WorkSpecV1 and bounded artificial fixture
→ disposable Coordinator database through migration 0004
→ actual current program initialization
→ actual current author-effect establishment
→ separate fake planner
→ actual current Section 41 selection
→ actual current RW0-C1 phase establishment
→ separate fake worker
→ one authorized workspace mutation
→ parent candidate capture
→ parent capsule construction
→ independent capsule reconstruction and verification
→ workspace removal
→ typed D1 handback plus separate parent-only state custody
```

There is no user relay between any of these stages.

D1 will leave the existing durable program, author effect, selection, and phase owners unchanged. It introduces no shadow lifecycle. The fake planner cannot select; the fake worker cannot accept; the supervisor cannot progress the program; the workspace cannot become program state; and the handback cannot become a C2 decision.

# D2 handoff retained

The map’s D2 handoff is accepted: D2 needs the exact manifest, immutable before/after bytes and modes, WorkSpec and selected artifact, author command/fences/delivery, worker observations and parent process facts, Section 41 result and receipt, C1 phase basis/result, artificial authority bindings, and access to the same disposable state through the parent-only run owner. Pasted text

D2 will reuse the D1 supervisor and process framing, then add:

```text
validator
→ independent reviewer
→ fake semantic-review model
→ typed evidence
→ post-execution proposal family
→ frozen C2-input projection
```

None of that is included in D1.

# D1 implementation handoff

Resume the **same Codex conversation that produced the map**, with the parent as sole writer. Use the highest exposed reasoning setting and attach nothing.

:chatgpt-content-reference{index="12"}[Download the complete RW0-D1 implementation prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt.txt

Bytes:
36,790

SHA-256:
7a9de7dac409f0a42826718db6306c54e0b8c5b8640862bc7ddd8200dc1ac2d2

Logical lines:
1,047

Final newline:
present
```

The prompt binds the exact merged baseline:

```text
Branch:
trunk_dev

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Sole parent:
630414faa07f4ac39c4a870a9cc44c7f92d46b80
```

It authorizes one integrated uncommitted D1 candidate with:

- nine package-private source modules;
- seven new D1 test modules;
- one D1 implementation-status owner document;
- bounded current-status amendments and their direct owning tests;
- no change to `__init__.py`, `pyproject.toml`, migrations, schemas, existing durable mutation owners, or frozen pure semantic modules;
- no staging, commit, push, PR, or merge.

It requires actual use of the existing private durable methods and recovery paths, not equivalent test-side construction.

The main success token is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

The prompt distinguishes:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPLAN_REQUIRED
```

for a concrete authority or boundary contradiction, and:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTATION_BLOCKED
```

for baseline, validation, or bounded implementation failure.

A successful result authorizes only a fresh independent read-only audit of the uncommitted D1 candidate. It does not authorize publication, D2, RW0-C2 physical implementation, migration `0005`, live providers, supplier qualification, Git effects, ES/Bridge integration, or RW0-E.

## Sources

Primary source: the attached Codex D1 implementation map, including its current call chain, proposed durable call order, process/workspace/capsule design, touched surfaces, D2 handoff, and implementation risks. Pasted text Pasted text Pasted text

The current snapshot-backed baseline was used only to check the map’s repository/status implications. Some older uploads have expired, but none is required for this implementation tranche.

**Confidence:** High on accepting the operative map and collapsing its three increments into one D1 tranche with internal stages. Medium-high on the exact touched surface until implementation exercises the production-private Section 41 and C1 constructors; the prompt requires a replan rather than path widening if those owners cannot be composed without shadow authority.
