# RW0-D1 V9 — PR #14 Squash Merge and Local Realignment Gate

## FIRST PROTECTED REPOSITORY ACTION — live guidance as text, workdir /

Use the same IMPLEMENTATION/PUBLICATION Codex conversation that committed the
accepted V9 source and opened PR #14. Parent only; no subagents or new audit.
This instruction separately authorizes one bounded MERGE gate, not source work.

First read live AGENTS.md as plain text, using tool workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read the complete output, using more plain-file reads if it truncates. Then run
section 1's filesystem-only opening BEFORE any Git command or remote contact.
Do not begin with generic git status, rev-parse, Git-backed settings discovery,
repository bootstrap, repository import, or parallel preflight.

Plain-data reading of an external instruction/attachment is permitted preparation;
prefer absolute external paths and neutral cwd. It may not include Git/index
operations, repository content/import/script, product-state access or mutation.
A repository cwd alone does not prove such effects; assess the actual command.
This does not excuse a real pre-opening Git operation. Stop on an actually missed
opening; do not silently replace the interval, reset the index or restore metadata.

## Decision and effect ceiling

The cognitive lead accepts the supplied publication closeout as the basis to
attempt this separately authorized integration gate. It reports:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_COMMITTED_AND_PR_OPENED`

Reports provide fixed expectations, not current remote facts. Verify every
required current condition before the first write. This gate authorizes, in order:

1. Read-only local source/index/worktree/receipt and fresh remote PR/policy checks.
2. ONE ordinary synchronous squash-merge request for PR #14, guarded by its exact
   source-head SHA, with the exact commit title/body below. No bypass or retry.
3. Independent remote readback of the merged PR, returned squash commit, sole
   parent, complete tree, message, signatures, trunk and preserved source topic.
4. ONE narrow fetch of remote trunk into its existing local tracking ref, only
   after that remote result is verified.
5. ONE expected-old-object update of local refs/heads/trunk_dev from the source
   commit to the verified squash, without touching index or working files.
6. Final local/remote verification, resource cleanup and inline closeout.

No per-step user approval after entry conditions pass. Do not return another
reconnaissance plan, architecture package or mutation prompt. Do not edit or
normalize accepted source/test/docs, stage, commit locally, amend, rebase,
reset, cherry-pick, checkout, create/delete worktrees or local branches, push
trunk/topic/tags, delete the topic, enable auto-merge, enter a queue, update the
PR branch, change rules/config/metadata, approve/dismiss/resolve reviews, dispatch
CI, publish a release, or deploy. No alternate merge method or repeated request.

No tests, collection, mutants, repository imports/scripts, D1 child execution,
SQLite access, migrations, installs, live provider/supplier/credential creation,
D2/physical-C2/terminal work, ES/Bridge/RW0-E action, or sibling-repository access.
Installed standard-library data/hash helpers and normal Git/gh/API inspection are
allowed; do not execute candidate code. Existing configured credentials may be
used through their normal interfaces without exposing secrets or switching actors.

Permitted writes are only the remote merge and its normal hosting metadata, the
narrow fetch's object/tracking/FETCH_HEAD bookkeeping, and the expected local
branch/ref/reflog update. The source tree, index bytes/metadata and live cache
remain unchanged. Do not mistake authorized object/ref changes for an index write.

The earlier acceptance audit and staged-byte publication validation are complete
for their stated scope. This gate does NOT rerun them. A changed source/tree/base
blocks this gate instead of initiating another validation or repairing the PR.

D1 remains the private artificial fake-planner/fake-worker proof. Publication is
an explicitly authorized Codex/GitHub action, not an automatic D1 runtime effect.
D1 integration is followed by a refreshed snapshot, then D2; physical C2 follows
D2. None of that later work is authorized here.

Use the highest exposed reasoning setting; record visible model/effort and
permission posture or `not visible`. Seek no additional account/computer access
to expose hidden settings. Return operative evidence INLINE with exact paths,
commands/results, timestamped remote observations and effects/limits. No delivered
report, manifest, patch, archive, freeze package or snapshot is required.

## 1. Fixed entry coordinates and pre-Git preservation

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

```text
local checked-out branch: trunk_dev
HEAD / refs/heads/trunk_dev (source):
f0e3169c55fad62d8d830d9fc799263d7c5332f1
source tree:
cc3cc104300f553ada581cee24e80dab6dd885b1
source sole parent / required remote base:
0d0926e3a483a3ab1a4fd597ac0495927352bf35
parent tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4
parent sole parent:
630414faa07f4ac39c4a870a9cc44c7f92d46b80
source subject:
feat: add RW0-D1 offline process and capsule spine
upstream: origin/trunk_dev, locally at the required remote base
opening local divergence: 1 ahead / 0 behind
worktrees: exactly one
HEAD: symbolic to the direct local refs/heads/trunk_dev ref
index: 263 stage-0 entries, exactly the source tree
working tree: clean; no staged/untracked/unmerged/unstaged paths
active operations/sequencer/unexpected locks: none
```

The previous gate's post-commit index hash was
`7af425d5a47b91b0a14294660f5d449f5ba6308dc8846a8b13aca371c191a587`.
It is a prior observation, not a substitute for the fresh record below. Verify
logical equality to the fixed source, capture the ACTUAL opening index bytes and
metadata, and preserve them throughout this merge interval. Do not set timestamps
or demand an old inode as if it proved this opening. Investigate any unexplained
logical drift; do not normalize a harmless historical physical difference.

After guidance, execute this data-only opener from `/`. It performs no Git,
repository import, database access or test. It records index/cache before Git and
writes only temporary external instrumentation. The strict read helper requires
this merge interval's opening index content/metadata throughout; unlike the prior
publication gate, no staging or write-tree is authorized.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d1-pr14-merge-gate-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d1-pr14-merge-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This merge interval only. Index, source payloads and cache stay fixed; only the explicitly authorized remote merge, narrow fetch and guarded ref update may change Git object/ref bookkeeping.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('merge_gate_index_content_or_metadata_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('candidate_guidance_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index content and metadata equal this merge opening; no stage or index write is permitted.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref', 'reflog'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nif args[0] == 'reflog' and (len(args) < 2 or args[1] != 'show'):\n    raise RuntimeError('readonly_reflog_show_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_PR14_MERGE_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use the ACTUAL emitted paths. Do not assume shell variables persist or recreate
the opening record. Every live Git read admitted by the helper uses it:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
```

The helper is not an OS interlock. It enforces per-subprocess optional-lock,
lazy-fetch and prompt suppression, disables external diff/textconv/fsmonitor,
and checks the original index/cache before and after each admitted read. Its
marker is not complete source authentication or merge permission.

Narrow configuration/remote metadata reads needed by section 4 and the two
specified local writes use equivalent command-local suppression and preserve
index/cache around each action. Do not bypass a failed helper with raw Git.
Missing objects, unexpected overrides or unsupported required inspection block
rather than authorizing fetch before its permitted step or a config change.

External attachments may be read as data under the opening qualification above.
Actual pre-opening Git/import/test/write remains a stop. There is no need to
investigate speculative invisible startup hooks or reconstruct older intervals.

After authentication, give one compact opening acknowledgement and proceed
without another user checkpoint.

## 2. Exact committed source and accepted endpoint relationship

The source and required squash trees have exactly 263 leaf files. All 46 changed
paths below are NOW tracked and present in source and index. `M` and `C` are only
classifications RELATIVE TO ORIGINAL PARENT 0d0926e3...; C is an original addition,
not a claim that the live file is still untracked. The other 217 entries equal
that parent. The parent has 246 files. Source has precisely 29 replacements and
17 additions, no deletion/rename/submodule/symlink/executable-bit change.

All 46 endpoints: regular nonsymlink OS mode 0644, Git mode 100644, strict UTF-8,
no BOM/CR/trailing whitespace, one final LF. Preserve the unrelated baseline
nonexecuting mode-0600 program-initialization test and every actual noncandidate
mode; do not impose 0644 on all files or normalize anything.

| Effect vs original parent | Repository-relative path | Bytes | SHA-256 | Original parent blob | Source / required squash blob | Git mode |
|---|---|---:|---|---|---|---|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | `7d21418a68d2d3002753227da08cf059836d0260` | `100644` |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | `3524d11d67a46344214b455396afeeaa3754b41d` | `100644` |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | `a46d51fe3ea480e39c8c7989a08e80d9db21f5b8` | `100644` |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | `04c068d07cd08feaf6c56dafbf3494ccde037ede` | `100644` |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | `49694cd86a51f3fb0fb3799e734a52c1a395b8c7` | `100644` |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | `5b7fb0072c6d04898cd212fdc4ff5f63903cf13b` | `100644` |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | `5e41d1cb3b2f430d29eb88bdbf2b46570faf3c6b` | `100644` |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | `56a0d057ec833234edc2dc7345a11706b9446b80` | `100644` |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | `4b69e424655ea67900f6c6042c0cbacaf2d53f8a` | `100644` |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | `f3557ca523cac0d6fa26647b17a84aef66fecc15` | `100644` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | `230167a39b115634c8f9b5ae5a0699639f6ff454` | `100644` |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | `464aef2aa7a561e4adc6792d1d07642d3576f364` | `100644` |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | `254854d4a57487d97ce02a73ce2ed26c86ece170` | `100644` |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | `088c832ca7e28d18c82ff6317738ac8ca1c7b5d1` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | `6b736bfb2309aabcf79e62215162194f3e0433e6` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | `7083f5e25a1dea40d48ae02e2d3a4f868a369719` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | `cb37f733141f1e3c3ce874fcc052149de1f82881` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | `ecfcf767a5f1c32c0cf007a2c8aa3137ef92374d` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | `4f2a82e46fda9be8123888f5ca46968a4345c25f` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | `c8a89d5f947d4b2e34bc3b453ef553fcc6621e49` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | `71b1a48fe6e6484ed981aeacead41107a30e0af7` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | `7dc90a0442e348aaac985d711c4d1a97adb7cc05` | `100644` |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | `b263e08f5ea1444107feefbdd4a9b24310bace65` | `100644` |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | `c595611ac47ebe2c12d522886150aa4ec1975e67` | `100644` |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | `ccadd884de29d606c9243ea7796cc380e29fe5c2` | `100644` |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | `8fe2591a233881b1cec6066ba88663df127a2b27` | `100644` |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | `3f343ae5886c92941ebfff63ba4213de2109025e` | `100644` |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | `b910d61aaf670ba40a0d649f933c06767e7360e5` | `100644` |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | `437a4e7cbd39682bdd08f03b3a30c0bbbd057614` | `100644` |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | `79d4ab185815234c9d087c48d2439b9a1d95d95d` | `100644` |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | `17d1e09c30b01287718c6b5175bac76b03daf458` | `100644` |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 50,244 | `cadcb41f652a539b5e2ac50ca6fe0bc192e321a663ac338ff9a2516d7d0b5844` | `b61f1744059a87988bff7bde032f3b578a554b18` | `4668d2a2c285d2d79bf6ebfb0c9c9f60166bcb27` | `100644` |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | `9e04f528326a6f337a4f47e7e9f9eda3c9a82e0a` | `100644` |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 120,405 | `44089176794734a285afd3852c97fddcfd073fb6d99d2d68667b91952d392921` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | `0f0159c172e1448d2b96ab19411e1f85467a2931` | `100644` |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | `e9d95b54a4b5921be8ec39d2bf3f6216204750c7` | `100644` |
| `C` | `tests/test_rw0_d1_handback_values.py` | 26,977 | `bdf1f78b9a359dfbc36c768e8bb44b2151de8bcaf74046401e4f8a9c20d73807` | `absent` | `982be9b37aa05db0c6d6a3321b775c7c64f2142d` | `100644` |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 53,116 | `21796d33330e62b4a389207063022e44c5458a4fe847e509f33d247b65b80afe` | `absent` | `33c2d85012cbdf0e7e04fdeb7d333d2c8675ae3f` | `100644` |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | `83f5e030775da163636b02fec078be23fd3a6e33` | `100644` |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | `063af4114bdcbb9ed80d5c39131622b7f8da80ca` | `100644` |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | `4ed2162e5fd09f202cf8be93cb10752c91aa1bf8` | `100644` |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | `e2a83abe44db720b5ce0725682ac71d30372959d` | `100644` |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 9,390 | `381ff379133bacd6264942cfea26af0cdf8ddbfdb424f77ea9e82fb9d6ad2264` | `absent` | `6b1a2fdbb1efd9e87cc6ae59510a47a238061070` | `100644` |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | `2a9144c3dfd2c883555703c8adecd21f447d6d34` | `100644` |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | `30943e75803e6ada6854c563a5b41e6d03c173a6` | `100644` |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | `855664f6e28cdcfaf79c8d391323c36b0aa24c77` | `100644` |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | `c646df6d439d0b70f45d6d72200fbedb5e730779` | `100644` |

Before merge, read all original M blobs from the fixed original parent; check all
C paths absent THERE, not absent from source. Read all 46 source blobs directly
and require the fixed Git OID, byte size and SHA-256, plus equality to index and
working payload. Confirm all 217 unchanged source/index/working entries equal
parent blob/mode and bytes. Exclude the opaque live cache from the 263-file set.

Read the raw source commit. Require exact OID, sole parent, tree and message;
record configured author/committer as observed. The closeout reports both raw
identities as `AlacerMortis <david.shaw.dev@gmail.com>` and the source unsigned.
Do not amend its identity or add a signature. Verify platform attribution and
current applicable signing requirements separately; an unsigned source is not a
signed object merely because a later squash may be signed.

Source/index/worktree must remain clean and source-exact until and after merge.
Do not use `git write-tree` to check equality: it may update the cache-tree index.
Use direct stage-0 and tree/blob reads or inert tree encoding instead.

### Fixed parent-relative endpoint replacement stream

Independently reconstruct twice from fresh reads; one concatenating and one
streaming calculation are suitable. Keep original-parent coordinates throughout:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw ORIGINAL PARENT blob bytes, or twenty zero bytes for C
    u64be(payload_length)
    exact source/working/squash payload bytes

rows: 46 (29 M / 17 C)
encoded row bytes: 4,557,431
prefix: 25
total: 4,557,456
SHA-256:
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

This is a stream of RAW PAYLOADS, not their digest strings. No new manifest or
post-merge reclassification can replace it. A report/hash does not authenticate
live payloads until these direct checks agree. Run read-only tracked diff and
whitespace checks as relevant; source is clean, and parent-to-source effects
must remain exactly the table. Do not execute source, validators or repo tests.

The gate author checked the tree-encoding arithmetic using snapshot baseline
payloads plus the supplied new blob OIDs; it yields the fixed source tree above.
That corroborates reported coordinates, not independent possession of candidate
payloads. This gate must authenticate the actual raw Git and working bytes.

## 3. Exact PR and message bindings

```text
GitHub repository: evo-agi/Governed-Execution-Coordinator
expected authenticated actor: SeritArbores
PR number: 14
PR node ID: PR_kwDOTYw1Ic8AAAABJIHYjg
PR URL: https://github.com/evo-agi/Governed-Execution-Coordinator/pull/14
base ref: trunk_dev
base OID: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
head ref: codex/rw0-d1-offline-process-capsule-spine-v1
head OID: f0e3169c55fad62d8d830d9fc799263d7c5332f1
head repository: same repository, not a fork
opening PR: OPEN, non-draft, unmerged; one commit; 46 file effects
PR title and selected squash title:
feat: add RW0-D1 offline process and capsule spine
```

All remote coordinates are required conditions to freshly check, not assertions
that they are still true. An already merged/closed/draft/moved PR at entry blocks
this gate's writes. Report observed state; do not reopen, update, rebase or choose
another PR. No merges initiated by another actor are silently adopted as this
request's result.

### Original raw source message (one final LF)

```text
feat: add RW0-D1 offline process and capsule spine

Add one private artificial offline invocation through the existing guarded
program initialization, author-effect, Section 41 selection, and RW0-C1 phase
owners, with separate deterministic fake planner and coding-worker processes.

Bound process lifecycle, child inputs, workspace mutation, parent-owned capsule
construction and independent verification. Return transient typed evidence with
separate creator-process-fenced disposable-state custody, not shadow program
truth. Preserve the existing durable and pure semantic owners.

Include the reviewed status/consumer updates and permanent causal safeguards.
The independent V9 audit qualified prior evidence and completed its ledger;
publication remains a separate human/Codex effect, not D1 runtime behavior.

No D2 validation/review/model closure, physical C2 decision or acceptance fact,
terminal outcome, migration 0005, live provider/supplier, ES/Bridge integration,
public service/CLI, or automatic Git/publication capability is introduced.

Audit: RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
Audited replacement SHA-256:
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

Exact source-message receipt:

```text
1,222 bytes
1e328192097185536ea7002562000769bfd1d25562ea97b9cc3bb0ce11b0900e
```

The source title is 50 UTF-8 bytes. Split the exact source message on the FIRST
blank-line separator only. Its body is 1,170 bytes including its ONE final LF.
For the merge request remove only that last LF from the body:

```text
request commit_message body: 1,169 bytes
c76d7d63deae0c18540081226db01313de7e8c613f7974ab2e20b4c76aafe2fe
```

Do not use the PR body as a squash message, regenerate prose, collapse wrapping,
append a PR number or co-author, or run `.strip()` on arbitrary message content.
The supplied local raw source message is authoritative for source verification.
The publication API reportedly omitted the final LF in its JSON presentation;
that is not evidence of different raw object bytes at the same commit OID.

### Exact PR body

The previously requested body is the following text with ONE final LF. Inspect
and verify; this merge gate may NOT edit it.

```markdown
## Summary

Implement the private artificial RW0-D1 process and capsule spine. One bounded
WorkSpec/fixture invocation uses the current guarded program, author-effect,
Section 41 selection, and RW0-C1 phase paths; launches separate deterministic
fake planner and coding-worker processes; captures one bounded candidate; and
constructs and independently verifies its capsule before returning typed evidence.

The existing Coordinator writers remain the durable authorities. The handback
is a transient projection. A separate creator-process-fenced owner retains only
the disposable-state lifetime needed for the later D2 handoff.

## Audit and validation

The exact 46-file V9 candidate received independent commit-gate eligibility.
That audit combined a new valid preservation interval, complete review of the
five amended tests, a predicate-level causal ledger, current four-family
readback, and explicitly qualified prior independent experiments and validation.
The earlier attachment-read/workdir nonconformance was not erased or called
compliant; its actual operations and pre-Git observation interval were examined.

Audited replacement: 4,557,456 bytes.
SHA-256: 53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0

This publication gate independently validated the exact staged tree in a fresh
remote-free external clone: 124 modules, 9,005 tests collected and passed, with
only the three existing Python 3.13 writer-session multithreaded-fork warnings.
The gate did not repeat the independent mutation campaign.

## Scope limits

This is fake-model/fake-worker offline proof behavior, not competent autonomous
coding, qualified live custody, restart-safe orchestration, or a hostile-code
sandbox. It introduces no D2 validator/reviewer/review-model closure, physical
C2 decision/acceptance family, terminal runtime, migration 0005, live provider or
supplier integration, public service/CLI, automatic publication, or ES/Bridge call.

Selected sequence remains D1, then D2, then physical C2. This PR requests ordinary
review of the exact accepted files. It does not request merge, auto-merge, a queue,
a deployment, or execution of RW0-E.

Audit: RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
```

Require the reported retained 2,235-byte form, SHA-256
`66483c0c6f377c15c3c9f1ce61678675a13094a454ec6017bb3e328f3703051a`.
The only already admitted presentation alternative is omission of that ONE
final LF: 2,234 bytes, SHA-256
`912775d9469b87fc5dd96d13acebe31104442c1fd4694b5dd4069f5ed49d97c2`.
Accept no other hidden/generated/edit difference. Record which form was read.

PR text describing the preceding publication gate's non-merge request is
historical context. THIS new instruction supplies the separate merge authority;
it requires no PR-body edit to turn that earlier publication into a merge gate.

## 4. Fresh policy, readiness and external effects BEFORE a merge request

After correct opening and complete local authentication, use installed Git/gh/API
read-only operations through normal configured access. Check expected actor
freshly; do not read token/key/env files, run login, change account or scopes, or
print credentialed URLs. Never equate local upstream equality with fresh remote
truth. Inspect all paginated inventories completely and record UTC times.

Require and report:

- The effective origin fetch and push identity is the specified GitHub repository;
  one intended endpoint, no mirror/URL rewrite/unexpected push refspec or alternate
  target. Do not mutate configuration. Inspect existing relevant hook paths as
  data. Any active unreviewed hook affecting the authorized ref/fetch operations
  blocks; do not disable hooks to bypass it. Inactive sample files are not active
  hooks. No candidate filter is to be invoked during this no-checkout gate.
- Fresh authenticated actor is SeritArbores. PR author/source attribution must be
  consistent with that existing publication; read author/committer attribution
  and current conditional attribution-approval requirements. Do not assume the
  old zero-review rule still applies or infer attribution from display names.
- Remote base equals the fixed parent, topic equals the fixed source, exact PR
  number/node/repositories/ref names/author/title/body/commit list/file effects
  match; source has the required sole parent and exact nontruncated full tree.
- List remote branch heads for preservation; distinguish hosting-generated PR
  refs and directories in recursive trees from user branch heads and file leaves.
  Require no auto-merge or queue entry for this PR. Preserve the source topic.
- Read CURRENT effective repository/organization rulesets and applicable classic
  branch protections, not just a previously named ruleset ID. Check required PR
  route, allowed squash, reviews/code owners/last-push or attribution approvals,
  thread resolution, checks/status contexts, signing, required deployments,
  merge queue and all other constraints that actually apply to this branch/PR.
- Read current reviews, requested/actual changes, comments and review discussions
  sufficiently to identify material unresolved issues. Required approvals and
  conversations must be satisfied by existing records. Do not approve, dismiss,
  reply, resolve threads or change the PR to make it mergeable. A new substantive
  unaddressed authority/runtime/security concern blocks even when a counter is
  zero; report it for the existing owning review.
- Read check runs, status contexts, relevant workflow runs and mergeability/state.
  Required results must satisfy fresh effective policy. An empty inventory and
  combined `pending` status are NOT a CI pass. If no status rule applies and the
  inventories truly are empty, report 'no required checks / no contexts' rather
  than fabricate a successful CI result. Nonempty pending/failing meaningful
  checks or contradictory observations require resolution, not bypass.
- Reconcile REST/GraphQL mergeability if both are used; unknown/calculating state
  receives at most bounded read-only rechecks in this invocation, no background
  watch or automatic deferred merge. Do not proceed on contradictory/unresolved
  readiness, regardless of earlier `clean` observations.
- Confirm ordinary squash merge is enabled and the normal non-bypass route is
  permitted. No --admin, bypass actor use, rebase/merge-commit alternative,
  auto-merge, queue request or update-branch is authorized. If mandatory queue or
  incompatible policy now applies, stop before a write rather than changing it.
- Verify automatic source-branch deletion is disabled or otherwise positively
  excluded for this exact ordinary operation; this gate must preserve the topic.
  Do not change the setting. Inspect source/base workflow and relevant active
  webhook metadata for merge-triggered effects without printing secrets/URLs or
  invoking endpoints. A known/ambiguous out-of-scope deployment or other prohibited
  effect blocks. Normal hosting notifications, audit logs, merge bookkeeping and
  policy-compatible check execution are inherent permitted effects, not authority
  to activate D1 or a separate runtime. No manual dispatch or deployment approval.

The closeout reported no active hook/workflow/webhook and squash-only base rules
with zero ordinary approvals. Those are PRIOR publication observations, not
current policy. All above conditions must be observed anew.

Immediately before sending the request, re-read the exact base and topic, PR
head/state/text, meaningful policy/readiness and local source/index/worktree/cache.
Require the same fixed identities and no competing change. Timestamp this final
pre-request observation. Do not reuse an opening result from before a long
inspection as an atomic guard.

## 5. One synchronous head-SHA-guarded squash request

No GitHub write is authorized before sections 1-4 pass. Send ONE request only:

```text
PUT /repos/evo-agi/Governed-Execution-Coordinator/pulls/14/merge
```

The object has exactly FOUR string fields:

```text
commit_title: exact title in section 3
commit_message: exact original source body WITHOUT its last LF
merge_method: squash
sha: f0e3169c55fad62d8d830d9fc799263d7c5332f1
```

Build UTF-8 JSON with recursively sorted object keys, separators (',', ':'),
ensure_ascii=False, allow_nan=False, and NO trailing newline. Reconstruct twice
from the verified source-message data and require:

```text
request bytes: 1,350
request SHA-256:
097203cb7b0fee9ed08b8c23221bb5dae6f466e433a75f326527981358ef2eda
```

Store only under the gate-owned mode-0700 external root, with request-file mode
0600. The request hash binds its content, not current permission or eventual
execution. Do not print credentials or include authentication in that JSON.

Use an ordinary synchronous installed API client; a supported command shape is:

```sh
gh api --hostname github.com --method PUT \
  -H 'Accept: application/vnd.github+json' \
  -H 'X-GitHub-Api-Version: 2022-11-28' \
  repos/evo-agi/Governed-Execution-Coordinator/pulls/14/merge \
  --input <ACTUAL_VERIFIED_REQUEST_JSON>
```

Use no retry loop, --admin, merge-queue/auto-merge wrapper, or second invocation.
Verify installed client behavior sufficiently to avoid hidden write retries; if
it cannot meet this gate, stop rather than install another tool or invent an
unguarded write. Use normal existing credentials without changing configuration.

IMPORTANT: the sha field guards the SOURCE HEAD. It is NOT a server-side atomic
BASE-SHA guard. The final precheck is only an observation. Independently verify
the resulting squash's sole parent and exact tree after the response. Do not
claim atomic guarding of both refs or invent an unsupported base field.

Retain the actual status/response, merge flag, returned SHA, request identifier
where available, and UTC observation time. Do not infer success only from process
exit. A refusal, lost response or timeout is NOT permission to retry the request.

## 6. Remote result verification before any local realignment

Let SQUASH be the exact SHA returned or conclusively recovered by read-only
reconciliation of this one request. Do not infer it from a presumed commit title.

Require independent authenticated readback of:

- PR #14 closed and merged, exact node/head/base provenance, merged actor and time;
- remote refs/heads/trunk_dev points to SQUASH itself, not merely a descendant;
- source topic remains at f0e3169c55fad62d8d830d9fc799263d7c5332f1;
- SQUASH has exactly ONE parent:
  0d0926e3a483a3ab1a4fd597ac0495927352bf35;
- SQUASH tree is exactly cc3cc104300f553ada581cee24e80dab6dd885b1;
- complete 263-leaf source/squash tree entries agree, including every fixed table
  blob/mode and all 217 unchanged parent entries; no truncated response receives
  complete-tree credit;
- parent-to-squash effects remain precisely 29 M + 17 A;
- exact PR title/body is preserved; head/source object and preserved branch heads
  remain consistent; normal server-generated PR refs are not extra user pushes;
- no out-of-scope metadata, publication or deployment request was made by this gate.

The allowed resulting RAW squash message is exact source subject plus one blank
line plus exact source body, with either zero or ONE final LF:

```text
preferred no-final-LF form:
1,221 bytes
41c96132d39108387fb211b4cda991e14f396336c3957fb79dabfd2c4976e477

permitted single-final-LF form:
1,222 bytes
1e328192097185536ea7002562000769bfd1d25562ea97b9cc3bb0ce11b0900e
```

No other PR suffix, generated co-author/trailer, removed paragraph or rewrite is
allowed. A JSON message field may omit the raw object's terminal LF; verify the
actual object after fetching as well. Do not amend an unexpected remote message.

Read signature metadata and author/committer attribution accurately. Require
fresh applicable signing policy. If a signature is present, require a conclusive
valid platform verification; do not call a raw signature header cryptographic
verification or claim local verification when only GitHub reported it. If an
unsigned squash is allowed by the current policy and is actually produced,
report that explicitly; never claim it signed or repair its identity. Invalid,
contradictory or policy-inadequate signature/provenance evidence blocks local
realignment. The original source remains the reported unsigned object.

A base race can produce a remote effect even though this gate cannot accept it.
If resulting parent/tree/ref/message/readiness differs, STOP with the actual
remote effect and preserve the local source. Do not undo remote integration,
force-update a ref, perform an alternate merge or silently advance local trunk.

If the merge response was lost, perform bounded READ-ONLY reconciliation. Continue
only if the intended single result, actor/head/base/parent/tree/message and refs
are conclusively established. If status is unknown, report unresolved. If it is
conclusively not merged, report blocked; do not reissue in this gate. If another
actor merged or the operation's provenance cannot be established, stop rather
than attribute that action to this request.

## 7. One narrow fetch, then raw object verification

Only after the complete remote result above is verified, recheck local source,
index/cache and exact working payloads. Require source HEAD unchanged, local
tracking ref still at the original parent, and one clean worktree. Recheck remote
trunk still equals the verified squash immediately before fetching.

The only permitted fetch is:

```sh
env GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 \
  PYTHONDONTWRITEBYTECODE=1 \
  git -c core.fsmonitor=false -c gc.auto=0 -c maintenance.auto=false \
  -c fetch.prune=false -c fetch.pruneTags=false -c fetch.writeCommitGraph=false \
  -C '/Users/ds/Repositories/Governed Execution Coordinator' \
  fetch --no-auto-maintenance --no-tags --no-recurse-submodules --no-prune \
  origin refs/heads/trunk_dev:refs/remotes/origin/trunk_dev
```

This authorizes required object/FETCH_HEAD/tracking-ref bookkeeping only. No
broad fetch, tags, prune, submodule traversal, source checkout, live worktree
creation or config write. The helper does not execute this write; perform its
immutable checks before and after the explicitly authorized command. Keep an
unambiguous count of fetch invocations. Do not retry after an ambiguous response.

Require fetched refs/remotes/origin/trunk_dev == SQUASH. Read the actual raw
fetched commit and tree/blob objects with guarded reads; verify object OID,
sole parent, exact tree, message form/hash, signature header if present, all 263
leaf entries, and exact 46 payload receipts/replacement relationship. The source
commit, current index and working tree must all still represent that same tree.
Reconcile raw author/committer separately from display/API attribution.

If fetch sees an unexpectedly advanced trunk or yields insufficient objects,
STOP: no local branch update, no second fetch, no reset. Report remote merged
state, current tracking ref and preserved local source accurately. Recover a
lost fetch response by readback only; proceed only when the exact intended
result is conclusive and all immutable surfaces remain exact.

## 8. One expected-old-object local branch realignment

Before the update require:

```text
HEAD is symbolic to refs/heads/trunk_dev
refs/heads/trunk_dev == f0e3169c55fad62d8d830d9fc799263d7c5332f1
refs/remotes/origin/trunk_dev == verified SQUASH
fresh remote trunk == verified SQUASH
source tree == squash tree == index/working tree
index bytes AND recorded metadata == this gate's opening
cache directory + 37 members == this gate's opening
one worktree; clean; no active operation or lock
```

Run exactly one expected-old-object ref update, substituting ONLY the verified
SQUASH SHA. Fixed reflog reason:
`realign trunk_dev after PR #14 squash merge`

```sh
env GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 \
  PYTHONDONTWRITEBYTECODE=1 \
  git -c core.fsmonitor=false -c gc.auto=0 -c maintenance.auto=false \
  -C '/Users/ds/Repositories/Governed Execution Coordinator' \
  update-ref -m 'realign trunk_dev after PR #14 squash merge' \
  refs/heads/trunk_dev <VERIFIED_SQUASH_SHA> \
  f0e3169c55fad62d8d830d9fc799263d7c5332f1
```

This is allowed only because source and squash have the same complete tree.
It replaces local commit identity, not working content. Do not use reset,
checkout, merge, rebase, cherry-pick, commit, or a different ref to imitate it.
Record the exact old/new ref and reflog result. Do not retry if the expected-old
check fails or the command response is lost. Inspect actual branch/reflog state
read-only and report the highest confirmed effect. A concurrent local change is
not permission to overwrite its expected old value.

No local topic or tag needs to be created: the source commit remains retained by
the existing remote topic, the local object database and normal reflog history.
Preserve the topic and do not garbage-collect or delete source history.

## 9. Closing verification and no new validation campaign

Fresh closing remote readback must show PR #14 merged, trunk at the verified
squash and source topic at the original source. All unrelated observed branch
heads should be preserved; if unrelated concurrent movement is observed, report
it precisely and do not revert it or attribute it to this gate without evidence.
A moved relevant trunk/topic prevents the normal synchronized closeout.

Require local:

```text
HEAD / refs/heads/trunk_dev / refs/remotes/origin/trunk_dev == SQUASH
upstream remains origin/trunk_dev
local divergence: 0 ahead / 0 behind
sole squash parent: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
tree: cc3cc104300f553ada581cee24e80dab6dd885b1
index/worktree: clean, same 263 entries and payloads as opening
all 46 original-parent-relative receipts and aggregate unchanged
all 217 unaffected parent entries unchanged
one worktree; no active operation/unexpected lock
index content AND all opening metadata unchanged
cache DIRECTORY plus 37 files' contents/metadata unchanged
```

Re-read raw commit/ref/reflog as necessary through the helper. It checks the same
opening record throughout, never a newly substituted index snapshot. Authorized
object/ref/FETCH_HEAD/reflog changes must be distinguished from the invariant
index/worktree/cache. Report the source-to-squash ref update, not a new source
commit or a local squash.

No pytest/collection/process/capsule/recovery/mutant/dependency/migration run is
permitted in this gate. The accepted source tree's staged-byte publication run
already established 9,005 unique nodes in 124 modules, 9,005 passes and the three
known writer-session fork warnings. Its inventory is
`7a38fcc5abe95d0ee818ea73649b75a9cabcb3298aab6c62974e14d224bb12fd`.
These remain prior validation evidence. Exact unchanged tree/parent requirements
and fresh hosting-policy checks are the integration controls; no new CI pass is
inferred from empty checks, a signature, mergeability or successful merge.

Keep helper/record until all final comparisons and remote readbacks finish. Scan
owned external files using lstat; hash/open regular files only; no symlink following
or FIFO/socket/device reads. Remove only this gate's positively owned roots and
request/response/helper files. No fixtures or D1 child should have been created.
If residue or immutable-surface drift is unresolved, report it and do not claim
normal complete closeout. Do not sweep /tmp or repair metadata.

## 10. Partial effects and final verdict

Preserve every completed effect. A failed or ambiguous write is not a reason to
repeat merge/fetch/update-ref, delete the PR/topic, reset local state, amend a
commit, force-push or create a compensating change. Use bounded read-only
reconciliation and report exact current local/remote coordinates.

Use one supported final token:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_PR_SQUASH_MERGED_AND_LOCAL_REALIGNED
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_MERGE_GATE_BLOCKED
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_MERGED_REMOTE_VERIFICATION_BLOCKED
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_MERGED_LOCAL_REALIGNMENT_INCOMPLETE
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_MERGE_OUTCOME_UNRESOLVED
AUDIT_PROVENANCE_MISMATCH
```

- SUCCESS only if ordinary remote squash, complete postcondition verification,
  narrow fetch, exact local expected-old ref transition, synchronized closing
  refs, immutable index/payload/cache and owned cleanup all pass.
- MERGE_GATE_BLOCKED when no merge from this gate is established and an entry,
  policy/readiness/procedure condition prevents it. State any pre-existing merge
  explicitly rather than calling it performed here.
- MERGED_REMOTE_VERIFICATION_BLOCKED when remote merge occurred but its exact
  parent/tree/message/ref/provenance/effect conditions are not accepted; do not
  advance local trunk.
- MERGED_LOCAL_REALIGNMENT_INCOMPLETE when remote result is verified but fetch,
  local ref update, relevant-ref synchronization or immutable closeout is incomplete;
  state whether the branch actually advanced and what remains unverified.
- MERGE_OUTCOME_UNRESOLVED for a write whose actual effect cannot be conclusively
  reconciled. Identify WHICH write and known effects; do not resend it.
- AUDIT_PROVENANCE_MISMATCH for fixed pre-write source/baseline/endpoint/message
  authentication mismatch. After a performed remote merge, report that effect
  explicitly under the relevant partial-result token rather than concealing it.

Inline closeout, with complete hashes and no invented final SHA:

1. Verdict, visible settings, opening guidance/pre-Git order and scope.
2. Exact source/base/tree/PR/topic identities, clean index and source receipts;
   all 263 source/remote/squash leaf entries and 217 unaffected parent entries.
3. Fresh actor/policy/reviews/threads/checks/signing/readiness and effect metadata;
   timestamp final pre-request observation, no assumed CI success or bypass.
4. Exact source raw-message/body and PR-body receipts; canonical request byte
   count/hash, one-request response or non-retry reconciliation, request ID/time.
5. Squash OID, sole parent, tree, exact allowed raw message form, observed raw
   and platform author/committer/signature facts, PR merged actor/time.
6. Exact one-fetch and one-update-ref commands/results, source-to-squash reflog
   old/new pair, relevant local/remote refs and 0/0 or actual partial divergence.
7. Candidate/index/cache preservation, known authorized object/ref bookkeeping,
   owned cleanup and actual prohibited non-actions; no false 'no mutations'.
8. Evidence limits, any corrected read-only inspection mistakes, partial effects
   and a continuation capsule <=1,000 words.

Successful integration ends this gate. Next is a freshly supplied snapshot and
re-grounding before the separate D2 program step, not D2 execution now. No source
repair, additional commit, snapshot-generation task, release, deployment, live
model/provider/supplier/ES/Bridge/RW0-E work is authorized. Do not issue the next
implementation prompt. End with exactly one supported verdict token.
