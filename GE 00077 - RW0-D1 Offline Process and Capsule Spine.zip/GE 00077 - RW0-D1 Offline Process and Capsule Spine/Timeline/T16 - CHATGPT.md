## Disposition

**Accept the scope stop. Preserve the retained repair and complete it under a corrected nine-file ceiling. This is not a D1 architecture replan.**

Unlike the earlier implementation attempts, **the repaired candidate still exists**. It should not be discarded or recreated. The missing authorization is one existing candidate file:

```text
tests/test_rw0_b2_wire_boundaries.py
```

The previous repair prompt required exact existing evidence types while prohibiting changes to the guard that controls their consumers. That was an incomplete repair boundary in my prompt. Codex correctly stopped rather than weakening the handback or routing its imports around the guard. Coordinator_RW0_D1_Offline_Proc… Coordinator_RW0_D1_Offline_Proc…

## Engineering correction

**Admit `_rw0_d1_handback.py` as one explicitly bounded consumer of the existing Wire result types.**

The Wire owner already defines:

```text
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
```

They represent worker-result evidence and process/result classification—not execution permission, acceptance, or durable progression. The snapshot’s importer guard already enforces exact consumer paths and permitted symbols. The correction should extend that mechanism, not replace it. See `.docs/rw0-b2-wire-protocol.md:49–61` and `tests/test_rw0_b2_wire_boundaries.py:551–611`.

The new allowance is:

```text
Consumer:
src/ge_nwp_coordinator/_rw0_d1_handback.py

Permitted direct Wire imports:
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1

Purpose:
exact runtime validation of existing handback evidence fields
```

The continuation first verifies those imports against the actual retained handback. It must preserve all current Capability, C1, and other D1 importer permissions.

It must **not** admit every `_rw0_d1_*` module, permit arbitrary Wire symbols, or introduce a whole-module import escape hatch. The handback gains no codec, classifier-execution, process, transport, cancellation, or custody authority. Wire source, schemas, digests, framing, and public exports remain unchanged.

Nor should the implementation retreat to `object` fields, string type names, dynamic imports, or re-exports through another module to satisfy the old guard. Those would evade the dependency being governed.

### No additional documentation or identity reset is indicated

I checked the baseline Wire owner and the tests referencing this boundary file. Capability’s `R25` records the Wire boundary test’s **path, mode, and authority-non-effect role**; it does not pin that test’s complete file hash. Its protected content row `P01` pins the **Wire implementation**, which will remain unchanged. See `tests/test_rw0_b2_capability_boundaries.py:104–105,118–145`.

Consequently, this correction does not require another `AGENTS.md`/`README.md` identity update, Capability source change, B1 registry change, or C2 guard revision.

That conclusion is snapshot-grounded. The current candidate’s exact imports and guard clauses still need the continuation’s live preflight.

## Preserve the repair already performed

The report provides useful, but not independently accepted, evidence that the four runtime fixes are present:

- exact handback types and stage-dependent evidence checks;
- creating-PID fencing of disposable-state custody;
- preserved process observations when cleanup is uncertain;
- exact-type checks before frame membership operations.

Groups 1–6 reportedly passed **92, 218, 46, 168, 109, and 135 tests**. The ten transformed repair copies also failed their intended tests. However, Group 7 still failed its importer guard, and Groups 8–12 were not completed. **The candidate is not ready for re-audit yet.**

The new primary work is the Wire guard and its direct controls. The prior eight repair paths remain available only for necessary corrections to the four existing findings—not for another D1 rewrite. The other **37 candidate files** stay byte-identical. The total candidate remains **46 paths**, because the Wire test is already one of them.

The guard must have causal controls proving that it rejects an unapproved consumer importing the same result types, an additional Wire function imported by the handback, and a wildcard or whole-module replacement for the admitted imports. Expected consumer and symbol sets must remain fixed, not derived from the observed source.

## Validation coordinates must change with the guard

There is a second correction to make now, rather than encounter it during validation:

**The Wire boundary file belongs to both Group 7 and Group 11.** Changing it legitimately changes both groups’ inventory digests and may increase both test counts. Their previous digests must not remain mandatory expected values.

The replacement prompt therefore requires:

```text
Group 1:
recompute if any D1 test changes further

Groups 7 and 11:
recompute after the Wire guard amendment

Group 12:
recompute the complete inventory and execute the full suite

Groups 2–6 and 8–10:
preserve their exact test-file inventories and expected regressions
```

All twelve groups must run from the **final** candidate. The earlier successful groups remain diagnostic evidence, not a substitute for that final run.

The count reconciliation is:

```text
final full count =
    8,820
    + final D1 Group 1 count
    + net tests added by the Wire-boundary amendment
```

This is only an arithmetic check. It does not establish a full-suite pass.

## Complete continuation handoff

Resume the **same implementation Codex conversation**, preserving the current repaired checkout.

:chatgpt-content-reference{index="2"}[Download the complete RW0-D1 audit-repair continuation prompt V2](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V2_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V2_Prompt.txt

Bytes:
34,542

SHA-256:
9d4c21b1f791e45a3cf49fe56a969c205bf7d4183a059542e46ee6806a67ea3c

Lines:
577

Final newline:
present
```

It uses the **retained repair’s** opening identity:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement recipe:
4,450,113 bytes
8332920fe49edf41a91ebd047b3b62cea04692293c67a818aea1e2d79220068b
```

It does **not** require the older `4,422,240`-byte pre-repair identity.

The handoff contains all 46 current endpoint receipts, the nine-path ceiling, the exact consumer/symbol amendment, preservation requirements for the four runtime repairs, the complete validation path lists, corrected inventory expectations, and explicit retained-work handling.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT
```

Success supports only a **fresh independent read-only re-audit**. It authorizes no commit, publication, D2, C2 physical implementation, migration `0005`, supplier work, live authority, ES/Bridge integration, or RW0-E execution.

## Evidence boundary

I inspected the mounted snapshot’s Wire owner, Wire importer guard, Capability protection rows, and related references, and read the issued repair mandate. I also corroborated all **29 baseline blob identities** in the replacement prompt against the snapshot and checked the retained recipe’s component arithmetic.

I did **not** inspect the eight live repaired files, reproduce their endpoint hashes, or execute repository code or tests. Their current identities and behavior remain Codex-reported until the continuation and subsequent audit verify them.

**Sources:** Your latest repair closeout; the issued Repair V1 mandate; Governed Execution Coordinator - Snapshot - 2026-10-15.zip[October 15 Coordinator snapshot](sandbox:/mnt/data/Governed%20Execution%20Coordinator%20-%20Snapshot%20-%202026-10-15.zip), particularly the Wire owner and guard references above. Some older uploads have expired; re-upload a historical original only when a later comparison requires its bytes. The sources needed for this correction were available.

**Confidence:** High on the scope correction and preserving the retained candidate. Final repair correctness and complete validation remain unresolved until the corrected guard and all final gates pass.
