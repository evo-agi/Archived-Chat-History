## Disposition

**Proceed to a fresh independent read-only re-audit of the exact repaired V5 candidate. Do not stage, commit, or begin D2.**

The report supports that next step: six permitted paths changed, the two optional process-consumer tests remained unchanged, and all twelve final validation groups reportedly passed. All 29 tracked candidate modifications—including the documents and governance guards—retained their previous bytes. No further repair, registry amendment, or mutation-ceiling expansion is indicated before independent inspection. Pasted text Pasted text

**The next audit must verify both rejection and preservation:** contradictory process records must fail, while legitimate failure and cleanup observations must remain representable. A validator that rejects the demonstrated `ok/99` specimen but also rejects a real supervisor failure path would still be incorrect.

## The repair addresses the right owner and consumers

V5 reports one pure `D1ProcessOutcome.validate()` method, invoked during construction and replacement and explicitly by handback admission for **both** process records. Clean-success checking then applies wherever the handback requires an ordinarily successful planner or worker. This is the selected owner/consumer arrangement, rather than another local check confined to `capsule_ready`. Pasted text

The reported distinctions are important:

| Retained observation | Intended treatment |
|---|---|
| `ok` with exit `99`, `None`, a negative signal code, or Boolean `False` | Reject as internally inconsistent |
| A genuine `nonzero_exit` with exit `99` or a supported signal-negative code | Retain as valid failure evidence; never readiness |
| Failed launch without a PID or process group | Retain as a legitimate failed-start observation |
| Timeout or cancellation followed by zero exit | Preserve the actual failure/control outcome; zero does not imply ordinary success |
| Known zero exit with unproved cleanup | Preserve the known exit and cleanup uncertainty; never `capsule_ready` |

Codex reports direct and forged-record tests for these distinctions, plus actual-return substitutions for a negative planner PID and worker `ok/99`. Those substitutions reportedly reject safely, prevent later child launch, remove only the failing invocation’s roots, and preserve the original successful run’s custody. Pasted text

That is promising repair evidence—not independent closure.

## Principal re-audit questions

### 1. Does the complete invariant match the actual supervisor?

The auditor should derive the twelve-field relationship from **every actual producer return site**, then compare it with the validator and independently fixed tests.

Several clauses need that direct check: the reported restrictions on TERM-delivery claims for `nonzero_exit`, the relationship between known exit and reap, and the permitted process-control and selector/stream cleanup combinations. They should not become accepted merely because the closeout lists them. Pasted text

The audit must distinguish malformed process records from genuine negative observations. It must also prove that handback consumption rejects forged exact wrappers independently of constructor validation. A constructor rejection cannot demonstrate that the consuming boundary is protected.

The check remains pure evidence validation. It must not poll a PID, query current process existence, signal a group, access SQLite, or purport to authenticate historical execution. Those limits were explicit in the repair mandate. Coordinator_RW0_D1_Offline_Proc…

### 2. Does Wire consistency remain correctly separated?

The report says the runner still passes the **actual worker return code** into the existing Wire classifier, while the handback neither imports nor executes that classifier. Its retained usable-Wire requirement remains additional to process consistency. Pasted text

The independent checks must establish both directions:

```text
usable Wire label + invalid/nonzero/missing worker exit
    → not ready

valid clean zero-exit worker + unusable or missing Wire evidence
    → not ready
```

The two-field Wire classification is not proof of its historical inputs. The auditor therefore needs a call-through observation of the runner’s actual classifier arguments, not only a handback specimen containing a preconstructed `usable` value.

### 3. Do the retained safeguards still hold?

The latest changes must preserve deep capture validation, reason/stage consistency, creator-PID custody, process-cleanup evidence, closed frame errors, and the exact B1/Wire consumer restrictions.

The nine reported transformed copies cover the six named process-repair classes. They are useful controls, but the re-audit must identify which predicate each actually tests. A worker-only mutation, for example, does not by itself prove protection across every admitted stopped and cleanup status. The handoff retains the named obligations and allows overlapping specimens to satisfy them explicitly, without turning this into an open-ended mutation campaign. Pasted text

## Provenance and validation reconciliation

The retained candidate remains:

```text
29 modified tracked paths
17 untracked additions
46 candidate paths total

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Final replacement identity:
4,511,038 bytes
e0221e5d67ed3091ead541c314163b49964ec298411f4c29a6d11a572434d1ed
```

The six reported payload changes total **16,862 bytes**, reconciling the preceding 4,494,176-byte replacement stream to 4,511,038 bytes. The other **40 candidate endpoints** are unchanged: the 38 protected paths plus the two optional tests. I checked that arithmetic and every encoded row length while preparing the handoff; this does not reproduce the aggregate hash without the live candidate payloads. Pasted text

The reported final validation is internally consistent:

| Gate | Collected / passed |
|---|---:|
| D1 runtime and integration | 108 / 108 |
| Wire | 135 / 135 |
| Legacy guards | 1,773 / 1,773 |
| Remaining changed owners | 679 / 679 |
| Complete repository | **8,970 / 8,970** |

Only three D1 test files changed, so the full-count increase reconciles as:

```text
8,966 + (108 − 104) = 8,970
```

The report supplies all twelve group inventories, their overlaps, and the same three existing fork warnings. It also distinguishes the interrupted earlier full run from the final successful run after the last edit. That interrupted run receives no final validation credit. Pasted text

Complete live-cache metadata equality and task-owned process/root cleanup are reported as well. They remain facts for the independent audit to reproduce, not inferred consequences of passing tests. Pasted text

## The unfinished independent acceptance work remains mandatory

The next audit must close the process-consistency finding **and** complete the previously omitted independent SQLite readback and four-site recovery checks, process/file-descriptor isolation, workspace faults, B1 one-sided projections, finite transformed-copy checks, and final twelve-group validation. The closeout correctly retains those limitations. Pasted text

A matching test-file inventory is not a test run. The 8,970-pass implementation result cannot substitute for independent acceptance. A newly reproduced material defect may justify another early block, but acceptance requires completing the named gates.

## Independent re-audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="12"}[Download the complete repaired-V5 D1 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V5_Independent_Reaudit_Prompt.txt)

```text
Bytes:
66,741

SHA-256:
e7e077d81f57a77893a19d8a1d607fd32ebf91df88bcafc11913ac05782a2e68

Lines:
1,065

Final newline:
present
```

The handoff contains the **complete final 46-path receipt table**, latest replacement identity, all twelve exact validation inventories, the process-owner/consumer obligations, and the retained acceptance checks. It requires no previous prompt or historical candidate attachment.

The live checkout remains read-only. Executable audit work is confined to disposable, remote-free external clones. No candidate repair, publication, D2/C2 implementation, supplier activity, or live authority action is authorized.

Possible verdicts remain:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would establish eligibility for a **separately issued commit/publication gate for these exact files**. It would not authorize D2, physical C2, migration `0005`, qualified-source or supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the current closeout, V5 repair mandate, and preceding re-audit mandate in full. I corroborated all **29 baseline blob identities** against the mounted October 15 snapshot, verified that the 17 additions are absent from that baseline, checked the receipt/count arithmetic, and reopened the generated prompt to verify its final table and exact validation memberships.

I did **not** inspect the live repaired D1 source, reproduce its endpoint hashes, or run repository code or tests. Candidate behavior and the 8,970-pass result remain Codex-reported.

Some older uploads have expired. Re-upload a particular expired original when its bytes are needed for a later comparison; this handoff requires no historical attachment.

**Sources:** The current V5 closeout and issued repair mandate cited above; the preceding independent-audit mandate for outstanding acceptance obligations; October 15 Coordinator snapshot for baseline-blob corroboration.

**Confidence:** High on re-audit readiness and provenance bookkeeping. Final process semantics, independent validation, and commit eligibility remain unproved.
