# Governed Execution Coordinator — RW0-D1 Audit Repair V7
# Runner capsule-verification causality: one integration-test file

## FIRST ACTION — live guidance as text, never Git first

The first repository-related tool action after receiving THIS instruction must
read live AGENTS.md as plain text, from a neutral working directory. Do not run
status, rev-parse, a repository bootstrap or a settings command that invokes Git
first. This is a new, explicitly authorized REPAIR interval, not a continuation
of the auditor's observation interval and not permission to reconstruct history.

```sh
python3 -I -B -S - <<'PY'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY
```

Read all returned guidance, using further text reads if output truncates. Then
establish the pre-Git record/helper below BEFORE any Git command. Once opening
and authentication pass, complete the bounded repair without per-phase user
approvals. No intermediate architecture or standalone contract handoff.

## Mandate and classification

Resume the IMPLEMENTATION conversation owning the RETAINED 46-path D1 candidate.
The latest independent Restart 01 audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

Its Medium finding is a PERMANENT-TEST CAUSALITY GAP. The current runner DOES
call verify_candidate_capsule() before returning capsule_ready. Deleting just
that call in an external copy preserved parse/import and all 108 D1 tests passed;
the runner still returned ready. A separate call-through probe counted one call
in the candidate and zero in the deletion copy. The existing capsule test checks
the returned manifest itself, not whether the runner verified before readiness.

Reported pointers, to re-resolve against exact retained source:

- src/ge_nwp_coordinator/_rw0_d1_offline.py:466 — verifier invocation;
- tests/test_rw0_d1_workspace_capsule.py:59 — post-return capsule check.

This is NOT an observed omission in the retained runtime. Do not rewrite the
runner or add a verifier/verification flag/receipt/handback field. Strengthen the
existing integration test so the claimed runtime safeguard cannot disappear
while the permanent tests remain green. Only ONE test file may change.

The latest audit has a valid pre-Git index/cache preservation interval. Its 23
selected B1 checks, alias-module refusals and helper-regression controls remain
labeled independent evidence. Its 108-test runs were focused, not final Group 1
or complete acceptance. Full durable readback, remaining finite mutations and
process/FD/workspace campaigns, all 29 tracked semantic diffs, and final Groups
1–12 remain unperformed. This repair does not fill those independent omissions
merely by running implementation tests.

D1 -> D2 -> physical C2 remains fixed. No standalone semantic tranche, additional
runtime owner, provider/supplier mechanism, protocol, import framework or D2 work.
Parent is sole writer; no subagents. Use highest exposed reasoning; report visible
model, effort and permissions or not visible. No extra account/computer access to
reveal hidden settings, network, credentials, sibling repository or publication.

Return operative evidence INLINE with repo-relative path:line, exact commands,
provenance and a continuation capsule <=1,000 words. No delivered patch, report,
archive, manifest, snapshot or architecture package. This mandate includes all
opening identities and test memberships; no historical attachment is required.
Do not issue the next audit/publication/D2/C2 prompt.

## 1. Exact baseline and successful pre-Git mechanism

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

- branch trunk_dev;
- HEAD 0d0926e3a483a3ab1a4fd597ac0495927352bf35;
- tree 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4;
- sole parent 630414faa07f4ac39c4a870a9cc44c7f92d46b80;
- subject: docs: freeze RW0-C2 scope admission provisioning;
- upstream origin/trunk_dev, locally 0 ahead / 0 behind;
- one worktree, index equal to HEAD, zero staged/unmerged paths;
- exactly 29 modified and 17 created candidate paths below;
- no active Git operation, sequencer or unexpected lock.

After reading AGENTS, execute this block from a neutral directory. It invokes no
Git, repository module, SQLite or test. It captures the index and known cache
then creates a forced-environment inspection helper under a mode-0700 external
root. It retains the successful Restart 01 mechanism, with this engagement's
labels. Do not substitute historical timestamps, inodes or hashes for fresh
opening observation. The helper is temporary instrumentation, not product truth.

```sh
python3 -I -B -S - <<'PY'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env

import datetime
import shutil
import tempfile

# This block does not run Git or import repository modules.
guarded_environment()
for key, value in GUARDS.items():
    os.environ[key] = value
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_does_not_match_the_fixed_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_not_found')
root = Path(tempfile.mkdtemp(prefix='rw0-d1-v7-repair-'))
print('AUDIT_OWNED_ROOT=' + str(root), flush=True)
os.chmod(root, 0o700)
record = {
    'schema': 'rw0-d1-v7-repair-opening-observation',
    'phase': 'recorded-before-first-git-in-this-repair-attempt',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents,
    'index_path': str(index), 'index': index_before, 'cache': cache_before,
    'git_environment': GUARDS, 'git_executable': git,
    'historical_limit': 'older audits lack pre-first-Git metadata; this record covers only this repair',
}
wrapper_text = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\nimport subprocess\nimport sys\n\nopening_path = Path(__file__).with_name('opening.json')\nopening = json.loads(opening_path.read_text(encoding='utf-8'))\n\ndef verify_preservation():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('live_index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('live_index_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('live_guidance_drift')\n\nargs = sys.argv[1:]\nverify_preservation()\nenv = guarded_environment()\nif args == ['--check']:\n    print('RW0_D1_V7_REPAIR_OPENING_PRESERVATION_OK')\n    raise SystemExit(0)\n\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_git_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'],\n                                                               ['--quiet', 'HEAD']):\n    raise RuntimeError('only_readonly_head_symbolic_ref_allowed')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('only_worktree_list_allowed')\nfor arg in args[1:]:\n    if (arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec')\n            or arg.startswith(('--output=', '--exec='))):\n        raise RuntimeError('unapproved_git_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager',\n           '-c', 'core.fsmonitor=false', '-c', 'gc.auto=0',\n           '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=env, check=False)\nfinally:\n    verify_preservation()\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(payload)

try:
    write_private(root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(root / 'live_git.py', wrapper_text.encode('utf-8'))
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_any_git_command')
    print('LIVE_GIT_HELPER=' + str(root / 'live_git.py'))
    print('OPENING_RECORD=' + str(root / 'opening.json'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_V7_REPAIR_PRE_GIT_OPENING_RECORDED')
except BaseException:
    # Only known regular files written by this invocation are removed.
    for name in ('live_git.py', 'opening.json'):
        owned = root / name
        if owned.exists():
            if not stat.S_ISREG(owned.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            owned.unlink()
    root.rmdir()
    raise
PY
```

Use the ACTUAL emitted helper/root paths. Do not assume shell variables persist,
guess a temporary root, or rerun the opener to replace its record. Every LIVE
Git inspection goes through the helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> rev-parse HEAD
```

The helper enforces GIT_OPTIONAL_LOCKS=0, GIT_NO_LAZY_FETCH=1 and noninteractive
inspection per subprocess, disables external diff/textconv/fsmonitor and checks
index content/metadata and cache before/after. --check invokes no Git. It does
not wrap pytest, edit the test or prove correctness. It checks AGENTS/index/cache,
not the permitted test's opening hash, so it remains valid after the test edit.

Local-only external clone creation is separately permitted with equivalent
command-local suppression; no live index/config change, fetch or maintenance.
Remove clone remotes before execution. Missing objects/unsupported inspection
are a stop, not raw-Git fallback permission. No live Git write is authorized.

Authenticate baseline and complete candidate before editing; provide one compact
inline opening acknowledgement, then proceed automatically. If any Git preceded
this interval's opening, stop before clones, probes or edits. Do not reset the
index, reconstruct prior history, restore metadata or silently rebaseline.
The recent valid audit interval does not replace this repair's own record.

## 2. Exact retained 46-path candidate

M means tracked modification; C means untracked creation, not Git copy/commit.
All candidates are regular nonsymlink OS-mode 0644, Git representation 100644.
Preserve unrelated nonexecuting 0600 files, including the known program-init
test. Require strict UTF-8, no BOM/CR, one terminal LF, no trailing whitespace.
No new/deleted/renamed path, link, submodule or executable-bit change.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 25,215 | `dde79042a7640571493f882b5130b8650c7a52ebd2fc28a6956799a261fa6d4c` | `absent` | 25,286 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 23,432 | `e5250a4921d1d441716fa356c742dbc886a0d13f7386c90e8409094c733f2109` | `absent` | 23,507 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read all 29 M baseline blobs from HEAD and check their OIDs. All 17 C paths are
absent from HEAD/index. All 217 noncandidate tracked files remain HEAD-exact in
content/type/Git mode. Complete candidate: 263 endpoints = 246 baseline + 17.

Reconstruct twice from fresh reads without importing candidate code:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 plus ONE NUL (25 bytes)
for each row in UTF-8 repo-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw HEAD blob bytes, or twenty zero bytes for C
    u64be(payload_length)
    exact file bytes

46 rows: 29 M / 17 C
encoded row bytes: 4,514,586
prefix: 25
total: 4,514,611 bytes
SHA-256: 9e1244f91b0a78350928715e3de1b9da5861e29ef92f777e032ec59d370b5fc9
```

On any mismatch stop before editing, preserve actual work and report it. No
source reconstruction from hashes, historical-payload prerequisite or new recipe.

## 3. ONE-file repair ceiling

Only this existing candidate file may change:

`tests/test_rw0_d1_offline_integration.py`

```text
opening status C; HEAD/index entry absent
OS mode 0644; Git representation 100644
payload 23,432 bytes
SHA-256 e5250a4921d1d441716fa356c742dbc886a0d13f7386c90e8409094c733f2109
encoded component 23,507 bytes
```

Add runner-level causal integration evidence and minimal test-local support.
Preserve all existing tests and assertions. No new conftest/module, skip/xfail,
source-string/hash assertion substituted for behavior, or removed old cases.

OTHER 45 candidate endpoints remain exact, including all nine D1 source modules,
other six D1 tests, all documents, B1 version-3 owner and both projections, V6 B1
acquisition fix, Wire guard and value semantics, Capability/bootstrap/scoped-C2
and other governance guards. All 217 noncandidate tracked paths remain HEAD-exact.
Keep package root, pyproject, .gitignore, StateStore, current semantic/durable/
reader/writer/recovery source, configuration and migrations 0001–0004 unchanged.
No 0005, public surface, new field/receipt/schema or registry permission.

No staging, commit, push, PR, merge, branch switch, reset, network, dependency
install, provider/supplier, live credentials/authority, enrollment, deployment,
D2, physical C2, terminal, ES/Bridge, RW0-E or sibling-repository action.

Production-text mutations below are allowed ONLY in disposable external copies
for tests. The live runner and verifier remain byte-identical, even if changing
them would make writing the tests easier.

## 4. Focused owner/caller inspection and repair sequence

Read the allowed integration-test module completely, then owning context in:

- _rw0_d1_offline.py: build/verify/readiness/failure/cleanup sites;
- _rw0_d1_capsule.py: real signature, independent reconstruction, relation,
  exact return and failure convention;
- _rw0_d1_workspace.py: capture structure and its complete validator;
- _rw0_d1_handback.py: ready/capsule_mismatch/cleanup predicates;
- tests/test_rw0_d1_workspace_capsule.py and test_rw0_d1_handback_values.py;
- .docs/rw0-d1-offline-process-and-capsule-spine.md and relevant unchanged
  worker/capsule contracts;
- any guard/content dependency of the sole changed test, as read-only context.

Resolve the verifier reference the runner REALLY uses. Patching an unused module
attribute is not coverage. Do not assume a Boolean return or invent an exception
where current semantics use normal return plus a private failure. Do not import
repo code in the live checkout.

Before editing return a compact inline map: call site/signature/failure convention,
ready/negative construction sites, existing test helpers, selected observations
and any implicated dependency. Then continue without another user choice.

Sequence: authenticate -> narrow inspection -> reproduce original deletion in an
external opening copy -> write permanent positive/rejection tests -> final-byte
bounded defect controls -> fresh normal final clone for all twelve groups ->
receipts/preservation/cleanup -> closeout.

If authentic verifier failure is mishandled by current production, report that
specific defect and stop. This mandate does not permit rewriting production or
weakening expected behavior to keep the task test-only.

## 5. Permanent positive test: verification is performed by the runner

In the allowed module, add a named permanent integration test invoking the actual
private D1 entry, actual current guarded durable paths and real fixed planner/
worker children under isolated temporary state/workspace.

Wrap the callable reference used by the runner, in TEST scope only:

1. Save the actual original verifier before patching.
2. Record entry and actual argument objects/contract coordinates locally.
3. Call through to the real original verifier with the runner's actual inputs.
4. Record successful completion only AFTER the real verifier returns successfully.
5. Return its original result unchanged. No fabricated success, copied verifier
   algorithm, MagicMock success result or self-issued verification receipt.

Observe actual capsule_ready construction (its existing validation/factory site)
without replacing evidence class identities. Call through to original methods.
The observation list belongs to the test, not a production stage ledger.

For the current single-candidate happy invocation require:

- exactly one runner-origin call to independent verification;
- real verification completes before the FIRST ready handback is constructed or
  exposed, and before the private entry returns;
- the manifest/capture actually passed are this run's builder/capture outputs;
- inputs and returned handback match the same WorkSpec/base/author-command/fence
  coordinates exposed by the actual signature and existing durable values;
- the returned handback retains that verified manifest/capture, not an unrelated
  fixture object with a separately checked digest;
- mutable workspace is gone, children reaped/groups clear, parent-only run
  custody remains valid and closes explicitly/idempotently.

Use canonical equality/digest and object identity only where appropriate to the
existing contract. Expectations cannot be whatever the spy happens to observe.

Do NOT call verify_candidate_capsule directly from the test to satisfy the count,
manufacture events, rely on an AST/string occurrence, or count verification done
only after return as runner-owned verification. Existing post-return content
checks remain valid but cannot discharge this gate. Deleting the runner call
must make this permanent test fail because the required runtime event is absent.

## 6. Permanent negative test: verifier refusal prevents readiness

Add one actual-run rejection case, not merely a call-count spy. At the real
verification boundary use a test-local wrapper that calls the existing verifier
with ONE structurally valid but relation-inconsistent capture/manifest pair.

One bounded existing-shape specimen is changing the already-mutated entry's
before/after bytes while preserving exact entry/container types, fixed path/mode,
size limit and exactly one changed path, without resealing its manifest. Select
the exact supported construction after reading the owner. The ordinary capture
validator must accept the structural specimen; actual rejection must occur in
the REAL independent verifier/relation, not an earlier shape check.

Record entry and the original verification failure. Re-raise/return the owner's
actual failure unchanged. Do not substitute generic RuntimeError, a test assertion,
new Boolean convention or an unrelated exception as the production signal.
These are controlled test-call arguments, not mutation of live production files.

Derive the expected negative result from the current owner and actual runner.
The retained D1 contract describes stopped/capsule_mismatch with validated
capture, no ready manifest, and proved normal workspace cleanup on this path.
Confirm that exact treatment; test the reason and allowed retained evidence,
not merely `status != capsule_ready` or a catch of any Exception. No new status,
generic durable_conflict, evidence erasure or fabricated empty handback.

Require:

- real verifier entry and rejection observed;
- no capsule_ready constructed or returned;
- earlier durable program/author/selection/C1 facts are preserved, not fabricated,
  retried, rolled back or replaced by this candidate refusal;
- the negative handback retains exactly the evidence its existing prefix allows;
- no claim that independent verification succeeded;
- both previously started children reaped/groups clear;
- workspace removed where cleanup is proved;
- returned parent run owner explicitly closes only its own state, idempotently;
- no state/workspace paths or payload leaked in errors/diagnostics.

Keep reconstruction in the existing verifier. The test does not define another
digest/capsule algorithm. A true verifier-content test and this runner-consumption
test have different responsibilities. Ordering observations must also reject
verification moved after a ready-handback construction, not just count calls
by the time the entry returns.

If a genuine specified refusal cannot be exercised within these existing owners
or produces a contradictory handback, stop with source evidence rather than
inventing a different error contract. No production repair is authorized here.

## 7. Finite before/after and transformed-copy evidence

Before editing tests, reproduce the reported omission in an external OPENING
copy: delete ONLY the runner's verification call, preserve normal parse/package
import and all 108 original D1 nodes, run them, and observe ready from a real
invocation. Separately establish one candidate call versus zero in the copy.
This is a new equivalent specimen, not a claim of original auditor byte identity.

Against FINAL test bytes, perform only these three bounded defect classes in
separate external copies, preserving the fixed expected tests:

| ID | External mutation | Required discrimination |
|---|---|---|
| V01 | Remove only the runner verifier call | New permanent positive test fails on absent runner verification; negative test cannot falsely pass without reaching its gate |
| V02 | Replace verifier body with its existing neutral-success convention, retain runner call | Authentic relation-rejection test fails because the inconsistent relation is no longer rejected; call counting alone cannot cover this |
| V03 | Let runner proceed successfully after the verifier's actual declared refusal | Negative integration fails on ready/wrong reason or evidence; swallowed failure cannot be counted as verification success |

Use the actual return/exception convention in V02/V03. Each complete module must
parse/import and its selected permanent tests collect normally. A syntax/import
error, changed test collection, unrelated source-inventory guard or injected false
assertion receives no semantic credit.

Run all original D1 tests once for the opening V01 survivor, then the final
D1 selection for its closure. V02/V03 use the smallest discriminating permanent
selection. No full-suite-per-mutant run, general mutation framework or expanding
quota. A single unmodified positive final run must also pass.

Report transformation locations, copy identities, exact selected nodes, actual
parse/import/collection outcomes and intended semantic failures. Separate actual
call-through observations from tests, mutated-source controls and audit-only
oracles. No test-side direct verifier invocation can supply V01's missing event.

## 8. Preservation and outstanding independent acceptance

No runtime redesign is commissioned. Preserve process-value/handback validation,
deep capture checks, reason-prefix constraints, creator-PID custody, explicit
close, cleanup/framing fixes, existing guarded durable flow and recovery, and
all B1/Wire/Capability/scoped-C2/public-boundary guards. No shadow program truth.

Tests must use finally/context managers so a failed assertion in a deletion or
swallowed-refusal copy still closes any returned run and accounts for every
owned process/root. Never close an original run belonging to another invocation,
rely on finalizers, sweep arbitrary temporary roots or kill by process-name alone.

The latest audit successfully established its opening interval and finite B1
closure. Preserve that as prior independent evidence. The complete four-family
identity/digest/receipt/head readback, full selected faults/mutations/diff review
and fresh final Groups 1–12 still require the later independent acceptance audit.
Repair-validation passes do not retroactively fill those omissions.

## 9. External execution and final validation

The only permitted live edit is the integration test. No live-checkout repo
import, pytest, child, script, compiler, SQLite or product/operator database
access. Use local-only external clones of exact HEAD plus the 46 endpoints,
remotes removed, installed dependencies and no network.

Keep the opening record/helper until final live checks. Use task-owned mode-0700
roots, test-process umask 022, TMPDIR inside an owned root, disabled bytecode/cache
and separate precreated collect/run basetemps. Preserve actual source OS modes.

After the LAST edit, build one fresh NORMAL final clone, not a reused mutated
copy. Verify all 263 endpoints before/after. Run collect then execute serially:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Each token expands to tests/test_<token>.py. Sort/deduplicate within a group only.
Group 12 has NO path arguments and includes all 124 current test modules.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Test-file inventory encoding for each sorted repo-relative module path:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

Opening IMPLEMENTATION references (not independent passes in the latest audit):

| Group | Files | Opening implementation collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 108 / 108 | `c768d282a219e67d89800643373e1c4ab7bad9a248949933f7beacfcdda3c7d6` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,980 / 8,980 | `9be322d172fccc745a5dd5ac0e448b5f73217edf537a0ffca28b2b7f27e94687` |

Only the integration-test file changes. Groups 2–11 retain exact memberships,
file bytes and inventory hashes; rerun all regressions and reconcile their listed
counts. Groups 1 and 12 need new inventories and actual collection/execution.
No fixed new count, test removal, count-driven skip/xfail or altered selectors.

```text
final_full_count = 8,980 + (final_Group1_count - 108)
                 = 8,872 + final_Group1_count
Group 2/3 overlap = 46; Group 7/11 overlap = 31
Group 1–11 union = 3,545 + final_Group1_count, if those are the only overlaps
```

These are bookkeeping equations, not pass evidence. Record complete node IDs,
including parameter values containing spaces. Every Group 1–11 node must appear
in the full collection. No whitespace-split collection parser, xdist, overlapping
runs, warning suppression or inherited historical/superseded final result.

Groups 10/12 have the existing three Python 3.13 multithreaded-fork
DeprecationWarning records attached to:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warnings. Repetition across overlapping groups is not a new
warning class. Investigate new failures/warnings or unsupported mandatory process
execution without suppressing them or calling omission a pass.

Also require:

- live diff --check via the guarded helper;
- all 17 creation no-index whitespace checks; ordinary difference status 1 with
  no whitespace diagnostic is not a failure;
- strict encoding/final-LF and candidate path/type/mode checks;
- all other 45 candidate endpoints and 217 HEAD-exact noncandidate files;
- unchanged B1/Wire owners, registries/projections, guards and document identities;
- exact nine D1 modules/two fake entries/sole subprocess owner;
- original source/package exports/scripts/StateStore/schema/migrations unchanged;
- migration 0005 absent;
- normal final-clone 263-endpoint equality, no extra clone files;
- live index CONTENT AND opening-recorded metadata equality;
- live cache DIRECTORY plus all 37 member metadata/hash equality.

Correct only identified external-runner mistakes outside live checkout; rerun
affected gates from exact final bytes and record failed/interrupted trials.
A late edit invalidates inherited final validation.

Scan owned artifacts using lstat. Open/hash only regular files; never follow
symlinks or open FIFOs/sockets/devices. Terminate/reap and account for owned
processes before removing their roots. Remove only positively identified task
resources. Run final checks using the SAME helper/opening record, then remove
the owned helper/root; never normalize live index, cache or source metadata.

## 10. Closeout, stops and next boundary

Keep retained work on every stop. No wholesale reset/rollback, recreation from
hashes, deletion of another actor's work, or restoration of index/timestamps.
Baseline HEAD/tree/parent/branch and index remain unchanged; final status remains
29 M / 17 C. Only the authorized integration test differs from its opening bytes.

Recompute all 46 endpoint receipts and the SAME replacement stream twice. Report
the sole target's before/after payload size/SHA-256, OS/Git mode, absent HEAD
blob and encoded component; preservation of the other 45 rows; encoded-row,
prefix and total bytes and measured final SHA-256.

```text
final replacement bytes = 4,514,611 + (final integration-test bytes - 23,432)
```

No invented final hash or new manifest. A single exact transition is sufficient
instead of repeating the full table only when 45-row preservation is unambiguous.
No delivered evidence file is requested.

Return inline:

1. Verdict/settings, true opening order and baseline/index/cache record.
2. Inspected verifier signature/owner failure convention, runner lookup and ready/
   rejection sites, and test-placement decision.
3. Exact new permanent tests, call-through argument/ordering observations,
   authentic refusal, negative handback and cleanup.
4. Opening V01 survivor and final V01/V02/V03 parse/import/collection/semantic
   results, selected node IDs, mutant identities and evidence-class distinctions.
5. One-file transition, 45/217 preservation and final replacement identity.
6. All twelve commands/memberships/inventories/counts/overlaps/warnings, failures,
   corrections/omissions and final clone equality.
7. Index/cache preservation, owned processes/roots and cleanup.
8. Outstanding independent acceptance and unchanged D1/D2/C2 nonclaims; a
   continuation capsule <=1,000 words.

For provenance drift, unfinished validation, unsafe cleanup or unproved current
opening/preservation:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V7_BLOCKED`

For a concrete production/owner contradiction or indispensable dependency beyond
the one test file:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V7_REPLAN_REQUIRED`

That requests review of the named bounded dependency, not automatic architectural
replanning or additional mutation permission.

Success requires deletion caught by permanent integration; real verification of
this run's candidate before readiness; authentic refusal prevents readiness;
three finite defect classes detected semantically; unchanged runtime/permissions;
all final groups pass; exact preservation and cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V7_VALIDATED_READY_FOR_REAUDIT`

Success supports ONLY a fresh independent read-only acceptance audit. No staging,
commit/publication, D2, physical C2, migration 0005, live authority/provider/
supplier, enrollment/deployment, Git effect, ES/Bridge integration or RW0-E.
This repair is not independent acceptance.
