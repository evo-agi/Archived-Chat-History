# Governed Execution Coordinator — RW0-D1 Audit Repair V8
# Observe every real worker launch across the C1 decision/recovery boundary

## FIRST ACTION — live guidance as text, never Git first

The first repository-related tool action after receiving THIS instruction must
read live AGENTS.md as plain text, from a neutral working directory. Do not run
status, rev-parse, a repository bootstrap or a settings command that invokes Git
first. This is a new, explicitly authorized REPAIR interval, not a continuation
of the auditor's observation interval and not permission to reconstruct history.

```sh
python3 -I -B -S - <<'PY'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY
```

Read all returned guidance, using further text reads if output truncates. Then
establish the pre-Git record/helper below BEFORE any Git command. Once opening
and authentication pass, complete the bounded repair without per-phase user
approvals. No intermediate architecture or standalone contract handoff.

## Mandate and classification

Resume the IMPLEMENTATION conversation owning the RETAINED V7 candidate. This
is one test-only repair inside the existing D1 implementation program. Do not
recreate the runtime, discard retained work, open a new semantic tranche, or
begin D2 or physical C2.

The latest independent audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

It reproduced a MEDIUM PERMANENT-TEST CAUSALITY GAP. The retained runner's
observed worker ordering is correct. In a disposable copy, changing only
_rw0_d1_offline.py to launch a real, unreported fake worker before C1 left BOTH
of these unchanged permanent tests passing:

```text
tests/test_rw0_d1_offline_integration.py::test_full_d1_through_guarded_writers_and_parent_capsule
tests/test_rw0_d1_offline_integration.py::test_unresolved_phase_recovery_retains_only_prior_prefix
```

The separate audit-only call-through observed:

```text
normal mutant:
    planner -> EXTRA worker -> C1 enter -> C1 commit return -> normal worker

committed-response-loss / unresolved mutant:
    planner -> EXTRA worker -> C1 committed, response lost -> recovery unresolved
    final handback reports no worker
```

Every observed child was real, reaped and group-clear. The observed survivor
cannot be fixed by checking only the final worker field, counting only reported
outcomes, or inspecting only the last worker call.

Current report pointers, to re-resolve against retained bytes:

- _rw0_d1_offline.py:382 -- C1 guarded mutation;
- _rw0_d1_offline.py:388 -- writer close after C1;
- _rw0_d1_offline.py:406 -- normal worker launch;
- _rw0_d1_process_supervisor.py:161 -- actual process creation;
- integration test :43 and :611 -- the two named surviving tests.

The exact auditor mutation payload is not supplied. Reproduce an equivalent
bounded one-module regression, not a claimed byte-identical historical mutant.
No observed current-runtime ordering defect was reported. Production MUST stay
unchanged. Strengthen the permanent integration evidence at the ACTUAL process
creation boundary so an unreported launch cannot be hidden by a handback.

The latest independent audit made real progress: it completed the V7 verifier
call/refusal and V01-V03 checks, finite B1 controls, four used durable-family
readbacks and replay/recovery checks, and all 29 tracked semantic diffs. It
passed final Groups 1-10, collected Group 11 and interrupted it after 233 passes,
and did not collect/run Group 12. The remaining finite negative-copy campaign
and full final-suite gate are still incomplete. Do not reset those prior
observations to 'unperformed', and do not relabel them as this repair's execution
or as complete acceptance. Detailed evidence limits appear in section 8.

Parent is the sole writer; no subagents. Use the highest exposed reasoning
setting; report visible model/effort/permission posture or `not visible`. Do not
seek extra account/computer access to expose hidden settings. No network,
credentials, real provider, sibling repository or publication action.

Return operative evidence INLINE with exact repository-relative path:line,
commands/results, final identities, limitations, and a continuation capsule
<=1,000 words. No delivered report/patch/archive/manifest/snapshot or architecture
package. No subsequent audit/publication/D2/C2 prompt. The mandate is complete;
no historical attachment or user choice about implementation details is needed.

## 1. Exact baseline and successful pre-Git mechanism

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

- branch trunk_dev;
- HEAD 0d0926e3a483a3ab1a4fd597ac0495927352bf35;
- tree 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4;
- sole parent 630414faa07f4ac39c4a870a9cc44c7f92d46b80;
- subject: docs: freeze RW0-C2 scope admission provisioning;
- upstream origin/trunk_dev, locally 0 ahead / 0 behind;
- one worktree, index equal to HEAD, zero staged/unmerged paths;
- exactly 29 modified and 17 created candidate paths below;
- no active Git operation, sequencer or unexpected lock.

After reading AGENTS, execute this block from a neutral directory. It invokes no
Git, repository module, SQLite or test. It captures the index and known cache
then creates a forced-environment inspection helper under a mode-0700 external
root. It retains the successful Restart 01 mechanism, with this engagement's
labels. Do not substitute historical timestamps, inodes or hashes for fresh
opening observation. The helper is temporary instrumentation, not product truth.

```sh
python3 -I -B -S - <<'PY'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env

import datetime
import shutil
import tempfile

# This block does not run Git or import repository modules.
guarded_environment()
for key, value in GUARDS.items():
    os.environ[key] = value
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_does_not_match_the_fixed_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_not_found')
root = Path(tempfile.mkdtemp(prefix='rw0-d1-v8-repair-'))
print('AUDIT_OWNED_ROOT=' + str(root), flush=True)
os.chmod(root, 0o700)
record = {
    'schema': 'rw0-d1-v8-repair-opening-observation',
    'phase': 'recorded-before-first-git-in-this-repair-attempt',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents,
    'index_path': str(index), 'index': index_before, 'cache': cache_before,
    'git_environment': GUARDS, 'git_executable': git,
    'historical_limit': 'older audits lack pre-first-Git metadata; this record covers only this repair',
}
wrapper_text = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\nimport subprocess\nimport sys\n\nopening_path = Path(__file__).with_name('opening.json')\nopening = json.loads(opening_path.read_text(encoding='utf-8'))\n\ndef verify_preservation():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('live_index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('live_index_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('live_guidance_drift')\n\nargs = sys.argv[1:]\nverify_preservation()\nenv = guarded_environment()\nif args == ['--check']:\n    print('RW0_D1_V8_REPAIR_OPENING_PRESERVATION_OK')\n    raise SystemExit(0)\n\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_git_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'],\n                                                               ['--quiet', 'HEAD']):\n    raise RuntimeError('only_readonly_head_symbolic_ref_allowed')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('only_worktree_list_allowed')\nfor arg in args[1:]:\n    if (arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec')\n            or arg.startswith(('--output=', '--exec='))):\n        raise RuntimeError('unapproved_git_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager',\n           '-c', 'core.fsmonitor=false', '-c', 'gc.auto=0',\n           '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=env, check=False)\nfinally:\n    verify_preservation()\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(payload)

try:
    write_private(root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(root / 'live_git.py', wrapper_text.encode('utf-8'))
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_any_git_command')
    print('LIVE_GIT_HELPER=' + str(root / 'live_git.py'))
    print('OPENING_RECORD=' + str(root / 'opening.json'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_V8_REPAIR_PRE_GIT_OPENING_RECORDED')
except BaseException:
    # Only known regular files written by this invocation are removed.
    for name in ('live_git.py', 'opening.json'):
        owned = root / name
        if owned.exists():
            if not stat.S_ISREG(owned.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            owned.unlink()
    root.rmdir()
    raise
PY
```

Use the ACTUAL emitted helper/root paths. Do not assume shell variables persist,
guess a temporary root, or rerun the opener to replace its record. Every LIVE
Git inspection goes through the helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> rev-parse HEAD
```

The helper enforces GIT_OPTIONAL_LOCKS=0, GIT_NO_LAZY_FETCH=1 and noninteractive
inspection per subprocess, disables external diff/textconv/fsmonitor and checks
index content/metadata and cache before/after. --check invokes no Git. It does
not wrap pytest, edit the test or prove correctness. It checks AGENTS/index/cache,
not the permitted test's opening hash, so it remains valid after the test edit.

Local-only external clone creation is separately permitted with equivalent
command-local suppression; no live index/config change, fetch or maintenance.
Remove clone remotes before execution. Missing objects/unsupported inspection
are a stop, not raw-Git fallback permission. No live Git write is authorized.

Authenticate baseline and complete candidate before editing; provide one compact
inline opening acknowledgement, then proceed automatically. If any Git preceded
this interval's opening, stop before clones, probes or edits. Do not reset the
index, reconstruct prior history, restore metadata or silently rebaseline.
The recent valid audit interval does not replace this repair's own record.

## 2. Exact retained V7 opening candidate

M is a tracked modification and C an untracked creation, not a Git copy/commit.
Require all 46 candidates to be regular nonsymlink OS-mode 0644 files with Git
representation 100644, strict UTF-8, no BOM/CR, one terminal LF and no trailing
whitespace. Preserve unrelated nonexecuting 0600 files, including the known
program-initialization test; do not impose 0644 on every noncandidate file.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 25,215 | `dde79042a7640571493f882b5130b8650c7a52ebd2fc28a6956799a261fa6d4c` | `absent` | 25,286 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 33,136 | `a4abd7236764b74c758bfbc133b4a1ecedef410801a0c39ce7a89ed0b1e85e4b` | `absent` | 33,211 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read all 29 M baseline blobs from HEAD and verify the recorded OIDs. All 17 C
paths are absent from HEAD and index. All 217 noncandidate tracked files remain
HEAD-exact in content, type and Git-relevant mode. Complete candidate: 263 file
endpoints = 246 HEAD files + 17 additions. No extra/deleted/renamed path, symlink,
submodule, executable bit or public export.

Reconstruct twice from independent fresh reads without importing candidate code:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 plus ONE NUL (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw HEAD blob bytes, or twenty zero bytes for C
    u64be(payload_length)
    exact file payload

46 rows: 29 M / 17 C
encoded row bytes: 4,524,290
prefix: 25
total: 4,524,315 bytes
SHA-256: b0d6c1192120ea0482617d2eb6ed7bfe779f6664a14de694b0a23949a5200a99
```

The complete current table is the subject. Earlier V6 bytes and mutation
payloads are not prerequisites. Do not recreate code from a digest, substitute
an old aggregate, or invent a new provenance grammar. On mismatch stop before
editing and preserve actual work.

## 3. ONE-file mutation ceiling

The only permitted LIVE edit is:

`tests/test_rw0_d1_offline_integration.py`

```text
opening status: C; absent from HEAD and index
OS mode: 0644; Git representation: 100644
payload bytes: 33,136
SHA-256: a4abd7236764b74c758bfbc133b4a1ecedef410801a0c39ce7a89ed0b1e85e4b
encoded component: 33,211
```

Strengthen the TWO NAMED surviving tests, keeping their names and current
behavioral assertions, and add only necessary test-local observation support
and bounded adjacent recovery/order cases within this file. Reuse existing
four-site recovery cases instead of starting another persistence test program.
No new conftest, helper module, dependency, global audit hook, or permanent
runtime trace is authorized.

Keep the other 45 candidate endpoints BYTE-EXACT: all nine D1 source modules,
other six D1 test modules, every document, B1 version-3 owner and both fixed
projections, V6 loader guard, Wire/Capability/scoped-C2 and all status guards.
Retain the V7 verification-order/refusal tests and their assertions. Keep all
217 noncandidate tracked files HEAD-exact, including existing private semantic,
writer, reader, recovery and transaction owners, exports/scripts, configuration
and migrations 0001-0004. Migration 0005 remains absent.

Do not add a launch latch, permission token, verified flag, extra handback field,
process ledger, database row, retry, import exception, or production wrapper.
A test-owned observation sequence is evidence only and must never authorize or
suppress a production stage.

No staging/commit/push/PR/merge, index write, branch change/reset/rebase, network,
installation, live provider/credentials/authority, supplier qualification,
enrollment/deployment, D2/physical-C2/terminal/ES/Bridge/RW0-E work.

Production mutations described below are permitted ONLY in disposable external
copies for causal tests. The live runner, supervisor and C1 owners must not be
edited to make the tests easier. Preserve retained work on any block.

## 4. Focused inspection and implementation sequence

Read the allowed integration module completely, especially both named tests,
all current response-loss/unresolved-recovery cases, and the V7 tests. Inspect
only the relevant owning source/context in:

- _rw0_d1_offline.py: whole invocation, real launch lookups, four guarded durable
  calls, recovery decisions, writer closures and every stop/cleanup path;
- _rw0_d1_process_supervisor.py: the actual Popen lookup, arguments, return,
  reaping and group-clear behavior;
- _rw0_d1_pre_execution.py and current C1 mutation/recovery/value owners: exact
  success, exact replay, committed_exact and unresolved result conventions;
- _rw0_d1_fake_planner.py / _rw0_d1_fake_worker.py: actual -m identities;
- current workspace/handback lifetime and cleanup APIs;
- .docs/rw0-d1-offline-process-and-capsule-spine.md, current phase-entry and C1
  contracts; any direct guard/content dependency of the one test as DATA only.

Resolve actual private functions/result shapes before authoring hooks. The
reported line numbers and trace are pointers, not substitutes for inspection.
Do not import repository code in the live checkout.

Return a compact INLINE map of actual process-creation interception point,
planner/worker module identifiers, C1 method and recovery result conventions,
writer-close completion point, current test helper/fault sites, and the new
fixed assertions. Then continue without a user checkpoint.

Selected implementation sequence:

1. Authenticate opening and all retained bytes.
2. Read the narrow caller/owner/test chain and resolve interception points.
3. In an external OPENING copy reproduce the unreported pre-C1 worker and both
   named surviving tests, separately confirming the actual child sequence.
4. Strengthen the two named permanent tests and reuse their launch observer in
   the bounded existing recovery cases.
5. Run normal positives and finite transformed controls on FINAL test bytes.
6. After the last edit, build a fresh normal candidate clone for all 12 groups.
7. Recompute complete receipts, preserve live state, clean owned resources,
   and return a bounded implementation-validation closeout.

If the unchanged current runtime actually violates its stated launch/commit/
recovery/close ordering, report that source-backed production defect and stop.
Do not weaken an assertion, invent a different contract, or edit production
under this test-only ceiling.

## 5. Test-owned observation at the actual launch boundary

Implement the smallest test-local, scoped observer inside the one allowed test
file. It must see ALL process creation requests for a single D1 invocation,
including any early, duplicate, ignored or unreported fake worker.

### Launch observations

Intercept the actual subprocess.Popen lookup used by the existing sole D1
supervisor, below the runner's chosen supervisor-return/handback assignments.
Resolve the import form from source. Call through to the original Popen in the
CURRENT external module/process, preserving its real arguments and behavior.
Do not replace the actual supervisor with a fake result.

For each attempt record test-local facts sufficient to compare:

- an attempt event before calling original Popen;
- actual argument vector and derived fixed child role (planner or worker);
- the returned real process handle/PID, or a genuine start failure;
- event sequence/order relative to C1 and writer closure;
- process handles needed to account for reap/cleanup in finally blocks.

Use the actual '-m ge_nwp_coordinator._rw0_d1_fake_planner' and
'-m ge_nwp_coordinator._rw0_d1_fake_worker' command targets, not a handback field,
caller-supplied role flag, wrapper nickname or expected list position. Unexpected
launches within the private invocation must not be silently discarded.

Install observation BEFORE entering run_rw0_d1_offline and keep it through the
whole invocation, including response-loss handling, stop/exception cleanup and
return. Use an isolated per-invocation record. Test setup/subprocesses outside
that interval are not this invocation's planner/worker history; do not erase or
filter in-interval children merely because their outcome was never returned.
Do not enable recording only when C1 begins, or keep only the most recent worker.

The observer must be OBSERVATIONAL, not an extra launch gate. Delegate to real
Popen; do not raise before a forbidden mutant launch to prevent the behavior the
test is supposed to detect. Assert the recorded invariant at a safe boundary
with finally-based cleanup. Do not call a worker directly from the permanent
test just to populate its expected trace.

This is scoped Python call-through evidence for fixed proof children. It is not
a universal OS audit of processes started through arbitrary native code, an
adversarial same-UID sandbox, or a new production supervisor. Do not widen into
that architecture.

### Durable completion and close observations

Wrap the actual guarded C1 method/recovery lookup used by the runner and call
through. Record method entry separately from completion. Record a successful
C1 result only AFTER the owner returns its exact valid success/exact-replay
result; retain its actual basis/receipt/identity coordinates for comparison.
Record successful recovery only AFTER the effective result returned TO THE
RUNNER is committed_exact with its exact current family, not before.

Distinguish three events when exercising commit-response loss:

```text
underlying C1 write completed physically
    != runner received an ordinary confirmed result
    != runner received committed_exact recovery
```

If a fault wrapper calls the real owner, loses the reply, then exposes unresolved
recovery, an internally observed commit or a success subsequently replaced by
that unresolved result must NOT become the test's resolved-C1 event. Bind the
observation to the effective caller-facing outcome after the intended fault
injection. Never set a `c1_done` flag at method ENTRY, in fixture setup, from
row presence alone, or from the final handback.

Wrap actual writer/state-authority close completion by calling the original
method. Record completion only when it returns as required by current ownership.
The last relevant writer/recovery session must be closed before each child
creation attempt. A test boolean must not substitute for that close observation.
Use current test/call-through mechanisms without replacing evidence class
identities or changing result constructors.

The sequence is test evidence, not a shadow program state machine. It does not
select, commit, recover, author a phase, or permit a child. No new observation
is added to production or serialized as run truth.

### Cleanup independent of reported handback

Keep handles for ALL observed children, including unreported mutant children.
Allow the real supervisor to perform its normal termination/reap/group checks;
verify those outcomes where the test claims them. In finally, close any returned
run explicitly and account for owned state/workspace/planner roots. If a test
assertion fails, cleanup must still happen. Do not claim the runtime reaped a
child if the test had to do emergency cleanup instead; report the intervention.

Emergency cleanup may use only the known task-owned process objects/groups and
roots after positive ownership identification. No kill-by-name, global /tmp
sweep, finalizer reliance, or deletion of another invocation's original run.
Observer event lists and raw path/argument details stay test-local; permanent
failure output should avoid dumping raw state locations or payloads.

## 6. Permanent test obligations

### A. Strengthen the named normal integration test

Keep and strengthen:

`test_full_d1_through_guarded_writers_and_parent_capsule`

Use the real private D1 entry, current guarded program/author/Section 41/C1
owners and fixed fake children. Keep all existing assertions and V7 capsule
causality tests intact.

For the current one-shot successful invocation require:

- exactly ONE actual planner launch attempt and created planner PID;
- exactly ONE actual worker launch attempt and created worker PID;
- no other invocation child launch;
- actual child sequence exactly planner then worker;
- successful planner completion and current selected Section 41 evidence;
- C1 normal success/exact replay or effective committed_exact recovery before
  EVERY worker attempt, with matching current phase basis and result/receipt;
- completion of the relevant writer/lock close before each child attempt;
- returned process observations correspond to the actually observed children;
- capsule verification/readiness, resource custody and cleanup remain as the
  current tests already require.

A mere count of two is insufficient: a count-preserving move of the sole worker
before C1 must fail the ordering assertion. Seeing one good worker after C1 is
also insufficient: any earlier or extra unreported worker must fail the complete
launch-sequence/count assertion. The final handback cannot rescue either.

### B. Strengthen the named unresolved-C1 test

Keep and strengthen:

`test_unresolved_phase_recovery_retains_only_prior_prefix`

Preserve the test's real guarded C1 call-through, simulated committed response
loss and effective unresolved recovery. Do not replace actual persistence with
an uncommitted exception just to avoid reaching the hard case.

Require across the WHOLE invocation:

- exactly one real planner; its actual close/reap facts retained;
- the underlying C1 operation was called; committed-response-loss and effective
  unresolved recovery were reached by the existing current owner/test fault;
- ZERO worker launch attempts and ZERO worker PIDs anywhere in the interval,
  including before the C1 call and after the underlying commit but before
  recovery resolves;
- exact existing stopped/unresolved handback and permitted prior prefix;
- no selected worker observation, Wire/capture/manifest claim or duplicate
  author delivery;
- no rollback/fabricated absence of the committed phase to make the test pass;
- parent-owned state and all actual children cleaned under current ownership.

The empty handback worker field is SECONDARY. Zero launch attempts/PIDs at the
lower boundary is the discriminating assertion. A real early worker whose result
is discarded must still fail the test.

### C. Apply the same observation to the existing bounded recovery cases

Reuse current test-local four-site response-loss/unresolved cases; do not create
a new recovery implementation or broad readback framework. Strengthen/add only
minimal cases needed to bind the existing launch expectations to real effects:

| Scenario | Planner attempts/PIDs | Worker attempts/PIDs | Required boundary |
|---|---:|---:|---|
| Ordinary successful run | 1 | 1 | worker after C1 result and writer close |
| Committed response loss with effective committed_exact recovery at a current owner | 1 | 1 | no duplicate delivery; worker after C1 resolution and final close |
| Program unresolved | 0 | 0 | no child at all |
| Author-effect unresolved | 0 | 0 | no child at all |
| Section 41 selection unresolved | 1 | 0 | no worker, no C1 advancement |
| C1 unresolved | 1 | 0 | no worker even though the original write may have committed |

For phase response loss followed by committed_exact recovery, specifically prove
that the worker occurs AFTER the effective recovery return and the recovery
writer close, not merely after the physical commit. This positive path prevents
a vacuous 'never launch any worker after response loss' repair.

Use fixed expectations from current owners, not counts obtained from the tested
handback. Do not increase the product's allowed number of workers or mint a
replacement delivery. Unsupported new owner behavior is not to be invented.
A few parameterized assertions reusing current cases are preferable to another
large test harness. Preserve complete original node intent and node names.

## 7. Finite opening reproduction and final causal copies

Keep all mutation work in disposable external copies. Do not execute the live
checkout or edit its production source.

### Opening reproduction

Before editing the integration test, create an exact external opening copy and
modify ONLY _rw0_d1_offline.py to launch an additional real fixed fake worker
before the C1 method is called. Retain the normal worker launch later and do not
place the extra outcome in the returned handback. Use the existing supervisor,
actual bounded command/fences and a separately owned disposable worker workspace
so the speculative launch does not merely corrupt the later normal fixture.
No database path, credentials or live authority may be supplied to it.

The auditor's exact code is unavailable. Produce the smallest equivalent
one-module regression with a reviewable before/after diff, using actual source
construction points. Record specimen identity and call sites. Do not claim byte
identity with the auditor's original mutation or its historical PIDs.

On this OPENING mutation, independently verify parse/package import, normal
collection and execution of BOTH named original tests. Reproduce their survivors
where the equivalent mutation permits it. Separately call through to real
process creation and C1/recovery to show:

```text
happy path: planner, extra worker, C1, normal worker
unresolved phase: planner, extra worker, committed-response loss, unresolved
```

Observe actual successful child creations, not a synthetic 'worker' event. Reap
and clean every extra child and its roots. This opening observer is audit-only
characterization; it is not the final permanent-test remedy.

### Final-byte controls: three bounded effect classes

Keep the final integration test and its fixed expectations unchanged in every
external mutation. Fresh imports/processes must use that copy's source, not a
saved pre-mutation run function.

| ID | External-only regression | Required permanent discrimination |
|---|---|---|
| L01 | Additional unreported real worker before C1, normal later worker retained | Both named tests fail on complete launch/count/order evidence despite otherwise plausible handbacks; show actual early PID in happy and unresolved paths |
| L02 | Move the sole worker before C1, suppress its normal later launch, preserving a two-child happy-path count | Normal named test fails on C1-before-worker ordering, not on total count or an unrelated malformed fixture |
| L03 | On the committed-response-loss C1 branch, launch an unreported worker after the physical commit but before an effective unresolved recovery result | Named unresolved test fails on a real forbidden worker attempt/PID; physical commit alone cannot satisfy the positive-resolution predicate |

These are concrete causal checks for the already-required 'worker before C1 or
after unresolved durability' safeguard. Do not expand into arbitrary process
spawning, scheduler interleavings, new platform support or a general mutation
framework. One transformation may cover multiple rows if its distinct event
relationships truly discriminate them and are explicitly mapped. Do not count
L01's three children as proof of L02's count-preserving ordering assertion.

For L02/L03 use the smallest source-grounded external-only transformation that
reaches the specified real process trace. Keep exact valid command/fence and
workspace inputs so an unrelated frame/type/capsule failure is not credited as
launch-order detection. No success requirement for malformed unrelated inputs.

Require for each final copy:

- complete affected module parses and actually imports in package context;
- final integration-module node inventory is unchanged and collects normally;
- the selected permanent test fails on the named launch/phase/recovery assertion;
- no syntax/import/collection or global source-inventory failure gets credit;
- no observer-generated exception prevented the real launch used as the specimen;
- all actual observed children and roots are accounted for even on assertion
  failure, including a speculative worker missing from the returned handback.

Run the normal final copy through all strengthened cases and the retained V7
verifier tests. It must pass. No full-suite run per mutant. The opening selected
survivor and final selected rejection are sufficient; do not require the full
opening D1/full suite again just to reconfirm an already demonstrated two-test
hole. All normal final groups still run below.

If a suitable transformation cannot be made without an unrelated source failure,
record the limit rather than reporting a causal pass. If the unchanged candidate
itself launches outside the contract, stop for a production review; no source
repair is authorized in this task.

## 8. Prior independent evidence and remaining acceptance work

Keep the latest auditor's observations accurately classified as PRIOR
INDEPENDENT EVIDENCE, not this repair's execution or complete acceptance:

- valid pre-Git index/cache opening and closing; all 46 candidate/217 other
  endpoints exact at 4,524,315 bytes and the stated digest;
- actual retained order writer_close_done -> child_launch for both children;
- V7 capsule positive/refusal and V01/V02/V03 discrimination completed;
- finite B1 alias/projection/regression checks and selected Wire checks completed;
- process/capture/type/custody/failure checks completed as described in that report;
- complete USED durable-family readback: 9 program rows/8 graph entries,
  10 author-effect rows/9 graph entries, 22 Section 41 rows/14 evidence bindings,
  17 C1 rows/14 operands; owner recovery committed_exact and exact replay with no
  added family row or changed original time; four response-loss and unresolved
  ordering/stop cases;
- actual child-launch interception confirmed stated options and exclusion of
  database/credential sentinels from arguments, environment and cwd. Do not
  inflate this to every independent inherited-FD case or an adversarial sandbox;
- all 29 tracked semantic diffs reviewed (13 guidance/doc and 16 test changes);
- final Groups 1-10 passed at fixed counts/hashes; Group 11 collection was 679,
  execution interrupted after 233 passes; Group 12 was not collected/run.

These observations must not again be described as if row-by-row readback or the
29-diff review had never occurred. They are still report-supplied observations
until a later reviewer accepts them in context; they are not a global acceptance
verdict or a new test oracle generated from returned data.

The remaining P/N/R/W/B and original finite mutation obligations, any unperformed
parts of the selected runtime/FD/workspace campaigns, and completed final
Groups 11-12/full membership were left open. This repair validates its bounded
new tests and all normal final groups; it does NOT claim to perform the remaining
independent acceptance campaign or close it through an implementation pass count.
A subsequent independent audit still owns acceptance of the new exact candidate.

D1 -> D2 -> physical C2 remains fixed. No new source/model/worker/validator/
reviewer/C2/terminal/live authority or publication capability is introduced here.
The event observer is test evidence, not program truth or runtime authority.

## 9. External execution and complete final validation

The sole allowed live edit is the integration test. No live-checkout repository
import, pytest, child process, script, compilation, SQLite or operator/product
state access. All executable work uses local-only external copies of exact HEAD
with the 46 authenticated candidates overlaid. Remove configured remotes before
execution; installed dependencies only, no network.

Keep the true opening/helper until final live checks. Use task-owned mode-0700
roots, test-process umask 022, owned TMPDIR, disabled bytecode and pytest cache,
precreated distinct collect/run basetemp parents, and serial non-overlapping
runs. Preserve actual source modes. Do not copy the live opaque cache into a
normal candidate clone or count it among 263 source endpoints.

After the LAST edit, build ONE fresh NORMAL final clone, not a reused mutant.
Verify all 263 endpoints before and after. Run collection then execution for all
12 groups, with no xdist, test removal, skip/xfail, warning suppression, altered
selectors or inherited superseded pass:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Each token below expands to tests/test_<token>.py. Sort/deduplicate ONLY within
a group. Group 12 has NO path arguments and still includes 124 test modules.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

For each sorted repository-relative module path, the test-file inventory stream
appends:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

Exact OPENING inventories and prior implementation references:

| Group | Files | Reported collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 110 / 110 | `f5a33fffbeee1bc845cc8742d4d802a941510b590288a3884f692be61c9d048e` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,982 / 8,982 | `76b30875b8868ead3d1052fce30ad226b8e0260eb16a8bcc19460332be55caac` |

The latest audit independently completed Groups 1-10, not Groups 11-12. The table
is the exact opening inventory to authenticate, not this repair's pass evidence.
Only tests/test_rw0_d1_offline_integration.py may change. Therefore:

- Groups 2-11: preserve exact memberships, file bytes and inventory hashes; rerun
  their listed normal regressions after the final edit.
- Groups 1 and 12: recompute inventory digests, collect and run final bytes.
- Retain all existing cases and expectations. New parametrization may increase
  counts; strengthening existing assertions need not. Do not force a new count.

Bookkeeping only:

```text
final full count = 8,982 + (final Group 1 count - 110)
                 = 8,872 + final Group 1 count
Group 2/3 overlap = 46; Group 7/11 overlap = 31
Group 1-11 union = 3,545 + final Group 1 count, if those are the only overlaps
```

Preserve full pytest node IDs including parameter text containing spaces. Every
Group 1-11 node must belong to final Group 12. Inventory equality is not
execution; overlapping groups' counts do not sum to unique coverage.

Groups 10 and 12 have the same three existing Python 3.13 multithreaded-fork
DeprecationWarning records at:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured records; repetition between these groups is not another
warning class. Investigate new warnings/failures or unsupported required POSIX
execution. Do not substitute an earlier report for the missing run.

Also require:

- live git diff --check through the guarded helper;
- all 17 addition no-index whitespace checks; status 1 without a whitespace
  diagnostic is the ordinary difference result;
- strict encoding/final-LF and complete candidate path/type/mode checks;
- all 45 other candidate endpoints unchanged and 217 noncandidate files HEAD-exact;
- unchanged V7 verification tests' purpose/assertions and runtime verification;
- unchanged B1/Wire registry, permissions, guard identities, all documents;
- exact nine D1 modules, two fake entry points, sole subprocess owner;
- current production/package exports/scripts/StateStore/schemas/migrations exact;
- migration 0005 absent;
- normal final clone has all 263 expected endpoints and no extra repository files;
- live index CONTENT and all recorded metadata equal true opening;
- live cache DIRECTORY and all 37 member records, including nanosecond mtimes,
  equal true opening.

An identified external test-runner mistake may be corrected OUTSIDE the live
checkout; rerun each affected gate from the same final bytes and record the
failed/interrupted trial. Do not silently replace a fixed expectation. Any late
candidate edit invalidates inherited final validation.

Use lstat during artifact scans. Hash only regular files; never follow symlinks
or open FIFOs/sockets/devices. Identify and finish every owned process before
removing its roots. Check the SAME opening record/helper for final live equality
before deleting the known helper/root. No index/cache/source metadata repair or
normalization, no process-name sweep or unrelated temporary-root deletion.

## 10. Retained-work closeout and stop conditions

Preserve all retained work on every stop. No wholesale rollback/reset, recreation
from hashes, deletion of another actor's work or restoration of index timestamps.
Baseline HEAD/tree/parent/branch and index remain unchanged; status stays
29 M / 17 C. Only the authorized integration test differs from this opening.

Recompute all 46 endpoint receipts and the SAME replacement stream twice. Report
one exact before/after transition and proof the other 45 endpoints are unchanged:

```text
final replacement bytes = 4,524,315 + (final integration-test bytes - 33,136)
```

Include actual target payload/hash, unchanged absent HEAD/index entry, OS/Git
mode, encoded component, encoded-row/prefix/total lengths and final measured
aggregate SHA-256. Do not invent a final hash or add a provenance schema.
No user-delivered receipt/package is required.

Return inline:

1. Verdict/settings and exact true opening/baseline/index/cache record.
2. Actual process-creation hook, effective C1/recovery return and writer-close
   observation points, selected test-local design and dependency inspection.
3. Both named tests' strengthened assertions, real normal/recovered/unresolved
   traces, all attempted/created planner/worker counts and handback reconciliation.
4. Equivalent opening L01 survivor in both named tests; final L01/L02/L03
   copy identities, parse/import/collection and exact semantic failures. Distinguish
   effect observations, permanent test protection and audit-only characterization.
5. Preservation of legitimate committed_exact recovery and all four unresolved
   stops, no production change or shadow execution authority.
6. One-file transition, 45/217 preservation and full replacement identity.
7. All twelve exact command/membership/inventory/node/overlap/warning results;
   failed trials, external corrections, omissions and normal final-clone equality.
8. Every observed child, group and root cleanup, including unreported mutant
   workers; record emergency test cleanup separately from normal runtime cleanup.
9. Index/cache preservation and exact inherited independent evidence/omissions.
10. Continuation capsule <=1,000 words naming only the next eligible audit step.

For baseline/provenance drift, unfinished required validation, unsafe cleanup
or an unproved required opening/preservation record, use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V8_BLOCKED`

For a concrete actual production/owner contradiction or essential dependency
outside this one test file, use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V8_REPLAN_REQUIRED`

That token requests review of the named dependency; it grants no automatic
runtime rewrite, new contract tranche or path expansion. An unselected broader
security model is not a reason to redesign the artificial D1 proof.

Success requires actual per-invocation launch observation; both named permanent
tests detect unreported pre-C1 work; count-preserving order and unresolved-reply
controls discriminate; legitimate recovery still works; runtime/permissions stay
unchanged; every final group passes; exact preservation and cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V8_VALIDATED_READY_FOR_REAUDIT`

Success supports ONLY an independent read-only acceptance audit of the new exact
candidate. No staging/commit/publication, D2/physical C2/migration 0005,
provider/supplier/live authority/enrollment/deployment, Git effect, ES/Bridge or
RW0-E is authorized. Implementation validation does not close the remaining
independent acceptance obligations.
