## Disposition

**Accept the independent audit block. Repair the existing 46-path candidate; do not replan RW0-D1 and do not stage or commit.**

The audit independently confirmed the most important architectural claims:

- the normal invocation uses the actual guarded program, author-effect, Section 41, and RW0-C1 paths in the required order;
- durable uncertainty blocks later process launch;
- writers are closed before both child processes;
- the tested child boundary excludes database, state, lock, credential, and inherited-descriptor sentinels;
- timeout, TERM→KILL escalation, reap, workspace containment, candidate capture, and independent capsule verification work in the tested paths;
- D2, durable C2, terminal, provider, Git, ES, and Bridge behavior remain absent. Pasted text

The four findings are bounded implementation defects in existing D1 owners. None requires another semantic tranche, durable-owner redesign, or broader architecture decision.

## Required repairs

### 1. Make the handback a real typed boundary

`RW0D1HandbackV1` currently accepts arbitrary object-valued evidence and does not enforce a complete relationship among status, reason, and available evidence. The audit could construct `capsule_ready` without the required worker/process/Wire evidence and could place a live `Path` in the supposedly typed handback. A transformed actual-run candidate could add the live state root while the existing D1 and governance tests stayed green. Pasted text

The repair must:

- remove `object`, `Any`, path-like values, live resource owners, sessions, locks, proofs, and arbitrary mutable containers from handback fields;
- freeze the exact field inventory and accepted types;
- enforce an explicit status/reason/evidence matrix;
- require full planner, worker, Wire, candidate, capsule, durable-lineage, and completed-cleanup evidence for `capsule_ready`;
- reserve `cleanup_unresolved` for cleanup uncertainty while retaining already observed process evidence;
- reject stopped/cleanup reason mismatches;
- prove an actual successful handback contains no state path, workspace path, session, descriptor, lock, proof, capability, or run owner.

The test must also detect a future extra `state_path`, generic `metadata`, or arbitrary `object` field—not only reject a path passed through one current slot.

### 2. Fence the disposable-state owner to its creating process

A forked child can currently call `run.close()` and delete the parent’s database. The child’s copied `_closed` state then diverges from the parent, whose later close raises `FileNotFoundError`. Pasted text

The run owner must capture its creator PID and check it before every operation that exposes or mutates retained-state custody, including:

```text
close()
context-manager entry/exit
state-location or database access intended for D2
```

A noncreator must receive a private ownership error with **no state deletion, closed-flag mutation, path disclosure, or parent-resource effect**.

A real POSIX fork test must establish:

```text
child close rejected
→ parent state still exists
→ parent remains open
→ parent close succeeds
→ second parent close is idempotent
→ state root is removed
```

The immutable handback may remain readable in the child only because the strengthened handback contains no live authority.

### 3. Preserve process evidence when cleanup is uncertain

A selector-close failure currently escapes before group-clear observation and process-outcome construction. The offline layer then converts the exception to `stopped/durable_conflict` and loses the planner process observation. Pasted text

Selector or stream cleanup must become a separate outcome dimension:

```text
retain PID/group/I/O/deadline/cancel/signal/exit/reap facts
→ attempt group-clear observation
→ record selector cleanup uncertainty
→ return a typed process outcome
→ map to cleanup_unresolved
```

It must never:

```text
erase the process outcome
escape as an untyped exception
be labeled durable_conflict
permit later durable or capsule progression
```

Planner cleanup uncertainty stops before Section 41. Worker cleanup uncertainty cannot produce `capsule_ready`. Timeout or cancellation evidence must remain visible even when cleanup itself is unresolved.

### 4. Normalize malformed frame types

The frame decoder currently performs a membership check before validating that `action` is an exact string, so a canonical frame containing:

```json
{"action":[]}
```

can raise raw `TypeError` rather than the closed `D1FrameError`. The offline layer then misclassifies it as a generic durable conflict. Pasted text

Every membership or lookup field in D1O1 and D1W1 must follow:

```text
exact built-in type
→ closed-value validation
→ D1FrameError on malformed input
```

No malformed frame may leak `TypeError`, `KeyError`, `AttributeError`, or an unhashable-value exception. A malformed planner response must map to the existing planner-frame reason and stop before Section 41.

## Repair boundary

Only these eight paths may change:

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_offline.py

tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_offline_integration.py
```

The other **38 candidate paths** remain byte-identical. No document or governance-guard amendment is justified by this audit.

The opening candidate remains bound to:

```text
Baseline HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created files

Replacement identity:
4,422,240 bytes
c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef
```

The audit reproduced that identity and every endpoint receipt. Pasted text

## Validation consequence

The audit stopped the full repository run after 1,405 passing tests because the Medium findings already barred acceptance. It did not claim the earlier 8,877-pass result or groups 2–11 as independently reproduced. Pasted text

The repair must therefore rerun **all twelve validation groups from final repaired bytes**, not only the four directly changed tests.

Groups 2–11 should retain their previous test-file identities, counts, and inventory hashes. Group 1 may grow. Since the other tests remain unchanged:

```text
final full count = 8,820 + final D1-group count
```

The prompt also corrects the audit-process evidence gap: the live-cache inventory must capture nanosecond mtimes at the true opening, not only during a later before/after comparison. The audit found no cache mutation, but could not prove full-period nanosecond equality from its original opening record. Pasted text

## Codex handoff

Resume the **same implementation Codex conversation**, with the parent as sole writer.

:chatgpt-content-reference{index="9"}[Download the complete RW0-D1 audit-repair prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V1_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V1_Prompt.txt

Bytes:
33,361

SHA-256:
68be5c60b736b1cb7ef7b24670fba7caab6b0251a96709c43d3b80fcb4696827

Logical lines:
576

Final newline:
present
```

The prompt includes:

- the complete 46-path opening receipt table;
- the exact replacement-identity recipe;
- the eight-path repair ceiling;
- typed handback and status-matrix requirements;
- real fork fencing tests;
- selector-cleanup and process-evidence requirements;
- closed frame-error normalization;
- ten transformed defect copies;
- all twelve validation groups and their unchanged inventory coordinates;
- exact checkout, noncandidate, migration, package, and cache preservation gates.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V1_VALIDATED_READY_FOR_REAUDIT
```

A successful repair authorizes only a **fresh independent read-only re-audit**. It does not authorize commit, publication, D2, RW0-C2 physical implementation, migration `0005`, live provider or supplier work, Git effects, ES/Bridge integration, or RW0-E.

**Source:** The attached RW0-D1 independent audit, read in full. Pasted text

**Confidence:** High on the audit block and the eight-path repair boundary. High that these are runtime-invariant and evidence-boundary defects rather than a failure of the selected D1 authority architecture.
