# Disposition

**Accept the block, but reject the formal `REPLAN_REQUIRED` classification.**

This is the second mutation-ceiling miss, not evidence that RW0-D1’s architecture is unsound. The implementation reached integrated validation:

```text
D1 focused tests:        60 passed
Owner/status group:   1,105 passed
Full repository:      8,864 passed / 9 failed / 3 warnings
```

All nine failures came from pre-existing guards whose historical assumptions are now changed by the explicitly authorized D1 source tranche. Codex restored every task edit and removed every created file, so **no candidate remains**. D1 must be recreated from the clean merged baseline.

The prior corrected prompt was still incomplete. It admitted the current-status and exact-document-identity guards but missed the older, source-wide assurance guards. That omission is mine.

## Complete known conflict set

The nine failures span **eight test files**.

### Blanket D1 absence

```text
tests/test_post_execution_pure_owner_boundaries.py
```

Its S004 check currently rejects every file matching:

```text
_rw0_d*.py
```

That must become a bounded inventory check admitting exactly the nine D1 modules, while continuing to prohibit D2, RW0-E, terminal runtime, and durable C2 decision implementation.

### Temporary complete-source manifest

```text
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

This test and its owner currently freeze the entire production-source tree by file count, payload length, and SHA-256. That was explicitly marked as temporary until a future authorized source tranche. D1 is now that tranche.

The correct repair is **not** to update the whole-source hash to another brittle snapshot. The complete-tree barrier should be superseded inside this source-bearing tranche by the existing scoped C2 nonimplementation guards: no C2 persistence module, caller, export, acceptance writer, terminal owner, runtime activation, or migration `0005`.

That bounded clarification also requires amending:

```text
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
```

The C2 branch, matrix, replay, recovery, acceptance, and terminal semantics remain frozen.

### Five historical “no subprocess anywhere” guards

```text
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
```

These historical tests concatenate essentially all production source and reject the token `subprocess`. Their intended B0/B1/B2A/B2C/B3A boundaries remain valid, but the global formulation is no longer valid after an authorized later D1 runtime owner exists.

They should admit exactly:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
```

as the sole production subprocess owner.

They must continue to reject subprocess use in:

```text
_rw0_d1_offline.py
the fake child modules
workspace and capsule modules
SQLite modules
writer/session modules
pure semantic modules
package-root or public modules
every other production source file
```

All other no-network, no-service, no-scheduler, no-queue, no-public-backend, no-StateStore-widening, lock-ownership, and migration assertions remain unchanged.

### Exact B1 importer inventory

```text
tests/test_rw0_b1_boundaries.py
```

RW0-B1’s current owner says RW0-B2-Capability is the sole cross-module production consumer. D1 now needs one bounded runtime consumer to construct the existing `RW0PhaseEntryBasisV1` for the guarded C1 operation.

This is an owner-document contradiction, not just a stale test. It requires a bounded amendment to:

```text
.docs/rw0-b1-pure-phase-values.md
```

The registry should advance to version 2 and distinguish:

```text
sole current pure consumer:
RW0-B2-Capability

bounded runtime consumer:
RW0-D1 pre-execution composition
```

The D1 direct B1 import must be centralized in:

```text
src/ge_nwp_coordinator/_rw0_d1_pre_execution.py
```

and limited to:

```text
RW0PhaseEntryBasisV1
```

D1 gains no B1 source-authentication, executable-permission, persistence, or semantic-acceptance authority.

The corresponding exact registry projection in the already admitted remote-phase test must advance with it.

## Why this is not another semantic tranche

The two owner amendments are consequences of actual source implementation:

- B1 has acquired one new bounded consumer.
- The C2 contract’s temporary global source manifest has reached its named supersession point.

They belong in the D1 implementation candidate. They do not precede source work and do not reopen the frozen domain contracts.

The operative D1 design remains unchanged:

```text
current program initialization
→ current author-effect establishment
→ fake planner process
→ current Section 41 selection
→ current RW0-C1 phase establishment
→ fake worker process
→ bounded workspace mutation
→ parent candidate capture
→ parent capsule construction
→ independent capsule verification
→ typed D1 handback
```

The implementation map already found these existing authority paths composable and identified the nine D1 source modules and their responsibilities. Pasted text Pasted text

## Corrected implementation handoff

Resume the **same Codex implementation conversation**. The checkout is clean, so this prompt recreates the integrated D1 candidate from the merged baseline.

:chatgpt-content-reference{index="2"}[Download the complete RW0-D1 implementation prompt V3](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt_V3.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Implementation_Prompt_V3.txt

Bytes:
55,000

SHA-256:
8503a0115543ed8048e57eb87e4ee6e98a367e1b01cfd4bcf4d3c6350719bb39

Logical lines:
1,440

Final newline:
present
```

The exact baseline remains:

```text
Branch:
trunk_dev

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Sole parent:
630414faa07f4ac39c4a870a9cc44c7f92d46b80
```

The V3 prompt preserves the entire source implementation mandate and adds the complete known guard/owner coordination.

It now authorizes, in addition to the previous D1 surface:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md

tests/test_post_execution_pure_owner_boundaries.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_b1_boundaries.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
```

The prompt requires:

- exactly one production subprocess owner;
- an exact nine-module D1 inventory;
- continued D2/RW0-E/terminal/C2-runtime absence;
- a version-2 B1 registry and one bounded D1 importer;
- supersession of the temporary complete-source manifest rather than repeated rehashing;
- preservation of the scoped C2 module/import/call/export/migration guards;
- dedicated validation of all eight legacy guard files;
- all prior D1 focused, durable-path, status, Capability, bootstrap-guard, and full-repository validation;
- a stop if another authority owner or exact-identity guard outside this expanded ceiling is discovered.

The success token remains:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

`REPLAN_REQUIRED` is now reserved for an actual authority or implementation contradiction—such as shadow program truth, required child access to writer authority, inability to establish C1 before contact, or inability to construct and independently verify the capsule—not another historical guard that must advance with authorized source.

## Nonclaims

This correction does not claim that the discarded implementation was complete or correct. Its partial test results are diagnostic evidence only.

It does not authorize:

- intermediate D1 commits;
- D2 or RW0-C2 implementation;
- migration `0005`;
- live provider or supplier work;
- credentials or network access;
- Git or publication effects;
- ES or Bridge integration;
- RW0-E.

No expired historical attachment is needed for this retry. The current October 15 snapshot and the Codex closeout are sufficient.

**Sources:** Codex’s blocked D1 closeout in this turn; current merged Coordinator snapshot, especially the eight guard tests and the RW0-B1 and RW0-C2 owners; the accepted D1 implementation map.  
**Confidence:** High that this is a complete known guard/owner correction rather than an architecture replan. Medium-high that no further exact-identity dependency will emerge; the prompt requires a bounded stop rather than another silent path expansion if one does.
