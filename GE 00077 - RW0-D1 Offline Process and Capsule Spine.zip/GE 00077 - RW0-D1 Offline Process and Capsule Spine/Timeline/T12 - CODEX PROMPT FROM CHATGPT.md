# Governed Execution Coordinator — RW0-D1 Offline Process and Capsule Spine: Independent Audit

## Mandate

Perform one fresh, parent-only, repository-first, READ-ONLY independent audit of
the exact uncommitted RW0-D1 implementation candidate below.

Implementation closeout:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

The closeout is evidence to verify, not acceptance. This is the first
runtime-bearing offline vertical slice. Audit actual process behavior, current
durable-authority reuse, workspace/capsule custody, resource cleanup, typed
handback, and the bounded governance changes. Do not judge the candidate only
from hashes or green tests.

Do not repair, format, stage, commit, publish, implement D2/C2, or perform any
live provider, supplier, credential, Git-publication, Bridge, ES, or RW0-E
operation. Return one substantive INLINE report with exact repository-relative
`path:line` evidence and a continuation capsule <=1,000 words. Create no
delivered report, manifest, patch, snapshot, archive, or evidence package.

Use the highest exposed reasoning setting. Record visible model, effort, and
permission posture, or `not visible`. No subagents or model workers.

## 1. Exact baseline

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

Required opening:

- branch `trunk_dev`
- HEAD `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject `docs: freeze RW0-C2 scope admission provisioning`
- upstream `origin/trunk_dev`, locally `0 ahead / 0 behind`
- one worktree
- no staged/unmerged paths
- exactly the candidate path set below as modified/untracked state
- no active Git operation or unexpected lock.

Read `AGENTS.md` first. Use non-mutating Git inspection; do not fetch, normalize,
clean, or repair. Tracking equality is not fresh remote truth.

Any baseline, path-set, type, mode, byte, hash, baseline-blob, or replacement-
recipe mismatch requires `AUDIT_PROVENANCE_MISMATCH` before correctness review.

## 2. Exact 46-path candidate

Require exactly 29 modified tracked files and 17 created untracked files, zero
deletions/renames/type changes/symlinks/executable changes/additional paths,
Git mode `100644` for every candidate, created paths absent from HEAD/index,
and every noncandidate tracked path equal to HEAD by bytes and Git mode.

| Change | Repository-relative path | Bytes | SHA-256 | Baseline blob | Component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,153 | `d58c9c882a2c9c2a07c652c095f69ad49cced30b6cc170ff17d04daf0f7e6f51` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,221 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 4,293 | `8e1523775a1b9144758ec13882cfc8a4501db4afdc1450bf8d1c4664e1f6149c` | `absent` | 4,370 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,194 | `1a4c2f0ec67755b934c09d933e457b49367b272ca3384082100b1631af2589be` | `absent` | 22,270 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,440 | `d9304c6bd25b89b780c2c9e524261a82c7c2327740b09cfc35333299a62f40cf` | `absent` | 5,523 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 7,692 | `5fcee759d6d3371538a13bdc07fa9826724144fbc6b6676f8158677e642a5cef` | `absent` | 7,779 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 39,069 | `2dbb15ee10d7155c4255ae01f1499ae50acd6e43f666efef633737f9a466f679` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 39,135 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 30,703 | `2de0fb039733846bc416dbd4858cc07e66f6e97f4698416b2770a9701c7bd8a7` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 30,774 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 1,560 | `3b5cc33305643d7d6b373858a3f5109181b57b41f5059d9b58cd7f7c15f604eb` | `absent` | 1,631 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 8,374 | `f28fc897c850b982e79cd851e0f74c6aed6999428ad3be46f90e6b4a3cbbf4f7` | `absent` | 8,449 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 2,906 | `ed1015f5598fdff7ca58dbcdc992a52654d719022a911a77903963ff234bae1f` | `absent` | 2,976 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 4,804 | `9875671c0c67450dd84459e4739f05483f387c5f45a18f3fba2f979a659be242` | `absent` | 4,878 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 174,623 | `78b47b119f88e1642599e350cd95d217b1a4056621301012dc52ed5c8f6beee5` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 174,711 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

The final repository has 263 regular tracked-file endpoints: baseline 246 plus
17 additions. The nine D1 production modules are exactly:

```text
src/ge_nwp_coordinator/_rw0_d1_capsule.py
src/ge_nwp_coordinator/_rw0_d1_fake_planner.py
src/ge_nwp_coordinator/_rw0_d1_fake_worker.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_pre_execution.py
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_workspace.py
```

No D2, RW0-E, terminal, durable-C2 runtime, public service/CLI, provider, or
supplier runtime module may be present.

## 3. Exact endpoint replacement identity

Reconstruct twice. Start with the 25 bytes
`RW0-D1-BINARY-REPLACE-V1\0`. For each candidate row in UTF-8 path order append:

```text
u16be(path UTF-8 length)
path UTF-8
one ASCII byte M or C
u32be(0o100644)
20-byte baseline blob, or twenty zero bytes for C
u64be(payload length)
exact final bytes
```

The component column is the encoded row length. Require:

```text
46 rows; 29 M; 17 C
row components: 4,422,215 bytes
prefix: 25 bytes
total: 4,422,240 bytes
SHA-256: c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef
```

Run `git diff --check` and inspect ordinary Git diffs, but do not replace the
endpoint identity with an unrecorded diff hash.

## 4. Audit effect ceiling

Live checkout: read-only Git/files/metadata/hashing only. No live imports,
pytest, compilation, subprocesses, SQLite, scripts, edits, stage/commit/reset,
remote contact, ignored product DB inspection, secrets, or sibling repos.

Executable work is allowed only in disposable local-only external clones of
exact HEAD with no remote and exactly these 46 overlays. Before execution,
inventory only the known live `src/ge_nwp_coordinator/__pycache__/` as opaque
path/type/mode/size/ns-mtime/hash data. The closeout reports 37 regular members.
Require exact opening/closing equality. External scans use `lstat`, hash regular
files only, never follow symlinks or open FIFOs/sockets/devices.

## 5. Authority model and fixed call order

Sole owners:

- existing SQLite program initialization owns program/WorkSpec/head truth;
- existing C2B3D path owns author effect, command, fences, and delivery;
- fake planner authors bounded plan content/recommendation only;
- Section 41 alone records selection;
- RW0-C1 alone owns phase basis/result;
- parent supervisor owns process facts only;
- worker mutates bounded workspace bytes and authors worker evidence only;
- parent builder/verifier owns capsule evidence;
- typed handback is transient;
- parent-only run owner manages disposable-state lifetime, not program truth;
- D2 and physical C2 remain absent.

Required order:

```text
WorkSpec + closed fixture
→ DB through migration 0004
→ guarded program init/replay/recovery
→ guarded author effect/replay/recovery
→ close writer/authority resources
→ separate fake planner
→ parent Section 41 bundle
→ recovery probe + guarded disposition
→ selected_for_dispatch_gates
→ guarded RW0-C1 phase/replay/recovery
→ close writer/authority resources
→ separate fake worker
→ bounded capture
→ parent capsule build
→ independent reconstruction/verification
→ workspace removal
→ typed handback + parent-only state owner
```

Shadow program/selection/phase truth, direct SQL, planner-selected booleans, or
advancement after unresolved recovery is blocking.

## 6. Required inspection

Read all nine D1 source modules and seven new D1 tests completely. Read the D1
owner document completely. Inspect every candidate diff against HEAD, especially
all modified status/authority documents and these guards:

```text
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_b1_boundaries.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
```

Follow unchanged program-init, author-effect, Section 41, C1, WorkSpec,
command/fence/delivery/observation/capsule, Wire, Capability, writer-close,
state-lock, migration, and recovery owners. Check that frozen semantics were not
silently changed by status or consumer updates.

## 7. Durable call-chain and no-shadow-truth audit

Trace `run_rw0_d1_offline(...)`. Require actual current reducers/writers and
exact recovery entries for program init, author effect, Section 41, and C1.
Independently instrument one external-clone run by wrapping the actual private
methods while calling through to originals. Record order, inputs, outputs,
writer lifetimes, and child PID creation.

Require no direct SQL/copied rows, no harness selection Boolean, no planner-
authored durable identity, no replacement command/fence/delivery, no child after
unresolved recovery, exact replay without another family, and handback durable
coordinates equal actual readback/database truth. A test that only constructs
equivalent values is insufficient.

## 8. Planner frames and process

Audit D1O1/D1W1 exact framing: magic, big-endian length, pre-allocation ceiling,
canonical closed JSON, duplicate/unknown key rejection, exact built-ins,
re-encoding equality, truncation/trailing/multiple-frame rejection, planner
request 256 KiB and response 64 KiB ceilings.

Planner output may contain bounded content/target/action/recommendation/reason/
prose only. It may not contain durable identities or selection.

Run the actual fake planner via the production supervisor for happy, malformed,
oversized, trailing, nonzero, timeout, cancellation, and stderr-limit cases.
Planner failure must occur before Section 41 mutation.

## 9. Supervisor and child isolation

Require absolute interpreter, `-B -m`, `shell=False`, new session, closed FDs,
empty `pass_fds`, no `preexec_fn`, allowlisted env, bounded streams, monotonic
deadline, cancellation distinct from signal/exit/result, TERM→grace→KILL,
reap, group-clear observation, and fail-closed unsupported host.

Use unique sentinel DB/state/lock/credential values in the parent. Independently
inspect child argv/env/cwd/stdin/open FDs. No child may see a DB path, state root,
SQLite/lock FD, writer session/proof/lease/capability, credential, or parent-only
run owner. Every writer/connection/lock must be closed before launch; uncertain
close blocks launch.

Exercise start failure, blocked stdin, limits, nonzero, malformed result,
deadline, cancellation, escalation, reap, surviving-group detection, and cleanup
uncertainty. Preserve the explicit nonclaim that same-UID proof children are not
a hostile-code sandbox.

## 10. Worker, workspace, and capture

Verify worker input is D1W1 containing an existing NWPF command and actual
fences; stdout is exactly one existing NWPF result frame decoded against the
actual committed command/delivery/fences. Worker cannot author the accepted
manifest or access DB/state/Git/network/credentials.

Independently exercise absolute/traversal paths, symlink, hardlink, unsupported
mode/type, add/delete/rename/extra change, missing candidate, multiple changes,
byte/file ceilings, and forged worker-manifest output. Require whole-workspace
before/after enumeration and exact retained bytes/modes for all three fixture
paths. The preassigned base OID is not authenticated Git truth; code must not
claim to derive it or invoke Git.

## 11. Capsule audit

Require parent construction of `CandidateCapsuleManifestV1` from immutable
fixture bytes, observed candidate bytes/modes, actual command/fences, and a
parent manifest ref. A separate verifier must reconstruct independently and
check path set, modes, hashes/lengths, exactly one replacement, all lineage and
fence bindings, path-scope digest, portable digest, and call
`validate_capsule_manifest_relation(...)`.

Worker-supplied manifest/digest data is never authoritative. Hostile path/mode/
base/fence/digest substitutions must fail. Mutable workspace must be gone before
`capsule_ready`; unresolved reap/removal yields `cleanup_unresolved`.

## 12. Handback and run owner

Require closed statuses/reasons and field invariants; no raw state/workspace
path, session, connection, FD, proof, lease, lock, or capability in handback;
nonprinting behavior; no serializer creating a live handle; parent-only
nonserializable run owner; no open writer after return; workspace already gone;
state retained only until explicit close; idempotent close/context cleanup; no
`__del__` authority; no second program truth.

Verify D2 can consume the exact immutable bytes/modes, manifest, lineage,
process evidence, selection, phase, and state lifetime without semantic
translation.

## 13. D1/D2/C2 boundary

Search imports/calls/tests/docs. D1 must not invoke validator, independent
reviewer, review model, post-execution proposal projection, D2 evidence
admission, `_rw0_c_decision_input_values`, durable C2 decision/acceptance,
terminal outcome, migration 0005, Git/network/provider/supplier/ES/Bridge.

## 14. Governance guard audit

Recompute twice:

```text
AGENTS.md: 62,778 bytes
076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6
README.md: 46,898 bytes
dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff
```

Verify fixed literal identities and hostile anti-dynamic controls.

Verify five Capability status projections remain normalized: Capability stays
pure/no-I/O/non-authoritative, D1 mechanics are separately implemented, and
D2/C2/live paths remain future.

Verify B1 registry v2: sole pure consumer Capability; only bounded runtime
consumer `_rw0_d1_pre_execution.py`; only direct imported B1 symbol
`RW0PhaseEntryBasisV1`. Extra importer/symbol mutations must fail.

Verify the temporary C2 complete-source manifest is explicitly superseded and
scoped guards still reject C2 writer/reader/runtime, caller, acceptance writer,
terminal owner, export, migration 0005, and activation. A prohibited disposable
C2 module/call must fail.

Require exactly nine D1 modules; reject D2/E/terminal/C2 runtime modules.
Require the supervisor as the sole production `subprocess` owner; a second
importer must fail all relevant historical guards.

Verify `__init__.py` and `pyproject.toml` are HEAD-identical, no public export or
entry point exists, only two fake child modules have executable guards, and all
existing pure semantic modules remain no-I/O.

## 15. Independent causal specimens

Run audit-authored specimens for:

1. successful one-call D1 invocation;
2. exact replay of each durable operation;
3. each durable operation forced unresolved, with no later child;
4. planner failure before Section 41;
5. nonselection before C1/worker;
6. C1 commit observed before worker PID;
7. worker timeout and cancellation;
8. child-isolation sentinel probe;
9. extra workspace mutation rejection;
10. forged worker manifest rejection;
11. capsule tamper rejection;
12. cleanup failure → `cleanup_unresolved`;
13. run-owner close/removal/idempotence;
14. one invocation with no relay callback/intermediate external input;
15. no Git/network/validator/reviewer/review-model/C2/terminal effect.

Expected outcomes must be independent of candidate helper logic.

## 16. Transformed-copy checks

Create disposable candidate copies and make narrow mutations. Selected permanent
tests must parse/import/collect and fail semantically. At minimum:

1. bypass program initialization with fixture truth;
2. replace Section 41 result with harness Boolean;
3. launch worker before C1;
4. continue after unresolved recovery;
5. expose DB path or sentinel FD to child;
6. skip process-group reap/cleanup;
7. accept worker manifest or bypass reconstruction;
8. allow extra/symlink/hardlink workspace mutation;
9. put raw state path/session/proof in handback;
10. add second subprocess importer;
11. add tenth D1 module or D2 module;
12. add B1 importer/symbol;
13. add prohibited C2 runtime module/call;
14. dynamically derive AGENTS/README hashes.

Do not credit syntax/import/collection failures. Separate permanent tests,
audit specimens, transformed copies, and audit-side oracles. The candidate
cannot self-authenticate coordinated edits; this audit owns the fixed basis.

## 17. Exact validation

Build one fresh mode-0700 external clone from exact HEAD, remove remote, overlay
exactly 46 verified paths, and verify all 263 files before testing. Use `umask
022`, distinct precreated basetemps, `PYTHONDONTWRITEBYTECODE=1`,
`PYTHONPATH=.:src`, `-p no:cacheprovider`, no xdist/parallelism, collection before
execution.

For inventory hashes use, per sorted repository-relative test path:
`u32be(path length) + path UTF-8 + raw SHA-256(file bytes)`.

Run serially:

```text
1 D1: 7 files, 57 passed
  ae7aee67465a1acb6ea2265e0ba1be17d80f533e05108a56472804485fd008fe
2 program: 9 files, 218 passed
  1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10
3 author effect: 4 files, 46 passed
  90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8
4 Section 41: 6 files, 168 passed
  522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55
5 C1: 8 files, 109 passed
  22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825
6 worker semantics: 4 files, 135 passed
  779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346
7 Wire: 7 files, 117 passed
  53ccc8874d06f47f4eab42f13c20de874bd91035359bd4ad57bda2675ccd374e
8 Capability: 4 files, 60 passed
  b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00
9 bootstrap guard: 1 file, 289 passed
  236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736
10 legacy guards: 8 files, 1,754 passed
  f0c8037a97d99ac77e81099c190b75c4f3e346988bde515913c2fb00a6236a45
11 remaining changed owners: 6 files, 656 passed
  95430563d25048a351e903fa0b7819434785d9b00149d8f0e4d87cb2a658e428
12 complete repository: no paths, 124 modules, 8,877 passed
  0c390a48b930b698f4b037e718ce044572c8bf8b021b1d730ea48bdbfe8ec7fe
```

Use the exact file inventories from the candidate closeout, reproduced by
repository glob/list inspection; groups 2 and 3 intentionally overlap. Require
unique node IDs and reconcile overlaps. The only accepted warnings are the
three existing Python 3.13 multithreaded-fork warnings from writer-session tests.

Also require `git diff --check`, no-index whitespace checks for each created
file, encoding/final-LF checks, exact path/type/mode checks, package export and
script preservation, source/migration inventories, migration 0005 absence,
before/after clone equality, and live-cache equality.

Audit-runner errors may be corrected only outside live checkout; rebuild from
the same exact candidate and rerun affected gates. Candidate defects are
findings, not audit repair authority.

## 18. Verdicts

Accept only if exact provenance, actual guarded durable call order, process
isolation and cleanup, bounded workspace/capsule independence, handback/run
ownership, D1/D2/C2 boundaries, governance guards, transformed defects, and all
validation/preservation gates pass with no unresolved High/Medium finding:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE`

Block for shadow durable truth, planner/supervisor progression authority,
speculative advancement, child DB/writer access, unbounded/unreaped state,
worker-authored or non-independently verified capsule, live authority in
handback, D2/C2/live widening, weakened guards, or material test/evidence gaps:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

Provenance mismatch:

`AUDIT_PROVENANCE_MISMATCH`

## 19. Inline report

Return:

1. verdict and visible settings;
2. exact baseline, 46-path receipts, and replacement recipe;
3. actual durable call trace and no-shadow-truth analysis;
4. frame/planner audit;
5. supervisor/child-isolation audit;
6. worker/workspace/candidate audit;
7. capsule construction/reconstruction audit;
8. handback/run-owner and D2-sufficiency audit;
9. D1/D2/C2 nonclaims;
10. status/legacy-guard audit;
11. direct specimens, transformed copies, and evidence limits;
12. exact validation commands, inventories, counts, warnings, corrections,
    external effects, cleanup, and skipped work;
13. severity-ranked findings or explicit none;
14. exact next boundary and continuation capsule <=1,000 words.

Acceptance authorizes only a separately issued commit/publication gate for the
exact 46 files. It does not authorize D2, C2, migration 0005, live provider/
supplier work, Git/publication effects, ES/Bridge integration, or RW0-E. End
with exactly one verdict token.
