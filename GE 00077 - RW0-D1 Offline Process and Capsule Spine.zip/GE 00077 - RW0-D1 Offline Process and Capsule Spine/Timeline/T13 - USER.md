Here is Codex's response:

# RW0-D1 independent audit

**Verdict: blocked.** The exact candidate provenance matches the supplied basis, and the normal offline call chain uses the guarded durable owners. Three material boundary findings remain, so this candidate is not ready for the commit gate.

Visible settings: GPT-6 family; exact model ID and reasoning effort not visible. Permission posture: `danger-full-access`, approval policy `never`. This was a parent-only audit with no subagents.

## Provenance and preservation

The opening and closing branch was `trunk_dev` at HEAD `0d0926e3a483a3ab1a4fd597ac0495927352bf35`, tree `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`, sole parent `630414faa07f4ac39c4a870a9cc44c7f92d46b80`, and subject `docs: freeze RW0-C2 scope admission provisioning`. One worktree was present; local tracking was `0 ahead / 0 behind` `origin/trunk_dev`. That tracking comparison is not fresh remote verification. No staged, unmerged, or unexpected paths or Git lock were observed.

All **46 supplied path receipts** matched individually: 29 modified tracked files and 17 created regular files, each mode `100644`, with the specified byte length, SHA-256, and baseline blob or absence. The 246 HEAD endpoints plus 17 additions made 263; noncandidate tracked files matched HEAD bytes and mode. The 25-byte prefix and 46 encoded rows totaled **4,422,240 bytes**. Concatenated and streaming reconstruction both produced `c271dfce596f3b5aac85ca5d70f71d3a510f20e61b8f0c3894d3ac76a43184ef`; the digest matched again after testing.

`AGENTS.md` and `README.md` matched their supplied hashes on both checks. `git diff --check`, no-index whitespace checks for all 17 additions, and UTF-8/final-LF checks for all 46 paths passed. `__init__.py` and `pyproject.toml` matched HEAD. The source inventory contains exactly nine D1 production modules and migrations 0001–0004, with no 0005.

The live cache retained the same 37 regular members, paths, types, modes, sizes, hashes, and second-resolution mtimes at opening and closing. I omitted nanosecond mtimes from the *opening* capture; a later nanosecond before/after comparison matched, but the requested full-period nanosecond equality is unproved.

## Runtime and boundary evidence

An audit-authored one-call trace observed: migration initialization → program initialization → C2B3D author effect → writer close → planner PID → new writer → Section 41 selection → C1 phase commit → writer close → worker PID. Both child launches occurred with no active writer. Read-only database inspection found one program head, WorkSpec binding, author command, selected disposition, selection head, and C1 phase with the expected refs; two development mutation receipts, one Section 41 receipt, and one C1 receipt were present. The call sites are [offline.py:267](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:267>), [offline.py:284](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:284>), [offline.py:297](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:297>), [offline.py:348](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:348>), and [offline.py:371](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:371>).

Forced committed response loss recovered exactly at each of the four durable operations. Forced *unresolved* recovery stopped progression in all four cases: program and author failures launched no child; selection and phase failures had launched the planner but never the worker. Malformed planner output stopped before Section 41; deferral recorded `deferred` and stopped before C1.

D1O1/D1W1 framing uses magic, big-endian lengths, bounded canonical JSON, and exact-frame checks at [process_frames.py:9](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_frames.py:9>) and [process_frames.py:104](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_frames.py:104>). A sentinel probe found only the seven allowlisted environment keys in a real child; it received no parent DB, state, lock, or credential environment value and did not inherit an explicitly inheritable sentinel FD. A child that blocked stdin and ignored TERM reached the deadline, received TERM then KILL, was reaped, and had a clear process group. The supervisor launch settings are at [process_supervisor.py:84](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:84>).

Audit-authored workspace probes rejected absolute and traversal selections, symlink, hardlink, FIFO, mode change, addition, deletion, rename, multiple changes, and oversized bytes. A forged suffix on the worker’s Wire result yielded `worker_frame` with no capsule. Separate verifier probes rejected changed capsule path, mode, digest, and base OID. The parent capture and verification calls are at [offline.py:437](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:437>) and [capsule.py:33](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_capsule.py:33>). The fixture base OID is a supplied coordinate, not authenticated Git truth.

The normal handback carries the captured bytes and modes, manifest, lineage, and process/Wire observations needed for a later D2 consumer; the separate run object retains disposable state. D2 validation/review/model closure and physical C2 decision/acceptance remain absent. The D1 modules showed no Git, network, provider, ES, Bridge, validator, reviewer, or C2/terminal call. Focused B1, sole-subprocess-owner, nine-module, scoped-C2, and post-execution boundary guards passed.

## Severity-ranked findings

1. **Medium — the typed handback does not enforce its evidence or custody boundary.** [handback.py:26](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:26>) accepts arbitrary `object` fields; [handback.py:41](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:41>) permits `capsule_ready` without worker/process/Wire evidence and permits mismatched stopped reasons. A direct specimen constructed a ready handback containing a raw `Path`. In a transformed copy, adding the live state root to every actual handback still allowed **four D1 tests and thirteen relevant guards to pass**. The normal candidate run did not itself return that path; the contract and permanent guards permit the violation.

2. **Medium — the parent-only run owner is usable after fork.** [handback.py:68](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:68>) and [handback.py:79](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_handback.py:79>) have no process-identity check. With an actual successful D1 run, a forked child called `run.close()` and removed the database. The parent still reported `closed == False`; its own `close()` then raised `FileNotFoundError`. This contradicts parent-only state-lifetime custody, although the normal fake children execute before the run object is returned.

3. **Medium — selector cleanup uncertainty loses its process classification.** [process_supervisor.py:196](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py:196>) lets `selector.close()` escape before group-clear observation and outcome construction. [offline.py:454](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:454>) then maps it to `stopped/durable_conflict`. An injected close failure after one real planner PID started produced exactly that result, with `planner_process=None`, rather than `cleanup_unresolved`. A separate workspace-close uncertainty was correctly classified as `workspace_cleanup_unresolved`.

4. **Low — one malformed canonical frame escapes the frame-error vocabulary.** [process_frames.py:88](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_process_frames.py:88>) tests frozenset membership before checking the built-in `str` type. A canonical planner response with `"action":[]` raised `TypeError`, not `D1FrameError`; [offline.py:329](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_d1_offline.py:329>) therefore classifies it as a generic durable conflict. Progression still stops before selection.

## Validation and evidence limits

In the remote-free disposable clone, with `umask 022`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONPATH=.:src`, `python3 -B -m pytest -q -p no:cacheprovider`, and distinct precreated `--basetemp` directories:

- The seven D1 test files collected **57** unique tests and passed **57/57**. Their inventory digest matched `ae7aee67465a1acb6ea2265e0ba1be17d80f533e05108a56472804485fd008fe`.
- All **124** repository test modules collected; their inventory digest matched `0c390a48b930b698f4b037e718ce044572c8bf8b021b1d730ea48bdbfe8ec7fe`. The full serial run was interrupted after **1,405 passed in 304.17 seconds** because the reproduced Medium findings already barred acceptance. No warning was observed before interruption; the requested 8,877-pass result and validation groups 2–11 are **not claimed**.
- Thirteen focused permanent governance tests collected and passed.
- Three transformed copies were exercised: the live-path handback mutant passed 17 relevant tests; a second subprocess importer failed its owning guard semantically; a tenth D1 module failed the production inventory guard semantically. The remaining requested transformed-copy matrix was not completed after the blocking finding.

Two audit-side probe mistakes—a NUL escape in the first replacement check and attempts to set public read-only capsule properties—were corrected in the disposable environment and rerun. No candidate file was repaired. The five disposable clone/copy directories and their test basetemps were removed. The live checkout was read and hashed only; no remote, live provider, credential, Git publication, Bridge, ES, D2, C2, or RW0-E operation was performed.

### Continuation capsule

Keep this exact 46-path basis as the audited candidate, with the provenance receipt above. Repair the handback’s field and status invariants, fence the run owner to its creating process, preserve `cleanup_unresolved` when supervisor cleanup cannot be proved, and normalize malformed frame types to the closed frame error. Add causal tests for those paths, including the live-state-path mutant. Any edit creates a new endpoint identity: recompute all path receipts and the replacement digest, complete the requested validation and transformed-copy gates in fresh external clones, then seek a new independent audit. D2, C2 physical persistence, live contact, and commit/publication remain separate boundaries.

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED
