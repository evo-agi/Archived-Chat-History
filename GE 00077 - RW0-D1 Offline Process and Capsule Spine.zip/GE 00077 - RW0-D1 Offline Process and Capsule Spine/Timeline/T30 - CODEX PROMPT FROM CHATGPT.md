# Governed Execution Coordinator — RW0-D1 Audit Repair V6: B1 Dynamic-Import Guard Closure

## Mandate

Continue the RETAINED, uncommitted 46-path RW0-D1 candidate. Repair one existing
test file only. Do not recreate D1, roll back its runtime repairs, change its
operating model, or open another semantic-contract tranche.

The latest independent audit returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED`

Its acceptance-blocking finding is LOW severity: the B1 handback consumer guard
recognizes importlib and direct __import__ calls but misses acquisition and use
of builtins.__import__ through an alias. A complete external handback copy with
a module-level B1 load/value parsed and imported, and its owning permanent test
still passed. A builtins module-alias form also passed the helper directly.

The named owning test is:

`test_private_module_has_no_package_exports_or_production_importer`

Reported current inspection coordinates are tests/test_rw0_b1_boundaries.py:620
and :662. Resolve the actual lines after opening provenance. The exact auditor
mutation bytes were not supplied; the finite reproductions below are new,
equivalent specimens of the reported forms, not claimed byte-identical copies.

This is a B1 GUARD-COVERAGE defect. The retained handback contains no observed
dynamic loader; the audit found no executable-permission or durable-authority
bypass. Do not inflate its severity, dismiss its contractual effect, or redesign
the runtime to avoid the test. All nine production D1 modules remain untouched.

The audit also disclosed a procedure lapse: its first git status ran before
AGENTS.md and without optional-lock suppression. Index content and candidate
bytes later matched, but opening index metadata was not recorded, so a refresh
cannot retrospectively be excluded. This repair must establish its own complete
opening record; it must not reset or 'repair' the prior index, infer a mutation,
or claim historical metadata proof that does not exist.

The selected change is one test-only correction INSIDE the retained D1
implementation program. No B1 registry version, consumer permission, value
schema, production import, document, or public interface changes are authorized.
D1 -> D2 -> physical C2 remains the sequence.

Parent is the sole writer; no subagents. Use the highest exposed reasoning
setting and report visible model, effort and permissions or `not visible`.
Do not seek extra account/computer access to reveal hidden settings.

Return operative findings INLINE, with exact repo-relative path:line references,
full validation/provenance and a continuation capsule <=1,000 words. No delivered
report, patch, archive, architecture package, freeze manifest or receipt file.
Do not issue a subsequent audit, publication, D2 or C2 prompt. This mandate has
all operative identities and test memberships; no historical attachment is needed.

## 1. Opening order, required baseline and index preservation

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: trunk_dev
- HEAD: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
- tree: 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4
- sole parent: 630414faa07f4ac39c4a870a9cc44c7f92d46b80
- subject: docs: freeze RW0-C2 scope admission provisioning
- upstream: origin/trunk_dev, locally 0 ahead / 0 behind
- one worktree; index equal to HEAD; zero staged/unmerged paths
- exactly 29 tracked modifications and 17 untracked creations listed below
- no active Git operation, sequencer or unexpected lock.

Before ANY Git command, including status:

1. Read the live AGENTS.md as text and follow applicable guidance.
2. Set GIT_OPTIONAL_LOCKS=0 for every live Git inspection subprocess. Do not write
   Git configuration. Set GIT_NO_LAZY_FETCH=1 so inspection does not lazily fetch
   missing objects; unavailable required local objects are a stop, not network
   permission. Use noninteractive inspection and no external diff/textconv.
3. Resolve the checkout's .git/index as filesystem metadata/data, without a Git
   command first. If .git is a file, read its gitdir pointer as data and resolve
   the corresponding per-worktree index; do not assume a directory or scan
   unrelated Git secrets. Capture the index's lstat type, device/inode, mode,
   UID/GID, byte length, st_mtime_ns and SHA-256 BEFORE the first Git command.
   Record supported metadata consistently. Access time is not an equality gate.
4. Record the known live cache DIRECTORY and its members as described in section
   8 before executable repository work. Inspect no unrelated ignored state.

Then verify the exact baseline, index CONTENT and candidate status through
nonmutating Git commands with the above environment. Do not fetch, refresh the
index, update-index, normalize, switch, stage, reset, clean or change policy.
Tracking equality is not fresh remote truth. Preserve both opening index bytes
and the recorded metadata to closing; this task authorizes no index write.

If this task itself misses the required opening order or causes unexplained
index drift, preserve all work and report the actual procedure limit. Do not
recreate the missing opening record, silently rebaseline it, or claim a clean
procedural pass. The earlier audit's lapse is historical and is not a reason to
roll back this candidate.

## 2. Exact retained 46-path candidate

M means tracked modification. C means untracked creation, not a Git copy or
commit. Require regular nonsymlink candidate files with Git mode 100644. The
current audit reports OS mode 0644 for all candidate endpoints. Verify/preserve
actual modes; do not normalize unrelated nonexecuting 0600 files. Require strict
UTF-8, no BOM/CR, one terminal LF and no trailing whitespace.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 47,819 | `b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 47,885 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 25,215 | `dde79042a7640571493f882b5130b8650c7a52ebd2fc28a6956799a261fa6d4c` | `absent` | 25,286 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 23,432 | `e5250a4921d1d441716fa356c742dbc886a0d13f7386c90e8409094c733f2109` | `absent` | 23,507 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | `733014e93b1503fc2101a0214fa9b44eaf887bc1c2fd75ccef2eae6d17eee439` | `absent` | 6,202 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read all 29 M HEAD blobs as data and verify their recorded OIDs. All C paths are
absent from HEAD and index. All 217 noncandidate tracked files must equal HEAD
content/type/Git-relevant mode. The complete candidate has 263 file endpoints:
246 baseline files plus 17 additions. No new/deleted/renamed path, symlink,
submodule, executable bit or public export is allowed.

### Exact opening replacement identity

Reconstruct twice from independent fresh file reads, without importing candidate
code. Use the established endpoint replacement format, not a new manifest:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw bytes of HEAD blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact retained file bytes
```

Required opening:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,511,013
prefix: 25 bytes
total: 4,511,038 bytes
SHA-256: e0221e5d67ed3091ead541c314163b49964ec298411f4c29a6d11a572434d1ed
```

The earlier a7910001... identity is historical only. Do not reconstruct source
from hashes or require old payloads. On any identity or baseline mismatch,
preserve actual state and stop before editing, without replacing expectations.

## 3. ONE-file repair ceiling

The only permitted live change is:

`tests/test_rw0_b1_boundaries.py`

Exact opening endpoint:

```text
status: M
Git mode: 100644
OS mode: 0644
payload: 47,819 bytes
SHA-256: b0d196bc878fa86e452f8d0b568679302538f37108b427b51ec7052b282990de
HEAD blob: 06266f08770b3d4efa77f26aff0b1e7ecadf46f1
encoded component: 47,885 bytes
```

Its responsibility is to strengthen the existing finite handback-consumer guard
and permanent controls for aliased builtins import acquisition/use. It may not
change the B1 owner registry or independently fixed expected consumer identities,
roles, symbols, value schemas, digest rules, constructor authority or nonclaims.

The OTHER 45 candidate endpoints remain byte-exact. All 217 noncandidate HEAD
entries remain exact. The overall candidate remains 29 M / 17 C, not 47 paths.
Keep specifically unchanged:

- all nine D1 production modules and seven D1 test modules;
- all documents, including AGENTS.md, README.md, D1 owner and B1 version-3 owner;
- the independently fixed B1 projection in the phase-entry test;
- Wire source and Wire consumer guard, allowed symbols/forms and classifier;
- process-value validation, handback invariants, capture/capsule validation,
  creator-PID custody, supervisor cleanup/framing and existing durable flow;
- Capability/bootstrap/scoped-C2/runtime/post-execution guards;
- current private semantic/durable/writer/reader/recovery source;
- package root, pyproject.toml, .gitignore, StateStore, exports/scripts;
- schemas/configuration/migrations 0001-0004; no 0005.

Do not re-export through another source module, rename imports to evade a guard,
replace exact types with strings/Any/object, or edit production merely so this
test can pass. No new import permission, runtime helper or source file.

No staging, commit, push, PR, merge, branch change, network, dependency install,
provider/supplier, credentials, live authority, enrollment, deployment, D2,
physical C2, terminal, ES, Bridge or RW0-E action. Fixed offline test children
and temporary SQLite fixtures are permitted only in external clones below.

## 4. Focused dependency inspection before editing

Read the CURRENT candidate target test fully, especially its helper and the
owning test test_private_module_has_no_package_exports_or_production_importer.
Read the handback module and its actual imports as DATA only. Follow the B1
version-3 owner and the two independently fixed registry projections, and the
relevant Capability path protection as read-only context.

Baseline guidance for this dependency check, not substitute current facts:

- tests/test_rw0_b2_capability_boundaries.py:90-91 names the B1 test in R18 as
  a path/mode/purpose protection; it is not one of that baseline's complete-file
  protected SHA-256 rows.
- The actual retained B1 importer guard and fixed negative cases were reported
  near lines 620 and 662. Re-resolve these against opening bytes.

Before editing, return a compact inline table identifying the existing helper,
its call from the named owning test, currently permitted exact B1 consumers,
handback's one permitted symbol, existing dynamic-import checks, and any other
source/content dependency of this one test. Do not commission a broad map.

Preserve the exact evidence-only role:

```text
supplier: src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
consumer: src/ge_nwp_coordinator/_rw0_d1_handback.py
symbol: RW0PhaseEntryBasisV1
field: phase_basis
```

Pre-execution constructs; C1 establishes/verifies durable phase; handback
validates/retains. B1's source_authentication, executable_permission,
durable_persistence and semantic_acceptance remain none. Registry version stays
3. All non-D1 importer and symbol/form restrictions remain exact.

If a genuine owning contradiction or mandatory content pin requires another
file, retain the work and stop with exact path/symbol/effect evidence. Do not
weaken another guard or widen the scope silently.

## 5. Guard correction: prohibit the acquisition, not one alias spelling

Strengthen the SAME B1 handback-consumer helper used by the existing named test.
Do not implement a helper that the owning test never calls, or rely on a Wire
or whole-source test to catch the specimen first.

Selected strategy for this single closed production consumer: syntactically
reject acquiring or referencing the dynamic builtin loader, so subsequent alias
spelling is irrelevant. Traverse relevant AST nodes throughout the whole
handback module, including nested functions/classes/conditionals, not just
module-level calls.

At minimum detect:

1. ImportFrom builtins importing __import__, with or without asname;
2. attribute access to __import__ on a builtins module reference/alias; an
   explicit ban on the syntactic __import__ attribute in this closed consumer
   is acceptable and avoids needing a general alias/data-flow resolver;
3. direct reference/acquisition of the __import__ builtin, including assigning
   it to a local name rather than immediately calling it;
4. the resulting straightforward assignment aliases and nested uses of the
   first two forms, through the same acquisition rejection.

Retain existing importlib and direct __import__ restrictions. Catch bindings
and acquisitions before only examining the eventual ast.Call spelling.
Do not globally ban ordinary builtin functions or change permissions in other
consumers. Comments or string literals merely mentioning '__import__' are not
an executed acquisition and should not be mistaken for one by raw substring
matching.

Do NOT build a universal import resolver or promise static protection against
arbitrary eval/exec, reflection, computed module names, bytecode replacement or
coordinated rewrites of all expected values. The closed direct/from/module/
assignment/nested syntax is the selected bounded test obligation. Do not expand
public or domain semantics to make the guard look complete.

Keep fixed expected importer/symbol sets and fixed negative cases independent of
observed production imports. Preserve legitimate type annotations and exact
value validation/retention in the actual handback. No registry bump, no new
consumer and no evidence-to-authority promotion.

## 6. Direct specimens and permanent causal controls

First reproduce the reported form on a disposable opening-candidate copy so
there is a before/after boundary. These are independently authored representative
snippets, NOT claimed original auditor bytes. Insert into a syntactically valid
position in the complete external handback module; preserve its required normal
imports and all other source content.

### A. Imported loader alias

```python
from builtins import __import__ as _d1_b1_loader_probe
_D1_B1_LOADED_PROBE = _d1_b1_loader_probe(
    "ge_nwp_coordinator._rw0_phase_entry_semantic_values",
    fromlist=("RW0PhaseEntryBasisV1",),
)
_D1_B1_VALUE_PROBE = _D1_B1_LOADED_PROBE.RW0PhaseEntryBasisV1
```

### B. Builtins module alias

```python
import builtins as _d1_builtins_probe
_D1_B1_LOADED_PROBE = _d1_builtins_probe.__import__(
    "ge_nwp_coordinator._rw0_phase_entry_semantic_values",
    fromlist=("RW0PhaseEntryBasisV1",),
)
_D1_B1_VALUE_PROBE = _D1_B1_LOADED_PROBE.RW0PhaseEntryBasisV1
```

These probes load only the existing pure B1 module and retain its class object.
Do not construct a basis, write C1, run the offline loop or contact anything as
part of the module-level probe. Execute/import them ONLY in the disposable
external test context with no credentials or configured remote.

### Permanent tests inside the sole allowed test file

Add small independently fixed source-text cases for A and B, their unaliased
forms, a simple assignment alias such as loader = module_alias.__import__, and
nested use. Vary alias names; do not match a single probe identifier. Reuse
cases where one acquisition rule covers more than one syntax; no open-ended
fuzzer or alias graph.

Require the SAME B1 helper to reject every negative case with an intended,
content-free assertion boundary. The positive retained handback must pass. Keep
existing importlib, direct loader, unauthorized symbol/path, alias/wildcard,
re-export and pre-existing consumer negative controls intact.

Positive controls must include the actual current handback's legal B1 import
and evidence use, and harmless comment/string mentions if the new AST handling
could confuse them with execution. Do not weaken current guard assertions to
admit the positive controls.

### Complete owning-test reproduction

For each of A and B, build an external transformed full handback module. Verify
normal parse and actual package-context import independently, in an isolated
external process with bytecode disabled. Then run the unchanged-named owning
permanent test through normal pytest collection/execution:

```text
tests/test_rw0_b1_boundaries.py::test_private_module_has_no_package_exports_or_production_importer
```

Before the repair, reproduce and report the survivor where available. After the
repair, the owning test must fail at the B1 dynamic-acquisition restriction.
A syntax/import/collection error, changed production-file count, unrelated Wire
check, or a hard-coded test assertion is not credit for detecting this finding.
Report the direct helper result and whole owning-test result separately.

### Two bounded guard-regression copies

Against FINAL repaired test bytes, separately disable the imported-loader
acquisition check and the builtin-attribute acquisition check. Keep the fixed
specimens and positive retained source unchanged. Each weakened test helper
must cause its permanent negative-control test to fail semantically while the
module still parses/imports/collects normally. If one common predicate covers
both, use narrow controlled substitutions or clearly identify shared coverage;
never claim that an unrelated guard detected the omitted predicate.

All deliberate production-text and test-helper mutations live only in disposable
copies. The live handback and other 45 live candidate endpoints remain exact.

## 7. Completed evidence and still-open acceptance work

The latest audit now provides useful independent observations:

- complete 46-endpoint and aggregate equality, 217 noncandidate HEAD files exact;
- 108 D1 tests passed, plus a selected 32 B1/Wire/registry tests;
- process-value constructor/consumer defects rejected in direct and actual-return
  probes; legitimate negative process and cleanup evidence retained;
- current guarded program/author/Section 41/C1 call-through ordering, writer
  closure before child launches, actual Wire exit input, parent capsule build
  and verification;
- read-only SQLite presence/readback of program/author/selection/phase/receipt
  rows in a 62-user-table database;
- committed response loss at each of the four durable sites reaches the current
  recovery owner and completes; forced unresolved after call-through recovery
  stops before planner at program/author and before worker at selection/phase.

Do not discard those observations, but do not expand them: they are not complete
row-by-row identity/digest acceptance. The report expressly left groups 2-12,
full node/overlap/inventory/warning reproduction, the finite P/N/R campaign,
full 29-diff semantic review, complete durable row/digest readback, and full
independent FD/workspace/process campaigns incomplete. The initial status/index
procedure lapse remains historically unproved as described above.

This one-file repair performs implementation validation, NOT independent
acceptance. It cannot fill the earlier audit's omissions merely by rerunning
ordinary tests. Carry the exact limits forward. A fresh independent acceptance
audit still has to inspect the new candidate and complete its required gates.
Do not issue that audit or a publication prompt in this task.

## 8. External execution, exact final validation and preservation

No live-checkout repository import, test, subprocess probe, script, compilation
or database connection. Only the one authorized test may be edited there.
All executable work uses task-owned local-only external clones of exact HEAD
with the 46 candidate endpoints overlaid and remotes removed. Use installed
dependencies; no network. Fixed fake children and isolated test SQLite fixtures
are permitted within the external validation scope.

Record the live __pycache__ DIRECTORY and all 37 regular members using lstat,
with path/type/actual mode/size/st_mtime_ns and hashes for regular files. Do not
hash a directory or replace metadata with existence. Capture before executable
work; preserve complete opening/closing equality. The index record from section
1 must precede the first Git command. No reconstruction of older missing data.

Use a mode-0700 task root, TMPDIR inside it, disabled bytecode/pytest cache,
test-process umask 022, and precreated separate collection/run basetemp parents.
Preserve source OS modes. Account for probe PIDs/process groups and every owned
state/workspace root. Never follow symlinks or open FIFOs/sockets/devices during
artifact scans; use lstat and hash only regular files. Remove only positively
identified task-owned resources after owned processes have ended.

Development sequence:

1. Authenticate opening bytes and the index/cache record.
2. Inspect the target helper/caller and narrow dependencies.
3. Reproduce the two reported alias shapes in an external opening clone.
4. Amend the one helper/test file, preserving owner permissions.
5. Run the direct helper controls, complete owning-test mutants, and the B1,
   phase-entry projection, Wire, Capability and scoped guards in external copies.
6. Complete the two final-byte guard-regression controls.
7. After the LAST edit, rebuild a fresh final remote-free normal candidate clone
   and collect then execute all twelve groups. Keep mutated copies separate.
8. Recompute final receipts/recipe, preserve live work and clean owned roots.

All final groups must run, including runtime groups whose bytes did not change.
An earlier partial run or superseded clone receives no final pass credit. Do not
run the wider independent acceptance campaign as if this repair were its audit.

From the final external clone use:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Run collection and execution serially, with no xdist, overlapping groups, warning
suppression or test removal. Each token below expands to tests/test_<token>.py.
Sort and deduplicate ONLY within its group; preserve exact membership:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12: NO path arguments. Complete repository; still 124 test modules.
Do not select tests to manufacture a preferred count.

### Opening inventories and reference results

| Group | Files | Opening reported collected / passed | Test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 108 / 108 | `c768d282a219e67d89800643373e1c4ab7bad9a248949933f7beacfcdda3c7d6` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 60 / 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 / 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,773 / 1,773 | `1c4f3fc6edc6b3561d426d52d2cd8b4ea8c65ea979311cf151f906d0f4190e8e` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 8,970 / 8,970 | `72e226a510ab08a4b0e6ff3b325c2ae37dcdf8a50a8520712304d38fb3aed276` |

Inventory encoding for sorted repository-relative module paths is:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

The table's full counts are IMPLEMENTATION reference results, not this audit's
independent reproduction. Only Group 1 and a selected B1/Wire set ran in the
latest audit. Preserve that distinction in the closeout.

This repair changes tests/test_rw0_b1_boundaries.py only. Therefore:

- Groups 1-9 and 11 keep the exact file bytes, membership and inventory hashes;
  execute their regressions and reconcile their expected counts.
- Group 10 contains the changed B1 file: recompute its inventory and count.
- Group 11 contains the phase-entry registry projection, which stays unchanged;
  do NOT gratuitously update that projection or Group 11 hash.
- Group 12 also contains the changed B1 file: recompute the full inventory,
  collect and execute the whole repository.

Useful count check, not a pass claim:

```text
final_full_count = 8,970 + (final_Group10_count - 1,773)
final_Group1_count = 108
final_Group11_count = 679
```

Preserve old behavioral tests' intent. Do not remove or weaken tests to retain a
number. Reconcile actual unique node IDs and additions. Group 2/3 overlap is
46 and Group 7/11 overlap is 31 at this opening; recompute actual relations and
confirm every group 1-11 node belongs to the full collection. The union should
be 3,643 plus Group 10's net additions if no other overlap changes.

Expected existing warnings in Groups 10 and 12 are the same three Python 3.13
multithreaded-fork DeprecationWarnings attached to:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured records. Repeated warnings in overlapping selections are
not new warning kinds. Investigate new warnings, failures or unsupported required
POSIX/fork execution without suppressing them or calling an omission a pass.

Also require:

- live git diff --check with optional locks suppressed and no textconv/ext-diff;
- all 17 addition no-index whitespace checks (ordinary difference status 1 is
  not a whitespace finding);
- UTF-8/BOM/CR/final-LF/trailing-whitespace and exact path/type/mode checks;
- all 45 protected candidate endpoints and 217 HEAD-exact noncandidate files;
- unchanged B1/Wire source, both registry projections, all documents and identities;
- exact nine-module D1/two-fake-entry/sole-subprocess-owner inventories;
- unchanged package root, scripts/exports, StateStore, schemas/migrations;
- migration 0005 absence;
- before/after equality of all 263 normal final-clone endpoints;
- opening/closing live index content and recorded metadata equality;
- complete live cache directory/member equality, including nanosecond mtimes.

Correct identified external harness errors outside the live checkout and rerun
every affected gate from exact final bytes. Record failed/interrupted trials
truthfully. A late edit invalidates inherited final validation.

## 9. Retained-work closeout and next boundary

Preserve the retained candidate on every stop. No reset, wholesale rollback,
reconstruction from hashes, disposal of another actor's edits, or metadata
normalization. No source reconstruction or historical attachment request.
Report the actual changed file and any external residue rather than hiding it.

At closeout:

- baseline HEAD/tree/parent/branch remain identical;
- index stays HEAD-equal and unchanged in recorded bytes/metadata;
- status stays 29 M / 17 C;
- only tests/test_rw0_b1_boundaries.py differs from this opening;
- all 45 other candidate and 217 noncandidate endpoints remain exact.

Recompute all 46 endpoints and the SAME replacement stream twice from fresh
reads. Report the single target's before/after size, SHA-256, OS/Git mode,
unchanged HEAD blob and encoded component, plus preservation of the other rows.
The final aggregate length must reconcile as:

```text
4,511,038 + (final_B1_test_payload_bytes - 47,819)
```

Report encoded-row, prefix and total bytes and the observed final SHA-256.
Do not invent its value in advance or require another manifest grammar.
A full 46-row closeout is optional only when the single exact transition and
45-row preservation are unambiguous. The next handoff can reconstruct the full
identity from this mandate plus that observed transition.

Return inline:

1. Verdict, visible settings, exact baseline and preserved opening/index order.
2. The B1 helper and named owning-test call path, unchanged version-3 consumers,
   roles/symbols and relevant protection dependencies.
3. Original alias-form reproductions, separately labeled helper and complete
   module/owning-test observations; no claim of original exact mutation bytes.
4. Selected finite AST acquisition rule and all retained positive restrictions.
5. Permanent negative/positive cases and two guard-regression controls, with
   parse/import/collection versus semantic outcomes distinguished.
6. Exact single-file transition, 45/217 preservation and final replacement identity.
7. All twelve commands/memberships/inventory hashes/node counts/overlaps/warnings;
   failed trials, corrections, omissions, final-copy identity and cleanup.
8. Index/cache directory/member preservation and any historical/current procedure
   limitations; no retrospective claim that the prior status call was inert.
9. The unchanged runtime evidence and exact outstanding independent acceptance
   obligations, plus continuation capsule <=1,000 words.

For baseline/provenance drift, required validation not completed, cleanup
uncertainty or this run's unproved procedural preservation, retain work and use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V6_BLOCKED`

For a concrete essential owner/content dependency outside the ONE allowed path,
retain work, name its exact path/symbol/effect and use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V6_REPLAN_REQUIRED`

Success requires the reported guard defect closed causally, unchanged runtime
and permissions, complete final implementation validation, exact preservation
and cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V6_VALIDATED_READY_FOR_REAUDIT`

Success supports ONLY a fresh independent read-only acceptance audit of the new
exact candidate. It authorizes no staging, commit, publication, D2, physical C2,
migration 0005, live authority/provider/supplier, enrollment, deployment,
ES/Bridge route, Git effect or RW0-E. The repair is not an acceptance audit.
