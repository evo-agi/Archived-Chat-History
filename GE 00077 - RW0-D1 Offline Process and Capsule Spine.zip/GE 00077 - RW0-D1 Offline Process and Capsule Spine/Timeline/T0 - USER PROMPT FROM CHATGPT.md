Before selecting the next tranche, reset the RW0 critical path from the current
merged baseline.

Do not treat every remaining semantic seam as a separate contract tranche.
The recent sequence has produced several accepted target contracts without
advancing worker, model, process, capsule, durable C2 decision, or terminal
runtime capability.

No further standalone docs-and-contract-test tranche is permitted merely
because another value, envelope, read-set, currentness, or recovery seam can be
specified.

Select the next observable operating capability.

My product priority is removal of my routine message-bus role.

Evaluate and recommend the shortest path between:

1. RW0-D offline message-bus-free vertical slice:
   - one supplied intent;
   - model planning;
   - process-separated fake worker/Codex execution;
   - candidate and capsule;
   - validation and independent review;
   - model review proposal;
   - typed handback;
   - fake authority/currentness sources;
   - disposable state and no live credentials.

2. RW0-C2 implementation-bearing durable-state slice:
   - exact bounded-hybrid physical representation;
   - migration 0005 only if truthfully required;
   - scope-admission provisioning;
   - guarded five-branch decision and immutable acceptance-fact family;
   - exact replay and readback-only recovery.

State which must come first, which interfaces must be stable between them, and
whether any bounded work can proceed independently without creating two active
user-relay-heavy programs.

A semantic clarification may be incorporated into an implementation tranche.
Do not recommend another standalone target-contract tranche unless a named
current contradiction makes source work unsafe.

Return:

- current implemented capability;
- target-only contract debt;
- selected next capability;
- why it directly advances operating autonomy;
- exact nonclaims;
- one or two implementation-bearing tranches;
- evidence that would force replanning.

Do not issue a Codex prompt yet.
Do not ask me to select schemas, transaction mechanics, tests, files, or
ordinary engineering boundaries.
