## Disposition

**Accept the scope stop. Preserve the retained D1 repair and Wire amendment; complete the B1 consumer coordination within the same repair candidate. Do not stage, commit, or send it for re-audit yet.**

The Wire-only continuation was too narrow. I should have followed **every newly exact handback type to its owning consumer guard**, rather than correcting only the first failing dependency.

Codex correctly stopped: the handback now directly imports `RW0PhaseEntryBasisV1`, while the B1 registry and importer guard still name only D1 pre-execution as the bounded D1 consumer. That is a real contract/test coordination requirement, but it does **not** require changing the D1/D2 architecture or recreating the implementation. Pasted text

## Engineering decision

**Admit the handback as an explicit, evidence-only consumer of `RW0PhaseEntryBasisV1`. Preserve pre-execution as the D1 basis constructor and C1 as the durable phase owner.**

The exact dependency is:

```text
Consumer:
src/ge_nwp_coordinator/_rw0_d1_handback.py

Field:
phase_basis

Existing supplying module:
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py

Only newly permitted B1 symbol:
RW0PhaseEntryBasisV1
```

This allows runtime-exact validation and retention of an already constructed, C1-established phase basis. It does not authorize the handback to construct or reconstruct a basis, call qualification or authorization relations, establish a phase, or infer execution permission from the value.

The handback must not revert to `object`, annotations alone, class-name strings, or re-exports through pre-execution to avoid the direct-consumer guard.

### Coordinate the owner and both fixed projections

The primary correction is confined to three existing candidate files:

```text
.docs/rw0-b1-pure-phase-values.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The third file matters: it carries an independently fixed B1 registry projection and composition assertions. Updating only the B1 owner and importer test would leave another known dependency inconsistent. In the inspected baseline, those expectations appear at `tests/test_rw0_remote_contact_phase_entry_contract.py:659–691,3024–3057`.

The replacement prompt advances the **consumer registry**, not the B1 value schema, from version 2 to version 3. It distinguishes two exact D1 roles:

```text
RW0-D1-pre-execution:
constructs the phase basis for the current guarded C1 command

RW0-D1-handback:
validates and retains the exact established phase evidence
```

All existing non-D1 consumer permissions remain unchanged. B1’s source authentication, executable permission, durable persistence, and semantic acceptance remain **none**.

The importer guard must retain a closed path-and-symbol allowance. Its negative controls must reject another importer, an extra B1 value or helper, nested unauthorized imports, wildcard/module aliases, and weakened restrictions on existing consumers. The registry and its two test expectations must remain independently fixed—not derived from whatever imports the candidate happens to contain.

## Preserve what already works

Only the Wire boundary test changed during the latest continuation. The eight runtime-repair endpoints remained byte-identical, and the Wire extension passed its positive and hostile controls. The report also reconfirmed the four original repair behaviors, including forked-child custody rejection, cleanup classification, and malformed-frame handling. Pasted text

Accordingly, the revised ceiling contains **twelve existing candidate paths**:

- The three B1 coordination files are the primary work.
- The previous nine paths remain available only for a necessary correction to the original runtime findings or their direct consumer-boundary controls.
- The other **34 candidate files** remain byte-identical.

No new file is authorized. The total remains **29 modified plus 17 created paths**. No `AGENTS.md`/`README.md` identity reset, Wire source change, B1 implementation change, migration, public export, or new runtime owner is selected.

This is a dependency amendment inside the retained source-bearing D1 repair—not another standalone contract tranche.

## Validation must use the corrected dependencies

The latest report establishes useful partial results:

| Gate | Reported result |
|---|---:|
| D1 | 92 passed |
| Wire | 123 passed |
| Capability | 60 passed |
| Bootstrap guard | 289 passed |
| Legacy guards | **1,753 passed; one B1 importer failure** |
| Remaining changed owners | Not collected or run |
| Complete repository | Not collected or run |

The static inventory hashes for the last two groups are **not test results**. Pasted text

The next continuation must recompute **Group 10**, which contains the B1 guard, and **Group 11**, which contains the independent phase-entry projection. Their old hashes cannot remain mandatory after their authorized edits. The complete-suite inventory and node count must also be recomputed and executed.

The prompt requires a bounded static review of **all actual handback type dependencies and their closed guards before editing**, followed by focused importer/projection checks before the expensive final run. That addresses the repeated failure mode rather than waiting for another full-suite run to reveal an adjacent registry.

After the last edit, all twelve groups must run from one fresh final candidate. Earlier successful groups remain diagnostic evidence, not final acceptance.

There is also a narrow evidence limitation to carry honestly: the latest run preserved the 37 cache members, but did not record the cache directory’s own opening mode and mtime. That does not establish directory mutation; it means full directory-metadata equality was unproved for that interval. The new continuation must capture the directory **and** members completely at its true opening. Pasted text

## Complete continuation handoff

Resume the **same implementation Codex conversation**, preserving the current retained checkout.

:chatgpt-content-reference{index="4"}[Download the complete RW0-D1 audit-repair continuation prompt V3](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V3_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V3_Prompt.txt

Bytes:
39,809

SHA-256:
b9cf687a702b0111b2686835578b19500d12cc41a18fa28eaea98a60ebe148b2

Lines:
674

Final newline:
present
```

It starts from the **latest retained identity**, including the completed Wire amendment:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement recipe:
4,453,900 bytes
66eea37eb17621aafa1b55e1cda250a1a11477612d0d97041cdef7c6781806b9
```

It does not require either older pre-Wire or pre-repair identity. The handoff includes all 46 opening receipts, the twelve-path ceiling, the selected B1 roles and symbol allowance, both registry projections, exact validation inventories, corrected count/hash treatment, and retained-work protection.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT
```

Success supports only a **fresh independent read-only re-audit**. It authorizes no publication, D2, C2 physical implementation, migration `0005`, supplier or live-source work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the current closeout and issued V2 continuation, inspected the snapshot’s B1 owner, importer guard, independent phase-entry projection, and related protection references, and corroborated all **29 baseline blob identities** in the new handoff against that snapshot. I also checked the updated receipt-component arithmetic and reopened the generated prompt.

I did **not** inspect the live repaired source or reproduce its runtime tests. Current endpoint and behavior claims remain Codex-reported until the continuation and independent audit verify them.

**Sources:** The attached V2 closeout; the issued V2 repair mandate; the October 15 Coordinator snapshot, particularly `tests/test_rw0_b1_boundaries.py:476–533` and `tests/test_rw0_remote_contact_phase_entry_contract.py:659–691,3024–3057`.

Some older uploads have expired. Please re-upload an older original when a later comparison requires its bytes; the current closeout, prior prompt, and snapshot were readable.

**Confidence:** High on the bounded B1 consumer decision and preserving the retained implementation. The corrected prompt covers the known owner/importer/projection dependencies; final runtime correctness and complete validation remain unresolved.
