## Disposition

**Accept the audit block. Preserve the retained D1 candidate and repair the two handback invariants plus the bounded Wire-guard gap. Do not stage, commit, or begin D2.**

These are implementation defects, not another dependency-registry problem or a reason to replan D1.

The earlier repair enforced exact outer types and separated stopped from cleanup outcomes, but it did not fully enforce **what those types contain** or **which execution stage the evidence can truthfully describe**. Those requirements were already part of the handback boundary; no new semantic-contract tranche is needed. Coordinator_RW0_D1_Offline_Proc…

The latest report does **not** establish that the normal run leaked a resource or emitted the impossible stopped states. It establishes that actual successful-run values can be substituted into malformed handbacks that the constructor accepts. That is sufficient to block this typed boundary’s acceptance.

## 1. Validate the capture’s contents at its owner and consuming boundaries

The first finding crosses two existing owners:

```text
_rw0_d1_workspace.py
    owns D1CandidateCapture and the validity of its nested data

_rw0_d1_handback.py
    admits and retains that capture as transient evidence
```

Checking `type(capture) is D1CandidateCapture` is insufficient when the class permits unchecked entries. Concealing those entries in `repr` does not make them safe.

**The repair should establish one owned, complete capture-value validator**, used during ordinary construction and again when the handback accepts the value. The capsule’s existing construction/verification boundaries should use the same validation where necessary—not a second, independently evolving schema.

That validator must cover the actual existing capture structure: every container, entry, and scalar leaf. It must retain only the exact immutable data types that structure requires and reject the demonstrated live run, arbitrary object, and state-root `Path` without opening, serializing, coercing, or disposing of them.

Two distinctions matter:

**Constructor validation and consumer validation are separate obligations.** A normal capture constructor must reject malformed entries. A handback must also reject an exact capture wrapper containing malformed entries when a controlled test deliberately bypasses normal construction. This is bounded fault-injection evidence—not a claim to secure Python against arbitrary code rewriting its interpreter.

**Data paths are not live resource handles.** Authorized repository-relative capsule paths remain legitimate data, and captured file bytes remain opaque bytes. The repair must not introduce a heuristic “path-looking text” scanner or reject legitimate content merely because it contains a pathname. The original audit mandate already made that distinction. Coordinator_RW0_D1_Offline_Proc…

The permanent integration control must exercise the reported hole directly: insert the **actual open run, actual state-root path, or arbitrary object under a nested capture entry** in a handback produced from a real D1 run. The boundary must reject it, and the parent must still be able to close its state normally.

## 2. Bind each stopped reason to a valid evidence prefix

A closed reason set is not a causal invariant. The constructor must check whether the retained evidence could exist at the point described by that reason.

The three reported examples require these distinctions:

| Stopped reason | Evidence that may legitimately remain | Evidence that must not be claimed |
|---|---|---|
| `invalid_input` | Only evidence legitimately available at initial input rejection | Later planner, selection, phase, worker, or capture evidence |
| `planner_frame` | Earlier committed program/author facts and planner-process facts actually observed on that failure path | Later selection, C1 phase, worker, Wire result, or capture |
| `worker_start` | Earlier committed lineage and, where applicable, a typed **failed-to-start** observation | A successfully executed worker, its Wire result, or captured candidate |

In particular, **do not prohibit `worker_process` indiscriminately for `worker_start`**. A failed-launch observation may be valid evidence. The constructor must distinguish that from a successfully started or completed worker.

The repair should derive a small explicit matrix from the current reason vocabulary and every actual handback construction site. Some broad reasons may permit several precisely enumerated stage prefixes; they must not become an unrestricted fallback.

This remains a check on a transient projection. It must not add a new authoritative stage ledger, harness-owned program state, or a `stage` field that makes its own evidence claims true.

The offline construction sites are included in the repair because the strengthened constructor must remain compatible with truthful failures. **Do not erase observed evidence or relabel a failure merely to satisfy the matrix.** Cleanup uncertainty must retain the process facts already observed, rather than masquerading as an early rejection or durable conflict. Coordinator_RW0_D1_Offline_Proc… Coordinator_RW0_D1_Offline_Proc…

## 3. Close the Wire guard’s own causal gap

**Repair the Low finding in the same candidate, without changing the consumer permissions.**

The current handback contains neither reported bypass. The audit also explicitly notes that B1 separately rejects `importlib`. Therefore this is not evidence of an active dynamic loader or a demonstrated full-suite escape.

Nevertheless, the Wire helper claims a closed consumer boundary and must reject the demonstrated re-export and dynamic-loading forms **when tested directly**, without borrowing B1’s protection. The existing mandate already forbids those forms. Coordinator_RW0_D1_Offline_Proc…

The amendment is limited to `tests/test_rw0_b2_wire_boundaries.py` and its finite source-text controls. It preserves the exact importer/symbol sets, permits legitimate annotations and exact-type checks, and rejects the reported forms through the same helper. It does not commission a universal Python import resolver or another parser framework.

## Bounded repair surface

The complete continuation permits changes to these **eight existing candidate files**:

```text
src/ge_nwp_coordinator/_rw0_d1_workspace.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_capsule.py

tests/test_rw0_d1_workspace_capsule.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_b2_wire_boundaries.py
```

The capsule file is available only for capture validation at its existing consumption boundaries; it should remain unchanged if that is unnecessary. Its independent reconstruction and manifest semantics are not reopened.

The other **38 candidate files remain byte-identical**, including all documents, the B1 version-3 registry and both projections, the supervisor, frame decoder, fake children, and pre-execution composition. All **217 noncandidate tracked files** remain HEAD-exact.

No new type-consumer permission, registry version, public field, source module, migration, or authority owner is selected. The prompt requires a compact examination of the actual capture shape, handback exits, and coupled guards before editing, so the repair does not discover another known dependency only after an expensive full run.

## Validation consequence

The latest independent evidence is narrower than the preceding implementation closeout:

```text
D1 group:
92 collected and passed

Selected B1/Wire checks:
29 passed

Groups 2–12:
not collected or executed by this audit

Complete test-file inventories:
matched, but were not test runs
```

The original broader durable-readback/recovery and transformed-copy acceptance obligations also remain incomplete. A successful repair run will not retroactively complete those independent checks.

The continuation requires all twelve implementation-validation groups from the **final repaired bytes**. It also requires direct nested-resource and stage-prefix specimens, six focused transformed-defect classes, and regression of the retained fork-custody, cleanup, frame-error, B1, and Wire fixes.

Because this repair can change three D1 test files and the Wire boundary test:

- Groups **1, 7, 11, and 12** need recomputed inventories.
- Groups **2–6 and 8–10** retain their exact test-file inventories.
- Group 11 must account for the same Wire test changes as Group 7.

The useful count check is:

```text
final full count =
    8,942
    + (final D1 count − 92)
    + (final Wire count − 123)
```

That is bookkeeping, not an expected pass manufactured by selecting or removing tests. The issued audit mandate likewise distinguishes inventory equality, actual execution, and independent acceptance. Coordinator_RW0_D1_Offline_Proc… Coordinator_RW0_D1_Offline_Proc…

## Complete repair handoff

Resume the **same implementation Codex conversation**, preserving the current retained candidate.

:chatgpt-content-reference{index="7"}[Download the complete RW0-D1 audit-repair prompt V4](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V4_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Audit_Repair_V4_Prompt.txt

Bytes:
42,842

SHA-256:
30f67b098531acfad47b79d7c208c6ad0837cacd9bdeff76c24abe31b5c4808c

Lines:
687

Final newline:
present
```

It binds the exact retained opening:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified + 17 created paths

Replacement identity:
4,465,502 bytes
b82b43fc4da2e5f258436cec351dcc2a561057b9edb64d7bffbbb35003c84974
```

The prompt contains the complete 46-path table, the unchanged replacement recipe, the eight-path ceiling, the owner/consumer validation requirements, stage-matrix requirements, Wire controls, exact validation groups, and retained-work rules. It requires no historical attachment or combined prompts.

Success is:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

Success supports only a **fresh independent read-only re-audit**. It grants no staging, commit, publication, D2, physical C2, migration `0005`, qualified-source or supplier work, ES/Bridge integration, or RW0-E execution.

## Evidence boundary

I read the latest audit pasted in your message and the issued re-audit requirements. I corroborated the **29 baseline blob identities** against the mounted October 15 snapshot, checked the complete receipt-component arithmetic, and reopened the generated prompt to verify its eight-path ceiling and affected validation groups.

I did **not** inspect the live D1 source or reproduce the new specimens. The candidate-specific source locations—handback `:94` and `:131`, workspace `:38`, and Wire guard `:612`—remain the auditor’s reported inspection coordinates.

**Sources:** Your latest independent re-audit; the issued repaired-V3 audit mandate cited above; October 15 Coordinator snapshot for baseline-blob corroboration.

Some older uploads have expired; re-upload a specific original when a later byte-level comparison needs it. The report and operative mandate needed here were available.

**Confidence:** High on accepting the block and repairing the capture-owner/handback boundary rather than adding more outer-type checks. The exact implementation and complete validation remain unproved until Codex repairs the retained bytes and an independent audit accepts them.
