# Governed Execution Coordinator — RW0-D1 Audit Repair V2: Wire Consumer Coordination and Completion

## Mandate

Continue the RETAINED uncommitted D1 repair candidate. Do not recreate D1 or
restore the original pre-repair bytes.

The prior eight-path repair stopped because the newly exact-typed handback
imports existing Wire result value types, while the Wire private-import guard
is outside the previous repair ceiling. That stop was required by the previous
prompt. This replacement authorizes the one missing guard surface; it does not
change the D1 operating model.

This is ONE source-bearing repair continuation. It is not a new contract tranche,
a separate process program, or permission for D2/C2 work. Preserve the eight
reported repaired files unless a remaining direct defect in the four audit
findings requires a bounded correction within the ceiling below.

The critical path is:

verify retained candidate -> inspect exact Wire dependencies -> update the
closed consumer guard -> exercise its positive and hostile boundaries ->
validate final candidate across all twelve groups -> independent re-audit.

The parent is the sole writer. No subagents. Use the highest exposed reasoning
setting and report visible model, effort, and permission posture or `not visible`.
Do not seek additional access just to discover hidden model settings.

Return one substantive INLINE closeout plus a continuation capsule of at most
1,000 words. Do not deliver a report, manifest, snapshot, patch, ZIP, or other
evidence package. Do not issue the next audit, publication, D2, or C2 prompt.

## 1. Exact opening state

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index equal to HEAD; no staged or unmerged paths
- exactly 29 modified tracked paths and 17 untracked created paths below
- no active Git operation, sequencer, or unexpected lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional-lock
suppression where appropriate. Do not fetch, normalize, reset, or discard work.
Local tracking equality is not fresh remote verification.

These are the current retained endpoint receipts, not the earlier audited
pre-repair receipts. Verify every row, baseline blob/absence, type, and mode
before editing. `C` below means untracked creation, not a commit or Git copy
status. All candidate files are regular and represented by Git mode `100644`.
Capture and preserve actual OS modes; do not normalize unrelated files.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Component bytes |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,153 | `d58c9c882a2c9c2a07c652c095f69ad49cced30b6cc170ff17d04daf0f7e6f51` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,221 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 9,698 | `76ef6a902733a0790da927b4881ad4bef6d2555d6b63be12517d347ea4f46802` | `absent` | 9,775 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,193 | `29e1dfb51e09941acea43ff907440f171a023d46a2de9bdce002d88f9088bc9f` | `absent` | 22,269 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 9,502 | `5d47b82d8b24f38f4a2c54825405f0370e308159908a104fdd9bc73c1ab970d9` | `absent` | 9,589 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 39,069 | `2dbb15ee10d7155c4255ae01f1499ae50acd6e43f666efef633737f9a466f679` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 39,135 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 30,703 | `2de0fb039733846bc416dbd4858cc07e66f6e97f4698416b2770a9701c7bd8a7` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 30,774 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 11,665 | `20470ec086cbad881c6d4687100905d4670b7f14cc53f3966e342585f1e4bda4` | `absent` | 11,736 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 13,881 | `fab122192528cdd0f668bc63181bea2e4a2fc70d3d1f42bd92061ff8532ffa79` | `absent` | 13,956 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 8,476 | `890c0717fcb1f5f9b53919d3c73b10dc54c98d53d1f1473e52a75108831ce9aa` | `absent` | 8,550 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 174,623 | `78b47b119f88e1642599e350cd95d217b1a4056621301012dc52ed5c8f6beee5` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 174,711 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

All 217 noncandidate tracked paths must equal HEAD by content and Git-relevant
mode. Baseline 246 files plus 17 additions equals 263 candidate repository files.
No path deletion, rename, symlink, submodule, executable change, or extra
untracked path is permitted. Preserve index equality to HEAD throughout.

### Opening endpoint replacement identity

Reconstruct twice from fresh reads using exactly:

```text
prefix: ASCII RW0-D1-BINARY-REPLACE-V1 followed by one NUL byte (25 bytes)
for each table row in UTF-8 path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20-byte baseline blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact final file bytes
```

Required opening identity:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,450,088
prefix bytes: 25
total bytes: 4,450,113
SHA-256: 8332920fe49edf41a91ebd047b3b62cea04692293c67a818aea1e2d79220068b
```

The 4,422,240-byte pre-repair recipe is historical only. Do not use it as this
continuation's required opening identity. No historical attachment is required;
all operative coordinates and instructions are in this prompt.

On any provenance mismatch, stop without editing or replacing the expected
coordinates. Preserve the actual retained work and report the mismatch.

## 2. Exact nine-path ceiling

Newly authorized for this repair continuation:

```text
tests/test_rw0_b2_wire_boundaries.py
```

Its required opening identity is:

```text
30,703 bytes
SHA-256: 2de0fb039733846bc416dbd4858cc07e66f6e97f4698416b2770a9701c7bd8a7
HEAD blob: 2ee82288a389f60d9ea71bebc8152ef10123794c
```

The previous eight repair paths remain available ONLY for necessary corrections
to the four original findings or their causal tests:

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
```

Prefer changing only the Wire guard and its direct negative controls; do not
rewrite successfully repaired runtime modules to avoid a guard mismatch.

The other 37 candidate endpoints must remain byte-identical to the opening
receipts. All 217 noncandidate tracked paths must remain HEAD-exact. No new path
is permitted. The overall candidate stays 46 paths, not 47.

Specifically keep unchanged:

- all candidate and baseline documentation, including AGENTS/README;
- `_rw0_wire_protocol_values.py` and all existing pure semantic owners;
- current program, author-effect, Section 41, C1, writer/session, transaction,
  database, and recovery source;
- fake planner/worker, workspace, capsule, and pre-execution modules;
- Capability, bootstrap-guard, B1, and C2 nonimplementation tests;
- package root, `pyproject.toml`, `.gitignore`, exports and script inventory;
- schemas, configuration, migration resources 0001–0004; no 0005.

No staging, commit, publication, branch change, network, dependency installation,
supplier, credential, enrollment, deployment, D2, C2, terminal, ES, Bridge, or
RW0-E action is authorized.

## 3. Resolve the exact Wire dependency before changing the guard

Read the CURRENT candidate's:

- `_rw0_d1_handback.py` and all actual handback construction sites;
- `tests/test_rw0_d1_handback_values.py` and integration tests;
- `tests/test_rw0_b2_wire_boundaries.py`, including its complete import guard;
- `.docs/rw0-b2-wire-protocol.md`, current D1 consumer/status clauses and result
  value definitions;
- `.docs/rw0-d1-offline-process-and-capsule-spine.md`;
- Wire result class definitions as data;
- relevant existing pure/import/public-boundary checks.

The committed Wire owner defines:

```text
RW0WireWorkerResultV1
RW0WireProcessResultClassificationV1
```

The selected new consumer is exactly:

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
```

Its permitted new direct imports are exactly the two existing result value
classes above, only as needed for its already required exact field validation.
Verify the retained source imports and the handback fields they serve; report
that small mapping inline. An import is justified by an actual typed evidence
field, not by naming similarity or by a desire to make the suite green.

This is a bounded private value-consumer extension. It does NOT confer:

- Wire decoding/encoding or process-classification execution on the handback;
- physical transport, launch, cancellation, or custody authority on Wire;
- public package exports;
- a new Wire schema, result class, digest, protocol version, or authority role.

Wire remains pure/no-I/O. The supervisor and offline composition retain their
existing responsibilities. The handback remains transient evidence.

If the retained handback actually requires another Wire symbol, identify the
field and owning requirement before proceeding. Do not silently expand to all
Wire exports or another importer. A genuine owner contradiction outside this
specific two-value dependency is a stop, not permission for an import trick.

## 4. Narrow private-import guard amendment

Extend the existing importer cases/closed registry in
`tests/test_rw0_b2_wire_boundaries.py` to admit the handback as one named
consumer of only the two exact Wire value classes.

Keep all CURRENT candidate importer paths, allowed symbols, and import styles
for Capability, C1, and existing D1 consumers unchanged. Do not replace them by
an inferred dynamic set or broaden them by suffix/prefix matching.

For the handback, require an explicit direct relative import of the named value
classes. No wildcard, broad module alias, re-export through another D1 module,
`TYPE_CHECKING`-only workaround, `getattr`, `importlib`, `__import__`, or opaque
wrapper can replace the actual runtime type dependency.

Do not import codecs, `classify_wire_process_result`, cancellation relations,
transport helpers, or unrelated Wire symbols into the handback. Do not call a
Wire classifier merely to validate an already produced typed result.

Preserve every unrelated assertion in this guard: Wire's own import set and
pure source boundary, package-root nonexports, Capability ownership, no
back-edge, status normalization, profile identity, existing relations and
classification tests.

A small parameterized AST helper inside this same test file is permitted only
to make this existing finite guard testable against controlled source-text
specimens. This is not a generic import resolver or new schema framework.
Expected importer/symbol sets must be fixed literals, not derived from the
source under test.

### Causal guard controls

Permanent positive control: the real candidate handback's exact two value
imports pass, and a real successful D1 invocation constructs the correctly typed
handback.

Permanent negative controls must exercise the same guard path and reject:

1. another unapproved production module importing even those same two types;
2. the handback importing an additional Wire function or unrelated value;
3. the handback using a wildcard or whole-module alias in place of its admitted
   exact imports;
4. removing a previously protected importer/symbol constraint or admitting all
   `_rw0_d1_*` modules.

Use bounded source-text/copy specimens. A false assertion inserted by the test
itself is not evidence of the guard's causal behavior.

Inspect known references to this test before editing. The baseline Capability
registry's R25 identifies this path, mode, and authority-non-effect role; it is
not a full-file content hash pin. Preserve its role and mode. Do not modify
Capability P01 or any protected Wire source identity.

## 5. Preserve and complete the four runtime repairs

The preceding report says these repairs passed focused tests; they have not
received independent acceptance. Keep their required behavior and complete any
remaining defect within the eight originally authorized files.

### A. Typed, path-free handback

Require exact existing private value classes and closed immutable containers,
not `object`, `Any`, mutable generic metadata, or path/session/proof slots.
Optional values are `None` or the exact declared type.

Fixed independent tests must cover field names/order, actual accepted types,
repr behavior, and status/reason/evidence invariants:

- `capsule_ready` requires the successful planner and worker process evidence,
  required Wire/candidate/capsule evidence, committed durable lineage, and
  completed process/workspace cleanup;
- `stopped` has a valid non-cleanup reason and no fabricated ready capsule or
  evidence from an unexecuted stage;
- `cleanup_unresolved` has a cleanup reason and retains safely observed process
  evidence rather than reporting durable conflict or success.

Keep a real-run test that checks the CLOSED expected handback graph for raw
state/workspace paths, path-like values, sessions, descriptors, locks, proofs,
capabilities, and run-owner objects. Keep the live-path-insertion mutant.

No public serializer, re-exported Wire alias, generic object escape hatch, or
second program truth is allowed.

### B. Parent-only state custody

Fence custody-affecting methods to the creating PID before exposing state,
changing `_closed`, or removing resources. A real forked child must be rejected
without deleting the database or changing parent-visible custody. Parent close
must still succeed; its second close must be idempotent.

The immutable handback is separate from the nonserializable run owner. Do not
put a location or live capability back in it. Do not rely on a finalizer for
cleanup or claim same-UID adversarial sandboxing.

### C. Process cleanup classification

Retain PID/group/start/I/O/cancel/deadline/signal/exit/reap observations when
selector or stream cleanup fails. Attempt group-clear observation even after a
selector-close failure. Return a sanitized typed process outcome instead of
losing it through an exception.

Planner cleanup uncertainty yields `cleanup_unresolved` with its process
outcome and stops before Section 41. Worker cleanup uncertainty retains its
process evidence and cannot yield `capsule_ready`. Timeout/cancellation remains
observable alongside cleanup uncertainty. No generic `durable_conflict` label
for this resource-cleanup failure.

### D. Closed frame errors

Exact built-in type checks precede every enum/set/mapping membership operation
in D1O1/D1W1. Canonical JSON containing `"action":[]` must produce `D1FrameError`,
not raw TypeError; integrated handling must remain planner-frame failure before
Section 41, not a generic durable conflict.

Preserve existing durable initialization/author-effect/Section 41/C1 order and
all exact recovery gates. No unresolved recovery may launch the next child.

## 6. Implementation and evidence order

1. Authenticate the retained 46-path opening candidate and cache.
2. Inspect actual handback imports and the exact candidate guard cases.
3. State the selected bounded importer/symbol change inline.
4. Change the Wire guard and add its direct positive/negative controls.
5. Run Wire Group 7 first in an external clone, then D1 Group 1, to expose the
   dependency conflict early. These are development checks only.
6. Reconfirm the four runtime fixes and the ten prior repair mutants from the
   FINAL candidate; retain fixed expectations.
7. Add three small transformed checks for this scope correction: remove the
   new handback allowance; broaden its symbols/allowed import form; broaden the
   importer set to accept an otherwise forbidden D1 module. Each must fail an
   intended permanent test without syntax/import/collection failure.
8. After the last edit, create a fresh final external clone and run all twelve
   groups serially, even those which passed before the stop.
9. Recompute final endpoint and recipe identities; preserve the retained work
   and report ready only when all final gates pass.

The ten prior repair mutations to preserve are: arbitrary handback object slot;
ready handback without required evidence; live state path insertion; removed
creator-PID fence; escaping selector close; erased process evidence; cleanup
mapped to durable conflict; missing group-clear after selector failure;
membership-before-type decoding; frame error mapped to durable conflict.

For every mutation credit only semantic failure in normally collected tests.
Keep direct specimens, permanent tests, transformed copies, and any outside
oracle distinct. These mutable files do not authenticate arbitrary coordinated
changes to themselves; independent re-audit supplies that boundary.

## 7. Exact final validation plan

No live-checkout repository execution, imports, pytest, compilation, or database
access. All executable work runs in task-owned local-only external clones of
exact HEAD overlaid with the verified current 46-path candidate, with remotes
removed. Use installed dependencies only; no network.

Before any executable work, capture the known live `__pycache__` directory and
37 regular members as opaque path/type/mode/size/hash data WITH `st_mtime_ns`
from the true opening. Hash only regular files. Do not move or modify live
cache, inspect unrelated operator state, or normalize pre-existing OS modes.

Create the external root with mode `0700`; use normal test-process `umask 022`.
Precreate each collect/run basetemp parent. Run collection then execution,
serially with no xdist or overlap, from the remote-free clone:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<external-precreated-group-path> [--collect-only] <exact-paths>
```

Each name below means `tests/test_<name>.py`. Sort and deduplicate within each
group. These are the exact path inventories; do not select tests to manufacture
a reported count.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12: complete repository, with NO path arguments. It is still expected to
collect from the same 124 test modules; no new module is authorized.

### Preserved groups

The source files may change within the repair ceiling, but the following test
file bytes and inventories must remain exact and their regressions pass:

| Group | Files | Prior pass count | Inventory SHA-256 |
|---|---:|---:|---|
| 2 program | 9 | 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 8 Capability | 4 | 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |
| 10 legacy guards | 8 | 1,754 | `f0c8037a97d99ac77e81099c190b75c4f3e346988bde515913c2fb00a6236a45` |

### Changed validation coordinates — do not pin stale hashes

- Group 1: seven D1 test modules; retained repair reports 92 passing tests and
  inventory `2beb9ecda4ce8636339f5d3fe8f93526c0242cae9c1e498cf27f15a01da76acf`.
  Preserve that inventory if those tests need no further change; otherwise
  report the exact justified delta and recompute.
- Group 7: seven Wire test modules. The retained opening collected 117 and had
  one import-guard failure. Its old inventory was
  `53ccc8874d06f47f4eab42f13c20de874bd91035359bd4ad57bda2675ccd374e`.
  The newly authorized guard changes this group's bytes and may add tests.
  Recompute its final inventory and count; do NOT require the old hash.
- Group 11: six owner tests, including the SAME Wire boundary file. Its old
  count was 656 and inventory
  `95430563d25048a351e903fa0b7819434785d9b00149d8f0e4d87cb2a658e428`.
  Recompute this group as well; do NOT require its old hash.
- Group 12: recompute the complete module inventory and unique node identities
  from the final candidate. No earlier full-suite pass is claimed for the
  retained partial repair.

Inventory serialization, for each sorted repo-relative test path:

```text
u32be(path_utf8_length) + path_utf8 + raw_sha256(file_bytes)
```

Reconcile actual node additions/removals, not just totals. Groups 2 and 3 share
46 nodes; Groups 7 and 11 share the Wire-boundary tests. Do not sum pass counts
as unique repository coverage.

With only the four D1 test modules and one Wire test file permitted to change:

```text
final full node count = 8,820 + final D1 Group 1 node count + delta_Wire
where delta_Wire = final Group 7 node count - 117
final Group 11 node count = 656 + delta_Wire
```

These are reconciliation formulas, not substituted test results. No existing
behavioral test may be removed or weakened to satisfy them.

The expected existing warnings are the three Python 3.13 multithreaded-fork
DeprecationWarning records attached to:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warning records. Investigate additional warnings rather than
suppressing them. If actual environment support prevents a required POSIX/fork
probe, report the unsupported gate; do not claim the repair fully validated.

### Preservation and cleanup

Require `git diff --check`, no-index whitespace checks on all 17 additions,
strict UTF-8/BOM/CR/final-LF/trailing-whitespace checks, exact candidate path/type/
mode checks, all 37 protected candidate receipts, all 217 noncandidate HEAD
entries, unchanged package/source-owner/migration inventories, and absence of
migration 0005. All 263 clone endpoints must equal their pretest bytes afterward.

External inventories use `lstat`; open/hash only regular files, never follow
symlinks or open FIFOs/sockets/devices. Before removing test roots, account for
owned PIDs/process groups and any disposable state roots leaked deliberately by
mutants. Remove only positively identified task-owned roots after those
processes terminate. Report failed cleanup honestly; do not label an unproved
process or root as gone.

End with exact live cache member equality including opening/closing nanosecond
mtimes. Correct only identified external-runner errors outside the live checkout;
rebuild from the same candidate bytes and rerun affected required gates. Any
late candidate edit requires fresh final-candidate validation.

## 8. Closeout, retained-work rule, and outcomes

Do not roll back the existing repair because this task encounters another stop.
Preserve the retained opening work and any identifiable new task changes;
report exact state. Never reset the checkout or overwrite concurrent changes.
No source recreation or byte reconstruction from hashes is authorized.

Report inline:

1. verdict and visible settings;
2. opening/closing Git coordinates and exact current-candidate provenance;
3. verified handback field-to-Wire-class dependency;
4. precise importer/symbol extension, existing importer preservation, and guard
   positive/hostile outcomes;
5. dispositions and evidence for all four original repair findings;
6. exact nine-path opening-to-final transitions (including any unchanged path),
   with proof that the other 37 candidate receipts and 217 noncandidate tracked
   entries are unchanged;
7. recomputed 46-row replacement component lengths, total bytes, and SHA-256,
   calculated twice from fresh reads using the SAME recipe;
8. final twelve validation groups, exact commands/path inventories/digests,
   unique node counts, warnings, overlaps, failed trials, corrections, and
   skipped work;
9. permanent tests versus direct specimens versus transformed copies;
10. live cache, source/exports/migrations, process and temporary-root cleanup;
11. remaining nonclaims and continuation capsule.

A complete 46-row final table is welcome but not mandatory if the nine exact
transitions and the fixed 37-row preservation proof are unambiguous. No
additional receipt format or delivered evidence artifact is required.

Stop with `RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V2_REPLAN_REQUIRED` only
for a concrete owning-contract contradiction or genuinely necessary path outside
this nine-path ceiling. Do not treat this already authorized Wire importer
extension as a product-policy question.

Use `RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V2_BLOCKED` for provenance drift,
validation failure, unsupported required environment, unresolved concurrent
state, or safe-cleanup failure. Do not claim ready on a partial test run.

Success requires the exact retained candidate plus bounded correction, all four
runtime fixes, a still-closed Wire consumer boundary, every final validation
group completed, and required preservation/cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT`

Success supports only a fresh independent read-only re-audit. It authorizes no
commit, publication, D2 validation/review/model closure, RW0-C2 physical
implementation, migration 0005, supplier/live-source work, Git effect,
Bridge/ES integration, deployment, or RW0-E execution.
