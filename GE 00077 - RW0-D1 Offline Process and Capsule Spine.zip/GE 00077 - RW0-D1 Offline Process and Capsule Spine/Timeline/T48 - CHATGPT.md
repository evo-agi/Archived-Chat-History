## Disposition

**Proceed to an independent read-only acceptance audit of the exact repaired V9 candidate. Do not stage, commit, or begin D2.**

The closeout reports the intended five-file, test-only repair, discrimination of all four named regressions, preservation of the earlier launch and capsule controls, and successful execution of all twelve final validation groups. **No further repair or scope expansion is indicated before independent inspection.** Production, documents, migrations, and consumer permissions remain unchanged according to the report. Pasted text Pasted text

The next audit should close these four causal boundaries and the specifically omitted reap/group-cleanup negative copy **before** the expensive final suite. This is not another architecture or implementation tranche.

## The four repairs address the demonstrated gaps

| Boundary | What V9 reports | What the independent auditor must establish |
|---|---|---|
| **E01 — actual child inputs** | The real invocation’s observer checks each launch’s seven fixed environment keys, values, arguments, working directory, options, and exclusion of its parent state/database paths. The real-path leak now fails integration while the separate supervisor test still passes. | The observer measures the original inputs and permits the real launch; it does not sanitize the environment or act as a test-only launch gate. Expectations must be independent of the producer. |
| **S01 — planner prerequisite** | An individually valid unsuccessful planner remains admissible at its own failure prefix but is rejected in valid later-stage handbacks. Deleting the later-prefix predicate makes the new test fail. | The specimen reaches the planner-success prerequisite without being rejected first by an invalid process record, wrong prefix, or missing unrelated evidence. |
| **H01 — hard-link invariant** | A real alias outside the workspace preserves the three-path set and one valid edit. Removing both link-count checks now makes the permanent test fail. | The link still exists at the consumption boundary, and no extra-path, mode, type, or capture-shape error masks the link check. The no-alias counterpart must pass. |
| **G01 — fixed expected identities** | Capability and the independent bootstrap checker each require one literal table binding and reject subsequent rebinding, even when dynamically calculated values equal the approved literals. | Both checkers enforce the rule independently. Finding the first literal assignment, comparing equal runtime values, or borrowing the other checker’s rejection is insufficient. |

Those are appropriately targeted repair claims. The closeout supplies separate external-copy identities and reports semantic failures for the intended controls—not merely green normal tests. Pasted text Pasted text

### Two distinctions need particular scrutiny

**The environment observer must remain observational.** The E01 copy reportedly still launched both real children with the database path and reached readiness; the strengthened integration assertion then detected the violation. That is the required causal relationship. A wrapper that removed the key or refused to launch would instead be supplying a safeguard absent from the production copy. The repair mandate explicitly prohibited that substitution. Pasted text Coordinator_RW0_D1_Offline_Proc…

**The protected-table rule must distinguish observed from expected values.** Hashing the documents to collect observations remains legitimate. Recomputing the expected table from those same documents is not. Both new uniqueness predicates reportedly discriminate a second assignment whose resulting values are still correct, and each predicate’s deletion causes its own fixed negative case to fail while its harmless positive remains accepted. The audit must reproduce both independently, within the selected finite assignment forms—not expand into a general Python reflection analyzer. Pasted text Coordinator_RW0_D1_Offline_Proc…

## Complete the remaining cleanup proof early

**The standalone “skip process reap/group cleanup” negative copy is still unperformed.** The closeout correctly leaves that obligation open; successful real cleanup and neighboring R08 checks do not supply it. Pasted text

The new handoff places it immediately after the four repaired boundaries and before final-suite execution. The auditor must select an existing bounded child scenario in which omitting the cleanup has an observable consequence, then test the claimed permanent safeguard against that omission.

The evidence must distinguish:

```text
The runtime performed the required cleanup.
```

from:

```text
The audit rescued the deliberately broken copy afterward.
```

Emergency audit cleanup remains mandatory for safety, but cannot count as runtime correctness. Likewise, an invalid process record rejected before a real child exists, an unrelated inventory failure, or a syntax error does not demonstrate protection of the cleanup effect.

No production change or additional test repair is authorized during that audit. A surviving material omission would be reported as a finding.

## Provenance and validation reconcile

The candidate remains:

```text
29 modified tracked paths
17 untracked additions
46 candidate paths total

HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Final replacement identity:
4,557,456 bytes
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

The five endpoint increases total **19,101 bytes**:

```text
4,392 + 3,746 + 1,762 + 5,940 + 3,261 = 19,101
4,538,355 + 19,101 = 4,557,456
```

The report supplies complete final hashes for all five changed tests and states that the other **41 candidate endpoints** and **217 noncandidate tracked files** remain exact. I checked the replacement-row arithmetic; that does not reproduce the aggregate hash without the live candidate payloads. Pasted text

The principal final validation results are:

| Gate | Codex-reported collected / passed |
|---|---:|
| D1 runtime and integration | 115 / 115 |
| Capability | 70 / 70 |
| Bootstrap guard | 297 / 297 |
| Legacy guards | 1,783 / 1,783 |
| Complete repository | **9,005 / 9,005** |

The count increase reconciles exactly:

```text
8,984
+ (115 − 112)
+ (70 − 60)
+ (297 − 289)
= 9,005
```

The reported overlaps also reconcile to the **3,678-node union** for Groups 1–11. All twelve groups reportedly completed from the clone rebuilt after the last edit. The earlier 9,005-test run is not substituted for that final-byte run. Pasted text

I independently recomputed all twelve **test-file inventory hashes** using the mounted baseline bytes plus the supplied candidate endpoint hashes. They match the closeout. This corroborates membership and identity bookkeeping—not live payload authentication or test execution.

## Preserve prior independent evidence without promoting it to acceptance

The preceding audit had already completed the 58-row used-family readback, replay and recovery observations, all 29 tracked semantic diffs, and a complete 8,984-test normal run. Those were real independent observations, not work that must again be described as never performed. The V9 mandate and closeout preserve that distinction. Coordinator_RW0_D1_Offline_Proc… Pasted text

The next auditor should authenticate the unchanged supplying endpoints, inspect the five new test changes and affected compositions, and explicitly distinguish:

```text
prior independently observed evidence
current corroboration
new direct or transformed-copy results
final independent validation
```

The retained L01–L03 launch and V01–V03 capsule controls reportedly still discriminate their defects after the observer changes. Their next reproduction must continue to isolate the intended count, ordering, or verification failure rather than credit a newly strengthened environment assertion that rejects first. Pasted text Coordinator_RW0_D1_Offline_Proc…

The complete finite obligation register remains in the handoff. Earlier evidence may be reused only with an explicit, applicable basis; no missing experiment becomes complete through a normal-suite pass. All twelve final groups still require independent collection and execution on V9.

## Independent acceptance-audit handoff

**Use the independent auditor conversation that reported the four V8 gaps—not the implementation writer.** The prompt starts a new read-only preservation interval and proceeds without per-phase approval.

:chatgpt-content-reference{index="15"}[Download the complete repaired-V9 D1 independent acceptance-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V9_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V9_Independent_Reaudit_Prompt.txt

Bytes:
75,314

SHA-256:
b4bc420acaa7860cda2f825d02aaddd06fd5da651b1e846b59ab2e9e8f07034a

Lines:
1,114

Final newline:
present
```

It includes the complete **46-path final receipt table**, existing pre-Git opening mechanism, four repaired causal boundaries, the early standalone cleanup obligation, retained finite acceptance register, evidence-reuse rules, and all twelve exact validation memberships and hashes. No earlier prompt or historical payload attachment is required.

The live checkout remains read-only. Executable work is confined to disposable, remote-free external copies. No candidate repair, staging, or publication is authorized.

Possible verdicts remain:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would establish eligibility for a **separately issued commit/publication gate**. It would not authorize D2, physical C2, migration `0005`, live authority/provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the V9 closeout and repair mandate in full, corroborated all 29 baseline blob identities and the 17 additions’ absence against the mounted snapshot, checked the replacement arithmetic and twelve inventory hashes, and reopened the generated prompt. Its embedded opening/helper code was syntax-checked, not executed against your Mac.

I did **not** inspect the five live amended tests, reproduce E01/S01/H01/G01, or execute repository code or tests. The repair’s behavior and 9,005-pass result remain Codex-reported.

Some older uploads have expired. Re-upload a specific original when a later byte-level comparison requires it; this handoff needs no historical attachment.

**Sources:** V9 repair closeout and issued V9 mandate, cited above; October 15 Coordinator snapshot for baseline and inventory corroboration.

**Confidence:** High on re-audit readiness, the test-only scope, and provenance bookkeeping. Permanent-test adequacy, the remaining cleanup proof, and complete independent acceptance remain unresolved.
