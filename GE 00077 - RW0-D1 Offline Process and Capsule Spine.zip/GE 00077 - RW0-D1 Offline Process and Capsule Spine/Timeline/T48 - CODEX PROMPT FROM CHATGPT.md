# RW0-D1 Repaired V9 — Independent Read-Only Acceptance Audit
# Four repaired test boundaries; finish the named remaining cleanup proof

## FIRST TOOL ACTION — live AGENTS as text, never Git first

Use the independent AUDITOR conversation that reported the V8 four-gap block,
not the implementation writer. This instruction authorizes ONE NEW read-only
observation interval. The next repository-related tool call must read live
AGENTS.md as plain text from neutral workdir `/`:

```sh
python3 -I -B -S - <<'PY'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY
```

Read all guidance; use further plain-text reads if output truncates. Do not
prepend git status, rev-parse, repository bootstrap, settings discovery using
Git, or a parallel preflight. Then execute section 1's filesystem-only opener
BEFORE any Git command, clone, repository import, test or probe. All subsequent
live Git reads must use its emitted helper. No inherited shell environment is
assumed. The helper cannot stop a raw command issued before it exists: perform
this first action correctly rather than treating the script as an OS interlock.

If the opening order is missed, stop immediately with AUDIT_BLOCKED before
cloning or tests. Do not reconstruct historical metadata, reset an index, replace
an opening record, silently restart the interval or attribute an unobserved
command to startup automation. After a valid opening and subject authentication,
complete the audit without further user approvals or planning-only handoffs.

## Mandate, current subject, and evidence classes

Audit the retained uncommitted V9 candidate, with NO live repository mutations.
The implementation closeout reports:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V9_VALIDATED_READY_FOR_REAUDIT`

The repair changed only five existing test files. All nine D1 production
modules, every document, current durable and pure owners, migrations, public
surfaces and consumer permissions reportedly remain unchanged. The subject is:

```text
29 modified tracked paths + 17 untracked additions = 46 candidate paths
replacement bytes: 4,557,456
replacement SHA-256:
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

All 46 full endpoint hashes are supplied below. There is no abbreviated or
MEASURE row, no historical payload prerequisite, and no permission to substitute
fresh observations for mismatching fixed expectations.

The latest completed independent V8 audit reproduced four causal-test survivors:

| ID | Original severity/type | Independent finding on transformed copies, not retained production |
|---|---|---|
| E01 | High acceptance evidence | Runner and supervisor passed the real parent SQLite path to both children; normal integration and separate direct-supervisor isolation test passed |
| S01 | Medium test causality | Deleting only the later-prefix planner clean-success predicate admitted a valid later handback with an individually valid unsuccessful planner; owning tests stayed green |
| H01 | Medium test causality | Deleting both nlink checks stayed invisible to an in-workspace extra-path specimen; an external hard-link alias with an otherwise valid workspace was admitted |
| G01 | Low protected-content test causality | A second dynamic protected-table assignment tracked current AGENTS/README bytes; the runtime values equaled fixed literals and selected owning tests passed |

V9 reports new permanent discrimination for each: actual-run launch input
snapshots; isolated planner prerequisite specimens with positive controls;
real outside-workspace link evidence; independently fixed single-literal-binding
checks in Capability and bootstrap. Reports are not independent acceptance.

V9's final implementation validation reports all twelve groups passing, including
115 D1, 70 Capability, 297 bootstrap and 9,005 complete repository tests. It also
reports retained L01-L03 launch and V01-V03 verifier causal controls still work.
Inspect actual final tests and reproduce those claims where required below.

Prior independent V8 evidence is real progress, not erased by this repair:
all twelve groups passed (8,984 full); all 58 used durable-family rows and original
timestamps matched current owners and replay; 29 tracked semantic diffs were
reviewed; real FD/child isolation and named L/V/P/N/R/W/B observations completed
as described. The four survivors remained blockers. One specifically unperformed
item was the standalone skip-process-reap/group-cleanup negative copy. Neighboring
cleanup/R08 tests do not discharge it. Do that named check EARLY in this audit,
after the four repaired boundaries and before the expensive final suite.

Keep separate: authenticated content, static inspection, independent direct
specimens, permanent tests, transformed-copy discrimination, prior independent
observations, implementation reports, and inference. Prior reported experiments
are never relabeled as fresh execution. A passing normal suite does not close a
known surviving material mutation. An audit-only detector cannot stand in for a
permanent safeguard whose causal protection is claimed.

D1 -> D2 -> physical C2 remains selected. Do not add requirements for arbitrary
Python reflection, hostile same-UID/native-code isolation, a new orchestration
protocol, or general fuzzing. The finite checks below are the existing selected
D1 obligations plus the four named repairs, not a new architecture program.

Use highest exposed reasoning and report visible model, reasoning effort and
permissions or `not visible`, without additional account/computer access. Parent
only; no subagents, network, providers, live credentials, supplier qualification,
sibling repositories, enrollment, deployment, Git publication, ES or Bridge.
Only fixed fake children and bounded audit/test processes inside owned external
copies are allowed. Return operative findings INLINE with exact repo-relative
path:line evidence and a continuation capsule <=1,000 words. Deliver no patch,
manifest, report file, archive, freeze package or subsequent task prompt.

## 1. Exact baseline and pre-Git preservation opening

Repository: `/Users/ds/Repositories/Governed Execution Coordinator`

- branch trunk_dev;
- HEAD 0d0926e3a483a3ab1a4fd597ac0495927352bf35;
- tree 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4;
- sole parent 630414faa07f4ac39c4a870a9cc44c7f92d46b80;
- subject: docs: freeze RW0-C2 scope admission provisioning;
- upstream origin/trunk_dev, locally 0 ahead / 0 behind;
- one worktree, index equal to HEAD, zero staged/unmerged paths;
- exactly 29 modified and 17 created candidate paths below;
- no active Git operation, sequencer or unexpected lock.

After reading AGENTS, execute this block from a neutral directory. It invokes no
Git, repository module, SQLite or test. It captures the index and known cache
then creates a forced-environment inspection helper under a mode-0700 external
root. It retains the successful Restart 01 mechanism, with this engagement's
labels. Do not substitute historical timestamps, inodes or hashes for fresh
opening observation. The helper is temporary instrumentation, not product truth.

```sh
python3 -I -B -S - <<'PY'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env

import datetime
import shutil
import tempfile

# This block does not run Git or import repository modules.
guarded_environment()
for key, value in GUARDS.items():
    os.environ[key] = value
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_does_not_match_the_fixed_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_not_found')
root = Path(tempfile.mkdtemp(prefix='rw0-d1-v9-acceptance-audit-'))
print('AUDIT_OWNED_ROOT=' + str(root), flush=True)
os.chmod(root, 0o700)
record = {
    'schema': 'rw0-d1-v9-acceptance-audit-opening-observation',
    'phase': 'recorded-before-first-git-in-this-audit-attempt',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents,
    'index_path': str(index), 'index': index_before, 'cache': cache_before,
    'git_environment': GUARDS, 'git_executable': git,
    'historical_limit': 'older audits lack pre-first-Git metadata; this record covers only this audit interval',
}
wrapper_text = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\nimport subprocess\nimport sys\n\nopening_path = Path(__file__).with_name('opening.json')\nopening = json.loads(opening_path.read_text(encoding='utf-8'))\n\ndef verify_preservation():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('live_index_location_drift')\n    if regular_record(index_path()) != opening['index']:\n        raise RuntimeError('live_index_content_or_metadata_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('live_guidance_drift')\n\nargs = sys.argv[1:]\nverify_preservation()\nenv = guarded_environment()\nif args == ['--check']:\n    print('RW0_D1_V9_AUDIT_OPENING_PRESERVATION_OK')\n    raise SystemExit(0)\n\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_git_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'],\n                                                               ['--quiet', 'HEAD']):\n    raise RuntimeError('only_readonly_head_symbolic_ref_allowed')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('only_worktree_list_allowed')\nfor arg in args[1:]:\n    if (arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec')\n            or arg.startswith(('--output=', '--exec='))):\n        raise RuntimeError('unapproved_git_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager',\n           '-c', 'core.fsmonitor=false', '-c', 'gc.auto=0',\n           '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=env, check=False)\nfinally:\n    verify_preservation()\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(payload)

try:
    write_private(root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(root / 'live_git.py', wrapper_text.encode('utf-8'))
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_any_git_command')
    print('LIVE_GIT_HELPER=' + str(root / 'live_git.py'))
    print('OPENING_RECORD=' + str(root / 'opening.json'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_V9_AUDIT_PRE_GIT_OPENING_RECORDED')
except BaseException:
    # Only known regular files written by this invocation are removed.
    for name in ('live_git.py', 'opening.json'):
        owned = root / name
        if owned.exists():
            if not stat.S_ISREG(owned.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            owned.unlink()
    root.rmdir()
    raise
PY
```

Use the ACTUAL emitted helper/root paths. Do not assume shell variables persist,
guess a temporary root, or rerun the opener to replace its record. Every LIVE
Git inspection goes through the helper:

```sh
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_GIT_HELPER> rev-parse HEAD
```

The helper enforces GIT_OPTIONAL_LOCKS=0, GIT_NO_LAZY_FETCH=1 and noninteractive
inspection per subprocess, disables external diff/textconv/fsmonitor and checks
index content/metadata and cache before/after. --check invokes no Git. It does
not wrap pytest or prove correctness. It checks AGENTS/index/cache,
not all candidate hashes; full candidate checks remain mandatory and no edit is allowed.

Local-only external clone creation is separately permitted with equivalent
command-local suppression; no live index/config change, fetch or maintenance.
Remove clone remotes before execution. Missing objects/unsupported inspection
are a stop, not raw-Git fallback permission. No live Git write is authorized.

Authenticate baseline and complete candidate before executable audit work; provide one compact
inline opening acknowledgement, then proceed automatically. If any Git preceded
this interval's opening, stop before clones, probes or tests. Do not reset the
index, reconstruct prior history, restore metadata or silently rebaseline.
The recent valid audit interval does not replace this audit's own record.

## 2. Complete final 46-path identity

M is a tracked modification; C is an untracked creation, not a commit/copy.
Every candidate is a regular nonsymlink OS-mode 0644 file represented by Git
100644. Preserve unrelated nonexecuting 0600 baseline files, including the known
program-initialization test. Do not normalize modes. Strict UTF-8, no BOM/CR,
one terminal LF, no trailing whitespace; no renamed/deleted/extra path, symlink,
submodule, executable bit, public export, or migration 0005.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 50,244 | `cadcb41f652a539b5e2ac50ca6fe0bc192e321a663ac338ff9a2516d7d0b5844` | `b61f1744059a87988bff7bde032f3b578a554b18` | 50,321 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 120,405 | `44089176794734a285afd3852c97fddcfd073fb6d99d2d68667b91952d392921` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 120,505 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 26,977 | `bdf1f78b9a359dfbc36c768e8bb44b2151de8bcaf74046401e4f8a9c20d73807` | `absent` | 27,048 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 53,116 | `21796d33330e62b4a389207063022e44c5458a4fe847e509f33d247b65b80afe` | `absent` | 53,191 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 9,390 | `381ff379133bacd6264942cfea26af0cdf8ddbfdb424f77ea9e82fb9d6ad2264` | `absent` | 9,463 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read all 29 baseline blobs from HEAD and corroborate their OIDs. The 17 creations
must be absent from HEAD and index. All 217 noncandidate tracked paths remain
HEAD-exact in content/type/Git mode. Baseline 246 plus 17 creations = 263 source
endpoints. Do not count or copy the 37 live opaque cache files into that set.

Reconstruct twice from independent fresh file reads, without importing code:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte (25 bytes)
for each row in UTF-8 repository-relative path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw bytes of baseline HEAD blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact file payload bytes

46 rows: 29 M / 17 C
encoded row bytes: 4,557,431
prefix bytes: 25
total bytes: 4,557,456
SHA-256: 53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

A streaming and a concatenating calculation are suitable. This is a stream of
raw payloads, NOT per-file digest strings. No new recipe, skipped row, guessed
hash, reconstruction from hashes, changed expected aggregate or extra evidence
package may substitute. Any mismatch is AUDIT_PROVENANCE_MISMATCH before
semantic acceptance.

### V8-to-V9 delta: five tests, all runtime unchanged

The immediately previous stream was 4,538,355 bytes,
173adda1a4d1cab3a0056a5156339e1fd1f059533a4f11e915894ddb21ea0ce0.

| Path | V8 bytes | V9 bytes | Increase | Final encoded component |
|---|---:|---:|---:|---:|
| `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | 50,244 | 4,392 | 50,321 |
| `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | 120,405 | 3,746 | 120,505 |
| `tests/test_rw0_d1_handback_values.py` | 25,215 | 26,977 | 1,762 | 27,048 |
| `tests/test_rw0_d1_offline_integration.py` | 47,176 | 53,116 | 5,940 | 53,191 |
| `tests/test_rw0_d1_workspace_capsule.py` | 6,129 | 9,390 | 3,261 | 9,463 |

The five increases total 19,101 bytes: 4,538,355 + 19,101 = 4,557,456.
Every other 41 endpoint retains its listed value. All production and document
bytes are unchanged. The closeout's pathname-component lengths are not the
replacement-row lengths; use the established binary encoding above and actual
UTF-8 path lengths. Do not impose an unrelated 255-byte component rule as proof
of replacement identity.

Authenticate the COMPLETE final table. Prior copy hashes identify reported
observations, not available source payloads. No old V8 payload is required; without
it do not claim a direct historical bytewise diff or old-to-new test-body equality.
Inspect current tests and their actual behavior. Exact final identity proves byte
binding, not correctness or authority.

## 3. Execution ceiling and audit order

LIVE checkout: text, metadata, hashing and guarded read-only Git only. No source
edits, formatting, staging, config/ref/index writes, repository imports, pytest,
compiler, scripts, child launch, SQLite open, or ignored product/operator state
inspection. Read the index and known cache only for preservation, not as product
state. No network, dependencies, real credentials/provider, D2/C2 or publication.

Executable work is confined to audit-owned local-only external copies/clones of
exact HEAD plus the 46 verified candidate endpoints. Remove configured remotes
before execution. Copy no live cache. Use installed dependencies, owned mode-0700
roots, test-process umask 022, owned TMPDIR, disabled bytecode/pytest cache,
precreated distinct basetemps, serial groups and no xdist. Verify all 263 source
endpoints before and after normal-copy runs. Keep transformed copies separate.

Order in this ONE interval:

1. Correct guidance/pre-Git opening; authenticate complete V9 and record one
   compact inline acknowledgement, then proceed without a user checkpoint.
2. Read all five changed tests, their actual production owners and current D1
   owner. Inspect current direct call sites and previous reported findings.
3. Close E01, S01, H01 and G01 with independent positive/negative/call-through
   evidence, and the small final-byte causal copies below.
4. Complete the named standalone skip-reap/group-cleanup negative copy EARLY.
5. Reconfirm affected L01-L03 and V01-V03 compositions and remaining current
   acceptance requirements. Record which earlier independent observations are
   corroborated as prior versus rerun; no fabricated new or reset-to-unperformed
   history. Cover the retained finite obligation register without adding quotas.
6. One fresh unmodified final clone; collect/run all twelve exact groups.
7. Cleanup all owned processes/roots; reproduce live provenance/index/cache
   equality with the original helper; return a supported verdict.

A material current defect or permanent-test survivor permits early BLOCK with
precise omissions. No candidate repair is permitted. A scope or evidence limit
is not permission to weaken a guard or change the runtime. Do not stop at an
opening-only result once authentication succeeds.

## 4. E01 — real runner-to-child isolation, not a separate supervisor fixture

### Inspect the five-file change in its actual ownership context

Re-resolve report pointers against authenticated bytes:

- tests/test_rw0_d1_offline_integration.py:164 -- child-input assertions;
- supervisor Popen lookup and environment around :163/:173;
- tests/test_rw0_d1_process_supervisor.py -- unchanged direct isolation case;
- current offline state-location creation, planner/worker calls and close paths;
- actual V8 observer and its strengthened normal/recovery callers.

Read the integration observer and actual producer, not only its new assertion.
The permanent observer must snapshot ALL invocation Popen inputs before calling
through unchanged: argv, environment, cwd, close_fds/pass_fds/session/shell
options and returned real process handle/PID or failed start. It must record
ignored/unreported children and stay active across recovery, cleanup and return.
It must not sanitize an environment, remove a key, block a mutant launch, filter
by the final handback, or treat only the reported worker as the invocation.

Independently identify THIS invocation's parent SQLite path and state root from
current parent-only location/custody creation, not from the child inputs or a
foreign test path. Distinguish those resources from the outer audit root and
permitted planner/workspace siblings. Keep raw paths/args test-local and errors
content-free; do not inspect real credentials or scan opaque capsule bytes.

The seven permitted environment key names must be literal expectations fixed
independently of the producer's environment-building function. Fixed values
must match current source/contracts; per-run values must bind the actual permitted
interpreter/package/scratch/workspace, not arbitrary captured values copied back
as their own expectation. Check both key membership AND contents of allowed
values. Valid observations must not fail merely because all roots share a parent.

At every real invocation launch independently establish:

- correct fixed planner/worker -m target and absolute interpreter;
- -B, existing framing inputs and current safe process options;
- exact allowed env keys and valid actual values;
- actual parent DB/state coordinate absent from env names/values, argv and resolved
  cwd; preserve the separately required stdin/FD probe, do not equate safe flags
  with an actual descriptor census;
- no writer/session/lock authority in child channels;
- original close-before-child, total-role/attempt and C1-order assertions intact;
- child input snapshots cannot be retroactively changed by a mutated mapping.

### Reproduce real E01 independently

Construct the smallest equivalent external TWO-MODULE regression carrying this
run's actual database path from offline runner into supervisor and BOTH real
child environments. Keep production in the live checkout unchanged. Preserve
valid command/fences, frames, workspace, child completion and readiness; do not
substitute a standalone supervisor with an unrelated string sentinel.

V9 reports these external identities (attribution only):

```text
supervisor: 91d079a60faac4f80a7c774ef992a08f97e669de7c25689d4f5f5eec4ad78f73
runner:     e4b0d5f387941e58e8f377f3bc5bfb9ce3f569d69db986f8c60d40c658b21900
```

Keep final tests unchanged. Parse/import both modules normally and preserve
selected test collection. Require:

```text
tests/test_rw0_d1_offline_integration.py::test_full_d1_through_guarded_writers_and_parent_capsule
    FAILS on actual invocation child inputs

tests/test_rw0_d1_process_supervisor.py::test_child_observes_sanitized_argv_env_cwd_and_no_parent_fd
    may PASS its separate direct invocation; not credit for runner isolation
```

The reported rejection is d1_child_parent_state_exposed. Re-resolve exact current
behavior rather than enforcing a guessed diagnostic. Independently call through
Popen and confirm both real children actually received the bad value before the
permanent assertion failed; the altered run can still be ready. If the observer
prevented launch or fixed the environment, the test has not discriminated the
required effect. All created children/roots must be cleaned on test failure.

Also use a bounded test-local allowed-key-value substitution to confirm the
check is not unknown-key-only. Label that as detector coverage unless a real
child received that changed value. Normal and legitimate recovered exact-commit
runs must retain their original successful launch/capsule behavior. No arbitrary
path-spelling/reflection/sandbox extension is required.

## 5. S01 — internally valid planner failure cannot support a later prefix

Inspect the handback's actual later-prefix planner clean_success predicate and
new owning test, reported around handback :185 and test :528. Process-record
validation and prior/later-stage compatibility are distinct requirements.

Build one otherwise valid worker_start handback using current exact values:
proper program/author/selection/C1 lineage, exact failed worker launch, allowed
cleanup, no later Wire/capture/manifest. Replace ONLY the earlier planner with an
INTERNALLY VALID unsuccessful process record. Independently call its existing
pure validator and prove it succeeds before handing it to the consumer.

The current handback must reject specifically the clean-planner prerequisite,
not invalid IDs/types/exit fields, missing predecessors, a wrong worker_start
observation, or a malformed capture. Use one supported broad stopped form, a
cleanup form and ready at their valid prefixes to confirm this is not solely a
ready-status check. Avoid unrelated predicate masking; fixed expectations come
from actual owner/call sites, not the production matrix's own accepted output.

Required positives:

- the same failure kind in its legitimate earlier planner_exit prefix is valid;
- worker_start with genuinely clean earlier planner remains valid;
- real normal/recovered runs retain their valid later-stage handbacks.

Delete ONLY the later-prefix planner requirement in one external handback copy,
leaving process constructor/consumer validation and every other rule unchanged.
The reported V9 copy was
`a1c0c7fe862bc7ab24deef53b2c7260aed3af4a17bdae7d695f88aa0291b91c1`.
The final permanent test must fail semantically because the invalid later history
is admitted (reported DID NOT RAISE). Normal module tests/positive controls pass.
No renamed reason, new stage ledger, new field or blanket ban on negative
process outcomes is required. The event/handback grammar validates consistency;
it does not authenticate that historical execution occurred.

## 6. H01 — outside hard link isolates the link-count invariant

Inspect both actual link-count checks and the complete workspace consumer. The
reported source pointers are workspace :181/:200 and test_workspace_capsule :61.
Use an owned one-filesystem layout with exactly three authorized regular files
inside workspace and an external_alias sibling outside it. Make the normal one
content edit. Link an UNCHANGED authorized file to that owned sibling location.

Before calling the real owner, independently observe all of these:

- workspace-relative file set is exactly the three accepted paths;
- accepted type/modes, bounded bytes, exactly one valid edit;
- no extra path, symlink, rename, deletion, invalid mode or malformed record to
  reject first;
- outside alias shares device/inode with the linked workspace file;
- its st_nlink > 1 at the actual validation boundary (not detached by replacement).

Invoke the current workspace consumer and require its actual link/unsafe refusal.
The identical workspace WITHOUT the alias must pass capture AND existing capsule
verification. Do not accept any exception as evidence or credit a test that only
checks nlink without invoking the owner. Link no live repo, database/cache,
credential or another invocation's resource. Guaranteed finally cleanup removes
only this alias and owned workspace, including when a mutant wrongly accepts.

In an external module omit BOTH link-count checks but preserve every other
path/type/mode/content check. Reported V9 copy:
`979f285cd464f51c8b0fb1ddd638cc28fec9affe17333e1288cbbc247435bbda`.
The new permanent specimen must fail on lost owner rejection. The older in-
workspace hardlink/extra-path specimen may still pass and is not substitute
credit. This proves the combined invariant, not each redundant check separately
when another would reject first. No race campaign or expanded filesystem threat
model is authorized; unsupported real hard-link execution remains a limit.

## 7. G01 — literal initialization must be the only protected-table binding

Read both changed checkers and their named owning callers completely:

- tests/test_rw0_b2_capability_boundaries.py (reported new rule :150);
- tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py (:777).

Observed document hashing remains legitimate. Expected identity derivation from
those same current bytes is forbidden even when results equal approved literals.
Preserve all existing literal identities, row IDs/order, names, paths, classes,
purposes, old/replacement identities, markers and helper/caller ordering. No
AGENTS/README rehash or whole-test-file identity replacement was selected.

Fixed protected document identities remain:

```text
AGENTS.md: 62,778 bytes
076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6
README.md: 46,898 bytes
dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff
```

Independently verify both checkers require one approved structurally literal
PROTECTED_CONTENT_ROWS definition and reject the stated subsequent direct,
annotated, augmented, conditional and loop rebinding forms. They must inspect
the relevant whole source rather than selecting the first matching assignment
and ignoring later execution. Ordinary read-only iteration, observed-file hashes,
comments and harmless string examples remain legal.

The bootstrap checker must retain its own fixed expectations and enforce the
source rule itself. It cannot call the primary helper as its oracle or derive
expected rows from the primary runtime table. Inspect narrow AST restrictions
for both under-detection and false rejection of the selected positive source.
This is a finite named-binding rule, not a general alias/exec/reflection solver.

Recreate an external Capability test module that retains the literal table and
adds a SECOND assignment deriving P11/P12 sizes and hashes from that copy's
unchanged AGENTS/README bytes. Keep all other fields. Both complete module
parse/import and selected collections must succeed; the actual table values
must still equal the approved ones. The primary owning test and independent
bootstrap source test must each fail on duplicate/dynamic binding, not a byte
mismatch elsewhere or a global file-count check.

Reported V9 copy:
`dcb7f6d7b42ec310e99797dfc3810513c8ba7289d7e2b2ddd161e4ecde10f9df`.

Separately omit the NEW uniqueness/rebinding predicate in each checker while
keeping that checker's fixed negative and harmless positive source specimens
unchanged. Each negative must fail and each positive must pass. A rejection in
the other module is not credit for the removed predicate. Reported regression
copy identities, attribution only:

```text
primary:     295ff1c29374e0ba4949a02c474d48ae654f50d553793c73d46388ccd2925afb
independent: d52398c6279e429f117bc04c0c2431f117e27601de9542bd187bf68ef170f362
```

Do not require immunity to coordinated rewriting of both checkers and every
fixed specimen. Independent review and authenticated final byte identity remain
that boundary. Current production does not dynamically derive these identities.

## 8. Complete the explicitly omitted standalone reap/group-cleanup negative copy

Do this EARLY, after E/S/H/G and before the final suite. The preceding independent
audit did not run this named material safeguard. R08 (group-clear observation
after cleanup failure), successful normal cleanup and test emergency cleanup do
NOT automatically discharge it.

Read actual supervisor termination, wait/reap, stream finalization and group-clear
paths and permanent process/integration tests. Select the smallest EXISTING
fixed-child deadline/cancellation/nontermination scenario where omission of the
owned reap/group-cleanup work has an observable consequence. Use the selected
POSIX proof behavior only; do not create a general orphan supervisor or new
production mechanism. State before execution the omitted actions, discriminating
permanent node and expected lifecycle difference.

In a separate external copy, make a narrow, reviewable regression that skips
process reap/group cleanup while otherwise retaining enough normal control flow
for the selected real-child path to run and the permanent test to collect. Do
not credit only a syntax/import error, a source-count guard, an invalid synthetic
process record rejected before the child exists, or an unrelated frame failure.
Observe the actual child/process-group lifecycle and which real cleanup calls
were omitted. No fixed test assertion or fake event may be inserted as the
mutation itself.

Run the unchanged claimed permanent safeguard on that copy. If it survives while
the selected cleanup obligation is actually lost, report a material causal gap,
not acceptance based on an audit-only detector. If another active producer path
really performs the same required cleanup, document it; the copy is not a
lost-safeguard specimen merely because one call vanished. Refine only within the
same named finite omission, rather than adding a new defect class.

Use real direct-child handles/group IDs under a bounded external driver deadline.
In finally, emergency cleanup must terminate/reap only positively identified
owned children and clear their groups before removing their roots. Distinguish
runtime cleanup from audit rescue, and never count rescue as candidate behavior.
No kill-by-name, arbitrary /tmp sweep or open-ended survivor search. Tests with
real leaked state must still be safe to finish; unsupported execution or inability
to create a discriminating bounded specimen remains an explicit incomplete gate.

An unmodified positive run of the same permanent test must pass. Record complete
external module hashes, exact change, normal parse/import/collection, selected
node and semantic outcome. One discriminating specimen can cover other named
cleanup rows with an explicit explanation; do not create a redundant campaign.
No live test or production change is allowed if a survivor is found.

## 9. Reconfirm affected prior safeguards; no expansion or reset of prior evidence

The earlier independent auditor already observed a 58-row used-family readback,
full replay/response-loss/stop behavior, all 29 tracked diffs and all twelve V8
normal groups. Preserve those as PRIOR independent observations, not 'never
performed' and not current V9 test execution. They do not grant acceptance while
E/S/H/G or the standalone cleanup gate is unresolved.

Use the same independent auditor conversation where possible. Authenticate the
unchanged runtime/docs against the fixed table, read the five amended tests in
full, inspect their dependency compositions, and record which past independently
performed checks remain applicable. If a named obligation cannot be established
from actually retained evidence plus current corroboration, perform the bounded
check now or report it unproved. No prior implementation report is a substitute
for an independent obligation. New/direct/permanent/transformed/static and
carried-forward evidence must be separately labeled in the final ledger.

### Launch effects and effective C1 resolution (L01-L03)

Preserve the observer's observational nature while adding E01 input assertions.
Reconfirm normal planner->worker and recovered exact-commit success; zero children
on program/author unresolved; one planner/zero worker attempts or PIDs on selection/
C1 unresolved. Count every actual Popen attempt through the whole invocation, not
handback entries. Role is actual -m target, not a user flag or list position.

Distinguish physical commit, caller-visible success and effective committed_exact
recovery. A fault wrapper's internal success later replaced by unresolved is not
permission. Observe relevant writer/recovery-session close after its real return
and before each child. Preserve valid recovery->replay->close->worker.

With FINAL tests unchanged, independently reproduce equivalent external copies:

| ID | Regression | Required signal |
|---|---|---|
| L01 | Extra unreported pre-C1 worker, normal worker retained | Both named normal/unresolved tests fail on complete attempt/role history |
| L02 | Sole worker before C1, two-child count and real writer close retained | Count passes; normal test fails specifically on effective-C1-before-worker |
| L03 | Worker after physical C1 commit/response loss, before unresolved recovery | Unresolved test fails on a real forbidden launch |

Keep valid env/path inputs so E01 cannot mask the intended count/order failure.
All copies parse/import/collect; the observer may not prevent the launch. Preserve
handles for even discarded workers and separately account for emergency cleanup.
This is fixed Python-call-site observation, not arbitrary native-spawn coverage.

### Runner-owned capsule verification (V01-V03)

Locate both current permanent V7 tests by name/content, not obsolete line numbers.
Observe real capture -> build -> original verifier entry/completion -> first
ready construction -> return, with this run's exact arguments and original
None-success/D1CapsuleError failure convention. The negative structurally valid
capture must reach real relation rejection, not an earlier shape error. Require
stopped/capsule_mismatch, allowed capture/durable evidence, no ready manifest,
proper child/workspace cleanup and explicit idempotent parent close.

With final tests unchanged, reproduce call deletion, neutral return None verifier,
and ignored authentic verifier refusal. Each intended permanent test must fail
semantically. Save originals from EACH copy, not pre-mutation cached callables.
Post-return test-side verification cannot supply the runner's missing event.
These copies cover the existing verification-bypass safeguard once, not a new
quota. Parent construction, independent reconstruction and content identity remain
separate checks.

### Process, handback, capture, custody and frames

Inspect/confirm the complete current process-value producer table and pure
validator. Both optional process fields must be revalidated at consumption before
stage checks. Valid failed starts, nonzero/signal-negative outcomes, deadlines,
cancellation, and known exit zero with unproved cleanup must remain representable
as negative evidence; none supports ordinary clean success. PID/group/exits have
exact built-in types; the owned initial group relation has its current meaning.
A stale usable Wire label cannot rescue a bad worker, nor a zero exit rescue an
unusable Wire result. Observe actual runner-to-classifier return-code input.

The sixteen-field handback and thirteen evidence-prefix ordering remain closed.
Re-derive relevant reason predicates from actual producer sites, particularly
broad durable_conflict/cleanup prefixes, worker_start, c1_phase_failure's current
nonproducer status and S01's planner prerequisite. No stage ledger, fabricated
empty handback, generic-error relabeling or loss of observed cleanup evidence.

Deep capture validation remains the workspace owner's pure, complete check:
three exact entries at fixed paths, exact 100644 modes, bounded immutable byte
leaves, one correctly identified changed path. Constructors AND consumers
(handback, blobs, capsule builder and verifier) must reject forged exact wrappers
containing live run/object/state Path values. Preserve relative path data and
opaque file bytes; do not introduce path-looking-content scanning. Actual-return
injection cleanup must affect only the failing invocation's own roots.

Creator-PID fencing must precede every custody exposure or close mutation. A real
forked child must be refused without deleting/exposing parent state; parent close
and second close remain correct. No writer remains open after D1 return and no
resource path/session/proof enters the typed handback or repr. The separate
parent-only run owner manages lifetime, not program truth or acceptance.

Retain real selector/stream-close failures after planner/worker PID creation,
cleanup+deadline/cancel composition, preserved process facts and group-clear
attempt, no readiness on unproved cleanup. Canonical wrong enum types (including
action: []) produce D1FrameError and the appropriate stage stop, not raw TypeError
or invented durable conflict. Existing frame length, duplicate/unknown fields,
magic, truncation, extra/trailing bytes and ceilings remain enforced.

### Current durable authority, actual resources and D1 boundary

An independent current invocation must call through actual guarded program,
author-effect, Section 41 and C1 writers/recovery, close authority before children,
and return the exact current-owner evidence. No direct SQL shortcut, planner-
authored IDs, harness-selected Boolean, duplicate author delivery or shadow
in-memory program lifecycle.

Corroborate the used families with existing read-only readers/authoritative
canonical functions: 9 program rows/8 graph entries, 10 author rows/9 graph
entries, 22 selection rows/14 evidence bindings and 17 C1 rows/14 operands were
reported independently matched (58 physical rows total). Bind current commands,
refs, digests, receipts, members, heads and unchanged replay times; do not infer
full family exactness from row presence. An earlier completed exact readback is
prior evidence; any new readback or recovery is labeled fresh. No new digest or
schema, and no audit of all unused tables or future C2 persistence.

Retain positive current-owner committed response-loss recovery at four sites,
unresolved stops at the actual lower launch boundary, and replay with no added
family/time. A physically committed but unresolved operation never permits work.

Reconfirm fixed launch options/allowlisted channels, actual stdin and inherited-FD
probe with only artificial parent sentinels. Popen flags alone are not a child FD
census. Parent-only DB/writer authority never crosses child argv/env/cwd/stdin/
descriptors. Check bounded start/frame/nonzero/limit/deadline/cancel/TERM-KILL/
reap/group-clear and no owned survivors, within supported POSIX proof.

Workspace checks retain exact paths/base/modes, one edit, bounds and rejection of
traversal, links, special types, additions/deletions/renames and multiple changes.
H01 is the combined outside-hardlink discriminator. Parent derives the manifest,
verifier independently reconstructs with original bytes and canonical relation.
The base Git OID is a supplied fixture coordinate, not authenticated Git truth.
Workspace is removed before ready; D2 data and disposable SQLite lifetime remain
under the explicit parent-only owner until close, with no open writer.

### Governance and consumer boundaries

Verify all 29 tracked changes remain within the accepted documentation/status
and owning-test treatment: 13 guidance/docs and 16 tests. The two amended tracked
tests need full new inspection; prior unchanged diff observations are not erased.
All pure/current durable source and package exports/pyproject/migrations remain
HEAD-exact. Exactly nine D1 modules, two private executable children, one
subprocess owner; no D2/E/terminal/provider or physical C2 runtime.

B1 registry version 3 keeps construction in D1 pre-execution and evidence-only
RW0PhaseEntryBasisV1 in handback, with C1 durable ownership. Primary and phase-
entry registry projections stay independently fixed. Repeat affected one-sided
role/version/import checks without new permissions. Direct/aliased/nested loader
acquisition (__import__/importlib), unauthorized consumers/symbols, wildcard/module
aliases and re-exports must be rejected under each owning helper's finite rule;
harmless string/comment positives remain legal. No universal reflection demand.

Wire handback imports remain ONLY its two exact existing evidence classes. The
Wire helper enforces its own finite export/dynamic-import/form/consumer checks,
not B1 rejection used as its oracle. It grants no codec/classifier execution or
permission to handback. Capability remains pure and five status projections stay
normalized. Protected table identities and independent markers remain fixed;
G01 prohibits the second binding without banning observed-file hashing.

The C2 whole-source historical manifest remains explicitly superseded by scoped
nonimplementation checks. Those still reject prohibited C2 module/call/export,
acceptance/terminal/runtime activation and migration 0005, without reviving a
blanket ban on authorized D1 source.

## 10. Finite material obligation register and evidence reuse

This register carries the existing finite scope; it does not commission a new
mutation framework. Independently fix expectations outside transformed subjects.
Each credited copy must parse/import and collect normally, with an intended
semantic failure. No unrelated inventory failure, invalid upstream fixture,
false assertion or collection shrinkage is evidence for the target predicate.
Use the smallest discriminating selection, never a full-suite run per mutant.

For a completed PRIOR independent obligation: identify its exact experiment/test,
unchanged supplying endpoints and any affected dependencies. Corroborate that
basis on V9 and label it prior, not fresh. Do not redo identical copies merely to
increase a quota. Current E/S/H/G, L/V compositions and the omitted standalone
cleanup copy must be independently closed in this interval. Any other obligation
without a supportable prior/current basis must be completed now or remain an
explicit acceptance blocker. Overlapping specimens may discharge multiple named
rows only when they actually discriminate, with that mapping recorded.

| ID | Existing negative-copy obligation / required boundary |
|---|---|
| E01 | Real runner->supervisor->child DB path leak: actual-run input assertion, not separate direct fixture |
| S01 | Individually valid unsuccessful planner under later-prefix handback: planner clean-success requirement |
| H01 | Real outside hard link with valid workspace: combined nlink invariant |
| G01 | Second dynamic protected-table binding with equal runtime values: both independent owning checks |
| P01 | Omit process constructor validation: direct inconsistent record |
| P02 | Consumer checks only outer process type: forged exact invalid record |
| P03 | Omit zero-exit/exact-int/positive-ID/owned-group primitive: corresponding fixed specimen |
| P04 | Validate only worker/ready or omit later-prefix success: planner/stopped/cleanup consumer; S01 covers its specific missing later-planner clause |
| P05 | Stale usable Wire rescue or synthetic-zero classifier input: actual values/call-through |
| P06 | Contradictory record erased/relabelled or rejection cleanup omitted: actual return/root ownership |
| N01 | Capture constructor validation omitted: malformed nested exact value |
| N02 | Only outer capture checked: nested live resource at consumer and actual returned graph |
| N03 | Old broad stopped rule: early reason with later facts |
| N04 | Failed worker-start evidence erased/relabelled: real failed launch |
| N05/N06 | Admitted Wire value export/dynamic loading: Wire helper's own finite negative |
| R01/R02 | Arbitrary extra handback slot or missing ready evidence: fixed inventory and status invariants |
| R03 | Actual state root in handback: closed nested-resource check (N02 may cover) |
| R04 | Creator-PID fence removed: real fork custody |
| R05/R06/R07 | Selector close escapes / process evidence erased / cleanup becomes durable conflict |
| R08 | Group-clear observation skipped after cleanup failure: actual cleanup trace |
| R09/R10 | Type-after-membership / frame-error-to-durable-conflict: direct and integrated error boundaries |
| W01-W03 | Remove Wire positive allowance / widen forms or symbols / widen consumers |
| B01-B03 | Remove B1 positive allowance / widen forms or symbols / widen consumers, including finite alias acquisition and independent projections |
| L01-L03 | Extra early worker / sole early worker / worker between physical commit and unresolved result |
| V01-V03 | Runner verifier omitted / verifier neutralized / authentic refusal ignored |
| O01 | Actual program writer or Section 41 selection replaced by fixture/harness values |
| O02 | Worker before C1 or after unresolved durable recovery (L01-L03 cover named cases) |
| O03 | Parent DB path/inheritable FD crosses child boundary (E01 covers env, not every FD claim) |
| O04 | Standalone skip process reap/group cleanup -- explicitly missing before this audit; section 8 mandatory |
| O05 | Worker-authored manifest or bypassed independent verification (V controls cover bypass, not all content/worker-authority claims) |
| O06 | Extra/link workspace mutation (H01 covers outside hardlink; preserve extra-path discriminator) |
| O07 | Second subprocess owner or additional D1/D2 module |
| O08 | Prohibited C2 module/call/export after source-manifest supersession |
| O09 | Dynamically derived AGENTS/README expected identities (G01 covers the named table-rebinding form) |

Do not claim all surviving copies were previously run through the complete suite;
only the identified selections were reported. Historical mutant hashes and PIDs
are attribution, not available payloads. Report your own equivalent copies' full
identities/deltas, fixed selected nodes and actual signals. If any new material
survivor appears, report its real severity and bounded effect: a permanent-test
gap is not automatically a current production vulnerability.

## 11. Exact independent final validation

Only after focused causal gates succeed, create one fresh NORMAL remote-free
clone of exact HEAD plus all 46 authenticated final payloads. No mutable test
copy or prior superseded clone supplies final credit. Verify 263 endpoints before
and after testing; exclude live cache, preserve unrelated 0600 modes.

Use installed Python 3.13/pytest, normal test-process umask 022, owned TMPDIR,
PYTHONDONTWRITEBYTECODE=1 and PYTHONPATH=.:src, no xdist, overlap, network,
warning suppression, skip/xfail, removed test or selector change. For EVERY group,
collect then execute serially with different precreated basetemp parents:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<owned-root> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<precreated-external-group-path> [--collect-only] <exact-paths>
```

Each token becomes tests/test_<token>.py. Sort/deduplicate within a group only.
Group 12 has NO path arguments and includes all 124 current modules.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Inventory stream, for each sorted repository-relative test-module path:

```text
u32be(path_utf8_length) + path_utf8 + raw SHA-256(file_bytes)
```

Fixed final candidate coordinates from the V9 closeout (report references to
REPRODUCE, not inherited independent passes):

| Group | Files | Reported collected / passed | Fixed test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 115 / 115 | `0c70dea0b7595604dbf971c7013d09ede34d1cef3d1947cce815b918d60be4db` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 70 / 70 | `21280c9b75f1f81aadad5c1f7bffefe3d0b08b69ded16ba22c4d8005e8b58758` |
| 9 bootstrap guard | 1 | 297 / 297 | `be2891c09719962ad4675a16d69cf5d1b8f56eb21222dad99f17503dac861acc` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 9,005 / 9,005 | `7a38fcc5abe95d0ee818ea73649b75a9cabcb3298aab6c62974e14d224bb12fd` |

Only Groups 1/8/9/12 file inventories changed from V8. Count bookkeeping:

```text
8,984 + (115 - 112) + (70 - 60) + (297 - 289) = 9,005
only reported overlaps: G2/G3 = 46; G7/G11 = 31
reported G1-G11 unique union = 3,678; all must belong to G12
```

Reconcile actual complete node IDs, including parameter values containing spaces.
Never split node IDs on whitespace, infer subset membership from a count, or add
group passes as unique coverage. A matching inventory is not collection/execution.
If count or hash differs, investigate exact bytes/selection/environment; do not
change the fixed expectation to make it pass.

The closeout says an earlier 9,005-test final run passed and then a last edit
caused another fresh clone/run. Only the final-byte table above is the operative
implementation result; neither run is this audit's independent final execution.
Report any observed trial/interruption/correction in this interval honestly.

Groups 10/12 have the same three known Python 3.13 multithreaded-fork
DeprecationWarning records at:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warnings, not test-name substring guesses. Repetition across
overlapping groups is not a new class. Investigate new warnings/failures or
unsupported mandatory POSIX execution; no suppressions or assumed pass.

Also perform guarded live diff --check; all 17 created-file no-index whitespace
checks (ordinary difference status 1 without whitespace diagnostic is not itself
a failure); strict encoding/newline/path/type/mode checks; all 46 endpoints and
217 HEAD-exact noncandidate checks; package/export/script/StateStore/schema/current
owner/migrations preservation; absence of 0005; exactly nine D1 modules/two fake
entries/one subprocess owner; unchanged documents and protected identities.

Correct only positively identified external audit-runner errors outside live
checkout, and rerun affected gates on the same exact final bytes. No live repair,
late edit, silent restart, reused mutant or interrupted run provides final credit.

## 12. Cleanup, preservation, stop rules and supported verdict

Maintain the opening helper and record throughout this one interval. Record all
owned PIDs/groups/returned runs/workspaces/state roots, including deliberately
leaked mutant resources. Reap/observe termination before removing owned roots.
Use lstat, hash/open regular files only; never follow test symlinks or open FIFO,
socket/device entries. Remove only positively owned resources; no kill-by-name,
broad temp sweep, deletion of an injected original run, or finalizer reliance.
Report emergency audit cleanup separately from candidate runtime cleanup.

After executable work and its main cleanup, reproduce live HEAD/tree/parent/
branch/upstream-local/worktree/index facts, 46 endpoint receipts and the same
replacement digest, all 217 HEAD-exact paths, and complete index content AND
opening metadata, cache DIRECTORY and all 37 member contents/metadata including
nanosecond mtimes. Use the SAME true-opening helper; retain it until closing
comparisons finish, then remove its known files/root. The helper and observation
are temporary audit evidence, never product truth.

Earlier missed pre-Git records stay historical limitations. This correct opening
proves only this attempt's interval; do not restore timestamps/index to imitate
an earlier state or assert an unobserved status command was inert.

A reproduced in-scope High/Medium defect, the required Low protected/consumer
causality survivor, omitted mandatory opening, unstable provenance or unproved
cleanup bars acceptance. Early BLOCK may stop expensive remaining gates with
precise completed/interrupted/unperformed entries. No test-only or production
repair is permitted in this audit. Do not convert unsupported evidence into a
user choice or broaden into D2/C2 to finish.

Use exactly one final token:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED
AUDIT_PROVENANCE_MISMATCH
```

ACCEPT requires the exact authenticated V9 subject and preservation; independent
E01/S01/H01/G01 closure without masking or circular checkers; the mandatory
standalone reap/group-cleanup negative copy; retained effective launch, capsule,
process/capture/handback/custody/frame/consumer/durable-authority safeguards with
explicit prior/current evidence mapping and no missing material obligation;
current affected compositions and scoped governance consistency; all twelve
final groups independently collected/passed; no remaining material defect,
required Low guard gap or procedural/evidence limit.

ACCEPT is eligibility for a SEPARATELY issued commit/publication gate for these
exact 46 files. It grants no staging, commit, push, PR, merge, D2, physical C2,
migration 0005, acceptance fact, terminal outcome, supplier/source qualification,
live credentials/provider, enrollment/deployment, ES/Bridge or RW0-E authority.
Normal D1 remains the private artificial proof; handback is evidence, not a
production acceptance or second program truth.

Return inline:

1. Verdict/settings, scope, exact first-action/opening and fixed baseline.
2. Complete 46-endpoint/aggregate reproduction; five-test delta evidence and
   historical limits; 41 unchanged candidate/217 unchanged baseline paths.
3. E01 actual-run input observer, real two-module leak discrimination, independent
   expectations, direct-fixture limit, normal/recovered success and cleanup.
4. S01 valid process/invalid prefix isolation and genuine negative positives.
5. H01 real outside alias, exact other premises, original refusal/deletion failure
   and valid no-alias counterpart; no redundant-predicate overclaim.
6. G01 both independent binding rules, equal-valued second assignment, finite
   source variants and separate uniqueness-predicate regression controls.
7. Standalone reap/group-cleanup negative copy: chosen actual branch, omitted
   effects, permanent-test result, real lifecycle and any emergency cleanup.
8. Affected L/V compositions; retained process/capture/stage/fork/frame/B1/Wire/
   durable/readback/resource/governance evidence, labeled prior versus fresh.
9. Finite obligation ledger: exact copies/nodes/signals, overlaps, material
   survivors/omissions, and no implementation report promoted to independent work.
10. All twelve commands/memberships/hashes/collections/passes/overlaps/warnings;
    trials/corrections and 263-file final-clone equality.
11. Owned process/root cleanup and true-opening-to-closing index/cache/candidate
    equality; prior procedural limits left historical.
12. Severity-ranked findings or no remaining in-scope material findings, with a
    continuation capsule <=1,000 words naming only the next eligible gate.

Deliver no external report, manifest, patch, bundle, snapshot or architecture
package. Do not issue the next repair, implementation, publication, D2 or C2
prompt. End with exactly one supported verdict token.
