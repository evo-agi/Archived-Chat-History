# Governed Execution Coordinator — RW0-D1 Audit Repair V3: B1 Consumer Coordination and Final Validation

## Mandate

Continue the RETAINED, uncommitted RW0-D1 candidate. Do not recreate D1, roll back
its runtime repairs, or return to either earlier pre-repair recipe.

The last continuation returned:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V2_REPLAN_REQUIRED`

It reports that only the Wire boundary test changed during V2. The four original
runtime repairs and the exact Wire consumer extension remain present. Validation
stopped at B1's closed importer registry: the exactly typed handback directly
imports `RW0PhaseEntryBasisV1`, but the registry and importer guard currently
admit D1 pre-execution, not D1 handback.

This replacement makes ONE bounded implementation decision: admit the handback
as an explicit evidence-only consumer of the existing B1 phase-basis value,
while preserving pre-execution as the D1 phase-basis constructor and C1 as its
durable establishment owner. Coordinate the B1 owner, its guard, and its
independently fixed phase-entry test projection together.

This is continuation of the SAME source-bearing D1 repair. It is not another
semantic-contract tranche, another implementation program, or permission for
D2/C2. The B1 consumer-registry amendment is an implementation dependency of the
required runtime-exact handback; it confers no new execution or durable authority.

The parent is the sole writer. No subagents. Use the highest exposed reasoning
setting; report visible model, effort, and permissions or `not visible`. Do not
seek additional access merely to discover hidden model settings.

Return one operative INLINE closeout plus a continuation capsule no longer than
1,000 words. No delivered report, receipt, architecture package, freeze manifest,
patch, ZIP, or snapshot. Do not issue the next audit, publication, D2, or C2 prompt.

## 1. Exact retained opening state

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed coordinates:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- index equal to HEAD; no staged or unmerged paths
- exactly 29 modified tracked paths and 17 untracked created paths below
- no active Git operation, sequencer, or unexpected lock.

Read `AGENTS.md` first. Use non-mutating Git inspection with optional-lock
suppression where appropriate. Do not fetch, normalize, reset, or discard work.
Local tracking equality is not fresh remote truth.

These are the retained V2 closing receipts, not its opening receipts. `C` means
untracked creation, not a commit or copy status. All candidate files are regular,
nonsymlink, represented by Git mode `100644`. Capture and preserve actual OS
modes; do not normalize pre-existing `0600` nonexecuting files to `0644`.

| Change | Repository-relative path | Bytes | SHA-256 | HEAD blob | Component bytes |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,153 | `d58c9c882a2c9c2a07c652c095f69ad49cced30b6cc170ff17d04daf0f7e6f51` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,221 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,742 | `dff1b17faec4751a19ae59758d594bece5d30b14bc322dfe8529716ef4d89985` | `absent` | 3,818 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 9,698 | `76ef6a902733a0790da927b4881ad4bef6d2555d6b63be12517d347ea4f46802` | `absent` | 9,775 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 22,193 | `29e1dfb51e09941acea43ff907440f171a023d46a2de9bdce002d88f9088bc9f` | `absent` | 22,269 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 9,502 | `5d47b82d8b24f38f4a2c54825405f0370e308159908a104fdd9bc73c1ab970d9` | `absent` | 9,589 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 7,011 | `0ff4afc0c9fd770e8604eac1541e0d34bda3f1beca2eb91a13cd4e4b72007792` | `absent` | 7,089 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 39,069 | `2dbb15ee10d7155c4255ae01f1499ae50acd6e43f666efef633737f9a466f679` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 39,135 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 45,852 | `0c3401cd96f7c7639d17096d20ea5f67dc6f6916a6f8eb6b8b0dc5773dacef9d` | `b61f1744059a87988bff7bde032f3b578a554b18` | 45,929 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 34,490 | `8d600d1044947964b74786f1bfa59326d79541d0ace74d57d4ccd97e82c68cc9` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 34,561 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 116,659 | `839316ee8c45b6ce80a70a30234b47550a194feff2726f9d8f02bb50052494de` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 116,759 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 11,665 | `20470ec086cbad881c6d4687100905d4670b7f14cc53f3966e342585f1e4bda4` | `absent` | 11,736 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 13,881 | `fab122192528cdd0f668bc63181bea2e4a2fc70d3d1f42bd92061ff8532ffa79` | `absent` | 13,956 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 8,476 | `890c0717fcb1f5f9b53919d3c73b10dc54c98d53d1f1473e52a75108831ce9aa` | `absent` | 8,550 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 2,781 | `022ddc43ae703b1a5036cd985459490cc27d872f5cca6b02b9dbef850361d853` | `absent` | 2,854 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 174,623 | `78b47b119f88e1642599e350cd95d217b1a4056621301012dc52ed5c8f6beee5` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 174,711 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

All 217 noncandidate tracked paths must equal HEAD content and Git-relevant mode.
Baseline 246 files plus 17 additions equals 263 candidate repository files. No
new path, deletion, rename, symlink, submodule, or executable-mode change is
permitted. Keep the index equal to HEAD throughout.

### Exact opening replacement identity

Reconstruct twice from fresh reads, without executing candidate code:

```text
prefix: ASCII RW0-D1-BINARY-REPLACE-V1 followed by one NUL byte (25 bytes)
for each table row in UTF-8 path-byte order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20-byte baseline blob OID, or twenty zero bytes for C
    u64be(payload_length)
    exact retained file bytes
```

Required opening:

```text
46 rows: 29 M / 17 C
encoded row bytes: 4,453,875
prefix bytes: 25
total bytes: 4,453,900
SHA-256: 66eea37eb17621aafa1b55e1cda250a1a11477612d0d97041cdef7c6781806b9
```

The 4,450,113-byte and 4,422,240-byte recipes are historical only. Do not use them
as this continuation's required opening identity. Do not reconstruct files from
hashes or request historical attachments; this prompt supplies every operative
receipt and path inventory.

On provenance drift, preserve the actual retained work and stop before editing.
Do not replace expected coordinates or reset the checkout.

## 2. Bounded twelve-path ceiling

### Newly authorized: primary correction, exactly three existing candidate files

```text
.docs/rw0-b1-pure-phase-values.md
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

These are the owner, importer/registry guard, and independently fixed composition
projection. No new file is created. Prefer completing the correction using only
these three files.

### Previous nine paths: retain; change only for a direct remaining repair defect

```text
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
```

Those nine endpoints already contain the reported runtime/Wire repairs. Do not
rewrite them merely to accommodate the old B1 guard. Any further edit must be
necessary to the four original audit findings, the exact evidence-type
consumer boundary, or their direct causal controls, with its justification
reported inline. No new behavior, protocol, runtime owner, or D2 feature.

The other 34 candidate receipts must remain exact. All 217 noncandidate HEAD
entries must remain exact. The overall candidate remains 46 paths, not 49.

Keep specifically unchanged:

- AGENTS.md, README.md, D1 implementation owner, and all other documents;
- the B1 implementation `_rw0_phase_entry_semantic_values.py`;
- Wire implementation `_rw0_wire_protocol_values.py`;
- all other existing pure semantic and durable program/author-effect/Section 41/
  C1/writer/session/transaction/database/recovery source;
- `_rw0_d1_pre_execution.py`, fake children, workspace and capsule modules;
- Capability, bootstrap-guard, scoped-C2, post-execution and other governance
  tests except the three explicitly admitted tests above;
- package root, `pyproject.toml`, `.gitignore`, exports, script inventory;
- schemas/configuration/migrations 0001–0004; no 0005.

No staging, commit, publication, branch change, network, installation, supplier,
credential, enrollment, deployment, D2, C2, terminal, ES, Bridge, or RW0-E action.

## 3. Close the actual dependency set before editing or expensive validation

Inspect the CURRENT retained source and owner/test edges, not only this report:

- `_rw0_d1_handback.py`: all sixteen fields, exact accepted types, every direct
  import, field/type validation, repr and nonserialization boundaries;
- handback creation sites and direct handback/integration tests;
- `_rw0_d1_pre_execution.py`: the current direct B1 import and construction role;
- B1 owner: registry version 2, runtime-consumer row, explanatory consumer prose,
  C1/post-execution compatibility paragraphs, and canonical value contracts;
- `tests/test_rw0_b1_boundaries.py`: complete expected registry/projection,
  parser/integrity controls, actual importer and imported-symbol checks;
- `tests/test_rw0_remote_contact_phase_entry_contract.py`: independently fixed
  B1 registry outcome, composition assertions, equivalence/hostile corpus;
- repaired Wire guard and its preserved consumer/symbol cases;
- `.docs/rw0-b2-wire-protocol.md` and D1 owner for compatibility only;
- known Capability R06/R18/R26 path/mode/purpose rows and protected-content rows;
- known bootstrap and private-value B1 compatibility references.

Perform one bounded static sweep across candidate docs/tests for references to:

- the handback's actual imported modules and symbols;
- the B1 registry marker, version, consumer-row key and values;
- exact importer sets, source/content pins, and independent B1 projections.

Return a small dependency table naming the actual handback field, type, supplying
module, and corresponding closed consumer guard, where one exists. This is
part of this implementation continuation, not another reconnaissance program.

Its purpose is to expose coupled dependencies BEFORE another partial long test
run. Do not react by granting blanket import permission. If a genuinely required
owner/pin is outside the twelve-path ceiling, report the exact path and semantic
conflict and preserve all retained work. No names, aliases, `TYPE_CHECKING`,
re-export, dynamic import, or generic object trick may evade it.

The baseline Capability registry names the B1 document and boundary test by
path/mode/authority-non-effect purpose, not by full content hash. Verify that
remains true in the retained candidate. Their changed bytes do not warrant
another AGENTS/README identity reset. Preserve Capability's value/source hashes
and all current identity-protection behavior.

## 4. Selected B1 consumer amendment

### Exact newly admitted dependency

```text
consumer: src/ge_nwp_coordinator/_rw0_d1_handback.py
field: phase_basis
supplier: src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
symbol: RW0PhaseEntryBasisV1
```

Admit a direct relative, unaliased runtime import of only this existing value
class. It supports exact field validation and retention of already constructed,
C1-established phase evidence. It is not a phase-construction entry or a
qualification relation.

Preserve:

- D1 pre-execution's existing direct `RW0PhaseEntryBasisV1` import and role in
  constructing the basis for the existing guarded C1 command;
- C1 as sole durable phase establishment/verification owner;
- current Capability, C1, post-execution, and all other already admitted B1
  consumers with their exact symbol/form constraints;
- the existing qualified-host private helper's restricted caller;
- all B1 value fields, versions, canonical domains/digests, work budgets,
  privacy rules, no-I/O behavior, and empty public export surface.

Handback may check `type(phase_basis) is RW0PhaseEntryBasisV1`, retain the value,
and read its existing safe fields for invariant checks. It must NOT import
other B1 values/helpers, construct or reconstruct a phase basis, invoke source/
qualification/authorization relations, establish a phase, or infer dispatch
permission or acceptance from the value.

Do not use a re-export through `_rw0_d1_pre_execution.py` to hide the direct
consumer. Do not revert exact field validation to `object`, annotations alone,
class-name strings, duck typing, or a generic mapping.

### Owner registry: one bounded successor

Advance ONLY the B1 current-consumer registry from version 2 to version 3. This
is not a new B1 value schema or protocol version.

Preserve the existing pure-consumer row and all unrelated registry facts.
Replace the singular D1 runtime-consumer row with these explicit two roles:

```text
| current_bounded_runtime_phase_construction_consumer | RW0-D1-pre-execution | authority | this_document |
| current_bounded_runtime_phase_evidence_consumer | RW0-D1-handback | authority | this_document |
```

Keep the registry's existing ordering convention; insert the evidence role
immediately after the construction role. Explain in the existing consumer prose
that both are bounded D1 production value consumers, but only pre-execution
constructs the basis; handback validates/retains exact already established
evidence. Do not misdescribe handback as another phase writer or make the older
Capability claim cover every unrelated B1 value consumer.

Retain exactly:

```text
source_authentication = none
executable_permission = none
durable_persistence = none
semantic_acceptance = none
```

Preserve retrieval budgets, historical compatibility, the B1 legacy latch-pair
nonproof rule, and all other future/live authority boundaries. No broad prose
rewrite and no new registry framework.

### Two independent fixed projections

Update the version, exact ordered row inventory, fixed expected projection,
consumer assertions and affected version/row hostile specimens in BOTH:

```text
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

Use literal expected roles/paths/symbols authored independently of the observed
source/document. Do not derive expected registry content from the document
under test or copy the primary parser's returned result as the independent
oracle. Preserve existing equivalent-parser and negative-language coverage;
mechanically update only expectations made stale by the authorized version and
row change. No expansion of the accepted Markdown or natural-language grammar.

Do not change `.docs/rw0-remote-worker-contact-phase-entry.md`: its existing B1
component/classification/projection remains true. Only its test's independent
B1 projection is being advanced. If a direct contradiction exists in the
actual retained owner outside this scope, report it rather than guessing.

## 5. Closed importer guard and causal controls

Extend the existing finite B1 importer/symbol guard to admit exactly the new
handback edge. Existing consumer permissions remain byte-for-byte or
semantically exact in their fixed inventory; explain mechanical refactoring.

For handback require an explicit direct relative unaliased import of
`RW0PhaseEntryBasisV1`, nothing else. Inspect nested imports with the same
bounded AST path. Reject wildcard, whole-module alias, aliasing, re-export,
`importlib`/`__import__`, and `TYPE_CHECKING`-only substitution for the required
runtime type. Do not build a generic import resolver.

Keep a positive case for the actual source and one real D1 invocation:

- exact handback phase_basis type;
- basis identity/fields match the value from current C1 establishment;
- no construction or C1 write occurs merely from forming the handback;
- the actual two Wire result fields still pass their repaired guard.

Permanent negative specimens must use the SAME guard path and reject:

1. an otherwise unapproved production module importing this same B1 class;
2. an additional B1 value or helper in handback, including a nested import;
3. wildcard/module alias or aliased symbol in handback;
4. removing the symbol restriction on pre-execution or another existing consumer;
5. restoring a singular registry consumer claim, omitting handback's role,
   changing its role to construction/authority, or one-sided version/row drift.

Retain existing importer paths and privacy/no-I/O/package guards. A new allowed
module prefix, dynamic observed importer set, or unconditional assertion is not
a valid fix.

Three bounded transformed-copy controls for this coordination:

- remove the newly admitted handback edge;
- widen its symbols/import forms to accept a forbidden helper;
- broaden the importer set to allow an otherwise unapproved D1 module.

Each must parse/import/collect normally and fail at the intended fixed semantic
control. Registry drift is additionally covered by direct independent primary
and composition-projection specimens. Do not multiply this into a generic
mutation campaign.

## 6. Preserve the retained runtime and Wire repairs

These are implementation-reported and not yet independently accepted. Do not
weaken them to clear an import restriction.

### Handback

Preserve all sixteen fields, exact types/immutable shapes, repr limits, and
status/reason/evidence checks. `capsule_ready` requires real planner/worker
process evidence, Wire results, candidate/capsule evidence, committed durable
lineage and completed cleanup. `stopped` and `cleanup_unresolved` remain distinct;
cleanup uncertainty retains observed process evidence. No raw Path, state root,
workspace path, session/connection/descriptor, lock/proof/lease/capability, run
owner, arbitrary `object`, or mutable metadata slot.

### Parent-only run ownership

Creator-process checks precede custody access, closed-flag mutation, and deletion.
A real forked child must fail without removing state or altering parent custody;
parent close succeeds and the second close is idempotent. No finalizer-based
cleanup, inherited authority, or hostile same-UID sandbox claim.

### Process cleanup and frame errors

Selector/stream cleanup failure retains PID/group/I/O/cancel/deadline/signal/
exit/reap evidence, attempts group-clear observation, and yields typed
`cleanup_unresolved`, not erased evidence or `durable_conflict`. Malformed frame
field types, including canonical `action: []`, yield `D1FrameError` and the
stage-specific planner-frame failure before Section 41.

### Durable call chain and source boundaries

Retain actual current program initialization -> author effect -> separate
planner -> current Section 41 selection -> current C1 phase -> separate worker
-> candidate/capsule handback. Exact recovery precedes advancement; unresolved
means no next child. Writers/locks close before each child. No shadow lifecycle,
direct SQL shortcut, worker-authored capsule, second delivery, or D2/C2 action.

### Repaired Wire guard

Retain the handback's exact two permitted Wire imports and every existing
consumer/symbol/import-form restriction. Keep its six added negative controls;
no edits are expected in Wire source or the already passing Wire test unless a
direct outstanding defect is found within the authorized ceiling.

Reconfirm from FINAL bytes the ten original repair mutations and the three Wire
guard mutations, keeping expected test specimens unchanged:

- arbitrary handback object slot;
- ready without required evidence;
- actual live state path insertion;
- removed creator-PID fence;
- escaping selector close;
- erased process evidence;
- cleanup mapped to durable conflict;
- omitted group-clear after selector failure;
- membership-before-type frame decoding;
- frame error mapped to durable conflict;
- missing Wire handback allowance;
- widened Wire symbols/form;
- widened Wire importer set.

A mutating specimen in an external copy is a negative control, not permission
to change the live implementation beyond this ceiling. Credit no syntax/import/
collection failure. These mutable files cannot authenticate arbitrary coordinated
changes to themselves; fresh independent re-audit owns the final acceptance.

## 7. Execution order — finish the dependency correction before the full run

1. Verify retained receipts, baseline, index, and complete opening cache metadata.
2. Finish the bounded static handback/import/registry dependency sweep.
3. Amend the B1 owner plus BOTH independently fixed test projections together.
4. In a remote-free development clone, run focused B1, phase-entry, Wire,
   Capability, bootstrap, post-execution, runtime, and handback guards first.
   This detects importer, projection, and protected-content dependencies early.
   Do not claim final validation from that diagnostic selection.
5. Run the direct B1 evidence-use specimen and the finite negative controls.
6. Reconfirm the four runtime fixes and existing Wire controls from final bytes;
   make only necessary, justified corrections within the ceiling.
7. After the LAST edit, create one fresh final clone and run all twelve exact
   groups serially, including those that already passed in V2.
8. Compute final endpoint and aggregate identities; preserve retained work and
   request re-audit only after the complete final validation and cleanup.

Do not begin another broad map, architecture package, or separate contract pass.
Do not consume a full-suite run merely to discover known version/projection
references that static inspection and focused guards can resolve first.

## 8. Exact final validation environment and groups

No live-checkout module execution, import, pytest, scripts, compilation, or
SQLite connection. All executable work uses task-owned external local-only
clones of exact HEAD with the verified candidate overlaid and remotes removed.
No dependencies installed and no remote/provider traffic.

BEFORE any executable work, capture the known live cache DIRECTORY and all 37
regular members with lstat: relative path, type, actual OS mode, size,
`st_mtime_ns`, and SHA-256 for regular files. Do not hash directories or record
mere presence as a substitute for their mode/mtime. Do not inspect unrelated
ignored state or secrets. Preserve actual metadata and file bytes throughout.

The prior report proved regular-member equality but did not capture the cache
directory's opening mode/mtime. That historical limit is not retroactively
repairable. Establish a complete new opening record for THIS continuation and
make no claim of earlier full-period directory equality.

Create one task-owned mode-0700 root. Preserve pre-existing source OS modes in
the clone (including any nonexecuting 0600 file). Test processes use umask 022.
Precreate distinct collect/run basetemp parents and set TMPDIR to the external
root. No xdist, overlap, parallel suites, or live imports.

Exact common command, from the remote-free external clone:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<external-precreated-group-path> [--collect-only] <exact-paths>
```

Each token means `tests/test_<token>.py`; sort/deduplicate within each group.
The exact path inventories are:

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

Group 12 uses NO path argument. There are still 124 test modules; no new module
is authorized. Do not select paths to reproduce a preferred count.

### Preserved inventory coordinates

The following test-file bytes must remain exact and their regression tests pass:

| Group | Files | Reference pass count | Inventory SHA-256 |
|---|---:|---:|---|
| 2 program | 9 | 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 8 Capability | 4 | 60 | `b3e0312635ab5738ff7d7a4f3e8ff52712db7ab70ccc4dcb8591980cdd5f1e00` |
| 9 bootstrap guard | 1 | 289 | `236257f277b9e27424b19ed0a296fe283b891ccceadf69304e61d1a44d879736` |

Inventory serialization for each sorted repo-relative path:

```text
u32be(path_utf8_length) + path_utf8 + raw_sha256(file_bytes)
```

### Changed or potentially changed inventory coordinates

- Group 1: 92 passed in V2, digest
  `2beb9ecda4ce8636339f5d3fe8f93526c0242cae9c1e498cf27f15a01da76acf`.
  Keep exact if these tests stay unchanged; otherwise justify and recompute.
- Group 7: 123 passed in V2, digest
  `b604716da90279bfed0435ca559476723ba760cf4f2e8341b8e01ff39c9d678b`.
  The retained Wire correction stays intact. Preserve this inventory unless a
  necessary direct correction changes this already-authorized file.
- Group 10: opening collection 1,754; V2 had 1,753 passed and one B1 importer
  failure. Its old digest
  `f0c8037a97d99ac77e81099c190b75c4f3e346988bde515913c2fb00a6236a45`
  MUST change with the admitted B1 test amendment. Recompute; do not require it.
- Group 11: NOT collected/run in V2. Its reported static inventory digest was
  `63f8a0cc635bdffd84d71b99d1e778405b64963e7b3caa68403c27357decad49`.
  It includes the newly admitted phase-entry test (and Wire test); recompute its
  final digest and count. No historical pass claim is available.
- Group 12: NOT collected/run in V2. Its reported static module-inventory digest
  was `ef0ec58c6357819b69551addd034aac60a037dc23b87a5a84cc301f6f47bbef1`.
  Recompute and fully execute from final bytes. A static inventory is not a
  test run or acceptance evidence.

Reconcile unique node identities and exact additions/removals. Groups 2 and 3
share 46 nodes; Groups 7 and 11 share the Wire-boundary tests. Other overlapping
selections must also be reported accurately; never sum group totals as unique
coverage.

Capture the retained opening per-module collections for B1 and phase-entry in
the development clone if needed to measure their deltas. With only the named
D1 test files, Wire test, B1 test and phase-entry test allowed to change, the
useful bookkeeping relationship is:

```text
final full count = 8,820 + final Group 1 count
                   + (final Group 7 count - 117)
                   + delta_B1 + delta_phase_entry
final Group 10 count = 1,754 + delta_B1
final Group 11 count = 656 + (final Group 7 count - 117) + delta_phase_entry
```

Here delta_B1 and delta_phase_entry are net test-node changes from the retained
opening versions of those two modules. These are reconciliation formulas only;
8,918 before those new deltas is NOT a collected/passed full-suite result.
No behavioral tests may be removed or weakened to force a count. Diagnose any
mismatch against actual node inventories.

Capture the three expected Python 3.13 multithreaded-fork DeprecationWarnings
as structured records attached to:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Investigate extra warnings; do not suppress them. Required fork/process probes
must run on the supported proof host. Unsupported execution is a stated gate
limit, not full validation.

### Whitespace, preservation, and cleanup

Require `git diff --check`, all seventeen addition no-index whitespace checks,
strict UTF-8/BOM/CR/final-LF/trailing-whitespace checks, exact path/type/mode
inventory, all 34 protected candidate receipts, all 217 noncandidate HEAD
entries, package/export/source-owner/migration preservation, and no migration
0005. All 263 clone endpoints must equal pretest bytes/modes afterward.

Use lstat before opening any external artifact. Hash regular files only; do not
follow symlinks or open FIFOs/sockets/devices. Account for task-owned child PIDs,
process groups, and state roots left by deliberate negative tests. Clean only
positively identified task-owned roots after their children end. Do not label
an unproved root or process as removed.

Correct only clearly identified external-runner errors outside the live
checkout. Rebuild from the same exact candidate and rerun affected gates. Any
late candidate edit requires final-candidate validation again.

End with exact live cache directory AND member equality, including actual
opening/closing modes and nanosecond mtimes. Do not claim missing opening
metadata was reconstructed retrospectively.

## 9. Retained-work rule and closeout

Do not roll back the opening runtime/Wire repairs on a later stop. Preserve
retained opening work and identifiable new changes, report exact status, and
never reset or overwrite concurrent edits. No source recreation from hashes.

Return inline:

1. verdict, visible settings, exact opening/closing Git coordinates;
2. verified current handback dependency table and coupled guard/projection set;
3. exact B1 phase_basis consumer purpose and unchanged construction/durable owners;
4. version-3 consumer registry and two independent fixed projections;
5. positive/negative import, symbol, role and projection evidence;
6. preservation of four runtime repairs and the Wire correction;
7. all twelve allowed paths' opening-to-final receipts, including unchanged ones;
8. proof that the other 34 candidate receipts and 217 noncandidate paths remain
   exact;
9. final 46-row replacement components, total length and SHA-256, computed twice;
10. all twelve final test groups, exact commands, files, inventory digests,
    unique-node counts, overlaps, warnings, trials and corrections;
11. direct specimens, permanent tests, transformed copies and any oracle evidence
    distinguished explicitly;
12. complete cache metadata equality, process/root cleanup, exact nonclaims;
13. continuation capsule no longer than 1,000 words.

A full 46-row final table is welcome, not mandatory, provided all twelve exact
transitions plus the 34-row preservation claim are unambiguous. No additional
receipt format or user-transported artifact is required.

Stop with:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V3_REPLAN_REQUIRED`

only for a genuine owning-contract contradiction or necessary path/symbol
outside this twelve-path authorization. The explicitly selected B1 consumer
extension is not a product-policy question. Use:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIR_V3_BLOCKED`

for provenance drift, validation failure, unsupported mandatory environment,
concurrent state, or unproved cleanup. A partial run cannot be ready.

Success requires the retained repair plus bounded B1 coordination, closed
consumer guards, four preserved runtime fixes, all final validation groups and
complete preservation/cleanup:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

Success supports only a fresh independent read-only re-audit of the final exact
candidate. It authorizes no staging, commit, publication, D2 validation/review/
model closure, RW0-C2 physical implementation, migration 0005, supplier or live
source work, Git effect, Bridge/ES integration, deployment, or RW0-E execution.
