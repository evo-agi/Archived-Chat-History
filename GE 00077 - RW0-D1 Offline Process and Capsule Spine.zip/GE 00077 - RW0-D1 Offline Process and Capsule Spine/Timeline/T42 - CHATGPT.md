## Disposition

**Proceed to an independent read-only acceptance audit of the repaired V8 candidate. Do not stage, commit, or begin D2.**

The closeout supports that step: the repair stayed in the integration-test file, reports discrimination of all three forbidden-launch cases, preserves legitimate `committed_exact` recovery, and reports successful execution of all twelve final validation groups. **No additional runtime repair or scope expansion is indicated before independent inspection.**

There is one reporting omission—the changed file’s abbreviated SHA-256—but the supplied full replacement-stream digest provides an exact audit-subject binding. It does not require another repair or user-relay round.

## The repair addresses actual effects, not just the handback

The important improvement is the observation point. Codex reports that the permanent tests now intercept the supervisor’s actual `Popen` lookup for the entire invocation, recording every attempt and created PID even when the runner discards that worker’s result.

That is the required distinction:

```text
No worker appears in the handback
```

does not establish:

```text
No worker was launched
```

The original repair mandate required this lower-level, whole-invocation observation and explicitly prohibited making the observer an additional launch gate. It also distinguished physical C1 commit from the successful result actually received by the runner. Coordinator_RW0_D1_Offline_Proc…

The reported V8 results address both concerns. Assertions run after the real invocation, and the observer calls through rather than preventing a forbidden launch. The C1 response-loss case records the **effective recovery response**, not an internally observed successful commit subsequently hidden by the fault wrapper.

### The three causal controls are complementary

| Control | Reported discrimination |
|---|---|
| **L01: extra, unreported worker before C1** | Both named tests fail on the complete launch sequence, even though the handback remains plausible |
| **L02: sole worker moved before C1** | The two-child count passes; the success test then fails specifically on missing effective C1 resolution |
| **L03: worker after physical commit but before unresolved recovery** | The unresolved test fails on the actual forbidden launch, despite the underlying write having committed |

L02 is particularly useful: it prevents a count-only repair from masquerading as an ordering check. Preserving the real writer-close boundary in that mutant was necessary so an unrelated close failure did not receive credit for detecting missing C1 resolution.

The positive recovery trace also matters:

```text
committed_exact recovery
→ exact replay
→ recovery-writer close
→ one worker
```

The tests reportedly retain that valid path rather than “fixing” unresolved recovery by forbidding all work after any response loss.

These remain **Codex-reported repair results**. The independent auditor must inspect the observer and reproduce the distinctions.

## What the auditor must scrutinize

The next audit should close the V8 gate first, with three specific checks.

**Observation completeness.** The observer must remain installed before the invocation begins through recovery, cleanup, and return. It must not filter children using handback membership, keep only the latest worker, or derive roles from an expected list position. Unexpected in-interval launches must remain visible.

**Effective-result ordering.** A successful return inside a fault wrapper must not set the test’s “C1 resolved” condition when the result ultimately delivered to the runner is response loss or `unresolved`. Likewise, the close event must belong to the relevant writer or recovery session and be recorded after the real close completes—not merely after any earlier session closed.

**Noninterference and cleanup.** The observer must allow the real mutant launch to occur, then detect it. Every observed child must remain accounted for even when its result is omitted from the handback. Test emergency cleanup, if needed, must not be credited as successful runtime cleanup.

This is bounded coverage of the existing Python supervisor call site—not a claim to intercept arbitrary native process creation or provide a hostile same-user sandbox.

## Provenance: one abbreviated endpoint, but a fixed complete subject

The candidate remains:

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Candidate:
29 modified tracked paths + 17 untracked additions

Final replacement identity:
4,538,355 bytes
173adda1a4d1cab3a0056a5156339e1fd1f059533a4f11e915894ddb21ea0ce0
```

The integration test grows by **14,040 bytes**, and the replacement arithmetic reconciles:

```text
47,176 − 33,136 = 14,040
4,524,315 + 14,040 = 4,538,355
```

However, its new individual SHA-256 was supplied only as:

```text
0f38baa2…00b4518b4b3
```

**That is not a complete endpoint receipt.** The audit prompt explicitly handles the omission rather than inventing the missing digits.

Before semantic or executable audit work, the auditor must measure the full file digest, verify the other 45 complete endpoint receipts, reproduce the exact fixed replacement stream twice, and match the supplied Group 1 and Group 12 inventory hashes. Only after those checks pass may the measured full endpoint hash become the current observation used for clone and closing comparisons.

The replacement stream contains the file’s **raw payload bytes**, so the independently fixed full-stream digest binds that payload. A newly measured aggregate must never replace the supplied expectation. Any mismatch stops the audit.

The same principle applies to the truncated mutant hashes: the auditor should record full identities for its equivalent transformed copies, not claim historical byte identity from the abbreviations.

## Validation reconciles, but remains implementation evidence

The principal reported results are:

| Gate | Collected / passed |
|---|---:|
| D1 runtime and integration | 112 / 112 |
| Wire | 135 / 135 |
| Legacy guards | 1,783 / 1,783 |
| Remaining changed owners | 679 / 679 |
| Complete repository | **8,984 / 8,984** |

The two additional D1 nodes account for the full-suite increase:

```text
8,982 + (112 − 110) = 8,984
```

The reported overlaps also reconcile to the stated **3,657-node union** for Groups 1–11.

I independently recomputed the **unchanged Groups 2–11 inventory hashes** using mounted baseline bytes plus the supplied candidate endpoint hashes. They match. I did **not** recompute Groups 1 and 12 because the full changed-file digest was not supplied; their exact reported hashes are carried into the audit as fixed expectations to verify from actual bytes.

None of this substitutes for independent test execution.

## Preserve completed audit evidence; finish what remains

The preceding audit made substantial progress. It reported complete readback of the four used durable families, including their required rows and bindings, `committed_exact` recovery, and replay without new family rows or changed original times. It also reviewed all 29 tracked semantic diffs. Those are **completed prior independent observations**, not tasks that were never performed. Pasted text

That audit nevertheless left the remaining finite mutation campaign incomplete, interrupted Group 11 after 233 passes, and did not run Group 12. The V8 implementation run does not retrospectively convert those omissions into independent passes. Pasted text

The handoff preserves that distinction. It authenticates the unchanged owners, reconfirms affected compositions, completes the remaining finite obligations, and requires fresh independent final validation. L01–L03 discharge the already-selected forbidden-launch safeguard; they do not create another mutation quota.

## Independent acceptance-audit handoff

**Use the independent auditor conversation that found the pre-C1 worker survivor—not the implementation writer.** The prompt starts a new read-only preservation interval and continues without per-phase approval.

:chatgpt-content-reference{index="3"}[Download the complete repaired-V8 D1 independent acceptance-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V8_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V8_Independent_Reaudit_Prompt.txt

Bytes:
119,446

SHA-256:
644afb490a1cf9b8d19ad48635c667b44da76183e16623daa0e192e327702f18

Lines:
1,921

Final newline:
present
```

It includes all 46 paths, the 45 fully supplied endpoint hashes, the explicit aggregate-bound treatment of the abbreviated endpoint, the successful pre-Git mechanism, L01–L03 requirements, retained acceptance obligations, and all twelve validation memberships and hashes.

The live checkout remains read-only. Executable work is confined to disposable, remote-free external copies. No candidate repair or publication is authorized.

Possible verdicts remain:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would establish eligibility for a separately issued commit/publication gate—not permission for D2, physical C2, migration `0005`, live authority/provider/supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the latest pasted V8 closeout, its repair mandate, and the preceding independent audit. I corroborated the 29 baseline blob identities and 17 additions’ absence against the mounted snapshot, checked the replacement arithmetic and unchanged inventory hashes, and reopened the generated prompt. Its embedded opening/helper code was syntax-checked, not executed against your Mac.

I did **not** inspect the live amended integration test, reproduce L01–L03, or run repository tests. The repair’s behavior and 8,984-pass result remain Codex-reported.

Some older uploads have expired. Re-upload a specific original when a later byte-level comparison requires it; this handoff requires no historical attachment.

**Sources:** Your pasted V8 repair closeout; the issued V8 repair mandate; the preceding V7 independent audit cited above; October 15 Coordinator snapshot for baseline corroboration.

**Confidence:** High on re-audit readiness, the scope boundary, and provenance bookkeeping. The abbreviated endpoint’s full identity, permanent-test adequacy, and complete independent acceptance remain to be verified by the audit.
