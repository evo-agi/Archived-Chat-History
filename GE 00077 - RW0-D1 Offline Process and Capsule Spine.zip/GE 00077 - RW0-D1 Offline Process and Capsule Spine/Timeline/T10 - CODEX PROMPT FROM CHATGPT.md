# Governed Execution Coordinator — RW0-D1 Offline Process and Capsule Spine: Implementation Tranche

## Mandate

Implement the first source-bearing RW0-D tranche:

`RW0-D1 — offline process and capsule spine`

This is one implementation tranche with three internal implementation stages:

- Stage A: private process supervisor, private frames, separate fake planner;
- Stage B: separate fake worker, bounded workspace, parent capsule construction
  and independent reconstruction;
- Stage C: current durable Coordinator composition and typed D1 handback.

The stages are dependency checkpoints inside ONE uncommitted candidate. They are
not separate contract tranches, publication programs, branches, commits, PRs,
or user handoffs. Complete and validate the integrated D1 capability before
returning.

The prior read-only implementation map returned
`RW0_D1_IMPLEMENTATION_MAP_REPLAN_REQUIRED` only because it proposed those
internal stages. That disposition is not adopted: the map also established that
the existing durable authority paths are composable and identified no authority
contradiction. Ordinary source decomposition is not a product replan.

Two implementation attempts then reached integrated validation and restored their
changes cleanly after discovering incomplete mutation ceilings. The latest full
suite exposed nine failures across eight exact legacy guard files: one post-
execution `_rw0_d*` absence guard, one temporary RW0-C2 complete-source manifest
guard, five historical source-wide subprocess guards, and one RW0-B1 exact
importer guard. This prompt supersedes the prior D1 implementation prompts and
admits those exact owners plus the two documents whose current claims must change.
The prior candidates no longer exist and provide no validation credit; recreate
the implementation from this clean baseline and validate the final bytes.

No standalone semantic-contract, value, envelope, or protocol tranche may
precede this source work. Bounded implementation clarification belongs in this
candidate.

The parent is the sole repository writer. Do not use subagents. Use the highest
exposed reasoning setting; report visible model, reasoning setting/effort, and
permission posture, or `not visible`. Do not seek additional account/computer
access merely to reveal hidden settings.

Return one substantive INLINE implementation closeout and a continuation capsule
no longer than 1,000 words. Do not create or deliver a report, manifest, patch,
snapshot, package, or evidence bundle. Do not issue a D2 or C2 mutation prompt.

## 1. Exact baseline

Repository:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline:

- branch: `trunk_dev`
- HEAD: `0d0926e3a483a3ab1a4fd597ac0495927352bf35`
- tree: `45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4`
- sole parent: `630414faa07f4ac39c4a870a9cc44c7f92d46b80`
- subject: `docs: freeze RW0-C2 scope admission provisioning`
- upstream: `origin/trunk_dev`
- locally observed divergence: `0 ahead / 0 behind`
- exactly one live worktree
- clean tracked, untracked, staged, and unmerged state
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or unexpected
  Git lock.

Read `AGENTS.md` first. Verify the baseline using non-mutating Git inspection
with optional-lock suppression where appropriate. Do not fetch or normalize the
checkout. Local tracking equality is not fresh remote truth.

Stop before mutation on any baseline or concurrent-work drift:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTATION_BLOCKED`

Do not reset or overwrite another actor's work.

## 2. Exact observable capability

One private parent invocation must perform, without intermediate user relay:

```text
accepted private WorkSpecV1 + bounded artificial offline fixture
→ disposable Coordinator database migrated through 0004
→ current guarded program initialization or exact replay
→ current guarded author-effect establishment or exact replay
→ close writer and state-authority resources
→ separate deterministic fake planner process
→ parent construction of the current production-private Section 41 bundle
→ current Section 41 recovery probe and guarded disposition recording
→ current durable selected_for_dispatch_gates result
→ current RW0-C1 phase establishment before worker contact
→ close writer and state-authority resources
→ separate deterministic fake coding-worker process
→ one bounded candidate mutation in an isolated temporary workspace
→ parent capture of exact candidate bytes and modes
→ parent construction of CandidateCapsuleManifestV1
→ separate parent reconstruction and verification from the immutable fixture
→ mutable workspace removal
→ typed private D1 handback
```

The initial input is one exact accepted private `WorkSpecV1` plus a closed
artificial fixture projection. Do not create:

- a public natural-language intent API;
- a generic task grammar;
- a service, daemon, scheduler, queue consumer, MCP surface, network endpoint,
  public API, or console script;
- a package-root export;
- a second program, selection, or phase lifecycle;
- a durable C2 decision, acceptance fact, terminal outcome, or migration 0005.

No user message or copied artifact may be required between planner, durable
selection, worker, capture, capsule verification, and handback.

## 3. Fixed authority model

Preserve these sole owners:

| Fact/material | Sole owner in D1 | Forbidden shadow authority |
|---|---|---|
| Program, version/head, WorkSpec binding | Current Coordinator SQLite program-initialization path | Offline orchestrator or handback |
| Attempt, author effect, command, fences, initial delivery | Current C2B3D author-effect path | Planner, supervisor, or workspace |
| Plan content and recommendation | Fake planner process | Planner cannot select or write SQLite |
| Pre-execution selection and selection head | Current Section 41 writer/receipt | No harness-selected boolean |
| RW0 phase basis and receipt | Current RW0-C1 writer | No in-memory substitute |
| Process launch/exit/timeout/cancel/reap | Parent supervisor | Process facts are not progression truth |
| Candidate bytes | Fake worker in bounded workspace; parent observes them | Candidate bytes are not acceptance or program head |
| Capsule manifest | Parent-owned builder plus independent verifier | Worker manifest is never authoritative |
| Workspace | Ephemeral evidence/custody surface | Filesystem markers are not program state |
| D1 handback | Transient typed projection | Not C2 decision, receipt, terminal outcome, or acceptance |

No in-memory run object, fixture, supervisor status, workspace marker, or
handback field may become a second source of program, author-effect, selection,
phase, or decision truth.

The private entry must invoke the actual current guarded program, author-effect,
Section 41, and C1 mutation paths. Direct SQL, copied rows, fixture-owned
selection state, or test-only durable builders are forbidden.

For any durable commit uncertainty, invoke the existing exact recovery entry
under a fresh writer before advancing. `unresolved` means no next child process.
Do not speculate, retry automatically, or create another delivery.

## 4. Fixed D1/D2 boundary

D1 ends after one independently verified capsule and typed handback.

D1 does not implement:

- validator;
- independent reviewer;
- fake semantic-review model;
- post-execution proposal family;
- RW0-C1 admission of D2 validation/review/model evidence;
- projection into `_rw0_c_decision_input_values.py`;
- durable C2 decision or acceptance.

D2 later consumes the exact D1 capsule, durable lineage, process observations,
and parent-owned disposable-state custody in the same parent process.

D1 may inspect D2 pure modules only to ensure its handback retains the needed
identities and bytes. It must not implement D2 behavior.

## 5. Exact mutation ceiling

### Create production-private source modules

```text
src/ge_nwp_coordinator/_rw0_d1_process_frames.py
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
src/ge_nwp_coordinator/_rw0_d1_fake_planner.py
src/ge_nwp_coordinator/_rw0_d1_fake_worker.py
src/ge_nwp_coordinator/_rw0_d1_workspace.py
src/ge_nwp_coordinator/_rw0_d1_capsule.py
src/ge_nwp_coordinator/_rw0_d1_pre_execution.py
src/ge_nwp_coordinator/_rw0_d1_handback.py
src/ge_nwp_coordinator/_rw0_d1_offline.py
```

### Create tests

```text
tests/test_rw0_d1_process_frames.py
tests/test_rw0_d1_process_supervisor.py
tests/test_rw0_d1_planner_process.py
tests/test_rw0_d1_worker_process.py
tests/test_rw0_d1_workspace_capsule.py
tests/test_rw0_d1_handback_values.py
tests/test_rw0_d1_offline_integration.py
```

### Create one implementation-status owner document

```text
.docs/rw0-d1-offline-process-and-capsule-spine.md
```

This document records implemented D1 behavior, process/custody limits, D2
handoff, and exact nonclaims. It follows the source implementation; it is not a
standalone target-contract prelude. The bounded B1 consumer and C2 temporary
source-guard amendments below are compatibility corrections exposed by the
same source-bearing tranche, not separate contract work.

### Modify current status and routing documents only

```text
AGENTS.md
README.md
.docs/architecture.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/c2b-durable-development-state.md
.docs/rw0-b2-wire-protocol.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
.docs/rw0-c2-first-live-proof-posture.md
```

Amend only current implementation status, D1 ownership/routing, the selected
D1→D2→C2 sequencing, synchronized RW0-B2-Capability current-status projections,
the bounded RW0-B1 runtime-consumer registry, the supersession of the temporary
RW0-C2 complete-source manifest barrier, and exact nonclaims. Do not rewrite
frozen C2A, B1 value meanings, B2, C1, C2 branch/recovery semantics,
first-live authority, or provisioning semantics.

The five existing RW0-B2-Capability current-status projections in:

```text
.docs/rw0-remote-worker-contact-phase-entry.md
.docs/authority-boundaries.md
.docs/autonomous-software-development-operating-model.md
.docs/durable-state-model.md
.docs/worker-execution-boundary.md
```

must remain visible, unique, and byte-for-byte synchronized after normalization.
Preserve the statement that RW0-B2-Capability itself is private, pure, no-I/O,
non-authoritative, and proves no physical process behavior. Narrow only the
repository-level future-status sentence so it truthfully states that RW0-D1
offline fake-process/capsule mechanics are implemented separately, while
RW0-D2, RW0-C2 physical closure/decision, provider/credential/live-proof, and
RW0-E runtime mechanics remain future.

### Modify only direct owning/status tests

```text
tests/test_runtime_non_authority.py
tests/test_c2a_nonimplementation.py
tests/test_architecture_contracts.py
tests/test_autonomous_software_development_operating_model.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_software_development_progression_boundary.py
tests/test_c2b0_durable_state_contract.py
tests/test_rw0_b2_wire_boundaries.py
tests/test_rw0_b2_capability_boundaries.py
tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
tests/test_rw0_c2_first_live_proof_posture_contract.py
tests/test_post_execution_pure_owner_boundaries.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_b1_boundaries.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
```

Update exact production-file inventories, admitted private executable-module
exceptions, synchronized current-status assertions, the two exact
AGENTS.md/README.md protected-content identities, the bounded B1 consumer
registry/importer set, the post-execution D1/D2 seam, the temporary C2 source
guard, and the five historical source-wide subprocess guards only where
directly required by D1.

`tests/test_rw0_b2_capability_boundaries.py` is admitted because it both owns the
five synchronized Capability status projections and pins the full literal
identities of `AGENTS.md` and `README.md`.

`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` is admitted
because its independently fixed Capability-replacement evidence also pins the
current replacement identities of `AGENTS.md` and `README.md`.

These two tests remain authority guards, not implementation owners. Do not
weaken, remove, dynamically derive, or bypass their protections.

### Must remain unchanged

- `src/ge_nwp_coordinator/__init__.py`
- `pyproject.toml`
- `.gitignore`
- `src/ge_nwp_coordinator/state_store.py`
- existing program, author-effect, Section 41, C1, reader, writer-session,
  transaction, migration, C2A, B1, Wire, Capability, D2, C2-input, and C2 source
  modules;
- `.docs/rw0-b2-capability.md` and the frozen Capability semantic owner;
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` and its frozen
  guard semantics;
- every RW0-B1 value field, digest, relation, privacy rule, and no-authority
  invariant other than the bounded consumer registry named above;
- every RW0-C2 branch, matrix, decision, replay, recovery, guard, acceptance,
  terminal, and physical semantic other than the temporary complete-source
  manifest guard named above;
- migrations `0001`–`0004`;
- all schemas and configuration;
- all other tests and documents.

If a path outside this ceiling is materially required, stop without widening:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPLAN_REQUIRED`

Do not stage, commit, push, create a PR, merge, switch branches, reset, rebase,
install dependencies, contact a network/provider, use live credentials, access
sibling repositories, or produce Git/publication effects.

## 6. Protected status and identity coordination

The baseline contains two intentional exact-identity guard surfaces that the
previous prompt omitted from its mutation ceiling.

Before editing, inspect and record:

1. `tests/test_rw0_b2_capability_boundaries.py`
   - `EXPECTED_STATUS`;
   - the five `STATUS_PATHS`;
   - `PROTECTED_CONTENT_ROWS` entries `P11` (`AGENTS.md`) and `P12`
     (`README.md`);
   - the tests that enforce literal inventory, mode, byte size, SHA-256,
     ownership class, and purpose.

2. `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
   - the independently fixed Capability replacement evidence for `P11` and
     `P12`;
   - `old_identity`, `replacement_identity`, semantic markers, ownership class,
     and purpose;
   - the source-integrity tests that prevent dynamic derivation or no-op
     comparison.

After the final integrated D1 source and documentation edits, and before final
validation:

- compute the final `AGENTS.md` and `README.md` byte lengths and SHA-256 hashes
  twice from fresh reads;
- update only the literal current identities required by the two owning tests;
- keep every prior/old identity, row ID, path, ownership class, purpose, and
  hostile source-integrity control unchanged;
- keep the expected identities fixed literals, never values derived at test
  runtime from the files under test;
- update the Capability `EXPECTED_STATUS` to the exact normalized text present
  in all five synchronized status projections;
- preserve the Capability owner's pure/no-I/O/non-authority claims;
- preserve every bootstrap guard semantic marker and invariant;
- add or retain a marker that makes the status distinction explicit: D1 is an
  artificial offline process/capsule proof implemented separately, while the
  Capability relation itself still proves no physical behavior and grants no
  permission.

Do not change `AGENTS.md` or `README.md` merely to satisfy an old hash. The
documents must truthfully report D1 after Stage C exists, and the owning tests
must advance to the exact new identities.

If another exact full-file identity pin for either document is discovered
outside the explicit test ceiling above, stop and report:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPLAN_REQUIRED`

Do not silently widen the path set.

## 6A. Legacy source-guard and owner coordination

The prior implementation attempt reached integrated validation and found nine
failures across exactly eight previously excluded guard files. Those guards are
now admitted because D1 is the authorized source tranche that changes their
historical premises. Preserve their real authority boundaries; do not bypass or
delete them.

### A. Exact affected guard set

The newly admitted files are exactly:

```text
tests/test_post_execution_pure_owner_boundaries.py
tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
tests/test_rw0_b1_boundaries.py
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
```

The two newly admitted owner documents are exactly:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
```

This is a coordinated source-bearing compatibility amendment. It is not a new
contract-only prelude and does not authorize changes to the B1 values or C2
decision semantics.

### B. Five historical source-wide subprocess guards

These tests currently forbid the token `subprocess` across every production
source file:

```text
tests/test_sqlite_backend_b0_contract.py
tests/test_sqlite_b1_runtime_boundary.py
tests/test_b2a_writer_session_contract.py
tests/test_b3a_persistence_contracts.py
tests/test_sqlite_b2c_writer_session.py
```

Narrow only that historical assertion. Require the exact authorized production
subprocess owner set to be:

```text
src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py
```

For each guard:

- preserve every other forbidden fragment and historical B0/B1/B2A/B2C/B3A
  invariant;
- continue to forbid `subprocess`, `Popen`, process launch, socket, urllib,
  requests, service, scheduler, queue, CLI, and writer-acquisition widening in
  every other production module according to that guard's existing scope;
- assert with AST/source evidence that only the D1 supervisor imports or calls
  `subprocess`/`Popen`;
- do not grant subprocess permission to `_rw0_d1_offline.py`, fake children,
  workspace, capsule, handback, pure semantic modules, SQLite modules, or
  package-root/public modules;
- preserve no-network, no-service, no-public-backend, no-StateStore-widening,
  and migration invariants;
- include a fixed hostile check or equivalent assertion showing that a second
  production subprocess importer fails.

The D1 supervisor remains process-fact authority only. These historical guards
must not imply that subprocess launch is part of B0/B1/B2A/B2C/B3A or SQLite
writer authority.

### C. Post-execution seam S004

`tests/test_post_execution_pure_owner_boundaries.py` currently treats every
`_rw0_d*.py` file as absent. Replace only that blanket absence check with an
exact bounded inventory:

```text
_rw0_d1_process_frames.py
_rw0_d1_process_supervisor.py
_rw0_d1_fake_planner.py
_rw0_d1_fake_worker.py
_rw0_d1_workspace.py
_rw0_d1_capsule.py
_rw0_d1_pre_execution.py
_rw0_d1_handback.py
_rw0_d1_offline.py
```

Require all nine and no additional `_rw0_d1_*.py` source. Continue to require:

- no `_rw0_d2*.py` source;
- no `_rw0_e*.py` source;
- no `RW0CTerminal` value or terminal runtime owner;
- no durable C2 decision/acceptance implementation;
- no import, call, or re-export from D1 into the six post-execution pure-owner
  modules that would give D1 decision authority.

Keep all other S001–S008 seam assertions and pure-owner import/effect guards
unchanged.

### D. RW0-B1 bounded runtime consumer

The current B1 owner and test truthfully state that RW0-B2-Capability is the
sole current cross-module production consumer. D1 now needs one additional,
bounded runtime consumer to construct the existing C1 phase command.

Amend `.docs/rw0-b1-pure-phase-values.md` and its fixed registry together:

- bump the bounded registry version from 1 to 2;
- replace the old singular row with:

```text
| sole_current_pure_cross_module_production_consumer | RW0-B2-Capability | authority | this_document |
| current_bounded_runtime_consumer | RW0-D1-pre-execution | authority | this_document |
```

- explain that the D1 consumer uses B1 only to construct the current
  `RW0PhaseEntryBasisV1` for the existing guarded C1 command;
- retain `source_authentication = none`, `executable_permission = none`,
  `durable_persistence = none`, and `semantic_acceptance = none` for B1;
- do not let D1 call `_validate_host_qualification_with_snapshots` or treat B1
  values as current permission.

In `tests/test_rw0_b1_boundaries.py`:

- update the fixed registry/projection to version 2 and the two exact rows;
- add exactly one D1 importer:
  `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py`;
- require its direct B1 import to contain exactly `RW0PhaseEntryBasisV1` and no
  source-authentication helper or additional B1 value;
- continue to require the existing Capability, C1 values, C1 runtime, and
  post-execution importers with their exact symbol sets;
- continue to forbid B1 package-root export and runtime/I/O behavior in the B1
  owner module.

Update the already admitted independent B1 registry projection in
`tests/test_rw0_remote_contact_phase_entry_contract.py` and any already admitted
fixed B1 document identity in the Capability/bootstrap guards after final bytes
are stable. Do not dynamically derive the expected registry or identities from
the document under test.

If actual D1 source requires another direct B1 importer or additional B1 symbol,
refactor D1 to centralize construction in `_rw0_d1_pre_execution.py`. If that
cannot be done without changing B1 authority, stop with the replan token.

### E. RW0-C2 temporary complete-source manifest supersession

The durable-decision owner contains a temporary complete-source count/hash guard
whose own `supersession` field names a future authorized source tranche. D1 is
that source tranche for unrelated offline process/capsule runtime. Do not update
the whole-tree count/hash to a new brittle snapshot.

Amend `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` and
`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` together:

- preserve the existing key `temporary_source_nonimplementation_guard` so the
  contract shape remains bounded;
- replace its complete-tree `manifest_count`, `manifest_payload_bytes`, and
  `manifest_sha256` fields with an explicit bounded supersession record:

```json
{
  "source_root": "src/ge_nwp_coordinator",
  "complete_tree_manifest_status": "superseded_by_authorized_rw0_d1_source_tranche",
  "bounded_scope": "rw0_c2_physical_decision_acceptance_terminal_runtime_only",
  "forbidden_modules_calls_exports_enforced": true,
  "migration_0005_exists": false,
  "production_caller_exists": false,
  "public_export_exists": false,
  "runtime_active": false
}
```

- update the human table, finite oracle, fixed expected contract, pointer/scalar
  coverage, and exact representation-equivalence tests for those exact fields;
- remove only the whole-tree count/payload/hash assertion and its hostile
  count/hash/symlink manifest mutants;
- retain and strengthen the existing scoped semantic source scan for forbidden
  C2 modules, names, imports, calls, re-exports, exports, production callers,
  acceptance-latch/durable-decision modules, terminal owner, and migration 0005;
- add a neutral-source control proving the exact nine authorized `_rw0_d1_*`
  modules do not violate the scoped C2 nonimplementation guard;
- add hostile controls proving a forbidden C2 module/call/re-export/export or
  migration 0005 still fails;
- preserve every branch, matrix, currentness, model, halt-only, replay,
  recovery, acceptance, terminal, and physical semantic outside this temporary
  guard;
- preserve `rw0_d = false` as meaning complete RW0-D/D2 closure is not
  implemented, and add explanatory prose that bounded D1 is separately
  implemented under its own owner.

The C2 owner remains target-only. D1 must not become a production caller of C2
pure owners or a durable decision/acceptance/terminal writer.

### F. Final fixed identities

Because the B1 and C2 owner documents now change, re-run all already admitted
fixed-identity and cross-document guards after their final bytes are stable.
Update fixed literals only in already authorized owning tests. Do not add a
runtime-derived hash expectation or weaken hostile integrity controls.

If another owner document or exact-identity test outside the expanded ceiling
is required by these two bounded amendments, stop and report the exact path and
reason. Do not silently widen.

## 7. Internal implementation sequence

Implement all stages in one working-tree candidate. Intermediate validation is
permitted and required, but do not return after A or B and do not update current
status to claim D1 until Stage C is integrated.

### Stage A — process supervisor, frames, and fake planner

Implement:

- `_rw0_d1_process_frames.py`
- `_rw0_d1_process_supervisor.py`
- `_rw0_d1_fake_planner.py`
- the corresponding three test modules.

Stage A observable evidence is one separate-PID fake planner invocation with
bounded framed input/output and typed process facts. It is not a published
capability or durable Coordinator progression.

### Stage B — fake worker, workspace, and capsule

Implement:

- `_rw0_d1_fake_worker.py`
- `_rw0_d1_workspace.py`
- `_rw0_d1_capsule.py`
- corresponding worker/workspace/capsule tests.

Stage B observable evidence is one separate-PID fake worker, one bounded
candidate mutation, and one independently verified capsule from an artificial
base. It creates no program or selection truth.

### Stage C — current durable composition and handback

Implement:

- `_rw0_d1_pre_execution.py`
- `_rw0_d1_handback.py`
- `_rw0_d1_offline.py`
- handback and integration tests;
- all bounded status/document/test amendments.

Stage C produces the complete private invocation and typed handback. Only the
integrated Stage C candidate may claim D1 implemented.

After the last source or document edit, rebuild final validation from the exact
final candidate. No Stage A/B test result may substitute for final integrated
validation.

## 8. Artificial offline fixture

Use the existing accepted private C2A WorkSpec/fence/command path set and fixed
semantic vectors as the bounded fixture basis:

```text
.docs/system_overview/hybrid_integration_architecture_adr.md
PLANS.md
docs_contract_test.go
```

The fixture is artificial proof data for repository
`repository.execution-substrate`; those files need not exist in the Coordinator
checkout.

Create one private frozen fixture/config value inside `_rw0_d1_offline.py` or
another already authorized D1 module. It may contain:

- exact accepted `WorkSpecV1`;
- immutable three-file base bytes and Git modes;
- the preassigned fixture `base_git_oid` already bound by the accepted WorkSpec;
- exact artificial standing-authority/currentness and requirement bindings;
- preassigned safe Coordinator identities needed by current reducers;
- bounded fake planner/worker behavior profile;
- process deadlines and byte ceilings.

Do not invent a public schema.

Important correction to the implementation map:

- Do NOT claim that the three fixture files and modes derive or authenticate a
  real Git commit OID unless an existing current owner provides that algorithm.
- Treat the accepted `base_git_oid` as the exact preassigned fixture coordinate
  already bound by `WorkSpecV1`.
- Independently verify the fixture bytes/modes and capsule relation against that
  bound coordinate, but do not create a Git repository or invoke Git to
  manufacture a proof.

The fixture must not derive expected values by copying arbitrary child output.
It is fixed parent-authored input.

## 9. Stage A — private process framing

### Planner frame

Use one private D1-only framed stream for planner request and response. It is an
implementation detail, not a durable/public protocol.

Selected framing:

```text
4-byte ASCII magic: D1O1
4-byte unsigned big-endian payload length
canonical closed JSON payload
```

Require:

- exact built-in types;
- recursive duplicate-key rejection;
- unknown-key rejection;
- canonical UTF-8 JSON with sorted keys and compact separators;
- exact re-encoding equality;
- length checked before allocation;
- truncation, trailing bytes, extra frame, wrong magic, and malformed JSON
  rejected;
- request ceiling 256 KiB;
- response ceiling 64 KiB.

Planner request contains only bounded planning content:

- objective;
- requirements;
- exclusions;
- three authorized path ordinals, not ambient paths from the parent filesystem;
- closed fake action vocabulary;
- private fixture behavior mode where needed for deterministic failure tests.

It contains no Coordinator database path, writer authority, durable selection,
program head, or credentials.

Planner response contains only:

- bounded one-step strategy;
- target ordinal;
- closed action;
- recommendation compatible with current pre-execution semantics;
- bounded reason;
- bounded plan prose.

The planner cannot author any durable identity, selection result, proposal
receipt, effect fence, delivery, or phase basis.

### Worker launch envelope

Use a separate private D1-only worker-launch frame. Select magic `D1W1` with the
same length/canonical JSON discipline.

It contains:

- the existing NWPF command frame encoded as bounded base64;
- exact actual attempt/effect fence mappings required to decode that command;
- selected target ordinal/action binding;
- closed fake-worker behavior mode;
- no database path, writer material, or parent-only custody data.

The worker stdout is exactly one existing NWPF result frame. Do not redefine or
wrap the NWPF result semantics.

## 10. Stage A — process supervisor

Implement one private POSIX/macOS proof supervisor. It may be reused by D2.

Use:

- absolute `sys.executable`;
- `-B`;
- package-private `-m` child module;
- `shell=False`;
- `start_new_session=True`;
- `close_fds=True`;
- `pass_fds=()`;
- no `preexec_fn`.

Use an allowlisted child environment only:

- a child-specific `PYTHONPATH` sufficient for this package;
- `PYTHONDONTWRITEBYTECODE=1`;
- fixed locale/encoding;
- child-specific `TMPDIR` under planner scratch or worker workspace if needed;
- no inherited database, lock, state-root, credential, token, provider, home,
  or unrelated environment value.

Use planner scratch cwd for planner and the isolated candidate workspace cwd for
worker.

The supervisor owns:

- start attempt;
- PID/process-group identity;
- bounded stdin transmission and close;
- concurrent bounded stdout and stderr draining;
- one monotonic deadline;
- cancellation polling/request;
- `SIGTERM` to the owned process group;
- bounded grace;
- `SIGKILL` if still live;
- direct-child wait/reap;
- final group-cleanup observation;
- typed start/frame/limit/exit/deadline/cancel/cleanup outcome.

Keep these distinct:

- cancellation request;
- signal delivery;
- observed exit;
- semantic process result;
- cleanup completion.

Do not infer semantic failure/success solely from an exit code.

Unsupported non-POSIX hosts fail closed for D1; do not claim cross-platform
support.

The fake executables are deterministic proof machinery, not an untrusted-code
sandbox. Explicitly retain the nonclaim that same-UID filesystem security is not
proved.

## 11. Child isolation

Close every `SQLiteWriterSession`, SQLite connection, state-authority lock, and
operation capability before each child launch. A close uncertainty blocks
launch.

Prove through tests that child-visible channels contain no:

- Coordinator SQLite path;
- state root;
- open SQLite/lock descriptor;
- WriterSession, writer proof, mutation lease, or operation capability;
- standing-policy credential;
- parent-only state-custody object.

Check argv, environment, cwd, stdin payload, and inherited descriptors.

`close_fds=True` is necessary but not sufficient evidence: supervisor tests must
launch a bounded probe child and independently inspect its observable argv/env/
cwd and open descriptors. Test helpers may use `python -c` or test-local data;
production code must not import test fixtures.

Do not pass raw WorkSpec or selected-plan bytes through argv, environment,
logs, public errors, or capsule metadata. Planner stdin may contain the bounded
planning projection; worker stdin contains the private launch envelope.

## 12. Stage B — fake planner and fake worker

### Fake planner

`_rw0_d1_fake_planner.py` is executable only through:

```sh
python -B -m ge_nwp_coordinator._rw0_d1_fake_planner
```

It:

- reads exactly one D1O1 request;
- validates the closed request;
- deterministically produces one D1O1 response or one bounded malformed/failure
  behavior selected by the artificial fixture;
- writes no file;
- accesses no database or network;
- emits no uncontrolled logs;
- exits deterministically.

### Fake worker

`_rw0_d1_fake_worker.py` is executable only through:

```sh
python -B -m ge_nwp_coordinator._rw0_d1_fake_worker
```

It:

- reads exactly one D1W1 launch envelope;
- decodes the embedded existing NWPF command with the actual fences;
- verifies the selected ordinal/action binding;
- mutates exactly one authorized regular file in cwd for the happy path;
- emits exactly one existing NWPF result frame;
- does not emit or author a capsule manifest;
- has deterministic fault modes for malformed result, nonzero exit, timeout,
  cancellation, bounded stderr, missing candidate, extra path, unsafe path, and
  cleanup tests;
- accesses no database, parent state root, network, Git, credentials, or
  provider.

The worker's semantic observations remain worker-authored evidence. Parent PID,
exit, timeout, and candidate-byte observations remain parent facts.

## 13. Stage B — workspace

Implement a parent-owned artificial base fixture with exactly the three accepted
paths and exact regular-file Git mode `100644`.

Create a private temporary workspace separate from the SQLite/state root.

Materialize using safe directory-relative, no-follow operations. Before and
after the worker:

- enumerate the complete workspace;
- reject absolute paths and `..`;
- reject symlinks;
- reject hardlinks (`st_nlink != 1`);
- reject unsupported file types/modes;
- reject additions, deletions, renames, or extra changes;
- reject writes outside the three paths;
- reject more than one changed file for the D1 happy path;
- enforce candidate byte and file-count ceilings;
- retain exact before/after bytes and modes for all three paths.

Do not treat a filesystem marker as program truth.

The mutable workspace must be removed after capture and capsule verification.
If process reap or workspace removal cannot be proved, return
`cleanup_unresolved`; never return `capsule_ready`.

## 14. Stage B — capsule

The worker must not supply the accepted manifest.

After worker exit/reap and workspace capture:

1. parent code constructs `CandidateCapsuleManifestV1` using the exact existing
   author command, fences, parent-assigned manifest ref, fixture base coordinate,
   and all three captured before/after entries;
2. a separately implemented verifier reconstructs the candidate from the
   immutable fixture base plus captured after-bytes;
3. it independently checks:
   - exact three paths;
   - exact modes;
   - exact before/after hashes and lengths;
   - exactly one permitted replacement;
   - base/work/program/attempt/candidate/command/fence bindings;
   - authorized path-scope digest;
   - portable capsule digest;
4. it invokes the existing `validate_capsule_manifest_relation(...)`.

Do not trust a worker-authored digest or manifest. Reject any worker result field
outside the closed existing grammar.

Retain immutable captured bytes and modes only in the parent-owned D1 result for
D2. Coordinator SQLite continues to store no capsule bytes.

## 15. Stage C — durable pre-execution composition

Implement `_rw0_d1_pre_execution.py` with production-private builders for the
current paths. It must not import test modules.

### Program initialization

D1 always invokes the current guarded program-initialization command/reducer and
writer path in its disposable database. Exact replay of the identical command
is allowed. An arbitrary pre-existing database/program is not accepted as D1
input truth.

### Author effect

Use the exact committed genesis result and current production constructors to
establish the author effect, command, fences, and planned initial delivery.

D1 must retain an independently reduced expected command and compare it with the
committed result. Do not mint a replacement command/fence/delivery after
selection.

### Planner and Section 41

Close the writer before launching the planner.

Parent code validates planner content and builds the current production-private
`PreExecutionProposalSelectionBundleV1` from:

- committed durable lineage;
- planner-authored content only;
- fixed artificial current-authority observation;
- planning context;
- source invocation;
- artifact and binding;
- safe projection;
- every required evidence binding;
- parent-preassigned Coordinator identities.

Do not import `_build_bundle()` or other fixtures from tests.

Reacquire the writer and use the current Section 41 recovery-probe preparation
and disposition-recording methods.

Continue only when the current durable result is committed/exact replay and its
outcome is `selected_for_dispatch_gates`.

No planner or harness boolean may substitute for that result.

### RW0-C1 phase

Build the current `RW0PhaseEntryBasisV1` and
`RW0C1EstablishPhaseCommandV1` from exact committed owner rows and current
constructors.

Invoke the existing guarded `_establish_rw0_phase(...)` path before worker
launch.

Close the writer and lock before worker launch.

Do not admit D2 validation/review/model evidence in D1.

## 16. D1 handback and state custody

Implement one frozen, private, nonprinting `RW0D1HandbackV1` with:

```text
status:
  capsule_ready | stopped | cleanup_unresolved
```

and a closed reason vocabulary covering:

- invalid input;
- durable conflict or unresolved commit;
- planner start/frame/limit/exit/deadline/cancellation;
- nonselection;
- C1 phase failure;
- worker start/frame/limit/exit/deadline/cancellation;
- unsafe, missing, or excessive candidate;
- capsule mismatch;
- process/workspace cleanup uncertainty.

Bind, when applicable:

- exact committed program initialization result/receipt and head coordinates;
- author-effect result/receipt, command, fences, and delivery;
- Section 41 result/receipt, selected proposal/artifact, disposition identity,
  and selection head;
- C1 phase basis/result/receipt;
- planner process outcome;
- worker process outcome;
- decoded existing wire result and classifier inputs/result;
- candidate capture outcome;
- immutable three-path before/after bytes and modes;
- verified `CandidateCapsuleManifestV1`;
- workspace cleanup state.

### Important correction to the implementation map

The typed handback must not carry:

- a raw database path;
- a raw workspace path;
- a `SQLiteWriterSession`;
- an open connection/descriptor;
- a writer proof, lock, mutation lease, or operation capability;
- a serializable live-state handle.

Implement a separate parent-only nonserializable resource owner, for example
`RW0D1OfflineRun`, returned by the private entry. It:

- owns the disposable state root/location lifetime;
- exposes the immutable typed `.handback`;
- retains only the parent-side access D2 will later need;
- never appears in child input, logs, repr, JSON, capsule, or public error;
- implements explicit idempotent `close()` and context-manager cleanup;
- contains no second program truth;
- does not retain an open writer session between stages or after D1 return.

D2 later consumes this private run owner in the same parent process. Standalone
D1 tests explicitly close it and prove state-root removal. Do not rely on
`__del__` for authority or cleanup.

The mutable workspace is already gone before a successful return. The disposable
SQLite state may remain under this explicit parent owner until D2 or standalone
inspection closes it.

## 17. Private entry

Implement one package-private function in `_rw0_d1_offline.py`, selecting an
appropriate explicit name such as:

```python
run_rw0_d1_offline(...)
```

It accepts only:

- an exact `WorkSpecV1`;
- the closed artificial D1 fixture/config;
- an optional bounded cancellation source owned by the caller.

It returns the parent-only `RW0D1OfflineRun`.

It must:

- validate input before state creation where possible;
- own all resource acquisition and ordered release;
- use current durable private APIs;
- launch at most one planner and at most one worker;
- never relaunch a semantic author delivery;
- not invoke validator, reviewer, review model, C2 decision, terminal, Git,
  network, or publication code;
- produce one terminal D1 handback without user relay.

## 18. Package and public-surface constraints

Keep unchanged:

- `src/ge_nwp_coordinator/__init__.py`;
- `pyproject.toml`;
- package-root exports;
- console-script/entry-point inventory.

The two fake executable modules may contain the only new narrowly admitted
module-level `__name__ == "__main__"` paths.

All D1 names remain package-private. No CLI or service is introduced.

Update `tests/test_runtime_non_authority.py` and
`tests/test_c2a_nonimplementation.py` narrowly:

- admit the exact new private source files;
- allow subprocess/process imports only in the D1 runtime-owned modules;
- allow executable module guards only in the two fake child modules;
- preserve pure/no-I/O restrictions for existing semantic modules;
- preserve no public export, script, service, network, provider, Git, ES, or
  Bridge authority.

## 19. Current-status documentation

After integrated source behavior passes focused tests, update the allowed
documents and their direct assertions once.

State precisely:

- RW0-D1 offline process/capsule proof is implemented;
- it uses fake planner/worker processes and artificial source/authority fixtures;
- current guarded program, author-effect, Section 41 selection, and C1 phase
  paths are reused;
- D1 has no validator, independent reviewer, review model, durable C2 decision,
  terminal runtime, live provider, supplier, ES route, Git/publication effect,
  or public service/CLI;
- RW0-D2 remains next;
- RW0-C2 physical implementation follows D2;
- the prior generic C2-before-D implementation ordering is superseded for the
  selected offline proof, without changing authority or live-entry rules.

Do not claim full RW0-D, autonomy, competent coding, or RW0-E readiness.

Update the synchronized RW0-B2-Capability status block in all five owning
documents only after integrated D1 passes focused tests. The normalized block
must state, in substance and exact synchronized wording:

- RW0-B2-Capability itself remains private, pure, no-I/O, and non-authoritative;
- it authenticates no source and proves no physical process behavior;
- RW0-D1 artificial offline planner/worker/process/capsule mechanics are now
  implemented separately under their D1 owner;
- RW0-D2 evidence/review/model closure, RW0-C2 physical decision persistence,
  live provider/credential/custody, and RW0-E runtime remain future.

After final documentation bytes are fixed, update the literal AGENTS/README
identity receipts in both admitted boundary tests as specified in section 6.

## 20. Required tests

### Process frames

Cover:

- canonical planner and worker-launch frames;
- exact type, duplicate/unknown key, canonical re-encoding;
- wrong magic, truncation, trailing bytes, extra frame;
- pre-allocation size rejection;
- request/response ceilings.

### Supervisor

Cover:

- separate PID and process group;
- sanitized argv/env/cwd/stdin;
- no inherited database or lock descriptors;
- bounded stdout/stderr;
- start failure;
- nonzero exit;
- malformed output;
- blocked input;
- deadline;
- cancellation;
- TERM→grace→KILL escalation;
- direct-child reap and no surviving owned group;
- cleanup uncertainty;
- unsupported-host fail-closed behavior.

### Planner

Cover:

- happy path;
- malformed, oversized, trailing frame;
- nonzero exit;
- timeout;
- cancellation;
- stderr bound;
- output cannot carry durable identities or selection.

### Worker

Cover:

- exact existing NWPF happy path;
- worker command/delivery/fence decode;
- one authorized mutation;
- malformed NWPF result;
- nonzero exit;
- timeout;
- cancellation;
- excessive stderr;
- missing candidate;
- extra path;
- unsafe path;
- worker manifest attempt rejected.

### Workspace and capsule

Cover:

- exact fixture materialization;
- no traversal/symlink/hardlink;
- file/mode/byte ceilings;
- additions/deletions/renames/extra changes rejected;
- before/after capture;
- parent manifest construction;
- independent reconstruction;
- hostile manifest/digest/path/mode/base/fence binding rejection;
- mutable workspace removed;
- cleanup uncertainty blocks `capsule_ready`.

### Handback/run owner

Cover:

- exact closed statuses/reasons and field invariants;
- nonprinting sensitive/raw bytes;
- no path/session/proof in handback;
- parent-only run owner context management;
- idempotent close;
- disposable state retained until close and removed afterward;
- no open writer after return.

### Legacy guard coordination

Cover:

- each of the five historical runtime guards accepts exactly the D1 supervisor
  as the sole subprocess owner and rejects a second importer;
- post-execution S004 accepts exactly the nine D1 modules while D2/E/terminal
  and C2 decision runtime remain absent;
- the B1 registry version-2 projection and exact importer/symbol set;
- the C2 temporary complete-tree manifest is superseded while the scoped C2
  module/call/export/migration guard remains causal;
- fixed B1/C2 owner-document identities and cross-document projections remain
  independently authored;
- no D1 module imports or calls C2 decision owners or grants B1 authority.

### Integrated D1

Cover at minimum:

- one successful invocation through actual program init, author effect, planner,
  Section 41 selection, C1 phase, worker, capture, capsule, handback;
- exact replay of each durable operation;
- program/author-effect/selection/C1 uncertainty blocks later child launch;
- planner failure stops before Section 41;
- nonselection stops before C1/worker;
- C1 commit occurs before first worker PID;
- worker failure produces typed stopped handback;
- timeout and cancellation for planner and worker;
- no harness-selected shadow truth;
- no direct SQL shortcut;
- no second program/attempt/delivery family;
- no child access to database/writer authority;
- one input and one handback, no relay callback;
- no validation/review/model/C2/terminal/Git/network effect;
- final capsule and retained D1 data are sufficient for the mapped D2 handoff.

Use the actual current private writer methods, reducers, readers, and receipts.
Tests that merely construct equivalent values without invoking those paths do
not satisfy D1.

## 21. Validation

Do not run repository code or tests from the live checkout if doing so would
modify the known live cache. Prefer fresh local-only external clones of exact
HEAD overlaid with the current candidate. Remove configured remotes. Use
installed dependencies only.

Development iterations may use rebuilt external clones. Final validation must
use one fresh clone populated from the final candidate after the last edit.

Use:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
python3 -m pytest -q -p no:cacheprovider \
  --basetemp=<external-precreated-path> [--collect-only] <groups>
```

Run collect then execution serially with normal `umask 022`, distinct basetemps,
no xdist, no overlap.

Required final groups:

1. all new `tests/test_rw0_d1_*.py`;
2. current program-initialization tests:
   `tests/test_c2b3*.py`;
3. current author-effect tests:
   `tests/test_c2b3d*.py`;
4. current Section 41 tests:
   `tests/test_section41*.py`;
5. current RW0-C1 tests:
   `tests/test_rw0_c1*.py`;
6. existing worker semantic tests:
   `tests/test_worker_execution_semantic_*.py`;
7. existing Wire tests:
   `tests/test_rw0_b2_wire_*.py`;
8. existing Capability tests:
   `tests/test_rw0_b2_capability_*.py`;
9. the bootstrap guard semantic contract test:
   `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`;
10. the legacy source-guard group, exactly:
    `tests/test_post_execution_pure_owner_boundaries.py`,
    `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`,
    `tests/test_rw0_b1_boundaries.py`,
    `tests/test_sqlite_backend_b0_contract.py`,
    `tests/test_sqlite_b1_runtime_boundary.py`,
    `tests/test_b2a_writer_session_contract.py`,
    `tests/test_b3a_persistence_contracts.py`, and
    `tests/test_sqlite_b2c_writer_session.py`;
11. owning/status tests modified by this tranche, deterministically
    deduplicated against groups 8–10;
12. complete repository with no path arguments.

Expand globs deterministically to sorted, deduplicated repository-relative paths
and report exact file inventories and hashes for multi-file groups. Do not
manufacture historical test counts.

Run:

- `git diff --check`;
- no-index whitespace checks for every new file;
- UTF-8/BOM/CR/trailing-whitespace/final-LF checks;
- exact changed-path/type/mode checks;
- package export and script/entry-point preservation;
- source inventory and pure-module restrictions;
- migration inventory and migration `0005` absence;
- before/after external clone equality;
- live-cache opening/closing member equality;
- exact synchronized Capability status block equality across all five owners;
- final fixed-literal AGENTS/README identity equality in both the Capability
  boundary test and bootstrap guard semantic test;
- hostile controls proving those tests still reject dynamic identity derivation,
  ignored observations, changed ownership classes, or no-op comparisons;
- exact sole subprocess-owner assertions in all five historical runtime guards;
- exact B1 registry-v2 and D1 importer/symbol assertions;
- exact C2 bounded nonimplementation guard and superseded complete-tree manifest
  representation across owner/test forms;
- exact D1 source inventory under post-execution seam S004 and continued D2/E,
  terminal, and C2 runtime absence.

Inventory external artifacts with `lstat`; open/hash only regular files; never
follow symlinks or open FIFOs/sockets/devices. Remove only task-owned external
roots after processes terminate.

## 22. Replan and stop conditions

Return:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_REPLAN_REQUIRED`

without widening if:

1. current program, author-effect, Section 41, or C1 paths cannot be composed
   without a second authoritative lifecycle;
2. mandatory production construction requires importing test fixtures;
3. planner output must author durable identities or selection authority;
4. child launch requires exposing database path, open descriptors, WriterSession
   authority, or hidden mutable state;
5. POSIX supervision cannot prove bounded timeout/cancellation/reap/cleanup for
   the fixed fake children;
6. a capsule cannot be reconstructed independently of worker claims;
7. existing worker/Wire semantics must change to represent D1;
8. D1 handback cannot support D2 without semantic translation;
9. D1 needs schema/migration changes, a public API/CLI/service, live
   credentials/network, Git effects, or D2/C2/terminal implementation;
10. current authority requires validation/review/model closure before a capsule
    handback, collapsing D1 and D2;
11. the expanded explicit mutation ceiling, including the protected-identity
    tests, five synchronized Capability status owners, eight legacy guard tests,
    and bounded B1/C2 owner amendments, is insufficient for a real authority
    owner rather than an ordinary source/status/guard update.

Return:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTATION_BLOCKED`

for baseline drift, unrelated concurrent work, test/validation failure that
cannot be corrected within the allowed source, or safe cleanup uncertainty.

On a block, restore only this task's own identifiable edits when no concurrent
change exists. Never reset the whole repository or overwrite another actor.

## 23. Success closeout

Success token:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_IMPLEMENTED_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

Success requires:

- the one private invocation works end to end;
- actual current durable program/author-effect/Section 41/C1 paths are used;
- planner and worker are separate processes;
- no child receives database/writer authority;
- one bounded candidate is captured;
- parent constructs and independently verifies the capsule;
- mutable workspace is removed;
- typed handback and separate parent-only state custody are correct;
- no user relay occurs;
- all required focused and full validation passes;
- final repository remains uncommitted and unstaged;
- no unauthorized effect occurs.

Return inline:

1. verdict and visible settings;
2. opening/closing Git coordinates;
3. exact touched path table with create/modify status, mode, bytes, SHA-256, and
   baseline blob where applicable;
4. final ordered binary patch recipe, component sizes, total size, and SHA-256;
5. implemented D1 call graph with exact current durable methods invoked;
6. process/frame/isolation behavior and evidence;
7. workspace/capsule construction and independent verification;
8. handback and parent-only custody behavior;
9. status/document changes, synchronized Capability status, exact final
   AGENTS/README identities, B1 registry-v2, C2 temporary-manifest supersession,
   and exact nonclaims;
10. the bounded changes to protected-identity and legacy guard tests, including
    sole subprocess ownership, post-execution D1 inventory, B1 importer set,
    and scoped C2 nonimplementation;
11. proof that hostile integrity controls remain effective;
12. focused/full test commands, file inventories, counts, warnings, failed
    trials, corrections, and skipped work;
13. source/export/migration/cache preservation and external cleanup;
14. remaining D2/C2 work and evidence limits;
15. continuation capsule no longer than 1,000 words.

Success authorizes only a fresh independent read-only audit of the exact
uncommitted D1 candidate. It does not authorize commit, publication, D2, C2,
migration `0005`, live provider/supplier work, Git effects, RW0-E, Bridge, or ES
integration.
