## Disposition

**Proceed to a fresh independent read-only re-audit of the exact repaired V4 candidate. Do not stage, commit, or begin D2.**

The closeout reports a complete repair within the authorized eight paths and successful execution of all twelve final validation groups. The other 38 candidate files—including every document, the B1 version-3 registry and its projections, and the retained process-supervisor fixes—remained unchanged. **No additional repair or scope expansion is indicated before independent inspection.** Pasted text

This establishes re-audit readiness, not implementation acceptance. The critical question is now whether the stronger capture and handback invariants reject the demonstrated defects **without losing truthful failure evidence or weakening the existing authority chain**.

## What the repair appears to establish

### Capture validity now belongs to the complete value

The reported capture contract is no longer an unchecked outer wrapper. It requires an exact tuple of three exact entry records, fixed path order, exact `100644` modes, bounded immutable before/after bytes, and one correctly identified changed entry. The same owner validation runs at construction and consumption: handback admission, `blobs()`, capsule construction, and independent capsule verification. Pasted text

That is the right ownership arrangement. The re-audit must independently prove both boundaries:

```text
ordinary construction/replacement
    rejects malformed nested contents

forged exact wrapper supplied to a consumer
    is revalidated rather than trusted by outer type
```

The actual-return injection matters most. Codex reports that a nested open run, arbitrary object, or live state-root `Path` now causes rejection, removes only the failing invocation’s newly owned state, and leaves the original injected run available for normal close. The auditor must reproduce that behavior, not merely confirm that `repr` conceals the object. Pasted text

The test boundary should remain precise: authorized repository-relative paths are legitimate data, and captured bytes remain opaque. This does not call for pathname scanning, a new serializer, or a general Python-object security framework.

### Handback reasons now have explicit evidence requirements

The closeout provides a finite reason/prefix matrix rather than only a reason allowlist. In particular:

| Reason | Reported constraint |
|---|---|
| `invalid_input` | No later-stage evidence |
| `planner_frame` | Earlier durable evidence plus a started, successful, cleaned-up planner process; no later selection or worker evidence |
| `worker_start` | Earlier selected/phase evidence plus an exact failed-launch observation; no successful worker, Wire, or capture evidence |
| `capsule_mismatch` | Validated capture retained, manifest absent |
| `workspace_cleanup_unresolved` | Retains legitimately reached evidence while explicitly withholding a workspace-cleanup claim |

The runner also reportedly distinguishes failed starts before applying the cleanup predicate, avoiding the earlier temptation to convert a legitimate failed-launch observation into a generic durable conflict. Pasted text

**The matrix must not become its own oracle.** The independent auditor should derive permissible combinations from the owning contracts and actual runner construction sites, then compare that derivation with the production predicates and fixed tests.

The broad `durable_conflict` and `process_cleanup_unresolved` rows deserve particular attention. Enumerating prefixes is better than accepting arbitrary evidence, but the auditor still needs to establish why each admitted prefix is legitimate. Conversely, removing a field can sometimes yield another valid shorter prefix under a broad reason; the corrected test assertion described in the closeout is not automatically a weakening. Its validity depends on those actual construction sites. Pasted text Pasted text

This remains validation of a transient evidence projection—not a second program-state ledger and not proof that a claimed history actually occurred.

### The Wire helper now claims independent enforcement

The reported Wire amendment rejects the demonstrated module-level value export and direct, aliased, or nested dynamic-loading forms through the Wire helper itself. The permitted consumer and existing symbol restrictions remain unchanged. Pasted text

The re-audit should exercise those cases directly without relying on B1 to reject them first. The finding remains a **guard-adequacy issue**: the prior audit did not demonstrate a production dynamic loader or a complete-suite escape.

The six final-byte transformed copies are useful implementation evidence. They reportedly detected removal of capture-constructor validation, deep handback consumption, stage checking, truthful worker-start handling, and the two Wire restrictions. They still require independent reproduction. Pasted text

## Provenance and validation reconciliation

The candidate remains **29 modified tracked files and 17 untracked additions** against the same merged baseline.

```text
HEAD:
0d0926e3a483a3ab1a4fd597ac0495927352bf35

Baseline tree:
45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4

Final replacement identity:
4,494,176 bytes
a79100018f014351a18cf5fb21464c6b26ac0e9bd2de94f1268d57e66857a236
```

The eight reported payload increases total **28,674 bytes**:

```text
4,465,502 + 28,674 = 4,494,176
```

I checked the complete row-component arithmetic while preparing the handoff. That corroborates the receipt structure; it does not reproduce the aggregate hash without the live candidate bytes. Pasted text

The principal final validation results are:

| Gate | Codex-reported collected / passed |
|---|---:|
| D1 runtime and integration | 104 / 104 |
| Wire | 135 / 135 |
| Legacy guards | 1,773 / 1,773 |
| Remaining changed owners | 679 / 679 |
| Complete repository | **8,966 / 8,966** |

All twelve groups reportedly ran serially from the final clone. The full-suite increase reconciles as:

```text
8,942 + 12 additional D1 tests + 12 additional Wire tests = 8,966
```

The report also accounts for the Group 2/3 and Group 7/11 overlaps, the three existing fork warnings, unchanged clone endpoints, complete live-cache metadata preservation, and external cleanup. Pasted text

**Those are implementation results.** The preceding blocked audits did not complete the broader independent durable-readback/recovery, transformed-copy, and twelve-group acceptance obligations. The next audit must finish them before returning acceptance; matching inventory hashes or citing this full-suite result cannot substitute for execution. The closeout correctly preserves that limitation. Pasted text

## Independent re-audit handoff

Start a **fresh parent-only read-only Codex conversation**, select the highest exposed reasoning setting, and attach nothing.

:chatgpt-content-reference{index="11"}[Download the complete repaired-V4 D1 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V4_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_D1_Offline_Process_Capsule_Spine_Repaired_V4_Independent_Reaudit_Prompt.txt

Bytes:
53,795

SHA-256:
48d7d23f3ad0cc868b5accaa391b1c0132db89dc5888b700c77329414278fed3

Lines:
861

Final newline:
present
```

The handoff contains the **complete final 46-path receipt table**, all twelve exact validation inventories and hashes, and the latest replacement identity. It requires no earlier prompt or historical candidate attachment.

The acceptance path covers the latest capture, reason-stage, and Wire repairs together with the still-required earlier safeguards: creating-process custody, cleanup evidence, frame errors, B1/Wire ownership, actual guarded durable calls and recovery, child isolation, independent capsule reconstruction, and the scoped governance guards. Overlapping specimens can satisfy multiple named obligations with an explicit mapping; they should not become duplicated or open-ended mutation work.

The live checkout remains read-only. Executable audit work is limited to disposable, remote-free external clones. No candidate repair, publication, D2/C2 implementation, supplier activity, or live authority action is authorized.

Possible verdicts remain:

```text
RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE

RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH
```

Acceptance would establish eligibility for a **separately issued commit/publication gate for these exact files**. It would not authorize D2, physical C2, migration `0005`, qualified-source or supplier work, ES/Bridge integration, or RW0-E.

## Evidence boundary

I read the current closeout and issued V4 repair mandate in full. I corroborated all **29 baseline blob identities** against the mounted October 15 snapshot, verified that the 17 additions are absent from that baseline, checked the updated receipt and test-count arithmetic, and reopened the generated prompt to verify its complete table, coordinates, and validation selections.

I did **not** inspect the live repaired source, reproduce its endpoint hashes, or execute repository code or tests. Candidate behavior and the 8,966-pass result remain Codex-reported.

**Sources:** The current V4 repair closeout and issued V4 repair mandate, cited above; the prior re-audit mandate for unfinished acceptance obligations; October 15 Coordinator snapshot for baseline-blob corroboration.

Some older uploads have expired. Please re-upload a specific original when a later byte-level comparison requires it; this handoff needs no historical attachment.

**Confidence:** High on readiness for this bounded re-audit and on provenance bookkeeping. Final runtime correctness, independent validation, and commit readiness remain unresolved.
