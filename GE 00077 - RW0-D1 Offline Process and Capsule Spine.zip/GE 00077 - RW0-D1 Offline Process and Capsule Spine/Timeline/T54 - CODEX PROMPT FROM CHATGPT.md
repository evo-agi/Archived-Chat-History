# RW0-D1 V9 — Exact Accepted Candidate: Commit and Pull-Request Gate

## FIRST REPOSITORY ACTION — live guidance as text, workdir /

Send this gate to the IMPLEMENTATION/PUBLICATION Codex conversation, not the
independent auditor and not a subagent. The first protected repository action in
this newly authorized interval must be this plain-file read from tool workdir `/`:

```sh
python3 -I -B -S - <<'PY_GUIDANCE'
from pathlib import Path
print(Path('/Users/ds/Repositories/Governed Execution Coordinator/AGENTS.md').read_text(encoding='utf-8'), end='')
PY_GUIDANCE
```

Read all guidance, using further plain-file reads if truncated. Then run section
1's filesystem-only opener BEFORE any Git command, clone, test, repository
import, staging or remote contact. Do not begin with generic git status.

Plain-data reading of an externally supplied instruction/attachment is permitted
preparation. Prefer neutral cwd and absolute paths. That exception permits no
Git/index action, repository content/import/script, product state or file change.
A repository cwd alone does not establish any of those actions. Assess actual
operations; do not invent startup hooks or waive a real pre-opening Git action.
If an actual protected action preceded the required opening, stop immediately;
no silent restart, index reset, timestamp restoration or retrospective proof.

## Decision, authority and bounded effects

The cognitive lead accepts the independent audit disposition for the exact V9
candidate below:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE`

This instruction separately authorizes a single publication gate, in order:

1. authenticate the opening local baseline, fixed 46 endpoints and aggregate;
2. perform narrow, fresh authenticated origin/actor/base/topic/policy preflight;
3. stage exactly those 46 files, verify index blobs/modes and the complete tree;
4. validate the staged tree in one fresh remote-free external clone;
5. make ONE local source commit on the existing checked-out trunk_dev;
6. make ONE ordinary non-force push of that exact commit to the specified topic;
7. create/read back ONE open non-draft PR against trunk_dev;
8. preserve all candidate/cache bytes, account for authorized Git transitions,
   clean only owned external resources and return the inline closeout.

There is no further per-step user approval once the entry checks pass. Do not
stop at a new reconnaissance plan. This is publication finalization, not another
audit/repair/design tranche. Broad host permissions do not broaden this gate.

NOT authorized: source/test/document repair or formatting; changing accepted
bytes; any merge/auto-merge/queue/update-branch; remote trunk push; force push;
amend/rebase/reset/cherry-pick/local merge/local squash; live branch checkout or
worktree creation/deletion; tag/release/deployment; dependency installation;
manual CI dispatch; secret export/credential creation/account change; sibling
repository access; subagents; D2 or physical C2/migration 0005/terminal work;
live provider/supplier/enrollment/ES/Bridge/RW0-E execution.

Only offline tests in the external validation clone may run the existing fixed
fake planner/worker and disposable SQLite fixtures. Do not invoke D1 manually
against live checkout, operator state or production credentials. Normal GitHub
publication records/notifications and documented policy-compatible hosting
checks are inherent publication effects; this does not authorize a deployment
or another configured out-of-scope downstream action.

Use highest exposed reasoning. Report visible model/effort/permission posture
or `not visible`; seek no additional account/computer access for hidden settings.
Use existing installed tools and configured credentials through their normal
interfaces; print no token, private key, signer secret or complete credentialed
URL. No delivered patch/report/manifest/snapshot/package is requested. This file
contains the full subject, message, PR text and validation expectations.

### Audit provenance accepted for this gate

The completion auditor reports a valid new pre-Git opening, complete review of
the five amended tests, a predicate-level finite ledger, exact 58-row readback
of the four used durable families with replay preservation, and current focused
positive/mutant controls. It substantiated the twelve-group V9 validation from
an earlier independent interval rather than claiming to run it again.

It inspected that earlier interval's actual first command: a cat of an external
attachment, with repository cwd, but no Git/import/repository content read. The
literal first-action deviation remains procedural nonconformance; it was
explicitly qualified as not demonstrating contamination of the subsequent true
pre-Git preservation interval. This qualification does not apply to older actual
pre-opening git status commands and reconstructs no missing historical metadata.

Audit report artifact SHA-256 (attribution, NOT a transported-file prerequisite):
c11489568dc354f5af443e67706623210661b9889024b9671ae485f050da1c91

The gate does not repeat the causal campaign or broaden its guarantees. Audited
identity is not a runtime authority token. Git alone will own the new commit/ref
facts after their authorized creation. Reports and this gate remain evidence.

## 1. Opening, Git effects and preservation phases

Repository:
`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening:

```text
branch: trunk_dev
HEAD: 0d0926e3a483a3ab1a4fd597ac0495927352bf35
tree: 45c8a5c0cc45cf50d4358c9a811c7bf62c174ae4
sole parent: 630414faa07f4ac39c4a870a9cc44c7f92d46b80
subject: docs: freeze RW0-C2 scope admission provisioning
upstream: origin/trunk_dev
local divergence: 0 ahead / 0 behind (not fresh remote truth)
worktrees: one
index: exactly all 246 HEAD entries; no staged/unmerged path
working differences: exactly 29 modified and 17 untracked candidate paths
active Git operation/sequencer/unexpected lock: none
```

The following data-only opening records the index and known cache before Git.
It creates temporary inspection instrumentation outside the repository. It
executes no Git, candidate module, SQLite operation or test.

IMPORTANT publication distinction: staging and commit are deliberately authorized
index/ref mutations LATER in this gate. The read helper below preserves index
bytes/metadata across EACH read command, but does not incorrectly demand the
pre-stage index persist after authorized staging. Section 5/6/8 checkpoints bind
the expected index/tree after those writes. Original opening.json is immutable;
never overwrite it or use a newly observed state to excuse an unexpected change.

```sh
python3 -I -B -S - <<'PY_OPEN'
import hashlib
import json
import os
import stat
from pathlib import Path

REPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')
AGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'
GUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',
          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}
OVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')

def meta(st):
    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,
            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),
            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,
            'mtime_ns': st.st_mtime_ns}

def regular_record(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('opening_requires_regular_nonsymlink_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_before_read')
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
        if meta(os.fstat(fd)) != meta(before):
            raise RuntimeError('opening_file_changed_during_read')
    finally:
        os.close(fd)
    if meta(path.lstat()) != meta(before):
        raise RuntimeError('opening_file_changed_after_read')
    return {**meta(before), 'sha256': h.hexdigest()}

def index_path():
    dotgit = REPO / '.git'
    st = dotgit.lstat()
    if stat.S_ISDIR(st.st_mode):
        gitdir = dotgit
    elif stat.S_ISREG(st.st_mode):
        regular_record(dotgit)
        raw = dotgit.read_text(encoding='utf-8').strip()
        if not raw.startswith('gitdir: ') or '\n' in raw:
            raise RuntimeError('unsupported_gitdir_pointer')
        pointed = Path(raw[len('gitdir: '):])
        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()
        if not stat.S_ISDIR(gitdir.lstat().st_mode):
            raise RuntimeError('gitdir_not_directory')
    else:
        raise RuntimeError('unsupported_dotgit_type')
    return gitdir / 'index'

def cache_record():
    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'
    st = cache.lstat()
    if not stat.S_ISDIR(st.st_mode):
        raise RuntimeError('cache_directory_missing_or_unsafe')
    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))
    if len(members) != 37:
        raise RuntimeError('unexpected_cache_membership')
    out = {'.': meta(st)}
    for path in members:
        out[path.name] = regular_record(path)
    if meta(cache.lstat()) != meta(st):
        raise RuntimeError('cache_directory_changed_during_read')
    return out

def guarded_environment():
    present = [name for name in OVERRIDES if name in os.environ]
    if present:
        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))
    env = dict(os.environ)
    env.update(GUARDS)
    env['GIT_PAGER'] = 'cat'
    env['PAGER'] = 'cat'
    return env


import datetime
import shutil
import tempfile

guarded_environment()
agents = regular_record(REPO / 'AGENTS.md')
if agents['sha256'] != AGENTS_SHA:
    raise RuntimeError('guidance_not_exact_audited_candidate')
index = index_path()
index_before = regular_record(index)
cache_before = cache_record()
git = shutil.which('git')
if git is None:
    raise RuntimeError('installed_git_unavailable')
gate_root = Path(tempfile.mkdtemp(prefix='rw0-d1-v9-commit-pr-gate-'))
os.chmod(gate_root, 0o700)
print('GATE_OWNED_ROOT=' + str(gate_root), flush=True)
record = {
    'schema': 'rw0-d1-v9-publication-opening-observation',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': str(REPO), 'guidance': agents, 'index_path': str(index),
    'index': index_before, 'cache': cache_before, 'git_executable': git,
    'git_environment': GUARDS,
    'limit': 'This interval only. Later authorized staging/commit may change the index; candidate and cache may not change.'
}
READ_HELPER = "import hashlib\nimport json\nimport os\nimport stat\nfrom pathlib import Path\n\nREPO = Path('/Users/ds/Repositories/Governed Execution Coordinator')\nAGENTS_SHA = '076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6'\nGUARDS = {'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1',\n          'GIT_TERMINAL_PROMPT': '0', 'PYTHONDONTWRITEBYTECODE': '1'}\nOVERRIDES = ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',\n             'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',\n             'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT')\n\ndef meta(st):\n    return {'type': stat.S_IFMT(st.st_mode), 'device': st.st_dev,\n            'inode': st.st_ino, 'mode': stat.S_IMODE(st.st_mode),\n            'uid': st.st_uid, 'gid': st.st_gid, 'size': st.st_size,\n            'mtime_ns': st.st_mtime_ns}\n\ndef regular_record(path):\n    before = path.lstat()\n    if not stat.S_ISREG(before.st_mode):\n        raise RuntimeError('opening_requires_regular_nonsymlink_file')\n    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)\n    try:\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_before_read')\n        h = hashlib.sha256()\n        while True:\n            chunk = os.read(fd, 1024 * 1024)\n            if not chunk:\n                break\n            h.update(chunk)\n        if meta(os.fstat(fd)) != meta(before):\n            raise RuntimeError('opening_file_changed_during_read')\n    finally:\n        os.close(fd)\n    if meta(path.lstat()) != meta(before):\n        raise RuntimeError('opening_file_changed_after_read')\n    return {**meta(before), 'sha256': h.hexdigest()}\n\ndef index_path():\n    dotgit = REPO / '.git'\n    st = dotgit.lstat()\n    if stat.S_ISDIR(st.st_mode):\n        gitdir = dotgit\n    elif stat.S_ISREG(st.st_mode):\n        regular_record(dotgit)\n        raw = dotgit.read_text(encoding='utf-8').strip()\n        if not raw.startswith('gitdir: ') or '\\n' in raw:\n            raise RuntimeError('unsupported_gitdir_pointer')\n        pointed = Path(raw[len('gitdir: '):])\n        gitdir = (pointed if pointed.is_absolute() else REPO / pointed).resolve()\n        if not stat.S_ISDIR(gitdir.lstat().st_mode):\n            raise RuntimeError('gitdir_not_directory')\n    else:\n        raise RuntimeError('unsupported_dotgit_type')\n    return gitdir / 'index'\n\ndef cache_record():\n    cache = REPO / 'src/ge_nwp_coordinator/__pycache__'\n    st = cache.lstat()\n    if not stat.S_ISDIR(st.st_mode):\n        raise RuntimeError('cache_directory_missing_or_unsafe')\n    members = sorted(cache.iterdir(), key=lambda p: p.name.encode('utf-8'))\n    if len(members) != 37:\n        raise RuntimeError('unexpected_cache_membership')\n    out = {'.': meta(st)}\n    for path in members:\n        out[path.name] = regular_record(path)\n    if meta(cache.lstat()) != meta(st):\n        raise RuntimeError('cache_directory_changed_during_read')\n    return out\n\ndef guarded_environment():\n    present = [name for name in OVERRIDES if name in os.environ]\n    if present:\n        raise RuntimeError('unexpected_git_override_names:' + ','.join(present))\n    env = dict(os.environ)\n    env.update(GUARDS)\n    env['GIT_PAGER'] = 'cat'\n    env['PAGER'] = 'cat'\n    return env\n\n\nimport subprocess\nimport sys\nopening = json.loads(Path(__file__).with_name('opening.json').read_text(encoding='utf-8'))\n\ndef immutable_checks():\n    if str(index_path()) != opening['index_path']:\n        raise RuntimeError('index_location_drift')\n    if regular_record(REPO / 'AGENTS.md')['sha256'] != AGENTS_SHA:\n        raise RuntimeError('candidate_guidance_drift')\n    if cache_record() != opening['cache']:\n        raise RuntimeError('live_cache_drift')\n\nimmutable_checks()\nindex_before_read = regular_record(index_path())\nargs = sys.argv[1:]\nif args == ['--check']:\n    print('READ_HELPER_IMMUTABLE_SURFACES_MATCH')\n    print('CURRENT_INDEX_SHA256=' + index_before_read['sha256'])\n    print('Index stage/commit consistency still requires the mandate phase checks.')\n    raise SystemExit(0)\nallowed = {'status', 'rev-parse', 'rev-list', 'ls-files', 'ls-tree',\n           'cat-file', 'diff', 'show', 'log', 'symbolic-ref', 'worktree',\n           'check-attr', 'for-each-ref'}\nif not args or args[0] not in allowed:\n    raise RuntimeError('unapproved_live_read_command')\nif args[0] == 'symbolic-ref' and args[1:] not in (['HEAD'], ['-q', 'HEAD'], ['--quiet', 'HEAD']):\n    raise RuntimeError('readonly_head_query_only')\nif args[0] == 'worktree' and args[1:] not in (['list'], ['list', '--porcelain']):\n    raise RuntimeError('readonly_worktree_list_only')\nfor arg in args[1:]:\n    if arg in ('--ext-diff', '--textconv', '--filters', '--output', '--exec') or arg.startswith(('--output=', '--exec=')):\n        raise RuntimeError('unapproved_output_or_execution_option')\nif args[0] in ('diff', 'show', 'log'):\n    args = [args[0], '--no-ext-diff', '--no-textconv', *args[1:]]\ncommand = [opening['git_executable'], '--no-pager', '-c', 'core.fsmonitor=false',\n           '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(REPO), *args]\ntry:\n    result = subprocess.run(command, env=guarded_environment(), check=False)\nfinally:\n    immutable_checks()\n    if regular_record(index_path()) != index_before_read:\n        raise RuntimeError('index_changed_during_read_command')\nraise SystemExit(result.returncode)\n"

def write_private(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(payload)

try:
    write_private(gate_root / 'opening.json',
                  (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode())
    write_private(gate_root / 'live_read.py', READ_HELPER.encode())
    if regular_record(index) != index_before or cache_record() != cache_before:
        raise RuntimeError('opening_changed_before_first_git')
    print('OPENING_RECORD=' + str(gate_root / 'opening.json'))
    print('LIVE_READ_HELPER=' + str(gate_root / 'live_read.py'))
    print('OPENING_INDEX_SHA256=' + index_before['sha256'])
    print('RW0_D1_COMMIT_GATE_PRE_GIT_OPENING_RECORDED')
except BaseException:
    for name in ('opening.json', 'live_read.py'):
        p = gate_root / name
        if p.exists():
            if not stat.S_ISREG(p.lstat().st_mode):
                raise RuntimeError('unexpected_owned_helper_type')
            p.unlink()
    gate_root.rmdir()
    raise
PY_OPEN
```

Use emitted ACTUAL paths, not guessed names or assumed persistent shell variables.
Before staging, require current index content/metadata still equals opening.json.
Every live Git READ admitted by the helper must use it:

```sh
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> --check
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> status --short --untracked-files=all
python3 -I -B -S <ACTUAL_LIVE_READ_HELPER> rev-parse HEAD
```

The helper is not an OS interlock. It enforces environment per subprocess and
checks guidance/cache plus per-read index equality. It does not stage, commit,
fetch or publish. No outcome marker replaces full fixed subject verification.

Separate authorized Git WRITE commands are specified later. Any necessary local
configuration/remote-URL read not supported by this helper is limited to the
explicit read-only publication preflight below, after opening, with equivalent
command-local optional-lock/lazy-fetch/prompt suppression and no config writes.
Record index/cache preservation around those reads. Do not bypass a failed
helper or inspect unrelated secrets to make a gate pass.

Report one concise opening acknowledgement, then proceed automatically.

## 2. Fixed 46-file accepted candidate

All candidate endpoints: regular nonsymlink OS mode 0644, Git mode 100644, strict
UTF-8, no BOM/CR/trailing whitespace and one final LF. Preserve unrelated baseline
nonexecuting mode 0600 files; do not normalize them. In particular preserve the
known program-initialization test's actual OS mode.

M and C below are fixed classifications RELATIVE TO THE ORIGINAL BASELINE.
At opening C must be absent from HEAD/index and untracked. After staging or commit
it is an addition to that SAME original baseline; do not falsely require it still
be absent/untracked or compare M against the new commit as if it were the parent.

| Parent-relative effect | Repository-relative path | Bytes | SHA-256 | Baseline blob | Encoded component |
|---|---|---:|---|---|---:|
| `M` | `.docs/architecture.md` | 44,056 | `9e8666ac79dd400a143763f31c2ae7a35f775a835ab7eec8ef30bcde3a0b6181` | `f025f29ca543d64b41e3a611c7ef0bd138fdb229` | 44,112 |
| `M` | `.docs/authority-boundaries.md` | 35,881 | `69b6dc690036a7d4c1c4bb6ac66f3f8432b87f61af24c8433dae26b6f1799074` | `60a40210d858f7fc0de188794a6570e515c39f22` | 35,945 |
| `M` | `.docs/autonomous-software-development-operating-model.md` | 40,903 | `93ba96c9197f32c6be425cf1345b60bddcb9b25ccfe172cd9e6a13f412fcb224` | `e3c1b8adde40075da050eefcf555414b2396574f` | 40,994 |
| `M` | `.docs/c2b-durable-development-state.md` | 1,890,378 | `3a8716317d3dba90d23dad911180841b025c518df76924edd24373315e0cc5b2` | `071f871d4b6e683ab2f0d6daed90d567614ffd31` | 1,890,451 |
| `M` | `.docs/durable-state-model.md` | 41,759 | `d6a092984e4e4a4ee7533aa0114337b8a8e701fe545d00336d46dffd564d915f` | `fd380c4920fb133c6be7970974387cc8ca17eb56` | 41,822 |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 34,629 | `a353aadd81f7dd0e4ac8a57e5a3d2682725c90a17b00634353aade08e733ecad` | `8bb9ad0675a21396f5edc19cc15c4a30e9e56f8c` | 34,697 |
| `M` | `.docs/rw0-b2-wire-protocol.md` | 25,395 | `3f8aef6687912a154cd48f409ba1b9d61aa5b96fa9c080b2370763acc075f011` | `e9d4830774d10d99e3e79326187e9b9acb9e2c06` | 25,459 |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 72,084 | `6512a7948f07a9f21d78f1eda833fa3db40fb1b3ba729c3760b210b181a42a9d` | `db27904ec30fa835224d9fce59187e5ad06901aa` | 72,181 |
| `M` | `.docs/rw0-c2-first-live-proof-posture.md` | 16,985 | `c812ebbe342e84cfb7294c030792746027f25f211a1269828b1a2773d1c0280e` | `bf184e13fa11c8642e839a4e1ae41c4b78fa3719` | 17,060 |
| `C` | `.docs/rw0-d1-offline-process-and-capsule-spine.md` | 4,181 | `0e706e5542f180e50768a349016bec3f44f7d9c8a9974a1f2831140b503d7949` | `absent` | 4,265 |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 59,292 | `aabeecd9dd498b937dd1c0ad9f0bfd03c7165cdf10d4ba1b81fa2f149dbd5e7a` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` | 59,373 |
| `M` | `.docs/worker-execution-boundary.md` | 32,115 | `f04e962fbe9bf8c2d7ed37a26bdc998780cbdc830fcccd6ef48168915cc5898d` | `8fe51ce8f24242cfcd0b0091a15dc93a17080502` | 32,184 |
| `M` | `AGENTS.md` | 62,778 | `076bde721eff6f1a632171f24b586e6d823f63b4e819dd2662942a3bfa720ba6` | `6b832d361d50649057f5e05ba2419093407e41c1` | 62,822 |
| `M` | `README.md` | 46,898 | `dfe879cfd680d3a62ec279be46fd96e97b3fdeba19668a8eb72d191b7ad1c4ff` | `0a184e1f4ead53841ccdcd3850fb2d69b3157b59` | 46,942 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_capsule.py` | 3,985 | `54184efb46db9c3cae84941a4cad2800f953c36c52fb8e041defaed2f0f039e9` | `absent` | 4,061 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_planner.py` | 1,461 | `c112f5462507c85ad852e505e831bcf610d989f1f3ef0afc7cb623e3c463bd29` | `absent` | 1,542 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_fake_worker.py` | 3,249 | `969dd4f39bd5ef4031df41813920db17cf752620b4d9356d3727892293640f01` | `absent` | 3,329 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_handback.py` | 14,257 | `4de860eec2bd4a233506bd1b6df48226943ecb63947230089737068d89bb45b9` | `absent` | 14,334 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_offline.py` | 23,206 | `7dfa5346b71237c17977fc2ab64d01e81f8708b3a06e186fc8d97e25d270cd95` | `absent` | 23,282 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_pre_execution.py` | 28,882 | `c5481a7f28f25791e2d1a139d2bf25d5d6d8dad94e54a49ec883159d6c4e8c18` | `absent` | 28,964 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_frames.py` | 5,458 | `68b2925c56faf2a442b06b160e9178015ce4fb55bbe164c84ad97f03fef619ba` | `absent` | 5,541 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_process_supervisor.py` | 12,023 | `cae6310a605e4b5fc55a0068155360ad42fc7a0a7568a1210c45ffd38e07bf2a` | `absent` | 12,110 |
| `C` | `src/ge_nwp_coordinator/_rw0_d1_workspace.py` | 8,893 | `503e68b02ee0a1bd9f97c16106157c57c856b7c9db95a44039576e1b46c45d55` | `absent` | 8,971 |
| `M` | `tests/test_architecture_contracts.py` | 100,517 | `de1a71a6a7ef40dc0ae9509409dd04157e479d3954eafb37e053ef77cb6dcc0b` | `058fe618589edf6955f9f8adafd27fa46572c9ea` | 100,588 |
| `M` | `tests/test_b2a_writer_session_contract.py` | 26,240 | `dce5cbcd9c22578c99c37245ff4bbb3e7999f426a55eea556e5a442661a3a7c1` | `3ebd80e2de15c27bb0773fc1d60f54de6c16031f` | 26,316 |
| `M` | `tests/test_b3a_persistence_contracts.py` | 37,353 | `8ecb6009323ae3ff2bcf54ad31474b7c4092b9d431b9268b89a15d109a64f973` | `fb76cff63afbb8f843d7dfbe4657a15495937ba3` | 37,427 |
| `M` | `tests/test_c2a_nonimplementation.py` | 29,764 | `cb4ef9a9255446e3b77af6dbc42563c7c3ca53128093e3ba5e58c57d73a2365d` | `afced8910b71197e6ee3ecc232f078a908fe15f9` | 29,834 |
| `M` | `tests/test_c2b0_durable_state_contract.py` | 885,966 | `1e852752b5cddb67b3cb47a9b943273f0701d480679ac315b3a4bf67a97dcf09` | `1497d043a2fe874427c86cce4249cd2d8e80aed7` | 886,042 |
| `M` | `tests/test_post_execution_pure_owner_boundaries.py` | 17,931 | `dc03d4a10a28e08afe900d2d4586177020cfcde5a7b553932dcc3b0ef8618525` | `84fed0a0e504d0363f116399ff1e301e7d4c3973` | 18,016 |
| `M` | `tests/test_runtime_non_authority.py` | 47,074 | `8874df69e3a621b9a4bf4ad08e2bb014cd0c0ae1f1105eeacae1008ecdc68c3c` | `ccb24ef91472de5af55fe0ff0348e71c3e83c664` | 47,144 |
| `M` | `tests/test_rw0_b1_boundaries.py` | 51,392 | `88eb35d2c0644227c4b8a8276286b69846a25c1a67d158bcc093afd189343967` | `06266f08770b3d4efa77f26aff0b1e7ecadf46f1` | 51,458 |
| `M` | `tests/test_rw0_b2_capability_boundaries.py` | 50,244 | `cadcb41f652a539b5e2ac50ca6fe0bc192e321a663ac338ff9a2516d7d0b5844` | `b61f1744059a87988bff7bde032f3b578a554b18` | 50,321 |
| `M` | `tests/test_rw0_b2_wire_boundaries.py` | 37,866 | `08d0a091ec3383185683f5cab974f7fb08a4fad73e23ef0454f66c4953c4558a` | `2ee82288a389f60d9ea71bebc8152ef10123794c` | 37,937 |
| `M` | `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py` | 120,405 | `44089176794734a285afd3852c97fddcfd073fb6d99d2d68667b91952d392921` | `d4b0635567274fc6ee4502dff24efca66d47c45c` | 120,505 |
| `M` | `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` | 247,224 | `4d8df19ee86cb07f5b183524dc8b3a15ad6443b61cb7cb5009fa1b9d4f20c1c5` | `6e315d797f8c6c5d991b2cc7b38981a800f04da0` | 247,326 |
| `C` | `tests/test_rw0_d1_handback_values.py` | 26,977 | `bdf1f78b9a359dfbc36c768e8bb44b2151de8bcaf74046401e4f8a9c20d73807` | `absent` | 27,048 |
| `C` | `tests/test_rw0_d1_offline_integration.py` | 53,116 | `21796d33330e62b4a389207063022e44c5458a4fe847e509f33d247b65b80afe` | `absent` | 53,191 |
| `C` | `tests/test_rw0_d1_planner_process.py` | 1,932 | `c5e4255bbfd6fbdb4fd26e1c420cbee58558cac653c92e85d480b98a3c126d00` | `absent` | 2,003 |
| `C` | `tests/test_rw0_d1_process_frames.py` | 4,263 | `2e5c11e6f52016c3787c4b29975faa0f64b6a4d63359ea341133c17812a0e6b0` | `absent` | 4,333 |
| `C` | `tests/test_rw0_d1_process_supervisor.py` | 13,969 | `7e7c22aed082926936454a128c712e44a26cb51e2d8ff75b54fbf5a79b2564e5` | `absent` | 14,043 |
| `C` | `tests/test_rw0_d1_worker_process.py` | 1,482 | `2b63a7e21512a528263739923020fe7ebef94ea3fbf9ae505a1edd6824ddfb77` | `absent` | 1,552 |
| `C` | `tests/test_rw0_d1_workspace_capsule.py` | 9,390 | `381ff379133bacd6264942cfea26af0cdf8ddbfdb424f77ea9e82fb9d6ad2264` | `absent` | 9,463 |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 176,999 | `1118eed1b5ac8073a19bd46cf7abde4927d65ca6fb9bbe7275facbdd408a11d1` | `49e812ef8fca792f8723ecc3db794496d3bac583` | 177,087 |
| `M` | `tests/test_sqlite_b1_runtime_boundary.py` | 7,913 | `790a1916ce545667191ae65f4f8f4cff88ef2dfc1c7eaf5953fa6bfab936aa99` | `c6f18c8f41c232fb9d57eeef4b5743a21acb9bad` | 7,988 |
| `M` | `tests/test_sqlite_b2c_writer_session.py` | 70,891 | `0224a3019fe7fd500477a20f7736f9a40e5a6512daf99a587dd0fbfa0232b1fd` | `679ff23e289aa6776ed90d164a3d7f61fd96c671` | 70,965 |
| `M` | `tests/test_sqlite_backend_b0_contract.py` | 26,328 | `de3d68022d39b09900d66509b59f5fafe1e0399821548fc1cef81c2895691b45` | `4bcae7d149e65bbb2aa7d8164c11acb8db3e49bd` | 26,403 |

Read each of the 29 baseline blobs directly and match its OID. Require all 17
creations absent in opening HEAD/index. Check all 217 noncandidate tracked paths
against baseline bytes and Git modes. Baseline 246 + 17 creations = 263 final
file entries. No other path, deletion, rename, submodule, symlink or executable
bit is admitted. The live cache is not part of these 263 source endpoints.

Preserve every existing source/semantic/durable owner, package export,
__init__.py, pyproject.toml, .gitignore, StateStore, configuration and migration
0001-0004 bytes. Exactly nine D1 source additions; migration 0005 absent. No
status normalization or publication-fact update to docs is allowed by this gate.

### Exact accepted replacement stream

Calculate twice from fresh data reads without importing candidate code:

```text
prefix = ASCII RW0-D1-BINARY-REPLACE-V1 followed by ONE NUL byte (25 bytes)
for each candidate row in UTF-8 repository-relative path order:
    u16be(path_utf8_length)
    path_utf8
    one ASCII byte M or C
    u32be(0o100644)
    20 raw ORIGINAL BASELINE blob bytes, or twenty zero bytes for C
    u64be(final_payload_length)
    exact final file payload bytes

46 rows: 29 M / 17 C
encoded row bytes: 4,557,431
prefix: 25
total: 4,557,456 bytes
SHA-256:
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

A streaming and a concatenating calculation are suitable. This is raw payload,
not a digest-string manifest. Use the SAME original-parent-relative recipe for
working, staged and committed blobs. Ordinary git diff remains useful for scope
and whitespace, but no different diff hash replaces the accepted identity.

Stop before staging on any fixed baseline/path/blob/mode/size/hash/aggregate
mismatch: `AUDIT_PROVENANCE_MISMATCH`. Do not repair or adopt another subject.

## 3. Fresh origin, actor, policy and external-effect preflight

The intended origin identity is:
`github.com/evo-agi/Governed-Execution-Coordinator`

Expected established GitHub actor: `SeritArbores`. Treat this as a condition to
verify freshly, not a claim of current authentication. Use only configured
existing access through installed Git/gh/API tooling. No login, new token,
credential file read, private-key export, account switch or permission change.
If the expected operator identity no longer applies, stop rather than infer a
replacement from display names.

Exact topic:
`codex/rw0-d1-offline-process-capsule-spine-v1`

Exact base:
`trunk_dev` at `0d0926e3a483a3ab1a4fd597ac0495927352bf35`

After local authentication and BEFORE staging:

- Read configured origin fetch/push URL identities and relevant push config as
  data; require the intended repository and no mirror/unintended extra target.
  Redact any embedded credentials. Do not change configuration or source branch.
- Fresh authenticated readback of repository/actor and remote trunk must match
  the expected base and identity. Do not use a local tracking ref as remote truth.
- Require the exact topic ABSENT and no existing open/closed/merged PR for that
  exact head in this repository. Do not select a new topic or reuse another PR.
- Read effective rules for base/topic, including signing, PR route, review/check
  requirements, attribution, thread resolution, queue/bypass and deletion policy.
  Historical ruleset IDs and empty check inventories are not current authority.
- Separate eligibility to publish a topic/open PR from readiness to merge. Do
  not wait for merge approvals/checks unnecessarily when publication is allowed;
  never treat clean/mergeable or empty checks as CI success or permission to merge.
- Inspect relevant existing workflow and active webhook metadata for triggered
  effects. Do not expose secrets/URLs or invoke a webhook. If this push/PR would
  trigger an out-of-scope deployment or ambiguous prohibited side effect, stop.
  Normal hosting notifications/audit logs and policy-compatible check execution
  are inherent permitted publication effects; no manual workflow dispatch.
- Inspect effective local hooks, attributes/clean filters, signing configuration,
  and configured author/committer identity as data. Do not execute hooks/filters
  during inspection, disable them to get a pass, or change identities/config.
  An active unreviewed hook/filter that could modify bytes or perform out-of-scope
  actions blocks staging/commit/push. Stage must not invoke hidden source code.
  Existing configured noninteractive signing may be used only through normal
  Git if required; never read/export signer material or invent a signature claim.

Use bounded authenticated read-only API requests with complete pagination as
needed. No unrelated repository/org/secret enumeration. The current gate itself
makes no GitHub write before its explicit push/PR steps.

Any base movement, unexpected topic/PR, actor mismatch, local drift, missing
required evidence or incompatible policy stops before mutation with
`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_COMMIT_GATE_BLOCKED`.
No fetch, rebase or candidate adaptation is authorized.

## 4. Stage exactly the accepted endpoints once

Recheck opening index/cache, HEAD, worktree shape and exact accepted bytes just
before staging. Use the EXACT 46 relative paths from the table; no dot, wildcard,
add -A, intent-to-add, unrelated file, force-add of ignored material or submodule.
A gate-owned NUL-separated path list outside the repository is permitted.

The authorized command form (replace only actual external path):

```sh
env GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 \
  PYTHONDONTWRITEBYTECODE=1 \
  git --literal-pathspecs -c core.fsmonitor=false -c gc.auto=0 \
  -c maintenance.auto=false \
  -C '/Users/ds/Repositories/Governed Execution Coordinator' \
  add --pathspec-from-file=<EXACT_46_PATHS_NUL_FILE> --pathspec-file-nul
```

Staging/index and blob-object writes for this command are authorized. Do not
reuse the old read-only audit helper that demands the original index after a
write. Do not suppress a poststage mismatch or call it expected simply because
staging was allowed.

## 5. Staged index, blobs and tree checkpoint

Before executing tests or committing, independently verify:

- index has exactly 263 stage-0 regular entries, all expected paths/modes;
- exactly 29 M + 17 A relative to original baseline, no other effect;
- all 46 staged payloads equal the table's size/SHA-256 and working bytes;
- all 217 unchanged staged entries equal original baseline blobs/modes;
- cached and working whitespace checks pass; no unstaged/untracked extras remain;
- original HEAD/branch/tracking ref unchanged; one worktree; no conflicts;
- cache directory and all 37 members remain original-opening exact.

Use direct index blob reads (e.g. cat-file on the stage-0 OIDs), not a diff
summary or the working file as a substitute for staged bytes. Reconstruct the
fixed replacement stream from STAGED payloads and original baseline coordinates.
Require the accepted size/hash exactly. Any clean/EOL/filter transformation of
an accepted payload is a mismatch, not permission to accept new bytes.

One ordinary `git write-tree` with the same command-local environment is
permitted after these checks. Record the exact tree OID, complete leaf inventory,
and each changed blob OID. The expected tree is measured from the verified index;
do not invent it from SHA-256 receipt strings. All 263 entries must be accounted
for. Store a separate immutable poststage index content/metadata observation.
Do not overwrite opening.json.

From this checkpoint until commit, the staged tree/index and all working/cache
bytes must stay unchanged; live read commands must not refresh the index.
Failure leaves the staged candidate intact for a bounded report. No automatic
unstage/reset/repair is authorized.

## 6. Validate the exact staged tree once

This gate requires ONE fresh full repository collection/execution from staged
bytes. It does NOT repeat the independent causal audit or all twelve overlapping
focused executions. The prior accepted twelve-group independent evidence remains
part of the accepted audit, accurately labeled with its qualified interval.

Build a fresh local-only external clone of the ORIGINAL baseline; clone remotes
must be removed before execution. External checkout/population is authorized
only inside the positively owned gate root, never a live checkout change. Use
local objects, no fetch, installed dependencies only, no copied live cache.
Populate the 46 candidate paths from the verified INDEX BLOBS, not from a new
working-tree edit or separately reconstructed approximation. Verify all 263 file
endpoints against the complete staged tree before and after tests. Respect
source actual modes; no executable or new repository artifact is allowed.

Independently match all twelve supplied static test inventories below to detect
wrong overlays. This step is inventory authentication, not twelve test runs.

Required runtime: installed Python 3.13 and pytest, as in the accepted validation.
Record exact versions, without installing or switching dependencies to make a
mismatch disappear. Test-process umask 022; owned TMPDIR; disabled bytecode and
pytest cache; precreated distinct basetemp parents; no xdist/overlap/network.

From the fresh staged-byte clone run exactly, with NO test-path selector:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<OWNED_TMPDIR> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<OWNED_BASETEMP_COLLECT> --collect-only

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src TMPDIR=<OWNED_TMPDIR> \
python3 -B -m pytest -q -p no:cacheprovider \
  --basetemp=<OWNED_BASETEMP_RUN>
```

Require 124 test modules, 9,005 unique collected node IDs and 9,005 passed.
Preserve full IDs including parameter text with spaces. No test removals,
skip/xfail, selector changes, warning suppressions or invented count-based pass.
The complete-file inventory must be:

`7a38fcc5abe95d0ee818ea73649b75a9cabcb3298aab6c62974e14d224bb12fd`

Only the three existing Python 3.13 multithreaded-fork DeprecationWarning records
are expected, from these exact tests:

```text
tests/test_sqlite_b2c_writer_session.py::test_operation_guard_close_waits_and_retains_authority_until_exit
tests/test_sqlite_b2c_writer_session.py::test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
tests/test_sqlite_b2c_writer_session.py::test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
```

Capture structured warning records and report full-scope results. An unexpected
warning/failure or unsupported required process/fork/hard-link evidence is a
block, not a permitted source fix. A positively identified external driver/setup
error may be corrected externally; rebuild the same staged-byte clone and rerun
every affected collection/execution. Interrupted or pre-edit runs receive no
final gate credit. Do not rerun a passing final suite merely for a new label.

After all test processes exit, classify fixtures by lstat; open/hash regular
files only and follow no symlink/FIFO/socket/device. Remove only owned test roots
once processes are reaped and groups clear. Preserve the gate's opening/checkpoint
records until final readback. Recheck the live staged checkpoint, fixed candidate,
cache equality and HEAD. A change invalidates the gate rather than authorizing
restaging or another candidate.

### Static group memberships and prior audit references (not twelve new runs)

Each token expands to tests/test_<token>.py. Group 12 has no path arguments.
For inventory hashing, sort paths and append u32be(path byte length), path UTF-8,
and raw SHA-256 of that file. All expected hashes are fixed, not recalculated as
new expectations after a mismatch.

```text
1: rw0_d1_handback_values,rw0_d1_offline_integration,rw0_d1_planner_process,rw0_d1_process_frames,rw0_d1_process_supervisor,rw0_d1_worker_process,rw0_d1_workspace_capsule
2: c2b3_private_atomic_program_initialization,c2b3_private_program_initialization_delegation,c2b3_program_initialization_contract,c2b3_program_initialization_recovery,c2b3c_author_effect_contract,c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
3: c2b3d_author_effect_establishment_contracts,c2b3d_author_effect_establishment_recovery,c2b3d_private_atomic_author_effect_establishment,c2b3d_private_author_effect_delegation
4: section41_cognitive_proposal_row_values,section41_cognitive_proposal_semantic_values,section41_pre_execution_plan_disposition_contracts,section41_pre_execution_plan_disposition_recovery,section41_private_atomic_pre_execution_plan_disposition,section41_private_pre_execution_plan_disposition_delegation
5: rw0_c1_mutation_contracts,rw0_c1_private_atomic_persistence,rw0_c1_private_readers,rw0_c1_reader_contracts,rw0_c1_recovery,rw0_c1_row_values,rw0_c1_semantic_values,rw0_c1_writer_session_delegation
6: worker_execution_semantic_boundaries,worker_execution_semantic_relations,worker_execution_semantic_values,worker_execution_semantic_vectors
7: rw0_b2_wire_boundaries,rw0_b2_wire_cancellation_control_boundaries,rw0_b2_wire_cancellation_control_relations,rw0_b2_wire_cancellation_control_values,rw0_b2_wire_codec,rw0_b2_wire_relations,rw0_b2_wire_values
8: rw0_b2_capability_boundaries,rw0_b2_capability_relations,rw0_b2_capability_values,rw0_b2_capability_vectors
9: rw0_c2_bootstrap_acceptance_guard_semantic_contract
10: b2a_writer_session_contract,b3a_persistence_contracts,post_execution_pure_owner_boundaries,rw0_b1_boundaries,rw0_c2_durable_progression_decision_semantic_contract,sqlite_b1_runtime_boundary,sqlite_b2c_writer_session,sqlite_backend_b0_contract
11: architecture_contracts,c2a_nonimplementation,c2b0_durable_state_contract,runtime_non_authority,rw0_b2_wire_boundaries,rw0_remote_contact_phase_entry_contract
```

| Group | Files | Prior independently supported collected/passed | Fixed test-file inventory SHA-256 |
|---|---:|---:|---|
| 1 D1 | 7 | 115 / 115 | `0c70dea0b7595604dbf971c7013d09ede34d1cef3d1947cce815b918d60be4db` |
| 2 program | 9 | 218 / 218 | `1d6cf2891d9dd6fd42bd2b9ad7dd2ca7d96e33d3b5748dd55e7bd0a728732d10` |
| 3 author effect | 4 | 46 / 46 | `90e22f5b34bc2de648629d169afe047527b7d39fec095f4805ffa8e1b31d7ea8` |
| 4 Section 41 | 6 | 168 / 168 | `522db858cbe16146f82c29c90065b533dcf62b43dd5a25fb2abd9814f1d51f55` |
| 5 C1 | 8 | 109 / 109 | `22ddac970f5dc03a037fa9930d2527fc0ada2daa764fc0853b288dd683bf1825` |
| 6 worker semantics | 4 | 135 / 135 | `779e732cd2a9832e2f2c92198857daba044d3c2e867134c57aae6d1bc2bb2346` |
| 7 Wire | 7 | 135 / 135 | `db47aa909711d850902d8f46ea0d2f7d19474b250315505ac0be0c0397979c54` |
| 8 Capability | 4 | 70 / 70 | `21280c9b75f1f81aadad5c1f7bffefe3d0b08b69ded16ba22c4d8005e8b58758` |
| 9 bootstrap guard | 1 | 297 / 297 | `be2891c09719962ad4675a16d69cf5d1b8f56eb21222dad99f17503dac861acc` |
| 10 legacy guards | 8 | 1,783 / 1,783 | `64725a98efcefc787e5caa67d42229bcf1963d5c45a8ddf3c38b6232b560ebaa` |
| 11 changed owners | 6 | 679 / 679 | `d4fc31d0662cafd03ba352db8f9a0abaf8e308444afb6748a3eee1c08d1e4986` |
| 12 full repository | 124 | 9,005 / 9,005 | `7a38fcc5abe95d0ee818ea73649b75a9cabcb3298aab6c62974e14d224bb12fd` |

Prior audited G2/G3 overlap = 46, G7/G11 = 31, G1-G11 union = 3,678, all in G12.
Those are prior audit facts, not newly executed focused-gate claims here.

## 7. Final commit-entry recheck

Immediately before commit, freshly reconfirm remote base/topic availability and
applicable policy, local staged tree/working bytes/HEAD, cache and absence of
concurrent work. Do not commit onto a moved local or remote base. Do not turn a
long validation interval into permission to skip rechecking.

Only after staging equality, the full staged-byte suite, policy and final local
checks pass may the source commit be created. Standard API reads are permitted;
no remote write yet. No extra post-audit doc edit or publication annotation.

## 8. One exact local source commit

Create exactly ONE commit on the existing checked-out local trunk_dev. Do not
create/switch to a local topic branch; follow the current one-source-commit
publication convention. The remote topic is created by the later explicit push.

Use the exact message below, one final LF, no added trailer/co-author/PR suffix:

```text
feat: add RW0-D1 offline process and capsule spine

Add one private artificial offline invocation through the existing guarded
program initialization, author-effect, Section 41 selection, and RW0-C1 phase
owners, with separate deterministic fake planner and coding-worker processes.

Bound process lifecycle, child inputs, workspace mutation, parent-owned capsule
construction and independent verification. Return transient typed evidence with
separate creator-process-fenced disposable-state custody, not shadow program
truth. Preserve the existing durable and pure semantic owners.

Include the reviewed status/consumer updates and permanent causal safeguards.
The independent V9 audit qualified prior evidence and completed its ledger;
publication remains a separate human/Codex effect, not D1 runtime behavior.

No D2 validation/review/model closure, physical C2 decision or acceptance fact,
terminal outcome, migration 0005, live provider/supplier, ES/Bridge integration,
public service/CLI, or automatic Git/publication capability is introduced.

Audit: RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
Audited replacement SHA-256:
53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0
```

Exact raw message: 1222 bytes; SHA-256:
1e328192097185536ea7002562000769bfd1d25562ea97b9cc3bb0ce11b0900e

Create a mode-0600 message file under the gate-owned external root. Confirm its
exact bytes before invoking the one commit. Use configured current identity and
policy-compatible configured signing only. Example command shape:

```sh
env GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 \
  PYTHONDONTWRITEBYTECODE=1 \
  git -c core.fsmonitor=false -c gc.auto=0 -c maintenance.auto=false \
  -C '/Users/ds/Repositories/Governed Execution Coordinator' \
  commit --cleanup=verbatim -F <EXACT_MESSAGE_FILE>
```

This command's index/object/ref/reflog writes are permitted. It may change index
metadata, but its logical stage-0 tree must remain the verified staged tree.
Do not demand original opening index bytes after the authorized commit; do not
permit a changed source payload or unexplained tree change either.

Read the raw new commit, and require:

- HEAD/local trunk_dev = new source commit, with the original HEAD as sole parent;
- tree = the exact verified staged tree;
- exact message bytes/hash, no extra trailers or regenerated text;
- all 263 committed leaf entries match index/working bytes/modes;
- all 46 candidate blob payloads reproduce the fixed parent-relative replacement
  stream; all 217 other entries match the original parent;
- accurate configured author/committer identities and signing status;
- no untracked/unstaged/staged/unmerged remainder; one worktree;
- upstream remains origin/trunk_dev at original baseline; divergence 1 ahead/0
  behind; no direct remote trunk effect;
- original cache content/metadata remains exact.

Save a separate postcommit index/ref observation without overwriting earlier
records. Subsequent remote operations must not alter working/index/candidate
bytes. No amendment or another commit is permitted to fix message/tree drift.

On a commit error or lost response: do not retry. Inspect actual HEAD, raw object,
index and reflog read-only. If exactly the intended sole-parent/tree/message
commit exists and is the checked-out head, verify it and continue only with steps
not yet performed. Otherwise stop with actual effects and preserved state.

## 9. One exact topic push, no trunk update

Re-read base and topic immediately before push. Base must still equal the fixed
original baseline, topic must remain absent, and no matching PR may exist.
Require clean source commit/tree/index/cache and ordinary policy-compatible
publication. Never infer this from opening observations alone.

Perform one ordinary non-force push of the verified source OID:

```sh
env GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1 GIT_TERMINAL_PROMPT=0 \
  PYTHONDONTWRITEBYTECODE=1 \
  git -c core.fsmonitor=false -c gc.auto=0 -c maintenance.auto=false \
  -c push.followTags=false \
  -C '/Users/ds/Repositories/Governed Execution Coordinator' \
  push --no-follow-tags --recurse-submodules=no origin \
  <EXACT_SOURCE_COMMIT>:refs/heads/codex/rw0-d1-offline-process-capsule-spine-v1
```

No force, force-with-lease, broad refspec, tags, upstream rewrite, mirrored push,
remote-trunk push or alternate topic. Preserve every pre-existing remote branch.
This ordinary push is not an atomic remote-base/absence guard. Report that limit
and any observed race rather than claiming a server-side compare-and-set.

Read back: topic equals source OID, base remains original baseline, source
commit/tree and all 263 remote leaf blob OIDs/modes agree with local. Inspect
complete nontruncated tree/paginated responses; directory entries are not file
leaves. No unrelated remote branch update is authorized. Normal hosting-generated
PR refs are not user branch pushes.

On ambiguous push response, do not retry. Bounded authenticated readback may
establish whether the exact topic now exists at this commit. Continue only when
that outcome is conclusive and compatible; otherwise report unresolved or partial
publication. Do not delete an unexpectedly created ref or force it into place.

## 10. Create/read back one non-draft PR

Repository: evo-agi/Governed-Execution-Coordinator
Base: trunk_dev
Head: codex/rw0-d1-offline-process-capsule-spine-v1
Title: feat: add RW0-D1 offline process and capsule spine

The exact UTF-8 body below includes ONE final LF:

```markdown
## Summary

Implement the private artificial RW0-D1 process and capsule spine. One bounded
WorkSpec/fixture invocation uses the current guarded program, author-effect,
Section 41 selection, and RW0-C1 phase paths; launches separate deterministic
fake planner and coding-worker processes; captures one bounded candidate; and
constructs and independently verifies its capsule before returning typed evidence.

The existing Coordinator writers remain the durable authorities. The handback
is a transient projection. A separate creator-process-fenced owner retains only
the disposable-state lifetime needed for the later D2 handoff.

## Audit and validation

The exact 46-file V9 candidate received independent commit-gate eligibility.
That audit combined a new valid preservation interval, complete review of the
five amended tests, a predicate-level causal ledger, current four-family
readback, and explicitly qualified prior independent experiments and validation.
The earlier attachment-read/workdir nonconformance was not erased or called
compliant; its actual operations and pre-Git observation interval were examined.

Audited replacement: 4,557,456 bytes.
SHA-256: 53fdd260c4fda8f43faca354385fa2f33072a06eb96e1130cfaf0c0944216ac0

This publication gate independently validated the exact staged tree in a fresh
remote-free external clone: 124 modules, 9,005 tests collected and passed, with
only the three existing Python 3.13 writer-session multithreaded-fork warnings.
The gate did not repeat the independent mutation campaign.

## Scope limits

This is fake-model/fake-worker offline proof behavior, not competent autonomous
coding, qualified live custody, restart-safe orchestration, or a hostile-code
sandbox. It introduces no D2 validator/reviewer/review-model closure, physical
C2 decision/acceptance family, terminal runtime, migration 0005, live provider or
supplier integration, public service/CLI, automatic publication, or ES/Bridge call.

Selected sequence remains D1, then D2, then physical C2. This PR requests ordinary
review of the exact accepted files. It does not request merge, auto-merge, a queue,
a deployment, or execution of RW0-E.

Audit: RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_ACCEPTED_READY_FOR_COMMIT_GATE
```

Body with final LF: 2235 bytes; SHA-256:
66483c0c6f377c15c3c9f1ce61678675a13094a454ec6017bb3e328f3703051a

The only admitted API representation difference is omission of that ONE final LF:
2234 bytes; SHA-256 912775d9469b87fc5dd96d13acebe31104442c1fd4694b5dd4069f5ed49d97c2.
No other generated text, hidden checklist, trailer, label, assignee, review
request, milestone/project change or automatic action is requested.

Write the request body file only under the owned external root. Verify its hash.
Use one ordinary synchronous create request, base/head/title/body/draft=false,
with no automatic retry. Do not enable auto-merge/queue, merge, update-branch,
approve or resolve reviews, dispatch checks, delete a branch or create a release.

Before create, reconfirm source topic/base and absence of a matching PR. If the
response is lost, read by exact repository/head/base. Do not create again. Only
exactly one open non-draft unmerged PR with the specified identity/text permits
successful completion; report any conflicting state rather than editing it.

Read back and report:

- PR URL, number/node ID, author, OPEN/non-draft/unmerged;
- exact head/source OID and base baseline OID;
- one source commit, 46 complete M/A file effects, exact title/body form;
- remote source tree equals the verified local staged/committed tree, with all
  263 file-mode/blob entries and 217 unchanged parent entries matched;
- no auto-merge/queue/deployment request or unintended metadata action;
- fresh checks/status/reviews/threads as observations only. Empty inventories or
  mergeable/clean do not establish CI success or merge authorization.

Use complete pagination; do not require a PR number before creation or guess it.
Do not block ordinary PR creation merely because its merge checks are pending
when publication policy permits creation. Any prohibitive current rule remains
binding; no bypass or permission widening.

## 11. Final preservation, closeout and incomplete effects

Require closing:

```text
local HEAD / trunk_dev: exact new source commit
local source tree/index/worktree: the exact accepted staged tree; clean
local origin/trunk_dev: original baseline (no fetch/rewrite in this gate)
local divergence: 1 ahead / 0 behind
remote trunk_dev: original baseline
remote topic: exact source commit
PR: open, non-draft, unmerged, exact head/base/text
worktrees: one
candidate payloads: unchanged from acceptance
noncandidate tracked payloads: original baseline exact
live cache directory + 37 members: original opening metadata/content exact
```

The local trunk is deliberately one ahead until the later separately authorized
squash-merge/realignment gate. Do not call it synchronized 0/0. Do not push it
remotely, fetch, reset or update-ref to make a cosmetic closing state.

Reconstruct the fixed replacement from both committed blobs and working bytes,
using ORIGINAL baseline M/C coordinates. Recheck the full 263-entry tree and
no additional file effect. Index may have changed only as allowed by staging and
commit; record its separate opening/staged/committed observations and exact
logical equality. Do not claim whole-interval byte/mtime invariance for an index
this gate intentionally changed. Candidate/cache immutability is required.

Remove only task-owned external roots after all test children exit and groups
clear, scanning with lstat and never following test symlinks or opening special
files. Keep the helper/checkpoints until final local/remote verification, then
remove those owned files/root. No delivered audit/package artifact is required.
If unavoidable residue remains, identify it precisely and block the claimed
cleanup; do not sweep arbitrary /tmp or processes by name.

On failure, preserve every existing accepted file and any completed stage/commit/
remote effect. Do not reset, unstage broadly, amend, force, delete a ref/PR or
retry a possibly completed write. Return the highest effect actually reached.
A deterministic source/test mismatch is not permission for repair in this gate.

## 12. Verdict and inline report

Success:

`RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_COMMITTED_AND_PR_OPENED`

Other dispositions, selected by actual effect:

- `AUDIT_PROVENANCE_MISMATCH`: fixed opening candidate/baseline authentication failed;
- `RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_COMMIT_GATE_BLOCKED`: no source commit was
  created; report whether exact files were staged before the later block;
- `RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_COMMITTED_PUBLICATION_INCOMPLETE`: intended
  local commit exists but push/PR is conclusively incomplete or policy blocks it;
- `RW0_D1_OFFLINE_PROCESS_CAPSULE_SPINE_PUBLICATION_OUTCOME_UNRESOLVED`: a commit,
  push or create response cannot be conclusively reconciled; do not retry it.

Report inline, without a delivered report or another prompt:

1. Verdict/settings, exact opening baseline and approved audit subject.
2. Guidance/pre-Git opening, external-preparation qualification where relevant,
   and exact authorized index/ref transitions rather than false immutability.
3. Fresh actor/origin/base/topic/policy/hook/filter/signing observations; secrets
   redacted, no historical policy claim promoted to current truth.
4. Complete 46-row endpoint accounting: original blob/absence, index blob,
   committed blob, Git mode, payload bytes/SHA-256 and no unexpected effect.
5. All 263 staged/source/remote leaf entries, 217 unchanged parent entries,
   exact staged tree and fixed replacement-stream reproductions.
6. Exact staged full-suite command, collected/passed counts, inventory, structured
   warnings, any trials/corrections/skips, source equality and process cleanup.
   Do not relabel static group hashes as newly executed focused groups.
7. New source commit OID, sole parent, tree, raw message bytes/hash, identity and
   signature status; one commit request and any response-loss reconciliation.
8. Exact push refspec/readback and one PR request/readback: full URL/number/node,
   head/base/tree/title/body identities, reviews/checks observations and limits.
9. Cache/candidate preservation, stage-aware index observations, owned cleanup
   and all actual prohibited non-actions; no fictional global no-mutation claim.
10. Continuation capsule <=1,000 words: exact source/base/tree/topic/PR, remaining
    merge gate and limits. No next-task implementation or merge prompt.

Success publishes the already accepted offline D1 source candidate only. A
SEPARATE merge gate must freshly assess then-current head/base/policy/checks and
perform any permitted integration. D2 planning/implementation follows successful
D1 integration and re-grounding; physical C2 follows D2. None is authorized here.
