Chat 00077 needed a "nudge" from me to continue after T34 of chat `GE 00077 - RW0-C2 Bootstrap Acceptance Guard`, hence `Timeline/T0 - USER.md`. That's not a first, and it's rather annoying.
