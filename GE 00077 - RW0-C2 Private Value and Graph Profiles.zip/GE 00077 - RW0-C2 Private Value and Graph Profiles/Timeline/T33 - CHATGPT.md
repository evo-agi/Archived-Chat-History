## Disposition

**Accept the V7 audit block. Do not stage or commit the candidate.**

The candidate’s provenance is exact: the baseline, all six file receipts, the `512,533`-byte patch, and the `1,381`-byte canonical receipt reproduced independently. No source, migration, export, reader, writer, or runtime surface changed; migration `0005` remains absent. :chatgpt-content-reference{index="0"}

Ordinary validation also remains green:

```text
Private contract:          737 passed
C2 guard and decision:   1,623 passed
B1/C2B2/migration:         458 passed
Architecture/runtime:       77 passed
Deterministic broad set: 4,740 passed
Complete repository:     8,554 passed, 3 warnings
```

:chatgpt-content-reference{index="1"}

This is therefore a semantic and test-causality block, not a repository regression.

## Genuine V7 defects

### Generic current posture is still fixture-specific

The recovery projector no longer accepts a caller-supplied classification, but its classifier decides whether posture is positive by comparing it to the single `FRESH_POSTURE_VECTOR`.

Another well-formed, semantically positive continuity/sole-active posture is therefore classified as `unresolved`, even for an exact complete family or eight proved absences. The normal projector also raises before returning `unresolved` for insufficient but well-formed posture. :chatgpt-content-reference{index="2"}

The repair should introduce a transient validated-posture grammar whose positivity is determined by semantic states:

```text
continuity_state == positively_established
and
sole_active_state == exactly_one_active_authority
```

The refs and digests identify the current evidence but must not have to equal one test fixture. Missing, stale, unknown, conflicting, or negative posture should produce an ordinary `unresolved` result when the posture observation itself is well formed.

### Reversed contrast clauses still bypass the parser

V7 rejects:

```text
Replay may create a new acceptance fact but no new timestamp.
```

but accepts the reversed form:

```text
Replay may not create a new timestamp but may create a new acceptance fact.
```

The second segment begins with a modal and no repeated subject, so the parser loses the inherited `replay` subject. The same weakness survives semicolon and other contrastive forms, including headings, lists, tables, blockquotes, and links. :chatgpt-content-reference{index="3"}

The next parser needs to carry the immediately preceding protected subject into a contrastive segment when that segment begins with a modal or protected action. Polarity must be determined separately for each protected action: prohibiting timestamp refresh cannot cancel permission to create a fact.

### Neutral-subject exclusions are weakly tested

The neutral controls pass, but they do not contain the protected action phrases. Removing the `replay glossary` exclusion therefore still leaves all 737 tests green while producing a false positive for stronger neutral prose. :chatgpt-content-reference{index="4"}

V8 should add neutral controls such as:

```text
The replay glossary may quote the phrase "create a new acceptance fact".
The replay diagram may display a node labelled "create a second receipt".
This receipt documentation can show the example text "refresh a timestamp".
```

These include the protected vocabulary but remain non-authoritative because their exact subjects are neutral compounds.

### Projector override needs integrated protection

A coordinated test-only change can reintroduce a classification override and change its direct test expectation while leaving the private suite green. :chatgpt-content-reference{index="5"}

The repair should add independent signature, unknown-key, AST, and runtime-dataflow checks:

- no `classification` or `expected_classification` input;
- no passthrough keyword map;
- no post-classifier override;
- the actual classifier return must become the result classification;
- an inconsistent supplied classification must be impossible or rejected.

### Structural consequences need end-to-end hostile paths

Each of the thirteen consequence helpers currently examines real structure, but replacing a helper with constant `True` and changing its direct unit test still leaves the entire private suite green. :chatgpt-content-reference{index="6"}

Every consequence therefore needs at least one integrated hostile structure passed through the complete owner-clause validation path. A constant-success helper must then fail those end-to-end tests even if its direct helper test is changed.

## Necessary trust-boundary correction

The audit also changed owner pointers, pointer-purpose tables, consequence identifiers, private prose, and private expectations together. Those coordinated private edits remained green. :chatgpt-content-reference{index="7"}

That observation is valid, but it exposes a limit rather than a fully solvable repository-test defect:

> Two mutable files cannot independently authenticate arbitrary coordinated edits to both themselves.

This is the same boundary V7 correctly adopted for its private-owned vocabulary. The repository verifier should reject one-sided drift and functional bypasses. The fresh independent audit must authenticate the exact authorized:

- owner-pointer inventory;
- owner assertion profile;
- structural-consequence inventory;
- private vocabulary.

Continuing to demand that the mutable verifier prove its own exact immutable contents would create more circular tests without adding authority.

V8 therefore adds a versioned owner-assertion profile and deterministic profile digest for one-sided drift protection, while explicitly leaving coordinated authentication to the independent audit.

## Preserved V7 work

The next repair should not reopen the surfaces that the audit independently found coherent:

- one unified recovery-result grammar;
- exact V1 private vocabulary;
- the thirteen-clause, thirty-seven-assertion inventory;
- all five fresh-write DAGs;
- distinct replay and recovery graphs;
- complete 26-field relation coverage;
- canonical command and family construction;
- static profile and complete receipt-role family;
- no second result, receipt, replay, recovery, or implementation owner. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

## Repair boundary

The narrowest sufficient mutation ceiling remains:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents remain byte-identical. No owner-document, source, migration, existing-test, public-surface, or runtime amendment is justified.

## Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as the sole writer, and use the exact V7 candidate as the opening state.

:chatgpt-content-reference{index="11"}[Download the V8 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V8_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V8_Repair_Prompt.txt

Size:
28,522 bytes

SHA-256:
ee3510525b15f2abc9b8ad09accfec3104b3bd8d17d5f67c6fa1b0ebb1643c0a

Logical lines:
854

Final newline:
present
```

The prompt binds:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Opening six-path patch:
512,533 bytes
c8be598dbdb2881ad9fdd51ec08b90586e86b2db3e4860ef16a9d88ab1787896

Opening canonical receipt:
1,381 bytes
b38d5dcbe70457c2def3c7d42ebdb0583032eb7e52c7c9fea98198b8703e7516
```

It requires:

- semantic posture validation independent of fixture identity;
- alternate valid positive posture vectors;
- normal `unresolved` results for well-formed nonpositive posture;
- no classification-override parameter, input, default, or post-call rewrite;
- actual classifier-return dataflow;
- integrated hostile structures for all thirteen consequences;
- a versioned, digest-bound owner-assertion profile;
- explicit acknowledgement that coordinated private-file authentication belongs to the independent audit;
- contrastive subject propagation in both clause orders;
- per-action polarity;
- strong neutral-subject controls containing protected action phrases;
- preservation of all accepted V7 lifecycle, family, profile, relation, replay, and recovery work;
- deterministic broad and complete regression validation;
- exact member-level cache equality.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V8_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V8_REPAIR_BLOCKED
```

A successful V8 result authorizes only another fresh independent read-only audit. It does not authorize staging, commit, migration `0005`, source-value implementation, provisioning, guarded persistence, readers, recovery runtime, terminal work, public APIs, RW0-D/E, or Execution Substrate integration.

**Source:** Fresh V7 independent re-audit attached in this turn. Its exact next boundary calls for correcting generic positive-posture classification, owner/consequence protections, and reversed protected clauses before any commit gate. :chatgpt-content-reference{index="10"}

**Confidence:** High that the audit block is correct. High on the generic-posture and contrastive-parser repairs. High that coordinated authentication of the two mutable files belongs to independent audit rather than further self-referential repository tests.
