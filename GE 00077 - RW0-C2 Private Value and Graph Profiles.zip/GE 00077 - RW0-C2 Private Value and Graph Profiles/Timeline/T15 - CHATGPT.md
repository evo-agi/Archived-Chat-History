## Disposition

**Accept the audit block. Do not stage or commit the V3 candidate.**

The result is not a provenance failure. The baseline, six path receipts, `239,870`-byte patch, and `1,381`-byte canonical receipt all reproduced exactly. The candidate remains source-, migration-, public-surface-, and runtime-clean. :chatgpt-content-reference{index="0"}

The blocking token is therefore correct:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED
```

Ordinary validation is also internally consistent—**8,127 tests passed with the three expected warnings**—but the hostile audit exposed semantic graph and test-causality defects that the green suite does not detect. :chatgpt-content-reference{index="1"}

## Engineering adjudication

### 1. Receipt-profile cycle and omitted transaction-time edges — accepted as High

The V3 graph is declaratively acyclic only because it omits necessary semantic edges.

The `receipt_graph_profile` contains `receipt_graph_digest`, while the final generic graph digest depends on the profile digest. That means either:

- both fields refer to the same generic graph digest, creating a cycle; or
- they refer to different digests, but the second digest has no defined origin or binding.

The graph also omits the transaction timestamp dependencies required by unchanged v1 decision, version, head, and receipt identities. :chatgpt-content-reference{index="2"}

The correct repair is directional:

```text
branch-specific receipt profile
→ profile digest
→ exact graph members + one transaction timestamp
→ generic receipt graph digest
→ generic receipt value/digest
→ replay and recovery projections
```

The profile must not contain the final generic graph digest.

One post-branch `transaction_timestamp` value should feed every unchanged v1 timestamp-bearing member:

```text
decision.decided_at
program_version.created_at
historical_head.updated_at
receipt/graph.committed_at
```

It remains excluded from the command digest, preassignment transcript, and precommit recovery selector. Replay returns the original timestamp.

### 2. Missing command-relation fields — accepted as Medium

The transcript and command digest cover four continuity and sole-active source coordinates that are absent from the closed `command_relation` schema. The tests currently inject them as unrelated flat fixture keys rather than validate a complete command value. :chatgpt-content-reference{index="3"}

The repair should add the exact four source fields to the command relation:

```text
continuity_source_ref
continuity_source_digest
sole_active_source_ref
sole_active_source_digest
```

Those values remain external evidence coordinates. Adding them does not make historical evidence current permission or local durable authority.

The verifier must build the transcript from the closed relation—not from fixture-only extras—and independently prove that changing every primitive changes the final command digest as well as its six sibling identities.

### 3. Admission-before-branch causality — accepted, with one qualification

The V3 test invokes the C2 interpreter before admission validation. A copied branch result with an unreachable helper call passes, so the test proves only that a call node exists, not that the shared C2 result causally controls the family. :chatgpt-content-reference{index="4"}

The correct ordering is:

```text
verify admission act/fact and command binding
→ call shared C2 interpreter exactly once
→ validate prospective identity
→ form the derived branch family
```

The verifier needs a live sentinel test: replacing the shared C2 helper with a unique exception must prove that valid admission reaches it, while invalid admission fails before it.

A qualification is important: changing an admission act, fact, and command together can describe another valid admitted scope in the generic product model. It is not inherently invalid. The test should therefore use a **fixed independent golden admission vector** to prevent its own fixture from changing its expected truth. That fixed vector is test evidence, not a product restriction on legitimate admission values.

### 4. Route-template self-confirmation — accepted

The contract’s prose and machine grammar now distinguish templates from concrete routes correctly. But the builder, validator, and assertion reuse one `ROUTES` definition, so jointly mutating the machine template and test template remains green. :chatgpt-content-reference{index="5"}

The verifier needs independently authored literals for:

- the eight expected templates;
- the eight expected concrete routes for a fixed selector;
- the prose route table;
- the observed machine inventory.

Concrete expected keys must not be generated from the templates under test. A joint change to the decision route—from `decision_ref` to another same-typed coordinate—must fail against the fixed expectation.

### 5. Acceptance-fact and receipt-family binding — accepted

The current helper verifies a reserved ref and recomputed digest but does not independently bind the acceptance fact’s scope or historical head revision to the family. A foreign scope and Boolean revision survive after resealing the digest. The acceptance test also checks a synthetic role list containing only `acceptance_fact`, rather than reconstructing the complete common family. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

The repair must require exact equality among the admission, command, fact, and canonical family for:

- lineage and scope;
- admission fact identity and digest;
- mutation, decision, and resulting-version identities;
- historical head ref, revision, and digest;
- transaction time when carried;
- fact ref and self-digest.

`historical_head_revision` must be an exact nonnegative `int`, never `bool`.

The receipt graph must reconstruct the exact common role inventory already declared by the branch profiles. Acceptance contains those common roles plus one acceptance role; nonaccept contains the common roles only.

### 6. Prose contradiction scanner — accepted, but should be narrowed rather than made “smarter”

The scanner drops headings and considers only sentences matched by a narrow topic regex. Contradictory headings, bullets, tables, modal variants, split sentences, and subject aliases pass all 310 tests. :chatgpt-content-reference{index="8"}

Trying to build a general natural-language theorem prover would be the wrong path.

The repair should instead establish a bounded normative-language discipline:

```text
NORMATIVE <clause_id>: <closed authority statement>
```

Every authority-sensitive normative block must be tagged and map to one fixed registered clause. The scanner must examine visible Markdown across headings, paragraphs, bullets, tables, blockquotes, and continuation lines. An untagged subject-plus-modal authority assertion fails.

The registry, normalized clause expectations, and document prose must be independently authored so changing the registry and contradictory prose together does not pass.

## Repair boundary

The audit’s recommended next boundary is correct: **two files only**. :chatgpt-content-reference{index="9"}

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents remain fixed:

```text
.docs/autonomous-software-development-operating-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
```

The repair should block rather than widen if closing the graph requires changing a semantic owner, current v1 source, a migration, or an existing test.

## Codex handoff

Resume the **same implementation Codex conversation**, switch the parent to workspace-write, and keep the parent as the sole writer.

:chatgpt-content-reference{index="11"}[Download the V4 semantic-graph and authority-causality repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V4_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V4_Repair_Prompt.txt

Size:
29,554 bytes

SHA-256:
7a668ea11dba6f2b8631e4df7aaebb2b49a7e7bc6a74a4c4bc3d00ffc547d71a

Logical lines:
867

Final newline:
present
```

The prompt requires:

- exact opening V3 provenance;
- a strict two-file mutation ceiling;
- removal of the receipt-profile/final-graph cycle;
- one complete transaction-time dependency path;
- a fully reconciled final graph rather than preserving the stale “66-node” count;
- closure of the four missing command-relation fields;
- command-digest recomputation for every primitive mutation;
- admission validation before the shared C2 interpreter;
- live sentinel proof that the shared interpreter causally controls the branch;
- independent fixed route-template and concrete-route expectations;
- full scope/head/type binding for the acceptance fact;
- reconstruction of the complete common receipt-role family;
- a tagged normative-clause discipline and whole-visible-Markdown scanner;
- at least 56 transformed external challenges;
- focused, broad, and complete repository validation;
- exact preservation of source, migrations, public/runtime surfaces, and the other four candidate documents.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V4_REPAIR_BLOCKED
```

A successful repair will authorize only another fresh independent read-only audit. It will not authorize migration `0005`, source values, admission provisioning, guarded persistence, readers, recovery implementation, terminal binding, public APIs, runtime activation, RW0-D/E, or Execution Substrate work.

**Source:** Fresh V3 independent re-audit. Its final findings are an incomplete/cyclic semantic graph, surviving authority-sensitive prose, unproven admission and branch causality, and an incomplete closed command mapping. :chatgpt-content-reference{index="10"}

**Confidence:** High that the audit block is correct. High that the receipt-profile direction, post-branch timestamp node, admission-before-branch sentinel, independent route expectations, and complete family binding are the narrowest truthful repair. Medium-high that the two-file ceiling remains sufficient; the prompt requires a clean block if current v1 receipt semantics force a wider owner amendment.
