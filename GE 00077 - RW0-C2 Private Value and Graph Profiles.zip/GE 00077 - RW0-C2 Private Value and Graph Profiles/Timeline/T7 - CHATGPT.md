## Disposition

**Accept the audit’s block. Do not stage or commit the six-path candidate.**

The audit reproduced the exact baseline, six file receipts, `70,272`-byte patch, and `1,378`-byte canonical receipt. Source and migrations remain unchanged and migration `0005` remains absent, so this is not a provenance or implementation-boundary failure. :chatgpt-content-reference{index="0"}

The blocking result is narrow:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED
```

The contract still lacks a branch-neutral acceptance-fact identity rule, its recovery selector has an open-ended alias-route grammar, and six prohibited semantic mutations survived the new verifier. :chatgpt-content-reference{index="1"}

No product-policy decision is required. These are ordinary value-contract and recovery-query engineering decisions.

## Engineering adjudication

### 1. The acceptance-fact coordinate must be mandatory for every command

The audit is correct that a nullable `preassigned_acceptance_fact_ref` creates a branch-selection channel:

- null followed by acceptance leaves no preassigned fact identity;
- rejecting that case lets the caller veto acceptance;
- null on nonaccept leaves recovery without a fact collision route;
- non-null on nonaccept currently leaves unclear whether the unused identity must still be checked. :chatgpt-content-reference{index="2"}

The narrowest truthful rule is:

```text
Every guarded command carries one mandatory, non-null,
deterministically derived prospective acceptance-fact identity.
```

That identity is a **reserved collision coordinate**, not a request for acceptance and not proof that a fact exists.

The Coordinator derives and validates it from branch-neutral, precommit-known coordinates such as the admitted lineage and scope, admission-fact identity, mutation reference, preassigned decision/version identities, and deterministic family route. It must not depend on branch, result, receipt, transaction timestamp, terminal state, or postcommit digests.

The authoritative branch then determines only whether the fact is materialized:

```text
candidate_acceptance:
    exactly one fact at the reserved identity

all four nonaccept branches:
    no fact at the reserved identity
    but the identity is still collision-probed
```

This preserves the existing branch owner and closes the caller-preselection problem without introducing another reducer or transaction.

### 2. Recovery needs a closed collision-route inventory

The audit is also correct that unconstrained `alias_routes` cannot support an exhaustive absence claim. A selector cannot prove `definitely_not_committed` if it is free to omit the route where a conflicting or partial family might exist. :chatgpt-content-reference{index="3"}

The repaired selector should contain one exact, ordered, mandatory route for each semantic lookup:

```text
mutation/receipt route
decision identity
resulting-version identity
prospective acceptance-fact identity
guarded family-relation identity
guarded result identity
deterministic family route
admitted-scope competing-winner route
```

Each route needs a closed role enum, exact coordinate source, exact type, and exactly-once cardinality. Missing, duplicate, unknown, null, malformed, foreign, or unreadable routes yield `unresolved`, never proof of absence.

`definitely_not_committed` from total absence requires both:

```text
positive current continuity and sole-active-authority posture
+
exhaustive absence across every mandatory route
```

A different complete winner in the same admitted scope may establish that the original command did not commit, while separately making fresh acceptance ineligible.

### 3. The six surviving mutations are real test gaps

The following prohibited changes passed all 45 contract tests:

- historical continuity evidence becomes current permission;
- caller nullability controls the branch;
- local absence proves noncommit without current continuity;
- replay creates a new fact or timestamp;
- an unadmitted scope becomes command-admissible;
- a null fact coordinate skips its collision lookup. :chatgpt-content-reference{index="4"}

The ordinary suite remains green—`7,862 passed, 3 warnings`—but that does not offset required hostile controls surviving. :chatgpt-content-reference{index="5"}

The repair should add direct branch-neutral truth-table tests, deterministic identity derivation tests, a closed route-inventory verifier, current-posture versus historical-basis tests, and external transformed mutants for all six failures.

## Repair boundary

The narrowest sufficient mutation ceiling is two files:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents should remain byte-identical:

```text
.docs/autonomous-software-development-operating-model.md
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
.docs/rw0-c2-durable-progression-decision-semantic-contract.md
```

The audit found the owner hierarchy, v1 preservation, B1 compatibility, graph-root design, and nonimplementation boundaries otherwise coherent. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

The audit itself prescribes this same next boundary: repair the branch-neutral coordinate, close the alias inventory, strengthen hostile tests, and submit the changed bytes to a fresh audit. :chatgpt-content-reference{index="8"}

## Codex handoff

Resume the **same implementation Codex conversation**, switch it to workspace-write, and keep the parent as the sole writer.

:chatgpt-content-reference{index="10"}[Download the complete V2 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V2_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V2_Repair_Prompt.txt

Size:
23,410 bytes

SHA-256:
0bed4f3367b1a908aec6369599e155dad05b4f7f148c408f550a28c36f87a76b

Logical lines:
684

Final newline:
present
```

The prompt requires:

- exact reproduction of the opening six-path candidate;
- a strict two-file repair ceiling;
- a mandatory, deterministic prospective acceptance-fact identity on every command;
- no caller branch selection through nullability;
- collision probing of the reserved fact identity on every branch;
- a closed, exactly-once recovery-route inventory;
- positive current posture before total absence can mean `definitely_not_committed`;
- direct closure of all six surviving hostile variants;
- additional branch, identity, route, replay, and recovery mutants;
- the focused groups and complete repository suite;
- preservation of all source, migrations, existing tests, public surfaces, and the other four candidate documents.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V2_REPAIR_BLOCKED
```

A successful repair authorizes only another fresh independent read-only audit—not staging, commit, migration `0005`, source values, provisioning, durable persistence, readers, recovery implementation, terminal work, public APIs, or runtime activation.

**Source:** Independent private-value/versioning contract audit attached in this turn. :chatgpt-content-reference{index="9"}

**Confidence:** High that the audit block is correct; high that the mandatory prospective identity plus closed collision-route grammar is the narrowest truthful repair; medium-high that the two-file ceiling is sufficient, with an explicit stop condition if live cross-reference enforcement proves otherwise.
