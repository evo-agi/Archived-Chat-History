## Disposition

**Accept the V8 audit block. Do not stage or commit the candidate.**

The block is narrow and verifier-specific. Provenance is exact: the baseline, all six file receipts, the `547,910`-byte patch, and the `1,381`-byte canonical receipt reproduced. Source, migrations, exports, readers, writers, and runtime surfaces remain unchanged, and migration `0005` is absent. :chatgpt-content-reference{index="0"}

Ordinary validation also remains green:

```text
Private contract:            854 passed
C2 guard and decision:     1,623 passed
Focused B1/C2B2:             458 passed
Expanded B1/C2B2:            926 passed
Architecture/runtime:         77 passed
Deterministic broad set:   4,857 passed
Complete repository:       8,671 passed, 3 warnings
```

The audit preserved exact live-cache equality and removed all temporary material. :chatgpt-content-reference{index="1"}

## The two remaining defects

### 1. Multiline blockquotes lose their subject

The parser removes the `>` marker before deciding whether a line belongs to an existing blockquote. It then tests the already stripped line for `>`, causing adjacent quote lines to become separate visible blocks.

This prohibited statement therefore passes:

```markdown
> Replay may not create a new timestamp but
> may create a new acceptance fact.
```

The first line establishes `Replay`; the second starts with `may` but has lost the protected subject because the parser split the quote. :chatgpt-content-reference{index="2"}

The repair must identify and group quote lines **before** stripping their markers. Consecutive nonblank quote lines at the same quote depth form one visible block. Quoted blank lines and depth changes terminate the block.

### 2. Neutral phrases suppress protected subjects from object position

The parser currently treats a neutral phrase found anywhere in a clause as evidence that the clause has a neutral subject. That allows this contradiction:

```text
Replay may not create a new timestamp but may create a new acceptance fact in the replay glossary.
```

Here `Replay` is plainly the subject; `replay glossary` occurs only in a prepositional object. The neutral phrase must not erase the protected subject. Analogous variants using `replay diagram`, `replay example`, and `replay documentation` also survived. :chatgpt-content-reference{index="3"}

Neutral classification must therefore be **subject-position based**. A phrase is neutral only when it occupies the initial grammatical subject slot, for example:

```text
The replay glossary may quote the phrase "create a new acceptance fact".
```

A neutral phrase appearing later as an object, label, citation, quoted example, or adjunct cannot suppress an explicit or inherited protected subject.

## What does not need to be reopened

The independent audit confirmed the substantive V8 repairs:

- generic posture classification works for distinct positive vectors;
- all well-formed nonpositive posture combinations return `unresolved`;
- projector signature and classifier-return dataflow are closed;
- the seven-field recovery result is coherent;
- the exact owner-assertion profile and vectors reproduced;
- all thirteen integrated structural consequences worked;
- private vocabulary matched the authorized V1 inventory;
- lifecycle, relation, command, family, profile, role, replay, recovery, v1, B1, and nonimplementation boundaries remain intact. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

The audit reconstructed 68 external copies. All expected controls behaved correctly except the multiline-blockquote hostile copy; it also independently reproduced four neutral-object-position bypasses outside that matrix. :chatgpt-content-reference{index="6"}

## Repair boundary

The narrowest sufficient ceiling is now **one file**:

```text
tests/test_rw0_c2_private_value_versioning_contract.py
```

The private-value contract already states the required blockquote/continuation and exact-subject semantics. It should remain byte-identical, together with the other four candidate documents.

No owner document, source, migration, existing test, public surface, or runtime change is warranted. The audit recommends this same exact next boundary. :chatgpt-content-reference{index="7"}

## Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as the sole writer, and use the exact V8 candidate as the opening state.

:chatgpt-content-reference{index="8"}[Download the V9 verifier-repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V9_Verifier_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V9_Verifier_Repair_Prompt.txt

Size:
22,226 bytes

SHA-256:
757cce4cd8152c624641bad30ea8d51c8c0e99cee9c317782d5e0a8ea9ab7f2e

Logical lines:
641

Final newline:
present
```

The prompt binds the exact opening candidate:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Opening six-path patch:
547,910 bytes
79e8c62ec8d96066cdca4d856b5be3706df720a75693d0096d95d0bae77f7225

Opening canonical receipt:
1,381 bytes
669c6c1574e754271bfc958eebacb1eb47541c498254d076e63924ef0bf9c4fb
```

It requires:

- an exact one-file mutation ceiling;
- quote origin and depth captured before marker removal;
- contiguous same-depth blockquote grouping;
- blank-line and nesting-depth boundaries;
- multiline hostile controls for both contrast orders and every supported connector;
- neutral-subject classification only from the initial subject position;
- protected subjects taking precedence over neutral phrases in object position;
- hostile controls for all demonstrated neutral-object variants;
- stronger neutral positive controls containing protected action phrases;
- neutral-to-protected transitions within one block;
- regression preservation of all V8 posture, projector, owner-profile, consequence, lifecycle, family, replay, and recovery checks;
- focused, deterministic broad, and complete repository validation;
- exact member-level live-cache equality.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_VERIFIER_REPAIRED_V9_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V9_REPAIR_BLOCKED
```

A successful V9 result authorizes only another fresh independent read-only audit. It does not authorize staging, commit, migration `0005`, source-value implementation, admission provisioning, guarded persistence, readers, recovery runtime, terminal work, public APIs, RW0-D/E, or Execution Substrate integration.

Some older uploaded files have expired, but they were not needed for this pass. Re-upload any of them only if a later task requires inspecting their original bytes.

**Source:** Fresh V8 independent re-audit attached in this turn.

**Confidence:** High that the audit block is correct; high that a verifier-only repair is sufficient; high that multiline quote grouping and subject-position neutral classification are the exact remaining boundaries.
