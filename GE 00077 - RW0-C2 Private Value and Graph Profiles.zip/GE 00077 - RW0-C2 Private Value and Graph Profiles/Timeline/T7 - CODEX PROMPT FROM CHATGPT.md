# Governed Execution Coordinator — RW0-C2 Private Value Contract V2 Branch-Neutral Identity and Recovery-Route Repair

## Role and objective

Resume the implementation conversation that wrote the uncommitted RW0-C2
private value/versioning and graph-profile contract candidate.

Change the parent permission posture to workspace-write before sending this
turn.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its independent audit returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

The audit established:

- exact baseline and six-path provenance;
- exact patch and canonical receipt;
- no source, migration, existing-test, public-surface, or runtime widening;
- owner hierarchy, closed eleven-value inventory, digest DAG, v1 preservation,
  branch profiles, B1 compatibility, and nonimplementation boundaries otherwise
  coherent;
- one High branch-neutral acceptance-fact identity defect;
- one Medium open recovery alias-route grammar;
- six required hostile semantic prose mutations that survived the 45-test
  contract verifier.

This is a **two-file contract/test repair**. Preserve the selected architecture.
Do not implement source, migration, provisioning, persistence, readers,
transactions, recovery, public APIs, runtime behavior, RW0-D/E, or Execution
Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 29,672 | `f6df461ed255259f4f550e14a53580b25cb13b4e773c9f876ea22b658389d41f` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 34,788 | `4d832275ff980d937d4ef39c12d079324b943166dbbfb22a0c0c4f9d85e09e5c` |

Required opening ordered patch:

- bytes: `70,272`
- SHA-256:
  `3e012b1a82a261bf4310a652078d17b83675ce7acb271e42afba2e1f89eb6e79`

Construct it in lexicographic path order using:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,378`
- SHA-256:
  `66a48768b710a8713d7be1dcf9a1bb9b5c9520b4018b6d0b8c5cab01703a384d`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V2_REPAIR_BLOCKED`

## Exact mutation ceiling

Only these two paths may change from their opening candidate bytes:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

The other four candidate documents must remain byte-identical to the opening
receipts.

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- architecture or C2B documents;
- configuration or examples.

Migration `0005` must remain absent.

If the two-file ceiling is insufficient, restore the exact opening candidate
and return the blocking token. Do not widen the tranche.

## Accepted architecture that must not be reopened

Preserve exactly:

1. The eleven logical private values/profiles and their owner hierarchy.
2. The guard owner controls lineage, scope, admission, continuity,
   sole-active-authority posture, one-shot eligibility, permanence, terminal,
   and ES boundaries.
3. The decision owner controls authoritative branch derivation, generic
   decision/version/head/result/receipt meanings, replay, collision taxonomy,
   and whole-family recovery.
4. Current migration-0002 v1 values remain canonical within unchanged meanings.
5. Admission provisioning and guarded decision persistence remain separate
   semantic owners.
6. Acceptance creates one immutable acceptance fact in the same atomic family.
7. Four nonaccept branches create no acceptance fact.
8. There is one logical result, one receipt root, one replay owner, and one
   recovery owner.
9. Historical continuity and sole-active evidence does not become current
   permission.
10. Current positive external posture remains required before protected replay
    or recovery disclosure.
11. B1 `latch_postimage_*` remains compatibility/nonproof only and is not
    consumed by the guarded decision writer.
12. Physical schema, migration `0005`, readers, writers, transactions,
    provisioner mechanics, public interfaces, and runtime remain future.

This repair closes value rules and test adequacy. It does not redesign the
architecture.

## Finding H1 — branch-neutral acceptance-fact identity

### Problem to close

The opening command relation contains nullable
`preassigned_acceptance_fact_ref`. The branch is derived later by the
Coordinator.

That leaves four unresolved cases:

- null coordinate followed by acceptance;
- non-null coordinate followed by nonaccept;
- null coordinate followed by nonaccept and incomplete recovery routing;
- non-null coordinate followed by acceptance.

A caller must not be able to select, veto, or influence the branch by supplying
or withholding an acceptance-fact coordinate.

### Selected repair

Keep the existing field name unless a document-local schema-version change
requires a clearer name.

For **every** guarded command, including all four nonaccept outcomes:

1. `preassigned_acceptance_fact_ref` is mandatory, non-null, and type-exact.
2. It is a **prospective reserved identity**, not a claim that acceptance will
   occur and not authority to create the fact.
3. The Coordinator independently derives and validates it from a
   domain-separated, branch-neutral, precommit-known identity preimage.
4. The command may carry it only as an expected coordinate assertion.
5. The coordinate is always command-digest covered.
6. The coordinate is always recovery-selector covered.
7. The coordinate is always collision-probed, including on nonaccept branches.
8. Only the authoritative derived branch controls whether a durable fact may
   exist:
   - `candidate_acceptance`: exactly one fact at the reserved identity;
   - the four nonaccept branches: no fact at the reserved identity.
9. Nonaccept absence does not assert that the scope remains unclaimed.
10. Null is invalid command grammar and cannot mean “no acceptance branch,”
    “unclaimed,” or “skip the collision route.”

### Branch-neutral identity derivation

Freeze one exact acyclic semantic preimage in the contract and machine block.

It must use only branch-neutral, precommit-known coordinates already owned by
the command relation and admission binding, including at minimum:

- acceptance-fact schema/profile version;
- canonical lineage;
- bootstrap scope;
- admission-fact ref and digest;
- mutation ref;
- preassigned decision ref;
- preassigned resulting-program-version ref;
- deterministic guarded family route.

It must not depend on:

- authoritative or expected branch;
- result;
- guarded relation or guarded result digest;
- receipt ref or digest;
- transaction timestamp;
- terminal outcome;
- current mutable head after commit;
- raw external attestations.

Choose the narrowest exact ordered preimage supported by the existing machine
contract. Freeze the order, domain separator, canonical type rules, and
derivation/validation relationship.

Do not freeze Python helper names or SQL serialization.

### Role behavior

For acceptance:

- the fact’s actual identity must equal the reserved coordinate;
- the fact remains required exactly once in the branch profile and receipt
  graph.

For nonaccept:

- the fact remains forbidden in the durable family and receipt graph;
- the reserved identity remains mandatory in the command and selector;
- the collision route must still be checked;
- a row or alias occupying that identity cannot be ignored;
- no branch profile may reinterpret the reserved ref as a fact member.

Use the existing decision-owner collision taxonomy. Do not create a new
result/reason owner.

## Finding M1 — closed recovery collision-route grammar

### Problem to close

The opening selector has an unconstrained `alias_routes` field. It does not
define an element grammar or exact mandatory route inventory, so omission of a
route could incorrectly support `definitely_not_committed`.

### Selected repair

Replace the open alias concept with one exact, closed, ordered
`required_collision_routes` grammar, or narrow `alias_routes` to the equivalent
closed grammar.

The selector must carry exactly one route for each semantic lookup below:

1. `mutation_receipt_route`
   - keyed by canonical mutation ref;
   - reaches the generic receipt/replay route.

2. `decision_identity_route`
   - keyed by preassigned decision ref.

3. `resulting_version_identity_route`
   - keyed by preassigned resulting-program-version ref.

4. `acceptance_fact_identity_route`
   - keyed by the mandatory prospective acceptance-fact ref;
   - required on every branch.

5. `guarded_family_relation_identity_route`
   - keyed by its preassigned ref.

6. `guarded_progression_result_identity_route`
   - keyed by its preassigned ref.

7. `deterministic_family_route`
   - keyed by the command-covered family route.

8. `admitted_scope_winner_route`
   - keyed by canonical lineage, bootstrap scope, admission-fact ref, and
     admission-fact digest;
   - observes a different complete winner under the same admitted scope.

If the live machine block has a semantically distinct fifth preassigned
identity or exact generic receipt route that the list above aliases
incorrectly, preserve the same closed intent but reconcile it explicitly from
the owning fields. Report any substitution. Do not add an open extension slot.

### Route element grammar

Freeze exact fields and types for each route element:

- exact route role from the closed enum;
- exact route kind;
- exact coordinate source or ordered key tuple;
- exact expected schema/profile version when applicable.

Require:

- exact route count;
- exact order;
- each role exactly once;
- no duplicate, missing, unknown, optional, null, caller-added, or
  implementation-specific route;
- every route coordinate equals the selector’s canonical top-level coordinate;
- no route depends on transaction timestamp or postcommit-only digest.

The route collection is a query plan value, not durable authority and not a
second collision or recovery owner.

### Absence and result rules

Freeze these value-level requirements:

- `definitely_not_committed` from total absence requires positive current
  continuity/sole-active posture and exhaustive absence across every mandatory
  route.
- An omitted, malformed, unreadable, foreign, duplicate, or unchecked route is
  `unresolved`, never proof of absence.
- Local absence without positive current posture is `unresolved`.
- A different complete winner in the admitted-scope route may prove the
  original command did not commit, while separately making fresh acceptance
  ineligible.
- Exact replay uses the complete original family; it creates no new fact or
  timestamp.
- Recovery does not repair fragments, reevaluate branch, renew scope, or retry.

Do not freeze SQL queries or reader layout.

## Six surviving hostile variants

Add permanent causal coverage so each of these exact prohibited changes fails:

1. retained historical continuity/sole-active basis becomes current standing
   permission;
2. caller null or optionality forces/vetoes the branch;
3. local absence yields `definitely_not_committed` without positive current
   continuity;
4. exact replay creates a new fact or transaction timestamp;
5. command relation admits or selects an unadmitted scope;
6. null or omitted acceptance-fact coordinate skips its collision route.

Each must fail at an exact named semantic boundary.

## Additional required contract tests

### Branch-neutral truth table

Test all derived branches against one mandatory reserved fact identity.

Require:

- command with null fact coordinate is invalid before branch reduction;
- command with wrong deterministic fact coordinate is invalid;
- acceptance materializes exactly one fact at the reserved identity;
- each nonaccept branch materializes zero facts but retains the selector route;
- supplying the coordinate does not change branch;
- omitting the coordinate cannot veto acceptance;
- a fact member on nonaccept is invalid;
- missing fact member on acceptance is invalid;
- occupied/colliding reserved identity is never ignored.

### Identity derivation

Independently author fixed preimage expectations.

Test:

- exact ordered preimage;
- exact domain separator;
- exact canonical type comparison;
- changing every included coordinate changes the derived ref;
- changing branch/result/receipt/timestamp/terminal data does not participate
  because those fields are prohibited from the preimage;
- machine and prose representations agree;
- no self-authored derivation expected/observed table.

### Closed route inventory

Test:

- exact eight-route inventory or the explicitly reconciled equivalent;
- exact element grammar, role, kind, source coordinate, order, and count;
- missing route;
- duplicate route;
- unknown route;
- reordered route;
- null route coordinate;
- coordinate copied from another role;
- omitted acceptance route on nonaccept;
- omitted scope-winner route;
- additional implementation-specific route;
- timestamp/final-receipt dependency.

### Recovery outcomes

Test at value-contract level:

- exact complete family;
- same mutation/different digest;
- every preassigned identity collision;
- family-route collision;
- competing complete winner;
- exhaustive total absence with positive current posture;
- total local absence without current posture;
- partial/orphan fact combinations;
- malformed/foreign/unreadable route;
- replay retaining original timestamp and fact;
- no repair or automatic retry.

Do not implement a SQL recovery engine or second reducer.

### Prose and machine independence

Strengthen the verifier beyond the opening eight phrase checks.

Require independent parsing/coverage of the exact normative clauses governing:

- historical basis non-authority;
- current external posture;
- mandatory prospective fact coordinate;
- branch nonselection;
- nonaccept collision probing;
- closed route inventory;
- total-absence currentness requirement;
- replay no-new-fact/no-new-timestamp;
- unadmitted-scope rejection.

Keep prose, machine block, fixed test expectations, identity derivation
expectations, and hostile expectations separately authored.

Do not create exhaustive token-by-token prose pointer tests.

## External transformed mutants

In disposable external copies, execute at least these transformations:

1. make fact ref nullable;
2. let null veto acceptance;
3. let non-null force acceptance;
4. omit fact collision lookup on nonaccept;
5. accept a wrong deterministic fact ref;
6. derive fact ref from branch;
7. derive fact ref from result or receipt;
8. remove one mandatory collision route;
9. duplicate one route;
10. add unknown route;
11. change one route to another role’s coordinate;
12. omit admitted-scope winner route;
13. let local absence prove noncommit without continuity;
14. make historical basis current permission;
15. let replay generate a fact;
16. let replay refresh timestamp;
17. permit an unadmitted scope;
18. mark partial route coverage `definitely_not_committed`.

For every mutant require:

- unchanged expected collection;
- failure at the intended exact semantic boundary;
- no syntax/import/format/collection-shrinkage failure.

Report external mutants separately from permanent internal negative controls.

## Test architecture requirements

Preserve:

- recursive duplicate-key rejection;
- exact built-in type comparison, including bool/int separation;
- fixed expectations independent of the machine block;
- current-source-derived v1 inventories;
- no broad source manifest;
- no physical schema emulator;
- no second decision reducer;
- no second replay/recovery owner;
- no file-hash-only correctness claims.

The new contract verifier may model finite value grammar and dependency
relations. It must not model SQLite execution.

## Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run and report collection plus execution for:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening reference: `45 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contracts
   - opening reference: `1,623 passed`.

3. Specified B1, C2B2 value, and migration-0002 modules
   - opening reference: `458 passed`.

4. Operating-model, architecture, and runtime modules
   - opening reference: `77 passed`.

5. `tests/test_rw0_*.py tests/test_c2b*.py tests/test_sqlite_c2b*.py tests/test_sqlite_rw0*.py`
   - opening reference: `4,048 passed`.

6. Complete repository
   - opening reference: `7,862 passed, 3 warnings`.

The final full-suite count may increase only by the exact added contract-test
nodes.

The only accepted warnings are the same three unchanged Python 3.13
multithreaded-`fork()` warnings from the writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling;
- proof the four other candidate documents remain byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-cache movement or modification.

## Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact two-file opening-to-closing transition;
6. proof the other four candidate paths stayed byte-identical;
7. branch-neutral fact identity rule and derivation;
8. closed route inventory and grammar;
9. recovery absence/currentness rules;
10. six previously surviving hostile dispositions;
11. permanent negative controls and external mutant results;
12. exact collection and validation results;
13. source/migration/public/runtime preservation;
14. deterministic final six-path patch bytes and SHA-256;
15. fully specified final canonical receipt grammar, bytes, and SHA-256;
16. cleanup;
17. remaining physical seams;
18. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create/modify a PR, or merge.

## Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the two-file ceiling is insufficient;
- another owner document must change;
- current source contradicts v1 preservation;
- the repair would require SQL, reader, writer, or transaction design;
- acceptance-fact identity cannot be made branch-neutral without changing the
  decision or guard semantic owner;
- the closed route inventory cannot be expressed without creating a second
  recovery owner;
- source, migration, export, or existing test changes are required.

Restore the exact opening candidate under a blocking result.

## Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V2_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

## Required non-actions

State:

```text
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
