# Governed Execution Coordinator — RW0-C2 Immutable Bootstrap Guard Physical/Value Architecture Reconnaissance

## Role and objective

Perform one repository-first, parent-led, read-only architecture reconnaissance
for the physical and private-value realization of the merged RW0-C2 immutable
bootstrap acceptance guard.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The purpose is to select the narrowest truthful architecture and tranche order
for:

- immutable bootstrap-scope admission;
- admitted-lineage command binding;
- lineage continuity and sole-active-authority evidence;
- immutable bootstrap-acceptance fact membership in the durable decision
  family;
- exact replay and one whole-family recovery classifier;
- migration and physical persistence treatment;
- private safe-value/versioning treatment;
- transaction-owner integration.

Do not implement anything. Do not issue an implementation prompt.

Return one substantive inline report with exact repo-relative `path:line`
evidence and one compact continuation capsule of no more than 1,200 words.

Do not generate or attach a JSON manifest, report file, freeze artifact,
package, or other external deliverable.

## Repository and required baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required opening baseline:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged posture
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Use the live merged repository as the sole source of current contract and
implementation truth.

Do not fetch or contact remotes.

Stop immediately on any mismatch:

`RW0_C2_BOOTSTRAP_GUARD_PHYSICAL_ARCHITECTURE_BLOCKED`

## Read-only posture

This turn is strictly read-only.

Do not:

- edit, create, delete, rename, format, or clean repository files;
- stage, commit, push, create or modify a PR, or merge;
- run tests;
- import repository modules;
- open or mutate any SQLite database;
- run migrations;
- start services;
- install dependencies;
- inspect sibling repositories;
- contact networks;
- create retained temporary artifacts.

Read-only Git inspection, text inspection, static AST inspection, and safe
metadata inspection are allowed.

Do not move, delete, rewrite, import through, or inventory the contents of
ignored bytecode beyond a safe path/type classification when needed.

## Authority and classification rules

Apply this hierarchy:

- Git owns commit, tree, blob, and ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within each document’s
  declared scope.
- `.docs/autonomous-software-development-operating-model.md` owns composition
  and current-status classification.
- source and migrations own current implemented behavior and physical durable
  representation.
- tests are executable evidence and drift guards, not independent semantic
  owners.
- reports, traces, generated artifacts, and chat summaries are evidence only.

Classify every material conclusion as one of:

- current implemented contract;
- accepted target contract;
- bounded compatibility edge;
- historical/proof precursor;
- reopened future seam;
- implementation detail;
- evidence/projection;
- inference;
- unresolved uncertainty.

Do not silently promote a historical C2B representation, test fixture, report,
or proof artifact into current physical authority.

## Fixed accepted target

Do not reopen the merged product-policy decision.

The accepted target is:

1. One bootstrap scope belongs to one explicitly standing-policy-admitted
   Coordinator authority lineage.
2. Operational realizations—deployment, machine, process, database, file,
   repository, program, attempt, candidate, command, grant, restore, rollback,
   clone, passive backup, or relocation—do not create a lineage or allowance.
3. One active Coordinator authority per lineage is supported. Ambiguous or
   active-active posture fails closed.
4. Lineage continuity must be positively established. Local row absence is
   never proof that the scope is unclaimed.
5. The target owns:
   - one immutable bootstrap-scope admission fact; and
   - zero or one immutable bootstrap-acceptance fact.
6. At most one distinct productive direct-local `candidate_acceptance` may
   commit across every participating program in one admitted scope.
7. The allowance is permanent and non-renewable. Restore, clone, replacement,
   relocation, a new grant, a new policy epoch, or later ES routing never
   replenishes it.
8. The acceptance fact is an immutable member of the same atomic
   decision/version/head/result/receipt family.
9. There is no mutable `available -> consumed` latch subsystem, state revision,
   reset path, separate latch transaction, separate latch receipt, separate
   latch replay classifier, or separate latch recovery classifier.
10. The decision writer may record acceptance against an admitted scope. It may
    not create, admit, repair, renew, or replenish that scope.
11. Exact replay returns the original complete family and acceptance fact
    without fresh eligibility evaluation or a new timestamp.
12. One whole-family classifier owns `committed_exact`,
    `definitely_not_committed`, and `unresolved`.
13. The four nonaccept branches create no acceptance fact.
14. Terminal outcome remains later, separate, and non-mutating.
15. Later ES-routed operation is separately governed and non-replenishing.
16. The B1 names `latch_postimage_ref` and `latch_postimage_digest` are legacy
    compatibility names only. Current B1 does not prove guard truth.

## Current merged capability and explicit nonimplementation

Treat as current merged reality:

- private pure post-execution evidence, policy, decision-input, Section 41
  projection, and role-resolution owners exist;
- RW0-C1 durable evidence is implemented;
- the RW0-C2 five-branch semantic contract is merged;
- the immutable bootstrap-guard semantic contract is merged;
- migrations 0001–0004 exist;
- migration 0005 is absent;
- migration-0002 development decision/version/head/receipt structures are
  current physical owners within their existing contracts;
- no RW0-C2 durable command, writer, scope provisioner, guard table, guard
  reader, acceptance-fact persistence, terminal owner, production caller,
  public export, or runtime activation exists.

Do not report accepted target behavior as implemented.

## Central architecture questions

Answer every question below with repository evidence, a selected recommendation,
rejected alternatives, and any remaining uncertainty.

### 1. Exact logical private-value families

Determine the exact future private value families and their semantic owners for:

- bootstrap-scope admission fact;
- admitted-lineage/scope command relation;
- lineage-continuity evidence;
- sole-active-authority evidence or attestation;
- bootstrap-acceptance fact;
- acceptance-fact membership or family relation;
- guarded decision command additions or supplemental command relation;
- result projection;
- receipt projection;
- replay projection;
- complete-family recovery selector and recovery result.

For each proposed value, state:

- whether it is a new immutable value, a relation, a projection, or reuse of an
  existing current owner;
- exact authority it carries and authority it must not carry;
- identity/digest dependencies;
- whether it is command-digest covered;
- whether it is recovery-selector covered;
- whether it is durable or external evidence;
- whether it belongs to the admission-provisioning family, guarded-decision
  family, or later terminal family.

Do not design public DTOs.

### 2. Physical owner split

Determine whether physical ownership should be:

- one combined owner;
- two owners:
  1. immutable scope-admission provisioning;
  2. guarded acceptance-decision persistence;
- or another justified bounded split.

The split must preserve:

- standing policy as admission authority;
- no lazy scope creation by the decision writer;
- one authoritative writer per mutable or append-only fact;
- one acceptance transaction;
- one replay owner;
- one recovery owner;
- terminal separation.

Decide whether the admission provisioner and acceptance writer may share a
migration and transaction infrastructure without sharing semantic authority.

### 3. Migration-free reuse versus migration 0005 versus bounded hybrid

Compare, from current source and migration truth:

1. migration-free reuse of existing migration-0002 rows;
2. additive migration 0005;
3. bounded hybrid:
   - keep current migration-0002 decision/version/head/receipt owners;
   - add only missing immutable admission, command-relation, acceptance-fact,
     membership, selector, or recovery relations.

Do not select the smallest diff by default.

Select the narrowest representation that can truthfully enforce:

- cross-program uniqueness;
- explicit admission;
- positive continuity;
- one-active-authority posture;
- local absence non-authority;
- atomic acceptance-family membership;
- exact replay;
- whole-family three-way recovery;
- fragment and alias detection;
- collision classification;
- permanent non-replenishment.

State exactly why every rejected option fails or creates duplicate truth.

### 4. Current migration-0002 reuse analysis

Inspect the current physical and private-value contracts for at least:

- `development_decisions`;
- `development_program_versions`;
- `development_program_heads`;
- `development_mutation_receipts`;
- current result projections;
- mutation-graph digest behavior;
- existing private readers;
- existing append-only and uniqueness constraints.

Determine:

- which existing rows remain canonical without alteration;
- which current row grammars are insufficient;
- whether adding fields to existing v1 rows would be a breaking semantic
  repurposing;
- whether supplemental immutable relations are required;
- whether any existing uniqueness key can enforce a lineage-wide,
  cross-program acceptance ceiling;
- whether the existing receipt algebra can truthfully include an acceptance
  fact without schema/versioning or migration changes.

### 5. Admission provisioning

Freeze the architecture, not implementation, for admitting one independent
Coordinator authority lineage.

Determine:

- the exact input authority and evidence required from standing policy;
- whether provisioning needs its own command/result/receipt/replay/recovery
  family;
- how admission-fact identity is derived;
- how duplicate, foreign, stale, malformed, unreadable, or conflicting
  admission is classified;
- whether admission recording is idempotent;
- whether admission can be provisioned before any development program exists;
- how independently admitted lineages remain distinct;
- how schema installation, an empty database, or copied state is prevented from
  becoming implicit admission.

Do not invent an operator workflow, public API, or standing-policy issuance
system.

### 6. Continuity and sole-active-authority evidence

Determine what is:

- durable Coordinator fact;
- external standing-policy or operational evidence;
- transient command-time observation;
- recovery-time evidence;
- deliberately unselected.

The architecture must survive:

- machine replacement;
- database replacement;
- restore;
- rollback;
- clone;
- passive backup;
- relocation.

It must not use machine identity, database identity, process identity, local
lock existence, or local row absence as lineage identity.

Determine whether one-active-authority posture is:

- a durable immutable attestation;
- a command-time externally supplied and currentness-checked fact;
- a fenced writer/session property;
- or a composed relation across those layers.

State the authoritative writer and verifier for each component.

### 7. Atomic acceptance-family integration

Determine the exact future transaction family for `candidate_acceptance`.

The family must include:

- existing canonical decision/version/head members;
- result;
- receipt;
- immutable acceptance fact;
- every required supplemental basis/currentness/graph relation;
- one transaction timestamp;
- one command digest;
- one mutation identity;
- one family route.

Determine:

- which identities are preassigned;
- acyclic digest order;
- exact cross-program uniqueness enforcement;
- exact order of fencing, receipt lookup, reducer, guard read, family
  construction, apply, capability invalidation, commit, and readback;
- what the transaction controller owns;
- what the writer session owns;
- what the semantic reducer does not own.

No second guard transaction is permitted.

### 8. Replay, collision, and recovery

Specify the architecture for:

- same mutation/same command;
- same mutation/different command digest;
- identity collision;
- family-route collision;
- same scope with a competing complete winner;
- missing family;
- partial decision without acceptance fact;
- acceptance fact without decision;
- duplicate fact;
- malformed fact;
- unreadable family;
- restore/clone ambiguity.

Determine the exact read set and selector needed to prove:

- `committed_exact`;
- `definitely_not_committed`;
- `unresolved`.

Recovery must not:

- create or repair a fragment;
- reevaluate the branch;
- create a new timestamp;
- renew an allowance;
- infer unclaimed status from local absence;
- retry automatically after unresolved.

### 9. B1 legacy compatibility and private-value versioning

Decide whether the existing B1
`latch_postimage_ref` / `latch_postimage_digest` pair:

- can remain unchanged until the later terminal tranche;
- requires a private safe-value versioning decision before the guarded decision
  writer;
- requires a new successor value now;
- or must not participate in guard persistence at all.

Preserve current source truth:

- the pair validates supplied representation/coherence only;
- it is not durable guard proof;
- its current schema, order, nullability, bytes, domain, and budgets remain
  current implementation facts.

State the exact prerequisite tranche and why.

### 10. Security, privacy, and authority widening

Identify risks involving:

- lineage theft or substitution;
- restored/cloned database replay;
- multiple active writers or authorities;
- partial-family recovery;
- admission forgery;
- local-absence inference;
- unsafe selector disclosure before fencing;
- sensitive standing-policy or operational evidence;
- database corruption;
- denial-of-service through permanent scope poisoning.

State which checks belong in:

- pure values;
- SQLite constraints;
- private readers;
- transaction/writer fencing;
- recovery;
- audit tests.

Do not expose secrets, database rows, credentials, endpoints, or ignored binary
contents.

## Minimum required inspection

Inspect at minimum the following, plus every exact owner/test edge they reveal.

### Guidance and composition

- `AGENTS.md`
- `README.md`
- `.docs/architecture.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/authority-boundaries.md`
- `.docs/durable-state-model.md`
- `.docs/software-development-progression-boundary.md`
- `.docs/worker-execution-boundary.md`
- `.docs/rw0-remote-worker-contact-phase-entry.md`

### Merged RW0 owners

- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`, especially:
  - Sections 4, 19, 25, 30–34, 36, 41–42;
  - the RW0-C2 decision successor;
  - the immutable bootstrap-guard successor.

### Physical/migration contracts

- `.docs/c2b2-migration-0002.md`
- `.docs/c2b2-pure-durable-row-values.md`
- `.docs/c2b2-private-readers.md`
- `.docs/sqlite-schema-v1.md`
- `.docs/sqlite-bootstrap-and-migrations.md`
- `.docs/sqlite-operations-and-recovery.md`
- `.docs/sqlite-threat-model.md`
- `.docs/writer-session-authority.md`
- `.docs/b3c4b-private-atomic-transition-persistence.md`

### Source and migrations

- `src/ge_nwp_coordinator/sqlite_migration.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/_rw0_c_decision_input_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py`
- `src/ge_nwp_coordinator/_rw0_c1_row_values.py`
- `src/ge_nwp_coordinator/_rw0_c1_semantic_values.py`
- `src/ge_nwp_coordinator/_development_program_initialization_contracts.py`
- `src/ge_nwp_coordinator/_development_author_effect_establishment_contracts.py`
- `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_program_initialization.py`
- `src/ge_nwp_coordinator/_sqlite_development_author_effect_establishment.py`
- `src/ge_nwp_coordinator/_sqlite_development_pre_execution_plan_disposition.py`
- `src/ge_nwp_coordinator/_sqlite_development_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_development_readers.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_reader_contracts.py`
- `src/ge_nwp_coordinator/_sqlite_rw0_c1_readers.py`
- `src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py`
- `src/ge_nwp_coordinator/sqlite_transition_transaction.py`
- `src/ge_nwp_coordinator/sqlite_writer_session.py`
- `src/ge_nwp_coordinator/state_store.py`
- `src/ge_nwp_coordinator/__init__.py`

### Tests

- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b0_durable_state_contract.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_sqlite_rw0_c1_migration_0004.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_c2b2_development_reader_contracts.py`
- `tests/test_c2b3_program_initialization_contract.py`
- `tests/test_c2b3_program_initialization_recovery.py`
- `tests/test_c2b3_private_atomic_program_initialization.py`
- `tests/test_c2b3d_private_atomic_author_effect_establishment.py`
- `tests/test_section41_private_atomic_pre_execution_plan_disposition.py`
- `tests/test_rw0_c1_private_atomic_persistence.py`
- `tests/test_rw0_c1_recovery.py`
- `tests/test_sqlite_b2c_writer_session.py`
- `tests/test_sqlite_transition_transaction.py`
- current public-surface and nonimplementation guards.

If a named path differs in the live tree, identify the owning replacement rather
than silently omitting the surface.

## Subagent workflow

Use at most three bounded read-only explorer agents. No nested delegation.

Each explorer must receive a self-contained context capsule with:

- repository and exact baseline;
- current implemented contract;
- accepted target;
- reopened seams;
- compatibility obligations;
- non-goals;
- mutation authority: none;
- required path:line report envelope.

Recommended scopes:

### Explorer 1 — value and authority architecture

Inspect:

- guard and decision semantic owners;
- B1 compatibility;
- exact private-value families;
- admission/continuity/sole-active evidence;
- semantic authority split;
- safe-value/versioning prerequisite.

### Explorer 2 — physical schema and migration

Inspect:

- migration 0002 and 0004;
- row values and readers;
- append-only/uniqueness constraints;
- migration-free reuse versus migration 0005 versus bounded hybrid;
- provisioning storage versus acceptance-family storage;
- exact current owners that must remain canonical.

### Explorer 3 — transaction, replay, recovery, and security

Inspect:

- private atomic writer patterns;
- writer-session and transaction controller;
- receipt-first replay;
- commit uncertainty;
- selector/read-set requirements;
- restore/clone/active-authority threats;
- tests and validation needed for later contract and implementation tranches.

The parent must independently inspect the central evidence, preserve
disagreements, and reconcile all three reports.

## Required parent report

Return these sections:

1. primary disposition token;
2. visible model/reasoning setting;
3. exact opening and closing Git coordinates;
4. inspection scope, explorers, failures/retries, and uninspected areas;
5. current implementation versus accepted target;
6. exact fact/authority ownership matrix;
7. selected private-value family;
8. selected physical owner split;
9. migration decision and rejected alternatives;
10. current migration-0002 reuse matrix;
11. admission-provisioning architecture;
12. continuity and sole-active-authority architecture;
13. atomic acceptance-family architecture;
14. replay/collision/recovery architecture;
15. B1 compatibility/versioning decision;
16. security/privacy analysis;
17. exact recommended contract-freeze tranche sequence;
18. exact likely touched-file ceiling for each later contract tranche;
19. validation and independent-audit plan for each tranche;
20. stop conditions and remaining uncertainties;
21. compact continuation capsule;
22. required non-actions.

### Fact/authority ownership matrix

For every mutable or immutable fact, include:

- fact;
- current or target status;
- authoritative owner;
- writer;
- verifier;
- physical source, when current;
- whether external evidence remains required;
- replay owner;
- recovery owner;
- prohibited substitute owners.

### Reuse matrix

For every relevant current table/value/reader/transaction surface, classify:

- reuse unchanged;
- reuse with successor value only;
- supplement through migration 0005;
- not reusable;
- historical/proof precursor only.

### Tranche sequence

The sequence must state whether the next mutation-bearing work should be:

- one combined contract freeze;
- a private safe-value/versioning freeze first;
- an admission-provisioning physical freeze first;
- a bounded-hybrid decision-family physical freeze first;
- or another justified order.

Do not request implementation before all prerequisite contracts are frozen.

## Product-policy threshold

Ordinary engineering decisions are yours to make.

Do not ask the operator to choose:

- tables;
- columns;
- indexes;
- selectors;
- migration mechanics;
- reader layout;
- transaction order;
- replay behavior;
- recovery behavior;
- private class names;
- test organization.

Use `RW0_C2_BOOTSTRAP_GUARD_PRODUCT_POLICY_DECISION_REQUIRED` only when two
architectures preserve the accepted safety invariant but produce materially
different product meaning that the repository and accepted target cannot
resolve.

If used, present exactly one bounded fork with:

- recommended default;
- consequence of each choice;
- work enabled or blocked;
- what remains unchanged.

## Disposition tokens

End with exactly one:

`RW0_C2_BOOTSTRAP_GUARD_PHYSICAL_ARCHITECTURE_READY`

Use when the repository supports a selected architecture, prerequisite order,
migration treatment, and exact next contract tranche.

`RW0_C2_BOOTSTRAP_GUARD_PRODUCT_POLICY_DECISION_REQUIRED`

Use only under the product-policy threshold above.

`RW0_C2_BOOTSTRAP_GUARD_PHYSICAL_ARCHITECTURE_BLOCKED`

Use when current repository contracts are contradictory or insufficient even
for a bounded engineering recommendation.

Do not return a generic `RECONNAISSANCE_READY` token in place of the required
specific disposition.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
ARTIFACTS_NOT_GENERATED
IMPLEMENTATION_PROMPT_NOT_ISSUED
IMPLEMENTATION_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SAFE_VALUE_VERSIONING_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_READ_ONLY_IF_USED
```
