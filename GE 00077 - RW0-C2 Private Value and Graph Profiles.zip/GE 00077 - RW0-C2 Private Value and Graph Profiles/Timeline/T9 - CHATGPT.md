## Disposition

**Proceed to a fresh independent read-only re-audit. Do not stage or commit the V2 candidate.**

Codex returned the intended repair token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V2_VALIDATED_READY_FOR_REAUDIT
```

The closeout is internally coherent and shows no deterministic pre-audit blocker.

## Repair reconciliation

The prior audit blocked the candidate because the nullable acceptance-fact coordinate could act as a caller-controlled branch selector, while the open `alias_routes` grammar could omit a collision route and still appear to prove absence. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

V2 addresses those defects with the correct architectural shape:

- Every guarded command now carries one mandatory, non-null **prospective acceptance-fact identity**.
- The identity is a reserved collision coordinate, not an assertion that acceptance will occur.
- The authoritative branch alone determines whether the fact is materialized.
- Acceptance requires exactly one fact at the reserved identity.
- All four nonaccept branches forbid the fact but still retain its collision route.
- Recovery uses a closed, ordered inventory of eight mandatory routes rather than an open alias collection.
- `definitely_not_committed` from absence additionally requires current positive continuity and sole-active-authority posture.

That preserves the already accepted owner split: the command carries expected coordinates, the Coordinator derives the branch, the guarded writer may materialize the fact only for acceptance, and recovery remains under the existing decision owner.

## Validation-count consistency

The test-count transition reconciles exactly:

| Surface | V1 | V2 | Delta |
|---|---:|---:|---:|
| Private-value contract module | 45 | 186 | +141 |
| Broad RW0/C2B group | 4,048 | 4,189 | +141 |
| Full repository | 7,862 | 8,003 | +141 |

The unchanged groups also remained stable:

```text
C2 guard + decision:                 1,623
B1/C2B2/migration-0002 group:          458
Operating model/architecture/runtime:   77
```

This strongly suggests the full-suite increase is entirely attributable to the new contract coverage rather than accidental collection drift.

The previous audit found six required hostile variants that passed all 45 tests. :chatgpt-content-reference{index="2"} Codex reports that those six now fail at named boundaries and that 19 transformed external copies retain the 186-node collection while failing semantically rather than through syntax or collection shrinkage. That is the correct evidence shape, but it still needs independent reproduction.

## Primary re-audit risks

### Hidden identity cycles

The prospective acceptance-fact preimage includes the preassigned decision ref, resulting-version ref, and deterministic family route. The auditor must independently establish how those coordinates are derived.

The critical question is whether any hidden cycle exists, such as:

```text
command digest
→ prospective acceptance ref
→ command digest
```

or:

```text
family route
→ prospective acceptance ref
→ family route
```

or:

```text
decision/version identity
→ command digest
→ prospective acceptance ref
→ decision/version identity
```

A declared ordering list is not enough. The complete identity DAG must be independently topologically sorted from the owning rules.

### Branch neutrality

The auditor must exercise the full truth table:

```text
null ref                         → invalid command
wrong deterministic ref         → identity mismatch/no-write
correct ref + acceptance         → exactly one fact
correct ref + any nonaccept      → no fact, collision route still mandatory
```

Supplying or withholding the coordinate must never alter the derived branch.

### Exhaustive route closure

The eight routes must form a closed query-plan grammar with exact count, order, role, key source, schema/profile ID, and coordinate equality. Any missing, duplicate, unknown, null, unreadable, or unchecked route must produce `unresolved`, not absence.

The particularly important routes are:

```text
acceptance_fact_identity_route
admitted_scope_winner_route
```

These close the exact gaps found by the prior audit.

### Fresh posture versus retained evidence

The family may retain the historical continuity and sole-active evidence that was checked at commit time. That retained basis must not become standing current authority.

Recovery or replay disclosure still requires fresh current external posture. Local rows—and especially local absence—cannot establish it.

### Test independence

The verifier grew from 34,788 to 66,615 bytes and from 45 to 186 tests. The auditor should verify that:

- fixed identity-preimage expectations are not generated from the machine block being tested;
- route expectations are not generated from observed routes;
- prose, machine JSON, fixed expectations, source-derived v1 facts, and hostile expectations remain independently authored;
- the verifier does not become a second reducer, recovery engine, or physical schema model.

## Fresh independent re-audit handoff

Start a **fresh read-only Codex conversation**, select the highest available reasoning setting, and attach nothing.

:chatgpt-content-reference{index="3"}[Download the V2 independent re-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V2_Independent_Reaudit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V2_Independent_Reaudit_Prompt.txt

Size:
27,950 bytes

SHA-256:
3461e5a9f1d04fd34aa46836fe1188b4a58fa44e0f7d0ff7766bcd9abbc62140

Logical lines:
811

Final newline:
present
```

The prompt binds:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Complete six-path patch:
114,527 bytes
63addad94b2a60bcc9750e3f57919b445c672cd87cd321722b94f989f5caf2ac

Canonical receipt:
1,379 bytes
e902ed0d650e50796a44b09675395dbc3a6c225297c621bfdf627fc1d521d70a
```

It requires independent verification of:

- the exact two-file V1-to-V2 transition;
- mandatory branch-neutral prospective identity;
- exact domain/preimage/canonicalization rules;
- the complete identity DAG and hidden-cycle analysis;
- the five-branch truth table;
- the closed eight-route selector grammar;
- current-posture requirements for absence;
- replay immutability;
- admitted-scope binding;
- v1 and B1 preservation;
- the six prior surviving hostile variants;
- more than 30 independently transformed identity, route, replay, and recovery mutants;
- exact collection and validation totals;
- source, migration, export, public, runtime, and cache preservation.

Possible outcomes:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED
```

```text
AUDIT_PROVENANCE_MISMATCH
```

Even acceptance authorizes only a separate commit/publication gate for the exact six audited paths. It does not authorize migration `0005`, source value implementation, scope admission provisioning, guarded decision persistence, readers, recovery implementation, terminal binding, public APIs, runtime activation, RW0-D/E, or Execution Substrate work.

**Sources:** Prior independent audit of the V1 private-value candidate; current Codex V2 repair closeout supplied in the user message.

**Confidence:** High that the candidate is ready for independent re-audit. No commit-readiness judgment is warranted until the prospective-ref DAG, branch neutrality, exhaustive route closure, fresh-posture requirement, and transformed hostile copies are independently reproduced.
