# Governed Execution Coordinator — RW0-C2 Private Value Contract V6 Lifecycle, Recovery-Observation, and Owner-Anchor Repair

## Role and objective

Resume the implementation conversation that produced the uncommitted RW0-C2
private value/versioning and receipt-graph-profile V5 candidate.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort;
- parent filesystem/permission posture, when visible.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its fresh independent re-audit
returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

The V5 audit established exact provenance and accepted the following V5
repairs:

- the canonical guarded command digest and command-selector-family binding;
- source-exact current-v1 receipt-graph value mapping;
- admission and explicit fresh posture before C2;
- actual C2 returned-branch causality;
- canonical current-v1 five-branch families;
- target supplemental-member binding;
- static profile selection through the guarded result;
- complete common and acceptance-only graph roles;
- current v1 and B1 preservation;
- no source, migration, public-surface, or runtime widening.

The remaining findings are bounded:

1. the machine dependency registry still conflates fresh-write construction and
   post-read recovery, and omits validated-admission/current-posture causality
   at the branch boundary;
2. the transient recovery observation grammar lacks exact types/nullability for
   every status, lacks an explicit unchecked state, and its status inventory is
   self-confirming;
3. only eight of twenty-six guarded-relation raw fields receive fully resealed
   independent negative tests;
4. private tagged clauses can still shadow or reverse unchanged owner meaning
   because the owner-anchor helper returns a mutable private-test tuple;
5. the bounded prose parser misses `might`, `replay adapter`, and immediate
   cross-sentence contradictions, while falsely rejecting neutral compounds.

This is a **two-file private contract/test repair**. Preserve the selected
architecture. Do not implement source, migration `0005`, admission
provisioning, continuity transport, durable persistence, readers, transaction
mechanics, recovery runtime, public interfaces, runtime activation, RW0-D/E, or
Execution Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V5 candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 156,160 | `119a7218230221c8c13f8039df308035a52195731d9f71f001437c8e493991aa` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 231,640 | `fca8e6715762bae4d97255f88cd936ea2cbbff0c32dd72dd81c7f3a0dcdd7b1b` |

Required opening ordered patch:

- bytes: `400,930`
- SHA-256:
  `88d0bc1203a9ebbb83d50108d9a196060c108579aada62c4916e3eb5bad958dc`

Construct it twice in lexicographic path order with:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,381`
- SHA-256:
  `5d30d4aa9974b499438752d284f4d7098a53366f4e2a79352d50b6790eec56ee`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V6_REPAIR_BLOCKED`

## Exact mutation ceiling

Only these two paths may change from their opening V5 bytes:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

The other four candidate documents must remain byte-identical to the opening
receipts.

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- architecture, C2B, guard-owner, decision-owner, B1, or operating-model
  documents;
- configuration or examples.

Migration `0005` must remain absent.

If the two-file ceiling is insufficient, restore the exact opening V5 candidate
and return the blocking token. Do not widen the tranche.

## Accepted architecture that must not be reopened

Preserve exactly:

1. The closed eleven logical private values/profiles and their owner hierarchy.
2. The guard owner controls lineage, scope, admission, fresh continuity,
   sole-active-authority posture, one-shot eligibility, permanence, terminal,
   and ES boundaries.
3. The decision owner controls authoritative branch derivation, generic
   decision/version/head/result/receipt meanings, replay, collision taxonomy,
   and whole-family recovery.
4. Migration-0002 v1 values remain canonical within unchanged meanings.
5. Admission provisioning and guarded decision persistence remain separate
   semantic owners.
6. Acceptance creates one immutable acceptance fact in the same atomic family.
7. Four nonaccept branches create no acceptance fact.
8. There is one logical result, one generic v1 receipt root, one replay owner,
   and one recovery owner.
9. Historical continuity and sole-active evidence is not current permission.
10. Fresh positive external posture remains required before protected branch,
    replay, or recovery disclosure.
11. B1 `latch_postimage_*` remains compatibility/nonproof only and is not
    consumed by the guarded decision writer.
12. The static receipt profile is verification metadata selected through the
    guarded result, not a graph member or durable row.
13. Physical schema, migration `0005`, readers, writers, transaction mechanics,
    provisioner mechanics, public interfaces, and runtime remain future.

This repair closes lifecycle partitions, typed recovery observations,
relation-field causality, owner-derived normative truth, and bounded prose
recognition only.

# Finding H1 — explicit lifecycle partitions

## H1-A. Stop using one global execution order

The V5 registry permits a lexical topological order in which recovery route
observations and `recovery_projection` appear before `transaction_timestamp`
and the durable family. That is unacceptable as a lifecycle claim even if the
subgraphs are mathematically independent.

Replace the combined executable-order claim with three explicit lifecycle
partitions:

1. `fresh_write_construction_v1`
2. `exact_replay_readback_v1`
3. `uncertain_commit_recovery_v1`

These are derivation/verification graphs inside the existing private contract.
They are not new durable schemas, public DTOs, or second replay/recovery owners.

A common identity/value registry may remain, but every node must declare one or
more exact lifecycle memberships. No single global topological ordering may be
presented as execution order across different lifecycle partitions.

## H1-B. Fresh-write construction graph

For each of the five authoritative branches, independently expand one exact
fresh-write DAG with this order:

```text
verified admission act/fact
+ explicit fresh continuity and sole-active posture
+ current decision basis/head/program identity
→ closed command relation and 24-coordinate transcript
→ six sibling preassignments
→ canonical command digest
→ validated_admission_command_and_current_posture
→ authoritative C2 branch
→ one transaction timestamp
→ canonical current-v1 branch members
→ target supplemental members
→ guarded relation and guarded result
→ exact graph entries and generic receipt preimage
→ generic graph digest
→ final generic v1 receipt row
```

Required node:

`validated_admission_command_and_current_posture`

It depends on:

- verified admission act and immutable admission fact;
- closed command relation;
- canonical command digest and all six validated sibling expectations;
- explicit fresh current continuity posture;
- explicit fresh current sole-active posture;
- local writer/session fencing only as a future transaction-owner prerequisite,
  not as lineage authority.

`authoritative_branch` depends on that validated node and the exact C2 decision
basis/currentness inputs.

Invalid or missing admission/current posture must leave `authoritative_branch`
unmaterialized.

Acceptance-only nodes and edges materialize only on
`candidate_acceptance`. Nonaccept expanded graphs omit them entirely.

## H1-C. Exact replay readback graph

Define exact replay as a post-read lifecycle:

```text
receipt-first mutation lookup
+ exact canonical command digest
+ fresh current posture required for protected disclosure
+ complete exact persisted family
→ replay_projection
```

Replay projection is downstream of the already committed final receipt and all
exact members.

It does not create:

- transaction timestamp;
- branch;
- fact;
- relation;
- result;
- graph entry;
- receipt;
- admission or scope state.

It returns the original committed timestamp and exact family.

No replay node belongs to fresh-write construction.

## H1-D. Uncertain-commit recovery graph

Define recovery as a separate post-read lifecycle:

```text
canonical command + complete-family selector
+ fresh current posture
+ eight typed route observations
→ complete recovery observation set
→ C2-owned recovery projection
```

The recovery graph is downstream of actual read observations, not necessarily a
committed family. It must not be represented as a stage before fresh-write
construction.

Recovery does not create or mutate family members.

## H1-E. Partition proof

Freeze and test:

- exact node and edge inventory for each of five fresh-write DAGs;
- exact replay graph;
- exact recovery graph;
- exact lifecycle membership for every shared node;
- no fresh-write node depends on a replay/recovery projection or observation;
- no replay/recovery projection is an input to branch or durable family
  construction;
- replay and recovery are post-read lifecycles;
- validated admission/current posture is a required ancestor of every
  authoritative branch;
- no default posture or historical basis substitutes for that node.

A mutation that moves recovery projection to an earlier numeric stage while
preserving its post-read lifecycle must not matter. A mutation that assigns it
to the fresh-write lifecycle or makes a fresh-write node depend on it must fail.

Do not use one global stage number as the sole lifecycle proof.

# Finding M1 — exact typed recovery observations

## M1-A. Closed observation grammar

Replace the open or partially typed observation shape with one exact transient
grammar.

Each route observation must contain exactly:

- `route_role`: exact closed route-role string;
- `route_key`: exact ordered tuple/JSON array of nonempty strings;
- `status`: exact closed status enum;
- `read_attempted`: exact `bool`;
- `readable`: exact `bool`;
- `evidence_ref`: exact nonempty string or `null`;
- `evidence_digest`: lowercase 64-character hexadecimal string or `null`;
- `total_absence_proved`: exact `bool`.

No mapping, list, integer, Boolean-as-integer, or arbitrary object may occupy a
string/digest field.

Use this exact status enum:

1. `unchecked`
2. `exact_complete_family`
3. `absent`
4. `partial`
5. `duplicate`
6. `foreign`
7. `malformed`
8. `unreadable`
9. `route_identity_conflict`
10. `competing_complete_scope_winner`

## M1-B. Exact status table

Freeze this exact type/nullability table:

### `unchecked`

- `read_attempted=false`
- `readable=false`
- `evidence_ref=null`
- `evidence_digest=null`
- `total_absence_proved=false`

### `unreadable`

- `read_attempted=true`
- `readable=false`
- `evidence_ref=null`
- `evidence_digest=null`
- `total_absence_proved=false`

### `absent`

- `read_attempted=true`
- `readable=true`
- `evidence_ref=null`
- `evidence_digest=null`
- `total_absence_proved=true`

### Every other status

- `read_attempted=true`
- `readable=true`
- `evidence_ref` is a nonempty string identifying the safe observation
  evidence;
- `evidence_digest` is lowercase 64-character hexadecimal over that safe
  observation evidence;
- `total_absence_proved=false`

The evidence coordinate is observation evidence, not durable family authority.

## M1-C. Exact outcome mapping

Freeze and test:

- `committed_exact` requires exactly one exact complete family on all routes
  required by the complete-family proof, exact member/command binding, and fresh
  positive posture;
- `definitely_not_committed` requires all eight observations to be `absent`,
  every `total_absence_proved=true`, and fresh positive posture;
- `competing_complete_scope_winner` proves original-command noncommit only under
  the exact scope-winner route and leaves fresh acceptance ineligible;
- `unchecked`, `partial`, `duplicate`, `foreign`, `malformed`, `unreadable`,
  `route_identity_conflict`, mixed statuses, missing/duplicate route
  observations, or insufficient posture yield `unresolved`.

No missing observation is silently converted to absence.

## M1-D. Fresh posture fields

Remove or replace any ambiguous single posture ref/digest pair in the recovery
result.

The recovery observation/projection grammar must carry or bind exactly:

- current continuity posture ref and digest;
- current sole-active posture ref and digest;
- canonical lineage and scope.

If a composite posture identity is retained, define its domain-separated
derivation explicitly from those six exact coordinates and test it
independently. Otherwise carry the two exact posture pairs directly.

Historical basis rows do not satisfy these fields.

## M1-E. Independence

Fix the status enum and outcome mapping independently from:

- the document machine list;
- observation builders;
- recovery-classifier implementation.

A joint change from `malformed` to `unverified` in machine data, builder, and
test helper must fail the independent fixed enum or unchanged decision-owner
anchor.

# Finding M2 — exhaustive guarded-relation raw-field coverage

The V5 contract declares twenty-six canonical relation raw fields. The verifier
must prove every field, not a selected subset.

## M2-A. Canonical relation reconstruction

Construct one independently fixed canonical relation from:

- actual verified admission values;
- actual closed command and canonical command digest;
- actual C2 returned branch;
- actual current-v1 decision/version/head/result members;
- actual target basis and guarded-result members;
- optional acceptance fact only on acceptance.

Do not let the relation validator reconstruct omitted values from hidden
defaults.

Its input must be the complete supplied relation value.

## M2-B. Per-field matrix

Parameterize all twenty-six relation fields.

For each field:

1. mutate only that supplied raw field to another same-typed value;
2. recompute the relation self-digest;
3. recompute every downstream guarded/graph/receipt digest necessary to form a
   syntactically coherent hostile family;
4. require rejection against the independently canonical source member or
   owner rule at a field-specific boundary.

Include exact controls for:

- branch;
- lineage and scope;
- command digest;
- every admission/basis ref and digest;
- decision and version refs/digests;
- historical head ref/revision/full value/digest;
- generic result projection value/ref/digest;
- deterministic family route;
- guarded-result expectation;
- acceptance ref/digest on acceptance;
- exact null acceptance ref/digest on every nonaccept branch;
- schema and relation identity.

`historical_head_revision=True` must fail as type mismatch.

## M2-C. Omitted, duplicate, and extra fields

Reject:

- missing field;
- duplicate JSON key;
- unknown extra field;
- reordered field when canonical order is normative;
- null in a non-null field;
- non-null acceptance fields on nonaccept;
- null acceptance fields on acceptance.

# Finding H2 — unchanged-owner-derived normative truth

The private test must stop returning a mutable private tuple after checking one
or two owner facts.

## H2-A. Owner claim references

For every authority-sensitive private clause, the private machine block must
contain exactly:

- `clause_id`;
- `owner_document`;
- `owner_machine_marker`;
- `owner_json_pointer` or exact bounded owner key path;
- `private_value_consequence_id`.

It must not repeat the owner’s Boolean or polarity as an independently mutable
private truth.

The private tagged prose states only the value-level consequence and references
the clause ID.

## H2-B. Generic owner resolver

The verifier must:

1. parse the unchanged owner document’s machine block at the exact stable
   marker;
2. resolve the declared owner pointer;
3. derive the semantic polarity and protected action directly from the owner
   value;
4. derive the expected private consequence through a closed generic mapping;
5. compare that result with:
   - the private consequence ID;
   - the parsed private tagged prose;
   - fixed test expectations for the required owner-reference inventory.

Do not return a semantic tuple authored in the private test.

Changing private prose, private machine consequence, and private test literals
together must still fail because the unchanged owner value resolves to the
opposite consequence.

## H2-C. Required owner anchors

At minimum resolve unchanged owner facts for:

- replay creates no new fact;
- replay creates no new timestamp;
- prospective coordinate cannot select or veto branch;
- fresh current posture is required;
- local absence is not authority or proof;
- command relation cannot admit or select scope;
- nonaccept retains collision coverage;
- one result/receipt/replay/recovery owner;
- terminal cannot create, repair, reset, or replenish acceptance;
- ES routing cannot replenish the direct-local allowance.

If an exact owner fact is represented by more than one key, define the bounded
composition from those unchanged values.

# Finding H3 — bounded prose parser without shadowing or false positives

## H3-A. Exact protected subjects

Use exact token-sequence subject recognition, not substring matching.

Include at least:

- `replay`
- `exact replay`
- `replay adapter`
- `prospective acceptance coordinate`
- `reserved acceptance-fact coordinate`
- `command relation`
- `local row absence`
- `historical continuity basis`
- `current continuity posture`
- `nonaccept branch`
- `terminal outcome`
- `ES routing`

Do not treat these neutral noun compounds as protected subjects:

- `replay glossary`
- `replay diagram`
- `replay example`
- `receipt documentation`
- `timestamp terminology`

A protected alias is recognized only when the full noun phrase matches the
closed subject inventory or when `it` immediately refers to the protected
subject in the same visible block.

## H3-B. Exact modal inventory

Recognize at least:

- `may`
- `might`
- `must`
- `shall`
- `can`
- `could`
- `is permitted to`
- `is allowed to`
- `is authorized to`
- `is sufficient to`
- `may not`
- `must not`
- `cannot`

## H3-C. Exact protected action grammar

Recognize closed action/object combinations for:

- create or recreate an acceptance fact;
- create a second receipt;
- refresh or create a timestamp;
- admit or select a scope;
- prove noncommit;
- establish current permission;
- skip a collision route;
- replenish or renew an acceptance allowance;
- force or veto an authoritative branch.

Do not match neutral uses of words such as `create`, `receipt`, or `timestamp`
outside those exact protected constructions.

## H3-D. Same-block immediate reference

Maintain immediate protected-subject context across adjacent sentences in the
same Markdown block:

```text
Replay is authorized. It creates a new acceptance fact.
```

The second sentence inherits `replay` as its subject and must fail.

Do not carry subject context across headings, list items, table rows, separate
paragraphs, or unrelated sentences.

## H3-E. Visible Markdown coverage

Parse outside fenced code and machine JSON:

- headings;
- paragraphs;
- blockquotes;
- list items and continuation lines;
- table cells;
- link labels.

Every authority-sensitive normative statement must be a tagged registered
clause. Untagged contradictions fail.

Neutral explanatory prose must pass.

# Required lifecycle, recovery, relation, and owner-anchor controls

Add permanent tests for:

- lifecycle membership of every node;
- five fresh-write branch DAGs;
- exact replay graph;
- exact recovery graph;
- validated admission/current posture as branch ancestor;
- no cross-lifecycle dependency;
- all ten recovery statuses and exact field grammar;
- every recovery outcome mapping;
- every one of twenty-six relation fields;
- unchanged-owner resolution for every private clause;
- exact modal/subject/action parser behavior;
- neutral noun-compound controls.

# Required transformed external copies

Execute at minimum the following transformed categories. Every copy must retain
the final expected private-test collection and fail at the intended exact
boundary unless explicitly identified as a neutral positive control.

## Lifecycle

1. assign recovery projection to fresh-write lifecycle;
2. make authoritative branch depend on recovery projection;
3. remove validated admission/current-posture ancestor;
4. let historical basis satisfy fresh posture;
5. put replay projection in fresh-write construction;
6. let recovery observation create a family member;
7. omit one acceptance-only node from acceptance DAG;
8. retain an acceptance edge in one nonaccept DAG.

## Recovery observation grammar

9. replace `malformed` with `unverified` in machine, builder, and helper;
10. omit `unchecked` status;
11. pass dict as evidence ref;
12. pass list as evidence digest;
13. pass bool as evidence string;
14. mark unreadable as absence;
15. mark unchecked as absence;
16. omit one route observation;
17. duplicate one route observation;
18. mix `absent` and `partial` but classify definitely-not-committed;
19. permit total absence without fresh posture;
20. derive one posture pair from historical basis;
21. alter observation/status expectations together;
22. change competing-winner mapping to fresh eligibility.

## Relation fields

23. independently mutate each of the twenty-six raw fields with all downstream
    target digests resealed;
24. omit each required field;
25. add unknown field;
26. reorder normative fields;
27. accept Boolean head revision;
28. non-null acceptance field on nonaccept;
29. null acceptance field on acceptance;
30. relation validator reconstructs hidden defaults instead of validating
    supplied fields.

## Owner anchors

31. private replay prose/machine/test all changed to permit new fact;
32. private replay timestamp rule jointly reversed;
33. private coordinate branch rule jointly reversed;
34. private local-absence rule jointly reversed;
35. private command-admission rule jointly reversed;
36. private nonaccept-route rule jointly reversed;
37. private terminal rule jointly reversed;
38. private ES rule jointly reversed;
39. owner pointer changed to an unrelated true value;
40. owner marker changed to another machine block;
41. generic resolver returns a private-test literal rather than owner-derived
    value.

## Prose parsing

42. `Replay might create a new fact.`
43. `A replay adapter may create a second receipt.`
44. `Replay is authorized. It creates a new acceptance fact.`
45. contradictory heading;
46. contradictory bullet plus continuation;
47. contradictory table cell;
48. contradictory blockquote;
49. contradictory link label;
50. prospective-coordinate force/veto modal variants;
51. local-absence sufficient-to-prove variant;
52. terminal/ES replenish synonyms;
53. untagged authority statement.

### Neutral positive controls

These must pass:

54. `The replay glossary may include the term timestamp.`
55. `The replay diagram may describe receipt creation.`
56. `This receipt documentation can include an example.`
57. `Timestamp terminology might evolve in explanatory prose.`

No negative receives credit for syntax, import, formatting, or collection
shrinkage.

# Test architecture requirements

Preserve:

- recursive duplicate-key rejection;
- exact built-in type comparison, including bool/int separation;
- fixed test expectations independent from the private machine block;
- current-source-derived v1 facts;
- one logical result/receipt/replay/recovery owner;
- no broad source manifest;
- no physical schema emulator;
- no second reducer;
- no file-hash-only correctness claim.

Separate and report:

1. permanent internal negative controls;
2. actual transformed external copies;
3. ordinary regression validation.

# Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution and report exact counts.

Run:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening V5 reference: `557 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contract modules
   - reference: `1,623 passed`.

3. Specified B1, C2B2 values, and migration-0002 modules
   - reference: `458 passed`.

4. Operating-model, architecture, and runtime modules
   - reference: `77 passed`.

5. Broad:
   `tests/test_rw0_*.py tests/test_c2b*.py tests/test_sqlite_c2b*.py tests/test_sqlite_rw0*.py`
   - opening V5 reference: `4,560 passed`.

6. Complete repository
   - opening V5 reference: `8,374 passed, 3 warnings`.

The full-suite increase may equal only the exact new contract-test nodes.

The only accepted warnings remain the unchanged Python 3.13
multithreaded-`fork()` warnings from existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling;
- proof the other four candidate documents remain byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- exact live-cache opening/closing member equality;
- removal of all engagement-created temporary data.

Never import repository modules from the live checkout. If any live bytecode or
cache member is created, stop, restore only the exact engagement-created member
when independently identified, and report the process deviation. A success
result requires exact opening/closing live-cache equality.

# Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact two-file V5-to-V6 transition;
6. proof the other four candidate paths stayed byte-identical;
7. lifecycle-partition inventories and DAG counts;
8. validated-admission/current-posture branch ancestry;
9. exact recovery observation grammar and status matrix;
10. recovery result/posture binding;
11. twenty-six-field relation coverage;
12. owner-reference registry and generic owner resolver;
13. bounded subject/modal/action parser and neutral controls;
14. disposition of every V5 audit finding;
15. permanent controls versus transformed external copies;
16. exact collection and validation results;
17. source/migration/public/runtime preservation;
18. deterministic final six-path patch bytes and SHA-256;
19. fully specified final canonical receipt grammar, bytes, and SHA-256;
20. live-cache equality and cleanup;
21. remaining physical seams;
22. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

# Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the two-file ceiling is insufficient;
- another owner document must change;
- lifecycle partitioning requires a second replay/recovery owner;
- the exact recovery observation grammar requires SQL or reader-layout design;
- owner-derived normative truth cannot be resolved from stable unchanged owner
  machine markers;
- relation-field closure requires source or migration changes;
- source, migration, export, or existing test changes are required.

Restore the exact opening V5 candidate under a blocking result.

# Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V6_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V6_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

# Required non-actions

State:

```text
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_OPENING_AND_CLOSING_EQUAL
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
