# Governed Execution Coordinator — RW0-C2 Private Value Contract V7 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and receipt-graph-profile
V7 candidate.

This audit follows a two-file repair intended to close the V6 audit findings:

1. the logical `complete-family-recovery-result-v1` had two incompatible field
   grammars, and the result projector accepted a supplied classification that
   could disagree with the observation classifier;
2. private owner-anchor logic chose action and polarity from mutable private
   mappings before evaluating unchanged owner facts, so unrelated same-valued
   owner pointers and coupled private reversals survived;
3. protected mixed-clause prose such as permission to create a fact followed by
   a prohibition on refreshing a timestamp bypassed the parser;
4. private-owned lifecycle/status/result vocabulary lacked one explicit
   versioned profile and a clear boundary between ordinary repository tests and
   fresh independent-audit authority.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort;
- parent filesystem/permission posture, when visible.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
audit packages, Downloads artifacts, Project artifacts, or generated manifests.
The V7 closeout is evidence only; independently reproduce every material claim
from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V7 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 202,206 | `3913b1e13264400e942ba092fe0f2bd3c5397b73e82aea38b998b4c87d00073a` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 294,909 | `5e72ac38c544a64df1e0980095ba95bc5052f5c434b277a7141bb850b9000975` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `512,533`
- SHA-256:
  `c8be598dbdb2881ad9fdd51ec08b90586e86b2db3e4860ef16a9d88ab1787896`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `b38d5dcbe70457c2def3c7d42ebdb0583032eb7e52c7c9fea98198b8703e7516`

Use two structurally independent serializers and require byte-identical output.

## V6-to-V7 transition evidence

The V7 closeout reports that only these two paths changed from the independently
blocked V6 candidate:

| Path | V6 bytes / SHA-256 | V7 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `194,221` / `12a285cc7f434e393468ed57f9994dba152d1ef72dcc563ff25d47ef500217a3` | `202,206` / `3913b1e13264400e942ba092fe0f2bd3c5397b73e82aea38b998b4c87d00073a` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `269,031` / `8b525f758488e5c88e62d22c0220f220e71b027758e6dc02d4d5ebbf324a8a98` | `294,909` / `5e72ac38c544a64df1e0980095ba95bc5052f5c434b277a7141bb850b9000975` |

The reported fixed-label unified V6-to-V7 diff of those two files is:

- bytes: `88,846`
- SHA-256:
  `0e01b9334332855a80b396076683b4c127029a19b226ba044de57e1a682f1d7c`

The other four candidate documents have the same receipts in V6 and V7.

The live V7 bytes are the primary audit target. Do not request historical V6
files. If V6 bytes are absent from the live checkout, classify the exact
two-file transition as corroborating history rather than blocking live
provenance.

## Prior V6 audit findings

The V6 audit established exact provenance and blocked because:

- the logical recovery-result schema conflicted with the result projection and
  a supplied classification could override the classifier;
- owner pointers could move to unrelated same-valued owner facts;
- private owner action/polarity maps could reverse unchanged owner meaning;
- a mixed protected sentence could permit creating a fact while prohibiting
  timestamp creation and still pass;
- private lifecycle/status vocabulary had no explicit versioned profile and
  coordinated private edits were being treated as if mutable tests could
  self-authenticate them.

Audit the V7 repair rather than assuming those findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Subagents must not import modules from the live checkout. If their read-only
posture or model availability cannot be guaranteed, continue parent-only and
record the limitation. Explorer unavailability is not itself a candidate
defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, lifecycle-partition, branch-profile, static
graph-profile, transient observation/query-value, private vocabulary, and
bounded private consequence semantics. It remains subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, fresh continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, exact replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive fresh continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one generic v1 receipt root, one replay owner, and one
   whole-family recovery owner;
10. the decision writer cannot provision, repair, renew, or replenish
    admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` remains compatibility/nonproof only;
13. the static receipt profile is verification metadata selected through the
    guarded result, not a graph member or durable row;
14. fresh write, exact replay, and uncertain recovery are distinct lifecycle
    contracts;
15. private lifecycle/status/result vocabulary changes require a successor
    profile and fresh independent audit.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- only the private-value contract and its verifier differ from their V6 endpoint
  receipts;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, exports, StateStore, readers, writers, transactions,
  public/runtime surfaces, configuration, and examples remain unchanged;
- migration `0005` remains absent;
- no accepted architecture changed outside recovery-result unification,
  owner-assertion mechanics, private vocabulary versioning, and bounded prose
  parsing.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — one recovery-result grammar

Independently locate every representation of
`complete-family-recovery-result-v1`:

- logical schema inventory;
- machine schema definition;
- human table;
- recovery projection section;
- vocabulary profile;
- builders;
- projectors;
- fixed expectations;
- positive and negative tests.

Require one exact payload in this exact semantic order:

1. `classification`
2. `lineage_ref`
3. `scope_ref`
4. `current_continuity_posture_ref`
5. `current_continuity_posture_digest`
6. `current_sole_active_posture_ref`
7. `current_sole_active_posture_digest`

A uniform `schema_id` may precede these fields only if that convention is used
consistently by the contract’s canonical values. Report the exact final
grammar.

Require complete removal from this result value of:

- `fresh_external_posture_ref`;
- `fresh_external_posture_digest`;
- `observed_family_digest`;
- `reason`;
- result self-digest;
- any undefined composite posture identity.

No compatibility alias or second result version is allowed.

## Audit question 3 — computed recovery classification

Trace the actual recovery-result projector.

Require:

- it accepts a validated recovery observation set, canonical selector/command
  binding, lineage/scope, and two current posture pairs;
- it computes classification internally;
- it has no classification override argument;
- it copies lineage/scope and both posture pairs from validated inputs;
- historical basis values cannot fill current posture fields;
- output fields and types match the one canonical result schema.

Independently reproduce:

- exact complete family → `committed_exact`;
- eight proved absences + positive fresh posture →
  `definitely_not_committed`;
- competing complete scope winner → original-command
  `definitely_not_committed`, with no fresh eligibility implication;
- every partial, mixed, malformed, duplicate, foreign, unreadable, unchecked,
  route-conflicting, missing-route, or insufficient-posture case →
  `unresolved`.

Attempt to supply an inconsistent classification. It must be impossible through
the normal interface or rejected at an exact boundary.

## Audit question 4 — private vocabulary profile

Independently verify the static profile:

`rw0-c2-private-value-contract-v1`

Require the exact lifecycle inventory:

- `fresh_write_construction_v1`
- `exact_replay_readback_v1`
- `uncertain_commit_recovery_v1`

Require the exact route-observation status inventory:

- `unchecked`
- `exact_complete_family`
- `absent`
- `partial`
- `duplicate`
- `foreign`
- `malformed`
- `unreadable`
- `route_identity_conflict`
- `competing_complete_scope_winner`

Require the exact recovery-result semantic field inventory above.

Verify:

- every consuming machine structure references the exact vocabulary/profile ID;
- one-sided drift is rejected;
- a changed vocabulary requires a new profile ID and successor contract;
- V1 is not silently reinterpreted;
- no test or prose claims that the mutable verifier can authenticate arbitrary
  coordinated edits to itself.

The fresh independent audit owns exact confirmation of this private vocabulary.
Report that boundary explicitly.

## Audit question 5 — exact owner-assertion registry

Independently reconstruct all thirteen clause records and thirty-seven
assertions from the candidate.

Each record must contain only:

- clause ID;
- unchanged owner document path;
- exact owner machine marker;
- ordered owner assertions;
- private structural consequence ID.

Each owner assertion must contain only:

- JSON pointer;
- comparison from:
  - `equals`
  - `contains`
  - `not_contains`;
- exact expected built-in value.

Require the exact clause/owner/assertion inventory reported in the V7 closeout:

### `historical_basis_non_authority`

- guard `/scope/continuity == "positively_established"`
- guard `/family/replay_historical_head_freshness == false`

### `current_external_posture`

- guard `/scope/continuity == "positively_established"`
- guard `/scope/active_authorities == 1`

### `mandatory_prospective_fact_coordinate`

- guard `/relation/every_applicable_command == true`
- guard `/acceptance_roles` contains
  `"acceptance_fact_identity"`

### `branch_nonselection`

- decision `/expected_branch/role == "conflict_assertion_only"`
- decision `/model/may_change_branch == false`
- decision `/guard/relation_grants_authority == false`
- decision `/guard/relation_requests_acceptance == false`

### `nonaccept_fact_collision`

- guard `/branch_effects/candidate_repair == 0`
- guard `/taxonomy/fact_identity_collision ==
  "preassigned_identity_or_family_route_collision"`

### `closed_collision_routes`

- guard `/taxonomy/family_route_collision ==
  "preassigned_identity_or_family_route_collision"`
- guard `/eligibility/acceptance_only` contains
  `"exact_command_family_route"`
- guard `/relation/recovery_selector_covered == true`

### `total_absence_currentness`

- decision `/recovery/unresolved_creates_decision == false`
- decision `/recovery/automatic_retry_after_unresolved == false`
- decision `/recovery/readback/ambiguous == "unresolved"`

### `replay_original_fact_timestamp`

- guard `/family/replay_new_fact == false`
- guard `/family/replay_new_timestamp == false`

### `admitted_scope_only`

- guard `/relation/authority == false`
- guard `/relation/requests_acceptance == false`
- guard `/relation/roles` contains
  `"canonical_scope_expectation"`
- guard `/scope/local_absence_is_proof == false`

### `separate_admission_decision_writers`

- guard `/authority/admission == "external_standing_policy"`
- guard `/authority/writer ==
  "future_guarded_decision_transaction"`
- guard `/relation/prohibited` contains `"caller_admission"`

### `single_result_receipt_replay_recovery`

- guard `/family/separate_receipt == false`
- guard `/family/separate_replay == false`
- guard `/family/separate_recovery == false`
- guard `/authority/replay == "decision_owner"`
- guard `/authority/recovery == "decision_owner"`

### `terminal_nonreplenishment`

- guard `/terminal/mutates_guard == false`
- guard `/scope/forbidden_changes` contains `"replenish"`

### `es_nonreplenishment`

- guard `/es/replenishes == false`
- guard `/es/new_grant_or_policy_epoch_replenishes == false`
- guard `/es/separately_governed == true`

Reconcile exact live marker/pointer spelling. Any difference from the table must
be explained and independently justified from the unchanged owner.

## Audit question 6 — pointer semantic purpose

For every owner pointer, verify:

- exact owner document;
- exact machine marker;
- enclosing object;
- terminal key;
- exact built-in value;
- semantic relation to the private clause;
- allowed private structural consequence IDs.

A pointer to an unrelated value with the same Boolean/string type and value is
invalid.

Independently mutate pointers to:

- unrelated false values;
- unrelated true values;
- same-typed strings;
- another valid owner block;
- another existing list containing the same member.

Every substitution must fail a fixed pointer-purpose boundary.

Do not rely on absolute line numbers.

## Audit question 7 — generic comparison-only owner resolver

Trace the resolver’s actual dataflow.

Require it to:

1. load the declared unchanged owner machine block;
2. resolve every declared owner pointer;
3. perform only the declared generic comparison;
4. return the observed assertion records;
5. invoke the declared private structural consequence.

It must not:

- choose action from a private action map;
- choose polarity from a private required/forbidden set;
- return a private-test-authored semantic tuple;
- default a missing owner value;
- reconstruct owner meaning from private prose.

Independently reverse private prose, private machine consequence, private test
literal, and consequence ID together while leaving owner assertions unchanged.
The coupled edit must fail either the fixed assertion inventory or the
independently executed structural consequence.

## Audit question 8 — structural consequences

Independently locate and execute the structural consequence for every clause.

Require each consequence to inspect actual private machine/value/graph
structure, not merely return true or compare prose.

At minimum verify:

- `historical_basis_not_current_permission`
- `fresh_posture_required_for_protected_disclosure`
- `derived_nonnull_coordinate_required`
- `coordinate_cannot_force_or_veto_branch`
- `nonaccept_fact_absent_but_collision_probed`
- `eight_exact_routes_required`
- `local_absence_cannot_prove_noncommit`
- `replay_creates_no_fact_or_timestamp`
- `command_relation_cannot_admit_scope`
- `decision_writer_cannot_provision_admission`
- `one_decision_owned_result_receipt_replay_recovery`
- `terminal_cannot_replenish_acceptance`
- `es_cannot_replenish_direct_local_allowance`

Mutate each helper to constant true. Every mutation must fail an independent
structural or owner assertion.

## Audit question 9 — mixed-clause segmentation

Inspect the visible-text parser.

Require segmentation at:

- sentence boundaries;
- semicolons;
- `but`;
- `however`;
- `although`;
- `yet`;
- `while`;
- `and` followed by an explicit negative, when used by the V7 grammar.

Each protected action/object/modal segment is evaluated independently. A
negative segment must not cancel an earlier positive permission.

This must fail:

```text
Replay may create a new acceptance fact but no new timestamp.
```

Also test reversed order:

```text
Replay may not create a new timestamp but may create a new acceptance fact.
```

Both are contradictory because they permit fact creation.

## Audit question 10 — subject, modal, and action grammar

Require exact protected subject phrases:

- replay;
- exact replay;
- replay adapter;
- prospective acceptance coordinate;
- reserved acceptance-fact coordinate;
- command relation;
- local row absence;
- historical continuity basis;
- current continuity posture;
- nonaccept branch;
- terminal outcome;
- ES routing.

Neutral compounds must not match:

- replay glossary;
- replay diagram;
- replay example;
- receipt documentation;
- timestamp terminology.

Require modal recognition of:

- may;
- might;
- must;
- shall;
- can;
- could;
- is permitted to;
- is allowed to;
- is authorized to;
- is sufficient to;
- may not;
- must not;
- cannot.

Require protected actions over exact objects:

- create/recreate acceptance fact;
- create second receipt;
- create/refresh timestamp;
- admit/select scope;
- prove noncommit;
- establish current permission;
- skip collision route;
- replenish/renew allowance;
- force/veto authoritative branch.

Reject broad stem matching that would turn neutral documentation phrases into
authority statements.

## Audit question 11 — same-block pronoun context and Markdown coverage

Require immediate protected-subject context across adjacent segments in the
same visible Markdown block only.

This must fail:

```text
Replay is authorized. It creates a new acceptance fact.
```

Subject context must not cross:

- headings;
- separate paragraphs;
- different list items;
- different table rows;
- unrelated intervening sentences.

Parse outside fenced code and machine JSON:

- headings;
- paragraphs;
- blockquotes;
- list items and continuations;
- tables/cells;
- link labels.

Untagged authority-sensitive statements fail.

The four neutral controls must pass:

```text
The replay glossary may include the term timestamp.
The replay diagram may describe receipt creation.
This receipt documentation can include an example.
Timestamp terminology might evolve in explanatory prose.
```

## Audit question 12 — preserved V6 lifecycle and family work

Independently re-verify, without reopening the selected architecture:

- exact private vocabulary/profile consumption;
- 86-node lifecycle registry;
- five fresh-write DAGs;
- exact replay graph;
- uncertain-recovery graph;
- validated admission/current posture as branch ancestor;
- ten-status typed observations;
- all 26 guarded-relation fields;
- canonical command digest and selector binding;
- current-v1 source mapping;
- actual C2 returned-branch causality;
- canonical current-v1 five-branch families;
- target supplemental-member binding;
- static profile and complete receipt-role family;
- exact replay and recovery semantics;
- v1, B1, and nonimplementation boundaries.

Block any regression.

## Audit question 13 — test independence and audit boundary

Inspect the reported 737-node verifier.

Require independent authorship among:

- exact private vocabulary profile;
- recovery-result schema and projector;
- fixed owner assertion inventory;
- owner marker/pointer purpose expectations;
- structural consequence implementations;
- tagged private prose;
- private machine consequence IDs;
- subject/modal/action parser expectations;
- neutral controls;
- preserved lifecycle/relation/family expectations;
- current-source-derived v1 facts;
- internal hostile expectations;
- external transformed copies.

Reject:

- owner assertion inventory generated from candidate rows under test;
- resolver action/polarity selected from private literals;
- structural consequence helper returning constant success;
- projector accepting caller classification;
- recovery result builder authoring expected schema;
- prose vocabulary extracted from document under test;
- broad source-manifest freezing;
- hash-only correctness;
- a second reducer, replay/recovery engine, or physical schema emulator.

Acknowledge explicitly:

- private-owned vocabulary cannot self-authenticate arbitrary coordinated edits
  to both contract and verifier;
- the fresh independent audit is the authority that verifies the exact V7
  vocabulary against this prompt and accepted architecture.

## Audit question 14 — implementation-reported transformed copies

Independently recreate all hostile categories reported by V7, plus exact
parameterized variants.

### Recovery-result grammar and projector

- old composite posture fields restored in schema only;
- old fields restored in projection only;
- `observed_family_digest` added to one representation;
- lineage/scope omitted;
- one continuity coordinate omitted;
- one sole-active coordinate omitted;
- projector accepts supplied classification;
- partial evidence classified definitely-not-committed;
- complete family classified unresolved;
- competing winner grants fresh eligibility;
- historical bases populate current posture;
- builder/schema changed together while fixed V7 vocabulary remains.

### Owner assertions and resolver

- branch pointer moved to unrelated runtime-active false;
- replay fact pointer moved to another false value;
- owner marker moved to another machine block;
- expected owner value changed;
- private consequence ID changed to unrelated structural consequence;
- structural consequence returns true;
- private prose/machine/literals/consequence reversed together;
- resolver reintroduces private action/polarity map;
- one required assertion omitted;
- unrelated same-valued pointer substituted.

### Vocabulary one-sided drift

- lifecycle ID changed in document only;
- lifecycle ID changed in machine only;
- lifecycle ID changed in consuming profile only;
- one status renamed in one representation;
- one recovery-result field changed in one representation;
- vocabulary changed without new profile ID;
- profile ID changed while one consumer remains V1.

### Prose parser

- mixed fact/timestamp clause in both orders;
- replay adapter might create second receipt;
- two-sentence replay authorization/fact creation;
- semicolon form;
- `however`, `although`, `yet`, and `while` forms;
- force/veto variants;
- local-absence sufficient-to-prove;
- nonaccept skip route;
- terminal/ES replenish variants;
- contradictory heading, bullet, table, quote, and link label;
- untagged authority statement.

Every hostile copy must retain the exact final private-test collection and fail
at the intended semantic boundary.

The four neutral controls must retain collection and pass.

## Audit question 15 — additional coupled mutants

In addition to the reported categories, test at least:

1. result schema, builder, projector, and test expectation changed together to
   the old composite posture form;
2. classification argument reintroduced and classifier changed to trust it;
3. owner assertion table, pointer-purpose expectation, and consequence mapping
   changed together to an unrelated owner fact;
4. owner marker and pointer changed together to a different valid machine
   block;
5. structural consequence implementation and its direct test changed together
   to constant true;
6. private vocabulary profile and every consuming private structure changed
   together;
7. parser subject vocabulary and contradictory prose changed together;
8. parser modal list drops `might` while hostile prose uses it;
9. parser treats `no new` as whole-sentence negation again;
10. immediate pronoun context disabled while direct one-sentence tests remain;
11. neutral compounds added to protected subject aliases;
12. exact owner assertion still passes but private structural consequence is
    inconsistent with the clause;
13. recovery-result classification is correct but posture pairs are from a
    different lineage/scope;
14. competing winner returns definitely-not-committed and also flips an
    eligibility flag elsewhere;
15. one-sided status drift plus vocabulary profile mismatch;
16. tagged prose clause ID matches but consequence ID names another valid
    clause.

Every negative must fail an independent schema, owner, consequence, vocabulary,
or parser boundary. Neutral controls must pass.

## Audit question 16 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `737 collected; 737 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Deterministic broad group | `4,740 collected; 4,740 passed` |
| Full repository | `8,554 collected; 8,554 passed, 3 warnings` |

The deterministic broad group must be generated exactly by:

1. expanding:
   - `tests/test_rw0_*.py`
   - `tests/test_c2b*.py`
   - `tests/test_sqlite_c2b*.py`
   - `tests/test_sqlite_rw0*.py`
2. resolving repository-relative paths;
3. sorting and deduplicating;
4. requiring exactly `48` files;
5. hashing the newline-joined paths without final newline to:
   `0c57aa37134d814b5e1dc3efb22cbe440c8c1bb6a12b8dc1b4223fb47e9893c0`;
6. passing that exact path list once to pytest.

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

Investigate every count, warning, path-inventory, or collection mismatch.

## Audit question 17 — live cache and cleanup

Before executable work, record a safe opening member-level inventory of ignored
cache paths, types, modes, sizes, mtimes, and hashes without importing live
repository modules.

The V7 closeout reports 37 live ignored-cache paths and exact member-level
opening/closing equality. Do not impose an invented aggregate unless you define
and reproduce the same grammar.

After all external work and cleanup, require exact member-level equality.

Any audit-created live cache member or modification is a provenance failure.

Remove every audit-created clone, basetemp, transformed copy, script, receipt,
and log.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- more than one recovery-result grammar;
- caller-supplied or inconsistent recovery classification;
- wrong or historical posture bound into result;
- private owner action/polarity map;
- owner pointer resolving unrelated semantics;
- missing or ineffective structural consequence;
- owner meaning reversible by coupled private edits;
- mixed protected clause surviving;
- neutral explanatory prose falsely rejected;
- private vocabulary/profile inconsistency;
- regression in V6 lifecycle, observation, relation, command, source-v1,
  C2-return, family, profile, role, replay, or recovery work;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- any mandatory transformed mutant surviving;
- unexplained collection, test-count, warning, path-inventory, or cache
  mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning/permission posture;
3. exact baseline and V7 six-path provenance;
4. patch, receipt, and transition-evidence reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. unified recovery-result grammar audit;
8. computed-classification audit;
9. private vocabulary/profile audit;
10. exact owner-assertion inventory audit;
11. pointer semantic-purpose audit;
12. generic owner-resolver audit;
13. structural consequence audit;
14. mixed-clause segmentation audit;
15. subject/modal/action grammar audit;
16. same-block pronoun and visible-Markdown audit;
17. preserved V6 lifecycle/family/nonimplementation audit;
18. test-independence and audit-boundary analysis;
19. implementation-reported transformed-copy results;
20. additional coupled-mutant results;
21. independent validation;
22. live-cache and final provenance;
23. severity-ranked findings;
24. exact next boundary;
25. required non-actions;
26. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED_BY_AUDIT
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
