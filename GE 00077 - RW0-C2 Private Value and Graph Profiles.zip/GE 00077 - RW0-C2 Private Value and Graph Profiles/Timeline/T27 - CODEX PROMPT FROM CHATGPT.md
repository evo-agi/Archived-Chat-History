# Governed Execution Coordinator — RW0-C2 Private Value Contract V6 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and receipt-graph-profile
V6 candidate.

This audit follows a two-file repair intended to close the V5 audit findings:

1. one combined dependency registry did not encode a truthful lifecycle boundary
   between fresh-write construction, exact replay readback, and uncertain-commit
   recovery;
2. authoritative branch lacked an explicit validated-admission/current-posture
   ancestor in the machine contract;
3. recovery observations lacked exact built-in types, complete nullability rules,
   an explicit `unchecked` state, and an independently fixed status-to-result
   mapping;
4. only a subset of the guarded-family relation's 26 raw fields received fully
   resealed independent negative tests;
5. private owner-anchor semantics could be reversed by changing private prose,
   machine tuples, and test literals together;
6. the bounded prose parser missed protected modal/alias/cross-sentence forms
   and falsely rejected neutral compounds.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort;
- parent filesystem/permission posture, when visible.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
audit packages, Downloads artifacts, Project artifacts, or generated manifests.
The V6 closeout is evidence only; independently reproduce every material claim
from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V6 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 194,221 | `12a285cc7f434e393468ed57f9994dba152d1ef72dcc563ff25d47ef500217a3` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 269,031 | `8b525f758488e5c88e62d22c0220f220e71b027758e6dc02d4d5ebbf324a8a98` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `478,046`
- SHA-256:
  `8990a9ecb93b023d6da6cf519b26b6f3f7a71d61917139ec6870df37d6edd496`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `a31d9d83d116e97e86c8f60d160c76b76616418abc0c643424fe7dd831ca82bd`

Use two structurally independent serializers and require byte-identical output.

## V5-to-V6 transition evidence

The V6 closeout reports that only these two paths changed from the independently
blocked V5 candidate:

| Path | V5 bytes / SHA-256 | V6 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `156,160` / `119a7218230221c8c13f8039df308035a52195731d9f71f001437c8e493991aa` | `194,221` / `12a285cc7f434e393468ed57f9994dba152d1ef72dcc563ff25d47ef500217a3` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `231,640` / `fca8e6715762bae4d97255f88cd936ea2cbbff0c32dd72dd81c7f3a0dcdd7b1b` | `269,031` / `8b525f758488e5c88e62d22c0220f220e71b027758e6dc02d4d5ebbf324a8a98` |

The other four candidate documents have the same receipts in V5 and V6.

The live V6 bytes are the primary audit target. Do not request historical V5
files. If V5 bytes are absent from the live checkout, classify the exact
two-file transition as corroborating history rather than blocking live
provenance.

## Prior V5 audit findings

The V5 audit established exact provenance and blocked because:

- the machine registry lacked a truthful separation among fresh-write, replay,
  and recovery lifecycles;
- `authoritative_branch` lacked a declared validated-admission/current-posture
  ancestor;
- moving recovery before the family remained green;
- recovery observation value fields accepted wrong built-in types;
- `unchecked` had no exact representation;
- the recovery status list and its tests could change together;
- only eight of twenty-six relation raw fields received fully resealed controls;
- owner anchors returned private-test-authored semantic tuples;
- private prose, machine tuples, and test literals could jointly reverse owner
  meaning;
- `might`, `replay adapter`, and cross-sentence replay contradictions survived;
- neutral `replay glossary` / `replay diagram` prose was falsely rejected.

Audit the V6 repair rather than assuming those findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Subagents must not import modules from the live checkout. If their read-only
posture or bytecode suppression cannot be guaranteed, continue parent-only.
Explorer unavailability is not itself a candidate defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, lifecycle-partition, branch-profile, static
graph-profile, transient observation/query-value, and bounded private
consequence semantics. It remains subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, fresh continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, exact replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive fresh continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one generic v1 receipt root, one replay owner, and one
   whole-family recovery owner;
10. the decision writer cannot provision, repair, renew, or replenish
    admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` remains compatibility/nonproof only;
13. the static receipt profile is verification metadata selected through the
    guarded result, not a graph member or durable row;
14. replay and uncertain recovery are post-read lifecycles, not inputs to fresh
    durable family construction.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- only the private-value contract and its verifier differ from their V5 endpoint
  receipts;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, exports, StateStore, readers, writers, transactions,
  public/runtime surfaces, configuration, and examples remain unchanged;
- migration `0005` remains absent;
- no accepted architecture changed outside lifecycle partitioning, observation
  grammar, relation-field coverage, owner anchoring, and bounded prose parsing.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — registry role and lifecycle partitions

Inspect the reported **86-node** registry and exact lifecycle memberships.

Require every node to declare a closed, exact lifecycle membership drawn only
from:

- `fresh_write_construction_v1`;
- `exact_replay_readback_v1`;
- `uncertain_commit_recovery_v1`;
- exact justified shared identity/value membership when a value genuinely
  participates in more than one lifecycle.

The registry is a contract dependency catalog, not a global execution schedule.

Require:

- no global stage or topological position is represented as cross-lifecycle
  execution order;
- every lifecycle has its own exact node and edge inventory;
- each lifecycle has an independent topological sort;
- shared nodes have identical meaning across lifecycles;
- no replay/recovery projection or route observation belongs to fresh-write
  construction;
- no fresh-write member depends on a replay/recovery observation or projection;
- replay and recovery are explicitly post-read;
- a numerical stage change inside one lifecycle remains meaningful only within
  that lifecycle;
- moving a recovery node to an earlier arbitrary registry number without
  changing lifecycle membership does not create a semantic failure;
- assigning recovery to fresh-write or introducing a cross-lifecycle edge does
  fail.

Independently derive node memberships rather than trusting the candidate’s
lifecycle lists.

## Audit question 3 — five fresh-write DAGs

Independently reconstruct all five branch-specific fresh-write DAGs.

Implementation references:

- `candidate_acceptance`: `70 nodes / 221 edges`;
- each nonaccept branch: `68 nodes / 205 edges`.

Do not accept those counts without deriving every node and edge.

Require this semantic ancestry:

```text
verified admission act/fact
+ explicit fresh continuity posture
+ explicit fresh sole-active posture
+ current decision basis/head/program identity
→ closed command relation and transcript
→ six sibling preassignments
→ canonical command digest
→ validated_admission_command_and_current_posture
→ authoritative C2 branch
→ one transaction timestamp
→ exact branch-specific current-v1 members
→ exact target supplemental members
→ guarded relation and guarded result
→ exact graph entries and receipt preimage
→ generic graph digest
→ final generic v1 receipt row
```

Require:

- `validated_admission_command_and_current_posture` is an ancestor of every
  authoritative branch;
- invalid/missing admission or fresh posture leaves branch unmaterialized;
- historical basis does not satisfy fresh posture;
- local session fencing is a future transaction-owner prerequisite only, not
  lineage authority;
- acceptance-only nodes and edges exist only in acceptance;
- nonaccept DAGs contain no dangling acceptance dependency;
- no node relies on hidden defaults or aggregate backedges;
- raw relation fields have explicit owning dependencies.

Independently topologically sort each DAG and compare exact edges.

## Audit question 4 — exact replay-readback graph

Independently derive the reported `7 nodes / 8 edges` exact-replay graph.

Require it to be a post-read lifecycle downstream of:

- receipt-first mutation lookup;
- canonical command digest;
- fresh current posture required for protected disclosure;
- complete exact persisted family and final receipt.

Replay must:

- return the original decision/version/head postimage;
- return the original optional acceptance fact;
- return the original supplemental members;
- return the original graph entries and generic receipt;
- return the original transaction timestamp;
- create no branch, fact, relation, result, graph, receipt, timestamp, admission,
  scope state, or retry authority;
- invoke no fresh branch or eligibility evaluation.

No replay node may feed fresh-write construction.

## Audit question 5 — uncertain-recovery graph

Independently derive the reported `56 nodes / 157 edges` recovery graph.

Require this semantic order:

```text
canonical command + complete-family selector
+ fresh current continuity/sole-active posture
+ eight actual typed route observations
→ exact complete observation set
→ existing C2-owned recovery projection
```

Require:

- recovery is post-read;
- no recovery observation or projection feeds fresh-write construction;
- selector remains a pre-read query-plan value;
- observation set is a post-read value;
- recovery projection is not a second recovery owner;
- no repair, branch reevaluation, automatic retry, new timestamp, admission
  renewal, or scope replenishment occurs;
- restore/clone with unproved continuity is unresolved.

Test a coupled machine/test lifecycle-membership change against an independently
fixed lifecycle oracle and unchanged decision-owner semantics.

## Audit question 6 — typed recovery-observation grammar

Independently verify every route observation has exactly:

- `route_role`
- `route_key`
- `status`
- `read_attempted`
- `readable`
- `evidence_ref`
- `evidence_digest`
- `total_absence_proved`

Require exact built-in types and the fixed closed status enum:

1. `unchecked`
2. `exact_complete_family`
3. `absent`
4. `partial`
5. `duplicate`
6. `foreign`
7. `malformed`
8. `unreadable`
9. `route_identity_conflict`
10. `competing_complete_scope_winner`

Require exact per-status rules:

- `unchecked`: unattempted, unreadable, null evidence, no absence proof;
- `unreadable`: attempted, unreadable, null evidence, no absence proof;
- `absent`: attempted, readable, null evidence, proved absence;
- every other status: attempted, readable, nonempty evidence ref, lowercase
  64-character hex digest, no absence proof.

Reject bool/int coercion, list/dict evidence fields, missing/extra keys,
duplicate route roles, wrong route keys, unknown status, wrong nullability, and
inconsistent read/readability flags.

The fixed enum and status table must be independently authored from the machine
block, builders, and classifier.

## Audit question 7 — recovery projection and posture binding

Verify exact outcome mapping:

- `committed_exact` requires the exact complete bound family, exact command,
  required route evidence, and fresh positive posture;
- `definitely_not_committed` requires all eight observations `absent`, all eight
  absence proofs true, and fresh positive posture;
- `competing_complete_scope_winner` may prove original-command noncommit only
  on the scope-winner route and must not renew acceptance eligibility;
- every mixed, missing, duplicate, partial, foreign, malformed, unreadable,
  unchecked, conflicting, or insufficient-posture case is `unresolved`.

Require the projection/result to bind exactly:

- canonical lineage;
- canonical scope;
- current continuity posture ref/digest;
- current sole-active posture ref/digest.

Historical basis rows cannot satisfy them.

If a composite posture identity exists, independently reconstruct its
domain-separated preimage. Otherwise require the two exact pairs directly.

A coupled status-enum, builder, and outcome-expectation mutation must fail an
independent fixed oracle or unchanged decision-owner anchor.

## Audit question 8 — all 26 guarded-relation fields

Derive the exact ordered 26-field relation grammar and self-digest from the
candidate machine contract.

Independently reconstruct one canonical supplied relation from actual verified
admission, command, C2 branch, current-v1 family, supplemental members, family
route, guarded-result expectation, and optional acceptance fact.

Require the validator to consume the complete supplied relation; it must not
reconstruct omitted or hostile values from hidden defaults.

For each of the 26 raw fields:

1. mutate only that field to another same-typed value;
2. recompute relation self-digest;
3. recompute every downstream guarded-result, graph, and receipt digest required
   to form a syntactically coherent hostile family;
4. require rejection against an independently reconstructed owner/member value
   at a field-specific boundary.

Also test:

- omission of each field;
- duplicate JSON key;
- unknown extra field;
- normative order violation;
- null in every non-null field;
- `historical_head_revision=True`;
- non-null acceptance fields on nonaccept;
- null acceptance fields on acceptance;
- wrong relation schema/ref;
- relation builder and expected values changed together.

All 26 fields—not a selected subset—must have causal coverage.

## Audit question 9 — owner-reference registry

Inspect all thirteen private owner references.

Require each to contain exactly:

- clause ID;
- unchanged owner document path;
- exact stable machine marker;
- bounded owner JSON pointer/key path;
- private value-level consequence ID.

The private machine contract must not copy the owner’s Boolean/polarity as a
separately mutable truth.

Verify every marker/pointer resolves to the intended unchanged guard or decision
owner fact, not an unrelated convenient true value.

Changing the marker or pointer to another existing owner value must fail fixed
owner-reference expectations.

## Audit question 10 — generic owner resolver

Independently trace the resolver.

Require it to:

1. parse the unchanged owner machine block at the declared marker;
2. resolve the declared path;
3. derive protected action and polarity from the actual owner value through a
   closed generic mapping;
4. derive the private consequence;
5. compare that owner-derived result with:
   - consequence ID;
   - private machine tuple;
   - parsed tagged private prose;
   - fixed test expectation.

It must not return a semantic tuple authored in the private test.

Jointly reversing private prose, private machine tuple, consequence ID, and
private test literals must still fail the unchanged owner value.

Mutate resolver logic, owner pointer, owner marker, and private literals
together; unchanged owner semantics must remain authoritative.

## Audit question 11 — bounded subject/modal/action parser

Independently verify the exact protected subject inventory, including:

- replay;
- exact replay;
- replay adapter;
- prospective acceptance coordinate;
- reserved acceptance-fact coordinate;
- command relation;
- local row absence;
- historical continuity basis;
- current continuity posture;
- nonaccept branch;
- terminal outcome;
- ES routing.

Require exact noun-phrase matching. Neutral compounds must not become protected
subjects:

- replay glossary;
- replay diagram;
- replay example;
- receipt documentation;
- timestamp terminology.

Require exact modal coverage including:

- may;
- might;
- must;
- shall;
- can;
- could;
- is permitted to;
- is allowed to;
- is authorized to;
- is sufficient to;
- may not;
- must not;
- cannot.

Require exact protected action/object constructions for:

- create/recreate acceptance fact;
- create second receipt;
- create/refresh timestamp;
- admit/select scope;
- prove noncommit;
- establish current permission;
- skip collision route;
- replenish/renew allowance;
- force/veto authoritative branch.

Do not use broad word stems that reject neutral documentation prose.

## Audit question 12 — visible Markdown and immediate pronoun context

The parser must inspect visible text outside fenced code/machine JSON across:

- headings;
- paragraphs;
- blockquotes;
- list items and continuation lines;
- table cells;
- link labels.

Maintain immediate protected-subject context only across adjacent sentences in
the same visible block.

This must fail:

```text
Replay is authorized. It creates a new acceptance fact.
```

Subject context must not cross:

- headings;
- separate paragraphs;
- different list items;
- different table rows;
- unrelated intervening sentences.

These neutral sentences must pass:

```text
The replay glossary may include the term timestamp.
The replay diagram may describe receipt creation.
This receipt documentation can include an example.
Timestamp terminology might evolve in explanatory prose.
```

Test tagged and untagged forms, modal aliases, subject aliases, and joint
private mutations.

## Audit question 13 — preserved V5 advances and no regressions

Re-verify that V6 preserves:

- canonical guarded command digest and fixed vector;
- command-selector-route-family binding;
- source-exact current-v1 receipt mapping;
- explicit fresh posture before C2;
- actual C2 returned-branch causality;
- canonical current-v1 five-branch family construction;
- target supplemental-member binding;
- static receipt profile through guarded result;
- ten common roles plus acceptance-only role;
- exact replay of original family and timestamp;
- one logical result/receipt/replay/recovery owner;
- current v1 and B1 meanings;
- target-only nonimplementation status.

Block any regression or new shadow implementation.

## Audit question 14 — test independence and shadow-owner risk

Inspect the reported 687-node verifier.

Require independent authorship among:

- lifecycle membership expectations;
- branch-expanded DAG expectations;
- recovery status enum/table;
- recovery outcome mapping;
- complete relation field expectations;
- unchanged owner markers/pointers;
- generic owner resolver mapping;
- private machine tuples;
- tagged prose;
- fixed parser subjects/modals/actions;
- current-source-derived v1 facts;
- internal hostile expectations;
- external transformed copies.

Reject:

- one helper generating and validating the same lifecycle graph;
- recovery enum and outcome map derived from the machine block;
- relation builder authoring expected raw fields;
- owner resolver returning private-test literals;
- prose vocabulary extracted from the document under test;
- broad source-manifest freezing;
- hash-only correctness;
- a second reducer, replay/recovery engine, or physical schema emulator.

Require recursive duplicate-key rejection and exact built-in type comparison,
including bool/int separation.

## Audit question 15 — implementation-reported transformed copies

Independently recreate the V6 reported matrix against the exact final candidate.

### Relation field and omission copies

Require:

- 26 same-type fully resealed raw-field mutations;
- 26 individual raw-field omissions;
- extra/duplicate/order/nullability/Boolean and branch-specific acceptance-field
  controls.

Every copy must retain the exact final private-test collection and fail at the
intended field-specific boundary.

### Lifecycle, recovery, and other relation copies

At minimum reproduce:

- recovery assigned to fresh-write lifecycle;
- fresh-write branch depends on recovery;
- validated-admission/current-posture ancestor removed;
- historical basis substitutes for fresh posture;
- replay projection enters fresh write;
- recovery observation creates family member;
- acceptance-only node omitted on acceptance;
- acceptance edge retained on nonaccept;
- `malformed` jointly renamed in machine/builder/helper;
- `unchecked` removed;
- wrong evidence field types;
- unreadable or unchecked treated as absence;
- missing/duplicate route observations;
- mixed statuses credited as definite absence;
- absence without posture;
- historical basis used as current posture;
- competing winner renews eligibility;
- relation hidden defaults.

### Owner transformed copies

Reproduce all thirteen private clauses or at least the twelve reported owner
copies plus any remaining clause. For each, jointly reverse private prose,
machine consequence, and private test literal while leaving the unchanged owner
fact intact. Every copy must fail the owner-derived resolver.

Also mutate owner marker/pointer to unrelated valid owner values.

### Prose transformed copies

Reproduce all fourteen hostile and four neutral controls, including:

- `might`;
- replay adapter;
- two-sentence pronoun;
- heading;
- bullet/continuation;
- table;
- blockquote;
- link label;
- force/veto aliases;
- local-absence sufficient-to-prove;
- terminal/ES replenishment;
- untagged authority statement;
- neutral glossary/diagram/documentation/terminology forms.

Every hostile copy must retain collection and fail semantically. Every neutral
copy must retain collection and pass.

## Audit question 16 — additional coupled mutants

In addition to the reported matrix, independently test at least:

1. lifecycle lists, branch graph expectations, and validator changed together;
2. replay and recovery lifecycle names swapped consistently in private files;
3. observation enum, status table, builder, classifier, and tests changed
   together;
4. observation route count changed together with expected count;
5. relation canonical builder and all 26 expected values changed together;
6. owner marker and generic resolver changed to an unrelated owner fact;
7. owner path resolves a true but semantically unrelated field;
8. private prose, machine tuple, test literal, and consequence mapping changed
   together;
9. protected subject list and contradictory prose changed together;
10. modal list drops `might` while prose uses it;
11. pronoun context disabled while direct-sentence controls remain;
12. neutral compounds added to protected subject aliases;
13. lifecycle membership remains correct but numeric stage is moved earlier;
14. fresh-write node gains a recovery dependency without count change;
15. recovery status `unchecked` is represented but classified as absence;
16. duplicate route observation replaces a missing route with total count eight;
17. relation ref is correct but self-digest belongs to another relation;
18. nonaccept acceptance fields are null but a durable fact exists at the
    reserved identity.

Every negative must fail an independent owner, lifecycle, relation, observation,
or parser boundary. Neutral and harmless lifecycle-order controls must pass.

## Audit question 17 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `687 collected; 687 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Broad RW0/C2B/SQLite group | `4,690 collected; 4,690 passed` |
| Full repository | `8,504 collected; 8,504 passed, 3 warnings` |

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

Investigate every count, warning, or collection mismatch.

## Audit question 18 — live cache and cleanup

Before executable work, record a safe opening member-level inventory of ignored
cache paths, types, modes, sizes, mtimes, and hashes without importing live
repository modules.

The V6 closeout reports 37 members and a path/content digest, but does not define
a complete canonical metadata grammar. Member-level opening/closing equality is
authoritative.

After all external work and cleanup, require exact member-level equality.

Any audit-created live cache member or modification is a provenance failure.

Remove every audit-created clone, basetemp, transformed copy, script, receipt,
and log.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- lifecycle conflation or cross-lifecycle dependency;
- missing validated-admission/current-posture branch ancestor;
- replay/recovery represented as fresh-write construction;
- incomplete or self-confirming recovery status grammar;
- malformed types or nullability accepted;
- unchecked/missing evidence credited as absence;
- total absence credited without fresh posture;
- incomplete 26-field relation coverage;
- relation validator reconstructing hidden defaults;
- private owner polarity not derived from unchanged owner facts;
- owner marker/pointer resolving unrelated semantics;
- contradictory protected prose surviving;
- neutral explanatory prose falsely rejected;
- regression in canonical command, source-exact v1 mapping, C2 return causality,
  canonical family, profile, roles, replay, or recovery;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- any mandatory transformed mutant surviving;
- unexplained collection, test-count, warning, or cache mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning/permission posture;
3. exact baseline and V6 six-path provenance;
4. patch, receipt, and transition-evidence reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. registry-role and lifecycle-partition audit;
8. five fresh-write DAG audits;
9. replay-readback graph audit;
10. uncertain-recovery graph audit;
11. typed observation grammar audit;
12. recovery outcome and posture-binding audit;
13. complete 26-field relation audit;
14. owner-reference registry audit;
15. generic owner-resolver audit;
16. bounded subject/modal/action parser audit;
17. visible-Markdown and pronoun-context audit;
18. preserved V5 advances and nonimplementation audit;
19. test-independence and shadow-owner audit;
20. implementation-reported transformed-copy results;
21. additional coupled-mutant results;
22. independent validation;
23. live-cache and final provenance;
24. severity-ranked findings;
25. exact next boundary;
26. required non-actions;
27. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED_BY_AUDIT
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
