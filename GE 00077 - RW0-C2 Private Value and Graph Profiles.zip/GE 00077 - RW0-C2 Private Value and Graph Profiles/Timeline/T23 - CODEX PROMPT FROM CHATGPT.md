# Governed Execution Coordinator — RW0-C2 Private Value Contract V5 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and receipt-graph-profile
V5 candidate.

This audit follows a two-file repair intended to close the V4 audit findings:

1. branch-independent dependency declarations omitted raw relation inputs,
   mishandled acceptance-only nodes, and left recovery without explicit read
   observations;
2. the command-digest witness was not the command digest actually bound through
   selector, family, receipt, replay, and recovery values;
3. the private source-exact test checked current v1 field names rather than
   actual source field-to-value mapping and canonical bytes;
4. admission preceded the shared C2 call, but the interpreter's returned branch
   did not causally control family formation and fresh posture was defaulted;
5. selector routes were internally consistent without being bound to the
   canonical command and family;
6. positive family/profile tests used placeholders or shared builders instead
   of independently reconstructed current-v1 and target members;
7. private tagged clauses were not fully anchored to unchanged owner semantics
   and the prose parser allowed contradictory modal, alias, and cross-sentence
   forms.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
audit packages, Downloads artifacts, Project artifacts, or generated manifests.
The V5 closeout is evidence only; independently reproduce every material claim
from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V5 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 156,160 | `119a7218230221c8c13f8039df308035a52195731d9f71f001437c8e493991aa` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 231,640 | `fca8e6715762bae4d97255f88cd936ea2cbbff0c32dd72dd81c7f3a0dcdd7b1b` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `400,930`
- SHA-256:
  `88d0bc1203a9ebbb83d50108d9a196060c108579aada62c4916e3eb5bad958dc`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `5d30d4aa9974b499438752d284f4d7098a53366f4e2a79352d50b6790eec56ee`

Use two structurally independent serializers and require byte-identical output.

## V4-to-V5 transition evidence

The V5 closeout reports that only these two paths changed from the independently
blocked V4 candidate:

| Path | V4 bytes / SHA-256 | V5 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `126,333` / `1108d8c72b1629973ae7d75a8afd8bd7a227ef62dcf13121ea23da7924001fc3` | `156,160` / `119a7218230221c8c13f8039df308035a52195731d9f71f001437c8e493991aa` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `145,730` / `4bac143d711deb64c12fc99b99a882a21f84f4c2268e4156481b2dd0ede10ebf` | `231,640` / `fca8e6715762bae4d97255f88cd936ea2cbbff0c32dd72dd81c7f3a0dcdd7b1b` |

The other four candidate documents have the same receipts in V4 and V5.

The live V5 bytes are the primary audit target. Do not request historical V4
files. If V4 bytes are absent from the live checkout, classify the exact
two-file transition as corroborating history rather than blocking live
provenance.

## Prior V4 findings

The V4 audit established exact provenance and blocked because:

- relation and graph nodes omitted required raw or conditional dependencies;
- recovery projection lacked explicit observed family and collision-route read
  inputs;
- the command-digest witness was disconnected from positive family fixtures;
- the private v1 source gate checked field names but not actual mapped values;
- the shared C2 call's return value did not causally control family formation;
- fresh posture was defaulted rather than supplied;
- selector routes were internally coherent but not command/family bound;
- canonical family and graph-role tests used placeholders or shared builders;
- private tagged clauses were not fully anchored to unchanged owners and
  contradictory modal, alias, and cross-sentence prose survived.

Audit the V5 repair rather than assuming those findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Subagents must not import modules from the live checkout. If their read-only
posture or bytecode suppression cannot be guaranteed, continue parent-only.
Explorer unavailability is not itself a candidate defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, branch-profile, static graph-profile,
query/observation-value, and bounded normative-clause semantics. It remains
subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, current continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive current continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one generic v1 receipt root, one replay owner, and one
   whole-family recovery owner;
10. the decision writer cannot provision, repair, renew, or replenish
    admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` remains compatibility/nonproof only;
13. the static receipt profile is verification metadata selected through the
    guarded result, not a graph member or durable row.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- only the private-value contract and its verifier differ from their V4 endpoint
  receipts;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, exports, StateStore, readers, writers, transactions,
  public/runtime surfaces, configuration, and examples remain unchanged;
- migration `0005` remains absent;
- no accepted architecture changed outside private canonical-family,
  conditional dependency, query/observation, and test-adequacy repair.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — lifecycle separation and branch-expanded dependency graphs

Independently reconstruct the reported common registry, five branch expansions,
and recovery read/projection graph.

Do not accept the reported counts without deriving every node and edge.

### Fresh-write branch DAGs

For each authoritative branch, require a fresh-write construction DAG with this
semantic order:

```text
verified admission/current posture and current-owner basis
→ primitive transcript
→ six sibling preassignments
→ canonical command digest
→ admission/command validation
→ authoritative C2 branch
→ one transaction timestamp
→ branch-specific current-v1 and target members
→ guarded relation and guarded result
→ source-exact graph entries and receipt preimage
→ generic graph digest
→ final generic v1 receipt row
→ replay projection of the committed family
```

Acceptance-only nodes materialize only on `candidate_acceptance`. Nonaccept
expanded graphs omit those nodes and all edges to them.

Require raw relation-field dependencies, not opaque substitutes.

### Recovery read/projection DAG

Recovery is a later post-read classification path, not part of fresh family
construction.

Require a separately identifiable recovery graph:

```text
canonical command and selector
+ fresh current continuity/sole-active posture
+ eight typed route observations
→ complete recovery observation set
→ C2-owned recovery projection
```

The recovery projection must not appear semantically before a possible durable
family merely because the combined registry admits a lexical topological order.
If the machine contract stores fresh-write and recovery nodes in one registry,
it must declare lifecycle partitions and prohibit a fresh-write path from
depending on recovery nodes or a recovery projection from being interpreted as
precommit execution.

The V5 closeout's reported topological order places route observations and
`recovery_projection` before `transaction_timestamp` and canonical family
members. Independently determine whether that is a harmless ordering of
independent subgraphs or an incorrect lifecycle-stage claim. Ambiguity is
blocking.

Require exact branch counts, edges, conditional materialization, and one
independent topological sort per branch plus one recovery graph.

## Audit question 3 — relation raw-field closure

Derive the guarded-family relation's exact canonical fields from the V5 machine
contract.

For every field, require a declared dependency on the node that owns the exact
raw value.

At minimum verify dependencies for:

- schema/profile literal;
- preassigned relation ref;
- authoritative branch;
- lineage and scope;
- canonical command digest;
- verified admission act ref/digest;
- immutable admission fact ref/digest;
- historical continuity basis ref/digest;
- historical sole-active basis ref/digest;
- canonical decision value/ref/digest;
- canonical resulting-version value/ref/digest;
- complete historical-head postimage value/ref/revision/digest;
- generic v1 result projection value/ref/digest;
- deterministic family route;
- guarded-result identity expectation;
- acceptance fact value/ref/digest only on acceptance.

No digest or aggregate may substitute for a raw canonical field required in the
relation preimage.

Mutate each field independently, reseal all downstream target digests, and
require failure against independently reconstructed canonical members.

## Audit question 4 — recovery observation-set grammar

Inspect `complete_family_recovery_observation_set_v1`.

Require it to be:

- transient private read-result grammar;
- not a twelfth durable schema or row;
- not public protocol;
- not a second recovery owner;
- consumed by the existing C2 recovery owner.

Require exactly eight route observations, one per mandatory route, with a
closed exact status enum and exact built-in field types.

Verify each observation binds:

- route role;
- exact route key;
- readability;
- observed member/family identity or absence proof;
- duplicate/foreign/malformed/conflict classification;
- no invented authority.

Require exact projection rules:

- exact complete family → `committed_exact`;
- exhaustive total absence on all routes plus fresh positive posture →
  `definitely_not_committed`;
- partial, duplicate, foreign, malformed, unreadable, unchecked, or
  insufficient-posture evidence → `unresolved`;
- competing complete scope winner may establish original-command noncommit but
  not fresh eligibility.

Mutating observation templates, observation builders, and expected statuses
together must fail an independently fixed recovery oracle or unchanged owner
anchor.

## Audit question 5 — canonical command digest

Independently reconstruct `guarded_command_digest_v1`.

Require:

- exact domain separator and NUL framing;
- exact 30 ordered name/value pairs;
- first 24 are the closed primitive transcript;
- final six are the independently derived sibling identities;
- exact built-in types and canonical JSON;
- exact supplied fixed vector:
  `a392abcc3f0981b4ac2aeab5d3869aea9f24ba7305b242563e3a41f402b716b1`;
- exclusion of branch, result, relation/result self-digests, graph digest,
  timestamp, terminal, credentials, and raw attestations;
- no hidden cycle or sibling-to-command backedge.

Every positive selector, relation, result, receipt, replay, and recovery fixture
must use this recomputed digest.

No positive fixture may contain a placeholder, arbitrary caller-supplied digest,
or digest produced by the same builder being validated.

For every primitive and sibling mutation, require old downstream values to
reject and the independently recomputed valid family to remain coherent.

## Audit question 6 — command, selector, route, and family binding

Require exact equality from command to selector for:

- lineage;
- scope;
- admission ref/digest;
- mutation ref;
- all preassigned identities;
- deterministic family route;
- canonical command digest.

Require each route key to equal the selector's bound coordinate and each family
member to bind the same command where its grammar requires it.

Independently mutate:

- selector lineage and its route key together;
- selector admission digest and route together;
- selector route and a caller-chosen digest together;
- selector family route and concrete route together;
- command digest and every downstream target digest together.

All must fail unless the complete command is independently reconstructed.

## Audit question 7 — source-exact current v1 receipt algebra

Using the real unchanged source in an external clone, independently construct
one sentinel receipt and graph family with a unique value for every field.

Derive and verify:

- exact 18 receipt preimage fields in order;
- exact source attribute mapped to each field;
- exact graph-entry field order and source attributes;
- current canonical encoding and domain;
- exclusion of `mutation_graph_digest` from its own preimage;
- final receipt as unchanged preimage plus graph digest;
- absence of an invented receipt self-digest/profile field.

Call the actual current `_receipt_graph_identity` owner or exact constructor
path and compare the observed canonical bytes/digest with a separately encoded
fixed expectation.

Transform current source in external copies to detect:

- `committed_at` mapped to `None`;
- any same-type field substitution;
- graph-entry order/value substitution;
- changed domain;
- inclusion of graph digest in its own preimage;
- invented self-digest/profile field.

The private verifier itself must fail these source mutations; credit from an
unrelated existing test is insufficient.

## Audit question 8 — admission and fresh posture before C2

Verify the private family path requires explicit supplied current posture with
no default `True`.

Require this causal order:

```text
validate fixed admission vector
→ validate command and prospective identities
→ validate fresh current continuity and sole-active posture
→ invoke the exact shared C2 interpreter once
→ consume its returned branch
→ form the exact branch family
```

Invalid admission or missing/stale/unknown/conflicting/false posture must invoke
C2 zero times.

Patch/observe the actual callable reference used by the path, not an unused
alias.

Historical retained bases must not substitute for fresh posture.

## Audit question 9 — actual C2 return-value dataflow

Use an independent outer observer and return-value wrapper.

Require:

- valid input invokes shared C2 exactly once;
- a wrapper returning a different valid branch causes family membership,
  relation nullability, graph roles, and acceptance fact presence to follow
  that returned branch;
- no expected branch parameter or fixed constant controls family formation;
- a reachable C2 call whose result is discarded fails;
- an unreachable or unused sentinel call does not receive credit;
- the prospective fact coordinate is absent from C2 branch input and cannot
  force or veto the result.

Inspect AST and execute actual dataflow probes.

## Audit question 10 — canonical current-v1 branch families

Independently reconstruct current-v1 members for all five branches using the
unchanged source owners:

- development decision with exact branch-dependent kind and variant;
- resulting program version;
- historical program-head postimage;
- generic v1 result projection;
- generic receipt preimage, graph digest, and final receipt row.

Use one independently fixed family input vector and fixed expected current-v1
refs/digests that are not generated by the builders under test.

Verify one shared transaction timestamp is used wherever the selected grammar
requires it.

Reject placeholder member digests.

## Audit question 11 — target supplemental family members

Independently construct and validate:

- verified admission act;
- immutable admission fact;
- historical continuity basis;
- historical sole-active basis;
- guarded family relation;
- guarded progression result with exact profile ID and authoritative branch;
- acceptance fact only on acceptance.

Every target member must bind the actual current-v1 members and the real
canonical command digest.

A foreign or malformed value followed by recomputation of every downstream
target digest must remain invalid against independently fixed current-v1 and
owner anchors.

## Audit question 12 — static profile and complete graph roles

Independently fix:

- profile ID/version;
- authoritative branch binding;
- ten common roles, schemas, types, and ordinals;
- acceptance-only role, schema, type, and ordinal.

Do not derive fixed expectations from the private machine profile, graph
builder, or branch helper.

For each branch:

- construct all actual current-v1 and target member values;
- build exact graph entries;
- acceptance has ten common roles plus acceptance fact;
- nonaccept has the ten common roles only;
- reconstruct current v1 graph digest and receipt;
- load and validate every exact member;
- verify guarded-result profile ID/branch before crediting profile
  completeness.

Joint changes to machine profile, family builder, role helper, and downstream
digests must still fail the independent profile or unchanged owner/source
anchor.

## Audit question 13 — replay and recovery canonical-family semantics

Verify exact replay returns the original:

- decision/version/head postimage;
- optional acceptance fact;
- supplemental members;
- graph entries and generic receipt;
- canonical command digest;
- transaction timestamp.

Replay must not create or refresh any value, reevaluate branch, repair
fragments, renew admission, or replenish a scope.

Verify recovery covers:

- same mutation/same command/complete family;
- same mutation/different command;
- all preassigned identity collisions;
- family-route collision;
- competing complete scope winner;
- total absence with fresh posture and all eight absence proofs;
- partial/orphan/duplicate/foreign/malformed/unreadable family;
- restore/clone with unproved continuity.

The private verifier must remain a value/query-contract verifier, not a SQL
recovery engine or second recovery owner.

## Audit question 14 — owner-anchored normative semantics

For every tagged private clause, require four independent representations:

1. fixed audit/test expectation;
2. unchanged guard or decision owner anchor at a stable marker;
3. private machine clause tuple;
4. parsed tagged private prose.

Do not use absolute line numbers as semantic authority.

Require exact subjects/aliases and bounded immediate same-block pronoun context,
including at least:

- replay;
- replay adapter;
- exact replay;
- prospective/reserved acceptance coordinate;
- command relation;
- local row absence;
- historical continuity basis;
- current continuity posture;
- nonaccept branch;
- terminal outcome;
- ES routing.

Require modal support including:

- may;
- might;
- must;
- shall;
- can;
- could;
- is permitted to;
- is allowed to;
- is authorized to;
- is sufficient to;
- may not;
- must not;
- cannot.

Require protected create/refresh/admit/select/skip/replenish/authorize/prove
actions over acceptance fact, receipt, timestamp, scope, noncommit, current
permission, allowance, and collision route.

Parse headings, paragraphs, blockquotes, bullets/continuations, tables/cells,
and link labels outside fenced code and machine JSON.

This must fail:

```text
Replay is authorized. It creates a new acceptance fact.
```

This neutral sentence must pass:

```text
The replay glossary may include the term timestamp.
```

Changing private prose, private machine tuple, and private test literal
together must still fail the unchanged owner anchor.

## Audit question 15 — test independence and shadow-owner risk

Inspect the reported 557-node verifier.

Require independent authorship among:

- fixed owner-anchor expectations;
- private prose;
- private machine block;
- command transcript and sibling fixed vectors;
- command-digest fixed vector;
- five branch-expanded DAG expectations;
- route-observation and recovery expectations;
- current-source sentinel mapping;
- fixed current-v1 family vectors;
- target supplemental-member expectations;
- fixed static profile/role inventory;
- internal hostile expectations;
- external transformed copies.

Reject:

- one builder generating and validating its own command/family/graph;
- route observation and recovery expectations derived from observed values;
- shared C2 invocation without return-value dataflow;
- source AST key checks without value causality;
- placeholder digests;
- broad source-manifest freezing;
- hash-only correctness;
- a second reducer, replay/recovery engine, or physical schema emulator.

Require recursive duplicate-key rejection and exact built-in type comparison,
including bool/int separation.

## Audit question 16 — implementation-reported transformed categories

Independently recreate all 68 requested categories from the V5 repair prompt,
including their individual parameterized variants. At minimum cover:

### Conditional graph and recovery

- relation raw-field omissions;
- acceptance-only dependency leakage into nonaccept;
- omitted acceptance dependencies on acceptance;
- hidden optional aggregate inputs;
- omitted recovery observation set or route observation;
- unreadable evidence treated as absence;
- total absence without fresh posture;
- undeclared relation fields;
- branch-specific stage inversion.

### Command digest and selector binding

- removal of each of 24 primitive fields, one at a time;
- removal of each of six sibling identities, one at a time;
- fixed placeholder digest;
- primitive mutation with stale digest;
- jointly changed selector/route;
- jointly changed selector/arbitrary digest;
- foreign admission/family route;
- self-consistent routes not command-bound.

### Current source graph

- every source field/value mapping;
- graph entry order/value mapping;
- domain;
- self-preimage and invented self-digest.

### C2/posture

- discarded returned branch;
- fixed expected branch;
- alternate valid wrapper branch;
- invalid admission entering C2;
- stale posture entering C2;
- default posture;
- prospective coordinate entering branch input;
- unreachable shared call.

### Canonical family/profile

- placeholder current-v1 members;
- wrong branch decision kind/variant;
- fully resealed foreign family values;
- profile and role coupled changes;
- missing/duplicate/substituted/foreign roles;
- ref/digest cross-role substitution;
- acceptance-role branch errors;
- jointly resealed wrong graph/receipt.

### Normative clauses

- all modal, alias, structure, cross-sentence, coupled-private, and owner-anchor
  transformations;
- neutral explanatory control.

Every transformed copy must:

- retain the exact expected 557-node collection;
- fail at the intended exact semantic boundary;
- avoid syntax/import/format/collection-shrinkage-only failure.

Report permanent internal controls separately from actual transformed copies.

## Audit question 17 — additional independent mutants

In addition to the requested categories, independently test at least:

1. recovery projection lifecycle stage placed before any possible receipt;
2. recovery observation statuses and expected classification changed together;
3. observation set omits one route while count/expectation changes together;
4. command digest domain and fixed vector changed together;
5. command builder and selector/family expectations changed together;
6. source function and source-exact expected mapping changed together;
7. shared C2 returns alternate branch while the family builder uses a cached
   earlier branch;
8. fresh posture object and expected posture changed together;
9. current-v1 constructor and fixed family vectors changed together;
10. static profile, role inventory, graph builder, and expectations changed
    together;
11. acceptance fact and admission fixture changed together;
12. same transaction timestamp replaced by four independently generated equal
    values, then by four unequal values;
13. graph entry has correct ref but digest from another role;
14. graph digest is valid over wrong same-typed member;
15. total absence has all routes but one route observation is stale rather than
    absent;
16. private clause, owner-marker parser, and fixed private literal changed
    together while unchanged owner meaning remains opposite;
17. neutral prose with `may` and a protected noun in a non-authority compound;
18. duplicate or conflicting recovery observations for one route.

Every negative must fail at a fixed owner, source, identity, lifecycle,
canonical-family, or recovery boundary. Neutral controls must pass.

## Audit question 18 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `557 collected; 557 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Broad RW0/C2B glob group | `4,560 collected; 4,560 passed` |
| Full repository | `8,374 collected; 8,374 passed, 3 warnings` |

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

An initial disposable-clone artifact failure does not invalidate the candidate
if exact cleanup and a clean complete rerun are independently reproduced. It
must be reported.

Investigate every count, warning, or collection mismatch.

## Audit question 19 — live cache and process deviation

Before executable work, record a safe opening member-level inventory of ignored
cache paths, types, modes, sizes, mtimes, and hashes without importing live
repository modules.

The V5 closeout reports that one temporary live ignored bytecode file was
created and removed, and that opening and closing member inventories matched.
This was a process deviation from the implementation prompt, but not necessarily
a candidate-byte defect.

The fresh audit must:

- verify the current opening live cache without assuming a historical aggregate;
- avoid all live imports and live pytest;
- perform executable work only in external clones;
- require exact member-level opening/closing equality;
- report any audit-created live member as provenance failure;
- classify the V5 implementation's prior live-cache cleanup as report/process
  uncertainty unless current repository or candidate bytes are affected.

Remove every audit-created clone, basetemp, transformed copy, script, receipt,
and log.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- conflation of fresh-write and recovery lifecycle stages;
- incomplete branch-expanded dependency graph;
- missing raw relation input;
- missing or self-confirming recovery observation;
- placeholder or disconnected command digest;
- selector/route/family not bound to the canonical command;
- private source-exact test missing value mapping;
- fresh posture default or historical posture substitution;
- shared C2 return not causally controlling the family;
- placeholder or self-confirming current-v1 family members;
- incomplete acceptance-fact binding;
- incomplete or self-confirming receipt-role/profile family;
- profile becoming a durable/member authority;
- changed v1 graph semantics;
- contradictory private prose surviving or neutral prose falsely rejected;
- private clause truth not anchored to unchanged owners;
- total absence credited without fresh posture/exhaustive route observations;
- replay creating or refreshing any value;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- any mandatory transformed mutant surviving;
- unexplained collection, test-count, warning, or cache mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V5 six-path provenance;
4. patch, receipt, and transition-evidence reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. lifecycle separation and five branch-expanded DAG audit;
8. relation raw-field closure audit;
9. recovery observation-set and projection audit;
10. canonical command-digest audit;
11. command-selector-route-family binding audit;
12. source-exact current-v1 graph audit;
13. admission/current-posture-before-C2 audit;
14. actual C2 return-value causality audit;
15. canonical current-v1 family reconstruction audit;
16. target supplemental-family binding audit;
17. static profile and complete graph-role audit;
18. replay/recovery canonical-family audit;
19. owner-anchored normative semantics audit;
20. test-independence and shadow-owner audit;
21. requested transformed-category results;
22. additional independent-mutant results;
23. independent validation;
24. live-cache and final provenance;
25. severity-ranked findings;
26. exact next boundary;
27. required non-actions;
28. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED_BY_AUDIT
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
