# Governed Execution Coordinator — RW0-C2 Private Value Contract Commit and PR Publication Gate

## Objective, evidence, and exact effect ceiling

Perform one parent-only commit and pull-request publication gate for the exact
six-path V9 private-value/versioning and graph-profile contract candidate.

The fresh independent audit returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

It accepted the two repaired parser boundaries within the documented visible-text
grammar, reproduced all six endpoint receipts, reconstructed 44 transformed-copy
categories with the intended outcomes, checked bounded composition specimens,
and passed an uncontended full suite of 8,742 tests with three existing warnings.
Its earlier overlapping full-suite trial receives no acceptance credit. Do not
repeat the overlap. All validation in this gate must be strictly serial.

The report is prior acceptance evidence, not Git authority or current product
capability. Reproduce live local and remote facts. No attachment is required:
use the live repository, this complete prompt, and the exact coordinates below.
Do not request historical V8/V9 files, an audit attachment, a snapshot, a receipt,
or a new freeze manifest. Historical transition bytes are not gate inputs.

Authorized effects, in order:

1. Local read-only inspection and authenticated remote read-only preflight.
2. Stage exactly the six accepted paths.
3. Validate an exact index-derived candidate in a private local-only clone.
4. Create one local commit on the currently checked-out `trunk_dev`.
5. Push that exact commit once, non-force, to the exact topic ref below.
6. Create and verify one open, non-draft PR against `trunk_dev`.
7. Remove only gate-created disposable external material.

No candidate edits or repairs are authorized. No merge, auto-merge, merge queue,
direct trunk push, force push, amendment, rebase, cherry-pick, branch deletion,
tag, release, deployment, dependency installation, product database access,
service, source implementation, product migration application, or sibling-
repository access is authorized. Only the specified pytest suites may apply
migrations to their isolated external fixture databases. Do not spawn subagents.

Use the highest available reasoning setting that the interface actually exposes.
Record the visible model, reasoning setting, and permission posture. Use `not
visible` for missing controls; do not infer or claim to change hidden settings.
Do not seek additional account/computer access just to discover those controls.

Return one substantive inline closeout, not an external report, JSON manifest,
package, patch, or other deliverable. Private temporary files needed for this
gate may exist only under an independently created external root and must be
removed. Do not make the user transport further evidence artifacts.

## 1. Repository, guidance, and opening baseline

Work only in:

`/Users/ds/Repositories/Governed Execution Coordinator`

First read `AGENTS.md`, then the composition/status and scope sections of all five
candidate documents. Read the relevant existing validation/provenance guidance
that `AGENTS.md` routes to. Inspect the candidate diff to confirm what is being
published; do not restart the semantic audit or redesign its parser.

Required opening coordinates beneath the uncommitted candidate:

- Branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- HEAD tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- Sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- Subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- Upstream: `origin/trunk_dev`
- Divergence against the existing tracking ref: 0 ahead / 0 behind
- Exactly one worktree
- Zero staged paths and zero unmerged paths
- No active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Use non-mutating inspection before staging, including optional-lock suppression
for read-only Git calls where appropriate. Do not refresh/fix/reset the index,
fetch, switch branches, or normalize local state to make the baseline match.

Any opening baseline, candidate path-set, file type, mode, size, or SHA mismatch:
stop before staging with `AUDIT_PROVENANCE_MISMATCH`. Report actual coordinates;
do not replace this prompt's expected values or silently adopt a newer target.

## 2. Exact six-path candidate

Require exactly four unstaged tracked document modifications and two untracked
regular files, with no other tracked/untracked difference from HEAD. In porcelain
status terms the first four are worktree-only modifications, not index changes.
All six are regular nonsymlink OS-mode `0644`, valid UTF-8 with no BOM, CR,
trailing whitespace, or extra final newline; exactly one final LF is present.

| Opening status | Repository-relative path | Bytes | SHA-256 |
|---|---|---:|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| `??` | `.docs/rw0-c2-private-value-versioning.md` | 207,042 | `3e1e8b8d3538f855029fa51a729d62d2df82f05eccda76d33c70828324e4581f` |
| `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 339,022 | `011d88401851315b18dafee6d17c64e0eb0b509f8598d5dcabad121d349e4762` |

Reject deletions, renames, executable-bit changes, type changes, symlinks,
submodules, conflict stages, intent-to-add, or additional untracked paths.

For each tracked path outside the four modified documents, compare bytes, Git
file type, and executable-bit mode to HEAD. Do not mistakenly require OS mode
`0644` for every unaffected file: its existing Git-mode meaning is authoritative.
The exact OS-mode requirement above applies to the six accepted candidate files.

Require source, migrations, existing tracked tests, exports, configuration,
examples, and all non-candidate paths unchanged. Packaged migration resources
remain exactly 0001–0004; migration 0005 is absent. Product implementations remain
unchanged, even though this gate records and publishes target contracts in Git.

## 3. Opening ordered patch and canonical receipt

Run from the physical repository root. Visit the six paths above in their listed
lexicographic order. For each tracked modification capture exact stdout from:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each untracked addition capture exact stdout from:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat no-index status 1 as differences found, not an execution failure. Assemble
stdout bytes without added separators. Require:

- Patch bytes: `562,434`
- Patch SHA-256:
  `334375bc4ec39afbd545c7a6b61bac77bc4e5099143a5ff859b0767ebf71da4d`

This is the audited recipe. Do not substitute different Git diff options, path
labels, sort order, or a staged-diff recipe and compare their output to this hash.
Record relevant diff configuration if reconciliation is needed; do not change
configuration to manufacture a match. An unresolved mismatch stops this gate.

Reconstruct the canonical receipt from observed baseline, file metadata/content,
and assembled patch, rather than merely serializing expected constants:

- Root keys: `baseline_head`, `files`, `patch`, `schema`
- `baseline_head`: opening HEAD above
- `schema`: `rw0-c2-private-value-audit-receipt-v1`
- `files`: six entries in lexicographic path order
- Each file entry: `mode`, `path`, `sha256`, `size_bytes`, `status`
- Modes: string `0644`; sizes: integers
- Statuses: strings `modified` for the first four, `untracked` for the last two
- `patch`: `byte_length` and `sha256`
- Recursively sorted object keys, compact comma/colon separators, UTF-8,
  `ensure_ascii=false`, `allow_nan=false`, no trailing newline

Require:

- Receipt bytes: `1,381`
- Receipt SHA-256:
  `9e5428fe8c0c3b9e9e0a1dd727d1aec4fd2da37d53b93b2779bc0be94e89061d`

Recompute complete file observations, patch, and receipt twice with fresh reads.
The two calculations must be byte-identical. Keep transient receipts in memory
or under the private external root, never in the repository.

These exact hashes bind pre-staging evidence. After staging/commit, compare
actual index/commit blob bytes and modes, not a receipt whose historical statuses
or HEAD would no longer match its opening grammar.

## 4. Live ignored-cache preservation

Before executable validation, inventory the pre-existing ignored cache without
importing live repository modules. The accepted audit counted 37 regular `.pyc`
files plus their directory: 38 entries, not 38 bytecode files.

Keep a safe member-level opening record of path, type, mode, size, nanosecond
mtime, and file SHA-256. Require the same members and metadata at closeout.
Do not print bytecode contents. Do not inspect sensitive ignored directories,
environment files, credentials, or operator databases to obtain provenance.

The audit reported an aggregate inventory hash but did not prescribe its complete
serialization grammar. Do not impose that aggregate or invent a historical one.
Member equality within this gate is authoritative for preservation; report any
opening inventory discrepancy before staging.

Never import from or run pytest in the live checkout. Do not move, rewrite,
delete, or temporarily hide its cache to satisfy an artifact test. If this gate
creates a live cache member or changes one, stop and report exact residue; no
live cleanup or repair of that deviation is authorized here.

## 5. Remote read-only preflight before staging

After local provenance passes, authenticated remote read-only inspection is
authorized for the configured `origin` repository only:

`evo-agi/Governed-Execution-Coordinator`

Exact publication coordinates:

- Base ref: `refs/heads/trunk_dev`
- Required remote base OID: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- Topic ref:
  `refs/heads/codex/rw0-c2-private-value-versioning-contract-v1`
- PR head name: `codex/rw0-c2-private-value-versioning-contract-v1`
- PR base name: `trunk_dev`

Verify remote repository identity without exposing credentials. Use existing
configured authentication; do not install tools, change credential stores,
request broader scopes, or display secrets. Inspect configured commit hooks and
signing policy sufficiently to know whether ordinary staging/commit could exceed
this gate's effect scope. Do not bypass hooks, signatures, branch rules, or review
requirements. If those requirements cannot be honored, stop.

Require the live remote base equals the opening HEAD. Require the topic ref is
absent and no open or closed PR already uses that exact head in this repository.
Do not use a different branch name or silently reuse an existing publication.

Read effective base-branch rules/rulesets and repository settings, including PR
requirements, permitted merge methods, required checks/reviews, conversation
resolution, bypass actors, auto-merge, and automatic branch deletion. Record them
as live observations, not assumptions from earlier PRs. The gate publishes a PR;
it does not require future merge approvals/checks to be complete before the PR
exists, and it never enables auto-merge or merges it.

Remote base drift, existing topic/PR, unexpected repository identity, unavailable
permitted authentication, or unresolved publication-policy requirements means:
`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_COMMIT_PUBLICATION_BLOCKED`.
Stop before staging. Do not contact sibling repositories.

A fetch is unnecessary at a matching baseline; do not update other refs during
preflight. Do not attempt a direct push to trunk.

## 6. Exact staging and index-tree verification

Stage only the six paths using a literal path list and `git add -- <paths>`.
Never use `git add .`, `git add -A`, or another broad staging command.

Then require:

- Exact changed staged path set: four modifications and two additions
- All six changed entries at index stage 0, Git mode `100644`
- No conflict entries, intent-to-add, deletes, renames, type/mode changes
- Every index blob byte count and SHA-256 equals its accepted receipt
- Every index blob equals its working-tree bytes
- Every unaffected index entry equals HEAD, including path, mode, and blob OID
- No unstaged tracked difference or remaining untracked candidate/additional path
- `git diff --cached --check` produces no whitespace diagnostics

The full index contains all repository paths; the requirement is six CHANGED
stage-0 entries, not an index containing only six entries.

Record each changed index blob OID and run `git write-tree`; record the staged
tree OID. Do not fabricate that OID from the working-tree patch hash. Do not alter
candidate bytes or the index after successful verification.

## 7. Index-derived, local-only validation

Create one private external gate root, mode `0700`, outside the repository. A
local clone—not an extra worktree of the live checkout—must use committed HEAD
`3d99e448bfe577b5a5878dd32b7e01b61322e7df` as its baseline. Use local Git objects
only, no network or hardlink/shared writable object dependency. Remove the clone's
local-source remote and verify it has zero configured remotes before testing.

Populate each of the six candidate paths from the live INDEX blob, not from
unverified working-tree files. Preserve candidate regular OS mode `0644`; use a
clone/file-creation umask that does not silently make all baseline files `0600`.
The enclosing gate root still remains private.

Before testing prove:

- Clone HEAD is the specified baseline
- All six clone files match index blob bytes, size, SHA-256, and required mode
- All other checked-out files equal baseline Git bytes/type/executable-bit mode
- Clone status is exactly the six intended differences, no ignored/generated
  bytecode, pytest cache, database, journal, build, coverage, or report residue
- Live HEAD, index tree, candidate bytes, and cache have not changed

Use the already available validation interpreter/environment. Do not install or
upgrade anything. Record Python and pytest versions and actual executable path;
no hidden environment defaults should be substituted to force a reference count.

### Serial validation runner

Run only with the external clone as current directory. The environment is:

```sh
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=.:src
```

Create an external basetemp parent before the first command. Define a shell
helper equivalent to the following in a fail-fast shell; `GATE_ROOT` is the exact
private external root that you just created:

```sh
set -eu
mkdir -p "$GATE_ROOT/basetemps"
run_group() {
  label="$1"
  shift
  python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$GATE_ROOT/basetemps/${label}-collect" \
    --collect-only "$@" || return $?
  python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$GATE_ROOT/basetemps/${label}-run" \
    "$@" || return $?
}
```

Invoke each group only after the preceding collection and execution have exited
successfully. No background pytest, parallel groups, pytest-xdist, overlapping
broad/full trials, or orphaned test processes. Check each collection total and
execution outcome before continuing.

#### A. Private verifier: 925 collected / 925 passed

```sh
run_group private \
  tests/test_rw0_c2_private_value_versioning_contract.py
```

#### B. Existing C2 owners: 1,623 collected / 1,623 passed

```sh
run_group c2_owners \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
```

#### C. Focused B1/C2B2/migration 0002: 458 collected / 458 passed

```sh
run_group focused_values \
  tests/test_rw0_b1_phase_values.py \
  tests/test_rw0_b1_boundaries.py \
  tests/test_c2b2_development_decision_row_values.py \
  tests/test_c2b2_development_program_row_values.py \
  tests/test_sqlite_c2b2_migration_0002.py
```

#### D. Composition/architecture/runtime: 77 collected / 77 passed

```sh
run_group composition \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_architecture_contracts.py \
  tests/test_runtime_non_authority.py
```

#### E. Deterministic broad set: 4,928 collected / 4,928 passed

Expand the following four globs in the external clone using filesystem pathname
matching, not a shell that fails on an unmatched pattern. Sort and deduplicate
repository-relative paths; pass each resulting path once as a separate pytest
argument:

- `tests/test_rw0_*.py`
- `tests/test_c2b*.py`
- `tests/test_sqlite_c2b*.py`
- `tests/test_sqlite_rw0*.py`

Require exactly 48 paths and SHA-256 of UTF-8 newline-joined paths with NO final
LF equal to:

`0c57aa37134d814b5e1dc3efb22cbe440c8c1bb6a12b8dc1b4223fb47e9893c0`

Use `run_group broad` with that exact array, or an equivalent blocking subprocess
runner with the same flags. Retain the exact array in memory or the disposable
root and report its count/hash and command expansion. Do not reverse-engineer
file selections to reach a test count.

#### F. Full repository: 8,742 collected / 8,742 passed, three existing warnings

```sh
run_group full
```

The three accepted warnings are unchanged Python 3.13 multithreaded-fork
DeprecationWarnings associated with these existing writer-session nodes:

- `test_operation_guard_close_waits_and_retains_authority_until_exit`
- `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang`
- `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock`

Reconcile node IDs and actual warnings, not just the number three. No suppression
or skipping. Extra, missing, or different warnings and any count mismatch require
investigation before a commit, not automatic acceptance or an environment change.

Do not invent the separately reported 926-test expanded selector: its exact
command was not an independently reproduced audit input. The six fully specified
groups above are the required staged-byte validation gates.

Do not rerun hostile-copy audits at this publication gate. The accepted audit
already owns the 44-copy matrix and independent bounded specimens. No additional
language support or parser machinery is authorized here.

### Post-validation equality

After all tests exit, prove the clone's six bytes still equal the live index;
non-candidate clone files still equal baseline; no clone-local generated cache,
database, journal, sidecar, coverage, build, or report artifact remains. Disposable
fixture databases under the external basetemps are permitted and later removed.

Recheck live HEAD, exact index tree, all six index/worktree bytes, unaffected Git
entries, and live cache. No test may change the live checkout or staged tree.

A candidate-related failure blocks before commit. A clearly isolated setup or
harness error may be corrected only outside the repository; record the failed
attempt and rebuild/reverify the clone before a clean rerun. Never edit candidate
bytes or weaken assertions to obtain a passing result. Never grant acceptance
credit to overlapping runs.

## 8. One exact local commit

Immediately before commit, recheck local baseline, staged tree/blobs, worktree,
cache, the live remote base OID, topic absence, and absence of a PR for that head.
If base or policy has materially changed, stop without committing. No rebase or
new candidate work is authorized.

Create exactly one ordinary commit on local `trunk_dev` with configured author
identity, configured hooks, and configured signing requirements. Do not override
identity, bypass a hook, disable signing policy, amend, or use an empty commit.

Exact subject:

```text
docs: freeze RW0-C2 private value and graph profiles
```

Exact body:

```text
Adopt the private RW0-C2 value/versioning and receipt-graph profile contract
and its causal contract verifier.

Preserve immutable lineage-scoped admission and acceptance semantics,
branch-neutral identities, exact replay, whole-family recovery, unchanged
migration-0002 v1 meanings, and B1 compatibility nonauthority.

This change adds target documentation and contract tests only. It adds no
source values, migration 0005, admission provisioner, durable decision writer,
reader, recovery runtime, terminal implementation, public API, RW0-D/E,
or Execution Substrate integration.

Audit:
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Construct the complete message as subject, two LF bytes, exact body, and one
terminal LF. Verify message bytes from the created commit object. Use a temporary
message file under the private root if needed; do not leave it in the repository.

After commit require:

- Exactly one parent: the opening HEAD
- Tree exactly equal to the staged tree
- Exact message, no amend or extra commit
- Exactly six changed paths: four modifications, two additions
- All six mode `100644`; every committed blob OID equals its staged OID
- Every committed blob byte count and SHA-256 equals its audited receipt
- All unaffected tree entries identical to the parent
- Clean live index/worktree/untracked/unmerged posture
- Local `trunk_dev` ahead 1 / behind 0 of unchanged `origin/trunk_dev`
- Exact live cache preservation

Record the new commit/tree OIDs, parent, message digest, and committed blob table.
Do not assume SHA values before Git creates the object.

## 9. One topic push and one PR

Re-read remote base, effective publication policy, exact topic ref, and existing
PR inventory immediately before push. Require the base still equals the opening
HEAD and the topic/PR remain absent. If drift appears after local commit, preserve
the commit and report publication incomplete; do not rebase, force, or use another
branch.

Push exactly once with a plain non-force refspec:

```text
git push origin <new_commit_oid>:refs/heads/codex/rw0-c2-private-value-versioning-contract-v1
```

Do not push `trunk_dev`, use `--all`, use `--tags`, set trunk's upstream to the
topic, or use any force/force-with-lease option. Do not retry a failed/ambiguous
write. Use read-only remote observations to determine its effect.

After push, verify topic ref equals the exact new commit and remote base remains
unchanged. Recheck for an existing PR before creating one. Do not create duplicate
publication effects after response loss.

Create exactly one non-draft PR in `evo-agi/Governed-Execution-Coordinator` with:

- Base: `trunk_dev`
- Head: `codex/rw0-c2-private-value-versioning-contract-v1`
- Exact head OID: new verified local commit
- Title: `docs: freeze RW0-C2 private value and graph profiles`
- Auto-merge: absent / disabled; do not enable it
- No labels, assignees, review requests, milestones, projects, or unrelated edits

Exact PR body (one final LF):

```markdown
## Summary

- adopt the target-only RW0-C2 private value/versioning and receipt-graph profile contract
- preserve lineage-scoped immutable admission and acceptance, branch-neutral identities, exact replay, and whole-family recovery
- retain current migration-0002 v1 meanings and the B1 compatibility-only boundary
- include the independently accepted V9 verifier repair for visible blockquote continuation and neutral-subject classification

## Validation

Validated exact staged blobs in a local-only external clone, serially:

- private verifier: 925 passed
- C2 guard and decision contracts: 1,623 passed
- focused B1/C2B2/migration-0002 group: 458 passed
- composition/architecture/runtime group: 77 passed
- deterministic 48-file broad group: 4,928 passed
- full repository: 8,742 passed, with 3 unchanged writer-session fork warnings

The prior independent audit accepted 44 reconstructed transformed-copy categories and bounded composition checks within the documented grammar.

## Non-implementation

No source-value implementation, migration 0005, admission provisioner, durable
decision writer, reader, recovery runtime, terminal implementation, production
caller, public API, runtime activation, RW0-D/E, or Execution Substrate
integration is introduced.

Audit:
`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
```

Verify after creation:

- Exact repository, base/head refs, head OID, and one source commit
- PR `OPEN`, non-draft, unmerged
- Exactly six changed files, path statuses and blob/tree effect as committed
- Exact title/body (report any server newline normalization explicitly)
- Auto-merge absent, no merge/merge queue requested
- Live mergeability, merge state, check/status/workflow projections, reviews and
  unresolved conversations, with their observation time
- Remote base unchanged and topic ref equal to the committed source OID

Checks can still be pending or absent after PR creation. Report their actual
state, never treat zero checks as CI success, and do not merge on their basis.
A separately authorized merge gate will recheck current policy and PR state.

## 10. Stop, partial-effect, and cleanup rules

### Before staging

On provenance mismatch use `AUDIT_PROVENANCE_MISMATCH`. On other preflight blocks
use the blocked token below. Leave the original candidate/index/ref state intact.

### After staging but before any commit exists

Do not repair files. If HEAD and all working-tree bytes still exactly equal the
opening candidate and only this gate's six staging effects exist, unstage those
six paths only using `git restore --staged -- <six literal paths>`. Verify the
opening four-modified/two-untracked, zero-staged posture is restored. No worktree
restore, reset, checkout, or broad cleanup is authorized.

If another actor changed HEAD/index/worktree, do not unstage or overwrite that
work. Stop, report the actual state, and preserve all unexpected differences.

### Once a commit may exist

Determine commit existence by read-only local inspection before any retry.
If a commit exists, preserve it. Do not reset, amend, drop, replace, or delete it.
No further local commit is authorized. Report its exact identity even if later
checks fail.

### Push or PR response loss / partial publication

Do not blindly retry a write. Inspect remote refs and PR state. If the exact
intended effect is conclusively present, verify it and proceed only to the next
not-yet-performed authorized step. If ambiguous, stop with publication incomplete.
Do not delete an existing topic/PR, close it, repush, or use an alternate head.

No rollback of a completed remote effect is authorized. Incomplete publication
is not permission to widen scope.

### Cleanup

Remove only gate-created external clones, basetemps, scripts, message/request
files, responses, and logs after extracting inline evidence. Check child test
processes are finished before removing their directories. Never clean unrelated
`/tmp` paths or the live ignored cache. Temporary isolated test databases are
permitted; live product/operator databases are not.

Recheck final branch/HEAD/tree/index/worktree/untracked/unmerged state, cache,
remote base/topic, PR status, and exact accepted bytes. Do not claim all files or
databases were never created; distinguish live preservation from disposable
external test effects.

## 11. Outcome and inline closeout

Successful publication:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_COMMITTED_AND_PR_OPENED`

Blocked with no commit created:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_COMMIT_PUBLICATION_BLOCKED`

Commit created, but push/PR publication or final verification incomplete:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_COMMITTED_PUBLICATION_INCOMPLETE`

Opening audit identity mismatch:

`AUDIT_PROVENANCE_MISMATCH`

The successful final local posture is clean local `trunk_dev` at the new source
commit, with upstream still `origin/trunk_dev` and divergence 1 ahead / 0 behind.
The successful remote posture is unchanged base, exact topic commit, and one
open non-draft unmerged PR. Do not realign local trunk before a separately
verified remote merge.

Return one inline report containing:

1. Verdict and visible model/reasoning/permission posture.
2. Opening and closing local coordinates; remote identity/ref/policy observations.
3. Opening file/patch/receipt reproduction and cache count/type reconciliation.
4. Six staged path/status/mode/blob/size/SHA rows and exact staged tree.
5. Exact commands, collection counts, results, warnings, and broad path inventory.
6. Post-test byte/index/cache equality and all harness failures or retries.
7. Commit OID/tree/parent/message digest; exact committed blob equality.
8. Push refspec and observed effect; PR number/URL, title/body verification,
   head/base OIDs, file/commit count, policy/check/review projections.
9. Cleanup and any incomplete effect or unperformed validation.
10. Compact continuation capsule: exact source commit/tree/base/topic/PR,
    current capability versus target-only content, and next permitted separate
    merge-gate boundary. No implementation prompt.

State actual non-actions: candidate bytes and all product source/migration/runtime
surfaces unchanged; no live imports/tests/cache edits or product database access;
no dependency install, sibling access, or subagents; no amendment/rebase/cherry-
pick, direct trunk push, force push, merge/auto-merge/queue, deletion, tag, release,
or deployment; no retained/delivered external evidence artifact.

Publication records the accepted contract and verifier. It does not implement
admission provisioning, guarded decision persistence, recovery runtime, terminal
outcomes, public APIs, RW0-D/E, or ES integration. End with the verdict token.
