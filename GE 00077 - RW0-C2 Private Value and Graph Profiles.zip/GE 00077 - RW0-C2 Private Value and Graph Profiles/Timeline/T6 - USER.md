# 1. Verdict

**RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED**

Provenance matched. The candidate is blocked by an unresolved branch-neutral acceptance-fact identity rule, incomplete recovery alias-route grammar, and six required hostile variants that passed the new contract tests.

## 2. Visible model setting

- Model name: `not visible`
- Reasoning setting or effort: `not visible`

I attempted three read-only explorer reviews at the highest selectable setting available to me. The model service rejected each before inspection with `403 Forbidden` (“Daybreak isn't available for this model”). No explorer findings were used.

## 3. Baseline and six-path provenance

The live checkout matched `trunk_dev` at HEAD `3d99e448bfe577b5a5878dd32b7e01b61322e7df`, tree `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`, sole parent `6f11d6b0b6f38995123434945d86db0b169bb8f8`, and subject `docs: adopt RW0-C2 bootstrap acceptance guard`. Upstream was `origin/trunk_dev`, with 0 ahead and 0 behind. There was one worktree, no staged or unmerged path, and no active Git operation or index lock.

| Status | Repository-relative path | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| M | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| M | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| M | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| M | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| ?? | `.docs/rw0-c2-private-value-versioning.md` | 29,672 | `f6df461ed255259f4f550e14a53580b25cb13b4e773c9f876ea22b658389d41f` |
| ?? | `tests/test_rw0_c2_private_value_versioning_contract.py` | 34,788 | `4d832275ff980d937d4ef39c12d079324b943166dbbfb22a0c0c4f9d85e09e5c` |

All six are regular, non-symlink `0644` files with valid UTF-8, no BOM or CR bytes, no trailing whitespace, and exactly one final newline. No other tracked or untracked difference appeared. Source and migrations remained byte-identical to HEAD; migration `0005` is absent.

## 4. Patch and receipt reconciliation

The complete binary patch assembled twice in the required order was **70,272 bytes**, SHA-256 `3e012b1a82a261bf4310a652078d17b83675ce7acb271e42afba2e1f89eb6e79`. A separate Ruby assembly matched.

The canonical receipt reconstructed independently in Python and Ruby was **1,378 bytes**, SHA-256 `66a48768b710a8713d7be1dcf9a1bb9b5c9520b4018b6d0b8c5cab01703a384d`. There is no provenance mismatch.

## 5. Inspection scope and limits

I inspected the six candidate paths, `AGENTS.md`, the guard and decision owners, the operating model, RW0-B1 and RW0-C1 boundaries, migration 0002 and the packaged catalog, current decision/program/receipt/graph values, private readers, public surfaces, and the specified tests. The three explorers failed before work began. The audit used only the checked-out repository and disposable local copies; it did not contact a remote or supporting repository.

Two initial isolated test runs used unsuitable temporary locations and hit the repository’s `unsafe_state_root` protection: `/tmp` is a symlink on this host, and a later `--basetemp` was inside a Git checkout. Reruns with an external private test root passed. These were explained test-environment failures, not candidate failures.

## 6. Owner hierarchy and status

The new document classifies itself as accepted target and unimplemented, and delegates guard semantics, decision/replay/recovery semantics, composition, and current v1 bytes to their existing owners (`.docs/rw0-c2-private-value-versioning.md:3`, `:14`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:11`, `:22`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:478`; `.docs/autonomous-software-development-operating-model.md:81`). I found no second reducer, public protocol, provisioner, receipt, or recovery owner in the baseline candidate.

## 7. Closed logical inventory and authority matrix

The machine block has exactly eleven named values. Each ID is `governed-execution.nwp-rw0-c2-<slug>.v1`; its listed digest domain appends `.identity`. Exact IDs and field sequences are at `.docs/rw0-c2-private-value-versioning.md:199` through `:209`; the per-value authority, coverage, and prohibited-substitute lists are at `:212` through `:222`.

| Value / slug | Status and future writer | Command / receipt graph / selector coverage |
| --- | --- | --- |
| Admission act / `verified-admission-act` | External safe evidence; external standing policy | Act expectation / verified evidence / via admission |
| Scope admission / `scope-admission-fact` | Immutable durable fact; separate provisioner | Ref and digest / required / ref and digest |
| Command relation / `admitted-command-relation` | Transient; none | All expectations / command digest / exact expectations |
| Continuity / `verified-lineage-continuity` | External current safe evidence; none | Basis and source / historical evidence / basis and source |
| Sole active / `verified-sole-active` | External current safe evidence; none | Basis and source / historical evidence / basis and source |
| Acceptance / `bootstrap-acceptance-fact` | Immutable durable fact; guarded decision writer on acceptance | Preassigned ref / acceptance-only / preassigned ref |
| Family / `guarded-family-relation` | Immutable supplemental relation; guarded decision writer | Preassigned ref / required / preassigned ref |
| Result / `guarded-progression-result` | Derived composite; none | Preassigned ref / required / preassigned ref |
| Receipt / `receipt-graph-profile` | Derived profile; none | Excluded / generic v1 receipt root / mutation route |
| Selector / `complete-family-selector` | Transient query; none | Excluded / excluded / self |
| Recovery / `complete-family-recovery-result` | Transient projection; none | Excluded / excluded / excluded |

Replay and recovery remain with the decision owner for every row. This inventory is closed as a list, but the acceptance coordinate and selector coverage are not sufficiently closed as *value rules*, as described below.

## 8. Caller branch preselection — **High**

The command contains `preassigned_acceptance_fact_ref`, calls optional references nullable, and includes that coordinate in its digest. The selector later contains `acceptance_fact_ref`; acceptance requires a fact, while all four other branches forbid one (`.docs/rw0-c2-private-value-versioning.md:77`, `:201`, `:208`, `:217`, `:225`, `:252`). No rule says the coordinate is reserved non-null for every command, nor supplies a deterministic branch-neutral identity when it is null.

| Command coordinate | Derived branch | Unresolved consequence |
| --- | --- | --- |
| Null | Acceptance | The required fact lacks its promised preassigned, command-covered identity, unless a derivation rule is added. Rejecting acceptance instead gives the caller a branch veto. |
| Non-null | Nonaccept | The profile forbids a fact, but does not say whether the unused reserved identity must be collision-probed. |
| Null | Nonaccept | The selector has no exact fact-identity route; null cannot prove an unclaimed scope. |
| Non-null | Acceptance | The intended case is representable, but does not settle the other three. |

The guard expressly forbids the relation from requesting acceptance and requires exhaustive acceptance-family proof (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:63`, `:68`, `:71`). The decision owner derives the branch (`.docs/rw0-c2-durable-progression-decision-semantic-contract.md:362`, `:365`). This rule needs to be fixed before the value contract can be accepted.

## 9. Current posture versus historical basis

The baseline prose correctly separates authenticated admission, retained historical continuity and sole-active evidence, and fresh external posture before protected replay or recovery (`.docs/rw0-c2-private-value-versioning.md:19`, `:27`, `:123`, `:131`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:94`). The original command digest need not change to obtain fresh proof. A hostile change making the historical basis standing permission nevertheless passed all 45 new tests; that is a regression-guard finding, not a claim that the baseline prose already says it.

## 10. Identity and digest DAG

An independent topological sort of the machine edges produced: admission act; continuity and sole-active bases; admission fact; command digest; decision/version/head; optional acceptance fact; family relation; guarded result; receipt graph; replay/recovery. The graph is acyclic. Admission does not depend on result or receipt, the acceptance fact does not depend on either, and the selector excludes timestamp and postcommit digests (`.docs/rw0-c2-private-value-versioning.md:90`, `:99`, `:224`, `:258`). The generic v1 result derives from the decision/version before the guarded relation binds its digest.

## 11. Command digest coverage

The block lists 29 included coordinates covering lineage/scope, admission act and fact, guard profile/applicability, safe continuity and sole-active expectations, mutation, basis and expected head, five preassigned identity coordinates, and route. It excludes caller-authored authoritative branch/conclusion, timestamp, resulting digests, graph digest, terminal outcome, credentials, and raw attestations (`.docs/rw0-c2-private-value-versioning.md:102`, `:225`). Machine mutations removing continuity or adding caller branch failed at `command_digest`. The decision owner separately requires its optional *expected-branch assertion* to be digested; that is an optimistic assertion, not an authoritative branch (`.docs/rw0-c2-durable-progression-decision-semantic-contract.md:398`).

## 12. Five branch profiles

The profile names ten common roles and adds `acceptance_fact` exactly once for `candidate_acceptance`; repair, replan, terminal reject, and block add none (`.docs/rw0-c2-private-value-versioning.md:229`, `:233`, `:252`). The historical head role is a complete postimage snapshot with explicit ref/revision/digest/version equalities, distinct from the later mutable head (`:231`, `:232`). External mutations adding, removing, duplicating, substituting, or copying roles failed at `receipt_graph` or `branch_profile`. Those static checks do not resolve the command-coordinate cases in section 8.

## 13. Current v1 result and receipt preservation

Current source fixes decision and receipt columns (`src/ge_nwp_coordinator/_development_decision_row_values.py:35`, `:54`), the five-field generic progression result identity (`:436`, `:451`), receipt validation (`:772`), and a graph digest over supplied entries (`:952`, `:1006`). Program head and version fields are fixed at `src/ge_nwp_coordinator/_development_program_row_values.py:35` and `:45`; migration 0002 supplies their physical tables and the receipt table (`src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:475`, `:537`).

The candidate adds no v1 field or domain and keeps the generic receipt as root (`.docs/rw0-c2-private-value-versioning.md:153`, `:227`, `:261`). The current graph primitive validates supplied entry shape and digest; it does **not** prove required-role completeness or exact member reconstruction (`src/ge_nwp_coordinator/_development_decision_row_values.py:993`, `:1025`). The target document correctly assigns that proof to a later profile verifier (`.docs/rw0-c2-private-value-versioning.md:124`). Current private readers expose no RW0-C2 complete-family proof (`src/ge_nwp_coordinator/_sqlite_development_readers.py:217`, `:261`).

## 14. Guarded relation, result, and receipt

The relation supplements exact v1 members and retains the historical head postimage; the guarded result is a derived composite; the profile creates no separate durable result or guard receipt (`.docs/rw0-c2-private-value-versioning.md:48`, `:54`, `:62`, `:68`). The generic receipt graph is one logical root. Exact member role/ref/digest reconstruction is required before its graph digest receives completeness credit (`:115`, `:124`, `:247`). This portion preserves the current v1 identity boundary.

## 15. Recovery selector and result — **Medium**

The result has the required three classes, and the baseline prose forbids repair, reevaluation, automatic retry, and renewal (`.docs/rw0-c2-private-value-versioning.md:139`, `:148`, `:260`). It covers exact replay, conflicting mutation digest, competing winner, total absence, partial/foreign family, and unproved clone continuity.

The selector, however, names an unconstrained `alias_routes` field without a closed element grammar or an exact inventory of required collision routes (`.docs/rw0-c2-private-value-versioning.md:208`, `:258`). Combined with the nullable fact coordinate, it does not specify how a verifier proves exhaustive absence rather than simply failing to query an omitted alias. The guard and decision owners require exhaustive checks before `definitely_not_committed` (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:68`, `:108`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:434`, `:438`). A hostile prose change allowing null to skip the fact collision route passed the new tests.

## 16. B1 compatibility

The exact `latch_postimage_ref` / `latch_postimage_digest` order and nullability remain in `RW0TerminalOutcomeV1`; its schema and budgets are unchanged (`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:746`, `:757`, `:761`, `:949`, `:1048`). The existing pair is required for normal accept and otherwise follows the current branch grammar (`:1059`, `:1063`). Its identity domain remains schema ID plus `.identity` (`:427`). The changed B1 documentation expressly bars the future guarded decision writer from reading or consuming either field and grants the pair no admission, acceptance, uniqueness, replay, or recovery authority (`.docs/rw0-b1-pure-phase-values.md:442`). I found no B1 successor or source change.

## 17. Nonimplementation and physical seam

The packaged catalog remains 0001–0004 at `src/ge_nwp_coordinator/sqlite_migration.py:388` through `:429`; no `0005` file exists. The source tree, exports, and `StateStore` are unchanged. The candidate explicitly defers SQL, indexes, readers, writer signature, transactions, provisioner, runtime, RW0-D/E, and ES work (`.docs/rw0-c2-private-value-versioning.md:173`, `:181`). No current-implementation claim was found.

## 18. Test independence

The test parses the document block with recursive duplicate-key rejection (`tests/test_rw0_c2_private_value_versioning_contract.py:41`), compares exact built-in types including bool versus int (`:24`), uses fixed test-local machine expectations (`:65`, `:239`), and derives current v1 inventories through source AST reads (`:302`, `:312`). It is not a hash-only or executable reducer test.

Its prose guard checks only eight selected phrases (`:259`, `:264`). The hostile tests mutate the parsed block in memory (`:390`, `:431`); they do not validate concrete command/family null cases or catch several contradictory normative prose edits. The document itself says prose and test both constrain meaning (`.docs/rw0-c2-private-value-versioning.md:185`).

## 19. Adversarial variants — **blocking test finding**

I ran **43** variants in a disposable external copy. Each collected the same 45 tests. **37 failed** at named semantic checks, covering admission authorship, operational identity, local absence, mutable latch state, extra owners, all five fact-count branches, DAG back-edges, command and selector fields, graph role addition/removal/duplication/substitution/copy, v1 identity changes, B1 authority, migration/runtime claims, terminal, and ES replenishment.

**Six required prohibited changes survived all 45 tests:** historical basis becomes current permission; caller null forces branch; local absence proves `definitely_not_committed` without continuity; replay creates a new fact/timestamp; command relation admits an unadmitted scope; and null fact coordinate skips its collision route. These were prose mutations in the external copy, restored after each run. No variant failed collection or only on syntax/import/formatting. Any survivor blocks the requested acceptance gate.

## 20. Independent validation

| Group | Collected | Measured run |
| --- | ---: | --- |
| New private-value contract | 45 | 45 passed |
| Existing guard and decision contracts | 1,623 | 1,623 passed |
| Specified B1, C2B2 values, migration 0002 | 458 | 458 passed |
| Operating model, architecture, runtime | 77 | 77 passed |
| RW0/C2B/SQLite globs | 4,048 | 4,048 passed |
| Complete repository | 7,862 | **7,862 passed, 3 warnings** |

The three full-suite warnings were Python 3.13 multithreaded-`fork()` warnings at `multiprocessing/popen_fork.py:67` and existing writer-session test paths `tests/test_sqlite_b2c_writer_session.py:1442` and `:1554`. `git diff --check HEAD` passed. Both new-file `/dev/null` whitespace checks returned the expected difference status `1` with no whitespace diagnostic. File hygiene, source/migration preservation, and an external-clone artifact scan passed. The corrected isolated runs had no unexplained collection, count, or warning mismatch.

## 21. Severity-ranked findings

1. **High — Branch-sensitive nullable identity:** no branch-neutral rule makes the preassigned acceptance-fact ref usable for every derived branch and for recovery. Evidence: `.docs/rw0-c2-private-value-versioning.md:201`, `:208`, `:217`, `:252`.
2. **High — Required hostile variants survive:** six prohibited semantic prose mutations passed all 45 tests. Evidence: `tests/test_rw0_c2_private_value_versioning_contract.py:259`, `:390`, `:431`.
3. **Medium — Recovery alias inventory is open:** `alias_routes` lacks the exact role and completeness grammar needed for exhaustive absence. Evidence: `.docs/rw0-c2-private-value-versioning.md:208`, `:258`.

## 22. Exact next boundary

Resolve the branch-neutral fact-coordinate rule and the selector’s closed alias inventory in the accepted-target contract, then strengthen the independent tests so the surviving semantic mutations fail at their owning boundaries. That changed candidate needs fresh provenance and audit before a separate commit gate. This verdict authorizes no implementation or publication step.

## 23. Required non-actions

These statements refer to the **live repository and operator/product state**. Disposable pytest fixtures did create and mutate test databases in the external test root; those fixtures and both external checkouts were removed.

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```

## 24. Final token

RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED
