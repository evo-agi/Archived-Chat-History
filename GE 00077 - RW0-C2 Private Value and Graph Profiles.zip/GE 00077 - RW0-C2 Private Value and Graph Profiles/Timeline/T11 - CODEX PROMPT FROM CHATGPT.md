# Governed Execution Coordinator — RW0-C2 Private Value Contract V3 Complete Preassignment DAG and Concrete Route Repair

## Role and objective

Resume the implementation conversation that produced the uncommitted RW0-C2
private value/versioning and graph-profile V2 candidate.

Change the parent permission posture to workspace-write before sending this
turn.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its fresh independent re-audit
returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

The audit established:

- exact baseline and six-path provenance;
- exact 114,527-byte patch and 1,379-byte canonical receipt;
- no source, migration, existing-test, export, public-surface, or runtime
  widening;
- the owner hierarchy, eleven-value inventory, v1 preservation, B1
  non-consumption, five branch profiles, current-posture rule, and
  nonimplementation boundary are otherwise coherent;
- five unresolved findings:
  1. the complete command/preassignment identity graph is not proven acyclic;
  2. concrete collision-route elements conflict with machine route templates;
  3. six prohibited contradictory prose additions still pass;
  4. nonaccept family-relation fact fields lack exact value rules;
  5. admission and branch-neutrality tests remain self-consistent fixtures
     rather than causal owner-bound checks.

This is a **two-file private contract/test repair**. Preserve the accepted
architecture. Do not implement source, migration 0005, admission provisioning,
continuity transport, persistence, readers, transactions, recovery, public
interfaces, runtime, RW0-D/E, or Execution Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V2 candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 41,459 | `db2d3298465f1958b0f5d3355abbfe4d32375d2c802934283b03c8bd0e145240` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 66,615 | `5b8155ab8a8730fcd716b6b7f5a716c8b2e25a0488d41700b2a28ecabf2f8a06` |

Required opening ordered patch:

- bytes: `114,527`
- SHA-256:
  `63addad94b2a60bcc9750e3f57919b445c672cd87cd321722b94f989f5caf2ac`

Construct it twice in lexicographic path order with:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,379`
- SHA-256:
  `e902ed0d650e50796a44b09675395dbc3a6c225297c621bfdf627fc1d521d70a`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V3_REPAIR_BLOCKED`

## Exact mutation ceiling

Only these two paths may change from their opening V2 bytes:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

The other four candidate documents must remain byte-identical to the opening
receipts.

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- architecture, C2B, guard-owner, decision-owner, B1, or operating-model
  documents;
- configuration or examples.

Migration `0005` must remain absent.

If the two-file ceiling is insufficient, restore the exact opening candidate and
return the blocking token. Do not widen the tranche.

## Accepted architecture that must not be reopened

Preserve exactly:

1. The closed eleven logical private values/profiles and their owner hierarchy.
2. The guard owner controls lineage, scope, admission, current continuity,
   sole-active-authority posture, one-shot eligibility, permanence, terminal,
   and ES boundaries.
3. The decision owner controls authoritative branch derivation, generic
   decision/version/head/result/receipt meanings, replay, collision taxonomy,
   and whole-family recovery.
4. Migration-0002 v1 values remain canonical within unchanged meanings.
5. Admission provisioning and guarded decision persistence remain separate
   semantic owners.
6. Acceptance creates one immutable acceptance fact in the same atomic family.
7. Four nonaccept branches create no acceptance fact.
8. There is one logical result, one receipt root, one replay owner, and one
   recovery owner.
9. Historical continuity and sole-active evidence is not current permission.
10. Fresh positive external posture remains required before protected replay or
    recovery disclosure.
11. B1 `latch_postimage_*` remains compatibility/nonproof only and is not
    consumed by the guarded decision writer.
12. Physical schema, migration `0005`, readers, writers, transaction mechanics,
    provisioner mechanics, public interfaces, and runtime remain future.

This repair closes exact private identity, query-value, relation-value, and test
semantics. It does not redesign product policy or physical storage.

# Finding H1 — complete branch-neutral preassignment DAG

## Problem to close

The V2 contract derives the prospective acceptance-fact ref from preassigned
decision/version refs and a deterministic family route, then covers all of
those values in the command digest. It does not freeze how those preassignments
or the guarded relation/result refs originate.

The contract therefore does not exclude hidden cycles such as:

```text
command_digest
  -> family_route
  -> prospective_acceptance_fact_ref
  -> command_digest
```

or:

```text
command_digest
  -> preassigned_decision_ref
  -> prospective_acceptance_fact_ref
  -> command_digest
```

The V3 contract must prove a complete expanded DAG rather than assert that refs
are “independently assigned.”

## Selected design

Define one exact, branch-neutral,
`guarded_family_preassignment_basis_v1` **derivation transcript** inside the
existing admitted-command-relation contract.

It is not a twelfth logical value, not durable authority, and not a public DTO.
It is a canonical value-level derivation basis owned by the private-value
contract.

### Primitive-basis partition

The contract must enumerate, in exact order, every primitive command coordinate
used by the transcript.

Each primitive field must satisfy all of:

- available before any protected branch reduction;
- not derived from command digest;
- not derived from any preassigned identity below;
- not derived from branch, result, receipt, transaction timestamp, terminal
  outcome, or postcommit state;
- already owned as verified external evidence, a current-owner value, an
  admission binding, mutation identity, or a caller expectation that the
  Coordinator independently verifies.

Derive the exact primitive list from the live admitted-command-relation machine
block and guard/decision owners.

At minimum the list must cover the applicable exact versions and coordinates
for:

- private command/preassignment profile;
- canonical lineage;
- bootstrap scope;
- admission-fact ref and digest;
- guard profile and direct-local applicability;
- mutation ref;
- program identity;
- exact decision basis/current-head expectation required by the decision
  owner;
- safe continuity and sole-active evidence expectation refs/digests or source
  coordinates, without treating them as standing permission;
- any other primitive branch-neutral command field currently covered by the
  command digest.

Do not silently omit a command-covered primitive. Do not include a derived
preassignment.

### Sibling identity derivations

Derive each of these independently from the same canonical primitive transcript
using a distinct, frozen domain separator:

1. `preassigned_decision_ref`
2. `preassigned_resulting_program_version_ref`
3. `preassigned_guarded_family_relation_ref`
4. `preassigned_guarded_progression_result_ref`
5. `deterministic_family_route`
6. `preassigned_acceptance_fact_ref`

None may depend on:

- another sibling derived identity;
- command digest;
- expected or authoritative branch;
- generic or guarded result;
- relation digest;
- receipt ref/digest or graph digest;
- transaction timestamp;
- terminal outcome;
- postcommit head;
- raw external credential or attestation bytes.

Use the same exact canonicalization family for all six:

```text
lowercase_sha256(
    domain_separator_utf8
    + NUL
    + compact_utf8_json(ordered primitive name/value pairs)
)
```

Freeze for each sibling:

- exact domain separator;
- exact output grammar/prefix;
- exact ordered primitive preimage;
- exact type requirements;
- one independent fixed vector.

The output may preserve an existing semantic prefix around the lowercase digest,
but the grammar must be exact.

### Command digest ordering

The authoritative future command digest is derived only after all six sibling
identities have been independently derived and validated.

It covers:

- all required primitive command coordinates;
- all six sibling preassignments;
- the existing command-covered expectations fixed by the V2 contract.

No sibling identity may depend on the command digest.

### Post-branch identities and digests

After authoritative branch derivation:

- canonical decision/version/head values use their already reserved refs;
- acceptance branch creates exactly one fact at its reserved ref;
- nonaccept branches create no acceptance fact;
- guarded relation/result use their reserved refs;
- actual content/self digests are computed from their branch-specific values;
- the generic receipt graph is last;
- replay/recovery projections follow.

No post-branch digest may feed any preassignment.

### Expanded dependency registry

Add one exact machine-readable dependency registry covering every identity and
digest node from external admission through recovery.

Each node must have exactly:

- `node`;
- `stage`;
- `origin_class`;
- `dependencies`;
- `prohibited_dependencies`.

Required origin classes must be closed and distinguish at least:

- externally verified;
- current-owner durable/current value;
- caller expectation independently verified by Coordinator;
- primitive derivation transcript;
- sibling domain-separated derivation;
- authoritative branch output;
- post-branch canonical value/digest;
- receipt graph;
- replay/recovery projection.

The verifier must independently topologically sort the complete graph and reject
any omitted node, hidden dependency, cycle, stage inversion, or prohibited
backedge.

A collapsed broad-node DAG is insufficient.

# Finding H2 — concrete selector routes versus route templates

## Problem to close

V2 prose states that each concrete
`selector.required_collision_routes` element has exactly:

```text
role
kind
key
expected_schema_id
```

The machine block uses `key_sources` under the same field name. Test code treats
those entries as templates, but the contract never names a template/instance
boundary.

## Selected design

Freeze two distinct machine-readable structures.

### A. Closed route-template inventory

Name it:

`collision_route_templates`

Each template has exactly:

- `role`;
- `kind`;
- `key_sources`;
- `expected_schema_id`.

Freeze exact order, count, roles, kinds, source-field names, and schema IDs for
the eight existing routes:

1. mutation receipt;
2. decision identity;
3. resulting version identity;
4. acceptance fact identity;
5. guarded family relation identity;
6. guarded progression result identity;
7. deterministic family route;
8. admitted-scope winner.

No extension slot is allowed.

### B. Concrete selector-value grammar

The logical `complete-family-selector` value contains
`required_collision_routes`.

Each concrete route element has exactly:

- `role`;
- `kind`;
- `key`;
- `expected_schema_id`.

Use one uniform exact `key` type:

- an ordered JSON array/immutable tuple of exact built-in strings;
- single-coordinate routes still use a one-element key;
- the admitted-scope winner uses its exact ordered multi-coordinate key.

Freeze exact instantiation:

```text
concrete.key =
    tuple(selector[top_level_field] for top_level_field in template.key_sources)
```

Require exact equality between every concrete key coordinate and the selector’s
top-level canonical coordinate.

The template is contract metadata. The concrete route is the transient selector
value. Neither is durable authority or a second collision/recovery owner.

### Required rejection

Reject at exact boundaries:

- template or concrete field confusion;
- `key_sources` in a concrete route;
- `key` in a template;
- missing/duplicate/unknown/reordered template;
- missing/duplicate/unknown/reordered concrete route;
- wrong key type;
- wrong coordinate order;
- coordinate copied from another role;
- wrong/null schema ID;
- implementation-specific extension route;
- timestamp or postcommit dependency;
- omitted acceptance route on a nonaccept branch;
- omitted scope-winner route.

# Finding M1 — exact family-relation acceptance fields

The guarded family relation currently carries:

- `acceptance_fact_ref`;
- `acceptance_fact_digest`.

Freeze exact branch rules.

## Acceptance branch

Both fields are exact non-null strings.

Require:

- `acceptance_fact_ref` equals the command’s reserved prospective fact ref;
- `acceptance_fact_digest` equals the verified actual immutable acceptance-fact
  digest;
- the acceptance fact exists exactly once;
- the receipt graph includes the exact acceptance role exactly once.

## Four nonaccept branches

Both fields are exactly JSON/Python `null`/`None`.

Require:

- no acceptance fact exists;
- no receipt-graph acceptance member exists;
- the command and recovery selector still carry and probe the reserved
  prospective fact ref;
- the null relation fields do not mean the scope is unclaimed;
- any non-null/dangling fact claim is invalid;
- any durable fact at the reserved identity is a collision/unresolved input
  under the existing decision-owner taxonomy.

Do not omit the relation fields and do not create a branch-specific second
relation schema.

# Finding M2 — causal admission and branch-neutrality evidence

## Admission binding

Replace self-consistent arbitrary admission strings with one independent fixed
verified-admission fixture.

The fixture must include the exact value-contract fields for:

- verified admission act;
- immutable scope-admission fact;
- lineage;
- scope;
- admission-fact ref/digest;
- guard profile;
- direct-local applicability.

The admitted-command relation must be checked against that separate fact before
any branch/family projection.

Mutations of lineage, scope, admission ref, admission digest, profile, or
applicability must fail at exact admission-binding boundaries.

The test must not let the command fixture author the expected admission
relationship.

## Branch neutrality without a second reducer

Do not copy or reimplement C2 branch logic.

Load and invoke the existing document-driven C2 contract interpreter/helper from
`tests/test_rw0_c2_durable_progression_decision_semantic_contract.py` in the
external validation clone, or use an equivalent exact shared helper already
present in that module.

For fixed bases that derive all five branches:

- vary the prospective fact coordinate independently;
- prove the C2 branch input grammar does not include that coordinate;
- prove the derived branch is unchanged by coordinate presence/value when
  command validation is intentionally observed separately;
- require null/wrong coordinates to fail command-relation validation before
  family materialization;
- require the correct coordinate to permit the already-derived branch;
- require acceptance/nonaccept materialization rules afterward.

The private-value verifier may validate command and family values. It must not
become a second branch reducer.

Add an AST/structural guard proving the private-value verifier calls the shared
C2 interpreter/helper and does not copy the branch table or precedence logic.

# Finding H3 — contradictory normative prose

## Problem to close

Six semantically prohibited assertions can be inserted into otherwise unchanged
prose while all 186 tests pass. Positive phrase presence is insufficient.

## Selected design

Create a bounded, closed normative-clause registry in the new document for the
authority-sensitive value rules.

Each clause has exactly:

- `clause_id`;
- `subject`;
- `modality`;
- `predicate`;
- `object`;
- `qualifier`.

The registry must cover at least:

- historical basis is not current permission;
- current positive posture is required;
- prospective identity cannot force or veto branch;
- local absence alone cannot prove noncommit;
- replay creates no fact and no timestamp;
- command relation cannot admit/select scope;
- nonaccept retains the acceptance-fact collision route;
- admission writer/decision writer separation;
- one result/receipt/replay/recovery owner;
- terminal/ES non-replenishment.

The human prose and machine block remain independently authored, but the
contract must declare that every normative statement about these subjects is
represented by exactly one registered clause.

## Closed normative prose surface

Implement one bounded whole-document semantic contradiction scan, not merely
positive-phrase checks.

At minimum:

- tokenize/normalize Markdown prose outside code/machine blocks;
- identify sentences using the registry’s closed subjects, modalities, and
  predicates;
- require every normative sentence in those subjects to map to exactly one
  known clause;
- reject an unknown or contradictory clause;
- reject duplicate opposite modality;
- reject added normative assertions that are not registered;
- allow explanatory nonnormative prose without authority verbs.

Do not claim general natural-language theorem proving. This is a bounded
contract-vocabulary parser for the exact authority-sensitive terms in this
document.

All six previously surviving contradictory additions must fail at named
boundaries:

1. historical basis becomes current permission;
2. null/non-null coordinate forces or vetoes branch;
3. local absence proves noncommit without current posture;
4. replay creates a fact or timestamp;
5. command relation admits/selects scope;
6. nonaccept skips the fact route.

Permanent controls and external transformed copies must both cover them.

# Complete test requirements

The repaired verifier must retain:

- recursive duplicate-key rejection;
- exact built-in type comparison, including bool/int separation;
- fixed expectations independent from the machine block;
- source-derived current-v1 inventories;
- one logical result/receipt/replay/recovery owner;
- no broad source manifest;
- no physical schema emulator;
- no second reducer;
- no file-hash-only correctness claim.

## Expanded DAG tests

Require:

- exact primitive basis field inventory and order;
- exact classification of every basis field’s origin;
- exact six sibling derivations and fixed vectors;
- every primitive change changes every sibling result where specified;
- sibling outputs do not feed one another;
- command digest is downstream of all siblings;
- branch/result/receipt/timestamp/terminal changes are excluded;
- complete graph topological sort;
- cycle insertion at every sibling and command edge;
- omitted node/dependency;
- unknown origin class;
- stage inversion;
- aggregate digest hiding a backedge.

## Relation/profile tests

For all five branches require exact:

- relation fact ref/digest values;
- acceptance-fact membership cardinality;
- receipt-role cardinality;
- prospective route retention;
- no unclaimed-scope inference.

## Concrete route tests

Require exact templates and concrete values, including:

- instantiation from selector top-level fields;
- exact route order and count;
- exact key arrays;
- exact schema IDs/nulls;
- every malformed template/route case listed above.

## Admission/branch tests

Require:

- independent verified admission fixture;
- all admission mismatch dimensions;
- shared C2 interpreter usage;
- all five derived branches;
- coordinate null/wrong/correct truth table;
- no coordinate influence on branch;
- collision at reserved identity on every branch.

## Recovery and replay tests

Require:

- complete exact family;
- same mutation/different command;
- every preassigned identity collision;
- deterministic family-route collision;
- competing scope winner;
- exhaustive absence only with fresh positive posture and all eight concrete
  routes;
- absence without posture unresolved;
- missing/unreadable/foreign/duplicate route unresolved;
- partial/orphan fact/relation/result/receipt combinations unresolved;
- exact replay preserves original fact absence/presence and timestamp;
- no repair, reevaluation, retry, or scope renewal.

# External transformed mutants

In disposable external copies execute at least:

## Identity DAG

1. decision ref derived from command digest;
2. version ref derived from command digest;
3. relation ref derived from guarded relation digest;
4. guarded-result ref derived from guarded result digest;
5. family route derived from command digest;
6. prospective fact ref derived from branch;
7. one sibling derived from another sibling;
8. command digest removed from downstream stage;
9. primitive basis omits a command-covered field;
10. postcommit timestamp added to primitive basis;
11. aggregate digest hides a backedge;
12. complete graph drops one node.

## Routes

13. machine uses `required_collision_routes` templates with `key_sources`;
14. concrete route uses `key_sources`;
15. template uses concrete `key`;
16. missing route;
17. duplicate route;
18. unknown route;
19. reordered route;
20. wrong key type/order;
21. copied coordinate;
22. wrong schema ID;
23. omitted acceptance route on nonaccept;
24. omitted scope-winner route;
25. extension route;
26. timestamp/final-receipt dependency.

## Relation and branch

27. nonaccept relation has non-null fact ref;
28. nonaccept relation has non-null fact digest;
29. acceptance relation has null fact ref/digest;
30. acceptance fact missing;
31. nonaccept fact present;
32. coordinate forces acceptance;
33. coordinate vetoes acceptance;
34. private verifier copies branch table instead of shared C2 helper.

## Admission/prose/replay

35. command relation binds a foreign admission fact;
36. command relation changes scope;
37. historical basis becomes current permission;
38. local absence proves noncommit without current posture;
39. replay creates a fact;
40. replay refreshes timestamp;
41. command relation admits/selects scope;
42. nonaccept skips acceptance collision route;
43. terminal replenishes acceptance;
44. ES routing replenishes acceptance.

For every mutant require:

- unchanged expected collection;
- failure at the intended exact semantic boundary;
- no syntax/import/format/collection-shrinkage-only failure.

Report permanent internal negative controls separately from transformed external
copies.

# Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution and report exact counts.

Run:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening V2 reference: `186 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contract modules
   - reference: `1,623 passed`.

3. Specified B1, C2B2 values, and migration-0002 modules
   - reference: `458 passed`.

4. Operating-model, architecture, and runtime modules
   - reference: `77 passed`.

5. Broad:
   `tests/test_rw0_*.py tests/test_c2b*.py tests/test_sqlite_c2b*.py tests/test_sqlite_rw0*.py`
   - opening V2 reference: `4,189 passed`.

6. Complete repository
   - opening V2 reference: `8,003 passed, 3 warnings`.

The full-suite increase may equal only the exact new contract-test nodes.

The only accepted warnings remain the unchanged Python 3.13
multithreaded-`fork()` warnings from existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling;
- proof the other four candidate documents remain byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- exact live-cache opening/closing member equality;
- removal of all engagement-created temporary data.

# Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact two-file V2-to-V3 transition;
6. proof the other four candidate paths stayed byte-identical;
7. complete primitive-basis and sibling-identity registry;
8. full expanded DAG and topological proof;
9. template/concrete route grammar and eight-route inventory;
10. branch-specific relation fact rules;
11. causal admission and shared-C2 branch evidence;
12. closed normative-clause registry and contradiction detection;
13. prior five audit findings disposition;
14. permanent controls versus external mutant results;
15. exact collection and validation results;
16. source/migration/public/runtime preservation;
17. deterministic final six-path patch bytes and SHA-256;
18. fully specified final canonical receipt grammar, bytes, and SHA-256;
19. live-cache equality and cleanup;
20. remaining physical seams;
21. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

# Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the two-file ceiling is insufficient;
- another owner document must change;
- current source contradicts v1 preservation;
- exact primitive origins cannot be frozen without selecting physical storage or
  transaction mechanics;
- the six sibling derivations would repurpose a current v1 identity/digest;
- a complete acyclic graph cannot be proven;
- concrete route grammar would require a second recovery owner;
- causal branch evidence requires copying the reducer rather than using the
  existing shared C2 helper;
- source, migration, export, or existing test changes are required.

Restore the exact opening V2 candidate under a blocking result.

# Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V3_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

# Required non-actions

State:

```text
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
