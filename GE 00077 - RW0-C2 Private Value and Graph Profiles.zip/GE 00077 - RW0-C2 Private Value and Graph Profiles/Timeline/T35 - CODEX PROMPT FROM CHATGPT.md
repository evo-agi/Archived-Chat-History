# Governed Execution Coordinator — RW0-C2 Private Value Contract V8 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and receipt-graph-profile
V8 candidate.

This audit follows a two-file repair intended to close the V7 audit findings:

1. recovery posture positivity was tied to one fixed fixture instead of generic
   validated current-posture semantics;
2. well-formed nonpositive posture raised instead of producing the normal
   `unresolved` recovery result;
3. projector and direct tests could be changed together to reintroduce a caller
   classification override;
4. structural-consequence helpers could be replaced by constant success when
   their direct tests were edited with them;
5. reversed contrastive clauses lost their protected subject and survived;
6. neutral-subject exclusions were not challenged with protected action
   phrases;
7. the exact owner-assertion inventory needed a versioned profile and an
   explicit independent-audit authentication boundary.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort;
- parent filesystem/permission posture, when visible.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
audit packages, Downloads artifacts, Project artifacts, or generated manifests.
The V8 closeout is evidence only; independently reproduce every material claim
from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V8 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 207,042 | `3e1e8b8d3538f855029fa51a729d62d2df82f05eccda76d33c70828324e4581f` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 324,792 | `d59d3bdfe05d5482ad233150810c7cdd34536634dd370dd208485fc3281bff7e` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `547,910`
- SHA-256:
  `79e8c62ec8d96066cdca4d856b5be3706df720a75693d0096d95d0bae77f7225`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `669c6c1574e754271bfc958eebacb1eb47541c498254d076e63924ef0bf9c4fb`

Use two structurally independent serializers and require byte-identical output.

## V7-to-V8 transition evidence

The V8 closeout reports that only these two paths changed from the independently
blocked V7 candidate:

| Path | V7 bytes / SHA-256 | V8 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `202,206` / `3913b1e13264400e942ba092fe0f2bd3c5397b73e82aea38b998b4c87d00073a` | `207,042` / `3e1e8b8d3538f855029fa51a729d62d2df82f05eccda76d33c70828324e4581f` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `294,909` / `5e72ac38c544a64df1e0980095ba95bc5052f5c434b277a7141bb850b9000975` | `324,792` / `d59d3bdfe05d5482ad233150810c7cdd34536634dd370dd208485fc3281bff7e` |

Reported per-file fixed-label unified diffs:

- private contract:
  - bytes: `9,288`
  - SHA-256:
    `50b94c33471cd6607340f0513773d6ae9d0830cdb404e645fb016fca0213a4b9`
- private verifier:
  - bytes: `54,733`
  - SHA-256:
    `e7e7136eb22f10522f644d6a6f4985f28921abb2f74ee249276a5fae9e775c73`

Reported concatenated two-file fixed-label diff:

- bytes: `64,021`
- SHA-256:
  `3d0d0cba710394e05a8532a528ac677086b27cd6f7b516eaae6756f4106e9597`

The other four candidate documents have the same receipts in V7 and V8.

The live V8 bytes are the primary audit target. Do not request historical V7
files. If V7 bytes are absent from the live checkout, classify the exact
two-file transition as corroborating history rather than blocking live
provenance.

## Prior V7 audit findings

The V7 audit established exact provenance and blocked because:

- otherwise valid alternate positive posture refs/digests were compared to one
  fixed vector and misclassified;
- well-formed nonpositive posture raised before normal projection could return
  `unresolved`;
- caller classification override could be reintroduced with its direct test;
- structural-consequence helpers could be replaced by constant success with
  their direct tests changed;
- reversed contrastive clauses lost the protected subject;
- neutral-subject exclusions were not strongly exercised;
- coordinated owner-pointer, owner-consequence, and private-vocabulary changes
  remained outside the mutable files’ self-authentication ability.

Audit the V8 repair rather than assuming those findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Subagents must not import modules from the live checkout. If their read-only
posture or model availability cannot be guaranteed, continue parent-only and
record the limitation. Explorer unavailability is not itself a candidate
defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, lifecycle-partition, branch-profile, static
graph-profile, transient observation/query/posture values, private vocabulary,
and bounded structural-consequence semantics. It remains subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, fresh continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, exact replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive fresh continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one generic v1 receipt root, one replay owner, and one
   whole-family recovery owner;
10. the decision writer cannot provision, repair, renew, or replenish
    admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` remains compatibility/nonproof only;
13. the static receipt profile is verification metadata selected through the
    guarded result, not a graph member or durable row;
14. fresh write, exact replay, and uncertain recovery are distinct lifecycle
    contracts;
15. private vocabulary and owner-assertion profile changes require successor
    profiles and fresh independent audit.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- only the private-value contract and its verifier differ from their V7 endpoint
  receipts;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, exports, StateStore, readers, writers, transactions,
  public/runtime surfaces, configuration, and examples remain unchanged;
- migration `0005` remains absent;
- no accepted architecture changed outside current-posture validation,
  classification dataflow, owner-profile versioning, structural-consequence
  integration, and bounded clause segmentation.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — validated current recovery posture grammar

Independently locate every representation of
`validated_current_recovery_posture_v1`.

Require one exact transient private grammar with these semantic fields:

1. `lineage_ref`
2. `scope_ref`
3. `current_continuity_posture_ref`
4. `current_continuity_posture_digest`
5. `continuity_state`
6. `current_sole_active_posture_ref`
7. `current_sole_active_posture_digest`
8. `sole_active_state`

A uniform `schema_id` may precede them only if the private contract uses that
convention consistently. Report the exact live grammar.

Require exact built-in strings, nonempty refs, lowercase 64-character hex
digests, and exact lineage/scope binding.

Require exact `continuity_state` enum:

- `positively_established`
- `missing`
- `stale`
- `unknown`
- `conflicting`
- `negative`

Require exact `sole_active_state` enum:

- `exactly_one_active_authority`
- `missing`
- `stale`
- `unknown`
- `conflicting`
- `not_exactly_one`

The value is positive if and only if:

```text
continuity_state == "positively_established"
and
sole_active_state == "exactly_one_active_authority"
```

Positivity must not compare refs/digests or object identity to one fixture.

Historical retained basis values must not instantiate this current-posture
value.

## Audit question 3 — alternate valid positive posture

Independently build at least three semantically valid positive posture values
for the same lineage/scope with distinct valid refs/digests.

Require identical classification for identical observation sets while each
result preserves its own posture coordinates.

Test:

- exact complete family → `committed_exact`;
- eight proved absences → `definitely_not_committed`;
- competing complete scope winner → original-command
  `definitely_not_committed`, without fresh eligibility;
- partial/mixed evidence → `unresolved`.

Any equality to a fixed posture fixture, fixed digest vector, or object identity
is blocking.

Also build positive posture for a different lineage/scope and require binding
failure against the canonical command/selector.

## Audit question 4 — well-formed nonpositive posture

For every nonpositive state combination, including each individual state and
representative cross-products, require the normal projector to return a valid
recovery result classified `unresolved`.

It must not raise merely because current posture is:

- missing;
- stale;
- unknown;
- conflicting;
- negative;
- not exactly one active authority.

Malformed field types/digests, empty refs, lineage mismatch, or scope mismatch
may fail value validation before projection.

Require the unresolved result to preserve the validated posture coordinates and
canonical lineage/scope.

Historical basis cannot be substituted for current posture.

## Audit question 5 — closed projector signature

Independently inspect and invoke the actual result projector.

Require its externally callable signature to contain only:

- validated observation set;
- canonical selector/command binding;
- validated current posture.

Reject:

- `classification`;
- `expected_classification`;
- `result`;
- arbitrary input mappings;
- `*args`;
- `**kwargs`;
- unknown keys;
- defaults that inject classification or posture.

The projector must call the actual classifier and write that returned value
directly into the result.

Patch the actual classifier reference to return each valid classification and
require the projector output to follow it while lineage/scope/posture
coordinates remain unchanged.

A reachable classifier call whose return is discarded must fail.

An inconsistent classification supplied through any side channel must be
impossible or rejected.

## Audit question 6 — recovery-result preservation

Re-verify the one V7 result grammar:

1. `classification`
2. `lineage_ref`
3. `scope_ref`
4. `current_continuity_posture_ref`
5. `current_continuity_posture_digest`
6. `current_sole_active_posture_ref`
7. `current_sole_active_posture_digest`

The two state fields belong only to the validated posture input, not the result
payload.

Require complete agreement among logical inventory, machine schema, human
table, vocabulary profile, builder, projector, and fixed tests.

No old composite posture fields, `observed_family_digest`, `reason`, result
self-digest, or second result version may reappear.

## Audit question 7 — owner-assertion profile provenance

Independently reconstruct the exact ordered thirteen-clause / thirty-seven-
assertion profile from the live candidate.

Require:

- profile ID:
  `rw0-c2-private-owner-assertions-v1`
- domain:
  `governed-execution.nwp-rw0-c2-private-owner-assertions.v1`
- canonical compact sorted-key JSON profile preimage:
  - bytes: `7,357`
- digest:
  `93b76bb45f90e44c999366462adc466db21970bdfbeae51246cba616ba19edb0`
- domain framing:
  UTF-8 domain, one NUL byte, then exact canonical profile JSON.

Reconstruct the first-clause fixed vector:

- canonical bytes: `492`
- SHA-256:
  `a1b7dc2ec2c5576f68d47a6da3046513410d8f95cc277bbb51920d1942e14d7a`

Inspect the contract to determine whether that vector hash is over the raw
clause JSON or another explicitly declared framing. Ambiguity is blocking.

Verify exact clause order, owner paths, markers, assertions, comparisons,
expected values, and structural consequence IDs against the authorized V7
inventory.

The profile is private-owned versioned contract metadata, not durable authority
or current runtime state.

## Audit question 8 — owner assertions and pointer purpose

For all thirty-seven assertions, verify:

- exact unchanged owner document;
- exact machine marker;
- exact JSON pointer;
- enclosing object;
- terminal key;
- comparison kind;
- exact built-in expected value;
- semantic relevance to the clause;
- allowed structural consequence IDs.

Resolve every assertion directly against the unchanged guard/decision owner
machine block.

A pointer to an unrelated true/false/string/list value is invalid even if its
comparison passes.

Externally test one-sided pointer substitutions to:

- unrelated false;
- unrelated true;
- same-typed string;
- another list containing the same member;
- another owner machine block.

Each must fail fixed pointer-purpose or profile-digest checks.

### Independent-audit boundary

Also construct coordinated copies that update the private profile, digest,
contract, and verifier together to use an unrelated same-valued pointer.

The private suite may remain green by acknowledged design. The audit must detect
the exact mismatch against this prompt's authorized profile and report that
detection. Do not incorrectly require mutable tests to self-authenticate the
coordinated copy.

## Audit question 9 — structural consequences

Independently execute all thirteen structural consequences against live private
machine/value/graph structures.

Require each consequence to inspect actual structure and not merely return
success or compare prose.

For every consequence:

1. identify one actual hostile private-structure mutation that violates it;
2. run the full clause validation path:
   unchanged owner assertions + consequence + tagged prose;
3. require failure.

Replace each helper with constant true while retaining those integrated hostile
structures. Every transformed copy must fail through the integrated tests or
AST/dispatch guards.

Changing only a helper's direct unit test must not make the integrated hostile
structures pass.

### Independent-audit boundary

A coordinated edit to helper, integrated hostile fixtures, profile, and verifier
may not be internally self-authenticating. The audit owns exact confirmation of
the V8 consequence inventory and behavior.

## Audit question 10 — clause segmentation and per-action polarity

Inspect the visible-text parser.

Require segmentation at:

- sentence boundaries;
- semicolons;
- `but`;
- `however`;
- `although`;
- `yet`;
- `while`;
- the explicitly supported negative `and` form;
- comma clauses beginning with a recognized modal, if the live V8 parser claims
  that support.

Every protected action/object segment must receive its own polarity.

A prohibition on timestamp creation cannot negate permission to create an
acceptance fact. A prohibition on fact creation cannot negate permission to
create a second receipt.

Require rejection of both orders:

```text
Replay may create a new acceptance fact but no new timestamp.
Replay may not create a new timestamp but may create a new acceptance fact.
```

Repeat both orders with semicolon, `however`, `although`, `yet`, and `while`.

## Audit question 11 — contrastive subject propagation

Within one original sentence or visible block, carry the most recent exact
protected subject into an immediately following contrastive segment when that
segment:

- contains no explicit protected or neutral subject; and
- begins with, or immediately reaches, a recognized modal or protected action.

Subject propagation must not cross:

- headings;
- paragraphs;
- different list items;
- different table rows;
- unrelated intervening sentences.

Require the inherited subject for reversed contrastive clauses across:

- paragraph text;
- heading;
- bullet/continuation;
- table cell;
- blockquote;
- link label.

## Audit question 12 — strong neutral-subject controls

Independently test these exact or semantically equivalent sentences:

```text
The replay glossary may quote the phrase "create a new acceptance fact".
The replay diagram may display a node labelled "create a second receipt".
This receipt documentation can show the example text "refresh a timestamp".
Timestamp terminology might include the words "prove noncommit".
The replay example may discuss why software must not create an acceptance fact.
```

All must pass.

Remove each neutral-subject exclusion one at a time. At least one strong neutral
control must then fail, proving the exclusion is exercised.

Neutral subject recognition must use exact noun-phrase classification rather
than a broad substring bypass that could hide true protected replay statements.

## Audit question 13 — private vocabulary and audit boundary

Independently confirm the exact V8 private vocabulary:

- profile ID:
  `rw0-c2-private-value-contract-v1`
- lifecycle IDs:
  - `fresh_write_construction_v1`
  - `exact_replay_readback_v1`
  - `uncertain_commit_recovery_v1`
- recovery status enum:
  - `unchecked`
  - `exact_complete_family`
  - `absent`
  - `partial`
  - `duplicate`
  - `foreign`
  - `malformed`
  - `unreadable`
  - `route_identity_conflict`
  - `competing_complete_scope_winner`
- seven recovery-result semantic fields;
- validated current-posture state enums from question 2.

Verify every consumer carries the exact profile/version.

Repository tests must reject one-sided drift.

Coordinated edits to both mutable private files are authenticated by this fresh
independent audit, not by a claim of internal self-authentication. State this
boundary accurately.

## Audit question 14 — preserved V7/V6 surfaces

Independently re-verify no regression in:

- 86-node lifecycle registry and exact memberships;
- five branch fresh-write DAGs;
- replay and recovery graphs;
- validated admission/current posture branch ancestor;
- ten-status typed route observations;
- all 26 guarded-relation fields;
- canonical command digest and selector/family binding;
- source-exact current-v1 graph mapping;
- actual C2 returned-branch causality;
- canonical current-v1 five-branch families;
- target supplemental-member binding;
- static profile and complete role inventory;
- exact replay and recovery semantics;
- one logical result/receipt/replay/recovery owner;
- current v1 and B1 meanings;
- target-only nonimplementation boundary.

Block any regression.

## Audit question 15 — test independence and shadow-owner risk

Inspect the reported 854-node verifier.

Require independent authorship among:

- generic posture state rules;
- alternate positive posture vectors;
- projector signature metadata;
- classifier-return dataflow expectations;
- owner-profile fixed coordinates;
- owner pointer-purpose expectations;
- structural consequence functions;
- integrated hostile structures;
- clause parser subjects/modals/actions;
- strong neutral controls;
- preserved lifecycle/relation/family expectations;
- current-source-derived v1 facts;
- internal hostile expectations;
- external transformed copies.

Reject:

- posture positivity by fixed-object equality;
- projector signature expected from itself;
- classifier and expected result generated by one helper;
- owner profile generated from candidate rows and accepted without fixed audit
  coordinates;
- structural helper and every hostile fixture sharing one success table;
- parser vocabulary extracted from prose under test;
- broad source-manifest freezing;
- hash-only correctness;
- a second reducer, replay/recovery engine, or physical schema emulator.

Require recursive duplicate-key rejection and exact built-in type comparison,
including bool/int separation.

## Audit question 16 — implementation-reported transformed copies

Independently reproduce every category from the V8 repair prompt and reconcile
the closeout's count of **68 external copies**:

- 36 source/profile hostile copies;
- 25 hostile prose copies;
- 7 strong neutral prose copies.

Require an exact manifest in the inline report mapping each transformed copy to:

- transformation;
- final expected 854-node collection;
- intended boundary;
- actual failing node/boundary or positive result;
- confirmation that failure was not syntax/import/format/collection shrinkage.

At minimum cover:

### Posture and classification

- fixed-vector positivity;
- alternate positive posture rejected;
- every nonpositive state handled as exception or positive;
- historical basis used as current posture;
- lineage/scope mismatch;
- malformed refs/digests/types;
- classification argument;
- classification mapping input;
- discarded classifier return;
- post-call override;
- unknown keyword.

### Structural consequences and owner profile

- all thirteen consequence helpers changed to constant true against integrated
  hostile structures;
- one-sided clause/consequence/pointer/profile drift;
- owner profile ID/digest mismatch;
- helper dispatch mismatch;
- missing integrated hostile control.

### Contrastive parser

- both mixed-clause orders;
- all required connectors in both orders;
- fact/receipt and fact/timestamp combinations;
- immediate pronoun;
- visible Markdown forms;
- untagged authority statement.

### Neutral positives

- glossary;
- diagram;
- documentation;
- terminology;
- replay example;
- any two additional neutral controls reported by the implementation.

## Audit question 17 — additional coupled mutants

In addition to the reported categories, test at least:

1. posture state enums, positivity predicate, and tests changed together to use a
   fixed vector;
2. alternate positive vectors and projector expectations changed together;
3. projector signature metadata, implementation, and direct tests changed
   together to reintroduce classification override;
4. classifier and result expectation changed together to trust supplied
   classification;
5. owner profile rows, profile digest/vector, contract, and verifier changed
   together to an unrelated same-valued pointer;
6. one structural consequence, all its integrated hostile structures, and its
   direct tests changed together to constant success;
7. parser segmentation, subject propagation, and hostile prose changed together
   so reversed permission survives;
8. strong neutral controls removed while neutral exclusions are removed;
9. private vocabulary profile and every consumer changed together;
10. recovery result fields and vocabulary changed together;
11. posture coordinates from another lineage with otherwise positive states;
12. positive posture with valid types but stale evidence metadata if the
    validated posture grammar carries freshness coordinates;
13. nonpositive posture returns unresolved but loses its input posture
    coordinates in the result;
14. projector returns correct classification but swaps continuity and
    sole-active posture pairs;
15. mixed protected actions appear in quoted Markdown or link labels;
16. neutral noun phrase followed by a separate protected subject later in the
    same block.

For coordinated private-owned profile changes, the independent audit—not the
private suite—must detect exact mismatch against this prompt. Distinguish that
expected audit behavior from a candidate test defect.

## Audit question 18 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `854 collected; 854 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Expanded B1/C2B2 coverage | `926 collected; 926 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Deterministic broad group | `4,857 collected; 4,857 passed` |
| Full repository | `8,671 collected; 8,671 passed, 3 warnings` |

The deterministic broad group must be generated exactly by:

1. expanding:
   - `tests/test_rw0_*.py`
   - `tests/test_c2b*.py`
   - `tests/test_sqlite_c2b*.py`
   - `tests/test_sqlite_rw0*.py`
2. resolving repository-relative paths;
3. sorting and deduplicating;
4. requiring exactly `48` files;
5. hashing the newline-joined paths without final newline to:
   `0c57aa37134d814b5e1dc3efb22cbe440c8c1bb6a12b8dc1b4223fb47e9893c0`;
6. passing that exact path list once to pytest.

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

Investigate every count, warning, path-inventory, or collection mismatch.

## Audit question 19 — live cache and cleanup

Before executable work, record a safe opening member-level inventory of ignored
cache paths, types, modes, sizes, mtimes, and hashes without importing live
repository modules.

The V8 closeout reports exact opening/closing equality across 37 members. Do not
impose an invented aggregate unless you define and reproduce the same grammar.

After all external work and cleanup, require exact member-level equality.

Any audit-created live cache member or modification is a provenance failure.

Remove every audit-created clone, basetemp, transformed copy, script, receipt,
and log.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- posture positivity tied to fixture identity rather than state semantics;
- valid alternate positive posture misclassified;
- well-formed nonpositive posture raising instead of returning unresolved;
- caller classification override;
- classifier return discarded or overridden;
- recovery-result field mismatch or wrong posture binding;
- owner profile mismatch against the exact V8 authorized inventory;
- owner pointer resolving unrelated semantics;
- structural consequence bypass through integrated hostile structures;
- reversed mixed clause surviving;
- neutral explanatory prose falsely rejected;
- neutral-subject exclusion unexercised;
- private vocabulary/profile inconsistency;
- regression in lifecycle, observation, relation, command, source-v1,
  C2-return, family, profile, role, replay, or recovery work;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- any mandatory transformed mutant surviving;
- unexplained collection, test-count, warning, path-inventory, or cache
  mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning/permission posture;
3. exact baseline and V8 six-path provenance;
4. patch, receipt, and transition-evidence reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. validated-current-posture grammar audit;
8. alternate positive and nonpositive posture audit;
9. projector signature and classifier-dataflow audit;
10. recovery-result preservation audit;
11. owner-assertion profile provenance audit;
12. owner pointer-purpose audit;
13. structural-consequence integration audit;
14. contrastive segmentation and per-action polarity audit;
15. subject propagation audit;
16. strong neutral-subject control audit;
17. private vocabulary/audit-boundary analysis;
18. preserved V7/V6 lifecycle/family/nonimplementation audit;
19. test-independence and shadow-owner audit;
20. implementation-reported transformed-copy results;
21. additional coupled-mutant results;
22. independent validation;
23. live-cache and final provenance;
24. severity-ranked findings;
25. exact next boundary;
26. required non-actions;
27. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED_BY_AUDIT
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
