## Disposition

**Accept the block. The repository is still at the exact V3 candidate, and the blocked V4 prompt is superseded.**

Codex stopped for the right reason. The problem is not the bounded-hybrid architecture or the two-file ceiling. The problem is that my V4 prompt imposed a representation that the unchanged v1 receipt graph does not support.

The prior audit correctly established that the V3 dependency graph was incomplete or cyclic around `receipt_graph_profile`, while also identifying missing timestamp edges and four other causal/test gaps. :chatgpt-content-reference{index="0"} But the attempted repair went too far: it required a profile ref/digest to become part of the generic receipt graph without adding a graph role or changing v1 receipt semantics.

Codex restored the exact opening V3 bytes, so:

- no V4 candidate exists;
- no new audit target exists;
- the V3 six-path patch and receipt remain authoritative for the next repair;
- no rollback, cleanup, or provenance reconstruction is needed.

## Correct architectural repair

The private receipt profile should **govern verification of the graph**, not become another member of it.

Current v1 source computes the graph identity from the unchanged receipt fields and graph entries:

```text
src/ge_nwp_coordinator/_development_decision_row_values.py:952-975
```

That preimage includes `committed_at` and every graph entry’s role, ordinal, ref, and digest. It deliberately excludes `mutation_graph_digest` itself. There is no profile field or profile entry in that v1 identity.

The correct target model is therefore:

```text
static versioned receipt profile
        ↓ selects/verifies
guarded progression-result member
        ↓ existing graph entry
unchanged v1 receipt fields + exact graph entries
        ↓
mutation_graph_digest
        ↓
final unchanged v1 receipt row
```

### Profile status

`receipt_graph_profile` remains one of the eleven logical contract surfaces, but only as a **static versioned verification profile**:

- it has a fixed profile/schema ID and branch-specific role grammar;
- it is not a durable row;
- it is not a graph entry;
- it has no per-family ref or self-digest;
- it is not a second receipt, replay owner, or recovery owner.

A successor profile requires a new profile ID/version. It must not reinterpret receipts already governed by the old profile.

### Binding the selected profile

The profile should be bound transitively through an existing common member: the guarded progression result.

That result carries—or is amended to carry—the exact receipt-profile ID and the authoritative branch. Its own digest is already included through the existing `guarded_progression_result` graph role. Therefore the unchanged generic graph cryptographically commits to the selected profile without adding an eleventh common role.

Verification then requires all of:

1. Reconstruct the unchanged v1 graph digest.
2. Load and validate every referenced member.
3. Validate the guarded result’s profile ID and branch.
4. Compare the actual roles, ordinals, refs, digests, and cardinalities against the static profile.

The supplied graph digest alone remains insufficient proof of completeness.

### Source-exact receipt direction

The dependency graph should distinguish the receipt’s preimage from the final row:

```text
branch
→ one transaction timestamp
→ decision/version/historical-head values
→ optional acceptance fact
→ guarded relation and guarded result
→ exact ten common graph entries
  (+ acceptance_fact only on acceptance)
→ generic receipt preimage fields excluding mutation_graph_digest
→ mutation_graph_digest
→ final generic v1 receipt row
→ replay/recovery projections
```

No profile graph entry, profile digest, additional generic receipt field, or invented receipt self-digest is allowed.

This also closes the prior timestamp finding correctly: the single post-branch transaction timestamp feeds `decided_at`, `created_at`, `updated_at`, and receipt `committed_at`; because `committed_at` is in `_receipt_graph_identity`, every branch’s graph digest has a real timestamp dependency. The V3 audit found that these required v1 timestamp edges were absent from the declared dependency graph. :chatgpt-content-reference{index="1"}

## Other findings remain open

Because Codex stopped before editing, none of the other V3 audit findings has been repaired:

- The four continuity/sole-active source coordinates are still missing from the closed command relation.
- Admission is still not causally proven before the shared C2 interpreter runs.
- Route templates, concrete route builders, and expectations remain insufficiently independent.
- The acceptance fact is still not fully bound to independent scope/head/family values.
- The receipt-role test still does not reconstruct all ten common roles.
- The prose scanner still permits contradictory headings, bullets, table rows, modal paraphrases, split assertions, and subject aliases.

The audit demonstrated that coordinated admission changes, a copied branch result, foreign acceptance-fact scope, Boolean head revision, and several prose contradictions survived the 310-test verifier. :chatgpt-content-reference{index="2"}

The next boundary therefore remains a **two-file repair**:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

No guard-owner, decision-owner, B1, operating-model, source, migration, or existing-test change is presently warranted.

## Revised Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as the sole writer, and use the exact restored V3 candidate as the opening state.

:chatgpt-content-reference{index="5"}[Download the revised V4 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_Revised_V4_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_Revised_V4_Repair_Prompt.txt

Size:
34,207 bytes

SHA-256:
f500538455cc75b0a641b17ef3703366cbb5a80cdaa6392b5c3fafee59277fd5

Logical lines:
966

Final newline:
present
```

The revised prompt explicitly supersedes the blocked V4 prompt and requires:

- no profile role or profile digest in the generic v1 graph;
- profile selection through the existing guarded-result member;
- source-exact `_receipt_graph_identity` semantics;
- no invented receipt self-digest;
- complete post-branch timestamp dependencies;
- the four missing command-relation fields;
- admission validation before the live shared C2 interpreter;
- sentinel proof that the shared interpreter causally controls family formation;
- independently fixed route-template and concrete-route expectations;
- full acceptance-fact scope/head/type binding;
- reconstruction of the complete common receipt-role family;
- bounded tagged normative clauses across headings, paragraphs, bullets, tables, and blockquotes;
- transformed challenges specifically rejecting attempts to add a profile graph member or alter v1 receipt semantics.

Success token remains:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT
```

Blocking token remains:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V4_REPAIR_BLOCKED
```

A successful repair will authorize only another fresh independent read-only audit.

**Sources:** Current V3 independent audit, especially its dependency-graph, causal-admission, route-independence, acceptance-family, and prose-scanner findings. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} Current committed snapshot source at `src/ge_nwp_coordinator/_development_decision_row_values.py:952-975`.

**Confidence:** High that Codex’s stop was correct; high that the profile-as-verification-metadata model is compatible with unchanged v1 graph semantics; medium-high that the two-file ceiling remains sufficient.
