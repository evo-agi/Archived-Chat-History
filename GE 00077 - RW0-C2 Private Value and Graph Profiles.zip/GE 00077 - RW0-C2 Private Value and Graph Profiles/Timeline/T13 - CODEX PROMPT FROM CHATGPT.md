# Governed Execution Coordinator — RW0-C2 Private Value Contract V3 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and graph-profile V3
candidate.

This audit follows a two-file repair intended to close five findings from the
V2 re-audit:

1. the command/preassignment identity graph was not proven acyclic;
2. route templates and concrete selector routes used conflicting grammars;
3. contradictory authority-sensitive prose could be added without detection;
4. nonaccept guarded-family relation fact fields lacked exact value rules;
5. admission binding and branch-neutrality evidence was self-consistent rather
   than causally bound to independent owners.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
report attachments, Downloads artifacts, Project artifacts, or generated
manifests. The implementation closeout is evidence only; independently
reproduce every material claim from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V3 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 116,817 | `7a599ef8c75dfff9644da114467691db6413336bd3433187200b4918bf50d4f0` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 113,001 | `d13c73d1aa5c20aeae90ccb5cc326f30668be22373728008d9f398ffb5a714d7` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `239,870`
- SHA-256:
  `02843af95268d6807d8fd851a10aebc89af5a3315fe7d7f5022b9040365b5240`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `45deffae290043c663ad53dc0f3686579018be638c3fb47644fff624508ffe93`

Use two independent serializers and require byte-identical output.

## Exact V2-to-V3 transition

Only these paths may have changed from the independently blocked V2 candidate:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

Reported transitions:

| Path | V2 bytes / SHA-256 | V3 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `41,459` / `db2d3298465f1958b0f5d3355abbfe4d32375d2c802934283b03c8bd0e145240` | `116,817` / `7a599ef8c75dfff9644da114467691db6413336bd3433187200b4918bf50d4f0` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `66,615` / `5b8155ab8a8730fcd716b6b7f5a716c8b2e25a0488d41700b2a28ecabf2f8a06` | `113,001` / `d13c73d1aa5c20aeae90ccb5cc326f30668be22373728008d9f398ffb5a714d7` |

The other four candidate documents must match both their supplied V2 receipts
and their final V3 receipts above.

Historical V2 bytes are corroborating transition evidence. The live V3 bytes
are the audit target.

## Prior blocking findings

The preceding V2 re-audit established exact provenance and blocked because:

1. the prospective acceptance-fact formula consumed preassigned identities and
   a family route whose origins were not frozen, so the complete identity graph
   could not be topologically proven;
2. prose described concrete route elements with `key`, while the machine field
   of the same name contained route templates with `key_sources`;
3. six contradictory authority-sensitive prose additions survived the complete
   verifier;
4. guarded-family relation fact ref/digest rules were underspecified on
   nonaccept branches;
5. admission and branch-neutrality tests used self-consistent supplied values
   rather than independent admission and the existing C2 interpreter.

Audit the repair rather than assuming those findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

If explorer creation is unavailable or rejected, continue parent-only and
record the limitation. Explorer failure is not by itself a candidate defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, branch-profile, graph-profile, query-value, and
bounded normative-clause semantics. It remains subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, current continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive current continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one receipt, one exact-replay owner, and one whole-family
   recovery owner;
10. local decision writer cannot provision or renew admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` fields remain compatibility/nonproof only.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- exactly the two specified files changed from V2 to V3;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, package exports, StateStore, readers, writers,
  transactions, public/runtime surfaces, configuration, and examples remain
  unchanged;
- no accepted architecture changed outside private identity, query-value,
  relation-value, and test-adequacy repair;
- migration `0005` remains absent.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — transcript status and current-versus-target truth

Inspect `guarded_family_preassignment_basis_v1`.

Require that it is:

- a private derivation transcript within the admitted-command relation;
- not a twelfth logical durable value;
- not public protocol;
- not durable authority;
- not current implemented source behavior;
- not a second command owner;
- not a physical schema or transaction contract.

Audit every primitive origin classification.

In particular, distinguish:

- current implemented values;
- accepted-target guard-owner values;
- externally verified evidence;
- caller expectations independently verified by the Coordinator;
- contract literals.

Block if lineage, scope, admission fact, guard profile, or applicability is
described as currently implemented when it is only accepted target, or if an
external evidence coordinate is promoted to local durable authority.

## Audit question 3 — exact primitive transcript

Independently derive the exact 24-coordinate transcript from the owning
contracts.

Require:

- exact field inventory and order;
- exact built-in type for every field;
- `expected_head_revision` is nonnegative `int`, never `bool`;
- digest fields are lowercase 64-character hexadecimal strings;
- other identity/profile/applicability coordinates are exact nonempty strings;
- every command-covered branch-neutral primitive required by the guard and
  decision owners is present;
- no sibling-derived, branch, result, receipt, timestamp, terminal, or
  postcommit value appears;
- no primitive is duplicated under another name;
- no omitted coordinate can change admission, currentness, decision basis, head
  expectation, or family routing without changing the transcript.

Mutate each primitive independently and verify the intended sibling and command
digest effects.

## Audit question 4 — six sibling derivations

Independently reconstruct the six sibling identities:

1. preassigned decision ref;
2. preassigned resulting-version ref;
3. preassigned guarded-family-relation ref;
4. preassigned guarded-progression-result ref;
5. deterministic family route;
6. prospective acceptance-fact ref.

For each require:

- exact distinct domain separator;
- exact domain UTF-8 plus NUL framing;
- exact compact ordered name/value JSON;
- exact output grammar;
- exact fixed vector;
- dependencies limited to the primitive transcript;
- no dependency on another sibling;
- no dependency on command digest or post-branch data.

Independently recompute all six supplied vectors.

Reject:

- duplicate domains;
- omitted NUL separator;
- sorted-map encoding replacing the frozen ordered representation;
- uppercase digest output;
- bool accepted for integer fields;
- branch/result/receipt/timestamp/terminal influence;
- sibling-to-sibling derivation.

## Audit question 5 — expanded 66-node dependency registry

Independently reconstruct the complete identity/digest graph from the machine
contract and prose.

Require every node to have exactly:

- node ID;
- stage;
- closed origin class;
- exact dependencies;
- exact prohibited dependencies.

Independently verify:

- exact node count;
- no duplicate or omitted node;
- every dependency names a known node;
- every dependency stage is strictly earlier;
- every required edge exists;
- no undeclared edge exists;
- no broad aggregate node hides a backedge;
- acceptance-only nodes are conditional without weakening graph completeness;
- all six sibling nodes are peers;
- command digest follows every sibling;
- branch follows command validation;
- decision/version/head/result/fact content and self-digests follow branch;
- relation and guarded result follow exact branch members;
- the single generic receipt graph/value/digest follows all required members;
- replay/recovery projections are last.

Perform an independent topological sort. Do not credit the candidate’s order
list as proof.

Required cycle/graph mutants include:

- command digest feeding any sibling;
- any sibling feeding another sibling;
- family route depending on command digest;
- decision or version ref depending on command digest;
- relation/result ref depending on eventual content digest;
- prospective fact ref depending on branch;
- postcommit timestamp entering the transcript;
- omitted node;
- omitted edge;
- stage inversion;
- aggregate digest hiding a backedge;
- unknown origin class.

## Audit question 6 — command digest and branch neutrality

Verify the command digest is derived only after the transcript and all six
siblings.

Require it to cover the exact branch-neutral command expectations fixed by the
guard and decision owners, including all six siblings, while excluding branch,
result, receipt graph, timestamp, terminal outcome, and raw external
attestations.

Audit the private verifier’s use of the existing C2 document-driven
interpreter/helper.

Require:

- no copied branch table or precedence;
- the prospective fact coordinate is absent from C2 branch inputs;
- all five branches are derived by the existing C2 interpreter;
- varying the prospective coordinate cannot alter the branch;
- null and wrong coordinates fail command-value validation separately;
- the correct coordinate permits the already-derived branch;
- acceptance then materializes one fact;
- every nonaccept branch materializes none while retaining collision coverage.

Externally replace the shared C2 helper with a private branch table and require
exact failure.

## Audit question 7 — independent admission binding

Inspect the fixed verified admission act and immutable admission-fact fixture.

Require:

- the fixture is authored independently from command expectations;
- exact lineage, scope, admission ref, admission digest, guard profile, and
  applicability binding;
- command relation validation occurs before family materialization;
- caller values are expected-coordinate assertions, not admission authority;
- the decision writer cannot create or repair admission;
- changing any admission dimension fails at an exact boundary;
- changing fixture and command together cannot bypass a third
  owner-derived invariant.

Block self-confirming fixture/expectation construction.

## Audit question 8 — route templates and concrete selector values

Verify two distinct structures:

### Route templates

`collision_route_templates` elements have exactly:

- `role`;
- `kind`;
- `key_sources`;
- `expected_schema_id`.

### Concrete routes

`complete-family-selector.required_collision_routes` elements have exactly:

- `role`;
- `kind`;
- `key`;
- `expected_schema_id`.

Require:

- exact eight-role inventory and order;
- exact closed role and kind enums;
- template count and concrete count both eight;
- each role exactly once;
- `key_sources` only in templates;
- `key` only in concrete routes;
- concrete key is an ordered array/tuple of exact strings;
- one-coordinate routes still use one-element keys;
- concrete key is instantiated exactly from selector top-level fields named by
  template `key_sources`;
- first six exact schema IDs and final two exact null schema IDs;
- every route remains present on all five branches;
- no extension route;
- no timestamp or postcommit dependency.

Independently mutate missing, duplicate, unknown, reordered, wrong-key-type,
wrong-order, copied-coordinate, wrong-schema, omitted acceptance, omitted
scope-winner, and extension routes.

## Audit question 9 — branch-specific relation fact fields

For `candidate_acceptance`, require:

- non-null exact `acceptance_fact_ref`;
- equality to the reserved prospective ref;
- non-null exact `acceptance_fact_digest`;
- equality to the verified immutable fact digest;
- one fact member;
- one receipt-graph role.

For each nonaccept branch, require:

- relation `acceptance_fact_ref` is exactly null;
- relation `acceptance_fact_digest` is exactly null;
- no fact member;
- no receipt-graph acceptance role;
- command and selector retain the prospective ref;
- acceptance collision route remains mandatory;
- null relation fields do not assert unclaimed scope;
- an occupied reserved identity is collision/unresolved evidence.

Mutate each field and membership independently.

## Audit question 10 — normative clause registry and contradiction scanner

Inspect the closed 13-clause registry and bounded prose scanner.

Require:

- exact registered subjects, modalities, predicates, objects, and qualifiers;
- every authority-sensitive normative statement outside code/machine blocks
  maps to exactly one registered clause;
- no registered clause is absent from normative prose;
- unknown authority-sensitive assertions fail;
- opposite modality and contradiction fail;
- duplicate contradictory clause fails;
- explanatory nonnormative prose remains allowed;
- headings, tables, and bullet lists cannot bypass the scanner;
- Markdown emphasis, punctuation, line wrapping, and common equivalent modal
  forms cannot bypass the exact six prior findings;
- scanner expectations are independent from the machine block and document
  content under test;
- the registry does not become a second guard or decision semantic owner.

Independently reproduce the six prior contradictory additions:

1. historical basis becomes current permission;
2. prospective coordinate forces or vetoes branch;
3. local absence proves noncommit without current posture;
4. replay creates a fact or timestamp;
5. command relation admits or selects scope;
6. nonaccept skips the acceptance collision route.

Also test bounded paraphrased variants, including:

- `may`, `must`, `is permitted to`, and `is sufficient to`;
- split assertions across a bullet and following sentence;
- double negation;
- contradictory table row;
- contradictory statement under a new explanatory heading;
- subject aliases already used by the document.

A surviving semantic contradiction is blocking.

## Audit question 11 — recovery and replay value semantics

Verify the selector/result rules still preserve:

- exact complete family;
- same mutation/different command conflict;
- all preassigned identity collisions;
- deterministic family-route collision;
- competing complete scope winner;
- total absence only with fresh positive current continuity and sole-active
  posture and exhaustive eight-route absence;
- missing, malformed, foreign, duplicate, unreadable, or unchecked route is
  unresolved;
- restore/clone without positive continuity is unresolved;
- replay returns original fact presence/absence and original timestamp;
- replay creates no fact, timestamp, result, receipt, or renewed scope;
- no repair, branch reevaluation, automatic retry, or replenishment.

The private contract must remain a value/query grammar, not a recovery engine.

## Audit question 12 — owner, v1, B1, and nonimplementation preservation

Verify no regression in:

- closed eleven-value inventory and authority matrix;
- guard/decision/operating-model hierarchy;
- current migration-0002 decision/version/head/result/receipt meanings;
- one logical result and receipt;
- one replay and recovery owner;
- B1 pair exact current grammar and non-consumption;
- no physical SQL/table/index/query/transaction selection;
- no migration `0005`;
- no source module, export, provisioner, writer, reader, caller, public API,
  runtime activation, RW0-D/E, or Execution Substrate behavior.

Block any accepted-target wording that reads as current implementation.

## Audit question 13 — test independence and scope

Inspect the 310-node verifier.

Require independent authorship among:

- normative prose;
- machine-readable contract block;
- fixed primitive transcript expectations;
- sibling-domain and fixed-vector expectations;
- complete dependency-registry expectations;
- route-template expectations;
- concrete-route expectations;
- admission fixture and owner-derived relation;
- current-source-derived v1 facts;
- internal hostile expectations;
- external transformed copies.

Reject:

- expectations generated from the machine block under test;
- observed graph reused as expected graph;
- route concrete values generated and validated by one helper without fixed
  comparison;
- admission fixture authoring its own expected relationship;
- prose scanner registry extracted from prose under test;
- hash-only protection;
- broad source-manifest freezing;
- a second reducer, replay engine, recovery engine, or physical schema emulator.

Require recursive duplicate-key rejection and exact built-in type comparison,
including bool/int separation.

## Audit question 14 — exact implementation-reported external mutants

Independently reproduce these 44 transformed copies:

### Identity DAG

1. decision ref derived from command digest;
2. version ref derived from command digest;
3. relation ref derived from guarded relation digest;
4. guarded-result ref derived from guarded result digest;
5. family route derived from command digest;
6. prospective fact ref derived from branch;
7. one sibling derived from another sibling;
8. command digest removed from downstream stage;
9. primitive basis omits one command-covered field;
10. postcommit timestamp added to primitive basis;
11. aggregate digest hides a backedge;
12. complete graph drops one node.

### Routes

13. machine puts route templates under concrete `required_collision_routes`;
14. concrete route uses `key_sources`;
15. template uses concrete `key`;
16. one mandatory route removed;
17. one route duplicated;
18. unknown route added;
19. routes reordered;
20. wrong key type or coordinate order;
21. one role copies another role’s coordinate;
22. wrong schema ID;
23. acceptance route omitted on nonaccept;
24. scope-winner route omitted;
25. implementation-specific extension route added;
26. timestamp or final-receipt dependency added.

### Relation and branch

27. nonaccept relation has non-null fact ref;
28. nonaccept relation has non-null fact digest;
29. acceptance relation has null fact ref/digest;
30. acceptance fact missing;
31. nonaccept fact present;
32. prospective coordinate forces acceptance;
33. prospective coordinate vetoes acceptance;
34. private verifier copies branch logic instead of shared C2 helper.

### Admission, prose, replay

35. command relation binds a foreign admission fact;
36. command relation changes scope;
37. historical basis becomes current permission;
38. local absence proves noncommit without current posture;
39. replay creates a fact;
40. replay refreshes timestamp;
41. command relation admits or selects scope;
42. nonaccept skips the acceptance collision route;
43. terminal replenishes acceptance;
44. ES routing replenishes acceptance.

Every mutant must:

- retain the exact expected 310-node contract collection;
- fail at the intended exact semantic boundary;
- avoid syntax/import/format/collection-shrinkage-only failure.

Report permanent internal controls separately from actual external transformed
copies.

## Audit question 15 — additional independent mutants

In addition to the exact 44, independently test at least:

1. duplicate sibling domain separator;
2. missing domain NUL separator;
3. uppercase sibling digest output;
4. `expected_head_revision=True`;
5. omitted primitive origin classification;
6. accepted-target guard value mislabeled current implementation;
7. transcript order changed while field set remains;
8. one dependency assigned the same stage as its consumer;
9. conditional acceptance node removed from graph;
10. concrete route key generated from the wrong selector field with the same
    type;
11. template and concrete route arrays mutated together;
12. admission fixture and command expectation mutated together;
13. clause registry and contradictory prose mutated together;
14. contradictory bullet/table/modal paraphrase;
15. shared C2 helper call removed while a copied result constant remains;
16. replay preserves family bytes but changes timestamp;
17. graph profile includes acceptance role on one nonaccept branch;
18. graph profile omits one required generic member on acceptance.

Each must fail at an exact identity, authority, route, relation, clause,
causality, replay, or completeness boundary.

## Audit question 16 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `310 collected; 310 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Broad RW0/C2B glob group | `4,313 collected; 4,313 passed` |
| Full repository | `8,127 collected; 8,127 passed, 3 warnings` |

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

Investigate every count, warning, or collection mismatch.

## Audit question 17 — live cache and cleanup

Before executable work, record a safe opening inventory of ignored cache paths,
types, modes, sizes, mtimes, and hashes without importing repository modules.

The implementation closeout reports 40 live ignored paths and an aggregate
manifest hash, but does not define a complete canonical inventory grammar in
the closeout. Treat member-level opening/closing equality as authoritative.

After all external work and cleanup, require exact member-level equality.

A mismatch between an independently chosen aggregate and the report-only
aggregate is not candidate drift when every member is identical. Any
audit-created live member or modified existing member is a provenance failure.

Remove every audit-created clone, basetemp, transformed copy, and log.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- derivation transcript becoming an unauthorized twelfth value or current
  implementation claim;
- primitive origin misclassification that widens authority;
- omitted command-covered primitive;
- duplicate domain or sibling dependency;
- incomplete or cyclic 66-node graph;
- command digest or branch feeding a sibling;
- copied branch reducer or branch influenced by prospective identity;
- self-confirming admission fixture;
- template/concrete route confusion;
- missing or non-exhaustive route;
- wrong branch-specific relation fact values;
- contradictory normative prose surviving;
- historical basis treated as current authority;
- total absence credited without current posture;
- replay creating a fact or timestamp;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- self-confirming tests;
- any mandatory mutant surviving;
- unexplained collection, test-count, or warning mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V3 six-path provenance;
4. patch, receipt, and V2-to-V3 transition reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. transcript status and current-versus-target audit;
8. primitive transcript and origin audit;
9. six sibling derivation and fixed-vector audit;
10. expanded 66-node DAG and topological audit;
11. command-digest and branch-neutrality audit;
12. independent admission-binding audit;
13. route-template and concrete-selector audit;
14. branch-specific relation-field audit;
15. normative-clause registry and contradiction-scanner audit;
16. replay/recovery value-semantic audit;
17. owner/v1/B1/nonimplementation preservation;
18. test-independence audit;
19. exact 44 mutant results;
20. additional independent mutant results;
21. independent validation;
22. live-cache and final provenance;
23. severity-ranked findings;
24. exact next boundary;
25. required non-actions;
26. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
