## Disposition

**Accept the V4 audit block. Do not stage or commit the candidate.**

The result is a correctness and test-adequacy block, not a provenance failure. The audit reproduced the exact six files, the `282,946`-byte patch, and the `1,381`-byte canonical receipt; source, migrations, readers, writers, exports, and runtime surfaces remain unchanged, and migration `0005` remains absent. :chatgpt-content-reference{index="0"}

The full repository still passes:

```text
8,244 passed, 3 expected warnings
```

But four of the required 63 transformed controls survived, and several stronger independent probes exposed related gaps. A green ordinary suite is therefore not sufficient for a commit gate. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

No architecture reset or product-policy decision is required. The selected private-value architecture remains viable; the verifier and exact dependency/value grammar still need one bounded repair.

## Engineering adjudication

### 1. The dependency graph is acyclic syntactically but incomplete semantically

The audit independently topologically sorted the declared 67-node graph, but found three missing semantic areas:

- `family_relation_value` omits dependencies on the authoritative branch and complete historical-head value even though those raw fields are in its canonical grammar.
- Acceptance-only nodes are listed as unconditional dependencies of relation and receipt-entry nodes, leaving the four nonaccept graphs undefined.
- `recovery_projection` has no dependency on actual route reads, observed family state, or fresh recovery-time posture. :chatgpt-content-reference{index="3"}

The repair should replace the single ambiguous graph with **five branch-expanded DAGs**. Each node needs explicit materialization and branch-specific dependencies. Acceptance-fact nodes exist only in the acceptance expansion; nonaccept graphs must not retain dangling edges to them.

Recovery also needs one explicit, transient observation basis:

```text
selector
+ fresh current continuity/sole-active posture
+ eight typed route observations
→ recovery projection
```

That observation basis is not a new durable value or recovery owner. It is the exact read-result grammar consumed by the existing C2 recovery owner.

### 2. The command digest must become a real canonical value used by every fixture

V4 has a test-only command-coverage witness, while downstream family fixtures use a fixed placeholder digest. Removing a primitive from the direct witness still passed because sibling hashes changed, and the placeholder remained disconnected from the family. :chatgpt-content-reference{index="4"}

The repair should freeze one canonical `guarded_command_digest_v1` derived from:

```text
closed command-relation fields
+ the 24 primitive coordinates
+ all six sibling preassignments
```

Every selector, relation, result, receipt, replay, and recovery fixture must use that recomputed digest. No positive path may retain `"cd"*32` or another arbitrary digest.

This also closes the selector defect. The selector’s lineage, scope, admission, identities, route, and command digest must equal the independently validated command. Changing selector lineage and its route key together must fail unless the underlying valid command is also independently reconstructed.

### 3. The private verifier must prove current v1 field mappings, not only field names

The audit changed current source so `committed_at` mapped to `None`; all 427 private tests still passed. An unrelated existing C2B2 test caught the change, but the private source-exact gate did not. :chatgpt-content-reference{index="5"}

The repair should pass unique sentinel values through the real current `_receipt_graph_identity` path and independently reconstruct the canonical bytes and digest. That test must detect:

- wrong source attribute mapping;
- wrong receipt-field value;
- wrong graph-entry field order or value;
- changed domain;
- inclusion of `mutation_graph_digest` in its own preimage;
- an invented receipt self-digest.

This remains test-only use of unchanged current source.

### 4. The shared C2 call occurs, but its return value does not causally control the family

Admission validation now precedes the shared interpreter, which is good. The remaining defect is dataflow: the sentinel raises before returning, while the truth table builds the fact from the test’s expected branch parameter rather than the interpreter’s returned branch. A reachable shared call whose result was discarded passed all 427 tests. Fresh posture is also defaulted to `True` rather than supplied explicitly. :chatgpt-content-reference{index="6"}

The repair should remove the expected branch from family formation. The only valid path is:

```text
validate admission and explicit fresh posture
→ invoke exact shared C2 interpreter
→ read returned branch
→ validate prospective identity
→ construct family from that returned branch
```

A wrapper should return a deliberately different valid branch; the resulting family must follow that wrapper-returned value. A copied branch with a reachable but ignored C2 call must fail.

Fresh continuity and sole-active posture should be mandatory test-path inputs with no default.

### 5. Selector routes need command and family anchors

The route grammar itself is closed and well formed, but the selector validator compares route keys only with the selector’s own top-level values. A jointly altered selector lineage and route key was accepted with arbitrary selector and command digests. :chatgpt-content-reference{index="7"}

The route checks must therefore be layered:

```text
command → selector top-level coordinates
selector top-level coordinates → concrete route keys
command/family identities → selector family coordinates
```

Internal selector consistency alone is insufficient.

### 6. Positive family tests must reconstruct real canonical members

The acceptance-fact checks reject several direct hostile substitutions, but their expected decision, version, head, relation, and result digests are placeholders rather than reconstructed canonical rows. The role family is then generated and checked from the same fixture. A joint common-role substitution survived while the exercised family stayed unchanged. :chatgpt-content-reference{index="8"}

The V5 verifier should construct actual current-v1 members from unchanged source:

```text
development decision
resulting program version
historical program-head postimage
generic v1 result projection
generic v1 receipt preimage and row
```

It should then independently construct target-only members:

```text
verified admission act
scope-admission fact
historical continuity basis
historical sole-active basis
guarded family relation
guarded result
optional acceptance fact
```

All graph roles must bind those actual values and digests. The ten common roles and acceptance-only role must be fixed independently from the machine profile and builders.

### 7. Private normative truth needs unchanged owner anchors

The V4 parser catches many exact forms, but contradictions using `might`, `replay adapter`, and cross-sentence wording survived. It also falsely rejected a neutral glossary sentence. More importantly, changing private tagged prose and private test literals together can pass while the machine tuple still says the opposite. :chatgpt-content-reference{index="9"}

The next repair should use the unchanged guard and decision documents as independent semantic anchors. Each private clause should bind:

```text
fixed test expectation
↔ unchanged owner anchor
↔ private machine tuple
↔ parsed tagged prose
```

The bounded parser should use exact subject aliases rather than substring matching, add the missing modal vocabulary, and maintain only immediate within-block subject context for constructions such as:

```text
Replay is authorized. It creates a new acceptance fact.
```

A neutral phrase such as `replay glossary` must not be treated as the protected subject `replay`.

## Repair boundary

The audit’s recommended boundary is correct:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents remain fixed, and no source, migration, owner-document, existing-test, or runtime change is justified. The audit ranks the unresolved dependency, C2-return causality, family/profile independence, and prose agreement findings High; source mapping and command/selector binding remain Medium. :chatgpt-content-reference{index="10"}

## Codex handoff

Resume the **same implementation Codex conversation**, use workspace-write if exposed, and keep the parent as the sole writer.

:chatgpt-content-reference{index="12"}[Download the complete V5 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V5_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V5_Repair_Prompt.txt

Size:
35,746 bytes

SHA-256:
a513fcbe3b5c50756b6fa51fae4cb1f25d38e40db981cbbf62c85e16ab248660

Logical lines:
1,034

Final newline:
present
```

The prompt binds the exact opening V4 candidate:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Ordered six-path patch:
282,946 bytes
9fa5fa6842d9ef85dbe82cd500c4e4e53986ebbb6c050c604dbcbf1cac5c50e8

Canonical receipt:
1,381 bytes
7a999cc5760ab60aba676e481d8cb538511df605fd27cc315271d2b9fc7ca839
```

It requires:

- five branch-expanded dependency DAGs;
- exact conditional acceptance-node materialization;
- explicit recovery route observations;
- one canonical command digest used throughout the family;
- command-to-selector-to-route binding;
- sentinel-based current v1 receipt reconstruction;
- actual C2 return-value causality and explicit fresh posture;
- canonical current-v1 decision/version/head/result/receipt construction;
- independently authored target supplemental members;
- fixed profile and complete role-family expectations;
- owner-anchored four-way normative agreement;
- at least 68 transformed external categories;
- focused, broad, and complete repository validation;
- exact preservation of the other four candidate files and every source,
  migration, export, public, and runtime surface.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V5_REPAIR_BLOCKED
```

A successful V5 result will authorize only another fresh independent read-only audit. It will not authorize staging, commit, migration `0005`, source-value implementation, admission provisioning, guarded persistence, readers, runtime recovery, terminal binding, public APIs, RW0-D/E, or Execution Substrate work.

**Source:** Fresh V4 independent audit attached in this turn. Its primary verdict is a correctness block with exact provenance, not a byte mismatch. :chatgpt-content-reference{index="11"}

**Confidence:** High on the audit block and two-file repair boundary. High on branch-expanded dependencies, canonical-family reconstruction, and actual C2-return causality as the necessary next repair. Medium-high on the bounded normative parser; owner anchoring is the critical addition that prevents another self-confirming private clause system.
