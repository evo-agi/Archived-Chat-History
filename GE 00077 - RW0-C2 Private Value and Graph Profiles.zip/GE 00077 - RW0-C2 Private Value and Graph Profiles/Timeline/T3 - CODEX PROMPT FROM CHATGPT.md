# Governed Execution Coordinator — RW0-C2 Private Value and Graph-Profile Contract Freeze

## Role and permission posture

Resume the same Codex conversation that completed the read-only physical/value
architecture reconnaissance.

Change the parent permission posture to workspace-write before sending this
turn.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

## Objective

Write and validate the **documentation-and-contract-test-only** freeze for the
private RW0-C2 value family and receipt-graph profile required by the merged
immutable bootstrap guard.

This tranche must freeze:

- private value ownership and authority boundaries;
- closed logical value/schema inventory;
- versioning and compatibility rules;
- exact identity/digest dependency DAG;
- command-digest coverage;
- acceptance versus nonaccept role/nullability rules;
- one versioned guarded result/family relation;
- one versioned receipt-graph profile rooted in the existing generic receipt;
- one complete-family recovery selector/result grammar;
- preservation of migration-0002 v1 meanings;
- non-consumption and non-authority of the B1 `latch_postimage_*` pair.

This tranche must **not** freeze or implement:

- SQL tables, columns, indexes, triggers, checksums, migration steps, or
  application-generation changes;
- migration `0005`;
- scope-admission provisioning transaction mechanics;
- continuity issuer, transport, transfer protocol, or currentness protocol;
- transaction order, reader layout, writer entry signatures, or collision
  queries;
- durable writer, provisioner, readers, recovery implementation, production
  caller, public API, runtime behavior, RW0-D/E, or Execution Substrate work.

Do not issue an implementation prompt for any later tranche.

Return one substantive inline implementation report. Do not create or attach a
manifest, package, freeze artifact, or external report. Temporary validation
material may exist only outside the repository and must be removed.

## Exact baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required baseline:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- clean tracked, untracked, staged, and unmerged posture
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_BLOCKED`

## Fixed architecture from the accepted merged contracts and reconnaissance

Treat the following as the architecture this tranche must express, not reopen.

1. Keep migration-0002 `development_decisions`,
   `development_program_versions`, `development_program_heads`, generic result
   projection, and `development_mutation_receipts` canonical within their
   current v1 meanings.
2. Use a bounded additive migration `0005` later for only the missing immutable
   admission, guarded-family, acceptance, selector-support, and uniqueness
   structures. This tranche does not design that migration.
3. Admission provisioning and guarded decision persistence are separate
   semantic owners.
4. A future provisioner alone records a verified immutable scope-admission fact.
   The decision writer may read that fact but may not create, repair, renew, or
   replenish admission.
5. A future guarded decision writer alone records the immutable
   bootstrap-acceptance fact, only on derived `candidate_acceptance`, inside the
   same atomic decision/version/head/result/receipt family.
6. There is one logical decision result, one receipt, one exact-replay owner,
   and one whole-family three-way recovery classifier. No separate guard
   receipt, replay path, or recovery classifier exists.
7. Four nonaccept branches contain no acceptance fact.
8. Positive lineage continuity and sole-active-authority posture remain
   external/current evidence composed with local writer fencing. Durable local
   rows, machine identity, database identity, process identity, locks, or local
   row absence cannot establish them.
9. The guarded decision writer must not consume B1
   `latch_postimage_ref` / `latch_postimage_digest`.
10. A later terminal consumer needs its own separately accepted safe-value
    compatibility/versioning contract.
11. Exact physical schema, query, reader, transaction, collision, and recovery
    mechanics remain later engineering contracts.

## Exact six-path mutation ceiling

Only these paths may change:

1. `.docs/rw0-c2-private-value-versioning.md` — new
2. `tests/test_rw0_c2_private_value_versioning_contract.py` — new
3. `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
4. `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
5. `.docs/rw0-b1-pure-phase-values.md`
6. `.docs/autonomous-software-development-operating-model.md`

No other path may change.

Do not modify:

- `AGENTS.md`;
- `README.md`;
- `.docs/architecture.md`;
- `.docs/c2b-durable-development-state.md`;
- source;
- migrations;
- package exports;
- existing tests;
- configuration or examples.

If coherent ownership or mandatory repository cross-reference tests require a
seventh path, stop and report the exact conflict. Do not widen the tranche.

## New contract owner

Create:

`.docs/rw0-c2-private-value-versioning.md`

It must declare itself the sole accepted-target owner for the private
RW0-C2 value/versioning and graph-profile seam described below.

It is subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, continuity,
  sole-active posture, one-shot eligibility, permanence, terminal/ES
  boundaries;
- the durable-decision owner for reduction, branches, decision/version/head,
  result/receipt, replay, collision taxonomy, and whole-family recovery;
- current source and migrations for implemented v1 bytes and physical storage;
- the operating model for composition and current-status classification.

It must not become:

- a second reducer;
- a physical schema owner;
- a provisioner or writer contract;
- a replay or recovery owner independent of the decision owner;
- a public protocol;
- current implementation authority.

## Required contract contents

### 1. Status and authority

Distinguish exactly:

- current implemented v1 values and migration-0002 rows;
- accepted target private values defined here;
- bounded B1 compatibility edge;
- future physical/migration/transaction seams;
- external authority/evidence that cannot be replaced by local values.

The document must state that no value defined by this tranche is implemented.

### 2. Closed logical schema inventory

Choose and freeze coherent private schema IDs and digest-domain identifiers for
the following logical values. Python class names remain implementation detail.

#### Admission-side inputs and facts

1. **Verified admission-act safe evidence**
   - safe, bounded projection of an externally authenticated standing-policy
     act;
   - external evidence, not Coordinator durable authority and not execution
     permission;
   - binds act identity/digest, policy-authored lineage, bootstrap scope,
     guard profile, direct-local applicability, and bounded provenance.

2. **Immutable bootstrap-scope admission fact**
   - future durable provisioner-owned fact;
   - records the verified admitted lineage/scope binding;
   - never means current permission, continuity, or sole-active posture;
   - identity must be domain-separated and independent of machine, process,
     database, program, attempt, candidate, command, grant renewal, restore, or
     relocation identity.

#### Guarded-decision inputs

3. **Admitted-lineage/scope command relation**
   - private command expectation, not admission authority;
   - binds canonical lineage, scope, admission-fact ref/digest, guard profile,
     applicability, deterministic family route, and every preassigned family
     identity required before evaluation;
   - caller may assert expected coordinates but may not select an unadmitted
     scope or author the admission conclusion.

4. **Verified lineage-continuity basis**
   - safe current evidence projection with exact source ref/digest,
     lineage/scope binding, currentness coordinates, and provenance;
   - remains external/current evidence;
   - any retained historical basis is evidence of what was checked, not proof
     of current continuity on replay or recovery.

5. **Verified sole-active-authority basis**
   - safe current evidence projection bound to the same lineage/scope and
     authority epoch/currentness;
   - composes with local writer/session fencing;
   - does not make the local lock, writer row, database, process, or machine the
     lineage authority.

#### Guarded-decision durable family

6. **Immutable bootstrap-acceptance fact**
   - future guarded-decision-writer-owned durable member;
   - present exactly once only for `candidate_acceptance`;
   - absent for `candidate_repair`, `attempt_selecting_replan`,
     `program_terminal_reject`, and `post_execution_program_block`;
   - binds the admitted scope and exact accepted decision family;
   - contains no reset, revision, available/consumed state, renewal, terminal
     state, or separate receipt identity.

7. **Guarded acceptance-family relation**
   - immutable supplemental relation over unchanged generic v1 rows and the
     acceptance fact;
   - exact required role inventory and nullability by branch;
   - binds historical program-head postimage evidence without requiring the
     mutable current head to remain at its historical value;
   - no separate transaction or receipt.

8. **Guarded progression-result composite/profile**
   - versioned private composite over the unchanged generic v1 result and the
     guarded family relation;
   - preserves the generic v1 result identity/digest meaning;
   - does not add fields to or silently reinterpret the v1 result.

9. **Guarded mutation-receipt graph profile**
   - versioned required-role profile rooted in the unchanged generic v1
     receipt;
   - one logical receipt only;
   - requires exact presence, role, identity, and digest of every member needed
     for branch-specific completeness;
   - proves no authority merely from a supplied graph digest.

#### Replay/recovery values

10. **Complete-family recovery selector**
    - transient private query value, not durable authority;
    - covers the command-bound lineage, scope, admission expectation, mutation,
      decision, version, optional acceptance fact, deterministic route, and
      alias/collision routes;
    - excludes transaction timestamp, final receipt digest, and other values
      unavailable before commit;
    - cannot infer unclaimed status from absence.

11. **Complete-family recovery result**
    - closed three-way result:
      `committed_exact`, `definitely_not_committed`, `unresolved`;
    - projection of exact durable reads plus required fresh external posture;
    - no repair, branch reevaluation, new timestamp, retry authorization, or
      scope renewal.

If the repository proves that one of these is a relation/profile rather than a
standalone canonical value, preserve the semantic inventory while choosing the
narrower representation. Explain the choice in the contract.

### 3. Exact authority/non-authority matrix

For every logical schema above, freeze:

- semantic owner;
- future writer, if durable;
- verifier;
- durable versus transient versus external status;
- command-digest coverage;
- receipt-graph coverage;
- recovery-selector coverage;
- replay owner;
- recovery owner;
- prohibited substitute authorities.

### 4. Identity and digest DAG

Freeze one acyclic dependency DAG.

Required order:

1. external admission-act identity/digest;
2. immutable admission-fact identity/digest;
3. command expectations and command digest;
4. canonical decision, resulting version, and historical head postimage;
5. immutable acceptance fact, acceptance branch only;
6. guarded family relation and guarded result composite;
7. generic receipt’s versioned required-role graph;
8. replay/recovery projections.

Required prohibitions:

- admission fact depending on a decision, result, receipt, or terminal fact;
- acceptance fact depending on its result or receipt;
- relation/result identity depending on final receipt digest;
- selector depending on transaction timestamp or postcommit-only digests;
- receipt graph being treated as proof of member validity without exact member
  verification;
- any cycle hidden through a supplied aggregate digest.

Freeze exact domain separation and canonicalization/versioning rules for the new
private values, but do not freeze Python names or SQL serialization.

### 5. Command-digest coverage

Freeze the exact semantic coverage of the future guarded command digest.

It must cover:

- expected lineage and bootstrap scope;
- admission-fact ref/digest and guard profile;
- bounded admission applicability;
- safe continuity and sole-active evidence expectations/ref-digests;
- mutation ref;
- preassigned decision/version/optional fact refs;
- deterministic family route;
- existing decision basis and current-head expectation required by the decision
  owner.

It must not cover:

- caller-authored branch or acceptance conclusion;
- transaction timestamp;
- resulting row self-digests;
- receipt graph digest;
- terminal outcome;
- raw credentials or raw external attestations.

### 6. Branch-specific family roles

Freeze exact required-role inventories for:

- `candidate_acceptance`;
- each of the four nonaccept branches.

For acceptance:

- acceptance fact is required exactly once;
- admitted scope and admission fact are required;
- exact decision/version/head postimage, guarded relation/result, and one
  receipt profile are required.

For nonaccept:

- acceptance fact must be absent;
- absence must be represented by branch grammar, not a caller-controlled null
  that can masquerade as an unclaimed scope;
- the result/receipt profile must still prove the exact nonaccept family;
- no projection may assert that the scope remains unclaimed.

### 7. Replay and recovery semantics at the value boundary

Do not freeze transaction mechanics, but freeze what the values must make
provable.

Exact replay must be able to return:

- original decision/version/head postimage;
- original optional acceptance fact;
- original guarded relation/result;
- original receipt and transaction timestamp;

without:

- reconstructing a new fact;
- reevaluating eligibility or branch;
- creating a new timestamp;
- changing the current program head;
- renewing a scope.

The selector/result grammar must distinguish:

- same mutation/same command/complete exact family;
- same mutation/different command digest;
- preassigned identity or route collision;
- different complete winner in the same admitted scope;
- exact total absence;
- partial/orphan/duplicate/malformed/foreign/unreadable family;
- restore/clone with unproved continuity.

Do not define SQL queries in this tranche.

### 8. V1 preservation

Freeze the current semantics and bytes of:

- migration-0002 decision row grammar;
- migration-0002 program-version grammar;
- migration-0002 program-head grammar;
- generic v1 result projection;
- generic v1 mutation receipt;
- supplied mutation-graph digest primitive.

State explicitly:

- none gains lineage, scope, admission, acceptance, or recovery authority;
- no existing v1 digest domain changes;
- no field is appended to an existing v1 canonical value;
- the future guarded profile supplements rather than repurposes v1.

### 9. B1 compatibility

Amend `.docs/rw0-b1-pure-phase-values.md` only as needed to state:

- current `latch_postimage_ref` and `latch_postimage_digest` names, order,
  nullability, bytes, domains, budgets, and validation remain unchanged;
- the pair proves supplied representation/coherence only;
- the guarded decision writer must not read or consume the pair;
- the pair is not admission, acceptance, uniqueness, family membership,
  continuity, replay, or recovery proof;
- terminal binding/versioning is a separate later contract.

Do not introduce a B1 successor value in this tranche.

### 10. Future physical handoff

State that a later bounded-hybrid physical contract may realize these values
through additive migration `0005`, while retaining migrations 0001–0004 and
their current meanings.

Do not select table, row, index, trigger, reader, or transaction layout.

## Amendments to existing owners

### Guard owner

Amend only to:

- route private value/versioning and graph-profile semantics to the new owner;
- preserve guard semantic authority;
- keep physical representation unimplemented;
- keep continuity/sole-active evidence external/current;
- preserve B1 nonproof and later terminal boundary.

### Decision owner

Amend only to:

- route private value/versioning and graph-profile semantics to the new owner;
- preserve reduction, branch, result/receipt, replay, collision, and
  whole-family recovery authority;
- state that generic v1 rows retain their meanings;
- preserve later bounded-hybrid physical and transaction freezes.

### Operating model

Add one bounded composition/status entry:

- new private-value contract is accepted target only;
- no source, migration, writer, reader, caller, export, or runtime exists;
- next prerequisites remain admission/continuity physical contract,
  bounded-hybrid migration contract, and transaction/recovery contract.

Do not claim migration `0005` exists.

## Contract-test requirements

Create:

`tests/test_rw0_c2_private_value_versioning_contract.py`

The test must be causal, compact, and document-driven. It must not become a
second reducer, physical schema emulator, or source manifest freeze.

### Independent representations

Require independently authored:

1. normative prose;
2. one closed machine-readable contract block in the new document;
3. fixed test expectations;
4. source-derived current-v1 inventories;
5. hostile mutation expectations.

Do not derive fixed expectations from the machine block being checked.

Reject duplicate JSON keys recursively.

Use exact built-in type comparison; booleans must not equal integers.

### Required positive checks

Verify at minimum:

- exact owner hierarchy and accepted-target/nonimplementation status;
- exact closed logical schema inventory;
- exact authority/non-authority matrix;
- exact DAG and acyclicity;
- exact command-digest inclusion/exclusion inventory;
- exact acceptance and four nonaccept role profiles;
- exact replay/recovery selector/result grammar;
- exact v1 source field order, schema IDs, and digest domains relevant to the
  preserved decision/result/receipt surfaces;
- exact B1 pair source grammar and non-consumption statement;
- migration catalog remains exactly 0001–0004;
- migration `0005` absent;
- no new source module, package export, public method, production caller,
  provisioner, writer, reader, or runtime surface;
- cross-references from the guard owner, decision owner, B1 owner, and
  operating model.

### Required hostile controls

At minimum, create causal mutations that attempt to:

1. make the decision writer create admission;
2. treat local row absence as an admitted or unclaimed scope;
3. make machine/database/process identity equal lineage identity;
4. turn continuity or sole-active evidence into a durable local standing fact;
5. add mutable `available`, `consumed`, revision, reset, or renewal state;
6. create a separate guard receipt;
7. create a separate guard replay or recovery classifier;
8. place an acceptance fact on any nonaccept branch;
9. omit the acceptance fact from the acceptance branch;
10. make the acceptance fact depend on result or receipt;
11. create another digest cycle;
12. include transaction timestamp in the precommit command digest or selector;
13. omit admission ref/digest from command or selector coverage;
14. let supplied graph digest prove member validity by itself;
15. reinterpret or append a field to a v1 result or receipt;
16. give B1 `latch_postimage_*` durable guard authority;
17. let the guarded decision writer consume the B1 pair;
18. claim migration `0005`, a writer, reader, provisioner, caller, export, or
    runtime exists;
19. make a terminal fact create, reset, repair, or replenish acceptance;
20. make later ES routing replenish the direct-local allowance.

Each mutation must fail at a named semantic boundary, not merely through
formatting or substring absence.

### Anti-overfitting requirements

- Do not require a huge scalar-pointer test for every prose token.
- Do not build a second executable decision reducer.
- Do not use one test-local dictionary as both expected and observed truth.
- Do not rely only on file hashes.
- Do not freeze absolute line numbers, source-file counts, or unrelated source
  bytes.
- Do not claim physical SQL correctness.
- Keep the verifier bounded to this contract.

## Validation

Run validation serially in a clean local-only external clone created from exact
HEAD and overlaid with the six candidate files.

Do not import modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run at minimum:

1. New contract module:
   `tests/test_rw0_c2_private_value_versioning_contract.py`
2. Existing semantic owners:
   - `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
   - `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
3. B1 and current-v1 boundaries:
   - `tests/test_rw0_b1_phase_values.py`
   - `tests/test_rw0_b1_boundaries.py`
   - `tests/test_c2b2_development_decision_row_values.py`
   - `tests/test_c2b2_development_program_row_values.py`
   - `tests/test_sqlite_c2b2_migration_0002.py`
4. Composition/architecture:
   - `tests/test_autonomous_software_development_operating_model.py`
   - `tests/test_architecture_contracts.py`
   - `tests/test_runtime_non_authority.py`
5. Relevant C2/RW0/C2B regression groups.
6. Complete repository suite.

Record exact commands, counts, warnings, and any skipped validation.

Also run:

- `git diff --check`;
- new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling check;
- source/migration/export/public/runtime preservation checks;
- external-clone artifact scan.

The only accepted full-suite warnings are pre-existing warnings independently
shown to be unchanged.

## Provenance and closeout

At closeout require:

- baseline HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six files regular mode `0644`;
- other repository files byte-identical to HEAD;
- source and migration trees unchanged;
- migration `0005` absent;
- no live-cache movement or modification;
- no retained validation clone or artifact.

Calculate twice and report:

- each path’s status, mode, byte size, and SHA-256;
- deterministic complete six-path binary patch bytes and SHA-256;
- a fully specified canonical receipt grammar, bytes, and SHA-256.

Do not stage, commit, push, create or modify a PR, or merge.

## Stop conditions

Return the blocking token without leaving partial edits if:

- baseline differs;
- the six-file ceiling is insufficient;
- current source contradicts v1 preservation;
- the new contract would require selecting SQL or transaction mechanics;
- a source, migration, export, or existing test must change;
- the accepted guard or decision semantics must be reopened;
- external continuity product meaning is unresolved;
- B1 must be changed rather than preserved;
- coherent DAG/versioning cannot be frozen without a second receipt/recovery
  owner.

## Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_BLOCKED`

## Required non-actions

State:

```text
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CEILING_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
