## Disposition

**Accept the independent audit’s block. Do not stage or commit the six-path candidate.**

The audit reproduced the exact baseline, all six path receipts, the `114,527`-byte patch, and the `1,379`-byte canonical receipt. The repository remained source- and migration-clean, and migration `0005` remains absent. This is therefore a semantic/test-adequacy block, not a provenance failure. :chatgpt-content-reference{index="0"}

The ordinary validation also remains green—`8,003 passed` with the three expected warnings—but that does not override the required hostile and architecture-proof failures. :chatgpt-content-reference{index="1"}

## Findings and engineering judgment

### 1. The prospective identity formula is locally reproducible but not globally acyclic

V2 successfully defines a non-null prospective acceptance-fact reference and a reproducible hash formula. The problem is that the formula consumes preassigned decision/version identities and a deterministic family route without freezing how those values are assigned.

The audit is correct that the current contract does not exclude cycles such as:

```text
command digest
→ family route
→ prospective acceptance-fact ref
→ command digest
```

The existing broad-node DAG and free-literal test do not prove the needed premise that all preassignments originate independently and before the command digest. :chatgpt-content-reference{index="2"}

**Selected repair:** define one exact branch-neutral preassignment transcript from primitive precommit coordinates. Derive the decision ref, version ref, guarded-relation ref, guarded-result ref, family route, and prospective acceptance-fact ref as **six sibling domain-separated hashes of that same transcript**. Then derive the command digest last, covering all six.

No sibling identity may depend on another sibling, the command digest, branch, result, receipt, timestamp, terminal state, or postcommit data.

This stays within the private value contract. It does not add a twelfth durable value or select SQL mechanics.

### 2. Route templates and concrete selector routes are conflated

The prose says each concrete route has:

```text
role
kind
key
expected_schema_id
```

The machine block instead puts `key_sources` under the same `required_collision_routes` field. The tests silently interpret those objects as templates, but the contract never declares that distinction. :chatgpt-content-reference{index="3"}

**Selected repair:** freeze two explicitly different structures:

```text
collision_route_templates:
    role, kind, key_sources, expected_schema_id

selector.required_collision_routes:
    role, kind, key, expected_schema_id
```

A concrete `key` is always an ordered tuple/JSON array of exact strings, including a one-element tuple for single-coordinate routes. The admitted-scope winner route uses its exact multi-coordinate key.

The contract must define deterministic instantiation from template source fields to concrete route keys and reject template/instance field confusion.

### 3. Contradictory normative prose still survives

All machine-profile mutations failed, but six prohibited assertions inserted into otherwise unchanged prose passed all 186 tests. These included making historical evidence current authority, making the prospective coordinate control the branch, deriving noncommit from local absence, and allowing replay to create a fact or timestamp. :chatgpt-content-reference{index="4"}

Positive phrase-presence checks are insufficient.

**Selected repair:** introduce a closed normative-clause registry for the authority-sensitive value rules and a bounded whole-document contradiction parser. Every normative statement over the registry’s subjects must map to one known clause. Unknown, contradictory, or opposite-modality assertions must fail.

This is not general natural-language theorem proving. It is a closed parser for the exact vocabulary of this contract.

### 4. Nonaccept family-relation fields are underspecified

The relation includes `acceptance_fact_ref` and `acceptance_fact_digest` for every branch, but V2 does not state their exact nonaccept values. The existing test checks a separate membership list rather than the relation fields themselves. :chatgpt-content-reference{index="5"}

**Selected repair:**

```text
candidate_acceptance:
    acceptance_fact_ref = reserved prospective ref
    acceptance_fact_digest = actual verified fact digest

all four nonaccept branches:
    acceptance_fact_ref = null
    acceptance_fact_digest = null
```

The reserved prospective identity still remains mandatory in the command and recovery selector and must still be collision-probed. Null relation fields never imply an unclaimed scope.

### 5. Admission and branch-neutrality evidence is not causal

The current verifier uses self-consistent arbitrary admission strings and builds expected branch memberships from its own `BRANCHES` constant. It does not bind the command to an independently verified admission fact or exercise the authoritative C2 branch interpreter while varying the prospective coordinate. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

**Selected repair:**

- Create an independent fixed verified-admission fixture and compare every command relation field to it.
- Reuse the existing document-driven C2 contract interpreter/helper from the current C2 test module.
- Do not copy the branch table or precedence into the private-value verifier.
- Prove dynamically that the prospective coordinate is absent from the reducer input and cannot alter any of the five derived branches.
- Validate null or incorrect coordinates separately before family materialization.

## Repair boundary

The narrowest sufficient ceiling remains exactly two files:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents should remain byte-identical. The audit found that owner routing, migration-0002 preservation, B1 non-consumption, single receipt/replay/recovery ownership, and nonimplementation status remained coherent. :chatgpt-content-reference{index="8"}

No guard-owner, decision-owner, B1, operating-model, source, migration, or existing-test amendment is presently justified. The repair must block rather than widen if live constraints prove otherwise.

## Codex handoff

Resume the **same implementation Codex conversation**, switch the parent to workspace-write, and keep the parent as the sole writer.

:chatgpt-content-reference{index="10"}[Download the complete V3 repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V3_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V3_Repair_Prompt.txt

Size:
30,538 bytes

SHA-256:
4e5c6ed0b5306649d08a7a3fa145f895032f2d1b080491ebc06c6045116b77e9

Logical lines:
954

Final newline:
present
```

The prompt requires:

- exact reproduction of the V2 candidate before editing;
- a strict two-file ceiling;
- a complete primitive preassignment transcript;
- six independently derived sibling identities;
- a fully expanded machine-readable dependency registry and real topological sort;
- command digest derivation only after all preassignments;
- separate route-template and concrete-route grammars;
- exact branch-specific relation fact fields;
- independent admission binding;
- reuse of the existing C2 interpreter rather than a copied reducer;
- a closed normative-clause registry and contradiction detection;
- more than 40 external transformed mutants;
- focused, broad, and full-suite validation;
- exact preservation of all source, migrations, public/runtime surfaces, and the other four candidate documents.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V3_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V3_REPAIR_BLOCKED
```

A successful result authorizes only another fresh independent read-only audit. It does not authorize migration `0005`, source value implementation, admission provisioning, durable decision persistence, readers, recovery implementation, terminal binding, public APIs, runtime activation, RW0-D/E, or Execution Substrate work.

**Source:** Fresh V2 independent re-audit attached in this turn. Its exact next boundary is a private contract/test repair covering preassignment origins, route grammar, branch relation values, causal tests, and contradictory-prose controls. :chatgpt-content-reference{index="9"}

**Confidence:** High that the block is correct. High that the sibling-derivation DAG and explicit template/concrete route split are the narrowest truthful engineering repairs. Medium-high that the two-file ceiling remains sufficient; the prompt requires a clean stop if closing the DAG would force changes to another semantic owner.
