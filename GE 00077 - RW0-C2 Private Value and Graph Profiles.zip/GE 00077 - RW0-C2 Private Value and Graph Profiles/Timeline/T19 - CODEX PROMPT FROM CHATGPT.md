# Governed Execution Coordinator — RW0-C2 Private Value Contract V4 Independent Re-audit

## Role and objective

Perform a fresh, parent-led, local, read-only independent re-audit of the exact
uncommitted six-path RW0-C2 private value/versioning and receipt-graph-profile
V4 candidate.

This audit follows a two-file repair intended to close the V3 audit findings:

1. the semantic dependency graph omitted required transaction-time edges and
   gave `receipt_graph_profile` a cyclic or undefined graph-digest binding;
2. the closed command relation omitted four command-covered continuity and
   sole-active source coordinates;
3. admission validation and shared-C2 branch causality were not independently
   proven;
4. route, acceptance-fact, and complete receipt-role verification were
   self-confirming or incomplete;
5. authority-sensitive contradictory prose survived the bounded scanner.

Use the highest available Codex reasoning setting. At the beginning of the
report, record exactly what the interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The checked-out repository is the sole audit target and source of current
contract and implementation truth. Do not request or use chat exports, prior
audit packages, Downloads artifacts, Project artifacts, or generated manifests.
The implementation closeout is evidence only; independently reproduce every
material claim from the live repository.

Do not repair the candidate.

Return one substantive inline audit report with exact repository-relative
`path:line` evidence. Do not create or attach a report, manifest, package,
freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

Any baseline, path-set, classification, file-type, mode, byte-size, or SHA-256
mismatch requires:

`AUDIT_PROVENANCE_MISMATCH`

Stop before correctness inspection.

## Exact V4 six-path candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six must be regular, non-symlink mode-`0644` files, valid UTF-8, with no
BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 126,333 | `1108d8c72b1629973ae7d75a8afd8bd7a227ef62dcf13121ea23da7924001fc3` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 145,730 | `4bac143d711deb64c12fc99b99a882a21f84f4c2268e4156481b2dd0ede10ebf` |

Require:

- zero deletions, renames, type changes, symlinks, executable-mode changes, or
  additional untracked paths;
- every tracked path outside this set byte-identical to HEAD;
- source and migration trees byte-identical to HEAD;
- migration `0005` absent.

## Complete binary patch provenance

Construct the complete patch in lexicographic path order.

For each tracked path:

```text
git diff --binary --no-ext-diff HEAD -- <path>
```

For each new path:

```text
git diff --no-index --binary --no-ext-diff -- /dev/null <path>
```

Treat expected `git diff --no-index` status `1` as “differences found.”

Concatenate exact stdout bytes without separators.

Expected:

- bytes: `282,946`
- SHA-256:
  `9fa5fa6842d9ef85dbe82cd500c4e4e53986ebbb6c050c604dbcbf1cac5c50e8`

Run the assembly twice.

The exact path set and per-file receipts are primary. An unresolved patch
difference is `AUDIT_PROVENANCE_MISMATCH`.

## Canonical receipt corroboration

Reconstruct the implementation-reported receipt exactly.

Grammar:

- root object keys:
  - `baseline_head`
  - `files`
  - `patch`
  - `schema`
- recursively sorted object keys;
- compact separators `,` and `:`;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- each file object has:
  - `mode`
  - `path`
  - `sha256`
  - `size_bytes`
  - `status`
- status values are `modified` or `untracked`;
- patch object has:
  - `byte_length`
  - `sha256`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`;
- baseline_head:
  `3d99e448bfe577b5a5878dd32b7e01b61322e7df`.

Expected:

- bytes: `1,381`
- SHA-256:
  `7a999cc5760ab60aba676e481d8cb538511df605fd27cc315271d2b9fc7ca839`

Use two structurally independent serializers and require byte-identical output.

## V3-to-V4 transition evidence

The implementation closeout reports that only these two paths changed from the
independently blocked V3 candidate:

| Path | V3 bytes / SHA-256 | V4 bytes / SHA-256 |
|---|---|---|
| `.docs/rw0-c2-private-value-versioning.md` | `116,817` / `7a599ef8c75dfff9644da114467691db6413336bd3433187200b4918bf50d4f0` | `126,333` / `1108d8c72b1629973ae7d75a8afd8bd7a227ef62dcf13121ea23da7924001fc3` |
| `tests/test_rw0_c2_private_value_versioning_contract.py` | `113,001` / `d13c73d1aa5c20aeae90ccb5cc326f30668be22373728008d9f398ffb5a714d7` | `145,730` / `4bac143d711deb64c12fc99b99a882a21f84f4c2268e4156481b2dd0ede10ebf` |

The other four candidate documents have the same receipts in V3 and V4.

The live V4 bytes are the primary audit target. Do not request historical V3
files. If V3 bytes are unavailable in the live checkout, classify the exact
two-file transition as corroborating history rather than blocking provenance.

## Prior audit findings and blocked first V4 attempt

The V3 audit established exact live provenance and blocked because:

- `receipt_graph_profile` carried an ambiguous/cyclic graph-digest field;
- transaction-time edges required by unchanged v1 identities were missing;
- four continuity/sole-active source coordinates were absent from the closed
  command relation;
- admission was checked after branch derivation, and a copied branch result
  survived;
- route builder, validator, and expectations shared one source;
- foreign acceptance-fact scope and Boolean head revision survived after
  resealing;
- complete common receipt roles were not reconstructed;
- contradictory headings, bullets, tables, modal variants, split assertions,
  and subject aliases survived the prose scanner.

A first V4 repair prompt incorrectly required the static receipt-profile digest
to become an additional member of the unchanged generic v1 graph. Codex stopped
before editing and restored exact V3 bytes. That blocked attempt produced no
candidate and is not an audit target.

Audit the revised V4 repair rather than assuming these findings are closed.

## Audit posture

Permitted:

- read-only Git inspection;
- static inspection of docs, source, migrations, tests, configuration, and
  package exports;
- safe AST and lexical analysis with `PYTHONDONTWRITEBYTECODE=1`;
- pytest and transformed hostile copies only in private external local clones;
- at most three bounded read-only explorer subagents with self-contained
  prompts.

Subagents must not import modules from the live checkout. If their read-only
posture or bytecode suppression cannot be guaranteed, continue parent-only.
Explorer unavailability is not itself a candidate defect.

Prohibited:

- editing, formatting, cleaning, or repairing live repository files;
- staging, committing, pushing, PR operations, or merging;
- remote or sibling-repository contact;
- opening or mutating operator or product-state databases;
- running migrations or services;
- installing dependencies;
- importing repository modules from the live checkout;
- moving, deleting, or rewriting ignored live cache material;
- generating client-visible artifacts.

Remove all audit-created temporary data at closeout.

## Authority posture

Apply this hierarchy:

- Git owns commit/tree/blob/ref facts.
- `AGENTS.md` owns repository guidance and routing.
- `.docs/` owns current and accepted-target semantics within declared scopes.
- the operating model owns composition and current-status classification.
- source and migrations own current implemented v1 bytes and physical
  representation.
- tests are evidence and drift guards, not semantic owners.
- reports are evidence only.

The private-value contract may own only accepted-target private value,
versioning, preassignment-DAG, branch-profile, static graph-profile,
query-value, and bounded normative-clause semantics. It remains subordinate to:

- the bootstrap-guard owner for lineage, scope, admission, current continuity,
  sole-active posture, one-shot eligibility, permanence, terminal, and ES
  boundaries;
- the durable-decision owner for branch reduction, generic
  decision/version/head/result/receipt, replay, collision taxonomy, and
  whole-family recovery semantics;
- current source and migrations for implemented v1 values and storage;
- the operating model for composition.

## Fixed accepted architecture

Do not reopen the merged product-policy decision.

The candidate must preserve:

1. one standing-policy-admitted Coordinator authority lineage per bootstrap
   scope;
2. immutable scope admission and zero-or-one immutable acceptance fact;
3. no lineage or allowance created by machine, process, database, program,
   command, restore, clone, relocation, or local row absence;
4. one active authority and positive current continuity;
5. one acceptance fact only for `candidate_acceptance`;
6. no acceptance fact for the four nonaccept branches;
7. acceptance fact in the same atomic decision/version/head/result/receipt
   family;
8. no mutable latch subsystem;
9. one logical result, one receipt, one exact-replay owner, and one whole-family
   recovery owner;
10. the decision writer cannot provision, repair, renew, or replenish
    admission;
11. terminal and later ES routing do not mutate or replenish the guard;
12. B1 `latch_postimage_*` remains compatibility/nonproof only.

## Required inspection

Read all six candidate paths completely and follow every exact owner/test edge
needed to verify them.

At minimum inspect:

### Guidance and semantic owners

- `AGENTS.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c1-durable-evidence.md`
- `.docs/c2b-durable-development-state.md`

### Current v1 owners

- `src/ge_nwp_coordinator/_development_decision_row_values.py`
- `src/ge_nwp_coordinator/_development_program_row_values.py`
- `src/ge_nwp_coordinator/_development_row_value_support.py`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql`
- `src/ge_nwp_coordinator/sqlite_migration.py`
- relevant current private reader contracts/readers;
- `src/ge_nwp_coordinator/__init__.py`
- `src/ge_nwp_coordinator/state_store.py`

### Tests and guards

- `tests/test_rw0_c2_private_value_versioning_contract.py`
- `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py`
- `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2b2_development_decision_row_values.py`
- `tests/test_c2b2_development_program_row_values.py`
- `tests/test_sqlite_c2b2_migration_0002.py`
- `tests/test_runtime_non_authority.py`
- migration-inventory and public-surface guards.

Follow additional exact owner/test edges discovered.

## Audit question 1 — two-file repair boundary

Verify:

- only the private-value contract and its verifier differ from their V3 endpoint
  receipts;
- the other four candidate documents remain byte-identical;
- every other repository path equals HEAD;
- source, migrations, exports, StateStore, readers, writers, transactions,
  public/runtime surfaces, configuration, and examples remain unchanged;
- migration `0005` remains absent;
- no accepted architecture changed outside private value, dependency,
  query/profile, and test-adequacy repair.

Any hidden semantic redesign or source widening is blocking.

## Audit question 2 — static receipt-profile status

Inspect `receipt_graph_profile`.

Require that it is exactly:

- static, versioned accepted-target verification metadata;
- one of the existing eleven logical contract surfaces;
- not a per-family durable row;
- not a graph entry;
- not assigned a per-family ref or self-digest;
- not a second result, receipt, replay, or recovery owner;
- not current implemented source behavior.

Its definition may contain only the fixed profile/schema ID and version,
authoritative branch inventory, ordered roles/ordinals, common versus
acceptance-only role grammar, schema/type/cardinality requirements, and
version-supersession rules.

Block if the profile contains or depends on:

- final generic graph digest;
- generic receipt digest;
- transaction timestamp;
- per-family member identity;
- a physical row/query/transaction layout.

Verify that profile evolution requires a new profile ID/version and cannot
reinterpret an existing generic v1 graph.

## Audit question 3 — profile selection through guarded result

Verify that the selected static profile is bound through the existing guarded
progression-result member rather than a new graph member.

Require:

- the guarded result carries the exact V4 `receipt_graph_profile_id` or exact
  equivalent selected by the contract;
- it carries the authoritative branch;
- its canonical content and self-digest bind both;
- `guarded_result_composite` is one of the ten common graph roles;
- the generic graph entry binds the exact guarded-result ref/digest;
- no duplicate profile selector appears in the generic receipt, graph entry,
  family relation, or acceptance fact;
- changing profile ID or branch without changing the guarded-result digest is
  rejected;
- changing profile ID and recomputing the guarded-result digest still fails the
  fixed contract unless a proper successor profile/version is selected.

Independently mutate machine, builder, and observed values together while
leaving fixed profile expectations unchanged.

## Audit question 4 — source-exact generic v1 graph

Derive current graph semantics from
`_development_decision_row_values.py`, not from the candidate.

Verify the exact current algebra:

1. current generic receipt preimage fields, excluding
   `mutation_graph_digest`;
2. exact current graph-entry grammar and ordering inputs;
3. current graph-digest domain and canonicalization;
4. final generic receipt row as unchanged preimage plus
   `mutation_graph_digest`;
5. no invented generic receipt self-digest or profile field.

Require the future guarded family to use:

- exactly ten common graph roles on every branch;
- `acceptance_fact` exactly once only on `candidate_acceptance`;
- no profile graph role;
- no replacement of a common member by the profile.

The graph digest must commit transitively to the profile through the guarded
result member.

Completeness may be credited only after:

- current v1 graph-digest reconstruction;
- exact member ref/digest verification;
- guarded-result profile/branch verification;
- exact static-profile role/cardinality verification.

A supplied graph digest alone is never sufficient.

Block any candidate rule or test that changes current
`_receipt_graph_identity` semantics.

## Audit question 5 — transaction timestamp and dependency graph

Independently reconstruct the reported **67-node / 175-edge** dependency
registry.

Do not credit its claimed count or topological order without deriving every
node and edge.

Require one post-branch `transaction_timestamp` that:

- is assigned exactly once by the future transaction owner;
- feeds decision `decided_at`;
- feeds resulting program-version `created_at`;
- feeds historical program-head postimage `updated_at`;
- feeds the generic receipt/graph preimage `committed_at`;
- feeds any acceptance-fact timestamp only if that field exists in the closed
  value grammar;
- is retained unchanged by exact replay;
- does not feed admission, preassignment, command digest, branch, or recovery
  selector.

Require:

- all six sibling preassignments remain peers;
- command digest is downstream of all six;
- branch is downstream of command and admission validation;
- branch-specific canonical values and digests are downstream of branch and
  timestamp where applicable;
- guarded relation/result are downstream of exact members;
- static profile definition is outside the per-family runtime graph;
- guarded result binds the profile ID;
- receipt preimage plus complete entries precedes generic graph digest;
- generic graph digest precedes final receipt row;
- replay/recovery projections are last;
- no undefined digest origin, hidden aggregate backedge, stage inversion,
  omitted node, or undeclared dependency exists.

Perform an independent topological sort and exact-edge comparison.

## Audit question 6 — closed command relation and transcript

Verify the closed command relation includes, with exact types:

- `continuity_source_ref`;
- `continuity_source_digest`;
- `sole_active_source_ref`;
- `sole_active_source_digest`.

Require those fields to:

- bind the corresponding verified external basis values;
- appear in the exact 24-coordinate branch-neutral transcript;
- be command-digest covered;
- receive the correct recovery-selector treatment;
- remain external-evidence coordinates rather than durable current authority.

Construct the transcript only from the closed command relation, verified
external values, and exact contract literals. Flat fixture-only keys are not
allowed.

For every primitive mutation, independently recompute and require all six
siblings and the final command digest to change where specified.

`expected_head_revision` must be exact nonnegative `int`, never `bool`.

## Audit question 7 — admission-before-branch causality

Verify the fixed admission evidence is independently authored at three layers:

1. fixed raw verified admission-act inputs;
2. independently fixed expected act/fact identities and digests;
3. command/family builders consuming those values.

Changing command, fact, and sibling values must not change the fixed expected
admission vector.

Require execution order:

```text
validate admission act/fact, command binding, current posture, and siblings
→ call shared C2 interpreter exactly once
→ validate prospective identity
→ materialize the exact returned branch family
```

Use an independent outer code-object/profile observer or equally strong actual
entry observation in addition to candidate sentinel tests.

Require:

- invalid lineage, scope, admission ref/digest, profile, applicability,
  continuity source, or sole-active source enters the shared C2 interpreter
  zero times;
- valid input enters it exactly once;
- the returned branch is the value consumed by family formation;
- the prospective coordinate is absent from C2 branch inputs;
- null/wrong prospective coordinates fail command validation separately;
- the verifier does not copy the branch table or precedence;
- an unreachable shared-helper call plus copied branch result is rejected.

Patch the actual callable used by the candidate, not merely an unused defining
module attribute or alias.

## Audit question 8 — route-template and concrete-route independence

Verify four independently authored representations:

1. fixed route-template expectations;
2. fixed concrete routes for one selector vector;
3. parsed prose route table;
4. machine route-template inventory.

Require:

- exact eight routes and order;
- exact template fields:
  `role`, `kind`, `key_sources`, `expected_schema_id`;
- exact concrete fields:
  `role`, `kind`, `key`, `expected_schema_id`;
- one-coordinate routes use one-element ordered keys;
- exact instantiation from selector top-level fields;
- exact first-six schema IDs and final-two null schema IDs;
- all routes on all five branches;
- no extension slot or postcommit dependency.

Builder, validator, fixed expectations, prose, and machine inventory must not
share one mutable `ROUTES` truth.

A joint mutation of machine templates and concrete builder must fail fixed
expectations.

## Audit question 9 — acceptance-fact family binding

Derive the exact acceptance-fact field set from the V4 machine contract.

Require exact binding to independently verified family values for every selected
field, including as applicable:

- lineage;
- bootstrap scope;
- admission-fact ref/digest;
- mutation ref;
- decision ref;
- resulting-version ref;
- historical head ref/revision/digest;
- transaction timestamp;
- schema/profile ID;
- self-digest.

Require:

- fact ref equals the reserved prospective identity;
- scope/lineage/admission equal the independently verified admission family;
- decision/version/head equal the canonical family;
- head revision is nonnegative exact `int`, never `bool`;
- timestamp equals the single family transaction timestamp when present;
- self-digest is computed only after exact field validation;
- a foreign or malformed field remains invalid after resealing all downstream
  digests.

## Audit question 10 — complete receipt-role family

Independently derive and fix the exact common role inventory and order:

1. `verified_admission_act`
2. `scope_admission_fact`
3. `historical_continuity_basis`
4. `historical_sole_active_basis`
5. `decision`
6. `program_version`
7. `historical_head_postimage`
8. `generic_v1_result_projection`
9. `guarded_family_relation`
10. `guarded_result_composite`

Require:

- every branch contains each common role exactly once;
- acceptance contains the ten common roles plus `acceptance_fact` exactly once;
- each nonaccept branch contains the ten common roles only;
- every role ref/digest equals its independently verified member;
- exact role order and ordinal grammar;
- graph digest recomputation from source-exact receipt preimage and complete
  entries;
- guarded-result role binds the profile ID;
- no branch-specific helper authors its own expected role inventory.

Mutate omission, duplication, substitution, reordering, extra role,
same-typed foreign member, acceptance-role placement, and recomputed graph
digest.

## Audit question 11 — bounded normative-language closure

Inspect the thirteen independently fixed tagged clauses.

Require:

- every authority-sensitive normative visible block is tagged with one exact
  clause ID;
- tagged prose normalizes to the independently fixed clause tuple;
- machine contract and tagged prose agree without one generating the other;
- explanatory prose may remain untagged only when it contains no closed
  subject-plus-modal authority construction.

The visible-Markdown parser must inspect outside fenced code and machine JSON:

- headings;
- paragraphs;
- blockquotes;
- bullets and continuation lines;
- tables and cells;
- link labels.

Require closed independent vocabularies for subject aliases, modal phrases,
predicates, objects, and qualifiers.

Independently challenge:

- headings;
- bullets;
- tables;
- blockquotes;
- link labels;
- modal synonyms;
- line wrapping;
- split bullet/continuation assertions;
- double negation;
- subject aliases;
- registry and prose changed together;
- untagged authority statements.

The following meanings must all be rejected:

- replay creates a fact;
- replay refreshes timestamp;
- prospective coordinate is optional;
- prospective coordinate forces or vetoes acceptance;
- historical continuity is sufficient for current authorization;
- local absence proves noncommit;
- command relation admits/selects scope;
- nonaccept skips the acceptance route;
- terminal or ES routing replenishes acceptance.

A surviving semantic contradiction is blocking.

## Audit question 12 — replay and recovery semantics

Verify the candidate still preserves:

- exact original family and timestamp replay;
- no new fact, result, receipt, graph, timestamp, branch evaluation, admission,
  retry, or replenishment;
- the closed eight collision routes;
- `committed_exact`, `definitely_not_committed`, and `unresolved` only;
- total absence credited only with fresh positive continuity and sole-active
  posture plus exhaustive route absence;
- missing, malformed, duplicate, foreign, unreadable, or unchecked route is
  unresolved;
- restore/clone ambiguity is unresolved;
- competing complete scope winner classification remains distinct from fresh
  eligibility.

The private contract must remain a value/query grammar, not a SQL recovery
engine.

## Audit question 13 — owner, v1, B1, and nonimplementation preservation

Verify no regression in:

- closed eleven-value inventory and authority matrix;
- guard/decision/operating-model hierarchy;
- current migration-0002 decision/version/head/result/receipt meanings;
- one logical result and receipt;
- one replay and recovery owner;
- B1 pair exact current grammar and non-consumption;
- no physical SQL/table/index/query/transaction selection;
- no migration `0005`;
- no source module, export, provisioner, writer, reader, caller, public API,
  runtime activation, RW0-D/E, or Execution Substrate behavior.

Block accepted-target wording that reads as current implementation.

## Audit question 14 — test independence

Inspect the reported 427-node verifier.

Require independent authorship among:

- normative prose;
- machine-readable contract block;
- fixed profile ID and role expectations;
- fixed transcript and sibling vectors;
- full dependency-registry expectations;
- route-template expectations;
- concrete-route expectations;
- admission vector and expected act/fact identities;
- acceptance-fact field expectations;
- common receipt-role expectations;
- current-source-derived v1 facts;
- internal hostile expectations;
- external transformed copies.

Reject:

- expectations generated from the machine block under test;
- one helper generating and validating the same graph or digest;
- route values generated and compared from one source;
- admission fixtures authoring their own expected relationship;
- clause registry extracted from prose under test;
- shared C2 helper call present but causally unused;
- broad source-manifest freezing;
- hash-only protection;
- a second reducer, receipt, replay engine, recovery engine, or physical schema
  emulator.

Require recursive duplicate-key rejection and exact built-in type comparison,
including bool/int separation.

## Audit question 15 — implementation-reported 63 external mutants

Independently reproduce at least the following 63 transformed-copy categories.

### Graph and profile binding

1. restore `receipt_graph_digest` inside the static profile;
2. add the profile as an eleventh common graph role;
3. add profile ref/digest fields to the generic v1 receipt;
4. replace one required common member with the profile;
5. remove profile ID from the guarded progression result;
6. change guarded-result profile ID without changing fixed expectation;
7. credit supplied graph digest without member/profile verification;
8. invent a generic receipt self-digest absent from current source;
9. omit transaction timestamp entirely;
10. omit timestamp edge from decision;
11. omit timestamp edge from version;
12. omit timestamp edge from historical head;
13. omit timestamp edge from receipt-graph preimage;
14. feed transaction time into command digest;
15. feed transaction time into recovery selector;
16. introduce a same-stage or reverse graph edge;
17. hide a backedge through an aggregate;
18. compute graph digest from fields differing from current
    `_receipt_graph_identity`;
19. change profile definition without a new profile ID/version.

### Command relation

20. omit continuity source ref;
21. omit continuity source digest;
22. omit sole-active source ref;
23. omit sole-active source digest;
24. retain those values only as flat fixture keys;
25. mutate a primitive without changing command digest;
26. accept `True` as head revision.

### Admission and branch

27. derive branch before admission validation;
28. return a copied branch with an unreachable shared-helper call;
29. call shared helper on invalid admission;
30. foreign admission ref;
31. foreign admission digest;
32. foreign scope;
33. guard-profile mismatch;
34. applicability mismatch;
35. change act/fact/command/siblings while leaving fixed admission expectations
    unchanged.

### Routes

36. mutate decision-route source in machine and concrete builder together;
37. mutate scope-winner route in machine and builder together;
38. copy a concrete key from another role;
39. omit acceptance route on one nonaccept branch;
40. omit scope-winner route;
41. add extension route;
42. confuse template and concrete fields.

### Acceptance fact and receipt roles

43. foreign fact scope with recomputed digest;
44. foreign fact lineage with recomputed digest;
45. Boolean historical-head revision;
46. wrong head digest with recomputed fact digest;
47. wrong decision or version ref;
48. acceptance role only, omitting common roles;
49. omit one common role;
50. duplicate one common role;
51. substitute one common role;
52. acceptance role on nonaccept;
53. acceptance fact missing on acceptance.

### Normative prose

54. contradictory heading;
55. contradictory bullet;
56. contradictory table row;
57. contradictory blockquote;
58. modal synonym;
59. split bullet/continuation assertion;
60. double negation;
61. subject alias;
62. clause registry and prose changed together;
63. untagged authority-sensitive normative statement.

For every mutant require:

- unchanged expected 427-node collection;
- failure at the intended exact semantic boundary;
- no syntax/import/format/collection-shrinkage-only failure.

Report permanent internal controls separately from actual transformed copies.

## Audit question 16 — additional independent mutants

In addition to the 63 categories, test at least:

1. profile ID changed in guarded result, machine block, and builder together;
2. profile role added while common-role expectations are changed together;
3. current `_receipt_graph_identity` omits `committed_at`;
4. current graph entry field order changes;
5. transaction timestamp split into different decision/version/head/receipt
   times;
6. acceptance-fact timestamp differs from family timestamp;
7. guarded-result profile branch differs from authoritative branch;
8. shared C2 sentinel patches an unused alias while the actual call bypasses it;
9. shared C2 result is returned but family builder uses a fixed branch;
10. fixed admission inputs and command values change together while fixed
    expected act/fact identities remain;
11. route machine, builder, and validator change together;
12. complete common-role list and branch helper change together;
13. graph digest is recomputed over a same-typed foreign guarded-result member;
14. one role ref is correct but digest belongs to another role;
15. total absence is declared with one unchecked route;
16. static profile is mislabeled durable/current;
17. neutral explanatory prose is falsely rejected by the scanner;
18. contradictory authority text appears in a Markdown link label or HTML-like
    table cell.

Each must fail—or, for the neutral explanatory control, pass—at the exact
intended boundary.

## Audit question 17 — validation

Create a private local-only external clone from exact HEAD, with no configured
remote, and overlay exactly the six verified candidate files.

Run serially with:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution.

Expected:

| Group | Collection / result |
|---|---:|
| Repaired private-value contract | `427 collected; 427 passed` |
| Existing C2 guard and decision contracts | `1,623 collected; 1,623 passed` |
| Specified B1, C2B2 values, migration 0002 | `458 collected; 458 passed` |
| Operating model, architecture, runtime | `77 collected; 77 passed` |
| Broad RW0/C2B glob group | `4,430 collected; 4,430 passed` |
| Full repository | `8,244 collected; 8,244 passed, 3 warnings` |

The three expected warnings must be exactly the unchanged Python 3.13
multithreaded-`fork()` warnings in existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- no live-checkout imports or cache changes.

Investigate every count, warning, or collection mismatch.

## Audit question 18 — live cache and cleanup

Before executable work, record a safe opening member-level inventory of ignored
cache paths, types, modes, sizes, mtimes, and hashes without importing live
repository modules.

The implementation reports 37 live ignored-cache members but supplies no
canonical aggregate grammar in the closeout. Do not impose an independently
invented historical aggregate. Require exact member-level opening/closing
equality.

Remove every audit-created clone, basetemp, transformed copy, script, receipt,
and log.

Any audit-created live cache member or modified existing member is a provenance
failure.

## Severity and verdict rules

Blocking findings include:

- provenance mismatch;
- static profile becoming a durable/member authority;
- profile selection not cryptographically bound through the guarded result;
- changed v1 receipt/graph identity semantics;
- profile graph role, receipt field, or invented receipt self-digest;
- missing or split transaction timestamp dependency;
- incomplete/cyclic dependency registry;
- missing command relation source coordinates;
- admission validation after branch evaluation;
- actual shared C2 interpreter not causally controlling the family;
- self-confirming route, admission, profile, fact, or role expectations;
- incomplete acceptance-fact family binding;
- incomplete common receipt-role family;
- contradictory normative prose surviving;
- total absence credited without fresh posture or exhaustive routes;
- replay creating a fact or timestamp;
- current v1 value/digest repurposing;
- a second result, receipt, replay, or recovery owner;
- B1 pair gaining guard authority;
- source/migration/public/runtime widening;
- any mandatory mutant surviving;
- unexplained collection, test-count, warning, or cache mismatch.

### Accept

Use only when no unresolved High- or Medium-severity finding remains:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`

Acceptance authorizes only a separate commit/publication gate for the exact six
audited paths.

It does not authorize migration `0005`, source values, provisioner, writer,
reader, recovery implementation, terminal binding, caller, public API, runtime,
RW0-D/E, or Execution Substrate work.

### Block

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

### Provenance mismatch

`AUDIT_PROVENANCE_MISMATCH`

## Inline report structure

Return:

1. primary verdict;
2. visible model/reasoning setting;
3. exact baseline and V4 six-path provenance;
4. patch, receipt, and transition-evidence reconciliation;
5. inspection scope, explorers, failures/retries, and limits;
6. two-file repair-boundary audit;
7. static profile status audit;
8. guarded-result profile-selection audit;
9. source-exact generic-v1 graph audit;
10. transaction timestamp and full dependency-graph audit;
11. closed command-relation and transcript audit;
12. admission-before-branch actual-causality audit;
13. route-template/concrete-route independence audit;
14. acceptance-fact family-binding audit;
15. complete receipt-role family audit;
16. normative-language closure audit;
17. replay/recovery audit;
18. owner/v1/B1/nonimplementation preservation;
19. test-independence audit;
20. exact 63 mutant results;
21. additional independent mutant results;
22. independent validation;
23. live-cache and final provenance;
24. severity-ranked findings;
25. exact next boundary;
26. required non-actions;
27. final token.

## Required non-actions

State:

```text
REPOSITORY_MUTATION_NOT_PERFORMED
REPAIRS_NOT_PERFORMED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUBAGENTS_READ_ONLY_IF_USED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
