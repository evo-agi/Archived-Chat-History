## Disposition

**Accept the V6 audit block. Do not stage or commit the candidate.**

The block is semantic, not provenance-related. The audit reproduced the exact six files, the `478,046`-byte ordered patch, and the `1,381`-byte canonical receipt. Source, migrations, exports, readers, writers, and runtime surfaces remain unchanged; migration `0005` is absent. :chatgpt-content-reference{index="0"}

The full repository also remains green:

```text
8,504 passed, 3 expected warnings
```

The ignored-cache inventory was unchanged across the audit. :chatgpt-content-reference{index="1"}

## What is actually still broken

### 1. The recovery-result contract has two incompatible schemas

This is the clearest blocking defect.

One part of the contract declares a result containing:

```text
fresh_external_posture_ref
fresh_external_posture_digest
observed_family_digest
```

while another declares and tests a result containing lineage, scope, and two distinct current-posture ref/digest pairs. No specified derivation connects those representations. More seriously, the result projector accepts a supplied classification that can disagree with the observation classifier: a partial observation set produced `unresolved`, but the projector accepted `definitely_not_committed`. :chatgpt-content-reference{index="2"}

The repair should select one exact result payload:

```text
classification
lineage_ref
scope_ref
current_continuity_posture_ref
current_continuity_posture_digest
current_sole_active_posture_ref
current_sole_active_posture_digest
```

The projector must compute `classification` internally from the validated observation set. It must not accept a caller- or test-supplied classification override.

### 2. The owner resolver still lets private code choose owner meaning

All thirteen owner pointers currently resolve, but a pointer can be redirected to unrelated owner data with the same Boolean value and still pass. The audit changed the branch clause pointer to an unrelated `runtime_active=false` value, while the unchanged decision owner continued to say the expected branch was assertion-only; all 687 private tests passed. :chatgpt-content-reference{index="3"}

The root problem is that the resolver chooses action and polarity from private mappings before reading the owner value. The unchanged owner is therefore used only as a type/value witness—not as the semantic authority.

V7 should remove private polarity maps entirely. Each clause must instead contain:

```text
exact owner document
exact machine marker
exact JSON pointer
generic comparison
exact expected owner value
independently tested private structural consequence
```

A branch clause, for example, must combine the exact decision-owner branch-role fact with a structural proof that the prospective acceptance coordinate is absent from authoritative branch inputs. An unrelated false value cannot support that consequence.

### 3. Mixed protected clauses still bypass the prose scanner

This contradiction passed all 687 tests:

```text
Replay may create a new acceptance fact but no new timestamp.
```

The parser sees `no new` and incorrectly negates the whole sentence, including the earlier permission to create a fact. :chatgpt-content-reference{index="4"}

The parser needs independent semantic segmentation at sentence boundaries, semicolons, and contrast conjunctions such as `but`, `however`, `although`, `yet`, and `while`. Each protected action must be evaluated separately.

The existing neutral controls must remain accepted:

```text
The replay glossary may include the term timestamp.
The replay diagram may describe receipt creation.
This receipt documentation can include an example.
Timestamp terminology might evolve in explanatory prose.
```

### 4. Lifecycle names and observation-status names need versioning—not impossible self-authentication

The audit also showed that jointly swapping the replay/recovery lifecycle names or jointly renaming `malformed` to `corrupt` in both the contract and its verifier left the suite green. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

There is an important boundary here: **a mutable test file cannot authenticate arbitrary coordinated edits to both itself and the contract it tests.** That is the role of independent audit and exact candidate provenance.

The repository should still freeze the exact vocabulary under a versioned profile:

```text
rw0-c2-private-value-contract-v1

fresh_write_construction_v1
exact_replay_readback_v1
uncertain_commit_recovery_v1

unchecked
exact_complete_family
absent
partial
duplicate
foreign
malformed
unreadable
route_identity_conflict
competing_complete_scope_winner
```

Any vocabulary change requires a successor profile/version. Ordinary repository tests should reject one-sided drift. The next independent audit should own detection of a coordinated edit to both the contract and its test expectations.

This avoids another round of self-referential tests that merely attempt to prove their own immutability.

## What does not need to be reopened

The audit independently confirmed several V6 repairs:

- all five fresh-write DAGs and their acceptance/nonaccept differences;
- the separate replay and recovery graphs;
- validated admission and current posture as branch ancestors;
- complete coverage of all 26 guarded-relation raw fields;
- preservation of canonical command, current-v1 family, static profile, graph roles, and C2 return-value causality. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

The next repair should preserve those surfaces.

## Repair boundary

The narrowest sufficient mutation ceiling remains exactly:

```text
.docs/rw0-c2-private-value-versioning.md
tests/test_rw0_c2_private_value_versioning_contract.py
```

The other four candidate documents stay byte-identical. No source, migration, existing-test, owner-document, public-surface, or runtime amendment is warranted.

The audit’s own next-boundary recommendation is consistent with this: align one recovery-result grammar, derive owner consequences from unchanged owners, close mixed-clause parsing, and then submit new bytes for another independent audit. :chatgpt-content-reference{index="9"}

## Codex handoff

Resume the **same implementation Codex conversation**, keep the parent as the sole writer, and use the exact V6 candidate as the opening state.

:chatgpt-content-reference{index="10"}[Download the V7 recovery-result and owner-authority repair prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_V7_Repair_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_V7_Repair_Prompt.txt

Size:
28,919 bytes

SHA-256:
897977de4e888cc50adec0b9b3702e5a0fb9fa4d66eeacf26ce1b78a0df08144

Logical lines:
862

Final newline:
present
```

The prompt binds the exact opening candidate:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Ordered six-path patch:
478,046 bytes
8990a9ecb93b023d6da6cf519b26b6f3f7a71d61917139ec6870df37d6edd496

Canonical receipt:
1,381 bytes
a31d9d83d116e97e86c8f60d160c76b76616418abc0c643424fe7dd831ca82bd
```

It requires:

- one exact seven-field recovery-result payload;
- classification computed internally from validated observations;
- removal of the conflicting composite-posture and observed-family fields;
- exact owner assertions against unchanged guard and decision machine values;
- generic comparison-only owner resolution;
- independently tested structural consequences for every owner clause;
- rejection of unrelated same-valued owner pointers;
- a versioned private vocabulary profile;
- segmentation of mixed protected clauses;
- exact protected subjects, modals, actions, and objects;
- preservation of all accepted V6 lifecycle, relation, family, profile, replay, and recovery work;
- deterministic broad-suite path expansion instead of relying on the ambiguous historical `4,690` count;
- focused and complete repository validation;
- exact live-cache opening/closing equality.

Success token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V7_VALIDATED_READY_FOR_REAUDIT
```

Blocking token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V7_REPAIR_BLOCKED
```

A successful V7 result will authorize only another fresh independent read-only audit. It will not authorize staging, commit, migration `0005`, source values, admission provisioning, guarded persistence, readers, runtime recovery, terminal work, public APIs, RW0-D/E, or Execution Substrate integration.

Some older uploaded attachments in the project have expired. The current audit response was readable; older files need to be re-uploaded only if a later pass must inspect their bytes directly.

**Source:** Fresh V6 independent re-audit attached in this turn.

**Confidence:** High that the audit block is correct. High that the recovery-result conflict and owner-resolver design are the substantive next repairs. High that versioned private vocabulary plus independent audit is a better boundary than continuing to demand that mutable tests authenticate coordinated edits to themselves.
