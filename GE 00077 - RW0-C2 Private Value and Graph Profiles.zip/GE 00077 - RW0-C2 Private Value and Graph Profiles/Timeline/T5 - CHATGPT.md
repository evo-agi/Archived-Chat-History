## Disposition

**Proceed to a fresh independent read-only audit. Do not stage or commit the six-path candidate.**

Codex returned the intended implementation-closeout token:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT
```

The report is internally coherent and shows no deterministic pre-audit blocker:

- exactly four tracked documentation modifications and two new files;
- no source, migration, existing-test, export, public-surface, or runtime change;
- migration `0005` remains absent;
- all six paths match explicit size and SHA-256 receipts;
- the full suite increased from the previous 7,817 tests to **7,862**, exactly matching the **45 tests** in the new contract module;
- focused and full validation passed with only the three unchanged Python 3.13 `fork()` warnings;
- the six-path patch and canonical receipt were reproduced twice.

The candidate implements the first contract tranche selected by reconnaissance: preserve migration-0002 decision/version/head/receipt meanings, freeze the missing private value and graph-profile semantics, and defer physical migration, provisioning, readers, transactions, and runtime work. The reconnaissance classified that bounded hybrid as architecture-ready rather than implemented behavior. :chatgpt-content-reference{index="0"}

## What the audit must establish

The green suite does not yet prove that the value contract is semantically safe. Four questions are especially important.

### Caller branch preselection

The authoritative branch is derived after the command exists. The audit must verify that an optional or nullable acceptance-fact coordinate cannot become a caller-authored branch bit.

A command must not be able to force acceptance by supplying a fact identity, force nonaccept by omitting it, or bypass collision coverage by toggling nullability. Acceptance-fact presence must follow only from the Coordinator-derived branch and the closed family profile.

### Fresh continuity versus historical basis

The family may retain evidence of what continuity and sole-active posture was checked when the command committed. That historical basis cannot become permanent authority.

Exact replay must return the original family while separately requiring current positive lineage continuity before protected disclosure. Recovery must not infer continuity, sole-active posture, or definite absence from local SQLite rows.

### Current v1 result and receipt semantics

This is the central compatibility question. The audit must independently derive migration-0002 result, receipt, and graph-digest semantics from source.

The new guarded relation and required-role graph may supplement v1, but they must not:

- change a v1 schema or digest domain;
- append authority to an existing field;
- treat a supplied graph digest as proof that members exist or are valid;
- create a second canonical result or receipt;
- claim that current readers verify behavior they do not implement.

### Single replay and recovery authority

The value contract may describe what future replay and recovery must prove, but it cannot become an independent replay or recovery owner.

The digest DAG must remain acyclic:

```text
admission act
→ admission fact
→ command digest
→ decision/version/head postimage
→ acceptance fact
→ guarded relation/result
→ generic receipt graph
→ replay/recovery projection
```

No acceptance fact may depend on its result or receipt, and no selector may depend on transaction time or postcommit-only digests.

## Audit handoff

Start a **fresh read-only Codex conversation**, select the highest available reasoning setting, and attach nothing.

:chatgpt-content-reference{index="3"}[Download the complete independent-audit prompt](sandbox:/mnt/data/Coordinator_RW0_C2_Private_Value_Versioning_Contract_Independent_Audit_Prompt.txt)

```text
Filename:
Coordinator_RW0_C2_Private_Value_Versioning_Contract_Independent_Audit_Prompt.txt

Size:
27,526 bytes

SHA-256:
9851c91ee0fc4cbcc19aad85528cf0b4ad5e896a712c640f593ea8b3049169b4

Logical lines:
794

Final newline:
present
```

The prompt binds the exact candidate:

```text
Baseline HEAD:
3d99e448bfe577b5a5878dd32b7e01b61322e7df

Complete patch:
70,272 bytes
3e012b1a82a261bf4310a652078d17b83675ce7acb271e42afba2e1f89eb6e79

Canonical receipt:
1,378 bytes
66a48768b710a8713d7be1dcf9a1bb9b5c9520b4018b6d0b8c5cab01703a384d
```

It requires independent inspection of:

- the closed eleven-value inventory and authority matrix;
- branch-neutral command formation;
- the exact digest DAG;
- command-digest inclusion and exclusion;
- all five branch-specific family profiles;
- current migration-0002 value and receipt semantics;
- guarded relation/result/graph ownership;
- the three-way recovery selector;
- B1 pair preservation and non-consumption;
- complete nonimplementation and physical-seam preservation;
- fixed expectations versus prose, machine contract, source-derived v1 facts, and hostile controls.

It also requires at least 32 external adversarial transformations, including branch preselection, digest cycles, stale continuity authority, local-absence recovery, graph incompleteness, v1 repurposing, separate receipt/recovery ownership, B1 authority widening, and false implementation claims.

Possible outcomes:

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

```text
RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED
```

```text
AUDIT_PROVENANCE_MISMATCH
```

Even acceptance authorizes only a separate commit/publication gate for these exact six files. It does not authorize migration `0005`, private source values, admission provisioning, decision persistence, readers, recovery implementation, terminal binding, public APIs, or runtime activation.

**Sources:** Codex implementation closeout in this turn; repository-first physical/value architecture reconnaissance. The latter explicitly selected separate admission and guarded-decision owners and classified the physical design as a later bounded additive migration, not present implementation. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

**Confidence:** High that the candidate is ready for independent audit. No commit-readiness judgment is appropriate until branch-neutral command formation, v1 receipt compatibility, fresh-continuity treatment, and single-owner replay/recovery semantics survive independent hostile testing.
