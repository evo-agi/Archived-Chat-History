# Governed Execution Coordinator — RW0-C2 Private Value Contract Revised V4 Source-Exact Graph and Authority-Causality Repair

## Role and objective

Resume the implementation conversation that produced the uncommitted RW0-C2
private value/versioning and graph-profile V3 candidate.

Change the parent permission posture to workspace-write before sending this
turn.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its fresh independent re-audit
returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

A prior V4 repair attempt stopped before editing because its prompt incorrectly
required the private receipt-profile digest to become an additional member of
the unchanged generic v1 mutation graph. That attempt produced no candidate
bytes and restored the exact V3 opening state. This revised V4 prompt supersedes
that blocked prompt and preserves the exact V3 provenance below.

The audit established:

- exact baseline and six-path provenance;
- exact 239,870-byte ordered patch and 1,381-byte canonical receipt;
- no source, migration, existing-test, export, public-surface, or runtime
  widening;
- the owner hierarchy, eleven-value inventory, branch-neutral sibling hashes,
  five branch profiles, v1 preservation, B1 non-consumption, current-posture
  recovery rule, and nonimplementation boundary remain broadly coherent;
- five bounded defects remain:
  1. the semantic dependency graph contains an implicit receipt-profile cycle
     or undefined digest origin and omits required transaction-time edges;
  2. the closed command relation omits four command-covered continuity and
     sole-active source coordinates;
  3. prebranch admission and branch causality are not independently proven;
  4. route, acceptance-fact, and receipt-role tests remain self-confirming or
     incomplete;
  5. authority-sensitive contradictions survive the prose scanner.

This is a **two-file private contract/test repair**. Preserve the accepted
architecture. Do not implement source, migration `0005`, admission
provisioning, continuity transport, durable persistence, readers, transaction
mechanics, recovery, public interfaces, runtime, RW0-D/E, or Execution
Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V3 candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 116,817 | `7a599ef8c75dfff9644da114467691db6413336bd3433187200b4918bf50d4f0` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 113,001 | `d13c73d1aa5c20aeae90ccb5cc326f30668be22373728008d9f398ffb5a714d7` |

Required opening ordered patch:

- bytes: `239,870`
- SHA-256:
  `02843af95268d6807d8fd851a10aebc89af5a3315fe7d7f5022b9040365b5240`

Construct it twice in lexicographic path order with:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,381`
- SHA-256:
  `45deffae290043c663ad53dc0f3686579018be638c3fb47644fff624508ffe93`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V4_REPAIR_BLOCKED`

## Exact mutation ceiling

Only these two paths may change from their opening V3 bytes:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

The other four candidate documents must remain byte-identical to the opening
receipts.

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- architecture, C2B, guard-owner, decision-owner, B1, or operating-model
  documents;
- configuration or examples.

Migration `0005` must remain absent.

If the two-file ceiling is insufficient, restore the exact opening candidate
and return the blocking token. Do not widen the tranche.

## Accepted architecture that must not be reopened

Preserve exactly:

1. The closed eleven logical private values/profiles and their owner hierarchy.
2. The guard owner controls lineage, scope, admission, current continuity,
   sole-active-authority posture, one-shot eligibility, permanence, terminal,
   and ES boundaries.
3. The decision owner controls authoritative branch derivation, generic
   decision/version/head/result/receipt meanings, replay, collision taxonomy,
   and whole-family recovery.
4. Migration-0002 v1 values remain canonical within unchanged meanings.
5. Admission provisioning and guarded decision persistence remain separate
   semantic owners.
6. Acceptance creates one immutable acceptance fact in the same atomic family.
7. Four nonaccept branches create no acceptance fact.
8. There is one logical result, one receipt root, one replay owner, and one
   recovery owner.
9. Historical continuity and sole-active evidence is not current permission.
10. Fresh positive external posture remains required before protected replay or
    recovery disclosure.
11. B1 `latch_postimage_*` remains compatibility/nonproof only and is not
    consumed by the guarded decision writer.
12. Physical schema, migration `0005`, readers, writers, transaction mechanics,
    provisioner mechanics, public interfaces, and runtime remain future.

This repair closes private dependency, command-shape, authority-causality,
family-completeness, and bounded normative-language semantics only.

# Finding H1 — complete semantic dependency graph

## H1-A. Make the receipt profile verification metadata, not a graph member

The prior V4 prompt incorrectly required the generic v1 receipt graph to bind a
separate profile ref/digest. Current v1 source has no profile field and no
profile graph entry. Its graph digest hashes the unchanged receipt preimage and
the exact graph entries. The V3 branch profile already fixes ten common entries,
plus `acceptance_fact` only on acceptance.

Preserve that current v1 shape exactly.

### Receipt-profile status

`receipt_graph_profile` remains one of the eleven logical contract surfaces only
as a **versioned static verification profile**. It is:

- accepted-target contract metadata;
- selected by an exact profile/schema ID and authoritative branch;
- not a per-family durable row;
- not a graph entry;
- not a separately referenced family member;
- not assigned a per-instance self-digest;
- not a second receipt, graph root, replay owner, or recovery owner.

Remove `receipt_graph_digest` from the profile grammar. Do not replace it with a
second profile digest that must be stored or graphed.

The profile definition may contain only:

- exact profile/schema ID and version;
- exact authoritative branch inventory;
- exact ordered role/ordinal grammar;
- exact common-role inventory;
- exact acceptance-only role rule;
- exact schema/type/cardinality requirements for each role;
- exact verification and version-supersession rules.

A profile-version change requires a new profile ID/version and corresponding
successor guarded-result contract. It must not reinterpret an existing generic
v1 graph.

### Profile selection and cryptographic binding

Bind the selected profile **transitively through an existing graph member**, not
through a new graph role.

Use the existing guarded progression-result value as the sole profile selector:

- it carries the exact current V3 receipt-profile ID/version, or an exact
  bounded equivalent already present in the V3 machine contract;
- it carries the authoritative branch;
- its canonical content and self-digest bind that profile selection;
- the unchanged common role inventory already includes the guarded
  progression-result member;
- the generic v1 graph entry for that member binds its exact ref/digest.

If the V3 guarded result does not yet contain a profile selector, add exactly
one target-only `receipt_graph_profile_id` field to that target value. Do not
add the field to any current v1 value or row.

Do not duplicate the selector in the generic receipt, graph entry, family
relation, or acceptance fact.

### Source-exact generic v1 graph direction

Freeze the source-exact graph algebra:

1. The future writer constructs the unchanged generic v1 result projection and
   all exact branch-family members.
2. It constructs the generic receipt preimage fields required by current v1,
   including `committed_at`, but excluding `mutation_graph_digest`.
3. It constructs the exact existing graph-entry inventory:
   - ten common roles on every branch;
   - plus `acceptance_fact` exactly once on `candidate_acceptance`;
   - no profile role.
4. `generic_receipt_graph_digest` is the current v1 domain-separated digest of:
   - the exact receipt fields used by current
     `_receipt_graph_identity`;
   - the exact ordered graph entries.
5. The final generic receipt row is the unchanged v1 receipt preimage plus that
   `mutation_graph_digest`.
6. The final receipt row has no invented receipt self-digest unless current
   source already defines one. The current source does not gain a new field.
7. Exact replay and recovery projections are downstream of the final generic
   receipt row and graph entries.

The graph digest commits cryptographically to the guarded result member and
therefore to its profile selection. Completeness is credited only after:

- current v1 graph-digest reconstruction;
- exact member ref/digest verification;
- guarded-result profile/branch verification;
- exact profile role/cardinality verification.

The supplied graph digest alone is never proof of completeness.

### Required prohibitions

Reject any design or test that:

- adds a profile role to the ten-common-role inventory;
- adds profile ref/digest fields to the generic v1 receipt;
- replaces an existing required role with the profile;
- treats the static profile definition as durable authority;
- lets the graph digest prove profile or member validity without loading and
  validating the exact members;
- invents a second generic receipt digest;
- makes the profile depend on the final graph digest;
- makes the final graph digest depend on a stored profile digest;
- changes current v1 `_receipt_graph_identity` semantics.

## H1-B. Add one transaction-time dependency

Freeze one logical `transaction_timestamp` node:

- assigned exactly once after authoritative branch derivation by the future
  transaction owner;
- not a command input;
- not command-digest covered;
- not part of the preassignment transcript;
- not part of the precommit recovery selector;
- retained by exact replay.

Bind every unchanged v1 timestamp-bearing value to it, including at minimum:

- decision `decided_at`;
- resulting program version `created_at`;
- historical program-head postimage `updated_at`;
- generic mutation receipt / receipt-graph preimage `committed_at`.

If any current v1 owner uses an additional timestamp field, include it.

The timestamp must feed each corresponding canonical content value before its
self-digest/identity. On every branch, the source-exact generic receipt-graph
preimage and final receipt row must have a path from this timestamp. The graph
digest must use the same `committed_at` value through the unchanged v1 receipt
fields.

Do not let transaction time feed a sibling preassignment, command digest,
branch, admission fact, or recovery selector.

## H1-C. Replace the stale 66-node claim

Update the expanded dependency registry to the exact final node/edge inventory.

Requirements:

- exact closed node count and edge count;
- exact stage and closed origin class;
- exact dependencies and prohibited dependencies;
- no omitted timestamp edge;
- no undefined digest origin;
- the static profile definition is outside the per-family runtime graph;
- no profile role, profile ref, profile digest, or final-graph backedge;
- all six sibling identities remain peers;
- command digest remains downstream of all six siblings;
- branch remains downstream of command validation;
- post-branch canonical content/digests include the transaction timestamp;
- guarded progression result precedes the generic graph and binds the exact
  profile ID/version;
- source-exact receipt preimage plus graph entries precede the generic graph
  digest;
- graph digest precedes the final unchanged generic receipt row;
- replay/recovery projections remain last.

Independently topologically sort the final graph in tests. Do not preserve the
number `66` unless it remains true after an exact node-for-node reconciliation.

# Finding M1 — closed command-relation mapping

The preassignment transcript and command-digest inventory include four
continuity/sole-active source coordinates that the closed `command_relation`
schema currently omits.

Add the exact four fields to the admitted command relation:

- `continuity_source_ref`;
- `continuity_source_digest`;
- `sole_active_source_ref`;
- `sole_active_source_digest`.

Use the exact existing V3 names if they differ only in a bounded spelling;
report any reconciliation.

Require:

- exact nonempty-string refs;
- exact lowercase 64-character hexadecimal digests;
- binding to the corresponding verified external basis values;
- inclusion in the 24-coordinate transcript at their current exact positions;
- command-digest coverage;
- recovery-selector coverage where already required;
- no promotion to durable current permission.

The transcript must be constructed from the closed command-relation value and
verified external values, not from extra flat fixture keys outside the schema.

For every primitive mutation, independently recompute and require:

- all six sibling identities change as specified;
- the final command digest changes;
- no branch or postcommit field participates.

# Finding H2 — prebranch admission and live C2 causality

## Independent admission test vector

Create one fixed admission test vector that is independent from command and
fact builders.

It must contain exact canonical literals and fixed expected identities/digests
for:

- verified standing-policy admission act;
- immutable scope-admission fact;
- lineage;
- scope;
- admission-fact ref/digest;
- guard profile;
- direct-local applicability.

The fixed vector is test evidence only. It does not restrict generic product
values to those literals.

Use at least three independently authored layers:

1. fixed raw admission inputs;
2. independently fixed expected act/fact identities and digests;
3. command/family builders consuming those values.

Do not derive the expected act/fact identities from the builder under test.

Mutating the act, fact, command relation, and sibling preassignments together
must still fail the fixed-vector or owner-binding check.

## Admission-before-branch ordering

For every test path:

1. validate the command relation against the verified act/fact and current
   posture;
2. only after successful admission validation call the existing shared C2
   document-driven interpreter;
3. validate the prospective identity;
4. materialize the branch-specific family.

Require dynamic proof:

- invalid lineage, scope, admission ref, admission digest, profile,
  applicability, continuity source, or sole-active source enters the shared C2
  interpreter **zero** times;
- a valid relation enters it exactly once;
- the returned branch is the branch consumed by family formation.

## Live shared-interpreter proof

Add a permanent sentinel test:

- temporarily replace the exact shared C2 interpreter/helper with a callable
  that raises a unique sentinel exception;
- invoke the private-value branch path with valid admission;
- require the exact sentinel to propagate;
- restore the original helper in `finally`.

Add a second test:

- use an invalid admission relation;
- install the same sentinel;
- require the admission boundary to fail before the sentinel is entered.

Add AST/structural protection against:

- copying the five-branch table;
- copying precedence logic;
- using a fixed branch constant;
- leaving the shared helper call unreachable.

A transformed copy that returns a copied branch while retaining an unreachable
shared-helper call must fail.

# Finding H3 — independent route truth

The builder, validator, and assertions must not share one `ROUTES` source.

Create independently authored fixed expectations for:

1. the eight route templates;
2. the eight concrete routes for one fixed selector vector;
3. the prose route table;
4. the machine template inventory.

Requirements:

- fixed expectations are literal and are not generated from the machine block;
- the concrete expected keys are literal ordered arrays/tuples, not generated
  from the templates under test;
- template instantiation is implemented separately from validation;
- validation compares the observed concrete routes to the independently fixed
  concrete expectation;
- the prose table is parsed independently;
- mutating machine templates and concrete builders together cannot mutate the
  fixed expectation.

The exact route remains:

1. mutation receipt;
2. decision identity;
3. resulting version identity;
4. prospective acceptance-fact identity;
5. guarded family relation identity;
6. guarded progression-result identity;
7. deterministic family route;
8. admitted-scope complete-winner route.

Changing the decision route from `decision_ref` to another same-type source in
both machine and builder must fail.

# Finding H4 — complete acceptance-fact and receipt-family binding

## Exact acceptance-fact value

Freeze and test every acceptance-fact field already selected by the V3 machine
contract.

At minimum bind it exactly to independent family values for:

- lineage;
- bootstrap scope;
- admission-fact ref/digest;
- mutation ref;
- decision ref;
- resulting-version ref;
- historical head ref;
- historical head revision;
- historical head digest;
- exact transaction timestamp if the fact carries one;
- schema/profile ID;
- self-digest.

Require:

- scope and lineage equal the independently verified admission fact and command
  relation;
- decision/version/head values equal the independently built canonical family;
- `historical_head_revision` is exact nonnegative `int`, never `bool`;
- self-digest is recomputed only after exact field validation;
- fact ref equals the reserved prospective identity;
- foreign scope, foreign lineage, wrong admission, wrong head, Boolean revision,
  and recomputed hostile digest all fail.

Do not invent fields absent from the current V3 machine contract. If the exact
machine field set differs, report the reconciliation and preserve the same
authority bindings.

## Exact common receipt-role family

The acceptance test may not use a synthetic role list containing only
`acceptance_fact`.

Derive and freeze the exact common role inventory already declared by the V3
branch profiles. The audit reports ten common roles; independently reconcile
the names and order from the live candidate.

Create one independently authored fixed constant:

`EXPECTED_COMMON_RECEIPT_ROLES`

Then require:

- every branch contains every common role exactly once;
- acceptance contains all common roles plus `acceptance_fact` exactly once;
- each nonaccept branch contains only the common roles and no acceptance role;
- every role ref/digest equals its independently verified family member;
- missing, duplicate, reordered, substituted, or extra roles fail;
- the generic v1 graph digest is recomputed from the source-exact receipt
  preimage and the complete role family;
- the guarded progression-result role carries and binds the fixed profile ID;
- no profile role or profile digest is added;
- no branch-specific helper authors its own expected role inventory.

# Finding H5 — bounded normative-language closure

The V3 scanner must not discard headings or inspect only a narrow topic regex.

## Normative-language discipline

Keep the closed clause registry, but require all authority-sensitive normative
statements to appear as explicitly tagged normative blocks:

```text
NORMATIVE <clause_id>: <closed statement>
```

The exact marker spelling may be reconciled with the live document, but it must
be unambiguous.

The contract must declare:

- tagged registered clauses are the only authority-sensitive normative prose
  outside machine blocks;
- explanatory prose is nonnormative and must not use a closed
  subject-plus-modal authority construction;
- the machine block and tagged prose are independently authored and must agree.

## Whole-document visible-text parser

Parse visible Markdown outside fenced code and machine JSON without discarding:

- headings;
- paragraphs;
- blockquotes;
- bullet/list items and their continuation lines;
- table rows and cells;
- link labels.

Normalize only bounded presentation differences:

- Markdown emphasis;
- inline-code delimiters;
- whitespace and line wrapping;
- punctuation;
- closed modal synonyms.

Define closed independent vocabularies for:

- authority-sensitive subject aliases;
- modal/permission phrases, including at least:
  `may`, `must`, `shall`, `can`, `cannot`, `is permitted to`,
  `is allowed to`, `is sufficient to`, `may not`, `must not`;
- protected predicates and objects.

Any visible block containing an authority-sensitive normative construction must:

1. carry one exact registered clause ID;
2. normalize to that independently fixed clause tuple;
3. contain no additional contradictory authority assertion.

Reject:

- untagged authority-sensitive normative blocks;
- unknown clause IDs;
- opposite modality;
- changed object or qualifier;
- duplicate contradictory clauses;
- registry/prose coupled mutation against fixed expectations.

Do not claim general natural-language theorem proving. This is a bounded parser
over the contract’s closed vocabulary.

## Required prose challenges

Permanent controls and transformed external copies must reject:

1. replay creates a fact;
2. replay refreshes the timestamp;
3. prospective coordinate is optional;
4. prospective coordinate forces acceptance;
5. prospective coordinate vetoes acceptance;
6. historical continuity is sufficient for current authorization;
7. local absence proves noncommit;
8. command relation admits/selects scope;
9. nonaccept may skip the acceptance route;
10. terminal or ES routing replenishes acceptance.

Exercise those assertions as:

- headings;
- bullets;
- tables;
- blockquotes;
- modal synonyms;
- split bullet/continuation sentences;
- double negation;
- existing subject aliases;
- registry and prose mutated together.

# Test architecture requirements

Preserve:

- recursive duplicate-key rejection;
- exact built-in type comparison, including bool/int separation;
- fixed expectations independent from machine blocks;
- source-derived current-v1 inventories;
- one logical result/receipt/replay/recovery owner;
- no broad source manifest;
- no physical schema emulator;
- no second reducer;
- no file-hash-only correctness claim.

Separate:

1. permanent internal negative controls;
2. actual transformed external copies;
3. ordinary regression validation.

# Required transformed external copies

Execute, at minimum, the following categories.

## Semantic graph and profile binding

1. restore `receipt_graph_digest` inside the static profile;
2. add the profile as an eleventh common graph role;
3. add profile ref/digest fields to the generic v1 receipt;
4. replace one required common member with the profile;
5. remove the profile ID from the guarded progression result;
6. change the guarded-result profile ID without changing the fixed expectation;
7. treat a supplied graph digest as sufficient without member/profile
   verification;
8. invent a generic receipt self-digest not present in current source;
9. omit transaction timestamp entirely;
10. omit timestamp edge from decision;
11. omit timestamp edge from version;
12. omit timestamp edge from historical head;
13. omit timestamp edge from the receipt-graph preimage;
14. feed transaction time into command digest;
15. feed transaction time into recovery selector;
16. same-stage or reverse-edge graph mutation;
17. hidden aggregate backedge;
18. compute the graph digest from fields that differ from current
    `_receipt_graph_identity`;
19. allow the profile definition to change without a new profile ID/version.

## Command relation

20. omit continuity source ref;
21. omit continuity source digest;
22. omit sole-active source ref;
23. omit sole-active source digest;
24. keep the fields only as flat fixture keys;
25. mutate a primitive without changing command digest;
26. accept `True` as head revision.

## Admission and branch

27. derive branch before admission validation;
28. copied fixed branch with unreachable shared-helper call;
29. shared helper called on invalid admission;
30. foreign admission ref;
31. foreign admission digest;
32. foreign scope;
33. guard-profile mismatch;
34. applicability mismatch;
35. act/fact/command/siblings mutated together.

## Routes

36. mutate decision route source in template and concrete builder together;
37. mutate scope-winner route in template and builder together;
38. concrete key copied from another role;
39. omitted acceptance route on one nonaccept branch;
40. omitted scope-winner route;
41. extension route;
42. template/concrete field confusion.

## Acceptance fact and receipt roles

43. foreign fact scope with recomputed digest;
44. foreign fact lineage with recomputed digest;
45. Boolean historical head revision;
46. wrong head digest with recomputed fact digest;
47. wrong decision or version ref;
48. acceptance role only, omitting common roles;
49. one common role omitted;
50. one common role duplicated;
51. one common role substituted;
52. acceptance role on nonaccept;
53. acceptance fact missing on acceptance.

## Normative prose

54. contradictory heading;
55. contradictory bullet;
56. contradictory table row;
57. contradictory blockquote;
58. modal synonym;
59. split bullet/continuation assertion;
60. double negation;
61. subject alias;
62. clause registry and prose changed together;
63. untagged normative authority sentence.

For every mutant require:

- unchanged expected collection;
- failure at the intended exact semantic boundary;
- no syntax/import/format/collection-shrinkage-only failure.

# Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution and report exact counts.

Run:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening V3 reference: `310 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contract modules
   - reference: `1,623 passed`.

3. Specified B1, C2B2 values, and migration-0002 modules
   - reference: `458 passed`.

4. Operating-model, architecture, and runtime modules
   - reference: `77 passed`.

5. Broad:
   `tests/test_rw0_*.py tests/test_c2b*.py tests/test_sqlite_c2b*.py tests/test_sqlite_rw0*.py`
   - opening V3 reference: `4,313 passed`.

6. Complete repository
   - opening V3 reference: `8,127 passed, 3 warnings`.

The full-suite increase may equal only the exact new contract-test nodes.

The only accepted warnings remain the unchanged Python 3.13
multithreaded-`fork()` warnings from existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling;
- proof the other four candidate documents remain byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- exact live-cache opening/closing member equality;
- removal of all engagement-created temporary data.

# Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact two-file V3-to-V4 transition;
6. proof the other four candidate paths stayed byte-identical;
7. command-relation field closure;
8. final dependency registry, node/edge count, and topological proof;
9. static profile selection, guarded-result binding, and source-exact generic
   graph direction;
10. transaction-time dependency closure;
11. admission-before-branch and live shared-helper evidence;
12. independent route expectations;
13. exact acceptance-fact and receipt-role family;
14. normative-language registry/parser design;
15. dispositions of all five audit findings;
16. permanent controls versus transformed external copies;
17. exact collection and validation results;
18. source/migration/public/runtime preservation;
19. deterministic final six-path patch bytes and SHA-256;
20. fully specified final canonical receipt grammar, bytes, and SHA-256;
21. live-cache equality and cleanup;
22. remaining physical seams;
23. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

# Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the two-file ceiling is insufficient;
- another owner document must change;
- current v1 source contradicts the source-exact receipt preimage or timestamp
  treatment;
- closing the profile binding requires a new generic receipt field, an
  additional graph role, replacement of an existing required role, or a second
  receipt/recovery owner;
- the four missing command fields cannot be added without changing guard or
  decision semantics;
- causal branch evidence requires copying the reducer rather than using the
  existing shared C2 helper;
- exact acceptance-fact scope/head binding requires selecting physical storage
  or transaction mechanics;
- source, migration, export, or existing test changes are required.

Restore the exact opening V3 candidate under a blocking result.

# Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V4_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V4_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

# Required non-actions

State:

```text
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
