# Governed Execution Coordinator — RW0-C2 Private Value Contract V5 Canonical-Family and Conditional-Recovery Repair

## Role and objective

Resume the implementation conversation that produced the uncommitted RW0-C2
private value/versioning and receipt-graph-profile V4 candidate.

Change the parent permission posture to workspace-write before sending this
turn when the interface exposes that control. If it does not, record that fact;
do not infer hidden posture.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its fresh independent re-audit
returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

The V4 audit established exact provenance and accepted the broad architecture,
but found that the private contract and verifier still substitute declarative,
placeholder, or self-consistent evidence for several required causal proofs.

The bounded findings are:

1. the dependency registry omits raw relation inputs, uses an acceptance-only
   digest as an unconditional dependency, and gives recovery no observed-family
   or route-read inputs;
2. the command-digest witness is not the actual command digest used by the
   selector and family;
3. the private source-exact test checks current v1 graph field names but not
   their values or canonical mapping;
4. admission is ordered before C2, but the returned C2 branch is not proven to
   causally control family formation and fresh posture is defaulted rather than
   supplied;
5. selector routes are internally coherent but are not bound back to the
   independently recomputed command and family;
6. acceptance-fact, common-role, profile, and graph checks use placeholder or
   shared fixtures instead of reconstructed canonical family members;
7. authority-sensitive prose still admits contradictory modal, alias, and
   cross-sentence forms, and its fixed truth is not anchored outside the two
   mutable files.

This is a **two-file private contract/test repair**. Preserve the accepted
architecture. Do not implement source, migration `0005`, admission
provisioning, continuity transport, durable persistence, readers, transaction
mechanics, recovery runtime, public interfaces, runtime activation, RW0-D/E, or
Execution Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V4 candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 126,333 | `1108d8c72b1629973ae7d75a8afd8bd7a227ef62dcf13121ea23da7924001fc3` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 145,730 | `4bac143d711deb64c12fc99b99a882a21f84f4c2268e4156481b2dd0ede10ebf` |

Required opening ordered patch:

- bytes: `282,946`
- SHA-256:
  `9fa5fa6842d9ef85dbe82cd500c4e4e53986ebbb6c050c604dbcbf1cac5c50e8`

Construct it twice in lexicographic path order with:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,381`
- SHA-256:
  `7a999cc5760ab60aba676e481d8cb538511df605fd27cc315271d2b9fc7ca839`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V5_REPAIR_BLOCKED`

## Exact mutation ceiling

Only these two paths may change from their opening V4 bytes:

1. `.docs/rw0-c2-private-value-versioning.md`
2. `tests/test_rw0_c2_private_value_versioning_contract.py`

The other four candidate documents must remain byte-identical to the opening
receipts.

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- architecture, C2B, guard-owner, decision-owner, B1, or operating-model
  documents;
- configuration or examples.

Migration `0005` must remain absent.

If the two-file ceiling is insufficient, restore the exact opening V4 candidate
and return the blocking token. Do not widen the tranche.

## Accepted architecture that must not be reopened

Preserve exactly:

1. The closed eleven logical private values/profiles and their owner hierarchy.
2. The guard owner controls lineage, scope, admission, current continuity,
   sole-active-authority posture, one-shot eligibility, permanence, terminal,
   and ES boundaries.
3. The decision owner controls authoritative branch derivation, generic
   decision/version/head/result/receipt meanings, replay, collision taxonomy,
   and whole-family recovery.
4. Migration-0002 v1 values remain canonical within unchanged meanings.
5. Admission provisioning and guarded decision persistence remain separate
   semantic owners.
6. Acceptance creates one immutable acceptance fact in the same atomic family.
7. Four nonaccept branches create no acceptance fact.
8. There is one logical result, one generic v1 receipt root, one replay owner,
   and one recovery owner.
9. Historical continuity and sole-active evidence is not current permission.
10. Fresh positive external posture remains required before protected replay or
    recovery disclosure.
11. B1 `latch_postimage_*` remains compatibility/nonproof only and is not
    consumed by the guarded decision writer.
12. The static receipt profile is verification metadata selected through the
    guarded result; it is not a graph member or durable row.
13. Physical schema, migration `0005`, readers, writers, transaction mechanics,
    provisioner mechanics, public interfaces, and runtime remain future.

This repair closes private canonical-family, conditional-dependency,
command/selector binding, owner-anchored normative, and causal-test semantics
only.

# Finding H1 — branch-expanded dependency and recovery-observation graph

## H1-A. Replace unconditional optional dependencies

The V4 registry unconditionally references
`acceptance_fact_digest_if_accept` from family-relation and receipt-entry nodes,
even though the acceptance fact does not materialize on four branches.

Replace the single ambiguous edge list with one exact branch-expanded graph
contract.

The machine representation must define:

- a closed common node registry;
- each node’s exact stage and origin class;
- `materializes_on`, whose value is one of:
  - `all_branches`;
  - exact closed branch list;
- `common_dependencies`;
- `dependencies_by_branch`;
- `prohibited_dependencies`.

For every one of the five authoritative branches, the verifier must expand an
exact concrete DAG containing only materialized nodes and the exact dependency
set for that branch, then independently topologically sort it.

Required rules:

- `acceptance_fact_value` and `acceptance_fact_digest` materialize only on
  `candidate_acceptance`;
- every nonaccept expanded DAG omits both nodes completely;
- `family_relation_value` depends on acceptance fact ref/digest only on
  acceptance;
- `generic_receipt_graph_entries_value` depends on the acceptance member only
  on acceptance;
- no nonaccept node has an unresolved edge to a nonmaterialized node;
- a branch-specific dependency may not be hidden inside a common aggregate.

Do not create a second relation schema or second graph profile.

## H1-B. Add every raw canonical input required by family relation

The canonical guarded-family relation requires exact raw values, not only
opaque digests.

At minimum, `family_relation_value` must depend on:

- `authoritative_branch`;
- complete `historical_head_postimage_value`;
- exact command digest;
- exact admission/scope/lineage binding;
- exact decision value and digest;
- exact resulting-version value and digest;
- exact generic v1 result projection value and digest;
- exact guarded-result identity expectation where the selected DAG permits;
- acceptance fact value/digest only on acceptance.

Reconcile the exact final list from the V4 canonical relation field inventory.
For every relation field, require a declared dependency on the node that owns
the raw value used in its canonical preimage.

A self-digest, member digest, or aggregate may not substitute for a required raw
field.

## H1-C. Model recovery observations explicitly

The selector is a precommit query plan. The recovery projection is a
post-read classification. They cannot have the same dependency set.

Add one non-durable derivation structure:

`complete_family_recovery_observation_set_v1`

It is not a twelfth logical schema, durable row, public DTO, or second recovery
owner. It is the exact transient read-result basis consumed by the existing C2
recovery owner.

It must contain exactly:

- fresh current continuity posture;
- fresh current sole-active-authority posture;
- one typed observation for each of the eight mandatory collision routes;
- exact observed family/member/readability state where a route resolves;
- exact total-absence proof bits;
- exact duplicate/foreign/malformed/unreadable classifications.

Freeze a closed per-route observation grammar with exact built-in types and a
closed status enum sufficient for:

- exact complete family;
- absent;
- partial;
- duplicate;
- foreign;
- malformed;
- unreadable;
- route/identity conflict;
- competing complete scope winner.

`recovery_projection` must depend on:

- the canonical selector value/digest;
- the exact observation set;
- fresh current posture;
- no local row absence outside those observations.

It must not depend on transaction timestamp as a query coordinate, create or
repair values, reevaluate branch, renew scope, or authorize retry.

Test all three recovery outcomes from exact observation values.

## H1-D. Final dependency proof

Recalculate the final node and edge counts. Do not preserve `67/175` unless the
exact branch-expanded registry still yields those values.

Report:

- common registry node count;
- common edge count;
- expanded node/edge counts for each branch;
- one independent topological order per branch;
- one recovery-query/projection graph;
- exact conditional materialization inventory.

Reject:

- omitted raw relation input;
- edge to nonmaterialized node;
- hidden optional input;
- undefined recovery observation;
- undeclared edge;
- omitted edge;
- stage inversion;
- hidden aggregate backedge.

# Finding H2 — one real command digest used everywhere

## H2-A. Canonical guarded-command digest

The V4 command-coverage hash is test-only and downstream fixtures use a fixed
placeholder digest.

Freeze one exact accepted-target canonical command digest:

`guarded_command_digest_v1`

It is a derived identity within the admitted-command relation, not a twelfth
logical schema and not a durable authority.

Its preimage must be the exact closed ordered combination of:

1. every command-relation field that is command covered;
2. the complete 24-coordinate primitive transcript;
3. the six independently derived sibling identities;
4. any exact decision-owner expectation already required by the V4 command
   grammar.

Use one exact domain separator, NUL framing, compact ordered canonical JSON,
exact built-in types, and lowercase SHA-256 output.

Freeze:

- exact ordered field inventory;
- exact field-to-owner mapping;
- exact domain;
- one fixed independent vector.

Do not include branch, result, relation/result self-digests, graph digest,
transaction timestamp, terminal outcome, raw credentials, or raw attestations.

## H2-B. Remove placeholder command digests

No positive family, selector, result, relation, receipt, replay, or recovery
fixture may use `"cd"*32`, an arbitrary digest, or a digest supplied by the
same builder being checked.

Every downstream value that carries or binds the command digest must receive
the independently recomputed canonical digest from the fixed command vector.

For every primitive and every sibling coordinate:

- mutate it independently;
- recompute the six siblings where appropriate;
- require the command digest to change;
- require the selector/family old digest to reject;
- require the newly recomputed valid command to remain internally coherent.

A command-digest test must execute the actual canonical digest function used by
all positive fixtures.

## H2-C. Command-to-selector and command-to-family binding

The complete-family selector must bind exactly to the command:

- lineage;
- scope;
- admission fact ref/digest;
- mutation ref;
- all preassigned family identities;
- deterministic family route;
- canonical command digest.

Each selector top-level coordinate must equal the command’s corresponding
coordinate. Each concrete route key must equal the bound selector coordinate.

The guarded relation, guarded result, generic result/receipt family, and replay
projection must bind the same command digest where their selected grammar
requires it.

Changing selector lineage and its route key together while leaving the command
unchanged must fail. Changing selector, route, and a caller-supplied arbitrary
command digest together must also fail because the digest is recomputed from the
closed command.

Do not add SQL selectors or reader layout.

# Finding M1 — source-exact current v1 receipt algebra

The private verifier must prove current v1 receipt/graph semantics itself, not
only rely on an unrelated existing C2B2 test.

## M1-A. Independent sentinel reconstruction

In the external clone, construct one current v1 receipt/preimage object and
graph-entry family with unique sentinel values for every field.

Independently compute the expected canonical graph preimage from a fixed
source-derived field/value mapping:

- all 18 receipt preimage fields in exact order and with exact values;
- each graph entry’s exact `role`, `ordinal`, `record_ref`, and
  `record_digest`;
- current domain separator and canonicalization.

Call the real current `_receipt_graph_identity` path or the exact public/private
constructor that owns the same computation.

Require byte-for-byte/digest equality with the independent expected preimage.

## M1-B. Source mapping and constructor causality

The verifier must detect, within its own module:

- `committed_at` mapped to `None` or another field;
- any other receipt preimage field mapped to the wrong attribute;
- graph-entry field order or attribute mapping changed;
- graph entries reordered contrary to current semantics;
- domain changed;
- `mutation_graph_digest` incorrectly included in its own preimage;
- invented receipt self-digest or profile field.

Do not merely compare AST key names. Observe unique sentinel values through the
real current function and compare to an independently encoded expectation.

# Finding H3 — actual C2 return-value and fresh-posture causality

## H3-A. Remove expected-branch dataflow from family formation

The private branch/family path may accept an input basis or scenario ID, but it
must not accept an expected branch parameter that can form the family.

Execution order must be:

1. validate fixed admission and command binding;
2. validate explicit fresh continuity and sole-active posture supplied by the
   caller of the test path;
3. call the exact shared C2 interpreter;
4. read its returned authoritative branch;
5. validate the prospective fact coordinate;
6. pass that returned branch—without substitution—to family construction.

No default `True` posture values are allowed.

The family result must expose the branch it actually used so tests can compare
it to the shared C2 return.

## H3-B. Return-value sentinel

Patch the exact callable reference used by the private path with a wrapper that:

- records entry;
- invokes the original shared C2 interpreter;
- returns a copy whose branch is deliberately changed to a different valid
  branch while preserving the required return grammar.

Require:

- valid admission reaches the wrapper exactly once;
- the family is formed under the wrapper-returned branch;
- branch-specific fact and role membership follows that returned branch;
- no expected test parameter or fixed branch constant overrides it.

A second mutant must leave a reachable shared call in place, discard its return,
and use a copied/fixed branch. It must fail at an exact dataflow boundary.

Patch and observe the actual runtime reference used by the path, not an unused
defining-module attribute.

## H3-C. Fresh posture causality

The private path must require explicit current continuity and sole-active
posture values. Test:

- valid fresh posture: shared C2 called once;
- missing, stale, unknown, conflicting, or false posture: shared C2 called zero
  times;
- historical retained basis without fresh posture: zero calls;
- current posture fields are not persisted as standing permission.

# Finding H4 — reconstruct canonical branch families

The V4 verifier’s placeholder decision/version/head/relation/result digests must
be removed from positive family, acceptance, role, graph, selector, replay, and
recovery fixtures.

## H4-A. Independent fixed family input vector

Define one fixed family input vector independent from all builders. It must
include exact canonical literals for:

- program and current head basis;
- mutation and command relation;
- verified admission act/fact;
- historical continuity and sole-active evidence;
- one transaction timestamp;
- decision basis/currentness inputs sufficient to derive all five branches.

Its expected current-v1 refs/digests must not be generated by the builder under
test.

## H4-B. Current canonical v1 members

Using unchanged current source constructors and digest owners in the external
clone, reconstruct for each branch:

- canonical development decision with the exact branch-dependent decision kind
  and variant;
- canonical resulting program version;
- canonical historical program-head postimage;
- exact generic v1 result projection required by the selected contract;
- exact generic receipt preimage and final receipt row.

Use the actual source-derived refs, field values, and digests.

Do not hard-code placeholder member digests.

## H4-C. Target supplemental members

Independently construct and validate:

- verified admission act;
- immutable admission fact;
- historical continuity basis;
- historical sole-active basis;
- guarded family relation;
- guarded progression result with fixed profile ID and authoritative branch;
- acceptance fact only on acceptance.

Every target member must bind the actual current-v1 members and the real
canonical command digest.

A wrong value followed by recomputing every downstream target digest must still
fail against the independently reconstructed canonical member.

## H4-D. Static profile and complete graph roles

Create separately authored fixed constants for:

- profile ID/version;
- ten common roles and ordinals;
- acceptance-only role and ordinal;
- per-role expected schema/type.

Do not alias the machine profile inventory or the family builder.

For each branch:

- build actual member values and digests;
- build the exact graph entries from those members;
- acceptance has ten common roles plus acceptance fact;
- each nonaccept has exactly ten common roles;
- reconstruct current v1 graph digest and receipt;
- verify guarded result profile ID/branch before crediting completeness.

A joint change to machine profile, family builder, and role helper must still
fail the fixed profile oracle or unchanged owner anchor.

Mutate same-typed foreign members, branch-dependent decision kind/variant,
ref-only and digest-only substitutions, reordered entries, and fully resealed
families.

# Finding H5 — owner-anchored normative clause agreement

The private contract is subordinate to unchanged guard and decision owners.
Use those unchanged files as independent semantic anchors.

## H5-A. Clause owner anchors

For every tagged private normative clause, add exact machine metadata:

- `clause_id`;
- fixed semantic tuple;
- owning document path;
- stable owner section/marker;
- owner semantic class.

The verifier must parse the unchanged owner document at that stable marker and
independently derive or verify the anchored semantic tuple.

Do not use absolute line numbers as authority.

At minimum anchor:

- admission and writer separation;
- branch nonselection by prospective fact coordinate;
- current posture requirement;
- local-absence nonauthority;
- exact replay creates no fact or timestamp;
- one receipt/replay/recovery owner;
- nonaccept retains collision coverage;
- terminal and ES non-replenishment.

Changing private tagged prose and private test literals together must still fail
the unchanged owner anchor.

## H5-B. Bounded visible-Markdown parser

Continue to parse headings, paragraphs, blockquotes, bullets and continuations,
tables/cells, and link labels outside fenced code and machine JSON.

Use exact closed phrase/grammar support for:

### Subjects

Include exact aliases, not substring matches, for at least:

- replay;
- replay adapter;
- exact replay;
- prospective acceptance coordinate;
- reserved acceptance-fact coordinate;
- command relation;
- local row absence;
- historical continuity basis;
- current continuity posture;
- nonaccept branch;
- terminal outcome;
- ES routing.

Do not treat neutral compounds such as `replay glossary` as the subject
`replay`.

### Modality and authority

Include at least:

- may;
- might;
- must;
- shall;
- can;
- could;
- is permitted to;
- is allowed to;
- is authorized to;
- is sufficient to;
- may not;
- must not;
- cannot.

### Protected actions and objects

Include exact create/refresh/admit/select/skip/replenish/authorize/prove
constructions over:

- acceptance fact;
- receipt;
- timestamp;
- scope;
- noncommit;
- current permission;
- acceptance allowance;
- collision route.

Maintain bounded subject context across adjacent sentences within one visible
block so this fails:

```text
Replay is authorized. It creates a new acceptance fact.
```

Support bounded pronoun resolution only for the immediately preceding protected
subject in the same block.

## H5-C. Four-way agreement

Require exact agreement among four independently obtained representations:

1. fixed test expectation;
2. unchanged owner-anchor semantics;
3. private machine clause tuple;
4. parsed tagged private prose.

No one representation may generate another.

Untagged authority-sensitive assertions fail. Neutral explanatory prose must
pass.

Permanent and transformed controls must cover:

- `Replay might create a new fact.`
- `A replay adapter may create a second receipt.`
- two-sentence authorization/creation;
- contradictory heading, bullet, table, quote, and link label;
- modal synonyms;
- subject aliases;
- registry, prose, and test-literal joint mutation;
- neutral `The replay glossary may include the term timestamp.`

# Required conditional recovery and canonical-family controls

Add permanent tests for:

- all five branch-expanded DAGs;
- relation raw-input dependency closure;
- nonaccept absence of acceptance nodes;
- acceptance-only edges;
- exact recovery observation set;
- every route observation status;
- total absence with and without fresh posture;
- partial, duplicate, malformed, foreign, unreadable, and unchecked routes;
- selector/command/family binding;
- same mutation/different command;
- every preassigned identity collision;
- family-route collision;
- competing complete scope winner;
- exact replay preserving canonical family bytes and transaction timestamp.

The test module may model finite private values and query grammar. It must not
implement SQLite reads, writes, transactions, or a second decision/recovery
owner.

# Required transformed external copies

Execute at minimum the following transformed categories in disposable external
clones. Every copy must retain the final expected private-test collection and
fail at the intended exact boundary.

## Conditional dependency graph

1. omit `authoritative_branch` from relation dependencies;
2. omit raw historical-head value from relation dependencies;
3. leave acceptance digest as a common nonaccept dependency;
4. remove acceptance dependency from acceptance relation;
5. remove acceptance graph-entry dependency on acceptance;
6. hide optional dependency in an aggregate;
7. omit recovery observation set;
8. omit one route observation from recovery;
9. classify unreadable route as absent;
10. permit total absence without fresh posture;
11. add an undeclared relation field with no dependency;
12. introduce a branch-specific stage inversion.

## Command digest and selector binding

13. remove each primitive from canonical command digest, one at a time;
14. remove each sibling from canonical command digest, one at a time;
15. replace real digest with fixed `"cd"*32`;
16. mutate primitive while retaining old command digest;
17. mutate selector lineage and route key together;
18. mutate selector and arbitrary command digest together;
19. selector uses foreign admission digest;
20. selector uses foreign family route;
21. route keys are self-consistent but not command-bound.

## Current source-exact graph

22. source maps `committed_at` to `None`;
23. source maps one receipt field to another same-type field;
24. source changes graph-entry field order;
25. source changes graph-entry value mapping;
26. source includes `mutation_graph_digest` in its own preimage;
27. source changes receipt domain;
28. source invents receipt self-digest.

## C2 return causality and posture

29. shared C2 called but return branch discarded;
30. family uses fixed expected branch;
31. wrapper returns alternate valid branch but family ignores it;
32. invalid admission enters C2;
33. stale current posture enters C2;
34. posture defaults to true when omitted;
35. prospective coordinate influences C2 branch input;
36. unreachable shared call remains while copied reducer controls family.

## Canonical family and profile

37. placeholder decision digest;
38. placeholder version digest;
39. placeholder head digest;
40. wrong branch-dependent decision kind/variant;
41. foreign scope with all downstream target digests resealed;
42. foreign lineage resealed;
43. wrong head revision, including bool;
44. wrong head digest resealed;
45. wrong command digest resealed;
46. guarded result profile ID changed jointly in machine and builder;
47. common-role substitution changed jointly in machine and builder;
48. omit one common role;
49. duplicate one common role;
50. same-typed foreign member under a correct role;
51. correct ref with another role’s digest;
52. acceptance role on nonaccept;
53. acceptance fact missing on acceptance;
54. graph entries and receipt jointly resealed over wrong members.

## Normative semantics

55. replay `might` create a fact;
56. replay adapter may create a second receipt;
57. replay authorized in one sentence and creates fact in the next;
58. historical basis sufficient for current permission;
59. local absence proves noncommit;
60. command relation admits/selects scope;
61. nonaccept skips route;
62. terminal replenishes allowance;
63. ES routing replenishes allowance;
64. tagged prose and private test literals changed together;
65. private machine tuple and prose changed together;
66. owner anchor removed or changed;
67. contradictory heading/bullet/table/quote/link-label variants;
68. neutral replay-glossary sentence.

No mutant receives credit for syntax, import, format, or collection shrinkage.

# Test architecture requirements

Preserve:

- recursive duplicate-key rejection;
- exact built-in type comparison, including bool/int separation;
- fixed test expectations independent from the private machine block;
- current-source-derived v1 facts;
- one logical result/receipt/replay/recovery owner;
- no broad source manifest;
- no physical schema emulator;
- no second reducer;
- no file-hash-only correctness claim.

Separate and report:

1. permanent internal negative controls;
2. actual transformed external copies;
3. ordinary regression validation.

# Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution and report exact counts.

Run:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening V4 reference: `427 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contract modules
   - reference: `1,623 passed`.

3. Specified B1, C2B2 values, and migration-0002 modules
   - reference: `458 passed`.

4. Operating-model, architecture, and runtime modules
   - reference: `77 passed`.

5. Broad:
   `tests/test_rw0_*.py tests/test_c2b*.py tests/test_sqlite_c2b*.py tests/test_sqlite_rw0*.py`
   - opening V4 reference: `4,430 passed`.

6. Complete repository
   - opening V4 reference: `8,244 passed, 3 warnings`.

The full-suite increase may equal only the exact new contract-test nodes.

The only accepted warnings remain the unchanged Python 3.13
multithreaded-`fork()` warnings from existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact six-path ceiling;
- proof the other four candidate documents remain byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- exact live-cache opening/closing member equality;
- removal of all engagement-created temporary data.

# Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning setting;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact two-file V4-to-V5 transition;
6. proof the other four candidate paths stayed byte-identical;
7. five branch-expanded DAG summaries and final node/edge counts;
8. exact relation raw-input dependency closure;
9. recovery observation-set and projection grammar;
10. canonical command-digest algorithm and fixed vector;
11. command-selector-family binding;
12. source-exact v1 sentinel reconstruction;
13. admission/current-posture-before-C2 and actual return-value causality;
14. canonical five-branch current-v1 and target-family reconstruction;
15. static profile and complete receipt-role verification;
16. owner-anchored normative-clause agreement;
17. disposition of every V4 audit finding;
18. permanent controls versus transformed external copies;
19. exact collection and validation results;
20. source/migration/public/runtime preservation;
21. deterministic final six-path patch bytes and SHA-256;
22. fully specified final canonical receipt grammar, bytes, and SHA-256;
23. live-cache equality and cleanup;
24. remaining physical seams;
25. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

# Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the two-file ceiling is insufficient;
- another owner document must change;
- current v1 source contradicts the selected canonical-family reconstruction;
- branch-expanded dependencies cannot be made complete without a second logical
  receipt/recovery owner;
- the actual shared C2 return cannot be made causal without copying or changing
  the C2 owner;
- canonical family reconstruction requires source or migration changes;
- owner-anchored normative agreement cannot be expressed without changing an
  owner document;
- source, migration, export, or existing test changes are required.

Restore the exact opening V4 candidate under a blocking result.

# Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_REPAIRED_V5_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V5_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

# Required non-actions

State:

```text
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_NOT_MOVED_OR_MODIFIED
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
