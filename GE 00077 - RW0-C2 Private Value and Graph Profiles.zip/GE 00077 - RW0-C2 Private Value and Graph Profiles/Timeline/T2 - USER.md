Here is Codex's response:

Model name shown by the interface: **not visible**.  
Reasoning setting or effort shown by the interface: **not visible**. I cannot verify the requested setting from the visible interface.

# RW0-C2 immutable bootstrap guard: physical and value architecture reconnaissance

## 1. Primary disposition

**Architecture ready for contract freeze.** The narrowest supported recommendation is a **bounded hybrid**: retain migration-0002 decision, version, head, and receipt records as canonical within their current meanings; add immutable admission and guarded-decision relations through a later additive migration. Give admission provisioning and guarded decision persistence separate semantic owners, while using the existing Coordinator mutation infrastructure. This is an **inference and recommendation**, not implemented behavior or an accepted SQL design. The required disposition token appears once, at the end.

## 2. Opening and closing Git coordinates

Opening and closing coordinates matched:

| Check | Observed value |
| --- | --- |
| Branch | `trunk_dev` |
| HEAD | `3d99e448bfe577b5a5878dd32b7e01b61322e7df` |
| Tree | `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3` |
| Sole parent | `6f11d6b0b6f38995123434945d86db0b169bb8f8` |
| Subject | `docs: adopt RW0-C2 bootstrap acceptance guard` |
| Upstream and divergence | `origin/trunk_dev`; 0 ahead, 0 behind |
| Worktrees | Exactly one |
| Tracked, untracked, staged, unmerged | Clean |
| Merge, rebase, cherry-pick, revert, bisect, sequencer, index lock | Absent |

These are local Git observations. No remote was contacted.

## 3. Inspection scope and limits

I independently inspected the merged guard and decision owners, composition record, historical C2B successor, migration catalog and SQL, v1 decision/result/receipt values, graph digest, head values, controller, C1 recovery precedent, and structural nonimplementation guards. Three bounded read-only explorers covered value/authority, physical schema, and transaction/recovery questions; none delegated further. Their conclusions agree on the owner split, bounded hybrid, and need for external continuity proof.

Of 68 specifically named paths, 67 existed and were read as text. The requested `tests/test_sqlite_transition_transaction.py` does not exist in this tree; its transaction-owner test edges are in `tests/test_b3c4b_private_atomic_transition_persistence.py` and `tests/test_b3c1b_rollback_only_writer_fencing.py` (`tests/test_b3c4b_private_atomic_transition_persistence.py:1728`; `tests/test_b3c1b_rollback_only_writer_fencing.py:2180`). One initial tool-orchestration syntax error was retried successfully before repository inspection. Some large outputs were truncated and reread in bounded ranges. I did not exhaustively trace the historical examples embedded in the roughly 25,000-line C2B document; its governing current successor was inspected at `.docs/c2b-durable-development-state.md:24879-24928`. Databases, ignored bytecode contents, sibling repositories, and live external authority systems were not inspected.

## 4. Current implementation and accepted target

**Current implemented contract:** RW0-C1 privately persists phase and supplied-evidence facts through the existing mutation controller. The package catalog ends at migration 0004, application generation 2. Migration 0002 physically owns generic development decision, version, head, and receipt rows. Private post-execution projections and input values exist, but there is no RW0-C2 durable command, guard provisioner, acceptance fact, writer, recovery path, terminal owner, production caller, or public export (`.docs/autonomous-software-development-operating-model.md:43-79,81-89`; `.docs/architecture.md:49-74`; `src/ge_nwp_coordinator/sqlite_migration.py:388-429`; `tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:611-623`).

**Accepted target contract:** One immutable admitted scope belongs to one standing-policy-admitted Coordinator lineage. Positive continuity and one active authority are required. At most one distinct productive direct-local `candidate_acceptance` may commit across programs. That acceptance creates an immutable member of the same decision/version/head/result/receipt family, with one replay owner and one whole-family recovery classifier. Four nonaccept branches create no acceptance fact. The B1 latch-named pair is only a compatibility representation (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:23-49,62-108,121-135`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:447-476`).

## 5. Fact and authority ownership matrix

“External required” means a local digest or SQLite row cannot independently prove the stated external fact. Proposed rows below are **recommendations for the reopened physical seam**.

| Fact | Status; authority and writer | Verifier; physical source | External required; replay and recovery | Prohibited substitute |
| --- | --- | --- | --- | --- |
| Standing-policy admission act | Accepted target; external standing policy authors it | External policy verifier; external source, exact mechanism unselected | Yes; external policy governs its own history | Caller, model, Coordinator, grant digest |
| Lineage continuity and sole-active claim | Accepted target; authoritative external operational/policy evidence, exact issuer unselected | Currentness verifier composed with Coordinator fence; external source | Yes on command and recovery; cannot replay an old claim as current | Machine, process, DB identity, local lock, row absence |
| Local writer issuance/session | Current implemented; Coordinator writer resource | Existing transaction fence; `writer_ownership` plus live private proof and lock | No lineage proof; local session lifecycle, not guard replay | Copied writer row or matching `Protocol` object |
| RW0-C1 evidence family | Current implemented; RW0-C1 guarded writer | C1 private readers and recovery; migration 0004 | Source authenticity still external; C1 replay/recovery only | C2 acceptance or completeness proof |
| Scope-admission fact | Accepted target, unimplemented; separate provisioner records verified policy act | New private row verifier; proposed migration 0005 | Yes for act and continuity; own provisioning replay/recovery | Decision writer, schema install, empty DB |
| Guarded command relation and retained basis | Accepted target, unimplemented; decision owner constructs from caller expectation and verified facts | New private relation verifier; proposed supplemental immutable relation | Yes for live posture; decision owner replay/recovery | Caller-authored admission or branch |
| Development decision | Current generic physical owner, future guarded C2 use; guarded decision writer | Current v1 row adapter plus future family verifier; migration 0002 | Yes for required external basis; decision owner replay/recovery | Report or model output |
| Program version | Current generic physical owner, future guarded C2 use; guarded decision writer | Current v1 row adapter; migration 0002 | Basis as required; decision owner replay/recovery | Mutable current head alone |
| Program head postimage/current head | Current mutable generic owner, future guarded C2 CAS; guarded decision writer | Current head row plus exact historical postimage proof; migration 0002 | Basis as required; decision owner replay/recovery | Historical replay tested against a later current head |
| Bootstrap-acceptance fact | Accepted target, unimplemented; **guarded decision writer only** | New immutable row and full-family verifier; proposed migration 0005 | Yes for lineage continuity; decision owner replay/recovery | Separate latch, terminal fact, C1 evidence |
| Result and mutation receipt | Current v1 generic physical owner; future guarded composite owned by decision writer | V1 projection/receipt plus required successor relation and exact graph verifier | Decision owner, one logical replay and recovery | Bare graph digest or separate guard receipt |
| Terminal outcome | Later separate target owner; writer and storage unselected | Later terminal verifier | Binds committed acceptance family; separate later replay/recovery unselected | Creation, reset, or repair of guard fact |

Current writer and C1 boundaries: `.docs/writer-session-authority.md:134-163,375-399`; `.docs/rw0-c1-durable-evidence.md:162-217`. Generic rows and closed receipt: `src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:1-30,475-566`. Target split: `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:11-21,43-49,73-108,110-129`.

## 6. Selected logical private-value families

The names here describe **private logical values**, not public DTOs or frozen class names. The guard owner supplies admission, scope, and ceiling semantics; the decision owner supplies command, result, receipt, replay, and whole-family recovery semantics (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:11-21`).

| Proposed value or relation | Form, authority, and family | Identity/digest dependencies; command and recovery coverage |
| --- | --- | --- |
| Admission-act safe evidence | External evidence for the admission-provisioning family. Carries an authenticated act identity and safe provenance, not execution permission | Act ref/digest and policy-authored lineage/scope/applicability feed admission fact. The act itself is independently verified; caller expectations, rather than raw act contents, enter the decision command digest |
| Immutable scope-admission fact | New durable fact, provisioner-only. Records exactly the admitted binding, never current permission | Domain-separated identity from canonical guard profile, lineage, scope, and verified act ref/digest; uniqueness by lineage and scope. Its ref/digest is resolved into command expectation and recovery coordinates |
| Admitted-lineage/scope command relation | New private non-authoritative expectation for every applicable command; guarded-decision family | Canonical admitted lineage, scope expectation, admission ref/digest, deterministic family route. Covered by command digest and complete-family recovery selector; cannot choose or admit a scope |
| Continuity evidence | External current evidence and transient verified posture; safe historical basis reference may be retained | Binds admitted lineage, scope, continuity point and currentness. The command covers its expectations, not a caller-authored conclusion; recovery requires fresh positive continuity proof |
| Sole-active evidence | External current attestation composed with local writer fencing; no independent Coordinator standing authority | Binds the same lineage/scope and current authority epoch. Its current observation is checked before receipt disclosure and again for recovery; an old snapshot cannot establish present sole-active posture |
| Acceptance fact | New immutable durable guarded-decision member, only on derived `candidate_acceptance` | Fifteen accepted roles include admission, mutation, command digest, decision/version/head, attempt/candidate, immutable basis, route and one timestamp. Digest follows decision/version/head and precedes result/receipt |
| Acceptance-family relation | New immutable supplemental relation, or a required role in one versioned composite; guarded-decision family | Binds fact ref/digest (null on four nonaccept branches), exact generic rows, historical head postimage, basis and route. Required by the family reader and receipt graph; it has no separate receipt or transaction |
| Guarded result projection | Successor private composite over unchanged generic v1 result plus supplemental guarded relation; guarded-decision family | Depends on exact decision/version/head and optional acceptance fact. The v1 projection retains its original digest meaning |
| Single receipt and replay projection | Reuse the generic v1 receipt as the receipt root, with a versioned required graph profile and supplemental member; replay is a projection of verified durable rows | Receipt graph must cover exact required members, including acceptance when present. Exact replay returns original timestamp, fact and result without reevaluation |
| Complete-family recovery selector/result | New private decision-owned selector and three-way projection, not durable authority | Selector binds command-covered lineage/scope/admission expectation and preassigned mutation, decision, version, fact and route identities; it excludes transaction timestamp and postcommit digests. Readback yields only `committed_exact`, `definitely_not_committed`, or `unresolved` |

The accepted role and DAG inventories are at `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:173-201`; command and selector coverage is at lines 51-60 and 82-108. The exact physical value schemas and digest domains beyond current v1 remain **unselected**.

## 7. Physical owner split

**Selected recommendation: two semantic owners.** A separate provisioner verifies and records the policy-authored immutable admission fact, potentially before any development program exists. The guarded decision writer reads that fact and writes the acceptance fact with its decision family; it cannot provision or repair admission. Both may use the existing migration catalog, operation lease, local writer session, nominal capability, and transaction controller, with separate private transaction entries and result grammars. Shared machinery is not shared semantic authority (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:43-49,73-80`; `.docs/c2b-durable-development-state.md:77-91`; `src/ge_nwp_coordinator/sqlite_transition_transaction.py:1976-2007`).

A combined semantic owner would make admission creation reachable from the decision path. A separate guard database/controller would introduce another authority and commit boundary. A terminal writer cannot supply acceptance truth because terminal recording is later and non-mutating (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:110-119`).

## 8. Migration decision and rejected alternatives

**Recommend a bounded additive migration 0005**, after its contracts are frozen. Keep migration 0002 unchanged; add only the missing immutable admission, guarded-family relation/result, acceptance fact, and lookup/uniqueness machinery. At minimum, the physical freeze must require one admitted scope per lineage, one immutable acceptance fact per scope across programs, identity and route collision probes, append-only guards, FK/coherence checks, and exact graph/readback validation. Local uniqueness is necessary but does not prove global continuity across copies. The exact SQL, index inventory, migration compatibility bounds, and application-generation treatment remain for that freeze (`.docs/rw0-c2-durable-progression-decision-semantic-contract.md:490-510`; `.docs/c2b2-migration-0002.md:13-38`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:131-135`).

- **Migration-free reuse fails:** current keys are program or mutation scoped; there is no admitted lineage/scope row, acceptance fact, or cross-program scope key. The v1 result and receipt cannot directly name the fact (`src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:1-30,475-566`; `src/ge_nwp_coordinator/_development_decision_row_values.py:436-455,873-891`).
- **A separate replacement decision store fails:** it duplicates canonical decision/version/head/receipt truth selected by the C2 decision owner (`.docs/rw0-c2-durable-progression-decision-semantic-contract.md:23-28,490-496`).
- **A mutable latch fails:** the merged guard explicitly supersedes it, including its separate state, revision, receipt, and classifier (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:5-7,307-311`).

## 9. Migration-0002 reuse matrix

| Current surface | Classification | Exact boundary |
| --- | --- | --- |
| `development_decisions` | Reuse unchanged, with successor guarded relation | Closed v1 candidate-acceptance branch and globally unique `mutation_ref`; no lineage, scope, admission, or fact field (`0002_development_program_and_effect_state.sql:475-535`) |
| `development_program_versions` | Reuse unchanged | Immutable program-scoped version and creating-decision link (`0002_development_program_and_effect_state.sql:14-30`) |
| `development_program_heads` | Reuse unchanged as mutable current truth; prove historical postimage separately | Keyed by `program_ref`; historical replay cannot demand that later current head remain fresh (`0002_development_program_and_effect_state.sql:1-12`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:99-101`) |
| `development_mutation_receipts` | Reuse unchanged as generic receipt root; supplement through 0005 | Fixed five-family v1 scalar/result grammar, no fact ref/digest (`0002_development_program_and_effect_state.sql:537-567`; `_development_decision_row_values.py:772-891`) |
| V1 progression result projection | Reuse unchanged only as generic component | Identity contains program, decision and version refs; adding fact fields would change its v1 digest meaning (`_development_decision_row_values.py:436-455,873-888`) |
| Supplied mutation-graph digest primitive | Reuse unchanged, add a family-specific required-role verifier | It can hash a fact entry, but proves no role validity, existence, completeness, replay or recovery (`_development_decision_row_values.py:952-1038`; `.docs/c2b2-pure-durable-row-values.md:141-149`) |
| Twelve private readers and 24 query specs | Reuse current roles; add separate bounded guard/family readers | Existing receipt reader does not locate or prove a graph (`.docs/c2b2-private-readers.md:47-115,177-180`) |
| RW0-C1 migration-0004 rows/recovery | Historical implementation precedent only | C1 proves supplied-evidence family mechanics, not C2 acceptance or completeness (`.docs/rw0-c1-durable-evidence.md:162-217`) |
| B1 `latch_postimage_*` pair | Bounded compatibility edge only | Pair/coherence validation, no durable guard proof (`.docs/rw0-b1-pure-phase-values.md:425-440`) |
| Shared controller/session/migration framework | Reuse mechanism with new private entries and catalog suffix | No second controller, public API, or lazy migration (`.docs/writer-session-authority.md:375-399`; `.docs/sqlite-bootstrap-and-migrations.md:27-37`) |
| Older C2B mutable latch and migration allocation | Historical/proof precursor only | Explicitly superseded for this guard seam (`.docs/c2b-durable-development-state.md:24900-24926`) |

The current supplied graph digest can bind a **versioned guarded result/family relation** and acceptance fact while leaving the v1 receipt row unchanged. That relation must have an acyclic digest independent of the receipt’s final graph digest; the receipt graph can then bind it. This yields one logical result and receipt, assembled from exact physical members. It is a recommended physical profile, not a claim that the current v1 reader already verifies it.

## 10. Admission provisioning architecture

**Recommendation:** provision one scope from an independently verified, immutable standing-policy admission act. The act must specify the canonical Coordinator authority lineage, distinct bootstrap scope, guard owner profile, bounded direct-local applicability, provenance and permanent one-shot ceiling. A canonical domain-separated admission-fact identity should bind those roles and the act identity/digest; unique lineage and scope keys prohibit a second distinct admission. Neither a new grant nor policy epoch changes that identity or allowance (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:23-49,173-177`).

Provisioning needs its **own private command, result, receipt, replay and readback-recovery family**, because it is a separate transaction that may precede a program, whereas the existing development receipt requires a `program_ref` and closed family grammar (`0002_development_program_and_effect_state.sql:537-566`). This is not an acceptance-guard latch receipt. An exact repeated act/command is idempotent and returns the original fact without a new timestamp; a different act for the same lineage or scope conflicts rather than renewing it. Missing, duplicate, foreign, stale, malformed, unreadable or conflicting evidence fails closed. The provisioner must verify the external act before recording, and must not derive admission from schema installation, an empty database, a copied row, or local absence. Independent lineages require distinct explicit acts and scopes. The external act verifier and its transport remain **unselected**, so this is an architecture freeze candidate, not a usable workflow.

## 11. Continuity and sole-active authority

**Accepted:** local row absence is never proof of an unclaimed scope; replacement, restore, rollback, clone and relocation do not create an allowance. One active authority per lineage is required (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:25-41`).

**Recommended composition:** immutable admission and acceptance are Coordinator durable facts; lineage-continuity and sole-active evidence are independently sourced, current, and verified at the command boundary; the existing WriterSession then fences the selected local database/process. A safe snapshot of the verified basis may be retained for historical family proof, but cannot substitute for a fresh current claim on replay or recovery. The current lock, proof, generation and filesystem binding fence one local state location, not active-active clones (`.docs/writer-session-authority.md:134-163,375-399`; `.docs/sqlite-threat-model.md:240-250,296-302`).

An external continuity contract must positively establish the authoritative lineage history across transfers and show that a restored or rolled-back copy has not lost a possible committed acceptance. It must also fence competing active realizations. If that proof is missing after a crash or transfer, fresh acceptance remains blocked; the system cannot interpret an empty restored table as a fresh allowance. The exact issuer, epoch/currentness protocol, transfer evidence, and recovery witness are **unselected engineering contracts**. A copied database or a passive backup is evidence, never the lineage authority. The existing restore checklist addresses database validation, not this C2 lineage proof (`.docs/sqlite-operations-and-recovery.md:463-479`).

## 12. Atomic acceptance family and transaction owner

**Recommended family:** one preassigned `mutation_ref`, decision ref, resulting version ref, acceptance-fact ref for a possible acceptance, admitted scope expectation, and deterministic family route. The command digest covers those expectations and excludes the later transaction timestamp or postcommit projections. The acyclic order is policy act → admission fact → command expectation/digest → decision/version/historical head postimage → acceptance fact (only for acceptance) → guarded result relation → single receipt graph → replay/recovery projection (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:73-86,191-201`).

The private decision entry should perform: exact local preflight; operation lease and mutation slot; bound connection and `BEGIN IMMEDIATE`; managed-state and writer fencing; **universal** lineage/admission/continuity/sole-active/no-foreign check before receipt disclosure; receipt-first same-command replay or collision; fresh basis/current-head checks; one reducer evaluation; acceptance-only exhaustive scope-family read; one timestamp and family construction; decision/version/fact/relation inserts and program-head CAS; receipt-last insert and complete in-transaction readback; capability invalidation; one commit attempt. Any commit-attempt uncertainty uses the **single decision-family** readback classifier, not a guard transaction or automatic retry (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:88-108`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:339-375,418-445`; `src/ge_nwp_coordinator/sqlite_transition_transaction.py:1976-2007,2341-2405`; `.docs/rw0-c1-durable-evidence.md:162-210`).

The controller owns transaction, capability, fence, commit and close resolution. The writer session owns guarded operation entry and resource lifecycle. The pure reducer selects a branch from validated evidence; it does not admit scope, author facts, inspect SQLite, commit, or resolve uncertainty. An exact historical head postimage must be recoverable after the mutable current head advances. The current head identity fields permit a proposed deterministic derivation from decision/version, expected revision, state mapping and single timestamp, but that derivation and graph equality need explicit contract proof before selecting it over an immutable supplemental snapshot (`_development_program_row_values.py:243-273`; `_development_program_initialization_contracts.py:815-855`).

## 13. Replay, collision and whole-family recovery

| Observation | Fresh/replay classification | Recovery implication |
| --- | --- | --- |
| Same mutation, same command and complete exact family | Exact replay after universal posture check; no reducer, new fact or timestamp | `committed_exact` |
| Same mutation, different command digest | `mutation_ref_reuse_conflict` | Collision is not definite absence |
| Preassigned identity or family-route collision | `preassigned_identity_or_family_route_collision` | Fragment/alias route makes original outcome `unresolved` unless exhaustive absence is independently proved |
| Different complete winner in same scope | `bootstrap_acceptance_guard_conflict`; no fresh acceptance | Original family may be `definitely_not_committed` if all its own routes are absent; retry remains ineligible |
| Entire original new family absent with exact prerequisites and no alias/read fault | Fresh eligibility is a separate question | `definitely_not_committed` |
| Decision without required fact, or fact without decision | No-write guard/integrity failure | `unresolved` |
| Duplicate, malformed, foreign or unreadable fact/family | Fail closed | `unresolved` after commit uncertainty |
| Restore or clone with unproved continuity/sole-active posture | `bootstrap_acceptance_guard_conflict` | `unresolved`; local absence is insufficient |

These outcomes follow the accepted taxonomy and classifier (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:62-71,99-108,223-272`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:427-476`).

The read set must locate the exact admission/provisioning family, current external continuity and active-authority evidence, receipt by mutation, decision/version, historical head postimage proof, required guarded basis/result relation, acceptance fact by scope **and** ref/digest/decision/mutation/route, and independent alias/collision routes. A receipt-present path must reconstruct all expected immutable members and graph roles. A receipt-absent path must prove every original new-member route absent and prerequisites exact. Existing C1 readback demonstrates bounded independent ref/digest and relation probes, but is precedent rather than C2 authority (`.docs/rw0-c1-durable-evidence.md:219-244`; `src/ge_nwp_coordinator/_sqlite_rw0_c1.py:4651-4790`). Recovery never repairs a fragment, reevaluates the branch, changes timestamp, renews scope, or retries after `unresolved`.

## 14. B1 compatibility and safe-value versioning

The exact v1 `latch_postimage_ref`/`latch_postimage_digest` names, order, nullability, schema, bytes, domain and budgets remain **current compatibility facts**. Their current source and contract validate supplied pair representation/coherence only; they prove no admission, uniqueness, commitment, family membership or recovery (`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py:746-765,1048-1073`; `.docs/rw0-b1-pure-phase-values.md:425-440`).

The guarded **decision writer should not consume this pair at all**. It therefore does not need a B1 source change as its prerequisite. A later terminal consumer that binds the pair to the committed acceptance fact needs the separately accepted B1 safe-value compatibility/versioning decision required by the guard owner (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:121-129`). Independently, a **C2 private value/versioning freeze is needed before decision persistence** because the fixed v1 progression result and receipt do not themselves prove the new member (`.docs/c2b2-pure-durable-row-values.md:126-149`).

## 15. Security and privacy placement

| Risk | Required boundary |
| --- | --- |
| Lineage theft, act substitution or admission forgery | Exact pure identity/digest checks; independent standing-policy authentication before provisioner write; immutable unique admission row; no caller-authored act conclusion |
| Cloned/restored active authorities or rollback replenishment | External current continuity/sole-active proof plus local writer fence; fail closed when lineage history is unprovable |
| Scope poisoning by a false fact | Provisioner/decision writers only; SQL uniqueness and append-only constraints; complete-family validation before treating any row as a winner; safe audit of conflicts |
| Receipt lookup disclosure to stale/foreign writer | Operation lease, `BEGIN IMMEDIATE`, durable writer fence and universal guard posture before receipt lookup |
| Partial family, aliases, collisions or corrupt rows | Exact private row adapters, independent route readers, complete graph proof and `unresolved` recovery; no repair |
| Sensitive policy or operational evidence | Persist only bounded safe identities, digests and provenance needed for verification; keep credentials, raw attestations and endpoints with their external owners |
| Database corruption | Existing migration/history/live-schema and integrity checks, plus later guard-family row/graph checks; quarantine without automatic repair |

The current backend explicitly limits its local lock/file guarantees and sanitizes errors (`.docs/sqlite-threat-model.md:238-266,296-332`; `.docs/sqlite-bootstrap-and-migrations.md:49-79`). Future audit tests should attack every boundary above, including cross-program acceptance, duplicate and orphan rows, forged act, stale witness, clone/restore, and failures after commit starts.

## 16. Contract-freeze tranche sequence

1. **Next exact tranche: private C2 safe-value/versioning contract.** Freeze closed command relation, admission/fact safe identities, guarded composite result and receipt-graph profile, selector grammar, digest DAG, v1 preservation, and B1 non-consumption. This prevents silent v1 repurposing before physical design.
2. **Admission and continuity physical contract.** Freeze act verification inputs, independent provisioner family, idempotency/recovery, positive lineage continuity, active-authority currentness, transfer/restore failure posture, and no-program provisioning. No standing-policy issuance system is selected.
3. **Bounded-hybrid migration-0005 contract.** Freeze exact additive rows, keys, indexes, immutable guards, FK/coherence checks, graph/membership profile, historical head proof, readers, zero-seed and migration compatibility. Retain 0001–0004 byte and meaning exact.
4. **Guarded decision transaction/replay/recovery contract.** Freeze one private controller entry, exact read/write order, family routes, receipt-first replay, one close/commit witness, three-way selector/read set, collision taxonomy and fault behavior.
5. **Later terminal safe-value contract.** Bind a later terminal value to exact committed decision/result/receipt and acceptance fact without mutating guard truth.

No source implementation is requested by this sequence. The C2 decision owner already identifies a later bounded-hybrid physical freeze, while the guard owner leaves physical representation unselected (`.docs/rw0-c2-durable-progression-decision-semantic-contract.md:490-510`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:131-135`).

## 17. Likely touched-file ceilings for those contract tranches

These are **proposed maximum contract-review surfaces**, not edits made or an implementation request. New document/test names are planning coordinates.

| Tranche | Exact likely file ceiling |
| --- | --- |
| 1, private values | `.docs/rw0-c2-private-value-versioning.md` (new); `.docs/rw0-b1-pure-phase-values.md`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`; `.docs/autonomous-software-development-operating-model.md`; `tests/test_rw0_c2_private_value_versioning_contract.py` (new). **6 files** |
| 2, admission/continuity | `.docs/rw0-c2-scope-admission-and-continuity-physical-contract.md` (new); `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`; `.docs/authority-boundaries.md`; `.docs/sqlite-threat-model.md`; `.docs/autonomous-software-development-operating-model.md`; `tests/test_rw0_c2_scope_admission_contract.py` (new). **6 files** |
| 3, bounded hybrid | `.docs/rw0-c2-bounded-hybrid-physical-contract.md` (new); `.docs/c2b-durable-development-state.md`; `.docs/c2b2-migration-0002.md`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`; `.docs/sqlite-bootstrap-and-migrations.md`; `.docs/autonomous-software-development-operating-model.md`; `tests/test_rw0_c2_bounded_hybrid_physical_contract.py` (new). **7 files** |
| 4, transaction/recovery | `.docs/rw0-c2-guarded-decision-transaction-contract.md` (new); `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`; `.docs/sqlite-operations-and-recovery.md`; `.docs/writer-session-authority.md`; `.docs/autonomous-software-development-operating-model.md`; `tests/test_rw0_c2_guarded_decision_transaction_contract.py` (new). **7 files** |
| 5, later terminal | `.docs/rw0-c2-terminal-value-binding.md` (new); `.docs/rw0-b1-pure-phase-values.md`; `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`; `.docs/rw0-remote-worker-contact-phase-entry.md`; `.docs/autonomous-software-development-operating-model.md`; `tests/test_rw0_c2_terminal_value_binding_contract.py` (new). **6 files** |

The older C2B body still states a mutable latch at `.docs/c2b-durable-development-state.md:138-152,640-663`, while its appended successor explicitly classifies that selection as historical and superseded (`.docs/c2b-durable-development-state.md:24900-24926`). Tranche 3 should make that routing easier to read without promoting the historical table into current physical authority.

## 18. Validation and independent-audit plan

| Tranche | Later validation | Independent audit question |
| --- | --- | --- |
| 1 | Closed value vectors, digest DAG, v1 byte/schema preservation, B1 pair non-proof, no public/source widening | Can any v1 field or supplied graph digest silently acquire guard authority? |
| 2 | Exact/missing/duplicate/foreign/stale act cases; provision-before-program; replay, uncertain recovery and clone/restore fail-closed cases | Can the decision path create admission, or can an old/copy authority appear active? |
| 3 | Exact catalog/history/schema checks, legacy migration checksums, zero seed, cross-program unique fact, append-only/FK and alias/fragment probes | Does every physical acceptance route resolve to exactly one admitted scope and one family? |
| 4 | Ordered fence-before-receipt tests, reducer-once, all five branches, receipt-first replay, CAS, one commit, every commit/cleanup fault, exhaustive three-way readback | Can any fragment be classified exact/absent, or can recovery retry or replenish? |
| 5 | Terminal binding to exact committed fact and receipt, unchanged B1 compatibility vectors, no guard writes | Can terminal inference create or erase an acceptance? |

Existing contract tests are evidence and drift guards, not independent semantic owners (`tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py:611-623,745-764`; `tests/test_rw0_c2_durable_progression_decision_semantic_contract.py:6197-6225,6460-6490`). No tests were run for this reconnaissance.

## 19. Stop conditions and remaining uncertainty

**Stop future implementation** if the external continuity and sole-active source cannot provide current, verifiable, clone/rollback-safe lineage evidence; if the safe-value freeze changes v1 identity meaning; if migration 0005 cannot enforce one scope-wide fact within one DB; if the family profile cannot prove result/receipt membership and historical head postimage; or if an implementation needs a second guard transaction, receipt or recovery classifier. In those cases, every applicable command remains fail-closed under the accepted guard (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:25-35,62-71,88-108,121-135`).

Unselected engineering details are the external witness issuer and transfer protocol; exact new value bytes/domains; exact additive SQL and migration compatibility; bounded query inventory; historical head proof; and private provisioning/decision entry signatures. The accepted target resolves the product meaning of one permanent scope allowance. No operator product-policy fork is needed for this recommendation.

## 20. Continuation capsule

The repository is clean at `trunk_dev` commit `3d99e448bfe577b5a5878dd32b7e01b61322e7df`, tree `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`, aligned 0/0 with `origin/trunk_dev`. RW0-C2 decision and immutable bootstrap guard are accepted semantics only; migration 0005, admission provisioner, acceptance fact, guarded writer, terminal owner, production caller and runtime are absent. `.docs/` governs semantics; the guard owner is `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`, the decision owner is `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`, and composition is `.docs/autonomous-software-development-operating-model.md`.

Recommended architecture: two semantic owners share the existing local writer/session/controller infrastructure. A separate provisioner records one externally policy-authored immutable admission fact before or after program creation. A guarded decision writer reads but cannot create admission, and alone writes a scope-unique immutable acceptance fact inside the exact decision/version/head/result/receipt transaction. Keep migration-0002 rows and v1 values unchanged. Freeze a private versioned guarded result/family relation whose digest follows the acceptance fact and whose exact role enters the existing receipt graph; add the missing immutable rows, routes and constraints in a bounded additive migration 0005. A bare v1 graph digest does not prove family completeness. The B1 `latch_postimage_*` pair stays unchanged and unused by the decision writer; a later terminal consumer needs its own safe-value compatibility decision.

Positive external continuity and sole-active evidence must compose with current local fencing before receipt disclosure. SQLite uniqueness and local file locks cannot prove the absence of a committed fact on another or rolled-back copy. If restore/clone continuity is unprovable, fresh acceptance fails closed. Exact replay returns the original complete family without fresh eligibility evaluation; one decision-owned readback classifier returns `committed_exact`, `definitely_not_committed`, or `unresolved`.

Next contract tranche: private C2 safe-value/versioning and graph-profile freeze. Then freeze admission/continuity, bounded-hybrid migration 0005, and transaction/replay/recovery before any source implementation. Reconcile the explicitly superseded mutable-latch prose in the older C2B body during the physical freeze. No product-policy choice is needed.

## 21. Required non-actions

```text
REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
MIGRATIONS_NOT_RUN
DATABASE_NOT_OPENED_OR_MUTATED
DEPENDENCIES_NOT_INSTALLED
SERVICES_NOT_STARTED
REMOTE_CONTACT_NOT_PERFORMED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
ARTIFACTS_NOT_GENERATED
IMPLEMENTATION_PROMPT_NOT_ISSUED
IMPLEMENTATION_NOT_PERFORMED
MIGRATION_0005_NOT_CREATED
SAFE_VALUE_VERSIONING_NOT_IMPLEMENTED
BOOTSTRAP_SCOPE_PROVISIONER_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_GUARD_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_READ_ONLY_IF_USED
```

RW0_C2_BOOTSTRAP_GUARD_PHYSICAL_ARCHITECTURE_READY
