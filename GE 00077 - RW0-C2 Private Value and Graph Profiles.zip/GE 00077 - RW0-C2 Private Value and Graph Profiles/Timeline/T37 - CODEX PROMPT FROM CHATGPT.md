# Governed Execution Coordinator — RW0-C2 Private Value Contract V9 Visible-Block and Neutral-Subject Verifier Repair

## Role and objective

Resume the implementation conversation that produced the uncommitted RW0-C2
private value/versioning and receipt-graph-profile V8 candidate.

Use the highest available Codex reasoning setting. Record exactly what the
interface visibly shows for:

- model name;
- reasoning setting or effort;
- parent filesystem/permission posture, when visible.

Do not infer hidden configuration. Record `not visible` when necessary.

The parent is the sole repository writer. Do not spawn subagents.

Repair the exact six-path candidate after its fresh independent re-audit
returned:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_AUDIT_BLOCKED`

The V8 audit established exact provenance and found no unresolved defect in:

- validated current recovery posture and alternate positive vectors;
- normal `unresolved` projection for well-formed nonpositive posture;
- closed projector signature and classifier-return dataflow;
- the unified seven-field recovery result;
- the exact private vocabulary;
- the exact owner-assertion profile and profile digest;
- all thirteen structural consequences;
- lifecycle, observation, relation, command, current-v1 family, target-family,
  profile, role, replay, recovery, B1, or nonimplementation boundaries.

Only two High-severity verifier defects remain:

1. contiguous multiline blockquote lines are split into separate visible blocks
   after their `>` markers are removed, so subject context is lost across quote
   continuations;
2. a neutral subject phrase found anywhere in a clause suppresses an already
   explicit or inherited protected subject, so a protected action can be hidden
   by placing `replay glossary`, `replay diagram`, `replay example`, or similar
   text in object or adjunct position.

This is a **one-file verifier repair**. The private value contract already
requires blockquote/continuation coverage, exact protected subjects, and neutral
noun-phrase controls. Do not modify that contract or any other candidate path.

Do not implement source, migration `0005`, admission provisioning, continuity
transport, durable persistence, readers, transaction mechanics, recovery
runtime, public interfaces, runtime activation, RW0-D/E, or Execution
Substrate behavior.

Return one substantive inline closeout report. Do not create or attach a report,
manifest, package, freeze artifact, patch, or other client-visible file.

## Exact committed baseline

Repository root:

`/Users/ds/Repositories/Governed Execution Coordinator`

Required committed baseline beneath the candidate:

- branch: `trunk_dev`
- HEAD: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- tree: `edd773fe66f8aca9a8eaec0c4ad43d99d73a20a3`
- sole parent: `6f11d6b0b6f38995123434945d86db0b169bb8f8`
- subject: `docs: adopt RW0-C2 bootstrap acceptance guard`
- upstream: `origin/trunk_dev`
- divergence: `0 ahead / 0 behind`
- exactly one worktree
- zero staged paths
- zero unmerged paths
- no active merge, rebase, cherry-pick, revert, bisect, sequencer, or index lock

Do not fetch or contact remotes.

## Exact opening V8 candidate

Require exactly four tracked documentation modifications and two untracked
files, with no other tracked or untracked difference from HEAD.

All six paths must be regular, non-symlink mode-`0644` files, valid UTF-8, with
no BOM or CR bytes, no trailing whitespace, and exactly one final newline.

| # | Status | Path | Bytes | SHA-256 |
|---:|---|---|---:|---|
| 1 | `M` | `.docs/autonomous-software-development-operating-model.md` | 38,248 | `dc6bfe999588db8af31a18711a763a51f55604ad70aceac0e3cf088d806509a5` |
| 2 | `M` | `.docs/rw0-b1-pure-phase-values.md` | 33,647 | `037daaabdf154c82634e58517b4911f52f28f985ad718b35f02ba5e2b5b820b6` |
| 3 | `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 25,574 | `b267831c1e16b7134055334848193ee90edc90c8e60ab674db0a0e8ef8a5265e` |
| 4 | `M` | `.docs/rw0-c2-durable-progression-decision-semantic-contract.md` | 71,408 | `936bbb34348624eb7757f1ff3c82a2b5bc08c3e02dbb7fdb0fe9a93fcb560d0e` |
| 5 | `??` | `.docs/rw0-c2-private-value-versioning.md` | 207,042 | `3e1e8b8d3538f855029fa51a729d62d2df82f05eccda76d33c70828324e4581f` |
| 6 | `??` | `tests/test_rw0_c2_private_value_versioning_contract.py` | 324,792 | `d59d3bdfe05d5482ad233150810c7cdd34536634dd370dd208485fc3281bff7e` |

Required opening ordered patch:

- bytes: `547,910`
- SHA-256:
  `79e8c62ec8d96066cdca4d856b5be3706df720a75693d0096d95d0bae77f7225`

Construct it twice in lexicographic path order with:

- tracked:
  `git diff --binary --no-ext-diff HEAD -- <path>`;
- new:
  `git diff --no-index --binary --no-ext-diff -- /dev/null <path>`.

Treat expected `git diff --no-index` status `1` as “differences found.”

Required opening canonical receipt:

- bytes: `1,381`
- SHA-256:
  `669c6c1574e754271bfc958eebacb1eb47541c498254d076e63924ef0bf9c4fb`

Receipt grammar:

- root keys: `baseline_head`, `files`, `patch`, `schema`;
- recursively sorted object keys;
- compact separators;
- `ensure_ascii=false`;
- `allow_nan=false`;
- UTF-8;
- no trailing newline;
- files ordered lexicographically by path;
- file keys: `mode`, `path`, `sha256`, `size_bytes`, `status`;
- schema:
  `rw0-c2-private-value-audit-receipt-v1`.

Run patch and receipt construction twice.

Stop before editing on any mismatch:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V9_REPAIR_BLOCKED`

## Exact one-file mutation ceiling

Only this path may change from its opening V8 bytes:

`tests/test_rw0_c2_private_value_versioning_contract.py`

The following five candidate paths must remain byte-identical:

- `.docs/autonomous-software-development-operating-model.md`
- `.docs/rw0-b1-pure-phase-values.md`
- `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md`
- `.docs/rw0-c2-durable-progression-decision-semantic-contract.md`
- `.docs/rw0-c2-private-value-versioning.md`

Every other repository path must remain byte-identical to HEAD.

Do not modify:

- any documentation;
- source;
- migrations;
- existing tests;
- package exports;
- `AGENTS.md`;
- `README.md`;
- configuration or examples.

Migration `0005` must remain absent.

If the one-file ceiling is insufficient, restore the exact opening V8 verifier
and return the blocking token. Do not widen the tranche.

## Accepted V8 surfaces that must not be reopened

Preserve every V8 contract and verifier boundary, including:

1. validated current recovery posture and generic state-based positivity;
2. alternate valid positive posture values;
3. normal `unresolved` projection for well-formed nonpositive posture;
4. closed projector signature and classifier-return dataflow;
5. unified seven-field recovery result;
6. exact private vocabulary/profile;
7. exact owner-assertion profile and fixed digest/vector;
8. all thirteen owner assertion records and structural consequences;
9. lifecycle partitioning and all DAGs;
10. ten-status typed observations;
11. all 26 guarded-relation fields;
12. canonical command/selector/family binding;
13. source-exact current-v1 mapping;
14. actual C2 returned-branch causality;
15. canonical current-v1 and target family members;
16. static profile and complete receipt-role inventory;
17. exact replay/recovery semantics;
18. current v1 and B1 meanings;
19. target-only nonimplementation.

This repair changes only visible-Markdown block construction, exact subject
classification, and their causal tests.

# Finding H1 — contiguous multiline blockquote grouping

## H1-A. Preserve quote structure until grouping is complete

The V8 parser strips `>` before grouping lines, then tests whether already
stripped text starts with `>`. That makes every quote line a separate block.

Refactor visible-Markdown extraction so quote origin and nesting depth are
identified **before** quote markers are removed.

For every source line, retain at least:

- original line;
- visible text after removing the exact quote prefix;
- block kind;
- quote depth;
- blank/nonblank status.

Do not infer quote membership from text after marker removal.

## H1-B. Exact bounded blockquote grammar

Use this bounded grouping rule:

1. A blockquote line begins, after optional indentation, with one or more `>`
   markers, each optionally followed by one space.
2. Consecutive nonblank quote lines of the same quote depth belong to one visible
   quote block.
3. A quoted blank line or an unquoted blank line ends the current quote
   paragraph.
4. A change in quote depth ends the current quote block and begins another.
5. Quote markers are removed only after grouping.
6. Joined visible text preserves line order and inserts one space or newline in
   the exact normalization expected by the clause segmenter.
7. Subject context may continue across lines inside that one quote block.
8. Subject context must not cross a quoted blank line, depth change, or separate
   quote block.

The repair must reject this exact hostile block:

```markdown
> Replay may not create a new timestamp but
> may create a new acceptance fact.
```

It must also reject the forward order and equivalent semicolon, `however`,
`although`, `yet`, and `while` forms split across two quote lines.

## H1-C. Quote continuation controls

Add permanent controls for:

- two-line quote, reversed `but`;
- two-line quote, forward `but`;
- two-line quote with semicolon split;
- two-line quote with each supported contrast connector;
- two-line quote where the second line begins directly with a protected action;
- three-line quote with subject, prohibition, and later permission;
- quote continuation in a list item only when the Markdown block is genuinely
  one quoted list block;
- quoted blank line breaking subject propagation;
- change from `>` to `>>` breaking the block;
- separate blockquotes not sharing subject;
- one-line quote behavior unchanged.

Do not implement a general Markdown renderer. This is a bounded visible-block
extractor for the contract’s closed clause grammar.

# Finding H2 — neutral phrases are subjects only in subject position

## H2-A. Remove anywhere-in-clause neutral suppression

A neutral phrase must never clear an explicit or inherited protected subject
merely because the phrase appears somewhere in the segment.

Remove logic equivalent to:

```text
if any neutral phrase occurs anywhere:
    clear protected subject
```

## H2-B. Exact neutral-subject position

A neutral noun phrase is neutral only when it occupies the segment’s grammatical
subject position.

Use an exact bounded rule:

- normalize Markdown presentation and leading punctuation;
- inspect the initial noun phrase before the first recognized modal or protected
  action;
- allow only bounded leading determiners/adjectives already used by the strong
  neutral controls;
- classify the phrase as neutral only when that initial noun phrase exactly
  matches one of the closed neutral subjects.

Closed neutral subjects include the exact V8 inventory, including at least:

- `replay glossary`
- `replay diagram`
- `replay example`
- `replay documentation`
- `receipt documentation`
- `timestamp terminology`

A protected subject explicitly present at the start of a segment has priority
over neutral phrases later in an object, complement, quoted phrase,
prepositional phrase, label, citation, or adjunct.

An inherited protected subject from the immediately preceding eligible segment
also has priority unless the new segment begins with an explicit subject of its
own.

## H2-C. Exact hostile object-position controls

Each of these must fail as an untagged protected assertion:

```text
Replay may not create a new timestamp but may create a new acceptance fact in the replay glossary.
Replay may create a second receipt as shown in the replay diagram.
Replay might refresh a timestamp in a replay example.
Replay may prove noncommit according to timestamp terminology.
Replay may create a new acceptance fact in receipt documentation.
Replay may create a new acceptance fact in replay documentation.
```

Add equivalent forms where the protected subject is inherited across a
contrastive segment before the neutral phrase appears.

## H2-D. Strong neutral-subject positive controls

These must continue to pass:

```text
The replay glossary may quote the phrase "create a new acceptance fact".
The replay diagram may display a node labelled "create a second receipt".
This receipt documentation can show the example text "refresh a timestamp".
Timestamp terminology might include the words "prove noncommit".
The replay example may discuss why software must not create an acceptance fact.
```

Also add:

```text
Replay documentation may quote the sentence "Replay may create a new acceptance fact" as a rejected example.
```

The quoted protected statement is an object of neutral documentation, not the
normative subject of the outer segment.

## H2-E. Neutral-to-protected transition

A neutral subject must not suppress a later explicit protected subject in the
same visible block.

This must fail:

```text
The replay glossary may quote examples. Replay may create a new acceptance fact.
```

This must pass:

```text
The replay glossary may quote examples. It may include the term timestamp.
```

Do not carry a neutral subject as protected subject context.

# Parser implementation constraints

Preserve:

- sentence and contrastive segmentation;
- per-action polarity;
- immediate protected-subject `it` context;
- exact protected subject phrases;
- exact modal inventory;
- exact protected action/object grammar;
- visible headings, paragraphs, lists, tables, quotes, and link labels;
- untagged authority-sensitive rejection;
- all V8 strong neutral controls.

Do not:

- add broad substring suppression;
- classify by word stems;
- use a full external Markdown parser or new dependency;
- weaken tagged-clause checks;
- alter contract semantics;
- change owner/vocabulary profiles.

# Permanent test requirements

Add fixed, independently authored tests for:

1. blockquote tokenization before marker removal;
2. quote depth and blank-line boundaries;
3. quote-line joining and subject inheritance;
4. both contrast orders across multiline quotes;
5. all supported contrast connectors across multiline quotes;
6. explicit protected subject with every neutral phrase in object position;
7. inherited protected subject with neutral phrase in object position;
8. exact neutral-subject position;
9. neutral-to-protected transition in one block;
10. neutral pronoun continuation;
11. one-line quote, heading, bullet, table, blockquote, and link-label
    regressions;
12. all accepted V8 hostile and neutral prose forms.

Tests must use fixed expected block sequences and parser outcomes, not derive
expectations from the extractor under test.

# Required transformed external copies

Execute at minimum these transformed copies against the exact final candidate.

## Blockquote structure

1. restore quote-marker removal before grouping;
2. group each contiguous quote line separately;
3. ignore quote depth;
4. propagate subject across quoted blank line;
5. fail to propagate subject across same-depth continuation;
6. join lines in reversed order;
7. discard the second quote line;
8. treat `>` and `>>` as one block;
9. remove the multiline reverse-contrast guard;
10. remove the multiline forward-contrast guard.

## Neutral subject position

11. restore neutral-phrase-anywhere suppression;
12. let a neutral object clear an explicit protected subject;
13. let a neutral object clear an inherited protected subject;
14. treat `replay glossary` as protected `replay`;
15. remove each closed neutral subject one at a time;
16. classify any phrase beginning with `replay` as neutral;
17. carry a neutral subject as protected `it` context;
18. let a neutral first sentence suppress a later explicit protected subject;
19. treat quoted protected text inside neutral documentation as normative;
20. accept each of the six hostile object-position clauses above.

## Regression sample

Re-run transformed copies or equivalent permanent controls for:

21. generic alternate positive posture;
22. well-formed nonpositive posture;
23. projector classification override;
24. one structural consequence changed to constant true;
25. owner profile digest mismatch;
26. one-sided private vocabulary drift;
27. direct reversed `but` clause;
28. immediate pronoun clause.

Every hostile copy must retain the exact final private-test collection and fail
at its intended boundary. Strong neutral copies must retain collection and pass.

Report permanent internal controls separately from actual transformed copies.

# Validation

Run all validation serially in a clean local-only external clone created from
exact HEAD and overlaid with the exact six candidate paths.

Do not import repository modules from the live checkout.

Use:

```text
PYTHONDONTWRITEBYTECODE=1
PYTHONPATH=.:src
python3 -m pytest -q -p no:cacheprovider --basetemp=<external>
```

Run `--collect-only -q` before every execution and report exact counts.

Run:

1. `tests/test_rw0_c2_private_value_versioning_contract.py`
   - opening V8 reference: `854 passed`;
   - final collection may increase but must not shrink.

2. Existing C2 guard and decision contract modules
   - reference: `1,623 passed`.

3. Specified B1, C2B2 values, and migration-0002 modules
   - reference: `458 passed`.

4. Expanded B1/C2B2 coverage
   - reference: `926 passed`.

5. Operating-model, architecture, and runtime modules
   - reference: `77 passed`.

6. Deterministic broad group:
   - exact 48 sorted/deduplicated files from:
     - `tests/test_rw0_*.py`
     - `tests/test_c2b*.py`
     - `tests/test_sqlite_c2b*.py`
     - `tests/test_sqlite_rw0*.py`
   - newline-joined path hash without final newline:
     `0c57aa37134d814b5e1dc3efb22cbe440c8c1bb6a12b8dc1b4223fb47e9893c0`
   - opening V8 reference: `4,857 passed`.

7. Complete repository
   - opening V8 reference: `8,671 passed, 3 warnings`.

The full-suite increase may equal only the exact new private-verifier test
nodes.

The only accepted warnings remain the unchanged Python 3.13
multithreaded-`fork()` warnings from existing writer-session tests.

Also require:

- `git diff --check`;
- both new-file `/dev/null` whitespace checks;
- UTF-8/BOM/CR/trailing-whitespace/final-newline checks;
- exact one-file V8-to-V9 mutation ceiling;
- proof the private contract and other four candidate files remain
  byte-identical;
- source/migration/export/public/runtime preservation;
- migration `0005` absent;
- external-clone artifact scan;
- exact live-cache opening/closing member equality;
- removal of all engagement-created temporary data.

Never import repository modules from the live checkout. A success result requires
exact opening/closing live-cache equality.

# Closeout provenance

At closeout require:

- committed HEAD unchanged;
- exactly four tracked documentation modifications and two untracked files;
- zero staged and unmerged paths;
- no other changed or untracked path;
- all six regular mode `0644`;
- only the private verifier differs from its opening V8 receipt;
- source and migration trees unchanged;
- migration `0005` absent;
- no retained temporary artifact.

Return:

1. outcome token;
2. visible model/reasoning/permission posture;
3. opening and closing Git coordinates;
4. exact final six-path receipt table;
5. exact one-file V8-to-V9 transition;
6. proof the other five candidate paths stayed byte-identical;
7. visible-block data model and blockquote grouping rules;
8. blockquote continuation and boundary controls;
9. exact neutral-subject-position classifier;
10. hostile object-position and strong neutral controls;
11. disposition of both V8 audit findings;
12. preserved V8 controls;
13. permanent controls versus transformed external copies;
14. exact collection and validation results;
15. source/migration/public/runtime preservation;
16. deterministic final six-path patch bytes and SHA-256;
17. fully specified final canonical receipt grammar, bytes, and SHA-256;
18. live-cache equality and cleanup;
19. remaining physical seams;
20. all required non-actions.

Calculate the final patch twice.

Calculate the final canonical receipt twice with independent implementations.

Do not stage, commit, push, create or modify a PR, or merge.

# Stop conditions

Return the blocking token without leaving partial edits if:

- opening provenance differs;
- the one-file ceiling is insufficient;
- the private contract must change;
- correct blockquote grouping requires a general Markdown parser or new
  dependency;
- exact neutral-subject classification requires changing contract semantics;
- source, migration, export, or existing-test changes are required.

Restore the exact opening V8 verifier under a blocking result.

# Outcome tokens

Success:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_VERIFIER_REPAIRED_V9_VALIDATED_READY_FOR_REAUDIT`

Blocked:

`RW0_C2_PRIVATE_VALUE_VERSIONING_CONTRACT_V9_REPAIR_BLOCKED`

Success authorizes only a fresh independent read-only re-audit of the exact
repaired six-path candidate.

# Required non-actions

State:

```text
PRIVATE_VALUE_CONTRACT_NOT_MODIFIED
OTHER_FOUR_CANDIDATE_DOCS_NOT_MODIFIED
SOURCE_NOT_MODIFIED
MIGRATIONS_NOT_MODIFIED
MIGRATION_0005_NOT_CREATED
EXISTING_TESTS_NOT_MODIFIED
NON_CANDIDATE_DOCS_NOT_MODIFIED
AGENTS_NOT_MODIFIED
README_NOT_MODIFIED
ARCHITECTURE_NOT_MODIFIED
C2B_NOT_MODIFIED
DATABASE_NOT_OPENED_OR_MUTATED
OPERATOR_OR_PRODUCT_STATE_NOT_OPENED_OR_MUTATED
LIVE_IGNORED_CACHE_OPENING_AND_CLOSING_EQUAL
ADMISSION_PROVISIONER_NOT_IMPLEMENTED
CONTINUITY_PROTOCOL_NOT_IMPLEMENTED
BOOTSTRAP_ACCEPTANCE_FACT_NOT_IMPLEMENTED
DURABLE_DECISION_WRITER_NOT_IMPLEMENTED
READERS_NOT_IMPLEMENTED
RECOVERY_NOT_IMPLEMENTED
TERMINAL_OUTCOME_NOT_IMPLEMENTED
PRODUCTION_CALLER_NOT_CREATED
PUBLIC_EXPORT_NOT_CREATED
RUNTIME_NOT_ACTIVATED
RW0_D_NOT_IMPLEMENTED
RW0_E_NOT_IMPLEMENTED
EXECUTION_SUBSTRATE_NOT_MODIFIED
SUPPORTING_REPOSITORIES_NOT_INSPECTED
REMOTE_CONTACT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED_OR_MODIFIED
MERGE_NOT_PERFORMED
SUBAGENTS_NOT_SPAWNED
EXTERNAL_ARTIFACTS_NOT_RETAINED_OR_DELIVERED
```
