# Disclaimer

- Before you use the timeline, please look out for gaps, e.g. missing events and/or messages, wrong sequence label; and make sure the contents from each file are unique, because I manually copied and pasted them from the MacOS ChatGPT app.
- ChatGPT's UI automatically converts long text into attachment. If the content is not captured in time, it would be skipped, and you can tell, based on the "T\<ID\> -" prefix in the filename. For example, "Timeline/T3 - CHATGPT.md" is immediately before "Timeline/T4 - USER.md"
