`Timeline/T0 - USER.md` is, from my point of view, what preceded the actual timeline of the failure detection.

Around `Timeline/T111 - CHATGPT.md`, a hard realignment took place, which may have been the result of GE Chat 00068 referencing GE Chat `Daily Review (2026-09-15)` (By the time you read this, the daily review chat may have been moved to another project, so if you want to see the chat again, request USER to move it back inside GE). `Daily Review (2026-09-15)` went into how inefficient the workflow had been, which I had to argue in favor of, because of the emphasis on correctness.

Around `Timeline/T132 - CODEX REPORT FROM USER.md`, I only stepped in, because of the repeated validation failures that annoyed me. Before this, any reports that are only linked, should be considered lost.

Somewhere along the line, ChatGPT started requesting Codex to calculate provenance for ChatGPT to pass back in the same or a different chat. This may defeat the purpose of provenance, now that Codex basically gets to decide which provenance is "right." Well, to be fair, ChatGPT can't access the files to calculate the score anyway, and we sort of mitigate the risks by not enabling memory for Codex.

Around `Timeline/T177 - CHATGPT.md`, I noticed that the Codex prompt from Chat 00068 started requiring new Codex chat for repairs. This was different from how I remembered repairs were done after a failed audit: repair prompts were sent to the same audit chat, until a new audit was required, which would start a new chat.

I'm happy to see that ChatGPT discovered contradictions and took actions, around `Timeline/T391 - CHATGPT.md`, but the price is way too high. Nearly 400 messages, across 14 days, is not very efficient.

`Timeline/T420 - USER PROMPT FROM CHATGPT.md` is from GE Chat 00071. It was created after we merged GE Chat 00068 RW0-B2 and requested GE Chat 00071 to review the chat histories in both GE 00068 10G and GE 00073 RW0-B2.

At `Timeline/T484 - USER.md`, I started to wonder again if we are witnessing the intellectual ceiling of ChatGPT Pro model (I think the first message in this series started with 5.6 Sol?). If yes, then we need to analyze the type(s) of problems and consider asking the cognitive governor (if we are adding it) to recognize the problem types and escalate early.
