## Engineering assessment

This is a clean implementation success. The harness is now **implemented, qualified on the actual `run-full-audit` path, source-frozen, deterministically packaged, externally authority-bound, and ready for one fresh audit**.

The final authority-bearing files are:

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz
```

- mode: `0400`
- size: `2,822,218`
- SHA-256: `2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2`

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json
```

- mode: `0400`
- size: `7,193`
- SHA-256: `349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986`

The containing output directory is nonauthoritative and contains exactly these two files.

### Why this result qualifies

The new generation closes both major prior seams:

- the audit-capsule authority and terminal-lifecycle defect;
- the macOS launch/runtime self-authentication defect.

The implementation now supports the frozen three-role interpreter model:

- platform-declared Framework launcher;
- launcher-valued `sys.executable` and `sys._base_executable`;
- Python.app-valued `sys.orig_argv[0]`;

while explicitly avoiding any claim about a terminal kernel image. It also implements the bounded `__CF_USER_TEXT_ENCODING` policy and rejects unknown runtime environment keys.

The substantive qualification is broad:

- 26 clean sources compiled with zero static violations;
- exact B00 and D01–D14 suite passed at `595/595`;
- 151 interpreter-tuple cases passed;
- capsule, confirmation, report, terminal, custody, and causal matrices all passed;
- synthetic `ACCEPT`, `BLOCK`, and `AUDIT_PROVENANCE_MISMATCH` lanes passed;
- bounded replay authenticated all 479 content-bundle members and eight roles without issuing a package verdict;
- real-path `ACCEPT`, `BLOCK`, and provenance-failure rehearsals all traversed the exact `run-full-audit` path successfully;
- all sources froze and remained unchanged;
- PYZ Build A, Build B, and the final PYZ are byte-identical;
- authority Build A, Build B, and final authority v3 are byte-identical;
- independent source, capsule, and authority validators passed;
- frozen-PYZ requalification passed against read-only authority v3.

No real audit ran, no implementation verdict was issued, and the current schema subject remains unconstructed.

### Progression decision

Run **exactly one fresh independent audit now**.

Do not perform another harness qualification, documentary tranche, source repair, authority repair, or rehearsal.

Use only:

1. final PYZ v2;
2. final authority v3;
3. current content snapshot bundle;
4. current content authority JSON.

The one authorized audit is consumed when the `run-full-audit` process is created, regardless of whether the terminal result is `ACCEPT`, `BLOCK`, or `AUDIT_PROVENANCE_MISMATCH`.

The audit task must stop after reporting. Even an `ACCEPT` result must not be combined with current-subject construction.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE FRESH INDEPENDENT AUDIT OF THE SEALED
GENERATION-2 RECONSTRUCTION-PARENT IMPLEMENTATION EVIDENCE

USING THE FINAL CLEAN HARNESS PYZ V2 AND EXTERNAL AUTHORITY V3

Objective

Execute exactly one fresh independent audit using:

1. the exact final clean source-external audit-harness PYZ v2;
2. the exact current external harness authority v3;
3. the exact current-authority content snapshot ZIP;
4. the exact content-snapshot authority JSON.

Capture the top-level audit-parent launch and completion exactly.

Use only the unique audit-root locator emitted by the harness.

After completion, inspect the emitted audit capsule read-only, authenticate its
terminal closure, and report its exact final verdict.

Do not modify, repair, resume, clean, or rerun the audit capsule.

Do not perform another harness qualification.

Do not execute `qualify-harness`.

Do not launch a replacement, recovery, or continuation parent.

Do not run a direct implementation auditor outside the frozen harness.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not invoke product or live-service behavior.

Do not run a target audit.

Do not rerun runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

The exact primary verdict must be one of:

ACCEPT

BLOCK

AUDIT_PROVENANCE_MISMATCH

If the real audit parent is not created because a prelaunch gate fails, return:

AUDIT_PROVENANCE_MISMATCH

and state that the one authorized audit was not consumed.

──────────────────────────────────────────────────────────────────────────────
1. EXACT FINAL HARNESS FILES
──────────────────────────────────────────────────────────────────────────────

FINAL_HARNESS_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz

Expected fixed identity:

- mode:
  0400
- size:
  2822218
- SHA-256:
  2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2

FINAL_HARNESS_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Expected fixed identity:

- mode:
  0400
- size:
  7193
- SHA-256:
  349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986

The containing directory is nonauthoritative.

Do not inspect or depend on any other directory member.

Do not open or use any predecessor harness PYZ or predecessor authority file.

──────────────────────────────────────────────────────────────────────────────
2. EXACT CURRENT IMPLEMENTATION-EVIDENCE FILES
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected fixed identity:

- mode:
  0400
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected fixed identity:

- mode:
  0400
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

The containing directory is nonauthoritative.

Do not inspect or depend on any other directory member.

──────────────────────────────────────────────────────────────────────────────
3. PRELAUNCH STABLE FILE AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Before launching any process, authenticate all four files.

For each file:

1. open no-follow;
2. require a regular file;
3. require the expected mode;
4. require link count one when bound by authority v3;
5. retain observed device and inode;
6. require the expected size and SHA-256;
7. perform two stable reads;
8. require byte and metadata equality.

Strict-parse both authority JSON files:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

Do not invent a required device, inode, or field that is not bound by the
current authority records.

Require authority v3 to establish:

- exact PYZ v2 path and identity;
- exact PYZ member registry;
- deterministic package equality;
- exact source freeze;
- exact source registries;
- exact post-package qualification;
- exact authority-v3 validation;
- exact frozen-PYZ requalification;
- the five-domain governing package;
- the interpreter-observation-tuple governing package;
- exactly 66 runtime report rows;
- exactly 81 runtime confirmation names;
- exactly 15 runtime matrices;
- exactly 595 runtime matrix cases;
- exact current content-bundle identity;
- exact current content-authority identity;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject constructed:
  false;
- launch authorized:
  true;
- future audit count authorized:
  1;
- exact future `run-full-audit` invocation;
- exact future cwd;
- exact future environment;
- exact stdout/stderr framing contract.

Require the content authority JSON to establish:

- exact content ZIP identity;
- archive members:
  479;
- current roles:
  8;
- content-snapshot roles:
  7;
- bounded failure-evidence roles:
  1;
- `.DS_Store` members:
  0;
- deterministic archive equality:
  true;
- independent archive validation:
  passed;
- implementation verdict:
  not issued;
- package verdict:
  not issued.

If any fixed-input predicate fails:

- do not run the platform preflight;
- do not launch the audit parent;
- return `AUDIT_PROVENANCE_MISMATCH`;
- retain the exact first blocker;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
4. PYZ V2 MEMBER AND GOVERNANCE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Parse the PYZ directly.

Require exact correspondence with authority v3.

At minimum require:

- exact member count bound by authority v3;
- raw UTF-8 byte-sorted member names;
- ZIP_STORED only;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no comments;
- no uncontrolled extra fields;
- no cache or bytecode.

Resolve members only through the exact embedded member registry.

Authenticate embedded current roles for:

- `__main__.py`;
- source freeze;
- production source registry;
- qualification source registry;
- independent source registry;
- five-domain governing records;
- interpreter-observation-tuple governing records;
- runtime report registry;
- runtime confirmation registry;
- runtime matrix registry;
- phase plan;
- capsule path registry;
- capsule writer registry;
- process-custody contract;
- cleanup contract;
- terminal-lifecycle contract;
- package status;
- post-package qualification;
- authority-v3 validation;
- frozen-PYZ v2 requalification.

Independently recompute:

- documentary domains:
  5;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrix rows:
  15;
- runtime matrix cases:
  595;
- stale 645 accepted:
  false;
- interpreter roles:
  3;
- terminal runtime-image role:
  absent;
- current content roles:
  8;
- current content archive members:
  479.

Do not require a redundant evidence path that is not required by authority v3
or the embedded contract.

Do not invent a stronger launch rule.

Do not weaken a sealed launch rule.

Any discrepancy:

- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
5. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

After Sections 3–4 pass, run exactly one harmless synchronous platform-capture
preflight.

This is not an audit and does not consume the one authorized audit launch.

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

The program must:

- write exactly:
  `PLATFORM_CAPTURE_STDOUT_V1\n`
  to stdout;
- write exactly:
  `PLATFORM_CAPTURE_STDERR_V1\n`
  to stderr;
- exit exactly:
  23;
- read no stdin;
- create no file;
- create no child.

Environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Retain:

- exact argv;
- exact cwd;
- exact submitted environment;
- PID;
- start and completion;
- duration;
- stdout bytes;
- stderr bytes;
- exit code;
- signal;
- reaping;
- descriptor closure.

Expected stdout:

- size:
  27
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

If the preflight fails:

- do not launch `run-full-audit`;
- return `AUDIT_PROVENANCE_MISMATCH`;
- retain the complete preflight result;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
6. EXACT REAL-AUDIT INVOCATION
──────────────────────────────────────────────────────────────────────────────

After the preflight passes, derive the exact invocation from authority v3 and
require it to use exactly these operands:

- pinned Framework Python;
- `-I`;
- `-S`;
- `-B`;
- final PYZ v2;
- `--mode run-full-audit`;
- `--harness-authority`;
- final authority v3;
- `--bundle`;
- current content bundle;
- `--bundle-authority`;
- current content authority JSON.

Do not supply:

- predecessor PYZ;
- predecessor authority;
- either documentary root;
- implementation root;
- historical root;
- continuation option;
- recovery option;
- any extra argument.

Use the exact cwd bound by authority v3.

No fallback cwd is permitted.

Use the exact submitted environment bound by authority v3.

At minimum it must contain exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Launch the audit parent synchronously in the foreground.

Launch count:

exactly one.

The one authorized audit is consumed when process creation succeeds,
regardless of terminal verdict or later custody failure.

Do not launch:

- `qualify-harness`;
- a replacement parent;
- a recovery parent;
- administrative continuation;
- a direct implementation auditor;
- a post-failure validator;
- a second audit.

──────────────────────────────────────────────────────────────────────────────
7. TOP-LEVEL PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Retain the complete platform process result before parsing output:

- custody ID;
- PID;
- process-creation result;
- start;
- completion;
- duration;
- exact argv;
- exact cwd;
- exact submitted environment;
- stdin posture;
- shell/TTY/detachment;
- raw stdout bytes;
- raw stderr bytes;
- stdout size and SHA-256;
- stderr size and SHA-256;
- exit code;
- signal;
- process error or null;
- reaped state;
- descriptor closure;
- PYZ identity at launch;
- authority-v3 identity at launch;
- content-bundle identity at launch;
- content-authority identity at launch.

The platform wrapper is authoritative for top-level process creation and
completion.

The audit capsule is authoritative only for runtime-observed process evidence
and its typed self-authentication crosswalk.

If completion capture is missing after process creation:

- do not scan for an audit root;
- do not guess;
- do not retry;
- do not launch recovery;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_CONSUMED`;
- retain every available platform field.

──────────────────────────────────────────────────────────────────────────────
8. STREAM AND TERMINAL-FRAME CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain raw streams before parsing.

Parse them only under the exact authority-v3 and embedded stream contract.

Require:

- exactly one audit-root locator;
- exactly one terminal frame;
- no progress chatter;
- no duplicate locator;
- no duplicate terminal frame;
- no unframed trailing bytes;
- handled-terminal stderr posture.

Strict-parse terminal JSON:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact schema;
- exact final verdict;
- exact audit-root path;
- exact preseal-result identity;
- exact terminal-result identity;
- exact temporal identity;
- exact manifest A identity;
- exact manifest B identity;
- A/B equality:
  true;
- terminal reprojection:
  passed;
- root row:
  exactly one;
- seal transition:
  exactly one;
- terminal marker;
- no postseal operation:
  true.

Allowed final verdict:

ACCEPT
BLOCK
AUDIT_PROVENANCE_MISMATCH

Require consistency among:

- unique locator;
- terminal frame;
- platform exit and signal;
- emitted marker;
- audit-root identity;
- retained terminal-result record;
- retained preseal result.

Any inconsistency:

- wrapper verdict:
  `AUDIT_PROVENANCE_MISMATCH`;
- do not promote package findings;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
9. AUDIT-ROOT SELECTION
──────────────────────────────────────────────────────────────────────────────

Use only the exact path from the unique emitted locator.

Do not:

- scan `/Users/ds/Downloads`;
- scan `/private/tmp`;
- search by prefix;
- select by recency;
- score candidates;
- select by inode, size, or hash;
- reuse a historical root.

Authenticate:

- absolute path;
- directory;
- no symlink;
- mode 0700;
- observed device/inode;
- equality with terminal-frame path;
- fresh creation by this parent according to capsule evidence.

If authentication fails:

- preserve the emitted locator as report-only evidence;
- return `AUDIT_PROVENANCE_MISMATCH`;
- inspect no alternative path.

──────────────────────────────────────────────────────────────────────────────
10. READ-ONLY AUDIT-CAPSULE INSPECTION
──────────────────────────────────────────────────────────────────────────────

Inspect only the unique emitted audit root.

Inspection is read-only.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute implementation source;
- run another validator;
- regenerate evidence;
- add a record;
- replace a record;
- add or regenerate manifests;
- repair closeout.

Resolve authoritative paths only through:

- terminal frame;
- embedded capsule path registry;
- capsule indexes;
- terminal manifests.

Do not use basename, suffix, recency, first match, or scoring.

For each authoritative record retain:

- exact relative path;
- schema;
- mode;
- link count;
- size;
- SHA-256;
- authority role.

──────────────────────────────────────────────────────────────────────────────
11. PARENT RUNTIME SELF-AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Authenticate:

opening/parent-runtime-self-authentication.json

Require the exact three-view model.

A. Platform-declared launch

Crosswalk against the externally retained platform custody:

- declared Framework launcher;
- argv;
- cwd;
- five submitted environment rows;
- stdin;
- shell;
- TTY;
- detachment;
- PID.

B. Runtime-observed process

Require exact retained values for:

- `sys.executable`;
- `sys._base_executable`;
- `sys.orig_argv`;
- `sys.argv`;
- flags;
- Python version and implementation;
- runtime cwd;
- runtime PID;
- runtime environment;
- executing PYZ identity;
- audit-root identity.

C. Interpreter observation tuple

Require:

- platform-declared launcher:
  exact Framework launcher identity;
- runtime `sys.executable`:
  same launcher identity;
- runtime `_base_executable`:
  same launcher identity;
- `sys.orig_argv[0]`:
  exact frozen Python.app token identity;
- no terminal-runtime-image role;
- no kernel-image claim;
- no role substitution;
- no basename/prefix/realpath/score fallback.

D. argv

Require:

- `sys.orig_argv[1:]` equals platform argv tail exactly;
- `sys.argv` equals the exact application sequence;
- `-I`, `-S`, and `-B` effective and represented correctly;
- no missing, duplicate, combined, or substituted flag.

E. cwd/PID/flags

Require exact crosswalks under the frozen contracts.

F. environment

Require the five submitted rows exactly.

Permit only optional:

__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0

When present:

- first component equals runtime UID 501;
- second and third components are zero;
- authority/configuration/verdict effect:
  none.

Reject every unknown extra key.

G. authority boundary

Require:

top_level_process_authority = external_platform_wrapper

The capsule must not claim process-creation authority.

Any self-authentication failure is an audit-provenance finding, not a package
finding.

──────────────────────────────────────────────────────────────────────────────
12. CAPSULE AUTHORITY AND PHASE AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Authenticate the complete capsule namespace under its embedded path and writer
registries.

Require at minimum:

opening/bootstrap-start.json
opening/parent-runtime-self-authentication.json
opening/fixed-input-opening-identities.json
opening/bundle-authentication.json
opening/role-resolution.json
opening/phase-plan-authentication.json

provenance/top-level-process-authority-boundary.json
provenance/complete-child-ledger.json
provenance/child-process-custody-result.json

phases/P00.json through phases/P24.json

analysis/source-external-evidence.json
analysis/security-and-authority-closure.json
analysis/findings-and-dependency-graph.json

validation/runtime-matrices.json
validation/negative-946-result.json
validation/contradiction-137-result.json
validation/field-map-766-333-result.json
validation/producer-rehearsal-result.json
validation/attempt-2-failure-evidence-result.json
validation/implementation-confirmation-result.json
validation/constructed-subject-domain-result.json
validation/fresh-behavioral-causals.json
validation/fresh-source-external-validation.json

report/runtime-report.json
report/runtime-confirmations.json

cleanup/cleanup-result.json
closing/fixed-input-closing-equality.json

closeout/phase-terminal-results.json
closeout/preseal-substantive-result.json
closeout/temporal-final-inventory.json

terminal/terminal-result.json

manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json

Every capsule JSON record must:

- have `schema`;
- be strict canonical UTF-8;
- be single-link;
- be mode 0600;
- be exclusively written once;
- match its path/writer registry.

For every P00–P24 record require:

- exact phase ID and name;
- exact prerequisites;
- explicit status:
  passed,
  failed,
  or not_reached;
- terminal:
  true;
- phase-specific evidence pointers;
- findings;
- first blocker or null;
- continuation decision;
- cleanup obligations;
- authority contribution;
- completion timestamp.

Reject:

- generic shared evidence strings;
- `pass:true` without explicit status;
- terminal-as-passed inference;
- missing phase;
- duplicate phase;
- absent evidence interpreted as pass.

──────────────────────────────────────────────────────────────────────────────
13. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Authenticate the internal child ledger and custody result.

Zero-child case is valid only when explicitly retained as:

- child_count:
  0;
- ordinals:
  [];
- complete_and_contiguous:
  true;
- every_created_child_reaped:
  true;
- all_child_descriptors_closed:
  true;
- recorder_bypass:
  false.

For every created child require:

- prelaunch before spawn;
- contiguous ordinal;
- exact executable identity;
- argv/cwd/environment/stdin;
- raw streams;
- exit/signal;
- timeout;
- reaping;
- descriptor closure;
- filesystem effects;
- cleanup obligations.

Require agreement between:

- internal child ledger;
- internal custody result;
- phase evidence;
- terminal report.

Do not require the capsule to self-attest top-level process creation.

──────────────────────────────────────────────────────────────────────────────
14. RUNTIME REPORT, CONFIRMATIONS, AND MATRICES
──────────────────────────────────────────────────────────────────────────────

Runtime report:

- exact R01–R66 IDs and order;
- exactly 66 rows;
- mode:
  run-full-audit;
- explicit applicability/status/value/evidence/authority;
- no blanket not-applicable projection;
- primary verdict separate.

Runtime confirmations:

- exact 81-name registry;
- exactly 81 rows;
- mode:
  run-full-audit;
- observed;
- expected;
- pass;
- evidence pointers;
- authority role.

Do not require every observed Boolean to be true.

Specifically require these current audit-mode rows to pass with:

- `RUN_FULL_AUDIT_MODE_NOT_EXECUTED`
  - observed:
    false;
  - expected:
    false.

- `FULL_INDEPENDENT_AUDIT_NOT_EXECUTED`
  - observed:
    false;
  - expected:
    false.

- `IMPLEMENTATION_PACKAGE_NOT_READJUDICATED`
  - observed:
    false;
  - expected:
    false.

Runtime matrices:

- exact B00 and D01–D14 IDs;
- exact 15 rows;
- exact 595 cases;
- all expected names closed;
- zero false acceptance/rejection/reason mismatch/skip/unexpected exception;
- stale 645 rejected.

Require runtime report and confirmation evidence pointers to resolve into the
current capsule or exact embedded frozen evidence.

──────────────────────────────────────────────────────────────────────────────
15. IMPLEMENTATION AUDIT EVIDENCE
──────────────────────────────────────────────── LIMITED TO PACKAGE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Authenticate and report:

- content bundle and role closure;
- implementation attempt lineage;
- current production and qualification source registries;
- source freeze;
- frozen requalification;
- production authority/security checks;
- E00/G00–G29 crosswalk;
- documentary lifecycle and writer ownership;
- 946-case negative result;
- 137-case contradiction result;
- 766/333 field-map result;
- producer rehearsal A/B evidence;
- Attempt-2 bounded failure evidence;
- implementation confirmation evidence;
- constructed-subject evidence domain;
- fresh audit-owned behavioral causals;
- fresh source-external validation;
- security/authority closure.

Do not execute implementation production source.

Do not treat historical report prose as authority.

Separate:

- direct package findings;
- audit findings;
- derivative findings;
- mixed findings;
- unresolved evidence.

Every direct package finding requires direct current audit evidence.

──────────────────────────────────────────────────────────────────────────────
16. CLEANUP AND FIXED-INPUT EQUALITY
──────────────────────────────────────────────────────────────────────────────

Authenticate:

cleanup/cleanup-result.json

Require canonical `cleanup_rows`.

Require exact set equality:

created
=
inventoried
=
evidence-retained
=
cleanup rows
=
twice absent

Equal empty sets pass.

Require zero process, descriptor, cache, and bytecode survivors.

Authenticate:

closing/fixed-input-closing-equality.json

Require exact opening/closing equality for:

- final PYZ v2;
- final authority v3;
- current content bundle;
- current content authority.

Compare:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

──────────────────────────────────────────────────────────────────────────────
17. FINDINGS, DEPENDENCY GRAPH, AND PRESEAL RESULT
──────────────────────────────────────────────────────────────────────────────

Authenticate:

analysis/findings-and-dependency-graph.json
closeout/preseal-substantive-result.json

Require complete finding ownership:

- package;
- audit;
- derivative;
- mixed;
- unresolved.

Require dependency edges.

Require severity.

Require exact first blocker when any.

Preseal result must be:

- nonauthoritative;
- bound to complete findings and phase states;
- explicit intended disposition:
  ACCEPT,
  BLOCK,
  or AUDIT_PROVENANCE_MISMATCH;
- `terminal_closure_required=true`.

No package ACCEPT or BLOCK is final before terminal closure.

──────────────────────────────────────────────────────────────────────────────
18. TERMINAL CAPSULE CLOSURE
──────────────────────────────────────────────── LIMITED TO AUTHORITY CHECKS
────────────────────────────────────────────────

Authenticate:

closeout/temporal-final-inventory.json
terminal/terminal-result.json
manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json

Require:

- temporal inventory includes root once;
- temporal exclusions exact;
- temporal immediate reprojection passes;
- A and B exist;
- A/B bytes identical;
- A/B identities exact;
- both manifests represent the final frozen namespace;
- independent final reprojection passes;
- root row exactly once;
- no empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- directory mode 0700;
- file mode 0600;
- no cache or bytecode;
- seal transition count one;
- no postseal filesystem or process operation.

Require the terminal stdout frame to bind:

- final verdict;
- audit root;
- preseal result;
- terminal result;
- temporal inventory;
- A;
- B;
- A/B equality;
- final reprojection;
- root-row count;
- seal-transition count;
- terminal marker;
- no-postseal result.

If terminal closure fails:

- wrapper verdict:
  AUDIT_PROVENANCE_MISMATCH;
- do not promote preseal ACCEPT or BLOCK.

──────────────────────────────────────────────────────────────────────────────
19. FINAL VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

A. ACCEPT

Report ACCEPT only when:

- all launch/provenance gates pass;
- parent self-authentication passes;
- audit evidence is complete;
- no direct blocking package finding remains;
- preseal intended disposition is ACCEPT;
- terminal frame says ACCEPT;
- terminal closure passes;
- cleanup/input equality pass.

State scope:

- accepts only the audited Generation-2 reconstruction-parent implementation
  package under this frozen audit contract;
- does not establish current-subject correctness;
- does not establish product/runtime readiness;
- does not authorize publication, deployment, target audit, or A6.

Do not construct the current schema subject.

B. BLOCK

Report BLOCK only when:

- all launch/provenance gates pass;
- at least one direct package blocker exists;
- finding/dependency evidence is complete;
- preseal intended disposition is BLOCK;
- terminal frame says BLOCK;
- terminal closure passes;
- cleanup/input equality pass.

Do not repair.

C. AUDIT_PROVENANCE_MISMATCH

Report AUDIT_PROVENANCE_MISMATCH for any failure of:

- fixed-input authentication;
- authority-v3 coherence;
- top-level process custody;
- stream/framing contract;
- locator/root authentication;
- parent self-authentication;
- phase/evidence completeness;
- child custody;
- runtime report/confirmations/matrices;
- finding ownership;
- cleanup;
- fixed-input equality;
- temporal/manifests;
- final reprojection;
- seal/no-postseal proof.

Do not retry or begin another reconciliation in this task.

──────────────────────────────────────────────────────────────────────────────
20. NO FOLLOW-ON EXECUTION
──────────────────────────────────────────────── LIMITED TO THIS TASK
────────────────────────────────────────────────

After reporting the final verdict:

- stop;
- preserve all four fixed files;
- preserve the audit capsule unchanged;
- do not clean the audit capsule;
- do not construct the current schema subject;
- do not run product process self-test;
- do not run product construct mode;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not stage, commit, or push;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete result inline.

Private paths may supplement but not replace findings and identities.

Required wrapper sections:

1. Exact primary verdict
2. PYZ v2 identity
3. Authority-v3 identity
4. Content-bundle identity
5. Content-authority identity
6. Stable prelaunch authentication
7. Authority-v3 coherence
8. PYZ member/governance closure
9. Platform-capture preflight
10. Exact real argv
11. Exact cwd
12. Exact submitted environment
13. Top-level platform custody
14. Raw stdout identity and framing
15. Raw stderr identity and framing
16. Exit code and signal
17. Exact audit-root locator
18. Audit-root identity
19. Terminal-frame identity and fields
20. Parent runtime self-authentication
21. Three-role interpreter tuple result
22. Runtime environment crosswalk
23. P00–P24 phase results
24. Child-process ledger
25. Child-process custody result
26. Content bundle and role closure
27. Implementation attempt/freeze/source closure
28. Production authority and security
29. E00/G00–G29 crosswalk
30. Documentary lifecycle/writer ownership
31. Runtime matrix evidence
32. 946-case negative evidence
33. 137-case contradiction evidence
34. 766/333 field-map evidence
35. Producer rehearsal evidence
36. Attempt-2 bounded failure evidence
37. Implementation-confirmation evidence
38. Constructed-subject evidence
39. Fresh behavioral causals
40. Fresh source-external validation
41. Security/authority closure
42. Runtime R01–R66 report
43. Runtime 81-name confirmations
44. Complete findings registry
45. Finding ownership
46. Dependency graph
47. Severity-ranked findings
48. Preseal substantive disposition
49. Cleanup
50. Fixed-input closing equality
51. Temporal-inventory identity
52. Manifest A identity
53. Manifest B identity
54. Independent terminal reprojection
55. Terminal topology and modes
56. Seal transition and marker
57. No-write-after-seal
58. Confirmation current subject was not constructed
59. Confirmation no product/runtime/target/A6 activity occurred
60. Remaining uncertainty and nonclaims
61. Explicit wrapper confirmations

Required wrapper confirmations:

FINAL_PYZ_V2_IDENTITY_MATCHED
FINAL_AUTHORITY_V3_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
AUTHORITY_V3_CURRENT_AND_COHERENT
PYZ_V2_MEMBER_SET_CLOSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_FROM_EXACT_PARENT_LOCATOR_USED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
PARENT_RUNTIME_SELF_AUTHENTICATION_RETAINED
INTERPRETER_OBSERVATION_TUPLE_PASSED
RUNTIME_ENVIRONMENT_POLICY_PASSED
CAPSULE_PRIMARY_VERDICT_REPORTED_EXACTLY
COMPLETE_RUNTIME_REPORT_RETAINED
COMPLETE_RUNTIME_CONFIRMATIONS_RETAINED
EVERY_REQUIRED_PHASE_TERMINAL
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_RESULT_RETAINED
FIXED_INPUT_CLOSING_EQUALITY_RETAINED
TEMPORAL_INVENTORY_RETAINED
MANIFEST_A_RETAINED
MANIFEST_B_RETAINED
MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_PASSED
ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_SEAL
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Source

:chatgpt-content-reference{index="0"}[Attached Codex report](sandbox:/mnt/data/Pasted%20text.txt)

**Confidence:** 0.999 that the clean harness v2 and authority v3 are qualified for exactly one fresh audit; 0.999 that no substantive implementation audit has yet occurred; 0.995 that no further harness, documentary, or authority repair is justified before the audit; 0.98 that the one-shot wrapper above is sufficiently strict without inventing stronger authority requirements than the sealed contracts.
