## Assessment

`AUDIT_PROVENANCE_MISMATCH` is correct, and this attempt produced **no finding about the repaired importer**. The audit stopped before inspecting the repaired package, its contracts, the state machine, causals, validation, or manifests.

The defect is entirely in Carrier 0001:

> It selected the launcher, wrapper, and interpreter through heuristic filename/content scoring and “first viable path” selection.

That violates the closed provenance model. Those inputs already have exact authoritative paths and identities; discovery is neither necessary nor permitted. In particular:

- Python has one exact absolute path and hash.
- The wrapper and launcher have exact relative paths under one exact qualified-package root.
- The CLI and request contracts have exact relative paths and hashes.
- The environment policy has one exact relative path whose identity is bound by the qualified package’s manifest.
- There must be no candidate list, scoring, glob, recursive search, PATH lookup, fallback, or “first viable” behavior.

This does **not** justify another importer implementation or another process package. It requires one wholly fresh audit attempt whose sole bootstrap exception uses a literal, fail-closed process-input map. Everything after bootstrap remains governed by the previous full audit brief.

Send this prompt to Codex:

```text
FRESH INDEPENDENT AUDIT RETRY —
VALIDATION-CUSTODY V3 BOOTSTRAP IMPORTER V1 AUDIT REPAIR,
WITH LITERAL EXACT-PATH PROCESS BOOTSTRAP

Repeat the immediately preceding complete independent-audit brief from the
beginning with a wholly fresh audit root.

All audit targets, supplied roots, fixed identities, four-auditor assignments,
correctness requirements, causals, validation requirements, process-ledger
requirements, closing requirements, verdict rules, and required inline-report
items remain unchanged unless explicitly replaced below.

This prompt replaces only Carrier 0001’s process-input selection and bootstrap
materialization rules.

Do not modify or repair the repaired importer package.
Do not implement another process package.
Do not resume or clean the failed audit root.
Do not inspect the candidate repository, Strategic B, V1/V2/V3 targets,
product source, or unrelated evidence before the opening gate permits it.
Do not run Git before the opening gate.
Do not use the network.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PRIOR FAILED AUDIT
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-lul5oumc

Treat it as immutable, nonqualifying process-failure evidence.

Its only adopted finding is:

Carrier 0001 selected Python, launcher, and wrapper inputs through heuristic
filename/content scoring and “first viable path” selection instead of exact
authoritative paths and identities.

Do not:

- resume it;
- repair it;
- clean it;
- reuse its auditors;
- reuse partial correctness work;
- use any selected process input from it as current authority.

The failed attempt contains no repaired-importer correctness finding.

──────────────────────────────────────────────────────────────────────────────
2. EXACT LITERAL PROCESS-INPUT MAP
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 must use only the following exact literal roots and paths.

No path discovery or candidate selection is permitted.

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Required identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Permission bits, device/inode, uid/gid, timestamps, flags, xattrs, and ancestor
posture are report-only.

Do not reject mode 0775.
Do not use `which`, PATH lookup, a shebang, candidate enumeration, or a fallback
interpreter.

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Exact wrapper:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/source/phase_runner.py

Required wrapper identity:

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- regular:
  true
- links:
  1
- mode:
  0600

Exact launcher:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/source/wrapped_carrier_launcher.py

Required launcher identity:

- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e
- regular:
  true
- links:
  1
- mode:
  0600

Exact phase-runner CLI contract:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/phase-runner-cli-contract-v1.json

Required identity:

- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Exact carrier-request contract:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/carrier-request-contract-v1.json

Required identity:

- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Exact environment-observation policy:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/environment-observation-policy-v1.json

Its exact type, mode, links, size, and SHA-256 must be obtained from the exact
row for that exact relative path in the authenticated qualified-package
manifest.

Do not find it through:

- filename matching;
- content search;
- role scoring;
- recursive candidate discovery;
- a first matching JSON object.

Qualified-package manifests:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/manifest/qualification-manifest-a-v1.json

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/manifest/qualification-manifest-b-v1.json

Required identity:

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- byte-identical:
  required

The exact five process artifacts are therefore:

1. `source/phase_runner.py`
2. `source/wrapped_carrier_launcher.py`
3. `contract/phase-runner-cli-contract-v1.json`
4. `contract/carrier-request-contract-v1.json`
5. `contract/environment-observation-policy-v1.json`

No sixth process artifact may be selected or copied.

──────────────────────────────────────────────────────────────────────────────
3. FORBIDDEN BOOTSTRAP SELECTION BEHAVIOR
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 must contain no process-input selection using:

- `glob`;
- `rglob`;
- `os.walk`;
- recursive directory search;
- filename scoring;
- content scoring;
- role scoring;
- “first viable” selection;
- “best candidate” selection;
- candidate lists;
- fallback paths;
- `which`;
- PATH lookup;
- shebang resolution;
- newest/latest selection;
- prefix scanning;
- searching all Python executables;
- searching all launcher-like files;
- searching all wrapper-like files.

Listing the qualified package after its exact root and manifests have been
authenticated is permitted only for complete manifest closure. It must not
influence process-input selection.

If any exact literal path is absent or mismatched:

- stop immediately;
- retain a canonical bootstrap failure;
- do not try an alternative;
- do not score another candidate;
- return AUDIT_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
4. RETAINED EXACT-PATH BOOTSTRAP MAP
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 must retain and fsync:

opening/bootstrap-process-input-map.json

before copying any process artifact.

Required fields:

- schema;
- selection_method:
  `literal-exact-path-no-discovery-no-fallback`;
- pinned_python:
  path, version, size, SHA-256, regular, links;
- qualified_launcher_root:
  path and required root identity;
- wrapper:
  exact absolute path, expected identity;
- launcher:
  exact absolute path, expected identity;
- phase_runner_cli_contract:
  exact absolute path, expected identity;
- carrier_request_contract:
  exact absolute path, expected identity;
- environment_observation_policy:
  exact absolute path and identity derived from the exact manifest row;
- manifest_a:
  exact path and identity;
- manifest_b:
  exact path and identity;
- exact_five_relative_paths;
- alternative_candidates_considered:
  0;
- fallback_allowed:
  false;
- discovery_used:
  false.

For every input record:

- expected identity;
- observed identity;
- equality;
- source of expected identity:
  literal prompt or exact manifest row;
- disposition.

──────────────────────────────────────────────────────────────────────────────
5. CARRIER 0001 ORDER
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 is the sole unwrapped bootstrap exception.

It must perform this exact high-level order:

1. Allocate the fresh audit root with `tempfile.mkdtemp`, umask 077.
2. Retain and fsync bootstrap-start.
3. Emit the exact fresh audit-root locator.
4. Verify the exact pinned Python path and identity.
5. Verify both qualified-package manifest paths and identities.
6. Parse both manifests under the already reconciled exact grammar.
7. Require the manifest pair byte-identical.
8. Read the exact manifest rows for the exact five process-artifact paths.
9. Verify the five exact source paths against those rows.
10. Retain `bootstrap-process-input-map.json`.
11. Copy exactly the five artifacts into the fresh audit root.
12. Reopen and verify every copied artifact.
13. Generate the fresh launcher identity record.
14. Generate the fresh fixed-environment record.
15. Generate the fresh root-bound launch contract.
16. Generate and retain the exact rebinding proof.
17. Create the audit-owned Carrier 0002 self-check payload and request.
18. Retain bootstrap-outcome.

Carrier 0001 must use only Python standard-library operations in-process.

It must launch no subprocess.
It must invoke no shell.
It must run no utility command.
It must not inspect the repaired importer target package until the process
self-check and opening process gate pass.

──────────────────────────────────────────────────────────────────────────────
6. EXACT DESTINATION PATHS
──────────────────────────────────────────────────────────────────────────────

Use one fixed destination map in the fresh audit root.

At minimum:

source/phase_runner.py
source/wrapped_carrier_launcher.py
contract/phase-runner-cli-contract-v1.json
contract/carrier-request-contract-v1.json
contract/environment-observation-policy-v1.json
opening/qualified-launcher-source-identity.json
opening/fixed-environment-observation.json
contract/wrapped-carrier-launch-contract-v1.json
opening/launch-contract-root-rebinding-v1.json

The Carrier 0002 payload and request paths must follow the exact conventions
already accepted by the qualified-launcher package and prior audit prompt.

No destination may be discovered from directory contents.

Every destination must be created exclusively at mode 0600.

──────────────────────────────────────────────────────────────────────────────
7. EXACT SOURCE AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

For every exact source path:

- open no-follow;
- require regular file;
- require links 1;
- require physical mode 0600 where specified;
- verify size;
- verify SHA-256;
- read complete bytes through the authenticated descriptor;
- reject identity change before close;
- do not use pathname fallback;
- do not silently normalize content.

For the environment-observation policy, use only the expected identity from
the exact supplied-manifest row for:

`contract/environment-observation-policy-v1.json`

Do not use a role ledger or report as a substitute for the manifest identity.

──────────────────────────────────────────────────────────────────────────────
8. EXACT PINNED-PYTHON AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Open and verify only:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Do not inspect other Python executables.

Require only the closed acceptance fields:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Mode remains report-only.

The interpreter path in every post-bootstrap launch contract and constructed
argv must be this exact path.

──────────────────────────────────────────────────────────────────────────────
9. PROCESS SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

After Carrier 0001 succeeds, Carrier 0002 must be the first post-bootstrap
local process.

Carrier 0002 must use:

- exact copied launcher;
- exact copied wrapper;
- exact pinned interpreter;
- exact copied CLI and request contracts;
- fresh root-bound launch contract;
- audit-owned self-check payload.

Require:

- complete request;
- complete constructed-launch record;
- complete phase-start;
- complete phase-outcome;
- parser admission;
- same-PID exec;
- expected-wrapper SHA exactly once;
- constructed fixed environment exact;
- every contract-owned observed value exact;
- additional post-exec environment key names diagnostic only;
- no child process;
- no target inspection;
- payload success;
- wrapper success.

Stop with AUDIT_PROVENANCE_MISMATCH on failure.

──────────────────────────────────────────────────────────────────────────────
10. POST-BOOTSTRAP PROCESS RULE
──────────────────────────────────────────────────────────────────────────────

After Carrier 0001, every local process must use the exact copied qualified
launcher and wrapper.

Every external child created within a payload must use the one retained child
recorder.

No direct Python, shell, utility, scanner, parser, validator, cleanup, or
closeout process may bypass the wrapped carrier.

A single bypass requires AUDIT_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
11. OPENING TARGET GATE AND CORRECTNESS WORK
──────────────────────────────────────────────────────────────────────────────

Only after the process self-check and child-recorder causals pass:

- perform the complete opening provenance gate;
- inspect the repaired importer package and all immutable inputs;
- start the four auditors;
- execute every correctness, causal, validation, matrix, determinism,
  handoff, security, chronology, and closing requirement from the immediately
  preceding complete audit brief unchanged.

In particular, retain the preceding requirements for:

- exact repaired source and contract identities;
- semantic touched-set comparison;
- explicit commit/publication nonauthority;
- 12-step model;
- completed-step semantics;
- failure ordinals 6, 8, and 10;
- complete 96-cell arithmetic reconciliation;
- production reachability of failure hooks;
- predecessor 56-case regression;
- repaired 46-case suite;
- retained independent 52-case validator;
- fresh audit-owned mutation matrix;
- two materializations;
- Carrier 0002 handoff;
- package closure;
- inventory chronology;
- closing equality;
- final wrapped closeout carrier.

Do not narrow any target-audit requirement.

──────────────────────────────────────────────────────────────────────────────
12. CARRIER INDEX ADDITIONS
──────────────────────────────────────────────────────────────────────────────

The final carrier index must explicitly bind Carrier 0001’s exact input
selection:

- selection method:
  `literal-exact-path-no-discovery-no-fallback`;
- exact Python path;
- exact launcher path;
- exact wrapper path;
- exact contract paths;
- exact expected and observed identities;
- manifest-row source for the environment policy identity;
- alternative candidates considered:
  0;
- fallback used:
  false;
- discovery used:
  false.

The carrier index must not claim that Carrier 0001’s process creation is
self-attested by the audit root.

Use:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

──────────────────────────────────────────────────────────────────────────────
13. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return AUDIT_PROVENANCE_MISMATCH if:

- Carrier 0001 uses any process-input discovery or heuristic selection;
- an exact literal input is missing or mismatched;
- any alternative candidate is considered;
- fallback is used;
- Carrier 0002 fails;
- any post-bootstrap local process bypasses wrapping;
- any phase or child record is missing;
- supplied-root opening/closing equality fails;
- final audit-capsule closure fails.

Return ACCEPT, BLOCK, or REJECT only under the substantive verdict rules from
the preceding complete audit brief after all process and provenance gates pass.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED REPORT ADDITIONS
──────────────────────────────────────────────────────────────────────────────

Retain every required report item and confirmation from the preceding complete
audit brief.

Additionally report:

1. Exact Carrier 0001 source identity.
2. Exact `bootstrap-process-input-map.json` identity.
3. Exact literal Python path.
4. Exact literal wrapper path.
5. Exact literal launcher path.
6. Exact literal CLI-contract path.
7. Exact literal request-contract path.
8. Exact literal environment-policy path.
9. Environment-policy expected identity and exact manifest row.
10. Alternative candidates considered.
11. Whether any discovery API was used.
12. Whether any fallback was used.
13. Exact five copied destination identities.
14. Exact process-self-check result.

Add these confirmations:

CARRIER_0001_LITERAL_EXACT_PATH_SELECTION_USED
CARRIER_0001_HEURISTIC_SELECTION_NOT_USED
CARRIER_0001_FILENAME_SCORING_NOT_USED
CARRIER_0001_CONTENT_SCORING_NOT_USED
CARRIER_0001_FIRST_VIABLE_SELECTION_NOT_USED
CARRIER_0001_ALTERNATIVE_CANDIDATES_CONSIDERED_ZERO
CARRIER_0001_FALLBACK_NOT_USED
PINNED_PYTHON_EXACT_LITERAL_PATH_USED
QUALIFIED_WRAPPER_EXACT_LITERAL_PATH_USED
QUALIFIED_LAUNCHER_EXACT_LITERAL_PATH_USED
CLI_CONTRACT_EXACT_LITERAL_PATH_USED
REQUEST_CONTRACT_EXACT_LITERAL_PATH_USED
ENVIRONMENT_POLICY_EXACT_LITERAL_PATH_USED
ENVIRONMENT_POLICY_IDENTITY_FROM_EXACT_MANIFEST_ROW
EXACT_FIVE_PROCESS_ARTIFACTS_COPIED
PROCESS_SELF_CHECK_PASSED

Retain all confirmations from the preceding full audit brief.
```

Do not implement another importer, launcher, or package-interface tranche. The next valid result should either be a substantive importer audit verdict or a genuinely identified exact-input mismatch.

**Source:** Codex’s latest `AUDIT_PROVENANCE_MISMATCH` report.

**Confidence:** 0.999 that this attempt contains no importer correctness finding; 0.995 that literal exact-path selection fully addresses the reported bootstrap defect; 0.97 that no additional implementation tranche is justified.
