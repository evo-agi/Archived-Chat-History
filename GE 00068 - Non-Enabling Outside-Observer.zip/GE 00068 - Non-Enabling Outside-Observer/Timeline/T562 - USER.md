Here is Codex's response:

# AUDIT_PROVENANCE_MISMATCH

The single authorized audit parent was created, so its authorization is permanently consumed. It exited unhandled before creating the capsule because the frozen harness requested the nonexistent subject file `validation/contract-schema-satisfiability-matrix-v2.json`. No retry, alternate-root search, or recovery execution occurred.

## Operative report

1. **Exact primary verdict:** The heading above. Classification: unhandled audit-parent failure, not an evidence-complete subject blocker.
2. **Final PYZ:** dev `16777234`, inode `182699827`, mode `0400`, nlink `1`, size `4589679`, SHA-256 `00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0`.
3. **Runtime authority:** inode `182699838`, mode `0400`, size `56463`, SHA-256 `9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0`.
4. **Profile v2:** inode `182745731`, mode `0400`, size `10412`, SHA-256 `2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c`.
5. **Certificate v3:** inode `182745737`, mode `0400`, size `19323`, SHA-256 `e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d`.
6. **Historical lineage:** Profile v1, certificate v2, and certificate v1 were certified noncurrent with zero active authorizations. Their certified hashes are respectively `14566342…58568`, `f0a5aedc…023f`, and `525ac09b…a50c`. They were not opened as launch controls.
7. **Replacement subject:** dev `16777234`, inode `182649818`, mode `0700`, UID/GID `501/20`; 73 entries, 12 directories, 61 files.
8. **Construction wrapper:** dev `16777234`, inode `182648782`, mode `0700`, UID/GID `501/0`; terminally closed, one production-parent launch, construction authorization consumed, independent audit previously pending.
9. **Accepted implementation chain:** audit inode `182593190`; wrapper inode `182593189`; authenticated accepted disposition and accepted-parent use.
10. **Content inputs:** bundle inode `181651092`, size `13598758`, SHA-256 `b494b918…13671`; authority inode `181651098`, size `19737`, SHA-256 `276fde7d…b1563`. The 479-member, eight-role closure passed.
11. **Stable prelaunch:** All fixed files received two stable no-follow reads; roots received stable opening inventories; strict JSON and exact-schema checks passed.
12. **Launch authority:** Exactly one active authorization, no prior execution or subject verdict, no promotion/rebinding, and coherent split-root policy.
13. **PYZ closure:** 89 members, 88 non-self registry rows, sorted names, stored compression, frozen timestamps, Unix metadata, mode `0600`, no duplicates/unsafe paths/cache/historical audit source.
14. **Wrapper evidence root:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6`; final inode `182768861`, mode `0700`, UID/GID `501/0`.
15. **Workspace:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-3ct88a_q`; inode `182768862`, mode `0700`, UID/GID `501/0`; preserved and empty.
16. **Capsule absence proof:** The direct child `audit-capsule` returned ENOENT twice immediately before launch. The wrapper did not create it.
17. **Platform preflight:** Executed once as PID `54821`; exact stdout/stderr, exit `23`, signal `null`, duration `15,253,500 ns`; workspace remained empty.
18. **Exact audit argv:** The required 23-element audit invocation was used, ending with `--output-root /private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-3ct88a_q/audit-capsule`.
19. **Process posture:** cwd was the workspace; exact five-variable non-inherited environment; stdin `DEVNULL`; shell/TTY/detachment false; foreground synchronous execution.
20. **Top-level custody:** Exactly one audit parent, PID `54822`, custody ID `95f43fd0613c54c71e6e7df30dd32e29017b6f19d25d09cabb81ed7a72bea53e`; created `2026-10-03T21:00:25.515215Z`, completed `21:00:25.562267Z`, duration `48,829,458 ns`; reaped and descriptors closed.
21. **Raw streams:** stdout size `0`, SHA-256 `e3b0c442…b855`; stderr size `2034`, SHA-256 `9fc4132c…9eec`. Both were retained before parsing.
22. **Exit/signal:** exit `1`; signal `null`; no custody loss.
23. **Terminal frame:** None. Stdout was empty and stderr contained an unhandled traceback, so strict terminal-frame promotion was correctly refused.
24. **Capsule authentication:** The authorized child remains absent. No alternative path was sought and the workspace was not misidentified as the capsule.
25. **Source/freeze/no-VCS:** The ten-source freeze and no-VCS contract authenticated prelaunch. No Git/VCS or network operation occurred.
26. **Subject terminal closure:** Opening and closing inventories were equal. Subject temporal identity `905a21d0…66b4`; manifests both `5f22e7e1…6758`; physical closure remained intact.
27. **Normative contract:** Unchanged through full subject-root opening/closing equality.
28. **Fifteen schema roles:** Authenticated in frozen prelaunch governance; not emitted as a terminal result of this run.
29. **Fourteen generated families:** Likewise authenticated prelaunch; no run capsule result.
30. **Role/family mapping:** Frozen model passed, including exclusion of the normative construction parent; not re-established terminally.
31. **Draft 2020-12 result:** Inherited qualification authenticated; no real-audit capsule result was produced.
32. **Contract-witness rows:** Not reached by the real audit.
33. **Schema-witness rows:** Not reached.
34. **Witness aggregate:** No per-run aggregate was created.
35. **Complete 946 result:** Not completed. The parent failed before oracle evaluation.
36. **Failed 946 rows:** None produced; this is not evidence that all rows passed.
37. **Complete 137 result:** Not completed. Loading its expected v2 matrix caused the exception.
38. **Failed 137 rows:** None produced.
39. **Dual-oracle crosswalk:** No oracle evaluation or crosswalk result was produced.
40. **766/333 field map:** Not reached.
41. **Documentary-validator closure:** Not reached.
42. **Confirmation derivation:** Not reached.
43. **Derivative-confirmation ledger:** Not created.
44. **Occupancy, lineage, producer status:** Prelaunch records authenticated; no terminal audit adjudication.
45. **Findings:** No authoritative findings record was created.
46. **Repair-owner registry:** No direct-blocker ownership record was created.
47. **Dependency graph:** Not created.
48. **A00–A15:** No phase records or A15 result were created.
49. **Child custody:** Both wrapper-created processes were reaped with descriptors closed; no capsule child ledger exists.
50. **Audit cleanup:** No capsule existed to clean. No workspace/capsule cleanup occurred after process creation.
51. **Supplied-root equality:** Cannot be established without a terminal frame and capsule.
52. **Wrapper fixed-input equality:** Passed for six fixed files, eleven support files, four roots, their inventories, and both interpreter identities.
53. **Audit temporal identity:** Not created.
54. **Audit manifests:** Neither audit manifest was created.
55. **Audit A/B equality:** Not applicable because neither manifest exists.
56. **Audit final reprojection:** Not performed.
57. **Audit physical topology:** No capsule exists. The preserved workspace is empty and mode `0700`; subject topology remained valid.
58. **A15/closure agreement:** Not established.
59. **Seal/no-postseal:** No audit seal transition occurred.
60. **Subject unchanged:** Confirmed by full opening/closing identity and inventory equality; no cleanup performed.
61. **Authority:** No current-authority promotion or rebinding.
62. **Excluded activity:** No product/live-service invocation, target audit, runtime-validation rerun, publication, deployment, or A6 activity.
63. **Remaining uncertainty/nonclaims:** No authoritative subject acceptance or block disposition exists. The failure establishes only that this frozen harness cannot complete against this exact subject because its required v2 matrix path is absent.
64. **Evidence and confirmations:** [Final wrapper report](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6/report/final-operative-report-v1.json), [process custody](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6/process/audit-parent-custody-v1.json), [raw stderr](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6/streams/audit-parent.stderr.raw), [prelaunch evidence](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6/opening/prelaunch-authentication-v1.json), and [closing equality](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6/closing/wrapper-fixed-input-closing-equality-v1.json).

### Confirmed wrapper facts

`FINAL_AUDIT_PYZ_IDENTITY_MATCHED`, `FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED`, `CURRENT_PROFILE_V2_IDENTITY_MATCHED`, `CURRENT_CERTIFICATE_V3_IDENTITY_MATCHED`, `PROFILE_V1_NOT_CURRENT`, `CERTIFICATE_V2_NOT_CURRENT`, `CERTIFICATE_V1_NOT_CURRENT`, `EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION`, `REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED`, `REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED`, `ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED`, `CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED`, `CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED`, `CURRENT_SPLIT_ROOT_LAUNCH_AUTHORITY_COHERENT`, `AUDIT_PYZ_MEMBER_SET_89_CLOSED`, `WRAPPER_WORKSPACE_ALLOCATED`, `WRAPPER_WORKSPACE_EMPTY_BEFORE_LAUNCH`, `CAPSULE_CHILD_ABSENT_BEFORE_LAUNCH`, `WRAPPER_DID_NOT_PRECREATE_CAPSULE_ROOT`, `PLATFORM_CAPTURE_PREFLIGHT_PASSED`, `PREFLIGHT_WORKSPACE_REMAINED_EMPTY`, `PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT`, `REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE`, `FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_CONSUMED`, `QUALIFICATION_MODE_NOT_EXECUTED`, `SYNTHETIC_MODE_NOT_EXECUTED`, `REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED`, `ADMINISTRATIVE_CONTINUATION_NOT_USED`, `NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS`, `RAW_STDOUT_RETAINED`, `RAW_STDERR_RETAINED`, `PLATFORM_EXIT_AND_SIGNAL_RETAINED`, `AUDIT_ROOT_SCAN_NOT_PERFORMED`, `CAPSULE_ROOT_DISTINCT_FROM_WORKSPACE`, `CLEAN_AUDIT_SOURCE_FREEZE_AUTHENTICATED`, `NO_GIT_OR_VCS_INVOCATION`, `SUBJECT_TERMINAL_REPROJECTION_PASSED`, `NORMATIVE_CONTRACT_BYTES_UNCHANGED`, `WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED`, `ALL_CREATED_CHILDREN_REAPED`, `ALL_CHILD_DESCRIPTORS_CLOSED`, `REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED`, `REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED`, `CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED`, `CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED`, `NO_NETWORK_CONTACT`, `NO_GIT_INVOCATION`, `NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION`, `NO_TARGET_AUDIT_EXECUTED`, `NO_RUNTIME_VALIDATION_RERUN`, `NO_A6_ACTIVITY`, `NO_SUBAGENTS_CREATED`.

### Prelaunch-authenticated only; not promoted as this run’s terminal result

`EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES`, `EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES`, `NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY`, `SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE`, `ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID`, `FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID`, `FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID`, `WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE`, `EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET`, `NO_HARDCODED_CONFIRMATION_SUCCESS`, `GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED`, `NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT`, `NO_FAILED_ARTIFACT_CURRENT`, `IMPLEMENTATION_PRESENT_FALSE`, `IMPLEMENTATION_AUTHORITY_FALSE`, `PRODUCER_PACKAGE_NOT_SELF_PROMOTED`, `INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED`.

### Not established by the failed real audit

`TERMINAL_FRAME_STRICTLY_PARSED`, `TERMINAL_FRAME_ROOT_EQUALS_CAPSULE_CHILD`, `GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED`, `EVERY_NONPASSING_946_ROW_RETAINED`, `CONTRADICTION_REGRESSION_137_COMPLETED`, `EVERY_NONPASSING_137_ROW_RETAINED`, `DUAL_ORACLE_RESULTS_AGREE`, `NO_ORACLE_EXCEPTION`, `EXACT_GOVERNED_OUTCOME_VOCABULARY_USED`, `CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED`, `ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT`, `ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED`, `CONFIRMATION_EVIDENCE_MAP_COMPLETED`, `DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS`, `CURRENT_ROLE_OCCUPANCY_COMPLETE`, `EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE`, `EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER`, `FINDING_OWNERSHIP_COMPLETE`, `EVERY_REQUIRED_AUDIT_PHASE_TERMINAL`, `A15_STATUS_EQUALS_FINAL_CLOSURE_PASS`, `CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS`, `AUDIT_CLEANUP_SET_EQUALITY_PASSED`, `CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED`, `AUDIT_TEMPORAL_INVENTORY_CREATED`, `AUDIT_TEMPORAL_INVENTORY_VERIFIED`, `AUDIT_MANIFEST_A_CREATED`, `AUDIT_MANIFEST_B_CREATED`, `AUDIT_MANIFESTS_BYTE_IDENTICAL`, `AUDIT_TERMINAL_REPROJECTION_PASSED`, `AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE`, `NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE`, `NO_SYMLINK_OR_SPECIAL_OBJECT`, `NO_MULTIPLY_LINKED_FILE`, `ALL_AUDIT_DIRECTORY_MODES_0700`, `ALL_AUDIT_FILE_MODES_0600`, `NO_AUDIT_CACHE_OR_BYTECODE_RETAINED`, `SINGLE_AUDIT_SEAL_TRANSITION`, `NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL`.

No future real-audit authorization remains under this authority.
