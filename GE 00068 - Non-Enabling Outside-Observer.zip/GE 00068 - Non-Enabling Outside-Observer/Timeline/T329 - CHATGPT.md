## Assessment

The diagnostic is conclusive: **the supplied inputs are valid, and no bootstrap-package finding has yet been adjudicated**.

Two opening-harness defects must be corrected together:

1. The physical root row `"."` must be compared symmetrically. Removing it only from the observed set manufactured `manifest_only:["."]`.
2. The two manifest files are declared self-exclusions. They must be authenticated by exact exclusion membership, pinned identities, and byte equality—not required to possess ordinary manifest rows.

The other observations are robustness improvements to the reconciliation harness, not new package findings: retain exact failing-path context and traceback bytes, mark roots as opened when first accessed, and create the final path-resolution record exclusively.

No package implementation tranche is warranted. The next pass should be the complete parent-owned Findings A–K reconciliation with the corrected opening algorithm.

```text
FRESH PARENT-OWNED FINDINGS RECONCILIATION —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP PACKAGE V1
WITH CORRECT ROOT-ROW AND MANIFEST-EXCLUSION SEMANTICS

This is a bounded package-findings reconciliation.

It is not:

- an independent package-acceptance audit;
- an implementation task;
- a package repair;
- a V3 target audit;
- a product or repository audit.

Do not modify or repair the bootstrap package.
Do not modify, resume, clean, or seal any failed reconciliation root.
Do not modify the failed package-audit root.
Do not modify any other supplied root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository or product tests.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents or direct auditors.

Use one parent-owned reconciliation process.

Return exactly one primary verdict:

BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED
BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_NO_REPAIR_REQUIRED
BOOTSTRAP_PACKAGE_FINDINGS_EVIDENCE_INSUFFICIENT
RECONCILIATION_PROVENANCE_MISMATCH

OBJECTIVE

Independently adjudicate every package-level observation retained by the
nonqualifying package audit at:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv

Classify every observation as exactly one of:

1. confirmed implementation defect;
2. confirmed contract/schema defect;
3. confirmed validation/evidence defect;
4. failed-audit method defect only;
5. report-only hardening opportunity;
6. disproved finding;
7. unresolved because indispensable evidence is absent.

Do not inherit any auditor’s classification or severity.

If at least one acceptance-affecting package defect is independently confirmed,
return:

BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED

and provide one exact bounded repair contract. Do not implement it.

──────────────────────────────────────────────────────────────────────────────
1. EXACT BOOTSTRAP PACKAGE
──────────────────────────────────────────────────────────────────────────────

BOOTSTRAP_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-be5v9nny

Expected root identity:

- device/inode:
  16777234 / 179120828
- physical mode:
  0700
- producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  33552 each
- SHA-256:
  cec56d4c9ac08c79ae7da58107fd56cd3389ba879ed566e327b4582ae27e259b
- byte-identical:
  required

Expected closure:

- 177 represented entries;
- 12 represented directories including `"."`;
- 165 represented nonmanifest regular files;
- 167 physical regular files including the two manifests;
- exactly two manifest self-exclusions;
- no symlink;
- no special object;
- no multiply linked regular file;
- no retained empty directory;
- directories mode 0700;
- regular files mode 0600 and link count 1.

Primary semantic sources:

source/full_audit_bootstrap_v1.py

- size:
  81613
- SHA-256:
  01fb237ef588241e7147abf92baa59009d0b159dd5bc5543e70f7f83d82b01f5

source/process_self_check_payload_v1.py

- size:
  18433
- SHA-256:
  a6e83b46b4696b92a2a6cd66b9e7709d51f1ce376703138cf808f10e7582642e

source/qualification_harness_v1.py

- size:
  66641
- SHA-256:
  47d12bc390fd41a255f8b0adfa8e02826b8f25419195a3ac8f8fa596a0666fe8

Implementation report:

closeout/final-implementation-report-v1.md

- size:
  3062
- SHA-256:
  7f4f8841130917fa672a24b5c3ad85cdfe1ce29b9aa09e0241dfe58a10363a29

Independently bind all other package objects through the verified manifests.
Do not use the implementation report as artifact authority.

──────────────────────────────────────────────────────────────────────────────
2. EXACT FAILED PACKAGE-AUDIT INTERFACE
──────────────────────────────────────────────────────────────────────────────

FAILED_PACKAGE_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv

Expected root identity:

- device/inode:
  16777234 / 179156020
- physical mode:
  0700

Its `AUDIT_PROVENANCE_MISMATCH` verdict is nonqualifying and is not a package
verdict.

Required ordinary manifested paths:

1. `closeout/final-audit-report.md`
2. `analysis/severity-ranked-findings.json`
3. `provenance/complete-child-process-ledger.json`
4. `auditors/auditor-1-report.md`
5. `auditors/auditor-2-report.md`
6. `auditors/auditor-3-report.md`
7. `closeout/supplied-root-closing-equality.json`
8. `fixtures/cleanup-completion.json`

Required self-excluded manifest paths:

9. `manifest/canonical-manifest-a-v1.json`
10. `manifest/canonical-manifest-b-v1.json`

Expected manifest identities:

- size:
  12860 each
- SHA-256:
  6935ae04a130a5f1f27fd8c2f0cd9b829ba50213c909652292ab4da2f006d12b
- byte-identical:
  required

Do not require:

- `auditors/direct-auditor-schedule-v2.json`;
- `closeout/terminal-audit-manifest-a-v1.json`;
- `closeout/terminal-audit-manifest-b-v1.json`;
- an Auditor 4 report.

Those paths are absent by design or historical process stop and are not part of
this corrected interface.

──────────────────────────────────────────────────────────────────────────────
3. PRIOR FAILED RECONCILIATIONS
──────────────────────────────────────────────────────────────────────────────

Treat these roots as immutable harness-failure evidence only:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-findings-reconciliation-25gyidxd

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-findings-reconciliation-t75jioc1

The only adopted conclusions are:

A. The first root used incorrect required paths and an incorrect pre-manifest
   empty-directory rule.

B. The second root’s resolver self-check passed, but its manifest closure
   removed the observed `"."` row while retaining the manifest `"."` row.

C. The second root would next have incorrectly demanded ordinary manifest rows
   for the two explicitly self-excluded manifest files.

D. Neither root adjudicated package Findings A–K.

Do not resume, repair, clean, or use their package-finding conclusions.

──────────────────────────────────────────────────────────────────────────────
4. OPTIONAL SUPPORTING ROOTS
──────────────────────────────────────────────────────────────────────────────

Open only when a concrete Finding A–K requires them:

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

FAILED_PREDECESSOR_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-3_22cefi

Every optional root opened becomes subject to complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. FRESH RECONCILIATION ROOT
──────────────────────────────────────────────────────────────────────────────

The first operation must allocate one fresh private root beneath
`/Users/ds/Downloads` using `tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-findings-reconciliation-

Before inspecting any supplied root, retain and fsync:

opening/bootstrap-start.json
provenance/parent-source.py
provenance/parent-process-start.json

These records must bind:

- fresh root path;
- device/inode/mode;
- exact parent-source size and SHA-256;
- parent PID;
- cwd;
- umask;
- supplied roots inspected:
  false.

Create output directories lazily.

Do not create `manifest/` until terminal sealing.

Create `private/` only if temporary state is needed, and remove it before close.

Recommended terminal structure:

opening/
analysis/
causals/
validation/
provenance/
closeout/
manifest/

No direct auditors.
No subagents.

All retained directories mode 0700.
All retained files regular, single-link mode 0600.
No symlink, special object, or multiply linked file.
No retained empty directory at final close.

The no-empty-directory rule is terminal only. A directory may be transiently
empty during construction.

──────────────────────────────────────────────────────────────────────────────
6. PARENT AND CHILD PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

One parent process must perform bootstrap, opening provenance, Findings A–K,
closing equality, cleanup, and capsule finalization.

No administrative continuation is permitted.

The parent must catch and retain ordinary:

- opening failures;
- causal failures;
- validation failures;
- cleanup failures;
- closeout failures;
- manifest-generation failures.

Every external child process must use one retained child recorder.

For each child retain:

- contiguous ordinal;
- start record before spawn;
- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- reaping;
- descriptor closure;
- purpose;
- paths written;
- qualifying or failed/superseded status.

Pure in-process parsing, hashing, filesystem inspection, and record generation
do not require invented child records.

A child-record gap or uncaught parent termination requires:

RECONCILIATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
7. OPENING-HARNESS SELF-CHECKS
──────────────────────────────────────────────────────────────────────────────

Before opening a supplied root, run in-process audit-owned self-checks over
synthetic fixtures beneath the fresh root.

A. Relative-path resolver

Positive:

- `closeout/report.md`
- `analysis/findings.json`
- `auditors/auditor-1-report.md`
- `manifest/a.json`

Negative:

- absolute path;
- `../escape`;
- `a/../../escape`;
- empty path;
- `"."` as a required leaf;
- repeated separator yielding an empty component;
- basename-only substitution;
- root-level substitution for a nested path;
- symlink leaf;
- symlink ancestor.

B. Manifest-closure algorithm

Create a synthetic physical tree whose canonical manifest contains:

- root row `"."`;
- one child directory;
- one regular file;
- exactly two self-excluded manifest files.

Require:

1. physical observed set includes `"."`;
2. manifest entry set includes `"."`;
3. physical comparison set is:
   `all_physical_paths - exact_exclusions`;
4. `"."` is not removed from either side;
5. exact equality passes;
6. missing root row rejects;
7. altered root mode rejects;
8. extra physical path rejects;
9. missing ordinary path rejects;
10. unexpected exclusion rejects;
11. excluded manifest missing rejects;
12. excluded manifest identity mismatch rejects;
13. non-byte-identical manifest pair rejects.

C. Required-path authentication

Require:

- ordinary required paths use exact manifest rows;
- excluded manifest paths use exact exclusion membership and pinned
  manifest-pair authentication;
- excluded manifest paths are not required to have ordinary rows.

Retain:

validation/opening-harness-self-check.json

Require exact case-name closure, zero false acceptance, and zero false
rejection.

A self-check failure requires:

RECONCILIATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
8. CORRECT MANIFEST-CLOSURE ALGORITHM
──────────────────────────────────────────────────────────────────────────────

For each supplied capsule:

1. Enumerate the physical root and every descendant with lstat/no-follow
   semantics.
2. Represent the root as `"."`.
3. Parse both canonical manifests strictly.
4. Require the manifest pair byte-identical.
5. Require exact exclusion membership.
6. Let:
   `physical_paths = all observed relative paths, including "."`
7. Let:
   `comparison_paths = physical_paths - manifest_exclusions`
8. Let:
   `listed_paths = every manifest entry path`
9. Require:
   `comparison_paths == listed_paths`
10. Do not discard `"."`.
11. Compare every manifest entry’s exact fields with its physical object.
12. Authenticate excluded manifests separately through:
    - exact exclusion membership;
    - exact path;
    - regular type;
    - mode 0600;
    - link count 1;
    - pinned size;
    - pinned SHA-256;
    - byte equality.

Retain for each capsule:

- physical count;
- exclusion count;
- comparison count;
- manifest-entry count;
- actual-only paths;
- manifest-only paths;
- failed rows;
- manifest-pair identity;
- excluded-manifest identity result;
- pass/fail.

──────────────────────────────────────────────────────────────────────────────
9. CORRECT REQUIRED-PATH AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Retain the exact ten-path contract before processing.

For ordinary paths 1–8:

- resolve exactly beneath the failed package-audit root;
- require one exact ordinary manifest row;
- compare type, mode, links, size, and SHA-256.

For manifest paths 9–10:

- require exact membership in the manifest exclusion set;
- require the pinned type/mode/link/size/SHA identities;
- require byte equality;
- do not require an ordinary manifest row.

Retain:

opening/failed-audit-required-path-resolution.json

Create it exclusively at mode 0600.

Before retaining the terminal record, keep in parent state:

- current ordinal;
- current relative path;
- current absolute path;
- already passed row summaries.

On failure, the failure record must contain that context.

──────────────────────────────────────────────────────────────────────────────
10. FAILURE RECORD QUALITY
──────────────────────────────────────────────────────────────────────────────

Every retained parent failure record must include:

- schema;
- phase;
- operation;
- exception type;
- exception message;
- complete traceback path;
- traceback size and SHA-256;
- source path;
- source line if available;
- current ordinal;
- current relative path;
- current absolute path;
- partial artifacts;
- supplied roots opened;
- supplied roots mutated;
- whether Findings A–K began;
- next action.

Retain complete traceback bytes in a separate mode-0600 file.

Record a supplied root as opened when the first read begins, not only after its
inventory succeeds.

──────────────────────────────────────────────────────────────────────────────
11. OPENING GATE ORDER
──────────────────────────────────────────────────────────────────────────────

Use this order:

1. Allocate fresh root.
2. Retain bootstrap and parent source.
3. Establish child recorder.
4. Run ENOENT child causal.
5. Run `/usr/bin/true` child causal.
6. Run opening-harness self-checks.
7. Verify bootstrap-package identity and closure.
8. Verify failed package-audit identity and closure.
9. Verify all ten required paths under the corrected ordinary/excluded split.
10. Retain that the three historical nonexistent paths are explicitly
    nonrequired.
11. Capture complete opening inventories.
12. Confirm no root alias.
13. Retain:
    `opening/opening-gate-result.json`
14. Only after a passing gate begin Findings A–K.

Stop with `RECONCILIATION_PROVENANCE_MISMATCH` only for:

- actual supplied-root drift;
- actual required-input absence under this corrected contract;
- manifest mismatch;
- supplied-root mutation;
- aliasing;
- opening-harness self-check failure;
- child-process record failure;
- uncaught parent failure.

──────────────────────────────────────────────────────────────────────────────
12. CLOSED FINDING LEDGER
──────────────────────────────────────────────────────────────────────────────

Create one row for every Finding A–K.

Each row must contain:

- finding ID;
- exact failed-audit allegation and source;
- alleged owning source/contract/schema/record;
- exact source path and line range or JSON pointer;
- expected behavior;
- observed behavior;
- static evidence;
- audit-owned dynamic causal where safely possible;
- whether the failed-audit process violation affects the observation;
- classification:
  - implementation defect;
  - contract/schema defect;
  - validation/evidence defect;
  - failed-audit method defect;
  - hardening opportunity;
  - disproved;
  - unresolved;
- severity;
- acceptance effect;
- exact bounded repair requirement if confirmed;
- uncertainty and nonclaims.

No allegation is accepted merely because an auditor reported it.

──────────────────────────────────────────────────────────────────────────────
13. FINDING A — INTERPRETER ISOLATION FLAGS
──────────────────────────────────────────────────────────────────────────────

Allegation:

Production verifies interpreter bytes but records `-I -S -B` without verifying
actual importer runtime flags.

Inspect:

- bootstrap source;
- CLI contract;
- bootstrap start/outcome/result;
- pinned-interpreter verification;
- generated launch contract;
- producer tests.

Distinguish:

1. actual importer interpreter state;
2. configured future launcher/wrapper argv;
3. submitted argv;
4. observed runtime flags;
5. responsibility of the external caller versus the importer.

Using audit-owned roots, invoke the bootstrap safely with varied flags when
possible and without target access.

Classify:

- observed-state claim without observation:
  defect;
- accurate required future configuration:
  allegation disproved;
- ambiguous responsibility:
  contract defect.

Do not invent a new requirement.

──────────────────────────────────────────────────────────────────────────────
14. FINDING B — RECONCILIATION ROOT DEVICE/INODE
──────────────────────────────────────────────────────────────────────────────

Determine whether the reconciliation root’s device/inode is:

- acceptance-bearing;
- report-only;
- intentionally excluded in favor of literal path and authenticated complete
  content.

Inspect the package contract, lineage, verifier, tests, and report.

Use an audit-owned physically distinct byte-exact fixture to observe behavior.

Do not classify omission as a defect unless a closed contract requires physical
root identity.

──────────────────────────────────────────────────────────────────────────────
15. FINDING C — POST-COPY REVERIFICATION
──────────────────────────────────────────────────────────────────────────────

Determine whether copied destination files are genuinely reopened and freshly
observed after copy.

Inspect:

- copy function;
- initial verification;
- claimed post-copy re-verification;
- identity objects;
- no-follow behavior.

Run an audit-owned causal:

1. copy a valid process artifact;
2. mutate or replace the destination after initial copy verification;
3. invoke the actual production post-copy re-verification boundary;
4. observe accept/reject.

Do not mutate supplied roots.

Acceptance of the altered destination is a confirmed high-severity
implementation defect.

──────────────────────────────────────────────────────────────────────────────
16. FINDING D — AUTHORITY RECORD AGREEMENT
──────────────────────────────────────────────────────────────────────────────

Enumerate:

- main authority/nonauthority contract;
- every applicable schema;
- actual success records;
- actual failure records;
- self-check result;
- contract identity bindings.

Determine whether each record must:

A. repeat the complete map;
B. bind the main contract identity;
C. carry only record-local authority;
D. perform a specified combination.

Do not treat repetition as inherently required.

Confirm a defect only if:

- schema fields are omitted;
- a record claims standalone authority without binding;
- narrowing or widening is possible;
- a record contradicts the main contract;
- consumers can misinterpret record-local authority.

Otherwise classify audit overconstraint or hardening.

──────────────────────────────────────────────────────────────────────────────
17. FINDING E — SAME-PID EVIDENCE
──────────────────────────────────────────────────────────────────────────────

Inspect:

- launcher contract;
- launcher source;
- constructed-launch record;
- self-check payload/result;
- child recorder;
- producer handoffs.

Determine:

- promised PID fields;
- launcher pre-exec PID;
- payload PID;
- equality;
- whether child-recorder PID anchoring is required;
- whether constructed-launch PID can be forged by the payload;
- whether both producer handoffs satisfy the strongest promised equality.

Do not add recorder anchoring unless the contract requires it.

Classify implementation defect, evidence hardening, or audit overreach
separately.

──────────────────────────────────────────────────────────────────────────────
18. FINDING F — CLI AND WRAPPER-SHA BINDING
──────────────────────────────────────────────────────────────────────────────

Independently parse constructed argv from fresh audit-owned handoffs.

Verify:

- required options;
- cardinality;
- option/value association;
- canonical order;
- wrapper SHA occurrence count;
- wrapper SHA bound specifically to
  `--expected-wrapper-sha256`;
- payload path/size/hash;
- audit root;
- carrier/phase/entry;
- authorized operands;
- expected outputs.

Determine whether the self-check validates underlying values or only trusts an
aggregate conformance field.

Classify duplicated checks as hardening unless required by contract.

──────────────────────────────────────────────────────────────────────────────
19. FINDING G — HANDOFF NORMALIZATION
──────────────────────────────────────────────────────────────────────────────

Independently normalize the two producer handoff records.

Adjudicate differences at:

- `/environment_evidence/constructed_map_sha256`
- `/environment_evidence/launch_contract_map_sha256`

Determine:

- whether underlying maps differ only through root-bound HOME/TMPDIR;
- whether normalized maps are byte-identical;
- whether derived hashes must be recomputed after normalization;
- whether producer normalization omitted this;
- whether the contract requires raw, normalized, or semantic equality;
- whether the report overclaimed byte identity.

Classify runtime nondeterminism, normalizer/evidence defect, report overclaim,
or audit-normalization error.

Freeze the exact corrected normalization rule if needed.

──────────────────────────────────────────────────────────────────────────────
20. FINDING H — FAILURE ATOMICITY AND SUCCESS PUBLICATION
──────────────────────────────────────────────────────────────────────────────

Identify the exact success commit point.

Inspect:

- result/outcome write ordering;
- exclusive creation;
- fsync and close;
- parent-directory synchronization;
- late verification;
- exception handling after visible success;
- producer hooks and causals;
- cleanup.

Using audit-owned exact source copies or supported hooks, inject failures:

1. before success result creation;
2. during result write;
3. result fsync;
4. after result close before outcome creation;
5. during outcome write;
6. after outcome close;
7. parent/directory synchronization;
8. postpublication verification or cleanup if present.

For each retain:

- process exit;
- result and outcome posture;
- partial artifacts;
- retry posture;
- final classification.

Also identify every claimed producer causal whose source fixture or replay
input no longer exists.

Classify separately:

- implementation atomicity defect;
- validation coverage gap;
- unreproducible evidence;
- safe but undocumented commit point.

──────────────────────────────────────────────────────────────────────────────
21. FINDING I — SYNTHETIC OR HARD-CODED CASES
──────────────────────────────────────────────────────────────────────────────

For every producer and independent validation case record:

- name;
- claimed mechanism;
- actual code path;
- production source invoked:
  yes/no;
- real production input mutation:
  yes/no;
- static/schema-only:
  yes/no;
- hard-coded expected reason:
  yes/no;
- fixture retained:
  yes/no;
- report description accurate:
  yes/no.

Distinguish:

- legitimate static/source checks;
- legitimate schema mutations;
- real integration rejection causals;
- fabricated result parsing;
- self-fulfilling outcomes.

Static tests need not invoke the full importer, but must be described honestly.

Produce the exact overstated-case list.

──────────────────────────────────────────────────────────────────────────────
22. FINDING J — CONTRACT/SCHEMA ALIGNMENT
──────────────────────────────────────────────────────────────────────────────

Strictly compare every contract, schema projection, producer, and actual record
family.

Verify:

- required and optional keys;
- unknown-key behavior;
- types;
- enums;
- cardinality;
- canonical encoding;
- cross-field constraints;
- success/failure distinctions;
- authority fields;
- contract identity binding.

Run mutations for:

- missing contract-required field accepted by schema;
- schema-required field absent from implementation;
- unknown field;
- wrong type;
- wrong enum;
- success-only field in failure;
- failure-only field in success;
- authority narrowing;
- authority widening;
- contradictory status;
- stale contract identity.

Identify exact fail-open behavior rather than textual differences alone.

──────────────────────────────────────────────────────────────────────────────
23. FINDING K — LAYOUT, PLACEHOLDERS, AND SENSITIVE MATERIAL
──────────────────────────────────────────────────────────────────────────────

Classify every file created in a successful output root:

- schema;
- owner;
- lifecycle stage;
- consumer;
- authority;
- whether required before Carrier 0002;
- whether it exists merely to prevent an empty directory.

Reject false evidence of:

- auditor completion;
- target analysis;
- child execution;
- V3 result;
- closeout completion.

Perform a bounded sensitive-material scan over every package file.

Do not emit matched secret content.

Verify:

- production source writes only beneath its fresh audit root;
- qualification fixture writes are declared and bounded;
- no product or target path is accessed.

──────────────────────────────────────────────────────────────────────────────
24. FAILED-AUDIT PROCESS FINDING
──────────────────────────────────────────────────────────────────────────────

Record:

- Auditor 3 created and deleted four `/tmp` files.
- This was a failed-audit process-boundary defect.
- It is not a package defect.
- It made that audit nonqualifying.

Future acceptance recommendation:

- one parent-owned execution path;
- four parent-generated analytical perspectives;
- no tool-enabled direct auditors.

Retain parent-generated records:

analysis/perspective-contract-and-authority.json
analysis/perspective-runtime-and-causals.json
analysis/perspective-validation-and-lineage.json
analysis/perspective-security-and-artifacts.json

These are analyses, not independent authorities.

──────────────────────────────────────────────────────────────────────────────
25. REPAIR-BOUNDARY DECISION
──────────────────────────────────────────────────────────────────────────────

If one or more acceptance-affecting package defects are confirmed, produce one
closed proposed repair plan containing:

- confirmed findings only;
- exact touched semantic files;
- exact source changes;
- contract/schema changes;
- exact tests and causals;
- preserved behavior;
- non-goals;
- validation commands;
- provenance requirements;
- independent-audit requirements;
- stop conditions.

Do not implement it.

Do not bundle report-only hardening unless required for contract consistency.

If no repair is required:

- explain why every package observation is disproved or nonblocking;
- define one simplified parent-only acceptance audit;
- do not introduce another process package.

──────────────────────────────────────────────────────────────────────────────
26. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Do not mutate or clean supplied roots.

Retain complete inventories of reconciliation-owned fixtures before removing
them.

For each removed fixture/private root, perform two fresh `lstat` calls and
require ENOENT twice.

Verify no process or descriptor survivor.

──────────────────────────────────────────────────────────────────────────────
27. TERMINAL CAPSULE FINALIZATION
──────────────────────────────────────────────────────────────────────────────

Finalize in this exact order:

1. opening records;
2. complete finding ledger;
3. source-line crosswalk;
4. all causal records;
5. contract/schema comparison;
6. validation case-level adjudication;
7. four parent-owned perspective records;
8. repair plan or no-repair decision;
9. child-process ledger;
10. closing supplied-root equality;
11. cleanup and ENOENT records;
12. final report;
13. temporal final inventory;
14. create `manifest/`;
15. write manifest A;
16. write manifest B;
17. independently reproduce both manifests in memory;
18. perform no later filesystem write.

The temporal final inventory must explicitly exclude:

- itself;
- future manifest A;
- future manifest B.

The two terminal manifests must exclude only themselves and must cover the
temporal inventory.

Terminal requirements:

- no empty directory;
- all directories mode 0700;
- all files regular, single-link mode 0600;
- no symlink;
- no special object;
- exactly two manifest self-exclusions;
- byte-identical manifests.

Do not create a postmanifest record.

Terminal manifest identities belong in the inline response, not in a file
written after sealing.

──────────────────────────────────────────────────────────────────────────────
28. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED

when at least one acceptance-affecting implementation, contract/schema, or
validation/evidence defect is independently confirmed.

Return:

BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_NO_REPAIR_REQUIRED

only when every package observation is independently disproved, audit-only, or
nonblocking hardening.

Return:

BOOTSTRAP_PACKAGE_FINDINGS_EVIDENCE_INSUFFICIENT

only when indispensable target evidence is genuinely absent after the corrected
opening gate.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

only for:

- actual supplied-root drift or mutation;
- actual required-input absence;
- opening-harness self-check failure;
- child-process record failure;
- parent process terminating without a retained outcome;
- closing inequality;
- terminal capsule closure failure.

Do not use a provenance verdict for an ordinary package causal failure that was
fully retained. Classify that finding and continue when safe.

──────────────────────────────────────────────────────────────────────────────
29. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh reconciliation-root identity
3. Parent-source identity and process posture
4. Bootstrap-package identity and closure
5. Failed package-audit identity and exact adopted interface
6. Opening-harness self-check result
7. Corrected root-row closure result
8. Corrected manifest-exclusion result
9. Exact ten-path authentication table
10. Opening-gate result
11. Complete finding ledger
12. Interpreter-flag adjudication
13. Reconciliation-root physical-identity adjudication
14. Post-copy reverification adjudication
15. Authority-record agreement adjudication
16. Same-PID adjudication
17. CLI/wrapper-SHA adjudication
18. Handoff-normalization adjudication
19. Failure-atomicity and success-publication adjudication
20. Synthetic/hard-coded case adjudication
21. Contract/schema alignment
22. Layout, placeholder, and sensitive-material findings
23. Failed-audit process finding
24. Confirmed repair scope or no-repair conclusion
25. Exact next tranche
26. Supplied-root closing equality
27. Fixture cleanup and ENOENT observations
28. Reconciliation-capsule inventory and terminal manifests
29. Remaining uncertainty and nonclaims
30. Explicit confirmations

Required confirmations:

BOOTSTRAP_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_PACKAGE_AUDIT_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_RECONCILIATION_ROOTS_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
FRESH_ROOT_CREATED_BEFORE_SUPPLIED_ROOT_INSPECTION
PARENT_SOURCE_RETAINED_AND_HASH_BOUND
OPENING_HARNESS_SELF_CHECK_PASSED
MANIFEST_ROOT_ROW_COMPARED_SYMMETRICALLY
MANIFEST_ROOT_ROW_NOT_DISCARDED
MANIFEST_SELF_EXCLUSIONS_HANDLED_EXPLICITLY
FAILED_AUDIT_ACTUAL_MANIFEST_PATHS_USED
ALL_TEN_REQUIRED_PATHS_AUTHENTICATED
NONEXISTENT_SCHEDULE_PATH_NOT_REQUIRED
NONEXISTENT_CLOSEOUT_MANIFEST_PATHS_NOT_REQUIRED
EVERY_PACKAGE_FINDING_INDEPENDENTLY_ADJUDICATED
FAILED_AUDIT_PROCESS_DEFECT_NOT_ATTRIBUTED_TO_PACKAGE
ONE_PARENT_PROCESS_COMPLETED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITORS_USED
NO_SUBAGENTS_CREATED
NO_PACKAGE_REPAIR_PERFORMED
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
A6_NOT_STARTED
```

Do not run another package-acceptance audit or issue a package repair prompt
until this reconciliation establishes the actual package repair boundary.
```

This is now a straightforward harness correction: the substantive Findings A–K brief can remain unchanged once the root row and self-exclusions are treated correctly.

**Source:** Codex’s `OPENING_GATE_FAILURE_RECONCILED_HARNESS_DEFECT` report in the current turn.  
**Confidence:** 0.999 that the supplied roots are intact; 0.999 that the first failure was `actual.discard(".")`; 0.998 that explicit self-exclusion handling is the only additional opening-interface correction needed before Findings A–K can begin.
