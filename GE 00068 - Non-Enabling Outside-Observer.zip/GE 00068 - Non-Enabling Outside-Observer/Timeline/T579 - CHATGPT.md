## Engineering assessment

The external schema-package authority chain is now complete.

The accepted replacement subject is independently validated, and the unique owning authority has transitioned the governed `current-schema-package` role from the predecessor schema package to:

```text
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
```

The successor content snapshot and authority are:

```text
/Users/ds/Downloads/ES-repair10i-v3-current-schema-subject-authority-successor-oy7bs2ak/gen2-current-authority-manifest-content-snapshot-successor-v1.zip
```

- mode: `0400`
- size: `12,093,871`
- SHA-256: `aefab9f9695df38df10ca2f61b501eaf4a3faeeeea11e686cb9e54af6cf7cd16`

```text
/Users/ds/Downloads/ES-repair10i-v3-current-schema-subject-authority-successor-oy7bs2ak/gen2-current-authority-manifest-content-snapshot-successor-v1.authority.json
```

- mode: `0400`
- size: `8,827`
- SHA-256: `4d5413b92cd6c613932080a422056b5579ac57028003691b884ce2452a2e4e18`

The report establishes:

- exactly one `current-schema-package` role;
- the accepted replacement subject is current;
- the predecessor schema package is historical;
- the accepted subject audit is bound as acceptance evidence;
- the other seven content roles and 416 unchanged archive members remained byte-identical;
- deterministic archive and authority builds matched;
- independent validation and the 48-case promotion matrix passed;
- the predecessor content snapshot and every supplied input remained unchanged;
- the promotion evidence capsule terminally closed.

The earlier `TypeError: unhashable type: 'dict'` was also closed correctly by preserving the structured exclusion rows and deriving their governed `path` selectors, rather than flattening or hashing the objects.

### The important boundary

This promotion makes the replacement subject current **within the content-snapshot authority contract**. It does not, by itself, establish that the Execution Substrate Git repository:

- contains the same accepted schema bytes;
- resolves the successor content authority automatically;
- has migrated every consumer away from the predecessor snapshot;
- is ready for the next implementation or A6 tranche;
- has changed any product or runtime behavior.

The report explicitly confirms that no repository mutation occurred.

Accordingly, another external snapshot or promotion tranche would be premature. The critical path now returns to the ES repository.

## Progression decision

Run one read-only ES repository adoption and consumer crosswalk.

The task must determine whether:

1. the current working-tree schema and authority contracts already match the accepted subject;
2. bounded repository adoption is needed;
3. only consumers of the external content authority need rebinding;
4. governing repository contracts must be migrated before either action;
5. the next current `PLANS.md` priority is now unblocked.

No repository edits should occur in this crosswalk. Its result should supply the exact implementation tranche, touched files, and validation commands—or establish that no repo adoption is needed.

---

## Complete replacement Codex prompt

```text
PERFORM A READ-ONLY EXECUTION SUBSTRATE REPOSITORY ADOPTION AND
CURRENT-AUTHORITY CONSUMER CROSSWALK

DO NOT EDIT THE REPOSITORY

Objective

Re-ground the current Execution Substrate repository against the newly accepted
and promoted external `current-schema-package` authority.

Determine whether the repository and every acceptance-bearing consumer are
already congruent with the accepted replacement subject, or whether the next
engineering treatment must be:

1. bounded repository adoption;
2. external-authority consumer rebinding;
3. governing contract migration before adoption;
4. no change because the repository is already congruent.

Do not implement the selected treatment in this task.

Do not mutate the repository.

Do not stage, commit, push, merge, rebase, reset, clean, checkout, switch,
restore, stash, or alter a worktree.

Do not install dependencies.

Do not use the network.

Do not modify any supplied external authority artifact.

Read-only Git commands are explicitly authorized only for repository identity,
status, history, tracked-file, and diff inspection.

Return one exact primary verdict:

ES_CURRENT_SCHEMA_PACKAGE_REPO_AND_CONSUMERS_CONGRUENT

ES_CURRENT_SCHEMA_PACKAGE_BOUNDED_REPO_ADOPTION_REQUIRED

ES_CURRENT_SCHEMA_PACKAGE_CONSUMER_REBIND_REQUIRED

ES_CURRENT_SCHEMA_PACKAGE_CONTRACT_MIGRATION_REQUIRED

ES_CURRENT_SCHEMA_PACKAGE_CROSSWALK_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. REPOSITORY
──────────────────────────────────────────────────────────────────────────────

REPOSITORY_ROOT:

/Users/ds/Repositories/Execution Substrate/

Authenticate and report:

- physical root;
- branch;
- HEAD;
- HEAD tree;
- parent or parents;
- upstream;
- ahead/behind;
- all worktrees;
- staged status;
- unstaged status;
- untracked paths;
- conflicts;
- active Git operations;
- locks;
- submodules, when any;
- ignored build, cache, database, archive, or generated artifacts relevant to
  this crosswalk.

Use read-only commands only.

Preserve every preexisting repository change.

Do not assume HEAD alone is current reality.

When a relevant file is modified in the working tree:

- inspect both HEAD and current working-tree bytes;
- classify the working tree as current local reality;
- state the difference;
- do not overwrite or normalize it.

Repeat the complete repository identity and status at closeout and require no
task-caused change.

──────────────────────────────────────────────────────────────────────────────
2. REPOSITORY GUIDANCE AND CURRENT PLAN
────────────────────────────────────────────────

Before authority analysis, read all applicable repository guidance.

At minimum inspect, when present:

- root and directory-scoped AGENTS.md or equivalent instructions;
- PLANS.md;
- README and architecture entry points;
- current authority and schema-package documentation;
- relevant contracts and schemas;
- tests and contract/assurance tests;
- source;
- migrations;
- scripts;
- configs;
- examples;
- retained artifacts and reports;
- package/build metadata.

Follow the latest current `PLANS.md`.

Do not reuse a milestone order from an older chat, report, or snapshot when the
current repository says otherwise.

Retain:

- files read;
- governing instructions;
- current plan status;
- current highest-priority seam relevant to the accepted schema package.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED SUBJECT
──────────────────────────────────────────────── LIMITED TO CURRENT PACKAGE EVIDENCE
────────────────────────────────────────────────

ACCEPTED_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- entries:
  73
- directories:
  12
- regular files:
  61
- canonical inventory SHA-256:
  eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

Expected subject manifest SHA-256:

5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Authenticate read-only:

- root identity;
- temporal inventory;
- manifest A and B;
- A/B byte equality;
- physical reprojection;
- role registry;
- exact fifteen schemas;
- exact fourteen generated families;
- documentary-validator registry;
- package status and lineage.

Do not execute subject source.

Do not modify or clean the subject.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. ACCEPTED AUDIT
──────────────────────────────────────────────── LIMITED TO ACCEPTANCE BINDING
────────────────────────────────────────────────

ACCEPTED_AUDIT_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-_nkdl2oe

Expected identity:

- device/inode:
  16777234 / 182855547
- mode:
  0700

ACCEPTED_AUDIT_CAPSULE_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-hyt4r2f_/audit-capsule

Expected identity:

- device/inode:
  16777234 / 182860759
- mode:
  0700
- canonical inventory SHA-256:
  0f23428965bed3096ee4ce6821a6e126e22a6e8432e43edbc8e92b06f84d6c2b

Expected raw disposition:

SUBJECT_AUDIT_ACCEPT

Expected wrapper verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

Authenticate read-only:

- process custody;
- terminal frame;
- capsule binding;
- zero findings;
- 946 and 137 completion;
- zero nonpassing rows;
- zero direct findings;
- field-map closure;
- documentary-validator closure;
- confirmation closure;
- occupancy;
- all A00–A15 passed;
- cleanup and equality;
- terminal manifests and seal.

Do not rerun or reinterpret the audit.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. SUCCESSOR CURRENT CONTENT AUTHORITY
────────────────────────────────────────────────

SUCCESSOR_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-schema-subject-authority-successor-oy7bs2ak/gen2-current-authority-manifest-content-snapshot-successor-v1.zip

Expected identity:

- device/inode:
  16777234 / 182888909
- mode:
  0400
- link count:
  1
- size:
  12093871
- SHA-256:
  aefab9f9695df38df10ca2f61b501eaf4a3faeeeea11e686cb9e54af6cf7cd16

SUCCESSOR_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-schema-subject-authority-successor-oy7bs2ak/gen2-current-authority-manifest-content-snapshot-successor-v1.authority.json

Expected identity:

- device/inode:
  16777234 / 182888910
- mode:
  0400
- link count:
  1
- size:
  8827
- SHA-256:
  4d5413b92cd6c613932080a422056b5579ac57028003691b884ce2452a2e4e18

Authenticate authority before interpreting the archive.

Require:

- exact archive and authority identities;
- 483 archive members;
- 482 indexed rows;
- exact successor bundle index;
- exact successor role registry;
- exactly one `current-schema-package` role;
- accepted replacement subject bound current;
- predecessor schema package historical;
- accepted subject audit bound;
- seven other roles preserved;
- 416 unchanged predecessor members byte-identical;
- no unsafe, duplicate, symlink, special, cache, bytecode, or `.DS_Store`
  member;
- deterministic authority/archive binding.

Do not modify either file.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO HISTORICAL COMPARISON
────────────────────────────────────────────────

6. PREDECESSOR CONTENT AUTHORITY

PREDECESSOR_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected SHA-256:

b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

PREDECESSOR_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected SHA-256:

276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Use only when necessary to:

- authenticate predecessor/successor lineage;
- identify exact changed roles and members;
- identify stale consumers;
- verify no unrelated authority change.

Classify as historical under successor authority.

Do not use as the current authority source.

────────────────────────────────────────────────

7. REPOSITORY CURRENT-AUTHORITY CONTRACT MAP

Identify every repository contract that claims or consumes any of:

- current schema package;
- current schema role;
- current generated-record family;
- schema-package authority;
- content-snapshot authority;
- current authority bundle;
- role registry;
- package status;
- subject acceptance;
- subject audit acceptance;
- schema supersession;
- current/historical posture.

For every claim retain:

- repository path;
- line or JSON pointer;
- owning component;
- fact owned;
- writer;
- readers/consumers;
- current value;
- authority classification:
  contract/invariant,
  compatibility edge,
  reopened seam,
  implementation detail,
  report-only evidence;
- whether the external successor authority is recognized;
- whether the predecessor authority remains referenced;
- whether the claim conflicts with another current claim.

Determine what the owning repository contracts say about the relationship
between:

- Git-tracked schema bytes;
- generated schema-package artifacts;
- external content-snapshot authority;
- current-role registries;
- runtime/product consumption.

Do not silently treat an external artifact as repository truth when the repo
contract says otherwise.

────────────────────────────────────────────────

8. ACCEPTED-SUBJECT TO REPOSITORY FILE CROSSWALK

Create a complete mapping for every accepted subject artifact that could
correspond to repository-owned source or contract content.

At minimum crosswalk:

- fifteen current schema files;
- schema-role registry;
- fourteen-family specification or field freeze;
- normative contract;
- 946-case specification;
- 137-case specification;
- 766/333 field-map specification;
- documentary-validator specifications;
- confirmation-evidence specifications;
- role-occupancy or lineage contracts when repository-owned.

For every row retain:

- accepted-subject role;
- accepted-subject path;
- accepted-subject SHA-256;
- candidate repository path or explicit none;
- repository HEAD SHA-256;
- repository working-tree SHA-256;
- semantic equality;
- byte equality;
- current/historical status;
- generated/evidence-only posture;
- authoritative owner;
- action classification:
  no change,
  adopt bytes,
  regenerate,
  update binding only,
  documentation only,
  test migration,
  not repository-owned,
  unresolved.

Do not copy anything.

Do not assume every subject artifact belongs in Git.

Explicitly distinguish:

- normative source;
- generated source artifact;
- validation specification;
- retained result/evidence;
- terminal closure metadata.

────────────────────────────────────────────────

9. REPOSITORY ROLE AND SUPERSESSION CROSSWALK

Determine the repository’s exact current role vocabulary.

Require explicit answers:

- Does the repository use `current-schema-package`?
- Does it use `current-schema-subject`?
- Does it use another governed role?
- Which file owns that role?
- Does the repository currently point to the predecessor schema package?
- Does it already contain or imply the replacement subject?
- Is the accepted external successor authority allowed to supersede the
  repository claim without a Git change?
- Does the repository require a migration or checked-in registry update?
- Is the old role retained as a compatibility edge?
- Are any tests freezing the predecessor role, path, hash, schema version, or
  member set?

Do not invent a new role vocabulary.

────────────────────────────────────────────────

10. CONSUMER AUDIT

Inspect every acceptance-bearing consumer of current schema authority.

Include, when present:

- product source;
- build/package scripts;
- audit scripts;
- validators;
- code generators;
- migration tools;
- runtime configuration;
- tests;
- examples;
- development utilities;
- CI configuration;
- documentation that supplies executable commands;
- external-artifact locators or hashes.

For every consumer retain:

- path;
- symbol, line, or JSON pointer;
- consumed role;
- consumed path/hash/version;
- predecessor reference, successor reference, or semantic-role resolution;
- whether the reference is authoritative or illustrative;
- effect if left unchanged;
- required treatment:
  none,
  consumer rebind,
  repository adoption,
  contract migration,
  remove stale compatibility,
  unresolved.

Search for exact predecessor hashes and paths, including:

- predecessor bundle SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

- predecessor authority SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

- predecessor schema-package root when governed:
  /Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Also search for the current role names and stable semantic interfaces rather
than only literal paths.

Classify hard-coded private `/Users/ds/Downloads` paths as report-only,
test-only, local proof, or product-affecting.

Do not generalize local proof paths into product contracts.

────────────────────────────────────────────────

11. DOCS, TESTS, SCHEMAS, SCRIPTS, CONFIGS, EXAMPLES, AND ARTIFACTS

Audit together:

- governing docs;
- architecture docs;
- PLANS.md;
- contracts;
- schemas;
- migrations;
- source;
- tests;
- scripts;
- configs;
- examples;
- generated artifacts;
- retained reports.

Identify:

- docs that describe the predecessor package as current;
- tests that freeze old authority semantics;
- scripts that regenerate a different package;
- configs that point to predecessor authority;
- examples that would teach stale usage;
- artifacts that should remain historical;
- generated files that must not be hand-edited;
- missing tests for successor authority adoption;
- stale package-status or lineage assertions.

Classify each finding as:

- contract/authority drift;
- compatibility edge;
- implementation drift;
- test gap;
- documentation gap;
- script/config gap;
- artifact-only historical evidence;
- report-only uncertainty.

────────────────────────────────────────────────

12. CURRENT PLAN AND NEXT-MILESTONE READINESS

Using the current repository `PLANS.md`, determine:

- the current active milestone or repair tranche;
- whether current-schema-package acceptance was a prerequisite;
- which exact planned item is now unblocked;
- whether repository adoption or consumer rebinding is required first;
- whether target audit, runtime validation, A6, or another step remains
  explicitly blocked;
- whether the external promotion is sufficient evidence for the next planned
  task;
- whether governing docs/tests must change before implementation.

Do not infer that A6 or target audit is now authorized merely because the
schema package was accepted.

State the exact repository evidence for readiness or continued blocking.

────────────────────────────────────────────────

13. DECISION RULES

Return:

ES_CURRENT_SCHEMA_PACKAGE_REPO_AND_CONSUMERS_CONGRUENT

only when:

- repository-owned current schema bytes and contracts match the accepted
  subject where they are supposed to;
- external successor authority is recognized under current contracts;
- no acceptance-bearing consumer uses the predecessor;
- no governing docs/tests/configs are stale in a way that affects execution;
- no repository adoption or rebind is required.

Return:

ES_CURRENT_SCHEMA_PACKAGE_BOUNDED_REPO_ADOPTION_REQUIRED

when:

- the accepted subject is authoritative;
- repository-owned source/contracts differ;
- current contracts permit a bounded Git adoption;
- exact touched files and validation can be determined without an operating
  model change.

Return:

ES_CURRENT_SCHEMA_PACKAGE_CONSUMER_REBIND_REQUIRED

when:

- repository source/contracts are already congruent;
- one or more acceptance-bearing consumers still bind the predecessor or fail
  to resolve the successor;
- no schema/source-byte adoption is required.

Return:

ES_CURRENT_SCHEMA_PACKAGE_CONTRACT_MIGRATION_REQUIRED

when:

- repository contracts disagree with the external successor authority;
- tests/docs freeze the predecessor authority model;
- adopting the successor would change writer ownership, role vocabulary,
  current/historical semantics, or another governing invariant;
- governing docs and contract tests must change before implementation.

Return:

ES_CURRENT_SCHEMA_PACKAGE_CROSSWALK_PROVENANCE_MISMATCH

when:

- required repository or external authority identities cannot authenticate;
- relevant working-tree state cannot be safely distinguished;
- authoritative role ownership remains ambiguous;
- the crosswalk lacks required evidence.

────────────────────────────────────────────────

14. SELECTED NEXT TREATMENT

Retain one exact selected treatment.

When repository adoption is required, provide:

- objective;
- exact touched files;
- exact bytes/roles to adopt;
- generated versus hand-edited files;
- docs/tests/scripts/configs affected;
- non-goals;
- compatibility treatment;
- migration treatment;
- exact validation commands;
- required artifacts;
- provenance requirements;
- stop conditions;
- expected commit boundary.

When consumer rebinding is required, provide the same fields limited to the
consumer surface.

When contract migration is required, identify:

- governing docs;
- contract tests;
- authority split;
- migration sequencing;
- compatibility period;
- prohibited implementation before contract freeze.

When no change is required, identify the exact next `PLANS.md` item and why it
is unblocked.

Do not execute the treatment.

────────────────────────────────────────────────

15. CLOSING REPOSITORY AND INPUT EQUALITY

At closeout:

- repeat branch, HEAD, tree, upstream, worktrees, and complete status;
- require no task-caused repository change;
- repeat opening/closing identities for every external artifact opened;
- remove only task-owned temporary extraction directories after retaining
  evidence;
- report skipped files or incomplete inspection.

Do not clean preexisting repository state.

────────────────────────────────────────────────

16. REQUIRED INLINE REPORT

Return:

1. Exact primary verdict
2. Repository opening identity
3. Preexisting repository status and protected changes
4. Applicable repository guidance
5. Current PLANS.md status and priority
6. Accepted subject authentication
7. Accepted audit authentication
8. Successor content authority authentication
9. Predecessor authority disposition
10. Repository current-authority contract map
11. Authoritative writer map
12. Accepted-subject/repository file crosswalk
13. Fifteen-schema byte crosswalk
14. Fourteen-family crosswalk
15. Validation-specification crosswalk
16. Documentary and confirmation crosswalk
17. Repository role-vocabulary adjudication
18. Supersession and lineage crosswalk
19. Consumer inventory
20. Stale predecessor references
21. Docs/tests/source/schema/script/config/example/artifact findings
22. Contract and authority conflicts
23. Compatibility edges
24. Current milestone readiness
25. Target-audit/runtime/A6 readiness or blocking
26. Selected next treatment
27. Exact future touched files
28. Exact future validation commands
29. Non-goals and stop conditions
30. Inspection limitations
31. Repository closing identity and status
32. External-input closing equality
33. Explicit confirmations

Required confirmations:

ES_REPOSITORY_ROOT_AUTHENTICATED
ES_REPOSITORY_GUIDANCE_READ
CURRENT_PLANS_MD_READ
CURRENT_PLAN_PRIORITY_REPORTED
PREEXISTING_REPOSITORY_CHANGES_PRESERVED
ACCEPTED_SUBJECT_AUTHENTICATED
ACCEPTED_SUBJECT_AUDIT_AUTHENTICATED
SUCCESSOR_CONTENT_BUNDLE_AUTHENTICATED
SUCCESSOR_CONTENT_AUTHORITY_AUTHENTICATED
PREDECESSOR_CONTENT_AUTHORITY_CLASSIFIED_HISTORICAL
EXACTLY_ONE_EXTERNAL_CURRENT_SCHEMA_PACKAGE_ROLE
REPOSITORY_CURRENT_SCHEMA_AUTHORITY_OWNER_IDENTIFIED
REPOSITORY_ROLE_VOCABULARY_ADJUDICATED
FIFTEEN_SCHEMA_FILES_CROSSWALKED
FOURTEEN_GENERATED_FAMILIES_CROSSWALKED
NORMATIVE_CONTRACT_CROSSWALKED
946_CASE_SPECIFICATION_CROSSWALKED
137_CASE_SPECIFICATION_CROSSWALKED
766_333_FIELD_MAP_CROSSWALKED
DOCUMENTARY_VALIDATOR_AUTHORITY_CROSSWALKED
CONFIRMATION_EVIDENCE_AUTHORITY_CROSSWALKED
EVERY_ACCEPTANCE_BEARING_CONSUMER_INSPECTED
PREDECESSOR_PATH_HASH_AND_ROLE_REFERENCES_CLASSIFIED
DOCS_TESTS_SOURCE_SCHEMAS_SCRIPTS_CONFIGS_EXAMPLES_ARTIFACTS_INSPECTED
NO_EXTERNAL_ARTIFACT_SILENTLY_TREATED_AS_REPO_TRUTH
CURRENT_MILESTONE_READINESS_ADJUDICATED
TARGET_AUDIT_READINESS_ADJUDICATED
RUNTIME_VALIDATION_READINESS_ADJUDICATED
A6_READINESS_ADJUDICATED
EXACTLY_ONE_NEXT_TREATMENT_SELECTED
FUTURE_TOUCHED_FILES_EXACT
FUTURE_VALIDATION_COMMANDS_EXACT
REPOSITORY_MUTATION_NOT_PERFORMED
REPOSITORY_CLOSING_IDENTITY_MATCHED
PREEXISTING_REPOSITORY_STATUS_PRESERVED
EXTERNAL_INPUT_CLOSING_EQUALITY_PASSED
NO_NETWORK_CONTACT
NO_DEPENDENCY_INSTALLATION
NO_GIT_MUTATION
NO_COMMIT_OR_PUSH
NO_SUBAGENTS_CREATED
```

## Source and confidence

**Source:** Codex’s operative report in your message.

**Provenance confidence:** 0.999  
**External current-schema-package promotion confidence:** 0.999  
**Repository congruence confidence before crosswalk:** undetermined  
**Read-only repo crosswalk as the correct next step:** 0.995

Some older project attachments have expired, but they were not needed for this assessment.
