## Assessment

The amendment closes the qualification gap cleanly. The A6D successor is now ready for downstream use, but only through a **joint evidence input**:

1. **Original A6D child** — authoritative for successor source, binaries, validation, causals, and the original manifest.
2. **A6D verifier amendment** — authoritative only for the corrected seal-verification procedure and the supersession of the defective packaged verifier.

The amendment does **not** alter or replace the A6D successor bytes:

- Original A6D manifest: `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`
- Amendment manifest: `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`
- Original successor T: `8c237318e3a72172e5cbbdf41f5e68244ae15895`
- Original successor inventory: `7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852`
- All original source, binaries, 59-per-side command records, 46 causals, and manifests remain unchanged.
- The corrected verifier passed twice against the original A6D child and once against the sealed amendment.
- The defective verifier remains preserved and explicitly nonqualifying.

No more source/tool repair is indicated. The next gate is the **complete fresh five-control A6 restart in a new child**. Neither prior failed A6 child may be resumed.

The amendment remains proof/evidence tooling rather than ES runtime architecture or authority. 

## Codex prompt: fresh A6 restart with the joint A6D input

```text
Permission is workspace-write for one new source-external evidence child only.

Objective

Execute, analyze, close out, and seal the complete fresh Repair 10I-A6
policy-evidence refresh using the jointly qualified Repair 10I-A6D successor
input:

1. the original sealed A6D implementation child; and
2. the separately sealed A6D post-seal-verifier amendment.

Freshly materialize and independently qualify:

1. pristine final;
2. independent pristine final;
3. intentional mutant;
4. historical HEAD;
5. historical Repair 9 under its exact validation-harness overlay.

Run all five semantic comparisons:

1. final ↔ fresh;
2. final ↔ intentional mutant;
3. mutant ↔ fresh;
4. HEAD ↔ final;
5. Repair 9 ↔ final.

Then derive the complete historical transition and hazard matrices for:

- HEAD → final;
- Repair 9 → final.

Use those fresh, independently qualified records to decide whether the
structural historical-directional no-regression policy can be frozen for a
later successor implementation.

This turn performs validation, evidence generation, deterministic analysis,
and policy freezing only.

Do not modify repository source.
Do not modify either A6D input child.
Do not modify any predecessor evidence.
Do not resume, overwrite, or seal either prior failed A6 child.
Do not implement the historical comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole evidence writer.

Candidate repository

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D implementation child

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D verifier amendment

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Sealed A5T4 repository validation

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A6O historical-overlay successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Sealed A6R mutable-tree successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

Earlier failed A6 child, immutable and unsealed

FAILED_A6O=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Later failed A6 child, immutable and unsealed

FAILED_A6R=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Required new A6 child, absent at opening

A6=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6d-8de797304ea9

## 1. Absolute physical-root lock

Before any substantive observation:

1. Component-walk and `lstat` CANDIDATE_R.
2. Require physical path exactly:
   `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
3. Require:
   - type: directory;
   - device: `16777234`;
   - inode: `122118502`;
   - mode: `0755`;
   - UID/GID: `501/20`.
4. Enter the candidate using an explicitly configured cwd.
5. Require physical `pwd -P` to equal CANDIDATE_R.
6. Require CANDIDATE_R and PRIMARY_R to remain physically distinct siblings:
   - PRIMARY_R device/inode: `16777234/47685738`;
   - no equality;
   - no alias;
   - no nesting;
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode `0644`;
- size `123`;
- device/inode `16777234/122118504`;
- link count `1`;
- SHA-256:
  `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419`;
- exact target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured subprocess cwd equal to physical CANDIDATE_R.

No command may use PRIMARY_R as:

- cwd;
- Git `-C` target;
- source root;
- inventory root.

For inline Python:

- use `PYTHONDONTWRITEBYTECODE=1`;
- verify `os.getcwd()` before repository-relative access;
- import no executable module from evidence children;
- create no `__pycache__` or `.pyc`.

Stop on mismatch:

REPAIR10I_A6_WORKTREE_MISMATCH

## 2. Repository opening gate

Using candidate-rooted observations only, require:

- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- upstream:
  absent
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- repository inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- inventory size:
  `54314`
- membership:
  `389 total / 375 tracked / 14 nonignored untracked`
- tracked modifications:
  `22`
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require every governed source member to be a regular nonsymlink member under
the existing inventory contract.

Require the repository delta from sealed A5 to remain exactly the three
existing A5T4 test files recorded in sealed A5T4.

## 3. Joint A6D input gate

The downstream successor input is the pair:

### 3.1 Original A6D implementation child

Require:

- manifest SHA-256:
  `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`
- manifest size:
  `103293`
- manifested payloads:
  `623`
- descendant directories:
  `205`
- successor source T:
  `8c237318e3a72172e5cbbdf41f5e68244ae15895`
- successor inventory:
  `7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852`
- successor members:
  `12`.

A6D binaries:

repair10-runner:
`44280431013579568ee1e3dc54c834f5755291372977b50a16c82260dcd3598e`

repair10-compare:
`ef694c89a7b3c89f94f1c1d7f11de1ec8d5690e066c0ab0d0f9d0bf94f248482`

repair10-semantic:
`c916cb7fdfffbcfd090605171ba2c43ba895ca5af2f727fb4cf847f6ce1137e7`

repair10-fixture:
`d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`

Recover and require their exact sizes from the original A6D final report and
manifest.

Require the exact original A6D source delta:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`

Require the other eight source members to match the sealed predecessor exactly.

Require read-only validation adjudication to reproduce:

- `59` commands per side;
- all `46` frozen A6D causals executed and passed;
- every required race gate passed;
- zero required skips;
- zero test failures;
- zero race reports;
- zero malformed streams;
- zero missing or duplicate terminals;
- deterministic A/B builds;
- every A/B binary pair byte-identical and inode-distinct;
- complete cleanup and two absence epochs.

Do not use the original packaged verifier for qualification.

Preserve it only as the disclosed defective historical helper.

### 3.2 Verifier amendment

Require:

- manifest SHA-256:
  `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`
- manifest size:
  `3801`
- payloads:
  `29`
- directories:
  `9`.

Require corrected helpers:

- `tool/corrected/verify-closing-v1.py`
  SHA-256
  `52003d2bb42e96ada233b341543d744dfd288228dd826da6905233d7594249e1`

- `tool/corrected/verify-postseal-v1.py`
  SHA-256
  `746d63cfab5256766a366b8f829ac0f00de0c6a38f6bc70598231d55d2c08461`

Require:

- all 20 verifier fixture cases passed;
- original vulnerable layout failure reproduced;
- two corrected verification runs against A6D exited `0`;
- those two outputs were byte-identical;
- amendment post-seal verification passed;
- original A6D remained byte-exact;
- no source or binary rebuild occurred.

Require:

`A6D_AMEND/closeout/joint-qualification-v1.json`

to bind both manifests and classify the original packaged verifier as
superseded for qualification.

### 3.3 Corrected verification at this opening gate

Use only the corrected verifier from A6D_AMEND.

Run it twice against:

1. A6D;
2. A6D_AMEND.

Require for each target:

- both exits `0`;
- repeated canonical outputs byte-identical;
- exact manifest and sidecar identity;
- complete path/type/mode/size/hash/link closure;
- exact directory-mode closure;
- no unexpected payload;
- no write or timestamp restoration;
- no target mutation.

Bracket A6D and A6D_AMEND before and after with complete safe identity
snapshots and require equality.

Do not let the amendment replace or rewrite the original A6D manifest.

Stop on any mismatch:

REPAIR10I_A6_JOINT_INPUT_MISMATCH

## 4. Other lineage gate

Require exact sealed A5T4:

- manifest SHA-256:
  `7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888`
- manifest size:
  `202930`
- payloads:
  `1000`
- directories:
  `188`
- repository T/inventory:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e` /
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`.

Bind its qualified full-suite terminal universe:

Tests:

- `2753 pass`
- `137 fail`
- `8 skip`

Packages:

- `14 pass`
- `11 fail`
- `23 skip`

Require A6O and A6R predecessor identities to remain exact.

Require FAILED_A6O and FAILED_A6R to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact;
- nonqualifying.

Require A6 to be absent.

Stop on any mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

## 5. New A6 evidence child

After all opening gates pass, create A6 exclusively under umask `077`.

Use exactly:

opening/
tool/
sources/
commands/
controls/
validation/
comparisons/
analysis/
findings/
closeout/

All directories mode `0700`.

All files regular, single-link, nonsymlink, mode `0600` or `0700`.

No hardlinks.

Do not import executable modules from predecessor evidence children.

Copy independently into private tool roots:

- original A6D successor A and B binaries;
- corrected A6D verifier helpers.

Require:

- origin-to-copy byte equality;
- A/B successor binary equality;
- every copied binary inode distinct;
- every helper copy inode distinct;
- link count one;
- expected mode;
- no shared writable tool state.

The corrected verifier is evidence tooling only.

Acceptance-bearing suite execution uses the original A6D successor binaries.

## 6. A6D successor hard gate

Before creating a source control:

1. Verify all 12 A6D successor source members.
2. Verify the exact A6R→A6D four-file delta.
3. Verify all four A6D binary identities.
4. Verify the exact A6D active schema dialect.
5. Reopen and verify:
   - all 46 A6D device-security causals;
   - exact `/dev/null` device-literal contract;
   - ACL and xattr unsupported-for-volume posture;
   - malformed-request rejection;
   - volume-capability evidence;
   - all 32 A6R mutable-tree causals;
   - all 58 overlay causals;
   - all seven A5C observability causals;
   - A5P2 PTY and execution-policy causals;
   - cleanup and absence records.
6. Require:
   - old policy/source-binding records cannot qualify current semantics;
   - producer captions remain non-authoritative;
   - no grant-scope widening;
   - no repository, overlay, PTY, semantic, or comparison-policy widening.

Stop on mismatch:

REPAIR10I_A6_SUCCESSOR_INPUT_MISMATCH

## 7. Exact active schema dialect

Recover the exact active 24-schema A6D dialect from the original A6D report
and source.

Require:

### Outer v6

- `execution-substrate.repair10i.suite-spec.v6`
- `execution-substrate.repair10i.ab-suite-spec.v6`
- `execution-substrate.repair10i.suite-result.v6`
- `execution-substrate.repair10i.binding-recomputation.v6`
- `execution-substrate.repair10i.control-qualification.v6`
- `execution-substrate.repair10i.semantic-comparison-spec.v6`
- `execution-substrate.repair10i.semantic-comparison-result.v6`
- `execution-substrate.repair10i.semantic-comparison-custody.v6`

### Command v3

- `execution-substrate.repair10i.command-intent.v3`
- `execution-substrate.repair10i.command-result.v3`
- `execution-substrate.repair10i.terminal-reconciliation.v3`

### Private PTY v2

- `execution-substrate.repair10i.private-pty-command.v2`
- `execution-substrate.repair10i.private-pty-broker-journal.v2`
- `execution-substrate.repair10i.private-pty-allocation.v2`
- `execution-substrate.repair10i.private-pty-reconciliation.v2`

### Read policy v3

- `execution-substrate.repair10i.effective-read-policy.v3`

### Unchanged v1

- `execution-substrate.repair10i.control-observation.v1`
- `execution-substrate.repair10i.mutable-inventory.v1`
- `execution-substrate.repair10i.intentional-mutant-provenance.v1`
- `execution-substrate.repair10i.validation-harness-overlay-provenance.v1`
- `execution-substrate.repair10i.go-test-semantics.v1`
- `execution-substrate.repair10i.byte-capture.v1`
- `execution-substrate.repair10i.byte-comparison-spec.v1`
- `execution-substrate.repair10i.byte-comparison-result.v1`

Require strict rejection of mixed prior/current acceptance chains.

## 8. One-attempt rule

Each acceptance-bearing source control receives exactly one full-suite
execution.

Do not retry or replace a launched full-suite control.

Do not select among multiple outputs.

A prelaunch construction failure stops before execution.

A full-suite, qualification, unknown, or comparison failure triggers the
applicable mandatory-stop verdict.

Retain every prelaunch, failed, and superseded attempt separately.

## 9. Exact five source controls

### 9.1 Final

- source class:
  `pristine-final`
- validation overlay:
  absent
- intentional-mutant provenance:
  absent
- base == effective
- T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- members:
  `389`.

### 9.2 Fresh independent final

- source class:
  `pristine-final`
- overlay:
  absent
- mutant provenance:
  absent
- same T, inventory, and membership as final;
- physically independent source, Git, cache, runtime, command, evidence, PTY,
  listener, socket, process, and control state.

Do not create another source class.

### 9.3 Intentional mutant

- source class:
  `intentional-mutant`
- overlay:
  absent
- base:
  exact final.

Recover the complete active mutation contract from the exact A6D source,
tests, and retained bounded causals.

Do not reconstruct it approximately.

Require:

- exact mutation provenance frozen before execution;
- exactly one existing changed path;
- same logical mode;
- no addition, deletion, rename, or second path;
- exact base/effective T and inventory;
- exact declared diagnostic tuple;
- exact declared test and package terminal delta;
- source frozen before execution.

Stop if ambiguous.

### 9.4 Historical HEAD

- source class:
  `historical-head`
- overlay:
  absent
- mutant provenance:
  absent
- base == effective
- T:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- inventory:
  `291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a`
- members:
  `375`.

### 9.5 Historical Repair 9

- source class:
  `historical-repair9`
- mutant provenance:
  absent.

Base:

- T:
  `0ea3b661f09e73e1126bae0f6e993e22bbf21198`
- inventory:
  `7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e`
- members:
  `382`.

Overlay:

- ID:
  `repair10i-historical-repair9-a5t4-validation-harness-overlay-v1`
- schema:
  `execution-substrate.repair10i.validation-harness-overlay-provenance.v1`
- recipe SHA-256:
  `811c420adc61f33a4117ae553863d194d021ede9f0a8d0ae5dfee9c3fe0e64e5`
- exact recipe and one-file transformation from sealed A6O.

Effective:

- T:
  `4bd05d4f949e6239ff7aaeb68ac229143ddeff6e`
- inventory:
  `e17a7732e260a8af7305d5e130bbbc2cc9608175390c2d763f8c655471ea6583`
- members:
  `382`.

Classification:

`historical source under validation-harness overlay`

Explicit nonclaims:

- effective bytes are not historical product source;
- overlay is not a product improvement;
- overlay is not historical runtime behavior;
- overlay is not an intentional mutant.

## 10. Physical control isolation

Materialize all five controls in physically disjoint, short, exclusive roots.

Each independently owns:

- base source where applicable;
- effective source;
- Git administration and object store where required;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- runtime root;
- command and evidence roots;
- read-policy state;
- PTY/broker state;
- listener/socket state;
- process tree.

No writable state may be shared.

Require:

- no hardlinks;
- no cross-control inode collision;
- no root equality or containment;
- no shared mutable Git alternate/object store;
- no cache alias;
- no runtime, PackageFloor, evidence, socket, listener, PTY, or process alias.

For Repair 9, base and effective roots must be distinct and nonaliasing.

## 11. Source-specific policy construction

Before launch for each control:

1. Enumerate active tests.
2. Inspect source-specific PTY call graph.
3. Declare finite PTY roles and counts.
4. Compute every prospective Unix-socket and broker path.
5. Require every path at most `100` bytes.
6. Construct `effective-read-policy.v3`.
7. Classify each grant by exact kind and role.
8. Recompute exact device-security posture.
9. Retain stable and report-only observations separately.
10. Omit capabilities not needed by the control.

Do not reuse the final-source request inventory blindly for historical sources.

Reject every undeclared PTY request.

Keep generic `/dev/fd/*` denied.

Do not add a path outside the sealed A6D policy.

## 12. Exact full-suite execution and qualification

The acceptance-bearing full-suite command for each control is literal:

go test -json -count=1 -p=1 -parallel=1 ./...

Use pinned Go 1.26.5 and the established clean offline environment.

Expected process exit membership:

{0,1}

Exit alone never qualifies.

Distribute controls across both A6D tool sides.

Require opposite-side external raw re-extraction and qualification for every
control.

For each control require:

- valid source class;
- exact base identity;
- exact overlay or mutant provenance where applicable;
- exact effective identity;
- source frozen before execution;
- complete raw stdout/stderr through EOF;
- exactly one Wait;
- terminal reconciliation complete;
- resource disposition complete;
- no forced cleanup;
- no survivor;
- no malformed or truncated JSONL;
- no duplicate or missing lifecycle record;
- semantic integrity pass;
- zero unknown diagnostics;
- producer and peer semantic bytes equal;
- producer and peer qualifications both `qualified`;
- suite and logical fingerprints bound;
- read-policy v3 independently recomputed;
- exact `/dev/null` posture independently recomputed;
- overlay or mutant provenance independently recomputed;
- PTY policy fingerprint bound;
- every declared PTY request consumed exactly;
- no undeclared PTY request;
- direct `/dev/ptmx` denied;
- generic `/dev/fd/*` denied;
- unrelated terminal inaccessible;
- actual PTY EOF/EIO reconciled;
- every socket path at most `100` bytes;
- two cleanup epochs;
- verified-empty next-command barrier.

## 13. Final/fresh gate

Execute final and fresh first.

Before continuing require:

- lifecycle equal;
- diagnostics equal;
- canonical semantics equal;
- logical suite fingerprints equal;
- read-policy semantics equal;
- both independently qualified;
- zero unknowns;
- accepted equality true;
- outcome:
  `qualified-equal`;
- comparator exit:
  `0`.

Require exact terminal identity-set equality.

Expected counts:

Tests:

- `2753 pass`
- `137 fail`
- `8 skip`

Packages:

- `14 pass`
- `11 fail`
- `23 skip`

Counts alone are insufficient.

Raw bytes may differ.

Any difference or qualification failure stops:

REPAIR10I_A6_VALIDATION_BLOCKED

## 14. Intentional-mutant gates

After final/fresh passes, execute the mutant.

Require final ↔ mutant:

- both qualified;
- zero unknowns;
- exact declared diagnostic tuple;
- exact declared test and package terminal delta;
- no additional lifecycle or diagnostic difference;
- accepted equality false;
- outcome:
  `qualified-different`;
- exit:
  `2`.

Require mutant ↔ fresh:

- both qualified;
- zero unknowns;
- exact inverse declared delta;
- no additional difference;
- outcome:
  `qualified-different`;
- exit:
  `2`.

Any mismatch stops:

REPAIR10I_A6_VALIDATION_BLOCKED

## 15. Historical controls

Only after final/fresh and both mutant directions pass, execute HEAD and
Repair 9.

Require:

- exact source class;
- exact base identity;
- exact effective identity;
- exact overlay absence or presence;
- exact provenance;
- zero unknowns;
- producer qualification:
  `qualified`;
- peer qualification:
  `qualified`;
- complete raw and semantic custody;
- complete terminal/resource/read-policy reconciliation;
- no survivor;
- no forced cleanup.

Repair 9 qualification must independently reconstruct:

- base source;
- overlay recipe;
- effective source;
- pre-execution freeze.

## 16. Current historical comparator

Run the sealed A6D comparator for:

- HEAD ↔ final;
- Repair 9 ↔ final.

Retain:

- specs;
- custody;
- results;
- exits;
- reason codes;
- lifecycle and diagnostic differences;
- qualification references;
- read-policy references;
- Repair 9 overlay projection.

The current historical acceptance policy is not A6 readiness authority.

Exit `1` may permit structural analysis only if:

- both controls are independently qualified;
- unknown count is zero;
- raw/semantic custody complete;
- terminal/resource/read-policy reconciliation passes;
- rejection is exclusively the current historical-policy mismatch.

Any source, overlay, policy, qualification, unknown, integrity, custody,
resource, or late-fault failure stops:

REPAIR10I_A6_VALIDATION_BLOCKED

## 17. Deterministic transition analyzer

Create one source-external versioned analyzer inside A6.

It is evidence tooling only.

Retain:

- exact source;
- source SHA-256;
- tests;
- argv;
- cwd;
- environment;
- outputs.

Run it twice and require byte-identical canonical output.

### Identity model

Test/subtest identity:

- package;
- test/subtest;
- occurrence.

Package identity:

- package;
- empty test;
- occurrence.

Sort by raw UTF-8 bytes.

Every canonical array includes:

- count;
- canonical byte length;
- SHA-256;
- complete embedded identities.

### Test transition matrix

For HEAD→final and Repair-9→final independently compute every class:

- absent→pass
- absent→fail
- absent→skip
- pass→pass
- pass→fail
- pass→skip
- pass→absent
- fail→pass
- fail→fail
- fail→skip
- fail→absent
- skip→pass
- skip→fail
- skip→skip
- skip→absent.

### Package transition matrix

Compute the same package classes.

Separately classify:

- exact `[no test files]` skip;
- package fail with failing tests;
- package failure abort;
- setup/build failure where bound raw evidence supports it;
- unclassified package failure.

### Integrity and hazard arrays

Compute deltas for:

- panic;
- race;
- warning;
- fatal runtime;
- unknown diagnostics;
- malformed stream;
- truncated stream;
- duplicate start/run/terminal;
- missing start/run/terminal;
- terminal without start;
- impossible association;
- mapping errors;
- package failure aborts;
- final-exit inconsistency.

### Final-only passes

For each absent→pass test or package:

- retain exact identity;
- prove terminal pass;
- bind recognized diagnostics;
- require zero unknown and no hazardous class.

Do not use a finite name allowlist.

### Repair 9 overlay

Retain historical base and overlay-effective identities separately.

Do not count the overlay as:

- product improvement;
- test addition;
- historical product source;
- final-side behavior.

Require test-declaration-universe equality.

## 18. Candidate structural policy

Adjudicate HEAD→final and Repair-9→final independently.

### Admitted test transitions

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

### Blocked test transitions

- absent→fail
- absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent

### Admitted package transitions

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

Admit absent→skip only when:

- package absent in baseline;
- final has exactly one package skip;
- exact raw `[no test files]` evidence exists;
- no test run/terminal identities exist for that package;
- zero unknown diagnostics;
- zero package abort;
- qualification, terminal, custody, read-policy, and resources are clean.

### Blocked package transitions

- absent→fail
- unclassified absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent
- any package abort or setup/build uncertainty.

### Independent hazard blockers

Block on:

- new panic;
- new race;
- new warning;
- new fatal runtime;
- new unknown;
- malformed/truncated stream;
- missing, duplicate, or impossible lifecycle state;
- new package abort;
- terminal disappearance;
- unexplained final-exit inconsistency.

Aggregate exit equality is not required.

A clean fail→pass may change exit `1` to `0`.

No final-only name allowlist.
No policy generated from one observed pass set.
New passes cannot mask one blocked transition.

## 19. Policy freeze

If both historical directions have:

- independently qualified controls;
- zero unknowns;
- zero blocked transitions;
- zero hazards;
- zero unexplained disappearance;
- deterministic complete matrices;

freeze the future historical-comparator contract.

Do not implement it.

### Schema-generation rule

A6D already uses active outer v6 schemas.

Do not reuse active v6 identifiers for changed historical-policy semantics.

Inspect the producer/consumer graph and freeze the next unused generation only
for records whose meaning changes.

The next semantic-comparison generation is likely v7, but derive it.

Determine separately whether changes are required to:

- comparison spec;
- comparison result;
- comparison custody;
- runner schema registry;
- comparator CLI dispatch;
- suite result;
- control qualification;
- binding recomputation;
- other records.

Freeze:

- exact future schema IDs;
- complete fields;
- producer/consumer map;
- strict decoding;
- current historical policy as parse-only/nonqualifying;
- exact future touched-file set;
- exact reason codes;
- exact exit policy;
- complete causal matrix.

If a real blocked transition or hazard exists, return policy blocked without an
exception.

## 20. Future historical result

Freeze an embedded historical analysis containing:

- baseline exit code;
- final exit code;
- accepted no-regression boolean;
- test transition sets;
- package transition sets;
- final-only passing tests/packages;
- admitted package-no-test records;
- blocked transitions;
- improvements;
- inherited failures;
- missing baseline identities;
- package-abort deltas;
- hazard-class deltas;
- unknown/lifecycle-integrity deltas;
- base/overlay/effective historical identity;
- read-policy qualification references.

Every transition set includes:

- from action;
- to action;
- count;
- complete identities;
- canonical byte length;
- canonical SHA-256.

External references may not be the sole acceptance record.

## 21. Reason and exit freeze

Recover all current A6D reason codes.

Add only source-grounded historical codes, including at minimum:

- `historical-no-regression-satisfied`
- `historical-no-regression-not-satisfied`
- `final-only-pass-observed`
- `final-only-package-pass-observed`
- `package-no-tests-admitted`
- `inherited-failure-observed`
- `baseline-fail-became-pass`
- `baseline-skip-became-pass`
- `final-only-fail`
- `final-only-test-skip`
- `final-only-package-fail`
- `final-only-package-skip-unclassified`
- `final-only-package-abort`
- `baseline-pass-regressed`
- `baseline-terminal-disappeared`
- `baseline-fail-became-skip`
- `baseline-skip-became-fail`
- `new-panic`
- `new-race`
- `new-warning`
- `new-fatal-runtime`
- `malformed-stream`
- `truncated-stream`
- `unknown-diagnostic`
- `lifecycle-integrity-failed`
- `overlay-qualified`
- `overlay-qualification-failed`
- `read-policy-qualification-failed`.

Exit policy:

- `0` only for qualified-equal with accepted equality true;
- `2` only when both controls qualify, unknown count is zero, and either:
  - exact intentional-mutant delta; or
  - accepted historical no-regression;
- `1` for every qualification, overlay, read-policy, custody, integrity,
  unknown, policy, or late fault.

Do not derive exit `2` from `errors.Is` over a joined mismatch error.

## 22. Future causal matrix

Freeze at least:

1. Arbitrary absent→pass tests admitted without name allowlist.
2. Arbitrary final-only passing subtests admitted.
3. Final-only fail blocks.
4. Final-only test skip blocks.
5. Final-only package fail blocks.
6. Final-only package abort blocks.
7. Pass→fail blocks.
8. Pass→skip blocks.
9. Pass→absent blocks.
10. Fail→pass admitted and reported.
11. Skip→pass admitted and reported.
12. Fail→skip blocks.
13. Skip→fail blocks.
14. Fail→absent blocks.
15. Skip→absent blocks.
16. Exact package no-test skip admitted only with raw proof.
17. No-test evidence mutation blocks.
18. New passes cannot mask a blocked transition.
19. New panic/race/warning/fatal/unknown/malformed/truncated/lifecycle fault
    blocks.
20. HEAD and Repair 9 evaluated independently.
21. Reverse direction rejected.
22. Repair 9 overlay qualification required.
23. Overlay bytes receive no product-improvement credit.
24. Current historical schemas parse-only/nonqualifying.
25. Final/fresh and mutant policies unchanged.
26. Transition arrays/hashes deterministic.
27. Clean fail→pass may improve aggregate exit.
28. Rename is pass→absent plus absent→pass and blocks.
29. Deleting baseline failure is fail→absent and blocks.
30. Mixed schema generations reject.
31. Read-policy v3 failure blocks acceptance.
32. Device-posture failure blocks acceptance.
33. Mutable-tree report-only differences do not change transitions after
    qualification.
34. Seal-verifier amendment is evidence tooling only and never comparison
    authority.

## 23. Security and authority

Require:

- repository and successor read-only;
- no generic `/dev/fd`;
- no broad `/dev` or terminal grant;
- no product/public schema change;
- no product execution-authority change;
- no `.out` traversal/write;
- no live PackageFloor or fixed-runtime access;
- no credential/keychain/TLS/SPIFFE/Vault/private-endpoint exposure;
- no raw PTY payload;
- overlay remains validation scaffolding;
- analyzer remains evidence tooling;
- corrected seal verifier remains evidence tooling;
- generated evidence remains non-authoritative.

## 24. Evidence requirements

Retain:

- physical-root and repository capsule;
- command-root audit;
- joint A6D input verification;
- corrected-verifier identities and outputs;
- A6D source/binary hard gate;
- exact five source identities;
- Repair 9 overlay provenance;
- mutant provenance frozen before execution;
- source-specific read/PTY/path policies;
- suite specs;
- command intents, argv, cwd, environment;
- profiles and effective policies;
- raw streams through EOF;
- command, terminal, policy, and resource records;
- PTY journals;
- producer/peer semantics and qualifications;
- all five comparison records;
- deterministic analyzer source/tests;
- transition and hazard arrays;
- policy adjudication;
- frozen future contract if supported;
- failed and superseded attempts;
- cleanup and two absence epochs;
- final report;
- exact path/mode/size/hash inventory.

Do not retain sensitive environment material or raw PTY payloads.

## 25. Closeout and sealing

Require:

- repository identity unchanged;
- candidate physical root and `.git` binding unchanged;
- exact three-file repository delta unchanged;
- original A6D and amendment unchanged;
- all predecessors unchanged;
- both failed A6 children unchanged and unsealed;
- no predecessor bytecode/cache;
- no private source, Git store, cache, runtime, PTY, process, socket, analyzer,
  build, or report root remains;
- two fresh absence epochs;
- command-root audit proves PRIMARY_R was never cwd or source root.

Use the corrected verifier from A6D_AMEND for:

1. pre-seal A6 layout verification;
2. sealed A6 verification.

Install the A6 detached digest before its manifest.

Install `A6/evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Run the corrected verifier twice against sealed A6 and require byte-identical
exit-0 output.

Perform complete read-only post-seal verification.

## 26. Mandatory stop conditions

Stop on:

- physical-root mismatch;
- baseline/lineage mismatch;
- joint A6D input mismatch;
- corrected-verifier mismatch;
- source identity ambiguity;
- overlay mismatch;
- mutant ambiguity;
- final/fresh difference;
- terminal universe differs from A5T4;
- mutant delta differs;
- any control unqualified;
- read-policy or device-posture failure;
- unknown diagnostic;
- malformed/incomplete lifecycle;
- undeclared PTY;
- socket path above 100 bytes;
- direct PTY allocation succeeds;
- unrelated terminal accessible;
- historical qualification/custody failure;
- analyzer nondeterminism;
- unresolved historical transition;
- survivor, forced cleanup, or seal failure.

## 27. Verdicts

Physical-root mismatch:

REPAIR10I_A6_WORKTREE_MISMATCH

Opening/lineage mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

Joint A6D input mismatch:

REPAIR10I_A6_JOINT_INPUT_MISMATCH

Fresh validation, comparison, or qualification failure:

REPAIR10I_A6_VALIDATION_BLOCKED

All controls qualify, but a real historical transition or hazard blocks the
candidate policy:

REPAIR10I_A6_POLICY_BLOCKED

Complete refresh and supported future policy freeze:

REPAIR10I_A6_POLICY_REFRESH_SEALED_READY_FOR_HISTORICAL_COMPARATOR_IMPLEMENTATION

A validation-blocked child remains unsealed.

A policy-blocked child may be sealed only when all controls independently
qualified, final/fresh and mutant gates passed, historical controls qualified,
and the blocker is a complete source-grounded transition or hazard.

## 28. Required success report

Include:

1. Repository and physical-root opening/closing identities.
2. Original A6D and amendment manifest identities.
3. Corrected-verifier identity and joint-input verification.
4. A6D source and binary identities.
5. Active v6/v3/v2/v1 dialect.
6. Exact five base/effective source identities.
7. Repair 9 overlay provenance.
8. Intentional-mutant provenance.
9. Final/fresh raw and semantic identities.
10. Final/fresh accepted equality and exit 0.
11. Both mutant comparisons and exit 2.
12. Historical control qualifications.
13. Current historical comparator factual outputs.
14. Complete transition matrices.
15. Complete hazard and integrity arrays.
16. Canonical lengths and hashes.
17. Package no-test evidence.
18. Independent structural-policy adjudication for HEAD and Repair 9.
19. Recognition that v6 is already active.
20. Frozen next schema generations, fields, reasons, exits, files, and causal
    matrix when supported.
21. A6 manifest SHA-256, size, and payload count.
22. Corrected-verifier sealed-A6 results.
23. Cleanup and two absence epochs.
24. Command-root audit.
25. Explicit statement that no historical-comparator implementation occurred,
    B6 was not started, product A/B was not run, and no snapshot or independent
    audit occurred.

No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The current chain now has exact provenance for the implementation child and its separate verifier amendment. That establishes which bytes are eligible for the fresh run; it does not establish that the eventual five-control results or historical policy will succeed. Provenance is evidence rather than correctness or authority. 

Implementation and independent audit remain distinct engagements, and any later comparator implementation will require fresh validation and re-audit. 

### Sources

- Codex’s `REPAIR10I_A6D_SEAL_VERIFIER_AMENDMENT_SEALED_READY_FOR_FRESH_A6_RESTART` report supplied in this turn.
- Milestone 0 proof-scaffolding and non-authority boundary. 
- Governed Execution implementation and repair lifecycle. 
- Governed Execution provenance limits. 

**Confidence**

- Amendment provenance and scope: **0.999**
- Original A6D validation continuity: **0.995**
- Joint downstream-input readiness: **0.995**
- Readiness to restart fresh A6: **0.995**
- Confidence that the structural historical policy will pass before fresh evidence: **0.86**
