## Assessment

This is again a **pure audit-harness failure**, not a finding against V3.

The first post-epoch process exited `0` but failed to establish any of the outputs needed to continue:

- no audit-root path;
- no bootstrap identity;
- no retained recorder-gate result;
- no persistent recorder session;
- no evidence that the missing-executable and recovery causals ran.

Codex stopped correctly. Starting another process would have broken the required parent-recorder continuity.

### What this means

**Do not change the V3 capsule.** Nothing in this response reached, much less rejected:

- the V3 contract;
- Plan V3→V4 equivalence;
- the `itoa.go` source closure;
- explicit nonauthority;
- V2 evidence adoption;
- the mutation matrix;
- capsule closure.

The target remains **technically unevaluated by an independent audit**, not negatively adjudicated.

More importantly, this is now the third distinct failure of the custom process-recorder bootstrap:

1. a child-creation failure occurred before a start record;
2. the runner depended on an undefined `__file__`;
3. the bootstrap exited successfully but provided no handoff or persistent session.

That pattern shows the **audit transport itself is unqualified**. Sending another complete target audit with another revised bootstrap would continue coupling V3 qualification to an unproven Codex session capability.

## Recommended next step

Run a **small capability probe only**. It must not inspect the candidate or any evidence root. Its sole purpose is to establish whether Codex can maintain one interactive supervisor process across multiple tool interactions and record subprocess attempts before spawn.

Do not rerun the full V3 audit until this probe returns `PERSISTENT_AUDIT_SUPERVISOR_READY`.

## Prompt for a fresh Codex chat

```text
PERSISTENT AUDIT SUPERVISOR CAPABILITY PROBE

This is a capability probe for a future independent audit. It is not an audit
of the candidate, V3, or any supplied evidence.

Do not inspect any repository content or supplied evidence root.
Do not create subagents.
Do not run Git.
Do not run tests.
Do not use the network.
Do not repair anything.

Return exactly one primary verdict:

PERSISTENT_AUDIT_SUPERVISOR_READY
PERSISTENT_AUDIT_SUPERVISOR_UNAVAILABLE
SUPERVISOR_PROBE_PROVENANCE_MISMATCH

PURPOSE

Prove or disprove that the current Codex tool interface can:

1. launch one persistent audit-owned Python supervisor;
2. keep that same process alive across multiple parent interactions;
3. send later commands to it without launching a second carrier process;
4. create a child-process start record before attempting child creation;
5. fully record a missing-executable spawn failure;
6. successfully launch and record a second child afterward;
7. close the same supervisor cleanly;
8. retain complete, contiguous process evidence.

No target inspection is authorized.

──────────────────────────────────────────────────────────────────────────────
1. ADMINISTRATIVE INTAKE
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking a tool.

Administrative prompt intake is outside the probe epoch.

After reading the complete prompt, state exactly:

SUPERVISOR_PROBE_EPOCH_START

No filesystem content may be inspected before that statement except this
prompt attachment.

──────────────────────────────────────────────────────────────────────────────
2. FIRST AND ONLY CARRIER PROCESS
──────────────────────────────────────────────────────────────────────────────

The first post-epoch tool invocation must start one persistent interactive
process using the Codex tool interface’s persistent-session facility.

Use cwd:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

The cwd is a process-boundary value only. Do not inspect its contents.

Explicit environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Set umask 077.

The process must remain alive after printing its READY message. A normal
short-lived process that exits after bootstrap does not qualify.

Do not start a shell daemon, detached child, background process, second
terminal, or second supervisor.

The one carrier process may replace itself with `os.execve`, preserving its
PID, to enter the retained supervisor source. It may not fork or spawn a child
to establish the supervisor.

──────────────────────────────────────────────────────────────────────────────
3. BOOTSTRAP AND RETAINED SOURCE
──────────────────────────────────────────────────────────────────────────────

Within the one carrier process:

1. Allocate a fresh root beneath `/Users/ds/Downloads` with
   `tempfile.mkdtemp` and prefix:

   ES-repair10i-audit-supervisor-capability-probe-

2. Create direct mode-0700 directories:

   opening/
   provenance/
   closeout/
   private/

3. Retain the supervisor source as:

   provenance/supervisor.py

4. Create it exclusively as a regular, single-link mode-0600 file.

5. Fsync the source and its parent.

6. Record its exact:

   - path;
   - device;
   - inode;
   - type;
   - mode;
   - link count;
   - size;
   - SHA-256.

7. Create `opening/bootstrap.json` exclusively at mode 0600 and record:

   - probe root;
   - root device/inode/mode;
   - process PID;
   - supervisor source identity;
   - explicit environment;
   - effective umask;
   - bootstrap timestamp;
   - assertion that no target was inspected.

8. Enter the supervisor in the same process. Preserving the same PID across an
   `execve` is permitted.

The supervisor must not use `__file__`, `inspect`, import metadata, cwd, argv
source discovery, or module lookup to infer its identity. Pass the already
verified source identity explicitly.

──────────────────────────────────────────────────────────────────────────────
4. SUPERVISOR PROTOCOL
──────────────────────────────────────────────────────────────────────────────

The supervisor communicates only through its existing stdin/stdout streams.

Use canonical one-line JSON requests and responses.

Required operations:

- `ping`
- `self_check`
- `close`

After initialization and the two mandatory child causals in §6, print and
flush exactly one READY response containing:

- status:
  `ready`
- probe root
- supervisor PID
- supervisor source SHA-256
- completed process ordinals
- recorder self-check outcome

Then remain alive and wait for commands.

The parent must communicate through the same persistent process session. It
must not launch a client process or second shell to send requests.

──────────────────────────────────────────────────────────────────────────────
5. PROCESS RECORD FORMAT
──────────────────────────────────────────────────────────────────────────────

For each child-process attempt N, create exactly:

provenance/process-NNNN.start.json
provenance/process-NNNN.stdout
provenance/process-NNNN.stderr
provenance/process-NNNN.outcome.json

Before attempting child creation:

1. Allocate the contiguous ordinal.
2. Exclusively create and fsync the complete start record.
3. Exclusively create stdout and stderr capture files.

The start record must contain:

- ordinal;
- full argv;
- cwd;
- explicit child environment;
- effective umask;
- purpose;
- start timestamp;
- supervisor PID;
- retained supervisor-source identity;
- stdout/stderr paths.

After the attempt, always retain an outcome containing:

- process-created Boolean;
- PID when created;
- exit or signal when applicable;
- exception type, errno, and message for spawn failure;
- stdout/stderr sizes and SHA-256 values;
- reaped status;
- descriptor-close status;
- end timestamp;
- complete disposition.

Catch `FileNotFoundError`, `PermissionError`, and all other `OSError`
subclasses. A child-creation exception must not escape the supervisor.

Fsync all four records and the provenance directory before the next ordinal.

No overwrite, reconstruction, or ordinal reuse is permitted.

──────────────────────────────────────────────────────────────────────────────
6. MANDATORY CHILD CAUSALS
──────────────────────────────────────────────────────────────────────────────

Process 0001 — missing executable

Attempt:

<PROBE_ROOT>/private/definitely-absent-executable

Requirements:

- the path is absent before the attempt;
- start record exists and is fsynced before spawn;
- process-created is false;
- exception type is `FileNotFoundError`;
- errno is `ENOENT`;
- exit and signal are null;
- stdout is empty;
- stderr is empty or contains a canonical supervisor-generated exception
  representation;
- stream hashes match;
- outcome is complete;
- the supervisor stays alive.

Process 0002 — success after spawn failure

Execute:

/usr/bin/true

Requirements:

- start record exists and is fsynced before spawn;
- process-created is true;
- exit is 0;
- signal is null;
- stdout and stderr are empty;
- child is reaped;
- descriptors are closed;
- outcome is complete;
- the supervisor remains alive.

After both, independently self-check:

- ordinals are exactly 0001 and 0002;
- each has exactly one complete quartet;
- stream bytes match sizes and hashes;
- the same supervisor identity occurs in both;
- no gap or duplicate exists.

Only then print READY.

──────────────────────────────────────────────────────────────────────────────
7. REQUIRED PARENT INTERACTIONS
──────────────────────────────────────────────────────────────────────────────

After receiving READY, while the same process remains alive:

Interaction 1:

Send:
{"op":"ping","request_id":"ping-1"}

Require a flushed response containing:

- request_id `ping-1`;
- status `pong`;
- the same supervisor PID;
- the same probe root.

Interaction 2:

Send:
{"op":"self_check","request_id":"self-check-1"}

Require a flushed response containing:

- request_id `self-check-1`;
- status `pass`;
- ordinals `[1,2]`;
- complete quartet count `2`;
- no gap;
- no duplicate;
- no unreaped child;
- no open child descriptor;
- retained source identity still equal to bootstrap.

Interaction 3:

Send:
{"op":"close","request_id":"close-1"}

Before exit, the supervisor must:

1. Write `closeout/process-record-audit.json`.
2. Write `closeout/final-report.json`.
3. Write `closeout/final-inventory.json`.
4. Verify all retained directories are 0700.
5. Verify all retained files are regular, single-link 0600.
6. Remove `private/`.
7. Make two fresh `lstat` observations returning ENOENT for `private/`.
8. Fsync closeout files and directories.
9. Return a flushed response with:
   - request_id `close-1`;
   - status `closed`;
   - final ordinal;
   - report and inventory SHA-256 values.
10. Exit 0.

──────────────────────────────────────────────────────────────────────────────
8. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return PERSISTENT_AUDIT_SUPERVISOR_READY only if:

- the first carrier process remained alive across READY, ping, self-check, and
  close interactions;
- no second carrier/client process was launched;
- process 0001 was completely recorded as a spawn failure;
- process 0002 was completely recorded as a successful child;
- ordinals and quartets are complete and contiguous;
- the supervisor source is retained and identity-bound;
- the supervisor exited cleanly only after `close`;
- closeout and inventory passed.

Return PERSISTENT_AUDIT_SUPERVISOR_UNAVAILABLE when the Codex tool interface
cannot keep one process session alive or cannot send later stdin interactions
to that same process. Do not characterize that result as a V3 or repository
finding.

Return SUPERVISOR_PROBE_PROVENANCE_MISMATCH for a malformed, missing,
overwritten, or unprovable probe record.

Do not inspect or comment on V3 correctness.

──────────────────────────────────────────────────────────────────────────────
9. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete result inline:

1. Primary verdict
2. Probe-root identity
3. First carrier-process identity and PID
4. Supervisor-source identity
5. Confirmation no `__file__` or runtime self-discovery
6. Process 0001 result
7. Process 0002 result
8. READY response
9. Ping interaction
10. Self-check interaction
11. Close interaction and exit
12. Process-record continuity
13. Retained membership and modes
14. Cleanup and two ENOENT observations
15. Audit-created paths
16. Explicit nonclaims

Required confirmations on READY:

TARGET_CONTENT_NOT_INSPECTED
CANDIDATE_GIT_NOT_INVOKED
SUPPLIED_EVIDENCE_NOT_INSPECTED
SUPERVISOR_SOURCE_RETAINED_AND_HASH_BOUND
SUPERVISOR_PID_PERSISTED_ACROSS_INTERACTIONS
PROCESS_0001_START_RECORDED_BEFORE_SPAWN
MISSING_EXECUTABLE_CAUSAL_RECORDED
PROCESS_0002_SUCCESS_RECORDED
PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_SECOND_CARRIER_PROCESS_CREATED
PRIVATE_SUBTREE_REMOVED
TWO_ABSENCE_OBSERVATIONS_COMPLETED
NETWORK_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

### Decision after the probe

- `PERSISTENT_AUDIT_SUPERVISOR_READY`: reuse this validated execution pattern—not the probe root—for a wholly fresh V3 audit.
- `PERSISTENT_AUDIT_SUPERVISOR_UNAVAILABLE`: stop trying to encode a persistent in-process recorder in the audit. Revise the audit-process contract to a tool-supported evidence model before another target audit.
- `SUPERVISOR_PROBE_PROVENANCE_MISMATCH`: repair only the probe harness and rerun the probe; do not touch V3.

**Source:** Codex response in the preceding message.

**Confidence:** 0.999 that this stop contains no V3 finding; 0.98 that a separate capability probe is now mandatory; 0.9 that persistent-session support is the actual unresolved capability rather than another V3 or bootstrap-source defect.
