## Engineering assessment

The reconciliation is terminal and decisive:

- **Zero package defects were verified.**
- **Twenty-three primary audit-side defects** and **six derivative failures** explain all 29 historical blockers.
- No finding remains mixed or evidence-insufficient.
- The ten deduplicated defect surfaces span lineage, freeze semantics, role resolution, path-sensitive static analysis, confirmation semantics, matrix adapters, typed field-map semantics, subject-domain grammars, root-bound normalization, and report projection.
- This exceeds the threshold for another bounded repair and crosses interfaces beyond the repaired terminal adapter. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The reconciliation found concrete audit causes throughout:

- Attempt 3 was explicitly current; the audit read the wrong status vocabulary.
- The source freeze had valid transitive bindings; the audit invented a redundant direct-hash requirement.
- The 24 production roles and nine qualification roles were misjoined against source registries.
- G01 had no reachable late directory creation; the audit’s owner-name heuristic produced a false positive.
- All ten matrix lanes, the 946-case lane, the 137-case lane, and the 766/333 field map had passing authoritative results; the audit selected wrong registries, wrong row keys, wrong domains, or obsolete aliases.
- Both fresh rehearsals completed successfully. Their errors came from applying the implementation package’s 125-confirmation domain and the wrong manifest grammar to constructed subjects, which correctly own 66 confirmations and `canonical-manifest.v1`.
- The rehearsals were semantically equal after contract-wide physical normalization, and all indispensable evidence was retained before cleanup. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

The mandatory treatment is therefore exactly what Codex selected:

> **Retire the incremental audit-harness lineage, cleanly implement a source-external harness from the governing contracts, qualify it, and freshly audit the unchanged implementation package.** :chatgpt-content-reference{index="6"}

Do not repair the implementation package. Do not repair the retired harness. Do not perform another retrospective reconciliation.

```text
CLEAN-ROOM IMPLEMENTATION AND QUALIFICATION OF A NEW SOURCE-EXTERNAL
INDEPENDENT AUDIT HARNESS FOR THE SEALED GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

Objective

Implement a completely new source-external independent-audit harness from the
current governing contracts, schemas, validation specifications, and terminal
findings-reconciliation.

The new harness must be independently architected and must not copy, patch,
import, execute, transform, or use as an AST/source origin any source from the
retired incremental audit-harness lineage.

Qualify, freeze, requalify, and terminally close the new harness package.

Do not execute the fresh full implementation-package audit in this task.

Do not modify or repair the sealed implementation package.

Do not execute the implementation reconstruction parent.

Do not construct fresh schema-subject rehearsals against the real
implementation package in this task.

Do not construct the authoritative current schema subject.

The immediate output is a sealed clean audit-harness package ready to run
exactly one fresh independent audit in a later tranche.

This task is not:

- another historical findings reconciliation;
- another localized repair of the retired harness;
- an implementation-package repair;
- an implementation-package acceptance or rejection;
- product process-self-test;
- product construct mode;
- target audit;
- runtime validation;
- repository work;
- publication, deployment, or A6 work.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

At most three complete clean-source attempts are permitted.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace material identities, authority decisions,
source registries, process custody, qualification results, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. TERMINAL FINDINGS-RECONCILIATION AUTHORITY
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected identity:

- device:
  16777234
- inode:
  181119472
- mode:
  0700
- verdict:
  GEN2_IMPLEMENTATION_AUDIT_BLOCK_RECONCILED_AUDIT_HARNESS_REIMPLEMENTATION_REQUIRED

Expected physical closure:

- entries:
  56
- directories:
  11
- regular files:
  45
- no symlink, special object, multilink, empty descendant, cache, or bytecode
- directory/file modes:
  0700 / 0600
- seal transitions:
  1
- filesystem operations after seal:
  0
- guarded terminal marker:
  6b098680bb7809ca9fbd541356834085d2e6111f3e750103beafe46626cbe355

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  181133295
- mode:
  0600
- link count:
  1
- size:
  19496
- SHA-256:
  fe18b553b3bb18e8bf1b42c75e78baef641ccd8c4257c58653084120049482cf
- represented rows:
  53

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  181133296
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920
- represented rows:
  54

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  181133297
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920

Authenticate through exact manifest membership:

findings/complete-29-finding-ledger-v1.json
analysis/audit-source-predicate-crosswalk-v1.json
analysis/confirmation-and-terminal-marker-adjudication-v1.json
analysis/fresh-validation-lane-adjudication-v1.json
analysis/fresh-rehearsal-a-b-adjudication-v1.json
analysis/29-finding-dependency-graph-v1.json
analysis/mandatory-next-engineering-treatment-v1.json
validation/audit-block-findings-reconciliation-matrix-v1.json
closing/supplied-root-closing-equality-v1.json
report/explicit-confirmations-v1.json

Treat these records as:

- authoritative historical defect catalogue;
- authoritative repair-ownership decision;
- authoritative retirement decision for the incremental harness lineage;
- nonauthoritative regarding implementation-package acceptance.

Do not reopen or reinterpret F01–F29.

Do not perform another findings reconciliation.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. RETIRED HISTORICAL AUDIT AND HARNESS ROOTS
──────────────────────────────────────────────────────────────────────────────

HISTORICAL_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-independent-audit-fresh-qAGO1c0a

Expected identity:

- device/inode:
  16777234 / 181116268
- mode:
  0700
- historical verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

RETIRED_INCREMENTAL_HARNESS_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

Expected identity:

- device/inode:
  16777234 / 181106957
- mode:
  0700

Classify both as historical evidence only.

The old harness source may not be:

- copied;
- patched;
- transformed;
- imported;
- executed;
- used as a module template;
- used as an AST or bytecode source origin;
- used to generate new source mechanically;
- used as a fallback interface authority.

The old harness may be authenticated read-only only to prove:

- historical identity;
- lineage retirement;
- supplied-root equality.

All technical defect requirements must come from the terminal reconciliation
records and current governing contracts, not from reusing old source.

Require complete opening/closing equality for every historical root opened.

──────────────────────────────────────────────────────────────────────────────
3. SEALED IMPLEMENTATION PACKAGE — UNCHANGED FUTURE AUDIT SUBJECT
──────────────────────────────────────────────────────────────────────────────

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700
- producer verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

Expected closure:

- physical entries:
  112
- directories:
  17
- regular files:
  95
- temporal represented rows:
  109
- manifest represented rows:
  110

Expected production registry:

- inode:
  180895418
- size:
  704
- SHA-256:
  1ded4df7836c16a153b6aab587d7d41903f1d8e907903a0000ae0efb518962c4

Expected production source:

- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

Expected qualification registry:

- inode:
  180895419
- size:
  4391
- SHA-256:
  57c22b15bab5667d32f9949867f198eddd41b0d345ad1d30111370c6c1548a8c

Expected source freeze:

- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

Expected frozen requalification:

- size:
  31819
- SHA-256:
  5e48332bec6610032ea14067eeecda20f653a14af03d0d27f9edc09db862e21f

Use this root only for bounded read-only compatibility qualification.

Do not:

- execute the production reconstruction parent;
- run its qualification driver as the harness parent;
- mutate, resume, reseal, or repair the package;
- issue an implementation verdict in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT GOVERNING ROOTS
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Use only current roles resolved through the successor registry.

Use the normative contract as the sole semantic authority.

Use only current schemas and current validation specifications.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
5. CLEAN IMPLEMENTATION ROOT AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json
opening/clean-source-authority-v1.json

Bind:

- fresh-root identity;
- allocation method and umask;
- terminal reconciliation identity;
- historical harness lineage retired:
  true;
- historical harness source use:
  prohibited;
- clean source initially absent:
  true;
- implementation package mutation authorized:
  false;
- implementation adjudication authorized:
  false;
- full independent audit authorized in this task:
  false;
- production reconstruction execution authorized:
  false;
- rehearsal creation authorized:
  false;
- current-subject construction authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- publication/deployment/A6 authorized:
  false;
- same-root retry authorized:
  false;
- source-attempt limit:
  3.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. PRE-SOURCE OPERATING-MODEL FREEZE
──────────────────────────────────────────────────────────────────────────────

Before writing source, retain:

contract/clean-audit-harness-operating-model-v1.json
contract/clean-audit-harness-authority-v1.json
analysis/clean-audit-harness-source-architecture-v1.json

Freeze:

Authority:

- authenticate supplied roots;
- inspect source and evidence read-only;
- execute audit-owned matrices and causals;
- execute audit-owned disposable rehearsals in a later full-audit mode;
- retain process and filesystem evidence;
- clean only audit-owned roots after evidence retention;
- issue package verdicts;
- close the audit capsule.

Nonauthority:

- implementation repair;
- contract or schema repair;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

Process model:

- one finite parent;
- one child recorder;
- prelaunch-before-spawn;
- complete separate streams;
- exact exit/signal;
- reaping;
- descriptor closure;
- effect attribution before cleanup;
- no stdin reads;
- no persistent supervisor;
- no administrative continuation;
- no shell;
- no PATH executable lookup;
- no network;
- no Git;
- no broad Downloads scan;
- no latest/prefix/score selection;
- no existing-root adoption.

Source boundaries:

- production audit logic;
- qualification-only logic;
- independent validators;
- fixture generators;
- report/capsule finalization;
- failure closeout.

No source may be written before this operating model closes.

──────────────────────────────────────────────────────────────────────────────
7. TEN HISTORICAL DEFECT SURFACES — REQUIRED DESIGN INPUTS
──────────────────────────────────────────────────────────────────────────────

The terminal reconciliation established these ten independent audit defect
surfaces.

Implement each as a separately owned, typed interface with a direct test and an
independent-validator test.

D01 — Attempt/status semantic adapter

Must understand exact authoritative attempt fields, including:

- `final_source_contributor`;
- disposition;
- current/noncurrent posture;
- qualified/frozen/requalified posture.

No status-name scoring.
No recursive arbitrary-string selection.
No fallback to empty status lists.

D02 — Transitive source-freeze binding

Must validate:

freeze
→ source registry
→ source identity
→ rehearsal binding
→ frozen requalification

Do not invent redundant direct-copy requirements not present in the contract.

D03 — Role-layout/source-registry join

Must join:

- component role rows;
- classification;
- relative source path;
- source registry identities.

Must support many roles implemented by one source file.

Must not assume one role row per source-registry row.

D04 — Path-sensitive phase and directory reachability

Must distinguish:

- presence of a generic filesystem helper;
- call-site reachability;
- owning phase;
- successful-path versus failure-path behavior;
- create versus verify-existing semantics.

Must prove G01 and absence of late directory creation path-sensitively.

D05 — Confirmation evidence and guarded terminal semantics

Must understand:

- implementation package confirmation domain:
  125 rows;
- constructed subject confirmation domain:
  66 rows;
- preterminal rows;
- terminal-marker-dependent rows;
- hard-coded success;
- `absence_used_as_success` Boolean value;
- external guarded terminal authority.

Do not search field-name tokens and infer their truth.

D06 — Lane-specific matrix adapters

Implement one explicit adapter per lane.

No generic recursive registry discovery.

No first-match selection.

No same-length-list selection.

No arbitrary string-list selection.

Support each lane’s exact:

- registry document;
- row pointer;
- case-name field;
- expected/observed fields;
- mechanism vocabulary;
- error representation;
- pass representation.

D07 — Typed 766/333 field-map semantics

Treat:

- 766 normative contract facts;
- 333 generated enforcement rows

as distinct typed layers.

Do not impose a stale one-to-one alias map.

D08 — Constructed-subject domain, manifest grammar, and retained evidence

Use the governed constructed-subject:

- confirmation domain;
- manifest schema;
- temporal grammar;
- root-row semantics;
- evidence-retention requirements.

Do not apply implementation-package confirmation or manifest grammars to a
constructed subject.

D09 — Contract-wide root-bound normalization

Normalize physical/root-bound differences by explicit field semantics and
dependency propagation, not filename tokens.

Cover:

- root paths;
- device/inode;
- PIDs;
- root-bound SHA-256 chains;
- root-bound request and authority identities;
- permitted timestamps.

D10 — Causal reconciliation and report projection

Package defects may be reported only from direct package observations.

Do not relabel audit parser failures as implementation defects.

Do not derive primary package findings from failed audit summaries.

Terminal reports must preserve:

- primary versus derivative findings;
- package versus audit defects;
- unresolved evidence;
- terminal-marker semantics.

Retain:

contract/clean-audit-harness-defect-prevention-registry-v1.json

Each D01–D10 row must bind:

- governing source;
- interface contract;
- production owner;
- qualification owner;
- independent-validator owner;
- direct tests;
- historical regression cases.

──────────────────────────────────────────────────────────────────────────────
8. TOTAL EXTERNAL-INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before source, generate:

contract/clean-audit-harness-external-interface-registry-v1.json

Enumerate every acceptance-bearing supplied interface required for a future
full audit.

At minimum include:

- successor 41-role registry;
- implementation production registry;
- implementation qualification registry;
- attempt ledger;
- source freeze;
- frozen requalification;
- producer rehearsal records;
- component-role layout;
- confirmation registry;
- confirmation evidence map;
- ten matrix result families;
- 946-case result;
- 137-case result;
- 766/333 field map;
- constructed-subject phase results;
- constructed-subject confirmation registry;
- constructed-subject temporal inventory;
- constructed-subject terminal manifests;
- Attempt-2 failure evidence;
- supplied-root inventories;
- process records;
- cleanup records;
- terminal capsule records.

For every interface bind:

- role ID;
- authoritative document;
- schema or authenticated grammar;
- exact pointer;
- exact row-key field;
- exact types;
- exact counts;
- uniqueness rule;
- digest rule;
- nullability;
- authority;
- applicability;
- fallback:
  forbidden;
- alias:
  forbidden unless explicitly governed;
- consumer;
- direct qualification test;
- independent test.

Unknown or ambiguous interface fails closed.

──────────────────────────────────────────────────────────────────────────────
9. TOTAL JSON OBSERVATION MODEL
──────────────────────────────────────────────────────────────────────────────

Freeze exact statuses:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

No object-only operation without an exact object observation.

No array access without exact array type and bounds.

No chained `.get()` on untrusted or mutated JSON.

No missing value interpreted as:

- zero;
- false;
- null;
- empty array;
- empty object;
- success.

No generic truthiness for acceptance-bearing:

- Booleans;
- integers;
- nulls;
- arrays;
- objects.

Retain:

contract/clean-audit-harness-total-json-observation-v1.json

──────────────────────────────────────────────────────────────────────────────
10. SOURCE ARCHITECTURE AND ROLE REGISTRIES
──────────────────────────────────────────────────────────────────────────────

Define a clean modular architecture before source creation.

At minimum assign distinct roles for:

- finite audit parent;
- child recorder;
- strict JSON parser;
- total JSON observer;
- no-follow inventory;
- current-role resolver;
- manifest/temporal grammar registry;
- attempt/status adapter;
- source-freeze validator;
- component-role/source joiner;
- path-sensitive static analyzer;
- qualification-independence analyzer;
- confirmation adjudicator;
- lane-specific matrix adapters;
- field-map adjudicator;
- rehearsal supervisor;
- constructed-subject validator;
- root-bound normalizer;
- evidence-retention and cleanup;
- process/failure-custody adjudicator;
- security/authority analyzer;
- causal reconciliation;
- report projection;
- capsule terminal lifecycle;
- failure closeout;
- platform-capture preflight;
- independent component validators;
- independent end-to-end harness validator.

Every role must map exactly once to a source path.

Production audit logic may not import qualification fixtures.

Independent validators may not import:

- production audit modules;
- producer helpers;
- producer matrix generators;
- producer expected-result maps;
- production JSON observers;
- production normalizers;
- production manifest projectors.

Retain planned and final:

contract/clean-audit-harness-production-source-registry-v1.json
contract/clean-audit-harness-qualification-source-registry-v1.json
contract/clean-audit-harness-independent-source-registry-v1.json

──────────────────────────────────────────────────────────────────────────────
11. CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before compilation, retain:

contract/clean-audit-harness-cross-module-interface-registry-v1.json

For every cross-module interface bind:

- provider file/function;
- consumer file/function;
- input shape;
- output shape;
- exact consumed fields;
- types;
- nullability;
- exception semantics;
- authority;
- applicable verdict classes;
- direct integration test;
- independent coverage.

Require:

- every acceptance-bearing edge registered;
- no consumer field outside provider shape;
- no duplicated mutable fact;
- no alias or fallback;
- no recursive field search;
- one authoritative representation per fact;
- direct real-function integration test per interface.

Unknown interface blocks qualification.

──────────────────────────────────────────────────────────────────────────────
12. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete clean-source attempts are permitted.

A complete attempt begins when:

- production source registry closes;
- qualification source registry closes;
- independent source registry closes;
- compilation begins.

For every attempt retain:

- complete source identities;
- clean-room provenance;
- compilation;
- static gates;
- interface gates;
- matrices reached;
- synthetic audit results;
- first blocker;
- supersession disposition.

Any source modification after compilation begins creates a new attempt.

If Attempt 3 fails:

- stop;
- return the blocked verdict;
- do not create Attempt 4.

No failed attempt contributes:

- final source identity;
- passing result counts;
- source freeze;
- readiness status.

──────────────────────────────────────────────────────────────────────────────
13. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every source under pinned Python with `-I -S -B`.

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- interface-shape analysis;
- process-launch crosswalk;
- filesystem-operation crosswalk;
- terminal-operation crosswalk.

Require:

- finite control flow;
- no stdin read;
- no persistent supervisor;
- every child through one recorder;
- no network;
- no Git;
- no shell;
- no PATH executable lookup;
- no broad Downloads traversal;
- no latest/prefix/score selection;
- no supplied-root mutation;
- no historical harness import;
- no dynamic import escape;
- no postseal filesystem operation;
- success and failure closeout reachable;
- every D01–D10 owner present;
- every cross-module interface directly covered.

Static pass is false when any required field is false.

──────────────────────────────────────────────────────────────────────────────
14. DEFECT-PREVENTION MATRICES
──────────────────────────────────────────────────────────────────────────────

Run independently named matrices for D01–D10.

Every matrix requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

At minimum:

A. Attempt/status matrix — 30 cases

Include:

- exact Attempt 1/2/3 baseline;
- missing `final_source_contributor`;
- wrong type;
- two contributors;
- no contributor;
- stale disposition;
- status-string distractions;
- nested unrelated status values;
- empty arrays;
- null fields.

B. Freeze-binding matrix — 25 cases

Include:

- exact transitive baseline;
- stale source registry;
- stale source identity;
- missing registry binding;
- rehearsal bound to wrong source;
- frozen requalification bound to stale source;
- redundant absent direct hash that must not fail;
- contradictory direct hash.

C. Role/source join matrix — 30 cases

Include:

- 24 roles in one production file;
- nine roles in nine qualification files;
- multiple roles per source;
- missing role;
- duplicate role;
- stale source path;
- wrong classification;
- source-registry row count different from role count.

D. Path-sensitive G01 matrix — 30 cases

Include:

- exact three creation sites;
- helper present but unreachable;
- late successful-path mkdir;
- failure-path-only mkdir;
- verify-existing directory;
- idempotent noncreating check;
- generic helper owner-name false positive.

E. Confirmation semantics matrix — 35 cases

Include:

- implementation 125-domain;
- constructed-subject 66-domain;
- preterminal rows;
- terminal-marker rows;
- absence flag false;
- absence flag true;
- null blocker;
- hard-coded true;
- missing evidence pointer;
- stale source binding;
- terminal marker absent/present.

F. Matrix-adapter matrix — at least 100 cases

Cover every current lane grammar:

- bootstrap order;
- external interface;
- JSON observation;
- schema/family;
- process custody;
- cleanup/failure evidence;
- writer/lifecycle;
- namespace/temporal;
- manifest/terminal;
- negative-checker robustness;
- 946 literal-name cases;
- 137 literal-name cases.

Include wrong registries and wrong same-length lists.

G. Field-map matrix — 30 cases

Cover:

- 766 normative rows;
- 333 enforcement rows;
- exact typed baseline;
- unresolved count;
- wrong layer;
- stale aliases;
- missing contract pointer;
- missing schema role;
- duplicate row;
- cross-layer collision.

H. Subject-domain/manifest matrix — 40 cases

Cover:

- 66 confirmations;
- incorrect 125-domain;
- `canonical-manifest.v1`;
- incorrect `canonical-terminal-manifest.v1`;
- temporal grammar;
- root row;
- exclusions;
- retained evidence payloads;
- deleted-root evidence replaced by immutable copied payloads.

I. Root-normalization matrix — 40 cases

Cover root-bound propagation through:

- authority records;
- fixed-input records;
- process outcomes;
- regeneration records;
- independent-validator records;
- nested hashes and identities.

No filename-token gating.

J. Causal-report matrix — 30 cases

Cover:

- direct package defect;
- audit parser defect;
- audit oracle defect;
- static-analysis defect;
- derivative failure;
- mixed finding;
- evidence insufficiency;
- substantive BLOCK report;
- provenance mismatch report.

──────────────────────────────────────────────────────────────────────────────
15. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Run audit-owned causals for:

- nonexistent executable;
- zero exit and empty streams;
- nonzero exit with both streams;
- timeout/kill/reap;
- dynamic-root zero exit;
- dynamic-root nonzero exit;
- missing result;
- empty child ledger;
- one child;
- multiple children;
- lost stdout;
- lost stderr;
- unregistered filesystem effect;
- evidence-before-cleanup;
- zero-root cleanup;
- one-root cleanup;
- multiple-root cleanup.

Require:

- prelaunch before spawn;
- complete streams;
- exit or signal;
- reaping;
- descriptor closure;
- root attribution on zero/nonzero/timeout;
- evidence retained before cleanup;
- exact cleanup-set equality;
- double ENOENT;
- zero survivors.

──────────────────────────────────────────────────────────────────────────────
16. SYNTHETIC END-TO-END AUDIT FIXTURES
──────────────────────────────────────────────────────────────────────────────

Create audit-owned synthetic package fixtures from the governing contracts.

Do not copy implementation-package result bytes as the synthetic oracle.

Run at minimum:

A. Synthetic accepted implementation package

Must produce:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

B. Synthetic substantive BLOCK package

Introduce one exact known implementation defect.

Must produce:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

C. Synthetic audit provenance failure

Lose or corrupt one audit-owned process/evidence obligation.

Must produce:

AUDIT_PROVENANCE_MISMATCH

D. Synthetic constructed-subject pair

Two physically distinct but semantically equal roots.

Must pass 66-confirmation, manifest-grammar, normalization, retention, and
cleanup lanes.

E. Synthetic matrix corpus

All lane adapters must parse only their exact registries and reject
same-length or similarly named alternatives.

For each end-to-end fixture retain:

- complete process custody;
- exact inputs;
- exact verdict;
- complete findings;
- report;
- temporal inventory;
- manifest pair;
- terminal adapter result;
- cleanup;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
17. BOUNDED READ-ONLY COMPATIBILITY REPLAY
──────────────────────────────────────────────────────────────────────────────

Run a bounded read-only replay against the unchanged real implementation and
governing roots.

Do not execute:

- the implementation production parent;
- fresh rehearsals;
- the full audit mode.

Require the clean harness to:

1. authenticate the implementation package;
2. reproject its temporal inventory and manifest pair;
3. resolve all 41 successor roles;
4. resolve Attempts 1–3 using `final_source_contributor`;
5. validate transitive freeze binding;
6. resolve all 24 production roles;
7. resolve all nine qualification roles;
8. path-sensitively adjudicate G01;
9. audit all 125 implementation confirmations;
10. parse every current matrix lane;
11. parse all 946 and 137 rows;
12. parse the 766/333 field map;
13. parse both retained producer rehearsals under their governed subject
    domain and grammar;
14. normalize retained producer rehearsals with zero unexplained difference;
15. authenticate Attempt-2 failure evidence;
16. derive one exact future full-audit invocation;
17. produce no implementation ACCEPT/BLOCK verdict.

Retain:

validation/clean-harness-bounded-compatibility-replay-v1.json

Allowed posture:

ready_for_fresh_full_audit

Require:

- zero parser error;
- zero interface ambiguity;
- zero unexplained difference;
- zero package verdict.

This replay validates harness compatibility; it does not accept the package.

──────────────────────────────────────────────────────────────────────────────
18. TWO HARNESS QUALIFICATION REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete harness rehearsals against independent
audit-owned synthetic fixture sets.

Use exact same frozen candidate source bytes.

Require in each rehearsal:

- full source-external audit process;
- matrices;
- process custody;
- synthetic accepted package;
- synthetic BLOCK package;
- synthetic provenance failure;
- constructed-subject comparison;
- report generation;
- terminal capsule closure;
- cleanup.

Retain complete rehearsal roots until:

- independent rehearsal validation;
- normalized comparison;
- evidence retention.

Normalize only explicit physical fields.

Require zero unexplained semantic difference.

──────────────────────────────────────────────────────────────────────────────
19. INDEPENDENT HARNESS VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Implement source-external independent validators that import neither:

- harness production modules;
- harness qualification helpers;
- matrix generators;
- expected-result maps;
- production JSON observers;
- production normalizers;
- production terminal projectors.

Independent validators must separately verify:

- clean-room provenance;
- source architecture;
- interface registry;
- D01–D10 matrices;
- process custody;
- synthetic verdict lanes;
- bounded compatibility replay;
- both harness rehearsals;
- normalization;
- evidence retention and cleanup;
- capsule closure;
- terminal report semantics.

Require zero errors and no exception.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE EVIDENCE AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any audit-owned root retain:

- exact root identity;
- complete no-follow inventory;
- all process records and streams;
- every indispensable result;
- failure outcome;
- terminal posture.

Then:

- re-lstat and verify identity;
- remove exact root;
- observe ENOENT twice.

Require exact equality:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Equal empty sets are valid.

No path inside a removed root counts as retained evidence.

──────────────────────────────────────────────────────────────────────────────
21. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- all static gates pass;
- every D01–D10 matrix passes;
- process-custody qualification passes;
- every synthetic verdict fixture passes;
- bounded compatibility replay passes;
- two harness qualification rehearsals pass;
- normalized equality passes;
- independent harness validators pass;
- evidence retention and cleanup pass;
- supplied roots remain equal.

Retain:

opening/clean-audit-harness-source-freeze-v1.json

Bind:

- exact production registry;
- exact qualification registry;
- exact independent registry;
- clean-room provenance;
- governing role identities;
- all matrices;
- synthetic fixtures;
- compatibility replay;
- both rehearsals;
- normalized comparison;
- cleanup;
- full audit not executed;
- later source modification permitted:
  false.

Reopen every source no-follow and verify identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
22. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source bytes rerun:

- compilation;
- static and interface gates;
- all D01–D10 matrices;
- process-custody qualification;
- synthetic verdict fixtures;
- bounded compatibility replay;
- independent validators;
- source/result identity linkage;
- supplied-root closing equality.

Do not rerun the two complete harness rehearsals.

Require proof that both passing rehearsals used the exact bytes later frozen.

Retain:

validation/clean-audit-harness-frozen-source-requalification-v1.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
23. HARNESS PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  clean-source-external-gen2-implementation-audit-harness-implemented-qualified-frozen-pending-fresh-audit;
- incremental harness lineage:
  retired;
- implementation package mutated:
  false;
- implementation package adjudicated:
  false;
- full audit executed:
  false;
- harness qualification:
  passed;
- source frozen:
  true;
- fresh full audit required:
  true;
- current-subject construction authorized:
  false;
- process self-test:
  not executed;
- product construct mode:
  not executed;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- publication/deployment/A6:
  not authorized.

Do not claim implementation acceptance or rejection.

──────────────────────────────────────────────────────────────────────────────
24. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- terminal reconciliation root;
- historical audit;
- retired harness;
- implementation package;
- successor Generation-2 package;
- authoritative contract;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root;
- any additional supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every harness-owned fixture root:

- retain complete inventory;
- retain indispensable evidence;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
25. CLEAN HARNESS-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize every nonclosure output;
- create only final directories actually used;
- ensure `closeout/` and `manifest/` exist;
- retain no empty descendant;
- exclusively reserve zero-length manifest A/B;
- retain descriptors;
- freeze directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and A/B;
2. write into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. independently generate A/B with A/B excluded;
6. require identical bytes;
7. write through retained descriptors;
8. fsync, close, and fsync manifest directory;
9. reopen no-follow;
10. verify path/inode/type/mode/link/size/hash;
11. independently reproject final root;
12. require root row exactly once;
13. require no empty descendant;
14. require no symlink or special object;
15. require no multiply linked regular file;
16. require directory/file modes 0700/0600;
17. require no cache or bytecode;
18. transition seal once;
19. build final report through typed closed interfaces;
20. emit only guarded terminal marker and verdict;
21. exit nonreturningly;
22. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
26. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- first blocker;
- structured exception;
- complete process ledger and streams;
- complete partial inventory;
- indispensable evidence before cleanup;
- cleanup;
- supplied-root equality;
- harness authority false;
- source-freeze posture;
- terminal seal false;
- same-root retry false.

Do not create success manifests for a failed package.

Failure to retain indispensable evidence, clean audit-owned roots, or close
supplied roots equally is:

CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
27. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- terminal reconciliation authenticates;
- incremental harness lineage remains retired;
- clean-room source authority closes;
- no historical harness source is reused;
- operating model and source architecture freeze before source;
- every D01–D10 interface is implemented and directly tested;
- total JSON observation closes;
- every cross-module interface closes;
- implementation completes within three attempts;
- static gates pass;
- all matrices pass;
- process custody passes;
- synthetic ACCEPT/BLOCK/provenance lanes pass;
- bounded compatibility replay passes with no verdict;
- two harness rehearsals pass;
- normalized rehearsal equality passes;
- independent validators pass;
- evidence is retained before cleanup;
- cleanup closes;
- source freezes;
- frozen-source requalification passes;
- full audit remains unexecuted;
- implementation remains unchanged and unadjudicated;
- supplied roots close equal;
- harness package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when:

- a clean implementation cannot satisfy the governing contracts within three
  attempts;
- an external interface remains ambiguous;
- a static gate, matrix, synthetic lane, compatibility replay, rehearsal, or
  independent validator fails;
- implementation would require changing package semantics, schemas, validation
  semantics, or governing authority.

Return:

CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- supplied-root mutation;
- source drift after freeze;
- unregistered process or filesystem effect;
- indispensable evidence loss;
- cleanup inequality;
- supplied-root closing inequality;
- harness-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
28. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh clean-harness root identity
3. Terminal reconciliation authentication
4. Incremental harness-lineage retirement
5. Implementation-package identity and preservation
6. Governing-root identities and preservation
7. Clean-room source-authority result
8. Pre-source operating-model freeze
9. D01–D10 defect-prevention registry
10. External-interface registry
11. Total JSON-observation contract
12. Source architecture
13. Planned source registries
14. Source-attempt ledger
15. Final production-source registry
16. Final qualification-source registry
17. Final independent-source registry
18. Cross-module interface registry
19. Static source results
20. Attempt/status matrix
21. Freeze-binding matrix
22. Role/source-join matrix
23. G01 reachability matrix
24. Confirmation-semantics matrix
25. Lane-adapter matrix
26. Field-map matrix
27. Constructed-subject-domain matrix
28. Root-normalization matrix
29. Causal-report matrix
30. Process-custody qualification
31. Synthetic accepted-package result
32. Synthetic BLOCK-package result
33. Synthetic provenance-failure result
34. Synthetic constructed-subject-pair result
35. Bounded compatibility replay
36. Harness rehearsal A
37. Harness rehearsal B
38. Normalized harness-rehearsal comparison
39. Independent harness-validator results
40. Evidence retention
41. Fixture and rehearsal cleanup
42. Source freeze
43. Frozen-source requalification
44. Confirmation full audit was not executed
45. Harness-package status
46. Supplied-root closing equality
47. Failure-closeout capability and use
48. Temporal-inventory identity
49. Manifest A identity
50. Manifest B identity
51. Independent terminal reprojection
52. Terminal membership and modes
53. No-write-after-closure
54. Remaining uncertainty and nonclaims
55. Explicit confirmation registry

Required confirmations:

FINAL_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
FINAL_RECONCILIATION_IDENTITY_MATCHED
FINAL_RECONCILIATION_TERMINAL_CLOSURE_AUTHENTICATED
HISTORICAL_BLOCK_PRESERVED
INCREMENTAL_AUDIT_HARNESS_LINEAGE_RETIRED
FURTHER_INCREMENTAL_HARNESS_REPAIR_NOT_USED
HISTORICAL_AUDIT_ROOT_MUTATION_NOT_PERFORMED
RETIRED_HARNESS_ROOT_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
SUCCESSOR_GEN2_ROOT_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_ROOT_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_ROOT_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_ROOT_MUTATION_NOT_PERFORMED
ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
NO_HISTORICAL_HARNESS_SOURCE_COPIED
NO_HISTORICAL_HARNESS_SOURCE_PATCHED
NO_HISTORICAL_HARNESS_SOURCE_IMPORTED
NO_HISTORICAL_HARNESS_SOURCE_USED_AS_AST_ORIGIN
CLEAN_OPERATING_MODEL_FROZEN_BEFORE_SOURCE
CLEAN_SOURCE_ARCHITECTURE_COMPLETE
D01_ATTEMPT_STATUS_ADAPTER_IMPLEMENTED
D02_TRANSITIVE_FREEZE_BINDING_IMPLEMENTED
D03_ROLE_SOURCE_JOIN_IMPLEMENTED
D04_PATH_SENSITIVE_G01_ANALYSIS_IMPLEMENTED
D05_CONFIRMATION_AND_TERMINAL_SEMANTICS_IMPLEMENTED
D06_LANE_SPECIFIC_MATRIX_ADAPTERS_IMPLEMENTED
D07_TYPED_766_333_FIELD_MAP_IMPLEMENTED
D08_CONSTRUCTED_SUBJECT_DOMAIN_AND_GRAMMAR_IMPLEMENTED
D09_ROOT_BOUND_NORMALIZATION_IMPLEMENTED
D10_CAUSAL_RECONCILIATION_AND_REPORT_PROJECTION_IMPLEMENTED
ALL_ACCEPTANCE_BEARING_EXTERNAL_INTERFACES_FROZEN
NO_ACCEPTANCE_BEARING_POINTER_FALLBACK
TOTAL_JSON_OBSERVATION_IMPLEMENTED
NO_UNGUARDED_ACCESS_ON_UNTRUSTED_JSON
CROSS_MODULE_INTERFACE_REGISTRY_COMPLETE
EVERY_ACCEPTANCE_BEARING_INTERFACE_DIRECTLY_TESTED
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_PRODUCTION_SOURCE_REGISTRY_COMPLETE
FINAL_QUALIFICATION_SOURCE_REGISTRY_COMPLETE
FINAL_INDEPENDENT_SOURCE_REGISTRY_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
ATTEMPT_STATUS_MATRIX_PASSED
FREEZE_BINDING_MATRIX_PASSED
ROLE_SOURCE_JOIN_MATRIX_PASSED
G01_REACHABILITY_MATRIX_PASSED
CONFIRMATION_SEMANTICS_MATRIX_PASSED
LANE_ADAPTER_MATRIX_PASSED
FIELD_MAP_MATRIX_PASSED
CONSTRUCTED_SUBJECT_DOMAIN_MATRIX_PASSED
ROOT_NORMALIZATION_MATRIX_PASSED
CAUSAL_REPORT_MATRIX_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
CLEAN_HARNESS_SOURCE_FROZEN
CLEAN_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_CLEAN_HARNESS_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CLEAN_HARNESS_TEMPORAL_INVENTORY_CREATED
CLEAN_HARNESS_TEMPORAL_INVENTORY_VERIFIED
CLEAN_HARNESS_MANIFEST_A_CREATED
CLEAN_HARNESS_MANIFEST_B_CREATED
CLEAN_HARNESS_MANIFESTS_BYTE_IDENTICAL
CLEAN_HARNESS_TERMINAL_REPROJECTION_PASSED
CLEAN_HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged sealed
implementation package using the clean frozen harness.

Do not combine that full audit with this implementation tranche.

Do not construct the authoritative current schema subject until the later
fresh audit accepts the implementation package.
```

### Sources

The terminal reconciliation reports 23 primary audit defects, six derivative failures, zero package defects, zero mixed findings, and no remaining causal-ownership uncertainty. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

Its finding ledger and later adjudications identify the concrete parser, binding, oracle, static-analysis, domain, normalization, and report-projection defects behind all 29 blockers. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

The reconciliation deduplicates those failures into ten independent audit-harness scopes and mandates clean source-external harness reimplementation followed by a fresh audit of the unchanged package. :chatgpt-content-reference{index="13"}

**Confidence:** 0.999 that the implementation package should remain unchanged; 0.998 that the incremental harness lineage must be retired; 0.99 that clean harness implementation and qualification is the only authorized next engineering tranche.
