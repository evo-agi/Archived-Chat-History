## Assessment

This is a strong producer result. It appears to close the three findings from the V2 audit without changing executable behavior:

- **`CONTRACT_FREEZE_INCOMPLETE`**: V3 now freezes the missing allocator mechanics—no-follow traversal, held parent custody, EEXIST-only retries, fresh collision material, attempt bound, and terminal non-EEXIST behavior.
- **`NONAUTHORITY_INCOMPLETE`**: hostile/shared hosts and symlink, bind-mount, mount, and pathname aliases are all explicitly unsupported.
- **`PATH_SOURCE_CLOSURE_INCOMPLETE`**: the closure now includes pinned Go `src/internal/strconv/itoa.go`, including its exact size and digest.

The report also preserves the right separation:

- V2’s runtime behavior is not rerun or rewritten.
- The V2 audit remains `BLOCK`; only its bounded technical observations are adopted.
- Plan V4 is claimed to be semantically identical to Plan V3.
- Strategic B remains the sole B source/provenance package.
- V3 remains proposed-effective pending an independent audit.

No further producer implementation is indicated before audit.

### Remaining audit seams

The independent audit should focus narrowly on record integrity rather than repeat runtime validation:

1. **Recompute Plan V3→V4 equivalence independently.** The producer’s normalization result must not hide an acceptance-bearing omission or changed default.
2. **Derive the path budget from the actual source chain**, including `tempfile.go` and `itoa.go`, rather than merely confirming recorded hashes.
3. **Inspect every adopted V2 audit record directly.** The audit must establish that each claimed technical observation is supported while preserving the historical `BLOCK`.
4. **Reconstruct mutations independently.** The second producer validator used producer-retained mutation fixtures; the fresh auditor should generate its own copies and mutations.
5. **Adjudicate the retained failed-attempt copies.** The failed build contains copies of the V3 contract and Plan V4 beneath `validation/failed-attempts/`. They must be clearly quarantined and nonauthoritative, not competing normative writers.
6. **Reconstruct capsule closure independently**, including all failed-attempt material.

A runtime replay should occur only if the audit finds a semantic difference between Plans V3 and V4. Otherwise, repeating the eight commands would add risk without resolving an open behavioral question.

After an `ACCEPT`, the next operation is the real H→B commit gate.

## Prompt for Codex

```text
FRESH NARROW INDEPENDENT AUDIT —
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 RECORD COMPLETION

Perform a fresh, independent, read-only audit of the combined target:

1. the immutable Repair 10I T2A-P strategic B snapshot;
2. the immutable blocked V1 validation-custody capsule;
3. the immutable V2 validation-custody capsule;
4. the immutable V2 independent audit; and
5. the V3 record-completion capsule.

Do not repair anything.

Do not rerun the eight-command runtime validation plan unless independent
comparison proves that Plan V4 changes executable or acceptance-bearing
semantics relative to Plan V3.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether V3:

- completely and unambiguously freezes the validation-custody contract;
- preserves all Plan V3 executable and acceptance semantics in Plan V4;
- completes the exact source closure of the 86-byte path-budget derivation;
- adds the required explicit nonauthority statements;
- correctly composes bounded V2 technical evidence without promoting the V2
  audit’s BLOCK verdict;
- has independent contradiction resistance;
- has complete provenance and artifact closure;
- creates no competing B source authority or competing normative writer.

An ACCEPT qualifies the record-complete validation-custody contract. It does
not grant product readiness, deployment authority, A6 authority, or commit
authority by itself.

──────────────────────────────────────────────────────────────────────────────
1. ADMINISTRATIVE INTAKE AND AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Reading this prompt or its attachment before the audit epoch is administrative
intake only. It is excluded from evidence.

Do not inspect the candidate repository or any supplied evidence root before
the audit epoch.

After reading the complete prompt, state:

AUDIT_EPOCH_START

The first post-epoch process must:

- use the candidate repository as cwd;
- carry the explicit environment in §3;
- set umask 077;
- allocate the fresh audit root using `tempfile.mkdtemp`;
- create an exclusive mode-0600 bootstrap record before inspecting target
  content.

Retain contemporaneous start, stdout, stderr, exit, and outcome records for
every post-epoch parent process. Do not overwrite or reconstruct a missing
process record.

──────────────────────────────────────────────────────────────────────────────
2. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected identity:

- physical root:
  exact path above
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed/tracked/untracked:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory:
  54314 bytes
  SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Expected identities:

- root device/inode/mode:
  16777234 / 178255587 / 0700
- complete-tree inventory:
  164555 bytes
  SHA-256:
  797aad807f76e93a92642b7b3ef798ebab856ecea242325daa623ec08866c201
- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory:
  54314 bytes
  SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- governed files:
  389
- H→B classification:
  22 modified, 14 added, 0 deleted, 0 renamed
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- synthetic parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- synthetic subject:
  implement Remote Alpha external TLS T2A-P source
- closeout/final-evidence-inventory.json:
  130182 bytes
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb
- closeout/final-report.md:
  151150 bytes
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe
- both strategic manifests:
  139328 bytes each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  byte-identical

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Expected identities:

- root device/inode/mode:
  16777234 / 178515489 / 0700
- complete-tree inventory:
  20758 bytes
  SHA-256:
  7e202a82f642124f952c288ae5ba6f4056150e8163df60101f6d7d630257d3b0
- final inventory SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- both manifest SHA-256 values:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498
- disposition:
  immutable historical, non-effective sibling-root design

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

Expected identities:

- root device/inode/mode:
  16777234 / 178558083 / 0700
- complete-tree inventory:
  29434 bytes
  SHA-256:
  33a659bc82d8fe67778e9806674c8a5f5b0477ea7a36a67af9cb902c3c186b76
- contract:
  execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2
- Plan V3:
  28590 bytes
  SHA-256:
  fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee
- final inventory:
  22990 bytes
  SHA-256:
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658
- final report:
  1355 bytes
  SHA-256:
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd
- both manifests:
  24408 bytes
  SHA-256:
  2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628
  byte-identical

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected identities:

- root device/inode/mode:
  16777234 / 178646858 / 0700
- complete-tree inventory:
  64018 bytes
  SHA-256:
  e8824a5f0b36b5d4c3b93e71a92b443257e3c1c1f4e97bfba9d4509d8a63ba5e
- verdict:
  BLOCK
- final audit report:
  92491 bytes
  SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05
- final audit inventory:
  69706 bytes
  SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

VALIDATION_CUSTODY_V3_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

Expected root:

- device/inode/mode:
  16777234 / 178799785 / 0700

Expected principal records:

- contract/strategic-b-validation-custody-v3.json
  4878 bytes
  SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

- contract/validation-plan-v4.json
  26001 bytes
  SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

- contract/plan-v3-v4-semantic-equivalence-v1.json
  3937 bytes
  SHA-256:
  4855cbd41a4c16a4d0ff52aa2dec75bdd66b1f272d1e1323d7a3b8759efe2f5b

- validation/producer-documentary-validator-result-v1.json
  18211 bytes
  SHA-256:
  796c295ae899fe386e268939e6a8c1bdad53559ac8d5cb9ffd066ec9454a0f04

- validation/independent-documentary-validator-result-v1.json
  19104 bytes
  SHA-256:
  5411a9a2c3b36d4d8af0c724319d6c1e0451576d9c0f8bb90adb403b48d9f19d

- validation/mutation-matrix-v1.json
  22410 bytes
  SHA-256:
  77c844a8261f55110c8900b42cef0d3d47ec39205209f089467c8c0c4cb9fe60

- closeout/final-implementation-report-v1.md
  21171 bytes
  SHA-256:
  4cec72ec50ddf41658b9fbf6a48c843ce5a2377bfaf17424bdefada7f1f0d3e6

- closeout/final-evidence-inventory-v1.json
  18305 bytes
  SHA-256:
  f7f602952c1a44d442982e883fe6be44c48dca0a908701126463e943964b25c9

- both manifests:
  19881 bytes each
  SHA-256:
  94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359
  byte-identical

Expected V3 closure:

- 12 directories including root;
- 88 physical retained files including manifests;
- 86 nonmanifest files;
- 98 represented manifest entries;
- exactly two self-excluded manifests;
- no empty directory;
- directories mode 0700;
- files regular, single-link, mode 0600.

PINNED GO SOURCE

Go executable:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected SHA-256:

3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Expected exact source closure:

- B `internal/testsupport/controlroot.go`
  8695 bytes
  SHA-256:
  3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3

- B `internal/testsupport/controlroot_test.go`
  1359 bytes
  SHA-256:
  de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f

- B `es/runtimehelper/helper_test.go`
  5017 bytes
  SHA-256:
  715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0

- pinned Go `src/os/tempfile.go`
  4002 bytes
  SHA-256:
  a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16

- pinned Go `src/internal/strconv/itoa.go`
  6171 bytes
  SHA-256:
  cfda0d39152dc8ad8e2eb0407682c399ea0a321796211e015096fa57b17a35d5

Do not inspect unrelated sibling repositories or unrelated Downloads content.

──────────────────────────────────────────────────────────────────────────────
3. REQUIRED PROCESS ENVIRONMENT
──────────────────────────────────────────────────────────────────────────────

Every Git read against CANDIDATE_R must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to CANDIDATE_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

No Git command may target a supplied evidence root or the primary checkout.

──────────────────────────────────────────────────────────────────────────────
4. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate a fresh retained audit root beneath
`/Users/ds/Downloads` using `tempfile.mkdtemp` with prefix:

ES-repair10i-t2ap-validation-custody-v3-independent-audit-

Required directories:

opening/
auditors/
contract/
validation/
provenance/
closeout/
manifest/
private/

Retained directories:

- direct physical directories;
- mode 0700.

Retained files:

- regular;
- single-link;
- mode 0600.

The `private/` subtree must be removed before closeout and observed absent twice.

Do not retain unexplained empty directories.

──────────────────────────────────────────────────────────────────────────────
5. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Read candidate AGENTS.md and applicable nested guidance.
2. Verify complete candidate identity and current F inventory.
3. Verify complete closure of all four predecessor/supplied roots.
4. Verify complete V3 root closure and every fixed record identity.
5. Verify the exact pinned Go executable and all five source-closure files.
6. Retain complete opening inventories for every supplied root.
7. Verify candidate operation markers and locks are absent.
8. Verify the audit root was absent before allocation and the bootstrap record
   preceded content inspection.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

Do not clean, normalize, chmod, recreate, or repair a supplied object.

──────────────────────────────────────────────────────────────────────────────
6. FOUR DIRECT READ-ONLY AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes, start exactly three direct auditors
concurrently. After the first closes, start a fourth distinct auditor.

Auditor 1 — contract and authority

Inspect:

- V3 contract;
- supersession record;
- V3/V4 plan records;
- complete relevant reports;
- nonauthority fields;
- failed-attempt classification.

Adjudicate:

- one sole normative writer;
- complete allocator contract;
- complete nonauthority;
- no B-source authority;
- no verdict promotion;
- failed-attempt copies do not create competing authority.

Auditor 2 — plan equivalence and source closure

Inspect:

- complete Plan V3 and Plan V4;
- producer equivalence checker;
- exact B and Go source files.

Independently derive:

- normalized plan equivalence;
- exact eight-command preservation;
- path-source dependency closure;
- decimal maximum 10;
- generated-component maximum 12;
- worst-case path 86;
- limit 100.

Auditor 3 — evidence adoption and lineage

Inspect:

- V2 audit report and inventory;
- every V2 technical record referenced by the adoption record;
- adoption record;
- supersession lineage;
- failed and superseded attempts.

Adjudicate:

- every adopted observation is supported;
- the V2 verdict remains BLOCK;
- no runtime evidence is invented or copied into a competing lineage;
- V3 claims only bounded composition.

Auditor 4 — provenance, artifacts, and security

Inspect:

- every V3 capsule object;
- both manifests and final inventory;
- failed-attempt directories;
- validator sources and mutation fixtures;
- sensitive-material posture.

Adjudicate:

- complete membership;
- modes, links, types, and self-exclusions;
- no unexplained empty object;
- no competing normative file;
- no secret or unsafe artifact;
- no supplied-root mutation.

Auditors must:

- use exact absolute operands;
- run no Git;
- run no tests or product code;
- write no files;
- make no network contact;
- create no nested agent.

The parent must retain their prompts, exact operand sets, start/finish order,
reports, uncertainties, uninspected scope, and minority findings.

If four distinct auditors cannot complete, return BLOCK for incomplete audit
coverage.

──────────────────────────────────────────────────────────────────────────────
7. INDEPENDENT CONTRACT RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not import producer validator code.

Independently parse the V3 contract with:

- duplicate-key rejection;
- nonfinite-number rejection;
- exact canonical encoding;
- exact complete key set;
- exact value types;
- exact enumerations and lists.

Require all allocator semantics to be literal, including:

- OS CSPRNG;
- fresh material per attempt;
- component no-follow traversal;
- held parent descriptor and identity;
- descriptor-relative exclusive creation;
- EEXIST-only retry;
- fresh retry material;
- attempt limit 128;
- terminal non-EEXIST behavior;
- direct child identity requirements;
- forbidden authority sources;
- forbidden allocation actions.

Require all six explicit nonauthority fields to be false.

Require `source_authority`, `publication_authority`, `commit_authority`,
`product_authority`, `runtime_authority`, `deployment_authority`,
`readiness_authority`, and `a6_authority` to be false.

Require the contract to name itself as the sole validation-custody writer and
the strategic snapshot as sole B source/provenance package.

──────────────────────────────────────────────────────────────────────────────
8. INDEPENDENT PLAN V3→V4 EQUIVALENCE
──────────────────────────────────────────────────────────────────────────────

Do not use the producer semantic-equivalence checker as the audit oracle.

Parse complete Plan V3 and Plan V4 independently.

Construct an explicit normalization that may remove only:

- schema/version captions;
- V2→V3 contract-reference update;
- source-closure references;
- explicit nonauthority references;
- lineage/status metadata;
- record identities generated by V3.

Normalization must not remove:

- command definitions;
- command order;
- argv;
- cwd semantics;
- environment parameter names or values;
- pinned tools;
- expected exits;
- pass/fail/skip identity policies;
- governing reasons;
- B source/tree/inventory/synthetic-commit identities;
- shared `r` custody;
- authority boundaries.

Require exactly eight commands, in the same order.

Require normalized bytes or canonical normalized maps to be identical.

If any executable or acceptance-bearing difference exists:

- return BLOCK;
- do not run runtime validation.

Retain a complete field-level difference record even when the result is equal.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT SOURCE-CLOSURE AND PATH-BUDGET DERIVATION
──────────────────────────────────────────────────────────────────────────────

Read the five exact source files independently.

Do not accept the contract’s numeric values as the proof.

Trace the relevant call and formatting chain through:

- B control-root logic;
- B runtime-helper socket construction;
- Go temporary-name construction;
- Go decimal formatting.

Derive independently:

- short-root byte count 57;
- shared root byte count 59;
- generated prefix byte count 2;
- maximum decimal digits for the actual unsigned 32-bit value: 10;
- maximum generated component: 12;
- separator bytes: 2;
- `identity.sock`: 13;
- worst-case path: 86;
- limit: 100;
- acceptance: 86 <= 100.

Verify `itoa.go` is an actual dependency of the derivation, not merely an
unrelated pinned file.

If any additional exact source file is acceptance-bearing but absent from the
V3 source-closure set, return BLOCK.

──────────────────────────────────────────────────────────────────────────────
10. INDEPENDENT V2 TECHNICAL-EVIDENCE ADOPTION AUDIT
──────────────────────────────────────────────────────────────────────────────

For each adopted observation:

1. Open the exact referenced V2 audit record.
2. Verify path, size, SHA-256, schema, and relevant fields.
3. Verify the observation is supported by that record.
4. Verify the adoption record does not strengthen it.
5. Verify no dynamic output was copied into V3 as competing evidence.
6. Verify the V2 audit verdict remains BLOCK everywhere it is stated.
7. Verify V3 does not claim a new runtime execution.

Required observations:

- allocator causals;
- independent 86-byte derivation;
- four causals;
- exact B materialization;
- eight-command validation;
- cross-command isolation;
- cleanup;
- closing equality;
- V2 capsule closure.

If the adoption record relies on a summary that omits acceptance-bearing raw
references, inspect those raw records and record the gap. Return BLOCK when the
claim cannot be independently substantiated from retained V2 evidence.

──────────────────────────────────────────────────────────────────────────────
11. FAILED-ATTEMPT AND SOLE-WRITER ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

The V3 capsule retains an earlier failed build beneath:

validation/failed-attempts/build-attempt-1/

It contains copies of contract and plan records.

Require:

- the failed attempt is explicitly indexed and superseded;
- it is outside the normative contract namespace;
- no consumer references it;
- it claims no authority;
- it cannot be mistaken for the current Plan V4 or V3 contract;
- any differing bytes are explained by the stopped construction attempt;
- the final contract remains the only normative writer.

If the failed-attempt copies create unresolved competing authority, return
BLOCK.

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import either producer validator.

Do not use the producer mutation fixtures as the audit input generator.

Create independent in-memory copies of the accepted baseline records and
independently construct at least these 41 mutations:

ALLOCATOR

1. fresh CSPRNG disabled
2. suffix source changed
3. descriptor-relative exclusive creation weakened
4. component no-follow removed
5. retry widened beyond EEXIST
6. collision material reused
7. attempt limit changed
8. non-EEXIST fallback admitted
9. scan/latest authority admitted
10. adoption admitted
11. rename into eligibility admitted
12. PID authority admitted
13. counter authority admitted
14. timestamp authority admitted
15. Git-hash authority admitted

NONAUTHORITY

16. shared/adversarial host supported
17. hostile/remotely administered host supported
18. symlink alias supported
19. bind-mount alias supported
20. mount alias supported
21. pathname alias supported

SOURCE CLOSURE AND PATH BUDGET

22. `itoa.go` omitted
23. `itoa.go` hash changed
24. `tempfile.go` hash changed
25. decimal maximum changed
26. component maximum changed
27. worst-case path changed
28. socket limit changed

PLAN PRESERVATION

29. command removed
30. command reordered
31. argv changed
32. expected identity removed
33. expected failure reclassified
34. expected skip reclassified
35. B source/tree identity changed
36. shared `r` custody changed

LINEAGE AND AUTHORITY

37. V2 BLOCK promoted to ACCEPT
38. Plan V3 described as previously effective
39. Plan V4 described as current without audit
40. V3 source authority granted
41. publication, commit, readiness, or A6 authority granted

Also independently test:

42. duplicate JSON key
43. unknown contract key
44. missing mandatory contract key
45. wrong field type
46. second normative V3 contract introduced outside `contract/`
47. failed-attempt contract copy referenced as authority
48. adopted V2 record path or digest changed
49. V2 technical observation strengthened beyond its source record
50. normalization removes an acceptance-bearing Plan field

Require each mutation to reject for a specific, mechanism-appropriate reason.

Retain audit-owned validator source, mutation definitions, and result matrix.

──────────────────────────────────────────────────────────────────────────────
13. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- the eight-command validation plan;
- Go repository tests;
- product code;
- the V2 allocator;
- V2 causal harnesses;
- live services.

The absence of runtime replay is intentional because V3 is a record-only
successor.

If §8 finds any executable-semantic difference, return BLOCK rather than
running the commands.

Allowed executable work is limited to audit-owned parsers, hashers, inventory
builders, semantic-comparison tools, and mutation validators.

──────────────────────────────────────────────────────────────────────────────
14. CAPSULE CLOSURE AND SECURITY
──────────────────────────────────────────────────────────────────────────────

Independently enumerate V3_ROOT.

Require:

- 12 directories including root;
- 88 physical retained files including manifests;
- 86 nonmanifest files;
- 98 represented entries;
- exactly two self-excluded manifests;
- no missing, extra, or duplicate entry;
- no empty or unexplained directory;
- all directories mode 0700;
- all files regular, single-link, mode 0600;
- no symlink or special object.

Generate two manifest projections with independently implemented traversal
logic. Require both to equal the supplied manifest bytes and hash to:

94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359

Verify the fixed report and inventory identities in §2.

Perform bounded sensitive-material scanning without printing matching payload
content. Distinguish fake fixtures, redaction patterns, and hashes from
plausible live secrets.

──────────────────────────────────────────────────────────────────────────────
15. AUTHORITY AND NONAUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Require the combined target to preserve this split:

Strategic B snapshot owns:

- B source bytes;
- logical modes;
- byte origins;
- B inventory;
- B source T / Git tree;
- synthetic evidence commit;
- H→B classification.

V2 evidence owns only its retained dynamic observations.

V3 owns only:

- complete validation-custody contract;
- record-complete Plan V4;
- exact source closure;
- explicit nonauthority;
- semantic equivalence with V2 behavior;
- bounded adoption references.

Neither V2 nor V3 owns:

- publication or commit;
- current repository truth for B;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation;
- hostile/shared-host support;
- symlink or mount-alias support.

Return BLOCK on any authority drift.

──────────────────────────────────────────────────────────────────────────────
16. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After all work:

1. Remove only audit-owned private mutation fixtures and temporary state.
2. Reap all audit-owned child processes.
3. Verify no process or descriptor survivor.
4. Make two fresh observations that the audit private subtree is absent.
5. Recompute candidate opening/closing equality.
6. Recompute STRATEGIC_B_ROOT equality.
7. Recompute BLOCKED_V1_REPAIR_ROOT equality.
8. Recompute VALIDATION_CUSTODY_V2_ROOT equality.
9. Recompute V2_INDEPENDENT_AUDIT_ROOT equality.
10. Recompute V3_ROOT equality.
11. Reverify the five exact source-closure files.
12. Retain complete audit process and artifact inventories.
13. Require retained audit directories mode 0700 and files regular,
    single-link, mode 0600.
14. Require no unexplained empty directory.

Return AUDIT_PROVENANCE_MISMATCH on any supplied-root drift or unprovable
opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
17. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- opening and closing provenance qualify;
- the V3 contract is complete and unambiguous;
- Plan V4 is independently semantically identical to Plan V3;
- the exact path-source closure is complete;
- all explicit nonauthority is present;
- V2 technical evidence adoption is exact and bounded;
- the independent mutation matrix passes;
- failed attempts create no competing authority;
- capsule closure and security pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable contract, plan, source-closure, lineage,
evidence-adoption, contradiction-resistance, authority, artifact, or
provenance-record defect.

Return REJECT only for fundamental unsoundness not repairable within the
record-completion scope.

Return AUDIT_PROVENANCE_MISMATCH for input drift, supplied-root mutation,
missing exact input, process-record incompleteness, or failed opening/closing
equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
18. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete audit report inline, including:

1. Primary verdict
2. Audit-root and bootstrap identity
3. Candidate and supplied-root opening identities
4. Four auditor identities, schedule, operands, and reports
5. V3 capsule closure
6. Independently parsed V3 complete field map
7. Plan V3→V4 field-level equivalence
8. Exact path-source dependency derivation
9. Explicit nonauthority adjudication
10. V2 evidence-adoption adjudication
11. Failed-attempt and sole-writer adjudication
12. Independent 50-case-or-greater mutation matrix
13. Confirmation no runtime replay occurred
14. Capsule authority and nonauthority
15. Artifact and sensitive-material findings
16. Severity-ranked residual findings
17. Minority findings and parent resolution
18. Cleanup and two absence observations
19. Candidate and supplied-root closing equality
20. Audit-created paths and complete inventory
21. Remaining uncertainty and explicit nonclaims
22. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V3_CAPSULE_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
VALIDATION_COMMAND_SEMANTICS_NOT_CHANGED
PATH_SOURCE_CLOSURE_INCLUDES_PINNED_ITOA_GO
HOSTILE_SHARED_HOST_SUPPORT_EXPLICITLY_FALSE
SYMLINK_MOUNT_ALIAS_SUPPORT_EXPLICITLY_FALSE
V2_BLOCK_VERDICT_NOT_PROMOTED
RUNTIME_VALIDATION_NOT_RERUN
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, proceed to the real H→B commit gate. That gate should:

1. stage the exact 36 accepted H→B paths;
2. materialize and validate the exact staged tree using the accepted
   validation-custody contract;
3. create exactly one commit with subject:

   `implement Remote Alpha external TLS T2A-P source`

4. perform no push and create no upstream.

Only after B is committed should the already-audited B→F governance commit be
gated.

**Source:** Codex’s V3 record-completion report supplied above.

**Confidence:** 0.995 that V3 is ready for this narrow independent audit; 0.99 that runtime replay is unnecessary unless Plan V4 differs semantically; 0.96 that the failed-attempt duplicate records are the most important remaining authority/provenance seam.
