Here is Codex's response:

## Operative report

1. **Exact wrapper verdict:** `AUDIT_PROVENANCE_MISMATCH`

   Final adjudication: [final-wrapper-adjudication.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m/report/final-wrapper-adjudication.json), mode `0600`, size `2,429`, SHA-256 `71e242055ee69080143032b255cd36953d77db58146853c6cf8614cdd231844d`.

2. **Exact raw harness disposition:** `SUBJECT_AUDIT_BLOCK`

3. **Successor PYZ identity:** device/inode `16777234/182785051`; mode `0400`; links `1`; size `4,216,423`; SHA-256 `d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19`.

4. **Authority-v2 identity:** device/inode `16777234/182785057`; mode `0400`; links `1`; size `47,750`; SHA-256 `64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec`.

5. **Profile-v4 identity:** device/inode `16777234/182800237`; mode `0400`; links `1`; size `12,763`; SHA-256 `d31ad9f854399f62dcc484f235f707ec3daaf8ad23e123a5e4600ef74cbcafab`.

6. **Certificate-v5 identity:** device/inode `16777234/182800243`; mode `0400`; links `1`; size `34,814`; SHA-256 `f753ed8adfbee2ff122fe63f54fbcaca833ca1694e6f284baf0edba018f9211a`.

7. **Historical launch lineage:** profile v3 and certificate v4 were authenticated through certificate-v5’s internal lineage only. Both are non-current; certificate-v4 active authorization count is zero. No historical artifact supplied execution controls.

8. **Replacement subject:** device/inode `16777234/182649818`; mode `0700`; UID/GID `501/20`; 73 entries; canonical inventory `eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3`.

9. **Construction wrapper:** device/inode `16777234/182648782`; mode `0700`; UID/GID `501/0`; 49 entries; inventory `9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e`.

10. **Accepted implementation roots:** audit root inode `182593190`, 78 entries, inventory `3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d`; wrapper root inode `182593189`, 12 entries, inventory `6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108`. Both mode `0700`.

11. **Content inputs:** bundle inode `181651092`, mode `0400`, size `13,598,758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`; authority inode `181651098`, mode `0400`, size `19,737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`. Closure: 479 members, eight roles, zero `.DS_Store`.

12. **Stable prelaunch authentication:** all six governed files passed two-cut no-follow reads; all four roots passed two identical canonical projections. Content authority was authenticated before ZIP interpretation.

13. **Current authority closure:** profile v4 and certificate v5 were current and coherent before launch. Exactly one authorization was active and unconsumed; all predecessors had zero active authorization. The successful audit-parent creation consumed the sole authorization.

14. **PYZ/member closure:** 75 exact members, 74 registered non-self members, `ZIP_STORED`, timestamp `2024-01-01 00:00:00`, member mode `0600`, no duplicate/unsafe/directory/symlink/cache members, 11 frozen sources, ten dependency roles.

15. **Wrapper evidence root:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m`; device/inode `16777234/182808075`; mode `0700`; UID/GID `501/0`. Preserved.

16. **Workspace:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-li_3jihu`; device/inode `16777234/182808076`; mode `0700`; UID/GID `501/0`. It was empty at allocation and is preserved with its capsule.

17. **Capsule-child absence proof:** `/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-li_3jihu/audit-capsule` was absent at allocation, after preflight, and immediately before audit-parent creation. The wrapper did not precreate it.

18. **Platform preflight:** executed once as PID `73309`; exit `23`, signal `null`; exact 27-byte stdout/stderr hashes `6cb09bf…8c2` and `bd0334ca…ec5`; workspace remained empty; capsule remained absent; process reaped and descriptors closed.

19. **Exact audit invocation:** `/usr/local/bin/python3.13 -I -S -B`, PYZ v2, `--mode audit`, authority v2, exact subject/construction/content/implementation inputs, and `--output-root` equal to the absent capsule child. CWD was the workspace. Environment was exactly `PATH=/usr/bin:/bin`, `LANG=C`, `LC_ALL=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`.

20. **Top-level custody:** custody ID `GEN2-REPLACEMENT-SUBJECT-REAL-AUDIT-1`; process PID `73310`; created once; duration `58,007,750 ns`; synchronous, foreground, no shell/TTY/detachment; reaped; descriptors closed. Candidate report retained at [final-wrapper-report.json](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m/report/final-wrapper-report.json).

21. **Raw streams:** [stdout](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m/process/audit-parent.stdout.bin) is 253 bytes, SHA-256 `359c4cd596d230c186494deec103c481beb28db624323328da11a9e18c39caaf`; [stderr](/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m/process/audit-parent.stderr.bin) is empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

22. **Exit/signal:** audit exit `0`; signal `null`; no process error.

23. **Terminal frame:** strict canonical UTF-8 JSON plus one LF; exact schema `clean-audit-harness.synthetic-terminal-frame.v1`; `closure_pass=true`; scenario `block`; capsule root exactly matched the profile-derived child.

24. **Capsule root:** device/inode `16777234/182808084`; mode `0700`; UID/GID `501/0`; direct child of the workspace; created by the frozen runtime; no alternate-root scan or fallback.

25. **Source/freeze/no-VCS posture:** 11-source freeze and layout authenticated; embedded source/member bindings closed; no Git/VCS or network activity occurred.

26. **Ten-role resolution:** all ten roles resolved `PRESENT_UNIQUE`; the access set exactly equaled the dependency registry: artifact plan, two manifests, schema-role registry, 946 matrix, 137 matrix, field map, documentary-validator registry, confirmation map, and occupancy record.

27. **Subject terminal closure:** replacement-subject identity, temporal record, byte-identical manifests, canonical inventory and closing equality all remained coherent.

28. **Normative contract:** schema `execution-substrate.target-audit-harness.package-construction-parent-contract.v1`; size `32,038`; SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`; unchanged.

29. **Fifteen schema roles:** child-process-record, cleanup-result, current-export-registry, executable-origin-registry, failure-outcome, metadata-coherence, normative-construction-parent, package-freeze, package-root-rebinding, phase-record, plan-identity-consumer-registry, pointer-resolution-result, qualification-result, temporal-inventory, terminal-manifest-metadata.

30. **Fourteen generated families:** the same roles except normative-construction-parent, which is intentionally not a generated family.

31. **Role/family mapping:** 15 unique schema roles mapped completely to 14 unique families; normative-construction-parent was the single intentional unmapped role.

32. **Draft 2020-12:** all 15 schemas passed metaschema validation; error count zero.

33. **Contract witnesses:** 14/14 schema-valid and contract-valid; aggregate passed.

34. **Schema witnesses:** 14/14 contract-valid and schema-valid; aggregate passed.

35. **Witness aggregate:** exact row evidence was present for all 28 witness rows.

36. **Complete 946 result:** the authoritative subject matrix contains 946 cases and reports pass, with zero false acceptance, false rejection, reason mismatch, skip, exception or nonpassing rows.

37. **Exact failed 946 rows:** none. The harness nevertheless projected 907 passing rows as blockers.

38. **Complete 137 result:** all 137 cases passed; zero false outcomes, reason mismatches, skips or nonpassing rows.

39. **Exact failed 137 rows:** none.

40. **Dual-oracle crosswalk:** both frozen oracles agreed with each other, but shared the same projection defect. For example, vocabulary row 1 expects reason class `required`; the passing subject row carries descriptive reason text. Both oracles compare that prose directly with `required`, return false, and promote the still-`pass:true` row as a blocker. This is an invalid outcome projection.

41. **766/333 field map:** 766 normative-contract leaves and 333 generated-record enforcement fields closed; unresolved count zero.

42. **Documentary validators:** exact ten-role registry; all results present, current and passing.

43. **Confirmation derivation:** 66 required confirmations and 66 evidence rows; confirmation validator passed with zero errors; evidence DAG passed and was acyclic with zero validator-confirmation backedges.

44. **Derivative-confirmation ledger:** 13 terminal-dependent confirmations; derivative confirmation evidence was not treated as a valid direct subject blocker.

45. **Occupancy/lineage/producer status:** 25 current roles—15 schema and ten documentary roles—closed without duplicates; implementation-present, implementation-authority and independent-acceptance were all false; no failed or historical output occupied a current role.

46. **Findings:** the capsule contains 907 claimed 946-domain blockers, ordinals 1–907. Every cited evidence row says `pass:true`; there are zero genuine nonpassing 946 or 137 rows. Therefore `DIRECT_BLOCKER_STANDARD_SATISFIED=false` and `OUTCOME_PROJECTION_VALID=false`.

47. **Repair-owner registry:** all 907 projected blockers name `replacement-subject-package`, but each lacks the mandatory governing pointer, exact repair surface, subject-byte-change decision, reconstruction decision and unchanged-subject re-audit decision. Their subject ownership is therefore non-operative; the demonstrated defect is in the frozen harness’s 946 reason-class projection.

48. **Dependency graph:** the ten-role access graph and documentary evidence DAG closed. No valid subject-finding dependency graph exists for the 907 invalid projections.

49. **A00–A15:** all 16 phase records exist, are terminal, and report `passed`.

50. **Child custody:** wrapper child ordinals `0` and `1` were complete and contiguous; preflight and audit children were both reaped with all pipe descriptors closed. No continuation or replacement parent ran.

51. **Audit cleanup:** capsule cleanup record passed with set equality. The workspace and capsule were deliberately not removed or cleaned.

52. **Capsule supplied-root equality:** capsule record passed. The independent wrapper closing equality supplied the substantive ten-role opening/closing check.

53. **Wrapper fixed-input equality:** exact six-file/four-root role set; no missing or extra roles; every opening and closing identity/inventory matched.

54. **Audit temporal identity:** mode `0600`; size `2,448`; SHA-256 `05c4ed679e808f3bffcf7f0568cd92b155b95c6dea4ab697ac0e7e2aca356036`; root row count one.

55. **Audit manifests:** A and B are each mode `0600`, size `2,560`, SHA-256 `8d714df8c96cccafb91edae62ce048d064be657e70f66877346de40ec539cffc`.

56. **A/B equality:** byte-identical.

57. **Final reprojection:** passed with 33 entries.

58. **Physical topology/modes:** nine directories, 24 regular files, no empty descendants, symlinks, special objects, multiply-linked files, caches or bytecode; directory/file modes were `0700/0600`.

59. **A15/closure agreement:** A15 `passed`; final closure `true`; equality confirmed.

60. **Seal/no-postseal:** one seal transition; no write or operation inside the capsule after seal. Terminal record SHA-256 `f9297204749332b2ac06a94dc3f0e3036ff0568a8f74a6dd5e5cf55a9e0db7a9`.

61. **Subject unchanged:** no mutation, cleanup, construction or source execution was performed.

62. **Authority posture:** no promotion or rebinding occurred. The single v5 authorization is irrevocably consumed by successful PID `73310` creation.

63. **Excluded activity:** no qualification, rehearsal, synthetic mode, direct external auditor, replacement parent, continuation, product/live-service invocation, target audit, runtime-validation rerun, network, Git, publication, deployment or A6 activity occurred.

64. **Remaining uncertainty/nonclaims:** the capsule and process custody are valid, but the embedded BLOCK is non-promotable because its 907 blocker projections contradict their own passing evidence and fail the mandatory blocker schema. This report therefore claims neither subject acceptance nor a valid subject block. No retry remains authorized; the preserved frozen harness/outcome-projection defect requires separate authority before any future audit.

65. **Explicit wrapper confirmations:**

```text
SUCCESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED=TRUE
SUCCESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED=TRUE
CURRENT_PROFILE_V4_IDENTITY_MATCHED=TRUE
CURRENT_CERTIFICATE_V5_IDENTITY_MATCHED=TRUE
PROFILE_V3_NOT_CURRENT=TRUE
CERTIFICATE_V4_NOT_CURRENT=TRUE
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION=TRUE
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED=TRUE
REPLACEMENT_SUBJECT_INVENTORY_BINDING_MATCHED=TRUE
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED=TRUE
CONSTRUCTION_WRAPPER_INVENTORY_BINDING_MATCHED=TRUE
ACCEPTED_IMPLEMENTATION_AUDIT_ROOT_AUTHENTICATED=TRUE
ACCEPTED_IMPLEMENTATION_AUDIT_INVENTORY_BINDING_MATCHED=TRUE
ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT_AUTHENTICATED=TRUE
ACCEPTED_IMPLEMENTATION_WRAPPER_INVENTORY_BINDING_MATCHED=TRUE
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED=TRUE
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED=TRUE
CURRENT_LAUNCH_AUTHORITY_COHERENT=TRUE
CURRENT_PYZ_MEMBER_SET_CLOSED=TRUE
WRAPPER_WORKSPACE_ALLOCATED=TRUE
WRAPPER_WORKSPACE_EMPTY_BEFORE_LAUNCH=TRUE
CAPSULE_CHILD_ABSENT_BEFORE_LAUNCH=TRUE
WRAPPER_DID_NOT_PRECREATE_CAPSULE_ROOT=TRUE
PLATFORM_CAPTURE_PREFLIGHT_PASSED=TRUE
PREFLIGHT_WORKSPACE_REMAINED_EMPTY=TRUE
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT=TRUE
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE=TRUE
CURRENT_REAL_AUDIT_AUTHORIZATION_CONSUMED=TRUE
QUALIFICATION_MODE_NOT_EXECUTED=TRUE
REHEARSAL_MODE_NOT_EXECUTED=TRUE
SYNTHETIC_MODE_NOT_EXECUTED=TRUE
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED=TRUE
ADMINISTRATIVE_CONTINUATION_NOT_USED=TRUE
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS=TRUE
RAW_STDOUT_RETAINED=TRUE
RAW_STDERR_RETAINED=TRUE
PLATFORM_EXIT_AND_SIGNAL_RETAINED=TRUE
AUDIT_ROOT_SCAN_NOT_PERFORMED=TRUE
TERMINAL_FRAME_STRICTLY_PARSED=TRUE
TERMINAL_FRAME_ROOT_EQUALS_PROFILE_DERIVED_CAPSULE_CHILD=TRUE
SUCCESSOR_CLEAN_SOURCE_FREEZE_AUTHENTICATED=TRUE
NO_GIT_OR_VCS_INVOCATION=TRUE
SUBJECT_INPUT_ACCESS_SET_10_COMPLETE=TRUE
SUBJECT_INPUT_ACCESS_EQUAL_DEPENDENCY_REGISTRY=TRUE
NO_ACCEPTANCE_BEARING_DIRECT_SUBJECT_PATH_LITERAL=TRUE
NO_UNHANDLED_ENOENT=TRUE
SUBJECT_TERMINAL_REPROJECTION_PASSED=TRUE
NORMATIVE_CONTRACT_BYTES_UNCHANGED=TRUE
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES=TRUE
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES=TRUE
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY=TRUE
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE=TRUE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID=TRUE
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID=TRUE
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID=TRUE
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE=TRUE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED=TRUE
EVERY_NONPASSING_946_ROW_RETAINED=TRUE
CONTRADICTION_REGRESSION_137_COMPLETED=TRUE
EVERY_NONPASSING_137_ROW_RETAINED=TRUE
DUAL_ORACLE_RESULTS_AGREE=TRUE
NO_ORACLE_EXCEPTION=TRUE
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED=TRUE
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED=TRUE
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET=TRUE
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT=TRUE
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED=TRUE
CONFIRMATION_EVIDENCE_MAP_COMPLETED=TRUE
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS=TRUE
NO_HARDCODED_CONFIRMATION_SUCCESS=TRUE
CURRENT_ROLE_OCCUPANCY_COMPLETE=TRUE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED=TRUE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT=TRUE
NO_FAILED_ARTIFACT_CURRENT=TRUE
IMPLEMENTATION_PRESENT_FALSE=TRUE
IMPLEMENTATION_AUTHORITY_FALSE=TRUE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED=TRUE
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED=TRUE
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE=TRUE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER=TRUE
FINDING_OWNERSHIP_COMPLETE=TRUE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL=TRUE
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS=TRUE
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS=TRUE
ALL_CREATED_CHILDREN_REAPED=TRUE
ALL_CHILD_DESCRIPTORS_CLOSED=TRUE
AUDIT_CLEANUP_SET_EQUALITY_PASSED=TRUE
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED=TRUE
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED=TRUE
AUDIT_TEMPORAL_INVENTORY_CREATED=TRUE
AUDIT_TEMPORAL_INVENTORY_VERIFIED=TRUE
AUDIT_MANIFEST_A_CREATED=TRUE
AUDIT_MANIFEST_B_CREATED=TRUE
AUDIT_MANIFESTS_BYTE_IDENTICAL=TRUE
AUDIT_TERMINAL_REPROJECTION_PASSED=TRUE
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE=TRUE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE=TRUE
NO_SYMLINK_OR_SPECIAL_OBJECT=TRUE
NO_MULTIPLY_LINKED_FILE=TRUE
ALL_AUDIT_DIRECTORY_MODES_0700=TRUE
ALL_AUDIT_FILE_MODES_0600=TRUE
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED=TRUE
SINGLE_AUDIT_SEAL_TRANSITION=TRUE
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL=TRUE
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED=TRUE
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED=TRUE
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED=TRUE
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED=TRUE
NO_NETWORK_CONTACT=TRUE
NO_GIT_INVOCATION=TRUE
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION=TRUE
NO_TARGET_AUDIT_EXECUTED=TRUE
NO_RUNTIME_VALIDATION_RERUN=TRUE
NO_A6_ACTIVITY=TRUE
NO_SUBAGENTS_CREATED=TRUE
```
