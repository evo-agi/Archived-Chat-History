## Engineering assessment

This is still an **audit-harness lineage failure**, not an implementation-package finding. The report explicitly preserves the implementation package and classifies the original seven audit findings as harness defects or contradictions; it does not establish a product or implementation defect. :chatgpt-content-reference{index="0"}

The important distinction is that the second repair attempt did not fail broadly:

- All six qualification matrices passed: 209 cases with zero false acceptances, false rejections, reason mismatches, skips, or unexpected exceptions.
- Bounded replay and all six synthetic success, BLOCK, and failure-capsule lanes passed.
- Process and cleanup custody closed.
- The repair failure capsule itself terminally closed with matching manifests, clean topology, supplied-root equality, and no post-seal filesystem activity. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The blocker is instead one exact, deterministic integration defect:

- `repair_core.close_capsule()` returns the root identity at `/inventory/root_identity`.
- `repair_core.seal_audit()` forwards that shape.
- `Audit.build_inline_report()` incorrectly requests top-level `/audit_root_identity`.
- A real full audit would therefore raise `KeyError` before emitting its verdict and terminal marker. :chatgpt-content-reference{index="3"}

That interface was omitted from both the static gates and the “independent” validator. Their green results were therefore incomplete, not evidence that the interface is ambiguous. :chatgpt-content-reference{index="4"}

### Progression decision

Authorize **one final bounded incremental repair of this audit-harness source lineage**.

The repair should:

1. Freeze one authoritative terminal-adapter interface.
2. Preserve `/inventory/root_identity` as the sole root-identity representation and adapt the consumer; do not introduce a duplicative top-level alias.
3. Inventory and directly test every cross-module provider/consumer interface in the six-file harness.
4. Exercise the real `close_capsule → seal_audit → build_inline_report → terminal marker` path for success, substantive BLOCK, and audit-failure capsules.
5. Rerun every prior matrix, synthetic causal, bounded replay, static gate, and independent validator from a fresh root.
6. Freeze and terminally close the repaired harness, but do **not** run the full independent audit in the same tranche.

This is the terminal incremental repair. If it fails within its new two-attempt budget, or uncovers another acceptance-bearing cross-module mismatch outside the frozen adapter surface, retire this harness source lineage and require a clean source-external audit-harness implementation. Do not issue another localized repair prompt.

```text
FINAL BOUNDED REPAIR OF THE GENERATION-2 IMPLEMENTATION
INDEPENDENT-AUDIT HARNESS — TERMINAL ADAPTER AND CROSS-MODULE INTERFACES

Objective

Create a fresh successor to the blocked independent-audit-harness repair by
correcting the exact terminal provider/consumer mismatch and closing the
cross-module interface coverage that allowed it to escape qualification.

This is the final permitted bounded incremental repair of this audit-harness
source lineage.

Do not run the full independent implementation-package audit in this task.

Do not execute the production reconstruction parent.

Do not construct subject rehearsals.

Do not modify, repair, reinterpret, or adjudicate the sealed implementation
package.

Do not change package acceptance rules, verdict thresholds, governing
Generation-2 semantics, the normative construction-parent contract, current
schemas, validation case semantics, or implementation source.

If this final bounded repair cannot qualify within two source attempts, or if
it uncovers another acceptance-bearing source defect outside the exact frozen
cross-module interface surface, stop and select:

RETIRE_INCREMENTAL_AUDIT_HARNESS_LINEAGE_AND_CLEANLY_REIMPLEMENT

Do not issue or recommend another localized repair.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned repair and qualification process in one fresh
private root.

Return the complete operative report inline. Private artifact paths may
supplement but must not replace material identities, causal findings, source
deltas, interface contracts, validation results, and the disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIR_BLOCKED

HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. BLOCKED REPAIR PACKAGE — FIXED PREDECESSOR
──────────────────────────────────────────────────────────────────────────────

BLOCKED_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6

Expected root identity:

- device:
  16777234
- inode:
  181082379
- mode:
  0700
- verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_REPAIR_BLOCKED

Expected terminal identities:

Temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  181094949
- mode:
  0600
- link count:
  1
- size:
  32055
- SHA-256:
  c6a3532ff28528f95b61d66ab4c7667f605996db5a65b3ff2abefad13eaad4ab

Manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  181094947
- mode:
  0600
- link count:
  1
- size:
  33301
- SHA-256:
  0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf

Manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  181094948
- mode:
  0600
- link count:
  1
- size:
  33301
- SHA-256:
  0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf

Expected closing-equality identity:

closing/supplied-root-closing-equality-final-v1.json

- size:
  7563
- SHA-256:
  392290e4295b1754883c1d276bddcbd6174095983bf7e2743ef8454d9e436095

Expected blocked status identity:

- SHA-256:
  fad5526228906c0845ddc409c13838e666df92aba6dc0556

Expected failure-closeout identity:

- SHA-256:
  e2c6fffee7a36a4c9389a318abf6161fe255b47456465bb0273baba7bff4c8c1

Authenticate:

- root identity and complete closure;
- temporal inventory;
- manifest pair and reprojection;
- final physical topology;
- current source registry;
- Attempt-1 and Attempt-2 source ledgers;
- protected-function equivalence;
- all six matrix results;
- bounded live replay;
- six synthetic capsule lanes;
- independent-validator result and its coverage adjudication;
- exact terminal-adapter blocker;
- blocked readiness record;
- failure closeout;
- explicit confirmation registry.

Classify this root as:

historical_blocked_terminal_adapter_repair_predecessor

It is immutable, noncurrent, nonauthoritative, nonresumable, and not cleanable
in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. EXACT CURRENT ATTEMPT-2 SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Resolve all current Attempt-2 source paths only through the authenticated
current source registry.

Expected registry SHA-256:

910eb1a344f73bc1d9679b32c9af1ca038a5f6219454fdb0322fbb0f9a1fc6bb

The registry covers:

- six source files;
- fourteen source roles.

Expected exact identities include:

Audit parent:

- size:
  239303
- SHA-256:
  1caa2554c923ce2f1e9bc684301860654bfd18b1a18e614613e7115eafce7d6c

Repair core:

- size:
  46559
- SHA-256:
  adaecf6cf565748a95e2afe2059ea811638fbbae60188d8133adb3b69ccb65d5

Qualification driver:

- expected size:
  59954
- resolve exact SHA-256 through the current registry.

Independent validator:

- expected size:
  18809
- resolve exact SHA-256 through the current registry.

Recorder and platform-capture roles:

- resolve exact current paths and identities through the same registry and
  authenticated predecessor bindings.

Do not select source by basename, uniqueness, recency, or fallback.

Use only these exact Attempt-2 current source bytes as the bounded repair base.

No Attempt-1 source may become current.

Retain:

opening/attempt-2-source-authority-v1.json

Require:

- every current role resolved;
- every source identity exact;
- no historical source substituted;
- no stale source binding;
- Attempt 2 classified as the sole repair base;
- Attempt 2 remains nonqualified until this successor closes.

──────────────────────────────────────────────────────────────────────────────
3. EXACT BLOCKER REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before modifying source, reproduce:

FUTURE_AUDIT_PARENT_TERMINAL_ADAPTER_INTERFACE_MISMATCH

Authenticate and retain the exact source ranges:

Audit parent:

- `build_inline_report`:
  prior source lines 4041–4199
- `seal_terminal_capsule`:
  prior source lines 4201–4349

Repair core:

- `close_capsule`:
  prior source lines 891–1025
- `seal_audit`:
  prior source lines 1028–1048

Reproduce this exact chain:

1. `repair_core.close_capsule()` returns a terminal result with root identity
   at:
   `/inventory/root_identity`
2. It does not return a top-level:
   `/audit_root_identity`
3. `repair_core.seal_audit()` forwards the provider result unchanged.
4. `Audit.build_inline_report()` requests:
   `terminal["audit_root_identity"]`
5. The real success path would raise:
   `KeyError("audit_root_identity")`
6. The guarded terminal marker and verdict would not be emitted.

Retain:

analysis/terminal-adapter-mismatch-reproduction-v1.json

Bind:

- exact provider source and identity;
- exact consumer source and identity;
- exact returned shape;
- exact consumed pointer;
- exact available pointer;
- exact exception;
- exact call path;
- first failed operation;
- authority effect;
- terminal effect;
- why prior matrices and validator missed it.

Required classification:

AUDIT_HARNESS_CROSS_MODULE_INTERFACE_DEFECT

unless authenticated governing evidence proves another owner.

──────────────────────────────────────────────────────────────────────────────
4. FINAL INCREMENTAL-REPAIR TERMINALITY
──────────────────────────────────────────────────────────────────────────────

Retain before source modification:

opening/final-incremental-repair-authority-v1.json

Bind:

- this is the final incremental repair of this harness source lineage;
- at most two complete source attempts are authorized;
- no third attempt;
- no post-attempt patch;
- no hidden waiver;
- only the terminal-adapter and cross-module-interface surface may change;
- implementation-package semantics may not change;
- package verdict rules may not change;
- full audit may not run;
- production reconstruction source may not run.

If either repaired attempt fails qualification, or if qualification discovers
another acceptance-bearing defect outside the frozen interface surface:

- stop;
- preserve all evidence;
- select:
  RETIRE_INCREMENTAL_AUDIT_HARNESS_LINEAGE_AND_CLEANLY_REIMPLEMENT
- do not issue another localized-repair recommendation.

──────────────────────────────────────────────────────────────────────────────
5. FRESH SUCCESSOR REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- `tempfile.mkdtemp`;
- umask `077`;
- prefix:

ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- predecessor repair-root identity;
- Attempt-2 source authority;
- exact terminal-adapter defect;
- final incremental-repair terminality;
- bounded repair authority;
- implementation-package mutation authorized:
  false;
- full independent audit authorized:
  false;
- production-source execution authorized:
  false;
- rehearsal creation authorized:
  false;
- current-subject construction authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- A6 authorized:
  false;
- same-root retry authorized:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. TERMINAL-ADAPTER AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before source modification, retain:

analysis/terminal-adapter-authority-adjudication-v1.json

Independently crosswalk:

- all terminal provider outputs;
- all terminal-result consumers;
- all schemas or documentary contracts governing those results;
- all successful synthetic capsule records;
- all failure-capsule records;
- all report-building consumers;
- all terminal-marker consumers.

Determine one authoritative representation of audit-root identity.

Expected adjudication, absent contrary governing evidence:

- authoritative value:
  terminal inventory root identity;
- canonical pointer:
  `/inventory/root_identity`;
- top-level `/audit_root_identity`:
  not authoritative and not required;
- consumer must use the canonical nested pointer;
- no duplicate top-level alias may be introduced.

Reason:

- one authoritative writer per mutable fact;
- no duplicated root identity;
- no contradictory alias;
- provider already returns the terminal inventory containing the canonical
  identity.

If a governing current contract explicitly requires top-level
`/audit_root_identity`, stop with the repair-blocked verdict and report the
contract conflict.

Do not silently support both representations.

Do not add a fallback pointer.

──────────────────────────────────────────────────────────────────────────────
7. CLOSED TERMINAL-ADAPTER INTERFACE
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/terminal-adapter-interface-v1.json

Freeze:

- provider:
  `repair_core.close_capsule`
- forwarding function:
  `repair_core.seal_audit`
- consumer:
  `Audit.build_inline_report`
- canonical terminal-result schema;
- exact required top-level fields;
- exact nested inventory fields;
- canonical root-identity pointer:
  `/inventory/root_identity`
- exact verdict field and type;
- exact terminal posture fields;
- exact manifest and temporal identity fields used by the consumer;
- exact nullability;
- exact success, substantive BLOCK, and audit-failure applicability;
- unknown-field policy;
- missing-field policy;
- wrong-type policy;
- contradictory-alias policy;
- post-seal purity requirement.

Require:

- consumer uses a typed total accessor;
- no direct unchecked dictionary access;
- no alias;
- no fallback;
- no generic recursive search;
- no top-level duplicate root identity;
- provider and consumer bind the same closed shape;
- interface failure yields a structured adapter error;
- interface failure cannot produce a terminal success marker;
- after terminal seal, adapter and report generation are in-memory only;
- no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/audit-harness-cross-module-interface-registry-v1.json

Enumerate every acceptance-bearing provider/consumer interface among all six
current Attempt-2 source files.

For every interface bind:

- interface ID;
- provider file and function;
- consumer file and function;
- call path;
- input shape;
- output shape;
- exact fields or pointers consumed;
- types;
- nullability;
- exception semantics;
- authority;
- applicable verdict classes;
- direct integration test;
- independent-validator coverage.

Require:

- every cross-module edge classified;
- no unregistered acceptance-bearing edge;
- no consumer field outside provider shape;
- no provider field silently ignored when acceptance-bearing;
- no recursive or fallback field discovery;
- no conflicting duplicate representation;
- at least one direct real-function integration test per interface;
- terminal-adapter interface explicitly included.

Unknown or unresolved interface is a qualification blocker.

This registry must not redefine package acceptance semantics.

──────────────────────────────────────────────────────────────────────────────
9. BOUNDED SOURCE-REPAIR SURFACE
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/terminal-adapter-repair-surface-v1.json

Default permitted production changes:

- `Audit.build_inline_report`;
- a new or existing typed terminal-result accessor used by that function;
- source-level interface declarations or constants required to bind the closed
  adapter shape.

Protected by default:

- `repair_core.close_capsule`;
- `repair_core.seal_audit`;
- terminal inventory generation;
- terminal manifest generation;
- package verdict constants;
- package acceptance rules;
- process recorder;
- package grammar and role logic;
- cleanup logic;
- security logic.

A provider change is permitted only if the authority adjudication proves that
the current provider violates a governing current contract.

If provider change is required:

- do not add a duplicated top-level alias;
- choose one canonical location;
- update every consumer and test;
- prove no other consumer is broken.

Permitted qualification changes:

- terminal-adapter integration fixtures;
- cross-module-interface fixtures;
- terminal-adapter matrix;
- independent interface validator;
- static checks covering provider/consumer compatibility.

No unrelated function may change.

Require every unrelated common function to remain AST-identical.

──────────────────────────────────────────────────────────────────────────────
10. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete source attempts are permitted.

A complete attempt begins when:

- repaired source registry closes;
- compilation starts.

For each attempt retain:

- predecessor source identities;
- repaired source identities;
- exact textual and AST delta;
- changed functions;
- protected functions;
- compilation;
- static checks;
- matrices reached;
- direct integration tests;
- first blocker;
- supersession disposition.

Any source modification after compilation begins creates a new attempt.

If Attempt 2 fails:

- stop;
- return the repair-blocked verdict;
- set:
  `retire_incremental_harness_lineage=true`
- set:
  `clean_source_external_audit_harness_implementation_required=true`
- do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
11. TERMINAL-ADAPTER INTEGRATION TESTS
──────────────────────────────────────────────────────────────────────────────

Exercise the real production functions, not a hand-built terminal dictionary.

Required success-path integration:

`repair_core.close_capsule`
→ `repair_core.seal_audit`
→ `Audit.build_inline_report`
→ guarded terminal marker and verdict preparation

Run for:

1. successful audit capsule;
2. substantive BLOCK capsule;
3. `AUDIT_PROVENANCE_MISMATCH` capsule;
4. source-preflight failure capsule when the terminal adapter is applicable;
5. terminal package failure capsule.

For every case require:

- actual provider return;
- actual forwarding behavior;
- actual consumer call;
- no `KeyError`;
- exact root identity;
- exact verdict;
- exact report material values;
- exact marker preparation;
- no filesystem operation after seal;
- no change in substantive verdict class.

Required negative integration cases:

- missing `/inventory`;
- `/inventory` wrong type;
- missing `/inventory/root_identity`;
- root identity wrong type;
- top-level alias only;
- nested plus equal top-level alias;
- nested plus conflicting top-level alias;
- stale root identity;
- malformed verdict;
- missing terminal posture;
- extra unknown acceptance-bearing field;
- provider returns `None`;
- forwarding function changes shape;
- report consumer asks for an unprovided field.

Every negative case must fail closed with a structured adapter reason and no
terminal success marker.

Retain:

validation/terminal-adapter-integration-matrix-v1.json

Require:

- unique case names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

──────────────────────────────────────────────────────────────────────────────
12. CROSS-MODULE INTERFACE MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/cross-module-interface-matrix-v1.json

For every registered cross-module interface test:

- exact baseline;
- one required field missing;
- one required field wrong type;
- unknown acceptance-bearing field;
- null where forbidden;
- exception propagation;
- consumer/provider identity mismatch.

At minimum include 40 uniquely named cases.

Require:

- exact interface-name closure;
- every registered interface covered;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

No interface may be declared covered solely by static inspection.

──────────────────────────────────────────────────────────────────────────────
13. STATIC AND BYTECODE INTERFACE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every repaired source under pinned Python `-I -S -B`.

Require exit 0 and empty stderr.

Run fresh source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception-table;
- CFG;
- return-shape analysis;
- consumer-field analysis;
- cross-module interface crosswalk;
- post-seal operation analysis.

Require:

- every `close_capsule` return path conforms to the adapter contract;
- `seal_audit` preserves the contract;
- every `build_inline_report` terminal access is contract-backed;
- no direct `terminal["audit_root_identity"]`;
- canonical `/inventory/root_identity` used exactly;
- no alias or fallback;
- no unchecked object access;
- all terminal adapter calls tested;
- no unregistered cross-module interface;
- no post-seal filesystem operation;
- package verdict constants unchanged;
- no package acceptance-rule change.

Static pass is false if any interface lacks direct integration coverage.

──────────────────────────────────────────────────────────────────────────────
14. PRIOR QUALIFICATION REGRESSION
──────────────────────────────────────────────────────────────────────────────

Rerun every prior Attempt-2 qualification lane from a fresh root:

- manifest/current-role matrix:
  exact prior 44-case registry;
- invocation matrix:
  exact prior 39-case registry;
- cleanup matrix:
  exact prior 26-case registry;
- temporal/terminal matrix:
  exact prior 42-case registry;
- security matrix:
  exact prior 32-case registry;
- process-custody matrix:
  exact prior 26-case registry.

Require exact prior case-name and expectation equality.

Across the 209 prior cases require:

- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Do not silently replace an old case with a new adapter case.

Adapter and cross-module matrices are additional lanes.

──────────────────────────────────────────────────────────────────────────────
15. SYNTHETIC END-TO-END TERMINAL LANES
──────────────────────────────────────────────────────────────────────────────

Rerun all six prior synthetic lanes through the actual terminal adapter and
inline-report path:

1. success capsule;
2. substantive BLOCK capsule;
3. zero-root causal failure;
4. one-root causal failure;
5. temporal-verification failure;
6. manifest-B write failure.

For each lane retain:

- complete process custody;
- actual terminal provider result;
- actual report consumer result;
- verdict class;
- marker posture;
- temporal/manifest posture;
- root identity;
- cleanup;
- no post-seal filesystem operation.

The success and BLOCK lanes must reach inline report and marker preparation.

Failure lanes must retain explicit failure outcomes and must not fabricate
terminal success.

──────────────────────────────────────────────────────────────────────────────
16. BOUNDED READ-ONLY LIVE REPLAY
──────────────────────────────────────────────────────────────────────────────

Run a bounded read-only replay against the unchanged supplied roots.

Do not execute:

- implementation production source;
- full independent audit parent;
- fresh rehearsal parent.

Require the repaired harness to:

1. authenticate the implementation package;
2. reproject its temporal inventory;
3. reproject its manifest pair;
4. resolve all 41 successor roles;
5. resolve current production and qualification registries;
6. authenticate source freeze and frozen requalification;
7. derive one exact future rehearsal invocation;
8. authenticate Attempt-2 failure custody;
9. produce one internally consistent security result;
10. produce a passing empty-set cleanup result;
11. construct an in-memory terminal success result through the actual adapter;
12. construct the corresponding inline report without exception;
13. emit no package ACCEPT/BLOCK verdict.

Retain:

validation/repaired-terminal-adapter-bounded-live-replay-v1.json

Allowed posture:

ready_for_fresh_full_audit

No package adjudication authority.

──────────────────────────────────────────────────────────────────────────────
17. INDEPENDENT REPAIRED-HARNESS VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a fresh source-external independent validator.

It may not import:

- repaired audit-parent modules;
- repaired repair-core modules;
- producer integration fixtures;
- producer matrix generators;
- producer expected-result maps;
- producer interface registry helpers.

It must independently verify:

- exact repair scope;
- predecessor and repaired source identities;
- unrelated-function AST equality;
- terminal-adapter authority adjudication;
- closed adapter contract;
- complete cross-module interface registry;
- provider/consumer conformance;
- every adapter integration case;
- every cross-module interface case;
- every prior 209-case regression;
- every synthetic terminal lane;
- bounded live replay;
- static and bytecode interface coverage;
- no full audit executed;
- no implementation package mutated.

Critically, it must itself call or source-externally exercise the real:

`seal_audit()` → `build_inline_report()`

integration for success, BLOCK, and audit-failure shapes.

Retain:

validation/independent-terminal-adapter-repair-validator-v1.json

Require zero errors.

A validator that checks only copied matrices or source predicates is
insufficient.

──────────────────────────────────────────────────────────────────────────────
18. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- blocker reproduction;
- authority adjudication;
- bounded source delta;
- compilation and static gates;
- terminal-adapter matrix;
- cross-module interface matrix;
- all prior qualification regressions;
- six synthetic terminal lanes;
- bounded live replay;
- independent validator;
- supplied-root equality.

Retain:

opening/final-terminal-adapter-repair-source-freeze-v1.json

Bind:

- exact source registry;
- predecessor source identities;
- exact changed functions;
- protected-function identities;
- adapter contract;
- cross-module interface registry;
- all qualification results;
- bounded live replay;
- no implementation-package mutation;
- full audit not executed;
- later source modification permitted:
  false.

Reopen every source no-follow and verify exact identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
19. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source bytes, rerun:

- compilation;
- static and bytecode gates;
- terminal-adapter matrix;
- cross-module interface matrix;
- all prior 209-case regressions;
- all six synthetic terminal lanes;
- bounded live replay;
- independent terminal-adapter validator;
- source/record identity linkage;
- supplied-root closing equality.

Do not run the full independent package audit.

Retain:

validation/frozen-terminal-adapter-repair-requalification-v1.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
20. HARNESS STATUS
──────────────────────────────────────────────────────────────────────────────

Generate a preterminal status record:

- status:
  gen2-independent-audit-harness-terminal-adapter-repaired-frozen-pending-fresh-audit;
- predecessor repair package:
  historical noncurrent after successor closure;
- implementation package mutated:
  false;
- implementation package adjudicated:
  false;
- full audit executed:
  false;
- repaired harness qualification:
  passed;
- repaired harness frozen:
  true;
- fresh full audit required:
  true;
- current subject construction authorized:
  false;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- product operation:
  not invoked;
- A6:
  not started.

Do not claim implementation acceptance or rejection.

──────────────────────────────────────────────────────────────────────────────
21. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- blocked repair predecessor;
- original failed audit;
- implementation package;
- successor Generation-2 package;
- authoritative contract package;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root;
- any other supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every repair-owned fixture root:

- retain complete pre-removal inventory;
- retain indispensable evidence;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
22. SUCCESSOR HARNESS-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize every nonclosure artifact;
- create only final directories actually used;
- ensure `closeout/` and `manifest/` exist;
- ensure no empty descendant;
- exclusively create zero-length A/B;
- retain both descriptors;
- freeze the directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and A/B;
2. write into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. independently generate A/B with A/B excluded;
6. require generated bytes identical;
7. write through retained descriptors;
8. fsync, close, and fsync manifest directory;
9. reopen no-follow;
10. verify path/inode/type/mode/link/size/hash;
11. independently reproject final root;
12. require root row exactly once;
13. require no empty descendant;
14. require no symlink or special object;
15. require no multiply linked regular file;
16. require modes 0700/0600;
17. require no cache/bytecode;
18. transition seal once;
19. emit only guarded terminal marker;
20. exit nonreturningly;
21. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
23. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- first blocker;
- structured exception;
- process ledger and streams;
- complete partial inventory;
- indispensable evidence before cleanup;
- fixture cleanup;
- supplied-root closing equality;
- harness authority false;
- source-freeze posture;
- terminal seal false;
- same-root retry false;
- retirement disposition when attempt budget is exhausted.

Do not create success manifests for a failed harness package.

Failure to retain indispensable evidence, complete cleanup, or close supplied
roots equally is:

HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

only when:

- predecessor repair root authenticates;
- Attempt-2 current source authority closes;
- exact blocker reproduces;
- terminal-adapter authority is unambiguous;
- one closed adapter contract is frozen;
- no duplicated root-identity alias exists;
- every cross-module interface is registered and directly tested;
- repair remains within the bounded source surface;
- all terminal-adapter cases pass;
- all cross-module interface cases pass;
- all prior 209 cases regress exactly;
- all six synthetic terminal lanes pass through the real adapter;
- bounded live replay passes;
- independent validator directly covers the adapter;
- static and bytecode interface gates pass;
- source freezes;
- frozen requalification passes;
- implementation package remains unchanged and unadjudicated;
- full audit remains unexecuted;
- supplied roots close equal;
- successor harness package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIR_BLOCKED

when:

- the adapter authority remains ambiguous;
- a governing contract requires conflicting shapes;
- another acceptance-bearing cross-module mismatch exists;
- repair exceeds the frozen surface;
- an interface cannot be closed;
- a matrix, synthetic lane, bounded replay, static gate, or independent
  validator fails;
- source attempt 2 fails.

When this blocked verdict follows attempt-budget exhaustion, also retain:

- `retire_incremental_harness_lineage=true`
- `clean_source_external_audit_harness_implementation_required=true`
- `further_localized_repair_authorized=false`

Return:

HARNESS_REPAIR_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- fixed source/input mismatch;
- indispensable evidence loss;
- unaccounted process or filesystem effect;
- cleanup inequality;
- supplied-root closing inequality;
- harness-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor repair-root identity
3. Predecessor blocked repair-root identity and closure
4. Exact Attempt-2 source authority
5. Original failed-audit identity and disposition
6. Implementation-package identity and closing equality
7. Successor Generation-2 identity and closing equality
8. External-root identities and closing equality
9. Attempt-2 failed-root identity and closing equality
10. Exact terminal-adapter blocker reproduction
11. Terminal-adapter authority adjudication
12. Canonical terminal-result schema
13. Canonical audit-root-identity pointer
14. Confirmation no duplicate root-identity alias exists
15. Complete cross-module interface registry
16. Repair authority and source surface
17. Source-attempt ledger
18. Final repaired source registry
19. Exact source delta
20. Protected-function equality
21. Terminal-adapter integration matrix
22. Cross-module interface matrix
23. Static and bytecode interface gates
24. Prior 209-case qualification regression
25. Synthetic success terminal path
26. Synthetic BLOCK terminal path
27. Synthetic zero-root failure path
28. Synthetic one-root failure path
29. Synthetic temporal failure path
30. Synthetic manifest-B failure path
31. Bounded read-only live replay
32. Independent terminal-adapter validator
33. Source freeze
34. Frozen-source requalification
35. Confirmation implementation production source was not executed
36. Confirmation full independent audit was not executed
37. Harness-package status
38. Supplied-root closing equality
39. Fixture cleanup
40. Failure-closeout capability and use
41. Temporal-inventory identity
42. Manifest A identity
43. Manifest B identity
44. Independent terminal reprojection
45. Terminal membership and modes
46. No-write-after-closure
47. Incremental-lineage terminality disposition
48. Remaining uncertainty and nonclaims
49. Explicit confirmation registry

Required confirmations:

PREDECESSOR_REPAIR_ROOT_MUTATION_NOT_PERFORMED
PREDECESSOR_REPAIR_ROOT_NOT_RESUMED
EXACT_ATTEMPT_2_SOURCE_AUTHORITY_ESTABLISHED
ATTEMPT_1_SOURCE_NOT_PROMOTED
ORIGINAL_FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
SUCCESSOR_GEN2_PACKAGE_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
TERMINAL_ADAPTER_MISMATCH_REPRODUCED
PROVIDER_RETURN_SHAPE_AUTHENTICATED
CONSUMER_REQUIRED_SHAPE_AUTHENTICATED
CANONICAL_ROOT_IDENTITY_POINTER_FROZEN
CANONICAL_ROOT_IDENTITY_POINTER_IS_INVENTORY_ROOT_IDENTITY
TOP_LEVEL_ROOT_IDENTITY_ALIAS_NOT_INTRODUCED
TERMINAL_ADAPTER_CONTRACT_CLOSED
TERMINAL_ADAPTER_TOTAL_ACCESSOR_IMPLEMENTED
NO_TERMINAL_ADAPTER_POINTER_FALLBACK
COMPLETE_CROSS_MODULE_INTERFACE_REGISTRY_PRODUCED
EVERY_ACCEPTANCE_BEARING_CROSS_MODULE_INTERFACE_REGISTERED
EVERY_REGISTERED_INTERFACE_DIRECTLY_TESTED
REPAIR_BOUNDED_TO_TERMINAL_ADAPTER_AND_INTERFACE_COVERAGE
PACKAGE_ACCEPTANCE_RULES_UNCHANGED
PACKAGE_VERDICT_CONSTANTS_UNCHANGED
UNRELATED_AUDIT_FUNCTIONS_AST_IDENTICAL
SOURCE_ATTEMPT_LIMIT_RESPECTED
TERMINAL_ADAPTER_SUCCESS_PATH_PASSED
TERMINAL_ADAPTER_BLOCK_PATH_PASSED
TERMINAL_ADAPTER_AUDIT_FAILURE_PATH_PASSED
OLD_KEYERROR_PATH_REJECTED_BY_REGRESSION
MISSING_INVENTORY_REJECTED
WRONG_INVENTORY_TYPE_REJECTED
MISSING_ROOT_IDENTITY_REJECTED
TOP_LEVEL_ALIAS_ONLY_REJECTED
CONFLICTING_ROOT_IDENTITY_ALIAS_REJECTED
NO_FILESYSTEM_OPERATION_IN_POSTSEAL_ADAPTER_PATH
TERMINAL_ADAPTER_MATRIX_PASSED
CROSS_MODULE_INTERFACE_MATRIX_PASSED
STATIC_INTERFACE_GATES_PASSED
BYTECODE_INTERFACE_GATES_PASSED
PRIOR_209_CASE_REGRESSION_PASSED
SYNTHETIC_SUCCESS_CAPSULE_PASSED
SYNTHETIC_BLOCK_CAPSULE_PASSED
SYNTHETIC_ZERO_ROOT_FAILURE_CAPSULE_PASSED
SYNTHETIC_ONE_ROOT_FAILURE_CAPSULE_PASSED
SYNTHETIC_TEMPORAL_FAILURE_CAUSAL_PASSED
SYNTHETIC_MANIFEST_B_FAILURE_CAUSAL_PASSED
BOUNDED_LIVE_REPLAY_PASSED
INDEPENDENT_TERMINAL_ADAPTER_VALIDATOR_PASSED
INDEPENDENT_VALIDATOR_EXERCISED_REAL_SEAL_TO_REPORT_PATH
REPAIRED_HARNESS_SOURCE_FROZEN
REPAIRED_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_HARNESS_REQUALIFICATION_PASSED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_HARNESS_MANIFEST_A_CREATED
SUCCESSOR_HARNESS_MANIFEST_B_CREATED
SUCCESSOR_HARNESS_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_HARNESS_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

If the verdict is:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

the next tranche is exactly one new fresh independent audit of the unchanged
sealed implementation package.

Do not combine that audit with this repair.

If the verdict is the blocked verdict after the two-attempt budget is consumed,
retire this incremental audit-harness lineage and require a clean,
source-external audit-harness implementation. Do not issue another localized
repair.
```

**Source:** Codex’s attached `SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_REPAIR_BLOCKED` report. The report says the prior seven harness defects were repaired, all 209 declared qualification cases and synthetic capsule lanes passed, but the real terminal provider/consumer interface remained uncovered and would raise `KeyError`; it also says the failure package itself sealed cleanly and explicitly requires a new source-attempt authorization before another full audit. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

**Confidence:** 0.995 that the implementation package remains unadjudicated; 0.99 that the defect is a localized audit-harness cross-module interface mismatch; 0.97 that this should be the final incremental repair before retiring the harness lineage.
