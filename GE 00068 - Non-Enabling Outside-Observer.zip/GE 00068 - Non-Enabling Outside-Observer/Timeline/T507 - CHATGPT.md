## Engineering assessment

The missing operating-model decision is now frozen correctly. The new additive package is terminally sealed and ready to govern a **new clean harness implementation generation**.

The current authority split is now precise:

- The predecessor five-domain documentary package remains authoritative for the five documentary domains, 66 runtime report rows, 81 runtime confirmation names, 15 matrices, 595 matrix cases, and aggregate ownership.
- The new additive successor package governs only `TOP_LEVEL_LAUNCH_RUNTIME_SELF_AUTHENTICATION`.
- Neither package supplies implementation source.
- The retired harness PYZ, authority v2, blocked dual-view root, and Attempt-3 generation remain historical evidence only.

### What the successor froze

The interpreter ambiguity has been eliminated by refusing to collapse distinct observations into a fictitious “real runtime image.”

The exact accepted tuple is:

| Role | Current exact value |
|---|---|
| `PLATFORM_DECLARED_LAUNCHER` | `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13` |
| runtime `sys.executable` | same Framework launcher |
| runtime `sys._base_executable` | same Framework launcher |
| `ORIG_ARGV_EXECUTABLE_TOKEN` | `/Library/Frameworks/Python.framework/Versions/3.13/Resources/Python.app/Contents/MacOS/Python` |

The contract expressly makes these distinct acceptance-bearing facts:

- no role substitution;
- no terminal-runtime-image role;
- no claim about the kernel’s executable image;
- no basename, prefix, generic `realpath`, scoring, or first-match fallback.

It also freezes the launch/runtime crosswalk:

- `sys.orig_argv[1:]` must exactly equal the submitted argument tail;
- `sys.argv` must equal the expected application sequence after interpreter flags;
- cwd and PID must match exactly;
- `isolated`, `no_site`, `dont_write_bytecode`, `ignore_environment`, and `safe_path` must have the frozen posture;
- source/PYZ identity and source freeze remain mandatory.

The environment policy is now bounded rather than permissive:

- the five declared environment rows must remain exact;
- the sole optional extra is `__CF_USER_TEXT_ENCODING`;
- when present it must be exactly `0x1F5:0x0:0x0`;
- its first component must equal UID 501;
- it has no authority, configuration, or verdict effect;
- any other extra key fails closed.

### Qualification strength

The package did more than record this decision:

- it authenticated the three original observations and their stability;
- froze the exact three-role taxonomy and tuple;
- passed a 151-case matrix with zero classification errors;
- passed an independently authored validator with zero errors;
- reconciled six documentary perspectives with no disagreement;
- closed an 18-role additive registry;
- preserved every predecessor documentary count and semantic;
- terminally sealed with byte-identical manifests, one root row, successful reprojection, clean topology and modes, and no postseal activity.

The new package is:

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-f5ys2h7f
```

- device/inode: `16777234 / 182148007`
- mode: `0700`

Closure identities:

```text
manifest/interpreter-observation-temporal-inventory-v1.json
```

- inode: `182159647`
- size: `11,608`
- SHA-256: `181015fc4ef80841995af4005e068b0a348a3d0e8cbb2ef9fac6ef6424af0031`

```text
manifest/interpreter-observation-manifest-a-v1.json
manifest/interpreter-observation-manifest-b-v1.json
```

- inodes: `182159648 / 182159649`
- size: `11,968` each
- SHA-256: `cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66`

### Progression decision

Proceed to a **new clean harness implementation generation**.

This is not Attempt 4 of the retired generation. It gets a fresh three-attempt source budget.

The implementation must be authored from:

1. the predecessor five-domain documentary package;
2. the additive interpreter-observation-tuple package;
3. the current content snapshot ZIP;
4. the current content authority JSON.

It must not copy or patch any retired harness source.

The implementation should preserve the successful capsule-lifecycle design from the retired attempt as **requirements**, not as source:

- mode-aware 66-row report projection;
- mode-aware 81-name confirmation projection;
- explicit P00–P24 terminal records;
- parent self-authentication using the newly frozen tuple;
- zero-child and nonzero child custody;
- canonical cleanup;
- fixed-input opening/closing equality;
- fresh audit-owned causals;
- namespace-stable temporal/manifests;
- one seal transition;
- terminal frame only after closure.

The correct final artifacts remain:

```text
gen2-clean-source-external-independent-audit-harness-v2.pyz
gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json
```

No v2/v3 artifact currently exists, so those names are available.

---

## Complete replacement Codex prompt

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
GENERATION-2 SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS

GOVERNED BY THE FIVE-DOMAIN DOCUMENTARY PACKAGE AND THE ADDITIVE
INTERPRETER-OBSERVATION-TUPLE CONTRACT

Objective

Implement a new clean-room source-external independent-audit harness using
only these current governing authorities:

1. the sealed predecessor five-domain documentary package;
2. the sealed additive interpreter-observation-tuple successor package;
3. the current-authority content snapshot ZIP;
4. the current content-snapshot authority JSON.

The new harness must:

- implement the frozen five-domain runtime governance;
- implement the exact three-role interpreter-observation tuple;
- implement the exact platform/runtime/environment crosswalk;
- implement a complete authoritative run-full-audit capsule;
- qualify against exact runtime matrices and new capsule/self-authentication
  matrices;
- pass source-external independent validation;
- complete physically distinct real-path ACCEPT, BLOCK, and provenance-failure
  rehearsals;
- freeze its source;
- build a deterministic executable PYZ;
- run fresh post-package qualification;
- create a self-contained external authority-v3 JSON;
- authorize exactly one later real audit.

Do not execute the real independent audit in this task.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any governing input.

Do not reopen original contaminated package directories.

Do not copy, patch, import, translate, execute, disassemble into source, or use
as an AST/bytecode/source origin:

- the retired harness PYZ;
- any retired harness source;
- any failed Attempt-3 source;
- predecessor documentary tooling;
- additive-successor documentary tooling.

Historical evidence may inform tests and defect catalogues. It is not source
authority.

Do not perform another historical findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

This is a new clean implementation generation.

Source-attempt budget:

- maximum complete attempts:
  3;
- consumed:
  0;
- remaining:
  3;
- Attempt 4:
  forbidden.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. GOVERNING INPUT A — FIVE-DOMAIN DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

FIVE_DOMAIN_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifest A:

manifest/documentary-manifest-a-v2.json

- device:
  16777234
- inode:
  181887816
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Expected manifest B:

manifest/documentary-manifest-b-v2.json

- device:
  16777234
- inode:
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Authenticate:

- root identity;
- temporal identity;
- A/B identities and byte equality;
- manifest grammar;
- independent terminal reprojection;
- one root row;
- 50-entry physical closure;
- topology and modes;
- one seal transition;
- no postseal activity.

Resolve current roles only through:

contract/current-governing-documentary-role-registry-v2.json

Required governing semantics:

- exactly five documentary domains;
- exact R01–R66 runtime report registry;
- exact 81-name runtime confirmation registry;
- exact B00 plus D01–D14 matrix registry;
- exact 15 matrices;
- exact 595 matrix cases;
- stale 645 rejected;
- aggregate owner classifications;
- aggregate owner/consumer registry;
- runtime/task-domain separation;
- package status:
  frozen pending new clean implementation generation.

Documentary tooling Python is not future source.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING INPUT B — ADDITIVE INTERPRETER-TUPLE PACKAGE
──────────────────────────────────────────────────────────────────────────────

INTERPRETER_TUPLE_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-f5ys2h7f

Expected root identity:

- device:
  16777234
- inode:
  182148007
- mode:
  0700

Expected temporal record:

manifest/interpreter-observation-temporal-inventory-v1.json

- device:
  16777234
- inode:
  182159647
- mode:
  0600
- link count:
  1
- size:
  11608
- SHA-256:
  181015fc4ef80841995af4005e068b0a348a3d0e8cbb2ef9fac6ef6424af0031

Expected manifest A:

manifest/interpreter-observation-manifest-a-v1.json

- device:
  16777234
- inode:
  182159648
- mode:
  0600
- link count:
  1
- size:
  11968
- SHA-256:
  cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66

Expected manifest B:

manifest/interpreter-observation-manifest-b-v1.json

- device:
  16777234
- inode:
  182159649
- mode:
  0600
- link count:
  1
- size:
  11968
- SHA-256:
  cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66

Authenticate:

- root identity;
- temporal identity;
- A/B identities and equality;
- manifest grammar;
- independent final reprojection;
- root row exactly once;
- 42-entry physical closure;
- topology and modes;
- one seal transition;
- no postseal operation.

Resolve additive roles only through:

contract/current-launch-runtime-successor-role-registry-v1.json

Required governing semantics:

- predecessor five-domain package remains current for every predecessor seam;
- additive successor governs only:
  TOP_LEVEL_LAUNCH_RUNTIME_SELF_AUTHENTICATION;
- exact three-role interpreter taxonomy;
- exact interpreter-observation tuple;
- exact three-view process-authority model;
- exact argv crosswalk;
- exact cwd/PID/flags/source crosswalk;
- exact runtime environment policy;
- exact parent self-authentication schema v3;
- exact 151-case tuple matrix;
- exact independent successor validator result;
- exact additive package status.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING INPUT C — CURRENT CONTENT SNAPSHOT
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate the authority JSON before the ZIP.

Require:

- exact archive identity;
- 479 archive members;
- eight current roles;
- seven content-snapshot roles;
- one bounded failure-evidence role;
- no `.DS_Store` archive member;
- deterministic-build equality;
- independent archive validation passed;
- implementation verdict not issued;
- package verdict not issued.

Authenticate ZIP grammar and exact index/member closure.

The containing directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
4. HISTORICAL DEFECT EVIDENCE
──────────────────────────────────────────────────────────────────────────────

Do not open retired roots unless exact paths and identities are resolved through
the two governing documentary packages.

The new implementation must retain a historical defect catalogue that includes:

- incomplete run-full-audit capsule lifecycle;
- stale qualification-mode runtime confirmations during audit mode;
- generic phase evidence;
- missing child ledger/custody;
- missing cleanup and input-closing equality;
- missing temporal/manifests;
- premature final frame;
- flat launch/runtime self-authentication;
- Framework-launcher versus Python.app orig-argv distinction;
- optional macOS `__CF_USER_TEXT_ENCODING` injection.

Historical evidence is test input only.

It is not source authority.

No source may be copied or patched from a retired generation.

──────────────────────────────────────────────────────────────────────────────
5. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh private build root beneath `/private/tmp` with:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate a fresh output directory beneath `/Users/ds/Downloads` with:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

Successful final files:

gen2-clean-source-external-independent-audit-harness-v2.pyz

gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/new-clean-generation-authority-v1.json
opening/fixed-input-registry-v1.json
opening/five-domain-documentary-resolution-v1.json
opening/interpreter-tuple-documentary-resolution-v1.json
opening/clean-room-source-authority-v1.json
opening/process-execution-policy-v1.json
opening/implementation-operating-freeze-v1.json

Bind:

- generation:
  new clean implementation generation;
- source-attempt maximum:
  3;
- consumed:
  0;
- same-root retry:
  false;
- historical source use:
  forbidden;
- implementation-package adjudication:
  forbidden in this task;
- real full audit:
  forbidden in this task;
- implementation production execution:
  forbidden;
- current-subject construction:
  forbidden;
- product/runtime/target/repository/publication/deployment/A6:
  forbidden.

──────────────────────────────────────────────────────────────────────────────
6. CLEAN-ROOM SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Permitted source inputs:

- authenticated documentary contracts and registries;
- normative contract and current schemas inside the content bundle;
- current validation specifications inside the content bundle;
- terminal findings/reconciliation evidence inside the content bundle;
- historical defect classifications as test requirements;
- this task’s pre-source contracts.

Forbidden source inputs:

- predecessor harness source;
- retired Attempt-3 source;
- documentary-package tooling source;
- implementation source as harness source;
- transcript-reconstructed source;
- hash-reconstructed source;
- disassembly-reconstructed source;
- generated source derived from subject source.

Implementation source may be authenticated and parsed read-only during
compatibility qualification and the later audit.

It may not be imported or executed.

Retain:

opening/clean-room-source-authority-v1.json

Require no source-similarity or source-recovery mechanism.

──────────────────────────────────────────────────────────────────────────────
7. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/clean-independent-audit-harness-authority-v2.json
contract/clean-independent-audit-harness-operating-model-v2.json

Future `run-full-audit` authority:

- authenticate exact harness authority v3;
- authenticate exact harness PYZ v2;
- authenticate exact content bundle and content authority;
- self-authenticate using the three-role interpreter tuple;
- resolve all eight current content roles;
- create one fresh audit root;
- run source-external implementation audit;
- retain complete external/internal process-custody boundary;
- classify direct package, audit, derivative, mixed, and unresolved findings;
- issue exactly one package verdict:
  ACCEPT,
  BLOCK,
  AUDIT_PROVENANCE_MISMATCH;
- retain dependency graph;
- retain cleanup and fixed-input closing equality;
- terminally close the audit capsule.

Nonauthority:

- implementation repair;
- source-package mutation;
- contract/schema repair;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

──────────────────────────────────────────────────────────────────────────────
8. EXACT FUTURE CLI AND AUTHORITY INPUT
──────────────────────────────────────────────────────────────────────────────

Final PYZ supports exactly:

--mode qualify-harness

--mode run-full-audit

No default mode.

Future `run-full-audit` invocation must be exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_PYZ_V2>
--mode
run-full-audit
--harness-authority
<FINAL_AUTHORITY_V3>
--bundle
<CURRENT_AUTHORITY_BUNDLE>
--bundle-authority
<CURRENT_AUTHORITY_JSON>

Explicit environment:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

`qualify-harness` may omit authority v3 before authority creation.

After authority v3 exists, final frozen-PYZ requalification must bind and
validate it.

Retain:

contract/future-full-audit-invocation-v2.json

──────────────────────────────────────────────────────────────────────────────
9. THREE-ROLE PARENT SELF-AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Implement the exact additive successor contracts.

Required semantic roles:

1. PLATFORM_DECLARED_LAUNCHER
2. RUNTIME_API_EXECUTABLE
3. ORIG_ARGV_EXECUTABLE_TOKEN

Required current tuple:

- submitted launcher:
  `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`;
- `sys.executable`:
  same launcher identity;
- `sys._base_executable`:
  same launcher identity;
- `sys.orig_argv[0]`:
  `/Library/Frameworks/Python.framework/Versions/3.13/Resources/Python.app/Contents/MacOS/Python`.

No `terminal_runtime_image` role.

No kernel-image claim.

No role substitution.

No basename, prefix, realpath, score, or first-match fallback.

Implement:

- exact argv executable-token distinction;
- exact `sys.orig_argv[1:]` versus submitted argv tail;
- exact `sys.argv` application sequence;
- exact cwd equality;
- exact external/runtime PID equality when external PID is available;
- exact required Python flags;
- exact source/PYZ identity;
- source-freeze authentication.

The future capsule record:

opening/parent-runtime-self-authentication.json

must satisfy the frozen v3 schema.

Top-level process creation authority remains:

external_platform_wrapper

The capsule validates the launch contract; it does not attest process creation.

──────────────────────────────────────────────────────────────────────────────
10. RUNTIME ENVIRONMENT POLICY
──────────────────────────────────────────────────────────────────────────────

Implement the exact additive environment policy.

Declared rows:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

Require every declared row and exact value.

The sole permitted optional extra:

__CF_USER_TEXT_ENCODING

When present:

- exact value:
  `0x1F5:0x0:0x0`;
- first hexadecimal component equals runtime UID 501;
- second component zero;
- third component zero;
- authority:
  none;
- configuration effect:
  none;
- verdict effect:
  none.

Unknown extra keys fail closed.

The optional key may not replace or override a declared row.

Generic superset/subset environment acceptance is forbidden.

──────────────────────────────────────────────────────────────────────────────
11. FIVE-DOMAIN RUNTIME GOVERNANCE
──────────────────────────────────────────────────────────────────────────────

Implement exactly:

- five documentary domains;
- R01–R66 report registry;
- exact 81-name confirmation registry;
- exact B00 and D01–D14 matrix registry;
- exact 15 / 595 aggregate;
- aggregate-owner classifications;
- aggregate owner/consumer rules.

Runtime report rows and runtime confirmation rows are mode-aware.

Task-level implementation report/confirmations remain separate domains.

No count is hard-coded independently from its exact owner rows.

Stale 645 fails.

──────────────────────────────────────────────────────────────────────────────
12. MODE-AWARE REPORT AND CONFIRMATION PROJECTION
──────────────────────────────────────────────────────────────────────────────

The exact runtime report IDs and confirmation names remain unchanged.

Runtime confirmation rows must contain:

- name;
- mode;
- applicability;
- observed;
- expected;
- pass;
- evidence pointers;
- authority role.

For `run-full-audit`, facts such as:

RUN_FULL_AUDIT_MODE_NOT_EXECUTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED

must use:

- observed:
  false;
- expected:
  false;
- pass:
  true.

Do not require all observed Booleans to be true.

Runtime report rows contain:

- section ID;
- title;
- mode;
- applicability;
- status;
- value;
- evidence pointers;
- authority role.

No blanket `not-applicable`.

No qualification-mode projection reused without current-mode adjudication.

The primary verdict remains separate from confirmations.

──────────────────────────────────────────────────────────────────────────────
13. FULL-AUDIT PHASE PLAN AND PHASE RECORDS
──────────────────────────────────────────────────────────────────────────────

Implement P00–P24 from the governing phase plan.

Each phase record contains:

- schema;
- phase ID;
- phase name;
- prerequisites;
- status:
  passed,
  failed,
  not_reached;
- terminal:
  true;
- direct phase-specific evidence pointers;
- findings;
- first blocker or null;
- continuation decision;
- cleanup obligations;
- authority contribution;
- completion timestamp.

No generic shared evidence string.

No `pass:true` without explicit status and terminality.

Terminal does not imply passed.

Retain exact aggregate phase-terminal results.

──────────────────────────────────────────────────────────────────────────────
14. CAPSULE NAMESPACE AND ONE-WRITER REGISTRY
──────────────────────────────────────────────────────────────────────────────

Freeze the complete run-full-audit namespace before compilation.

Required directories:

opening/
provenance/
phases/
analysis/
validation/
process/
report/
closing/
cleanup/
closeout/
terminal/
manifest/

Required final records include:

opening/bootstrap-start.json
opening/parent-runtime-self-authentication.json
opening/fixed-input-opening-identities.json
opening/bundle-authentication.json
opening/role-resolution.json
opening/phase-plan-authentication.json

provenance/top-level-process-authority-boundary.json
provenance/complete-child-ledger.json
provenance/child-process-custody-result.json

phases/P00.json through phases/P24.json

analysis/source-external-evidence.json
analysis/security-and-authority-closure.json
analysis/findings-and-dependency-graph.json

validation/runtime-matrices.json
validation/negative-946-result.json
validation/contradiction-137-result.json
validation/field-map-766-333-result.json
validation/producer-rehearsal-result.json
validation/attempt-2-failure-evidence-result.json
validation/implementation-confirmation-result.json
validation/constructed-subject-domain-result.json
validation/fresh-behavioral-causals.json
validation/fresh-source-external-validation.json

report/runtime-report.json
report/runtime-confirmations.json

cleanup/cleanup-result.json
closing/fixed-input-closing-equality.json

closeout/phase-terminal-results.json
closeout/preseal-substantive-result.json
closeout/temporal-final-inventory.json

terminal/terminal-result.json

manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json

Every path has:

- one phase owner;
- one function owner;
- one successful write;
- exclusive creation;
- no overwrite;
- no adoption;
- no staging use;
- exact schema.

Unknown or duplicate ownership fails closed.

──────────────────────────────────────────────────────────────────────────────
15. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Always retain:

provenance/complete-child-ledger.json
provenance/child-process-custody-result.json

Zero-child ledger must explicitly pass:

- child_count:
  0;
- ordinals:
  [];
- complete_and_contiguous:
  true;
- every_created_child_reaped:
  true;
- all_child_descriptors_closed:
  true;
- recorder_bypass:
  false.

Nonzero children require:

- prelaunch-before-spawn;
- ordinal;
- exact executable;
- argv/cwd/environment/stdin;
- streams;
- exit/signal;
- timeout;
- reaping;
- descriptor closure;
- effects;
- cleanup obligations.

Top-level process custody remains external.

──────────────────────────────────────────────────────────────────────────────
16. CLEANUP AND FIXED-INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Canonical cleanup uses:

cleanup_rows

Retain:

cleanup/cleanup-result.json

Require exact equality:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Equal empty sets pass.

No Boolean/integer conflation.

Require zero process, descriptor, cache, and bytecode survivors.

Retain:

closing/fixed-input-closing-equality.json

Cover:

- final PYZ v2;
- final authority v3;
- current content bundle;
- current content authority.

Compare device, inode, mode, link count, size, and SHA-256.

──────────────────────────────────────────────────────────────────────────────
17. FRESH AUDIT-OWNED BEHAVIORAL CAUSALS
──────────────────────────────────────────────────────────────────────────────

Do not pass the causal phase without fresh audit-owned cases.

Do not execute implementation production source.

At minimum cover:

- source same-size mutation;
- source-freeze mutation;
- duplicate/missing source role;
- post-G01 directory creation;
- stale 645;
- missing matrix;
- runtime confirmation mode mismatch;
- zero-count cleanup conflation;
- interpreter role substitution;
- wrong orig-argv token;
- unknown environment key;
- missing input-closing row;
- missing temporal;
- missing B;
- A/B mismatch;
- missing root row;
- postseal write.

Require zero false outcomes, mismatches, skips, and exceptions.

Retain complete cleanup.

──────────────────────────────────────────────────────────────────────────────
18. TERMINAL CAPSULE LIFECYCLE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize all nonclosure records;
- precreate every terminal directory;
- exclusively reserve temporal and both manifest paths;
- retain descriptors;
- freeze namespace;
- require no unknown path.

Temporal:

- independently generate twice;
- include root once;
- include terminal directories and nonmanifest files;
- exclude self and A/B;
- require byte equality;
- write through retained descriptor;
- fsync;
- reopen no-follow;
- verify identity;
- independently reproject immediately.

Manifests:

- independently generate A/B from identical frozen namespace;
- include temporal;
- exclude A/B;
- require byte equality;
- write through retained descriptors;
- fsync;
- reopen no-follow;
- verify descriptor/path inode equality;
- independently reproject final root.

Require:

- root row once;
- no empty descendant;
- no symlink/special object;
- no multiply linked regular file;
- modes 0700/0600;
- no cache/bytecode.

Transition seal once only after all checks pass.

After seal:

- no filesystem operation;
- no child/process operation;
- emit only guarded terminal frame;
- exit nonreturningly.

──────────────────────────────────────────────────────────────────────────────
19. PRESEAL AND TERMINAL AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Preseal result is always nonauthoritative.

It retains:

- intended disposition;
- direct package findings;
- audit findings;
- derivative/mixed/unresolved findings;
- dependency graph;
- phase states;
- `terminal_closure_required=true`.

The terminal frame promotes the result only after closure.

It contains:

- schema;
- audit root;
- final verdict;
- preseal-result identity;
- terminal-result identity;
- temporal identity;
- manifest identities;
- A/B equality;
- reprojection passed;
- root-row count one;
- seal-transition count one;
- terminal marker;
- no postseal operation true.

No ACCEPT or BLOCK frame may be emitted before closure.

All final dispositions, including provenance failure, must terminally close when
filesystem integrity permits.

──────────────────────────────────────────────────────────────────────────────
20. SCHEMA-BEARING RECORDS
──────────────────────────────────────────────────────────────────────────────

Every capsule JSON record:

- contains `schema`;
- uses strict canonical UTF-8 JSON;
- rejects duplicate keys and nonfinite values;
- ends with exactly one LF;
- is mode 0600;
- is single-link;
- is exclusively written once;
- participates in terminal closure unless explicitly excluded.

Static and runtime gates reject any capsule JSON without `schema`.

──────────────────────────────────────────────────────────────────────────────
21. SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Define clean modular roles for:

- executable PYZ entrypoint;
- finite audit parent;
- child recorder;
- strict JSON;
- total JSON observation;
- ZIP/bundle authority reader;
- role/member resolver;
- governing-document reader;
- interpreter-tuple validator;
- launch/runtime crosswalk;
- environment validator;
- source/freeze validator;
- path-sensitive phase analyzer;
- runtime matrix adapters;
- mode-aware report projector;
- mode-aware confirmation projector;
- cleanup owner;
- fixed-input equality owner;
- capsule lifecycle;
- terminal frame;
- findings/dependency builder;
- security/authority analyzer;
- failure closeout;
- qualification fixtures;
- independent validators.

Independent validators import no production or qualification helpers,
generators, expected maps, observers, normalizers, or projectors.

Retain exact production, qualification, and independent source registries.

──────────────────────────────────────────────────────────────────────────────
22. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete clean-source attempts in this new generation.

An attempt starts only when:

- all final source registries close;
- compilation begins.

Any source modification after compilation begins consumes the next attempt.

Retain every attempt’s:

- source identities;
- provenance;
- compilation;
- static gates;
- matrices;
- rehearsals reached;
- first blocker;
- supersession.

If Attempt 3 fails, stop.

No Attempt 4.

──────────────────────────────────────────────────────────────────────────────
23. COMPILATION AND STATIC GATES
──────────────────────────────────────────────────────────────────────────────

Compile all sources using pinned Python with:

-I -S -B

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception tables;
- CFG;
- interface crosswalk;
- writer crosswalk;
- filesystem/process operation crosswalk;
- report/confirmation registry analysis;
- tuple/environment crosswalk;
- terminal-operation crosswalk;
- forbidden source/path/executable analysis.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- every child through one recorder;
- no network;
- no Git/VCS;
- no shell or PATH lookup;
- no broad filesystem scan;
- no historical-source origin;
- no unresolved acceptance edge;
- no role substitution;
- no generic environment superset;
- no postseal operation;
- success/failure closeout reachable.

──────────────────────────────────────────────────────────────────────────────
24. QUALIFICATION MATRICES
──────────────────────────────────────────────────────────────────────────────

A. Preserve exact runtime suite:

- B00;
- D01–D14;
- 15 matrices;
- 595 cases;
- exact names and expected outcomes.

B. Implement the exact 151-case interpreter-observation tuple matrix from the
additive package.

C. Capsule evidence matrix:
at least 60 cases.

D. Mode-aware confirmation matrix:
at least 40 cases.

E. Mode-aware report matrix:
at least 40 cases.

F. Terminal-frame/lifecycle matrix:
at least 40 cases.

G. Process-custody matrix:
at least 40 cases.

H. Fresh causal matrix:
at least 20 cases.

Each matrix requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

New matrices do not alter the governed 15/595 runtime suite.

──────────────────────────────────────────────────────────────────────────────
25. SYNTHETIC AND REAL-PATH REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run source-independent synthetic lanes for:

- ACCEPT;
- BLOCK;
- AUDIT_PROVENANCE_MISMATCH;
- semantically equal constructed subjects;
- wrong tuple;
- unknown environment injection;
- incomplete capsule evidence;
- terminal mutations.

Then run physically distinct real-path rehearsals through the exact final
`run-full-audit` code path.

A. ACCEPT rehearsal

- exact synthetic accepted package;
- provisional PYZ;
- provisional harness authority;
- exact CLI including `--harness-authority`;
- pinned Framework launcher;
- exact declared environment;
- platform capture;
- parent self-authentication passes the exact tuple;
- complete sealed ACCEPT capsule.

B. BLOCK rehearsal

Same requirements with one direct package blocker and a complete sealed BLOCK
capsule.

C. Provenance rehearsal

One exact audit-provenance blocker and a complete sealed
AUDIT_PROVENANCE_MISMATCH capsule.

Each rehearsal must retain:

- PYZ/authority identities;
- platform custody;
- raw streams;
- root locator;
- capsule identity;
- every record;
- phase states;
- cleanup;
- temporal/manifests;
- terminal frame;
- independent capsule validation.

Require no stale mode confirmation and exact R01–R66/81-name projections.

Retain all evidence before cleanup.

Remove disposable roots with double ENOENT.

──────────────────────────────────────────────────────────────────────────────
26. INDEPENDENT VALIDATION
──────────────────────────────────────────────────────────────────────────────

Independent validators must verify:

- clean-room provenance;
- both governing documentary packages;
- content bundle/authority;
- exact source registries;
- exact five-domain governance;
- exact tuple and environment policy;
- source architecture and interfaces;
- runtime matrices;
- new qualification matrices;
- process custody;
- synthetic lanes;
- all three real-path rehearsals;
- mode-aware projections;
- phase records;
- cleanup and input equality;
- temporal/manifests;
- terminal frames;
- no postseal operation;
- evidence retention and cleanup.

They may not import candidate producer/qualification helpers.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
27. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze only after all qualification and rehearsal gates pass.

Retain:

opening/clean-independent-audit-harness-v2-source-freeze-v1.json

Bind:

- both documentary package identities;
- content bundle and authority identities;
- final source registries;
- exact source identities;
- five-domain governance;
- tuple/environment governance;
- all matrix results;
- synthetic lanes;
- rehearsal identities;
- independent results;
- cleanup;
- future invocation;
- full real audit not executed;
- later modification forbidden.

Reopen every source no-follow.

Do not modify afterward.

──────────────────────────────────────────────────────────────────────────────
28. DETERMINISTIC PYZ V2
──────────────────────────────────────────────────────────────────────────────

Build independently twice:

gen2-clean-source-external-independent-audit-harness-v2.pyz

Require byte equality.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicates;
- no unsafe/directory/symlink/special members;
- no comments or uncontrolled extras;
- no cache or bytecode.

Include exact byte-identical governing records from both documentary packages,
not their tooling source.

Retain exact member registry and derived member count.

──────────────────────────────────────────────────────────────────────────────
29. POST-PACKAGE QUALIFICATION AND AUTHORITY V3
──────────────────────────────────────────────────────────────────────────────

Run final PYZ v2 in `qualify-harness` mode exactly once after packaging.

Retain complete platform custody and raw streams.

Require fresh qualification of:

- exact PYZ v2;
- source freeze;
- unchanged sources;
- both governing packages;
- exact tuple/environment policy;
- prior and new matrices;
- process custody;
- synthetic lanes;
- all real-path rehearsals;
- deterministic member closure;
- no run-full-audit execution;
- no implementation verdict.

Create:

gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Authority v3 binds:

- exact PYZ v2;
- member registry;
- source freeze;
- post-package qualification custody/result;
- both documentary-package identities;
- tuple/environment identities;
- runtime registries;
- all qualification results;
- rehearsal identities;
- exact future run invocation with `--harness-authority`;
- current content bundle and authority;
- authorized future audit count:
  1;
- full real audit executed:
  false;
- implementation verdict:
  not issued.

Build authority v3 independently twice and require byte equality.

Run an independent authority-v3 validator.

Set PYZ v2 and authority v3 to mode 0400 only after validation.

──────────────────────────────────────────────────────────────────────────────
30. FROZEN-PYZ V2 REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Run exact final PYZ v2 in `qualify-harness` mode with the frozen operands needed
to validate authority v3.

Require:

- exit zero;
- empty stderr;
- exact qualification record;
- PYZ/member self-authentication;
- source-freeze linkage;
- both governing packages;
- exact tuple/environment semantics;
- prior and new matrices;
- process custody;
- real-path rehearsal linkage;
- authority-v3 coherence;
- no run-full-audit execution;
- no implementation verdict.

Independently recompute every governed aggregate.

Retain:

validation/frozen-pyz-v2-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
31. INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow checks for:

- five-domain documentary package;
- additive tuple package;
- content bundle;
- content authority.

Require exact opening/closing equality.

Do not mutate supplied inputs.

──────────────────────────────────────────────────────────────────────────────
32. CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing disposable roots retain:

- identity;
- complete inventory;
- streams;
- results;
- failure outcome where applicable.

Revalidate, remove exact root, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

──────────────────────────────────────────────────────────────────────────────
33. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt;
- first blocker;
- structured exception;
- process ledger/streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- input equality;
- freeze/package posture;
- same-root retry false.

Do not create current outputs on failure.

If provisional outputs exist:

- retain identities;
- classify nonauthoritative;
- remove after evidence retention;
- double ENOENT.

──────────────────────────────────────────────────────────────────────────────
34. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- all governing inputs authenticate;
- clean-room provenance passes;
- source qualifies within three attempts;
- exact 15/595 suite passes;
- 151-case tuple matrix passes;
- all capsule/projection/custody/terminal matrices pass;
- synthetic lanes pass;
- ACCEPT/BLOCK/provenance real-path rehearsals terminally pass;
- independent validators pass;
- source freezes;
- deterministic PYZ v2 A/B match;
- fresh post-package qualification passes;
- authority v3 A/B match;
- independent authority-v3 validation passes;
- frozen-PYZ v2 requalification passes;
- input equality and cleanup pass;
- final files are mode 0400;
- no real implementation audit ran;
- no implementation verdict was issued.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTATION_BLOCKED

when:

- source cannot qualify within three attempts;
- a governed semantic remains unresolved;
- a matrix, rehearsal, validator, or requalification fails without provenance
  failure;
- implementation would require changing package acceptance semantics.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- clean-room source violation;
- retired-source use;
- Git/VCS use;
- unregistered effects;
- evidence loss;
- cleanup inequality;
- input mutation;
- source drift after freeze;
- final package/authority mismatch;
- post-finalization modification.

──────────────────────────────────────────────────────────────────────────────
35. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Five-domain documentary-package identity
5. Interpreter-tuple documentary-package identity
6. Content-bundle identity
7. Content-authority identity
8. Fixed-input authentication
9. Governing-role resolution
10. Clean-room source authority
11. Harness authority and nonauthority
12. Future invocation
13. Five-domain governance
14. Interpreter role taxonomy
15. Exact observation tuple
16. Environment policy
17. Parent self-authentication contract
18. Mode-aware report contract
19. Mode-aware confirmation contract
20. Phase plan and phase-record contract
21. Capsule namespace
22. One-writer registry
23. Process custody
24. Cleanup and fixed-input equality
25. Terminal lifecycle
26. Source architecture
27. Source-attempt ledger
28. Final production-source registry
29. Final qualification-source registry
30. Final independent-source registry
31. Cross-module interface registry
32. Compilation/static gates
33. Exact B00/D01–D14 result
34. Exact 151-case tuple-matrix result
35. Capsule-evidence matrix
36. Mode-aware confirmation matrix
37. Mode-aware report matrix
38. Terminal-lifecycle matrix
39. Process-custody matrix
40. Fresh causal matrix
41. Synthetic ACCEPT
42. Synthetic BLOCK
43. Synthetic provenance failure
44. Bounded real-bundle replay
45. Real-path ACCEPT rehearsal
46. Real-path BLOCK rehearsal
47. Real-path provenance rehearsal
48. Rehearsal comparison
49. Independent validators
50. Evidence retention
51. Cleanup
52. Source freeze
53. PYZ v2 Build A
54. PYZ v2 Build B
55. PYZ v2 equality
56. PYZ member closure
57. Post-package qualification
58. Authority-v3 Build A
59. Authority-v3 Build B
60. Authority-v3 equality
61. Independent authority-v3 validation
62. Frozen-PYZ v2 requalification
63. Confirmation no real audit was executed
64. Confirmation no implementation verdict was issued
65. Input closing equality
66. Failure-closeout capability/use
67. Final PYZ v2 path and identity
68. Final authority-v3 path and identity
69. Remaining uncertainty/nonclaims
70. Explicit task confirmations

Required confirmations include:

FIVE_DOMAIN_DOCUMENTARY_PACKAGE_AUTHENTICATED
INTERPRETER_TUPLE_DOCUMENTARY_PACKAGE_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_AUTHENTICATED
CURRENT_CONTENT_AUTHORITY_AUTHENTICATED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
NO_RETIRED_SOURCE_USED
NEW_IMPLEMENTATION_GENERATION_ESTABLISHED
SOURCE_ATTEMPT_LIMIT_RESPECTED
FIVE_DOCUMENTARY_DOMAINS_IMPLEMENTED
RUNTIME_REPORT_REGISTRY_66_IMPLEMENTED
RUNTIME_CONFIRMATION_REGISTRY_81_IMPLEMENTED
RUNTIME_MATRIX_REGISTRY_15_595_IMPLEMENTED
INTERPRETER_ROLE_TAXONOMY_IMPLEMENTED
EXACT_OBSERVATION_TUPLE_IMPLEMENTED
TERMINAL_RUNTIME_IMAGE_ROLE_ABSENT
KERNEL_IMAGE_NOT_CLAIMED
THREE_VIEW_PROCESS_AUTHORITY_IMPLEMENTED
PLATFORM_DECLARED_LAUNCHER_IMPLEMENTED
RUNTIME_API_EXECUTABLE_IMPLEMENTED
ORIG_ARGV_EXECUTABLE_TOKEN_IMPLEMENTED
ARGV_CROSSWALK_IMPLEMENTED
CWD_CROSSWALK_IMPLEMENTED
PID_CROSSWALK_IMPLEMENTED
PYTHON_FLAG_CROSSWALK_IMPLEMENTED
RUNTIME_ENVIRONMENT_POLICY_IMPLEMENTED
CF_USER_TEXT_ENCODING_POLICY_IMPLEMENTED
UNKNOWN_RUNTIME_ENVIRONMENT_KEY_REJECTED
PARENT_RUNTIME_SELF_AUTHENTICATION_IMPLEMENTED
MODE_AWARE_RUNTIME_REPORT_IMPLEMENTED
MODE_AWARE_RUNTIME_CONFIRMATIONS_IMPLEMENTED
PHASE_TERMINAL_STATE_IMPLEMENTED
PHASE_SPECIFIC_EVIDENCE_IMPLEMENTED
CAPSULE_PATH_REGISTRY_COMPLETE
ONE_WRITER_PER_CAPSULE_PATH
ZERO_CHILD_LEDGER_IMPLEMENTED
CHILD_PROCESS_CUSTODY_IMPLEMENTED
CANONICAL_CLEANUP_IMPLEMENTED
FIXED_INPUT_CLOSING_EQUALITY_IMPLEMENTED
FRESH_BEHAVIORAL_CAUSALS_IMPLEMENTED
TEMPORAL_INVENTORY_IMPLEMENTED
TERMINAL_MANIFESTS_IMPLEMENTED
TERMINAL_MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_IMPLEMENTED
ROOT_ROW_PRESENT_EXACTLY_ONCE
SCHEMA_PRESENT_IN_EVERY_CAPSULE_JSON
SINGLE_SEAL_TRANSITION_IMPLEMENTED
NO_POSTSEAL_OPERATION
PRESEAL_RESULT_NONAUTHORITATIVE_UNTIL_CLOSURE
TERMINAL_FRAME_ONLY_AFTER_CLOSURE
ALL_SOURCES_COMPILED
STATIC_GATES_PASSED
PRIOR_RUNTIME_MATRICES_PASSED
INTERPRETER_TUPLE_MATRIX_PASSED
CAPSULE_AND_PROJECTION_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_LANES_PASSED
REAL_PATH_ACCEPT_REHEARSAL_PASSED
REAL_PATH_BLOCK_REHEARSAL_PASSED
REAL_PATH_PROVENANCE_REHEARSAL_PASSED
INDEPENDENT_VALIDATORS_PASSED
SOURCE_FROZEN
SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_V2_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
AUTHORITY_V3_BUILD_A_B_BYTES_IDENTICAL
INDEPENDENT_AUTHORITY_V3_VALIDATOR_PASSED
FROZEN_PYZ_V2_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_PYZ_V2_CREATED
FINAL_PYZ_V2_MODE_0400
FINAL_PYZ_V2_IDENTITY_VERIFIED
FINAL_AUTHORITY_V3_CREATED
FINAL_AUTHORITY_V3_MODE_0400
FINAL_AUTHORITY_V3_IDENTITY_VERIFIED
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh audit using:

- final PYZ v2;
- final authority v3;
- current content bundle;
- current content authority.

Do not combine that audit with implementation.

Do not construct the current schema subject until the later audit accepts the
Generation-2 implementation package.
```

### Source

Codex’s operative report in your message is the sole basis for the factual assessment above.

**Confidence:** 0.999 that the additive operating model is now frozen without changing implementation acceptance semantics; 0.999 that no future source or audit was executed; 0.995 that the next correct tranche is a new clean implementation generation; 0.98 that the exact three-role tuple and bounded macOS environment policy remove the final known self-authentication ambiguity.
