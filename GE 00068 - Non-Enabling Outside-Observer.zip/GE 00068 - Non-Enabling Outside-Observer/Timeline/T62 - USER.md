Here is Codex's response:

REPAIR10I\_A5\_PRODUCT\_OR\_TEST\_REPAIR\_REQUIRED

All 12 sided differences are classified. Ten entries arise from five repository tests that construct overlength Unix-socket fixtures and fail before their intended assertions. The remaining two entries arise from A5S observability canonicalization treating duration-value equality as correlation topology. No retained evidence shows a production behavior divergence.

A successor-only A5C amendment would be unsafe because it could normalize the five fixture failures into apparent final↔fresh equality.

## 1. Opening and closing identities

Opening and closing values matched exactly.

Repository:

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Upstream: absent
- Index SHA-256: `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- T: `e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c`
- Inventory SHA-256: `9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b`
- Inventory size: `54314`
- Membership: `389 / 375 / 14`
- Tracked modified: `22`
- Staged/deleted/renamed/unmerged: `0/0/0/0`

Sealed A5:

- Manifest: `29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc`
- Manifest size/payloads/directories: `50474 / 341 / 84`
- T/inventory: `e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c` / `9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b`

Sealed A5S:

- Manifest: `57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f`
- Manifest size/payloads/directories: `42838 / 271 / 81`
- Source T/inventory/members: `983943e612dd4d48ca4f0fabbc48ad51909c2e11` / `799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a` / `12`
- Both binary copies match:
  - runner `ce6a44a99d4f53eaa6c8feeadc407e063deb7e6303e68f154fbe1cf0d573e68b`
  - compare `e31887e0d45026d6bad6a6f2e5a4a30dd1f0f7c5bd55847991a9120ef6351e06`
  - semantic `2f28bf8996b4a42d318cb16604804ad90cdb41b17517d30b4c0db85d5fbd0c2e`
  - fixture `d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`

Failed refresh child, opening and closing:

- Snapshot digest: `501b04e31157d2437d73aafae053a49f3fb4140880247fdc3256ac6433b924ae`
- Entries/files/directories: `180 / 134 / 46`
- Present and unsealed
- Manifest absent
- Detached digest absent
- No base-directory entry containing `a5c` exists

Retained controls:

| Fact`a5-finala5-fresh` |                                                                    |                                                                    |
| ---------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| source class           | `pristine-final`                                                   | `pristine-final`                                                   |
| suite spec             | `82bf3ffac241b88c998860a040e14142a408b6690c3487ce2717574b269edf41` | `fe1479a66ef6116b7a173a7eb4d4dc04b4cc4a47a65cfc2e4fc0a36969820cee` |
| suite result           | `524c91116f6425553b1c2dba5d55694682823fc12ce64ed5605587b0d29b3211` | `4f6932e5b7d47ab1339341c187c84ef7e52915d9058dc703a02422994bf75704` |
| raw stdout             | `fb8be8b0cc364284886596e981db917a8ae9a8af66dcc3a383c432a677bec7bf` | `6def7e652c6e8dcf55b7cf00b6e1a5c8a4df0b596b215812a65220d43acc0de6` |
| semantics              | `8c52a6c01b89804f94140efcdfed6229d3923c055b858fb8a4eac12974d25b00` | `0129d00c471d28edd1edeaf9a93120142c9734d6c24ea98eb30caa092cc61837` |
| mapping table          | `7479d59e3377b7282204a94e2565c2b7a14494bf3ad2681b60303caba6065086` | `0765276981cadc937df0fd2cba67780580755e51e09a8ff55330dbaa816c96c4` |
| producer qualification | qualified                                                          | qualified                                                          |
| opposite qualification | qualified                                                          | qualified                                                          |
| unknown diagnostics    | 0                                                                  | 0                                                                  |

Both full-suite commands exited `1`, which their suite specifications allowed. Qualification establishes evidence integrity, not that every repository test passed.

The comparison document has SHA-256 `6410ba731b71089351b9b15eca5df5e57346666afb3aa3f5a61ec792e19a7a9b`, size `14785`, and reproduces:

- `LifecycleEqual=true`
- `DiagnosticsEqual=false`
- `CanonicalSemanticsEqual=false`
- `RawBytesEqual=false`
- both qualified
- logical fingerprint equal
- zero unknowns
- `AcceptedEqual=false`
- `Outcome=blocked-uncertain`
- exit `1`
- exactly six `+1` and six `-1` entries across six identities

## 2. Exact 12-entry ledger

Evidence shorthand:

- [FRAW](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4/controls/a5-final/03-full-suite-semantic-restoration/stdout.raw)
- [RRAW](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4/controls/a5-fresh/03-full-suite-semantic-restoration/stdout.raw)
- [FSEM](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4/controls/a5-final/03-full-suite-semantic-restoration/semantics.json)
- [RSEM](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4/controls/a5-fresh/03-full-suite-semantic-restoration/semantics.json)

Lines are one-based; byte spans and semantic indices are zero-based and half-open. The private control-root hashes are:

- Final: `cb2b0dcc4a39a0ceb15c09651d896fdfcbcc74258a3befdf9a540f59591899a0`
- Fresh: `f09d8d25d297534641491c93405f714d8e6e790c4590bbc123c6e237bdcef5ec`

For every pair, package, test, occurrence, ordinal, count, classification, and rule are equal. Each semantic record differs only in `text`; all other record fields match.

### Pair 1 — bounded remote command

Identity: `execution-substrate / TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand`, occurrence/ordinal/count `1/1/1`, `recognized-typed-nondeterminism`, `command-result.control-root-v1`, semantic index `233`.

Safe template:

`remote_alpha_operator_test.go:5373: ... listen unix <CONTROL_ROOT>/t.<suffix>/run/spire/server/private/api.sock: bind: invalid argument`

- L1, final-only: suffix `2311322113`; full socket-path SHA `92b20d3fe8d3db1ceba438c56f9305131a15e76624b28d882ab54249c0339e9a`, 115 bytes. FRAW line `2990`, span `[755284,755727)`, line SHA `311b8f2bb751a9e262c80bbee82c3248020610320487d019025ab7fa1abe09c4`, Output SHA `5cd5e6fb911495526408b1f67186aa192bb08347ffa45c91a4f163aeb0baa137`. FSEM `/diagnostics/233`, text SHA `6fa387796019974c713f766d9ee87c53f788f3363476f0474af183394470bcbb`.
- L2, fresh-only: suffix `2232138604`; path SHA `bbee0f272c123da75f94c4ab563e4e9a62f9fd467dc80306ac51216816ccb7a8`, 115 bytes. RRAW line `2990`, span `[755312,755755)`, line SHA `48adfd5ac3ba1751352b74f6529240f5aab28b89f6a443ff31ff43b7a03bd412`, Output SHA `d704176b2f6c089a0bf8e79b5b692cce1430f85d3e4e7e8aa9224e5e9e26d587`. RSEM `/diagnostics/233`, text SHA `7d66a63a36d6da5f8e32dcc6bcf96984ee878badfba81f0b3d22406ecb2c7a44`.

Minimal semantic-text difference: byte `[99,108)`, `311322113` versus `232138604`; the shared leading `2` belongs to both complete suffix captures. L1 and L2 are counterparts.

### Pair 2 — traversal ambiguity

Identity: `execution-substrate / TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection`, `1/1/1`, same classification/rule, semantic index `234`.

- L3, final-only: suffix `1594114553`; path SHA `383c06c0e8b1838167d79d758db42c49291eae97d616ac03eb918ddcc6f6e4cd`, 115 bytes. FRAW line `2995`, span `[756932,757404)`, line SHA `7991ddd443fe5f76999858c9bcf93b1246d18f6436c88cd0a26b5c0fbed10048`, Output SHA `06e7f621d0db768751b282a9fcc1714b24144cf7959e2c70b619d49ec9c4c0e6`. FSEM `/diagnostics/234`, text SHA `4f97a441466ff0c7fc02807135489809f303af2468a1ff1fd6ecc7794a1dda63`.
- L4, fresh-only: suffix `1667269809`; path SHA `26d3c73af86bbbe87fd818c0a5e685b63fa3461eb959426ac27585a14e35474d`, 115 bytes. RRAW line `2995`, span `[756961,757433)`, line SHA `b4b113e3eb471e62f65750ed20b989a76f4813857b38c24e0cda5b1ed87aeb9a`, Output SHA `36d0f2010314cf6f3c2b74bc7bb9ad3240f14f2506efbc28d66d1a6e6de1bd98`. RSEM `/diagnostics/234`, text SHA `ca4464778027d31c5c0547a185c0e4a98ac39fc14a3b188e2f827196a0f3d8eb`.

Minimal difference: `[99,108)`, `594114553` versus `667269809`; shared leading `1`. L3↔L4.

### Pair 3 — accessible bundle-show failure

Identity: `execution-substrate / TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure`, `1/1/1`, same classification/rule, semantic index `239`.

- L5, final-only: suffix `408921568`; path SHA `213a1161e8c4efc32180a586e991a983587bcdce3936d587052419b36802a574`, 114 bytes. FRAW line `3020`, span `[764963,765418)`, line SHA `62e020bbbde3e03f2177e99d9209a0aa46f36cb823d69c078da2a7f264773555`, Output SHA `d6d10c1ac446169484ab7dcf815cd8341222ca81733ea6273ca8216b6205e0d5`. FSEM `/diagnostics/239`, text SHA `283e5564ad2341e05802e38381a6ad4597a37c4bc6c10a09b6050fd8067beeb1`.
- L6, fresh-only: suffix `128057647`; path SHA `4dc07aa2fda7e168fb708208734bea8f48f00a7c569667bdb46bbbee29a4a3f1`, 114 bytes. RRAW line `3020`, span `[764994,765449)`, line SHA `d41ca83c5f13f512b74bb71d12f1029e680d6e425453d25d85c1b1407756449a`, Output SHA `f74f15dec5035af90a3ceecf157afc3e2ebf2e6bdf98c305ea180224fdb19808`. RSEM `/diagnostics/239`, text SHA `ea8d847cb714172fb4650a851932348a61ef8117e2fe4fc35ce2035ae65bbb02`.

Minimal difference: `[98,107)`, the complete suffixes. L5↔L6.

### Pair 4 — prepare-before-helper ordering

Identity: `execution-substrate / TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution`, `1/1/1`, same classification/rule, semantic index `240`.

- L7, final-only: suffix `3295929611`; path SHA `d986e790d247573c08848dbf76d7c8231334ee9f7d8b4b1fbb626ae39773b9c4`, 115 bytes. FRAW line `3025`, span `[766534,766963)`, line SHA `76eef0a2a38550eaec46545ee5182879c19a161d7cccc077e338a34e0182c3bc`, Output SHA `f1792745940fe3b46ba98c999183d301a39c17ae415618253315948bd4b8460f`. FSEM `/diagnostics/240`, text SHA `e47c3ea88df4275a6dbf05bac4e4e8caa73dc957a61ed1b1074e931c8567bc19`.
- L8, fresh-only: suffix `2334180797`; path SHA `c820ff02320874541513be8346eb8a19c6b61c77d0081a906ba7b69ce6fb107b`, 115 bytes. RRAW line `3025`, span `[766565,766994)`, line SHA `4a4d389c6b48806b37e04b0271eb26497ed02eaf08d333b3534a1ea012c37b6e`, Output SHA `0e61fd1486e113e4b46690dd39036cb97b492e65c400c2c0e2358825e0`. RSEM `/diagnostics/240`, text SHA `8081c13aa7730cd8ce44b955b6632838986c62ddc6ddf5950ff3d3e420ebf1a0`.

Minimal difference: `[98,108)`, complete suffixes. L7↔L8.

### Pair 5 — observability sequence

Identity: `execution-substrate/es/api / TestWorkstreamCExecutionCompatibilityRoutesRemainAvailable`, occurrence `1`; comparison entry contains ordinals `[1,2,3]`, each `count=1`, `recognized-typed-nondeterminism`, `observability-inbound-request-complete-v1`. Only ordinal `3`, semantic index `456`, differs; indices `454` and `455` are fully equal.

Shared fixed captures:

- Event: `inbound_request_complete`
- Service: `execution`
- Status: `success`
- Routes, in order:
  1. `GET /v1/executions:contract`
  2. `POST /v1/executions:prepare`
  3. `POST /v1/executions:submit`

Final raw captures:

| OrdinalRaw line/spanLine SHA / Output SHATrace SHA / request SHADuration |                             |                                                                                                                                         |                                                                                                                                         |           |
| ------------------------------------------------------------------------ | --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| 1                                                                        | `6756`, `[1657979,1658420)` | `c7ae7d56b5c44bc2298745acbac68fef9d92fe6433a863123c14ed579f9524a8` / `0cc7da270a47f7980b8690612d4b046a197dc03e49ba618e94e46aba10462ef8` | `b6cb8f36ddaf0c4f4d4c657c4025e33b2558c29b7c886be48d19300393b193a8` / `af04caad1da834a3453396dab5a1013706071ab6f9a4bd0f0584708ff7b5989a` | `2.583µs` |
| 2                                                                        | `6757`, `[1658420,1658861)` | `dabe4bf6ad8f64f6e97c77389f6ec2baff27288346dcd3e451506e0114bcdead` / `8e1c11542d56d5d1cbf8232180ad68f92fd7df4ed730c2e89b60dcf0c2054444` | `edc18cea23e1c1e340f4dde40856bc4f4ccc75df2baa2f78704a35b896cc45d4` / `17a469f8594b2bacfe0b36522b6e8738ba48fc549f0ce05c34a24d8f00c99846` | `6.625µs` |
| 3                                                                        | `6758`, `[1658861,1659299)` | `2a52086678bf77212d4c2bf9f0be9d1636e78f40d8a2f8617ccf08877cb75880` / `1fa4c05e007eeb9fe5583b81e5570fc8190f34c5406c0e8c449893ca871cfab3` | `e4f366669696f1f70782b675d5389e589174a986dc5ace4d2db8dd290f59709d` / `b53c8d7d2587018c2306c3a40349b26f77c84e93663a9de29f047d08ee647d84` | `3.5µs`   |

Final log-timestamp hash for all three: `bb8ec613e8648d419a8e8bd92c965146c1c7caa6e0bbdb0655a763fd7e3b86e9`.

Fresh raw captures:

| OrdinalRaw line/spanLine SHA / Output SHATrace SHA / request SHADuration |                             |                                                                                                                                         |                                                                                                                                         |           |
| ------------------------------------------------------------------------ | --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| 1                                                                        | `6756`, `[1657992,1658433)` | `3c861633e80a03ba4b9d4ea1e10cacc2ebdd03246666235503868614c0e8e62e` / `758646e78cd138cd433e4c4209248cb02a55494378c4b6ef140d3fea93d50b5b` | `f5aee5a25b757f66d1b62998d7f9bacba66f073c335bf873006dc765807d9472` / `556cfd90b525090b1b09c9d0cdc7f23f87ae2df82340fabd8f228287ab90d906` | `3.333µs` |
| 2                                                                        | `6757`, `[1658433,1658874)` | `22e46fe99248b7a2ffc40368658d681ceb0d960af245eacfae32b0d620baf9aa` / `12daf77f87a9f2236c6b6cd9ce65e90c03d5753c7064fffe8d919dafcd913aa8` | `0c43cba65e68440b77c8702cc4c846c2107a18e114ded043bffc924b949852a4` / `5dbf851b078bc592413d557338db1481405a2324d015ebcfa3cefa99617f4fc1` | `8.334µs` |
| 3                                                                        | `6758`, `[1658874,1659313)` | `5a040e7d938d2222caf9d34bd205dc5529e19d2cf67e1852dd16f1a66aeb751c` / `b009259caf617851cb76e5e8dff0d8019c2038dfbf5a16a873ffbbad3d4feb92` | `a3ce3ef61ae64c141dedc101f555a99cd5d77b25dc557c002a25dcde78d79425` / `65f6351fd77b95144677bc0cd9aff5bfc6f41dc20b0d55af303d4b11f71c13de` | `3.333µs` |

Fresh log-timestamp hash for all three: `423a51e0c79824adfda68b8113fbead8ec7e74042465ffb5c8ed64bf5e48687b`.

- L9, final-only: FRAW composite span `[1657979,1659299)`. Canonical duration topology is `1,2,3`. FSEM `/diagnostics/456`, text SHA `47186b6280eba62f46d3eac53909ddb3f6a53cc0d5a43879d54050ccf9003305`.
- L10, fresh-only: RRAW composite span `[1657992,1659313)`. Canonical duration topology is `1,2,1`. RSEM `/diagnostics/456`, text SHA `52216adb74ede63395cf1bdf0330a3a0a6ffe2ed3d4a4f5c3b8b5990d947b878`.

Minimal semantic difference: byte `[262,263)`, `<OBSERVABILITY_DURATION:3>` versus `<OBSERVABILITY_DURATION:1>`. L9↔L10.

### Pair 6 — runtimehelper source socket

Identity: `execution-substrate/es/runtimehelper / TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir`, `1/1/1`, `recognized-typed-nondeterminism`, `command-result.control-root-v1`, semantic index `519`.

Safe template:

`supervisor_test.go:27: listen on source socket: listen unix <CONTROL_ROOT>/t.<suffix>/internal/source/api.sock: bind: invalid argument`

- L11, final-only: suffix `257155197`; path SHA `e8a91700d7aa1faebe6864d94365bb2e86cc5f4d50a1623e43fa3ebfd47e2c7b`, 105 bytes. FRAW line `12798`, span `[3229730,3230129)`, line SHA `85f2f8ed27a667008e84cd4f1b43cee050ca907c8d866d80437bd221e07bd106`, Output SHA `f6820198469e48947035f9152c11c634a3d68df94f610a1a94a948549dbc0872`. FSEM `/diagnostics/519`, text SHA `a09d0d85f7fc563f0bbf708e15e15b86b24832222b9f63a990aea821fcc428bd`.
- L12, fresh-only: suffix `732363521`; path SHA `efd105c4dded888dbc66b200867dfe89b29434f9d5df6fcae7e1189daec3319a`, 105 bytes. RRAW line `12798`, span `[3229714,3230113)`, line SHA `648d2875cb5895ca38898df9a315b5e158eb711e024a228b58431a37dfa45591`, Output SHA `3905ab6a7591f4c4aad0239078271dc757368de61e71ecc82d8ad14eca213516`. RSEM `/diagnostics/519`, text SHA `864d3b9d656bb6125726733e303ba4503731ff2211513adc2832fcc2e5779b81`.

Minimal difference: `[81,90)`, complete suffixes. L11↔L12.

The raw JSONL envelopes additionally contain different observation times and private roots. Therefore raw-line equality outside the described fields is not claimed. At the semantic-record level, the stated lexical span is the complete difference.

## 3. Six-test source and generator map

| TestGenerator and intended assertionResult and classification |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |                                                                                                                                                                                                                                                     |
| ------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Bounded remote command                                        | [test call (line 5365)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:5365>) → `createFakeBootstrapSpireSocket` at [5098 (line 5098)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:5098>) → `net.Listen("unix", …)` at 5104. Intended to prove the bounded remote SPIRE command, ACL handling, redaction, and no helper execution.                                                                                                                   | `run/fail` on both, lifecycle ordinals `1368/1369`. Repository test nondeterminism/incorrect fixture. Product route never reached. Test bytes must change; production and successor bytes must not conceal it.                                      |
| Traversal ambiguity                                           | [test call 5482 (line 5476)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:5476>) through the same helper. Intended to distinguish traversal denial using sudo-visible inspection and apply only bounded ACLs.                                                                                                                                                                                                                                                                                                         | `run/fail` on both, `1370/1371`. Same repository-test classification.                                                                                                                                                                               |
| Accessible bundle-show failure                                | [test call 5680 (line 5678)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:5678>) through the same helper. Intended to classify the forced `spire-server bundle show` failure without leaking raw stderr/material.                                                                                                                                                                                                                                                                                                     | `run/fail` on both, `1380/1381`. Same repository-test classification.                                                                                                                                                                               |
| Prepare before helper                                         | [test call 5731 (line 5713)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:5713>) through the same helper. Intended to prove summary/config/SPIRE preparation precedes staging and helper execution.                                                                                                                                                                                                                                                                                                                   | `run/fail` on both, `1382/1383`. Same repository-test classification.                                                                                                                                                                               |
| Compatibility routes                                          | [test 1131 (line 1131)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/api/server_test.go:1131>) calls the handler at 1158, 1165, and 1181. [Handler (line 53)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/api/server.go:53>) wraps the mux with observability. [WrapHandler (line 75)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/internal/observability/observability.go:75>) generates IDs, starts `time.Now`, and emits `time.Since(...).String()` at line 106. | `run/pass` on both, `3150/3151`. Primary classification: validation-construction nondeterminism. Raw timing variation is semantically acceptable production nondeterminism; product and test bytes need no correction. Successor bytes must change. |
| Runtimehelper stable alias                                    | [test 13 (line 13)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/runtimehelper/supervisor_test.go:13>) constructs `internal/source/api.sock` and calls `net.Listen` at 25. Intended to reach [materializeHelperPrivateSPIRESocket (line 592)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/runtimehelper/supervisor.go:592>) and verify the stable symlink target resolves to a socket.                                                                                                                   | `run/fail` on both, `6140/6141`. Repository test nondeterminism/incorrect fixture. Production function is never called. Only test bytes need change.                                                                                                |

`createFakeBootstrapSpireSocket` uses `t.Helper()`, explaining why diagnostics are attributed to the four caller lines rather than its internal fatal line 5106.

The common allocator chain is:

`setupFake…` → `testsupport.NewControlRoot` → `AllocateControlDir("t.")` → `os.MkdirTemp(controlRoot, "t.")`.

See [controlroot.go (line 30)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/internal/testsupport/controlroot.go:30>) and [controlroot.go (line 106)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/internal/testsupport/controlroot.go:106>). The pinned Go implementation obtains a `uint32(runtime_rand())` and formats it base-10. Thus the suffix grammar is 1–10 canonical decimal digits, with no leading zero except the value `0`. Equal suffixes across independent controls are possible by chance but never required.

## 4. Socket-path analysis

All five socket differences share these facts:

- They are Unix stream listener paths, not ordinary files or successful endpoints.
- They are beneath the registered control root.
- They are not beneath `TMPDIR` or `GOTMPDIR`.
- `t.TempDir()` is used elsewhere in the remote harness for local binaries/logs, but not for these socket paths.
- The random component comes from `os.MkdirTemp(controlRoot, "t.")`.
- Endpoint roles, address family, path-component topology, containing-root role, basename, operation, errno text, and failed-listen result match pairwise.
- Remote tail: `run/spire/server/private/api.sock`.
- Runtimehelper tail: `internal/source/api.sock`.
- Every path exceeds the documented 100-byte bound: remote `114–115`, runtimehelper `105`.
- `net.Listen` fails with bind `EINVAL`; no listener is returned, no connect occurs, and listener-specific cleanup is not registered.
- Collision and rebind behavior are not exercised on either side and therefore are not proved equal.
- The registered `ControlRoot` cleanup still completes. Both retained terminal reconciliations report completed outcome, one terminal, disposed owners, joined workers, released endpoints, two fresh-zero observations, and an empty next-command barrier.
- The logical `/run/spire/server/private/api.sock` and `api.sock` role are material. The private absolute prefix and random suffix are not. Absolute overlength is not the intended assertion, but satisfying the bounded socket-path contract is mandatory.

The repository already provides the correct primitive: [ControlRoot.ShortDir (line 70)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/internal/testsupport/controlroot.go:70>) creates a direct `TMPDIR` child and rejects complete socket paths over 100 bytes. This matches [PLANS.md (line 1994)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:1994>) and [artifact\_hygiene.md (line 316)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md:316>).

Existing canonicalization does not cover the residual suffix:

- `command-result.control-root-v1` replaces only the registered root.
- `go-testing-tempdir-parent-v1` requires exact `<CONTROL_ROOT>/gotmp/...` templates.
- These paths contain `<CONTROL_ROOT>/t.<suffix>/...`.
- No typed socket grammar exists.

Adding a canonicalization rule for these errors would be unsafe. It would preserve five tests as identically failing before their actual assertions and would erase the only visible distinction between two instances of an invalid fixture.

## 5. Observability and correlation analysis

The mapping tables contain only source-root and control-root mappings. Timestamp, trace ID, request ID, and duration are not registered mappings; A5S generates their tokens internally in `canonicalizationStateV1`.

The sequence topology is:

- Three events on both sides
- Same event, service, route, status, order, package, test, and occurrence
- Timestamp topology: one repeated timestamp per side
- Trace topology: three distinct trace IDs per side
- Request topology: three distinct request IDs per side
- Duration topology:
  - final: three distinct values → tokens `1,2,3`
  - fresh: first equals third → tokens `1,2,1`

The implementation at [semantic.go (line 194)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/envelope/semantic.go:194) keys all tokens by raw value. At [semantic.go (line 670)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/envelope/semantic.go:670), duration is therefore treated like an identity-correlation field.

That is the defect. Trace/request equality topology is contractually meaningful; equality between two incidental execution durations is not. The observability contract requires the duration field but does not require equal operations to measure equal, nor different operations to measure differently. The test passed on both sides, and exact duration equality is possible but not required.

Frozen successor rule:

- Rule ID: `observability-inbound-request-complete-v2`
- Scope: package `execution-substrate/es/api` and exactly the existing 29-name allowlist at [semantic.go (line 636)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/envelope/semantic.go:636); no new package, test, or subtest.
- Complete syntax remains the existing anchored, field-ordered grammar:
  - timestamp `YYYY/MM/DD HH:MM:SS`
  - event exactly `inbound_request_complete`
  - trace ID exactly 32 lowercase hex
  - request ID exactly 16 lowercase hex
  - service exactly `execution`
  - quoted route without quote/backslash
  - status exactly `success|client_error|server_error`
  - positive canonical duration using `ns|µs|ms|s`
  - exact newline and no appended text
- Timestamp, trace ID, and request ID remain raw-keyed within package/test/occurrence scope.
- Duration becomes diagnostic-position keyed: `<OBSERVABILITY_DURATION:<ordinal>>`, not raw-duration keyed.
- Route, status, event, service, field order, count, ordering, package/test occurrence, trace/request alias topology, lifecycle, and terminal state remain material.
- Partial, malformed, wrong-package, wrong-test, unsupported-status, zero/noncanonical duration, altered field order, or appended text remains unknown/blocking.

Because the duration semantics genuinely change, retaining the `v1` rule ID would misstate provenance. No generic duration canonicalization is authorized.

## 6. Material versus control-local adjudication

| EntriesPrimary classAdjudication |                                                     |                                                                                                                                                                                            |
| -------------------------------- | --------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| L1–L8, L11–L12                   | Repository test nondeterminism or incorrect fixture | The suffix is private control-local data, but the diagnostic exists only because an overlength socket path prevents the intended test. The failure is material and must not be normalized. |
| L9–L10                           | Validation-construction nondeterminism              | Raw duration variation is semantically acceptable production nondeterminism. A5S incorrectly encodes duration equality as identity topology.                                               |
| None                             | Production behavior difference                      | No such difference was found.                                                                                                                                                              |
| None                             | Unresolved                                          | All 12 entries have a source-grounded classification.                                                                                                                                      |

## 7. Frozen repair class

The next repair is necessarily two-stage:

1. Repository test repair for the five socket fixtures.
2. Successor semantic amendment for observability duration handling.

The socket repair should use compact actual listener paths while retaining material logical roles:

- Remote harness: allocate the actual `api.sock` using `ControlRoot.ShortDir("api.sock")`; keep the logical fake-remote path `/run/spire/server/private/api.sock`; bind the short physical socket and expose it to the fake remote path with a test-owned logical indirection; clean both physical and logical paths.
- Runtimehelper test: retain `internalDir` under `ControlRoot.Dir()`, but allocate `spireSourceDir` with `ShortDir("api.sock")`, bind its `api.sock`, and then call the unchanged production materializer.

Any need to change production code, broaden the helper contract, or normalize socket failures is a stop-and-readjudicate condition.

## 8. Exact touched-file recommendation

Repository test repair:

- [remote\_alpha\_operator\_test.go](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go>) — current SHA `ec3ff21ffabee06711fb85d1794758f01b14e59b61b901263ee17db14bcb67c5`
- [es/runtimehelper/supervisor\_test.go](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/runtimehelper/supervisor_test.go>) — current SHA `1d798d53b5aacf7ba18ecfb7d1a988f922e5a33bdb7a0003c2078644fab2d841`

Follow-on successor amendment:

- [FORMAT.md](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/FORMAT.md) — `c001441752c6bd8af519c90b946e6e8359c9b25bfa7bd6a4ea9895f846258ec3`
- [semantic.go](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/envelope/semantic.go) — `0ebf04c0cc8a9f22d1ddc2d876fd23d37b8169fdf39974bc3ccf9474d0785933`
- [envelope\_test.go](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4/tool/source/envelope/envelope_test.go) — `092756bb0f6b13b90bae2b446656d77b739433289c576eb22bcfad82acc343ba`

Not required:

- `internal/testsupport/controlroot.go`
- repository production source
- `envelope/runner.go`
- `envelope/source.go`
- semantic or comparator CLI
- `PLANS.md` or `.docs/`—the existing documents already require compact socket paths
- public or private acceptance-schema changes

## 9. Causal test matrix

Repository positives:

- All four exact remote tests pass under independently long control roots and reach their named assertions.
- The runtimehelper test reaches `materializeHelperPrivateSPIRESocket`, verifies the exact link target, and verifies socket mode through the alias.
- Every actual bound socket is under owned `TMPDIR`, has its fixed role/basename, and has a complete path of at most 100 bytes.
- Logical remote logs and assertions retain `/run/spire/server/private/api.sock`.
- `TestRepair10ControlRootPolicyV1` and `TestRepair10ValidationIsolationASTV1` remain passing.
- Cleanup proves listener close, logical/physical path removal, and two absence observations.

Socket negatives:

- Exactly 100 bytes is admitted; 101 bytes is rejected before `net.Listen`.
- Wrong package/test context receives no semantic normalization.
- Wrong endpoint role, containing-root role, logical prefix, basename, address family, or path topology remains visible.
- A reused live socket path produces visible collision failure.
- Rebind is accepted only after close/removal.
- Altered errno, operation, appended text, or partial text remains material.
- Missing parent, missing socket, wrong type, and multiple-source-socket tests remain fail-closed.
- No generic `/tmp`, socket, control-root descendant, or decimal-suffix rule is introduced.

Observability positives:

- The retained final and fresh three-event sequences canonicalize identically under `v2`.
- Fresh ordinal 3 becomes `<OBSERVABILITY_DURATION:3>` despite its raw duration equalling ordinal 1.
- Timestamp and trace/request equality topology remain unchanged.
- Re-extracting the retained streams removes only the observability comparison pair; the ten socket-sided entries remain material. The retained streams must not become accepted-equal.
- Per-side lifecycle and terminal content is unchanged by semantic re-extraction.
- No diagnostic outside the exact existing observability allowlist changes, aside from the deliberate `v1`→`v2` rule identity within that allowlist.

Observability negatives:

- Independently mutate route, status, event, event count, event order, trace/request equality topology, missing or extra correlation, package/test occurrence, sequence length, or pass/fail/skip terminal.
- Each remains visible or blocking.
- `0s`, leading-zero, signed, malformed-unit, missing-duration, reordered-field, extra-field/text, uppercase-ID, wrong ID length, and partial records remain unknown.
- Equal and distinct valid duration values both canonicalize by diagnostic position; duration grammar and presence remain material.

Historical/tool nonregression:

- Re-extract HEAD and Repair 9 using the new rule and adjudicate every legitimate `v2` application separately.
- Preserve A5S’s exact line-1706 rule and its `134217728` bound.
- Preserve wrong-line, wrong-template, and overbound blocking tests.
- Preserve final/fresh and mutant tool causals where inputs do not contain the changed grammar.
- A postrepair final↔fresh run must have both controls independently qualified, lifecycle/diagnostics/canonical semantics equal, zero unknowns, accepted equality true, qualified-equal outcome, and exit zero.

## 10. Schema and version disposition

No JSON schema identifier needs to change. The suite, result, qualification, semantic, comparison-specification, comparison-result, and custody shapes remain unchanged.

The canonicalization rule identifier must change to `observability-inbound-request-complete-v2`. New source T/inventory and binary identities are required naturally after the successor source changes.

## 11. Evidence carry-forward and restart

Because repository bytes must change:

- Sealed A5 remains immutable historical predecessor evidence only.
- Its T/inventory cannot represent the repaired repository.
- The two retained A5 controls remain valuable negative causal fixtures for the socket and observability tests.
- They cannot establish postrepair final↔fresh acceptance.
- Sealed A5S remains immutable predecessor lineage, not the final corrected tool.
- The current unsealed refresh child must never be resumed or sealed.
- After the repository test repair and successor amendment are sealed, the complete two-control policy-evidence refresh must restart from independently materialized controls with the new repository T/inventory and new successor binaries.
- Directional HEAD/final and Repair-9/final comparisons, mutant comparisons, qualification, cleanup, and subsequent validation must be regenerated against that new lineage.

## 12. Limits and nonclaims

- No test or build was executed, so the proposed compact-path/indirection layout remains implementation work requiring targeted proof.
- The socket diagnosis is source-grounded by five over-100-byte paths, identical `net.Listen("unix")` EINVAL failures, and the repository’s explicit 100-byte contract. No live socket probe was performed.
- The five failing tests provide no evidence about the product behavior they intended to exercise because they stop in fixture setup.
- Qualified controls do not imply a passing repository suite.
- `LifecycleEqual=true` is comparator-level equality. The complete cross-side lifecycle arrays are not claimed byte-identical because permitted cross-package scheduling order differs.
- No A6, B6, product A/B, capture, handoff, ZIP, or independent-audit claim is made.

## 13. Read-only confirmation

No file, cache, bytecode, `__pycache__`, `.pyc`, scratch object, temporary JSON, report, source copy, snapshot artifact, evidence child, successor child, test output, or build output was created. No repository, A5, A5S, or failed-child byte changed. No subagent was created or used. Nothing was staged, committed, pushed, installed, remotely contacted, or executed through a live route or Linux binary.
