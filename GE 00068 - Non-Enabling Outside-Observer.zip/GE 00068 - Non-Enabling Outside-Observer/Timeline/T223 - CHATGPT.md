## Assessment

This is the **right repair**, and the reported implementation is ready for the required fresh audit.

It closes the blocker at the correct layer:

- **No repository byte changed.**
- The predecessor evidence capsule remains immutable.
- The correction supersedes only the two defective deltas and their associated identity/report claims.
- Both new builders independently produced the same corrected delta.
- The result matched the audit’s independently predicted SHA-256:
  `0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1`.
- The old and corrected deltas differ in exactly **three mode fields / six bytes**.
- A third implementation, sharing no parser/helper with either builder, validated reconstruction and rejected ten targeted corruptions.
- The new capsule’s two manifests cover every directory and every nonmanifest file, with only the two manifests self-excluded.
- Closing checks report the repository, predecessor capsule, and blocking-audit root unchanged.

There is no visible reason to return to implementation or touch the governance contract again. I have not independently inspected the correction capsule, so this is not an audit verdict.

The only remaining critical path is:

> **fresh read-only audit of the unchanged repository target plus the new correction capsule**

That separation is required: implementation closeout is audit input, not independent correctness assessment.  After any repair to blocking evidence, the project protocol requires new provenance followed by a fresh audit. 

## Fresh independent-audit prompt

Send the following to a new **read-only Codex conversation**.

```text
MANDATORY PRIMARY VERDICT

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Embed the complete audit report inline in Markdown. Evidence paths may
supplement the report but must not replace it.

This is a fresh independent audit. Do not repair, edit, format, normalize,
chmod, clean, stage, commit, push, install, deploy, invoke live services, or
contact a network.

## 1. Objective

Independently audit the combined Repair 10I A6 successor-governance target:

1. the unchanged seven-path repository governance implementation;
2. its immutable predecessor implementation-evidence capsule;
3. the fresh source-external mode-provenance correction capsule;
4. the blocking audit that identified PARENT-EVID-001.

Determine whether the sole blocking defect is closed:

The predecessor “complete” repair-only deltas encoded evidence-custody mode
`100600` as logical before-mode for three repository files whose authenticated
repair-opening logical mode was `100644`.

The new correction claims to change exactly those three fields—six bytes
total—while preserving every path, payload byte, size, hash, after-mode,
delimiter, ordering, length, and terminal byte.

Do not reopen or redesign the governance contract merely because a prior audit
was BLOCK. Distinguish:

- unchanged repository implementation facts;
- immutable predecessor evidence;
- superseded defective provenance artifacts;
- new correction evidence;
- audit-owned inference.

An ACCEPT verdict applies to the exact combined target. It does not authorize
staging, commit, push, semantic-successor implementation, orchestrator
implementation, or A6 execution.

## 2. Exact roots

CANDIDATE_R:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

PREDECESSOR_REPAIR_EVIDENCE:

  /Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

CORRECTION_ROOT:

  /Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-repair-fsgu2x8c

BLOCKING_AUDIT:

  /Users/ds/Downloads/repair10i-a6-governance-independent-audit-5n5vkzxr

Allocate a fresh audit root with Python `tempfile.mkdtemp` under:

  /Users/ds/Downloads

using a prefix containing:

  ES-repair10i-a6-governance-mode-provenance-independent-audit-

Use umask `077`. Do not choose a fixed suffix, rename an existing directory, or
reuse an earlier audit root.

## 3. Audit posture and process boundary

The parent alone may:

- run read-only Git commands;
- create audit-owned evidence beneath the fresh audit root;
- run audit-owned parsers and mutation fixtures beneath that root;
- run isolated, non-mutating validation when explicitly required below.

Audit subagents:

- are read-only;
- run no Git;
- write no files;
- invoke no tests, builds, verifier, caller, product route, or network;
- create no nested subagents;
- report exact operands and actual cwd;
- distinguish evidence, inference, and uncertainty.

Every repository Git command must use:

  git -C "$CANDIDATE_R" ...

with cwd exactly CANDIDATE_R and:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

No Git command may target:

- the primary checkout;
- PREDECESSOR_REPAIR_EVIDENCE;
- CORRECTION_ROOT;
- BLOCKING_AUDIT;
- the fresh audit root.

Do not reconstruct a missing contemporaneous process record after the fact.
Preserve failed or superseded audit-owned attempts separately.

## 4. Opening provenance gate

Complete this gate before correctness inspection.

### 4.1 Repository identity

Require:

- physical root:
  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
- device/inode:
  16777234 / 122118502
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed objects:
  389
- tracked/untracked:
  375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- directories:
  93
- source T:
  f276536fea579d0842cda43b0290656b200b7f27
- inventory size:
  54,314 bytes
- inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

Require the exact seven final path identities reported by the implementation:

- PLANS.md
  - logical mode 100644
  - 288,739 bytes
  - f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f
- .docs/system_overview/configuration.md
  - 100644
  - 129,589
  - f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3
- .docs/system_overview/boundaries.md
  - 100644
  - 96,086
  - 0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd
- .docs/system_overview/artifact_hygiene.md
  - 100644
  - 38,322
  - 2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910
- .docs/system_overview/capability_probing.md
  - 100644
  - 42,668
  - f177f939932e21e8d53fe521aad9386253e330527b6a85eeb73c0888b1acdeb2
- .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
  - 100644
  - 99,195
  - 18cfad593028ea25575d5e9593d95533cbda6400bba52897bba8a9ae4f17f32d
- docs_contract_test.go
  - 100644
  - 794,256
  - e43d41791758e6e8ebf2e7fe585e7469f342d9eb3013171cc76bece662f02684

### 4.2 Predecessor evidence

Require:

- device/inode:
  16777234 / 177742499
- 10 directories and 98 regular files;
- all directories mode 0700;
- all files regular, single-link, mode 0600;
- no symlink, special object, empty unexplained directory, or extra path;
- inventory size/hash:
  14,380 bytes /
  0036cb2e461a66c94fd29f9cde71fc9c51d2ceceddca0d2f6da421396d4ac2ac
- two byte-identical manifests:
  - 19,136 bytes
  - 1c07db3979d02afcf7852c6c4819630046950712426a267a4117a6774c28b751
- both predecessor deltas:
  - 2,474,094 bytes
  - 641612e748d2764d7a78d066d73b788fbc30b527b3088723a73d4dd8ac771021

### 4.3 Blocking audit

Require:

- device/inode:
  16777234 / 177779617
- 4 directories and 86 regular files;
- inventory size/hash:
  11,720 bytes /
  f64183e7bc5bc731afd291d2e773e2f0062796942a5eeff58918863fb3b37cac
- no opening-to-audit drift.

The prior blocker supplied to this audit is:

PARENT-EVID-001 / A3-PROV-001 / A4-EVID-001

The authenticated repository opening mode for each repaired path was `100644`,
but both predecessor deltas encoded logical before-mode `100600` because their
builders used `lstat` on private mode-0600 evidence copies.

The independent audit predicted that changing exactly those three fields would
preserve size 2,474,094 and yield SHA-256:

  0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1

Treat that digest as an audit cross-check, not as construction authority.

### 4.4 Correction capsule

Require:

- physical root:
  /Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-repair-fsgu2x8c
- device/inode:
  16777234 / 177842688
- root mode:
  0700
- 7 directories including root;
- 43 regular files;
- no symlink or special object;
- no empty or unexplained directory;
- every directory mode 0700;
- every file regular, single-link, mode 0600;
- exactly two self-excluded manifest files;
- 41 nonmanifest files represented;
- 48 represented entries total.

Require both manifests to be byte-identical:

- size:
  8,590 bytes
- SHA-256:
  d7a0c0f376c1a52c2b9b6cdc2b64d43ce9cd2235602b71a2e15552746f6f7cde

Require these exact correction identities:

- corrected delta A:
  2,474,094 bytes
  0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1
- corrected delta B:
  same size and hash; byte-identical to A
- corrected delta identity:
  1,798 bytes
  d8682902a3f678a13502b693b1a90d2c309a32df6e23e965ac9973ae8c95ea6e
- authoritative supersession record:
  3,870 bytes
  adb479a081cd8723be1842551a4b27e5ed3cdf4cec0dcd4a48dd47b3972c8495
- Builder A source:
  7,982 bytes
  8ffc4a85e6fe5765d36e9b2dc291fe742d42e673c394893b949758bd88cce65c
- Builder B source:
  9,856 bytes
  16ff8dca1f481030834f84fbd18fc8443fcf67d4c04f6b275f4686891a1ae771
- independent validator source:
  21,071 bytes
  6a16ddc6f845cbf3a32f73456b3a57461e2ac2ce1ab894e67373411c2bcf558f
- validator positive result:
  2,741 bytes
  66e75ad31fc9bd486b40331b31a681600849836747d566f2fb372d1fbe80bd6c
- negative matrix:
  2,769 bytes
  974f7533ea4558b1e5c6936f104acf2238a2b948e22c0faa438788e389ab7f7d
- failed-attempt index:
  1,096 bytes
  3f8b48ad905c2dc484f60f50370cdb98317826c889f82f19c9d87b853b895079
- final report:
  16,288 bytes
  1a79fab0360a9a56b6b6cf832eaab640b4c4f4f95582361c09205facf42dc07b

Stop with AUDIT_PROVENANCE_MISMATCH on any opening mismatch. Do not continue
correctness inspection after a failed opening gate.

## 5. Independent perspectives

After the opening gate passes, start exactly three read-only auditors
concurrently. After the first closes, start the fourth. Allow one start retry.

Give all four the same repository identity, predecessor delta identity,
correction identity, prior blocker, current/target classification, and
non-goals.

### Auditor 1 — Delta semantics and reconstruction

Inspect:

- authenticated repair-opening and final inventories;
- predecessor deltas;
- corrected deltas;
- both builders;
- byte-difference record;
- delta identity.

Determine whether the corrected delta represents the actual repository
before/after modes and bytes.

### Auditor 2 — Builder and validator independence

Inspect:

- both builder implementations;
- independent validator;
- positive result;
- negative-mutation matrix;
- failed/superseded attempts.

Determine whether the two builders are materially independent and whether any
shared helper, hard-coded correction, audit digest, or custody-mode inference
predetermined the result.

### Auditor 3 — Supersession, authority, and lineage

Inspect:

- authoritative supersession record;
- final report;
- predecessor identities;
- blocking-audit inputs;
- current governance authority boundaries.

Determine whether the correction supersedes only the defective logical-mode
provenance and does not rewrite repository correctness, contract authority,
validation, or historical evidence.

### Auditor 4 — Filesystem, artifact, security, and capsule closure

Inspect:

- complete correction-root membership;
- modes, links, types, sizes, hashes;
- manifest generators and checker;
- cleanup and two absence records;
- opening/closing supplied-root comparisons;
- process/descriptor closeout.

Determine whether the new capsule is immutable, private, complete, and free of
unexplained or unauthenticated objects.

Auditors run no Git, tests, builders, validators, or writes.

## 6. Parent-owned independent delta audit

The parent must independently implement an audit parser/reconstructor. It may
not import or call either producer builder or the producer validator.

### 6.1 Parse and authenticate the predecessor defect

Verify for exactly:

- `.docs/system_overview/capability_probing.md`
- `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
- `docs_contract_test.go`

that:

- authenticated opening logical mode is `100644`;
- predecessor before-mode is `100600`;
- predecessor after-mode is `100644`;
- before and after sizes and hashes match their inventories;
- complete embedded before and after payloads match those hashes.

### 6.2 Parse and authenticate the correction

Verify:

- corrected before-mode is `100644` on all three paths;
- corrected after-mode remains `100644`;
- corrected before/after payloads match authenticated inventories;
- reconstructing from opening produces the exact final files and modes;
- no fourth path appears;
- no authorized path is missing;
- ordering and grammar match the predecessor format.

### 6.3 Exact predecessor-versus-corrected byte comparison

Require exactly:

- three fields changed;
- six bytes changed;
- no length change;
- no payload-byte change;
- no path/order change;
- no size/hash change;
- no after-mode change;
- no delimiter or terminal-byte change.

Verify the reported zero-based offsets:

- 156 and 157;
- 114,209 and 114,210;
- 376,748 and 376,749.

Do not treat the offsets as authority; derive them independently and compare.

### 6.4 Independent corrected-delta identity

Independently hash the validated corrected bytes and require:

  0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1

A different independently derived result is BLOCK or
AUDIT_PROVENANCE_MISMATCH according to whether bytes or opening identity
differ. Do not alter bytes to obtain the expected hash.

## 7. Builder-source review

For each builder, establish exactly how it obtains:

- path order;
- logical before-mode;
- logical after-mode;
- before payload;
- after payload;
- size;
- SHA-256;
- canonical output grammar.

Require:

- before-mode originates from the authenticated repair-opening inventory;
- after-mode originates from the authenticated final inventory;
- live final logical mode is independently checked;
- neither builder uses physical mode of the predecessor evidence copy;
- neither builder uses physical mode of a correction-root copy;
- neither builder hard-codes `100644` only for the three named paths;
- neither builder reads the audit-predicted corrected hash before output;
- neither builder shares a mode-source or delta-parser helper with the other.

Source-language difference alone is not sufficient evidence of independence.

## 8. Independent mutation matrix

Create audit-owned copies under the fresh audit root and independently test at
least:

1. one before-mode restored to `100600`;
2. one before-mode changed to `100755`;
3. one after-mode changed;
4. one before hash changed;
5. one after hash changed;
6. path ordering changed;
7. unauthorized path added;
8. authorized path removed;
9. before payload byte changed;
10. after payload byte changed;
11. custody mode substituted for all three logical modes;
12. one extra trailing byte;
13. one truncated byte.

Require mechanism-specific nonaccepting reasons. Do not modify supplied files.

## 9. Supersession adjudication

Require the authoritative supersession record to:

- bind exact predecessor root/path/size/hash;
- bind exact successor root-relative path/size/hash;
- state the precise mode-provenance defect;
- classify predecessor deltas and their identity/report claims as nonqualifying
  for logical-mode provenance;
- preserve predecessor repository bytes, tests, validation, authority block,
  and unrelated evidence;
- preserve the predecessor capsule as immutable historical input;
- name the correction capsule as sole current writer for the corrected
  repair-delta identity;
- avoid granting product, runtime, execution, readiness, commit, publication,
  or orchestration authority.

Reject silent replacement, deletion, rewriting, or broad reclassification of
the predecessor evidence.

## 10. Repository implementation re-binding

The repository implementation bytes were not changed by this repair.

Independently confirm:

- the exact seven-path final target;
- the complete current contract block and its sole-writer/reference posture;
- the repaired allocation and orchestration fields remain present;
- the exact 33 documentary mutations remain represented in
  `docs_contract_test.go`;
- no product source or public schema changed.

Fresh repository test execution is not required solely because source-external
evidence changed. Review the prior blocking audit’s exact validation results
and bind them to the unchanged seven path hashes.

The parent may run only these non-mutating checks if needed to resolve
uncertainty:

- pinned focused `TestRepair10IA6SuccessorGovernanceContract`;
- pinned `gofmt -d docs_contract_test.go`;
- rooted `git diff --check`.

Any test run must use private audit-owned TMPDIR, HOME, GOCACHE, GOMODCACHE,
and GOTMPDIR, with offline Go settings. Do not install or download anything.
A test-created repository artifact is an immediate BLOCK.

## 11. Capsule closure and disclosure

Independently verify both correction manifests, without using the producer
membership checker, against the physical root.

Require:

- exact 7-directory set;
- exact 43-file set;
- exact 41 represented nonmanifest files;
- exact two manifest self-exclusions;
- no unrepresented file or directory;
- no absent represented path;
- no empty directory;
- no symlink, FIFO, socket, device, database, cache, bytecode, lock, journal,
  or unsupported object;
- directories 0700;
- files regular, single-link, 0600;
- final report included in manifest coverage;
- no raw secret, credential, private key, bearer token, API key, TLS/SPIFFE/
  Vault material, payload dump, or unrelated private endpoint.

Do not expose sensitive matching material. Report classifications only.

## 12. Closing provenance

After audit-owned cleanup:

- re-enumerate CANDIDATE_R;
- re-enumerate PREDECESSOR_REPAIR_EVIDENCE;
- re-enumerate CORRECTION_ROOT;
- re-enumerate BLOCKING_AUDIT;
- recheck repository Git identity, status, staging, operation markers, and
  locks;
- require exact equality with opening;
- require audit private temporary roots removed;
- record two fresh absence observations when a private generated-state root was
  removed;
- require no audit-owned child, process, or descriptor survivor.

Do not mutate a supplied root to obtain closing equality.

## 13. Acceptance criteria

Return ACCEPT only when all are true:

1. Opening provenance passed.
2. The repository target is unchanged.
3. The predecessor defect is independently reproduced.
4. The corrected deltas are independently reconstructed and valid.
5. Exactly three mode fields and six bytes changed.
6. The corrected SHA-256 independently equals
   `0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1`.
7. Both builders derive logical modes from authenticated inventories and are
   materially independent.
8. The audit-owned mutation matrix fails closed.
9. Supersession is exact and does not overreach.
10. Correction-root manifests bind every object and only self-exclude
    themselves.
11. No new authority, security, repository, or artifact defect is found.
12. Opening and closing supplied-root identities match exactly.

A repairable failure is BLOCK.
A fundamental mismatch in the claimed target is REJECT.
A failed opening identity or provenance gate is AUDIT_PROVENANCE_MISMATCH.

## 14. Required final report

Report:

1. Verdict.
2. Administrative pre-epoch disclosure, if any.
3. Exact repository and supplied-root identities.
4. Opening provenance result.
5. Four auditor identities, schedule, operands, cwd, completion, and
   disagreements.
6. Reproduced predecessor defect.
7. Independent corrected-delta reconstruction.
8. Exact byte-difference result.
9. Corrected-delta SHA-256.
10. Builder independence adjudication.
11. Independent mutation matrix.
12. Supersession adjudication.
13. Repository re-binding and any fresh validation.
14. Capsule membership and manifest closure.
15. Authority and nonauthority adjudication.
16. Severity-ranked findings.
17. Minority findings and parent resolution.
18. Remaining uncertainty and explicit nonclaims.
19. Audit-created paths and cleanup.
20. Closing equality.
21. Explicit confirmations:

    REPOSITORY_MUTATION_NOT_PERFORMED
    PREDECESSOR_EVIDENCE_MUTATION_NOT_PERFORMED
    CORRECTION_CAPSULE_MUTATION_NOT_PERFORMED
    BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
    REPAIR_NOT_PERFORMED
    FORMATTING_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    A6_NOT_STARTED
    SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
    ORCHESTRATOR_NOT_IMPLEMENTED
    EVIDENCE_VERIFICATION_NOT_INVOKED
    CALLER_NOT_INVOKED
    PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
    NETWORK_CONTACT_NOT_PERFORMED
    NESTED_SUBAGENTS_CREATED: 0
```

## After an `ACCEPT`

Do not combine the next step with this audit. The next engagement is a separate commit gate against the accepted repository bytes. The correction capsule remains source-external audit evidence; it is not a repository artifact to stage.

The project’s provenance guidance distinguishes exact-byte identity from correctness and authority, and requires the auditor to reproduce provenance before implementation judgment.  

### Sources

- Codex mode-provenance repair implementation report supplied in this turn.
- Governed Execution Codex Subagent Operating Protocol: implementation, repair, and independent audit must remain separate; repaired evidence requires new provenance and a fresh audit.  
- Governed Execution Provenance Guidance: provenance binds exact bytes but does not establish correctness or authority. 

**Confidence:** 0.98 that no additional implementation is warranted before audit; 0.97 that the report closes the identified mode-provenance mechanism; 0.94 that the fresh audit should be able to issue `ACCEPT`, contingent on independent capsule and builder inspection.
