## Assessment

This is the first **substantive BLOCK** in the recent sequence. It is not another audit-harness or provenance failure.

The audit effectively accepted the repository repair itself:

- Exact opening and closing provenance matched manifest `4a3a4244…18537`.
- The repository remained at the restored 477-object baseline.
- The generic authority-family repair closed TV-01, including generated non-enumerated identifiers.
- Test 89 passed three times; all four 89-test suites passed.
- A6D, the amendment, synthetic A6, and SEC-02 compatibility checks passed.
- MK-01 was explicitly adjudicated nonblocking under the closed four-document contract surface.
- No repository or supplied-evidence mutation occurred.

The remaining defect is outside the 13-path repository patch:

> `launch_v3_trusted_host.py` makes pathname-based snapshot equality a condition of its `accepted` outcome, but its `lstat()` followed by `read_bytes()` traversal can be raced so that metadata and bytes come from different filesystem objects.

That is a legitimate assurance defect. The fact that a snapshot is only one of several required gates limits its impact, but does not make it merely cosmetic: it can falsely support the caller’s acceptance-bearing no-write observation. The audit-owned compatibility reconstruction already demonstrated the correct design direction—descriptor-relative, no-follow, bounded traversal.

### Required next action

Do **not** change any of the 13 repository paths. The one-file alternate-authority repair remains the exact repository target. It changed only `test_verify_v1.py`; the other twelve patch paths remained byte-identical. 

Do **not** edit the existing source-external caller or its evidence in place. Preserve it as the vulnerable historical input.

Create a new source-external caller implementation that replaces only the snapshot mechanism. Keep snapshot equality acceptance-bearing, but make the snapshot itself descriptor-bound. Merely relabeling it “corroborative” would weaken the existing assurance instead of repairing it.

After that repair, run one fresh independent audit against:

1. the unchanged repository manifest `4a3a4244…18537`; and
2. the new exact caller source and caller-repair evidence.

The project protocol requires returning to a writer task after `BLOCK`, producing new validation and provenance, and then using a fresh read-only audit; the old audit cannot qualify changed evidence bytes.  Provenance remains evidence rather than correctness or authority. 

## Codex prompt — source-external caller snapshot repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must contain the complete implementation report inline in
Markdown. Evidence links may be supplemental, but must not replace the inline
report.

FRESH SOLE-WRITER TASK

This must be a fresh Codex conversation.

Do not resume:

- the independent audit that returned BLOCK for CALLER-SNAPSHOT-01;
- any previous audit conversation;
- the alternate-authority repository implementation conversation;
- the artifact-restoration conversation.

Do not create subagents. The defect is localized and the parent is the sole
writer of source-external repair evidence.

Objective

Repair CALLER-SNAPSHOT-01 in a new source-external caller without modifying the
Evidence Verification repository patch or any existing evidence.

The current source-external caller makes target/package/TMPDIR/caller-evidence
snapshot equality a condition of `outcome="accepted"`, but its snapshot
implementation performs pathname-based `lstat()` followed by a separate
pathname `read_bytes()`. A concurrent replacement can cause metadata and bytes
to come from different objects and can undermine the acceptance-bearing
no-write observation.

Replace that snapshot implementation with deterministic,
descriptor-relative, no-follow, bounded traversal and stable identity checks.

Do not weaken the assurance by merely making snapshots nonblocking or
relabeling them corroborative.

Return exactly one:

EVIDENCE_VERIFICATION_V1_CALLER_SNAPSHOT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
EVIDENCE_VERIFICATION_V1_CALLER_SNAPSHOT_REPAIR_BLOCKED
EVIDENCE_VERIFICATION_V1_CALLER_SNAPSHOT_CAPABILITY_UNAVAILABLE
EVIDENCE_VERIFICATION_V1_CALLER_SNAPSHOT_BASELINE_MISMATCH

No repository mutation.
No modification of existing evidence.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, live-service invocation, or network contact.
No subagents.

## 1. Exact inputs

Repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected canonical repository manifest:

REPO_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f/provenance/manifest-run-1.json

Expected manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Expected restored repository inventory:

RESTORED_INVENTORY=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632/restoration/full-object-after.json

Expected governed object count:

477

Existing vulnerable caller, immutable historical input:

OLD_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected old caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Blocking audit, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5

Useful audit-owned descriptor-relative reference, read-only and
non-authoritative:

$BLOCKING_AUDIT/reports/compatibility_reconstruction.py

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python identity:

- version: 3.13.4
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

New repair root, required absent before creation:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-repair-4a3a42441632-v1

## 2. Authority and seam classification

Current contract:

- The repository verifier is an ES-owned Bounded slice rule.
- Its output has structural-evidence authority only.
- The source-external caller and caller records are validation/provenance
  evidence only.
- Neither caller nor verifier grants product, runtime, admission,
  orchestration, readiness, commit, publication, or durable-state authority.
- Supported-local trusted-host assumptions and the explicit nonclaim of atomic
  interpreter custody remain unchanged.

Repair classification:

- source-external validation-evidence repair;
- no repository patch change;
- no product or public schema change;
- no launch-protocol change;
- no verifier change;
- no registry/layout change;
- no authority widening;
- no reopened architectural seam.

MK-01 has already been adjudicated nonblocking for the intentionally closed
four-document contract set. Do not alter the authority-family validator,
governing documents, or test 89.

## 3. Permitted writes

Write only beneath REPAIR_ROOT.

Do not modify:

- IMPL_R;
- OLD_CALLER;
- BLOCKING_AUDIT;
- the implementation evidence root;
- the restoration evidence root;
- A6D;
- A6D_AMEND;
- any previous repair or audit root.

Create all REPAIR_ROOT directories at mode 0700 and all retained regular files
at mode 0600. Use exclusive creation. Do not rewrite retained records.

Suggested retained structure:

REPAIR_ROOT/
  opening/
  source/
  tests/
  causals/
  validation/
  provenance/
  closeout/
  tmp/

The final `tmp/` must be empty.

## 4. Source disposition

Create a new caller source derived from the exact OLD_CALLER bytes, for example:

REPAIR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Preserve, unless this repair proves impossible without a version decision:

- launch protocol v2;
- pinned-interpreter handling;
- source-by-value verifier launch;
- verifier source, registry, and layout authentication;
- CLI arguments and ordering;
- supported-local host posture;
- existing mandatory nonclaims;
- `execution-substrate.evidence-closure-launch-record.v3`;
- record field names and meanings;
- returned verifier-output validation;
- existing error and acceptance semantics outside snapshot construction.

Do not add a pathname fallback.

Do not change `outcome="accepted"` semantics by removing snapshot equality from
the acceptance gate. The repair must make that gate trustworthy within its
documented observation limits.

If repairing the snapshot requires changing the private record schema, launch
protocol, CLI, repository documentation, or verifier output, stop with:

EVIDENCE_VERIFICATION_V1_CALLER_SNAPSHOT_REPAIR_BLOCKED

and report the exact required versioning decision. Do not silently widen scope.

## 5. Descriptor-bound snapshot requirements

Replace every acceptance-bearing pathname snapshot of target, package,
TMPDIR, and caller-evidence roots with one shared closed implementation.

At minimum, the implementation must:

1. Require an absolute root.
2. Traverse each root-path component without following symlinks.
3. Open and hold the root directory descriptor for the complete scan.
4. Enumerate directory entries descriptor-relatively.
5. Sort names deterministically by their encoded byte representation.
6. Use `dir_fd` and `follow_symlinks=False` for entry observations.
7. Open child directories using `O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC`.
8. Open regular files using
   `O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC`.
9. Compare pre-open path observation, descriptor `fstat`, post-read descriptor
   identity, and post-read path reobservation.
10. Hash file bytes only from the held file descriptor.
11. Reject symlinks and unsupported file types.
12. Reject a regular file with an unaccepted hardlink count.
13. Recheck each directory entry and directory identity after traversing it.
14. Reopen the root through its no-follow component chain at close and require
    equality with the held root descriptor.
15. Fail closed on disappearance, replacement, type change, size change,
    mode change, link change, unsupported descriptor operation, uncertain
    identity, read error, or traversal race.
16. Use finite explicit limits for:
    - file count;
    - directory count;
    - depth;
    - path bytes;
    - per-file bytes;
    - total bytes.
17. Produce deterministic snapshot content for an unchanged tree.
18. Retain no file contents in the caller record.
19. Emit no absolute target/package path in shared output.
20. Perform zero writes to watched roots.

A mutation that begins and ends entirely between the before and after
observations is not claimed detectable. Preserve that nonclaim. The repair is
for internal snapshot consistency and pathname-swap resistance during each
observation, not atomic filesystem history.

Do not copy the audit-owned reference blindly. Independently inspect and
justify the final implementation.

## 6. Vulnerable predecessor causal

Use an audit-owned exact copy of OLD_CALLER.

Construct a deterministic expected-negative causal showing the old snapshot
can combine:

- metadata observed from one inode; and
- bytes read from a replacement inode through the same pathname,

without producing an internal snapshot error when type, mode, size, and content
are chosen to appear equal.

The causal must:

- leave OLD_CALLER unchanged;
- use only audit-owned fixtures;
- record both inode identities;
- record the exact synchronization point;
- show why the old snapshot result is falsely consistent or internally
  unbound;
- remove the audit-owned fixture afterward.

Do not overclaim a complete caller acceptance bypass if the causal proves only
the snapshot-level defect. State exactly what was demonstrated.

## 7. Repaired snapshot causals

Create source-external tests for at least:

1. Stable tree snapshots deterministically twice.
2. Empty directory.
3. Nested regular files.
4. Final root symlink.
5. Symlinked root ancestor.
6. Symlink entry inside the tree.
7. Special file.
8. Regular-file hardlink.
9. File replacement between entry observation and file open.
10. File replacement after open but before closing reobservation.
11. In-place size or byte mutation during read.
12. Directory replacement during traversal.
13. Root replacement during traversal.
14. Entry disappearance.
15. Entry type change.
16. Mode change.
17. Link-count change.
18. Per-file byte limit.
19. Aggregate byte limit.
20. File-count limit.
21. Directory-count limit.
22. Depth limit.
23. Path-byte limit.
24. Unsupported `dir_fd`, no-follow, or descriptor-listing capability.
25. Repeated execution with byte-identical canonical snapshot output.
26. Shared record contains no watched-root absolute path or file payload.
27. No watched-root write.

Use deterministic test coordination. Do not depend on probabilistic timing.

No test-only race hook may be caller-controlled through CLI, environment, the
target, or the verifier invocation. If deterministic testing requires an
internal dependency-injection seam, it must be inaccessible from normal
caller execution and must fail closed if unexpectedly non-null there.

## 8. Caller compatibility validation

Using the final repaired caller source, run:

### A6D

Two sealed runs.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical verifier stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- deterministic caller record semantics;
- target, package, TMPDIR, and caller-evidence snapshots equal;
- A6D manifest unchanged;
- mandatory trusted-host nonclaims preserved.

### Amendment

Two sealed runs.

Require canonical verifier stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same caller, stderr, snapshot, manifest, and nonclaim conditions.

### Synthetic A6

Create an audit-owned fixture outside every supplied root.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require:

- caller accepted;
- deterministic outputs per stage;
- empty verifier stderr;
- descriptor-bound snapshots equal during each verifier invocation;
- only the expected writer-owned seal transition between stages.

### SEC-02

Run a target-marker source-by-value causal.

Require:

- target-contained script is not loaded;
- marker remains absent;
- direct-script predecessor shape remains nonqualifying;
- no atomic interpreter-custody claim.

### Caller-negative checks

Require rejection for:

- wrong interpreter hash;
- wrong interpreter size;
- source mismatch;
- registry result mismatch;
- layout result mismatch;
- package/target boundary violation;
- snapshot uncertainty;
- snapshot replacement;
- unsupported snapshot capability.

## 9. Repository invariance

At opening and closing:

- reproduce repository manifest
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- reproduce tracked diff
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- require exact equality with RESTORED_INVENTORY;
- require exactly 477 governed objects;
- require no repository cache, bytecode, test cache, or generated artifact;
- require zero staged, deleted, renamed, or unmerged paths.

Do not run or alter repository tests. Repository bytes are not part of this
repair.

## 10. Source-external repair provenance

Retain:

- exact OLD_CALLER source identity;
- exact new caller source;
- exact test source;
- old-defect causal;
- repaired causal matrix;
- every compatibility record;
- every caller-negative record;
- opening and closing repository manifests;
- a complete REPAIR_ROOT path/type/mode/size/link/SHA-256 inventory;
- failed and superseded attempt index;
- cleanup record;
- implementation report.

Generate a canonical source-external repair manifest twice and require
byte-identical output. It must include all retained repair files but no file
contents or sensitive absolute target data.

Report:

- new caller path, size, and SHA-256;
- test path, size, and SHA-256;
- old caller SHA-256;
- repair-manifest SHA-256;
- file count;
- directory count;
- exact caller record schema disposition;
- exact compatibility outcomes;
- exact remaining nonclaims.

## 11. Stop conditions

Stop without broadening or relabeling the repair if:

- IMPL_R differs from the specified manifest or 477-object inventory;
- OLD_CALLER differs from its pinned hash;
- REPAIR_ROOT already exists;
- any supplied evidence changes;
- descriptor-relative no-follow traversal is unavailable;
- a pathname payload-read fallback becomes necessary;
- snapshot equality must be removed from acceptance;
- caller CLI or launch protocol must change;
- launch-record schema or field meaning must change;
- verifier, registry, layout, docs, or repository tests must change;
- target/package/caller-evidence scope must widen;
- a compatibility output differs unexpectedly;
- an authority, readiness, product, or runtime claim would widen;
- retained evidence cannot be closed at 0600/0700 with an empty `tmp/`.

## 12. Final inline report

Include:

1. Verdict.
2. Exact opening repository and old-caller identities.
3. Repair classification and non-goals.
4. Exact new caller source identity.
5. Exact touched source-external files.
6. Descriptor snapshot algorithm.
7. Resource limits.
8. Old caller expected-negative causal.
9. Complete repaired causal matrix and outcomes.
10. Record-schema and launch-protocol disposition.
11. A6D results.
12. Amendment results.
13. Synthetic A6 results.
14. SEC-02 result.
15. Caller-negative results.
16. Repository opening/closing invariance.
17. Evidence inventory and cleanup.
18. Canonical repair-manifest identity.
19. Authority/security/protocol widening: none, or exact stop.
20. Remaining uncertainty and nonclaims.
21. Explicit confirmations:
    - repository mutation not performed;
    - existing evidence mutation not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - independent audit not performed;
    - subagents created: 0.

Do not perform an independent audit in this task.
Do not stage, commit, or push.
```

Once Codex returns `…READY_FOR_FRESH_AUDIT`, the next audit should use the unchanged repository manifest plus the new exact caller source. It should not reopen MK-01 or repeat repository implementation.

### Sources

- The earlier process-blocked audit still established that the repository target, manifest, and 477-object baseline remained exact; its failure was confined to audit-evidence file modes. 
- The repository repair changed only `test_verify_v1.py`; all other twelve patch paths remained byte-identical, and the validator now scans the generic contract family. 
- The project workflow requires a separate repair task after `BLOCK`, followed by a new independent audit against the changed evidence bytes. 
- Provenance is evidence rather than correctness or authority, and the commit gate is permitted only after an accepted audit.  
- The restored worktree contains exactly 477 objects, no cache or bytecode, and retains manifest `4a3a4244…18537`. 

**Confidence**

- CALLER-SNAPSHOT-01 is a real validation-evidence defect: **0.98**
- The 13-path repository repair itself requires no further change: **0.99**
- Descriptor-relative snapshot repair is the narrowest safe correction: **0.97**
- Existing caller and evidence must remain immutable historical inputs: **1.00**
- Correct next step is the source-external repair above, followed by one fresh audit: **0.99**
