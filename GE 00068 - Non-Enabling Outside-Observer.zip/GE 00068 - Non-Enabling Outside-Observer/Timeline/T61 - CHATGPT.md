The stop is correct. This is a **new layer of failure**, distinct from the line-1706 incompatibility that A5S repaired:

- Both A5 controls independently qualified.
- Both had zero unknown diagnostics.
- Lifecycle outcomes were equal, including the seven required named tests.
- The stability gate failed only because 12 **recognized but still material** diagnostic entries differed across six tests.

So A5S did its job: the full A5 stream is now representable. What remains is not yet evidence of either a product defect or harmless nondeterminism. The summary points toward control-local socket names and a correlation sequence, but those require exact source-grounded adjudication before another canonicalization rule is authorized.

Do **not** implement A6, derive historical matrices from one side, rerun the full suite, or patch A5S immediately. The next step is a narrow, read-only divergence reconnaissance against the two retained qualified controls.

I would reserve **A6** for the historical directional-policy amendment and call any proven successor-only canonicalization repair **A5C**.

Pass this to Codex:

```text
Objective

Perform a parent-only, read-only Repair 10I-A5C diagnostic-divergence
reconnaissance over the two exact qualified A5 controls retained in:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Recover and classify every final↔fresh diagnostic difference, determine
whether it is:

1. safely typed control-local nondeterminism requiring a bounded successor
   canonicalization amendment;
2. an unstable or incorrect repository test;
3. a production behavior difference;
4. a validation-construction defect; or
5. unresolved and therefore blocking.

Freeze the exact next repair, touched-file scope, causal tests, and restart
requirements.

Do not implement anything in this turn.

Do not modify or seal the failed policy-evidence child.
Do not modify repository source.
Do not modify A5S.
Do not rerun either full suite.
Do not implement A6.
Do not start B6.
Do not create a successor child, evidence child, cache, report file, snapshot,
ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. This is a narrow parent-only source/evidence investigation.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 product repair

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5S successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Failed but qualified-control-bearing evidence refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

## 1. Mandatory opening and closing gates

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require exact A5:

- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A5S:

- manifest SHA-256:
  57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f
- payloads:
  271
- source T:
  983943e612dd4d48ca4f0fabbc48ad51909c2e11
- source inventory:
  799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a
- members:
  12

A5S binaries:

repair10-runner:
  ce6a44a99d4f53eaa6c8feeadc407e063deb7e6303e68f154fbe1cf0d573e68b

repair10-compare:
  e31887e0d45026d6bad6a6f2e5a4a30dd1f0f7c5bd55847991a9120ef6351e06

repair10-semantic:
  2f28bf8996b4a42d318cb16604804ad90cdb41b17517d30b4c0db85d5fbd0c2e

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the failed evidence-refresh child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact from opening through closing.

Require its retained control facts to reproduce exactly:

- both controls use `source_class=pristine-final`;
- both source T values equal:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c;
- both inventories equal:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b;
- both producer qualifications are `qualified`;
- both opposite-side requalifications are `qualified`;
- both have zero unknown diagnostics;
- final↔fresh:
  - LifecycleEqual=true;
  - DiagnosticsEqual=false;
  - CanonicalSemanticsEqual=false;
  - RawBytesEqual=false;
  - LeftQualified=true;
  - RightQualified=true;
  - LogicalSuiteFingerprintEqual=true;
  - UnknownDifferenceCount=0;
  - AcceptedEqual=false;
  - Outcome=blocked-uncertain;
  - exit 1;
- exactly 12 diagnostic-delta entries exist across exactly six test identities.

Require the new A5C target to remain absent if any such path already exists.

At closeout, repeat all identity checks and require no changed repository,
A5, A5S, or evidence-refresh path.

Stop on any mismatch:

REPAIR10I_A5C_RECONNAISSANCE_BLOCKED

## 2. Read-only operating rules

Use direct no-follow reads only.

If structured parsing is needed, use:

PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -

with complete source supplied on stdin and results emitted to stdout only.

Do not import any Python module from a sealed or unsealed evidence child.

Do not create:

- `__pycache__`;
- `.pyc`;
- temporary JSON;
- scratch files;
- redirected stdout/stderr;
- analysis reports;
- source copies;
- Git caches.

Do not use ordinary `git status`.

Any necessary Git read must use `GIT_OPTIONAL_LOCKS=0` and an explicitly
read-only command.

## 3. Recover the exact 12 differences

Inspect at minimum:

- the final↔fresh comparison result;
- both complete semantics documents;
- both bound raw stdout streams;
- both suite specifications;
- both command results;
- both terminal reconciliations;
- both producer and peer qualifications;
- both mapping tables;
- A5S `FORMAT.md`;
- A5S `envelope/semantic.go`;
- A5S `envelope/envelope_test.go`;
- repository source and tests producing all six diagnostic identities.

For each of the 12 sided entries report:

- side:
  final-only or fresh-only;
- package;
- test or subtest;
- occurrence and ordinal;
- classification;
- rule ID;
- complete typed captures;
- safe exact diagnostic identity;
- raw-stream path and byte span or line;
- semantics-record path/index;
- corresponding opposite-side record;
- exact differing lexical spans;
- whether all nondiffering bytes match;
- generating repository path and line;
- generating helper/call chain;
- source of variability;
- whether the value affects product behavior, assertion behavior, or only
  private test/control addressing.

Do not print secret or unrelated private material.

For private control roots and socket paths, report safe placeholder-rendered
forms plus exact hashes and evidence locations rather than unnecessarily
reproducing complete absolute values.

Prove that the comparison contains exactly six left/right record pairs—or
state the actual pairing if the 12 entries do not form six one-to-one pairs.

## 4. Socket-path divergence analysis

For every difference involving a socket or endpoint path, determine exactly:

1. Which test generated it.
2. Which function allocated the directory and socket basename.
3. Whether the path is:
   - beneath the registered control root;
   - beneath TMPDIR or GOTMPDIR;
   - generated by `t.TempDir`, `os.MkdirTemp`, random suffix logic, or another
     mechanism;
   - a Unix socket path, an error-rendered candidate, or ordinary file path.
4. Whether both sides have the same:
   - endpoint role;
   - address family;
   - path-component structure;
   - basename grammar;
   - containing-root role;
   - socket lifecycle;
   - listen/connect result;
   - cleanup result;
   - collision/rebind behavior.
5. Whether path length or exact basename is itself part of the test contract.
6. Whether the path is already covered by:
   - control-root mapping;
   - source-root mapping;
   - Go TempDir mapping;
   - another typed grammar.
7. Why the existing rule did not canonicalize it.
8. Whether safe normalization can preserve:
   - endpoint role;
   - path topology;
   - repeated-versus-distinct relationships;
   - collision identity;
   - path-length boundary;
   - errno and operation;
   - package/test/occurrence identity.

Do not recommend generic replacement of:

- arbitrary `/tmp` paths;
- arbitrary socket paths;
- arbitrary decimal or hexadecimal suffixes;
- every path beneath a control root.

A safely canonicalizable socket value must have an exact package/test/template
grammar and a finite typed role.

## 5. Observability/correlation divergence analysis

For each observability or correlation-sequence difference, determine:

1. Exact package, test, event, route, status, and source location.
2. Exact differing fields.
3. Whether the difference is:
   - a generated trace ID;
   - request ID;
   - correlation ID;
   - placeholder ID;
   - sequence number;
   - event order;
   - duration;
   - timestamp;
   - port or PID;
   - another field.
4. Whether each value is registered in the mapping table.
5. Whether the sequence topology is the same:
   - same number of values;
   - same equality/inequality relationships;
   - same first-use order;
   - same repeated references;
   - same event order;
   - same package/test occurrence.
6. Whether the differing field is required to remain material by the existing
   observability rule.
7. Whether the current difference exposes:
   - missing typed mapping;
   - unstable event ordering;
   - a flaky assertion;
   - actual product semantic variation.
8. Whether a proposed canonicalization would conceal:
   - route/status changes;
   - missing events;
   - reordered events;
   - correlation aliasing;
   - multiplicity changes;
   - request/trace relationship changes;
   - pass/fail/skip changes.

Do not sort or aggregate records merely to obtain equality unless the owning
test and contract establish that order is nonsemantic.

## 6. Repository-source adjudication

For each of the six test identities classify the difference as exactly one:

- expected private control-local nondeterminism;
- repository test nondeterminism or overbroad logging;
- validation-construction nondeterminism;
- production nondeterminism that is semantically acceptable;
- production behavior difference;
- unresolved.

For every classification provide:

- governing source/test path and line;
- current intended assertion;
- value generation mechanism;
- why lifecycle remains equal;
- whether the test passed on both sides;
- whether a same-value run is possible or required;
- whether product production bytes would need to change;
- whether only test bytes would need to change;
- whether only successor bytes would need to change.

Do not infer “harmless” merely from both tests passing.

## 7. Successor-rule adjudication

For every difference proposed as safely canonicalizable, freeze:

- proposed rule ID;
- exact package/test/subtest scope;
- exact complete template or structured-record grammar;
- typed captures;
- canonical replacement;
- correlation/topology invariants;
- preserved material fields;
- malformed and near-miss behavior;
- bounds;
- required negative corpus.

Determine whether the repair can use an existing rule or requires a new rule.

Do not rename an existing rule unless its semantics genuinely change.

Determine whether any schema identifier must change. A mere finite grammar
addition should not automatically version acceptance schemas.

## 8. Causal test matrix

If a successor-only repair is recommended, define exact active tests for:

### Exact positives

- Both retained final and fresh records canonicalize to the same record.
- The complete retained A5 streams become semantically equal.
- Lifecycle and terminal sets remain byte-identical.
- Exactly the intended 12 sided records change canonical representation.
- No other diagnostic record changes.

### Socket-path negatives

Independently mutate:

- package;
- test/subtest;
- endpoint role;
- containing-root role;
- path prefix;
- basename grammar;
- address family;
- path length boundary;
- repeated/distinct relationship;
- collision/rebind result;
- errno;
- operation;
- appended text;
- partial text.

Every material mutation must remain visible or become unknown/blocking.

### Correlation negatives

Independently mutate:

- route;
- status;
- event name;
- event count;
- event order;
- ID equality topology;
- missing correlation;
- extra correlation;
- package/test occurrence;
- sequence length;
- pass/fail/skip terminal.

Every material mutation must remain visible or blocking.

### Historical/tool nonregression

Require:

- historical HEAD canonical semantics unchanged except where the new exact
  grammar genuinely applies and is separately adjudicated;
- Repair-9 canonical semantics likewise;
- A5S line-1706 rule remains exact;
- wrong-line and overbound controls remain blocking;
- final/fresh and mutant sealed tool causals remain unchanged where their
  inputs do not contain the new grammar.

## 9. Exact likely repair surface

Determine the minimal touched files.

Expected successor-only candidate:

- `tool/source/FORMAT.md`
- `tool/source/envelope/semantic.go`
- `tool/source/envelope/envelope_test.go`

But do not assume those three are sufficient.

State explicitly whether any of these are required:

- `envelope/runner.go`;
- `envelope/source.go`;
- semantic CLI;
- comparator CLI;
- repository test source;
- repository production source;
- private schema version.

If more than a finite successor grammar amendment is needed, state that and
do not force it into A5C.

## 10. Restart consequences

Freeze which evidence remains usable after the next repair.

At minimum:

- A5 implementation and source identity remain predecessor evidence if
  repository bytes do not change.
- The current two qualified A5 control executions remain negative causal input
  for testing the successor repair.
- They cannot establish the post-repair final/fresh acceptance result.
- The full two-control policy-evidence refresh must restart from newly
  materialized controls after any successor byte change.
- The current unsealed child remains nonqualifying and must not be resumed or
  sealed.

If repository bytes must change, state which A5 evidence is invalidated and
which broader validation must restart.

## 11. Required verdict

Return exactly one:

### Successor-only bounded repair can be frozen

REPAIR10I_A5C_RECONNAISSANCE_READY

Use only when:

- all 12 differences are completely classified;
- every difference is proven safe, typed control-local nondeterminism;
- no product or repository-test correction is required;
- one finite successor scope and causal matrix are frozen;
- no unresolved material field remains.

### Repository product or test repair is required

REPAIR10I_A5_PRODUCT_OR_TEST_REPAIR_REQUIRED

Use when any difference is caused by:

- a flaky or incorrect repository test;
- nondeterministic assertion semantics;
- product behavior that should be deterministic;
- actual product semantic divergence;
- repository logging/output that violates the intended comparison contract.

State the exact likely repair paths and why successor canonicalization would
be unsafe.

### Evidence is insufficient

REPAIR10I_A5C_RECONNAISSANCE_BLOCKED

Use when any difference cannot be classified safely from the retained
evidence.

## 12. Required final report

Include:

1. Opening and closing identities.
2. Exact 12-entry ledger.
3. Six-test source/generator map.
4. Socket-path analysis.
5. Observability/correlation analysis.
6. Material-versus-control-local adjudication.
7. Exact recommended repair class.
8. Exact touched-file recommendation.
9. Exact causal test matrix.
10. Schema/versioning disposition.
11. Evidence carry-forward and restart rules.
12. Inspection limits and unresolved uncertainty.
13. Confirmation that no file, cache, bytecode, scratch object, evidence child,
    test, build, or source copy was created.

No implementation.
No new successor child.
No evidence-refresh retry.
No A6.
No B6.
No product A/B.
No snapshot.
No ZIP or handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

### Critical path after reconnaissance

If every delta is safely typed, implement a sealed A5C successor amendment and then restart the two-control evidence refresh from scratch. If any delta is a repository test or product issue, repair that first and rerun the affected implementation validation before returning to the policy evidence.

The present two qualified controls remain valuable as an exact vulnerable corpus, but they cannot become post-repair acceptance evidence. The project’s prior A2 closeout makes that non-substitution rule explicit.  Exact hashes and manifests establish that everyone examined the same bytes, but they do not establish that treating these diagnostics as equivalent is correct or safe.  Any resulting byte-changing repair requires new validation, provenance, and later fresh audit. 

### Sources

- Codex’s `REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED` response in the current turn.
- Sealed Repair 10I-A2 non-substitution boundary. 
- Governed Execution Provenance Guidance. 
- Governed Execution repair and re-audit protocol. 

**Confidence:** 0.999 that the stability-gate stop was correct; 0.97 that the blocker is now confined to diagnostic semantics rather than lifecycle behavior; 0.84 that all 12 entries will prove safely canonicalizable; 0.99 that classification must precede any further successor patch; 0.995 that any patch must be followed by a completely fresh two-control evidence refresh.
