## Engineering assessment

The split-root launch path worked exactly as designed, but the **single real-audit authorization is now permanently consumed**. The audit parent was created once, ran under the correct workspace/capsule-child model, and exited with an unhandled exception before creating the capsule. No retry or alternate-root search occurred. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The failure is narrow:

```text
requested subject member:
validation/contract-schema-satisfiability-matrix-v2.json

result:
file does not exist
```

The parent failed before witness evaluation, the 946- or 137-case suites, the field map, documentary-validator adjudication, findings, phases, or terminal closure. Consequently, it established neither subject acceptance nor a subject blocker. :chatgpt-content-reference{index="2"}

### What succeeded

The external execution boundary is now proven:

- the final PYZ, runtime authority, profile v2, and certificate v3 authenticated;
- exactly one active authorization existed;
- the 89-member PYZ closed;
- the workspace was allocated correctly;
- the capsule child was absent before launch;
- platform preflight passed;
- the exact 23-element audit invocation was used;
- the audit process was created, reaped, and fully captured;
- the subject remained unchanged;
- no Git, network, product, target-audit, runtime-validation, or A6 activity occurred. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

The root-lifecycle problem is therefore closed. The next defect is inside the frozen audit harness’s **subject evidence dependency resolution**.

### What is not yet known

The absent path could represent either:

1. a stale hard-coded audit path where the current subject exposes the same semantic evidence under another exact path or role; or
2. a genuinely missing subject artifact required by the governing subject contract.

The failed audit cannot distinguish those cases because it raised an unhandled exception rather than producing a terminal, evidence-complete result.

The correct classification is:

```text
UNHANDLED_CURRENT_SUBJECT_EVIDENCE_ROLE_RESOLUTION_DEFECT
```

This is currently an **audit-harness defect**. It does not preclude the repaired audit from later determining that the subject is missing a required record and therefore should be blocked.

### Progression decision

Do not reconstruct or modify the subject.

Create a successor audit-harness generation from the current frozen clean source, with one bounded repair:

- replace acceptance-bearing subject path literals with an exact semantic-role dependency registry;
- determine the requested matrix’s actual governing role and current subject representation;
- pre-resolve **every** subject input required by the real audit, not just the first missing path;
- treat a governed required role that is absent as a handled direct package finding, not an exception;
- treat an ambiguous or unauthenticated role mapping as audit provenance failure;
- qualify the repaired packaged path against the exact unchanged replacement subject without issuing a real subject verdict;
- issue new PYZ/runtime authority/profile/certificate artifacts with exactly one successor audit authorization.

Profile v2 and certificate v3 are now historical and consumed. They cannot be reused.

---

## Complete replacement Codex prompt

```text
REPAIR THE CLEAN INDEPENDENT-AUDIT HARNESS’S CURRENT-SUBJECT
EVIDENCE-ROLE RESOLUTION, REQUALIFY IT, AND ISSUE ONE SUCCESSOR
REAL-AUDIT AUTHORIZATION

DO NOT EXECUTE THE REAL SUBJECT AUDIT IN THIS TASK

Objective

Repair the frozen independent-audit harness after its single authorized real
audit failed unhandled while requesting the nonexistent subject path:

validation/contract-schema-satisfiability-matrix-v2.json

The failed real-audit parent:

- was created exactly once;
- consumed the certificate-v3 authorization;
- ran under the qualified split-root launch profile;
- exited 1 with signal null;
- emitted no terminal frame;
- created no audit capsule;
- did not run witnesses;
- did not run the 946-case suite;
- did not run the 137-case suite;
- did not run the 766/333 field map;
- did not create findings or phase records;
- did not establish subject ACCEPT or BLOCK.

Repair the audit harness so that every acceptance-bearing subject input is
resolved by an authenticated semantic role rather than a hard-coded versioned
path.

The repair must determine whether the requested path corresponds to:

1. a current subject evidence role present under a different exact path;
2. a required current subject role that is genuinely absent;
3. an obsolete or nonapplicable historical role;
4. an ambiguous or unauthenticated role mapping.

Future behavior must be:

- present unique role:
  open the exact current record;

- governed required role absent:
  retain a direct package-finding candidate with exact authority evidence and
  continue to a handled, terminal audit disposition;

- optional or nonapplicable role absent:
  retain explicit nonapplicability and continue;

- ambiguous, duplicate, or unauthenticated role:
  fail as `AUDIT_PROVENANCE_MISMATCH`;

- filesystem `ENOENT`:
  never escape as an unhandled exception.

Do not mutate, repair, reconstruct, clean, chmod, relocate, or reseal the
replacement subject.

Do not execute the real replacement-subject audit in this task.

Do not issue a subject ACCEPT or BLOCK.

Do not promote or rebind current schema authority.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite repair and qualification parent in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_REPAIR_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT FROZEN AUDIT PYZ
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUDIT_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz

Expected identity:

- device:
  16777234
- inode:
  182699827
- mode:
  0400
- link count:
  1
- size:
  4589679
- SHA-256:
  00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0

Authenticate with stable no-follow reads.

Resolve source members only through the embedded member registry and source
freeze.

Do not select source by basename, similarity, hash search, decompilation, or
external historical build roots.

Classify this PYZ after successor closure as:

HISTORICAL_CONSUMED_AUDIT_HARNESS_WITH_INPUT_ROLE_RESOLUTION_DEFECT

Do not mutate it.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. CURRENT RUNTIME AUTHORITY
──────────────────────────────────────────────────────────────────────────────

CURRENT_RUNTIME_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json

Expected identity:

- device:
  16777234
- inode:
  182699838
- mode:
  0400
- link count:
  1
- size:
  56463
- SHA-256:
  9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0

Strict-parse with duplicate-key and nonfinite-number rejection.

Authenticate:

- current source freeze;
- current source registries;
- 89-member package registry;
- current qualification results;
- exact 15/14 model;
- 946 and 137 vocabularies;
- split-root invocation relationship;
- historical real-audit count:
  one;
- historical subject verdict:
  not issued.

Classify after successor closure as historical runtime authority.

Do not mutate it.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO CONSUMED LINEAGE
────────────────────────────────────────────────

3. CONSUMED PROFILE V2 AND CERTIFICATE V3

CONSUMED_PROFILE_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json

Expected identity:

- device:
  16777234
- inode:
  182745731
- mode:
  0400
- link count:
  1
- size:
  10412
- SHA-256:
  2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c

CONSUMED_CERTIFICATE_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json

Expected identity:

- device:
  16777234
- inode:
  182745737
- mode:
  0400
- link count:
  1
- size:
  19323
- SHA-256:
  e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d

Authenticate their exact identities and lineage.

Required disposition after successor closure:

- profile v2 current:
  false;
- certificate v3 current:
  false;
- certificate-v3 audit authorization consumed:
  true;
- certificate-v3 active authorization count:
  zero;
- mutation:
  forbidden;
- deletion:
  forbidden.

Do not reuse their authorization.

──────────────────────────────────────────────── LIMITED TO FAILURE EVIDENCE
────────────────────────────────────────────────

4. FAILED REAL-AUDIT WRAPPER EVIDENCE

FAILED_REAL_AUDIT_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-v9k0tyf6

Expected root identity:

- device:
  16777234
- inode:
  182768861
- mode:
  0700
- UID/GID:
  501/0

FAILED_REAL_AUDIT_WORKSPACE:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-3ct88a_q

Expected root identity:

- device:
  16777234
- inode:
  182768862
- mode:
  0700
- UID/GID:
  501/0

Expected wrapper report:

report/final-operative-report-v1.json

Resolve its exact identity from the wrapper registry.

Expected failure facts:

- primary verdict:
  AUDIT_PROVENANCE_MISMATCH;
- real audit parent created:
  true;
- authorization consumed:
  true;
- exit:
  1;
- signal:
  null;
- stdout:
  empty;
- stderr:
  unhandled traceback;
- terminal frame:
  absent;
- capsule root:
  absent;
- requested missing subject path:
  validation/contract-schema-satisfiability-matrix-v2.json;
- substantive audit:
  not reached;
- subject verdict:
  not issued;
- retry:
  forbidden.

Authenticate exact raw stderr and process custody.

Resolve the traceback’s exact:

- source member;
- function;
- call chain;
- requested root/path;
- open operation;
- exception type;
- surrounding role or consumer context.

Use this root only as failure evidence.

Do not execute any source from it.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. REPLACEMENT SUBJECT
──────────────────────────────────────────────── LIMITED TO COMPATIBILITY
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID/GID:
  501/20

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files;
- root row exactly once;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory/file modes:
  0700/0600;
- no cache or bytecode.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4

Expected manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16620 each
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Authenticate read-only.

The subject may be used in this task only for:

- exact manifest/path closure;
- role and artifact registry resolution;
- dependency compatibility;
- schema/identity checks for required audit inputs.

Do not perform the real witness, 946, 137, field-map, documentary-validator,
confirmation, occupancy, finding, or verdict audit.

Do not mutate or clean the subject.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING CONSTRUCTION PROVENANCE
────────────────────────────────────────────────

6. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID/GID:
  501/0

Authenticate only:

- exact subject locator;
- accepted implementation chain;
- producer input roles;
- subject artifact plan;
- subject package status;
- producer terminal closure;
- no second construction.

Do not use wrapper prose as subject evidence-role authority.

Require opening/closing equality.

────────────────────────────────────────────────

7. CURRENT CONTENT AUTHORITY

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before ZIP interpretation.

Require:

- 479 members;
- eight current roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive-validation evidence;
- no `.DS_Store`.

Resolve current authority for:

- normative contract;
- current schemas;
- schema-role registry;
- generated-family specification;
- validation specifications;
- 946 registry;
- 137 registry;
- field-map specification;
- documentary-validator specifications;
- confirmation-evidence specifications.

The containing directory is nonauthoritative.

Require opening/closing equality.

────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION CHAIN
──────────────────────────────────────────────── LIMITED TO SOURCE LINEAGE
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only:

- accepted implementation chain;
- accepted production source and freeze;
- subject construction contract;
- replacement construction used accepted source;
- no implementation supersession.

Do not re-audit the implementation.

Require opening/closing equality.

────────────────────────────────────────────────

9. FRESH REPAIR AND OUTPUT ROOTS

Allocate one fresh private repair root beneath `/private/tmp`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-replacement-subject-audit-input-role-repair-`.

Immediately emit:

AUDIT_INPUT_ROLE_REPAIR_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-`.

Immediately emit:

AUDIT_INPUT_ROLE_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit-v2.pyz

gen2-replacement-schema-subject-independent-audit.authority-v2.json

gen2-replacement-schema-subject-independent-audit.launch-profile-v3.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v4.json

The output directory is nonauthoritative.

Before source extraction retain:

opening/bootstrap-start.json
opening/audit-input-role-repair-authority-v1.json
opening/fixed-input-registry-v1.json
opening/consumed-audit-disposition-v1.json
opening/source-adoption-authority-v1.json
opening/process-execution-policy-v1.json
opening/implementation-operating-freeze-v1.json

────────────────────────────────────────────────

10. CURRENT SOURCE ADOPTION

Resolve all current source members through:

- current PYZ member registry;
- current source freeze;
- current source registries;
- runtime authority.

Extract exact source members to the fresh repair root using:

- stable ZIP-member read;
- exact member identity;
- exclusive creation;
- mode 0600;
- byte-for-byte verification.

Classify extracted source as:

AUTHENTICATED_CURRENT_CLEAN_AUDIT_SOURCE_REPAIR_BASE

It is:

- noncurrent in the successor generation before qualification;
- not independently accepted merely by extraction;
- eligible only for the bounded repair in this task.

Retain:

opening/adopted-audit-source-registry-v1.json
opening/adopted-audit-source-copy-result-v1.json

Require:

- complete source count;
- zero missing source;
- zero extra source;
- zero transformation;
- no line-ending change;
- no generated substitution.

────────────────────────────────────────────────

11. EXACT FAILURE CROSSWALK

Before source modification retain:

analysis/missing-subject-evidence-path-failure-crosswalk-v1.json

Crosswalk:

- traceback;
- current source member;
- source function/class;
- AST node;
- call chain;
- subject-root operand;
- requested path literal;
- expected record schema;
- consuming audit phase/domain;
- expected semantic purpose;
- current subject manifest;
- current subject role registries;
- current validation specifications;
- content-authority roles.

Required requested path:

validation/contract-schema-satisfiability-matrix-v2.json

Determine the exact semantic evidence role intended by that request.

Do not infer the role solely from the filename.

Retain exact answers:

1. Which audit domain consumes this record?
2. What semantic fact does it provide?
3. Which governing authority defines that fact?
4. Is that fact required in the current subject package?
5. Is it represented by another current subject artifact?
6. If represented elsewhere, what exact current role/path/identity owns it?
7. If absent, is absence a direct package defect, explicit nonapplicability, or
   audit input-model error?
8. Why did prior synthetic and qualification runs not expose the mismatch?
9. Which exact source and qualification surfaces require repair?

Classify the immediate failure as one of:

STALE_HARD_CODED_SUBJECT_PATH

MISSING_REQUIRED_SUBJECT_EVIDENCE_ROLE

OBSOLETE_OR_NONAPPLICABLE_AUDIT_DEPENDENCY

AMBIGUOUS_OR_UNAUTHENTICATED_ROLE_MAPPING

MIXED_INPUT_MODEL_DEFECT

Do not classify the replacement subject as blocked in this task.

────────────────────────────────────────────────

12. CURRENT SUBJECT AUDIT-DEPENDENCY REGISTRY

Retain:

contract/current-subject-audit-dependency-registry-v1.json

Enumerate every acceptance-bearing subject record the real audit may request.

Do not limit this registry to the first failed path.

Every row contains:

- semantic dependency role;
- audit domain and phase consumers;
- governing authority role/path/schema;
- required, optional, or conditionally applicable status;
- applicability predicate;
- exact current subject role;
- exact current subject relative path when present;
- current record schema;
- expected identity fields;
- current presence status;
- missing-role disposition:
  - DIRECT_PACKAGE_FINDING,
  - EXPLICIT_NOT_APPLICABLE,
  - AUDIT_PROVENANCE_FAILURE;
- duplicate-role disposition;
- consumers;
- historical aliases:
  forbidden;
- direct path fallback:
  forbidden.

Derive rows from:

- current subject manifests;
- current subject role registries;
- artifact plan;
- current-role occupancy;
- documentary-validator registry;
- confirmation-evidence map;
- current content authority;
- governing validation specifications.

Require:

- unique semantic roles;
- unique current path for each present role;
- no two roles silently sharing one artifact unless explicitly governed;
- every acceptance-bearing subject read covered;
- no required audit dependency omitted.

────────────────────────────────────────────────

13. SEMANTIC SUBJECT INPUT RESOLVER

Retain:

contract/semantic-subject-input-resolution-v1.json

Implement a resolver with exact outcomes:

PRESENT_UNIQUE

- one authenticated current subject artifact;
- exact path and schema returned.

REQUIRED_ABSENT

- governing authority requires the role;
- no current artifact exists;
- return a structured direct package-finding candidate;
- do not raise `ENOENT`;
- do not stop capsule construction.

OPTIONAL_ABSENT

- governing applicability says not required;
- retain explicit nonapplicability;
- continue.

AMBIGUOUS

- multiple current candidates;
- audit provenance failure.

UNAUTHENTICATED

- identity, schema, or authority cannot close;
- audit provenance failure.

WRONG_SCHEMA

- current path exists but record schema does not match;
- classify according to governing ownership:
  direct package finding when current subject owns the requirement;
  otherwise audit provenance failure.

No resolver branch may expose an unhandled filesystem exception.

No acceptance-bearing source may construct a subject path directly from a
versioned filename.

────────────────────────────────────────────────

14. BOUNDED SOURCE REPAIR

Permit initial source changes only to:

- the subject input resolver;
- the exact consumer that requested the stale path;
- audit dependency registry loading;
- handled finding/provenance projection;
- directly affected qualification and independent validation source.

Do not change:

- 15/14 semantic model;
- 946 vocabulary;
- 137 vocabulary;
- total documentary checking;
- dual-oracle semantics;
- witness semantics;
- field-map semantics;
- documentary-validator semantics;
- confirmation semantics;
- finding ownership rules;
- terminal-capsule lifecycle;
- split-root runtime behavior;
- no-VCS policy.

Retain:

analysis/current-to-successor-source-delta-v1.json
contract/protected-audit-source-surface-v1.json

Require:

- exact changed functions;
- exact added functions;
- no unrelated removed function;
- all unrelated functions AST-identical;
- no subject semantic change;
- no validation-case expectation change;
- no acceptance-rule change.

────────────────────────────────────────────────

15. SUBJECT-INPUT RESOLUTION MATRIX

Run at least 70 uniquely named cases.

A. Present-role resolution

- exact current baseline;
- exact current role/path;
- current path with expected schema;
- exact identity join;
- role present through documentary registry;
- role present through confirmation map;
- role present through occupancy registry.

B. Stale paths

- exact historical failing path absent;
- same semantic role at another current path;
- same basename under unrelated role;
- version-v1/v2/v3 name differences;
- obsolete path literal;
- historical alias;
- direct filesystem fallback.

C. Required absence

- required role missing;
- required path removed;
- required role absent from artifact plan;
- required role absent from manifest;
- required artifact path missing physically;
- required schema mismatch.

Require handled direct package-finding output, not exception.

D. Optional/nonapplicable absence

- optional absent;
- condition false;
- unsupported historical lane absent;
- explicit nonapplicable role.

E. Provenance failures

- duplicate role;
- two paths for one role;
- one path with two conflicting roles;
- wrong identity;
- wrong schema under unauthenticated ownership;
- stale current flag;
- historical artifact marked current;
- ambiguous identity join;
- unknown role;
- registry missing.

F. Runtime behavior

- `ENOENT` from required role becomes structured result;
- `ENOENT` from optional role becomes nonapplicability;
- permission error;
- symlink;
- special object;
- path escape;
- unhandled exception forbidden.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/subject-input-resolution-matrix-v1.json

────────────────────────────────────────────────

16. INDEPENDENT SUBJECT-INPUT VALIDATOR

Create an independently authored validator that imports neither:

- repaired resolver;
- dependency-registry producer;
- matrix generator;
- expected-result map;
- path normalizer;
- finding projector.

It must independently:

1. authenticate the replacement subject manifest;
2. reconstruct current subject roles;
3. reconstruct all required audit dependencies;
4. identify the intended role of the historically requested matrix;
5. validate every role/path/schema join;
6. verify no acceptance-bearing direct path literal remains;
7. validate required/optional/ambiguous dispositions;
8. run independent negative cases;
9. require zero errors.

Retain:

validation/independent-subject-input-resolution-validator-v1.json

────────────────────────────────────────────────

17. STATIC DIRECT-PATH AUDIT

Run source-external AST and bytecode inspection over all successor source.

Retain:

validation/acceptance-bearing-subject-path-static-audit-v1.json

Require:

- every subject file open originates from the semantic resolver;
- no direct versioned subject path literal in acceptance-bearing source;
- no `subject_root / "validation/..."` outside the resolver;
- no basename search;
- no prefix/suffix/recency/first-match selection;
- no broad root scan;
- no fallback alias;
- no catch-and-ignore `ENOENT`;
- all missing-role outcomes structured.

Diagnostic text, regression case names, and historical failure descriptions may
contain the old path but must be nonoperative.

────────────────────────────────────────────────

18. EXACT SUBJECT-COMPATIBILITY PREFLIGHT

After the dependency registry and resolver qualify, run one read-only
compatibility preflight against the exact replacement subject.

This is not the real subject audit.

It must:

- authenticate subject identity and manifests;
- enumerate every audit dependency role;
- resolve every role;
- open and strict-parse every present required record;
- verify expected schemas and identities;
- record optional/nonapplicable roles;
- record required-absent roles as structured compatibility findings;
- execute no witnesses;
- execute no 946 cases;
- execute no 137 cases;
- execute no field-map resolution;
- execute no documentary semantic adjudication;
- issue no subject ACCEPT/BLOCK;
- create no audit capsule.

Retain:

validation/replacement-subject-audit-input-compatibility-v1.json

Required output:

- total dependency roles;
- present unique;
- required absent;
- optional absent;
- ambiguous;
- unauthenticated;
- wrong schema;
- exact path/identity rows;
- no exception.

A required-absent role does not block harness packaging if the repaired harness
is qualified to produce an authoritative terminal BLOCK for that condition.

An ambiguous or unauthenticated mapping blocks harness packaging.

────────────────────────────────────────────────

19. REGRESSION PRESERVATION

Rerun unchanged:

- exact 15/14 qualification;
- complete 946 vocabulary qualification;
- complete 137 vocabulary qualification;
- total documentary checking;
- dual-oracle qualification;
- occupancy vocabulary;
- evidence-derived confirmations;
- physical closure and A15 qualification;
- no-Git/VCS qualification;
- all historical null/wrong-type regressions;
- all previous logic matrices.

Require exact prior case-name and expected-result closure.

No existing semantic expectation may change.

────────────────────────────────────────────────

20. PACKAGED SYNTHETIC REHEARSALS

Build a provisional successor audit package.

Run physically distinct packaged rehearsals:

A. ACCEPT

- all required roles present;
- all semantic lanes pass;
- terminal ACCEPT capsule.

B. DIRECT SUBJECT BLOCK — REQUIRED ROLE ABSENT

- remove one governed required subject evidence role from the synthetic fixture;
- resolver returns `REQUIRED_ABSENT`;
- exact direct package finding retained;
- primary repair owner retained;
- no unhandled exception;
- terminal BLOCK capsule.

C. AUDIT PROVENANCE — AMBIGUOUS ROLE

- two current candidates for one role;
- terminal provenance-mismatch capsule;
- no package verdict promotion.

D. HISTORICAL PATH REGRESSION

- old path
  `validation/contract-schema-satisfiability-matrix-v2.json`
  absent;
- semantic role present under the fixture’s current path;
- audit proceeds through all required input resolution;
- no exception;
- terminally closed expected disposition.

E. COMPLETE SUBJECT-INPUT COMPATIBILITY

- every registry role exercised;
- no direct path fallback;
- exact access-set equality.

Every rehearsal must:

- use packaged source;
- retain process custody;
- retain phase records;
- retain cleanup and fixed-input equality;
- create temporal inventory and byte-identical manifests;
- pass final reprojection;
- make A15 equal closure pass;
- perform no postseal operation;
- pass independent capsule validation.

Do not use the real replacement subject for substantive rehearsal verdicts.

────────────────────────────────────────────────

21. SOURCE FREEZE

Freeze successor source only after:

- source compilation passes;
- subject-input matrix passes;
- independent input validator passes;
- direct-path static audit passes;
- exact subject compatibility preflight completes without ambiguity or
  unauthenticated role;
- all regression suites pass;
- all packaged rehearsals pass;
- independent capsule validators pass.

Retain:

opening/successor-audit-source-freeze-v1.json

Bind:

- predecessor source identities;
- bounded source delta;
- dependency registry;
- input resolver;
- compatibility preflight;
- all qualification;
- all rehearsals;
- future invocation;
- real audit not executed;
- subject verdict not issued;
- later modification forbidden.

Reopen every source no-follow.

Do not modify afterward.

────────────────────────────────────────────────

22. DETERMINISTIC SUCCESSOR AUDIT PYZ

Build independently twice:

gen2-replacement-schema-subject-independent-audit-v2.pyz

Require byte equality.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- `create_system=3`;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special member;
- no comment or uncontrolled extra;
- no cache or bytecode.

Embed:

- successor clean source;
- successor source freeze;
- exact current governing contracts and registries;
- current-subject audit-dependency registry;
- semantic input-resolution contract;
- compatibility-preflight result;
- all qualification and rehearsal evidence;
- future real-audit invocation;
- no historical source.

Retain exact member registry and count.

────────────────────────────────────────────────

23. SUCCESSOR RUNTIME AUTHORITY V2

Build independently twice:

gen2-replacement-schema-subject-independent-audit.authority-v2.json

Bind:

- exact successor PYZ;
- member registry;
- successor source freeze;
- source registries;
- predecessor harness identities and consumed disposition;
- replacement subject identity;
- construction wrapper identity;
- content inputs;
- accepted implementation chain;
- audit-dependency registry;
- subject compatibility result;
- qualification and rehearsals;
- future invocation;
- real subject audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Require byte equality.

────────────────────────────────────────────────

24. POST-PACKAGE QUALIFICATION

Run the exact successor PYZ in qualification mode once with runtime authority
v2.

Retain full custody.

Require fresh verification of:

- PYZ/member closure;
- source freeze;
- input-role registry;
- semantic resolver;
- compatibility preflight;
- all unchanged semantic qualification;
- packaged rehearsals;
- independent validators;
- deterministic package closure;
- no real subject audit;
- no subject verdict.

────────────────────────────────────────────────

25. SUCCESSOR SPLIT-ROOT LAUNCH PROFILE V3

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-profile-v3.json

Preserve the qualified split-root policy:

- wrapper workspace:
  existing cwd;
- capsule root:
  absent `audit-capsule` child;
- unchanged five-row environment;
- `DEVNULL`;
- shell/TTY/detachment false;
- exact platform preflight;
- authorization consumed on process creation.

Update only bindings required by:

- successor PYZ identity;
- successor runtime-authority identity;
- successor invocation.

Require deterministic byte equality and mode 0400.

────────────────────────────────────────────────

26. SUCCESSOR LAUNCH CERTIFICATE V4

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v4.json

Bind:

- successor profile v3;
- successor PYZ;
- successor runtime authority v2;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation chain;
- source freeze;
- dependency registry;
- compatibility preflight;
- qualification and rehearsal evidence;
- split-root policy;
- exact framing contract;
- predecessor certificate v3:
  historical and consumed;
- all earlier certificates:
  historical;
- exactly one active successor authorization;
- real audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Require deterministic byte equality and mode 0400.

Run independent certificate-input validation.

────────────────────────────────────────────────

27. FROZEN-PACKAGE REQUALIFICATION

Run the final successor PYZ in qualification mode with final authority v2.

Require:

- exit zero;
- empty stderr;
- exact result;
- package/source self-authentication;
- subject-input resolution closure;
- compatibility-preflight linkage;
- all old and new qualification;
- packaged rehearsal linkage;
- authority coherence;
- no real subject audit;
- no subject verdict.

Independently recompute all aggregates.

Retain:

validation/frozen-successor-audit-pyz-requalification-v1.json

────────────────────────────────────────────────

28. CURRENT AUTHORITY REGISTRY

Retain:

contract/current-successor-audit-authority-role-registry-v1.json

Current roles:

- successor audit PYZ v2;
- successor runtime authority v2;
- successor launch profile v3;
- successor launch certificate v4.

Historical roles:

- predecessor audit PYZ;
- predecessor runtime authority;
- profile v2;
- certificate v3;
- all earlier launch artifacts.

Require:

- exactly one current value per role;
- no ambiguity;
- predecessor real-audit authorization consumed;
- successor authorization unconsumed;
- total active future real-audit authorization:
  one.

────────────────────────────────────────────────

29. INPUT CLOSING EQUALITY AND CLEANUP

Repeat complete opening/closing equality for every supplied input opened:

- predecessor PYZ;
- predecessor runtime authority;
- consumed profile v2;
- consumed certificate v3;
- failed real-audit wrapper root;
- failed real-audit workspace;
- replacement subject;
- construction wrapper;
- content bundle;
- content authority;
- accepted implementation roots.

Do not mutate supplied inputs.

Before removing disposable roots retain complete evidence.

Then revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

────────────────────────────────────────────────

30. FAILURE CLOSEOUT

On failure retain:

- first blocker;
- role-resolution adjudication;
- source identities;
- bounded delta;
- process records and streams;
- matrices;
- compatibility preflight;
- rehearsal results;
- partial output inventory;
- cleanup;
- input equality;
- predecessor/successor authority posture;
- real audit not executed;
- subject verdict not issued.

Do not create current successor authority on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

31. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

only when:

- all fixed inputs authenticate;
- historical failure crosswalk closes;
- intended missing-path semantic role is adjudicated;
- complete subject audit-dependency registry closes;
- semantic resolver qualifies;
- no acceptance-bearing direct subject path remains;
- compatibility preflight has no ambiguous or unauthenticated role;
- all prior semantic qualification passes unchanged;
- packaged ACCEPT/BLOCK/provenance/path-regression rehearsals pass;
- source freezes;
- successor PYZ Builds A/B match;
- authority-v2 Builds A/B match;
- post-package qualification passes;
- profile-v3 Builds A/B match;
- certificate-v4 Builds A/B match;
- certificate validation passes;
- frozen-package requalification passes;
- current authority registry closes;
- exactly one unconsumed successor audit authorization exists;
- input equality and cleanup pass;
- final artifacts have mode 0400;
- no real subject audit ran;
- no subject verdict was issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_REPAIR_BLOCKED

when:

- the intended semantic role cannot be uniquely established;
- governing subject authorities contradict each other;
- compatibility preflight contains an ambiguous or unauthenticated role;
- repair requires changing subject semantic contracts or validation
  expectations;
- bounded repair cannot qualify without a clean audit-source rewrite.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- source adoption mismatch;
- forbidden source origin;
- evidence loss;
- custody failure;
- cleanup inequality;
- supplied-input mutation;
- source drift after freeze;
- deterministic-output mismatch;
- final-output identity failure;
- Git/VCS or network activity.

────────────────────────────────────────────────

32. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve predecessor audit and launch artifacts;
- preserve failed real-audit evidence;
- preserve content and accepted implementation inputs;
- preserve successful successor artifacts;
- do not execute the real subject audit;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

33. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh repair-root identity
3. Fresh output-root identity
4. Predecessor PYZ identity
5. Predecessor runtime-authority identity
6. Consumed profile-v2/certificate-v3 disposition
7. Failed real-audit wrapper/workspace disposition
8. Replacement-subject identity
9. Construction-wrapper identity
10. Content identities
11. Accepted implementation chain
12. Adopted source registries and copy result
13. Exact failure traceback/call-chain crosswalk
14. Requested missing path
15. Intended semantic evidence role
16. Governing authority for that role
17. Current subject representation or absence
18. Immediate failure classification
19. Complete subject audit-dependency registry
20. Resolver outcome model
21. Bounded source delta
22. Protected-source comparison
23. Subject-input resolution matrix
24. Independent input-resolution validator
25. Direct-path static audit
26. Exact replacement-subject compatibility preflight
27. Regression preservation
28. Packaged ACCEPT rehearsal
29. Packaged required-role-absent BLOCK rehearsal
30. Packaged ambiguous-role provenance rehearsal
31. Historical path-regression rehearsal
32. Independent capsule validation
33. Source freeze
34. Successor PYZ Build A/B
35. Successor PYZ member closure
36. Authority-v2 Build A/B
37. Post-package qualification
38. Profile-v3 Build A/B
39. Certificate-v4 Build A/B
40. Certificate-input validation
41. Frozen-package requalification
42. Current authority registry
43. Exactly-one-active-authorization result
44. Input closing equality
45. Cleanup
46. Confirmation real subject audit not executed
47. Confirmation no subject verdict
48. Final successor PYZ path/identity
49. Final authority-v2 path/identity
50. Final profile-v3 path/identity
51. Final certificate-v4 path/identity
52. Remaining uncertainty/nonclaims
53. Explicit confirmations

Required confirmations:

PREDECESSOR_AUDIT_PYZ_IDENTITY_MATCHED
PREDECESSOR_RUNTIME_AUTHORITY_IDENTITY_MATCHED
CONSUMED_PROFILE_V2_IDENTITY_MATCHED
CONSUMED_CERTIFICATE_V3_IDENTITY_MATCHED
PREDECESSOR_REAL_AUDIT_AUTHORIZATION_CONSUMED
FAILED_REAL_AUDIT_WRAPPER_AUTHENTICATED
FAILED_REAL_AUDIT_WORKSPACE_AUTHENTICATED
UNHANDLED_MISSING_SUBJECT_PATH_REPRODUCED
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_AUDIT_SOURCE_ADOPTED_BYTE_IDENTICAL
MISSING_PATH_SEMANTIC_ROLE_ADJUDICATED
CURRENT_SUBJECT_AUDIT_DEPENDENCY_REGISTRY_COMPLETE
EVERY_ACCEPTANCE_BEARING_SUBJECT_INPUT_HAS_SEMANTIC_ROLE
NO_ACCEPTANCE_BEARING_DIRECT_SUBJECT_PATH_LITERAL
REQUIRED_ABSENT_ROLE_PRODUCES_HANDLED_PACKAGE_FINDING
OPTIONAL_ABSENT_ROLE_PRODUCES_EXPLICIT_NONAPPLICABILITY
AMBIGUOUS_ROLE_PRODUCES_AUDIT_PROVENANCE_FAILURE
NO_UNHANDLED_ENOENT
SUBJECT_INPUT_RESOLUTION_MATRIX_PASSED
INDEPENDENT_SUBJECT_INPUT_VALIDATOR_PASSED
DIRECT_PATH_STATIC_AUDIT_PASSED
REPLACEMENT_SUBJECT_INPUT_COMPATIBILITY_PREFLIGHT_COMPLETED
NO_AMBIGUOUS_COMPATIBILITY_ROLE
NO_UNAUTHENTICATED_COMPATIBILITY_ROLE
PRIOR_SEMANTIC_QUALIFICATION_PRESERVED
PACKAGED_ACCEPT_REHEARSAL_PASSED
PACKAGED_REQUIRED_ROLE_ABSENT_BLOCK_REHEARSAL_PASSED
PACKAGED_AMBIGUOUS_ROLE_PROVENANCE_REHEARSAL_PASSED
HISTORICAL_PATH_REGRESSION_REHEARSAL_PASSED
INDEPENDENT_CAPSULE_VALIDATION_PASSED
SUCCESSOR_SOURCE_FROZEN
SUCCESSOR_SOURCE_NOT_MODIFIED_AFTER_FREEZE
SUCCESSOR_AUDIT_PYZ_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_AUDIT_PYZ_MEMBER_CLOSURE_PASSED
SUCCESSOR_RUNTIME_AUTHORITY_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
SUCCESSOR_PROFILE_V3_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_V4_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_SUCCESSOR_PYZ_REQUALIFICATION_PASSED
CURRENT_SUCCESSOR_AUTHORITY_REGISTRY_COMPLETE
EXACTLY_ONE_ACTIVE_FUTURE_REAL_AUDIT_AUTHORIZATION
PREDECESSOR_AUTHORIZATION_NOT_REUSED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_INPUT_ROLE_RESOLUTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

the next task is exactly one real audit using:

1. successor audit PYZ v2;
2. successor runtime authority v2;
3. successor launch profile v3;
4. successor launch certificate v4;
5. unchanged replacement subject;
6. construction wrapper;
7. content bundle and authority;
8. accepted implementation authority chain.

Do not combine harness repair with the real audit.
```

## Source and confidence

The attached report establishes that launch authority, split-root custody, fixed inputs, and package closure all passed, while the real audit failed unhandled on a nonexistent versioned subject path before creating any capsule or substantive audit evidence. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

It also establishes that the subject remained unchanged and that the current authorization is consumed with no future authorization left under certificate v3. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

**Provenance confidence:** 0.999  
**No-subject-verdict confidence:** 0.999  
**Audit input-role defect confidence:** 0.995  
**Unchanged-subject reuse confidence:** 0.995  
**Next-step confidence:** 0.98

The latest attachment was fully readable. Some older project uploads have expired; re-upload an older artifact only when its original bytes, rather than the retained reports and identities, are required.
