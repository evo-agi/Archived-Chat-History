Here is Codex's response:



# 1. Verdict

REPAIR10I\_RECONNAISSANCE\_READY

The opening gate passed, all 15 audit-reported findings were recovered and independently traced to exact source/evidence, and one executable Repair 10I plan is frozen below. This is implementation-plan readiness—not an independent audit acceptance, and not retroactive qualification of any Repair 10H artifact.

# 2. Opening and closing identities

Roots used below:

- `R`: [exact candidate repository](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1>)
- `H`: [sealed Phase H child](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d)
- `C`: [sealed capture child](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-00280085500a-fwAgN6fQWCdn)
- `A`: [sealed audit child](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/audit-integrated-00280085500a-gBIiZSZFeFK4)

The opening and closing reads agreed:

| IdentityOpening and closing value |                                                                    |
| --------------------------------- | ------------------------------------------------------------------ |
| Branch                            | `codex/remote-alpha-external-tls-status-observation-v1`            |
| HEAD                              | `567bceced5df95ecfe787cc66038d463a854e12c`                         |
| Sole parent                       | `05dde14d185b6e022dcc169ef1a658a97961850f`                         |
| HEAD tree                         | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                         |
| Upstream                          | absent                                                             |
| Index SHA-256                     | `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31` |
| Candidate T                       | `00280085500a40dc4a931b416fc00f0f1c9bf1e9`                         |
| Candidate inventory               | `ede21d8fe52e22ed12b37bca9c4ed97f89ae0a99a0198d77160fcbe16e4545ec` |
| Membership                        | 375 tracked + 14 nonignored untracked = 389                        |
| Staged/deleted/renamed/unmerged   | `0/0/0/0`                                                          |

Seal identities:

| ArtifactExact verification |                                                                                                                                                                                                                                                |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Phase H                    | Manifest 1,223,514 bytes, SHA-256 `fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb`; 6,191 payloads, 6,193 files, 1,102 directories; detached-file SHA-256 `238f72b2f71983f632d20c99de5848b83dd377735eeac3c09fcddb2e1bc6486c` |
| Capture child              | Manifest 73,589 bytes, SHA-256 `c27f7dbe00bd27ad4abf4d2564792b9bb73918bd594ce6a6aab5498cef89e090`; 499 payloads, 501 files, 98 directories; detached-file SHA-256 `896f4f48aa2a28d7e83582424685569916e790b03288fae081f33db54a4a9fe7`           |
| Audit child                | Manifest 193,460 bytes, SHA-256 `f020099e959e8a4cce0d929fbbcdf99aaa0ddd44e6c6d915bb5ab4ead0817152`; 815 payloads, 817 files, 196 directories; detached-file SHA-256 `0640ae7669856218c8f2c1ac8c19069262a71709485bb63d25b4270f66cf7f66`         |
| Audit report               | 51,232 bytes, SHA-256 `672dbb788759058ec4e76a99973d38ea8db342219d66c5679b67717e86ccd3cf`; included consistently in the audit seal                                                                                                              |
| Integrated ZIP             | 2,338,208 bytes, SHA-256 `86f3d17a2d672964575f2273ae397ee71f479fc5d8d057065a206d83f9205ca6`; 389 unique, CRC-clean members                                                                                                                     |
| Handoff                    | 26,930 bytes, SHA-256 `abd1526c155644f3f576ede15c0de5d39773da96be4717ad8e8784a8f7d8da0d`                                                                                                                                                       |

Current ZIP state remained unchanged during reconnaissance:

- device `16777234`, inode `169973340`, mode `0600`, UID/GID `501/0`, link count `1`;
- mtime `1789260037627941012 ns`;
- ctime `1789260039495423242 ns`;
- birth time `1789260037406410240 ns`;
- xattr names: `com.apple.macl`, `com.apple.provenance`.

Git-administration checks:

- Common Git inventory: 5,707 rows.
- Linked-worktree administration inventory: 10 rows.
- Nonvolatile refs SHA-256: `270f5932f520649b72fa0b922969253dd54e55ae648fad8ed599196be273f0a4`.
- Raw refs inventory SHA-256: `9a30a871…c8b` was recorded at opening; the exact stable nonvolatile digest above was reproduced at closing.
- Candidate-ref identity digest: `35a27ba96b6a5737a238ef7b1d2aec9b6ba0817da8a0b0caef6e56e4b08197c7`.
- Git config SHA-256: `825adf46ee7247944a876af9a1c5cc5ff04d99b4a94acffc0ce60dbbea082368`.
- Packed-refs SHA-256: `b33d296f791585d8b645716879952f83f236fb4941851b4f7996c59688ed822f`.
- Linked HEAD SHA-256: `6c07176712a72c2da0edb6d7ab4954741d3db80cb7ba241446fb91c3d8a0e358`.
- A closing before/after administration pass produced unchanged common/linked aggregates `c7666ecf86e5c735e91862fbe5f958e4ba742ee7a3b0b754201d9ad55edef854` and `5d98dec3dc73b23fa8f516cd47a8fbc92145a639b6091e2e10e607dd51732dc0`, with no changed path.

Every Git read used `GIT_OPTIONAL_LOCKS=0`. Ordinary `git status` was not used.

# 3. Audit-protocol deviation assessment

The primary capture-provenance mismatch is valid:

- Initial recorded ZIP ctime: `1789260039405070275 ns`.
- Recovery ctime: `1789260039495423242 ns`.
- Delta: `90,352,967 ns`.
- No pre-recovery xattr-name or xattr-value-digest baseline exists.
- Consequently, historical no-xattr-mutation cannot be reconstructed.

This does not establish ZIP corruption, source drift, republication, or actual xattr mutation. ZIP bytes, inode, membership, CRCs, raw headers, source T, and inventory remain exact.

The audit’s initial gate deviated narrowly by trusting `recovery_did_not_republish_or_mutate_zip=true` without reconciling the changed ctime or missing xattr baseline. Its final analysis corrected that mistake and applied the required provenance disposition.

Because the audit protocol required stopping on that mismatch, all later findings remain audit-reported leads. This reconnaissance independently verified their cited bytes, source mechanisms, evidence bindings, and causal reachability, but did not convert them into an accepted independent-audit adjudication.

No production observer defect or privacy leak was found.

# 4. Explorer outcomes and preserved disagreements

Exactly four bounded read-only explorers ran; none delegated further.

| ExplorerOutcome                       |                                                                                                                                                                                                                                                                                                                                                                              |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Authority, contracts, capture         | Confirmed F-AUTH-001 and both capture findings. The Repair 10H lifecycle-order block itself is consistent: the same 910-byte block, SHA-256 `eb4db022c49e266a23ab13326b871b80400e8cc7b6f9ebdab75b43a320c8bb69`, appears across all ten governing lifecycle pages. Existing authority has a ctime/xattr-policy gap, not a contradiction. Recommended byte-transport identity. |
| Product tests, typed canonicalization | Confirmed F-PRIV-001 and F-SUCC-001/002/003/004/006. No production privacy defect. Also found that `OutsideSentinel`, in addition to `OpenUngrantedListener`, affects behavior but is absent from logical fingerprinting.                                                                                                                                                    |
| Mutant, qualification, comparator     | Confirmed F-SUCC-004/005 and F-QUAL-001/002. The intended mutant is exactly reconstructable, but the consumed provenance payload was not retained. No audit execution exists for the forged-envelope causal.                                                                                                                                                                 |
| Validation, evidence, sequence        | Reconciled retained Phase H, audit-fresh, and unexecuted validation. Recommended two separately hard-gated finite subtranches.                                                                                                                                                                                                                                               |

Preserved disagreements and parent resolution:

- Some explorer reasoning proposed H-owned replacement schemas. The parent freezes a complete I-owned active dialect: H is immutable historical evidence, while Repair 10I changes qualification semantics. F/G/H records remain parse-only/report-only.
- The validation explorer proposed changing `tool/source/cmd/repair10-compare/main.go`. Parent inspection found no independent phase/schema/policy logic there, so it stays byte-identical unless an API-signature change proves unavoidable.
- One explorer treated source/tool repair as a single tranche; another required two tranches overall. Resolution: one coherent 10I-A source/tool repair, followed by a separately gated 10I-B validation/evidence/capture tranche.
- The audit’s privacy perspective favored rejection. Parent adjudication remains medium-severity, repairable product-test incompleteness with no production leak.

# 5. Complete recovered finding ledger

Each record below contains the required contract, location, control, causal basis, impact, correction, surfaces, gates, and uncertainty.

### F-AUTH-001 — high → high; candidate source

- **Contract:** Repair 10H is an unaccepted T2A-P `Bounded slice rule`, with no product-authority changes.
- **Paths:** [PLANS.md (line 3481)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:3481>) through 3680; [docs\_contract\_test.go (line 137)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:137>) through 145 and 12676–12686.
- **Positive control:** Removing exact bytes `[246732:252169]` from the 278,434-byte file reconstructs the 272,997-byte Repair 10G plan, SHA-256 `48a0324f939210f66eb23fb6d6792b06fad460b06a9c08885edd359fc6ee7696`. Lifecycle blocks are byte-consistent.
- **Mechanism:** `## Repair 10H` interrupts `## Repair 10B`; B’s resumed body is structurally under H. Whole-document `assertContainsAll` misses the section error.
- **Impact/correction:** Highest design authority contradicts H’s scope. Restore B completely before H, append I after H, and add bounded section/order assertions.
- **Surfaces:** `PLANS.md`, `docs_contract_test.go`.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** none material.

### F-SUCC-001 — high → high; successor tool

- **Contract:** Each typed grammar requires exact package, test/subtest, and complete template scope; unsupported typed-looking text is unknown and blocking.
- **Paths:** [semantic.go (line 417)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:417), ranges 417–472, 525–545, 550–579, 592–651, 656–673.
- **Positive control:** [envelope\_test.go (line 977)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/envelope_test.go:977) through 1137 exercises all eight named grammars.
- **Mechanism:** Recognizers ignore `pkg`; unsupported tests are rejected before candidate detection. Wrong-package text canonicalizes, and unsupported-test candidates avoid unknown.
- **Impact/correction:** Out-of-scope diagnostics can be laundered or bypass the unknown gate. Add exact package/test/subtest registries and candidate-first detection for all eight grammars.
- **Surfaces:** `FORMAT.md`, `semantic.go`, `envelope_test.go`, semantic command integration.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** additional unsupported templates may exist beyond the reproduced controls.

### F-SUCC-002 — high → high; successor tool

- **Contract:** Only exact, ordered panic templates may normalize explicitly typed address positions; message, type, function, file, line, offset, scalar/nil shape, and frame order remain material.
- **Path:** [semantic.go (line 676)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:676) through 762.
- **Positive control:** [envelope\_test.go (line 1139)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/envelope_test.go:1139) through 1224 covers message, nil, line, offset, and partial forms.
- **Mechanism:** Arbitrary dotted functions are admitted, extra calls are not rejected, and every nonzero lowercase hex call argument is replaced. An unlisted function containing `0x1d` versus `0x2a` canonicalizes equal.
- **Impact/correction:** Function/frame/scalar differences can disappear. Replace the regex/minimum-count logic with exact per-package/test ordered templates and typed address positions.
- **Surfaces:** `FORMAT.md`, `semantic.go`, `envelope_test.go`.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** every currently admitted scalar position still needs enumeration in the new exhaustive table.

### F-SUCC-003 — high → high; successor tool

- **Contract:** `logical_bytes=134217727` is allowed; `134217728` and larger are intrinsically blocking.
- **Path:** [semantic.go (line 654)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:654) through 673.
- **Positive control:** H checks lexical malformed cases and below-bound behavior; [envelope\_test.go (line 1091)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/envelope_test.go:1091) through 1112 exposes the mistaken “material only” boundary treatment.
- **Mechanism:** Overbound values return `material=true`, but the acceptance caller gates only on `candidate`; identical `134217728` diagnostics can compare equal.
- **Impact/correction:** A mandatory resource bound can pass accepted equality. Make `candidate || overBound` unknown or an intrinsic blocker.
- **Surfaces:** `FORMAT.md`, `semantic.go`, `envelope_test.go`.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** none for the exact boundary.

### F-SUCC-004 — high → high; qualification/comparator

- **Contract:** HEAD→final and Repair-9→final independently reject every undeclared final-only fail, skip, disappearance, package abort, panic, race, warning, malformed stream, or unknown diagnostic.
- **Paths:** [semantic.go (line 1244)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:1244) through 1274; related outcome handling 1126–1132 and 1303–1310.
- **Positive control:** [envelope\_test.go (line 1414)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/envelope_test.go:1414) through 1464 covers declared historical exceptions, shared pass→skip, package abort, and malformed evidence.
- **Mechanism:** `noFinalOnlyRegressionV1` iterates only baseline identities. New final-only failure and skip identities are omitted and were causally accepted.
- **Impact/correction:** New regressions can receive a no-regression caption. Compare the union of baseline and final identities, permit only explicitly defined new passes, and reject all new/disappeared hazardous outcomes.
- **Surfaces:** `semantic.go`, `envelope_test.go`, comparison specs/results and closeout.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** retained directional captions are report-only until recomputed with the repaired predicate.

### F-SUCC-005 — high → high; qualification/comparator

- **Contract:** The mutant must contain exactly one declared diagnostic tuple and exact lifecycle delta.
- **Paths:** [semantic.go (line 1212)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:1212) through 1234.
- **Positive control:** Exact intended tuple: package `execution-substrate/es/externaltls/internal/statusobservation/remoteobserver`; test `TestRepair10HStructuralPrivacyProjectionCausalControlsV1`; occurrence/ordinal `1/1`; rule `raw-v1`; classification `material`; count `1`; text `    observe_test.go:2454: REPAIR10H-DELIBERATE-ASSERTION-MUTANT-V1\n`; exactly one test and package terminal fail→pass.
- **Mechanism:** Predicate checks only package/test/text/classification, ignores occurrence/ordinal/rule/count, and rewrites every matching lifecycle failure. Two occurrences and bogus `99/99/not-raw/99` values were accepted.
- **Impact/correction:** Undeclared mutant effects can qualify. Compare the complete diagnostic tuple and whole remaining semantics; apply one explicit deep-copied lifecycle patch and reject extra changes.
- **Surfaces:** `semantic.go`, `envelope_test.go`, mutant provenance/specification and comparison closeout.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** all semantic fields must be exhaustively audited rather than assuming these are the only ignored ones.

### F-QUAL-001 — high → high; qualification/comparator

- **Contract:** Qualification must re-extract semantics from the identity-bound raw Go-test stream; producer envelopes and captions are untrusted.
- **Paths:** [semantic.go (line 967)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/semantic.go:967) through 1038; [runner.go (line 2167)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/runner.go:2167) through 2339.
- **Positive control:** Production extraction exists at `runner.go:1949–1970`, and the standalone semantic command invokes it at `cmd/repair10-semantic/main.go:34–65`.
- **Mechanism:** Qualification hashes raw/envelope/mappings and checks the envelope’s raw hash but never calls `ExtractGoTestSemantics` on the bound raw bytes.
- **Impact/correction:** A fabricated but internally self-consistent semantic envelope can qualify. Re-extract from raw using the sealed I successor and exact mappings, compare canonical bytes, and bind the derived digest.
- **Surfaces:** `runner.go`, `semantic.go`, `source.go`, `FORMAT.md`, command mains, tests, all qualification records.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** no actual sealed forgery is alleged; the comparator-side forged-envelope causal was not executed by the audit.

### F-QUAL-002 — high → high; qualification/comparator

- **Contract:** Only the current repair generation may own active acceptance records; older schemas are historical parse-only inputs.
- **Paths:** [runner.go (line 28)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/runner.go:28), 943–1010, 1150, 2167–2285, 2614–2639; [source.go (line 717)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/source.go:717) through 720; [PLANS.md (line 3569)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:3569>) through 3572.
- **Positive control:** H’s mixed-schema test at `envelope_test.go:2433–2483` proves strict mechanical schema checking, but also enshrines the governance mismatch.
- **Mechanism:** Active acceptance requires seven Repair 10G schemas and a Repair 10F effective-read policy. Three active G byte-capture/comparison schemas were also omitted from H’s historical-schema guard.
- **Impact/correction:** H/F/G record generations receive current qualification authority contrary to plan. Mint the complete I-owned dialect below and reject F/G/H schemas on all active I paths.
- **Surfaces:** `FORMAT.md`, `runner.go`, `semantic.go`, `source.go`, tests, command mains, evidence producers and consumers.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** historical reuse may have been intentional, but it was undocumented; Repair 10I resolves that governance ambiguity explicitly.

### F-CAPTURE-001 — medium → medium; capture/transport

- **Contract:** Transport qualification must use a documented, reproducible identity policy.
- **Paths:** `C/capture/zip-publication-v1.json`; `C/recovery/published-zip-reverification-v1.json`; [capture-integrated-snapshot-v1.py (line 1179)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-00280085500a-fwAgN6fQWCdn/capture-integrated-snapshot-v1.py:1179), 1707–1733; [resume-after-xattr-capability-v1.py (line 191)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-00280085500a-fwAgN6fQWCdn/resume-after-xattr-capability-v1.py:191), 277–278, 302–360; `C/closeout/final-capture-report-v1.md:13,18`.
- **Positive control:** Bytes, size, mode, link count, inode, mtime, member set, CRCs, raw headers, T, inventory, extractions, and handoff remain exact.
- **Mechanism:** Ctime changed and no pre-recovery xattr-name/value-digest baseline exists.
- **Impact/correction:** Historical no-xattr-mutation is unprovable. Adopt Option B for a wholly new capture from absent targets; do not recertify the old ZIP.
- **Surfaces:** capture authority docs, new capture scripts, capture/handoff records.
- **Blocks implementation / snapshot only:** no / yes.
- **Uncertainty:** exact ctime cause and whether any xattr name/value changed are permanently unknowable.

### F-PRIV-001 — medium → medium; product test

- **Contract:** Legitimate public values containing `7001`, `7002`, `77001`, and `77002` must be positively exercised in timestamps and other public fields.
- **Path:** [observe\_test.go (line 2423)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statusobservation/remoteobserver/observe_test.go:2423>) through 2435.
- **Positive control:** The audit’s selected privacy runs passed 9/9 top-level executions and 15/15 prohibited-mutant subtests.
- **Mechanism:** `2026-09-12T07:00:02Z` contains none of the four required substrings.
- **Impact/correction:** Timestamp-specific privacy behavior is not causally covered. Add independent RFC3339Nano values ending `.7001Z`, `.7002Z`, `.77001Z`, `.77002Z`; rename/add the I causal test.
- **Surfaces:** `observe_test.go`, governing docs, literal mapping.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** none about the test gap; production behavior was not shown defective.

### F-EVIDENCE-001 — medium → medium; evidence/report

- **Contract:** Every closeout claim must bind to a test that actually proves the claimed causal relationship.
- **Paths:** [implementation-report-v1.md (line 55)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/closeout/implementation-report-v1.md:55) through 59; one-based literal-map entries 2–3 in [literal-assertion-mapping-v1.json](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/closeout/literal-assertion-mapping-v1.json).
- **Positive control:** Genuine paired tests exist: `TestObserverClosingWitnessPrivacyV1` and `TestObserveV1WitnessCustodyClassificationAndContextV1`.
- **Mechanism:** The timestamp claim is false, and paired noninterference points to a test that constructs no paired observer input.
- **Impact/correction:** H overstates proof coverage. Correct the anchors/claims, and make the mapping validator inspect bounded test/causal semantics rather than only existence and hashes.
- **Surfaces:** literal mapping, implementation report, closeout adjudicator.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** no additional false mapping was established among the remaining entries.

### F-SUCC-006 — medium → medium; successor tool

- **Contract:** Logical fingerprints include every non-root-derived `CommandSpec` behavior affecting execution or qualification.
- **Paths:** [runner.go (line 102)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/tool/source/envelope/runner.go:102) through 128, 811–889, 943–974, 1185–1187, 1337–1351, 1533–1608, 2963–2976.
- **Positive control:** Complete suite-spec SHA changes correctly, and H positively tests `ExpectedExit`.
- **Mechanism:** Toggling `OpenUngrantedListener` leaves the logical fingerprint unchanged. Parent inspection also found `OutsideSentinel` omitted despite behaviorally active uses.
- **Impact/correction:** Controls with different resource behavior can claim logical equivalence. Add both fields and an exhaustive exported-field-to-fingerprint-policy table.
- **Surfaces:** `runner.go`, `FORMAT.md`, `envelope_test.go`.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** Listener has an audit causal; sentinel is source-conclusive but lacks a dedicated audit causal.

### F-EVIDENCE-002 — medium → medium; evidence/report

- **Contract:** Exact mutant provenance must be retained before execution, identity-bound, and independently inspectable after private-root cleanup.
- **Paths:** [intentional-mutant-construction-result-v4.json](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d/preparation/intentional-mutant-construction-result-v4.json); `H/commands/repair10h-final-only-mutant-v1.json:113–116`; missing private provenance path.
- **Positive control:** Audit reconstruction produced the exact 1,252-byte record, SHA-256 `e4b7dab8758bba6b4374f0fd4b510ce23ded54bd85648f0e4d816fa52597a70f`, effective T `40b0e9f532d11892732aea442e8d0cd83ad79793`, inventory `5b5c77c46ed964af72a3ee10666a413b9ee0b345588eeeb7ebbeba411af422e9`, and exactly one same-mode changed path.
- **Mechanism:** Selected records cite a deleted private file; no sealed Phase H copy exists.
- **Impact/correction:** Recipe reproducibility is proven, but consumed provenance custody is incomplete. Retain the I provenance payload before execution and bind every suite, qualification, and comparison to it.
- **Surfaces:** preparation script/result, provenance payload, suite specs, qualifications, comparison custody, payload inventory.
- **Blocks implementation / snapshot only:** yes / no.
- **Uncertainty:** an external copy may once have existed, but it is outside the supplied authority set.

### F-CAPTURE-002 — observation → observation; capture/transport

- **Contract:** A failed capture must retain original caller-observed argv, cwd/environment, raw streams through EOF, exit, wait, and reap disposition.
- **Paths:** [resume-after-xattr-capability-v1.py (line 239)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-00280085500a-fwAgN6fQWCdn/resume-after-xattr-capability-v1.py:239) through 269; `C/recovery/initial-execution-failure-*`; failed-attempt index.
- **Positive control:** Commands 1–41, the stopping stage, published ZIP state, failed recipe, and recovery records corroborate the narrative.
- **Mechanism:** The continuation synthesized the traceback transcript and `process_reaped_by_caller=true`; no original outer recorder survives.
- **Impact/correction:** Exact failed-process custody is not independently reproducible. Place all future capture execution behind an outer recorder.
- **Surfaces:** new outer recorder, capture/resumption scripts, failed-attempt records.
- **Blocks implementation / snapshot only:** no / yes if omitted from the future capture.
- **Uncertainty:** an original caller record may exist outside the supplied capture.

### F-AUDIT-001 — low → low; audit process

- **Contract:** Audit-owned output stays beneath its exclusive root; failed attempts remain distinct from accepted evidence.
- **Paths:** `A/failed-attempts/*`; [fresh-execution-ledger-v1.md](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/audit-integrated-00280085500a-gBIiZSZFeFK4/analysis/fresh-execution-ledger-v1.md).
- **Positive control:** Corrected reruns are separately retained; final quiescence found no process, descriptor, cwd, mmap, socket/FIFO, cache, runtime, build, mutant, or temporary survivor.
- **Mechanism:** Several audit harness failures occurred, including one accidental `/tmp/final_sem.txt`, immediately recorded and removed.
- **Impact/correction:** Contained audit-process noise and one temporary path escape. Future audit writers must use audit-root-only output APIs without external shell redirection.
- **Surfaces:** future audit harness only; no candidate repair surface.
- **Blocks implementation / snapshot only:** no / no.
- **Uncertainty:** no syscall trace exists; containment rests on inventories and direct cleanup observations.

No finding is classified as an inherited unrelated issue. The existing red full-suite failures are inherited validation context, not evidence against this patch by themselves.

## Repair 10H claim disposition

| #Repair 10H claimStatusBasis |                                                                                           |                    |                                                                                  |
| ---------------------------- | ----------------------------------------------------------------------------------------- | ------------------ | -------------------------------------------------------------------------------- |
| 1                            | Structural projections preserve numbers and use independent allowlists                    | `CLOSED_CONFIRMED` | Source and selected controls confirm it.                                         |
| 2                            | Paired custody/closing inputs are publicly noninterfering                                 | `CLOSED_CONFIRMED` | Actual paired tests prove it; H’s mapping anchor is inaccurate.                  |
| 3                            | Legitimate collision values survive in PID/timestamp/request/counter/digest/string fields | `PARTIAL`          | Timestamp cases are missing.                                                     |
| 4                            | Private keys/scalars/structures/nesting/laundering are rejected                           | `CLOSED_CONFIRMED` | Five causal mutants exist and passed.                                            |
| 5                            | Each of eight nondeterminism grammars accepts only its full template                      | `PARTIAL`          | Package and unsupported-candidate scope remain defective.                        |
| 6                            | Partial/malformed/ambiguous/unsupported typed text is unknown/blocking                    | `OPEN`             | Unsupported-test candidates can escape unknown.                                  |
| 7                            | One-nibble OID/SHA changes remain visible                                                 | `CLOSED_CONFIRMED` | Negative controls are valid.                                                     |
| 8                            | EPERM/EACCES remains visible                                                              | `CLOSED_CONFIRMED` | Exact grammar preserves the distinction.                                         |
| 9                            | Route/status changes remain visible                                                       | `CLOSED_CONFIRMED` | Observability control preserves both.                                            |
| 10                           | Panic type/message/function/file/line/offset/order remain visible                         | `PARTIAL`          | Arbitrary functions, extra calls, and scalar erasure remain.                     |
| 11                           | Scalar/nil and lifecycle changes remain visible                                           | `PARTIAL`          | Covered generally, but panic scalar and final-only lifecycle holes exist.        |
| 12                           | Logical-byte boundary is blocking                                                         | `PARTIAL`          | Lexical/below-bound handling works; exact and overbound equality does not block. |
| 13                           | Complete and logical suite identities are correctly separated                             | `PARTIAL`          | Behaviorally active fields are absent from logical fingerprinting.               |
| 14                           | External qualification independently recomputes raw semantics                             | `OPEN`             | It does not re-extract from raw.                                                 |
| 15                           | Wrong qualification SHA/control/T/inventory/fingerprint blocks                            | `CLOSED_CONFIRMED` | Those bound-field controls are valid.                                            |
| 16                           | Inode alias, late-close fault, and resource fault block                                   | `CLOSED_CONFIRMED` | Structural gates exist and controls are valid.                                   |
| 17                           | Second mutant path/unqualified mutant cannot pass                                         | `PARTIAL`          | Source-path controls exist; semantic-delta predicate is incomplete.              |
| 18                           | Mutant is separately frozen and qualified before execution                                | `PARTIAL`          | Recipe reconstructs, but consumed provenance was not retained.                   |
| 19                           | Final/fresh requires accepted equality, zero unknowns, and exit 0                         | `CLOSED_CONFIRMED` | Formula is present; its retained result remains nonqualifying.                   |
| 20                           | Closeout is false when accepted equality is false                                         | `CLOSED_CONFIRMED` | False-ready control is valid.                                                    |
| 21                           | Repair 10G schemas remain historical/nonqualifying                                        | `OPEN`             | G/F schemas actively qualify H.                                                  |
| 22                           | Product A/B bind equal C/T/D/E and compare through EOF                                    | `REPORT_ONLY`      | Retained records reconcile, but no fresh audit A/B ran after the stop.           |

Additional lineage claims:

- Exact eight-file H repository delta: `CLOSED_CONFIRMED`.
- Production observer/public schema/module/script bytes unchanged: `CLOSED_CONFIRMED`.
- Lifecycle governing block unchanged: `CLOSED_CONFIRMED`.
- Phase G remained immutable: `CLOSED_CONFIRMED`.
- Phase H final-manifest discipline: `CLOSED_CONFIRMED`.
- Phase H created no ZIP: `CLOSED_CONFIRMED`.
- Old ZIP/capture/audit qualification: `REPORT_ONLY`.

# 6. Capture-policy decision

Repair 10I freezes **Option B — byte-transport identity**.

Existing authority does not contradict Option B; it lacks an explicit classification for ctime and host-managed xattrs. Repair 10I must close that gap doc-first before capture begins.

Acceptance-bearing identity will bind:

- exact ZIP bytes, size, and SHA-256;
- unique safe member paths, allowed types/modes, raw headers, CRCs, and complete membership;
- two inode-disjoint extractions, their inventories, and reconstructed T;
- archive type, non-symlink status, mode `0600`, link count `1`, and owner policy;
- owner UID/GID equal to the explicitly captured effective capture identity;
- atomic same-filesystem no-clobber publication from an absent target;
- completed write, `fsync`, close, and successful publication record;
- forward/reverse handoff bindings and a sealed capture manifest.

The following are supplementary/report-only container observations:

- ctime and birth time;
- device and inode as transported identity;
- host-managed xattr names and value digests;
- host-specific flags.

Local inode continuity may support no-republication custody, but not cross-host transport identity. Xattr names/value digests are collected when capability is available, with explicit `unavailable` otherwise. Intentional xattr mutation remains prohibited, but historical equality is never claimed without a baseline.

The old H ZIP, handoff, capture child, and audit child remain permanently nonqualifying.

# 7. Exact intended repository touched files

Repair 10I is limited to these eight repository files:

1. [PLANS.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md>)
2. [.docs/system\_overview/artifact\_hygiene.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md>)
3. [.docs/system\_overview/boundaries.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/boundaries.md>)
4. [.docs/system\_overview/capability\_probing.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md>)
5. [.docs/system\_overview/configuration.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/configuration.md>)
6. [.docs/system\_overview/remote\_alpha\_external\_tls\_status\_deployment\_v1.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md>)
7. [docs\_contract\_test.go](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go>)
8. [observe\_test.go](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statusobservation/remoteobserver/observe_test.go>)

No production observer, public schema, module file, operational script, CLI, or `.docs/execution_lifecycle/*` file is intended to change.

# 8. Exact intended successor and evidence files

Phase H remains byte-immutable. Repair 10I works from a new copied successor/evidence child.

## Successor files to change

1. `tool/source/FORMAT.md`
2. `tool/source/envelope/runner.go`
3. `tool/source/envelope/semantic.go`
4. `tool/source/envelope/source.go`
5. `tool/source/envelope/envelope_test.go`
6. `tool/source/cmd/repair10-runner/main.go`
7. `tool/source/cmd/repair10-semantic/main.go`

Files frozen byte-identical unless an API incompatibility stops the plan:

- `tool/source/cmd/repair10-compare/main.go`
- `tool/source/cmd/repair10-fixture/main.go`
- `tool/source/go.mod`
- `tool/source/envelope/testdata/evidence-manifest-v1.golden`
- `tool/source/envelope/testdata/source-inventory-v1.golden`

## Mandatory active Repair 10I private schemas

All acceptance-bearing records use these IDs:

1. `execution-substrate.repair10i.suite-spec.v1`
2. `execution-substrate.repair10i.ab-suite-spec.v1`
3. `execution-substrate.repair10i.command-intent.v1`
4. `execution-substrate.repair10i.command-result.v1`
5. `execution-substrate.repair10i.terminal-reconciliation.v1`
6. `execution-substrate.repair10i.suite-result.v1`
7. `execution-substrate.repair10i.control-observation.v1`
8. `execution-substrate.repair10i.mutable-inventory.v1`
9. `execution-substrate.repair10i.binding-recomputation.v1`
10. `execution-substrate.repair10i.effective-read-policy.v1`
11. `execution-substrate.repair10i.control-qualification.v1`
12. `execution-substrate.repair10i.intentional-mutant-provenance.v1`
13. `execution-substrate.repair10i.go-test-semantics.v1`
14. `execution-substrate.repair10i.semantic-comparison-spec.v1`
15. `execution-substrate.repair10i.semantic-comparison-result.v1`
16. `execution-substrate.repair10i.semantic-comparison-custody.v1`
17. `execution-substrate.repair10i.byte-capture.v1`
18. `execution-substrate.repair10i.byte-comparison-spec.v1`
19. `execution-substrate.repair10i.byte-comparison-result.v1`

Any additional acceptance-bearing closeout record must also use the `repair10i` namespace. F/G/H inputs are parse-only historical records.

## Static evidence producers and specifications

New I-child copies:

- `commands/generate-repository-validation-specs-v1.py`
- `commands/finalize-semantic-comparisons-v1.py`
- `commands/successor-build-a-v1.sh`
- `commands/successor-build-b-v1.sh`
- `commands/successor-selftest-a-v1.sh`
- `commands/successor-selftest-b-v1.sh`
- `commands/successor-hard-gate-v1.py`
- `commands/repair10i-pristine-final-v1.json`
- `commands/repair10i-fresh-independent-final-v1.json`
- `commands/repair10i-final-only-mutant-v1.json`
- `commands/repair10i-head-v1.json`
- `commands/repair10i-repair9-v1.json`
- `commands/repair10i-final-semantic-comparisons-v1.json`
- `preparation/construct-deliberate-mutant-v1.py`
- `preparation/derive-final-semantic-suite-v1.py`
- `preparation/intentional-mutant-provenance-v1.json`, sealed before execution
- `comparisons/specs/final-fresh-v1.json`
- `comparisons/specs/final-mutant-v1.json`
- `comparisons/specs/mutant-fresh-v1.json`
- `comparisons/specs/head-final-v1.json`
- `comparisons/specs/repair9-final-v1.json`
- `closeout/adjudicate-repair10i-closeout-v1.py`
- `closeout/capture-git-closeout-v1.py`
- `closeout/cleanup-private-roots-v1.py`
- `closeout/normalize-phase-i-modes-v1.py`
- `closeout/literal-assertion-mapping-v1.json`
- `closeout/provenance-recipe-inventory-v1.json`
- `closeout/provenance-payload-inventory-v1.json`
- `closeout/failed-and-superseded-attempt-index-v1.json`
- `closeout/command-index-v1.json`
- `closeout/phase-i-closeout-adjudication-v1.json`
- `closeout/implementation-report-v1.md`
- manifest and detached digest, written last.

Every selected command must retain its indexed intent, result, raw stdout/stderr through EOF, terminal reconciliation, extracted semantics, qualification, and resource disposition. No unindexed record may contribute to readiness.

## New capture files

- `capture-integrated-snapshot-v2.py`
- `outer-capture-recorder-v1.py`
- `resume-after-capture-failure-v1.py`
- opening source/Git/target-absence records;
- per-command intent/result/raw-stream/terminal records;
- private and published ZIP verification, raw-header, extraction, inventory, and T records;
- publication and Option-B host-metadata reports;
- original failed-attempt records, if any;
- recovery and closing records;
- final capture report, command index, failed-attempt index, manifest, and detached digest.

The new ZIP and handoff names must be derived from the final Repair 10I T and must be absent before publication; the current `00280085500a` targets are never reused.

# 9. Docs-first implementation order

Repair 10I is divided into two finite hard-gated subtranches.

## 10I-A — authority, tests, and successor

1. Repair `PLANS.md` hierarchy; define Repair 10I classification, I-owned schemas, Option B, and no-retroactive-qualification rule.
2. Update the five affected system-overview pages.
3. Add failing bounded documentation, product-test, successor, qualification, and capture-contract tests.
4. Make the parent-only eight-file repository change.
5. Implement the seven-file successor change.
6. Run two disjoint successor build/self-test controls and the full causal matrix.
7. Seal the 10I-A successor/tool gate.

No 10I-B work begins if this gate fails.

## 10I-B — validation, evidence, and capture

8. Consume only the sealed 10I-A tool and exact repository source.
9. Construct and retain the mutant provenance before execution.
10. Run the five source controls, external requalification, and five comparisons.
11. Run product A/B and exact C/T/D/E plus EOF comparisons.
12. Complete evidence closeout, failed-attempt separation, cleanup, and sealing.
13. Capture a new ZIP and handoff from absent targets under Option B.
14. Run a fresh independent audit.
15. Permit exact-byte commit review only after that audit accepts.

# 10. Exact validation and causal-mutant matrix

## Retained Phase H validation

The H command index is 1,098,534 bytes, SHA-256 `f57b01e3df6024c3bc4a49e7470ef9b3f2a72b88f2e1964542286f0c30540293`: 50 suites, 221 commands. Eleven selected suites contain 60 commands:

| Selected suiteCommands       |    |
| ---------------------------- | -- |
| pristine final v11           | 3  |
| fresh independent final v9   | 3  |
| final-only mutant v11        | 3  |
| historical HEAD v7           | 3  |
| Repair 9 v7                  | 3  |
| semantic comparisons v7      | 6  |
| repository validation v5     | 14 |
| successor validation v5      | 6  |
| product A v2                 | 8  |
| product B v2                 | 8  |
| product direct comparison v4 | 3  |

Retained comparison exits were `0,2,2,2,2` for final/fresh, final/mutant, mutant/fresh, HEAD/final, and Repair-9/final.

Retained pristine/fresh full-suite lifecycle counts were identical: tests `2714/158/8` pass/fail/skip; packages `14/11/23/48` pass/fail/skip/start. These remain report-only because qualification/regression predicates are defective.

The failed/superseded index contains 97 attempts:

- 17 retained nonqualifying/failed;
- 22 qualified but superseded;
- 42 superseded or failed;
- 16 selected.

The 25-entry recipe inventory resolves, but does not contain the missing mutant provenance payload.

## What the fresh audit actually ran

- Three exact privacy tests with `-count=3`: 9/9 top-level executions and 15/15 mutant subtests passed.
- Two disjoint successor controls, each building four deterministic binaries.
- Successor `go test -json -count=3 ./...` and race `-count=1 ./...` in both controls.
- Exact mutant recipe reconstruction, without mutant execution.
- Seven audit-only vulnerable-precondition controls:\
  wrong package; unsupported typed candidate; panic function/scalar erasure; logical-byte boundary; final-only failure/skip; underconstrained mutant; logical-fingerprint omission.

The audit did not run product full suites, external requalification, five comparisons, product A/B, forged-envelope execution, or a new capture.

## Repair 10I command set

Using pinned Go 1.26.5, offline private caches:
```
gofmt -d docs_contract_test.go \
  es/externaltls/internal/statusobservation/remoteobserver/observe_test.go
```

The same no-write check covers all eight Go files in the successor tree, including frozen compare/fixture mains.
```
go test -json -count=1 -p=1 -parallel=1 . \
  -run '^TestRemoteAlphaExternalTLST2APRepair10Contract$'

go test -json -count=3 -p=1 -parallel=1 \
  ./es/externaltls/internal/statusobservation/remoteobserver \
  -run '^(TestObserveV1WitnessCustodyClassificationAndContextV1|TestObserverClosingWitnessPrivacyV1|TestRepair10IStructuralPrivacyProjectionCausalControlsV1)$'

go test -json -count=1 -p=1 -parallel=1 ./es/externaltls/... \
  -skip '^TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2$'

go mod verify
go vet ./...
```

Deterministic cross-builds:
```
GOOS=darwin GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  ./es/externaltls/cmd/es-external-tls-status-package

GOOS=darwin GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  ./es/externaltls/cmd/es-external-tls-status

GOOS=linux GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  ./es/externaltls/cmd/es-external-tls-observer

GOOS=linux GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -buildvcs=false -ldflags=-buildid= \
  ./es/externaltls/cmd/es-external-tls-observer
```

Linux outputs are inspected and hashed, never executed.

Successor validation:
```
go test -json -count=3 -p=1 -parallel=1 ./...
go test -json -count=3 -p=1 -parallel=1 ./envelope -run '^TestRepair10I'
go test -race -json -count=1 -p=1 -parallel=1 ./...
go test -race -json -count=1 -p=1 -parallel=1 ./envelope -run '^TestRepair10I'
```

Two disjoint controls build runner, comparator, semantic extractor, and fixture with:
```
go build -trimpath -buildvcs=false -ldflags=-buildid=
```

A/B outputs must be byte-identical through EOF, inode-distinct, single-link, and derived from inode-distinct source copies.

The five source controls each execute literal:
```
go test -json -count=1 -p=1 -parallel=1 ./...
```

Expected exit membership is `{0,1}`; semantic predicates—not exit code alone—decide qualification.

Comparison outcomes:

| ComparisonRequired result |                                                                    |
| ------------------------- | ------------------------------------------------------------------ |
| final ↔ fresh             | both independently qualified; accepted equal; zero unknown; exit 0 |
| final ↔ mutant            | both qualified; exact declared difference; exit 2                  |
| mutant ↔ fresh            | both qualified; exact declared difference; exit 2                  |
| HEAD ↔ final              | both qualified; no undeclared final regression; exit 2             |
| Repair 9 ↔ final          | both qualified; no undeclared final regression; exit 2             |

## Causal matrix

| SurfaceRequired controls and repaired result |                                                                                                                                                                                                                                                 |
| -------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Typed grammars                               | Valid full template for each of eight rules succeeds. Wrong package/test/subtest, partial, malformed, unsupported, ambiguous, multiplicity, or correlation change becomes unknown/blocking.                                                     |
| OID/SHA, permissions, route/status           | One-nibble OID/SHA, EPERM↔EACCES, route, and status changes remain material.                                                                                                                                                                    |
| Panic grammar                                | Message/type/function/file/line/offset/order/scalar/nil differences, extra/reordered/duplicate frames, and unlisted functions remain material; only enumerated address positions normalize.                                                     |
| Logical bytes                                | `134217727` valid; `134217128`-style ordinary in-bound values valid; `134217728`, larger, signed, leading-zero, overflow, malformed, and identical overbound pairs block.                                                                       |
| Directional regression                       | Final-only fail, skip, disappearance, package abort, panic, race, warning, malformed stream, and unknown diagnostic block independently for HEAD and Repair 9. A declared new pass is the only permitted new identity.                          |
| Mutant                                       | Exact single full tuple and exact two-terminal lifecycle delta qualify. Extra occurrence, path, diagnostic, package/test terminal, bogus occurrence/ordinal/rule/count, or any other semantic change fails.                                     |
| Raw re-extraction                            | A forged but hash-consistent stored envelope fails because re-extraction from retained raw bytes differs.                                                                                                                                       |
| Logical fingerprint                          | Toggle each exported `CommandSpec` field individually. Every behaviorally active field, including `OpenUngrantedListener` and normalized `OutsideSentinel` role/presence, changes the fingerprint unless explicitly documented as root-derived. |
| Schema generation                            | Active I records pass. F/G/H schema substitution fails on every acceptance-bearing input.                                                                                                                                                       |
| Late faults                                  | Late stream close, terminal reconciliation, resource, inode-alias, custody, or raw-EOF fault clears qualification and accepted equality.                                                                                                        |
| Authority                                    | Misordered B/H/I headings and unbounded whole-document assertions fail; correct bounded hierarchy passes.                                                                                                                                       |
| Privacy                                      | Independent timestamp positives ending `.7001Z`, `.7002Z`, `.77001Z`, `.77002Z` pass; five private-data mutants still fail.                                                                                                                     |
| Evidence closeout                            | Wrong anchor, absent provenance payload, nonfresh record, false accepted equality, unknown diagnostics, or missing payload inventory makes readiness false.                                                                                     |
| Capture                                      | Existing target, overwrite, non-atomic publication, unsafe member, CRC/header/membership mismatch, wrong mode/owner/link policy, extraction/T mismatch, missing outer failure record, or handoff-binding mismatch blocks capture qualification. |

Before accepting a causal as killed, its H vulnerable precondition must first reproduce in an isolated H copy. The forged-envelope and `OutsideSentinel` cases require new runtime causals because the audit did not execute them.

## Explicitly unexecuted by the fresh audit

1. Protected-script Bash syntax.
2. No-write `gofmt`.
3. Documentation-contract and lifecycle/order guards.
4. Broader external-TLS regression suite.
5. `go mod verify`.
6. `go vet ./...`.
7. Darwin arm64 status-package/status builds.
8. Linux amd64 observer cross-build.
9. Linux arm64 observer cross-build.
10. Pristine-final full suite.
11. Fresh-independent-final full suite.
12. Mutant full suite.
13. Historical-HEAD full suite.
14. Historical-Repair-9 full suite.
15. External requalification of all five controls.
16. Final↔fresh.
17. Final↔mutant.
18. Mutant↔fresh.
19. HEAD↔final.
20. Repair-9↔final.
21. Forged-envelope causal.
22. Product preparation A.
23. Product preparation B.
24. Product A/B C/T/D/E plus 9,870,994 artifact bytes and 112,275 evidence bytes through EOF.

# 11. Evidence-retention and new-snapshot requirements

Each A/B/control root must be newly exclusive, mode `0700`, under `umask 077`, with distinct private home, temporary, Go cache, module cache, GOPATH, XDG, package-floor, runtime, and control roots. Execution is offline with the pinned Go toolchain and no live route, remote host, or Linux-binary execution.

Required evidence includes:

- exact source copies, inventories, T values, modes, and inode-disjointness;
- successor source inventory and two independent deterministic build/self-test records;
- complete suite specs and every command’s argv, cwd, bounded environment, raw streams, EOF, exit, wait, terminal reconciliation, and resource disposition;
- raw-derived semantic envelopes and independent I qualification;
- intentional-mutant provenance retained before execution;
- five comparison specs/results/custody records;
- product A/B payload and evidence indexes plus C/T/D/E and direct EOF equality;
- all failed/superseded attempts separately indexed and excluded from readiness;
- literal-assertion and provenance recipe/payload inventories;
- two private-root absence epochs;
- phase-I adjudication and implementation report;
- manifest and detached digest written last.

The new snapshot must:

1. Start with absent ZIP and handoff targets.
2. Use the Option-B publication contract.
3. Retain original outer caller custody for every failure.
4. Perform private and published extraction/inventory/T verification independently.
5. Seal capture evidence after publication and cleanup.
6. Produce a new handoff binding the new evidence and ZIP.
7. Receive a fresh independent audit.

No Repair 10H evidence is copied forward as current qualification authority.

# 12. Stop conditions

Stop immediately if any of the following occurs:

- branch, HEAD, parent, tree, index, T, inventory, membership, seal, or immutable input differs;
- doc-first authority cannot unambiguously place B, H, and I or define Option B;
- implementation exceeds the eight repository or seven successor files without explicit reclassification;
- a production/public schema, CLI, protocol, module, route, deployment, or lifecycle authority would change;
- any H/G/F record is accepted as active I qualification;
- qualification can succeed without raw re-extraction and canonical-byte equality;
- any causal vulnerable precondition cannot be reproduced, or survives the repair;
- a behaviorally active `CommandSpec` field lacks an explicit fingerprint disposition;
- 10I-A build, test, race, causal, determinism, or sealing gate fails;
- source or sealed-tool identity changes between 10I-A and 10I-B;
- mutant provenance is not retained before execution or more than the declared source/semantic delta appears;
- any five-control suite lacks complete streams, EOF, terminal/resource reconciliation, or independent qualification;
- final/fresh is not accepted equal with zero unknowns and exit 0;
- either historical direction contains an undeclared final regression;
- product A/B C/T/D/E or byte comparisons differ;
- any selected record depends on a failed, superseded, missing, private-only, or producer-caption-only record;
- a new public target already exists or publication is not atomic, no-clobber, closed, and synced;
- an acceptance-bearing Option-B member/mode/owner/link/extraction/T/handoff predicate fails;
- output escapes an authorized root, network/live-route/remote behavior occurs, or cleanup cannot prove two absence epochs;
- manifest/detached sealing or fresh-audit acceptance fails.

No new snapshot is created if 10I-A fails. No commit review begins before fresh independent acceptance.

# 13. Inspection limits and uncertainty

- This turn used read-only source, artifact, manifest, ZIP, metadata, and Git-administration inspection only.
- Product tests, builds, five-control validation, and causal programs were not executed in this turn.
- Audit-retained runs were independently parsed and rehashed, but remain prior evidence.
- The exact old ctime cause and historical xattr state cannot be recovered.
- Current xattr names do not supply a missing historical baseline.
- The forged-envelope and `OutsideSentinel` runtime causals remain to be executed.
- Additional unsupported typed templates, panic scalar positions, or omitted logical-fingerprint fields may be found by the required exhaustive tables.
- No syscall trace proves global audit containment; retained path inventories and closing quiescence are the available evidence.
- Fresh product A/B and the full five-comparison matrix remain future work.
- None of these limits prevents freezing the finite Repair 10I plan.

# 14. Confirmation of no mutation

The candidate, Git administration, Phase H, capture child, ZIP, handoff, and audit child remained unchanged. Exactly four direct explorers were used, with zero nested subagents.

REPOSITORY\_SOURCE\_MUTATION\_NOT\_PERFORMED\
GIT\_ADMINISTRATION\_MUTATION\_NOT\_PERFORMED\
PHASE\_H\_MUTATION\_NOT\_PERFORMED\
CAPTURE\_MUTATION\_NOT\_PERFORMED\
AUDIT\_CHILD\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
BUILDS\_NOT\_RUN\
NEW\_SNAPSHOT\_NOT\_CREATED\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
INSTALLATION\_NOT\_PERFORMED\
LIVE\_ROUTE\_NOT\_INVOKED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
NESTED\_SUBAGENTS\_CREATED: 0
