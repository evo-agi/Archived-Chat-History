## Assessment

The audit’s **BLOCK** is correct and extremely narrow.

The current documents are coherent, the authoritative v1 contract is valid, all 31 intended contradictions are rejected, all tests and compatibility checks pass, and four distinct auditors completed. The remaining defect is only this:

> Test 89 recognizes authoritative markers only when they use the exact v1 identifier. A second balanced authority block using `trusted-host-contract.v2` can coexist with the v1 block and pass validation.

That defeats the intended “one authoritative writer” invariant even though the live documents currently contain no competing block.

This is **not** another contract-design problem. It requires no changes to:

- the trusted-host model;
- the governing prose;
- `verify_v1.py`;
- the source-external caller;
- registry or layouts;
- compatibility evidence;
- authority boundaries.

The proportional fix is **one repository file only**:

`tools/evidence_verify/test_verify_v1.py`

The validator should scan the entire trusted-host authority-marker namespace across all four governing documents, not merely the exact v1 markers. Any marked `execution-substrate.evidence-verification.trusted-host-contract.*` block other than the exact authorized v1 block must fail with a specific reason. Add balanced alternate-ID causals in both the authoritative document and a consumer document.

Do not solve this by hard-coding only `v2`. Enforce the contract-family rule generically.

AP-06 is closed: the latest audit used four distinct auditor instances in the required sequence. No further audit-orchestration repository work is needed.

The next cycle is therefore one-file repair → new provenance → fresh independent audit. Changed bytes invalidate the current audit even though the change is test-only.  Provenance will bind the new audit target but will not establish correctness by itself. 

## Codex prompt: alternate-authority-ID repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete implementation report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

Supplemental evidence links may follow the complete inline report.

This applies to every outcome:

- implemented and ready for fresh audit;
- baseline mismatch;
- scope expansion;
- validation block;
- provenance block;
- process-boundary block.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh, parent-only workspace-write Codex conversation.

Do not resume the independent audit conversation.

Do not spawn subagents. You are the sole writer.

Objective

Repair the sole blocking finding TV-01 from the latest independent audit of
Evidence Verification v1.

TV-01 established that:

- the current governing documents are coherent;
- exactly one current v1 authoritative contract exists;
- the existing 31 contradiction mutations reject correctly;
- test 89 and its validator scan only the exact v1 authority-marker ID;
- a second syntactically valid marked authority block using a different
  identifier, such as
  `execution-substrate.evidence-verification.trusted-host-contract.v2`,
  is accepted while the v1 block and references remain intact;
- this violates the sole-authority requirement.

Repair the validator and its mutation coverage so that every marked contract in
the trusted-host authority family is discovered across all four governing
documents.

Do not change the substantive contract.
Do not change governing documents.
Do not change the verifier.
Do not change the source-external caller.
Do not reopen interpreter custody.
Do not change launch protocol v2.
Do not change registry, layouts, or historical fixtures.

No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

## 1. Exact opening target

Repository:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Current canonical manifest:

OPENING_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/trusted-host-contract-test-repair-2aedcf930bfa/provenance/manifest-run-1.json

The prior audit states that the implementation inventory uniquely indexes that
flat path. If the exact indexed path differs, use only the machine-readable
inventory and closing gate to identify it. Do not infer a replacement path.

Expected opening canonical-manifest SHA-256:

0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0

Expected opening tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected current test source:

TESTS=$IMPL_R/tools/evidence_verify/test_verify_v1.py

- size:
  83542
- SHA-256:
  f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea

Expected unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Blocking audit root, read-only:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1

TV-01 causal:

$AUDIT_ROOT/validation/alternate-authority-causal.json

New implementation evidence root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f

Require REPAIR_ROOT absent before creation.

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and process boundary

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - `GIT_OPTIONAL_LOCKS=0`;
  - `GIT_CONFIG_NOSYSTEM=1`;
  - `LC_ALL=C`;
  - `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
- be retained with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in PRIMARY_R, AUDIT_ROOT, REPAIR_ROOT, or any evidence root.

Non-Git absolute-path reads are permitted from another inherited cwd.

No repository-relative operand may resolve through PRIMARY_R.

Any nonconforming Git invocation is an immediate process-boundary block.

## 3. Opening provenance gate

Require IMPL_R:

- physical root equals lexical path;
- exact branch, HEAD, tree, parent, and absent upstream;
- exactly 13 patch paths;
- four modified tracked and nine untracked;
- every patch path regular and single-link;
- working mode `0644`;
- logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

Open OPENING_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact manifest and recipe hashes;
- every manifest row equals live bytes;
- exact tracked binary diff;
- exact test and verifier identities;
- exact governing-document identities;
- exact registry, layout, and historical-fixture identities;
- AUDIT_ROOT and TV-01 causal present and stable.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_BASELINE_MISMATCH

## 4. Evidence root and opening replay

After the repository gate passes, create REPAIR_ROOT under umask `077`:

opening/
decision/
validation/
provenance/
closeout/
tmp/

Directories mode `0700`.
Retained files regular, single-link, mode `0600`.

Run the exact unchanged RECIPE twice into fresh absent paths beneath:

REPAIR_ROOT/opening/provenance/

Require:

- both exits `0`;
- empty stderr;
- byte-identical outputs;
- outputs equal OPENING_MANIFEST;
- canonical SHA-256:
  `0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0`;
- tracked binary diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`.

Retain a decision record stating:

- TV-01 is the sole repository repair objective;
- current governing documents contain no alternate authority;
- the defect is only failure to discover marked authority blocks under another
  contract-family identifier;
- AP-06 is closed by the prior audit’s four distinct auditor instances;
- verifier, caller, documents, registry, layouts, and fixtures remain
  unchanged;
- new test bytes require a fresh audit.

## 5. Exact authorized repository scope

The only authorized repository path is:

tools/evidence_verify/test_verify_v1.py

Keep every other repository path byte-identical.

No documentation edit.
No verifier edit.
No caller edit.
No registry or layout edit.
No fixture edit.
No new repository file.
No deletion.
No rename.
No mode change.
No dependency.

If another repository path is required, stop:

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_SCOPE_EXPANSION_REQUIRED

## 6. Required validator design

Preserve the existing exact authoritative contract:

execution-substrate.evidence-verification.trusted-host-contract.v1

Add a contract-family concept that is independent of the exact version:

execution-substrate.evidence-verification.trusted-host-contract.

The validator must scan all four governing documents:

- `PLANS.md`;
- `.docs/system_overview/evidence_verification.md`;
- `.docs/system_overview/artifact_hygiene.md`;
- `.docs/system_overview/capability_probing.md`.

It must discover every exact HTML authority marker whose identifier belongs to
that family, including identifiers other than v1.

A suitable closed marker grammar is:

```text
<!-- BEGIN <family-identifier> -->
<!-- END <family-identifier> -->
```

where `<family-identifier>` begins exactly with:

```text
execution-substrate.evidence-verification.trusted-host-contract.
```

and the remaining identifier token contains no whitespace, `<`, or `>`.

Do not discover authority merely from arbitrary prose containing the family
string. Discover marked authority blocks.

### Required invariants

The validator must require:

1. Exactly one trusted-host authority block in the whole four-document set.
2. Its document is exactly:
   `.docs/system_overview/evidence_verification.md`.
3. Its identifier is exactly:
   `execution-substrate.evidence-verification.trusted-host-contract.v1`.
4. Its BEGIN and END identifiers match.
5. There are no unmatched family BEGIN or END markers.
6. There is no nested or overlapping family authority block.
7. There is no alternate-ID family block in the authoritative document.
8. There is no family authority block in a consumer document.
9. Existing strict v1 JSON, canonical encoding, field, type, value, and
   reference validation remains unchanged.

Reject an alternate authority based on its marker identity before accepting its
payload semantics.

### Required specific failure classes

Add specific stable reasons equivalent to:

```text
unauthorized_authoritative_contract_id:<document>:<identifier>
unauthorized_authoritative_block:<document>:<identifier>
authoritative_marker_mismatch:<document>:<begin-id>:<end-id>
authoritative_marker_unbalanced:<document>
authoritative_section_count
```

Exact spelling may follow the existing error taxonomy, but the report must map
each causal to one specific reason.

Do not implement a special case that rejects only `.v2`.

## 7. Vulnerable predecessor causal

Before editing, reproduce TV-01 against the exact opening test bytes using only
audit-/repair-owned document copies.

Create a complete, syntactically valid, balanced alternate authority block:

```text
execution-substrate.evidence-verification.trusted-host-contract.v2
```

Use a full contract-shaped JSON payload, not malformed placeholder JSON.

At minimum, make:

```json
"atomic_loaded_object_binding_claimed": true
```

while retaining otherwise valid typed fields.

Append that alternate block to an audit-owned copy of
`evidence_verification.md`.

Require the opening validator to accept the documents, reproducing the defect.

Also reproduce a second causal by placing a balanced alternate-ID block in an
audit-owned copy of `PLANS.md`.

Retain exact inputs, output, and result.

If the opening validator already rejects both causals, stop and reconcile
against the supplied TV-01 evidence rather than editing blindly.

## 8. Test 89 repair

Preserve the identity:

InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim

Preserve all existing 31 contradiction cases and their intended reasons.

Add at least these new mechanism-specific cases:

32. Balanced `trusted-host-contract.v2` authority block in
    `evidence_verification.md`.
33. Balanced `trusted-host-contract.v2` authority block in `PLANS.md`.
34. Alternate family BEGIN and END identifiers that do not match.
35. Unmatched alternate family BEGIN marker.
36. Unmatched alternate family END marker.

The first two cases must use valid contract-shaped JSON and must fail because
of the unauthorized authority identity/location, not because of malformed JSON
or a missing field.

Do not derive the alternate identifier solely by editing the current contract
ID at runtime. Retain an explicit independent alternate-ID literal in the test
so an error in the current contract-ID constant cannot erase the causal.

Do not add a new numbered unittest method solely to evade TV-01.

The complete test count should remain 89.

## 9. Independent repair validation

Create a source-external validator beneath REPAIR_ROOT that does not import or
call test 89’s helper as its sole oracle.

It must independently:

- scan all four documents for the authority-marker family;
- verify the live documents contain exactly the one v1 block;
- reject the v2 authoritative-document causal;
- reject the v2 consumer-document causal;
- reject mismatched identifiers;
- reject unmatched begin/end markers;
- retain exact observed reasons.

This validator is implementation evidence only.

## 10. Validation

Use pinned Python 3.13.4.

### Static gates

Run:

- `ast.parse` over verifier and final test source;
- parse both historical `.py.txt` files without executing them;
- strict-parse registry and three layouts;
- require every non-test repository path byte-identical to opening;
- run the independent family-marker validator;
- run rooted `git diff --check`.

### Targeted test 89

Run test 89 alone three times.

Require every owning command:

- exit `0`;
- exactly one test;
- zero failure;
- zero error;
- zero skip;
- all original 31 and all new alternate-marker cases execute;
- repository snapshot unchanged.

### Complete suite

Independently discover the complete test set.

Require exactly 89 identities.

Run:

- twice under umask `077`;
- twice under umask `022`.

Require every owning command:

- exit `0`;
- exactly 89 tests;
- zero failure;
- zero error;
- zero skip;
- identical identity set;
- no repository artifact.

Do not accept an inner successful suite when its owning shell exits nonzero.

### Repaired TV-01 causals

Against final bytes, rerun the exact two predecessor causals.

Require:

- alternate v2 block in authoritative document rejects with its intended
  specific reason;
- alternate v2 block in consumer document rejects with its intended specific
  reason;
- current documents still pass;
- original 31 contradiction cases still reject for their original intended
  reasons.

## 11. Exact unchanged identities

Require unchanged:

Verifier:

bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Source-external caller:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

All four governing documents:

- `PLANS.md`
  `fb3b2590103af1db07f17eac8fbe9c9e65420fd9d2c7fc6a8ccf9e7510e72750`
- `evidence_verification.md`
  `fc7d485728b8ba2815ae7a9f3e21b0859f0e35ba28083ba355a64047857f5875`
- `artifact_hygiene.md`
  `1a3e570167ab7b2238a75d43f678e7121e226950d6202b9e17259317bf5ce1c5`
- `capability_probing.md`
  `3333ea9b3c618ae95110273041396a2d7482891fac01b9d29e6b1609a2124d63`

Boundaries:

643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e

Registry:

e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

Layouts:

267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc
3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4
b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

Historical fixtures:

e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98
5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f

Do not rerun A6D, amendment, synthetic, or SEC-02 compatibility during this
one-file implementation repair. The fresh independent audit must rerun those
acceptance-bearing checks.

## 12. Artifact hygiene

Scan IMPL_R for:

- `__pycache__`;
- `.pyc`;
- `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixtures;
- databases;
- journals;
- locks;
- build output;
- unexpected executable modes;
- unsupported file types.

Remove only artifacts created by this activity.

Do not delete, chmod, normalize, or restore pre-existing repository objects.

Require AUDIT_ROOT and all predecessor evidence unchanged.

## 13. Final provenance

After validation and cleanup, run the exact unchanged RECIPE twice into fresh
paths beneath:

REPAIR_ROOT/provenance/

Require:

- both exits `0`;
- empty stderr;
- byte-identical canonical manifests;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- all paths regular, single-link, logical mode `100644`;
- no extra path;
- deterministic tracked binary diff.

Retain:

- exact recipe source and SHA-256;
- both manifests;
- new canonical-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities;
- exact one-file touched scope;
- opening and final test hashes;
- vulnerable and repaired TV-01 causals;
- targeted test records;
- full-suite records;
- independent validator record;
- artifact scan and cleanup;
- failed/superseded attempt index.

## 14. Closing gate

Require final IMPL_R:

- same branch, HEAD, tree, parent, and absent upstream;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- no extra path;
- every patch object regular and single-link;
- logical mode `100644`;
- `git diff --check` clean;
- no generated repository artifact;
- every path except `test_verify_v1.py` byte-identical to opening.

Do not stage or commit.

## 15. Mandatory stops and verdicts

Stop if:

- opening provenance differs;
- a second repository path is needed;
- any governing document must change;
- verifier or caller must change;
- registry/layout/fixture must change;
- test count changes;
- original 31 cases regress;
- alternate-ID cases cannot reject for specific reasons;
- full-suite behavior differs by umask;
- repository artifacts are created;
- final provenance is unstable.

Use exactly one:

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_SCOPE_EXPANSION_REQUIRED

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_VALIDATION_BLOCKED

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_ALT_AUTHORITY_ID_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

## 16. Complete inline report

Include:

1. Verdict.
2. Response-format confirmation.
3. Opening repository and provenance.
4. TV-01 finding consumed.
5. AP-06 closed disposition.
6. Exact actual touched scope.
7. Authority-family marker design.
8. Marker grammar.
9. Exact validator invariants.
10. Vulnerable predecessor causals.
11. Repaired causals and specific reasons.
12. Original 31-case preservation.
13. New alternate-marker mutation cases.
14. Independent external validator results.
15. Three targeted test-89 results.
16. Exact final test count and identity result.
17. Both umask-077 results.
18. Both umask-022 results.
19. Static and unchanged-byte checks.
20. Artifact/no-write results.
21. Exact final 13-path manifest.
22. Provenance recipe identity.
23. New tracked binary-diff SHA-256.
24. New canonical-manifest SHA-256.
25. Evidence inventory and cleanup.
26. Authority/non-authority adjudication.
27. Remaining uncertainty and nonclaims.
28. Explicit confirmations:
    - prior audit no longer qualifies changed test bytes;
    - fresh independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
```

## After implementation

A successful one-file repair requires another fresh independent audit against the new exact manifest. That audit should focus on:

- generic authority-family discovery;
- alternate-ID blocks in both authoritative and consumer documents;
- mismatched and unbalanced marker pairs;
- preservation of the original 31 contradictions;
- unchanged governing documents, verifier, and caller;
- fresh compatibility checks;
- four distinct auditor instances.

An `ACCEPT` verdict can then proceed directly to the exact-byte commit gate. No further threat-model, verifier, caller, or documentation work should intervene.

### Sources

- The project’s earlier audit established that the trusted-host contract itself was coherent and that atomic interpreter custody is expressly not claimed. 
- The latest Codex audit supplied in this turn identifies the sole remaining blocker as alternate-ID authority-marker detection and reports AP-06 closed.
- Audit blocks return to bounded parent-only repair, followed by new provenance and a fresh audit. 
- The audit protocol requires separate contract, correctness, test, and security roles, no silent substitution, and preserved disagreements. 
- The MVP freeze prohibits proof scaffolding and generated evidence from becoming architecture or authority by drift. 

**Confidence**

- TV-01 is the sole current repository-patch blocker: **0.997**
- One-file test repair is sufficient: **0.98**
- Governing documents, verifier, and caller should remain unchanged: **0.999**
- Generic family scanning is preferable to a v2 special case: **0.995**
- Correct next gate after repair is one final fresh audit: **0.999**
