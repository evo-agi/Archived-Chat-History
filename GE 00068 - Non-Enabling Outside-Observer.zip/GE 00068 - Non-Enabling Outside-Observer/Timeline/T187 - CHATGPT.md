## Assessment

This is a **substantive, well-supported BLOCK**. It is not another provenance or audit-process failure.

The audit establishes that the prior repair succeeded in two important respects:

- The fixed record-root restriction is gone; the exact successor works with multiple fresh external record directories.
- The depth contract is now uniform: files and directories at depth 12 are admitted, while depth 13 is rejected before observation.

Those pieces should remain unchanged.

The two remaining findings are genuine caller defects:

1. **Caller-evidence containment is incomplete.**  
   The caller snapshots its own source/evidence container, but record destinations equal to, beneath, or containing that container are admitted. Because record output is written after the closing snapshot, the resulting accepted record can describe a caller-evidence state that no longer represents the completed invocation.

2. **The JSON record is published before acceptance is irrevocable.**  
   A complete, schema-valid v3 record with `"outcome":"accepted"` can remain after the caller itself rejects a later JSON reobservation failure. That creates two conflicting terminal projections: a failed invocation and an accepted-looking durable record.

The second defect is the more fundamental one. The previous implementation report claimed that uncertain output closure prevents an accepted result, but its algorithm wrote the final JSON before all acceptance-bearing checks had completed.  The record schema and 25-field contract can remain unchanged, but the **publication state machine must change**. 

Do not run another audit, commit gate, or A6 restart. Return to source-external caller implementation, produce new bytes and provenance, then obtain a fresh independent audit. That is the required repair lifecycle after a blocking audit. 

## Frozen repair direction

The narrow repair should:

- Add `caller_evidence_root` to the record-parent disjointness checks in **both ancestry directions**.
- Preserve the final public output set: stdout sidecar, stderr sidecar, and JSON record.
- Write the JSON first to a same-directory **staging name**, fully close and verify it, and revalidate all acceptance-bearing state.
- Publish the final JSON pathname as the **last acceptance-bearing filesystem operation**, using a behaviorally proven atomic, exclusive, no-overwrite publication primitive.
- On this supported-local Darwin host, the intended primitive is `renameatx_np(..., RENAME_EXCL)` or an equally strong descriptor-relative primitive. No ordinary `os.rename` overwrite fallback is authorized.
- Leave the final JSON absent on every pre-publication failure. Sidecars or staging files left by failure are nonaccepted attempt evidence and make same-basename retry fail closed.
- Perform no check after final publication that can downgrade the record from accepted to failed. Final publication is the record commit point.
- Keep protocol v2, record schema v3, all 25 fields, depth behavior, snapshot behavior, and trusted-host nonclaims unchanged.

## Codex prompt — narrow implementation repair

```text
MANDATORY RESPONSE FORMAT

Embed the complete implementation report inline in Markdown. Evidence links may
be supplemental, but must not replace any report section.

Return exactly one:

EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_BLOCKED
EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_BASELINE_MISMATCH
EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_SCOPE_EXPANSION_REQUIRED

FRESH IMPLEMENTATION CONVERSATION

This is a new source-external caller repair. Do not resume or mutate the
preceding implementation root or audit root.

You are the sole writer. Do not create subagents.

Do not modify the Evidence Verification repository, predecessor repair root,
blocked audit root, A6D, amendment, or any supplied evidence.

Do not stage, commit, push, create a PR, merge, install, deploy, restart A6,
invoke product/live services, contact the network, or run Linux binaries.

Objective

Repair exactly the two blocking findings from the independent audit of the
caller reusability/depth successor:

1. record destinations equal to, beneath, or containing caller_evidence_root
   can qualify and can mutate the watched caller-evidence container after its
   closing snapshot;

2. a late output failure can leave a complete v3 JSON record whose outcome is
   "accepted" even though the caller invocation rejects.

Preserve the successful record-destination reusability repair and uniform
depth-12 repair.

## 1. Exact frozen inputs

Frozen Evidence Verification repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected repository identity:

- branch:
  codex/evidence-verification-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- canonical manifest SHA-256:
  4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537
- tracked binary-diff SHA-256:
  b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb
- governed inventory:
  477 exact objects

Frozen predecessor snapshot-repair caller:

PREDECESSOR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-repair-4a3a42441632-v1

PREDECESSOR_CALLER=$PREDECESSOR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Expected predecessor identity:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

Frozen reusability/depth repair root:

BASE_REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-repair-c030f2baf200-v1

Exact current caller to repair:

BASE_CALLER=$BASE_REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12.py

Expected current caller identity:

- size: 33758
- SHA-256:
  c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24

Retained predecessor copy:

BASE_PREDECESSOR_COPY=$BASE_REPAIR_ROOT/source/predecessor_caller_exact.py

Expected retained predecessor-copy identity:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

Blocking audit root, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-independent-audit-70e2a46949f2-v2

Read and bind at minimum:

- the complete inline audit report supplied in the conversation;
- BLOCKING_AUDIT/causals/caller-evidence-ancestor.json
- BLOCKING_AUDIT/causals/late-json-full-main-corrected.json
- BLOCKING_AUDIT/causals/destination-negatives.json
- BLOCKING_AUDIT/causals/output-races-and-retry.json
- BLOCKING_AUDIT/causals/sealed-compatibility.json
- BLOCKING_AUDIT/causals/caller-negatives-independent.json
- BLOCKING_AUDIT/closeout/final-addendum.json

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python identity:

- version: 3.13.4
- regular and single-link
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

New implementation root, required absent before creation:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1

Intended successor source:

SUCCESSOR=$REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py

## 2. Opening gate

Before creating REPAIR_ROOT:

1. Verify all frozen identities above.
2. Verify the repository’s exact 477-object restored inventory.
3. Verify BASE_REPAIR_ROOT against both canonical repair manifests.
4. Verify BASE_CALLER and BASE_PREDECESSOR_COPY.
5. Verify the blocking audit causals are present and stable.
6. Verify REPAIR_ROOT is absent.

Stop with:

EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_BASELINE_MISMATCH

on any mismatch.

Do not reconcile or normalize a mismatch.

After the gate, create REPAIR_ROOT under umask 077. All retained directories
must be 0700. Every retained file must be exclusively created, regular,
single-link, and 0600.

## 3. Frozen authority and non-goals

Classification:

- source-external validation-evidence repair;
- repository verifier remains an ES-owned Bounded slice rule;
- caller and records remain validation/provenance evidence only.

No authority widening is permitted.

Do not change:

- repository bytes;
- verifier bytes;
- launch protocol:
  execution-substrate.evidence-closure-launch/v2
- record schema:
  execution-substrate.evidence-closure-launch-record.v3
- the exact 25 top-level record fields;
- CLI option names, order, required/optional status, or defaults;
- source-by-value launch;
- trusted-host model or nonclaims;
- source, registry, layout, interpreter, target, candidate, or snapshot gates;
- uniform depth-12 behavior;
- snapshot resource limits;
- A6D or amendment;
- product/runtime/readiness/publication authority.

No fourth public output file or new schema field is authorized.

## 4. Repair A — caller-evidence containment

The record destination parent must be physically disjoint from
caller_evidence_root in both directions.

Reject all of the following before child launch or output preparation:

- parent == caller_evidence_root;
- parent beneath caller_evidence_root;
- parent is an ancestor containing caller_evidence_root;
- case alias or physical inode alias of those relationships;
- symlink-mediated equivalent relationship.

Use the existing descriptor-bound physical ancestry model. Do not use lexical
string prefix, Path.resolve(), commonpath(), or case folding as the security
decision.

Use the existing containment error class unless a more specific existing
record-destination class is already frozen. Do not create a new public schema
field.

Preserve the meaning of the existing caller_evidence field:

the complete source-external caller evidence container observed for the
completed invocation, not a pre-output snapshot of a container later mutated
by the same invocation.

## 5. Repair B — atomic accepted-record publication

The final `<basename>.json` path is the accepted-record commit marker.

A final JSON record whose outcome is `"accepted"` must not become visible until
all acceptance-bearing checks except the publication operation itself have
succeeded.

Implement a two-phase output protocol:

### Phase 1 — sidecars and staged JSON

1. Validate and bind the output parent.
2. Require absent:
   - final stdout sidecar;
   - final stderr sidecar;
   - final JSON path;
   - deterministic same-directory JSON staging path.
3. Create and fully close stdout and stderr sidecars through the held parent
   descriptor using the existing exclusive no-follow 0600 contract.
4. Create the accepted JSON at the staging pathname, not at the final JSON
   pathname.
5. Fully write, fsync, close, and descriptor-relatively reobserve:
   - stdout;
   - stderr;
   - staged JSON.
6. Revalidate:
   - parent binding;
   - all sidecar and staged-file identities;
   - source/package/target/candidate/TMPDIR/caller-evidence relationships;
   - every closing snapshot and provenance condition;
   - no late caller error.

Any failure in phase 1 must leave the final JSON path absent.

Partial stdout/stderr/staging files are failed-attempt evidence only. They must
block same-basename retry. They must never be interpreted as an accepted
record.

### Phase 2 — exclusive atomic publication

Publish the already verified staged JSON to the final JSON pathname by one
atomic, exclusive, no-overwrite, same-directory operation.

Selected target primitive on this supported-local Darwin host:

`renameatx_np(..., RENAME_EXCL)`

or an independently proved descriptor-relative primitive with exactly
equivalent semantics.

Requirements:

- behaviorally prove the primitive;
- derive and verify the local capability rather than guessing silently;
- publish relative to the held parent descriptor;
- destination must not be overwritten;
- no ordinary `os.rename` overwrite fallback;
- no copy-and-delete fallback;
- no hard-link publication that leaves an acceptance-bearing second link;
- unsupported or uncertain capability fails closed before final publication.

If no adequate primitive is available, stop with:

EVIDENCE_VERIFICATION_V1_CALLER_EVIDENCE_AND_PUBLICATION_REPAIR_BLOCKED

and report the exact capability result. Do not weaken the contract.

Successful exclusive publication is the commit point.

After successful publication:

- no acceptance-bearing filesystem or provenance check may still fail;
- no later error may downgrade the accepted record;
- no final JSON reobservation may turn success into failure;
- process-shared stdout is projection only and must not invalidate the committed
  record if its consumer is unavailable;
- resource-close cleanup after commit must be non-authoritative and must not
  produce a contradictory failed invocation.

Document the bounded nonclaim that this is atomic name publication under the
supported-local filesystem, not crash-durable transport history or privileged
host attestation.

## 6. Exact source scope

Create an exact inert copy of BASE_CALLER in REPAIR_ROOT.

Create SUCCESSOR from that exact source.

The source delta may change only:

1. caller_evidence_root destination containment;
2. staged JSON naming and collision checks;
3. behaviorally proven exclusive atomic publication;
4. output state-machine and error handling required to make publication the
   commit point;
5. private deterministic test hooks and normal-main guards required to exercise
   the two repairs;
6. comments/constants describing the bounded publication contract.

Do not change snapshot depth or traversal logic except where tests require an
unchanged-byte assertion.

Retain a deterministic unified source delta and independent semantic
crosswalk.

## 7. Required causals — caller-evidence containment

Using audit/implementation-owned fixtures, prove:

- external safe destination accepted;
- second distinct external destination accepted;
- later-A6-style destination accepted;
- destination equal to caller_evidence_root rejects;
- destination beneath caller_evidence_root rejects;
- destination ancestor containing caller_evidence_root rejects;
- physical alias and case-alias forms reject where supported;
- no file is written into caller_evidence_root for any rejected case;
- caller_evidence opening and closing snapshots remain equal on accepted runs;
- no supplied repair root receives new records.

## 8. Required causals — publication state machine

Run deterministic injections at every boundary:

1. before stdout creation;
2. during stdout write;
3. stdout fsync;
4. after stdout, before stderr;
5. during stderr write;
6. stderr fsync;
7. after both sidecars, before staged JSON;
8. during staged JSON write;
9. staged JSON fsync;
10. staged JSON close/reobservation;
11. parent rebinding before publication;
12. publication-capability unavailable;
13. final destination created concurrently;
14. exclusive publication failure;
15. successful publication;
16. attempted late error after successful publication;
17. shared-stdout consumer failure after publication;
18. same-basename retry after every failed phase;
19. same-basename retry after successful publication.

For every pre-publication failure require:

- final JSON path absent;
- no accepted JSON record at the final path;
- nonzero/nonaccepted invocation result;
- no overwritten output;
- partial files clearly classifiable as nonaccepted;
- retry does not reuse or overwrite the failed attempt.

For successful publication require:

- exactly one final JSON path;
- final JSON is canonical v3 with outcome accepted and empty errors;
- staging path absent;
- final file identity equals the verified staging identity;
- stdout/stderr sidecars match the record;
- process result is successful;
- no operation after publication can generate a contradictory failure;
- retry rejects without changing any of the three final outputs.

Explicitly reproduce the blocking audit’s
`late-json-full-main-corrected.json` mechanism. The repaired caller must leave
no accepted final JSON on the corresponding pre-publication failure.

## 9. Regression matrix

Preserve and rerun:

- uniform depth:
  - root depth 0;
  - file/directory depth 12 accepted;
  - file/directory depth 13 rejected before observation;
- stable/canonical snapshot repeat;
- symlink, special file, hardlink, replacement, disappearance, mutation,
  mode/link/type and resource-limit causals;
- runtime descriptor-listing failure;
- normal-main test-hook guard;
- no watched-root write;
- existing destination, symlink destination, wrong mode/owner/name/relative
  path;
- target/package/candidate/TMPDIR/interpreter containment;
- parent replacement before/during output;
- wrong interpreter hash/size;
- source mismatch;
- registry/layout result mismatch;
- snapshot uncertainty/replacement/capability failure.

Private hooks must remain unreachable through normal caller inputs.

## 10. Record schema and disclosure

Require unchanged:

- launch protocol v2;
- record schema v3;
- exact 25 top-level fields and their meanings;
- mandatory trusted-host nonclaims;
- no absolute watched-root, caller-evidence, staging, or record destination;
- no source text, payload, credential, private endpoint, or readiness claim.

The temporary staging pathname must not enter the final record or shared
stdout.

An accepted record must mean:

all caller acceptance gates completed and the record was exclusively committed
at its final pathname.

## 11. Exact-successor compatibility

All acceptance-bearing compatibility runs must execute exact SUCCESSOR bytes.
Do not patch constants or use an edited reconstruction.

### A6D

Run sealed twice in two fresh external record directories.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical verifier stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- deterministic nonsnapshot fields;
- equal target/package/TMPDIR/caller-evidence snapshots;
- exclusive 0600 outputs;
- final publication contract satisfied;
- unchanged A6D manifest;
- mandatory nonclaims.

### Amendment

Run sealed twice with canonical verifier stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same conditions.

### Synthetic A6

Create only a private implementation-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require deterministic outputs per stage, exact successor bytes, empty verifier
stderr, equal snapshots, and only the expected writer-owned seal transition.

### SEC-02

Require source-by-value launch, target script never loaded, marker absent, and
direct-script predecessor shape nonqualifying.

Do not claim atomic interpreter custody.

## 12. Evidence and provenance

Keep all writes within REPAIR_ROOT except temporary private fixtures removed at
closeout.

Retain:

- exact base caller copy;
- exact successor source;
- exact source delta;
- atomic-publication capability record;
- caller-evidence containment causals;
- full publication-failure matrix;
- depth and snapshot regression;
- caller negatives;
- A6D, amendment, synthetic, and SEC-02 records;
- sidecar outputs;
- record-schema comparison;
- failed/superseded attempt index;
- opening/closing repository and supplied-root inventories;
- cleanup record;
- complete inline implementation report.

Create two byte-identical canonical repair manifests. Cover every retained
nonmanifest file exactly once and only self-exclude the two manifests.

## 13. Closing gates

At closeout require:

- unchanged repository manifest and tracked diff;
- exact 477-object repository inventory;
- unchanged BASE_REPAIR_ROOT and blocking audit;
- unchanged A6D and amendment manifests;
- no output written into any supplied root;
- no process, child, descriptor, fixture, or temporary-root survivor;
- empty private tmp;
- every retained file regular, single-link 0600;
- every retained directory 0700;
- exact path/mode/hash/link closure.

Do not perform an independent audit.

## 14. Mandatory stops

Stop and report BLOCKED or SCOPE_EXPANSION_REQUIRED if:

- exclusive atomic no-overwrite publication cannot be behaviorally proved;
- a protocol or record-schema change is needed;
- a fourth public output file is required;
- crash durability or privileged-host attestation becomes necessary;
- final JSON can still say accepted after a failed invocation;
- caller_evidence semantics cannot be preserved;
- a supplied root must be changed;
- depth/snapshot behavior regresses;
- repository work becomes necessary;
- scope widens beyond the exact caller and external evidence.

## 15. Inline implementation report

Include:

1. Verdict.
2. Opening identities.
3. Audit findings consumed.
4. Classification and authority.
5. Exact source identity and delta.
6. Caller-evidence containment repair.
7. Publication state machine and commit point.
8. Atomic publication capability and probe.
9. CLI/protocol/schema preservation.
10. Exact 25-field disposition.
11. Partial-output and retry behavior.
12. Hook reachability.
13. Depth/snapshot regression.
14. Caller-evidence causals.
15. Publication-failure matrix.
16. Caller negatives.
17. A6D results.
18. Amendment results.
19. Synthetic A6 results.
20. SEC-02 result.
21. No-write and deterministic-output evidence.
22. Repository and supplied-input invariance.
23. Repair evidence inventory and manifests.
24. Failed and superseded attempts.
25. Remaining uncertainty and nonclaims.
26. Explicit confirmations:
    - repository mutation not performed;
    - supplied-evidence mutation not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - independent audit not performed;
    - subagents created: 0.
```

### Sources

The prior implementation explicitly required a fresh independent audit and froze the caller as source-external evidence rather than authority.  It also claimed that uncertain output closure prevented acceptance; the audit has now disproved that claim for the exact implementation. 

The standard project lifecycle requires returning a blocked patch to implementation, producing new validation and provenance, and then using a fresh audit because changed bytes invalidate the prior audit.  Provenance must bind the new implementation and audit to the same bytes, but it does not itself establish correctness. 

**Confidence**

- Both audit findings are real caller defects: **0.995**
- The depth and general external-destination repairs should be preserved: **0.99**
- Caller-evidence disjointness is a narrow, straightforward correction: **0.99**
- Atomic exclusive JSON publication is the correct repair class: **0.95**
- Another audit before this repair would add no value: **0.999**
