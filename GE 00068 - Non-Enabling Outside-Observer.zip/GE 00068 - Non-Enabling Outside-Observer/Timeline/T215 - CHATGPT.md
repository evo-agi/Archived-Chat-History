## Assessment

This is a strong implementation closeout. At report level, `REPAIR10I_A6_SUCCESSOR_GOVERNANCE_FREEZE_IMPLEMENTED_READY_FOR_FRESH_AUDIT` is the correct disposition.

The implementation appears to have stayed inside the frozen seven-path scope, preserved the 389-object dirty baseline, changed no product source, installed one structured authority block with five bounded consumers, added a full-documentary contract test, and validated all 106 `docs_contract_test.go` identities. The current-versus-target distinction is also materially better than the earlier reconnaissance: v7 is selected, but explicitly not implemented; A6D and the amendment remain historical evidence; Evidence Verification and caller v4 retain bounded structural and publication roles.

I see no report-level reason to send it back for implementation repair before audit.

It is not accepted yet. The implementation report and its provenance capsule are producer evidence, not independent correctness evidence; the project has consistently kept that distinction explicit.  A fresh read-only audit is the required next engagement, separate from implementation validation.  Exact provenance can establish that the same bytes were inspected, but cannot establish that the policy is coherent, tests are sufficient, or authority boundaries are sound. 

### Audit-sensitive points

The fresh audit should concentrate on five areas rather than reopening the whole Repair 10I design:

1. **Complete-document coherence.** The bounded authority block can be internally perfect while stale prose elsewhere still calls an older v1/v5/v6 family current. The auditor must inspect complete governing documents, not only the marked sections.

2. **Oracle independence.** `docs_contract_test.go` may legitimately hard-code the expected contract as a regression oracle, but the audit must independently parse the contract and reconstruct the mutations. The repository test cannot be its own sole correctness oracle.

3. **Sole-writer scope.** The audit must determine whether “one sole authority block” is intended across the entire repository or only the six named governing documents, then test exactly that claim. It should not silently impose repository-wide marker semantics if the contract freezes a closed document set.

4. **Dirty-baseline provenance.** The material audit target is the seven-path delta from the retained 389-object opening inventory, not the much larger HEAD-relative patch. All other 382 governed objects must remain equal to the implementation opening state.

5. **Evidence-manifest exclusions.** The producer intentionally excluded `manifest/**` and the detached final report to avoid cycles. The audit should verify those exact exclusions, establish that no excluded object is silently being used as acceptance-bearing evidence, and independently regenerate the tranche delta and closeout records.

The seven failed validation attempts are not inherently problematic. They become a concern only if a superseded result was counted, an induced compatibility statement widened the contract, or the final attempt no longer binds the reported bytes.

I would **not begin the semantic successor implementation until this audit returns `ACCEPT`**. An eventual publication or commit decision also remains separate: this is a seven-path delta layered on an already dirty candidate worktree, so audit acceptance should not be mistaken for authorization to stage the full current versions of those seven files.

## Prompt for the fresh independent audit

```text
MANDATORY RESPONSE FORMAT

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Embed the complete audit report inline in Markdown. Supplemental evidence paths
may be linked, but must not replace the inline report.

This is a fresh, read-only independent audit.

Do not repair, edit, create repository files, format repository files, normalize
repository files, remove repository artifacts, stage, commit, reset, amend,
revert, merge, push, create an upstream, create a PR, install dependencies,
contact a network, invoke product or live services, execute Repair 10I
controls, invoke comparison/analyzer binaries, invoke Evidence Verification or
caller v4, create or resume an A6 child, or mutate any supplied evidence root.

Audit-owned records, fixtures, copied inputs, validation caches, and temporary
files may be created only beneath the fresh audit root defined below.

## 1. Objective

Independently audit the exact Repair 10I A6 successor-governance freeze
implemented in:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Determine whether the exact live seven-path tranche:

1. accurately separates current facts from selected-but-unimplemented target;
2. establishes one coherent private governance authority;
3. freezes the exact v7, canonicalization, historical-transition, allocation,
   orchestration, and nonauthority decisions;
4. is contradiction-resistant through an adequate documentary contract test;
5. preserves the accepted dirty baseline outside the seven authorized paths;
6. contains no authority, product, public-schema, runtime, or proof-harness
   widening;
7. is sufficiently precise to govern the later source-external semantic
   successor tranche.

This audit does not evaluate a semantic successor implementation, allocator,
orchestrator, fresh A6, product runtime behavior, or deployment readiness.

An ACCEPT verdict means only that these exact governance-overlay bytes are
sound enough to govern the next source-external semantic implementation
tranche. It does not authorize staging, commit, push, A6 execution, or product
publication.

## 2. Administrative and process boundary

Reading the complete prompt or an attachment containing it is administrative
and may occur before the audit epoch. Do not treat such a read as repository
inspection merely because its process cwd is unrelated.

The audit epoch begins immediately before the first repository- or
implementation-evidence-facing operation.

After the epoch begins:

- repository-facing commands must use the exact candidate worktree as cwd;
- Git commands must use `git -C "$CANDIDATE_R" ...`;
- do not run Git or filesystem searches in the primary checkout;
- supplied evidence roots are read-only;
- auditors must not run Git;
- no nested subagents are allowed;
- no repository module may be imported in a way that can create bytecode or
  repository-local cache artifacts.

Every repository Git invocation must explicitly receive:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

Use a private audit TMPDIR.

Do not invent a process failure merely because linked-worktree Git
administration is physically under the primary repository’s `.git` directory.
If Git-administration inspection is needed, derive exact paths through rooted
Git commands and perform only narrow read-only checks.

## 3. Exact roots

CANDIDATE_R:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

IMPLEMENTATION_EVIDENCE:

  /Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2

Relevant historical inputs, read-only and only where needed to verify current
fact claims:

A6D_ROOT:

  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

AMENDMENT_ROOT:

  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

A6V_ROOT:

  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6v-evidence-target-recon-8de797304ea9

A6R_ROOT:

  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Allocate AUDIT_ROOT atomically beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, a descriptive prefix, umask `077`, directory mode `0700`,
and retained file mode `0600`.

Do not require a predetermined fresh audit-root suffix.

Create private cache and temporary directories only beneath AUDIT_ROOT.

## 4. Expected live repository identity

Expected physical root:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected device/inode:

  16777234 / 122118502

Expected branch:

  codex/remote-alpha-external-tls-status-observation-v1

Expected HEAD:

  567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

  b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

  05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

  absent

Expected status posture:

- 389 governed objects;
- 375 tracked;
- 14 nonignored untracked;
- 22 tracked modifications;
- zero staged, deleted, renamed, or unmerged paths.

Expected final source T:

  e01538a45d8b11a332ee6b6fc78239bfd6509303

Expected final inventory SHA-256:

  29251ed38218cadb5528db1e6b04a60078abf7aea3d9ebfa2b29437fc6c923a7

Expected final inventory size:

  54,314 bytes

The retained implementation opening baseline is:

- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- 389 members.

The opening baseline exists only as retained producer evidence. Recompute its
identity from retained opening rows and bytes rather than trusting a summary.

## 5. Exact authorized tranche and live final identities

Exactly these seven repository paths may differ from the retained opening
baseline:

1. PLANS.md
   - 288,739 bytes
   - SHA-256:
     f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f

2. .docs/system_overview/configuration.md
   - 129,589 bytes
   - SHA-256:
     f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3

3. .docs/system_overview/boundaries.md
   - 96,086 bytes
   - SHA-256:
     0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd

4. .docs/system_overview/artifact_hygiene.md
   - 38,322 bytes
   - SHA-256:
     2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910

5. .docs/system_overview/capability_probing.md
   - 42,667 bytes
   - SHA-256:
     4730644365b4ad65f56f57573cb39e592ff3eeb88a0a5e10f6df444dcc75a65b

6. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
   - 97,555 bytes
   - SHA-256:
     010d2d6ed46e325ec82eaeeb8f843493f6cd7d52feef53ed140db12e1cc042e6

7. docs_contract_test.go
   - 778,632 bytes
   - SHA-256:
     b1f61eed7960d208541c25ac145af0768ab178248c020333841fc619543432d3

Every other governed object must match the retained implementation opening
baseline in path, type, mode, size, and SHA-256.

No product Go source, public schema, module file, operational script,
production command, or Evidence Verification/caller source may differ because
of this tranche.

## 6. Implementation-evidence identities

Expected sole structured contract:

  execution-substrate.repair10i-a6.successor-governance.v1

Expected canonical authority-block SHA-256:

  ec6191e0ffdd1647215f37ee5ca033f47816dd44c63a7f99d8c87c4b886e8a94

Expected documentary test:

  TestRepair10IA6SuccessorGovernanceContract

Expected tranche-only provenance recipe:

- ID:
  execution-substrate.repair10i-a6.successor-governance-provenance.v1
- source:
  IMPLEMENTATION_EVIDENCE/provenance/build_closeout_v1.py
- size:
  28,602 bytes
- SHA-256:
  50e767ba6551a309bc9390cb1baddb389659e5a6b715fd0868af2d4dd8d29276

Expected tranche-only delta:

- path:
  IMPLEMENTATION_EVIDENCE/delta/tranche-only-binary-unified-delta-v1.patch
- size:
  51,594 bytes
- SHA-256:
  f78a14dc8c78f692001a2b6818c3aae6b42f7067c7db1b1ccb18b7c702d1ac9c

Expected canonical implementation-evidence manifest:

- path:
  IMPLEMENTATION_EVIDENCE/manifest/canonical-manifest-v1.txt
- file count:
  55
- size:
  8,396 bytes
- SHA-256:
  ba4d570e12f9746646a747cf4728e3328b11b8525ece7a7e652beb87404c1ca0

Expected evidence-manifest recipe source SHA-256:

  9c980ce38223485bcc58483fee9218db4efcb1841eb862dc199fbf61f6f7e737

Expected implementation records include:

- provenance/apply_governance_freeze_v1.py
- closeout/full-inventory-comparison-v1.json
- closeout/failed-and-superseded-attempt-index-v1.json
- closeout/final-implementation-report-v1.md
- validation/011-all-docs-contract-test-identities.json
- validation/014-focused-governance-contract-verbose-final.json

The implementation report states that `manifest/**` and the detached final
implementation report are excluded to avoid a digest cycle. Verify the actual
root independently:

- enumerate every retained file and directory;
- verify every listed row;
- identify every excluded object;
- require that exclusions are exactly explained;
- do not use an excluded object as acceptance-bearing proof without separately
  authenticating it;
- stop on an unexplained extra, omission, wrong mode, wrong link count, or
  changed hash.

## 7. Opening provenance gate

Before correctness inspection:

1. Verify the physical candidate root and all Git identities.
2. Compute the complete live 389-object inventory.
3. Recompute final source T and inventory.
4. Verify the exact seven live final file identities.
5. Reconstruct the retained opening inventory and source T from producer
   evidence.
6. Compare live final state with retained opening state and require exactly
   seven changed paths and 382 unchanged objects.
7. Verify the exact implementation provenance recipe bytes.
8. Inspect its interface and execute exact copies twice into separate,
   audit-owned fresh continuations, directing all output under AUDIT_ROOT.
9. Require byte-identical canonical outputs and the expected opening/final
   identities.
10. Independently rebuild the tranche-only binary delta twice from retained
    opening bytes and live final bytes; require both builds to be byte-identical
    to each other and to `f78a14...ac9c`.
11. Independently extract the structured authority block and require its
    canonical digest to equal `ec6191...a94`.
12. Verify the implementation evidence root and the failed/superseded-attempt
    lineage.

If exact recipe execution would require writing into the producer root, copy
the exact source into AUDIT_ROOT and direct only its outputs to AUDIT_ROOT.
Do not change recipe semantics.

Return `AUDIT_PROVENANCE_MISMATCH` and stop before correctness inspection on
any discrepancy.

Do not reconstruct missing source approximately.

## 8. Four distinct independent auditors

After the opening gate passes, start exactly three read-only auditors
concurrently. After one closes, start a fourth distinct auditor.

Retry a required start at most once. If the fourth perspective cannot be
started, complete no correctness verdict by parent substitution; return
`BLOCK` with a specific audit-process finding.

No auditor may:

- run Git;
- write a file;
- run tests;
- import repository code;
- create a nested subagent;
- inspect unrelated repositories or Downloads roots;
- contact a network.

Each auditor receives the same exact candidate, opening/final inventory,
seven-path delta, contract-block digest, implementation-evidence identities,
current facts, selected target, and non-goals.

### Auditor 1 — Contract and authority

Inspect:

- AGENTS.md;
- complete `PLANS.md`;
- all six changed governing documents;
- relevant unchanged governing documents referenced by them;
- the authority block and all consumer references;
- the critical current-fact source inputs under A6D, amendment, A6V, and A6R.

Determine:

- whether current fact and selected target are consistently separated;
- whether v7 is ever described as implemented;
- whether v6 is silently redefined;
- whether v5/v2 is promoted to current qualification;
- whether the runner-v1/extractor-v2 mismatch is stated accurately;
- whether historical comparator, allocator, orchestrator, and five literal
  instances remain unimplemented;
- whether one document is the sole authority writer;
- whether consumers only reference and do not redefine;
- whether any public/product/runtime/readiness authority is widened;
- whether the target conflicts with AGENTS.md or current product contracts.

Inspect complete documents, not only bounded marker blocks.

### Auditor 2 — Structured contract and documentary-test correctness

Inspect:

- the complete structured contract;
- `docs_contract_test.go`;
- all helper functions used by
  `TestRepair10IA6SuccessorGovernanceContract`;
- producer mutation records;
- canonical encoding and duplicate-key behavior.

Determine:

- whether the repository test has an independent expected oracle rather than
  reading expected values from the document under test;
- whether it validates the complete structured contract;
- whether exact types, values, keys, placement, writer, consumers, and
  canonical encoding are enforced;
- whether the test’s mutation count and names are stable;
- whether contradictory cases reject for mechanism-specific reasons;
- whether the test is a regression oracle rather than a second normative
  contract writer.

### Auditor 3 — Validation and dirty-baseline provenance

Inspect:

- the exact opening and final inventories;
- source-T reconstruction;
- the seven-path delta;
- both provenance recipes;
- implementation validation records;
- all failed and superseded attempts;
- Go tool and gofmt identities;
- test identity discovery and document-reader selection.

Determine:

- whether exactly seven paths changed from the retained dirty baseline;
- whether no failed attempt was counted as qualifying;
- whether the four documentation corrections following failed tests widened or
  contradicted the final contract;
- whether all reported tests ran against final bytes;
- whether excluded evidence objects are safely nonauthoritative;
- whether producer provenance is reproducible.

### Auditor 4 — Security, artifact, allocation, and orchestration semantics

Inspect:

- allocator and orchestration portions of the structured contract;
- artifact-hygiene and capability-probing consumers;
- no-resume and sole-writer semantics;
- CSPRNG, no-follow traversal, exclusive mkdir, collision handling, and retry
  bounds;
- authority split among repository governance, future semantic package,
  future orchestrator, Evidence Verification, caller v4, Git, and validating
  runtimes;
- sensitive-material and output boundaries;
- implementation-evidence modes, links, exclusions, temporary files, and
  cleanup.

Determine whether the documents accidentally:

- permit scan/latest/timestamp/PID allocation;
- permit adoption, rename, repair, or resumption of an existing child;
- permit multiple progression writers;
- grant Evidence Verification or caller semantic/readiness authority;
- turn generated schemas or evidence into product/public authority;
- expose sensitive evidence or private paths;
- claim future package bytes, schemas, binaries, or instances already exist.

Each auditor must state evidence, inference, uncertainty, files inspected,
scope not inspected, and whether a blocking finding exists.

## 9. Independent contract parsing and causal matrix

The parent must build an audit-owned structured-contract parser without
importing or copying the repository test helper’s parser logic.

The parser must:

- locate the authority block;
- reject duplicate JSON keys and nonfinite JSON constants;
- enforce canonical one-line encoding and terminal newline rules;
- compare the complete field set, types, and values;
- parse every consumer reference;
- detect duplicate or competing authority markers according to the contract’s
  claimed scope.

First determine from the actual contract whether authority-marker uniqueness is
defined:

- across the entire repository; or
- across a closed named governing-document set.

Test the exact documented claim. Do not silently widen it.

Perform a repository-wide read-only literal marker search as an observation
even when the contract uses a closed set.

Independently reconstruct all fourteen producer mutation cases without
calling the producer mutation generator:

1. v7 claimed implemented;
2. v6 silently redefined;
3. v5/v2 promoted;
4. observability rule reverted to v1;
5. independent runner/extractor registries allowed;
6. `absent → pass` rejected;
7. new passes offset regressions;
8. aggregate-exit equality made authoritative;
9. factual result and adjudication merged;
10. scan/latest/timestamp/PID allocation permitted;
11. existing child resumed;
12. second orchestration writer admitted;
13. Evidence Verification granted readiness authority;
14. source-external evidence granted product authority.

Require each to reject for the intended mechanism-specific reason.

Add audit-only cases covering at least:

- missing mandatory contract key;
- unknown key;
- Boolean replaced by string;
- string replaced by Boolean;
- duplicate JSON key;
- noncanonical JSON;
- duplicate authority block;
- alternate authority-family identifier;
- authority block in each consumer;
- mismatched BEGIN/END identifiers;
- unmatched BEGIN;
- unmatched END;
- nested or overlapping blocks;
- duplicate consumer reference;
- wrong sole-writer path;
- consumer override or local narrowing/widening;
- selected-target status changed to current implementation;
- generated JSON Schema promoted to normative authority;
- caller or verifier granted execution, commit, or publication authority;
- interruption changed from permanent failure/supersession to resumability.

Record every observed reason.

Unmarked prose outside bounded sections need not be machine-interpreted by the
repository test. The auditors must nevertheless inspect the current complete
documents for actual contradictions.

## 10. Exact policy review

Independently verify that the final contract freezes exactly:

### Selected v7 family

- suite-spec.v7
- ab-suite-spec.v7
- suite-result.v7
- binding-recomputation.v7
- control-qualification.v7
- semantic-comparison-spec.v7
- semantic-comparison-result.v7
- semantic-comparison-custody.v7

### Retained versions

- command intent/result/terminal reconciliation v3;
- effective read policy v3;
- four private PTY v2 records;
- the enumerated v1 observation, inventory, provenance, semantic, and
  byte-comparison records.

### Adopted A6 records

- historical-transition-analysis.v2
- historical-comparison-adjudication.v1
- child-allocation.v1
- opening-capsule.v1
- orchestration-record.v1
- closeout-adjudication.v1
- cleanup.v1
- command-index.v1
- failed-and-superseded-attempt-index.v1
- closing-gate.v1
- command-root-audit.v1

### Canonicalization

- policy:
  execution-substrate.repair10i.semantic-canonicalization.v2
- active observability rule:
  observability-inbound-request-complete-v2
- v1 observability rule:
  historical only
- one future authoritative ordered registry;
- semantic extraction and logical fingerprint use the same registry;
- final/fresh equality under a shared wrong fingerprint is nonqualifying;
- policy ID, rules digest, and logical fingerprint are bound.

### Historical direction and transitions

Directions:

- historical HEAD → pristine final
- historical Repair 9 effective → pristine final

Admitted:

- pass → pass
- fail → fail
- skip → skip
- absent → pass
- fail → pass
- skip → pass

Rejected:

- pass → fail
- pass → skip
- pass → absent
- fail → skip
- fail → absent
- skip → fail
- skip → absent
- absent → fail
- absent → skip

`absent → absent` is outside the nonempty transition set.

New passes cannot mask any rejected transition.

Historical aggregate exits need not be equal. Each control must be
individually specification-consistent, terminal-consistent, semantically
consistent, qualified, EOF-complete, and custody-complete.

### Output separation

Require distinct factual comparison, directional transition analysis, and
historical adjudication records and exit meanings.

### Allocation

Require:

- exact parent;
- prefix `phase-i-a6-policy-evidence-v7-`;
- 32 lowercase hex characters from 16 operating-system CSPRNG bytes;
- no-follow component traversal;
- held parent descriptor and identity;
- exclusive descriptor-relative mkdir;
- mode 0700;
- at most 128 collision attempts;
- no scanning, latest selection, adoption, timestamp, PID, counter, Git-hash
  authority, rename, or resume.

### Orchestration

Require:

- exactly one evidence-instance progression writer;
- immutable events/results and one final record;
- no second mutable current-state authority;
- interrupted or uncertain child permanently failed or superseded;
- no repair, adoption, rename, sealing, or resume of that child.

## 11. Independent verification of critical current facts

Read-only inspect only the exact files necessary to verify:

1. A6D runner uses `observability-inbound-request-complete-v1`.
2. A6D semantic extraction and FORMAT require v2.
3. The amendment and A6D are immutable retained evidence.
4. Joint qualification records that fresh A6 was not restarted and historical
   comparator was not implemented.
5. Retained v5/v2 records and analyzer are historical-only.
6. A6V naming was a design candidate rather than an allocation authority.
7. Existing A6 policy children are nonresumable.

Do not execute binaries or traverse unrelated evidence trees.

A discrepancy between current evidence and the governing document is a
blocking contract finding.

## 12. Fresh validation

Use the exact pinned Go 1.26.5 tool identified in the implementation command
records.

Verify:

- `go version` equals `go1.26.5 darwin/arm64`;
- `go` SHA-256 equals
  `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`;
- `gofmt` SHA-256 equals
  `3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81`.

Use:

  GOTOOLCHAIN=local
  GOPROXY=off
  GOSUMDB=off
  GOENV=off
  GOWORK=off
  GOFLAGS=-mod=readonly

Place GOCACHE, GOMODCACHE, TMPDIR, HOME when needed, and all other generated
state beneath AUDIT_ROOT.

Before running tests, independently enumerate every top-level test identity in
`docs_contract_test.go` and identify which tests read any of the six changed
documents.

Run:

1. The governance contract test alone with `-v` and `-count=1`.
2. Every pre-existing test that reads an authorized changed document.
3. Every identity defined in `docs_contract_test.go`.
4. The complete docs-contract identity set again under a second umask:
   - one run under `077`;
   - one run under `022`.
5. `gofmt -d docs_contract_test.go`, requiring empty output.
6. `git -C "$CANDIDATE_R" diff --check`, requiring empty output.

Require:

- exact test identity sets;
- no failure, error, or skip unless the source contract explicitly permits it;
- no network or live-service use;
- no repository mutation;
- no repository cache or generated artifact;
- the exact live final `docs_contract_test.go` hash before every owning group.

Retain exact argv, cwd, environment, tool identity, exit, stdout, stderr,
identity set, and before/after inventory.

Do not run product tests, Repair 10I controls, A/B, semantic binaries, remote
helpers, Evidence Verification, caller v4, or A6.

## 13. Failed and superseded attempt review

Inspect every producer failed or superseded attempt.

Verify:

- the local Go 1.26.1 run is excluded;
- the missing `ES_REPAIR10_SOURCE_ROOT` run is excluded;
- the JSON HTML-escaping attempt is excluded;
- all four failed compatibility-statement attempts are excluded;
- the three failed provenance attempts are excluded;
- no failed output contributes to final counts, hashes, or acceptance;
- the final compatibility statements do not contradict or widen the selected
  governance contract;
- no failed attempt mutated an unauthorized path.

If a failed result is counted or a superseded source is used as the final
oracle, return BLOCK.

## 14. Artifact and evidence hygiene

At every major checkpoint, compare the full 389-object repository inventory
with opening.

Inspect the implementation evidence root for:

- mode `0700` directories;
- mode `0600` retained files;
- regular/single-link file posture;
- no symlink or special object;
- exact canonical-manifest coverage;
- exact and justified self-exclusions;
- empty private temporary directories;
- no sensitive path, credential, environment, raw evidence payload, or secret
  in shareable summaries;
- no generated object masquerading as authority.

Do not chmod, delete, normalize, or repair producer evidence.

Audit-created files must remain under AUDIT_ROOT.

Remove only audit-owned temporary fixtures and caches. Retain the evidence
needed to support the audit report.

## 15. Authority adjudication

Classify the resulting patch as a private governance and documentary contract
slice.

Confirm that it does not:

- alter product Go source;
- alter a public/product schema;
- alter runtime, admission, lifecycle, credential, deployment, or route
  semantics;
- implement v7;
- implement the semantic package;
- implement allocator/orchestrator behavior;
- create a fresh A6 child;
- grant Evidence Verification semantic or readiness authority;
- grant caller v4 semantic or readiness authority;
- turn reports, manifests, generated schemas, comparison results, analyses, or
  closeout records into hidden run truth;
- create a new cross-repository framework owner.

Preserve the distinction between:

- current repository contract;
- sealed historical evidence;
- selected strategic target;
- unimplemented future mechanism;
- report-only evidence.

## 16. Closing provenance

After audit-owned cleanup:

1. Recompute the full live 389-object inventory.
2. Recompute final source T and inventory.
3. Recheck all seven path identities.
4. Recheck the other 382 opening-baseline objects.
5. Re-run the exact tranche provenance recipe twice into new audit-owned
   continuations.
6. Rebuild the tranche delta twice.
7. Recheck implementation-evidence inventory and exclusions.
8. Re-run rooted Git identity/status/diff checks.
9. Require no repository or supplied-evidence mutation.

Return `AUDIT_PROVENANCE_MISMATCH` if the exact target differs at closing.

## 17. Finding format

For each material finding report:

- ID
- type
- severity: critical | high | medium | low | observation
- classification:
  current contract | selected target | compatibility | process | provenance |
  test adequacy | authority | artifact
- exact path and line
- evidence
- reachable mechanism
- impact
- required correction
- containment and nonclaims
- uncertainty
- patch defect, pre-existing issue, or audit-process issue
- blocking: yes or no

Preserve minority findings and explain the parent adjudication.

## 18. Required final report

1. Verdict.
2. Audit target and exact identities.
3. Opening provenance.
4. Exact dirty-baseline and seven-path delta.
5. Four auditor identities, schedules, operands, findings, and limits.
6. Sole authority and complete-document review.
7. Independent parsed contract field map.
8. Consumer-reference adjudication.
9. Repository-wide marker observation and exact claimed scope.
10. Independent producer and audit-only mutation matrices.
11. Test-oracle independence.
12. Current-versus-target treatment.
13. Exact version and canonicalization map.
14. Historical direction, transition, and exit policy.
15. Fact/analysis/adjudication separation.
16. Allocation contract.
17. Orchestration/interruption contract.
18. Critical current-fact verification.
19. Fresh validation results and exact test identities.
20. Failed/superseded attempt adjudication.
21. Implementation-evidence and manifest-exclusion adjudication.
22. Artifact and sensitive-material findings.
23. Authority/nonauthority adjudication.
24. Severity-ranked findings.
25. Minority findings and parent resolution.
26. Remaining uncertainty and explicit nonclaims.
27. Audit-created paths and cleanup.
28. Closing provenance.
29. Explicit confirmations:

    REPOSITORY_MUTATION_NOT_PERFORMED
    SUPPLIED_EVIDENCE_MUTATION_NOT_PERFORMED
    REPAIR_NOT_PERFORMED
    FORMATTING_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    A6_NOT_STARTED
    SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
    ORCHESTRATOR_NOT_IMPLEMENTED
    EVIDENCE_VERIFICATION_NOT_INVOKED
    CALLER_NOT_INVOKED
    PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
    NETWORK_CONTACT_NOT_PERFORMED
    NESTED_SUBAGENTS_CREATED: 0
```

## After the audit

On `ACCEPT`, the next engineering tranche is the **source-external semantic successor**, not fresh A6 and not the orchestrator. It should consume the exact audited governance bytes as its target contract, correct the shared canonicalization/fingerprint defect, implement the v7 factual comparison and transition/adjudication chain, and produce independently reproducible A/B binaries.

Because the candidate repository remains a larger dirty worktree, `ACCEPT` should not automatically trigger a seven-file commit gate. Commit treatment needs its own deliberate decision about whether the full current blobs of those seven paths belong in an isolated commit or remain bound as an audited working-tree overlay until the larger candidate is published.

### Sources

- Codex implementation report supplied in this turn.
- The project’s implementation/audit separation and fresh-audit protocol. 
- The project’s exact audit sequence and stop-on-provenance-mismatch rule. 
- Provenance scope and confidence boundaries. 
- Evidence Verification’s separation of structural closure from semantic readiness and its fresh-child rule. 

**Confidence**

- Report-level readiness for fresh audit: **0.97**
- Seven-path scope and dirty-baseline preservation: **0.96**
- Governance target completeness: **0.93**
- Documentary test adequacy before independent inspection: **0.82**
- Recommendation to audit before semantic implementation: **0.99**
