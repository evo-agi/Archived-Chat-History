## Assessment

`AUDIT_PROVENANCE_MISMATCH` is the correct primary verdict. Auditor 3 violated the declared read-only boundary by creating and deleting four `/tmp` files, so this attempt cannot qualify the package.

That process failure does **not** erase the substantive observations. The package should not be audited again unchanged. The report identified several likely real defects:

- Production records `-I -S -B` as if verified but apparently does not inspect the interpreter’s actual flags.
- The claimed post-copy re-verification appears to compare cached identity dictionaries instead of reopening the copied files.
- Final success publication may not be failure-atomic.
- Some producer negative cases appear synthetic or hard-coded rather than routed through the claimed rejection boundary.
- Two handoffs are not deterministic under the stated normalization because root-derived environment-map hashes remain different.
- Contract/schema alignment may fail open.
- Same-PID and CLI/SHA evidence may be weaker than claimed.

Other observations may be audit overreach rather than package defects:

- Requiring the reconciliation root’s original device/inode despite exact path and complete content closure.
- Requiring same-PID evidence to be anchored to the audit child-recorder PID, rather than the launcher’s authenticated pre-`execve` PID.
- Requiring every result record to repeat the full authority map rather than bind the closed contract.

Because Auditor 4 never started and the fresh mutation/failure matrices were incomplete, the correct next step is **not** another full audit and not yet a repair. First perform one parent-only, read-only findings reconciliation that independently proves or dismisses each reported package issue.

The four tool-using auditor pattern should also be retired for this package. It has become a recurring source of audit contamination without owning any authority. Future acceptance work should use one parent-owned execution path and four separately recorded analytical perspectives over already-retained evidence, with no auditor tool access or filesystem writes.

## Prompt for Codex

```text
READ-ONLY FINDINGS RECONCILIATION —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP PACKAGE V1

This is a bounded package-findings reconciliation, not another independent
acceptance audit and not an implementation task.

Do not modify or repair the bootstrap package.
Do not modify or clean the failed audit root.
Do not modify any supplied root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents or direct auditors.

Use one parent-owned reconciliation process. Audit-owned fixture files and
processes may be created only beneath a fresh reconciliation root. Every
external child process must have a contemporaneous start/outcome record,
complete streams, exit/signal, reaping, and descriptor closure.

Return exactly one primary verdict:

BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED
BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_NO_REPAIR_REQUIRED
BOOTSTRAP_PACKAGE_FINDINGS_EVIDENCE_INSUFFICIENT
RECONCILIATION_PROVENANCE_MISMATCH

OBJECTIVE

Independently adjudicate every package-level observation retained by the failed
audit at:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv

Separate each observation into exactly one class:

1. confirmed implementation defect;
2. confirmed contract/schema defect;
3. confirmed validation/evidence defect;
4. audit-method defect only;
5. report-only hardening opportunity;
6. disproved finding;
7. unresolved because indispensable evidence is absent.

Do not inherit the failed audit’s classification or severity. Reconstruct each
finding from the exact package source, contracts, records, and audit-owned
causals.

If one or more acceptance-affecting package defects are confirmed, return
`BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED` and provide the exact
bounded repair contract. Do not implement it.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

BOOTSTRAP_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-be5v9nny

Expected root identity:

- device/inode:
  16777234 / 179120828
- mode:
  0700
- producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected terminal manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  33552 each
- SHA-256:
  cec56d4c9ac08c79ae7da58107fd56cd3389ba879ed566e327b4582ae27e259b
- byte-identical:
  required

Expected live closure reported by the failed audit:

- 177 represented entries;
- 12 directories;
- 165 represented nonmanifest files;
- 167 physical files including manifests;
- exactly two manifest exclusions.

Primary semantic source files:

source/full_audit_bootstrap_v1.py

- size:
  81613
- SHA-256:
  01fb237ef588241e7147abf92baa59009d0b159dd5bc5543e70f7f83d82b01f5

source/process_self_check_payload_v1.py

- size:
  18433
- SHA-256:
  a6e83b46b4696b92a2a6cd66b9e7709d51f1ce376703138cf808f10e7582642e

source/qualification_harness_v1.py

- size:
  66641
- SHA-256:
  47d12bc390fd41a255f8b0adfa8e02826b8f25419195a3ac8f8fa596a0666fe8

Implementation report:

closeout/final-implementation-report-v1.md

- size:
  3062
- SHA-256:
  7f4f8841130917fa672a24b5c3ad85cdfe1ce29b9aa09e0241dfe58a10363a29

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv

Expected root identity:

- device/inode:
  16777234 / 179156020
- mode:
  0700

The primary `AUDIT_PROVENANCE_MISMATCH` verdict is nonqualifying and is not a
package verdict.

At minimum authenticate and inspect:

closeout/final-audit-report.md
analysis/severity-ranked-findings.json
provenance/complete-child-process-ledger.json
auditors/direct-auditor-schedule-v2.json
auditors/auditor-1-report.md
auditors/auditor-2-report.md
auditors/auditor-3-report.md
closeout/supplied-root-closing-equality.json
fixtures/cleanup-completion.json
closeout/terminal-audit-manifest-a-v1.json
closeout/terminal-audit-manifest-b-v1.json

Expected terminal audit manifest pair:

- size:
  12860 each
- SHA-256:
  6935ae04a130a5f1f27fd8c2f0cd9b829ba50213c909652292ab4da2f006d12b
- byte-identical:
  required

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

FAILED_PREDECESSOR_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-3_22cefi

Open these only when required to adjudicate a concrete package finding.

──────────────────────────────────────────────────────────────────────────────
2. FRESH RECONCILIATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-findings-reconciliation-

Retain at minimum:

opening/
analysis/
causals/
validation/
provenance/
closeout/
private/

No subagents.

No retained empty directory at close.

All retained directories mode 0700.
All retained files regular, single-link mode 0600.
No symlink, special object, or multiply linked file.

──────────────────────────────────────────────────────────────────────────────
3. OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Before finding adjudication:

1. Verify the complete bootstrap-package manifests and membership.
2. Verify the complete failed-audit capsule and terminal manifests.
3. Bind every fixed source and report identity above.
4. Capture complete lstat/no-follow opening inventories.
5. Confirm the reconciliation root aliases no supplied root.
6. Confirm no supplied input was modified during opening.
7. Establish one child-process recorder with:
   - ENOENT causal;
   - `/usr/bin/true` causal;
   - complete streams;
   - reaping;
   - descriptor closure.

Stop with `RECONCILIATION_PROVENANCE_MISMATCH` on any actual opening drift,
mutation, alias, or process-record failure.

──────────────────────────────────────────────────────────────────────────────
4. FINDING LEDGER
──────────────────────────────────────────────────────────────────────────────

Create one closed ledger with one row for every package observation below.

Each row must contain:

- finding ID;
- audit source and exact cited claim;
- alleged owning source/contract/record;
- exact source path and line range;
- governing contract path and JSON pointer;
- expected behavior;
- observed behavior;
- static evidence;
- dynamic audit-owned causal, when safely possible;
- whether the audit process failure could affect the observation;
- classification:
  implementation defect / contract-schema defect / validation-evidence defect /
  audit-only issue / hardening / disproved / unresolved;
- severity;
- acceptance effect;
- exact repair requirement, when confirmed;
- nonclaims and uncertainty.

No finding may be accepted merely because an auditor reported it.

──────────────────────────────────────────────────────────────────────────────
5. FINDING A — INTERPRETER ISOLATION FLAGS
──────────────────────────────────────────────────────────────────────────────

Allegation:

Production verifies the interpreter file identity but records `-I -S -B`
unconditionally without verifying the actual running interpreter flags.

Independently inspect:

- bootstrap source;
- bootstrap contract;
- bootstrap start/outcome/result schemas;
- pinned-interpreter verification;
- generated launch contract;
- producer tests.

Determine:

1. Does production inspect actual runtime state equivalent to:
   - isolated mode;
   - no-site mode;
   - no-bytecode mode?
2. Does it distinguish:
   - the importer’s own interpreter flags;
   - the future launcher/wrapper interpreter flags?
3. Does it record flags as observed, required, or merely configured?
4. Can the importer run without one or more of `-I -S -B` and still emit a
   success record claiming those flags?
5. Does the closed CLI contract assign verification responsibility to the
   external invoker rather than the importer?

Run audit-owned fixture invocations with safely varied flags when possible.
Use no target root and no supplied-root mutation.

Classify carefully:

- If the package claims observed verification but does not perform it:
  confirmed defect.
- If the package only records required future invocation configuration:
  disprove the allegation.
- If responsibility is ambiguous:
  contract defect.

Do not invent a new interpreter requirement.

──────────────────────────────────────────────────────────────────────────────
6. FINDING B — RECONCILIATION ROOT DEVICE/INODE
──────────────────────────────────────────────────────────────────────────────

Allegation:

Production enforces the literal reconciliation-root path and complete content
closure but does not enforce the original root device/inode.

Inspect:

- immutable-input contract;
- lineage binding;
- import-reconciliation verification;
- producer tests;
- implementation report.

Determine whether device/inode is:

- an acceptance-bearing immutable-input identity;
- report-only provenance;
- or intentionally excluded in favor of exact path and complete content
  closure.

Use an audit-owned physically distinct byte-exact fixture to determine actual
behavior.

Do not classify omission as a defect unless the closed package contract
requires physical-root identity.

──────────────────────────────────────────────────────────────────────────────
7. FINDING C — POST-COPY REVERIFICATION
──────────────────────────────────────────────────────────────────────────────

Allegation:

The separately contracted post-copy re-verification compares cached identity
dictionaries rather than reopening copied destination files.

Inspect the exact copy and reverify functions.

Determine:

1. Are destination files reopened no-follow after copy?
2. Are bytes, size, hash, type, mode, and link count freshly observed?
3. Are “before” and “after” records actually the same cached object?
4. Could destination replacement or mutation between copy and reverify pass?

Create an audit-owned fixture causal:

- copy a valid source;
- mutate or replace the destination after the initial copy verification but
  before the claimed post-copy reverify;
- exercise the production reverify path without modifying supplied roots.

A confirmed acceptance of the changed destination is a high-severity
implementation defect.

Retain exact source and causal evidence.

──────────────────────────────────────────────────────────────────────────────
8. FINDING D — AUTHORITY-BOUNDARY REPETITION
──────────────────────────────────────────────────────────────────────────────

Allegation:

The main contract has the complete authority/nonauthority set, but bootstrap
start, outcome, result, and self-check records inherit it rather than repeating
the complete map.

Independently enumerate:

- main contract authority map;
- every applicable record schema;
- actual successful output records;
- actual failure output records;
- process-self-check result.

Determine whether each record is contractually required to:

A. repeat the complete map;
B. bind the main contract identity;
C. carry only record-local authority fields; or
D. do some explicit combination.

Do not treat repetition as inherently superior.

Classify as a defect only when:

- a schema requires fields that are omitted;
- a record claims standalone authority without a binding;
- narrowing or widening is possible;
- or the record contradicts the main contract.

Otherwise classify as an audit-method overconstraint or optional hardening.

──────────────────────────────────────────────────────────────────────────────
9. FINDING E — SAME-PID EVIDENCE
──────────────────────────────────────────────────────────────────────────────

Allegation:

The payload compares retained launcher PID and payload PID, but the evidence is
not anchored to the audit child-recorder’s observed spawned PID.

Inspect:

- qualified launcher contract;
- launcher constructed-launch record;
- payload source;
- self-check result;
- child recorder;
- producer handoff records.

Determine the actual promised evidence:

- launcher pre-`execve` PID;
- wrapper PID, if promised;
- payload PID;
- child-recorder spawned PID.

Answer:

1. Is launcher/payload PID equality sufficient under the qualified contract?
2. Can the constructed-launch `launcher_pid` be forged by the payload?
3. Does the child recorder observe the launcher PID independently?
4. Is recorder anchoring a stated contract requirement?
5. Did both producer handoffs satisfy the strongest contractually promised
   equality?

Do not add recorder anchoring unless the contract requires it.

Classify separately:

- implementation defect;
- evidence-hardening opportunity;
- audit overreach.

──────────────────────────────────────────────────────────────────────────────
10. FINDING F — CLI AND WRAPPER-SHA BINDING
──────────────────────────────────────────────────────────────────────────────

Allegation:

The result reports CLI conformance and wrapper-SHA success, but does not
completely bind every option value or prove that the SHA value corresponds to
the `--expected-wrapper-sha256` option.

Inspect:

- launcher parser;
- constructed-launch record;
- CLI contract;
- payload assertion code;
- result schema;
- producer causals.

Independently parse exact constructed argv for fresh audit-owned handoffs.

Verify:

- every required option;
- exact option cardinality;
- exact values;
- option/value association;
- canonical order;
- wrapper-SHA occurrence count;
- SHA value specifically associated with
  `--expected-wrapper-sha256`;
- payload path/size/hash;
- audit root;
- phase;
- entry;
- authorized operands;
- expected outputs.

Identify whether the payload relies on an aggregate conformance field without
independently binding the underlying values.

Classify missing duplicated checks as hardening unless the process-self-check
contract explicitly requires them.

──────────────────────────────────────────────────────────────────────────────
11. FINDING G — HANDOFF NORMALIZATION
──────────────────────────────────────────────────────────────────────────────

Allegation:

After permitted root/PID normalization, the two handoff records still differ at:

- `/environment_evidence/constructed_map_sha256`
- `/environment_evidence/launch_contract_map_sha256`

Determine:

1. Whether these digests are necessarily root-bound because HOME/TMPDIR differ.
2. Whether the deterministic-materialization contract requires raw equality,
   normalized equality, or semantic equality.
3. Whether the producer’s normalization omitted recomputation or normalization
   of derived hashes.
4. Whether the two underlying normalized environment maps are equal.
5. Whether the report’s claim of byte-identical normalized results is false.

Independently normalize both producer handoffs.

Possible outcomes:

- runtime behavior correct, determinism evidence/normalizer defective;
- actual semantic nondeterminism;
- report-only overclaim;
- audit normalization overreach.

Freeze the exact correct normalization rule if a repair is required.

──────────────────────────────────────────────────────────────────────────────
12. FINDING H — FAILURE ATOMICITY AND SUCCESS PUBLICATION
──────────────────────────────────────────────────────────────────────────────

Allegations:

- Producer causals omit important verifier and final-success-publication
  boundaries.
- Final success publication may be non-atomic.
- Deleted replay evidence may prevent independent reproduction.

Inspect:

- success-record write order;
- bootstrap outcome/result publication;
- fsync and close ordering;
- directory synchronization;
- exception handling after visible success creation;
- cleanup;
- producer injection points;
- final failure-atomicity records.

Determine the exact commit point for bootstrap success.

Require the package not to leave a canonical success result when the process
ultimately reports failure.

Using audit-owned exact source copies or supported hooks, inject failures:

1. before success record creation;
2. during success record write;
3. during success-record fsync;
4. after success record close but before outcome creation;
5. during outcome write;
6. after outcome close;
7. during final parent/directory synchronization;
8. during postpublication verification, if present.

For each report retained artifacts and process disposition.

Identify every claimed producer failure case whose source fixture or replay
input was deleted.

Classify separately:

- implementation atomicity defect;
- validation coverage gap;
- unreproducible evidence;
- safe but undocumented commit-point behavior.

──────────────────────────────────────────────────────────────────────────────
13. FINDING I — SYNTHETIC OR HARD-CODED NEGATIVE CASES
──────────────────────────────────────────────────────────────────────────────

Allegation:

Several producer negative cases are hard-coded or synthetic rather than routed
through the rejection boundary they claim to test.

Inspect both producer and independent validators.

For every reported case identify:

- case name;
- claimed mechanism;
- actual code path;
- whether production source was invoked;
- whether the case parsed a fabricated result instead;
- whether it directly returned an expected reason;
- whether it mutated a real production input and observed production rejection;
- whether fixture source remains retained.

At minimum distinguish:

- legitimate unit/static checks;
- legitimate schema mutation checks;
- integration rejection causals;
- hard-coded expected-result fixtures;
- self-fulfilling tests.

Produce the exact list of overstated cases.

Do not require every static contract mutation to execute the whole importer.
Require only that the report describe the level honestly.

──────────────────────────────────────────────────────────────────────────────
14. FINDING J — CONTRACT/SCHEMA ALIGNMENT
──────────────────────────────────────────────────────────────────────────────

Allegation:

Contract/schema alignment may fail open.

Strictly compare every closed contract with every schema projection and actual
record producer.

For each record family verify:

- exact required keys;
- optional keys;
- unknown-key policy;
- types;
- enum values;
- cardinality;
- canonical encoding;
- cross-field constraints;
- authority fields;
- success/failure distinctions.

Run mutations for:

- missing contract-required field accepted by schema;
- schema-required field absent from implementation;
- unknown field accepted;
- wrong type accepted;
- success-only field in failure record;
- failure-only field in success record;
- authority narrowing/widening;
- contradictory status.

Identify exact fail-open path, if any.

──────────────────────────────────────────────────────────────────────────────
15. FINDING K — PLACEHOLDERS, SENSITIVE SCAN, AND INCOMPLETE LANES
──────────────────────────────────────────────────────────────────────────────

The failed audit did not complete:

- Auditor 4;
- full root-layout adjudication;
- final sensitive-material review;
- full independent mutation matrix.

Do not report these as package defects merely because they were incomplete.

Perform bounded parent-owned checks:

- classify every output-root ownership/namespace record;
- identify placeholder-only files, if any;
- scan every package file for plausible live sensitive material;
- do not emit matched payload content;
- confirm no source writes outside its fresh audit root except declared
  qualification fixture roots.

Any new finding must be independently evidenced.

──────────────────────────────────────────────────────────────────────────────
16. AUDIT-PROCESS FINDING
──────────────────────────────────────────────────────────────────────────────

Independently record that Auditor 3 created and deleted four `/tmp` files.

Classify it only as:

- failed-audit process-boundary defect.

Do not attribute it to the package.

For the future acceptance audit, recommend one of:

A. parent-only audit with four analytical perspectives generated by the parent;
B. direct auditors with no tool/filesystem access;
C. another bounded mechanism justified by evidence.

Do not require another four tool-using auditor schedule merely because the
failed audit used one.

──────────────────────────────────────────────────────────────────────────────
17. EXACT NEXT TRANCHE
──────────────────────────────────────────────────────────────────────────────

If repair is required, produce a closed proposed repair plan containing:

- confirmed findings only;
- exact touched semantic files;
- exact contract/schema changes;
- exact source changes;
- exact tests and causals;
- preserved semantics;
- explicit non-goals;
- validation commands;
- provenance requirements;
- independent-audit requirements;
- stop conditions.

Do not implement the repair.

Do not combine report-only hardening with acceptance-bearing repairs unless
needed for contract consistency.

If no repair is required, produce the exact simplified fresh-audit method and
explain why every partial package finding was disproved or nonblocking.

──────────────────────────────────────────────────────────────────────────────
18. CLOSING EQUALITY AND CAPSULE
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Remove only reconciliation-owned fixture and private roots after retaining
their complete inventories.

Perform two fresh `lstat` observations for each removed root and require
ENOENT twice.

Retain:

- complete finding ledger;
- source-line crosswalk;
- all dynamic causals;
- contract/schema comparison;
- synthetic-case adjudication;
- exact next-tranche plan;
- process ledger;
- closing equality;
- final report;
- final inventory;
- two independent covering manifests.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh reconciliation-root identity
3. Bootstrap-package identity and closure
4. Failed-audit identity and exact adopted evidence
5. Process posture
6. Complete finding ledger
7. Interpreter-flag adjudication
8. Reconciliation-root physical-identity adjudication
9. Post-copy reverification adjudication
10. Authority-record agreement adjudication
11. Same-PID adjudication
12. CLI/wrapper-SHA adjudication
13. Handoff-normalization adjudication
14. Failure-atomicity and success-publication adjudication
15. Synthetic/hard-coded case adjudication
16. Contract/schema alignment
17. Layout and sensitive-material findings
18. Audit-process finding and future-method recommendation
19. Confirmed repair scope or no-repair conclusion
20. Exact next tranche
21. Supplied-root closing equality
22. Fixture cleanup and ENOENT observations
23. Reconciliation-capsule inventory and manifests
24. Remaining uncertainty and nonclaims
25. Explicit confirmations

Required confirmations:

BOOTSTRAP_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
NO_SUBAGENTS_CREATED
NO_DIRECT_AUDITOR_USED
EVERY_PACKAGE_FINDING_INDEPENDENTLY_ADJUDICATED
AUDIT_PROCESS_DEFECT_NOT_ATTRIBUTED_TO_PACKAGE
NO_REPAIR_PERFORMED
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
A6_NOT_STARTED
```

Do not run another full package audit until this reconciliation decides the
actual package repair boundary.

**Source:** Codex’s latest nonqualifying full-audit-bootstrap report above.

**Confidence:** 0.995 that another unchanged audit would be wasteful; 0.95 that at least the isolation-flag, post-copy-reverification, and success-publication observations warrant independent causal reconciliation; 0.99 that the unauthorized auditor writes are an audit-method defect rather than a package defect.
