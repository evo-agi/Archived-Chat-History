Here is Codex's response:

# Repair 10I T2A-P Strategic B Snapshot — Final Report

## 1. Primary verdict

`REPAIR10I_T2AP_STRATEGIC_B_SNAPSHOT_READY_FOR_FRESH_AUDIT`

## 2. Opening candidate and supplied-root identities

Candidate repository:

`/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- Tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream absent
- Cached paths: 0
- Modified paths: 22
- Untracked paths: 14
- Tracked paths: 375
- Governed paths: 389
- Ignored/unmerged paths: 0
- Index and Git-lock state unchanged by opening reads

All candidate Git operations used the mandated `git -C`, candidate cwd, and exact six-variable environment.

The seven supplied roots were fully no-follow fingerprinted:

```text
accepted audit       dev=16777234 ino=177899858 files=5      bytes=716651      aggregate=a69a86c1506ff7e39b5f75175c08a4140ec8851af6164228625578470c30fd9b
reconciliation       dev=16777234 ino=177969035 files=234    bytes=2210939     aggregate=5c2da60ab476492aa6f960e9ddb0b890eca244bbedc81f62bca709f87396486f
failed gate          dev=16777234 ino=177938057 files=66     bytes=1424535     aggregate=ce4cc73b2f5688daf79e41d2aa627f78a9b080f00233c8dc9801cacf8ddbd1b1
audit repair         dev=16777234 ino=177742499 files=98     bytes=6610704     aggregate=6d359f034b1366a29a5455b6205499724a2e7037e38b5012946216569e3441fb
governance impl      dev=16777234 ino=177683220 files=60     bytes=3365062     aggregate=c6fc33db8905462008f34ed7ccb060837d9291c8003604c7a2fee3d2b71bdb4d
topology recon       dev=16777234 ino=178071975 files=75     bytes=3604378     aggregate=97fdb291e918dd50a271f042c350c6025ef3aa93d75dbb9053bcd22e6a4c3da2
Repair 10 lineage    dev=16777234 ino=149648711 files=129296 bytes=12556899768 aggregate=eb3fd5f3836eb32879596fa0f66735301652230fb18b21528fe304e9d11860a6
```

## 3. Snapshot-root identity

[Snapshot root](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2>)

- Device: `16777234`
- Inode: `178255587`
- Mode: `0700`
- Allocated with `tempfile.mkdtemp` and prefix `ES-repair10i-t2ap-strategic-b-snapshot-`

## 4. Exact H/B/F state map

- H: commit `567bceced5df95ecfe787cc66038d463a854e12c`, tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`, 375 files.
- B: source T `8de797304ea944b6a155924e0d1e9e8bbe79534e`, inventory `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`, 54,314 bytes, 389 files.
- F: source T `f276536fea579d0842cda43b0290656b200b7f27`, inventory `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`.
- H→B: 22 modified, 14 added, 0 deleted, 0 renamed.
- B→F: seven later governance paths.
- Frozen subject: `implement Remote Alpha external TLS T2A-P source`.

## 5. Complete 36-path H→B manifest

Identity format is `logical-mode/size/SHA-256`; `-` means absent.

```text
.docs/system_overview/artifact_hygiene.md | modified | H=100644/9898/2a74855d259f89e66aa8d7551247caaa85bc642822b05f546dca9ac1753b9c4e | B=100644/37504/667db2e1666c0175f8e1b7b302a84d986ba6cee97202a0482317fd4510e09831 | F=100644/38322/2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910 | B→F=yes
.docs/system_overview/boundaries.md | modified | H=100644/64066/160ba5f5518947807ed49411c8b015a9a9535fcd4bad38045ff1624a063b209b | B=100644/95470/247b265f382f055161e66939f17c830d48db14e7e5bc43d3c3afa368388f9e04 | F=100644/96086/0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd | B→F=yes
.docs/system_overview/capability_probing.md | modified | H=100644/6730/136936689d8cf1fde19fbc184081646c86326f895c921010021634e9f85dc4d8 | B=100644/41308/0ffb738eed19b69178aa2db16bfebb8593d6096d86cd5af48987c54fa58d22b8 | F=100644/42668/f177f939932e21e8d53fe521aad9386253e330527b6a85eeb73c0888b1acdeb2 | B→F=yes
.docs/system_overview/configuration.md | modified | H=100644/108882/695e2b3cfeeb99c81dae39c74cfb7d9edc44f59bdac093e5c918cc25dd730670 | B=100644/128904/0e0cf296db648d1de6d00733663740acb2a55a24ff5e96d8d1dd507fa689d67e | F=100644/129589/f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3 | B→F=yes
.docs/system_overview/remote_alpha_external_tls_lifecycle.md | modified | H=100644/19446/d33d42b5886710b116c08f2e05a689fa0b21afb191a579c6d65cc6e68bb1da6c | B=100644/26614/d28bc651f777fc595654b481a1c9a67374244a3ab7d87faaeaa047dab89c8f6e | F=100644/26614/d28bc651f777fc595654b481a1c9a67374244a3ab7d87faaeaa047dab89c8f6e | B→F=no
.docs/system_overview/remote_alpha_external_tls_policy_core_v1.md | modified | H=100644/25250/abe762e11a8bc742e7b2a34776541f65dc7bca7ab4efe1140447bca460dc5b7c | B=100644/30284/6ee2b5e67e257426e81714e419668415c8e2c665880acd49e7eccfdcd5e77c62 | F=100644/30284/6ee2b5e67e257426e81714e419668415c8e2c665880acd49e7eccfdcd5e77c62 | B→F=no
.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md | added | H=- | B=100644/83290/4560711c86b7c49c9cd14c85996d731efe5036821a5291ec112057715b46739a | F=100644/99195/18cfad593028ea25575d5e9593d95533cbda6400bba52897bba8a9ae4f17f32d | B→F=yes
.docs/system_overview/remote_alpha_external_tls_status_observation_v1.md | modified | H=100644/74125/f56c24ebbfd8c072dc6c8ac5edd6ea1b6b07f4b2b96aeeeba4f33892ed0bd411 | B=100644/80594/8cf875cd84709b33184198054924bc5d8f7e6c32d99dfbcbe512d8596f0297ad | F=100644/80594/8cf875cd84709b33184198054924bc5d8f7e6c32d99dfbcbe512d8596f0297ad | B→F=no
.docs/system_overview/remote_supported_host_alpha.md | modified | H=100644/297177/b90e644a6741f985ee12586f2d57063cb840dbb45e74e2f39be86eb4658d922e | B=100644/302581/e884e00590986eefc41e08d3009d439716496b707405941db1ae53af431e562a | F=100644/302581/e884e00590986eefc41e08d3009d439716496b707405941db1ae53af431e562a | B→F=no
PLANS.md | modified | H=100644/214550/968bb84a32d2a9538104c3d7e3c65c3f7b9edc0c9fad1502c230c24975b4387c | B=100644/288586/9e8a989e89d05df09ae0216b0d74ab77c38eb1a49acb44d57580d7056b47c6c6 | F=100644/288739/f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f | B→F=yes
docs_contract_test.go | modified | H=100644/677102/6ebf44fcecb1ccd07f4da792b72552dc5646e47d7a8c25669a8a01202f3edf76 | B=100644/761534/375ca77db2402e1aea612dc70935304b61504606006aa7a2944a04f62a2944d8 | F=100644/794256/e43d41791758e6e8ebf2e7fe585e7469f342d9eb3013171cc76bece662f02684 | B→F=yes
es/admission/internal/reliablesubmit/sqlite_physical_test.go | modified | H=100644/13955/99a0d7c5fadcb98f334481d3661487bab7b4eeba1fece59bdb035e4fb87e4048 | B=100644/14218/4d97b16fcb166fb3200b1229eb0eaffe3928ca2e6ec9f4a7b8c2c0bbf5242621 | F=100644/14218/4d97b16fcb166fb3200b1229eb0eaffe3928ca2e6ec9f4a7b8c2c0bbf5242621 | B→F=no
es/admission/service_direct_test.go | modified | H=100644/11807/de42ca72bd6227785242b7583c4e8bebe139e8894a9543c8481d540352f108d0 | B=100644/11500/06bf1b071ac97cd4f9c1ef7d30edbafe4daa81f7bfb6150bac5688b771eb6f68 | F=100644/11500/06bf1b071ac97cd4f9c1ef7d30edbafe4daa81f7bfb6150bac5688b771eb6f68 | B→F=no
es/app/submit_integration_test.go | modified | H=100644/104946/5babefbe1b6d2a82051e348324d7c756af96f189abdb0afe0a7da83946ae3545 | B=100644/105161/8a0d3b6dda8fd57497e607c54b97331d3799e9b2cba445f504e4d22061404720 | F=100644/105161/8a0d3b6dda8fd57497e607c54b97331d3799e9b2cba445f504e4d22061404720 | B→F=no
es/externaltls/cmd/es-external-tls-status-package/main.go | added | H=- | B=100644/176/f125fc8c860179e58b65afea80d7fe32f06f39704b59e62fde34d2cd2c7b0484 | F=100644/176/f125fc8c860179e58b65afea80d7fe32f06f39704b59e62fde34d2cd2c7b0484 | B→F=no
es/externaltls/internal/statusobservation/remoteobserver/observe_test.go | modified | H=100644/250889/e5d54c5d47a9e5a81331117c28b46b6c07895dcc3af8fd0f48050b017f666468 | B=100644/268924/cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec | F=100644/268924/cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec | B→F=no
es/externaltls/internal/statuspackage/package.go | added | H=- | B=100644/315262/168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6 | F=100644/315262/168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6 | B→F=no
es/externaltls/internal/statuspackage/package_test.go | added | H=- | B=100644/463762/046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f | F=100644/463762/046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f | B→F=no
es/externaltls/internal/statuspackage/schema.go | added | H=- | B=100644/27681/9375bb13026cc91005e58a71ff8ef211a84490c487af71e4246ac2636860980a | F=100644/27681/9375bb13026cc91005e58a71ff8ef211a84490c487af71e4246ac2636860980a | B→F=no
es/runtimehelper/helper_test.go | modified | H=100644/5100/0805c758af02b8c2faf9e9533f7d23ae440c77d45dfd9ee313309efef140ccb1 | B=100644/5017/715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0 | F=100644/5017/715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0 | B→F=no
es/runtimehelper/supervisor_test.go | modified | H=100644/2687/6468873f827558d24088b218ea08f4d1531a8283ab6e4c2f2040ba80d30f8d2e | B=100644/5293/842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226 | F=100644/5293/842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226 | B→F=no
internal/testsupport/controlroot.go | added | H=- | B=100644/8695/3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3 | F=100644/8695/3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3 | B→F=no
internal/testsupport/controlroot_test.go | added | H=- | B=100644/1359/de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f | F=100644/1359/de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f | B→F=no
internal/testsupport/process.go | added | H=- | B=100644/17833/ab4bc338ae5b9f46c06ad677a86da8559eb42918e0d03a090dce970f507f6c62 | F=100644/17833/ab4bc338ae5b9f46c06ad677a86da8559eb42918e0d03a090dce970f507f6c62 | B→F=no
internal/testsupport/process_test.go | added | H=- | B=100644/10658/366b66afdb47d624e0a425e054f052b7389d36bb808d5f61f4cd9e0d8b073146 | F=100644/10658/366b66afdb47d624e0a425e054f052b7389d36bb808d5f61f4cd9e0d8b073146 | B→F=no
remote_alpha_migrate_es_service_user_test.go | modified | H=100644/39776/f913019dd137e19b20447de3079621bd4db5224caefecc5929ac4fd413bfabc9 | B=100644/39701/8b9877547e6c3ff5c9e2431a2a876c87bcf9adda762532ada6df83d71d4ba86e | F=100644/39701/8b9877547e6c3ff5c9e2431a2a876c87bcf9adda762532ada6df83d71d4ba86e | B→F=no
remote_alpha_normal_shell_runtime_image_check_test.go | modified | H=100644/22007/46c596f237448d71d4d9b90558e710285dc4f3213c20af3807d39606dd357ff6 | B=100644/22202/7276239128ac6945c9daef051a0b39770ff925d121bf3c111ae7f1bf7fb03081 | F=100644/22202/7276239128ac6945c9daef051a0b39770ff925d121bf3c111ae7f1bf7fb03081 | B→F=no
remote_alpha_operator_test.go | modified | H=100644/302232/0a3a3d5aa0f6d7b47e5f06eff6521e2c12ec1f324b13f7a544c92efd98890754 | B=100644/333580/f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578 | F=100644/333580/f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578 | B→F=no
remote_alpha_prepare_external_tls_status_test.go | added | H=- | B=100644/249415/71b99721dd3bca0a956fe66aab16cca23cf280e579f89b25e5fd0110a37c7446 | F=100644/249415/71b99721dd3bca0a956fe66aab16cca23cf280e579f89b25e5fd0110a37c7446 | B→F=no
remote_alpha_runtime_security_boundary_check_test.go | modified | H=100644/35931/4b281dd26e05c05f2d791740bb764a363babf4ca82abec676b31ea995267c13a | B=100644/35994/1d189733beb8a60cd2109f19fc0b3c40d60510b2cdb183d74689795970d1c3ff | F=100644/35994/1d189733beb8a60cd2109f19fc0b3c40d60510b2cdb183d74689795970d1c3ff | B→F=no
remote_alpha_vault_workload_auth_check_test.go | modified | H=100644/47917/a630c9125fa6cc5e985445d1fb2623d4f7bb0459876e7d627d7015543903d53e | B=100644/49347/2f8bea285ab0ca4e4015dd2f1cdd4e681980e8e95822c89fed3872ccf9b3193c | F=100644/49347/2f8bea285ab0ca4e4015dd2f1cdd4e681980e8e95822c89fed3872ccf9b3193c | B→F=no
scripts/remote_alpha_operator.sh | modified | H=100755/253854/4bd156fdefaeea544bf0aeb78e05413cb155690381139dc96b87672742723e03 | B=100755/258480/8b7cb6e8982965a82330d7990ad5ad68e4d281c28ef7bedab982ff61987ffe5a | F=100755/258480/8b7cb6e8982965a82330d7990ad5ad68e4d281c28ef7bedab982ff61987ffe5a | B→F=no
scripts/remote_alpha_prepare_external_tls_status.sh | added | H=- | B=100755/84316/23405e5ebed82f70ef7b3f35d47fc58c3d0293305e191569125316e8d81af5b7 | F=100755/84316/23405e5ebed82f70ef7b3f35d47fc58c3d0293305e191569125316e8d81af5b7 | B→F=no
testdata/remote_alpha_external_tls_status/repair10_git_session_v1.json | added | H=- | B=100644/1958/ec44b020427918292e91fd90d0ce8771e206ce2e483850d2dd987b5154400e4a | F=100644/1958/ec44b020427918292e91fd90d0ce8771e206ce2e483850d2dd987b5154400e4a | B→F=no
testdata/remote_alpha_external_tls_status/repair10_tree_corpus_v1.json | added | H=- | B=100644/1532/e02beedfeb1a5afbc3a351dd97897bd37c686344b8c5a7ba9b2370cb4d9e5013 | F=100644/1532/e02beedfeb1a5afbc3a351dd97897bd37c686344b8c5a7ba9b2370cb4d9e5013 | B→F=no
validation_isolation_test.go | added | H=- | B=100644/19366/6d06b1a9280c6e94aa22c9d6a26c44ad2bbb40c659f2b84ac381306b12d118ef | F=100644/19366/6d06b1a9280c6e94aa22c9d6a26c44ad2bbb40c659f2b84ac381306b12d118ef | B→F=no
```

The canonical retained form, including each changed path’s authenticated authority records and B source, is [H-B-36-path-manifest.json](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/provenance/H-B-36-path-manifest.json>).

## 6. Complete B source inventory and byte-source provenance

The complete 389-row inventory is retained at [B-canonical-source-inventory.json](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/provenance/B-canonical-source-inventory.json>) and its exact canonical text form at [B-source-inventory.txt](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/provenance/B-source-inventory.txt>).

Each JSON row contains classification, logical and custody modes, size, SHA-256, source path/device/inode/mode/link count, retained custody identity, H SHA-256 and Git blob OID where present, F identity, and B→F status.

Compact inline encoding:

- Columns: `path | H→B class | logical mode | size | SHA-256 | origin`
- `U/M/A`: unchanged/modified/added.
- `C`: exact candidate byte at the same path, authenticated because B=F.
- `G`: exact pre-governance byte from the governance-freeze `opening/authorized-bytes` tree.
- Every retained physical custody mode is `0600`.

```text
001 .codex/agents/es-boundary-auditor.toml | U | 100644 | 2556 | 15cfef845cd56b9890f85d9e6137a57a3d66cae437f82b7fbcd7926fbe331138 | C
002 .dockerignore | U | 100644 | 93 | 8cedd9fda5c5df380a3e8e0e3c042e2c249251520d0bb982f85cec4a010bdbca | C
003 .docs/commercialization/claim-ledger.md | U | 100644 | 55859 | bf392c1e39122752d66d48e8fae259c98199b5f6d6baecab2e0bcf55c0e4606e | C
004 .docs/commercialization/first-buyer-and-failure-mode.md | U | 100644 | 29240 | f1821c0db7867a4aaf145a25e5085d535526d3ce3d9312cdafb542ce5bdeede1 | C
005 .docs/execution_lifecycle/contracts.md | U | 100644 | 79433 | 4a8c5a7cdaebf058c1e46f278b2df42d371c5e6c3ed5f5ec418c17d1ed75d7fd | C
006 .docs/execution_lifecycle/design.md | U | 100644 | 38648 | 8d0b5ba50bac9b506eff2b2df12414e6e3467a2914ab3c6eb412be46f6021469 | C
007 .docs/execution_lifecycle/es_execution_admission_model.md | U | 100644 | 48780 | 45b6519c13c7dc805a74a191ac35363b926582fddc53d7516e9e56687680c607 | C
008 .docs/execution_lifecycle/implementation.md | U | 100644 | 61128 | e9b14468b26915d485f736910d37faf4592422745476410218a9631c46295b02 | C
009 .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md | U | 100644 | 62018 | 9f29edc216ca5da579a63e2a08b00afedd5489b2097efec7f7a71e92cb5f6a6c | C
010 .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md | U | 100644 | 56537 | e40e6d6e36c446b4b3ebb73333365e97e780a377fbbbebd262d6f8e1ff5a0a8f | C
011 .docs/execution_lifecycle/workstream_c7_checkpoint.md | U | 100644 | 11670 | 8c824236dd286275fbc95dbc0bb3b660a9701fd9f59daf192fc940a72c0ea8b8 | C
012 .docs/mvp.md | U | 100644 | 35184 | 2b2b55cf66b5002ad417b4e4a039ba8e7d0e9a8b38e9871e9b013527e560dcef | C
013 .docs/remote_alpha_operator_healthcheck_noninteractive_status.md | U | 100644 | 22874 | 457228b10d6c6a7076f91a68f83222060045c22c3b4b9b066af540f05f08583c | C
014 .docs/remote_alpha_operator_healthcheck_tls_operator_authorized_replacement.md | U | 100644 | 22902 | 015ac17ff4d7390b3e01004c0ff5eabb615bb1d3bb8c7682d8a9b6f8036f9222 | C
015 .docs/remote_alpha_operator_healthcheck_tls_signing_custody.md | U | 100644 | 19349 | d52e2114183f4d96caea50d0610ac0c48d9a1ccfc34a14236fe605ea06bacaf8 | C
016 .docs/remote_alpha_operator_healthcheck_tls_signing_custody_decision.md | U | 100644 | 22221 | ac452afd3ac0a622d7b6adaacd0f3665b662ba109030c2519519924b0474d9ad | C
017 .docs/remote_alpha_operator_healthcheck_tls_signing_custody_resolution.md | U | 100644 | 20815 | ad207c183ef4f40c9ef09e95f1c04ac57a4f26dfe63f5242c8ab33171e68a9b7 | C
018 .docs/supported_local_cp_consumer_runbook.md | U | 100644 | 38443 | 0b4397814d09ada92c7297ddaaac2670193174860aab436f3d71304128d071c9 | C
019 .docs/system_overview/architecture.md | U | 100644 | 25481 | 323b8b2c11d58ab6cda5bb5aea2afb7a838f92d5b8f2c6c31d4d0821e24168a0 | C
020 .docs/system_overview/artifact_hygiene.md | M | 100644 | 37504 | 667db2e1666c0175f8e1b7b302a84d986ba6cee97202a0482317fd4510e09831 | G
021 .docs/system_overview/artifact_publication_storage.md | U | 100644 | 18090 | aba1d471c708a31fb49b9f9ccac1ef7eaec8610473df854e6ca0fd52e32e039c | C
022 .docs/system_overview/boundaries.md | M | 100644 | 95470 | 247b265f382f055161e66939f17c830d48db14e7e5bc43d3c3afa368388f9e04 | G
023 .docs/system_overview/capability_probing.md | M | 100644 | 41308 | 0ffb738eed19b69178aa2db16bfebb8593d6096d86cd5af48987c54fa58d22b8 | G
024 .docs/system_overview/configuration.md | M | 100644 | 128904 | 0e0cf296db648d1de6d00733663740acb2a55a24ff5e96d8d1dd507fa689d67e | G
025 .docs/system_overview/contracts.md | U | 100644 | 75834 | 260799066d0a0cfe9030d0b82a32810218c417b9e2e4a51e99aae62dede10388 | C
026 .docs/system_overview/evolution.md | U | 100644 | 8269 | a6ab14431408b9ebe5b701a6819787f4f1fe19f6c9f52b0e8c7a50911fdf7fab | C
027 .docs/system_overview/go_toolchain_baseline.md | U | 100644 | 4363 | a53ee3e1293fa5bbf4be0b8b9ebd9c8984d0a0f701e57ffa56a4848f850f79e2 | C
028 .docs/system_overview/hybrid_integration_architecture_adr.md | U | 100644 | 29693 | 79c582c43a8e6544291d4462b9318e676b143511ea48f3601c982653de815cf5 | C
029 .docs/system_overview/observability.md | U | 100644 | 6113 | bed77709023955ecf7467de8967c206478b8f703f14b7e39c999bbb7ac5bcb1d | C
030 .docs/system_overview/remote_alpha_beta_es_privilege_boundary_assessment.md | U | 100644 | 17003 | f9db2c52d3df65a1afa9e0042b13606b70ca399143c8c499a6ec9edef448b51f | C
031 .docs/system_overview/remote_alpha_beta_es_privileged_operation_matrix.md | U | 100644 | 45475 | 59dba67f7014f7f251ca6e48a320fc8cf8a38d2895346a8560e01eba0e078df6 | C
032 .docs/system_overview/remote_alpha_beta_es_runtime_ownership_normalization.md | U | 100644 | 35909 | bc313db17e266cf1d434c21d65446a0b0831b29c3c45477dfea772ba4b47ec89 | C
033 .docs/system_overview/remote_alpha_beta_es_writable_state_ownership.md | U | 100644 | 43842 | 4eb9c76f663622c035437a5e307c5a50ae247cf69254fcb8613f951a79dc5653 | C
034 .docs/system_overview/remote_alpha_external_tls_lifecycle.md | M | 100644 | 26614 | d28bc651f777fc595654b481a1c9a67374244a3ab7d87faaeaa047dab89c8f6e | C
035 .docs/system_overview/remote_alpha_external_tls_one_time_incident_contract.md | U | 100644 | 15561 | e800476cd1e4857203cb25305b8c5fbcfd6824f27c1eb665b0df5b42eb765cb9 | C
036 .docs/system_overview/remote_alpha_external_tls_policy_core_v1.md | M | 100644 | 30284 | 6ee2b5e67e257426e81714e419668415c8e2c665880acd49e7eccfdcd5e77c62 | C
037 .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md | A | 100644 | 83290 | 4560711c86b7c49c9cd14c85996d731efe5036821a5291ec112057715b46739a | G
038 .docs/system_overview/remote_alpha_external_tls_status_observation_v1.md | M | 100644 | 80594 | 8cf875cd84709b33184198054924bc5d8f7e6c32d99dfbcbe512d8596f0297ad | C
039 .docs/system_overview/remote_supported_host_alpha.md | M | 100644 | 302581 | e884e00590986eefc41e08d3009d439716496b707405941db1ae53af431e562a | C
040 .docs/system_overview/runtime_config_ownership.md | U | 100644 | 10935 | 03239484bad91f0e52a00a5e4efa0d1253a6c588bafc703cfae32b52859cbb34 | C
041 .docs/system_overview/runtime_identity_handoff.md | U | 100644 | 14229 | f3f6079d3b65a0eae91a01a350bfc37dc43dbfa08b12d77d560f7a61a507edf5 | C
042 .docs/system_overview/shared_kernel.md | U | 100644 | 13956 | 551b781cef1781909aec8f84d443a770419b9a1b7cfe75396b97977d621cb4da | C
043 .docs/system_overview/supported_linux_host_qualification.md | U | 100644 | 16656 | df37d63df5a353d026b3d12a07d059c6ccf6906146e45fc0a9172d4ef2d452db | C
044 .examples/config/README.md | U | 100644 | 1573 | ac495b59fed5e02f84a8ab768170c5636896177a25cce25066f1ff73b3ac9e71 | C
045 .examples/config/ags.json | U | 100644 | 1140 | c1f79b5fca0240b98dd731734f6ce4908dc1f56932f1eb33e62309bcbe0e7207 | C
046 .examples/config/ags.operator_and_control_plane.json | U | 100644 | 1171 | bd498ec9ef70a0b6fba94279a4d2ef29f2fa07d4c2cde144ee0d893645850ec5 | C
047 .examples/config/ars.json | U | 100644 | 699 | 1fa8eddb637abee4e8add449164a46cc3fa40334700dfddee6ca795135ab0047 | C
048 .examples/config/egs.json | U | 100644 | 928 | a6f1b19c14d6c3fc7440806769fd8d0ad10bdd3c6ca31eb1781c30d2b0a6d098 | C
049 .examples/config/es.configured_literal_policy_demo.json | U | 100644 | 2899 | f6103f38d2d58e0d861f9066b60e7830fbfe0cfffae2d976ac73f173883687b9 | C
050 .examples/config/es.json | U | 100644 | 2591 | 43b3f95663b4ad3ba1e421dd109b03c00b3f1ed3bd8248e6c76c9fc6490020f1 | C
051 .examples/config/es.operator_and_control_plane.json | U | 100644 | 2994 | 737a20aa37bc56124bc1186493b16fe38a18da85bc545f161da56889a5b02516 | C
052 .examples/config/nomad.hcl | U | 100644 | 325 | 10ef969ddc8aa283556fb7c52d90c8d5d4dfc18715b2404612da106b510c9d65 | C
053 .examples/control_plane_normal_shell_runtime/dist/control_plane_normal_shell_runtime.tar.gz | U | 100644 | 3849 | b3cd8da9fe0049d532b4400802e9520eb0e8a0404e18e12a403d35513ae182d4 | C
054 .examples/control_plane_normal_shell_runtime/entrypoint | U | 100755 | 12296 | 006fa18155d802d91d0179c3f95e3bb7f2e0198f61da4ba4b722a50df0897252 | C
055 .examples/control_plane_normal_shell_runtime/package.sh | U | 100755 | 373 | f9171130d5391ce6cd6772b4d5ecdea8e4a6cfc3001c2a8f7c85bfcaa04a4d05 | C
056 .examples/control_plane_static_script/README.md | U | 100644 | 4235 | 9ef5a83ec5785a16d0edd778153c91468de0e7c777b9f11b9acbc239d617fa73 | C
057 .examples/control_plane_static_script/run.sh | U | 100755 | 15213 | 91e203f7f3bb0c34e5ab1db33a430f2441738968b9b6a020064f9c40f6024d83 | C
058 .examples/execution_loop/artifacts/build.log | U | 100644 | 32 | 1a18fc1e53d2ca917ad6fa006b25c93256584920945a8fe8ed204156896d6f3b | C
059 .examples/execution_loop/artifacts/package_static_script_success.sh | U | 100755 | 355 | cd080ae6932ff5c22d97b059c887859e62f5f7656aae0c12e5aebe1b023ce396 | C
060 .examples/execution_loop/artifacts/static-script-success-entrypoint.sh | U | 100755 | 166 | 1e99d498776703b8fbf4247ed216d85bf33bd7c4612f3fdbabb132aedbf6ceb0 | C
061 .examples/execution_loop/artifacts/static-script-success.tar.gz | U | 100644 | 246 | ffba33d10b92dc35d8a8277d3fee31f0bf31f62789f49f4bf5f0ce34294e2425 | C
062 .examples/execution_loop/control_plane_normal_shell_runtime.input.json | U | 100644 | 1781 | c85b93aeba4ea63d822ee05e7d6db5f75e0255805e0813cc915ebac31fccfd14 | C
063 .examples/execution_loop/runtime_identity_vault_success.input.json | U | 100644 | 1730 | d98cab5c16875eb81d3b2887fb74a6cee8f1c2c5de322a0a257438d87422d653 | C
064 .examples/execution_loop/static_script_success.input.json | U | 100644 | 1548 | 0abdad423e332f78277758985bd876ee9000afec8bc36bcacc1054b7843dd1c7 | C
065 .examples/runtime_identity_reference/README.md | U | 100644 | 3788 | 8ecf6b4c7018d0352d637b2f02d6e99b0cb98953b9d14f539b56511ee2d6edbc | C
066 .examples/runtime_identity_reference/dist/runtime_identity_reference.tar.gz | U | 100644 | 2690 | 4d8766d10274d195344092355e40c140aa31d0629602255351e84a7e8887a473 | C
067 .examples/runtime_identity_reference/entrypoint | U | 100755 | 8748 | 983dfcbee6b8c2d9b35a2937499bc6704ad9afd6503ab3cec96b7be294c3a8c0 | C
068 .examples/runtime_identity_reference/helpers/mock_identity_endpoint.py | U | 100755 | 3462 | c2bec12ddf8c3b8474899aea2808d2c3c04fce2aee1ca91ac01d809673726e33 | C
069 .examples/runtime_identity_reference/helpers/mock_vault.py | U | 100755 | 2971 | 483824e83f567562441b2f17f5e016edc1fe7bf4b7c8d382e35003b0b84335b9 | C
070 .examples/runtime_identity_reference/package.sh | U | 100755 | 365 | ff777b5781001e20f7cba056b9c2a7baf4a5c3c2ee2480ed89171fa9e67c9b44 | C
071 .examples/runtime_identity_vault_login/README.md | U | 100644 | 2620 | e8f0491b460a4ec3157ad5518db157fcc67e663eb5e56ce67aac62cf1f97874a | C
072 .examples/runtime_identity_vault_login/entrypoint | U | 100755 | 7505 | f30c7961c5b5f8d7fb4013234d177002190dd822a3e94a66e777f88c2c0e79c0 | C
073 .examples/runtime_identity_vault_login/package.sh | U | 100755 | 426 | 352e43dbaba700891341aa10aafcdc2a443fd860d03edf2309e46889251f18a9 | C
074 .gitignore | U | 100644 | 805 | 32dad9ed3351397ac4e67a62f1f83f1e32839f8cd92cb51d47254749bf6da68f | C
075 .out/Dockerfile | U | 100644 | 1251 | db6ad1f03a2cc1bb7d52eaca5bb1e28a6dbfb8b008311dcfb418c5c7a17a74fe | C
076 .runbooks/execution/v1_runtime_identity_local_validation.md | U | 100644 | 9326 | 50d2fce1ddff3ec87b2a7fc945950107f797e14ad8cb47091f23ebc4c9430b54 | C
077 .runbooks/execution/v1_submit_runtime_identity_reference.md | U | 100644 | 9721 | 0a5c9a759d90bd0456cbd139e87ff5fab68ade264998a2aad432f6eb3d916516 | C
078 .runbooks/execution/v1_submit_runtime_identity_vault_login.md | U | 100644 | 9312 | fa7ba584884011239b9f45f89785d5b755277672897928f3915236c2c7a237ba | C
079 .runbooks/execution/v1_submit_static_script.md | U | 100644 | 9124 | 245a092dddf23220b6a0889471f1d0b7e2a5c8543c457f2b86c58d41e065b8f4 | C
080 .runbooks/system/v1_bringup.md | U | 100644 | 30486 | 9182ea19a65a4c96dd402b289fe163c8dfe4ab7a89613fb7c005e1803dc227b7 | C
081 AGENTS.md | U | 100644 | 7263 | 7a688b7a7dafa2cb9faea64ecc07d61cf70a13a3d2a180225cf101024ab8b2b5 | C
082 PLANS.md | M | 100644 | 288586 | 9e8a989e89d05df09ae0216b0d74ab77c38eb1a49acb44d57580d7056b47c6c6 | G
083 README.md | U | 100644 | 6200 | 307cb763e2e730c46d795fa03ee1665fc0ed12c3e5390499dd84fa24ee07ab96 | C
084 ags/api/server.go | U | 100644 | 4605 | c5986541adec0d3519f22a29dc6078524288185c0f272c6fc9c197d43d350472 | C
085 ags/api/types.go | U | 100644 | 810 | 830f9c3f1e41d1750efc2ecbc6e8f73935339611f85a8773982ce07f70b6c4f6 | C
086 ags/app/app.go | U | 100644 | 2706 | be9613e643e1768e8fe554eb5dd0dd0e5b3da053510755e44c2205788e101421 | C
087 ags/app/app_integration_test.go | U | 100644 | 48657 | 465a4a2038a96f55806cff3923a781b1f69508b3dda129017b31761aff954fdb | C
088 ags/config/config.go | U | 100644 | 6470 | 3f34ef886c5c18868b1e2c865cabcee6ea88a0772cae7a3b047395f0d2f69026 | C
089 ags/publish/service.go | U | 100644 | 16075 | f43ca245e9d14e525674bc1c7cedce618a10e5ea427d1df8a86d3a2eacc0b0f8 | C
090 ags/publish/types.go | U | 100644 | 2507 | 0ca492a31cb2deaed48da91e570fb8a30c2492a5503528640704cb79ec75074e | C
091 ags/publish/workstream_b_guardrails_test.go | U | 100644 | 5596 | b457bbe8aae3d806b9a3cc36be637cbb6abb85dc9110d7e165b96f72adea195b | C
092 ags/sign/signer.go | U | 100644 | 2251 | 9b9d1cd1e60be025ea5d5a603290d3de09f6508edaf00f3e78a0ebc6daf25a6d | C
093 ars/api/server.go | U | 100644 | 33080 | d57b89bc1a4e830827de6d68939bb45ed4e0b3adbdbb4620dfd71e717dc2909f | C
094 ars/api/types.go | U | 100644 | 2589 | e10f0218afa85ccec2d143e0706966834744bc55d532054be2ca6959197094e9 | C
095 ars/app/app.go | U | 100644 | 2982 | aab399d944337e43ea4bf5da26860f29e1b2f62b0a7905fecfe513b7a5769faa | C
096 ars/app/app_integration_test.go | U | 100644 | 61424 | 519a4c077f6544282d9c65eba45b505dfeac821b9896a58f6bc4cfb21908765a | C
097 ars/app/workstream_b_guardrails_test.go | U | 100644 | 4380 | 32c4b4b75d7f3ec7c71613b540dc60823d7e7bf3d9752493c05b6bf452200df9 | C
098 ars/config/config.go | U | 100644 | 3830 | 1b4e49cccffcdd01e66bbf1e39a996e39a0a83a5fee9c8801f6febc6dfd1e3f3 | C
099 ars/index/fileindex.go | U | 100644 | 4841 | c316686404998457399d9ae2abe6471980b9b80c904673934c7370bf0765782e | C
100 ars/index/index.go | U | 100644 | 950 | c9c849629bffe4ab0a7262c6607225b6c5b67dd5de3d9ccf8b6a0109fca1b96f | C
101 ars/store/blobstore.go | U | 100644 | 851 | e4aae56064f4f24c925cc20d5b0083ffa85587a5e33bf021cf8d9acb51119baf | C
102 ars/store/filesystem.go | U | 100644 | 4326 | 4cde2c262ab7c20952e880f93de5e701f844e67c6d2afcaa1448f64e8f673245 | C
103 artifact_hygiene_test.go | U | 100644 | 3211 | 555780752178a52bb40ca0bd9aea18087b78c1f659452ae947eac3c21770f713 | C
104 cgs/api/ids.go | U | 100644 | 273 | 954e7de11496e06176645895407665c05ca029992b2f344317cda81bb2e8a13d | C
105 cgs/api/server.go | U | 100644 | 5147 | 812af3a315dec5ad678a934f96b7e651f3418d75faf43813b6c9125f8024201a | C
106 cgs/api/types.go | U | 100644 | 1428 | 69dbfdc5d1a7587eac176634f7b972d1d374b545fbd5e53468b21c7f0af0f0ee | C
107 cgs/app/app.go | U | 100644 | 2444 | d6e3486a05ab97d13918afb50228b18e72f166aeb7a6235835711ff2f5834a8a | C
108 cgs/app/app_integration_test.go | U | 100644 | 36643 | e285f1f79160dcfdfe02aecb1667003cf4f224f0b920a31da1c352de0ba6da9f | C
109 cgs/config/config.go | U | 100644 | 3134 | fda0accf7a069a2852ccc68edcae58988dfd961db6e091604ada992f44025b0e | C
110 cgs/policy/id.conf | U | 100644 | 467 | e4ad337e529bded0df20299948d71dbedb31baf3598ece1772d08d99b737ee72 | C
111 cgs/policy/idfile.go | U | 100644 | 9349 | 73b6096813aaa07f3612dd6b6623e4a93e0d018f619b2e042024b29de8985ae7 | C
112 cgs/policy/idfile_test.go | U | 100644 | 2997 | 016155b75d597421bf5db378520da7d7fb2f2aeb360dcbd78cbdf717232aad7c | C
113 cmd/ags/main.go | U | 100644 | 1156 | 536a3df542f86310858fec5164caeed107c21f484df6eebc477c5b31f52057f5 | C
114 cmd/ars/main.go | U | 100644 | 1154 | bf3f90d980851afb4554403cb5bcf77da6ee736bf84dcc2d6bf894238eb7f1fe | C
115 cmd/cgs/main.go | U | 100644 | 1158 | ec50165f10049057bd5678ed75aefd49f8367c0d3b4d638b06c4d6f7f1e500b4 | C
116 cmd/egs/main.go | U | 100644 | 1157 | 44c3a1f2eb20d70c979c37046d59b17cd711ab5b774bbe15cae4bf55ef78cab1 | C
117 cmd/es-runtime-support/main.go | U | 100644 | 131 | 57413063787f95134990c2e228100532857ecff8c0fd2b8f4265c39b329a87d0 | C
118 cmd/es-workload-api-mock/main.go | U | 100644 | 4690 | f9c781c7f670b3fb3a61eafa5b5314d45521a527e2290f63955b2e742c3472b0 | C
119 cmd/es/main.go | U | 100644 | 1037 | 8bc2e7b0de3b3511992a7adfa64374d904a81074045de9b8962134f4e634f4f6 | C
120 codex_agent_configs_docs_contract_test.go | U | 100644 | 9481 | dcb838adc950cc2550ac6004f77e7c008a303890c4e014b78221843077ea1110 | C
121 docs_contract_test.go | M | 100644 | 761534 | 375ca77db2402e1aea612dc70935304b61504606006aa7a2944a04f62a2944d8 | G
122 egs/api/server.go | U | 100644 | 3893 | 84b706d6ad8435fb39d036404cd8e5cb605de9f315f88bbc70aa6b2ae3caabd4 | C
123 egs/api/types.go | U | 100644 | 1029 | 10bf99fef32b78eb2a58dcc2b66edf2e1df3d16a7c086b39bb8b78070ab8b106 | C
124 egs/app/app.go | U | 100644 | 3047 | ebeb1240f9daa8e8e48e2c6ee121a016d2a2c9708a0bc04e39f9edb8fad0347e | C
125 egs/app/app_integration_test.go | U | 100644 | 23079 | d1a254098347dbcebed76c41a821f7c026a6d9d6dcf9adcca90223e315d2ade4 | C
126 egs/config/config.go | U | 100644 | 4615 | a2e86a6ba2658740c8ec6ff206b2e1bd69e6f2f731f109ae72a09324dbd00a27 | C
127 egs/model/trustmodel.go | U | 100644 | 4604 | 01018c334f1d7f3c5997fb94a330f6ebef7bbe11c6aa993df8938d3b5c8b0f68 | C
128 egs/sign/signer.go | U | 100644 | 2982 | 3d4227bd353c4630064c4c5640b714126548c7e7b677318dd2f22f863a4ed054 | C
129 es/admission/artifact_prepare_test.go | U | 100644 | 12065 | d31f5464e4fa14d0661e32e4cf87a4c7926238fac31c63af052ddde061b0940a | C
130 es/admission/authorityhandoff.go | U | 100644 | 7324 | 24aaaf08ce89cfc9d23fd11e0779107b9c6573a3d40732fe0a282b75fe6aabc9 | C
131 es/admission/authorityhandoff_test.go | U | 100644 | 6017 | 0a461bf681763be56648c726a974c7703033b416f1d879472f13ddcaac747444 | C
132 es/admission/executionlocator.go | U | 100644 | 1183 | 145b03ddb257f97642b7a9a24e83d32a895f0f165a75e11a0fb945c2294be81f | C
133 es/admission/executionpackage.go | U | 100644 | 10475 | dcba1eeec234598fe85d370674e8f0dcab2d83182628ca9c762b972aab51d68e | C
134 es/admission/executionpackage_test.go | U | 100644 | 6971 | f91549d73257b5a60bba8fd7c3eff76498e3d56d0cf189036df7a18f40882e7b | C
135 es/admission/internal/reliablesubmit/clock.go | U | 100644 | 1161 | ef563f8c440f8afd4cebd3ee760169833c4fec70ebbc943ff367ce354c3dd83e | C
136 es/admission/internal/reliablesubmit/durable_operation.go | U | 100644 | 9248 | 4bd250d5eac0c5a5df1ab31e88fa97b50f03d3dc4182ad89cd301ca1419792e8 | C
137 es/admission/internal/reliablesubmit/durable_operation_test.go | U | 100644 | 12069 | 3dff85fc886aea0197ae365867e72bdb70110a76a8c3e906aca5de70543c1cf7 | C
138 es/admission/internal/reliablesubmit/durable_record.go | U | 100644 | 20672 | dfe72263aefea8b6b30bfbf70c2984a9efb9e039a8586dfcfc3793008ac6a236 | C
139 es/admission/internal/reliablesubmit/durable_record_test.go | U | 100644 | 20221 | 090d4bd938e01ce09687c744b750a4a96d3daefa26a720b27669c9bcd10531ab | C
140 es/admission/internal/reliablesubmit/durable_service.go | U | 100644 | 31415 | 08b8b4223b131a8a6de80e183576acfa27c6fabc50212265fef7c26dd1c9065b | C
141 es/admission/internal/reliablesubmit/durable_service_test.go | U | 100644 | 53049 | c5f015885f789fd05c80ff8c5a3fbcd399102974ba9b86b6d8be1b5c7ce9f912 | C
142 es/admission/internal/reliablesubmit/guardrails_test.go | U | 100644 | 20164 | cfd9488862eeb3213b95bd9a7f8d11e8b6e10eaa358cf42eae44ffdebe6a29a6 | C
143 es/admission/internal/reliablesubmit/model.go | U | 100644 | 42552 | f0c732deaa0d5f9c19f801d83dc572660c38ba5c30a723511bc33c5e0ec7d4ce | C
144 es/admission/internal/reliablesubmit/model_test.go | U | 100644 | 48954 | e12419b023a1a6d67de7f3ca9692b52ca8610869877a3ef675325446e482d2b2 | C
145 es/admission/internal/reliablesubmit/sqlite_migrations.go | U | 100644 | 17189 | ec459964f8ca4f098ca07436d7e1a005daee45cc99079f193a55c2b2c2022b34 | C
146 es/admission/internal/reliablesubmit/sqlite_physical_test.go | M | 100644 | 14218 | 4d97b16fcb166fb3200b1229eb0eaffe3928ca2e6ec9f4a7b8c2c0bbf5242621 | C
147 es/admission/internal/reliablesubmit/sqlite_store.go | U | 100644 | 32228 | acf5702f91d07dec0298aeeaa6c893828b8052b1939d08c5878708b8f74fae45 | C
148 es/admission/internal/reliablesubmit/sqlite_store_test.go | U | 100644 | 33204 | 6b82c41a7d1a9f9b95d736470e101f6eb4df74fb5f2a3a7efedbd773633aa92f | C
149 es/admission/internal/reliablesubmit/store.go | U | 100644 | 2908 | 45c722179ade25f2daccc25975d273776f0d4c4cdcd70acd5977f474477c4e95 | C
150 es/admission/internal/reliablesubmit/store_conformance_test.go | U | 100644 | 18592 | fba8fc590e8861a94d62b82f728567458c1c1fc3473a992eff3d02cfe4c86a09 | C
151 es/admission/lifecycle.go | U | 100644 | 16046 | 5a7537ceb2e504335d99e7aea508a0a78d0fc2d5c58f914867ef6b823c2a751c | C
152 es/admission/lifecycle_nomad_test.go | U | 100644 | 9886 | 33d29bbfc1633e9b649714814dff9420f7c744feb1672d0158ccfc651c996c90 | C
153 es/admission/lifecycle_test.go | U | 100644 | 7734 | 5cc611aec795262b45e80b8054573872af0430a3d1aae624883d1d9969e3fb3f | C
154 es/admission/lifecyclepolicy.go | U | 100644 | 770 | a9e16d1217ba9c599ef8accc4f589dd173e6fbcdb6c2ec869d5fcaf1582707d3 | C
155 es/admission/lifecyclepolicy_test.go | U | 100644 | 1183 | cef2ad0d16c64e0a648eff9766f7569ec83f398c0adcd1b7424a23a2a730423c | C
156 es/admission/mounts.go | U | 100644 | 12585 | b2a50ace001aea8617721df258f62354e817fc87be9ba560df1671895b4c41c9 | C
157 es/admission/mounts_test.go | U | 100644 | 4413 | 4c77169ac647d1f7b6756c9cab5db3d3a3ab9688eab149a804c99ee7d201a829 | C
158 es/admission/outcomeevidence.go | U | 100644 | 2640 | 51eaed805113a7de9f6d31dbc6a3867b7e310b375b99cc6577baa7705e1db999 | C
159 es/admission/ownership.go | U | 100644 | 3248 | dae5f61356d4f27b956749cb925d8dbdb8206dab11d79a75c8022d48941dfc2c | C
160 es/admission/ownership_test.go | U | 100644 | 1768 | 69562ce60eea423b9434d368529f8c231d00b4cb251c1942d5d0d3d51608a4db | C
161 es/admission/permission_fixture_test.go | U | 100644 | 1722 | aa757c1dbcef31f5e2d604bab8e0b6b6e904f9c9b5bbb98b705c4d1a2affe237 | C
162 es/admission/policy.go | U | 100644 | 11271 | 08de3fea8dfdc2db4eac19ea99524f0c306fabf44f48e62341278f2b2ac5fc4f | C
163 es/admission/policy_admission_test.go | U | 100644 | 17051 | 322ce77a557df7d9d3da8f987d109d881a4af268d826320cd89bf1da00dc35dd | C
164 es/admission/policy_payload.go | U | 100644 | 5328 | 28607f4e0a2381e2460ea7dcd9e5a1700204275995ac7751124df447c92f78e8 | C
165 es/admission/policy_test.go | U | 100644 | 15396 | a156228d854e878e7eb64cdd69ec586924274aaef4ea0aed24a6e467dc27992b | C
166 es/admission/producercontract.go | U | 100644 | 4739 | 8e251af5bcf2795d35b98b0413e42d499dbfa98d7da371e209bb5e559d65c6f3 | C
167 es/admission/producercontract_test.go | U | 100644 | 18951 | ddfe8a3ff50009e4e1f2e9b33d1493b2a9e459757124b0eeec6b58b1c3916970 | C
168 es/admission/reliable_submit_contract.go | U | 100644 | 5225 | 4804389e83ba7dd1c3571270e2c9a10eab0a8a4ccbcd7dea0e793d1cfba10dcf | C
169 es/admission/reliable_submit_contract_test.go | U | 100644 | 23979 | 111f831ff8e69bf7f0072d836e8e27b8f9bfc801d8946ffa52a479da1ef96efb | C
170 es/admission/reliable_submit_guardrails_test.go | U | 100644 | 18683 | e4568120e4862d50fa3b4e81d2e2291d500234034c6b710df3c59ee88c71fd6a | C
171 es/admission/reliable_submit_identity.go | U | 100644 | 1966 | 6475e7532eeed6402740ac7b8e80ab050d710125b3efd7ff1fe20beb27f664d4 | C
172 es/admission/reliable_submit_identity_test.go | U | 100644 | 6401 | 38ff8f04cd6a9bda2e2af62531c03c3c02b475647cf4ec3031ffe3b482e3ddbc | C
173 es/admission/reliable_submit_outcome.go | U | 100644 | 8237 | 9dacd88fd6da58e633447339dd6ff2a7ad324d528c77ab902eae07e58c1dc8b6 | C
174 es/admission/reliable_submit_outcome_test.go | U | 100644 | 8547 | a1fc999cb010211e6484e74204c94352156a1a552a48e9f2f49431ad3d272b50 | C
175 es/admission/results.go | U | 100644 | 11686 | 393e54ae678901a5f4cdc64fe22671f648c4450cef3535f139ebcc00c328c428 | C
176 es/admission/results_test.go | U | 100644 | 19378 | 8a46b5c87a99d71b01cb3782eea5995dfce50ae8d9c8b1620d9133751149ed63 | C
177 es/admission/runtimeidentity.go | U | 100644 | 2369 | 400b89ca8bfc549ad26227d32dd473dd90046fc8b56e3cd495bf9ee70e8ce007 | C
178 es/admission/runtimeidentity_test.go | U | 100644 | 2452 | e33b6c44f4f07ee8aa8e9fe357e81c8d1d691e1ee9f5c26e2775fc50e672e0b7 | C
179 es/admission/runtimeprofile.go | U | 100644 | 3122 | 8163c6b2d265efdfa4521dd1101369eaec7902d0b6050b675dbe8b91d0a05afa | C
180 es/admission/runtimeprofile_test.go | U | 100644 | 7817 | 227a9b7a9b06e8d3c0dd04cb6e022f6b89c50bde18308653ec85e2e2c969a1e5 | C
181 es/admission/service.go | U | 100644 | 31002 | 9670457887b377d6014e6ea58cd30eed7ca2d5d9a0ae02edf3b4b8bd188072b2 | C
182 es/admission/service_direct_test.go | M | 100644 | 11500 | 06bf1b071ac97cd4f9c1ef7d30edbafe4daa81f7bfb6150bac5688b771eb6f68 | C
183 es/admission/submit.go | U | 100644 | 13107 | e003a0fd74782960bba5dfe684db5633021518e0a74b581f3db2d74a243c8a9d | C
184 es/admission/submit_test.go | U | 100644 | 12402 | 8619d435a3396a0759590e16cbb21575f88ba56fdf3cdad5cf03fbd8dce57b53 | C
185 es/admission/types.go | U | 100644 | 10458 | ada6333e95ead09646382f962659871c58ee368fa25747ef5453951f69771412 | C
186 es/admission/workstream_a_guardrails_test.go | U | 100644 | 18460 | c97454aeea309c6d6a48a142164b96ca34f4febb072a9e19b723055e8e8d7369 | C
187 es/admission/workstream_b_guardrails_test.go | U | 100644 | 5277 | 1301bf3516faa12b82be63689fa6e235d3aae3430565def19e2f19c1598fffed | C
188 es/admission/workstream_c_guardrails_test.go | U | 100644 | 53037 | 8bdb94aa292ebd55ec2b023b6f081914963fe55d4cafa9d748637cb7c6808349 | C
189 es/admission/writablestate_preflight.go | U | 100644 | 7452 | 46b19ec62b7ad266fd94595288a2039e8a8437e48953fd352f2a48677bd65027 | C
190 es/admission/writablestate_readiness_test.go | U | 100644 | 37502 | 64dc90c67435780c362071bb3b26d485dee4b57becea55e9f46148d7aeb12738 | C
191 es/api/server.go | U | 100644 | 11040 | 76ff5b591ed09d0c81d56fa27912cdcfcdc820721e0e43d0a3841e19d2eae748 | C
192 es/api/server_test.go | U | 100644 | 67771 | 1279bb80d39d4f0a2eba50c68a5e37e6ff9851d87d8f050fdcfcd6b0838d1a93 | C
193 es/api/types.go | U | 100644 | 680 | c177ba4137c0a7deeaec58054ffd9596264e7c294b2015363db2db12baa4c530 | C
194 es/app/app.go | U | 100644 | 2769 | 05f6447c80ae442bf8d1f25207f329878d49e70612abc80524e023d214817562 | C
195 es/app/app_integration_test.go | U | 100644 | 41950 | 4e0d00b09b1cb16f6717ac48540862d71d97ab238e2b919df09e9ba81c1d22e7 | C
196 es/app/control_plane_integration_path_test.go | U | 100644 | 11655 | f89e88f2a7cec7752e4e658ad9b5b83a8d9120fc31da93606637961f31575f9f | C
197 es/app/execution_loop_integration_test.go | U | 100644 | 10583 | 0b450b01a1d8af1c5413e781576f6141630ce87dc86b00c506c17a8229e9a51f | C
198 es/app/lifecycle_integration_test.go | U | 100644 | 15494 | c76f3b80c7f3bb5d15dacc35245e60607c97673bdd9503cdefad47bd98137ce7 | C
199 es/app/mock_vault_test.go | U | 100644 | 8476 | 38b47ad8d9664b8e8791ee775277237d69891c5de230825f160791331a62f565 | C
200 es/app/observability_integration_test.go | U | 100644 | 5956 | d1e264658c4678b2a6e6338d9b6a2884c130417d09545ddd0bdc0f923b93b91d | C
201 es/app/operator_scripts_integration_test.go | U | 100644 | 153629 | b6253aca22dc4acc48c0d87e07ad6bde786ba2949881c416e6be86f0d83b15ea | C
202 es/app/proof_codex_shim_test.go | U | 100644 | 9868 | 30be385f1a307c4b061c46ab97efa9e9662ea0d1d037a413cfcb929a0736c2b4 | C
203 es/app/result_integration_test.go | U | 100644 | 4903 | 04e4287c1131fefa00022f4941373b40502f3e59c4d9597adbaf6633a57774af | C
204 es/app/runtime_identity_vault_flow_test.go | U | 100644 | 4248 | 15d537c681568f707ee51ec50037d5994932509a33a9f4991eb37a2d3ca149c4 | C
205 es/app/staging_cleanup_integration_test.go | U | 100644 | 6768 | a15eb4a46336c4fa7c3de2dba8798600bc1574f1f261ecdc6eba5a477822437a | C
206 es/app/submit_integration_test.go | M | 100644 | 105161 | 8a0d3b6dda8fd57497e607c54b97331d3799e9b2cba445f504e4d22061404720 | C
207 es/app/supported_local_proof_cleanup_test.go | U | 100644 | 3806 | 150325b2f2ac0fba51422a7369ec6adf53b8f3499077fd1129b35b3fb3786782 | C
208 es/app/supported_local_proof_validation_test.go | U | 100644 | 24840 | 50e97aff104f84126169e7d92b64d0ab6f0f9352ca30f8fe9813b6da1ea48d43 | C
209 es/config/config.go | U | 100644 | 22152 | d30886efd95dca7754d7c598cb6420a48315abe8ad390379c09edc23ca9d5545 | C
210 es/config/config_test.go | U | 100644 | 30365 | dd1cb4e3edce908a445da7ed71aad8671149839ba701a363de24ca62b691aed4 | C
211 es/externaltls/cmd/es-external-tls-observer/main.go | U | 100644 | 204 | cec0d633eb97382e178c4a47838104288c1651ecc57656ab5a13c5fbcc7d3782 | C
212 es/externaltls/cmd/es-external-tls-status-package/main.go | A | 100644 | 176 | f125fc8c860179e58b65afea80d7fe32f06f39704b59e62fde34d2cd2c7b0484 | C
213 es/externaltls/cmd/es-external-tls-status/main.go | U | 100644 | 190 | d30293dde1e006dfe63ddc806c7968320ae7ca794d03a3eaed79c99bd4e20572 | C
214 es/externaltls/internal/policycore/callable_boundary_external_test.go | U | 100644 | 35601 | 6cd7e372a7e2f5fc82ad27d7e31851bfd74a96a2b6223549f1fc48c494b579c2 | C
215 es/externaltls/internal/policycore/certificates.go | U | 100644 | 27936 | 95e1cc413623d596fc6ddd8ff82a8b6eb824e1c9f75fae093787f99717e32fe7 | C
216 es/externaltls/internal/policycore/construction.go | U | 100644 | 10309 | 58c953f69df76bc36c14195cbba33ea0b5b1fc8210b5be4fa302c8c921cc1e16 | C
217 es/externaltls/internal/policycore/evaluate.go | U | 100644 | 13482 | 4b204e169d49f355c14db7edc8ef5701d74b377e36e225df23278ff4218f2032 | C
218 es/externaltls/internal/policycore/foreground_signer_profile_v1.json | U | 100644 | 1514 | c326f41dfd159e14f81bf9c7e9636b5bad4f01c5025a426c60879011d549ee5a | C
219 es/externaltls/internal/policycore/guardrails_test.go | U | 100644 | 84227 | 9540b3eb3101b11c1d9659747d62f40cb63068bff49d07ba6c6e88732e59aa0f | C
220 es/externaltls/internal/policycore/load.go | U | 100644 | 28138 | 0699680b97daf586f07e32aa5c732165568469b9f50f3e5cb528d37567403dd2 | C
221 es/externaltls/internal/policycore/loader_determinism_test.go | U | 100644 | 15130 | d7d152249011ca0b2f551e9a0f273ba8b68827bc701e898934d2edf32b536b8c | C
222 es/externaltls/internal/policycore/policycore_test.go | U | 100644 | 119475 | 6cf539f5e3e6a81c13408f40b51aa3e5ede0ab2893db650762b6f09657d1b8f1 | C
223 es/externaltls/internal/policycore/remote_alpha_policy_v1.json | U | 100644 | 5958 | eac545e3f9d9feab5fd54ac7fabaacc11bd54f94a2298a27c81b0fde282d1d30 | C
224 es/externaltls/internal/policycore/status.go | U | 100644 | 16360 | 6c08e3c75a84e8d70d22dd746f386dbfabfcee1e968988782fc4382934ddb9e9 | C
225 es/externaltls/internal/policycore/status_test.go | U | 100644 | 22217 | 02725a7c2458d580bfec80f7ac4dbe1f01006196215ee4050b3302862f2ec50a | C
226 es/externaltls/internal/policycore/types.go | U | 100644 | 26129 | ada0a24b1b326a6c81d1cba1f495a8446390593e11067b048c77dfdffc7ce504 | C
227 es/externaltls/internal/statusobservation/binding.go | U | 100644 | 31142 | b0acc294bffa9f099b506ec45ed98886822077728b0afedf25aba0ea9942031a | C
228 es/externaltls/internal/statusobservation/binding_test.go | U | 100644 | 22071 | 66a763507acb18987c804c5b09960d43717d3c77feb5ed3dc88ff8dc3fc45c72 | C
229 es/externaltls/internal/statusobservation/mac.go | U | 100644 | 17924 | 59b551fa27e6becb3e51a7c2c003d209c3b08404fb282ccf24b9ce1a8f087d2c | C
230 es/externaltls/internal/statusobservation/mac_test.go | U | 100644 | 10528 | cecdeb07be51513d5a340827cfe7b77fee6041c404214bcf984c4675820bbdfa | C
231 es/externaltls/internal/statusobservation/mapping.go | U | 100644 | 26309 | e61e64d36bda1e1ac156f773ec36bb3a4ecceac33989a3ee89787e92c16a005d | C
232 es/externaltls/internal/statusobservation/mapping_test.go | U | 100644 | 25120 | 00567f994e614029c1cd46e71883a42eec62eaad8575e513ad159f255f9827e4 | C
233 es/externaltls/internal/statusobservation/protocol/v1.go | U | 100644 | 16273 | 56b439dd3afb1501d15b5c965819875da7928ca61375817586f64b90e0695f33 | C
234 es/externaltls/internal/statusobservation/protocol/v1_test.go | U | 100644 | 9235 | 18456e08b9ca9cecd2120cbb3716295bcd4cca757fc1aa1b0f3309323c774c95 | C
235 es/externaltls/internal/statusobservation/remoteobserver/manifest.go | U | 100644 | 6470 | 979edf471c0f594448f0e5d5aacef00a3ffa1b5b17aa9598bbe2420a496f53fc | C
236 es/externaltls/internal/statusobservation/remoteobserver/manifest_test.go | U | 100644 | 2229 | f284e28910879d077e31592c81c3f2a7293c1a6ba4dc2ee65caa6c5b5d65d69c | C
237 es/externaltls/internal/statusobservation/remoteobserver/observe.go | U | 100644 | 131220 | f09c714902f49d26d77eaaf81a23ecece42ca450c9887bdc6859412cf0ba138c | C
238 es/externaltls/internal/statusobservation/remoteobserver/observe_test.go | M | 100644 | 268924 | cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec | C
239 es/externaltls/internal/statusobservation/run.go | U | 100644 | 11945 | f780c994df75e307da054e72616728d3bacd74b850067c7971b1b414b5f59782 | C
240 es/externaltls/internal/statusobservation/run_test.go | U | 100644 | 14345 | c6e95cfc7401aeceb1540efe5e26a6134912475d577b4ff3e53c810707ff957d | C
241 es/externaltls/internal/statuspackage/package.go | A | 100644 | 315262 | 168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6 | C
242 es/externaltls/internal/statuspackage/package_test.go | A | 100644 | 463762 | 046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f | C
243 es/externaltls/internal/statuspackage/schema.go | A | 100644 | 27681 | 9375bb13026cc91005e58a71ff8ef211a84490c487af71e4246ac2636860980a | C
244 es/internal/ownershipnorm/marker.go | U | 100644 | 5797 | 84f2e7b819a2b0bb7eaa9058142cfcf203dbb9110de53628a00ea20c3382d10c | C
245 es/internal/ownershipnorm/marker_test.go | U | 100644 | 3010 | 5142b0d6c807e3865269a7c9bf4ed72307961e1d7656ce27c534d0e3d94f9d42 | C
246 es/runtimehelper/common.go | U | 100644 | 2888 | 9941ad1f63d1b4457e873829323553bad4949ca370abc9e38904b022f85699d2 | C
247 es/runtimehelper/helper.go | U | 100644 | 9199 | f78b0f29796ac291fcefb791b5fb48360e01feb7dd688e91b8025adbaba427be | C
248 es/runtimehelper/helper_test.go | M | 100644 | 5017 | 715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0 | C
249 es/runtimehelper/main.go | U | 100644 | 727 | 32650c244645a9f0d2f083fe64aef1c9481316729f67d208ec7b8125ba4cbc49 | C
250 es/runtimehelper/privilege_linux.go | U | 100644 | 5604 | e7c05914ec8734e71d23147c99ed7a3c330110130f470a252c3835806e9f8c60 | C
251 es/runtimehelper/privilege_stub.go | U | 100644 | 529 | 4991dc6a7237d7a169f7fad0d3ecfc42cf44320aaaa8556af99a4639d4aa7f16 | C
252 es/runtimehelper/supervisor.go | U | 100644 | 26835 | 02b43bea4cbc13ccf451ab5fce9289c86064eef9a0b71c24105c5e7b34d5e556 | C
253 es/runtimehelper/supervisor_additional_test.go | U | 100644 | 5568 | 2f87fe6637e426c082d8ea47b74ae844657c58127469d40b064cef1084a1e84f | C
254 es/runtimehelper/supervisor_normalization_test.go | U | 100644 | 11100 | 6c3e2eaeb07145105fab72023c6a8c69830381a7087c6cd56d25998e9c77ad73 | C
255 es/runtimehelper/supervisor_test.go | M | 100644 | 5293 | 842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226 | C
256 es/runtimeprofiles/control_plane_normal_shell/Dockerfile | U | 100644 | 1331 | 81b72422192e8cc5e1fde097bb97a34de4f0819f44b4d5aa4d9a544d73062916 | C
257 es/runtimeprofiles/control_plane_normal_shell/proof-codex-shim.py | U | 100644 | 10556 | 8aba3219fa82b382e21abfdd4d32d9a76f452161f891c9081bdde2b1209b82e6 | C
258 go.mod | U | 100644 | 967 | af622e2528c074e8d8d46ab5b18e8f57ebb7fad39a1f4349fe94d3c83783a1e3 | C
259 go.sum | U | 100644 | 6809 | 5c2e536bc93d89ce2a874a5203207b2bee6a859a90471c7abfbe4850fb00970e | C
260 internal/contracts/evidence/v1/admission_authorization_claims.go | U | 100644 | 1514 | 39d0d99d6363dd60e7af03151aa80dad6d592627b3acd5396e913908b254aa99 | C
261 internal/contracts/evidence/v1/admission_claims.go | U | 100644 | 728 | cdae2550e7e89ff0191e47e975a82cd3e0d70b22a07221da914224fdd7b6011 | C
262 internal/contracts/evidence/v1/claims.go | U | 100644 | 2294 | ac3d8517791b12fd77dc869609dd8626f9e79544e0dc3ce1a42c5d0c94b37412 | C
263 internal/contracts/evidence/v1/execution_claims.go | U | 100644 | 1884 | 07adcedfaf181cd1131649895ae073a82127aaaf9a7fdfce776420089ea765d0 | C
264 internal/contracts/evidence/v1/package_claims.go | U | 100644 | 5928 | da2ac4b3d76a6b45190055184fde9ea1975890fbc33b84319bb608bd020e246c | C
265 internal/contracts/evidence/v1/record.go | U | 100644 | 2503 | f33c527e984ffdaa8172f2ff771a8521979092e5767f4ee98d9ea26b160e4232 | C
266 internal/contracts/evidence/v1/record_test.go | U | 100644 | 8177 | 233696c973351769b3393b0d8a4d385bf5f142915c5113b4db02c624d35efd7e | C
267 internal/contracts/runtimeconfig/v1/workload_zone_vault.go | U | 100644 | 3752 | bbbdd5eaa37f5112a30eeb2ab327d0fb8db62ab0817a9d246d36419183689394 | C
268 internal/contracts/runtimeconfig/v1/workload_zone_vault_test.go | U | 100644 | 5692 | da5d9d67725c059c85ad86e484deb729c85bcd2c46cd4db7fbe374e2f17faf4f | C
269 internal/externaltlsruntimewitness/v1.go | U | 100644 | 18377 | 680955c62a1c2a713995bf24e10c9ba6eb2d5e9d86841fdc3db745dbd6c17367 | C
270 internal/externaltlsruntimewitness/v1_test.go | U | 100644 | 9449 | c7bf4b8e362a1ce55e33cf8cb38e28f558f433e659f64032d050e2ab74b1af73 | C
271 internal/httpx/httpx.go | U | 100644 | 1484 | 9234d1f787b2541fc66213c4b7efb6e1f67d9ed8bdbf43d1dd234bc47ea0e243 | C
272 internal/httpx/httpx_test.go | U | 100644 | 3072 | 88ece815ec60db8058e594c9781f395fd7eeca61cf7bb6ce2f4b4e39d291a242 | C
273 internal/observability/observability.go | U | 100644 | 7061 | a7e1f94aa5e753270bb6b52008790c77f6d13edb2ef26101ca3f10053271d34e | C
274 internal/observability/observability_test.go | U | 100644 | 8080 | 8ffcf12db5261a0659dbb9c72a1f4cb891e9fe4ae80088eeedf06e59a2ebbe03 | C
275 internal/testsupport/controlroot.go | A | 100644 | 8695 | 3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3 | C
276 internal/testsupport/controlroot_test.go | A | 100644 | 1359 | de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f | C
277 internal/testsupport/process.go | A | 100644 | 17833 | ab4bc338ae5b9f46c06ad677a86da8559eb42918e0d03a090dce970f507f6c62 | C
278 internal/testsupport/process_test.go | A | 100644 | 10658 | 366b66afdb47d624e0a425e054f052b7389d36bb808d5f61f4cd9e0d8b073146 | C
279 remote_alpha_check_es_writable_state_readiness_test.go | U | 100644 | 44504 | 5eb00c9e5e4c1b37f29a4fe34a764f91ada9e50814ac2795a9e34bc58ae796f3 | C
280 remote_alpha_deploy_es_binaries_test.go | U | 100644 | 17764 | 1f121fb1fe76d09c2db9f97f1c7626f69e9bb1bbce7322c4c0a2aef49069f594 | C
281 remote_alpha_es_service_tls_renew_test.go | U | 100644 | 33123 | c2db2b0a6d3ad3bb682fb26981d4595ac2c29db2708fdc80950fc129721f0aba | C
282 remote_alpha_es_service_user_rollback_rehearsal_test.go | U | 100644 | 5637 | 4b1a92f2855f45d6170084f865852028ef2315799739161088a621426123f188 | C
283 remote_alpha_harden_ags_service_test.go | U | 100644 | 16249 | 846081d0ed98ce852b2b9bee34bd2b92dfd83d14262c58727c246f183cdac763 | C
284 remote_alpha_harden_ars_service_test.go | U | 100644 | 21020 | 4c40689f03609ae73cc56d04fbfdfe82e4f337b30b4eba18acf726186d56ddb4 | C
285 remote_alpha_harden_egs_service_test.go | U | 100644 | 36816 | fe8fc44106bd1f858eb967b0886b326d8500481ec1e752e50b09f765ada5ef1b | C
286 remote_alpha_migrate_es_service_user_test.go | M | 100644 | 39701 | 8b9877547e6c3ff5c9e2431a2a876c87bcf9adda762532ada6df83d71d4ba86e | C
287 remote_alpha_migrate_vault_service_user_test.go | U | 100644 | 25114 | 00bf23a0f4ca28e1205c1953045a64b0fddedb3b776d127172756d1b22b9d851 | C
288 remote_alpha_normal_shell_runtime_image_check_test.go | M | 100644 | 22202 | 7276239128ac6945c9daef051a0b39770ff925d121bf3c111ae7f1bf7fb03081 | C
289 remote_alpha_operator_healthcheck_tls_renew_test.go | U | 100644 | 13898 | 83375519338313e8ddc9e2982275517bda9c9ff51e407e6609903e5a52fdb89d | C
290 remote_alpha_operator_healthcheck_tls_status_noninteractive_test.go | U | 100644 | 76969 | 755ac76f0e89ad7657dd20eab31bc3bb1aa6381067cd510c46467d79106ef5eb | C
291 remote_alpha_operator_test.go | M | 100644 | 333580 | f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578 | C
292 remote_alpha_plan_old_root_cleanup_test.go | U | 100644 | 8026 | 442f8823339e3bc6f03e51b4c2c3446aa65a94fe9af8b29b4b3f988f38994401 | C
293 remote_alpha_prepare_es_config_tls_test.go | U | 100644 | 67547 | c9c233f0d52fd9ac1b3a8aa3aaf789276831f77c2f1ee6687bbf7a77f8978099 | C
294 remote_alpha_prepare_es_writable_state_ownership_test.go | U | 100644 | 97819 | 2bab353ff07b99167fcc5e7c8b523b102ba562752992337de6de24af5b361a85 | C
295 remote_alpha_prepare_external_tls_status_test.go | A | 100644 | 249415 | 71b99721dd3bca0a956fe66aab16cca23cf280e579f89b25e5fd0110a37c7446 | C
296 remote_alpha_reset_disposable_vault_test.go | U | 100644 | 4277 | ddddf084e6afa7e080f8c3027c3c10c6a64deba1d5c7dee1f6da12a7a76534dc | C
297 remote_alpha_runtime_identity_helper_summary_test.go | U | 100644 | 4765 | 2fee24608367c964235d19b18e947ee6e41d3fc5121866647e176217d94173fb | C
298 remote_alpha_runtime_security_boundary_check_test.go | M | 100644 | 35994 | 1d189733beb8a60cd2109f19fc0b3c40d60510b2cdb183d74689795970d1c3ff | C
299 remote_alpha_stage_es_binaries_test.go | U | 100644 | 20751 | cb27c8909cd71503ed0065a9c352cb11ba3ddcaea82c181a051bdef606fd8f72 | C
300 remote_alpha_stage_es_config_tls_prep_test.go | U | 100644 | 25964 | 919fb17416391da8567a9a59e67a71d99bbe4490b792922e10d067ed462b7b9e | C
301 remote_alpha_stage_es_service_user_migration_test.go | U | 100644 | 36200 | dabf65352ac8267a16518090d1ddcd63f1b5af510a5cf55f22f297fa925bee13 | C
302 remote_alpha_stage_es_writable_state_readiness_check_test.go | U | 100644 | 37543 | 101b43f2152421eac6a3ab801ddc21473eec97d98c3b95b1d86b2503c0652408 | C
303 remote_alpha_vault_workload_auth_bootstrap_test.go | U | 100644 | 56310 | 8fde34ab7e2c58a7cf4f5c608db2a267acedbcf04e911f0a05877d667ac5e250 | C
304 remote_alpha_vault_workload_auth_check_test.go | M | 100644 | 49347 | 2f8bea285ab0ca4e4015dd2f1cdd4e681980e8e95822c89fed3872ccf9b3193c | C
305 scripts/01_bringup.sh | U | 100755 | 8499 | 88a95862cec1cbf4fef51169f1778a3797ab17f0ec225dc3e38c6c36d411a24c | C
306 scripts/02_start_ars.sh | U | 100755 | 1312 | 66fb460f50af070137ef5220e48976bec12014319bdb30d1369179767b06fd01 | C
307 scripts/03_start_egs.sh | U | 100755 | 1312 | ebefcb93b070975a03f616ecceaa072b3098c061e04b88ce21014abe972a525d | C
308 scripts/04_start_ags.sh | U | 100755 | 1312 | b30d06ed95782a000160b7b787ff1149b4fef140043e5d2e68e5d703889d72b7 | C
309 scripts/05_start_es.sh | U | 100755 | 1343 | 036db7159a3b29647d7a0c4d5b02cb36f0a12ff5798269ec501fccfded379dce | C
310 scripts/06_start_nomad.sh | U | 100755 | 1113 | 8ac7d93200c9489f664fae462db7d249ea2c6b9703e807dba780deb116ce463d | C
311 scripts/10_health_check.sh | U | 100755 | 3017 | 25d5dea68856063210f09216b48da83105d281a1ada9b9a352fccb4f905c1c4a | C
312 scripts/20_publish.sh | U | 100755 | 2180 | 41777c4ac2ae944d0ce4d41512d8f936dfae455a5f038da9ad10c348f8af34a0 | C
313 scripts/30_prepare.sh | U | 100755 | 2003 | e557b32afb6f213a2788727cb19b85ff4b89cc6d078e5b75b896474d7d1ea311 | C
314 scripts/40_submit.sh | U | 100755 | 2230 | 9f5225e1e2e3f86b398f4ae358dd03665bd966f4e82672c67b24e859359b36c7 | C
315 scripts/50_lifecycle.sh | U | 100755 | 5837 | 07477a7850182f578878901b9f479fc7ba04c4730d926cabc4799c58e417dd5d | C
316 scripts/60_execute_loop.sh | U | 100755 | 25694 | 95c1bc8ad576021dc4299ddd94624d394f8e3785b2d56c68cc6153b37b5b8b3f | C
317 scripts/70_diagnostics.sh | U | 100755 | 17577 | 7cfdd6d79269b035d3f6a11bb7592fff08cff56d7df7843918dc21ede6b72a93 | C
318 scripts/70_linux_setup.sh | U | 100755 | 22308 | f4ccf39c8ca18b334f3b27cdd039188896a8e47e3103ca67b82c9488a76b813e | C
319 scripts/71_diagnostics_summary.sh | U | 100755 | 3232 | d156d2f81f5c345fcec96680f2ac406854cdde0efc95044a26943e159cc8c96e | C
320 scripts/72_supported_local_setup.sh | U | 100755 | 49907 | 1162bce170f1b9a7c2ceba53f350a7500c25ef4400096066f6bad53e40beacaa | C
321 scripts/73_supported_local_proof.sh | U | 100755 | 28731 | c13b98be12a6354b3de085b1c3a9e45adec3d98944fec840f0ab20d07e79dae1 | C
322 scripts/build_control_plane_normal_shell_image.sh | U | 100755 | 1151 | 1c2c7fc9711ea578bce0a07277d9fccdda1dbeb46e2bc890178605afbd2c6872 | C
323 scripts/canonicalize_json.py | U | 100755 | 1775 | a21086359df20c08f08a6780a01142852ebb25f1114b2dfd044c1ff1aee5b0d5 | C
324 scripts/generate_control_plane_dockerfile.sh | U | 100755 | 1416 | 49759a65664022950af0821ee8ca822b773cb8ffbeecc7bce7d96de2a7de169f | C
325 scripts/internal/bringup.sh | U | 100755 | 23625 | 676ca7e68b2379e1c7f027017ee323c3133f6c47f7eadc87e657349d2baed14a | C
326 scripts/internal/control_plane.sh | U | 100644 | 11309 | 060d4ee4b82eb8b7b0c0b83e8a4faf4aa8219d5b7e16638554c3428df02d3ae8 | C
327 scripts/internal/operator_failures.sh | U | 100644 | 14389 | e3d3a01a6fead7ddc6016b7959ec9af9b301bbe9ab5664a43598488e526c3942 | C
328 scripts/internal/remote_alpha_check_es_writable_state_readiness.sh | U | 100644 | 58279 | 7b01e23440167f2169b4056841570e410a46e93e1af806440f58c1667ff1c095 | C
329 scripts/internal/remote_alpha_deploy_es_binaries.sh | U | 100644 | 81779 | 84f555fbca73d4ab86333263658c5242269db5e51b5d8421d34d7b3780f0b1d9 | C
330 scripts/internal/remote_alpha_es_service_tls_renew.sh | U | 100755 | 54660 | 45ff17374b5648e89987fd744fe1d73024fef922346bc499450e4c1db2ca4432 | C
331 scripts/internal/remote_alpha_es_service_user_rollback_rehearsal.sh | U | 100755 | 30475 | 39e6f20322ddb54b18f8d924eeeb49a0c9c59f63e548a1c04aabf2f041b2cc0d | C
332 scripts/internal/remote_alpha_harden_ags_service.sh | U | 100755 | 36997 | 2ebb6e4fa05d85a92bc6d8af0e3898a2e45d464be4843964edf8dbc59f3cff33 | C
333 scripts/internal/remote_alpha_harden_ars_service.sh | U | 100755 | 53233 | e721c71bbe6612cda8f12d6d72446dbb2115ea0c2134c798f2a07a1d75281ac2 | C
334 scripts/internal/remote_alpha_harden_egs_service.sh | U | 100755 | 65420 | e9e1223aa027f6d44c981c3d4c2af3ad3d52a3c86e4d970a6261b310d969ce14 | C
335 scripts/internal/remote_alpha_migrate_es_service_user.sh | U | 100644 | 130289 | 15ca18aba3f71a42de4dd8748e1e5d6cd16dab247c771c1bbee595f59b770bfa | C
336 scripts/internal/remote_alpha_migrate_vault_service_user.sh | U | 100755 | 66885 | 8df483f4abd309929b9204f646cb77c64451ebf93611c600bb7a5e7e1aee7c70 | C
337 scripts/internal/remote_alpha_normal_shell_runtime_image_check.sh | U | 100755 | 26930 | c16e17edb0260c76e7a8dbb80066a4034e390771d85e1ef8ac388926acadbed1 | C
338 scripts/internal/remote_alpha_operator_healthcheck_tls_renew.sh | U | 100755 | 34479 | 8e2bba7f921ea30dc1956cddfb05d4c8ebe3cc17a71f9b4153d6b3d82ac6f3d2 | C
339 scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py | U | 100644 | 42360 | b8d5de8eb762b4989eadf65f64f369b7995c98f35df19d4cb20bebea5d3bc891 | C
340 scripts/internal/remote_alpha_plan_old_root_cleanup.sh | U | 100644 | 13742 | ff19387d6ebc403af4409230c866e45b97f0085c2c977993e7cce1c5bab263b3 | C
341 scripts/internal/remote_alpha_prepare_es_config_tls.sh | U | 100755 | 82081 | b7c1e590e3e52bf6039d790778751933468acfc06082ece562c79f9be598793d | C
342 scripts/internal/remote_alpha_prepare_es_writable_state_ownership.sh | U | 100644 | 177933 | 0faa0b93f6526f4efe09b00c210af0624cf06790f816d94471d | C
343 scripts/internal/remote_alpha_runtime_security_boundary_check.sh | U | 100755 | 59327 | 3d8ded9eefbdc8968961f815d994e15a863e18f9734c5ed380c97420b6251de8 | C
344 scripts/internal/remote_alpha_stage_es_config_tls_prep.sh | U | 100644 | 24794 | d684e0e735b286fc7ef8a20f5c993f4dd8833407e3677b0098ef67e146dccc8b | C
345 scripts/internal/remote_alpha_stage_es_writable_state_readiness_check.sh | U | 100755 | 46409 | c00b77d87850ae2a52c9f53a1a13a286ad1548c299938928f18c7f7decebe118 | C
346 scripts/internal/remote_alpha_vault_workload_auth_bootstrap.sh | U | 100644 | 36501 | 00c4a1666a5ed8746355201b3af6303b28f5e9197a36a64f9b367252e4c787ae | C
347 scripts/internal/remote_alpha_vault_workload_auth_check.sh | U | 100644 | 61222 | c6c077dd4bb249ce19deb7f0799b9b2706325791d94c666fb7a0124984b96b82 | C
348 scripts/internal/supported_local_proof_cleanup.sh | U | 100644 | 7110 | b39e320165e0332f0ac60b30cec17a64341ba8ff939d3eb78646a10a5a4bfce8 | C
349 scripts/package_example_archive.py | U | 100644 | 1779 | f3dbbcf54aa50b5bc3a29fc02d29e0a23efc849c733e31cf50bf94b64ede472a | C
350 scripts/remote_alpha_build_normal_shell_runtime_image.sh | U | 100755 | 1826 | d3e9fe71dcfe3daf4e0956fe0f390f1e6e812658504264ddd43372a50408d744 | C
351 scripts/remote_alpha_check_es_writable_state_readiness.sh | U | 100644 | 325 | 8a6f6a24fc241e4f21a80523b5702f70242b0fefa24137fa9aef09ed9313b2d9 | C
352 scripts/remote_alpha_deploy_es_binaries.sh | U | 100644 | 280 | 673ebd0efdbbae88dc27040b734184dcdcab5e83412cf18f4681333ec3106272 | C
353 scripts/remote_alpha_es_service_tls_renew.sh | U | 100755 | 286 | 44c8b32224a222b6d0577a055cea453e56ef44351ad9f4d8833093c051d1ff04 | C
354 scripts/remote_alpha_es_service_user_rollback_rehearsal.sh | U | 100755 | 328 | d83664c34cf0b0f80f09ea5790343512ab5e9d0dd186ab1d2c5efa78eb7a4f7a | C
355 scripts/remote_alpha_harden_ags_service.sh | U | 100755 | 315 | e30a252de632c7c8c3fedfa8337ab384c261535b5cba9a0275eba9a806bf5500 | C
356 scripts/remote_alpha_harden_ars_service.sh | U | 100755 | 315 | 5ac545c3c5b05f1eb0930fb45b688703558e30bba33c9f56fa0582a8d3e26f96 | C
357 scripts/remote_alpha_harden_egs_service.sh | U | 100755 | 315 | 2f7cda0b4f9a799bf6f1bc4ca9975dbc1e1a0381f79dbbef6e64d10a8825189b | C
358 scripts/remote_alpha_migrate_es_service_user.sh | U | 100644 | 295 | 095af1659a41922f7c53c727ee840d9794a2ff890533e200c97d47c0f6f433f7 | C
359 scripts/remote_alpha_migrate_vault_service_user.sh | U | 100755 | 304 | 85bf9734b2cb3b43a07f83e8210dabd4c5576893be4574dee79d1003bbb899c6 | C
360 scripts/remote_alpha_normal_shell_runtime_image_check.sh | U | 100755 | 315 | 2e63048840a41013088e49df3bee54e51937ef32dbeb1ea9963a416e5920c | C
361 scripts/remote_alpha_operator.sh | M | 100755 | 258480 | 8b7cb6e8982965a82330d7990ad5ad68e4d281c28ef7bedab982ff61987ffe5a | C
362 scripts/remote_alpha_operator_healthcheck_tls_renew.sh | U | 100755 | 316 | e6ba6f1fccc365ca0c18e7ad77d4e52c9ecb090fdd2d2adea0ea0ae240844cf9 | C
363 scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py | U | 100644 | 54531 | 35dc99896341c3d0818cb37bcc2b20408045e39493d8479a5fe6ee987d199150 | C
364 scripts/remote_alpha_plan_old_root_cleanup.sh | U | 100644 | 289 | e9772b2c281bf59476f06a1c52a010b9f8bcfe7d87595508fd556fa57d2aa660 | C
365 scripts/remote_alpha_prepare_es_config_tls.sh | U | 100755 | 286 | 985e9f271cc3a02838cc8025ffb976882068f3c1fbba0016a6976e9e31689513 | C
366 scripts/remote_alpha_prepare_es_writable_state_ownership.sh | U | 100644 | 331 | 790ea14659380c4559bbacffaa0e9f152b61b4931f7c69ba411652566dc5b4d4 | C
367 scripts/remote_alpha_prepare_external_tls_status.sh | A | 100755 | 84316 | 23405e5ebed82f70ef7b3f35d47fc58c3d0293305e191569125316e8d81af5b7 | C
368 scripts/remote_alpha_reset_disposable_vault.sh | U | 100755 | 22729 | ee1b1d3911bdf23dad6c79dfc0a1fe4c0a0d0505996fd1ebb08ade96a46a2694 | C
369 scripts/remote_alpha_runtime_identity_helper_summary.sh | U | 100755 | 21547 | 7c18010e8cbe92f7e25ad53d5e28db76be4e0063a1e9e5c16d629831c6143f7d | C
370 scripts/remote_alpha_runtime_security_boundary_check.sh | U | 100755 | 330 | f016433b78e4c8615a520e70a493beadeac9951a58a1afc1170a57ca74db33b5 | C
371 scripts/remote_alpha_stage_es_config_tls_prep.sh | U | 100644 | 298 | af6dd1d033ce57909e7ae375ea35cd2e3e7bd5e426d48e080b14253373ce92ff | C
372 scripts/remote_alpha_stage_es_writable_state_readiness_check.sh | U | 100755 | 343 | 1c2dbb77957a15734f684c898e78c5873e10fad2c900f4c16f347144f527e3d2 | C
373 scripts/remote_alpha_vault_workload_auth_bootstrap.sh | U | 100755 | 289 | 7db4909d5ad89f450b0bfbe5a2f8ada7dd72ca7aeb5bacfc542f6ed9b4a8b141 | C
374 scripts/remote_alpha_vault_workload_auth_check.sh | U | 100755 | 306 | fbea06973f0f184c3d9f4c4bd31e4bc507312e9163b883efab06d56defa826a8 | C
375 testdata/remote_alpha_es_service_user_rollback_rehearsal/blocker/es-binary-deployment-apply-summary.json | U | 100644 | 955 | 33043ee5d71393699f30cd32c2d561e076f1dfa22618fa0996b6a80bd2d45ccd | C
376 testdata/remote_alpha_es_service_user_rollback_rehearsal/blocker/es-service-user-migration-apply-summary.json | U | 100644 | 2013 | 9d340920603b01e51b7e54d7f936ecd9674258301911468b3f729a39af5cbc16 | C
377 testdata/remote_alpha_es_service_user_rollback_rehearsal/blocker/es-service-user-migration-check-only.json | U | 100644 | 732 | 5722b2f89094a1ea451871b9b39d07ae8814b6da242d1a326f53b9d82bde2b3e | C
378 testdata/remote_alpha_es_service_user_rollback_rehearsal/blocker/es-writable-state-ownership-apply-summary.json | U | 100644 | 1591 | 853235d9b4c01992393daed7d4c1ff971d541a142f6ac62df75971c2315e1500 | C
379 testdata/remote_alpha_es_service_user_rollback_rehearsal/pass/es-binary-deployment-apply-summary.json | U | 100644 | 955 | 33043ee5d71393699f30cd32c2d561e076f1dfa22618fa0996b6a80bd2d45ccd | C
380 testdata/remote_alpha_es_service_user_rollback_rehearsal/pass/es-service-user-migration-apply-summary.json | U | 100644 | 2096 | 56b2bad78a3b43aaeff9170b878ed87f558fe325160ad2e27c2d08a392a3c9dd | C
381 testdata/remote_alpha_es_service_user_rollback_rehearsal/pass/es-service-user-migration-check-only.json | U | 100644 | 732 | 5722b2f89094a1ea451871b9b39d07ae8814b6da242d1a326f53b9d82bde2b3e | C
382 testdata/remote_alpha_es_service_user_rollback_rehearsal/pass/es-writable-state-ownership-apply-summary.json | U | 100644 | 1591 | 853235d9b4c01992393daed7d4c1ff971d541a142f6ac62df75971c2315e1500 | C
383 testdata/remote_alpha_es_service_user_rollback_rehearsal/warning/es-binary-deployment-apply-summary.json | U | 100644 | 955 | 33043ee5d71393699f30cd32c2d561e076f1dfa22618fa0996b6a80bd2d45ccd | C
384 testdata/remote_alpha_es_service_user_rollback_rehearsal/warning/es-service-user-migration-apply-summary.json | U | 100644 | 2096 | 56b2bad78a3b43aaeff9170b878ed87f558fe325160ad2e27c2d08a392a3c9dd | C
385 testdata/remote_alpha_es_service_user_rollback_rehearsal/warning/es-service-user-migration-check-only.json | U | 100644 | 732 | 5722b2f89094a1ea451871b9b39d07ae8814b6da242d1a326f53b9d82bde2b3e | C
386 testdata/remote_alpha_es_service_user_rollback_rehearsal/warning/es-writable-state-ownership-apply-summary.json | U | 100644 | 1132 | 245b2f01e9ff68565622f5ef99293f6f8826af089e71ec9bc5b479471636c7d8 | C
387 testdata/remote_alpha_external_tls_status/repair10_git_session_v1.json | A | 100644 | 1958 | ec44b020427918292e91fd90d0ce8771e206ce2e483850d2dd987b5154400e4a | C
388 testdata/remote_alpha_external_tls_status/repair10_tree_corpus_v1.json | A | 100644 | 1532 | e02beedfeb1a5afbc3a351dd97897bd37c686344b8c5a7ba9b2370cb4d9e5013 | C
389 validation_isolation_test.go | A | 100644 | 19366 | 6d06b1a9280c6e94aa22c9d6a26c44ad2bbb40c659f2b84ac381306b12d118ef | C
```

## 7. Logical-mode versus custody-mode treatment

Logical repository modes are independently authenticated `100644`/`100755` values and drove the private Git tree. Every retained `source/` file is a physically distinct regular, single-link `0600` file; all directories are `0700`. Logical mode was never inferred from custody permissions.

## 8. B source T and inventory reproduction

Fresh closing scan reproduced:

- Files: `389`
- Source T: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Inventory SHA-256: `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- Inventory size: `54,314`
- Exact byte equality with the authenticated B inventory: yes
- Physical aliases with candidate/supplied sources: 0
- Symlinks/special/multiply-linked source objects: 0

## 9. B Git tree SHA

Private `git write-tree` and committed-tree verification both produced:

`8de797304ea944b6a155924e0d1e9e8bbe79534e`

## 10. Synthetic commit identity, parent, subject, and nonauthority

- Synthetic commit: `e42aac659299e023df07a842df17e9fc84a135c1`
- Parent: `567bceced5df95ecfe787cc66038d463a854e12c`
- Tree: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Subject: `implement Remote Alpha external TLS T2A-P source`
- Author/committer: `Repair 10I Strategic Snapshot <repair10i-strategic-snapshot.invalid>`
- Timestamp: `2001-01-01T00:00:00Z`

This synthetic commit is evidence only and is not the future publication identity.

## 11. Proof every non-36 path equals H

A complete H/B tree-entry comparison found exactly the 36 listed deltas. All 353 H paths outside that set had identical logical mode and Git blob OID. B contains exactly 14 additions and 22 modifications.

Evidence: [non-36-equality.json](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/git/non-36-equality.json>).

## 12. Recovered validation plan and governing sources

The plan was recovered from:

- topology reconciliation command records;
- exact 105-name B docs-contract list;
- test-path dependency DAG;
- Repair 10 exact-64 results;
- exact historical-outcome reconciliation;
- governance-freeze evidence;
- repository governing documents.

It retained all seven historical acceptance-bearing commands and added the required rooted private `git diff --check`. No reduced replacement plan was invented.

Full exact argv, environment, expectations, rationale, and authority records: [validation-plan.json](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/validation/validation-plan.json>).

## 13. Exact validation commands, environments, and results

Pinned Go:

`/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go`

SHA-256:

`3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`

Isolation included private `HOME`, `TMPDIR`, `GOTMPDIR`, `GOCACHE`, and `GOMODCACHE`, plus:

```text
GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
ES_REPAIR10_SOURCE_ROOT=<exact separate private B clone>
```

Results:

```text
go-version
  argv: <pinned-go> version
  exit=0 accepted=true
  stdout=33 sha256=278375c8a03c34bb0f855154850de7c4f217fd3b8cdf37986819e3f05d0a4c33
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

complete-docs-105
  argv: <pinned-go> test -modcacherw . -run <exact anchored 105-identity regex> -count=1 -p=1 -parallel=1 -json
  exit=0 accepted=true; 105/105 expected top-level identities passed
  stdout=171305 sha256=b11e869baefed7d9515d3a4fd1081554ac92efc676acf7d8b76a4b00841614a6
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

testsupport-acceptance
  argv: <pinned-go> test -modcacherw ./internal/testsupport -run ^(TestRepair10ControlRootPolicyV1|TestRepair10OwnedProcessLifecycleV1|TestRepair10SignalBirthMismatchNeverSignalsV1)$ -count=1 -p=1 -parallel=1 -json
  exit=0 accepted=true; 3/3 passed
  stdout=12453 sha256=642ae94aa4627f61238792ea7e0b3c88d62724c762400f86c8330fa7ad9f541a
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

external-tls-all
  argv: <pinned-go> test -modcacherw ./es/externaltls/... -count=1 -p=1 -parallel=1 -json
  raw exit=1 accepted=true
  exact governed result: one allowed failure and four allowed skips; zero unexplained failure/skip
  stdout=1481576 sha256=8c89302e15540780b6aa801a049700d9b0a26ed0a0c011fc3309011627bf0313
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

repair10-current-affected-pass
  argv: <pinned-go> test -modcacherw . -run <exact anchored 20-identity regex> -count=1 -p=1 -parallel=1 -json
  exit=0 accepted=true; 20/20 passed
  stdout=149703 sha256=86b387f9a522d1c4c43327cc5cfc13babd85793c79479d635a34ce01d13d2d84
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

changed-nonroot-product-tests
  argv: <pinned-go> test -modcacherw ./es/admission ./es/admission/internal/reliablesubmit ./es/app ./es/runtimehelper -run <exact anchored 9-identity regex> -count=1 -p=1 -parallel=1 -json
  exit=0 accepted=true
  eight positive top-level identities passed; the one closed helper-process fixture skip was exactly observed and allowed
  stdout=10471 sha256=344845b6fef66fd57296b71a540c2cb54425040cf578bc901c643a3f774f4bce
  stderr=0 sha256=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

bash-syntax
  argv: /bin/bash -n scripts/remote_alpha_prepare_external_tls_status.sh scripts/remote_alpha_operator.sh
  exit=0 accepted=true; stdout/stderr empty

private-git-diff-check
  argv: git -C <private-validation-root> diff --check 567bceced5df95ecfe787cc66038d463a854e12c e42aac659299e023df07a842df17e9fc84a135c1 --
  exit=0 accepted=true; stdout/stderr empty
```

Source T, inventory, committed tree, and clean Git state were unchanged after validation. There were zero unexplained failures, errors, or skips.

## 14. Failed/superseded attempts

Two harness attempts were retained separately and contributed no qualification:

1. Opening attempt 001 stopped before source construction because the harness expected a boolean `pass` field where the authenticated lineage schema uses `outcome=pass`.
2. Closeout attempt 001 completed cleanup and all equality checks, then stopped because an overbroad scanner treated governed PEM-header test/sanitization literals as live key material. Corrected adjudication distinguished the literals, including the explicit invalid `abc` negative fixture.

There were no failed validation attempts.

## 15. Snapshot authority and nonauthority

The snapshot may claim only:

- exact source bytes and logical modes;
- exact H→B classification;
- exact B source T and inventory;
- exact B Git tree candidate;
- observed validation results;
- provenance to named sources.

It grants no publication, candidate commit, current-repository-fact, product/runtime/deployment readiness, A6 readiness, semantic-successor, orchestrator, or future commit-identity authority.

## 16. Artifact and sensitive-material findings

No generated validation state or plausible live credential/private-key material remains in retained source.

Authenticated source fixtures include three `.tar.gz` archives and `.out/Dockerfile`. Five PEM-header occurrences were classified as governed test/sanitization literals; one is the explicit invalid `abc` negative fixture. No key/keystore path or plausible live key payload was found.

## 17. Cleanup and absence observations

Only the recorded task-owned private transient root was removed. Two fresh observations found:

- exact transient path absent;
- zero `private-transient-*` matches;
- zero process survivors;
- zero descriptor or deleted-open-file survivors.

Private Git repositories, bundle, clone, caches, home, temporary files, and validation materializations were removed.

## 18. Candidate and supplied-root closing equality

Closing checks reproduced:

- Candidate H and H tree exactly.
- Candidate F source T and inventory exactly.
- Opening status bytes exactly.
- Opening modified/untracked membership exactly.
- Opening index identity exactly.
- No Git markers or locks.
- All seven supplied-root aggregate fingerprints exactly equal to opening.

No candidate or supplied-root drift occurred.

## 19. Complete evidence membership and manifest identities

[Final evidence inventory](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/closeout/final-evidence-inventory.json>):

- Size: `130,182`
- SHA-256: `fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb`

[Canonical manifest A](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/manifest/canonical-manifest-a-v1.json>) and [canonical manifest B](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/manifest/canonical-manifest-b-v1.json>):

- Independently generated using different traversals.
- Byte-identical.
- Size: `139,328` each.
- SHA-256: `df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc`
- Entries: `567`
- Directories including root: `107`
- Nonmanifest files: `460`
- Empty directories: `0`
- Self-exclusions: exactly the two canonical manifest files.
- All retained directories: `0700`.
- All retained files: regular, single-link `0600`.
- Symlink/special/multiply-linked objects: `0`.

The third, read-only post-seal verifier reproduced the manifests exactly.

[Retained final report](</Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2/closeout/final-report.md>):

- Size: `151,150`
- SHA-256: `2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe`

## 20. Remaining uncertainty

No source, topology, mode, validation, or provenance uncertainty remains inside the bounded snapshot objective.

The deliberate remaining boundary is governance: fresh independent audit has not been performed, B has not been published into the candidate, and no product/runtime/A6 authority follows from this package.

## 21. Explicit confirmations

- `CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED`
- `CANDIDATE_INDEX_MUTATION_NOT_PERFORMED`
- `STAGING_NOT_PERFORMED_IN_CANDIDATE`
- `COMMIT_NOT_PERFORMED_IN_CANDIDATE`
- `SUPPLIED_EVIDENCE_NOT_MUTATED`
- `EXACT_B_SOURCE_CONSTRUCTED`
- `EXACT_36_PATH_SCOPE_RECONSTRUCTED`
- `B_GIT_TREE_COMPUTED`
- `SYNTHETIC_COMMIT_IS_EVIDENCE_ONLY`
- `PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED`
- `NETWORK_CONTACT_NOT_PERFORMED`
- `A6_NOT_STARTED`
- `SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED`
- `ORCHESTRATOR_NOT_IMPLEMENTED`
- `INDEPENDENT_AUDIT_NOT_PERFORMED`
