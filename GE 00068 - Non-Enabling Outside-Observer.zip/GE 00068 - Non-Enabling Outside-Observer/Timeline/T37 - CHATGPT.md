The stop is correct, but this is a much narrower failure than the earlier ones.

B3 has now established several important facts:

- All five fresh controls independently qualified with zero unknown diagnostics.
- Final↔fresh reached `qualified-equal`, exit `0`, despite raw-byte differences. That validates the A3 canonicalization repair and the fresh-control construction.
- The failure is confined to `exactMutantDeltaV1`.
- Product A/B was correctly not started.
- Repository source remains unchanged.

## Diagnosis

`exactMutantDeltaV1` is conflating three distinct layers:

1. **Control qualification and physical independence**
   - physical control/source roots;
   - mapping tables;
   - process identities;
   - raw-stream and custody records;
   - cross-control disjointness.

2. **Source/mutant provenance**
   - base T and inventory;
   - effective mutant T and inventory;
   - sole changed path;
   - exact insertion and provenance record.

3. **Comparable test semantics**
   - logical lifecycle identities and outcomes;
   - canonical diagnostics;
   - unknown classifications;
   - panic/race/warning/malformed state;
   - within-occurrence ordering, multiplicity, and correlation.

Physical mapping tables **must differ** between independently materialized controls. Requiring both disjoint controls and mapping-table equality makes the intended mutant acceptance path impossible. Mapping tables must remain independently validated and cryptographically bound, but they are not part of the declared semantic mutant delta.

The same problem applies to raw global lifecycle ordering. Independent runs may differ in irrelevant scheduler chronology. The mutant predicate must operate on the same canonical comparable-semantic projection already used successfully for final↔fresh. It must still preserve package/test occurrence identity, within-occurrence diagnostic order, multiplicity, and correlation; it must not weaken those properties or introduce set-only comparison. The frozen semantic design already permits ignoring only cross-package scheduling order while retaining those stronger local relationships. 

The correct next increment is therefore:

> **Repair 10I-A4: successor-only correction of the intentional-mutant comparison projection**, followed by a completely fresh **Repair 10I-B4**.

Do not repair this inside B3. Keep B3 unsealed and immutable as the causal failed attempt. As with the preceding amendments, a changed successor requires a fresh downstream restart rather than promoting partial downstream results. The sealed A2 lineage explicitly used that restart rule. 

Pass this to Codex:

```text
Objective

Create and seal a bounded Repair 10I-A4 successor amendment correcting the
unsatisfiable intentional-mutant comparison policy exposed by Repair 10I-B3.

This is a successor-tool-only repair.

Do not modify repository source.
Do not resume, overwrite, seal, or clean Repair 10I-B3.
Do not start Repair 10I-B4 in this turn.

After A4 succeeds, a later fresh turn must create Repair 10I-B4 and rerun all
five source controls from the beginning with the sealed A4 successor.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Required new A4 child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

No subagents. You are the sole writer.

## 1. Immutable inputs and opening gate

Repository expected identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- repository inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Immutable lineage:

Repair 10I-A:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a
  manifest:
  dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7
  payloads:
  334

Repair 10I-A2:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800
  manifest:
  f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7
  payloads:
  210

Repair 10I-A3:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800
  successor T:
  6d4d9bd209dc67ebef2ae6f33451841766b74bf7
  successor inventory:
  d28c0e10247c805c2e50e9e894e361ea2d6fee93431a6ecd36e5c0df9670505f
  members:
  12
  manifest:
  a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b
  payloads:
  292
  detached-digest file SHA-256:
  f7040f7f66ee30b40084ef2818d7d5cdcf9d77ac10d9fc0c0cf4b16d427c911c

Expected A3 binaries:

repair10-runner
  size:
  5,587,714
  SHA-256:
  aba83c2a19664ae3adfc16633bf3dfe1ae10db1ee2201b96d253d249e147377f

repair10-compare
  size:
  4,597,410
  SHA-256:
  f5ace5d0ade46af4b444756f4da549fc8aff14a5fdd141ae73623c7daf2fde1d

repair10-semantic
  size:
  4,129,186
  SHA-256:
  5a71e78080fa9fdd06147a95044cdf6135251e4ad16eca49dd148c86fcfb3dc6

repair10-fixture
  size:
  7,709,426
  SHA-256:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Phase H:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d
  manifest:
  fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb
  payloads:
  6,191

Failed and unsealed children, immutable and nonqualifying:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b3-closure-4dd211207800

Require the A4 target to be absent.

Reverify every immutable manifest completely, not only by aggregate digest.

Stop before mutation on any mismatch:

REPAIR10I_A4_BASELINE_MISMATCH

## 2. Finding classification

Freeze the defect as:

ID:
  REPAIR10I-A4-MUTANT-COMPARISON-PROJECTION-001

Type:
  successor semantic comparison policy

Severity:
  high, acceptance-blocking

Classification:
  private validation/successor defect; not repository product source

Exact causal evidence:

- All five B3 source controls independently qualified.
- Every control had zero unknown diagnostics.
- Final versus fresh produced qualified-equal and exit 0.
- Final versus mutant reached:
  - both controls qualified;
  - zero unknowns;
  - physically disjoint controls;
  - valid frozen mutant provenance.
- exactMutantDeltaV1 nevertheless returned:
  blocked-uncertain / mutant-delta-policy-mismatch.
- The current predicate retains physical mapping tables and full/raw lifecycle
  ordering while also requiring independent physical controls.

Mechanism:

- Physical mapping tables necessarily contain distinct control roots, source
  roots, process identities, and other control-local values.
- Those differences prove isolation; they are not mutant semantic changes.
- Raw or globally ordered lifecycle records may also differ in irrelevant
  cross-package scheduling chronology.
- The predicate therefore requires equality of values that must differ for a
  valid independent comparison.

Impact:

The exact required final-versus-mutant comparison is structurally
unsatisfiable even when:
- both sides independently qualify;
- mappings are valid and disjoint;
- unknowns are zero;
- source/provenance is exact;
- the only logical semantic change is the declared mutant.

No product, source-control, canonicalization, or A/B preparation defect is
established by this finding.

## 3. Frozen separation of concerns

The repaired design must keep three independent planes.

### 3.1 Qualification and physical-independence plane

This plane retains and validates, per side:

- control ID;
- source class;
- physical control and source roots;
- complete mapping table;
- mapping-table identity and digest;
- raw stream identity;
- qualification record;
- process and resource custody;
- terminal reconciliation;
- source T and inventory;
- base/effective mutant provenance;
- physical disjointness;
- no inode alias, containment, hardlink, process, socket, cache, Git, runtime,
  PackageFloor, or evidence collision.

These fields must remain cryptographically bound and mandatory.

They are prerequisites for comparison.

They are not themselves entries in the intentional semantic delta.

A missing, malformed, unbound, producer-caption-only, aliased, or
nonindependent mapping or qualification record blocks with exit 1.

### 3.2 Comparable-semantic plane

Define or reuse one canonical comparable-semantic projection used consistently
by:

- final versus fresh equality;
- final versus mutant;
- mutant versus fresh;
- HEAD versus final;
- Repair 9 versus final.

It contains only logical test semantics, including all acceptance-relevant
properties:

- package/test/subtest lifecycle identities and terminal outcomes;
- skips;
- package aborts;
- panic, race, fatal, warning, malformed, and unknown classifications;
- canonical diagnostic records;
- diagnostic class, template ID, canonical text, multiplicity, occurrence,
  ordinal, and correlation sequence;
- package/test occurrence identity;
- within-occurrence diagnostic ordering;
- every other material canonical semantic field.

It excludes only nonsemantic, independently validated control-local metadata:

- physical mapping-table values and physical roots;
- control IDs;
- raw filesystem paths;
- qualification-record paths;
- raw-stream paths;
- leader PIDs and process epochs after their typed canonical role has already
  been validated;
- custody/report file locations;
- source-class captions;
- raw hashes and evidence references as values inside semantic equality.

Do not discard their validation. Keep it in the qualification plane.

Ignore only already-governed cross-package scheduler chronology. Preserve
package/test occurrence identity, within-occurrence order, multiplicity, and
correlation.

Do not introduce:
- set-only lifecycle comparison;
- sorting that loses repeated occurrences;
- generic diagnostic normalization;
- omission of skips, package aborts, panics, races, warnings, malformed data,
  or unknowns.

### 3.3 Mutant provenance plane

Separately require:

- exact base final T/inventory;
- exact effective mutant T/inventory;
- exact sole changed path;
- exact before/after mode, size, and SHA-256;
- exact insertion offset and context digest;
- immutable pre-execution mutant source;
- exact retained provenance payload;
- source class intentional-mutant;
- no second changed path or post-launch mutation.

The semantic delta predicate consumes the validated provenance but does not
replace it.

## 4. Required intentional-mutant algorithm

Repair exactMutantDeltaV1 or replace it with an equivalently bounded unexported
implementation.

Required algorithm:

1. Require both final and mutant controls to be independently qualified.
2. Require physical independence and all mapping/custody gates to pass.
3. Require zero unknowns.
4. Require exact mutant provenance and source bindings.
5. Build the final control's canonical comparable-semantic projection.
6. Deep-copy that projection.
7. Apply exactly the mutation declared by the comparison specification and
   provenance:
   - the exact declared test lifecycle transition;
   - any explicitly declared and necessary enclosing package/command terminal
     transition;
   - the one complete declared diagnostic tuple, including package, test,
     subtest, classification, rule/template ID, canonical text, occurrence,
     ordinal, count/multiplicity, and correlation sequence.
8. Do not infer or hard-code an enclosing package transition when the package
   was already failing. The comparison specification must state the exact
   lifecycle delta.
9. Canonically encode the expected mutant projection.
10. Canonically encode the observed mutant projection.
11. Require byte-exact equality.
12. Require every unpatched semantic field to remain equal.
13. Retain factual raw-byte differences separately.
14. Return:
    - qualified-different;
    - AcceptedEqual=false;
    - unknown count zero;
    - exact intentional-mutant reason codes;
    - exit 2.

Do not compare complete physical mapping tables for equality.

Do not compare unnormalized global raw lifecycle chronology.

Do not weaken or bypass independent qualification, mapping validation, physical
disjointness, raw re-extraction, custody, or terminal/resource checks.

Final versus fresh remains:
- qualified-equal;
- AcceptedEqual=true;
- exit 0.

## 5. Authorized A4 source scope

Copy all 12 A3 successor source members into A4 without hardlinks.

Modify exactly:

1. tool/source/FORMAT.md
2. tool/source/envelope/semantic.go
3. tool/source/envelope/envelope_test.go

Keep byte-identical:

- tool/source/envelope/runner.go
- tool/source/envelope/source.go
- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-fixture/main.go
- tool/source/go.mod
- both golden files

Retain the current Repair 10I private schema identifiers. This amendment changes
the implementation of the already frozen comparison contract; it does not
change record shape or public/product schemas.

If a fourth successor source file or a schema-shape change is required, stop:

REPAIR10I_A4_SCOPE_EXPANSION_REQUIRED

Report:
- exact required file;
- exact API or schema incompatibility;
- why semantic.go cannot perform the correction while preserving the frozen
  contract.

Do not widen silently.

## 6. Vulnerable-precondition reproduction

Before applying the repair:

1. Identity-bracket the exact B3:
   - final semantic envelope;
   - mutant semantic envelope;
   - final and mutant qualification records;
   - mapping tables;
   - comparison specification;
   - mutant provenance;
   - blocked comparison result;
   - source-or-tool finding;
   - raw streams and terminal/resource records needed by the comparison.
2. Copy the minimum required inputs into A4 as independent regular files.
3. Record source path, mode, size, SHA-256, opening identity, and closing
   equality.
4. Label them:
   nonqualifying-vulnerable-precondition
5. Using exact A3 source or binary, reproduce:
   - both controls qualified;
   - zero unknowns;
   - disjoint controls;
   - exact provenance accepted;
   - final/mutant blocked solely as
     mutant-delta-policy-mismatch.

If the exact vulnerable precondition cannot be reproduced, stop:

REPAIR10I_A4_IMPLEMENTATION_BLOCKED

Do not mutate B3.

## 7. Required causal tests

Add active Repair 10I-A4 tests covering all of the following.

### 7.1 Valid exact mutant delta with physical disjointness

- Final and mutant use different physical control roots.
- Mapping tables contain different physical values.
- Process identities differ.
- Both mapping tables are independently valid and bound.
- Controls are physically disjoint.
- Exact declared semantic mutant delta succeeds as qualified-different.
- Exit is 2.
- AcceptedEqual is false.
- Unknown count is zero.

### 7.2 Qualification and mapping failures remain blocking

Each must produce exit 1, not a clean expected difference:

- missing mapping table;
- malformed mapping table;
- unbound mapping digest;
- mapping role missing;
- unknown mapping role;
- aliased physical roots;
- equal inode across controls;
- containment in either direction;
- unqualified left;
- unqualified right;
- raw re-extraction mismatch;
- late custody fault;
- terminal-reconciliation fault;
- resource-disposition fault.

### 7.3 Exact delta failures

Each must reject:

- missing declared test transition;
- wrong test transition;
- extra test transition;
- wrong or unexpected package terminal transition;
- missing declared package transition when required;
- extra diagnostic;
- missing diagnostic;
- changed package;
- changed test or subtest;
- changed classification;
- changed rule/template ID;
- changed canonical text;
- changed occurrence;
- changed ordinal;
- changed multiplicity/count;
- changed correlation sequence;
- second source path;
- source mode change;
- effective mutant T/inventory mismatch;
- provenance payload mismatch;
- post-launch source mutation;
- any other semantic-field change.

### 7.4 Ordering and multiplicity

- A permitted cross-package scheduler-order difference must not invalidate the
  exact mutant delta when the canonical comparable projection is unchanged.
- A within-test or within-occurrence diagnostic reorder must reject.
- A duplicate occurrence must reject.
- A missing occurrence must reject.
- A correlation-order change must reject.
- Repeated identical diagnostics with different occurrences must remain
  distinguishable.

### 7.5 Regression protections

- Final/fresh A3 retained inputs still produce qualified-equal, exit 0.
- Final/mutant retained B3 inputs produce qualified-different, exit 2, after the
  repair.
- Mutant/fresh produces the exact inverse declared delta, exit 2.
- HEAD/final and Repair-9/final no-regression predicates remain unchanged.
- A3 source-line grammar behavior remains exact:
  - governed final unknown count zero;
  - historical HEAD and Repair 9 byte-identical;
  - lines and offsets preserved.
- Every prior Repair 10I causal test remains active and passing.
- No H/G/F schema becomes qualifying.
- No generic physical-root, mapping, PID, diagnostic, lifecycle, or ordering
  normalization is introduced.

## 8. Independent A/B hard gate

Use two disjoint private controls under umask 077.

Per side:

- no-hardlink A4 source materialization;
- private HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- pinned offline Go 1.26.5;
- no-write gofmt over all 12 source members;
- focused A4 tests count 1;
- focused A4 tests count 3;
- all Repair 10I tests count 3;
- full ./... count 3;
- focused A4 race;
- all Repair 10I race;
- full ./... race;
- zero required skip, failure, malformed JSON, race, timeout, survivor, forced
  cleanup, or resource uncertainty;
- deterministic builds:
  go build -trimpath -buildvcs=false -ldflags=-buildid=
- runner, compare, semantic, and fixture A/B binary pairs must be byte-identical,
  inode-distinct, single-link, and mode 0700.

Retain every argv, cwd, bounded environment, raw stream through EOF, exit, Wait,
terminal reconciliation, resource disposition, source inventory/tree, binary
identity, and cleanup record.

## 9. Retained-input adjudication

Using both independently built A4 successor sides, rerun comparison over the
retained B3 inputs.

Required result:

- final qualification:
  qualified
- mutant qualification:
  qualified
- unknowns:
  zero
- provenance:
  exact
- physical independence:
  pass
- factual semantic equality:
  false
- accepted equality:
  false
- outcome:
  qualified-different
- reason codes:
  exact intentional-mutant delta only
- exit:
  2

Require A and B to produce byte-identical comparison records.

Also rerun:

- final/fresh retained B3 inputs:
  qualified-equal, AcceptedEqual=true, exit 0
- mutant/fresh retained B3 inputs:
  exact inverse intentional-mutant delta, exit 2

Do not promote any B3 source control as fresh Repair 10I-B qualification.
These are bounded successor causal tests only.

## 10. Seal and closeout

Create a complete A4 evidence child containing at least:

- opening identities;
- exact A3 source and binary identities;
- exact three-path A3→A4 source delta;
- vulnerable-precondition reproduction;
- all causal tests;
- A/B source/build/hard-gate records;
- retained B3 final/fresh/mutant comparison adjudications;
- failed and superseded attempts;
- command index;
- cleanup and two absence epochs;
- implementation report;
- evidence manifest and detached digest.

Install the detached digest before the manifest.
Install evidence-manifest-v1.txt as the final mutation.
Write nothing into A4 afterward.
Run complete read-only post-seal verification.

Do not create:
- Repair 10I-B4;
- product A/B;
- source ZIP;
- audit handoff;
- capture child;
- independent audit.

## 11. Closing gates

Reverify unchanged:

- repository source T/inventory/membership;
- branch/HEAD/parent/HEAD tree/upstream/index;
- staged/deleted/renamed/unmerged posture;
- protected repository files;
- Repair 10I-A;
- Repair 10I-A2;
- Repair 10I-A3;
- Phase H;
- failed B, B2, and B3 children.

Require no private source, Git store, cache, build, process, descriptor, socket,
listener, runtime root, PackageFloor, fixed slot, comparison root, or temporary
record remains outside sealed A4.

## 12. Verdicts

On success:

REPAIR10I_A4_MUTANT_COMPARISON_PATCH_SEALED_READY_FOR_10I_B4_RESTART

Report:

- A4 source T/inventory;
- exact three-path delta;
- four binary identities;
- exact vulnerable-before and repaired-after comparison outcomes;
- final/fresh retained-input nonregression;
- mutant/fresh inverse-delta result;
- manifest identity and payload count;
- B4 restart point.

On baseline mismatch:

REPAIR10I_A4_BASELINE_MISMATCH

On fourth-file or schema-shape need:

REPAIR10I_A4_SCOPE_EXPANSION_REQUIRED

On causal, test, race, build, comparison, cleanup, or sealing failure:

REPAIR10I_A4_IMPLEMENTATION_BLOCKED

Do not create subagents.
Do not edit repository source.
Do not mutate A/A2/A3/H/B/B2/B3.
Do not stage, commit, push, install, invoke a live route, contact a remote host,
or begin B4.
```

After A4 seals, B4 must rerun all five controls from the beginning. B3’s five qualification results are useful causal evidence, but a changed successor means they cannot become active B4 qualification. Independent audit remains a later, fresh conversation; implementation validation must not be relabeled as audit. 

### Sources

- Codex’s Repair 10I-B3 report in the current turn.
- Sealed A2 report: repository and predecessor baseline, exact successor lineage, and the explicit requirement to restart downstream validation after successor amendment.  
- Repair 10H semantic contract: preserve package/test occurrence identity, within-occurrence diagnostic order, multiplicity, and correlation while ignoring only cross-package scheduler order. 
- Governed Execution implementation/audit separation protocol. 

**Confidence:** 0.995 that this is a successor comparison-layer defect rather than a product or source-control defect; 0.97 that it can remain within `FORMAT.md`, `semantic.go`, and `envelope_test.go`; 0.99 that physical mapping validation must remain mandatory but outside the intentional semantic-delta equality projection.
