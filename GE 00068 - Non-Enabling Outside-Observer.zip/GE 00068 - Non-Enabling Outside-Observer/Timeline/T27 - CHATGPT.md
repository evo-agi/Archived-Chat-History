This is a **correct and useful stop**, not another broad setback. Repair 10I-B found a narrowly bounded defect in the **sealed successor’s semantic coverage**, before the remaining controls could be misclassified.

The repository candidate remains unchanged and still has its sealed 10I-A validation. The missing behavior is confined to the successor’s closed `goTempTemplatesV1` registry: seven historical-HEAD diagnostics are valid control-local forms but become `unknown-diagnostic-present` because their exact package/test/template tuples were never admitted.

Three consequences follow:

1. **Do not alter repository source or reopen product work.**
2. **Do not modify the sealed Phase I-A child.**
3. **Do not resume the existing unsealed Phase I-B child after changing the successor.** It must remain a failed, non-authoritative attempt under the old tool bytes. Create a successor-only amendment, seal it, then restart 10I-B from a new absent child.

This is the normal repair lifecycle: correct the audit/validation finding in a write-enabled implementation turn, produce new validation and provenance, then use the changed bytes in a fresh downstream gate.  Independent audit remains separate from implementation validation. 

Pass this to the same parent Codex implementation conversation:

```text
Continue the existing Repair 10I parent implementation conversation.

Permission remains workspace-write. This is a source-external, successor-only
Repair 10I-A2 amendment.

Do not create subagents. You are the sole writer.

Return exactly one:

REPAIR10I_A2_SUCCESSOR_PATCH_SEALED_READY_FOR_10I_B_RESTART
REPAIR10I_A2_BASELINE_MISMATCH
REPAIR10I_A2_SCOPE_EXPANSION_REQUIRED
REPAIR10I_A2_VALIDATION_BLOCKED
REPAIR10I_A2_CLOSEOUT_BLOCKED

## 1. Objective

Repair the exact sealed Repair 10I successor defect exposed by the first
Repair 10I-B control:

Seven legitimate historical-HEAD diagnostics beneath the governed
`<CONTROL_ROOT>/gotmp/` grammar are omitted from the closed
`goTempTemplatesV1` registry. They therefore become unknown diagnostics and
prevent independent qualification of historical HEAD.

This is a validation-tool coverage defect only.

Do not modify repository source, repository tests, governing repository docs,
product code, public schemas, Phase H, sealed Repair 10I-A, or the failed
Repair 10I-B child.

Do not begin or resume the five-control Repair 10I-B matrix in this turn.

## 2. Mandatory opening baseline

Repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Require:

branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

upstream:
absent

index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

repository T:
4dd2112078004c3d82d24a5167f16a6f25fe33ed

repository inventory:
2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0

membership:
389 total
375 tracked
14 nonignored untracked

staged/deleted/renamed/unmerged:
0/0/0/0

Protected production source:

es/externaltls/internal/statuspackage/package.go

SHA-256:
168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6

No repository tuple may change during this turn.

Stop with REPAIR10I_A2_BASELINE_MISMATCH on any discrepancy.

## 3. Immutable sealed inputs

Require the sealed Repair 10I-A child:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Manifest size:
55676 bytes

Manifest SHA-256:
dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7

Payload count:
334

Detached-digest file SHA-256:
5c1beb551414e711dd5135be8642ee7a5a2b1a208dd3009bd74b4e3d111ea896

Require sealed successor:

T:
8f60b33980c436422ccb55b3f5d6e938c03c4a22

inventory:
02bd6db8dfede6184c7bae21f6b2047c92da9091de2b77f425bac0a4515bcc3c

members:
12

Opening sealed successor binaries:

runner:
5587346 bytes
2cfa383765810184047c60ef4b87d47b1c493d08a4f899d2288c0dde56b2f8f6

compare:
4597042 bytes
225b92ceb95539e1d6700cd7ec3677d47a1491de20523a9b1fa7c4cd2135d04e

semantic:
4128818 bytes
652f6e84575dc917f03d818974030bf75e6a2da87b5d019a41d2c24951748268

fixture:
7709426 bytes
d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require Phase H to remain immutable:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Phase H manifest SHA-256:
fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Require the failed, unsealed Repair 10I-B attempt to remain unchanged:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

It is failed evidence only. Do not add to it, delete from it, seal it, or reuse it
as the continuation root.

Bind the retained failed raw stream:

validation/repair10i-head-v1/.../stdout.raw

Expected size:
2759234 bytes

Expected SHA-256:
43c45dc0912fe9bcdd60df78ffa39b519805e376d7ec82926bd6bbf8a02a9a5c

Bind the failed semantics and peer qualification records by their exact current
bytes before copying any input into the new amendment child.

## 4. New successor-amendment child

Require this path to be absent:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800

Create it exclusively under umask 077.

Use exact top-level directories:

opening
tool
controls
commands
validation
findings
closeout

Copy the twelve sealed Repair 10I-A successor source members into:

tool/source

Use independent regular files—no hardlinks.

Restore the logical source modes according to the sealed successor inventory.
Do not mutate the sealed source files.

Record opening copied-source inventory and pure tree. They must reproduce:

T:
8f60b33980c436422ccb55b3f5d6e938c03c4a22

inventory:
02bd6db8dfede6184c7bae21f6b2047c92da9091de2b77f425bac0a4515bcc3c

## 5. Reproduce the vulnerable precondition first

Before editing the copied successor source:

1. Copy the exact retained historical-HEAD raw stream into the amendment child,
   preserving its original size and SHA-256.
2. Run the sealed Repair 10I-A semantic extractor over that copy using the exact
   sealed I mappings and control metadata.
3. Require independent A-side and B-side extraction to reproduce byte-identical
   semantics.
4. Require exactly the seven reported unknown diagnostics and no additional
   unknown.
5. Record their exact:
   - package;
   - test or subtest;
   - full raw diagnostic text;
   - occurrence and ordinal;
   - source rule candidate;
   - raw byte offsets and decoded-output hashes.

The seven expected semantic families are the historical remote-alpha operator
diagnostics corresponding to:

- readiness summary;
- readiness staging record;
- Vault workload-auth summary;
- runtime-identity summary;
- Vault service-user summary;
- unknown-schema default/strict behavior;
- evidence-directory discovery.

Do not infer the literal tuples from this prose. Recover their complete exact
package/test/full-text forms from the bound raw stream and failed semantics.

If the precondition does not reproduce exactly seven unknowns, stop with
REPAIR10I_A2_BASELINE_MISMATCH.

## 6. Exact mutable successor scope

Modify exactly these two copied successor files:

tool/source/envelope/semantic.go
tool/source/envelope/envelope_test.go

Every other copied successor member must remain byte- and mode-identical,
including:

tool/source/FORMAT.md
tool/source/envelope/runner.go
tool/source/envelope/source.go
tool/source/cmd/repair10-runner/main.go
tool/source/cmd/repair10-semantic/main.go
tool/source/cmd/repair10-compare/main.go
tool/source/cmd/repair10-fixture/main.go
tool/source/go.mod
tool/source/envelope/testdata/evidence-manifest-v1.golden
tool/source/envelope/testdata/source-inventory-v1.golden

No schema name or record shape changes are authorized.

If another successor file must change, stop with
REPAIR10I_A2_SCOPE_EXPANSION_REQUIRED.

## 7. Required implementation

Extend the existing closed `goTempTemplatesV1` registry with only the seven
recovered exact package/test/full-text templates.

Do not introduce:

- generic path normalization;
- generic numeric normalization;
- generic suffix recognition;
- substring-based matching;
- wildcard package or test matching;
- fallback acceptance for typed-looking text;
- normalization outside the existing `go-testing-tempdir-parent-v1` grammar.

Each new entry must retain the existing rule’s bounded semantics and normalize
only the already governed control-local temporary component.

Wrong package, wrong test/subtest, changed fixed literal, malformed path,
partial template, unsupported extra text, noncanonical number, out-of-range
number, multiplicity change, occurrence/ordinal change, and correlation change
must remain unknown and blocking.

Existing five templates and all other Repair 10I canonicalization behavior must
remain unchanged.

## 8. Exact active tests to add

Add these active tests inside `envelope/envelope_test.go`:

TestRepair10IHistoricalHeadGoTempTemplatesV1
TestRepair10IHistoricalHeadGoTempTemplateRejectionsV1
TestRepair10IHistoricalHeadRawReextractionV1

The positive table must contain all seven complete recovered tuples.

For every tuple, include at least:

- exact valid positive;
- wrong package;
- wrong test or subtest;
- malformed path;
- missing component;
- changed fixed literal;
- overbound/noncanonical numeric component;
- appended text;
- duplicated occurrence;
- changed occurrence/ordinal;
- changed correlation topology where applicable.

The raw-reextraction test must consume a copied, hash-bound fixture derived from
the retained failed HEAD stream or a minimal exact extracted corpus retained in
the amendment child. Do not embed an opaque absolute private path in successor
source.

The test must prove:

- the old sealed successor yields exactly seven unknowns;
- the repaired successor yields zero unknowns for those seven records;
- the repaired successor preserves all lifecycle records;
- no unrelated diagnostic is newly recognized;
- A and B repaired extraction bytes are identical.

## 9. Validation

Use pinned Go 1.26.5, offline, with distinct mode-0700 A and B controls, umask
077, separate HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR roots, and no
network.

Run on both sides:

gofmt -d envelope/semantic.go envelope/envelope_test.go

Require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10IHistoricalHead'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10IHistoricalHead'

No required skip, race report, malformed stream, missing terminal, survivor,
forced cleanup, or resource uncertainty is permitted.

Build in both controls:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require each A/B binary pair to be byte-identical, inode-distinct,
single-link, and built from inode-distinct source copies and disjoint caches.

Run the complete existing Repair 10I successor hard gate, not merely the new
focused tests.

## 10. Exact historical-HEAD causal control

Using the newly built A and B successors:

1. Re-extract the copied retained historical-HEAD raw stream independently.
2. Require byte-identical semantic envelopes.
3. Require:
   - zero unknown diagnostics;
   - unchanged lifecycle identity set;
   - unchanged package/test terminal set;
   - unchanged panic/race/fatal/warning classification;
   - exactly seven records classified by
     `go-testing-tempdir-parent-v1`;
   - no additional record newly classified by that rule.
4. Externally qualify this bounded historical-HEAD extraction from the opposite
   successor side.
5. Require qualification to pass for semantic integrity.

This is a tool causal control only. Do not represent it as the fresh Repair
10I-B historical-HEAD source control. Repair 10I-B must rerun HEAD from a newly
materialized source after this amendment is sealed.

## 11. Closing and sealing

Before sealing:

- reverify repository source and Git administration remained unchanged;
- reverify sealed Repair 10I-A remained exact;
- reverify Phase H remained exact;
- reverify the failed Phase I-B child remained unchanged and unsealed;
- verify exactly two successor source paths changed in the amendment child;
- verify no process, descriptor, listener, socket, cache, control root, or
  temporary build remains;
- retain all failed/superseded attempts separately.

Required closeout records:

- opening identities;
- vulnerable-precondition reproduction;
- exact seven-template registry;
- positive/negative causal table;
- A/B source inventories and trees;
- A/B test, race, build, and hard-gate records;
- historical-HEAD raw reextraction and peer qualification;
- exact two-path successor delta;
- command index;
- failed/superseded index;
- closeout adjudication;
- implementation report.

Create the detached digest first.

Install evidence-manifest-v1.txt as the final child mutation.

Write nothing into the child afterward.

Perform complete read-only post-seal verification.

## 12. Restart boundary

After successful sealing, report the exact new successor:

- source T;
- source inventory;
- four binary sizes/SHA-256 values;
- manifest size/SHA-256/payload count;
- complete two-path delta;
- historical-HEAD causal outcome.

Do not restart Repair 10I-B in this turn.

The old unsealed Phase I-B child remains a failed attempt under the predecessor
successor.

The next turn must create a new absent child:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

That restart must bind both:

- the sealed repository/tool-gate lineage in Phase I-A; and
- this new sealed successor amendment.

## 13. Stop conditions

Stop with REPAIR10I_A2_BASELINE_MISMATCH on any repository, Phase I-A, Phase H,
failed-B, raw-stream, successor-source, or old-binary identity mismatch.

Stop with REPAIR10I_A2_SCOPE_EXPANSION_REQUIRED if:

- repository source must change;
- FORMAT or another successor source member must change;
- a schema/version change is required;
- the seven literal tuples cannot be uniquely recovered;
- the repair requires generic normalization.

Stop with REPAIR10I_A2_VALIDATION_BLOCKED if:

- the vulnerable precondition does not reproduce;
- any new positive fails;
- any negative is incorrectly accepted;
- any existing successor test regresses;
- A/B binaries differ;
- the complete hard gate fails;
- historical-HEAD reextraction retains an unknown or recognizes an eighth record;
- any required skip, race, survivor, resource, or cleanup failure occurs.

Stop with REPAIR10I_A2_CLOSEOUT_BLOCKED if exact scope, cleanup, sealing, or
immutable-input equality cannot be proved.

Do not weaken a predicate to continue.

## 14. Final report

Report:

1. Verdict.
2. Repository, Phase I-A, Phase H, and failed Phase I-B opening identities.
3. New amendment path.
4. Exact seven recovered package/test/full-text tuples.
5. Exact two-file successor delta.
6. New successor T and inventory.
7. Positive and negative causal results.
8. Full/count-three/race results for A and B.
9. Complete successor hard-gate result.
10. Four A/B binary identities and byte-equality proof.
11. Historical-HEAD old-versus-new reextraction result.
12. External peer qualification result.
13. Manifest size/SHA-256/payload count and sidecar identity.
14. Failed/superseded evidence.
15. Repository and predecessor no-mutation evidence.
16. Cleanup and absence evidence.
17. Remaining limitations and exact 10I-B restart point.

Required footer:

REPOSITORY_SOURCE_MUTATION_NOT_PERFORMED
REPAIR10I_A_SEALED_INPUT_MUTATION_NOT_PERFORMED
PHASE_H_MUTATION_NOT_PERFORMED
FAILED_REPAIR10I_B_ATTEMPT_MUTATION_NOT_PERFORMED
REPAIR10I_B_NOT_RESTARTED
INTEGRATED_SNAPSHOT_NOT_CREATED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

### Strategic assessment

The core repository work has not regressed. This is precisely the kind of defect the five-control qualification layer was intended to expose: historical HEAD cannot be compared safely until every accepted normalization is closed, typed, and causally tested. The correct response is **not** to weaken the zero-unknown rule and **not** to skip HEAD. It is to complete the exact closed registry, reseal the changed successor, and restart the downstream gate on fresh controls.

### Sources

- Codex’s Repair 10I-B stop report in this turn.
- Governed Execution Codex Subagent Operating Protocol: repair and re-audit lifecycle, implementation/audit separation.  
- Governed Execution Provenance Guidance: exact bytes bind implementation and audit but do not prove correctness. 

**Confidence:** 0.99 that Codex stopped at the correct boundary; 0.97 that the defect is successor-only; 0.94 that the two-file amendment above is the smallest coherent repair.
