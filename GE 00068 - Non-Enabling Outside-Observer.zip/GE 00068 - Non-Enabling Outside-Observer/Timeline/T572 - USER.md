Here is Codex's response:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

## Operative report

1. **Exact primary verdict:** `GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT`.

2. **Fresh repair root:** `/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u`; device `16777234`, inode `182819322`, mode `0700`, UID/GID `501/0`.

3. **Fresh output root:** `/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7`; device `16777234`, inode `182819323`, mode `0700`, UID/GID `501/20`.

4. **Predecessor identities:** PYZ v2 matched inode `182785051`, size `4216423`, SHA-256 `d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19`; authority v2 matched inode `182785057`, size `47750`, SHA-256 `64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec`.

5. **Consumed launch authority:** profile v4 and certificate v5 matched their required identities. Both are historical/current `false`; certificate-v5 authorization is consumed, with zero active predecessor authorizations. Neither artifact was mutated or deleted.

6. **Failed real-audit evidence:** wrapper inode `182808075`, workspace inode `182808076`, and capsule inode `182808084` authenticated. Historical process custody retained preflight PID `73309`/exit `23` and audit PID `73310`/exit `0`. Raw `SUBJECT_AUDIT_BLOCK` remains nonpromotable; wrapper adjudication remains `AUDIT_PROVENANCE_MISMATCH`. Temporal SHA `05c4ed…6036`, manifest SHA `8d714d…cffc`, terminal SHA `f92972…b7a9`, and terminal closure all matched.

7. **Replacement subject:** device `16777234`, inode `182649818`, mode `0700`, UID/GID `501/20`, 73 entries, inventory SHA-256 `eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3`. It was not mutated.

8. **Construction wrapper:** device `16777234`, inode `182648782`, mode `0700`, UID/GID `501/0`, 49 entries, inventory SHA-256 `9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e`.

9. **Content authority:** bundle matched inode `181651092`, size `13598758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`; authority matched inode `181651098`, size `19737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`. Authority was authenticated before bundle interpretation.

10. **Accepted implementation chain:** audit root inode `182593190`, 78 entries, inventory `3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d`; wrapper inode `182593189`, 12 entries, inventory `6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108`. No implementation re-audit occurred.

11. **Source adoption:** all 11 predecessor source roles were resolved through the PYZ member registry, source registry, source freeze, and runtime authority; zero missing, extra, transformed, or normalized sources. Copies were byte-identical. See [adoption registry](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/opening/adopted-source-registry-v1.json).

12. **Defect crosswalk:** exactly 946 subject rows passed, with zero genuine nonpassing row. The old harness projected ordinals 1–907 into 907 blockers by comparing descriptive prose with governed reason-class tokens. Every projected row retained `pass:true`, and every finding lacked the required actionable fields. See [defect crosswalk](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/analysis/946-reason-class-projection-defect-crosswalk-v1.json).

13. **Current row schemas:** the governing case rows carry `schema_errors`, `documentary_failures`, structured admission fields, identity, outcome, pass, and prose. Subject result rows carry identity, outcome, pass, prose, skip, and exception posture but omit the structured reason evidence.

14. **Governed expectation fields:** acceptance posture, exact outcome token, semantic reason class, and controlling specification pointer are now separate typed dimensions.

15. **Observed semantic fields:** acceptance posture, exact outcome, semantic reason class, validator keyword, instance path, schema path, and documentary-rule result are separately retained.

16. **Report-only fields:** descriptive reason text, human explanation, and producer narrative are explicitly non-semantic and never used for class comparison.

17. **Primary projection:** independently derives from an exact structured reason field, an allowed validator keyword, an allowed documentary rule, or structured historical-admission evidence. Missing, conflicting, or unsupported evidence yields provenance failure.

18. **Secondary projection:** separately authored control flow and mappings implement the same typed contract. Its projector AST differs from the primary projector.

19. **Dual-projection independence:** no cross-import or shared projection helper exists. All 946 exact compatibility rows agreed; zero unexplained disagreement and zero oracle exception occurred.

20. **Finding eligibility:** a 946 finding requires completed agreeing oracles, an exact semantic mismatch, non-null evidence, governing pointer, repair owner, repair surface, byte-change posture, reconstruction posture, and unchanged-subject re-audit posture. Passing and prose-only rows cannot create findings. See [finding contract](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/contract/direct-subject-finding-eligibility-v1.json).

21. **Disposition derivation:** A07 derives from all exact 946 row results; A13 derives only from schema-complete valid findings. Zero valid findings cannot produce BLOCK. Invalid findings or ambiguous semantics produce provenance mismatch without subject-verdict promotion.

22. **Bounded source delta:** seven existing functions changed: both 946 projectors/evaluators, `audit_subject`, package qualification, and the A07/A13 phase-field derivation in the capsule creator. Three finding/projection helpers and two independent qualification modules were added. See [source delta](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/analysis/predecessor-to-successor-source-delta-v1.json).

23. **Protected source comparison:** every unrelated predecessor function remained AST-identical. Subject resolution, ten-role closure, 15/14 model, registries, witnesses, field maps, documentary checks, split-root controls, terminal lifecycle, and no-VCS posture remained protected.

24. **946 projection matrix:** 984 uniquely named cases passed, with zero false acceptance, false rejection, reason mismatch, skip, unexpected exception, or unexplained oracle disagreement. See [matrix evidence](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/validation/946-outcome-projection-matrix-v1.json).

25. **Historical 907-row regression:** all 907 producer-pass rows semantically passed; zero valid findings, audit errors, exceptions, or disagreements.

26. **Replacement-subject compatibility:** 946/946 unique rows evaluated by both successor oracles; producer matrix remained passing with zero nonpassing row, zero semantic mismatch, zero descriptive-only mismatch, zero disagreement, and zero exception. No finding or disposition was emitted.

27. **Unchanged regression preservation:** all nine prior matrices retained exact names and expectations: case counts `25`, `946`, `160`, `79`, `60`, `30`, `35`, `40`, and `30`. Ten-role resolution, 15/14 model, 137 semantics, documentary totality, witnesses, field maps, confirmations, occupancy, A15 closure, split-root behavior, and missing-path regressions passed.

28. **Packaged ACCEPT rehearsal:** terminal `SUBJECT_AUDIT_ACCEPT`; 946 rows, zero findings/errors; archive size `1316700`, SHA-256 `f0a671043a00010ac9e8aa00eb90327fc2a83033723d9a90cbee9e73cc078a16`.

29. **Packaged direct 946 BLOCK rehearsal:** one structured reason-class mismatch produced exactly one complete finding and terminal `SUBJECT_AUDIT_BLOCK`; archive SHA-256 `7a6dddfbd1b84298ac1382461219b7ca24fcfab30d7a4c747875ed53fd531e98`.

30. **Packaged ambiguous-reason rehearsal:** zero findings, one provenance error, terminal `SUBJECT_AUDIT_PROVENANCE_MISMATCH`; archive SHA-256 `151a70b1715cb705d32f6fdca83827cadf80abf34ac7c2c38a722d2378e24b10`.

31. **Historical projection-regression rehearsal:** all historical rows replayed with zero findings/errors and terminal ACCEPT rehearsal disposition; archive SHA-256 `d0d94a326de042bcb0275419605a08b88b6dad4e1b7d3b58c53e0907ca46a28e`.

32. **Finding-schema-failure rehearsal:** incomplete mandatory finding data was rejected, yielding zero promoted findings, one provenance error, and terminal provenance mismatch; archive SHA-256 `a43deeb85eba3bcd007a968ab5fdac1af0de4507067e97a95718a7239b0b0bde`.

33. **Independent validation:** zero errors. It imported neither successor oracle nor matrix/finding/disposition helpers and independently validated contracts, matrices, compatibility, finding counts, dispositions, capsules, terminal closure, and no-VCS posture.

34. **Source freeze:** 13 successor sources frozen after all pre-freeze checks; freeze SHA-256 `4499813d2fcf486cca83309863535fee5ec9e85af9921151e75416817177f903`. Reopened no-follow and unchanged afterward. See [source freeze](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/opening/successor-audit-source-freeze-v2.json).

35. **PYZ-v3 Builds A/B:** byte-identical, each size `14537525`, SHA-256 `60b62e1e41a79c7b154f50aad34a451c26f819eb7eecf127999026791ced25db`.

36. **Successor member closure:** 84 members; sorted raw UTF-8 names, `ZIP_STORED`, fixed timestamp, `create_system=3`, member mode `0600`; zero duplicate, unsafe, directory, symlink, special, cache, bytecode, comment, uncontrolled, or historical-source members.

37. **Authority-v3 Builds A/B:** byte-identical, size `28318`, SHA-256 `f4adc99efe033cbdbfdd28a2970d215f6bd0c7e9f0bbbe21d3fcf219cc79ae26`.

38. **Post-package qualification:** exact final PYZ executed once in qualification mode with authority v3; exit `0`, empty stderr, `QUALIFICATION_PASS`, 984 matrix cases, 907 historical rows, 946 compatibility rows, and five rehearsal links.

39. **Profile-v5 Builds A/B:** byte-identical, size `14417`, SHA-256 `ab682c027344ea98fcd78d3494d1a4f503a3ef6d337db5dc56bbd5750937ffa3`. Interpreter, isolation, split-root lifecycle, cwd, five-row environment, stdin, shell, TTY, detachment, preflight, framing, and consumption controls remain unchanged.

40. **Certificate-v6 Builds A/B:** byte-identical, size `18164`, SHA-256 `063c5c3bd57840bdeec550ff17e19c7134961f6df4126a1383853526d77b4894`.

41. **Certificate-input validation:** all 13 independent checks passed, including artifact identities, fixed inputs, preserved launch controls, consumed predecessor authority, exactly one successor authorization, and no promotion/rebinding.

42. **Frozen-package requalification:** exit `0`, empty stderr; package/source authentication, projection closure, historical regression, compatibility linkage, prior qualification, rehearsal linkage, and authority coherence passed.

43. **Current authority registry:** exactly one current artifact exists for each successor role, with zero ambiguity. All predecessor roles are historical. See [role registry](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/contract/current-successor-audit-authority-role-registry-v2.json).

44. **Authorization:** predecessor active count `0`; successor unconsumed count `1`; total active future real-audit authorization count `1`.

45. **Input closing equality:** all six fixed files and seven supplied roots matched their opening identities/inventories. See [closing equality](/private/tmp/ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-bp2xun9u/closing/supplied-input-closing-equality-v1.json).

46. **Cleanup:** seven disposable targets were inventoried, removed, and observed absent twice; cleanup-set equality passed. No process, descriptor, cache, or bytecode survivor remains.

47. **Real subject audit:** not executed in this task.

48. **Subject verdict:** not issued. No current schema authority was promoted or rebound.

49. **Final PYZ v3:** [gen2-replacement-schema-subject-independent-audit-v3.pyz](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit-v3.pyz) — inode `182836502`, mode `0400`, size `14537525`, SHA-256 `60b62e1e41a79c7b154f50aad34a451c26f819eb7eecf127999026791ced25db`.

50. **Final authority v3:** [gen2-replacement-schema-subject-independent-audit.authority-v3.json](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.authority-v3.json) — inode `182836506`, mode `0400`, size `28318`, SHA-256 `f4adc99efe033cbdbfdd28a2970d215f6bd0c7e9f0bbbe21d3fcf219cc79ae26`.

51. **Final profile v5:** [gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json) — inode `182836514`, mode `0400`, size `14417`, SHA-256 `ab682c027344ea98fcd78d3494d1a4f503a3ef6d337db5dc56bbd5750937ffa3`.

52. **Final certificate v6:** [gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-bjm8ily7/gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json) — inode `182836518`, mode `0400`, size `18164`, SHA-256 `063c5c3bd57840bdeec550ff17e19c7134961f6df4126a1383853526d77b4894`.

53. **Remaining uncertainty/nonclaims:** this establishes harness readiness only. It does not predict or issue the next real audit’s subject verdict. The one successor authorization remains unconsumed. No product/runtime, target audit, deployment, publication, schema-authority promotion, or A6 work was performed.

54. **Explicit confirmations — all true:**

```text
PREDECESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED
PREDECESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED
CONSUMED_PROFILE_V4_IDENTITY_MATCHED
CONSUMED_CERTIFICATE_V5_IDENTITY_MATCHED
PREDECESSOR_REAL_AUDIT_AUTHORIZATION_CONSUMED
FAILED_REAL_AUDIT_WRAPPER_AUTHENTICATED
FAILED_REAL_AUDIT_CAPSULE_AUTHENTICATED
RAW_SUBJECT_AUDIT_BLOCK_RETAINED_AS_NONPROMOTABLE
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_AUDIT_SOURCE_ADOPTED_BYTE_IDENTICAL
EXACT_946_PROJECTION_DEFECT_REPRODUCED
HISTORICAL_907_INVALID_FINDINGS_RETAINED
SUBJECT_946_RESULT_ROWS_PASSING_RETAINED
SUBJECT_137_RESULT_ROWS_PASSING_RETAINED
STRUCTURED_946_RESULT_SEMANTICS_FROZEN
DESCRIPTIVE_REASON_TEXT_CLASSIFIED_REPORT_ONLY
NO_PROSE_TO_REASON_CLASS_COMPARISON
NO_FUZZY_OR_SUBSTRING_REASON_CLASSIFICATION
PRIMARY_REASON_CLASS_PROJECTION_IMPLEMENTED
SECONDARY_REASON_CLASS_PROJECTION_IMPLEMENTED
DUAL_REASON_CLASS_PROJECTIONS_INDEPENDENT
AMBIGUOUS_REASON_CLASS_PRODUCES_AUDIT_PROVENANCE_FAILURE
DIRECT_FINDING_ELIGIBILITY_ENFORCED
PASSING_ROW_CANNOT_CREATE_DIRECT_FINDING
FINDING_COUNT_EQUALS_NONPASSING_ROW_COUNT
BLOCK_REQUIRES_VALID_DIRECT_FINDING
INVALID_FINDING_SCHEMA_PREVENTS_BLOCK_PROMOTION
AUDIT_DISPOSITION_DERIVED_FROM_VALID_FINDINGS
SOURCE_REPAIR_BOUNDED_TO_PROJECTION_AND_FINDING_SURFACES
ALL_UNRELATED_FUNCTIONS_AST_IDENTICAL
OUTCOME_PROJECTION_MATRIX_PASSED
HISTORICAL_907_ROW_REGRESSION_PASSED
REPLACEMENT_SUBJECT_946_COMPATIBILITY_COMPLETED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
PRIOR_SEMANTIC_QUALIFICATION_PRESERVED
PACKAGED_ACCEPT_REHEARSAL_PASSED
PACKAGED_DIRECT_946_BLOCK_REHEARSAL_PASSED
PACKAGED_AMBIGUOUS_REASON_PROVENANCE_REHEARSAL_PASSED
HISTORICAL_PROJECTION_REGRESSION_REHEARSAL_PASSED
FINDING_SCHEMA_FAILURE_REHEARSAL_PASSED
INDEPENDENT_SUCCESSOR_VALIDATION_PASSED
SUCCESSOR_SOURCE_FROZEN
SUCCESSOR_SOURCE_NOT_MODIFIED_AFTER_FREEZE
SUCCESSOR_AUDIT_PYZ_V3_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_AUDIT_PYZ_V3_MEMBER_CLOSURE_PASSED
SUCCESSOR_RUNTIME_AUTHORITY_V3_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
SUCCESSOR_PROFILE_V5_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_V6_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_SUCCESSOR_PYZ_V3_REQUALIFICATION_PASSED
CURRENT_SUCCESSOR_AUTHORITY_REGISTRY_COMPLETE
EXACTLY_ONE_ACTIVE_FUTURE_REAL_AUDIT_AUTHORIZATION
PREDECESSOR_AUTHORIZATION_NOT_REUSED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

No follow-on execution was performed.
