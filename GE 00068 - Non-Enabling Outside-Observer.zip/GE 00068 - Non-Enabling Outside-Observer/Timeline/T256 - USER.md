Here is Codex's response:

## 1. Primary verdict

`REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_V2_READY_FOR_FRESH_AUDIT`

The corrected shared-root contract, four-causal matrix, complete eight-command replay, source-identity checks, cleanup gate, supplied-root closing equality, and capsule closure all passed. Independent audit remains intentionally pending.

## 2. Opening candidate and supplied-root identities

Candidate:

- Root: `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
- Device/inode/mode: `16777234 / 122118502 / 0755`
- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream: absent
- Governed files: `389`
- Tracked/untracked: `375 / 14`
- Modified: `22`
- Staged/deleted/renamed/unmerged: `0 / 0 / 0 / 0`
- F source T: `f276536fea579d0842cda43b0290656b200b7f27`
- F inventory: `54314` bytes, SHA-256 `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`
- Index: device/inode `16777234 / 177958951`, size `44490`, SHA-256 `b2856028ec627e9f5f07d508a08b840545750419e98ce32a869d8d7197a20d91`

Every candidate Git invocation used `git -C` with cwd equal to the candidate and the required explicit read-only environment.

Strategic B snapshot:

- Root: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2`
- Device/inode/mode: `16777234 / 178255587 / 0700`
- Fingerprint: `569` entries, `107` directories, `462` regular files, `14345062` logical bytes
- Aggregate SHA-256: `bc48896d63540b7db0cb75ade6e5c19aba525cea7dea1d8dca3ceaabf7814826`
- Final inventory: `130182` bytes, SHA-256 `fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb`
- Final report: `151150` bytes, SHA-256 `2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe`
- Both manifests: `139328` bytes, SHA-256 `df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc`; byte-identical

Blocking audit:

- Root: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9`
- Device/inode/mode: `16777234 / 178361381 / 0700`
- Fingerprint: `85` entries, `6` directories, `79` regular files, `88777822` logical bytes
- Aggregate SHA-256: `1ae5c09749d7d6bcef5a0bc4000e8561e0e193ab81df9190fe9cebd3ac97476a`
- Report: `34460` bytes, SHA-256 `b7e959a5785af954c6be556da594b39fc3c2da37e8d1b09dd775ddcae623ea65`
- Inventory: `25624` bytes, SHA-256 `d514e99ce2833bdf6bb36dc5e3b9ced3b9eb52651425f9d6057c13e5fb4a8475`
- Required verdict: `BLOCK`

Blocked V1 repair:

- Root: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf`
- Device/inode/mode: `16777234 / 178515489 / 0700`
- Fingerprint: `73` entries, `11` directories, `62` regular files, `1180971` logical bytes
- Aggregate SHA-256: `d4d947e147b2dd4ef8392d02fa20219c990f3db3f4663c9aa59d682f235c0364`

The pinned Go toolchain and the 20 exact module-cache roots used for offline seeding were also identity-recorded before use.

## 3. V2 correction-root identity

Retained capsule:

`/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra`

- Allocated with `tempfile.mkdtemp` under umask `077`
- Direct parent: `/Users/ds/Downloads`
- Device/inode: `16777234 / 178558083`
- UID/GID: `501 / 20`
- Mode: `0700`
- Parent device/inode: `16777234 / 273613`
- All retained directories are physical mode `0700`
- All retained files are regular, single-link, mode `0600`

## 4. Blocking V1 findings consumed

The historical V1 contract bound:
```
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/t
```

The sibling relationship caused both mandatory identities to fail with `is outside control root`:

- `TestRepair10ControlRootPolicyV1`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`

V1 remained immutable historical evidence and was not treated as an effective supersession.

Its fixed identities remained:

- Final inventory: `16030` bytes, SHA-256 `42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0`
- Manifests: `17363` bytes each, SHA-256 `73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498`, byte-identical
- Proposed plan V2: `28443` bytes, SHA-256 `177ea4e983a3d3eae5b23302bf5ae7ac7cf1aedaa7335027607f3e4e5ad65ea4`

## 5. Exact V2 validation-custody contract

Contract ID:

`execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2`

Bindings:
```
ES_REPAIR10_SOURCE_ROOT=${SHORT_ROOT}/s
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/r
HOME=${SHORT_ROOT}/h
GOTMPDIR=${SHORT_ROOT}/u
GOCACHE=${SHORT_ROOT}/c
GOMODCACHE=${SHORT_ROOT}/m
```

Allocation contract:

- Physical parent `/Users/ds/Downloads`
- Basename grammar `r10b-<32-lowercase-hex>`
- Exactly 16 OS-CSPRNG bytes per attempt
- Descriptor-relative, exclusive child creation at mode `0700`
- Component walk without following symlinks
- Retry only on `EEXIST`, with fresh CSPRNG material; maximum 128 attempts
- Every other error terminal; no fallback
- Parent and child descriptors held through causal and full validation
- Direct parentage, invoking UID, expected GID, stable identity, and no alias/containment with supplied roots required
- No latest-entry discovery, adoption, rename workaround, PID, counter, timestamp, or Git-hash authority
- Direct children: `s`, `h`, `u`, `c`, `m`, `r`
- No persistent `t`; the only `t` was a short-lived fixture required for the historical-negative causal and was removed before positive/full validation

## 6. Short-root allocation and identities

Allocated on the first attempt:

`/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2`

- Basename: `r10b-ce97533514f5459f258c5421b6a190e2`
- Absolute UTF-8 path length: exactly `57` bytes
- Device/inode: `16777234 / 178559839`
- UID/GID/mode: `501 / 20 / 0700`
- No symlink component
- No alias or containment overlap with the candidate, strategic snapshot, blocking audit, blocked V1 root, or retained V2 root
- `t` absent at allocation
- Direct child set at qualification: exactly `c,h,m,r,s,u`

Child identities, all device `16777234`, UID/GID `501/20`, mode `0700`:

| ChildInode |             |
| ---------- | ----------- |
| `s`        | `178559840` |
| `h`        | `178559841` |
| `u`        | `178559842` |
| `c`        | `178559843` |
| `m`        | `178559844` |
| `r`        | `178559845` |

## 7. Shared control/TMP identity proof

Both lexical bindings resolved to:

`/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r`

Proof:

- Lexical paths equal: true
- Device/inode equal: `16777234 / 178559845`
- Mode: `0700`
- `filepath.Rel(control, TMPDIR)`: `.`
- Physical equality: true
- Exact B containment predicate: satisfied
- Shared-root path length: exactly `59` bytes

## 8. Source-derived 86-byte worst-case proof

Exact sources examined:

- `internal/testsupport/controlroot.go`: SHA-256 `3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3`
- `internal/testsupport/controlroot_test.go`: SHA-256 `de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f`
- `es/runtimehelper/helper_test.go`: SHA-256 `715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0`
- Pinned `src/os/tempfile.go`: SHA-256 `a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16`

The generated component grammar is a two-byte prefix (`t.` or `s.`) plus an unsigned base-10 `uint32(runtime_rand())`, whose maximum decimal representation is 10 bytes. Therefore the maximum generated component is 12 bytes.
```
shared root       59
separator          1
generated name    12
separator          1
identity.sock     13
--------------------
maximum            86 bytes
```

Thus `59 + 1 + 12 + 1 + 13 = 86`, and `86 <= 100`. This is a grammar-derived maximum, not an observed random sample.

## 9. Long shared-root negative

Audit-owned root:

`/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra/private-long-shared-root-6mzbe8en`

- Root path length: `114` bytes
- Source-derived maximum socket path: `141` bytes
- Control root and `TMPDIR` were the same directory
- `TestRepair10ControlRootPolicyV1`: raw exit `1`, exact failure fragment `socket path exceeds 100 bytes`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`: raw exit `1`, exact failure fragment `bind: invalid argument`
- No `outside control root` error
- Control stdout: `1580` bytes, SHA-256 `21b1eb8fe3322cca6dff64d913b03ca59038b68d3f9a4120f6944d2453fb62a8`
- Runtime-helper stdout: `1822` bytes, SHA-256 `0de5aa06d91a570983cba1d32608ec28bcc06f9f0a1b2ad2b727d96017000752`
- Both stderr streams empty and complete
- Root removed successfully

## 10. Blocked V1 sibling-root negative

Bindings:
```
ES_REPAIR10_CONTROL_ROOT=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r
TMPDIR=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/t
```

Results:

- Both mandatory identities failed with exactly `is outside control root`
- Both raw exits: `1`
- No path-length or bind-length failure
- Control stdout: `1703` bytes, SHA-256 `49b9b1e1ea4ff078d27c297b98530d2a2d3f3733a0395b3c0658e5eaef6808b5`
- Runtime-helper stdout: `1819` bytes, SHA-256 `081d1cb6aa7b13618b4c472f40388035b14e9fbeaebf684828921722702884d7`
- Both stderr streams empty and complete

The causal-only `t` fixture, inode `178572736`, was removed immediately. Two `lstat` observations returned `ENOENT` at `1789867496433665000` and `1789867496433686000` ns. The exact V2 child set was restored before the corrected positive and full validation.

## 11. Corrected V2 shared-root positive

Bindings:
```
ES_REPAIR10_CONTROL_ROOT=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r
TMPDIR=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r
```

Results:

- `TestRepair10ControlRootPolicyV1`: pass, raw exit `0`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`: pass, raw exit `0`
- No skips
- No socket path above 100 bytes
- Control stdout: `1308` bytes, SHA-256 `de3fd19c0d04a7fff2d2a27c1769c81ac20384bea70b03e1e56854a5d60d9bf1`
- Runtime-helper stdout: `1410` bytes, SHA-256 `1c5a0d560d1a25a2c3654e84c52d68c3f00f69087ea1acc8e8ad43a7cd560429`
- Both stderr streams empty and complete
- Shared generated-state directory empty afterward
- `t` absent
- Private Git state clean
- Exact B source T, inventory, and tree unchanged

## 12. 100/101 boundary causal

A separate exact-B copy was placed under the transient `u` subtree. The retained same-package audit-only harness is:

`provenance/boundary_harness_test.go`

- Size: `895`
- SHA-256: `0c36a125e8262c2f617cb740685a7faddfa218fc15f5646a96301f3741ecf7db`
- Exact source predicate exercised: `len([]byte(filepath.Join(dir, leaf))) <= 100`
- Complete path of `100` bytes: admitted
- Complete path of `101` bytes: rejected
- Rejection occurred before socket bind or process launch
- `TestAuditValidationCustodyBoundary100And101V2`: pass, raw exit `0`
- Stdout: `1391` bytes, SHA-256 `84bae37f7351d732651dcd8a3b7f0ac325afd0f3b5a2a05ef55604880d89fb3c`
- Stderr: empty
- Separate B copy removed
- Primary B materialization unchanged
- The harness was not counted as product or B validation

## 13. Validation-plan V1/V2/V3 lineage

- Base strategic-snapshot validation plan:
  - Historical source plan
  - Size `28615`
  - SHA-256 `b8627359a3df382d8a9d9bb40b03c3e864f632304581bb614557ab36a74fa8ad`
- Blocked custody V1 / proposed plan V2:
  - Historical, non-effective sibling-root plan
  - Size `28443`
  - SHA-256 `177ea4e983a3d3eae5b23302bf5ae7ac7cf1aedaa7335027607f3e4e5ad65ea4`
- Validation-custody V2 / validation plan V3:
  - Proposed effective correction pending fresh independent audit
  - Size `28590`
  - SHA-256 `fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee`

Plan V3 preserves all eight labels, order, argv semantics, pinned tools, expected exits, and identity policies. It changes only generated-state custody to the shared `${SHORT_ROOT}/r` binding. It contains typed `${SHORT_ROOT}` parameters and does not make the producer’s random root future authority.

## 14. Proof B source/tree identities remained unchanged

The transient primary B materialization was physically separate and had no inode aliases with supplied roots.

Before, after each command, and after all validation:

- Governed files: `389`
- Source T: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Inventory: `54314` bytes, SHA-256 `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- Git tree: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Synthetic commit: `e42aac659299e023df07a842df17e9fc84a135c1`
- Synthetic parent: `567bceced5df95ecfe787cc66038d463a854e12c`
- Synthetic subject: `implement Remote Alpha external TLS T2A-P source`
- H→B: `22 modified, 14 added, 0 deleted, 0 renamed`
- Private Git state: clean before and after every owning command

## 15. Exact eight commands, environment, and outcomes

All commands used cwd:

`/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/s`

Exact common environment:
```
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
HOME=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/h
TMPDIR=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r
GOTMPDIR=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/u
GOCACHE=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/c
GOMODCACHE=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/m
ES_REPAIR10_SOURCE_ROOT=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/s
ES_REPAIR10_CONTROL_ROOT=/Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/r
GOROOT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64
GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

The pinned Go binary SHA-256 was `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`.

The following are shell-escaped renderings of the exact argv arrays:
```
1. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version

2. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw . -run '^(TestDocsRemoteAlphaOperatorFacadeBoundaries|TestDocsRemoteAlphaOperatorP0cFirstDelegationBoundary|TestGo1265ToolchainBaselineDocsAndBuildContract|TestGoldenProducerProofPathIsDocumented|TestHybridIntegrationArchitectureADRDocsContract|TestHybridIntegrationBridgeCodexRowPinsEvidenceBoundary|TestMilestone1BoundaryPostureMatrixIsDocumented|TestMilestone1LeastPrivilegeBoundaryCloseoutIsDocumented|TestPrimaryMilestoneRealignmentPreservesESOwnership|TestProducerFailurePathDistinctionsAreDocumented|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestRemoteAlphaExternalTLSIncidentCompatibilityAndMigration|TestRemoteAlphaExternalTLSLifecycleCurrentAndTargetContract|TestRemoteAlphaExternalTLSLifecycleHasExactPolicyCoreConsumer|TestRemoteAlphaExternalTLSLifecyclePlanningAndBoundaryAlignment|TestRemoteAlphaExternalTLSLifecycleRejectsTargetWidening|TestRemoteAlphaExternalTLSLifecycleSecurityAndOwnership|TestRemoteAlphaExternalTLSPolicyCoreDocumentationContract|TestRemoteAlphaExternalTLSRestorationAndChat00054Boundary|TestRemoteAlphaExternalTLSStatusObservationV1Contract|TestRemoteAlphaExternalTLSStatusT2APackageAndFacadeContract|TestRemoteAlphaExternalTLST2APCurrentTargetMatrixV1|TestRemoteAlphaExternalTLST2APRepair10Contract|TestRemoteAlphaExternalTLST2APRepair5LifecycleOrderV1|TestRemoteAlphaExternalTLST2APRepair7Contract|TestRemoteAlphaExternalTLST2APRepair8Contract|TestRemoteAlphaExternalTLST2APRepair9Contract|TestRemoteAlphaMaintenanceMonitorBoundaryAndRouteMatrix|TestRemoteAlphaOperatorDocsInvolvementAndP0dEvidenceBoundaries|TestRemoteAlphaOperatorHealthcheckTLSCompanionDocsCurrentAndTargetSeparation|TestRemoteAlphaOperatorP0dDocsFirstDelegationBoundary|TestRemoteAlphaOperatorP0fDocsReadinessSessionBoundary|TestRemoteAlphaOperatorP0gDocsRecoverySessionBoundary|TestRemoteAlphaOperatorP0hDocsSchemaAwareRecoveryEvidenceBoundary|TestRemoteAlphaOperatorP0iDocsHostLocalUnsealBoundary|TestRemoteAlphaOperatorP0jDocsMacSideUnsealBoundary|TestRemoteAlphaOperatorP0kDocsMacSideResetDryRunBoundary|TestRemoteAlphaOperatorP0lDocsMacSideResetExecuteContractPrep|TestRemoteAlphaOperatorP0mDocsMacSideResetExecuteImplementationBoundary|TestRemoteAlphaOperatorP0nDocsMacSideWorkloadAuthCheckBoundary|TestRemoteAlphaOperatorP0oDocsVaultWorkloadAuthBootstrapPlanningBoundary|TestRemoteAlphaOperatorP0pDocsVaultWorkloadAuthBootstrapExecutionContractPrep|TestRemoteAlphaOperatorP0qDocsVaultWorkloadAuthBootstrapExecutionRoute|TestRemoteAlphaOperatorP0rDocsRuntimeIdentitySummaryRoute|TestRemoteAlphaOperatorP0sDocsESServiceTLSRenewRoute|TestRemoteAlphaOperatorP0tDocsESGovernanceTLSRenewRoute|TestRemoteAlphaOperatorP0uDocsOperatorHealthcheckTLSRenewRoute|TestRemoteAlphaOperatorP0vCompanionDocsCurrentStatusAlignment|TestRemoteAlphaOperatorP0vDocsOperatorHealthcheckTLSNoninteractiveStatusDesign|TestRemoteSupportedHostAlphaAGSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaARSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaDirectBoundaryIsDocumented|TestRemoteSupportedHostAlphaDoctorVocabularyIsDocumented|TestRemoteSupportedHostAlphaEGSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaESBinaryDeploymentOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESConfigTLSPrepOperatorStagingFlowIsDocumented|TestRemoteSupportedHostAlphaESConfigTLSPrepSliceIsDocumented|TestRemoteSupportedHostAlphaESServiceUserMigrationOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESServiceUserRollbackRehearsalIsDocumented|TestRemoteSupportedHostAlphaESWritableStateOwnershipOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESWritableStateReadinessOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaNormalShellRuntimeImageSummarySchemaIsDocumented|TestRemoteSupportedHostAlphaRuntimeSecurityBoundaryCheckerIsDocumented|TestRemoteSupportedHostAlphaSupportBundleSummarySectionsAreDocumented|TestRemoteSupportedHostAlphaVaultServiceUserMigrationSurfaceIsDocumented|TestRemoteSupportedHostAlphaVaultWorkloadAuthSummarySchemaIsDocumented|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries|TestSystemOverviewAuthorityHeadersFollowRepoHierarchy|TestWorkstreamASharedKernelDecisionIsDocumented|TestWorkstreamB0ArtifactBoundaryGateIsDocumented|TestWorkstreamB1ArtifactBoundaryGuardrailPostureIsDocumented|TestWorkstreamBArtifactCompatibilityEdgesStayConsistent|TestWorkstreamBArtifactPublicationStorageDecisionIsDocumented|TestWorkstreamC0BoundarySurfaceAssertionsAreDocumented|TestWorkstreamC0ExecutionOwnershipGateIsDocumented|TestWorkstreamC0ExternalAuthorityAndEvidenceNonOwnershipIsDocumented|TestWorkstreamC1PrepareAdmissionGuardrailPostureIsDocumented|TestWorkstreamC2SubmitLifecycleProjectionGuardrailPostureIsDocumented|TestWorkstreamC3RetainedResultAuthorityHandoffGuardrailPostureIsDocumented|TestWorkstreamC4RuntimeIdentityVaultHandoffGuardrailPostureIsDocumented|TestWorkstreamC5StatusLogsResultCancelCompatibilityGuardrailPostureIsDocumented|TestWorkstreamC6AdmissionPolicyLayerV0ContractIsDocumented|TestWorkstreamC6AdmissionPolicyNonClaimsAreDocumented|TestWorkstreamC6ConfigurableAdmissionPolicyInputsAreDocumented|TestWorkstreamC7CheckpointDocsContract|TestWorkstreamCESExecutionAdmissionModelDecisionIsDocumented|TestWorkstreamCLifecycleProjectionAuthorityLabelsAreDocumented|TestWorkstreamCProducerContractPrepareBoundaryTestsAreDocumented|TestWorkstreamCResultSurfaceClassificationStaysConsistent|TestWorkstreamCRetainedResultBundleClarificationIsDocumented|TestWorkstreamCRuntimeProfileBoundaryStaysNarrow|TestWorkstreamCRuntimeProfileCompatibilityMatrixIsDocumented|TestWorkstreamD1bCGSV2AuthorizeContractDesignIsDocumented|TestWorkstreamD1cEGSVersionedRuntimeTrustWrapperDesignIsDocumented|TestWorkstreamD1dIDConfCompatibilityDowngradeIsDocumented|TestWorkstreamDPolicyAuthorizationBoundaryClarificationIsDocumented|TestWorkstreamDVersioningGuardrailBeforeSemanticExpansionIsDocumented|TestWorkstreamERuntimeConfigOwnershipDecisionIsDocumented|TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal|TestWorkstreamFRuntimeIdentityHandoffOwnershipDecisionIsDocumented|TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal)$' -count=1 -p=1 -parallel=1 -json

3. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./internal/testsupport -run '^(TestRepair10ControlRootPolicyV1|TestRepair10OwnedProcessLifecycleV1|TestRepair10SignalBirthMismatchNeverSignalsV1)$' -count=1 -p=1 -parallel=1 -json

4. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./es/externaltls/... -count=1 -p=1 -parallel=1 -json

5. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw . -run '^(TestRemoteAlphaPrepareExternalTLSStatusDirectExecEnvironmentForwardingAndFailuresV3|TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2|TestRemoteAlphaPrepareExternalTLSStatusParseSafeDirectStartupBoundary|TestRemoteAlphaPrepareExternalTLSStatusPreGoResiduePreservationAndNoShellCleanupV3|TestRemoteAlphaPrepareExternalTLSStatusWrapperExactGrammar|TestRemoteAlphaT2APRepair10CClosingConfigAndSourceSessionActualFlowV9|TestRemoteAlphaT2APRepair10ExactBlobSizeAndLongListingCausalV8|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7|TestRemoteAlphaT2APRepair10ShellConfigLeafBracketCausalV7|TestRemoteAlphaT2APRepair10ShellPrivateReaderCausalV7|TestRemoteAlphaT2APRepair9SequentialSixCallerPrivateSlotNamespacesV6|TestRemoteAlphaT2APRepair9ShellObjectBoundaryTimestampDigestV6|TestRemoteAlphaT2APRepair9ShellPackedLooseDirectoryPrefixCaseFoldV6|TestRemoteAlphaT2APShellGitTopologyResolutionAndZeroObjectSentinelV5|TestRemoteAlphaT2APShellLexicalDirectoryGateV4|TestRemoteAlphaT2APShellRawRefGrammarConformanceV5|TestRemoteAlphaT2APShellSingleAlternateColonDecoyV5|TestRepair10IDualSetpgidRaceReconciliationV1|TestRepair10ISetpgidFailureRequiresExactGroupProofV1|TestRepair10ISetpgidInverseMutantsV1)$' -count=1 -p=1 -parallel=1 -json

6. /Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./es/admission ./es/admission/internal/reliablesubmit ./es/app ./es/runtimehelper -run '^(TestExecutionWorkspaceTempDirUsesControlRoot|TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir|TestNomadHarnessProcessCustodianFixtureV1|TestNomadHarnessProcessCustodianWithoutServiceV1|TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention|TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess|TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath|TestValidateExecutionRuntimeInputsRejectsNonRegularBinary|TestWaitForHelperReadinessReturnsWhenEndpointServesJWT)$' -count=1 -p=1 -parallel=1 -json

7. /bin/bash -n scripts/remote_alpha_prepare_external_tls_status.sh scripts/remote_alpha_operator.sh

8. git -C /Users/ds/Downloads/r10b-ce97533514f5459f258c5421b6a190e2/s diff --check 567bceced5df95ecfe787cc66038d463a854e12c e42aac659299e023df07a842df17e9fc84a135c1 --
```

All signals were null, all streams were complete, and every stderr was empty with SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| #IDExitStdout bytes / SHA-256Generated-state inventory bytes / SHA-256 |                                  |             |                                                                                |                                                                                |
| ---------------------------------------------------------------------- | -------------------------------- | ----------- | ------------------------------------------------------------------------------ | ------------------------------------------------------------------------------ |
| 1                                                                      | `go-version`                     | 0           | `33` / `278375c8a03c34bb0f855154850de7c4f217fd3b8cdf37986819e3f05d0a4c33`      | `1524401` / `e826be316c5b762713449c22d9d858dda59ca5ff9ad4073ec5efcf2d8c133a73` |
| 2                                                                      | `complete-docs-105`              | 0           | `171315` / `b81701b9056b5a557b72b22de1fd236548e0d00a1aad3c896472469991b8adfa`  | `1534336` / `7ade1098b282f20d5de8863e634e581120186a16d1aea0a037a1bd483d7f0337` |
| 3                                                                      | `testsupport-acceptance`         | 0           | `12451` / `5bb4ac63648eed55bccbf705ed1f913ac7d5ec9c84e5eb0d5d8f5274f55df6d8`   | `1534336` / `6d60f97f4f5917e2a25de08d06aec6c0d5cd8ff7644d1a029d43d19789e11884` |
| 4                                                                      | `external-tls-all`               | 1, accepted | `1481578` / `470ea0d669269e403605a499fc3efb825e77874fab0fa3187540540a23cea752` | `1633170` / `0545a1dea4eae0d54851040eabbb615fc41f89cd9424f05773410faaff227b34` |
| 5                                                                      | `repair10-current-affected-pass` | 0           | `149695` / `94b59c8adba718240ea1c0d1c99d42a8fefc86117ec73fbaee58174fdda2eaa2`  | `1633170` / `8781249c0413808df4b8772e1c9b51cdad1af3d0bd3c7e3850a56b3bdcbcfa00` |
| 6                                                                      | `changed-nonroot-product-tests`  | 0           | `10472` / `a59ba0d81334e187b5ea6f99cda2a2778562860b10eef50e09de0fd952c49377`   | `3012990` / `1ebb55b70eadc29caf71ea2b89073879022904db9f163cdb4124fe952be281a8` |
| 7                                                                      | `bash-syntax`                    | 0           | empty                                                                          | `3012990` / `1ebb55b70eadc29caf71ea2b89073879022904db9f163cdb4124fe952be281a8` |
| 8                                                                      | `private-git-diff-check`         | 0           | empty                                                                          | `3012990` / `1ebb55b70eadc29caf71ea2b89073879022904db9f163cdb4124fe952be281a8` |

## 16. Exact pass/fail/skip adjudication

- `go-version`: exact stdout `go version go1.26.5 darwin/arm64\n`.
- `complete-docs-105`: all exact 105 top-level identities passed; 179 total pass terminals including subtests; zero fail or skip.
- `testsupport-acceptance`: the three required top-level identities passed; 13 total pass terminals including subtests; zero fail or skip.
- `external-tls-all`: 1361 pass terminals, exactly one allowed failure, and exactly four allowed skips.
  - Failure: `execution-substrate/es/externaltls/internal/statuspackage::TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2`
  - Required mechanism present: `lifetime_lock_identity_invalid`
  - Skips:
    - `TestPrivateExactCandidateCompilerInputOracleAndOmissionsV2`
    - `TestPrivateExactCandidateDeterministicPreparationAndReuseV2`
    - `TestRepair10ECombinedErrorExactCloseCardinalityV2`
    - `TestRepair10PublishedStageCombinedErrorRealPreparationV2`
- `repair10-current-affected-pass`: all exact 20 top-level identities passed; 162 total pass terminals including subtests; zero fail or skip.
- `changed-nonroot-product-tests`: exact eight required passes:
  - `TestExecutionWorkspaceTempDirUsesControlRoot`
  - `TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir`
  - `TestNomadHarnessProcessCustodianWithoutServiceV1`
  - `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`
  - `TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess`
  - `TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath`
  - `TestValidateExecutionRuntimeInputsRejectsNonRegularBinary`
  - `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`
  - Exact governed skip: `TestNomadHarnessProcessCustodianFixtureV1`, reason `private custodian fixture only`
- `bash-syntax`: exit `0`, empty stdout and stderr.
- `private-git-diff-check`: exit `0`, empty stdout and stderr.

Across the complete plan there were no unexpected failures, skips, errors, panics, malformed events, duplicate/missing terminal histories, timeouts, or incomplete streams.

## 17. Failed or superseded attempts

- Complete eight-command plan attempted: true
- Producer validation attempts excluded from qualification: none
- Failed/superseded attempt array: empty
- The four causal executions are retained separately and all satisfied their expected classifications
- The expected long-root and sibling-root negatives were not misclassified as producer-validation failures
- Historical V1/V2 custody results remain historical and non-effective

## 18. V2 capsule authority and nonauthority

This work is a source-external bounded validation/proof refinement. It did not revise repository architecture or B source.

The capsule may claim:

- Short-root allocation semantics
- Exact shared control/TMP identity
- Source-derived path budget
- Validation-plan V3 custody and environment
- Fresh observed validation results
- Narrow supersession of blocked custody plans/results, pending independent audit

It does not claim:

- New B source, mode, origin, inventory, tree, or synthetic-commit authority
- Publication or commit authority
- Current repository truth for B
- Product, runtime, installation, deployment, or A6 readiness
- Semantic-successor or orchestrator implementation
- Hostile/shared-host, symlink, bind-mount, or mount authority

The strategic B snapshot remains the sole B source/provenance package.

## 19. Artifact and sensitive-material findings

- No credential or secret material observed
- No governed repository artifact created
- No installation or deployment
- No network contact
- No product or live service invocation
- No retained competing copy of all 389 B files
- Primary and boundary B materializations removed
- Retained harness classified audit-only, not B or product validation
- Retained content classified as non-authoritative validation evidence and replay source
- Offline module-cache seed: 20 modules, 80 exact objects, network unused
- No symlink, socket, FIFO, device, special object, multiply linked file, or Python bytecode remained in the capsule

## 20. Cleanup and two ENOENT observations

All 15 task-launched process IDs were reaped; no launched-process or path-process survivor remained.

During cleanup, macOS `mdworker` processes temporarily held read descriptors inside the private module cache. Seven bounded observations recorded those external descriptors. The eighth observation contained zero matching lines. Final descriptor survivors were empty before removal.

The transient root, device/inode `16777234 / 178559839`, was removed without chmod changes. No task-owned `r10b-*` sibling remained.

Two fresh `lstat` observations returned `ENOENT`:

- Observation 1: `1789867681584160000` ns
- Observation 2: `1789867681632965000` ns

A final read-only check also confirmed absence of the short root, long-root causal directory, and boundary-copy directory.

## 21. Candidate and supplied-root closing equality

All closing comparisons passed:

| ObjectOpening aggregate/identityClosing result |                                                                                     |                |
| ---------------------------------------------- | ----------------------------------------------------------------------------------- | -------------- |
| Candidate                                      | Branch, HEAD, tree, parent, status counts, source T, inventory, index identity/hash | Exact equality |
| Strategic B snapshot                           | `bc48896d63540b7db0cb75ade6e5c19aba525cea7dea1d8dca3ceaabf7814826`                  | Exact equality |
| Blocking audit                                 | `1ae5c09749d7d6bcef5a0bc4000e8561e0e193ab81df9190fe9cebd3ac97476a`                  | Exact equality |
| Blocked V1 repair                              | `d4d947e147b2dd4ef8392d02fa20219c990f3db3f4663c9aa59d682f235c0364`                  | Exact equality |
| Pinned Go and named module-cache provenance    | Per-object identity records                                                         | Exact equality |

The candidate index retained the same device/inode, size, timestamps, mode, and SHA-256. No supplied-root drift was found.

## 22. Complete retained membership and manifest identities

Actual retained membership is 12 directories and 90 regular files. The two manifests self-exclude, so each canonical manifest represents 12 directories plus 88 nonmanifest files: 100 entries.

Complete relative membership:
```
.
causals/
  blocked-v1-sibling-root-negative.json
  corrected-v2-shared-root-positive.json
  long-shared-root-expected-negative.json
  path-budget-boundary.json
  logs/
    blocked-v1-sibling-control-root.stderr
    blocked-v1-sibling-control-root.stdout
    blocked-v1-sibling-runtimehelper.stderr
    blocked-v1-sibling-runtimehelper.stdout
    corrected-v2-shared-control-root.stderr
    corrected-v2-shared-control-root.stdout
    corrected-v2-shared-runtimehelper.stderr
    corrected-v2-shared-runtimehelper.stdout
    long-shared-control-root.stderr
    long-shared-control-root.stdout
    long-shared-runtimehelper.stderr
    long-shared-runtimehelper.stdout
    path-budget-boundary-100-101.stderr
    path-budget-boundary-100-101.stdout
closeout/
  absence-observation-1-v1.json
  absence-observation-2-v1.json
  artifact-and-sensitive-material-findings-v1.json
  blocked-v1-repair-closing-inventory.jsonl
  blocking-audit-closing-inventory.jsonl
  cleanup-v1.json
  closing-equality-v1.json
  final-evidence-inventory-v1.json
  final-implementation-report-v1.md
  strategic-snapshot-closing-inventory.jsonl
contract/
  path-budget-v2.json
  short-root-allocation-v2.json
  strategic-b-validation-custody-v2.json
  validation-plan-supersession-v2.json
  validation-plan-v3.json
manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json
opening/
  blocked-v1-repair-binding.json
  blocked-v1-repair-full-inventory.jsonl
  blocking-audit-binding.json
  blocking-audit-full-inventory.jsonl
  candidate-and-supplied-root-identities.json
  other-named-provenance-identities.json
  strategic-snapshot-binding.json
  strategic-snapshot-full-inventory.jsonl
  v2-correction-root-identity.json
provenance/
  B-source-inventory.txt
  allocator_v2.py
  boundary_harness_test.go
  build_v2_capsule.py
  cleanup.py
  exact-B-materialization.json
  exact_b_materializer.py
  module-cache-seed.json
  path_budget_checker_v2.py
  source-hashes.json
  validation_runner.py
validation/
  failed-and-superseded-attempt-index-v1.json
  identity-level-result-summary-v3.json
  validation-summary-v3.json
  commands/
    bash-syntax.json
    changed-nonroot-product-tests.json
    complete-docs-105.json
    external-tls-all.json
    go-version.json
    private-git-diff-check.json
    repair10-current-affected-pass.json
    testsupport-acceptance.json
  generated-state/
    bash-syntax.jsonl
    changed-nonroot-product-tests.jsonl
    complete-docs-105.jsonl
    external-tls-all.jsonl
    go-version.jsonl
    private-git-diff-check.jsonl
    repair10-current-affected-pass.jsonl
    testsupport-acceptance.jsonl
  logs/
    bash-syntax.stderr
    bash-syntax.stdout
    changed-nonroot-product-tests.stderr
    changed-nonroot-product-tests.stdout
    complete-docs-105.stderr
    complete-docs-105.stdout
    external-tls-all.stderr
    external-tls-all.stdout
    go-version.stderr
    go-version.stdout
    private-git-diff-check.stderr
    private-git-diff-check.stdout
    repair10-current-affected-pass.stderr
    repair10-current-affected-pass.stdout
    testsupport-acceptance.stderr
    testsupport-acceptance.stdout
```

Closure identities:

- Final evidence inventory: `22990` bytes, SHA-256 `c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658`
- Final retained report: `1355` bytes, SHA-256 `9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd`
- Canonical manifest A: `24408` bytes, SHA-256 `2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628`
- Canonical manifest B: `24408` bytes, same SHA-256
- Manifest pair byte-identical: true
- Empty directories: none
- Non-`0700` directories: none
- Non-`0600` files: none
- Symlink/special entries: none
- Multiply linked files: none
- Only the two manifests are self-excluded

## 23. Remaining uncertainty

The capsule contains producer implementation and validation evidence, not an independent audit. A fresh auditor must independently allocate a conforming short root, replay the contract and plan, and decide whether the proposed supersession becomes effective.

The producer’s random short-root path is historical evidence only. The expected `external-tls-all` failure and four governed skips remain present exactly as inherited; this custody repair does not resolve or reclassify them. No live-service, deployment, hostile-host, semantic-successor, orchestrator, or A6 conclusion is claimed.

## 24. Explicit confirmations
```
CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
CONTROL_ROOT_AND_TMPDIR_SHARED_EXACT_PHYSICAL_DIRECTORY
SHORT_TRANSIENT_ROOT_ALLOCATED
SHORT_TRANSIENT_ROOT_REMOVED
TWO_ABSENCE_OBSERVATIONS_COMPLETED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
SUBAGENTS_CREATED: 0
```
