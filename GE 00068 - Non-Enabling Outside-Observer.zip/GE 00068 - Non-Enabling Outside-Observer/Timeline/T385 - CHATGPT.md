## Assessment

This is another **process-provenance failure before package construction**, not a package, target, metadata, or qualification defect.

The latest attempt established several useful negatives:

- No semantic export was written.
- Neither failed retry root was opened.
- No historical tool or output was reused.
- The real target audit did not run.
- No repository, product, network, Git, deployment, or A6 effect occurred.

The concrete blocker is narrower: **the construction parent was executed before its executable-origin registry and child-process ledger were fully implemented and frozen.** Retaining and hashing the parent source was necessary but insufficient. The provenance mechanism had to exist completely before that source was allowed to run.

We should not retry package construction again yet. That would keep mixing two separate activities:

1. qualifying the process envelope that can safely perform construction; and
2. performing the metadata repair and package construction.

The next tranche should qualify and freeze the construction parent itself. It must run only a dedicated process self-test—not package construction. Once that source is accepted, the following task can execute its exact `construct` mode once.

## Prompt for Codex

```text
BOUNDED RECONCILIATION, REPAIR, QUALIFICATION, AND FREEZE OF THE
TARGET-AUDIT HARNESS PACKAGE-CONSTRUCTION PARENT

This task qualifies the finite construction parent and its process-custody
mechanism before any package construction is permitted.

It is not:

- a target-audit harness package retry;
- semantic export construction;
- metadata repair;
- a target audit;
- runtime validation;
- a repository or product task.

Do not write any target-audit semantic export.
Do not create a current target-audit harness package.
Do not execute the construction path.
Do not run the real target audit.
Do not execute Plan V3 or Plan V4.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT FAILED PROCESS-CLEAN RETRY
──────────────────────────────────────────────────────────────────────────────

FAILED_PROCESS_CLEAN_RETRY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-y3vg_lqk

Expected retained verdict:

PREFLIGHT_PROVENANCE_MISMATCH

The supplied report states:

- the fresh construction parent was retained and hash-bound;
- the complete executable-origin implementation was not completed before
  execution;
- the complete process-ledger implementation was not completed before
  execution;
- package construction did not begin;
- no semantic export was written;
- neither prior failed retry root was opened;
- no historical tooling or output was reused.

Treat this root as immutable process-failure evidence.

Do not:

- resume it;
- modify it;
- clean it;
- execute a retained tool from it;
- import its Python source;
- adopt any partial package state;
- promote any retained result.

It may be opened read-only only to authenticate and recover the exact failed
construction-parent source and process failure evidence.

Require complete opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
2. LOCATE THE EXACT FAILED CONSTRUCTION PARENT
──────────────────────────────────────────────────────────────────────────────

Within the exact failed root, enumerate retained files using lstat/no-follow.

Identify the construction parent only through explicit retained records such as:

- bootstrap-start;
- source-identity record;
- executable-origin record;
- process start/outcome;
- failure record;
- final report;
- retained inventory.

Do not select by:

- filename alone;
- basename scoring;
- content scoring;
- latest entry;
- first viable file;
- prefix scan;
- fallback.

Retain:

opening/failed-parent-candidate-ledger-v1.json

For every candidate record:

- relative path;
- size;
- SHA-256;
- mode;
- link count;
- declared role;
- producer;
- intended invocation;
- whether it was executed;
- whether it wrote files;
- whether it launched children;
- current-authority eligibility.

Require exactly one source explicitly bound as the failed construction parent.

If no unique authoritative source exists, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

Do not invent a source selection.

──────────────────────────────────────────────────────────────────────────────
3. RECONSTRUCT THE EXACT FAILED EXECUTION
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/failed-construction-parent-execution-v1.json

Reconstruct:

- source path, size, and SHA-256;
- submitted argv;
- cwd;
- explicit environment;
- pinned or unpinned interpreter;
- Python flags;
- top-level process authority;
- process exit or signal;
- stdout and stderr;
- paths written;
- whether a child launched;
- whether package construction began;
- exact first failure;
- exact missing executable-origin components;
- exact missing process-ledger components;
- whether the failure was:
  - source implementation incomplete;
  - initialization ordering wrong;
  - launch sequence wrong;
  - process contract incomplete;
  - or mixed.

Identify every process-related source function and record its source range.

Do not infer missing details that are not retained.

──────────────────────────────────────────────────────────────────────────────
4. FRESH SOURCE-QUALIFICATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-repair-

Immediately emit:

PARENT_REPAIR_ROOT=<absolute-path>

Before semantic work retain:

opening/bootstrap-start.json

including:

- fresh-root identity;
- allocation method;
- umask;
- failed-root identity;
- failed-parent identity;
- pinned Python identity;
- source-repair-only authority;
- package construction authorized:
  false;
- semantic exports may be written:
  false;
- real target audit executed:
  false.

Create directories lazily. Do not retain empty directories.

──────────────────────────────────────────────────────────────────────────────
5. EXACT FAILED-SOURCE COPY
──────────────────────────────────────────────────────────────────────────────

Copy the authenticated failed parent source to:

opening/original-package-construction-parent.py

Use:

- no-follow source open;
- stable pre/post-read fstat;
- exclusive destination creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/original-parent-source-identity.json

The copied source is an input to repair. It must not be executed.

──────────────────────────────────────────────────────────────────────────────
6. CLOSED REPAIR AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Create:

working/package_construction_parent_v1.py

Only process-envelope surfaces may change:

1. Explicit execution mode selection.
2. Executable-origin registry.
3. Executable-origin freeze before execution.
4. Python invocation contract.
5. Child-process recorder.
6. Prelaunch record creation.
7. Spawn-failure recording.
8. stdout/stderr custody.
9. Exit/signal recording.
10. Reaping and descriptor closure.
11. Fixed-output filesystem attribution.
12. Dynamic-root locator attribution.
13. Process and cache cleanup.
14. Process-ledger completeness gate.
15. Process self-test mode.
16. Construct-mode admission gate.

Preserve all existing package-construction semantics and algorithms.

No package-construction function, condition, export mapping, metadata rule,
qualification oracle, package path, target operand, or terminal-closure rule
may change except when strictly necessary to route a process through the
recorder.

Retain function-level AST hashes for all construction functions before and
after repair.

If a substantive construction semantic must change, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

Do not widen the repair.

──────────────────────────────────────────────────────────────────────────────
7. EXPLICIT EXECUTION MODES
──────────────────────────────────────────────────────────────────────────────

The repaired parent must require one explicit mode:

--mode process-self-test
--mode construct

There is no default mode.

Unknown or missing mode must fail before package input inspection.

For this task:

- only `--mode process-self-test` may execute;
- `--mode construct` must never execute;
- no semantic export may be written;
- no final package root may be allocated.

`process-self-test` must exercise only process custody and cleanup using
audit-owned fixtures.

`construct` remains frozen for the later one-shot execution task.

Retain a static control-flow proof that the self-test mode cannot enter the
construction path.

──────────────────────────────────────────────────────────────────────────────
8. PROCESS-AUTHORITY SPLIT
──────────────────────────────────────────────────────────────────────────────

Freeze the process-authority model:

- Codex platform transcript is authority for top-level parent creation,
  submitted argv, cwd, explicit environment, PID when exposed, raw streams,
  exit/signal, and elapsed duration.
- The repair capsule is authority for:
  - source identity;
  - executable-origin registry;
  - child prelaunch records;
  - child outcomes;
  - stream bytes;
  - filesystem effects;
  - cleanup;
  - self-test results.
- The capsule does not self-attest creation of the top-level parent.

Retain:

contract/top-level-process-authority-v1.json

──────────────────────────────────────────────────────────────────────────────
9. COMPLETE EXECUTABLE-ORIGIN REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before any repaired-parent execution, retain:

contract/executable-origin-policy-v1.json
opening/executable-origin-registry-v1.json

Every executable or source that may be launched must be registered before
launch.

Allowed origins:

A. Pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

B. Exact absolute-path operating-system executables explicitly listed in the
registry.

C. Fresh audit-owned self-test helpers retained under this repair root,
hash-bound before execution.

D. The exact frozen repaired parent.

Forbidden origins:

- any prior failed retry root;
- the failed unsealed harness package;
- the blocked closure-attempt root;
- the sealed metadata-inconsistent package;
- unretained here-doc source;
- unretained temporary scripts;
- PATH-resolved scripts;
- basename, prefix, recency, score, or fallback selection;
- symlinked executable source;
- mutable executable source after registry freeze.

Each registry row must bind:

- role;
- absolute path;
- source or binary;
- size;
- SHA-256;
- mode;
- link count;
- device/inode;
- producer;
- permitted consumers;
- permitted argv shape;
- permitted cwd;
- permitted environment;
- first permitted child ordinal;
- current:
  true.

Retain a registry-freeze record.

No child launch is permitted before registry freeze.

──────────────────────────────────────────────────────────────────────────────
10. PINNED PYTHON CONTRACT
──────────────────────────────────────────────────────────────────────────────

Every Python child must use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B

in that exact order as separate argv elements.

Every Python child must use explicit stable environment values including:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Use audit-owned HOME, TMPDIR, and PYTHONPYCACHEPREFIX paths.

Forbidden:

- `python`;
- `python3`;
- `/usr/bin/python3`;
- `/usr/bin/env python`;
- shebang execution;
- interpreter resolved through PATH;
- missing or reordered required flags;
- package-root cache destination.

Retain:

contract/pinned-python-invocation-v1.json

No Python process may launch unless its argv and source match the registry and
this contract.

──────────────────────────────────────────────────────────────────────────────
11. COMPLETE CHILD-PROCESS RECORD SCHEMA
──────────────────────────────────────────────────────────────────────────────

Retain before self-test execution:

contract/child-process-record-v1.json

For every child ordinal require one complete record family:

A. Prelaunch record, created exclusively and fsynced before spawn:

- ordinal;
- purpose;
- executable origin;
- argv;
- cwd;
- explicit environment;
- timeout;
- stdin posture;
- stdout/stderr posture;
- fixed output paths;
- dynamic output contract;
- prelaunch path observations;
- permitted filesystem scope.

B. stdout bytes.

C. stderr bytes.

D. Outcome:

- process-created;
- spawn exception when applicable;
- PID when created;
- exit code or signal;
- timeout;
- reaped;
- stdout descriptor closed;
- stderr descriptor closed;
- fixed-path post-state;
- dynamic locators;
- paths written;
- complete dynamic-root inventories;
- cleanup-registry additions;
- first blocker;
- qualifying or failed/superseded disposition.

Ordinals must be contiguous with no gaps or duplicates.

No direct subprocess, spawn, exec, system, or shell operation may bypass the
single recorder.

──────────────────────────────────────────────────────────────────────────────
12. FILESYSTEM-EFFECT ATTRIBUTION
──────────────────────────────────────────────────────────────────────────────

The recorder must support both:

A. Fixed outputs

Declared before launch with exact absolute paths.

B. Dynamic roots

Declared before launch with:

- exact permitted parent;
- exact basename prefix;
- exact stdout locator grammar;
- expected locator count;
- type and mode requirements.

Parse dynamic locators on:

- exit 0;
- nonzero exit;
- timeout;
- later result-parse failure.

A nonzero exit never permits skipping effect attribution.

For each valid locator:

- retain exact stdout bytes;
- require one full-match locator and no extra bytes;
- lstat exact path;
- require direct parent and prefix;
- retain root identity;
- retain complete no-follow inventory;
- append to `paths_written`;
- append to cleanup registry.

Missing or ambiguous dynamic-root attribution is process-provenance-fatal.

No broad directory scan, prefix scan, newest selection, scoring, guessing, or
fallback is permitted.

──────────────────────────────────────────────────────────────────────────────
13. PROCESS SELF-TEST CAUSALS
──────────────────────────────────────────────────────────────────────────────

The `process-self-test` mode must run only these bounded audit-owned causals:

1. Missing executable:
   - prelaunch retained before spawn;
   - `FileNotFoundError`/ENOENT;
   - no process created;
   - empty streams;
   - complete outcome.

2. `/usr/bin/true`:
   - exit 0;
   - empty streams;
   - reaped;
   - descriptors closed.

3. Pinned Python version:
   - exact interpreter;
   - exact `-I -S -B`;
   - expected version output.

4. Registered fresh helper:
   - exact source identity;
   - exit 0;
   - expected fixed output;
   - fixed output attributed.

5. Unregistered executable:
   - rejected before spawn;
   - no process created.

6. Historical-root executable source:
   - rejected before spawn;
   - no historical tool executed or imported.

7. Unpinned Python:
   - rejected before spawn.

8. Missing `-I`:
   - rejected before spawn.

9. Missing `-S`:
   - rejected before spawn.

10. Missing `-B`:
    - rejected before spawn.

11. Wrong Python flag order:
    - rejected before spawn.

12. Fixed-output child:
    - output absent before launch;
    - output created at exact path;
    - mode, size, and SHA retained;
    - `paths_written` exact.

13. Dynamic-root success child:
    - emits one exact locator;
    - root attributed and inventoried.

14. Dynamic-root nonzero child:
    - emits one exact locator;
    - exits nonzero;
    - root still attributed and inventoried.

15. Invalid locator:
    - provenance failure recorded;
    - no guessed root.

16. Child timeout:
    - timeout retained;
    - process reaped;
    - streams/descriptors closed;
    - effects still attributed.

17. Duplicate ordinal mutation:
    - rejected.

18. Missing prelaunch record mutation:
    - rejected.

19. Incomplete stream record mutation:
    - rejected.

20. Direct subprocess bypass mutation:
    - rejected by static gate.

No causal may inspect or write a semantic package input.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS-LEDGER MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a literal audit-owned matrix covering at minimum:

- every causal above;
- unregistered source;
- source identity drift;
- registry changed after freeze;
- executable symlink;
- multi-link source;
- wrong cwd;
- environment drift;
- fixed output missing;
- undeclared fixed output;
- dynamic root wrong parent;
- dynamic root wrong prefix;
- two locators;
- extra stdout bytes;
- path created but omitted from `paths_written`;
- cleanup registry missing a created root;
- root identity rebinding before cleanup;
- one ENOENT observation missing;
- process survivor;
- descriptor survivor;
- Python cache survivor;
- package-local `.pyc`;
- failed child incorrectly counted as passing;
- child launched before registry freeze;
- construct mode entered during self-test.

Require:

- exact literal names;
- unique names;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/process-ledger-mutation-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
15. INDEPENDENT PROCESS VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports neither:

- repaired parent;
- recorder implementation;
- first mutation helper;
- producer fixtures.

It must independently validate:

- registry closure;
- source origins;
- pinned Python;
- exact flags;
- prelaunch-before-spawn;
- ordinal continuity;
- stream custody;
- outcomes;
- filesystem attribution;
- cleanup set equality;
- no direct process bypass;
- no construction-path entry.

Use its own literal case registry and expected reasons.

Retain:

validation/independent-process-envelope-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
16. STATIC SOURCE GATES BEFORE EXECUTION
──────────────────────────────────────────────────────────────────────────────

Before executing the repaired parent:

1. Compile with pinned Python and exact `-I -S -B`.
2. Parse AST.
3. Build a call graph.
4. Locate all:
   - subprocess calls;
   - spawn calls;
   - exec calls;
   - system/shell calls;
   - process-library dynamic imports.
5. Require every permitted child creation to route through the recorder.
6. Require no import-time process or filesystem activity.
7. Require no stdin read or persistent input loop.
8. Require explicit self-test/construct mode split.
9. Require self-test cannot reach construction.
10. Require construct cannot start before process-provenance gate.
11. Require no package export write in self-test mode.
12. Require no executable source from a failed root.

Use two independent checks:

- AST/call-graph;
- bytecode/exception-table CFG.

Require agreement.

Retain:

validation/static-process-envelope-check-a.json
validation/static-process-envelope-check-b.json
validation/static-process-envelope-reconciliation.json

──────────────────────────────────────────────────────────────────────────────
17. EXACT PROCESS-ONLY SEMANTIC DELTA
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/exact-parent-source-delta-v1.json

For every changed hunk record:

- original and repaired source ranges;
- owning process defect;
- behavior before;
- behavior after;
- process-authority effect;
- construction-semantic effect:
  none.

Require function-level AST equality for every construction-semantic function.

Permitted ownership:

target-audit-harness-package-construction-process-envelope

No package export, metadata, qualification, or closure semantic may change.

If it must, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

──────────────────────────────────────────────────────────────────────────────
18. FREEZE BEFORE FIRST EXECUTION
──────────────────────────────────────────────────────────────────────────────

Only after:

- source compiles;
- static checks pass;
- executable registry is complete;
- executable registry is frozen;
- child-record contract is complete;
- self-test contract is complete;
- process-ledger matrix definitions are complete;
- independent-validator source is retained;
- exact delta passes;

install exact repaired bytes at:

provenance/package-construction-parent.py

Use:

- exclusive creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/package-construction-parent-freeze-v1.json

Record:

- original source identity;
- repaired source identity;
- exact delta;
- executable registry identity;
- process contracts;
- static-check identities;
- source frozen:
  true;
- later modification permitted:
  false;
- construction mode executed:
  false.

No repaired-parent execution is permitted before this freeze exists.

──────────────────────────────────────────────────────────────────────────────
19. EXECUTE ONLY PROCESS SELF-TEST MODE
──────────────────────────────────────────────────────────────────────────────

Invoke the exact frozen source once with pinned Python and exact flags:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<fresh-root>/provenance/package-construction-parent.py
--mode
process-self-test

Use one finite noninteractive top-level carrier.

Use DEVNULL stdin.

Retain platform-authoritative:

- argv;
- cwd;
- explicit environment;
- PID when exposed;
- raw stdout;
- raw stderr;
- exit/signal;
- elapsed duration.

Do not launch a replacement parent.

Do not run `--mode construct`.

Require self-test exit 0 and complete process ledger.

──────────────────────────────────────────────────────────────────────────────
20. SELF-TEST CLEANUP
──────────────────────────────────────────────────────────────────────────────

Construct the cleanup registry only from:

- validated dynamic locators;
- declared fixed audit-owned fixture roots;
- registered cache roots.

For every root:

1. Retain complete pre-removal inventory.
2. Require originating child reaped.
3. Require descriptors closed.
4. Revalidate device/inode and permitted parent.
5. Remove exactly the registered root.
6. Perform two fresh lstat calls.
7. Require ENOENT twice.
8. Retain both observations.

Require exact set equality:

created roots
=
inventoried roots
=
cleanup rows
=
twice-absent roots

Require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
21. SELF-TEST RESULT
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/process-self-test-result-v1.json

Require:

- source identity exact;
- registry frozen before execution;
- construct mode not entered;
- semantic package roots not opened;
- every required causal executed;
- every causal passed its expected classification;
- process ordinals contiguous;
- complete streams and outcomes;
- complete filesystem attribution;
- cleanup-set equality;
- no cache or bytecode;
- success:
  true;
- first blocker:
  null.

The result is process-envelope qualification only.

It grants no package-construction or target-audit verdict.

──────────────────────────────────────────────────────────────────────────────
22. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

After self-test and cleanup:

1. Reopen frozen source no-follow.
2. Verify source identity.
3. Recompile.
4. Rerun static check A.
5. Rerun static check B.
6. Rerun process-ledger mutation matrix in-memory.
7. Rerun independent validator.
8. Verify self-test ledger against the independent validator.
9. Verify construct mode remains unexecuted.
10. Verify no package export exists.

Retain:

validation/frozen-construction-parent-requalification-v1.json

Require exact equality with pre-execution source and contracts.

Do not edit the frozen source.

──────────────────────────────────────────────────────────────────────────────
23. NO PACKAGE CONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not create:

- target-audit payload export;
- target-audit plan;
- support-binding policy;
- finalizer lifecycle;
- process-custody contract;
- request template;
- invocation template;
- package metadata;
- package temporal inventory;
- package manifests.

Do not open the sealed predecessor package or target roots unless required only
to authenticate a fixed source identity already explicitly bound in the failed
root.

Prefer not to open them at all.

This task ends with an accepted frozen construction parent, not a package.

──────────────────────────────────────────────────────────────────────────────
24. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventory of the failed process-clean retry root.

Require exact opening/closing equality.

Any other supplied root opened also requires complete opening/closing equality.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
25. SOURCE-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before terminal manifests:

- bootstrap start;
- failed-root identity and execution reconstruction;
- original source;
- repaired source;
- exact delta;
- process contracts;
- executable registry;
- registry freeze;
- static checks;
- source freeze;
- self-test platform record;
- complete child ledger;
- self-test result;
- mutation matrix;
- independent validator;
- cleanup;
- frozen-source requalification;
- supplied-root closing equality;
- final report;
- temporal final inventory.

Then create two independently generated manifests.

Require:

- root represented;
- all retained directories represented;
- all nonmanifest regular files represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories 0700;
- files 0600;
- no `__pycache__`;
- no `.pyc`;
- manifests byte-identical;
- independent reprojection exact;
- no write after closure.

──────────────────────────────────────────────────────────────────────────────
26. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY

only when:

- failed root authenticates and closes unchanged;
- exact failed parent is identified;
- exact first failure is reconstructed;
- repair is process-envelope-only;
- construction semantics remain unchanged;
- executable registry is complete and frozen before execution;
- process ledger implementation is complete before execution;
- source compiles;
- static checks pass;
- exact repaired source is frozen;
- only self-test mode executes;
- process self-test passes;
- process-ledger matrix passes;
- independent validator passes;
- all children and effects are recorded;
- cleanup-set equality passes;
- frozen-source requalification passes;
- no package construction occurs;
- source package closes terminally.

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

when:

- exact failed source cannot be identified;
- source repair requires construction-semantic changes;
- self-test cannot prove complete process custody;
- dynamic output attribution cannot be made complete;
- construction mode cannot be separated safely;
- another process defect outside the bounded repair is found.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- closing inequality;
- source-authority mismatch;
- unauthorized source drift;
- pre-freeze parent execution;
- unregistered process execution;
- unpinned Python execution;
- missing exact `-I -S -B`;
- incomplete process ledger;
- cleanup-set inequality;
- source-package closure failure;
- any write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
27. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh source-repair-root identity
3. Failed process-clean retry identity
4. Failed construction-parent candidate ledger
5. Exact failed parent-source identity
6. Exact failed invocation
7. Exact first process-provenance failure
8. Failure classification
9. Original source identity
10. Repaired source identity
11. Exact process-only semantic delta
12. Execution-mode split
13. Top-level process-authority split
14. Executable-origin policy
15. Complete executable-origin registry
16. Registry-freeze identity
17. Pinned Python contract
18. Child-process record schema
19. Filesystem-effect attribution model
20. Process-self-test causals
21. Process-ledger mutation matrix
22. Independent process validator
23. Static check A
24. Static check B
25. Frozen parent-source identity
26. Source-freeze identity
27. Exact self-test invocation
28. Platform process custody
29. Complete child-ledger identity and continuity
30. Self-test result
31. Cleanup-set equality
32. Frozen-source requalification
33. Confirmation construct mode did not run
34. Confirmation no semantic export was written
35. Supplied-root closing equality
36. Source-package inventory and manifests
37. Remaining uncertainty and nonclaims
38. Explicit confirmations

Required confirmations:

FAILED_PROCESS_CLEAN_RETRY_ROOT_MUTATION_NOT_PERFORMED
FAILED_PROCESS_CLEAN_RETRY_ROOT_NOT_RESUMED
EXACT_FAILED_PARENT_SOURCE_IDENTIFIED
FAILED_PARENT_EXECUTION_RECONSTRUCTED
FIRST_PROCESS_PROVENANCE_FAILURE_IDENTIFIED
ORIGINAL_PARENT_SOURCE_BYTES_PRESERVED
REPAIR_BOUNDED_TO_PROCESS_ENVELOPE
CONSTRUCTION_SEMANTICS_UNCHANGED
EXPLICIT_SELF_TEST_AND_CONSTRUCT_MODES
CONSTRUCT_MODE_NOT_EXECUTED
TOP_LEVEL_PROCESS_AUTHORITY_SPLIT_FROZEN
EXECUTABLE_ORIGIN_POLICY_COMPLETE
EXECUTABLE_ORIGIN_REGISTRY_COMPLETE
EXECUTABLE_ORIGIN_REGISTRY_FROZEN_BEFORE_EXECUTION
NO_HISTORICAL_TOOLING_EXECUTED
NO_UNREGISTERED_EXECUTABLE_LAUNCHED
PINNED_PYTHON_IDENTITY_VERIFIED
ALL_PYTHON_CHILDREN_USED_LITERAL_I_S_B
CHILD_PROCESS_RECORD_SCHEMA_COMPLETE
PRELAUNCH_RECORD_CREATED_BEFORE_EVERY_SPAWN
SPAWN_FAILURE_CAUSAL_RECORDED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
CHILD_STREAMS_COMPLETE
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
FIXED_OUTPUT_EFFECTS_ATTRIBUTED
DYNAMIC_ROOT_EFFECTS_ATTRIBUTED
NONZERO_EXIT_EFFECTS_ATTRIBUTED
NO_BROAD_ROOT_DISCOVERY
PROCESS_LEDGER_MUTATION_MATRIX_PASSED
INDEPENDENT_PROCESS_VALIDATOR_PASSED
STATIC_PROCESS_CHECK_A_PASSED
STATIC_PROCESS_CHECK_B_PASSED
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PROCESS_SELF_TEST_MODE_EXECUTED
PROCESS_SELF_TEST_PASSED
PACKAGE_CONSTRUCTION_NOT_PERFORMED
NO_SEMANTIC_EXPORT_WRITTEN
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FROZEN_SOURCE_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY`, execute the exact frozen
source once in `--mode construct` under a separate explicit authorization. Do
not regenerate, edit, or re-preflight it.
```

## Decision

Do **not** retry metadata construction yet. First qualify and freeze the process envelope that will perform it.

**Source:** Codex’s latest `PREFLIGHT_PROVENANCE_MISMATCH` response.  
**Confidence:** 1.00 that no package or target repair is authorized; 0.99 that the next critical path is construction-parent process qualification; 0.95 that separating source qualification from package construction will stop the current retry loop.
