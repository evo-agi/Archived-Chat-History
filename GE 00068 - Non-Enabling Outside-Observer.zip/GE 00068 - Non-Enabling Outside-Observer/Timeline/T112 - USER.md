Here is Codex's response:

# Evidence verification architecture reset

**EVIDENCE_VERIFICATION_ARCHITECTURE_RESET_READY**

This is an architecture decision only. The selected design is an ES-owned, committed external verifier with committed, versioned layout specifications. Its bootstrap uses exact source supplied to a fresh independent audit before the first commit. Neither step requires the verifier to verify itself or a new evidence child to amend an earlier verifier.

## 1. Opening and closing identity

The read-only opening and closing checks matched the required physical candidate root, `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1` (device/inode `16777234/122118502`), distinct from the primary sibling. The candidate remained on `codex/remote-alpha-external-tls-status-observation-v1`, with HEAD `567bceced5df95ecfe787cc66038d463a854e12c`, parent `05dde14d185b6e022dcc169ef1a658a97961850f`, HEAD tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`, and no upstream. The index SHA-256 remained `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`.

All 389 inventory members matched their recorded bytes; membership remained 375 tracked and 14 nonignored untracked, with source T `8de797304ea944b6a155924e0d1e9e8bbe79534e` and inventory SHA-256 `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`. Status remained 22 tracked modifications, 14 untracked paths, and zero staged, deleted, renamed, or unmerged paths.

Independent read-only closure checks reproduced the original A6D manifest `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9` (623 payloads, 205 directories) and amendment manifest `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e` (29 payloads, 9 directories). A6V matched its nine recorded payloads and remained unsealed. All six present `phase-i-a6-policy-evidence-*` children remained unsealed; two successive complete path/type/mode/size/hash/link snapshots of each were identical. The current A6D, A6R, and A6O failed children also matched their retained historical snapshots.

## 2. Current mechanism and failure

The [original packaged post-seal verifier](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/commands/verify-postseal-v1.py) parses a manifest and checks payload closure, then invokes an A6D-specific closing helper. Its sealed top-level predicate omitted the manifest and sidecar, so valid sealed A6D evidence failed. The [amendment’s corrected verifier](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9/tool/corrected/verify-postseal-v1.py) fixed that predicate and strengthened canonical parsing and file checks. The corrected [closing helper](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9/tool/corrected/verify-closing-v1.py) recognizes the sealed A6D layout.

The reusable core checks manifest rows, detached digest, complete path set, regular file type, mode, size, SHA-256, single link, `0700` directories, absence of symlinks and special files, and observable manifest-last ordering. Target dispatch and authority checks are separate in the source, but coupled in execution:

| Layer | Current behavior | Replacement disposition |
| --- | --- | --- |
| Generic closure | Strict byte and filesystem checks | Retain as the verifier’s sole decision |
| Target dispatch | `original` and `amendment` require exact historical absolute roots; `fixture` requires an amendment-owned private descendant | Replace with committed spec registration |
| Layout | Seven A6D or six amendment top directories; fixture uses seven | Move structural rules into versioned specs |
| Stages | Real children accept sealed only; fixture alone accepts pre-seal | Permit both stages under each admitted spec |
| Readiness | A6D checks source inventory, A/B captions, command and causal counts, cleanup, and nested closing state; amendment checks joint qualification and 20 cases | Move to separate adjudication and later audit |
| Bootstrap | Candidate cwd, exact historical paths, and nested helper execution | Bind source by Git/provenance outside the target |

The [A6V six-rejection matrix](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6v-evidence-target-recon-8de797304ea9/tests/six-rejection-matrix-v1.json) records that `original`, `amendment`, and `fixture` each rejected the failed A6 root at both stages **before** stage or layout inspection. An amendment child at a new path also fails the exact amendment-root predicate. That is the recursive dead end; another amendment layer is disallowed. The 20-case [amendment fixture record](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9/validation/verifier-cases-v1.json) remains useful regression evidence, not authorization for a new target.

## 3. Authority and selected bootstrap

The repository’s [plan](/Users/ds/Repositories/Execution%20Substrate%20-%20external-tls-status-observation-v1/PLANS.md), [boundaries](/Users/ds/Repositories/Execution%20Substrate%20-%20external-tls-status-observation-v1/.docs/system_overview/boundaries.md), [artifact hygiene rules](/Users/ds/Repositories/Execution%20Substrate%20-%20external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md), and [MVP claim freeze](/Users/ds/Repositories/Execution%20Substrate%20-%20external-tls-status-observation-v1/.docs/mvp.md) classify Repair 10I as a **Bounded slice rule** and generated evidence as non-authoritative. T1 remains a **Current invariant**; the old target-specific verifiers and legacy manifest name become explicit **Temporary compatibility edges** for historical evidence. This design uses no **Reopened redesign seam** and changes no public product, runtime, service, or repository-observer contract.

**Primary model A:** commit one versioned verifier and its registry/specs under the candidate ES repository. Git identity, exact source SHA-256, and ordinary patch provenance bind the source. Evidence closeout records verifier ID, source SHA-256, repository commit, registry SHA-256, layout ID, and layout SHA-256. The verifier never judges its own repository or evidence container.

**Bounded bootstrap model B:** before that commit, give the exact source and canonical registry/spec bytes to producer and fresh auditor as external audit inputs. Each independently runs the same fixture and determinism gates twice. The independent audit accepts source semantics and provenance directly; verifier output does not certify the verifier. After audit, an exact-byte commit activates model A. A separately audited standalone package adds an unnecessary owner now. Embedded verifiers, amendment chains, and runtime caller-supplied layouts are rejected.

**Placement:** `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/`. ES owns this narrow Repair 10I assurance tool. Repair 10I producers and independent auditors consume it by exact source identity; later Governed Execution work may consume that audited identity without importing ES product authority. Project-level cross-repository tooling would create a new framework and owner before one is needed. Prompt-carried source remains bootstrap input, not durable placement. A future cross-repository owner would require its own documented decision and migration.

## 4. Frozen verifier and layout contracts

Tool ID: `execution-substrate.evidence-closure-verifier/v1`. The sole executable source is `tools/evidence_verify/verify_v1.py`, using Python standard library only. It reads `registry_v1.json` and canonical specs adjacent to its source. The registry maps exact layout IDs to package-relative filenames and SHA-256 values. It has no runtime registration or `--layout-file` option. Adding a closed target with unchanged schema semantics changes only a spec and registry entry, followed by ordinary source validation, provenance, audit, and commit; the verifier source bytes remain unchanged.

Invocation is `python3.13 -I -B verify_v1.py --root ABSOLUTE_PHYSICAL_TARGET --layout-id ID --stage pre-seal --manifest ABSOLUTE_EXTERNAL_CANDIDATE` or `--stage sealed` without `--manifest`. Producer and auditor pin the exact interpreter and source identity in provenance. The manifest candidate for pre-seal is outside both target and tool package; a separate writer installs its detached digest and then the exact manifest bytes last. The verifier performs **zero writes**, imports no target code, invokes no child process, reads no network or product state, and rejects a target containing or contained by its own source package. Unsupported no-follow or descriptor operations fail at this verification boundary; there is no OS-label branch or fallback, consistent with [capability probing rules](/Users/ds/Repositories/Execution%20Substrate%20-%20external-tls-status-observation-v1/.docs/system_overview/capability_probing.md).

The exact spec schema is canonical JSON with only: `schema`, `id`, `manifest_magic`, `required_root_directories`, `required_directories`, `required_files` with modes, `optional_subtrees`, `file_modes`, `directory_mode`, `stages`, and `limits`. Registry and specs use sorted-key, compact ASCII JSON plus one LF, reject duplicate or unknown keys, and hash their complete bytes. The registry admits these first three IDs:

| ID | Structural contract |
| --- | --- |
| `execution-substrate.repair10i.a6d-successor-layout/v1` | Seven historical top directories; fixed source inventory, A/B result, cleanup, and closing records |
| `execution-substrate.repair10i.a6d-amendment-layout/v1` | Six historical top directories; fixed joint qualification, cleanup, and corrected helper records |
| `execution-substrate.repair10i.a6-policy-layout/v1` | Exactly `opening`, `tool`, `sources`, `commands`, `controls`, `validation`, `comparisons`, `analysis`, `findings`, `closeout`; fixed `opening/opening-capsule-v1.json`, `closeout/closing-gate-v1.json`, `closeout/cleanup-v1.json`, `closeout/command-root-audit-v1.json`, and `closeout/final-report-v1.md` |

Each declared top directory permits bounded descendants only within its declared optional subtree. Shared limits are 8,192 files, 2,048 directories, 256 MiB per file, 4 GiB total payload, 12 path segments, and 1,024 path bytes. Path segments use the documented portable ASCII grammar; `.`/`..`, absolute paths, empty segments, symlinks, hardlinks, and special files fail. All directories are `0700`; regular payloads are `0600` or `0700`, with fixed records `0600`. At pre-seal, both root seal files must be absent. At sealed stage, the only additional root entries are regular single-link `0600` manifest and sidecar files.

The two historical specs admit only the existing `ES-REPAIR10-EVIDENCE-MANIFEST-V1` header. New A6 and later specs use `GE-EVIDENCE-MANIFEST-V1`. Both have the same closed row grammar: canonical count, byte-sorted unique relative paths, unpadded canonical URL-safe base64 path encoding, regular-file mode, canonical decimal size, lowercase SHA-256, and terminal LF. The sidecar is exactly the lowercase manifest digest plus LF. The verifier checks complete payload/path closure and manifest-last observable mtime/ctime ordering, with descriptor-bracketed reads to reject concurrent change. This is a same-child custody check; it does not claim to defeat privileged timestamp forgery or prove transport history.

Stdout is one compact sorted-key JSON line with `schema`, `tool_id`, `outcome`, `stage`, `layout_id`, `registry_sha256`, `layout_sha256`, `manifest_sha256`, `payload_count`, `directory_count`, and `error_class`; unavailable values are `null`. It contains no absolute paths, payload content, timestamps, or readiness captions. Exit codes are `0` pass, `2` invocation/target boundary, `3` unknown layout or registry/spec identity/schema, `4` stage/layout, `5` manifest/sidecar, `6` path/type/mode/link/size/hash/post-seal closure, and `7` I/O or race uncertainty. Closed error classes are `INVOCATION`, `TARGET_BOUNDARY`, `UNKNOWN_LAYOUT`, `SPEC_IDENTITY`, `SPEC_SCHEMA`, `STAGE`, `LAYOUT`, `MANIFEST_CANONICAL`, `SIDECAR`, `PATH_SET`, `TYPE_MODE_LINK`, `SIZE_HASH`, `POST_SEAL`, and `IO_OR_RACE`. Unknown IDs and arbitrary supplied layouts fail.

## 5. Readiness and Repair 10I migration

The verifier establishes **byte closure and admitted structure only**. It does not parse payload JSON or decide whether a test passed, comparison is acceptable, repair is correct, historical policy is safe, evidence has product authority, or a tranche is commit-ready. A separate closeout adjudicator consumes control, qualification, comparison, historical-policy, cleanup, and provenance evidence. Its conclusion remains evidence and must be recomputed by the later independent audit. A structurally valid child with empty or failing controls can therefore verify successfully and still be rejected by adjudication.

The original A6D and amendment remain sealed and unchanged; their original target-specific verifiers become historical regression fixtures. A6V remains an unsealed blocked reconnaissance record. All failed A6 children remain unsealed and must not be resumed. Future A6 starts a **fresh** child after verifier source audit and exact-byte commit. It may use the existing exact A6D successor source T `8c237318e3a72172e5cbbdf41f5e68244ae15895`, source inventory `7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852`, and recorded binary identities. The external verifier can independently close A6D and the new A6 child under their distinct specs. A successor rebuild is required only if later exact source/binary review finds an actual insufficiency or drift; this architecture decision does not require one.

## 6. Exact future touched-file set

The one bounded implementation tranche is limited to these paths under the candidate root:

```text
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/boundaries.md
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/evidence_verification.md
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/verify_v1.py
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/registry_v1.json
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/layouts/a6d_successor_v1.json
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/layouts/a6d_amendment_v1.json
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/layouts/a6_policy_v1.json
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/test_verify_v1.py
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt
```

The historical fixture files retain exact original bytes, with hashes asserted in tests. An additional needed path requires a new scope decision before editing.

## 7. Required causal and audit matrix

These are future gates; **none was run in this turn**.

| # | Required case | Expected result |
| ---: | --- | --- |
| 1 | Valid generic pre-seal closure | Pass |
| 2 | Valid generic sealed closure | Pass |
| 3 | Missing manifest at sealed stage | Reject |
| 4 | Missing sidecar | Reject |
| 5 | Wrong sidecar digest | Reject |
| 6 | Missing manifested payload | Reject |
| 7 | Unexpected payload | Reject |
| 8 | Wrong file mode | Reject |
| 9 | Wrong size | Reject |
| 10 | Wrong hash | Reject |
| 11 | Wrong link count | Reject |
| 12 | Directory mode mismatch | Reject |
| 13 | Symlink | Reject |
| 14 | Special file | Reject |
| 15 | Observable post-manifest mutation, including same-byte rewrite | Reject |
| 16 | Unknown layout ID | Reject |
| 17 | Wrong registered layout hash | Reject |
| 18 | Missing required layout entry | Reject |
| 19 | Unexpected layout entry | Reject |
| 20 | Pre-seal/sealed posture confusion | Reject |
| 21 | Caller-supplied arbitrary layout | Reject at CLI |
| 22 | Readiness content changed while structure and manifest are valid | Same closure result; separate adjudication decides readiness |
| 23 | Complete target and tool-package snapshot before/after invocation | Identical; zero verifier writes |
| 24 | Repeated invocation under pinned environment | Byte-identical canonical output |
| 25 | Verifier source inside or dependent on target child | Reject/source audit fails |
| 26 | Target is verifier package or its container | Reject |
| 27 | Producer and fresh auditor run exact same source/spec | Independently reproduce result |
| 28 | Exact original verifier fixtures and sealed-layout defect | Historical defect reproduced; new verifier closes valid fixture |
| 29 | Add a registered closed spec with unchanged verifier source | New kind passes after source audit; no amendment layer |
| 30 | Exact source, registry, spec, and manifest identities in closeout | Independent audit recomputes each identity |

## 8. Sequence, stops, and limits

Implementation order is: record this architecture in `PLANS.md` and the authoritative `.docs/` pages; add the 30 causal and audit gates; implement the single verifier, registry, and three specs; run exact fixtures and determinism checks twice; produce exact source and patch provenance; obtain a **fresh independent audit of verifier source and layout semantics only**; then, with separate authorization, commit exactly the audited bytes. Only after audit acceptance and source binding may a fresh A6 begin. The later A6 child receives its own independent evidence audit. The verifier implementation audit does not audit Repair 10I product behavior.

Stop if identity drifts; self-verification or another amendment layer becomes necessary; readiness leaks into closure; layouts become caller-controlled; placement or schema scope widens; a new kind requires verifier-code changes without a semantic reason; a product or public contract must change; a cross-repository framework becomes prerequisite; or the intended no-write, deterministic, exact-source gates cannot be proved.

The design is frozen, but implementation bytes, future source hashes, successful A6 evidence, and independent audit acceptance do not yet exist. Current A6V’s incomplete child cannot establish future control or comparison outcomes. This turn used only read-only file, Git identity, manifest, and snapshot inspection; it ran no product tests, source controls, comparisons, builds, A/B, live services, network contact, or Linux binaries. No repository or evidence file was created, modified, resumed, sealed, deleted, staged, committed, or published.
