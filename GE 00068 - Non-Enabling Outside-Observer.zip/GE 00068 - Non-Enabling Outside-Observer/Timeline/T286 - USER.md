Here is Codex's response:

# AUDIT\_PROVENANCE\_MISMATCH

The sole bootstrap carrier failed before retaining its required records or emitting the fresh audit-root path.

Cause: the bootstrap introduced an unauthorized interpreter-mode predicate. The pinned interpreter matched every specified identity field—version `Python 3.13.4`, size `119424`, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`, regular, and single-link—but had mode `0775`. The retry brief did not constrain interpreter mode, so rejecting it was an audit-process defect.

Consequences:

- Carrier 0002 was never launched.
- No wrapper phase records or carrier index were created.
- The wrapper-launch self-check and child-recorder causals did not run.
- No supplied root or target evidence was inspected or mutated.
- The historical failed audit root was not touched.
- No runtime validation, tests, product code, network access, staging, commit, A6 work, auditors, or subagents were started.
- A fresh audit-owned root was allocated under the required prefix, but its exact path was not emitted before bootstrap failure. It remains untouched.

Required confirmation status:
```
PINNED_PYTHON_IDENTITY_VERIFIED — OBSERVED MATCHING SPECIFIED FIELDS, BUT NOT RETAINED; NOT QUALIFIED
WRAPPER_RETAINED_MODE_0600 — NOT ESTABLISHED BY RETAINED RECORD
WRAPPER_NOT_EXECUTED_DIRECTLY — CONFIRMED
WRAPPER_NOT_CHMODDED — CONFIRMED
WRAPPER_NOT_COPIED_AS_EXECUTABLE — CONFIRMED
WRAPPER_INVOKED_THROUGH_PINNED_PYTHON — NOT REACHED
WRAPPER_INVOKED_WITH_ISOLATION_FLAGS — NOT REACHED
WRAPPER_LAUNCH_SELF_CHECK_PASSED — NOT SATISFIED
ALL_WRAPPED_CARRIERS_USED_SAME_INTERPRETER_CONTRACT — NOT REACHED

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED — CONFIRMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED — CONFIRMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED — CONFIRMED
RUNTIME_VALIDATION_NOT_RERUN — CONFIRMED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED — CONFIRMED
NETWORK_CONTACT_NOT_PERFORMED — CONFIRMED
A6_NOT_STARTED — CONFIRMED
STAGING_NOT_PERFORMED_IN_CANDIDATE — CONFIRMED
COMMIT_NOT_PERFORMED_IN_CANDIDATE — CONFIRMED
NESTED_SUBAGENTS_CREATED: 0
```
