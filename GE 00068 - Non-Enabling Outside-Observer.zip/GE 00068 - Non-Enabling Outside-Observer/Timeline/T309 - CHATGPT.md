## Assessment

The audit is correctly nonqualifying because its all-process ledger was incomplete. That is an **audit-process defect**, not an importer defect.

However, the audit also found two independent, repairable importer defects that make another audit premature:

1. **Nonauthority closure is incomplete.**
   - The closed importer contract omits explicit commit nonauthority.
   - The materialized authority-boundary record omits both commit and publication nonauthority.

2. **Failure-state custody is off by one.**
   - Fixed-environment failure: expected completed step `6`, recorded `5`.
   - Normalization-proof retention failure: expected `8`, recorded `7`.
   - Request-retention failure: expected `10`, recorded `9`.

The rest of the bounded behavior was strong: package closure, exact five-artifact copying, root rebinding, two deterministic materializations, importer-to-launcher handoff, security review, and supplied-root equality all passed. The right next step is therefore a **narrow importer audit repair**, not another full audit and not another launcher or import-interface tranche.

The process-ledger failure must be addressed in the later independent-audit prompt, not by changing importer semantics.

## Codex prompt

```text
VALIDATION-CUSTODY V3 BOOTSTRAP IMPORTER V1 —
BOUNDED AUDIT REPAIR FOR NONAUTHORITY CLOSURE
AND FAILURE-STEP CUSTODY

This is a source-external audit-process infrastructure repair.

Do not modify the predecessor importer package.
Do not modify the blocking independent-audit root.
Do not inspect or modify the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents.

Return exactly one primary implementation verdict:

VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_BLOCKED
IMPLEMENTATION_PROVENANCE_MISMATCH

OBJECTIVE

Produce one fresh immutable successor capsule that repairs exactly:

1. incomplete explicit nonauthority closure; and
2. incorrect `completed_step_ordinal` custody in failure records.

Preserve every already-qualified importer behavior outside those findings.

This task does not perform the independent audit.

──────────────────────────────────────────────────────────────────────────────
1. EXACT IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_IMPORTER_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-v1-s5l048qh

Expected root identity:

- device/inode:
  16777234 / 179051602
- mode:
  0700
- producer verdict:
  VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected primary source:

source/bootstrap_importer_v1.py

- size:
  66362
- SHA-256:
  f7f5a6f308e9a7a4af043a4c64b95c854f1d433787308c06647d5318452fe6ee
- mode:
  0600
- regular:
  true
- links:
  1

Expected terminal identities:

closeout/final-evidence-inventory-v1.json

- size:
  8815
- SHA-256:
  2000c0f9bd52bf4a98cf2d74091679334259b1f1759dbf3b245224a236a02129

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  8937 each
- SHA-256:
  336436ce9686344735fd5fbc0a4793d3b78e2949c32d41980e2ab7493a6e9d0f
- required:
  byte-identical

Expected closure:

- 55 represented entries;
- 11 represented directories including root;
- 44 represented nonmanifest regular files;
- 46 physical regular files including the two manifests;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-independent-audit-_p93agae

Treat it as immutable, nonqualifying independent-audit evidence.

At minimum bind and inspect:

closeout/final-audit-report-terminal.json
analysis/process-ledger-gap-terminal.json
auditors/direct-auditor-schedule-v2.json
validation/fresh-independent-82-case-matrix.json
causals/failure-atomicity-causals.json
analysis/root-layout-artifact-adjudication-v2.json
analysis/security-sensitive-material-review-v2.json
closeout/supplied-root-closing-equality-v2.json
closeout/fixture-cleanup-v2.json
closeout/terminal-audit-manifest-a-v1.json
closeout/terminal-audit-manifest-b-v1.json

Do not adopt the audit’s primary verdict as a target finding.

Consume only these target-level findings:

A. The closed importer contract omits explicit commit nonauthority.

B. The materialized authority-boundary record omits explicit commit and
   publication nonauthority.

C. Three failure records underreport `completed_step_ordinal` by one:

- fixed-environment failure:
  expected 6, recorded 5;
- normalization-proof retention failure:
  expected 8, recorded 7;
- request-retention failure:
  expected 10, recorded 9.

The incomplete audit process ledger is not an importer defect and must not
cause an importer-source change.

──────────────────────────────────────────────────────────────────────────────
2. REPAIR CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Classification:

- source-external audit-process infrastructure repair;
- bounded process-materialization rule;
- no product or repository behavior;
- no reopened architecture seam;
- no launcher-package change;
- no qualified-package import-interface change;
- no root-layout redesign;
- no runtime-validation change.

The predecessor importer was not independently accepted. This repair finalizes
the existing V1 package before acceptance.

Retain the existing V1 contract and schema identifiers unless the existing
closed schemas make the repair literally impossible.

If a version advance appears necessary, stop with:

VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_BLOCKED

and report the exact incompatibility. Do not silently introduce V2 identifiers.

──────────────────────────────────────────────────────────────────────────────
3. FRESH REPAIR PACKAGE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-bootstrap-importer-v1-audit-repair-

Recommended structure:

source/
contract/
schemas/
tests/
tests/fixtures/
validation/
lineage/
provenance/
closeout/
manifest/
private/

No retained empty directory is permitted.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or multiply linked file is permitted.

Do not mutate the predecessor package.

──────────────────────────────────────────────────────────────────────────────
4. EXACT REPAIR SCOPE
──────────────────────────────────────────────────────────────────────────────

The only authorized semantic changes are:

A. Explicit nonauthority closure.

B. Correct failure-step custody.

Likely affected implementation surfaces include:

source/bootstrap_importer_v1.py
contract/bootstrap-importer-contract-v1.json
contract/bootstrap-failure-contract-v1.json
contract/bootstrap-result-contract-v1.json
schemas/bootstrap-importer-contract-v1.schema.json
schemas/bootstrap-failure-v1.schema.json
schemas/bootstrap-result-v1.schema.json
tests/test_bootstrap_importer_v1.py
tests/independent_bootstrap_validator_v1.py

Inspect the package before freezing the final touched set.

Do not change an unaffected file merely to regenerate it.

Validation, lineage, closeout, and manifest files will necessarily be new
evidence in the fresh repair package; they are not semantic implementation
scope.

Preserve unchanged:

- importer CLI;
- pinned interpreter contract;
- qualified-package manifest grammar;
- exact reconciliation-verdict lookup;
- exact five-artifact copy boundary;
- auxiliary-record schemas and roles;
- exact twelve-pointer root rebinding;
- normalization algorithm;
- Carrier 0002 payload semantics;
- Carrier 0002 request semantics;
- root layout;
- stdout and stderr contract;
- process exit classes, except where an existing failure record must carry
  corrected custody;
- failure atomicity;
- no-target-access rule;
- no-network and no-Git posture.

──────────────────────────────────────────────────────────────────────────────
5. EXPLICIT NONAUTHORITY CLOSURE
──────────────────────────────────────────────────────────────────────────────

Independently inspect the predecessor’s complete authority and nonauthority
field maps.

Freeze one closed nonauthority set covering at least:

- repository authority:
  false;
- source authority:
  false;
- product authority:
  false;
- runtime authority:
  false;
- deployment authority:
  false;
- publication authority:
  false;
- commit authority:
  false;
- V3 target-correctness authority:
  false;
- audit-verdict authority:
  false;
- readiness authority:
  false;
- A6 authority:
  false.

Use the package’s existing naming and nesting conventions where already
defined. Do not create duplicate synonyms for the same authority dimension.

The closed importer contract must contain explicit publication and commit
nonauthority.

Every materialized authority-boundary record must contain the same closed
required set, including explicit:

- publication authority:
  false;
- commit authority:
  false.

Do not rely on:

- omission;
- inheritance;
- prose;
- a broad “process-only” caption;
- another record;
- a consumer assumption.

Require exact agreement among:

- closed importer contract;
- applicable JSON Schema projection;
- generated authority-boundary record;
- bootstrap result;
- bootstrap failure result where authority fields are present;
- final implementation report’s classification.

Add independent negative causals for:

- commit field omitted;
- commit set true;
- publication field omitted;
- publication set true;
- contract and generated record disagree;
- generated record has an unknown authority field;
- generated record silently narrows the contract set;
- generated record silently widens the contract set;
- process-only caption present but explicit fields missing.

Every mutation must reject for a specific mechanism-level reason.

──────────────────────────────────────────────────────────────────────────────
6. FAILURE-STEP STATE MODEL
──────────────────────────────────────────────────────────────────────────────

Inspect the predecessor contract, schemas, source, producer tests, and audit
causals to reconstruct the complete ordered bootstrap step model.

Retain one authoritative machine-readable step table in the repaired package.

At minimum, each step definition must include:

- ordinal;
- stable step ID;
- operation;
- prerequisites;
- commit point;
- expected persistent artifacts after completion;
- whether the step changes `completed_step_ordinal`;
- next permitted step.

Freeze the meaning:

`completed_step_ordinal`

equals the greatest ordinal whose defined commit point completed successfully
before the failure record was created.

It does not mean:

- the step before the currently named phase;
- the number of loop iterations begun;
- the last ordinal assigned before work;
- the failed step minus one unconditionally;
- the number of artifacts expected rather than retained.

Freeze separately:

- failed step ordinal;
- failed step ID;
- exact failed operation;
- exception or injected failure;
- partial artifacts;
- next-action authorization.

When a step’s complete artifact set has been:

1. exclusively created;
2. fully written;
3. fsynced;
4. closed;
5. reopened and verified;
6. accepted at its defined commit point;

advance the completed-step state exactly once.

A later failure must preserve that completed ordinal.

A failure before the commit point must retain the previous completed ordinal.

Implement this as one generic state transition mechanism. Do not special-case
the three reported failure labels.

If the current contract already defines this model, make the implementation
conform exactly.

If the model is not currently explicit, add the smallest closed contract field
map needed to remove ambiguity.

──────────────────────────────────────────────────────────────────────────────
7. REQUIRED THREE-CAUSAL REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Reproduce the predecessor behavior first, using immutable predecessor evidence
or an audit-owned exact predecessor source copy.

Then prove the repaired behavior:

A. Fixed-environment failure

Require:

- failed step identified exactly;
- `completed_step_ordinal = 6`;
- predecessor recorded 5;
- all step-6 commit-point artifacts exist and verify;
- no step-7 artifact is falsely claimed complete;
- partial artifacts exact.

B. Normalization-proof retention failure

Require:

- failed step identified exactly;
- `completed_step_ordinal = 8`;
- predecessor recorded 7;
- all step-8 commit-point artifacts exist and verify;
- no later step falsely claimed complete.

C. Request-retention failure

Require:

- failed step identified exactly;
- `completed_step_ordinal = 10`;
- predecessor recorded 9;
- all step-10 commit-point artifacts exist and verify;
- no later step falsely claimed complete.

Retain byte-level predecessor/repaired comparisons for the applicable failure
records.

Do not claim that only one integer field changes unless the exact bytes prove
that.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE STEP-BOUNDARY CAUSAL MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not limit validation to the three reported failures.

For every bootstrap step, inject failures at the meaningful boundaries:

1. before the step begins;
2. after partial write, when safely supported;
3. after full write but before fsync;
4. after fsync but before close;
5. after close but before verification;
6. after verification but before commit-state advancement;
7. immediately after the commit point;
8. before the next step begins.

Use only injections supported safely by the implementation.

For every causal verify:

- exact completed ordinal;
- exact failed ordinal and ID;
- exact retained artifacts;
- no missing artifact reported present;
- no present artifact omitted;
- no success result;
- root locator retained;
- bootstrap-start retained;
- canonical failure outcome retained;
- target inspection false;
- no later-step progression;
- no overwrite;
- no retry inside the failed root.

The matrix must specifically prove that the completed ordinal is not derived by
a fixed `failed_ordinal - 1` rule.

Retain a complete per-step causal ledger.

──────────────────────────────────────────────────────────────────────────────
9. SOURCE IMPLEMENTATION REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

The repaired importer must continue to:

- use no network;
- use no Git;
- use no shell;
- launch no subprocess;
- inspect no candidate or target path;
- scan no broad Downloads subtree;
- adopt no existing audit root;
- overwrite no artifact;
- follow no symlink;
- copy exactly five process artifacts;
- regenerate fresh auxiliary records;
- generate the exact root-bound launch contract;
- generate Carrier 0002 payload and request;
- not execute Carrier 0002.

Do not change the qualified launcher, wrapper, CLI contract, request contract,
environment policy, or reconciliation capsule.

──────────────────────────────────────────────────────────────────────────────
10. LINEAGE AND SUPERSESSION
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/predecessor-importer-binding-v1.json
lineage/blocking-audit-binding-v1.json
lineage/proposed-supersession-v1.json

Bind:

- predecessor root identity;
- predecessor manifests and final inventory;
- predecessor source identity;
- blocking audit root identity;
- exact consumed findings;
- new repair root identity;
- old/new contract identities;
- old/new source identities;
- exact touched semantic files;
- bounded supersession scope.

Required scope:

- explicit nonauthority closure;
- failure-step custody correctness;
- related tests, schemas, and evidence only.

Explicitly preserve:

- all other importer semantics;
- qualified launcher package authority;
- reconciliation interface;
- V3 target nonauthority;
- absence of runtime validation;
- absence of audit acceptance.

The new package remains proposed pending fresh independent audit.

Do not call it accepted or current authority.

──────────────────────────────────────────────────────────────────────────────
11. PRODUCER VALIDATION
──────────────────────────────────────────────────────────────────────────────

Run the complete predecessor producer suite against the repaired source and
contracts, plus the new cases.

Require:

- all prior 56 named cases still pass;
- every prior case name remains present unless an exact documented rename is
  required;
- no prior mechanism is weakened;
- new nonauthority cases pass;
- new step-boundary cases pass;
- no false acceptance;
- exact case count and name closure;
- no skip;
- no hidden platform branch.

Re-run:

- two distinct successful importer materializations;
- normalized deterministic comparison;
- importer-to-launcher Carrier 0002 handoff;
- package manifest verification;
- reconciliation exact-path verdict verification;
- security/static source review;
- no-target-access checks.

Carrier 0002 handoff must still pass unchanged.

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a fresh independent validator that imports no producer test helper
and does not derive cases from producer fixtures.

It must independently validate:

- closed authority/nonauthority set;
- contract/record agreement;
- required commit/publication false fields;
- ordered step table;
- commit-point semantics;
- all three reported off-by-one causals;
- representative precommit and postcommit failure boundaries for every step;
- exact copy boundary;
- exact reconciliation verdict path;
- exact twelve-pointer rebinding;
- Carrier 0002 request semantics;
- package closure.

Require:

- independently literal expected case names;
- independently literal expected reasons;
- uniqueness;
- exact set reconciliation;
- zero false acceptance.

──────────────────────────────────────────────────────────────────────────────
13. DETERMINISM AND HANDOFF
──────────────────────────────────────────────────────────────────────────────

Run the repaired importer successfully into two distinct fresh
implementation-owned roots.

Require:

- distinct physical roots;
- exact copied source bytes;
- normalized auxiliary records equal;
- normalized launch contracts equal;
- normalized bootstrap results equal;
- payload source equal;
- normalized requests equal;
- no target inspection;
- no supplied-root mutation.

Use one successful root for a bounded Carrier 0002 handoff through the exact
qualified launcher and wrapper.

Require the same prior successful handoff conditions.

Do not execute any V3 target process.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS EVIDENCE
──────────────────────────────────────────────────────────────────────────────

This is producer validation, not the independent audit.

Nevertheless, retain a complete contemporaneous record for every validation
subprocess the implementation task launches:

- argv;
- cwd;
- explicit environment;
- start before spawn;
- stdout;
- stderr;
- exit/signal;
- reaping;
- descriptor closure.

Do not claim coverage of opaque platform carrier internals.

Do not alter importer source to address the prior audit’s top-level
process-ledger gap. That audit-process requirement belongs to the next
independent-audit prompt.

──────────────────────────────────────────────────────────────────────────────
15. SECURITY AND ARTIFACT REVIEW
──────────────────────────────────────────────────────────────────────────────

Review the complete repaired package for:

- network APIs;
- subprocess or shell use in importer source;
- Git;
- repository/target paths;
- broad Downloads scanning;
- latest/prefix selection;
- existing-root adoption;
- symlink traversal;
- overwrite;
- unsafe modes;
- secret-bearing output;
- private keys;
- cloud/API tokens;
- bearer/JWT/Vault material.

Do not emit matched sensitive payload content.

No new authority field may accidentally become true or implicit.

──────────────────────────────────────────────────────────────────────────────
16. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Retain every failed or superseded implementation or validation attempt
separately.

No failed attempt may contribute:

- final source identity;
- final contract identity;
- final pass count;
- final causal count;
- final package inventory;
- final manifest;
- readiness verdict.

Do not overwrite failed artifacts.

──────────────────────────────────────────────────────────────────────────────
17. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Repeat complete inventories for:

- predecessor importer root;
- blocking independent-audit root;
- qualified launcher root if opened;
- import-reconciliation root if opened.

Require exact opening/closing equality.

Remove only implementation-owned fixture and private roots after retaining
complete inventories.

For every removed root, perform two fresh `lstat` observations and require
ENOENT twice.

Verify no process or descriptor survivor remains.

──────────────────────────────────────────────────────────────────────────────
18. PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use two independent lstat/no-follow manifest generators.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no unexplained or empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests.

Finalize:

- repaired source;
- repaired contracts and schema projections;
- ordered step table;
- predecessor/repaired causal comparison;
- complete step-boundary causal ledger;
- producer tests/results;
- independent validator/results;
- deterministic materialization records;
- handoff result;
- lineage and proposed supersession;
- security review;
- attempt index;
- cleanup;
- final report;
- final inventory;
- manifest pair.

──────────────────────────────────────────────────────────────────────────────
19. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop with
`VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_BLOCKED`
on:

- predecessor input drift;
- audit-finding ambiguity;
- inability to define exact completed-step semantics;
- need to change the qualified launcher or wrapper;
- need to change copy or root-rebinding semantics;
- need to inspect a V3 target;
- required package-version advance;
- any unrelated importer behavior change;
- false acceptance in producer or independent validation;
- nondeterministic normalized output;
- Carrier 0002 handoff regression;
- supplied-root mutation.

Return `IMPLEMENTATION_PROVENANCE_MISMATCH` on:

- incomplete retained implementation evidence;
- opening/closing supplied-root inequality;
- missing final artifact;
- package-manifest closure failure;
- mutation of an immutable input.

Do not repair supplied inputs.

──────────────────────────────────────────────────────────────────────────────
20. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-package identity
3. Immutable input identities
4. Exact findings consumed
5. Repair classification and authority
6. Exact touched semantic files
7. Before/after source identities
8. Before/after contract and schema identities
9. Complete repaired nonauthority field map
10. Generated authority-boundary field map
11. Ordered bootstrap step model
12. Exact `completed_step_ordinal` semantics
13. Three reported causal reproductions
14. Complete step-boundary causal matrix
15. Producer validation results
16. Independent validator results
17. Two deterministic materializations
18. Carrier 0002 handoff result
19. Security/artifact findings
20. Failed and superseded attempts
21. Supplied-root closing equality
22. Fixture cleanup and ENOENT observations
23. Final package inventory and manifests
24. Severity-ranked residual findings
25. Remaining uncertainty and nonclaims
26. Explicit confirmations

Required confirmations:

PREDECESSOR_IMPORTER_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
IMPORTER_CLI_NOT_CHANGED
COPY_BOUNDARY_NOT_CHANGED
ROOT_REBINDING_SEMANTICS_NOT_CHANGED
CARRIER_0002_SEMANTICS_NOT_CHANGED
COMMIT_AUTHORITY_EXPLICITLY_FALSE
PUBLICATION_AUTHORITY_EXPLICITLY_FALSE
CONTRACT_AND_AUTHORITY_RECORD_NONAUTHORITY_SETS_EQUAL
COMPLETED_STEP_ORDINAL_SEMANTICS_FROZEN
FIXED_ENVIRONMENT_FAILURE_COMPLETED_STEP_6
NORMALIZATION_FAILURE_COMPLETED_STEP_8
REQUEST_FAILURE_COMPLETED_STEP_10
STEP_BOUNDARY_CAUSALS_PASSED
PRODUCER_VALIDATION_PASSED
INDEPENDENT_VALIDATOR_PASSED
TWO_DETERMINISTIC_MATERIALIZATIONS_PASSED
IMPORTER_TO_LAUNCHER_HANDOFF_PASSED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
A6_NOT_STARTED
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

After this package reports
`VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT`,
perform a fresh independent audit of the repaired importer. That audit must
explicitly treat root allocation as the sole bootstrap exception and record
every subsequent host-level carrier; do not repeat the prior ledger gap.

**Source:** Codex’s bootstrap-importer independent-audit report above.

**Confidence:** 0.995 that the importer requires only this bounded repair; 0.99 that the process-ledger gap belongs to the audit harness rather than importer behavior; 0.98 that no launcher, import-interface, or V3-target change is justified.
