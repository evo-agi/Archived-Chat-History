## Assessment

This is a sound **BLOCK**, not a rejection of the architecture.

The authority model survived the audit: the verifier remains an ES-owned bounded assurance tool whose output proves structural closure only. It does not acquire readiness, product, runtime, admission, or orchestration authority. That matches the frozen external-verifier design and the broader rule that proof scaffolding and generated evidence remain non-authoritative.  

The patch needs one bounded repair pass:

| Finding | Disposition |
|---|---|
| EV-01 case-insensitive physical-boundary bypass | High patch defect; repair |
| EV-02 non-LF manifest separators accepted | High patch defect; repair |
| EV-03 traceback on deeply nested package JSON | Medium patch defect; repair |
| EV-04 resource limits enforced too late | Medium patch defect; repair |
| EV-05 unsupported descriptor operations can escape canonically | Medium patch defect; repair |
| EV-06 test 29 depends on process umask | Medium test defect; repair |
| EV-07 missing isolated causal coverage | Medium test defect; repair |
| EV-08 oversized decimal gets wrong error class | Low patch defect; repair now |
| EV-09 improperly rooted audit Git command | Audit-process issue only; no patch change |

Do **not** commit, restart A6, or revisit the architecture. Return to the same implementation worktree, repair within the existing 13-path tranche, generate new exact provenance, and submit the changed bytes to an entirely fresh read-only audit. The operating protocol requires exactly that loop after a blocking audit. 

The current audit cannot later become accepting: the patch bytes will change, and EV-09 separately prevents strict audit-process acceptance. The re-audit must start from a new audit root and keep every Git command explicitly rooted at the implementation worktree.

## Codex repair prompt

```text
Permission is workspace-write.

Resume the Evidence Verification v1 implementation in the same implementation
worktree and repair the independently audited findings EV-01 through EV-08.

Do not address EV-09 through repository changes. EV-09 is an audit-process
defect that must be eliminated by the later fresh audit.

This is a bounded audit-repair turn.

Do not redesign the external-verifier architecture.
Do not create another worktree.
Do not reset, clean, restore, rebase, or discard the current patch.
Do not modify the Repair 10I candidate.
Do not modify the sealed A6D or amendment children.
Do not modify the completed audit evidence.
Do not stage, commit, push, create a PR, install, deploy, restart A6, invoke a
live service, contact a network, or perform an independent audit.

No subagents. You are the sole repository writer.

## 1. Paths

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Implementation branch:

codex/evidence-verification-v1

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Completed audit root, read-only:

AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as implementation cwd or source root:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D verifier amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required new repair-evidence directory:

REPAIR_EVIDENCE=$EVIDENCE/audit-repair-v1

Require REPAIR_EVIDENCE to be absent before creation.

## 2. Mandatory opening provenance gate

Before editing, require IMPL_R:

- physical root equals lexical path;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked files;
- exactly nine untracked files;
- every path regular;
- every working-tree mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no path outside the audited set;
- no Git operation marker or lock.

Expected 13 paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Require current audited identities:

- canonical patch-manifest SHA-256:
  `d957a6b89f6c5eba827bfc700e82ba5477e8190e1f0172631efa67d5c421edb2`
- tracked binary-diff SHA-256:
  `f4f7998df20040b993e4a9dae6b8f4581947b868d26411d1002909a853344bd1`
- final provenance recipe source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
- verifier SHA-256:
  `aa4ba2ca528c38ef3f5bd969d0a4f04d7b240055ff42f03c504204dd1f9699c7`
- registry SHA-256:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`
- A6D successor layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`
- A6D amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`
- A6 policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`.

Run the exact final provenance recipe twice before editing.

Require:

- byte-identical outputs;
- equality with the retained canonical manifest;
- exact current per-file identities;
- exact tracked binary-diff digest.

Require the audit root to retain, unchanged:

- opening and closing provenance records;
- `validation/case-alias-reproduction.json`;
- `validation/vt-manifest-reproduction.json`;
- `validation/nested-json-reproduction-2.json`;
- `validation/fresh-1/result.json`;
- `validation/fresh-2/result.json`;
- `closeout/closing-gate.json`;
- the complete audit-created path inventory.

Require CANDIDATE_R to remain exact:

- device/inode:
  `16777234/122118502`;
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`;
- source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
- membership:
  `389 / 375 / 14`;
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require A6D manifest unchanged:

`dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`

Require A6D_AMEND manifest unchanged:

`a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`

Stop on any mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_BASELINE_MISMATCH

## 3. Repair-evidence root

After the opening gate, create REPAIR_EVIDENCE under umask `077` with:

- `opening/`
- `findings/`
- `validation/`
- `provenance/`
- `closeout/`

All directories mode `0700`.

All files regular, single-link, mode `0600` unless an exact executable
evidence file is explicitly required.

Do not overwrite prior implementation or audit evidence.

Retain one audit-finding disposition record that classifies:

- EV-01 through EV-08 as patch or test defects to repair;
- EV-09 as an audit-process defect requiring no repository change.

## 4. Exact repair scope

The final repository path set remains the same 13 audited paths.

During this repair, changes are authorized only within this subset:

1. `PLANS.md`
2. `.docs/system_overview/artifact_hygiene.md`
3. `.docs/system_overview/capability_probing.md`
4. `.docs/system_overview/evidence_verification.md`
5. `tools/evidence_verify/verify_v1.py`
6. `tools/evidence_verify/test_verify_v1.py`

Modify only the paths genuinely required by the repairs.

Keep byte-identical during this repair:

- `.docs/system_overview/boundaries.md`
- `tools/evidence_verify/registry_v1.json`
- all three layout JSON files
- both historical fixture files.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No public or product schema.
No Go source.
No runtime route.

If a registry, layout, fixture, boundary-document, or new-path change appears
necessary, stop:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_SCOPE_EXPANSION_REQUIRED

## 5. EV-01 — physical package/target/candidate boundary

Replace string-spelling authority with physical filesystem identity.

Do not use case folding, lowercasing, `realpath()` string equality, or
`commonpath()` as the deciding boundary.

Use no-follow, descriptor-bound physical observations.

At minimum:

1. Open the verifier package root and target root as directories.
2. Bind each to stable `(device,inode,type)` identity.
3. Derive each directory’s ancestor chain by descriptor-relative parent
   traversal until the physical root.
4. Reject when:
   - package and target are the same object;
   - package root appears in target’s ancestor chain;
   - target root appears in package’s ancestor chain.
5. For the pre-seal manifest candidate:
   - require a regular, single-link file;
   - bind opening identity;
   - bind its parent-directory ancestor chain;
   - reject when it resides within or aliases the package or target;
   - reject when its identity changes through complete read;
   - reject symlink, hardlink, case-alias, or containment substitution.
6. Repeat and compare the relevant physical identities at closing.

A different-case spelling that resolves to the same package, target, or
candidate object must reject identically to the canonical spelling.

Do not introduce a permissive fallback when an identity or parent operation
cannot be proven.

Required causals include:

- target physically nested beneath package through canonical spelling;
- the same nesting through case-variant spelling;
- package beneath target;
- exact target/package alias;
- candidate beneath package;
- candidate beneath target;
- case-variant candidate containment;
- candidate symlink alias;
- candidate hardlink alias where applicable;
- genuinely disjoint package, target, and candidate pass.

Preserve output minimization: no absolute path in canonical stdout.

## 6. EV-02 — literal-LF manifest grammar

Remove use of `str.splitlines()` or any equivalent accepting non-LF line
separators.

Parse raw manifest bytes using literal byte `0x0a` as the only line separator.

Require:

- exactly one final LF;
- no CR;
- no vertical tab;
- no form feed;
- no NEL;
- no Unicode line/paragraph separator;
- no embedded control separator;
- exact ASCII grammar for header, count, row delimiters, decimal, digest, and
  encoded path;
- no extra blank line.

A non-LF separator must return:

- outcome `reject`;
- error class `MANIFEST_CANONICAL`;
- the documented blocking exit;
- one canonical JSON line;
- no traceback.

Add pre-seal and sealed causals for at least:

- vertical tab;
- form feed;
- NEL;
- missing terminal LF;
- extra blank line;
- CRLF.

Retain the audit’s vertical-tab reproduction as expected-negative predecessor
evidence.

## 7. EV-03 — malformed package JSON and canonical failure

Bound registry/spec JSON parsing before `json.loads()` can recurse
unboundedly.

Implement a deterministic lexical preflight that:

- operates on raw UTF-8 bytes;
- respects quoted strings and escapes;
- counts object/array nesting only outside strings;
- rejects an explicitly documented maximum nesting depth;
- rejects oversized registry/spec source before parsing;
- rejects malformed escape or structural state;
- does not recurse itself.

The maximum may be a fixed verifier-package constant. It must comfortably
admit all three current specs and a schema-compatible fourth spec.

Map malformed registry/spec JSON to the existing source-package error
taxonomy, not to a traceback.

At the CLI boundary:

- catch `RecursionError`;
- catch expected JSON/Unicode/value/overflow failures;
- catch unexpected ordinary `Exception` fail-closed;
- emit exactly one canonical blocking JSON line;
- emit no traceback;
- preserve `KeyboardInterrupt`/process interruption semantics rather than
  converting them to pass.

Add tests for:

- nesting immediately below the bound;
- nesting at the bound;
- nesting above the bound;
- audit’s deep nested registry reproduction;
- malformed escapes;
- invalid UTF-8;
- package parse error with empty stderr/one canonical stdout line.

## 8. EV-04 — early resource-budget enforcement

Enforce resource limits before unbounded work.

Do not materialize an unbounded target directory with `os.listdir()` before
checking limits.

Use bounded iterative traversal, such as descriptor-relative `os.scandir()`,
with fail-closed capability handling.

Require:

1. Manifest payload count checked against `max_files` before row processing.
2. Each declared size checked against `max_single_file_bytes`.
3. Declared aggregate bytes accumulated and checked during parsing.
4. Target entry counts checked during traversal before collecting beyond the
   admitted bound.
5. Directory counts checked incrementally.
6. Actual file size checked before opening or hashing.
7. Actual aggregate size checked before hashing the next file.
8. Both stability scans individually remain within the declared aggregate
   budget.
9. No payload above the applicable budget is read merely to discover that it
   is oversized.
10. I/O or capability uncertainty remains fail-closed.

Add tiny-budget causals proving:

- too many files reject before full enumeration/storage;
- too many directories reject;
- one oversized file rejects before read;
- aggregate-size overflow rejects before the overflow-causing file is read;
- valid exact-bound target passes;
- repeated scan remains deterministic.

Use small private fixtures. Do not create a large stress tree.

Document that two stability scans may read at most twice the accepted aggregate
payload bound, rather than an unbounded multiple.

## 9. EV-05 — behaviorally required descriptor operations

At the invocation boundary, behaviorally establish every required
descriptor-relative/no-follow operation against a safe verifier-owned or
package-owned read-only object.

At minimum cover the operations actually used for:

- opening directories;
- descriptor-relative stat;
- no-follow component observation;
- descriptor-relative parent traversal;
- bounded directory iteration;
- file opening and reading.

Do not infer availability from attribute presence alone.

When a required operation raises `NotImplementedError`, unsupported-operation
`OSError`, or cannot be proven:

- emit one canonical result;
- outcome `indeterminate`;
- error class `IO_OR_RACE`;
- exit `7`;
- no traceback;
- no fallback to pathname traversal.

Also catch the same capability failure if it arises after preflight.

Add causals that inject `NotImplementedError` and the relevant unsupported
`OSError` at each required operation boundary.

Clarify in `capability_probing.md` that descriptor-relative traversal applies
to the untrusted target and manifest candidate, while verifier-package
identity is independently bound.

## 10. EV-06 — umask-independent tests

All test-created registry, spec, manifest, sidecar, helper, payload, and
directory modes must be explicit.

Do not rely on the parent process umask.

In particular, test 29’s temporary new layout spec must be explicitly set to
the required mode before invocation.

Run the complete test command under at least:

- umask `077`;
- umask `022`.

Require all tests to pass under both environments with zero skip.

Record the umask as a validation input, but do not make verifier behavior
depend on it.

## 11. EV-07 — isolated causal coverage

Add isolated, mechanism-specific tests.

### Missing required root

- remove one required root directory and its governed contents;
- regenerate a self-consistent manifest/sidecar or pre-seal candidate;
- ensure there is no unrelated extra or stale row;
- require the exact layout/missing-root failure.

### Expected-path symlink

- replace an exact required path, not an added extra path, with a symlink;
- keep the fixture otherwise self-consistent;
- require the exact type failure.

### Expected-path special file

- replace an exact required path with a FIFO or other safe test-owned special
  file;
- keep the fixture otherwise self-consistent;
- require the exact type failure;
- ensure no operation blocks on the FIFO.

Preserve separate extra-path symlink/special-file coverage.

Assert the expected failure class rather than only `exit != 0`.

## 12. EV-08 — bounded decimal parsing

Do not pass an unbounded digit string directly to Python `int()`.

Implement one bounded canonical unsigned-decimal parser that:

- rejects empty input;
- rejects sign;
- rejects leading zero except canonical `0` where allowed;
- rejects non-ASCII digits;
- enforces a lexical digit bound derived from the applicable maximum;
- accumulates with an early numeric ceiling;
- never triggers Python’s integer-conversion digit limit.

Apply it to:

- payload count;
- payload size;
- every other manifest decimal field.

Classify lexical/noncanonical conversion failure as:

`MANIFEST_CANONICAL`

Classify a canonical numeric value exceeding a declared layout resource limit
under the existing resource/closure error class.

Add tests for:

- a digit string beyond Python’s conversion limit;
- leading zero;
- signed value;
- non-ASCII digit;
- exact maximum;
- maximum plus one.

## 13. EV-09 disposition

Make no repository change for EV-09.

Record:

- classification:
  audit-process issue;
- patch implication:
  none;
- required future action:
  run the fresh audit in a new audit root and require every Git operation to
  use `git -C "$IMPL_R"` plus `GIT_OPTIONAL_LOCKS=0`.

Do not claim that this implementation repair resolves the prior audit-process
deviation.

## 14. Documentation alignment

Update only the authorized documentation needed to describe the repaired
contract.

At minimum align:

- physical identity and ancestry rather than case-sensitive string paths;
- literal-LF manifest grammar;
- bounded registry/spec parsing;
- incremental resource-budget enforcement;
- capability failures returning canonical indeterminate output;
- descriptor-relative traversal applying to the target;
- test matrix wording as:
  - 30 original architecture-reset causals;
  - ten original mode regressions;
  - the newly added audit-repair causals.

Do not renumber or claim an exact total until the final discovered test set is
known.

Do not change authority classification or widen the verifier’s role.

## 15. Complete fresh validation

After all repairs, rerun the entire validation program from the beginning.

Do not use prior passes as final proof.

Use the exact Python interpreter:

`/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`

Expected identity:

- version `3.13.4`;
- size `119424`;
- SHA-256
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Use:

- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- private repair-owned `TMPDIR`;
- no network.

Required gates:

1. Parse every Python source with `ast.parse`.
2. Strictly parse registry and all three layout specs.
3. Verify registry/spec hashes remain exact if their bytes are frozen.
4. Run the full test command twice under umask `077`.
5. Run the full test command twice under umask `022`.
6. Require equivalent complete discovered test sets and outcomes.
7. Require zero failure, error, or skip.
8. Run every EV-01 through EV-08 causal explicitly.
9. Reproduce each vulnerable predecessor mechanism and demonstrate its repaired
   rejection or canonical outcome.
10. Verify sealed A6D twice.
11. Verify sealed A6D amendment twice.
12. Verify synthetic A6 pre-seal twice.
13. Seal the synthetic fixture with the test-owned writer.
14. Verify synthetic A6 sealed twice.
15. Require repeated canonical stdout byte equality.
16. Snapshot targets and verifier package before and after every no-write
    control.
17. Require exact equality.
18. Verify historical fixture bytes and hashes unchanged.
19. Run `git diff --check`.
20. Scan IMPL_R for:
    - `__pycache__`;
    - `.pyc`;
    - `.pytest_cache`;
    - generated manifests;
    - databases/journals;
    - locks;
    - fixture roots;
    - temporary output.

Every test fixture and repair-owned temporary root must be removed after its
owning check.

No repository Go suite.
No product execution.
No live service.
No target mutation.
No child process from the verifier.
No network.

## 16. Validation evidence

Retain under REPAIR_EVIDENCE:

- audit finding disposition;
- exact pre-repair provenance;
- exact changed source/docs/tests;
- vulnerable and repaired causal records;
- all test runs under both umasks;
- complete discovered test list;
- real-child compatibility records;
- synthetic pre-seal/sealed records;
- no-write snapshots;
- failed and superseded attempt index;
- cleanup;
- implementation report inputs.

Preserve the completed audit root byte-exact.

## 17. Final provenance

After all validation passes, use the exact existing final provenance recipe
source:

- source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`

Do not modify or reconstruct it.

Run it twice against IMPL_R.

Require:

- byte-identical complete canonical outputs;
- exactly the same 13-path scope;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deletion;
- zero rename;
- zero unsupported type;
- no path outside scope.

Retain:

- exact recipe source;
- both outputs;
- new canonical patch-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities.

The prior audit manifest becomes predecessor provenance only and cannot qualify
the repaired bytes.

## 18. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- all 13 regular logical mode `100644`;
- `git diff --check` clean;
- no repository cache, bytecode, fixture, database, lock, generated manifest,
  or temporary output.

Require CANDIDATE_R closing identity to equal opening identity.

Require A6D and A6D_AMEND unchanged.

Require AUDIT unchanged.

Require PRIMARY_R never used as implementation cwd or source root.

Do not remove IMPL_R or EVIDENCE.

## 19. Mandatory stops

Stop on:

- opening provenance mismatch;
- any audit input mutation;
- need for a seventh repair path;
- need to change registry, layout specs, fixtures, or boundaries document;
- inability to perform physical-identity ancestry checks without a fallback;
- acceptance of a non-LF separator;
- any traceback or noncanonical CLI failure;
- resource limits still enforced only after unbounded work;
- unsupported descriptor operation falls back to pathname behavior;
- full tests differ by umask;
- isolated causal cannot distinguish its intended mechanism;
- real A6D or amendment child fails;
- any required test skips;
- target or package mutation;
- unstable final provenance.

## 20. Verdicts

Opening mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_BASELINE_MISMATCH

Scope expansion:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_SCOPE_EXPANSION_REQUIRED

Repair or validation failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_BLOCKED

Final provenance failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_PROVENANCE_BLOCKED

Complete success:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_REAUDIT

## 21. Required final report

Include:

1. Opening repository and provenance identity.
2. Exact audit target and finding ledger consumed.
3. EV-01 through EV-09 dispositions.
4. Exact repair-path subset.
5. Per-finding source mechanism and correction.
6. Physical-boundary algorithm.
7. Literal-LF manifest parser.
8. JSON depth/size and canonical-error behavior.
9. Incremental resource-limit behavior.
10. Descriptor-capability behavior.
11. Umask-independent fixture behavior.
12. Isolated causal additions.
13. Bounded decimal parsing.
14. Documentation alignment.
15. Exact fresh validation commands and outcomes.
16. Discovered complete test set and counts.
17. Results under umask `077` and `022`.
18. A6D and amendment compatibility runs.
19. No-write and deterministic-output results.
20. Final verifier SHA-256.
21. Registry and layout hashes, confirming whether unchanged.
22. Final exact 13-path manifest.
23. Final provenance recipe identity.
24. New tracked binary-diff SHA-256.
25. New canonical patch-manifest SHA-256.
26. Artifact hygiene and cleanup.
27. Authority/security widening:
    explicitly none, or exact contrary finding.
28. Remaining uncertainty and uninspected areas.
29. Explicit statements:
    - prior audit no longer qualifies changed bytes;
    - fresh re-audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## After repair

A successful repair must go to a **new** read-only audit conversation with a new audit root. The new audit should reproduce the new manifest before inspecting correctness, then rerun the specific EV-01 through EV-08 adversarial controls. It must not reuse the previous audit’s correctness verdict, and it must keep every Git command explicitly rooted to avoid repeating EV-09.

Any changed byte invalidates the prior audit and requires new validation, new provenance, and a fresh audit.  Exact provenance must again be reproduced before correctness inspection. 

### Sources

- Codex’s independent-audit `BLOCK` report supplied in this turn.
- The selected ES-owned external-verifier architecture and non-recursive bootstrap.  
- Frozen verifier authority and layout contracts. 
- Milestone 0’s prohibition on proof scaffolding becoming architecture or authority. 
- Repair and fresh re-audit protocol. 
- Provenance-before-correctness audit sequence. 

**Confidence**

- Audit provenance and BLOCK decision: **0.995**
- Authority/decomposition remains sound: **0.99**
- EV-01 and EV-02 severity: **0.99**
- Repairability within the existing 13-path tranche: **0.94**
- Correctness of treating EV-09 as audit-process-only: **0.999**
- Correct next gate after repair: fresh independent re-audit, **0.999**
