## Engineering assessment

This report clears the producer-qualification gate. It does **not** clear the independent-audit gate or authorize current-subject construction.

The load-bearing results are coherent:

- The sealed implementation package is rooted at `/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634`, identity `16777234/180884963/0700`.
- All 41 governing Generation‑2 roles were resolved through the successor’s current-role registry rather than predecessor or fallback records.
- Three source attempts were used; only Attempt 3 became current.
- The frozen implementation consists of one production source and nine qualification sources. That consolidation is not inherently wrong, but the independent audit must reconstruct the 24 production and nine qualification component boundaries rather than accepting the registry’s claim.
- Two physically distinct rehearsals completed E00 and G00–G29, produced the exact 73-path/61-file subject namespace, normalized equal, and passed an independent rehearsal validator.
- Attempt 2 physically exercised post-locator failure handling at G06. Its failed root remains immutable and must be independently authenticated through the exact retained path—never found by scanning.
- Source freeze and frozen-byte requalification passed.
- The implementation package terminally closed with 112 physical entries, a 110-entry terminal manifest projection, and a 109-entry temporal projection.
- The status correctly remains “pending independent audit,” and one-shot use remains unauthorized.

The independent audit should concentrate on five acceptance surfaces that producer qualification cannot settle by itself:

1. Whether the single 65,305-byte production file actually preserves all 24 component authorities and one-writer boundaries.
2. Whether the package’s source freeze, Attempt 1–3 lineage, and rehearsal-to-frozen-source bindings are exact and noncircular.
3. Whether the matrices, 946-case lane, 137-case lane, confirmation registry, and independent validators are substantively correct rather than merely internally consistent.
4. Whether two **fresh audit-owned rehearsals**, launched directly from the exact sealed production source, reproduce the claimed result.
5. Whether the independent audit itself retains complete process, stream, root, cleanup, and terminal evidence.

I have not independently opened the cited artifacts; this assessment is grounded in Codex’s inline report. The next prompt therefore treats every package claim as an audit target, not as an established fact.

```text
FRESH SOURCE-EXTERNAL INDEPENDENT AUDIT OF THE SEALED
GENERATION-2 SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

Objective

Perform the required fresh, source-external independent audit of the sealed
Generation-2 reconstruction-parent implementation package.

Independently authenticate the implementation package, reconstruct its current
authority and source boundaries, audit its source and qualification evidence,
rerun the governing validation lanes using audit-owned logic, execute two
fresh disposable subject rehearsals directly from the exact frozen production
source, independently validate and compare those rehearsals, and issue the
implementation-package acceptance decision.

Do not construct the authoritative current schema subject.

Do not modify or repair the implementation package.

Do not use the implementation package’s qualification conclusions as audit
authority. They are supplied evidence to be checked.

Do not import implementation-package production modules, qualification
helpers, mutation generators, expected-result maps, JSON observers, manifest
projectors, or process recorders into the audit tooling.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one fresh audit capsule and one finite, frozen, source-external audit
parent. Every child launch must pass through one audit-owned recorder.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace the material identities, source findings,
matrix results, process custody, causal findings, and final disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SEALED IMPLEMENTATION PACKAGE — FIXED SUBJECT
──────────────────────────────────────────────────────────────────────────────

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected root identity:

- device:
  16777234
- inode:
  180884963
- mode:
  0700
- producer verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

The user designates this exact root as the audit subject.

Do not select or substitute another implementation root by:

- basename;
- prefix;
- recursive search;
- recency;
- “latest”;
- score;
- report reference;
- fallback.

Expected package posture from the producer report:

- physical entries:
  112
- physical directories including root:
  17
- physical regular files:
  95
- terminal-manifest represented entries:
  110
- temporal-inventory represented entries:
  109
- current subject constructed:
  false
- status:
  gen2-bootstrap-repaired-reconstruction-parent-implemented-qualified-frozen-pending-independent-audit
- independent implementation audit:
  not performed
- one-shot current-subject use:
  unauthorized

Authenticate the exact package root before substantive audit work.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. SEALED IMPLEMENTATION-PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Authenticate these exact paths when present under the subject root:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Do not rely on the producer report for their final byte identities.

Independently establish:

- temporal-inventory file identity;
- manifest A identity;
- manifest B identity;
- A/B byte equality;
- exact terminal-manifest grammar;
- exact temporal-inventory grammar;
- root row exactly once;
- exact exclusions;
- exact 110-entry terminal projection;
- exact 109-entry temporal projection;
- exact 112-entry physical closure;
- all represented row identities;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory modes 0700;
- regular-file modes 0600;
- no cache or bytecode;
- no nonmanifest write after terminal closure.

Reproduce both terminal manifests independently from the live no-follow tree.

Reproduce the temporal projection independently under its declared exclusions.

A mechanically sealed package with semantically inconsistent contents is not
accepted merely because its manifests faithfully represent it.

──────────────────────────────────────────────────────────────────────────────
3. EXACT CURRENT SOURCE IDENTITIES
──────────────────────────────────────────────────────────────────────────────

Resolve the following solely through exact identity and the sealed package’s
manifest membership. Each identity must match exactly one path.

Final production-source registry:

- size:
  704
- SHA-256:
  1ded4df7836c16a153b6aab587d7d41903f1d8e907903a0000ae0efb518962c4

Final production source:

- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

Final qualification-source registry:

- size:
  4391
- SHA-256:
  57c22b15bab5667d32f9949867f198eddd41b0d345ad1d30111370c6c1548a8c

Source-freeze record:

- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

Frozen-source requalification:

- size:
  31819
- SHA-256:
  5e48332bec6610032ea14067eeecda20f653a14af03d0d27f9edc09db862e21f

Complete retained child ledger:

- SHA-256:
  68417ca2a1adf28f6a23eb4441ade07c53ff59ad41f4c064a72e7ef21b76537c

Supplied-root closing equality:

- SHA-256:
  bb1e3da048d3da927173096a167dcfbbc93a62dd8e9e65fbff11215cc7062331

Fixture/cache cleanup:

- SHA-256:
  661384f2c3fb9f06dfd01a3a3af79a067be506fe5dc1af9f3a8fc2de6e518699

Require:

- exactly one manifest match for each identity;
- regular file;
- mode 0600;
- link count one;
- stable no-follow read;
- no identity selected by name similarity or first match.

Retain:

opening/implementation-package-fixed-identity-resolution-v1.json

──────────────────────────────────────────────────────────────────────────────
4. GOVERNING SUCCESSOR GENERATION-2 PACKAGE
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Expected current-role registry:

contract/current-gen2-contract-role-registry-v2.json

- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

Expected manifest-pair SHA-256:

e83fcb2f7f27aef3af1306e9aa91f64fad6e24963937aff51b1e9eed42dbc3bf

Authenticate:

- root identity;
- package closure;
- temporal inventory;
- manifest pair;
- all 41 current roles;
- exact successor status;
- predecessor noncurrent status;
- independent bootstrap-order validator;
- explicit confirmation registry.

Resolve all governing implementation roles through this current-role registry
only.

Do not use a predecessor Generation-2 artifact as current.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. AUTHORITATIVE EXTERNAL INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use:

- the normative contract as sole semantic authority;
- only the fifteen current v2 schemas;
- only root-independent validation specifications and case registries.

Do not promote historical package results as fresh audit evidence.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
6. ATTEMPT-2 FAILED ROOT
──────────────────────────────────────────────────────────────────────────────

The producer report states that Attempt 2 physically exercised a post-locator
G06 failure and retained an immutable failed subject root with:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Expected failure-outcome identity:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Resolve the exact absolute root path only through the implementation package’s
authenticated Attempt-2 records and process ledger.

Do not scan `/Users/ds/Downloads`.
Do not search by inode globally.
Do not infer from prefixes.

If no unique exact path is retained, classify the Attempt-2 evidence as
nonqualifying and determine whether that defect is acceptance-affecting.

When uniquely resolved, authenticate read-only:

- root identity;
- bootstrap and locator chain;
- G00–G05 terminal phase records;
- G06 first blocker;
- process records and streams;
- partial inventory;
- failure outcome;
- authority posture;
- no same-root retry;
- no later mutation.

Require opening/closing equality for the failed root if opened.

Do not clean or modify it.

──────────────────────────────────────────────────────────────────────────────
7. FRESH AUDIT CAPSULE AND AUDIT-SOURCE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private audit root under `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-gen2-implementation-independent-audit-

Immediately emit:

AUDIT_ROOT=<absolute-path>

Before any supplied-root inspection, retain:

opening/bootstrap-start.json

Create a source-external finite audit parent under the audit root.

At most two complete audit-source attempts are permitted before source freeze.

The audit parent and its independent validators must not import:

- implementation-package production modules;
- implementation-package qualification modules;
- producer helpers;
- producer mutation generators;
- producer expected-result maps;
- producer JSON observers;
- producer process recorders;
- producer manifest projectors.

The audit tooling may use:

- the Python standard library;
- an already-installed Draft 2020-12 JSON Schema implementation, provided its
  exact module path, version, and identity are retained.

Do not install any dependency.

Before the audit epoch:

1. compile all audit source with pinned Python `-I -S -B`;
2. run AST/call-graph/dataflow checks;
3. run bytecode/exception-table/CFG checks;
4. prove finite control flow;
5. prove no stdin read;
6. prove no network, Git, shell, package mutation, product invocation, or
   persistent supervisor;
7. prove every child launch routes through one audit recorder;
8. prove success and failure closeout are reachable;
9. prove no postseal filesystem operation.

Freeze the exact audit source.

Retain:

opening/independent-audit-source-freeze-v1.json

After freeze, source modification is forbidden.

Launch the frozen audit parent exactly once.

Use no administrative continuation or replacement parent.

If audit-source preflight fails before supplied-root inspection, return:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
8. PLATFORM CAPTURE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before launching the frozen audit parent, run one bounded platform-capture
preflight that:

- writes a known line to stdout;
- writes a different known line to stderr;
- exits with a nonzero known exit code;
- uses no supplied root;
- creates no external fixture.

Retain exact:

- argv;
- cwd;
- environment;
- stdout bytes, size, SHA-256;
- stderr bytes, size, SHA-256;
- exit code;
- signal;
- start/completion;
- reaping.

The real audit parent may launch only if separate-stream and completion capture
are proven.

──────────────────────────────────────────────────────────────────────────────
9. AUDIT AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

The audit owns only:

- independent package authentication;
- read-only source and evidence analysis;
- audit-owned matrix execution;
- audit-owned disposable rehearsals;
- audit-owned causals;
- audit-owned process and filesystem custody;
- audit verdict;
- audit capsule closure.

The audit does not own:

- implementation repair;
- source modification;
- package mutation;
- current-subject construction;
- product/runtime behavior;
- repository truth;
- publication;
- deployment;
- A6.

Retain:

opening/independent-audit-authority-v1.json

──────────────────────────────────────────────────────────────────────────────
10. PACKAGE ROLE, SOURCE, AND ATTEMPT LINEAGE AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct:

- the 41 governing successor roles;
- the implementation package’s source-layout mapping;
- the 24 production component roles;
- the nine qualification component roles;
- exact source paths and identities;
- Attempt 1;
- Attempt 2;
- Attempt 3;
- current/noncurrent status;
- first blocker of each failed attempt;
- source freeze;
- frozen-source requalification;
- rehearsal-to-frozen-source linkage.

The fact that 24 production roles occupy one 65,305-byte source file is not
itself a defect.

Independently determine whether that file preserves:

- distinct role-specific functions or objects;
- explicit authority boundaries;
- one writer per mutable fact;
- one process-recorder owner;
- one failure-finalization owner;
- two independent manifest-projection implementations;
- one terminal-seal owner;
- no hidden qualification authority.

Retain:

analysis/source-role-and-attempt-lineage-audit-v1.json

Classify every source file exactly once as:

- current production;
- current qualification;
- superseded attempt source;
- validation fixture;
- generated evidence;
- historical lineage;
- forbidden/unknown.

Unknown count must be zero.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE FREEZE AND REQUALIFICATION AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently verify:

- source-freeze record identity;
- exact production and qualification registries;
- every frozen source identity;
- later modification forbidden;
- both passing rehearsals used the same bytes later frozen;
- frozen requalification used the frozen bytes;
- no rehearsal was rerun after freeze;
- no source changed after freeze;
- no superseded source contributes current results;
- no stale source identity appears in current acceptance evidence.

Compare every current validation result’s source bindings against the final
registries.

Retain:

analysis/source-freeze-and-result-binding-audit-v1.json

Any current result bound to a superseded source is a package defect.

──────────────────────────────────────────────────────────────────────────────
12. STATIC PRODUCTION-SOURCE AUDIT
──────────────────────────────────────────────────────────────────────────────

Perform fresh source-external AST, call-graph, dataflow, bytecode,
exception-table, and CFG analysis of the exact sealed production source.

Independently crosswalk:

- E00;
- G00;
- G01;
- G02;
- G03;
- G04;
- G05–G29;
- every process launch;
- every filesystem write;
- every directory creation;
- every locator write;
- every authority transition;
- every cleanup operation;
- temporal inventory;
- manifest A;
- manifest B;
- terminal seal.

Require:

- E00 allocates no subject root;
- E00 writes no subject path;
- G00 is the sole root allocator;
- `opening/` precedes bootstrap-start;
- locator follows durable bootstrap-start;
- G01 creates the exact complete directory set;
- no directory creation after G01;
- G02 authority follows G01;
- G03 follows G02;
- G04 follows G03;
- G05–G29 exact order;
- no phase skip or compensation;
- no network;
- no Git;
- no shell;
- no PATH executable lookup;
- no stdin read;
- no persistent loop;
- no broad Downloads traversal;
- no latest/prefix/score selection;
- no existing-root adoption;
- no overwrite;
- no successful second write;
- no same-root retry;
- no administrative continuation;
- one terminal seal transition;
- no postseal filesystem operation.

Retain exact source-line and bytecode evidence.

──────────────────────────────────────────────────────────────────────────────
13. STATIC QUALIFICATION-SOURCE AUDIT
──────────────────────────────────────────────────────────────────────────────

Inspect all nine qualification sources.

For every source bind:

- qualification role;
- imports;
- inputs;
- outputs;
- process-launch behavior;
- mutation behavior;
- result paths;
- producer or independent classification.

Require independent-validator roles to import neither:

- production modules;
- producer helpers;
- producer mutation generators;
- producer expected-result maps;
- production JSON observers;
- production manifest projectors.

Determine whether package qualification results actually came from the sources
identified in the final registry.

Retain:

analysis/qualification-source-independence-audit-v1.json

──────────────────────────────────────────────────────────────────────────────
14. AUTHORITY, WRITER, AND EVIDENCE-LIFECYCLE AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct from contract and source:

- every one of the 73 final subject paths;
- exact writer phase;
- exact writer function;
- maximum write count;
- staging/final posture;
- downstream consumers;
- documentary-evidence lifecycle;
- confirmation-validator writer;
- final ten-role registry ordering;
- registry-derived regeneration;
- explicit-confirmation derivation.

Require:

- one writer per path;
- no final path has multiple writers;
- no final path used as staging;
- no placeholder under a final result path;
- no overwrite;
- no adoption;
- confirmation validator result created exactly once;
- final ten-role registry after all ten results;
- regeneration derived from final registry;
- no hard-coded pass authority;
- no confirmation cycle;
- no result validates itself.

Retain:

analysis/writer-and-documentary-lifecycle-audit-v1.json

──────────────────────────────────────────────────────────────────────────────
15. PROCESS-CUSTODY AND FAILURE-SEMANTICS AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently adjudicate:

- platform/parent authority split;
- one production child recorder;
- prelaunch-before-spawn;
- ordinals;
- stdout/stderr custody;
- exit/signal;
- reaping;
- descriptor closure;
- fixed and dynamic effects;
- timeout handling;
- nonzero-exit effects;
- locator handling;
- cleanup-set equality;
- evidence-before-cleanup;
- same-root retry prohibition.

Use the retained Attempt-2 G06 failure as the primary live failure specimen.

Independently determine whether it proves:

- locator after durable bootstrap;
- root identity attribution;
- complete partial inventory;
- correct completed phases;
- G06 first blocker;
- explicit nonauthority;
- evidence retained before subsidiary cleanup;
- immutable failed root;
- no same-root retry.

Retain:

analysis/process-custody-and-failure-semantics-audit-v1.json

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT CONFIRMATION-REGISTRY AUDIT
──────────────────────────────────────────────────────────────────────────────

The package reports 125 current confirmations.

Independently authenticate the confirmation registry and every associated
evidence map.

For every confirmation bind:

- exact confirmation name;
- preterminal or terminal class;
- exact evidence document;
- exact pointer or externally observed terminal marker;
- observed value;
- expected value;
- hard-coded-success status;
- absence-as-success status;
- pass/fail.

Require:

- exactly 125 unique names;
- no duplicate;
- no missing expected name;
- no extra acceptance-bearing name;
- no hard-coded true;
- no absence-as-success;
- no stale source binding;
- no terminal confirmation preasserted as package data when the governing model
  requires an external terminal marker.

Retain:

analysis/complete-confirmation-evidence-audit-v1.json

──────────────────────────────────────────────────────────────────────────────
17. FRESH INDEPENDENT MATRIX EXECUTION
──────────────────────────────────────────────────────────────────────────────

Independently execute the governing case registries using audit-owned logic.

Do not import or invoke implementation-package matrix helpers.

Authenticate exact case-name registries and expected outcomes through the
successor Generation-2 and validation-specification roots.

Freshly execute:

- bootstrap-order cases:
  exact current registry; producer reports 55;
- external-interface cases:
  exact current registry; producer reports 50;
- JSON-observation cases:
  exact current registry; producer reports 49;
- schema/family cases:
  exact current registry; producer reports 35;
- process-custody/locator cases:
  exact current registry; producer reports 40;
- cleanup/failure-evidence cases:
  exact current registry; producer reports 40;
- writer/lifecycle cases:
  exact current registry; producer reports 73;
- namespace/temporal cases:
  exact current registry; producer reports 73;
- manifest/terminal cases:
  exact current registry; producer reports 40;
- negative-checker robustness cases:
  exact current registry; producer reports 45.

Also freshly and independently execute:

- all 946 negative cases;
- all 137 contradiction-regression cases;
- the 766/333 field-map closure.

For every lane require:

- exact case-name closure;
- unique names;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Do not treat agreement with producer results as sufficient; retain fresh
observations and mechanisms.

Retain one result per lane and an aggregate independent-matrix result.

──────────────────────────────────────────────────────────────────────────────
18. LIVE E00 NEGATIVE CAUSALS
──────────────────────────────────────────────────────────────────────────────

Run bounded audit-owned E00 causals against the exact sealed production source:

1. missing `-I`;
2. missing `-S`;
3. missing `-B`;
4. missing all three;
5. tokens supplied only after the script operand;
6. wrong interpreter, if the exact alternative can be invoked without
   ambiguity and without modifying a supplied root.

For each causal require:

- production source unchanged;
- no subject root allocated;
- no locator;
- exact exit;
- exact stdout/stderr;
- exact first blocker;
- no filesystem effect outside audit-owned paths;
- child reaped;
- descriptors closed.

Do not mutate the production source.

Do not use environment values as substitutes for missing literal options.

Retain:

causals/fresh-e00-negative-causals-v1.json

──────────────────────────────────────────────────────────────────────────────
19. EXACT FRESH-REHEARSAL INVOCATION
──────────────────────────────────────────────────────────────────────────────

Derive the production invocation from:

- the current successor contracts;
- the sealed production-source registry;
- the source-freeze record;
- the successful retained rehearsal process records.

Retain:

contract/independent-audit-rehearsal-invocation-v1.json

Bind:

- exact interpreter;
- exact `-I -S -B`;
- exact production source path inside the sealed package;
- exact mode;
- exact supplied-root operands;
- cwd;
- explicit environment;
- stdin;
- timeout;
- locator grammar;
- exit semantics;
- cleanup ownership.

Do not infer an operand from filename conventions.

Do not invoke the implementation package’s qualification driver as the
rehearsal parent.

Invoke the exact sealed production source directly.

──────────────────────────────────────────────────────────────────────────────
20. FRESH INDEPENDENT REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

Execute the exact sealed production source once.

Capture:

- child ordinal;
- PID;
- exact argv;
- cwd;
- environment;
- stdout;
- stderr;
- exit or signal;
- timeout posture;
- reaping;
- descriptor closure;
- exact `SUBJECT_ROOT` locator;
- returned root identity.

Retain the root without cleanup until all validation is complete.

Independently verify E00 and every G00–G29 phase.

Require exact final subject posture:

- 73 physical paths;
- 12 directories including root;
- 61 regular files;
- exact current namespace;
- exact contract bytes;
- exact fifteen schemas;
- exact fifteen-role registry;
- exact fourteen-family registry;
- exact role mapping;
- all witnesses;
- all 946 results;
- all 137 results;
- 766/333 field map;
- documentary lifecycle;
- ten validator results;
- confirmation evidence;
- occupancy/status/lineage/report;
- cleanup result;
- supplied-root equality;
- temporal inventory;
- manifest pair;
- terminal reprojection;
- root row once;
- modes;
- no empty descendant;
- no symlink/special/multilink/cache/bytecode;
- no postseal write.

Retain a complete no-follow inventory and every result identity.

──────────────────────────────────────────────────────────────────────────────
21. FRESH INDEPENDENT REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Execute the same exact sealed source bytes and invocation shape a second time.

Require a physically distinct returned root by:

- absolute path;
- device/inode pair.

Retain the same process and filesystem custody as rehearsal A.

Do not remove either root.

──────────────────────────────────────────────────────────────────────────────
22. SOURCE-EXTERNAL REHEARSAL ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before using any package qualification result, independently adjudicate each
fresh rehearsal using audit-owned code.

Retain:

validation/fresh-rehearsal-a-independent-result-v1.json
validation/fresh-rehearsal-b-independent-result-v1.json

The validators must independently implement:

- strict JSON parsing;
- total pointer observation;
- schema validation;
- inventory;
- namespace checking;
- 15/14 closure;
- case-count/name/result checking;
- field-map checking;
- writer/lifecycle checking;
- process-custody checking;
- temporal reprojection;
- manifest reprojection;
- topology;
- terminal-seal posture.

Do not import production or package qualification helpers.

──────────────────────────────────────────────────────────────────────────────
23. NORMALIZED FRESH-REHEARSAL COMPARISON
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/two-fresh-independent-rehearsals-v1.json

Normalize only explicitly physical fields:

- rehearsal-root path;
- root device/inode;
- root-bound identities;
- child PIDs;
- nonacceptance-bearing timestamps;
- explicitly listed physical bindings.

Semantically compare:

- contract bytes;
- schema identities;
- role/family rows;
- mapping;
- witnesses;
- all 946 results;
- all 137 results;
- field-map rows;
- ten-role registry;
- validator results;
- evidence DAG;
- confirmation semantics;
- occupancy/status/lineage;
- temporal semantics;
- normalized manifest bytes;
- final topology.

Require zero unexplained difference.

──────────────────────────────────────────────────────────────────────────────
24. PACKAGE QUALIFICATION-EVIDENCE RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Crosswalk the fresh independent results against the sealed package’s retained:

- Attempt-3 qualification;
- matrices;
- rehearsal A;
- rehearsal B;
- normalized comparison;
- independent rehearsal validator;
- source freeze;
- frozen requalification.

Classify every difference as:

- physical-only expected difference;
- producer evidence formatting;
- producer validation defect;
- implementation defect;
- audit defect;
- unresolved.

No unresolved acceptance-bearing difference is permitted for acceptance.

Retain:

analysis/package-qualification-evidence-reconciliation-v1.json

──────────────────────────────────────────────────────────────────────────────
25. SECURITY AND AUTHORITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Perform source-aware AST and dataflow analysis over all current production and
qualification sources.

Classify literals and operations by role rather than lexical substring.

Require no production-reachable:

- network operation;
- Git operation;
- shell execution;
- broad Downloads traversal;
- prefix/latest/score selection;
- existing-root adoption;
- hidden repository/product/target invocation;
- dynamic import escape;
- qualification failure hook;
- authority widening;
- secret-bearing output.

Expected-invalid fixtures must be positively classified and excluded from
ordinary production-source parsing.

Unresolved dynamic sink flow is blocking.

Retain:

analysis/security-authority-and-export-boundary-v1.json

──────────────────────────────────────────────────────────────────────────────
26. REHEARSAL EVIDENCE RETENTION BEFORE CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing either fresh rehearsal root, retain inside the audit capsule:

- exact root identities;
- complete inventories;
- parent process records;
- all stdout/stderr;
- all phase and result identities;
- audit-owned validation results;
- normalized comparison;
- qualification reconciliation;
- terminal identities;
- security findings.

Retain:

closing/rehearsal-evidence-retention-v1.json

Require:

- A evidence complete;
- B evidence complete;
- no indispensable evidence exists only in a rehearsal root;
- every copied or regenerated evidence identity verified.

Do not clean either root until this record passes.

──────────────────────────────────────────────────────────────────────────────
27. REHEARSAL AND FIXTURE CLEANUP
──────────────────────────────────────────────────────────────────────────────

After evidence retention:

1. re-lstat rehearsal A and verify original identity;
2. remove exact A;
3. observe ENOENT twice;
4. re-lstat rehearsal B and verify original identity;
5. remove exact B;
6. observe ENOENT twice;
7. remove every audit-owned causal/fixture root after evidence retention;
8. observe ENOENT twice per root;
9. require every child reaped;
10. require every descriptor closed;
11. require zero process survivor;
12. require zero cache/bytecode survivor.

Require exact set equality:

created audit-owned roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Retain:

closing/audit-owned-root-cleanup-v1.json

──────────────────────────────────────────────────────────────────────────────
28. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- implementation package;
- successor Generation-2 contract;
- authoritative contract package;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root, when resolved;
- any other supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

Any supplied-root inequality is:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
29. PRESEAL VERDICT
──────────────────────────────────────────────────────────────────────────────

Before terminal audit-capsule closure, retain:

closeout/preseal-independent-audit-result-v1.json

It must contain:

- fixed-input authentication;
- implementation-package closure;
- current-role resolution;
- source/attempt/freeze adjudication;
- static source audit;
- qualification-source independence;
- writer/lifecycle audit;
- process/failure audit;
- confirmation-registry audit;
- fresh matrices;
- E00 causals;
- fresh rehearsal A;
- fresh rehearsal B;
- normalized comparison;
- qualification-evidence reconciliation;
- security/authority audit;
- cleanup;
- supplied-root equality;
- complete severity-ranked findings;
- proposed primary verdict.

The preseal record is nonauthoritative until audit-capsule terminal closure.

──────────────────────────────────────────────────────────────────────────────
30. AUDIT-CAPSULE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- create every final audit-capsule directory, including `closeout/` and
  `manifest/`;
- finalize every nonclosure artifact;
- freeze the exact directory set;
- prohibit later directory creation.

Then:

1. generate a self-excluding temporal inventory;
2. write it into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. exclusively create zero-length manifest A and B in preexisting `manifest/`;
6. retain both descriptors;
7. generate A and B independently with both paths excluded;
8. require generated bytes identical;
9. write, fsync, and close;
10. fsync manifest directory;
11. reopen no-follow;
12. verify path/inode/type/mode/link/size/hash;
13. independently reproject the final audit root;
14. require root row exactly once;
15. require no empty descendant;
16. require no symlink or special object;
17. require no multiply linked regular file;
18. require directory/file modes 0700/0600;
19. require no cache or bytecode;
20. transition audit seal exactly once;
21. emit only the guarded terminal marker and verdict;
22. exit nonreturningly;
23. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

only when:

- the implementation package authenticates and terminally reprojects;
- all current governing roles resolve exactly;
- current source and attempt lineage close;
- source freeze and frozen requalification close;
- static production and qualification audits pass;
- one-writer and documentary lifecycles pass;
- process/failure custody passes;
- all 125 confirmations are independently evidence-bound;
- all fresh independent matrix lanes pass;
- all 946 and 137 cases freshly pass;
- 766/333 field-map closure passes;
- E00 negative causals pass with no root effect;
- Attempt-2 failure evidence qualifies;
- fresh rehearsal A passes;
- fresh rehearsal B passes;
- normalized equality passes;
- package qualification evidence reconciles;
- security/authority boundary closes;
- rehearsal evidence is retained before cleanup;
- cleanup closes;
- supplied roots close equal;
- the audit capsule terminally closes;
- no write follows audit seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_BLOCKED

when a package or implementation defect is independently established, including:

- current-role drift;
- source/attempt/freeze inconsistency;
- authority or writer drift;
- matrix false acceptance/rejection;
- independent-validator defect affecting package evidence;
- rehearsal failure;
- rehearsal semantic divergence;
- temporal or manifest defect;
- incomplete failure custody;
- security or authority widening;
- unresolved acceptance-bearing package discrepancy.

Return:

AUDIT_PROVENANCE_MISMATCH

for an audit-process failure, including:

- audit-source drift after freeze;
- incomplete platform capture;
- lost child streams or process ledger;
- unaccounted audit-owned filesystem effect;
- evidence lost before cleanup;
- audit-owned cleanup inequality;
- supplied-root mutation;
- supplied-root closing inequality;
- audit-capsule closure failure;
- postseal filesystem activity.

An audit provenance mismatch does not establish a package defect and does not
authorize current-subject construction.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Audit-source identity, preflight, and freeze
4. Platform capture preflight
5. Implementation-package identity and closure
6. Implementation temporal-inventory identity
7. Implementation manifest A identity
8. Implementation manifest B identity
9. Successor Generation-2 package authentication
10. Current governing-role resolution
11. External authoritative-input identities
12. Attempt-2 failed-root resolution and authentication
13. Current production-source registry
14. Current qualification-source registry
15. Attempt 1–3 lineage
16. Source-freeze and frozen-requalification adjudication
17. Production component-role and authority audit
18. Qualification-source independence audit
19. E00 implementation adjudication
20. G00 implementation adjudication
21. G01 implementation adjudication
22. G02 implementation adjudication
23. G03 implementation adjudication
24. G04 implementation adjudication
25. G05–G29 implementation adjudication
26. Writer-registry audit
27. Documentary-evidence-lifecycle audit
28. Process-custody and failure-semantics audit
29. Complete confirmation-registry audit
30. Fresh bootstrap-order matrix
31. Fresh external-interface matrix
32. Fresh JSON-observation matrix
33. Fresh schema/family matrix
34. Fresh process-custody/locator matrix
35. Fresh cleanup/failure-evidence matrix
36. Fresh writer/lifecycle matrix
37. Fresh namespace/temporal matrix
38. Fresh manifest/terminal matrix
39. Fresh negative-checker robustness matrix
40. Fresh 946-case result
41. Fresh 137-case result
42. Fresh 766/333 field-map result
43. E00 negative causals
44. Fresh rehearsal A process and result
45. Fresh rehearsal B process and result
46. Independent rehearsal A adjudication
47. Independent rehearsal B adjudication
48. Normalized rehearsal comparison
49. Package qualification-evidence reconciliation
50. Security and authority findings
51. Severity-ranked findings
52. Rehearsal evidence-retention result
53. Rehearsal and fixture cleanup
54. Complete audit child-process ledger
55. Supplied-root closing equality
56. Preseal substantive verdict
57. Audit temporal-inventory identity
58. Audit manifest A identity
59. Audit manifest B identity
60. Independent audit-capsule reprojection
61. Terminal audit-capsule membership and modes
62. No-write-after-audit-seal
63. Remaining uncertainty and nonclaims
64. Explicit confirmation registry

Required confirmations:

IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_IDENTITY_MATCHED
IMPLEMENTATION_PACKAGE_TERMINAL_CLOSURE_VERIFIED
IMPLEMENTATION_TEMPORAL_INVENTORY_REPROJECTED
IMPLEMENTATION_MANIFEST_PAIR_REPROJECTED
SUCCESSOR_GEN2_CONTRACT_MUTATION_NOT_PERFORMED
SUCCESSOR_GEN2_CONTRACT_IDENTITY_MATCHED
CURRENT_GEN2_ROLE_REGISTRY_RESOLVED
ALL_CURRENT_GEN2_ROLES_AUTHENTICATED
NO_HISTORICAL_GEN2_ARTIFACT_USED_AS_CURRENT
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
ATTEMPT_2_FAILED_ROOT_EXACTLY_RESOLVED_OR_DEFECT_REPORTED
ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
AUDIT_SOURCE_EXTERNAL_TO_IMPLEMENTATION
AUDIT_SOURCE_FROZEN_BEFORE_AUDIT_EPOCH
AUDIT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PLATFORM_CAPTURE_PREFLIGHT_PASSED
AUDIT_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
AUDIT_PARENT_STDIN_NOT_READ
PERSISTENT_AUDIT_SUPERVISOR_NOT_USED
CURRENT_PRODUCTION_SOURCE_REGISTRY_AUTHENTICATED
CURRENT_QUALIFICATION_SOURCE_REGISTRY_AUTHENTICATED
ALL_CURRENT_SOURCE_IDENTITIES_MATCHED
ATTEMPT_LINEAGE_COMPLETE
ONLY_ATTEMPT_3_CURRENT
SOURCE_FREEZE_AUTHENTICATED
FROZEN_REQUALIFICATION_AUTHENTICATED
BOTH_PRODUCER_REHEARSALS_BOUND_TO_FROZEN_SOURCE
ALL_24_PRODUCTION_COMPONENT_ROLES_INDEPENDENTLY_ADJUDICATED
ALL_9_QUALIFICATION_COMPONENT_ROLES_INDEPENDENTLY_ADJUDICATED
ONE_AUTHORITATIVE_WRITER_PER_MUTABLE_FACT_VERIFIED
PRODUCTION_NETWORK_ACCESS_ABSENT
PRODUCTION_GIT_INVOCATION_ABSENT
PRODUCTION_SHELL_EXECUTION_ABSENT
PRODUCTION_PATH_LOOKUP_ABSENT
PRODUCTION_BROAD_ROOT_DISCOVERY_ABSENT
PRODUCTION_EXISTING_ROOT_ADOPTION_ABSENT
PRODUCTION_REACHABLE_QUALIFICATION_HOOK_ABSENT
E00_STATIC_SEMANTICS_VERIFIED
G00_STATIC_SEMANTICS_VERIFIED
G01_STATIC_SEMANTICS_VERIFIED
G02_STATIC_SEMANTICS_VERIFIED
G03_STATIC_SEMANTICS_VERIFIED
G04_STATIC_SEMANTICS_VERIFIED
G05_G29_STATIC_SEMANTICS_VERIFIED
NO_DIRECTORY_CREATION_AFTER_G01_VERIFIED
NO_POSTSEAL_FILESYSTEM_OPERATION_VERIFIED
QUALIFICATION_VALIDATOR_INDEPENDENCE_VERIFIED
DOCUMENTARY_EVIDENCE_LIFECYCLE_VERIFIED
CONFIRMATION_VALIDATOR_SINGLE_WRITER_VERIFIED
FINAL_TEN_ROLE_REGISTRY_ORDER_VERIFIED
DOCUMENTARY_REGENERATION_DERIVATION_VERIFIED
COMPLETE_125_CONFIRMATION_AUDIT_PASSED
NO_HARDCODED_CONFIRMATION_SUCCESS
NO_ABSENCE_AS_CONFIRMATION_SUCCESS
FRESH_BOOTSTRAP_ORDER_MATRIX_PASSED
FRESH_EXTERNAL_INTERFACE_MATRIX_PASSED
FRESH_JSON_OBSERVATION_MATRIX_PASSED
FRESH_SCHEMA_ROLE_FAMILY_MATRIX_PASSED
FRESH_PROCESS_CUSTODY_LOCATOR_MATRIX_PASSED
FRESH_CLEANUP_FAILURE_EVIDENCE_MATRIX_PASSED
FRESH_WRITER_LIFECYCLE_MATRIX_PASSED
FRESH_NAMESPACE_TEMPORAL_MATRIX_PASSED
FRESH_MANIFEST_TERMINAL_MATRIX_PASSED
FRESH_NEGATIVE_CHECKER_ROBUSTNESS_MATRIX_PASSED
FRESH_946_CASE_AUDIT_PASSED
FRESH_137_CASE_AUDIT_PASSED
FRESH_766_333_FIELD_MAP_AUDIT_PASSED
E00_NEGATIVE_CAUSALS_PASSED
E00_NEGATIVE_CAUSALS_CREATED_NO_SUBJECT_ROOT
ATTEMPT_2_FAILURE_SEMANTICS_VERIFIED
FRESH_REHEARSAL_A_EXECUTED_EXACTLY_ONCE
FRESH_REHEARSAL_B_EXECUTED_EXACTLY_ONCE
FRESH_REHEARSAL_ROOTS_PHYSICALLY_DISTINCT
FRESH_REHEARSAL_A_PASSED
FRESH_REHEARSAL_B_PASSED
FRESH_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_FRESH_REHEARSAL_VALIDATION_PASSED
PACKAGE_QUALIFICATION_EVIDENCE_RECONCILED
NO_UNRESOLVED_ACCEPTANCE_BEARING_DIFFERENCE
FRESH_REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP
FRESH_REHEARSAL_A_DOUBLE_ENOENT_RETAINED
FRESH_REHEARSAL_B_DOUBLE_ENOENT_RETAINED
AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_AUDIT_CHILDREN_REAPED
ALL_AUDIT_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
AUDIT_CAPSULE_TEMPORAL_INVENTORY_CREATED
AUDIT_CAPSULE_TEMPORAL_INVENTORY_VERIFIED
AUDIT_CAPSULE_MANIFEST_A_CREATED
AUDIT_CAPSULE_MANIFEST_B_CREATED
AUDIT_CAPSULE_MANIFESTS_BYTE_IDENTICAL
AUDIT_CAPSULE_TERMINAL_REPROJECTION_PASSED
AUDIT_CAPSULE_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT_IN_AUDIT_CAPSULE
NO_MULTIPLY_LINKED_FILE_IN_AUDIT_CAPSULE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_WRITE_AFTER_AUDIT_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

If the verdict is:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_INDEPENDENT_AUDIT_ACCEPTED_READY_FOR_ONE_SHOT_SUBJECT_CONSTRUCTION

the next tranche may execute the exact frozen parent once to construct the
authoritative current schema subject.

That later one-shot construction must:

- use the exact audited source bytes;
- use the exact audited invocation contract;
- construct exactly one fresh current subject root;
- retain complete platform and process custody;
- perform no implementation repair;
- perform no retry or administrative continuation;
- stop after terminally closing the current subject.

Product construction-parent implementation, target execution, and A6 remain
blocked until the newly constructed current subject is independently accepted
under the governing target-audit path.
```

**Source:** Codex’s `SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT` report in this turn; artifact contents were not independently inspected here.  
**Confidence:** 0.995 that a fresh source-external independent audit is now the correct gate; 0.99 that current-subject construction remains unauthorized until that audit accepts; 0.98 that the audit must run fresh rehearsals rather than rely only on producer evidence.
