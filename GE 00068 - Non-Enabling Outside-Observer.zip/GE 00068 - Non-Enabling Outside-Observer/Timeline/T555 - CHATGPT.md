## Engineering assessment

No real subject audit was executed, and the one-audit authorization remains unconsumed. The wrapper correctly stopped before allocating either a wrapper root or an audit root because the current launch certificate does not bind several mandatory external execution controls. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The underlying package chain is otherwise intact:

- the final PYZ, runtime authority, and launch certificate identities matched;
- all nine fixed roles passed stable opening and closing authentication;
- the 89-member deterministic PYZ closed exactly;
- the replacement subject and construction chain remained unchanged;
- the accepted implementation chain and current content snapshot authenticated. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

The missing controls are specifically:

- exact `cwd`;
- exact submitted environment;
- TTY posture;
- detachment posture;
- root-allocation ownership and lifecycle;
- platform-preflight stdout marker;
- platform-preflight stderr marker;
- platform-preflight exit code. :chatgpt-content-reference{index="4"}

The embedded invocation template itself is resolved and coherent. It binds the interpreter, isolation flags, PYZ, runtime authority, replacement subject, construction wrapper, content inputs, accepted implementation roots, and an `<fresh-private-audit-root>` output placeholder. :chatgpt-content-reference{index="5"}

### Classification

```text
INCOMPLETE_EXTERNAL_LAUNCH_AUTHORITY
```

This is not:

- a clean-audit-source defect;
- a PYZ packaging defect;
- a runtime-authority defect;
- a replacement-subject defect;
- an accepted-implementation defect;
- a consumed audit attempt.

The current launch certificate is correctly authenticated as an artifact, but it is not complete enough to authorize deterministic process creation under the project’s fail-closed rules. Its one-audit count remains unused. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

## Progression decision

Do not rebuild or repair the audit PYZ.

Create a **successor external launch profile and launch certificate** that complete the missing wrapper-owned execution controls while binding the unchanged PYZ and runtime authority.

The successor must:

1. preserve the current PYZ and runtime authority byte-for-byte;
2. supersede—not mutate—the incomplete launch certificate v1;
3. retain exactly one active future real-audit authorization across the predecessor/successor certificate lineage;
4. bind the complete argv already present in the package;
5. freeze exact wrapper-owned cwd, environment, root-allocation, TTY, detachment, and platform-preflight controls;
6. qualify those controls without executing the real subject audit;
7. independently validate the successor certificate;
8. leave the replacement subject unchanged.

The exact new external controls should be frozen as an additive wrapper contract:

```text
cwd:
  the freshly allocated private audit root

submitted environment:
  PATH=/usr/bin:/bin
  LANG=C
  LC_ALL=C
  PYTHONDONTWRITEBYTECODE=1
  PYTHONHASHSEED=0

stdin:
  DEVNULL

shell:
  false

TTY:
  false

detachment:
  false

audit-root allocation:
  wrapper-owned tempfile.mkdtemp
  parent /private/tmp
  umask 077
  prefix ES-repair10i-v3-replacement-schema-subject-real-audit-

platform preflight:
  stdout PLATFORM_CAPTURE_STDOUT_V1\n
  stderr PLATFORM_CAPTURE_STDERR_V1\n
  exit 23
```

These values are a new external-wrapper authority decision. They do not change harness, subject, or package semantics.

---

## Complete replacement Codex prompt

```text
COMPLETE AND SEAL THE EXTERNAL LAUNCH AUTHORITY FOR THE
CLEAN REPLACEMENT-SUBJECT INDEPENDENT-AUDIT HARNESS

PRESERVE THE FINAL PYZ AND RUNTIME AUTHORITY UNCHANGED;
CREATE A SUCCESSOR LAUNCH PROFILE AND LAUNCH CERTIFICATE

Objective

Complete the external wrapper launch authority for the already implemented,
qualified, frozen, and packaged clean independent-audit harness.

The current audit artifacts are valid and unchanged:

1. final audit PYZ;
2. final runtime authority;
3. incomplete external launch certificate v1.

The previous wrapper authenticated all fixed inputs and the full 89-member PYZ,
but correctly refused to create the real audit parent because the current launch
authority omits exact wrapper-owned controls for:

- cwd;
- submitted environment;
- TTY;
- detachment;
- audit-root allocation;
- platform-preflight stdout marker;
- platform-preflight stderr marker;
- platform-preflight exit code.

No wrapper root was allocated.
No audit root was allocated.
No platform preflight ran.
No audit parent was created.
The one future real-audit authorization remains unconsumed.
No subject verdict exists.

Create one additive successor launch-authority generation.

Do not modify, rebuild, or replace:

- final audit PYZ;
- final runtime authority;
- audit source;
- source freeze;
- replacement subject;
- construction wrapper;
- accepted implementation chain;
- content bundle;
- content authority.

Do not execute the real replacement-subject audit in this task.

Do not execute audit mode.

Qualification mode may be used only when the exact current PYZ contract
supports it and only to verify package/authority coherence. It must not inspect
the real subject substantively or issue a subject verdict.

Do not mutate the replacement subject.

Do not run subject construction.

Do not promote or rebind current schema authority.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite source-external launch-authority builder in one fresh private
root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT FINAL AUDIT ARTIFACTS
──────────────────────────────────────────────────────────────────────────────

FINAL_AUDIT_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz

Expected identity:

- device:
  observe and retain;
- inode:
  182699827;
- mode:
  0400;
- link count:
  1;
- size:
  4589679;
- SHA-256:
  00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0.

FINAL_RUNTIME_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json

Expected identity:

- device:
  observe and retain;
- inode:
  182699838;
- mode:
  0400;
- link count:
  1;
- size:
  56463;
- SHA-256:
  9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0.

PREDECESSOR_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

Expected identity:

- device:
  observe and retain;
- inode:
  182699841;
- mode:
  0400;
- link count:
  1;
- size:
  3572;
- SHA-256:
  525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c.

Authenticate every file using:

- no-follow open;
- regular-file requirement;
- exact mode;
- exact link count;
- exact size and SHA-256;
- two stable byte and metadata reads.

Strict-parse both JSON authority files using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

Require complete opening/closing equality.

Do not mutate any file.

──────────────────────────────────────────────────────────────────────────────
2. REPLACEMENT SUBJECT AND CONSTRUCTION AUTHORITY
──────────────────────────────────────────────── LIMITED TO BINDING
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234;
- inode:
  182649818;
- mode:
  0700;
- UID/GID:
  501/20.

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files;
- one root row;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory/file modes:
  0700/0600;
- no cache or bytecode.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051;
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4.

Expected manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16620 each;
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758.

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234;
- inode:
  182648782;
- mode:
  0700;
- UID/GID:
  501/0.

Authenticate only the chain necessary to bind:

- exact replacement subject;
- subject terminal closure;
- one-shot construction consumption;
- production-parent custody;
- subject-root locator;
- pending-independent-audit posture;
- no second construction.

Do not independently audit subject semantics.

Do not mutate or clean either root.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED IMPLEMENTATION AUTHORITY
──────────────────────────────────────────────── LIMITED TO CERTIFICATE BINDING
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234;
- inode:
  182593190;
- mode:
  0700.

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234;
- inode:
  182593189;
- mode:
  0700.

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the current chain needed to bind:

- accepted reconstruction-parent implementation;
- accepted production source and freeze;
- accepted construction contract;
- unsuperseded implementation package;
- replacement construction used the accepted parent.

Do not re-audit the implementation package.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT INPUTS
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234;
- inode:
  181651092;
- mode:
  0400;
- link count:
  1;
- size:
  13598758;
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671.

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234;
- inode:
  181651098;
- mode:
  0400;
- link count:
  1;
- size:
  19737;
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563.

Authenticate authority before ZIP interpretation.

Require:

- 479 members;
- eight roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive-validation evidence;
- no `.DS_Store`.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. PREDECESSOR CERTIFICATE DISPOSITION
────────────────────────────────────────────────

Retain:

opening/predecessor-launch-certificate-disposition-v1.json

Required classification:

HISTORICAL_SUPERSEDED_INCOMPLETE_EXTERNAL_LAUNCH_AUTHORITY

Required facts:

- predecessor identity authenticated:
  true;
- predecessor schema authenticated:
  true;
- predecessor PYZ binding authenticated:
  true;
- predecessor runtime-authority binding authenticated:
  true;
- predecessor one-audit count:
  1;
- predecessor audit count consumed:
  0;
- predecessor current for launch:
  false after successor closure;
- predecessor may authorize a future audit:
  false after successor closure;
- predecessor file mutation:
  forbidden;
- predecessor deletion:
  forbidden;
- supersession cause:
  missing exact external execution controls;
- historical evidence effect:
  retained;
- active successor audit authorization count:
  exactly one.

There must never be two simultaneously current audit authorizations.

The successor certificate replaces the predecessor’s unconsumed launch
authorization. It does not add a second authorization.

──────────────────────────────────────────────────────────────────────────────
6. FRESH BUILD AND OUTPUT ROOTS
────────────────────────────────────────────────

Allocate one fresh private build root beneath `/private/tmp`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-subject-audit-launch-authority-

Immediately emit:

LAUNCH_AUTHORITY_BUILD_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-subject-audit-launch-authority-output-

Immediately emit:

LAUNCH_AUTHORITY_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json

The output directory is nonauthoritative.

Before builder source creation retain:

opening/bootstrap-start.json
opening/launch-authority-builder-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-launch-certificate-disposition-v1.json
opening/external-launch-policy-v1.json
opening/process-execution-policy-v1.json

──────────────────────────────────────────────────────────────────────────────
7. ADDITIVE EXTERNAL LAUNCH POLICY
────────────────────────────────────────────────

Retain:

opening/external-launch-policy-v1.json

Authority classification:

EXTERNAL_WRAPPER_LAUNCH_POLICY

This policy is additive and wrapper-owned.

It does not change:

- audit PYZ bytes;
- runtime-authority bytes;
- audit source;
- source freeze;
- subject bytes;
- construction evidence;
- audit logic;
- subject acceptance semantics;
- product/runtime/target/A6 authority.

Freeze these exact controls.

A. Interpreter and isolation

Executable:

/usr/local/bin/python3.13

Isolation flags:

-I
-S
-B

Require exact executable identity to be observed and retained during
qualification and future launch.

B. Audit argv template

```text
/usr/local/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz
--mode
audit
--runtime-authority
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json
--subject-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
--construction-wrapper
/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a
--content-bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--accepted-implementation-audit
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04
--accepted-implementation-wrapper
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg
--output-root
<FRESH_PRIVATE_AUDIT_ROOT>
```

No additional operand.

No omitted operand.

No launch certificate passed to the harness unless the current embedded CLI
contract explicitly requires it. Current evidence says it does not.

C. Audit-root allocation

Owner:

external wrapper

Allocation:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-schema-subject-real-audit-`;
- umask:
  `077`.

Requirements:

- freshly allocated;
- absolute path;
- directory;
- no symlink;
- mode:
  0700;
- empty before preflight;
- empty immediately before audit-parent creation;
- exact path substituted for `<FRESH_PRIVATE_AUDIT_ROOT>`;
- same path used as submitted cwd;
- no root scan;
- no root fallback;
- no preexisting-root adoption.

D. Submitted cwd

Exactly:

<FRESH_PRIVATE_AUDIT_ROOT>

Classification:

EXTERNAL_WRAPPER_NONAUTHORITATIVE_LAUNCH_CONTEXT

Runtime cwd must crosswalk to the exact submitted cwd.

E. Submitted environment

Use an empty inherited environment and submit exactly:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

No other submitted variable.

Any runtime-added variable is governed only by the existing runtime authority
and audit self-authentication policy.

F. Process posture

```text
stdin = DEVNULL
shell = false
TTY = false
detachment = false
foreground = true
synchronous = true
```

G. Platform-capture preflight

Use exactly:

```text
/usr/local/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>
```

The program is semantically equivalent to:

```python
import os
os.write(1, b"PLATFORM_CAPTURE_STDOUT_V1\n")
os.write(2, b"PLATFORM_CAPTURE_STDERR_V1\n")
os._exit(23)
```

Submitted cwd:

<FRESH_PRIVATE_AUDIT_ROOT>

Submitted environment:

the exact five-row environment above.

stdin:

DEVNULL

shell/TTY/detachment:

false.

Expected stdout:

- exact bytes:
  `PLATFORM_CAPTURE_STDOUT_V1\n`;
- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2.

Expected stderr:

- exact bytes:
  `PLATFORM_CAPTURE_STDERR_V1\n`;
- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5.

Expected exit:

23.

Expected signal:

null.

The preflight creates no file, creates no child, and reads no stdin.

The preflight does not consume the one real-audit authorization.

H. Authorization consumption

The single real-audit authorization is consumed only when the audit-parent
process is successfully created.

A prelaunch authentication, allocation, or preflight failure leaves it
unconsumed.

After process creation, it remains consumed regardless of final disposition or
custody failure.

I. Stream/framing contract

Preserve exactly the current handled-terminal and unhandled-failure stream
schemas already bound by:

- final PYZ;
- runtime authority;
- predecessor launch certificate.

The successor certificate must bind their exact schemas, fields, and identities.

Do not reinterpret or weaken the existing stream contract.

──────────────────────────────────────────────────────────────────────────────
8. LAUNCH-PROFILE SCHEMA
────────────────────────────────────────────────

Create:

contract/external-audit-launch-profile-v1.schema.json

The schema must require:

- profile schema/version;
- current status;
- predecessor certificate identity;
- PYZ identity;
- runtime-authority identity;
- subject identity;
- construction-wrapper identity;
- content identities;
- accepted implementation-root identities;
- interpreter identity;
- exact argv template;
- output-root placeholder contract;
- root-allocation owner and algorithm;
- root parent/prefix/umask;
- cwd contract;
- exact submitted environment;
- stdin;
- shell;
- TTY;
- detachment;
- foreground/synchronous posture;
- platform-preflight contract;
- authorization-consumption rule;
- stream/framing references;
- one-audit count;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Reject unknown fields.

No optional acceptance-bearing launch field.

──────────────────────────────────────────────────────────────────────────────
9. SUCCESSOR LAUNCH CERTIFICATE V2 SCHEMA
────────────────────────────────────────────────

Create:

contract/external-audit-launch-certificate-v2.schema.json

It must bind:

- exact launch profile identity;
- predecessor certificate identity and supersession;
- exact PYZ identity;
- exact runtime-authority identity;
- exact subject identity;
- exact construction-wrapper identity;
- exact content identities;
- exact accepted implementation roots;
- exact source-freeze identity;
- exact PYZ member registry and count:
  89;
- complete qualification evidence;
- post-package qualification;
- frozen-package requalification;
- synthetic ACCEPT/BLOCK/provenance/regression rehearsals;
- independent qualification;
- exact stream/framing contract;
- exact one-audit authorization;
- predecessor current:
  false;
- successor current:
  true;
- total active current authorization count:
  1;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Reject unknown fields.

Certificate v2 is external wrapper authority.

It is not passed to the audit harness unless the embedded CLI contract later
changes through separately governed authority.

──────────────────────────────────────────────────────────────────────────────
10. BUILDER SOURCE AUTHORITY
────────────────────────────────────────────────

Create fresh standard-library-only builder and validator source.

Builder source may read only:

- fixed inputs in Sections 1–4;
- this task’s launch policy and schemas;
- exact embedded member registries and qualification evidence from the current
  PYZ and runtime authority.

Builder source must not:

- import audit harness source;
- execute audit mode;
- execute subject source;
- execute construction source;
- modify current artifacts;
- use Git/VCS;
- use network;
- broad-scan any directory;
- select files by basename, suffix, recency, score, or first match.

Retain:

opening/launch-authority-source-registry-v1.json
opening/launch-authority-source-authority-v1.json

Compile under pinned Python `-I -S -B`.

Run source-external static analysis:

- AST;
- call graph;
- dataflow;
- process effects;
- filesystem effects;
- input-boundary analysis;
- no-Git/no-network;
- deterministic serialization;
- authorization-count logic;
- terminal-operation analysis.

──────────────────────────────────────────────── LIMITED TO NEGATIVE CASES
────────────────────────────────────────────────

11. LAUNCH-AUTHORITY MATRIX

Run at least 60 uniquely named cases.

Include:

A. Artifact binding

- exact baseline;
- wrong PYZ hash;
- wrong authority hash;
- wrong subject root;
- wrong construction wrapper;
- wrong content bundle;
- wrong accepted implementation root;
- wrong member count;
- stale predecessor certificate current.

B. Invocation

- exact argv;
- omitted operand;
- extra operand;
- wrong option name;
- wrong mode;
- launch certificate passed to harness;
- unresolved root placeholder;
- relative audit root;
- duplicate output-root option.

C. Root allocation

- exact fresh root;
- wrong parent directory;
- wrong prefix;
- wrong umask;
- nonempty root;
- symlink root;
- preexisting-root adoption;
- root scan;
- root fallback.

D. cwd and environment

- exact cwd;
- cwd not equal audit root;
- inherited environment;
- missing PATH;
- extra submitted variable;
- wrong hash seed;
- wrong bytecode posture;
- wrong locale.

E. process posture

- exact baseline;
- stdin inherited;
- shell true;
- TTY true;
- detached process;
- asynchronous launch.

F. platform preflight

- exact markers/exit;
- wrong stdout;
- wrong stderr;
- wrong exit;
- signal;
- file creation;
- child creation;
- stdin read;
- root changed by preflight.

G. authorization

- predecessor and successor both current;
- zero current authorization;
- two active authorization counts;
- prelaunch failure consumes authorization;
- process creation does not consume authorization;
- already-executed posture;
- subject verdict preissued.

H. framing

- exact existing framing reference;
- unknown frame schema;
- duplicate terminal frame;
- trailing bytes;
- framing identity mismatch.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/external-launch-authority-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT LAUNCH-AUTHORITY VALIDATOR
────────────────────────────────────────────────

Create one independently authored standard-library-only validator that imports
neither:

- builder;
- matrix generator;
- expected-result map;
- serialization helper;
- profile producer;
- certificate producer.

It must independently:

1. authenticate every fixed input;
2. parse the PYZ member registry;
3. parse current qualification evidence;
4. validate the additive launch policy;
5. validate profile schema;
6. validate certificate-v2 schema;
7. reconstruct the exact argv;
8. reconstruct root-allocation policy;
9. reconstruct cwd/environment/process posture;
10. validate preflight bytes and hashes;
11. validate stream/framing references;
12. validate predecessor supersession;
13. prove exactly one active current authorization;
14. run independent negative cases;
15. require zero errors.

Retain:

validation/independent-external-launch-authority-validator-v1.json

──────────────────────────────────────────────── LIMITED TO QUALIFICATION
────────────────────────────────────────────────

13. PLATFORM-PREFLIGHT QUALIFICATION

Allocate one disposable fresh private audit root using the exact new launch
profile.

Run the exact platform preflight once.

Retain complete external custody:

- argv;
- cwd;
- environment;
- PID;
- timing;
- streams;
- sizes and hashes;
- exit/signal;
- reaping;
- descriptor closure.

Require:

- exact stdout;
- exact stderr;
- exit 23;
- signal null;
- no file;
- no child;
- audit root still empty.

Retain evidence before removing the root.

Revalidate identity, remove it, and observe ENOENT twice.

This does not consume the real-audit authorization.

Do not run audit mode.

──────────────────────────────────────────────── LIMITED TO CURRENT PACKAGE
────────────────────────────────────────────────

14. OPTIONAL QUALIFICATION-MODE CROSSWALK

Inspect the embedded CLI contract.

If the final PYZ supports a qualification mode that can run without performing
the real subject audit:

- derive the exact qualification invocation from current embedded authority;
- run it once under the new exact cwd/environment/process posture;
- pass the unchanged runtime authority;
- retain complete custody;
- require exit zero;
- require no real subject audit;
- require no subject verdict;
- require no subject mutation.

If no such exact mode exists:

- retain `not_applicable`;
- do not invent a mode;
- rely on static/package crosswalk, platform preflight, and independent
  validation.

Qualification-mode absence is not itself a blocker.

──────────────────────────────────────────────── LIMITING DETERMINISTIC OUTPUTS
────────────────────────────────────────────────

15. DETERMINISTIC LAUNCH PROFILE

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json

Use deterministic canonical JSON.

Require Build A and B byte-identical.

Set mode:

0400.

The profile must bind every field in Section 7.

Retain exact identity.

────────────────────────────────────────────────

16. DETERMINISTIC SUCCESSOR CERTIFICATE V2

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json

Use deterministic canonical JSON.

Require Build A and B byte-identical.

Set mode:

0400.

Bind:

- final launch profile;
- unchanged PYZ;
- unchanged runtime authority;
- subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- current source freeze;
- current qualification evidence;
- predecessor certificate;
- predecessor supersession;
- one active future audit authorization.

Retain exact identity.

────────────────────────────────────────────────

17. CERTIFICATE-INPUT VALIDATION

Run an independent certificate-input validator over the final output bytes.

Require:

- exact profile binding;
- exact artifact identities;
- exact predecessor/successor lineage;
- exact one-audit count;
- no duplicate current certificate;
- complete execution controls;
- exact preflight controls;
- exact framing references;
- real audit false;
- subject verdict not issued;
- authority promotion false;
- no unknown field;
- zero errors.

Retain:

validation/successor-certificate-input-validation-v1.json

────────────────────────────────────────────────

18. CURRENT LAUNCH-AUTHORITY ROLE REGISTRY

Retain:

contract/current-external-launch-authority-role-registry-v1.json

Required rows:

- external-audit-launch-profile;
- external-audit-launch-certificate.

Require:

- exactly one current profile;
- exactly one current certificate;
- predecessor certificate historical;
- no duplicate current role;
- no ambiguous path;
- exact identities;
- current status true;
- predecessor current status false;
- active authorization count one.

────────────────────────────────────────────────

19. INPUT CLOSING EQUALITY AND CLEANUP

Repeat complete opening/closing equality for:

- final audit PYZ;
- runtime authority;
- predecessor certificate v1;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Do not mutate supplied inputs.

Before removing disposable roots retain:

- identity;
- inventory;
- custody;
- streams;
- results.

Require exact cleanup-set equality and double ENOENT.

Do not remove successful final outputs.

────────────────────────────────────────────────

20. FAILURE CLOSEOUT

On failure retain:

- first blocker;
- structured exception;
- source identities;
- process records and streams;
- matrix and independent-validator results;
- partial output inventory;
- cleanup;
- input closing equality;
- predecessor/successor authorization posture;
- real audit not executed;
- subject verdict not issued.

Do not create current successor certificate on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

21. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

only when:

- every fixed input authenticates;
- predecessor certificate disposition closes;
- additive launch policy freezes;
- profile and certificate schemas close;
- builder source qualifies;
- launch-authority matrix passes;
- independent validator passes;
- platform preflight passes;
- optional qualification crosswalk passes or is correctly not applicable;
- launch-profile Build A/B match;
- certificate-v2 Build A/B match;
- certificate-input validation passes;
- current role registry closes;
- exactly one active future audit authorization exists;
- input equality and cleanup pass;
- final files are mode 0400;
- real subject audit did not execute;
- no subject verdict was issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_BLOCKED

when:

- the current PYZ/runtime authority cannot be made launch-complete without
  modifying harness semantics or source;
- stream/framing contract is ambiguous;
- exact CLI cannot be uniquely resolved;
- additive wrapper authority is insufficient.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- predecessor-certificate mismatch;
- forbidden source use;
- evidence loss;
- custody failure;
- cleanup inequality;
- supplied-input mutation;
- deterministic-output mismatch;
- final-output identity failure;
- any Git/VCS or network activity.

────────────────────────────────────────────────

22. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve current audit PYZ and runtime authority;
- preserve predecessor certificate;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve successful launch profile and certificate;
- do not execute the real subject audit;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

23. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Final PYZ identity
5. Runtime-authority identity
6. Predecessor-certificate identity
7. Replacement-subject identity
8. Construction-wrapper identity
9. Accepted implementation-chain identities
10. Content identities
11. Predecessor certificate disposition
12. Additive external launch policy
13. Exact argv template
14. Audit-root allocation contract
15. Exact cwd contract
16. Exact environment contract
17. Process posture
18. Platform-preflight contract
19. Authorization-consumption rule
20. Stream/framing references
21. Launch-profile schema
22. Certificate-v2 schema
23. Builder-source registry
24. Builder compilation/static result
25. Launch-authority matrix
26. Independent validator
27. Platform-preflight qualification
28. Optional qualification-mode crosswalk
29. Launch-profile Build A
30. Launch-profile Build B
31. Launch-profile equality and identity
32. Certificate-v2 Build A
33. Certificate-v2 Build B
34. Certificate-v2 equality and identity
35. Certificate-input validation
36. Current launch-authority role registry
37. Exactly-one-current-authorization result
38. Input closing equality
39. Cleanup
40. Confirmation real audit not executed
41. Confirmation no subject verdict
42. Final launch-profile path and identity
43. Final certificate-v2 path and identity
44. Remaining uncertainty and nonclaims
45. Explicit confirmations

Required confirmations:

FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
PREDECESSOR_LAUNCH_CERTIFICATE_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
PREDECESSOR_CERTIFICATE_CLASSIFIED_HISTORICAL_SUPERSEDED
PREDECESSOR_CERTIFICATE_MUTATION_NOT_PERFORMED
PREDECESSOR_AUDIT_AUTHORIZATION_NOT_CONSUMED
ADDITIVE_EXTERNAL_LAUNCH_POLICY_FROZEN
EXACT_AUDIT_ARGV_FROZEN
WRAPPER_OWNED_AUDIT_ROOT_ALLOCATION_FROZEN
EXACT_CWD_CONTRACT_FROZEN
EXACT_SUBMITTED_ENVIRONMENT_FROZEN
STDIN_DEVNULL_FROZEN
SHELL_FALSE_FROZEN
TTY_FALSE_FROZEN
DETACHMENT_FALSE_FROZEN
FOREGROUND_SYNCHRONOUS_LAUNCH_FROZEN
PLATFORM_PREFLIGHT_CONTRACT_FROZEN
EXACT_PREFLIGHT_STDOUT_FROZEN
EXACT_PREFLIGHT_STDERR_FROZEN
EXACT_PREFLIGHT_EXIT_FROZEN
AUTHORIZATION_CONSUMPTION_RULE_FROZEN
EXISTING_STREAM_FRAMING_CONTRACT_PRESERVED
LAUNCH_PROFILE_SCHEMA_COMPLETE
SUCCESSOR_CERTIFICATE_V2_SCHEMA_COMPLETE
LAUNCH_AUTHORITY_BUILDER_SOURCE_EXTERNAL
LAUNCH_AUTHORITY_BUILDER_COMPILED
LAUNCH_AUTHORITY_STATIC_QUALIFICATION_PASSED
LAUNCH_AUTHORITY_MATRIX_PASSED
INDEPENDENT_LAUNCH_AUTHORITY_VALIDATOR_PASSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PREFLIGHT_AUDIT_ROOT_REMAINED_EMPTY
PREFLIGHT_ROOT_CLEANED_WITH_DOUBLE_ENOENT
OPTIONAL_QUALIFICATION_CROSSWALK_PASSED_OR_NOT_APPLICABLE
LAUNCH_PROFILE_BUILD_A_B_BYTES_IDENTICAL
LAUNCH_PROFILE_MODE_0400
LAUNCH_PROFILE_IDENTITY_VERIFIED
SUCCESSOR_CERTIFICATE_V2_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_V2_MODE_0400
SUCCESSOR_CERTIFICATE_V2_IDENTITY_VERIFIED
CERTIFICATE_INPUT_VALIDATION_PASSED
CURRENT_LAUNCH_AUTHORITY_ROLE_REGISTRY_COMPLETE
EXACTLY_ONE_CURRENT_LAUNCH_PROFILE
EXACTLY_ONE_CURRENT_LAUNCH_CERTIFICATE
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
PREDECESSOR_CERTIFICATE_NOT_CURRENT
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
CURRENT_AUDIT_PYZ_MUTATION_NOT_PERFORMED
CURRENT_RUNTIME_AUTHORITY_MUTATION_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

the next task is exactly one real audit using:

1. unchanged final audit PYZ;
2. unchanged runtime authority;
3. successor launch profile v1;
4. successor launch certificate v2;
5. replacement subject;
6. construction wrapper;
7. current content bundle;
8. current content authority;
9. accepted implementation authority chain.

Do not combine launch-authority completion with the real audit.
```

## Source and confidence

The attached report establishes that all current artifacts and fixed inputs authenticated, the 89-member PYZ closed, and no audit process or root was created. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

It identifies the missing launch controls precisely and confirms that the one future authorization remains unconsumed. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

**Provenance confidence:** 0.999  
**Incomplete-launch-authority classification confidence:** 0.999  
**PYZ/runtime-authority preservation confidence:** 0.995  
**Next-step confidence:** 0.99

Some older uploaded artifacts have expired. Re-upload an older file only if a later review needs its original bytes rather than the retained identities and reports.
