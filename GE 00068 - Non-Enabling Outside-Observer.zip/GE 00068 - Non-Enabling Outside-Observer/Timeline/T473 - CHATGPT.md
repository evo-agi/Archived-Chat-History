## Engineering assessment

The verifier reached a much stronger state than the earlier attempts, but its **acceptance model for temporal inventories was still wrong**.

The corrected fixed paths authenticated, all eight root identities authenticated, all eight root grammars were extracted and independently validated, all 15 verifier sources compiled, the static gates passed, and the 199-case closure-grammar matrix passed. :chatgpt-content-reference{index="0"}

The actual blocker was narrower and conceptually important:

- Projectors A and B agreed with each other.
- Both produced the expected 53 reconciliation temporal paths.
- Both nevertheless differed from the supplied temporal record for only two directory rows: `closeout` and `manifest`.
- Those differences were exactly in directory metadata changed by later closure operations: link count, modification time, and directory size.
- The report correctly concluded that the supplied temporal inventory contains **historical pre-closure topology metadata**, while the verifier attempted a **live final-state reprojection**. :chatgpt-content-reference{index="1"}

That means the remaining defect is not field-vocabulary translation. It is a mistaken equivalence between two different evidence cuts:

1. the **temporal cut**, captured before the temporal file and terminal manifests complete the namespace; and
2. the **terminal cut**, represented by the terminal manifests and observable from the current live root.

A final live tree cannot independently reproduce historical directory `size`, `link_count`, or `mtime_ns` after later writes have changed those directories. The verifier must authenticate the temporal record through its terminal-manifest binding, strict grammar, internal consistency, path-set semantics, closure lifecycle, stable-field correspondence, and package-owned pre-write verification evidence. It must reserve exact live reprojection for the terminal manifests.

No supplied root drift or implementation-package defect was established. All nine opened roots closed equal, no implementation verdict was issued, and no implementation or audit-harness source ran. :chatgpt-content-reference{index="2"}

The verifier’s two-attempt budget is exhausted, so that source lineage must not be patched or resumed. :chatgpt-content-reference{index="3"}

### Progression decision

Begin a **new clean verifier generation** with a frozen two-cut lifecycle model before source creation.

The failed verifier source must be historical evidence only. The new verifier must independently author:

- exact final-state manifest reprojection;
- historical temporal-snapshot authentication;
- root-specific closure lifecycle policies;
- stable-versus-mutable field classifications;
- explicit claim levels that distinguish “live reprojected” from “historical record authenticated.”

Only after that verifier is qualified and frozen should clean audit-harness implementation resume.

```text
NEW CLEAN GENERATION OF THE CURRENT-AUTHORITY CLOSURE VERIFIER

TWO-CUT TEMPORAL-SNAPSHOT AND TERMINAL-STATE MODEL

Objective

Implement a new clean-room current-authority verifier that correctly
distinguishes:

1. a historical temporal snapshot captured before later closure writes; and
2. the final terminal state represented by the canonical manifest pair.

The verifier must authenticate the exact eight current fixed inputs required by
the future clean independent-audit harness.

It must independently reproduce final terminal manifests from the current live
roots.

It must not require live final-state reprojection of historical directory
metadata recorded before later closure writes.

It must authenticate temporal inventories through:

- exact byte identity;
- terminal-manifest membership and identity binding;
- strict root-owned grammar;
- exact historical path-set semantics;
- exact stable-field correspondence;
- declared closure lifecycle;
- declared post-temporal writes;
- root-specific mutable-directory-field policy;
- package-owned pre-write verification evidence where present.

It must clearly distinguish:

- independently live-reprojected terminal facts;
- authenticated historical temporal facts;
- package-reported historical metadata not independently reobservable from the
  final live tree.

It must not implement the independent-audit harness.

It must not adjudicate the Generation-2 reconstruction-parent implementation.

It must not execute the implementation production source.

It must not construct the current schema subject.

It must not issue implementation ACCEPT or BLOCK.

It must not open any retired or failed audit-harness root.

Implement, qualify, freeze, requalify, and terminally close the new verifier
package.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not mutate a supplied root.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned implementation and qualification process in one
fresh private root.

At most two complete clean verifier-source attempts are permitted.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CURRENT_AUTHORITY_TWO_CUT_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

GEN2_CURRENT_AUTHORITY_TWO_CUT_VERIFIER_IMPLEMENTATION_BLOCKED

CURRENT_AUTHORITY_TWO_CUT_VERIFIER_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PRIOR VERIFIER LINEAGE — TERMINALLY RETIRED
──────────────────────────────────────────────────────────────────────────────

PRIOR_VERIFIER_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-closure-verifier-corrected-41ssflsk

Expected identity:

- device:
  16777234
- inode:
  181543268
- mode:
  0700
- verdict:
  GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTATION_BLOCKED
- source attempts:
  2 / 2
- source freeze:
  false
- success terminal seal:
  false
- same-root retry:
  false

Expected structured failure outcome:

- inode:
  181576958
- mode:
  0600
- size:
  792
- SHA-256:
  f3163a1e80e7a543566b168b4befbc5bc268a6649e4756b9304ab067a040ed87

Expected failure inventory:

- inode:
  181580508
- mode:
  0600
- link count:
  1
- size:
  26494
- SHA-256:
  92ae93ce5f29ff31455234304d86dda81cb7d8eef89083c611c5ba91005d854e

Authenticate through exact retained records:

opening/contract-package-closure-path-correction-v1.json
opening/fixed-root-registry-v2.json
opening/fixed-closure-path-registry-v1.json
opening/excluded-root-registry-v2.json
contract/current-root-closure-grammar-registry-v2.json
analysis/current-root-closure-grammar-extraction-v2.json
analysis/source-attempt-ledger-v2.json
contract/final-source-registry-attempt-2-v2.json
validation/current-root-closure-grammar-matrix-v2.json
analysis/reconciliation-temporal-reprojection-difference-v2.json
validation/current-authority-root-closure-replay-v2.json
validation/supplied-root-closing-equality-v2.json
closeout/failure-outcome-v2.json
closeout/failure-final-inventory-v2.json
validation/explicit-confirmation-registry-v2.json

Authenticate the exact historical mismatch:

`closeout` supplied/live:

- link count:
  4 / 5
- mtime_ns:
  1790647561927828505 / 1790647561929895831
- size:
  128 / 160

`manifest` supplied/live:

- link count:
  2 / 4
- mtime_ns:
  1790645824357020106 / 1790647561931988907
- size:
  64 / 128

Authenticate that:

- Projector A and B agreed;
- both produced 53 temporal paths;
- the only supplied/live row differences were the two directory rows above;
- the report classified the temporal record as historical closure-topology
  evidence and the candidate projections as live-only reprojections;
- all opened supplied roots closed equal;
- no implementation or package verdict was issued;
- no success verifier package was created.

Classify the prior root as:

historical_failed_live_only_temporal_reprojection_verifier

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- source-lineage exhausted;
- not a source base;
- not cleanable in this task.

The prior verifier’s source may not be:

- copied;
- patched;
- imported;
- executed;
- translated;
- used as a template;
- used as an AST or bytecode origin.

Its contracts, grammar records, matrices, and failure evidence may be used only
as historical requirements and regression evidence.

Require complete opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
2. FIXED CURRENT ROOT SET
──────────────────────────────────────────────────────────────────────────────

Open exactly these eight supplied roots.

A. TERMINAL_FINDINGS_RECONCILIATION

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected root identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

B. SEALED_IMPLEMENTATION_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected root identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

C. CURRENT_GENERATION_2_SUCCESSOR

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected root identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

D. AUTHORITATIVE_CONTRACT_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected root identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v2.json
manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

Expected corrected closure identities:

Temporal:

- size:
  17739
- SHA-256:
  e65b511f4c6fb69be9a14a4702ee32d2e1b670db04f4058b398fcf36d662f0f1

Manifest A/B:

- size:
  17596
- SHA-256:
  a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

E. CURRENT_SCHEMA_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected root identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

F. SCHEMA_RECONCILIATION_CAPSULE

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected root identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

G. CURRENT_VALIDATION_SPECIFICATION_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected root identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

H. CURRENT_ATTEMPT_2_FAILURE_SPECIMEN

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected root identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Expected failure outcome:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Resolve the exact failure-outcome path only through the implementation package’s
current Attempt-2 binding.

Do not search by basename, inode, size, hash, or directory scan.

──────────────────────────────────────────────────────────────────────────────
3. EXCLUDED ROOTS
──────────────────────────────────────────────────────────────────────────────

Do not open any retired or failed audit-harness root except the single prior
verifier root in Section 1.

Explicitly exclude:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-independent-audit-fresh-qAGO1c0a

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-4xuh1lon

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b

/Users/ds/Downloads/ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-dz2xlcfd

/Users/ds/Downloads/ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-current-authority-808ounoj

Retain:

opening/excluded-root-registry-v3.json

Every row must state:

- fixed input:
  false;
- opened:
  false;
- inventoried:
  false;
- source read:
  false;
- authority:
  none.

──────────────────────────────────────────────────────────────────────────────
4. FRESH TWO-CUT VERIFIER ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-current-authority-two-cut-verifier-

Immediately emit:

VERIFIER_ROOT=<absolute-path>

Before supplied-root inspection retain:

opening/bootstrap-start.json
opening/two-cut-verifier-authority-v1.json
opening/prior-verifier-disposition-v1.json
opening/fixed-root-registry-v3.json
opening/fixed-closure-path-registry-v2.json
opening/excluded-root-registry-v3.json
opening/process-execution-policy-v3.json

Authority is limited to:

- no-follow supplied-root inventory;
- strict closure-record parsing;
- root-specific grammar extraction;
- temporal-lifecycle authentication;
- terminal-state reprojection;
- immutable failure-specimen authentication;
- mutation qualification;
- verifier source freeze;
- verifier package closure.

Nonauthority includes:

- implementation ACCEPT/BLOCK;
- independent-audit harness implementation;
- implementation repair;
- implementation-source execution;
- current-subject construction;
- product/runtime/target/repository work;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
5. TWO-CUT EVIDENCE MODEL — PRE-SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Before verifier source creation retain:

contract/current-authority-two-cut-evidence-model-v1.json

Define exactly three closure classes.

A. TERMINAL_STATE_EXACT

Applicable to each successfully sealed root’s terminal manifest pair.

Authority rule:

- reproduce the current live final root exactly under the root-owned manifest
  grammar;
- require Projector A = Projector B;
- require both = manifest A;
- require both = manifest B;
- require A/B byte equality;
- require exact final topology, modes, links, hashes, exclusions, and root
  policy.

Claim level:

independently_live_reprojected_terminal_state

B. HISTORICAL_TEMPORAL_SNAPSHOT

Applicable to each successfully sealed root’s temporal inventory when the
record was generated before later closure writes changed directory metadata.

Authority chain:

terminal manifest
→ exact temporal-file identity
→ exact temporal bytes
→ strict temporal grammar
→ internal verification/producer-lifecycle records
→ path-set and exclusion rules
→ stable-field correspondence
→ declared post-temporal closure writes
→ declared mutable-directory-field policy

Claim level:

authenticated_historical_snapshot_lifecycle_consistent

This class must never claim:

independently_live_reprojected_historical_directory_metadata

C. IMMUTABLE_FAILURE_SPECIMEN

Applicable to Attempt 2.

Authority rule:

- exact root identity;
- exact failure-outcome binding;
- exact failure-outcome identity;
- complete current opening/closing inventories;
- no success temporal or terminal-manifest claim.

Claim level:

authenticated_immutable_failure_specimen

Unknown closure class fails closed.

──────────────────────────────────────────────────────────────────────────────
6. TEMPORAL FIELD CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-root-temporal-field-classification-v1.json

Create one row per sealed supplied root.

For every temporal entry field classify it as exactly one:

- stable_live_comparable;
- historical_mutable_directory_metadata;
- temporal_record_internal;
- terminal_manifest_bound_identity;
- not_applicable.

Default stable fields, when owned by the root grammar:

- path;
- entry kind/type;
- device;
- inode;
- mode;
- uid;
- gid.

Default regular-file fields for files included in the temporal cut:

- size;
- SHA-256;
- link count, when owned;
- other owned immutable identity fields.

These must match the final live tree exactly unless a governing lifecycle record
explicitly authorizes a later write to that exact file.

Historical mutable directory fields may include only fields explicitly declared
by the root lifecycle, such as:

- link count;
- directory size;
- mtime_ns or the root-owned modification-time field;
- ctime only when explicitly owned and governed.

Mutable directories must be enumerated by exact root-relative path.

A blanket “all directory metadata may differ” rule is forbidden.

For the reconciliation historical baseline, the lifecycle registry must
explicitly account for:

- `closeout`;
- `manifest`;

and the exact historical/live differences retained in Section 1.

Any difference in:

- path;
- kind;
- device;
- inode;
- mode;
- uid;
- gid;
- regular-file bytes;
- undeclared directory;
- undeclared field

fails closed.

──────────────────────────────────────────────────────────────────────────────
7. CLOSURE LIFECYCLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/current-root-closure-lifecycle-registry-v1.json

For every sealed root bind:

- role;
- temporal cut point;
- temporal self-exclusion;
- manifest exclusions;
- directories existing before the temporal cut;
- paths written after temporal projection;
- path owner for every post-temporal write;
- parent directories affected by each write;
- mutable directory fields;
- immutable directory fields;
- temporal file identity binding;
- terminal-manifest binding;
- internal verification evidence;
- producer lifecycle or seal evidence;
- no-nonclosure-write rule;
- terminal no-write rule.

Require exact closure sequence where governed, such as:

1. nonclosure outputs complete;
2. `closeout/` and `manifest/` already exist;
3. temporal bytes independently generated in memory;
4. temporal bytes verified before write;
5. temporal file written to `closeout/`;
6. manifest A/B namespace reserved or created according to root lifecycle;
7. A/B independently generated;
8. A/B written and read back;
9. final live reprojection;
10. terminal seal;
11. no later write.

Do not invent a sequence absent from the root’s authenticated evidence.

When lifecycle evidence is insufficient, block before source creation rather
than silently treating temporal data as live-reprojectable.

──────────────────────────────────────────────────────────────────────────────
8. ROOT-SPECIFIC GRAMMAR REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-root-closure-grammar-registry-v3.json

Create one exact row per root.

Preserve every root-owned vocabulary, including:

- reconciliation:
  `type`, `directory`, `regular_file`, `link_count`, directory `size`,
  `uid`, `gid`, `device`, `inode`, `mtime_ns`, regular-file `sha256`;
- implementation:
  `kind`, `directory`, `regular`, regular-file `nlink`;
- successor:
  successor-owned schemas, `subject`, verification fields, projection
  exclusions, and root binding;
- corrected contract:
  exact `v2` temporal and manifest grammars;
- schema package;
- schema reconciliation;
- validation package;
- Attempt-2 failure grammar.

Bind:

- temporal schema and path;
- manifest schemas and paths;
- entry pointers;
- path fields;
- per-kind fields;
- exclusions;
- root policy;
- serialization;
- unknown-field rules;
- ordering;
- final topology;
- temporal verification mode;
- terminal verification mode.

No generic cross-root field aliasing.

No current live projection may overwrite the historical temporal record’s field
values in evidence.

Retain both raw filesystem observations and root-vocabulary projections.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT PRE-SOURCE DOCUMENTARY VALIDATION
──────────────────────────────────────────────────────────────────────────────

Before verifier source creation, run a source-external documentary validator
against:

- fixed-root registry;
- closure-path registry;
- excluded-root registry;
- two-cut evidence model;
- temporal field classifications;
- lifecycle registry;
- grammar registry.

Require:

- eight exact current roles;
- seven sealed roots;
- one failure specimen;
- every temporal field classified once;
- every permitted mutable directory explicit;
- every permitted mutable field explicit;
- no temporal record assigned terminal live-reprojection authority;
- every terminal manifest assigned exact live-reprojection authority;
- no unsupported lifecycle invention;
- no conflicting authority;
- no excluded root access.

Any failure blocks before source creation and consumes zero source attempts.

──────────────────────────────────────────────────────────────────────────────
10. VERIFIER SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Define clean roles for:

- finite verifier parent;
- child recorder;
- strict JSON parser;
- no-follow inventory;
- root-specific grammar interpreter;
- raw filesystem observer;
- terminal Projector A;
- independently authored terminal Projector B;
- temporal snapshot authenticator A;
- independently authored temporal snapshot authenticator B;
- lifecycle evidence validator;
- stable-field comparator;
- mutable-directory-field adjudicator;
- failure-specimen verifier;
- mutation runner;
- current-root replay;
- independent end-to-end validator;
- supplied-root equality;
- fixture cleanup;
- terminal verifier-package lifecycle;
- failure closeout.

Terminal Projectors A/B may not import each other.

Temporal Authenticators A/B may not import each other.

Independent validation may not import:

- production projectors;
- production temporal authenticators;
- production grammar interpreter;
- production mutation generator;
- production expected-result maps.

Retain planned and final source registries.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete clean verifier-source attempts.

An attempt begins only when all final source registries close and compilation
begins.

Any source modification after compilation begins starts a new attempt.

If Attempt 2 fails:

- stop;
- do not create Attempt 3;
- return the blocked verdict unless provenance mismatch applies.

──────────────────────────────────────────────────────────────────────────────
12. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile all sources using pinned Python `-I -S -B`.

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- grammar-field crosswalk;
- temporal-authority crosswalk;
- lifecycle crosswalk;
- filesystem-operation crosswalk;
- process-launch crosswalk;
- terminal-operation crosswalk.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- all children through one recorder;
- no shell or PATH lookup;
- no Git/VCS;
- no network;
- no broad Downloads scan;
- no excluded-root access;
- no supplied-root mutation;
- no generic field aliasing;
- no missing-field coercion;
- no generic truthiness;
- no temporal/live authority conflation;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
13. TEMPORAL-LIFECYCLE MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 120 uniquely named cases.

Include:

A. Historical-cut baselines

- exact reconciliation `closeout` historical/live difference;
- exact reconciliation `manifest` historical/live difference;
- temporal record bound by final manifest;
- stable fields exact;
- declared mutable fields different;
- declared later writes present.

B. Wrong verification-mode cases

- temporal snapshot incorrectly required to equal final live metadata;
- terminal manifest treated as historical-only;
- live final projection accepted without matching manifests;
- temporal record accepted without terminal-manifest binding.

C. Stable-field mutations

- path differs;
- kind differs;
- device differs;
- inode differs;
- mode differs;
- UID differs;
- GID differs;
- regular-file size differs;
- regular-file hash differs;
- undeclared regular-file later write.

D. Mutable-directory mutations

- declared `closeout` size change;
- declared `closeout` link-count change;
- declared `closeout` mtime change;
- declared `manifest` size change;
- declared `manifest` link-count change;
- declared `manifest` mtime change;
- undeclared directory change;
- undeclared field change;
- mutable-field wrong type;
- historical mtime later than terminal mtime where chronology forbids it;
- missing post-temporal write explaining a change;
- extra post-temporal write.

E. Temporal authority-chain mutations

- temporal file missing from final manifest;
- temporal size mismatch;
- temporal hash mismatch;
- temporal schema mismatch;
- internal verification missing;
- producer lifecycle missing;
- stale source binding;
- wrong exclusions;
- wrong path set;
- duplicate root row;
- missing root row.

F. Terminal-state mutations

- A/B mismatch;
- live final projection differs from A/B;
- wrong terminal root identity;
- missing final path;
- extra final path;
- bad mode;
- symlink;
- special object;
- multilink;
- cache/bytecode.

G. Cross-root isolation

- reconciliation lifecycle applied to contract root;
- contract lifecycle applied to reconciliation;
- implementation grammar applied to successor;
- generic mutable-directory policy;
- same-length wrong record.

H. Failure specimen

- exact baseline;
- missing failure outcome;
- stale failure outcome;
- success temporal falsely required;
- success manifests falsely required.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/current-authority-two-cut-lifecycle-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
14. FINAL-STATE PROJECTOR AGREEMENT
──────────────────────────────────────────────────────────────────────────────

For each sealed root:

- Terminal Projector A independently projects the current live root under the
  terminal manifest grammar.
- Terminal Projector B independently projects the same root.
- Neither imports the other.
- Both retain raw observations.
- Both reproduce manifest A exactly.
- Both reproduce manifest B exactly.
- Both verify A/B byte equality.
- Both verify root policy, topology, modes, links, hashes, and exclusions.

Require:

A = B = manifest A = manifest B

This is the only lane allowed to claim:

independently_live_reprojected_terminal_state

──────────────────────────────────────────────────────────────────────────────
15. TEMPORAL-SNAPSHOT AUTHENTICATOR AGREEMENT
──────────────────────────────────────────────────────────────────────────────

For each sealed root:

Temporal Authenticator A and B independently verify:

1. exact temporal file identity;
2. temporal file inclusion and identity in the final manifest;
3. strict temporal grammar;
4. exact temporal path set;
5. exact exclusions;
6. exact root policy;
7. stable-field equality against the final live root;
8. regular-file byte/hash equality;
9. declared mutable directories only;
10. declared mutable fields only;
11. authenticated post-temporal write set;
12. authenticated lifecycle sequence;
13. internal temporal verification evidence;
14. terminal no-write evidence.

They must retain:

- the temporal record’s historical values unchanged;
- the final live values separately;
- field-by-field classification;
- cause of each permitted difference;
- claim level.

Require A and B to agree on:

- path set;
- stable-field results;
- permitted mutable differences;
- lifecycle evidence;
- overall result;
- first blocker.

They do not need to synthesize the historical directory metadata from the final
tree.

Required successful claim:

authenticated_historical_snapshot_lifecycle_consistent

Forbidden successful claim:

independently_live_reprojected_historical_directory_metadata

──────────────────────────────────────────────────────────────────────────────
16. CURRENT-ROOT REPLAY
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/current-authority-two-cut-root-replay-v1.json

For each role record:

- root identity;
- closure class;
- terminal-state result or N/A;
- temporal-snapshot result or N/A;
- terminal projector A result;
- terminal projector B result;
- temporal authenticator A result;
- temporal authenticator B result;
- stable-field differences;
- permitted historical mutable differences;
- lifecycle evidence;
- topology;
- modes;
- overall pass;
- first blocker or null;
- claim levels.

For Attempt 2 record only:

authenticated_immutable_failure_specimen

Overall allowed posture:

current_authority_inputs_authenticated_for_future_harness_implementation

Issue no implementation or package verdict.

──────────────────────────────────────────────────────────────────────────────
17. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero exit/empty streams;
- nonzero exit/both streams;
- timeout/kill/reap;
- one child;
- multiple children;
- empty ledger;
- lost stdout;
- lost stderr;
- unregistered filesystem effect;
- zero-root cleanup;
- one-root cleanup;
- multiple-root cleanup.

Require complete streams, exit/signal, reaping, descriptor closure, effect
attribution, evidence-before-cleanup, cleanup equality, double ENOENT, and zero
survivors.

──────────────────────────────────────────────────────────────────────────────
18. TWO VERIFIER QUALIFICATION REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct rehearsals over independently created synthetic
roots representing every registered grammar and lifecycle.

Each rehearsal must include:

- exact terminal-state baseline;
- exact historical temporal snapshot;
- post-temporal directory metadata changes caused by closure writes;
- all lifecycle mutation classes;
- immutable failure specimen;
- process custody;
- report generation;
- verifier-package terminal closure;
- cleanup.

Use identical candidate source bytes.

Retain complete roots until independent validation and normalized comparison
pass.

Normalize only explicitly governed physical fields.

Require zero unexplained semantic differences.

──────────────────────────────────────────────────────────────────────────────
19. INDEPENDENT VERIFIER VALIDATION
──────────────────────────────────────────────────────────────────────────────

Implement a source-external validator that imports neither:

- production verifier modules;
- qualification helpers;
- projectors;
- temporal authenticators;
- mutation generators;
- expected-result maps;
- grammar interpreters.

Independently verify:

- fixed and excluded root registries;
- two-cut evidence model;
- temporal field classifications;
- lifecycle registry;
- grammar registry;
- 120-case matrix;
- terminal projector independence and agreement;
- temporal authenticator independence and agreement;
- current-root replay;
- process custody;
- both rehearsals;
- normalized comparison;
- evidence retention;
- cleanup;
- verifier-package terminal closure.

Require zero errors and no exception.

──────────────────────────────────────────────────────────────────────────────
20. EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing an owned root retain:

- exact root identity;
- complete inventory;
- process records and streams;
- every result;
- failure outcome when applicable;
- terminal posture.

Then revalidate identity, remove the exact root, and observe ENOENT twice.

Require exact equality:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Equal empty sets pass.

──────────────────────────────────────────────────────────────────────────────
21. SOURCE FREEZE AND REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Freeze only after:

- pre-source documentary validation;
- compilation and static gates;
- lifecycle matrix;
- terminal projector agreement;
- temporal authenticator agreement;
- current-root replay;
- process custody;
- both rehearsals;
- normalized equality;
- independent validation;
- evidence retention and cleanup;
- supplied-root closing equality.

Retain:

opening/current-authority-two-cut-verifier-source-freeze-v1.json

Reopen every source no-follow.

Do not modify source afterward.

Against frozen bytes rerun:

- compilation;
- static gates;
- lifecycle matrix;
- terminal projector agreement;
- temporal authenticator agreement;
- current-root replay;
- process custody;
- independent validator;
- source/result identity linkage;
- supplied-root closing equality.

Do not rerun both complete rehearsals.

Prove both passing rehearsals used the exact bytes later frozen.

Retain:

validation/frozen-current-authority-two-cut-verifier-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
22. PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  current-authority-two-cut-verifier-implemented-qualified-frozen-ready-for-clean-harness-implementation;
- authority:
  current fixed-input closure authentication only;
- temporal claim:
  authenticated historical lifecycle-consistent snapshots;
- terminal claim:
  independently live-reprojected final state;
- implementation package adjudicated:
  false;
- independent-audit harness implemented:
  false;
- full audit executed:
  false;
- current schema subject constructed:
  false;
- product/runtime/target/repository/publication/deployment/A6:
  not performed or authorized.

──────────────────────────────────────────────────────────────────────────────
23. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow opening and closing inventories for:

- the prior failed verifier root, if opened;
- all eight current supplied roots.

Use one identical task-local raw observation grammar for opening and closing.

Require exact equality.

Do not open excluded historical roots.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
24. VERIFIER-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize all nonclosure outputs;
- create only used directories;
- precreate `closeout/` and `manifest/`;
- retain no empty descendant;
- reserve zero-length A/B;
- retain descriptors;
- freeze directory set.

Then:

1. generate temporal inventory excluding itself and A/B;
2. independently generate the same temporal bytes in memory;
3. require byte equality before write;
4. write to preexisting `closeout/`;
5. record its exact identity;
6. independently generate identical A/B excluding A/B;
7. write through retained descriptors;
8. fsync, close, and fsync manifest directory;
9. reopen no-follow;
10. verify path/inode/type/mode/link/size/hash;
11. independently reproject the final root exactly;
12. require root row once;
13. require no empty descendant;
14. require no symlink or special object;
15. require no multiply linked file;
16. require modes 0700/0600;
17. require no cache or bytecode;
18. transition seal once;
19. emit only guarded marker and verdict;
20. exit nonreturningly;
21. perform no filesystem or tool operation after seal.

The verifier package’s own temporal record must use the same two-cut lifecycle
model and must not attempt a post-write exact live reprojection of mutable
historical directory metadata.

──────────────────────────────────────────────────────────────────────────────
25. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- complete process ledger/streams;
- complete partial inventory;
- indispensable evidence;
- fixture cleanup;
- supplied-root equality;
- source-freeze posture;
- terminal-seal posture;
- same-root retry false.

Do not create success manifests for failure.

Return provenance mismatch for:

- fixed-input mismatch;
- supplied-root mutation;
- excluded-root access;
- historical source use;
- unregistered effect;
- indispensable evidence loss;
- cleanup inequality;
- supplied-root inequality;
- source drift;
- verifier-package closure failure;
- postseal operation.

──────────────────────────────────────────────────────────────────────────────
26. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CURRENT_AUTHORITY_TWO_CUT_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

only when:

- prior failed verifier authenticates;
- all fixed paths authenticate;
- two-cut model freezes;
- temporal field classifications close;
- lifecycle registry closes;
- root grammars close;
- reconciliation historical differences are classified as governed temporal
  metadata, not live-root drift;
- terminal projectors agree and exactly reproduce all final manifests;
- temporal authenticators agree and validate all historical snapshots;
- all eight roots authenticate;
- lifecycle matrix passes;
- process custody passes;
- both rehearsals pass;
- normalized comparison passes;
- independent validation passes;
- evidence retention and cleanup pass;
- source freezes;
- frozen requalification passes;
- supplied roots close equal;
- verifier package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CURRENT_AUTHORITY_TWO_CUT_VERIFIER_IMPLEMENTATION_BLOCKED

when:

- a lifecycle remains ambiguous;
- a root lacks enough authenticated lifecycle evidence;
- source cannot qualify within two attempts;
- a matrix, rehearsal, or validator fails;
- implementation would require inventing supplied semantics.

Return:

CURRENT_AUTHORITY_TWO_CUT_VERIFIER_PROVENANCE_MISMATCH

for provenance failures defined in Section 25.

──────────────────────────────────────────────────────────────────────────────
27. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh verifier-root identity
3. Prior failed verifier identity and disposition
4. Fixed-root registry
5. Fixed closure-path registry
6. Excluded-root registry
7. Confirmation excluded roots were not opened
8. Verifier authority and nonauthority
9. Two-cut evidence model
10. Temporal field-classification registry
11. Closure-lifecycle registry
12. Root-specific grammar registry
13. Pre-source documentary validation
14. Source architecture
15. Source-attempt ledger
16. Final source registries
17. Compilation and static gates
18. Temporal-lifecycle matrix
19. Terminal Projector A
20. Terminal Projector B
21. Terminal projector agreement
22. Temporal Authenticator A
23. Temporal Authenticator B
24. Temporal authenticator agreement
25. Reconciliation historical-cut adjudication
26. Implementation-root replay
27. Successor-root replay
28. Contract-root replay
29. Schema-source replay
30. Schema-reconciliation replay
31. Validation-source replay
32. Attempt-2 failure replay
33. Consolidated current-root replay
34. Process-custody qualification
35. Verifier rehearsal A
36. Verifier rehearsal B
37. Normalized rehearsal comparison
38. Independent verifier validation
39. Evidence retention
40. Fixture and rehearsal cleanup
41. Source freeze
42. Frozen-source requalification
43. Confirmation no implementation verdict was issued
44. Confirmation audit harness was not implemented
45. Package status
46. Supplied-root closing equality
47. Failure-closeout capability and use
48. Verifier temporal-inventory identity
49. Manifest A identity
50. Manifest B identity
51. Terminal reprojection
52. Terminal topology and modes
53. No-write-after-closure
54. Remaining uncertainty and nonclaims
55. Explicit confirmation registry

Required confirmations:

PRIOR_FAILED_VERIFIER_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_VERIFIER_ROOT_NOT_RESUMED
PRIOR_VERIFIER_SOURCE_LINEAGE_RETIRED
FIXED_CURRENT_ROOT_REGISTRY_COMPLETE
FIXED_CLOSURE_PATH_REGISTRY_COMPLETE
EXCLUDED_ROOT_REGISTRY_COMPLETE
NO_EXCLUDED_ROOT_OPENED
NO_HISTORICAL_VERIFIER_SOURCE_USED
TWO_CUT_EVIDENCE_MODEL_FROZEN
TERMINAL_STATE_EXACT_CLASS_FROZEN
HISTORICAL_TEMPORAL_SNAPSHOT_CLASS_FROZEN
IMMUTABLE_FAILURE_SPECIMEN_CLASS_FROZEN
TEMPORAL_FIELD_CLASSIFICATIONS_COMPLETE
MUTABLE_DIRECTORIES_EXPLICIT
MUTABLE_DIRECTORY_FIELDS_EXPLICIT
NO_BLANKET_DIRECTORY_METADATA_EXCEPTION
CLOSURE_LIFECYCLE_REGISTRY_COMPLETE
NO_UNSUPPORTED_LIFECYCLE_INVENTION
PER_ROOT_CLOSURE_GRAMMARS_FROZEN
UNKNOWN_CLOSURE_GRAMMAR_REJECTED
RECONCILIATION_REGULAR_FILE_VOCABULARY_PRESERVED
RECONCILIATION_LINK_COUNT_FIELD_PRESERVED
RECONCILIATION_DIRECTORY_SIZE_PRESERVED
RECONCILIATION_UID_GID_SEMANTICS_PRESERVED
RECONCILIATION_MODIFICATION_TIME_SEMANTICS_PRESERVED
HISTORICAL_TEMPORAL_VALUES_RETAINED_UNCHANGED
FINAL_LIVE_VALUES_RETAINED_SEPARATELY
NO_TEMPORAL_LIVE_AUTHORITY_CONFLATION
PRE_SOURCE_DOCUMENTARY_VALIDATION_PASSED
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
SOURCE_ATTEMPT_LIMIT_RESPECTED
ALL_VERIFIER_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
TEMPORAL_LIFECYCLE_MATRIX_PASSED
TERMINAL_PROJECTOR_A_B_AGREEMENT_PASSED
TEMPORAL_AUTHENTICATOR_A_B_AGREEMENT_PASSED
ALL_SEVEN_TERMINAL_STATES_LIVE_REPROJECTED
ALL_SEVEN_TEMPORAL_SNAPSHOTS_LIFECYCLE_AUTHENTICATED
ATTEMPT_2_FAILURE_SPECIMEN_AUTHENTICATED
CURRENT_ROOT_REPLAY_EMITTED_NO_PACKAGE_VERDICT
PROCESS_CUSTODY_QUALIFICATION_PASSED
COMPLETE_VERIFIER_REHEARSAL_A_PASSED
COMPLETE_VERIFIER_REHEARSAL_B_PASSED
TWO_VERIFIER_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_VERIFIER_VALIDATION_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
VERIFIER_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
VERIFIER_SOURCE_FROZEN
VERIFIER_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_VERIFIER_REQUALIFICATION_PASSED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
INDEPENDENT_AUDIT_HARNESS_NOT_IMPLEMENTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
VERIFIER_TEMPORAL_INVENTORY_CREATED
VERIFIER_TEMPORAL_INVENTORY_VERIFIED
VERIFIER_MANIFEST_A_CREATED
VERIFIER_MANIFEST_B_CREATED
VERIFIER_MANIFESTS_BYTE_IDENTICAL
VERIFIER_TERMINAL_REPROJECTION_PASSED
VERIFIER_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CURRENT_AUTHORITY_TWO_CUT_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

the next tranche is implementation and qualification of the new clean
source-external independent-audit harness, using the frozen two-cut verifier as
a current supplied tool.

Do not combine verifier implementation with harness implementation.

Do not execute the fresh full implementation audit until that later harness is
independently qualified and frozen.
```

### Sources

The report establishes that all corrected paths, all eight root identities, all eight root grammars, both projectors, compilation, static gates, and the 199-case grammar matrix passed before the replay blocker. :chatgpt-content-reference{index="4"}

The exact blocker was confined to historical versus live directory metadata for `closeout` and `manifest`, and the report explicitly states that historical directory-metadata reproduction was not implemented. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

All supplied roots remained unchanged, the verifier issued no implementation verdict, and its failure package closed without cache, invalid topology, or post-seal activity. :chatgpt-content-reference{index="7"}

**Confidence:** 0.999 that no implementation-package defect or supplied-root drift was established; 0.995 that the verifier failed by conflating historical and terminal evidence cuts; 0.98 that a clean two-cut verifier generation is the correct next tranche; 0.96 that exact final-manifest reprojection plus lifecycle-authenticated temporal snapshots is the right authority split.
