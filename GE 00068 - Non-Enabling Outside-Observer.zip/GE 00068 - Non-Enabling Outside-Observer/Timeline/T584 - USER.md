Here is Codex's response:

## 1. Exact primary verdict

`ES_ACTIVE_CANDIDATE_FINAL_AUDIT_REPAIR_REQUIRED`

The candidate has no identified production safety or authority defect, but three bounded test/harness defects and one mandatory native-Linux validation gate prevent commit readiness.

## 2. Opening repository identity

| Field | Authenticated value |
|---|---|
| Root | `/Users/ds/Repositories/Execution Substrate` |
| Branch | `trunk_dev` |
| HEAD | `b92bd9884106154d25342e1573dcc4c312311436` |
| Tree | `cdd4e44bac15c1952d70997143040644361f0bb1` |
| Parent | `4f797fb63d3c5b95275b1455af36ebc9b695f773` |
| Upstream | `origin/trunk_dev` |
| Divergence | behind 0, ahead 1 |
| Staged | 0 |
| Modified tracked | 64 |
| Untracked | 11 |
| Conflicts | 0 |
| Active Git operations/locks | none |
| Submodules | none |

Worktrees:

- Main: `/Users/ds/Repositories/Execution Substrate`, `trunk_dev`, expected HEAD.
- `Execution Substrate - evidence-verification-v1`, `codex/evidence-verification-v1`, `05dcedb…`
- `Execution Substrate - external-tls-lifecycle-reset`, `codex/remote-alpha-external-tls-lifecycle-reset`, `fbc0e72…`
- `Execution Substrate - external-tls-policy-core-v1`, `codex/remote-alpha-external-tls-policy-core-v1`, `05dde14…`
- `Execution Substrate - external-tls-policy-status-v1`, `codex/remote-alpha-external-tls-policy-status-v1`, `fbc0e72…`
- `Execution Substrate - external-tls-status-observation-v1`, `codex/remote-alpha-external-tls-status-observation-v1`, `567bcec…`

The supplied path/status digest `70f73043…` was not reproducible. The canonical opening and closing result of:

```text
git status --porcelain=v1 -uall | shasum -a 256
```

was:

```text
adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93
```

No canonical encoding tested produced the supplied digest. Because branch, commits, tree, exact path counts, worktree ownership, locks, and the opening/closing candidate set all match, this is an informational provenance-digest gap rather than an inability to distinguish protected changes.

## 3. Protected status and candidate inventory

All 75 candidate paths are regular files. `M` means modified tracked; `U` means untracked.

Authority documents, plans, navigation, and runbooks — 23:

```text
M .docs/execution_lifecycle/contracts.md
M .docs/execution_lifecycle/design.md
M .docs/execution_lifecycle/es_execution_admission_model.md
M .docs/execution_lifecycle/implementation.md
M .docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
M .docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
M .docs/system_overview/artifact_publication_storage.md
M .docs/system_overview/boundaries.md
M .docs/system_overview/capability_probing.md
M .docs/system_overview/configuration.md
M .docs/system_overview/contracts.md
M .docs/system_overview/remote_alpha_beta_es_privilege_boundary_assessment.md
M .docs/system_overview/remote_alpha_beta_es_privileged_operation_matrix.md
M .docs/system_overview/remote_alpha_beta_es_runtime_ownership_normalization.md
M .docs/system_overview/remote_alpha_beta_es_writable_state_ownership.md
M .docs/system_overview/remote_supported_host_alpha.md
M .docs/system_overview/runtime_config_ownership.md
M .docs/system_overview/supported_linux_host_qualification.md
M .runbooks/execution/v1_submit_runtime_identity_reference.md
M .runbooks/execution/v1_submit_static_script.md
M .runbooks/system/v1_bringup.md
M PLANS.md
M README.md
```

Documentation contract test — 1:

```text
M docs_contract_test.go
```

Admission production source — 15:

```text
M es/admission/authorityhandoff.go
M es/admission/executionpackage.go
M es/admission/lifecycle.go
M es/admission/mounts.go
M es/admission/ownership.go
M es/admission/policy_payload.go
M es/admission/results.go
M es/admission/service.go
M es/admission/submit.go
M es/admission/writablestate_preflight.go
U es/admission/resolved_execution_plan.go
U es/admission/resource_limits.go
U es/admission/staging_custody.go
U es/admission/staging_custody_darwin.go
U es/admission/staging_custody_linux.go
```

Admission tests — 17:

```text
M es/admission/authorityhandoff_test.go
M es/admission/executionpackage_test.go
M es/admission/lifecycle_nomad_test.go
M es/admission/lifecycle_test.go
M es/admission/mounts_test.go
M es/admission/reliable_submit_guardrails_test.go
M es/admission/results_test.go
M es/admission/service_direct_test.go
M es/admission/submit_test.go
M es/admission/workstream_c_guardrails_test.go
M es/admission/writablestate_readiness_test.go
U es/admission/resolved_execution_plan_test.go
U es/admission/resource_limits_test.go
U es/admission/staging_custody_darwin_test.go
U es/admission/staging_custody_linux_test.go
U es/admission/staging_custody_test.go
U es/admission/tranche_b2_privacy_guardrails_test.go
```

Application integration tests — 2:

```text
M es/app/result_integration_test.go
M es/app/staging_cleanup_integration_test.go
```

Remote Alpha root tests — 9:

```text
M remote_alpha_check_es_writable_state_readiness_test.go
M remote_alpha_es_service_user_rollback_rehearsal_test.go
M remote_alpha_migrate_es_service_user_test.go
M remote_alpha_operator_test.go
M remote_alpha_plan_old_root_cleanup_test.go
M remote_alpha_prepare_es_writable_state_ownership_test.go
M remote_alpha_runtime_security_boundary_check_test.go
M remote_alpha_stage_es_service_user_migration_test.go
M remote_alpha_stage_es_writable_state_readiness_check_test.go
```

Remote Alpha scripts — 8:

```text
M scripts/internal/operator_failures.sh
M scripts/internal/remote_alpha_check_es_writable_state_readiness.sh
M scripts/internal/remote_alpha_es_service_user_rollback_rehearsal.sh
M scripts/internal/remote_alpha_migrate_es_service_user.sh
M scripts/internal/remote_alpha_plan_old_root_cleanup.sh
M scripts/internal/remote_alpha_prepare_es_writable_state_ownership.sh
M scripts/internal/remote_alpha_stage_es_writable_state_readiness_check.sh
M scripts/remote_alpha_operator.sh
```

Only these candidate scripts have executable mode, as expected:

```text
scripts/internal/remote_alpha_es_service_user_rollback_rehearsal.sh
scripts/internal/remote_alpha_stage_es_writable_state_readiness_check.sh
scripts/remote_alpha_operator.sh
```

There are no candidate symlinks, special objects, generated files, or unexpected mode changes. Historical material is confined to explicitly labeled documentation history; it does not provide live authority.

Ignored material was preserved:

- 2,849 ignored paths, including 2,837 under `.out/`.
- 12 `.DS_Store`.
- 16 database/SQLite files.
- 76 archives.
- No `.pyc` or recognized cache directories.
- Preexisting proof outputs, binaries, tarballs, SQLite state, submit artifacts, and `.out/Dockerfile`.
- No candidate secret-bearing file was found. Secret-like matches were fixed refusal strings or test fixtures; no value is reproduced here.

## 4. Applicable guidance and plan

The applied authority order was:

1. `AGENTS.md`
2. current [PLANS.md](</Users/ds/Repositories/Execution Substrate/PLANS.md>)
3. `.docs/system_overview/**`
4. `.docs/execution_lifecycle/**`
5. current code and tests for factual behavior

`README.md` was used only for navigation.

The active candidate combines:

- Resolved-execution-plan foundation and B1 semantic ownership.
- B2 privacy assurance.
- Tranche A filesystem/resource custody.
- Retained staging/result publication behavior.
- Remote Alpha existing-host and evidence-compatibility retirement.
- Private reliable-submit work that remains runtime-unwired.

The latest completed obligation is accurately stated as the resolved-plan documentation-truth and finite-source-inventory closure. It changes no production custody source and begins no additional B behavior.

Remaining explicit work includes:

- Open-world source-flow and test-honesty audit.
- Reliable keyed-submit runtime wiring.
- Native Linux runtime validation on linux/amd64 and linux/arm64.

Native Linux validation is explicitly mandatory before the final combined audit and pre-commit; cross-compilation is compile evidence only.

## 5. Candidate scope and commit-boundary classification

Classification: **A — one coherent integration commit, after repair and missing validation**.

Although the candidate covers several ordered sub-tranches, their implementation, authoritative documents, root tests, and guardrails overlap extensively. Splitting by whole path would leave intermediate code/doc/test disagreement; splitting shared files by hunk would create fragile provisional boundaries.

No unrelated or nonqualifying work was found among the 75 paths.

## 6. Final seven-file repair audit

Audited:

- `PLANS.md`
- `.docs/execution_lifecycle/design.md`
- `.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md`
- `.docs/execution_lifecycle/es_execution_admission_model.md`
- `.docs/system_overview/remote_supported_host_alpha.md`
- `docs_contract_test.go`
- `es/admission/workstream_c_guardrails_test.go`

Results:

- The completed PLANS obligation is factually supported and is not a claim that the entire candidate is commit-ready.
- Resolved-plan authority is limited to admitted semantics.
- No plan, projection, DTO, report, or evidence record is declared hidden run truth.
- Byte material, host context, lifecycle, scheduler, retained-result, and replay ownership remain separately assigned.
- The documented inventories match production source.
- No reliable-submit runtime or external-schema-package behavior changed.
- Mutation coverage exists for inventory escapes, but semantic-order source checks remain vulnerable to comment/string duplication and incidental formatting. This is the medium test-oracle finding in §18.

## 7. Resolved-plan authority analysis

The admitted semantic plan owns:

- Request and invocation schema versions.
- Mode and timeout.
- CPU/memory.
- Selected runtime profile and image.
- Artifact, payload, derivation, output, runtime-support, and configuration digests.
- Resolved command and semantic environment.
- Mount semantics.
- Network policy.
- Admitted authority semantics.
- Runtime identity tmpfs size.
- Nomad job-envelope policy.

Material ownership retains byte-bearing facts:

- Payload bytes.
- Captured runtime-support bytes.
- Validated compressed mount bytes and parsed entries.
- Vault CA and workload TLS bundle bytes.

Host materialization context retains:

- Qualified staging root.
- Platform-state owner.
- SPIRE source directory.
- Datacenter.

The results root is normalized/qualified separately and is not promoted into plan or host authority.

Runtime and lifecycle truth remains with submitted Nomad state, authority handoff, lifecycle readers, and retained-result storage—not the plan.

`resolveExecutionForSubmit` deep-copies mutable maps, slices, and byte-bearing input before returning. The successful resolver return is the freeze point. No post-freeze mutation path was found.

`Submit` creates one `resolvedRunProjection`; materialization, handoff, job construction, revalidation, and registration derive from that projection. Exactly one Nomad submit call follows successful final revalidation.

No replay/retained-result path treats the plan as commitment, witness, run identity, scheduler truth, or lifecycle truth. Public Submit remains unkeyed, so no durable retry authority is inferred.

## 8. Custody and materialization audit

The sole production claim constructor is `claimStagingCustody`; production callers are `Submit` and the startup capability probe.

The sole production materializer is `materializeExecutionInputs`, called by `Submit`. Its mutation graph is:

- `stagePayload`
- `stageCapturedRuntimeSupportBinary`
- `stageWorkloadVaultTrustMaterial`
- `materializeValidatedRuntimeMounts`
- custody `ensureDirectory`
- custody `writeFile`

Darwin uses no-follow-any opens, exclusive rename, and stable identity/device checks. Linux uses `openat2` with beneath/no-magiclink/no-symlink restrictions, `NO_XDEV` where required, and `renameat2(RENAME_NOREPLACE)`.

Verified properties:

- Exclusive visible run-root creation; no adoption of an existing object.
- Descriptor-held ancestry and identities.
- No symlink traversal or path escape.
- No mutation of refused preexisting objects.
- Fresh directory cursor for each expected-tree validation.
- Exact incomplete-leaf or operation-local temporary cleanup only.
- Every post-claim path closes descriptors and retains the visible root.
- No whole-root cleanup, scanning, quarantine, or reclamation.
- No subprocess is created by the custody path.
- No hidden process or descriptor survivor was found.
- Darwin/Linux behavior is separated in platform files.
- No hidden package/global custody registry or rejected-A3 topology was found.

No production safety defect was established.

## 9. ReadDir inventory reconstruction

Production inventory:

- Interface declaration: `directoryEntryReader.ReadDir(int)`.
- Expected-tree completeness: `validateExpectedDirectoryEntries` calls `ReadDir(1)` using a fresh descriptor/cursor.
- Retained-result traversal: `readDirectoryEntries` calls `ReadDir(64)`; this is a separate bounded retained-result operation.

No other production or platform-specific `ReadDir` path participates in expected-tree validation. Test direct calls and synthetic fixtures are classified separately.

No missing, extra, stale, or wrongly platform-classified production row was found. The documented inventory is correct. The broader raw-source guardrail still has the brittleness described in §15.

## 10. Custody-claim inventory reconstruction

- Constructor/returner: `claimStagingCustody`.
- Production caller: `Service.Submit`.
- Capability-boundary caller: `probeStagingCustodyCapabilities`.
- Platform primitives: `platformOpenAtNoFollow`, `platformRenameNoReplace`, and `platformStatSnapshotStable`.
- Direct test callers are enumerated separately.
- Synthetic fixture strings are excluded from production counts.

No alternate production claim entry point, missing row, or hidden claim registry was found.

## 11. Materialization inventory reconstruction

- Sole producer: `materializeExecutionInputs`.
- Sole production caller: `Service.Submit`.
- Mutation graph is the exact stage/write graph listed in §8.
- Mount archives are parsed and validated once; materialization consumes captured entries and does not reparse compressed data.
- Direct test callers are distinguished from production.
- Platform variants supply primitives, not alternate materializers.

No alternate staging path, missing production caller, or extra materialization owner was found.

## 12. Synchronized-state inventory reconstruction

Exact governed mutable-state owners:

- `admission.Service.mu`
  - Protects trust-model state.
  - `Initialize` writes.
  - `Health` and `currentTrustModel` read.
  - Returned state is copied.
- `app.App.mu`
  - Protects start/listener lifecycle state.
- `runtimehelper.helperServer.mu`
  - Protects cached token state.
  - Readers receive copied values.

No atomics were found in the governed inventory. `reservedRuntimeEnvKeys` is static after initialization and is not a mutable authority registry.

Test hooks and immutable regex/error globals are not custody, lifecycle, lease, or root-pair authorities. No transitive synchronization escape or competing mutable writer was established.

## 13. Rejected-A3 reconstruction

Production source contains none of the rejected topology:

- Namespace lease or registry.
- Staging/results registry.
- Root-pair coupling.
- Package/global synchronized custody registry.
- `unix.Flock`.
- Persistent lease marker.
- Mutation-poison state.

The absence checks and mutation tests cover addition and removal/rename cases. No production reintroduction was found.

## 14. Retired-alias reconstruction

Retired top-level evidence routes:

- `vault-workload-auth-check`
- `runtime-identity-summary`
- `vault-service-user-check`

Nested recovery aliases:

- `vault-workload-auth-check`
- `runtime-identity-summary`

There is no nested `vault-service-user-check`.

Retired split and equals-form flags:

- `--evidence-check`
- `--evidence-dir`
- `--strict-known-schema`
- `--vault-workload-auth-summary`
- `--runtime-identity-summary`
- `--vault-service-user-summary`

Historical P0h flags remain separately retired:

- `--readiness-summary`
- `--staging-record`

Existing-host tombstone routes:

- `es-writable-state-readiness-check`
- `readiness-session`

Their six underlying helpers are fixed exit-2 tombstones. Unrelated recovery, TLS, and EGS routes remain live.

`reject_secret_args` precedes retired-route argument classification, and classification occurs before path/helper initialization. The behavioral inventory is correct; its source-layout oracle is not maintainable enough for commit readiness.

## 15. Docs/test-guardrail quality findings

Most inventory guards use finite source roots and identify production versus tests correctly. No hard-coded absolute private path, filesystem traversal ordering, or generated-output scan was found.

Two guardrail families violate the governing quality rule:

1. [workstream_c_guardrails_test.go:136](</Users/ds/Repositories/Execution Substrate/es/admission/workstream_c_guardrails_test.go:136>) and [line 4050](</Users/ds/Repositories/Execution Substrate/es/admission/workstream_c_guardrails_test.go:4050>) use `strings.Count`, exact `strings.Index` ordering, and the helper at [line 4201](</Users/ds/Repositories/Execution Substrate/es/admission/workstream_c_guardrails_test.go:4201>) for semantic call/control-flow claims.

2. [remote_alpha_operator_test.go:5139](</Users/ds/Repositories/Execution Substrate/remote_alpha_operator_test.go:5139>) and [line 5180](</Users/ds/Repositories/Execution Substrate/remote_alpha_operator_test.go:5180>) compare complete shell function text and indentation. `shellFunctionSource` at [line 5257](</Users/ds/Repositories/Execution Substrate/remote_alpha_operator_test.go:5257>) assumes an exact source layout.

Comments or dead strings can satisfy these checks; harmless formatting/refactoring can fail them. Exact public refusal text may remain a textual assertion, but semantic order and ownership require AST/parser/object identity or behavior-level verification.

## 16. macOS temp-root adjudication

Classification: **C — the tests improperly depend on the host’s symlinked default temporary-root spelling and require a test-owned physical fixture root.**

Evidence:

- Default macOS `t.TempDir()` paths begin under `/var/folders`.
- `/var` resolves through `/private/var`.
- The production custody implementation correctly rejects symlinked ancestry.
- Bare documented commands fail with `too many levels of symbolic links`.
- The same tests pass with `TMPDIR=/private/tmp`.
- No governing document makes `TMPDIR=/private/tmp` an explicit validation contract or declares the default invocation unsupported.

The correct repair is test-only: resolve custody-sensitive temporary roots to their physical path, preferably through one shared helper based on `filepath.EvalSymlinks(t.TempDir())`. Production no-follow policy should not be weakened.

## 17. Authority/security/privacy findings

No authority or security widening was established:

- No hidden mutable run truth.
- No stale plan copy consumed as a later authority.
- No privilege-boundary or filesystem-scope widening.
- No whole-root or recursive cleanup.
- No descriptor/process leak identified.
- No raw provider, credential, token, trust-material, or unexpected-child value in fixed public errors.
- Secret-option privacy filtering remains first.
- No unsupported Remote Alpha route revival.
- Capability enforcement uses behavior/static-resource checks, not OS-label branching.

No product-affecting external-schema-package integration exists:

- No external schema bytes.
- No content-snapshot reader.
- No external role registry.
- No Downloads path.
- No external digest pin.
- No current-schema-package ES role/checker.
- No external audit/promotion coupling.

Historical schema rationale is explicitly non-authoritative.

## 18. Complete severity-ranked findings

No critical or high findings.

### Medium M1 — macOS custody test-harness defect

- Type: test-harness/environment defect.
- Contract: ordinary documented developer commands must succeed or have an explicit governed prerequisite.
- Evidence: bare admission/full tests fail under `/var/folders`; physical-root tests pass.
- Effect: default validation is red and relies on an undiscoverable environment override.
- Owner: ES admission test harness.
- Exact repair surface:
  - `executionpackage_test.go`
  - `lifecycle_test.go`
  - `mounts_test.go`
  - `resolved_execution_plan_test.go`
  - `resource_limits_test.go`
  - `results_test.go`
  - `service_direct_test.go`
  - `staging_custody_darwin_test.go`
  - `staging_custody_test.go`
  - `submit_test.go`
  - `workstream_c_guardrails_test.go`
  - `writablestate_readiness_test.go`
- Repair: centralize a physical temporary-root helper in an existing admission test file and use it for custody-sensitive roots.
- Production bytes: no.
- Docs: no change needed if the harness is corrected.
- Required validation: focused tests, both bare default commands, physical-root sequence, and race suite.

### Medium M2 — Go semantic source-oracle defect

- Type: test-oracle defect.
- Path/symbols: [workstream_c_guardrails_test.go](</Users/ds/Repositories/Execution Substrate/es/admission/workstream_c_guardrails_test.go:136>), the post-freeze guard, Tranche A custody guard, and `assertContainsInOrderAdmission`.
- Contract: use AST/parser inspection where semantics matter; do not freeze incidental formatting.
- Evidence: raw counts and substring-order indices stand in for object identity and control flow.
- Effect: false pass through comments/dead strings; false failure after harmless refactoring.
- Owner: Workstream C guardrail tests.
- Repair surface: that existing test file.
- Repair: replace semantic string/count/order checks with Go AST/types inventories and behavior/mutation tests; retain raw matching only for literal text contracts.
- Production bytes: no.
- Docs/tests sufficient: tests only.
- Required validation: focused guardrails, mutation cases, default and physical full suites.

### Medium M3 — shell source-layout oracle defect

- Type: test-oracle defect.
- Path/symbols: [remote_alpha_operator_test.go](</Users/ds/Repositories/Execution Substrate/remote_alpha_operator_test.go:5139>), both exact-inventory tests and `shellFunctionSource`.
- Contract: source semantics must not depend on indentation or complete function-text equality.
- Evidence: exact prefixes, indentation, function body text, and lexical occurrence counts are asserted.
- Effect: legitimate formatting is frozen; comments or inert source can satisfy inventory counts.
- Owner: Remote Alpha operator tests.
- Repair surface: `remote_alpha_operator_test.go`.
- Repair: retain exact behavioral vectors for every route/flag/privacy ordering and fixed public text; replace complete function-body equality with structure-insensitive inventory/parsing.
- Production bytes: no.
- Docs/tests sufficient: tests only.
- Required validation: focused operator tests, `bash -n`, root suite, and full physical suite.

### Medium M4 — mandatory native-Linux runtime evidence missing

- Type: environment/host condition.
- Contract: [PLANS.md:303](</Users/ds/Repositories/Execution Substrate/PLANS.md:303>) and [PLANS.md:395](</Users/ds/Repositories/Execution Substrate/PLANS.md:395>) require native linux/amd64 and linux/arm64 validation before commit.
- Evidence: Darwin runtime tests and both Linux cross-compiles passed; no native Linux execution occurred.
- Effect: real `openat2`, `renameat2(RENAME_NOREPLACE)`, identity, collision, and mount-crossing behavior remains unverified for claimed deployment architectures.
- Owner: release/audit operator on governed Ubuntu 24.04 hosts.
- Repair surface: validation evidence; no repository source change.
- Production bytes: no.
- Docs/tests alone sufficient: no.
- Required validation: native `go test ./es/admission -count=1` on linux/amd64 and linux/arm64 with Go 1.26.5.

### Informational

- Supplied status digest is not reproducible; canonical opening and closing digest is stable.
- An initial Go 1.26.1 invocation failed before tests because `go.mod` requires 1.26.5.
- An initial overly narrow `PATH` caused unrelated Python/OpenSSL failures; the exact tests were rerun with the original environment preserved and the cached Go 1.26.5 toolchain prepended.

## 19. Formatting inspection

The exact modified/untracked Go set is the 44 `.go` paths enumerated in §3.

- `gofmt -l` over all 44 paths: exit 0, no output.
- `git diff --check`: exit 0, no output.
- No file was formatted or rewritten.

## 20. Focused validation results

CWD for every command:

```text
/Users/ds/Repositories/Execution Substrate
```

Successful environment:

```text
PATH=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin:<original PATH>
GOTOOLCHAIN=local
GOPROXY=off
GOSUMDB=off
GOFLAGS=-mod=readonly
```

The first attempt with launcher Go 1.26.1 exited 1 before tests: `go.mod requires go >= 1.26.5`. Classification: toolchain invocation failure.

Corrected admission command:

```text
go test ./es/admission -run '^(TestResolvedExecutionPlanSourcePrivacyGuardrails|TestResolvedExecutionPlanPostFreezeConsumerGuardrails|TestAdmissionProductionHasOneResolverAndOneMaterializationPath|TestStagingCustodyReadDirInventoryIsFinite|TestStagingCustodyReadDirInventoryRejectsFiniteEscapes|TestTypedResolverAndMaterializerInventoryRejectsReferenceEscapes|TestStagingOwnershipDeclarationInventoryRejectsAlternateEntryPoints|TestExecutionSubstrateProductionHasNoA3LeaseRegistryOrPoisonDesign|TestExecutionSubstrateSynchronizedMutableStateReferenceInventoryIsExact|TestTypedObjectReferenceInventoryRejectsEscapes|TestStructuralProductionStateInventoryRejectsNeutralMapBesideLock|TestStructuralProductionStateInventoryRejectsTransitiveSynchronizationAndMaps)$' -count=1
```

Exit 0: `ok execution-substrate/es/admission 3.524s`.

Corrected root command:

```text
go test . -run '^(TestResolvedPlanDocumentationTruthAndFiniteInventoriesContract|TestRemoteAlphaOperatorDocsRetireExistingHostESRoutes|TestRemoteAlphaOperatorDocsRetireAllSelectedEvidenceCompatibility|TestRemoteAlphaOperatorExistingHostESRoutesAreFixedEffectFreeTombstones|TestRemoteAlphaOperatorRetiredRoutesApplyExactPrivacyPrefilterFirst|TestRemoteAlphaOperatorEvidenceCompatibilitySurfacesAreFixedEffectFreeRetirements|TestRemoteAlphaOperatorEvidenceRetirementKeepsPrivacyPrefilterFirst|TestRemoteAlphaOperatorRetiredRouteSourceInventoryIsExact|TestRemoteAlphaOperatorEvidenceRetirementSourceInventoryIsExact)$' -count=1
```

Exit 0: `ok execution-substrate 0.683s`.

## 21. Default-host validation results

`go test ./es/admission -count=1`: exit 1.

`go test ./... -count=1`: exit 1; root and all other packages passed, while `es/admission` failed for the same symlinked-temp-root cause. `es/app` passed in 103.985s.

Complete failing top-level tests:

```text
TestTrancheB2TrustMaterializationCauseUsesFixedPublicError
TestWorkloadTrustMaterialCaptureWritesVaultAndCombinedBundles
TestDescriptorCloseRetainsSuccessfulRunRoot
TestRuntimeMountArchiveValidatesThenMaterializesWithinLimits
TestRuntimeMountArchiveMaterializerDoesNotReparseCompressedBytes
TestResolvedExecutionMaterialOwnsBytesBeforeHostMaterialization
TestSubmitAmbiguousNomadFailurePreservesPrimaryErrorAndRetainsRoot
TestResolvedSubmitLegacyEquivalenceOneNomadRegistrationAndAuthorityRecovery
TestRuntimeSupportMaterialIdentityMatchesCapturedBytes
TestTrancheB1QualifiedHostCaptureNormalizesEquivalentConfiguration
TestTrancheB1PayloadDigestLineageIsDistinctPrivateAndPreEffect
TestTrancheB1DefaultProfileLiteralNomadJobAndAuthorityHandoff
TestTrancheB2ControlPlaneNormalShellLiteralNomadJobAndAuthorityHandoff
TestTrancheALocalMaterialBoundariesUseSelectedLimits
TestStableLocalCaptureEnforcesExactLimitNoFollowSingleLinkAndLeafIdentity
TestStableLocalCaptureDetectsAncestorReplacement
TestTrancheB2GovernedResultRetentionLogsContainOnlyValidatedRunID
TestRetainTerminalResultPackagesResultDirectory
TestWorkstreamC3RetainedResultBundleRemainsESOwnedOpaqueOutput
TestRetainTerminalResultFailsClosedForSymlinkResultEntry
TestRetainTerminalResultFailsClosedForHardLinkedResultFile
TestRetainTerminalResultFailsClosedForSpecialResultFile
TestRetainedResultPublicationConcurrentWinnerAndValidatedLoser
TestRetainedResultPublicationValidatesExistingFinal
TestRetainedResultPublicationFaultsBeforeCommitAndDuringValidation
TestResultPublicationConflictRetainsStageRoot
TestRetainedResultCustodyRefusesConfiguredRootReplacementBeforeRead
TestResultReturnsRetainedBundleWithoutRuntimeLookup
TestResultRetainedBundleLookupIsScopedToRunID
TestResultRejectsUnsafeResultReferencesBeforeStorageLookup
TestRetainTerminalResultDoesNotSynthesizeInternalResultSidecars
TestResultReturnsRuntimeUnavailableWhenConfiguredRuntimeHasNilNomadClientAfterNoRetainedBundle
TestResultRuntimeUnavailableErrorResponseExcludesCredentialSecurityFields
TestResultReturnsNotFoundForTerminalExecutionWithoutOutput
TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess
TestValidateExecutionRuntimeInputsRejectsNonRegularBinary
TestDarwinStagingCustodyCapabilityProbeExercisesActualSyscalls
TestDarwinStagingCustodyRevalidationRefusesRootReplacementAndRetainsIt
TestStagingCustodyCreatesNoMarkerAndCloseRetainsRoot
TestStagingCustodyAcceptsDeepIterativeExpectedTree
TestStagingCustodyExpectedTreeSharesPrefixesAndOwnsEachEdgeOnce
TestStagingCustodyExpectedTreeRegistrationIsIdempotentAndRejectsConflicts
TestStagingCustodyValidationUsesFreshCursorAndIsRepeatable
TestStagingCustodyRevalidatesEmptyExpectedDirectory
TestStagingCustodyMaterializationRefusesPreExistingLeaf
TestStagingCustodyRevalidationDetectsReplacementAndRetainsBothTrees
TestStagingCustodyRevalidationDetectsHardLinkAndSymlinkReplacement
TestStagingCustodyRevalidationRejectsEveryUnexpectedChildWithoutMutation
TestStagingCustodyRevalidationRejectsMissingExpectedChildWithoutCleanup
TestStagingCustodyCapabilityProbeRemovesOnlyItsExactObjects
TestTrancheB2SubmitPublicNomadFailureIsFixedAndProviderBodyFree
TestSubmitRejectsUnexpectedStagingChildBeforeNomadAndRetainsTree
TestWorkstreamCSubmitReceiptRemainsBoundedAndHidesSchedulerIdentifiers
TestStageExecutionInputsSucceedsWithOwnerOnlyStagingRoot
TestRuntimeMountExtractionSucceedsWithOwnerOnlyMountStageRoot
TestRetainTerminalResultPackagesOwnerOnlyReadableResultTreeWithoutNormalizationMarker
TestRetainTerminalResultAcceptsValidOwnershipNormalizationMarker
TestResultServesRetainedBundleWhileStageRemains
TestReadRetainedResultBundleFailsClosedWithoutReconcilingExistingFinal
TestStatusTerminalSuccessWithValidNormalizationMarkerRetainsResultAndStage
TestStatusTerminalSuccessWithoutNormalizationMarkerRemainsAlphaCompatible
TestStatusTerminalSuccessWithInvalidNormalizationMarkerSkipsCleanupAndLeavesResultUnavailable
TestStatusTerminalFailureWithValidNormalizationMarkerRetainsStageRootForDebugging
TestStatusTerminalLostWithValidNormalizationMarkerRetainsStageRootForDebugging
TestStatusTerminalCanceledWithValidNormalizationMarkerRetainsStageRootAndServesRetainedResult
TestStatusTerminalCanceledWithInvalidNormalizationMarkerRetainsStageRootAndLeavesResultUnavailable
```

Failing subcases additionally covered:

- Existing-final validation: exact idempotent, invalid digest, wrong mode/link/owner.
- Publication faults: winner failure and final replacement.
- Replacement detection: hardlink and symlink.
- Unexpected-child rejection: root regular/dir/symlink/FIFO, payload, platform, result, mount-root, and nested mount cases.

Classification: test-harness defect, not production custody failure.

## 22. Physical-root validation results

With the successful environment from §20:

```text
TMPDIR=/private/tmp go test ./es/admission -count=1
```

Exit 0: `ok ... 5.188s`.

```text
TMPDIR=/private/tmp go test ./es/app -count=1
```

Exit 0: `ok ... 68.336s`.

```text
TMPDIR=/private/tmp go test . -count=1
```

Exit 0: `ok ... 74.200s`.

```text
TMPDIR=/private/tmp go test ./... -count=1
```

Exit 0:

- Root: 79.373s
- Admission: 5.914s
- App: 102.170s
- All packages passed.

An earlier root/full attempt with an overly narrow `PATH` exited 1 because it selected Python 3.9 without `tomllib` and an unsuitable system OpenSSL. Classification: invocation-environment failure. The commands were rerun with the original PATH preserved and passed as above.

## 23. Race-validation result

```text
TMPDIR=/private/tmp go test -race ./es/admission ./es/app -count=1
```

Exit 0:

- Admission: 15.495s
- App: 262.699s

No race was reported.

## 24. Full-suite disposition

- Focused guardrails: pass.
- Formatting and whitespace: pass.
- Default admission/full suite: fail because of the undisclosed macOS temp-root dependency.
- Physical-root admission/app/root/full suite: pass.
- Race suite: pass.
- Offline linux/amd64 cross-compile: pass.
- Offline linux/arm64 cross-compile: pass.
- Mandatory native linux/amd64 runtime: not executed.
- Mandatory native linux/arm64 runtime: not executed.

The passing override does not erase the default-host failure.

## 25. Commit-readiness adjudication

The candidate is not ready to stage or commit.

Required before a new final audit:

1. Repair the macOS physical-temp test harness.
2. Replace the two Go semantic raw-source oracles.
3. Replace the shell complete-function-text oracle.
4. Run the repaired default and physical/race suites.
5. Obtain native Linux runtime evidence on both required architectures.

No new architecture, authority, lifecycle, or product-scope decision is required.

## 26. Exact proposed stage set

Current stage set: **empty**.

After the bounded repairs and a clean re-audit, stage exactly the 75 `M`/`U` paths enumerated in §3—no other path. The proposed repairs can remain within existing candidate test paths, so no new file is required.

Remain unstaged:

- `AGENTS.md`
- All ignored `.out`, database, archive, `.DS_Store`, proof, build, and generated artifacts.
- Every other path not explicitly listed in §3.

## 27. Exact commit boundary

One integration commit:

- All 75 audited candidate paths.
- Test-only repairs contained within the existing test paths.
- Dependent native-Linux validation attached as pre-commit evidence.
- No ignored or generated artifacts.

A final post-stage diff audit remains mandatory.

## 28. Proposed commit subject

```text
execution: finalize resolved plan, custody, and retired routes
```

## 29. Required post-stage validation

After repair, but before commit:

```text
gofmt -l <all staged Go paths>
git diff --cached --check
```

Rerun both focused expressions from §20, then:

```text
go test ./es/admission -count=1
go test ./... -count=1
TMPDIR=/private/tmp go test ./es/admission -count=1
TMPDIR=/private/tmp go test ./es/app -count=1
TMPDIR=/private/tmp go test . -count=1
TMPDIR=/private/tmp go test ./... -count=1
TMPDIR=/private/tmp go test -race ./es/admission ./es/app -count=1
```

On governed Ubuntu 24.04 hosts with exact Go 1.26.5:

```text
GOARCH=amd64 go test ./es/admission -count=1
GOARCH=arm64 go test ./es/admission -count=1
```

Run each natively on its matching architecture; do not substitute cross-compilation.

Finally inspect:

```text
git diff --cached --stat
git diff --cached --summary
git diff --cached
git status --short
```

Recheck modes, secrets, exact stage membership, docs/code/test agreement, and repository identity.

## 30. Remaining uncertainty

- Native Linux syscall behavior remains unexecuted.
- The supplied digest-generation protocol is unknown and did not reproduce.
- Repairs will change candidate bytes, so this audit cannot serve as final approval of the repaired tree.
- Same-service-principal races are outside the documented adversary model; no broader claim is inferred.
- Reliable keyed-submit runtime remains intentionally unwired.

## 31. Closing repository identity and status

Closing state exactly preserved:

| Field | Closing value |
|---|---|
| Branch | `trunk_dev` |
| HEAD | `b92bd9884106154d25342e1573dcc4c312311436` |
| Tree | `cdd4e44bac15c1952d70997143040644361f0bb1` |
| Parent | `4f797fb63d3c5b95275b1455af36ebc9b695f773` |
| Upstream | `origin/trunk_dev` |
| Divergence | behind 0, ahead 1 |
| Staged | 0 |
| Modified tracked | 64 |
| Untracked | 11 |
| Conflicts | 0 |
| Locks/active operations | none |
| Submodules | none |
| Canonical status digest | `adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93` |
| Ignored paths | 2,849; unchanged |

The six-worktree set and every worktree branch/HEAD matched opening state. No repository-local task artifact, content change, mode change, ref change, or path-state change was introduced.

## 32. Explicit confirmations

```text
ES_REPOSITORY_ROOT_AUTHENTICATED
CURRENT_WORKTREE_CANDIDATE_PRESERVED
ALL_MODIFIED_AND_UNTRACKED_PATHS_CLASSIFIED
CURRENT_AGENTS_MD_READ
CURRENT_PLANS_MD_READ
FINAL_SEVEN_FILE_REPAIR_AUDITED
RESOLVED_PLAN_AUTHORITY_BOUNDARY_AUDITED
EXPECTED_TREE_READDIR_INVENTORY_RECONSTRUCTED
CUSTODY_CLAIM_INVENTORY_RECONSTRUCTED
CUSTODY_MATERIALIZATION_INVENTORY_RECONSTRUCTED
SYNCHRONIZED_STATE_INVENTORY_RECONSTRUCTED
REJECTED_A3_TOPOLOGY_RECONSTRUCTED
RETIRED_OPERATOR_ALIAS_INVENTORY_RECONSTRUCTED
DOCS_SOURCE_AND_TESTS_CROSSCHECKED
FILESYSTEM_AND_DESCRIPTOR_CUSTODY_AUDITED
CLEANUP_AND_FAILURE_PATHS_AUDITED
AUTHORITY_SECURITY_AND_PRIVACY_AUDITED
MACOS_TEMP_ROOT_POSTURE_ADJUDICATED
NO_EXTERNAL_SCHEMA_PACKAGE_INTEGRATION
NO_HIDDEN_RUN_TRUTH
NO_UNRESOLVED_AUTHORITY_WIDENING
MODIFIED_GO_FILES_FORMATTED
GIT_DIFF_CHECK_PASSED
FOCUSED_GUARDRAIL_TESTS_EXECUTED
DEFAULT_HOST_TEST_POSTURE_RETAINED
PHYSICAL_ROOT_TEST_SEQUENCE_EXECUTED
RACE_TEST_POSTURE_RETAINED
FULL_SUITE_DISPOSITION_RETAINED
EVERY_COMMIT_BLOCKING_FINDING_HAS_REPAIR_OWNER
COMMIT_BOUNDARY_ADJUDICATED
EXACT_STAGE_SET_PROPOSED
EXACT_COMMIT_SUBJECTS_PROPOSED
REPOSITORY_MUTATION_NOT_PERFORMED
NO_STAGING
NO_COMMIT
NO_PUSH
CLOSING_BRANCH_HEAD_AND_TREE_MATCHED
CLOSING_WORKTREE_SET_MATCHED
PROTECTED_PATH_STATE_PRESERVED
NO_TASK_REPOSITORY_ARTIFACT_RETAINED
NO_DEPENDENCY_INSTALLATION
NO_NETWORK_CONTACT
NO_SUBAGENTS_CREATED
```
