BOUNDED PHYSICAL-ROOT REBINDING AND TERMINAL CLOSURE —
VALIDATION-CUSTODY V3 TARGET-AUDIT HARNESS PACKAGE

This task creates one fresh, immutable, self-contained target-audit harness
package by explicitly rebinding its acceptance-bearing physical package-root
reference to the new final package root.

It is a bounded physical-path and transitive-identity repair.

It is not:

- a target-audit semantic redesign;
- a portable-package redesign;
- a target repair;
- an accepted-bootstrap repair;
- a target audit;
- runtime validation;
- a repository or product task.

Do not modify, resume, clean, finish, or reseal any prior package root.

Do not silently replace any absolute path.
Do not parameterize or generalize package-root semantics beyond what is needed
for this one immutable successor root.
Do not change executable control flow.
Do not change target-audit acceptance criteria.
Do not execute the real target audit.
Do not execute Plan V3 or Plan V4.
Do not rerun repository or product validation.
Do not run Git.
Do not use the network.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_READY
TARGET_AUDIT_HARNESS_PACKAGE_REBIND_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT SEMANTIC SOURCE PACKAGE
──────────────────────────────────────────────────────────────────────────────

FAILED_UNSEALED_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli

Expected identity:

- device/inode:
  16777234 / 180115518
- mode:
  0700
- retained task verdict:
  PREFLIGHT_PROVENANCE_MISMATCH

Preserve this root unchanged as historical, nonauthoritative evidence.

Authenticate at minimum:

opening/target-audit-harness-freeze-v1.json

- size:
  12063
- SHA-256:
  d37288c835598be83841c58163847817da333c08c38df8cd6f3edd2584f98e1a

validation/frozen-harness-requalification-v1.json
validation/support-binding-mutation-matrix-v1.json
validation/support-binding-live-replay-v1.json
validation/finalizer-mutation-matrix-v2.json
validation/independent-finalizer-validator-v1.json
validation/retained-failed-audit-replay-v1.json
qualification/direct-finalizer-process-custody-v1.json
validation/exact-semantic-delta-v1.json

Authenticate the exact current membership and classify:

source/__pycache__
source/__pycache__/*.pyc

as forbidden incidental artifacts.

Do not execute or import those bytecode files.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING BLOCKED CLOSURE ATTEMPT
──────────────────────────────────────────────────────────────────────────────

BLOCKED_CLOSURE_ATTEMPT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-qko804d4

Expected identity:

- device/inode:
  16777234 / 180242385
- mode:
  0700
- verdict:
  TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_BLOCKED

Authenticate and inspect at minimum:

analysis/export-root-independence-v1.json
analysis/failed-package-membership-ledger-v1.json
analysis/freeze-and-evidence-crosswalk-v1.json
analysis/bytecode-cache-adjudication-v1.json
lineage/failed-unsealed-package-binding-v1.json
opening/current-package-authority-v1.json
opening/target-audit-harness-package-closure-v1.json
closing/failed-package-closing-equality-v1.json
closeout/final-package-closure-report-v1.md
closeout/explicit-confirmations-v1.json

The governing blocker is exactly:

contract/target-audit-plan-v2.json
JSON pointer:
/payload/frozen_source_identity/package_path

Historical value:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/source/target_audit_payload_v2.py

The field is acceptance-bearing and identifies the package source used for
Carrier 0003 materialization.

No other blocker is currently authorized.

──────────────────────────────────────────────────────────────────────────────
3. EXACT CURRENT EXPORT IDENTITIES
──────────────────────────────────────────────────────────────────────────────

The current seven semantic exports are:

source/target_audit_payload_v2.py

- size:
  203704
- SHA-256:
  3528fc8b06665c4a1ec18a12b6ae0e0bbd0c1496767420139627d8064af7ee42

contract/target-audit-plan-v2.json

- size:
  8544
- SHA-256:
  5ea0060b8f26b9ced609075778ad8e678abe2d2bf471a1067f232b49a4640e00

contract/support-root-binding-policy-v1.json

- size:
  4051
- SHA-256:
  0cc44dc948227c32c1a34d9cf6518ae07caa1b3eaa46a69482cca6e00921a87d

contract/finalizer-lifecycle-v1.json

- size:
  2261
- SHA-256:
  73f30bed23431cc4b49234433ebebdaf9042faa2af26015ff1fd830936f5fef8

contract/finalizer-process-custody-v1.json

- size:
  1068
- SHA-256:
  b9e3ccd4754faf956c42eaa6fd8199feda76ee8a5f3d4794acd7c1949a037bd7

templates/carrier-0003-request-template-v2.json

- size:
  2941
- SHA-256:
  89bb7eb2a3b54f0583a91056349ebf3c97ebafc9535239f4386a6a003f5e20e7

templates/finalizer-invocation-contract-template-v1.json

- size:
  3557
- SHA-256:
  569509be03ecf3e7380bba0be63df5ccd80ccb44a223675c540525d3b1690dab

The source, policies, and templates remain authoritative only as qualified
historical inputs until a new package closes.

──────────────────────────────────────────────────────────────────────────────
4. FRESH FINAL PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate the final package root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-target-audit-harness-package-rebound-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

This exact physical path is the final immutable package root.

Do not construct an intermediate package and later move or rename it.

Retain before semantic work:

opening/bootstrap-start.json

including:

- fresh-root device/inode/mode;
- allocation method and umask;
- failed-package identity;
- blocked-closure-attempt identity;
- exact seven input export identities;
- repair authority:
  physical-package-root-rebinding-only;
- executable control-flow changes authorized:
  false;
- substantive target-audit semantic changes authorized:
  false;
- real target audit executed:
  false;
- runtime validation rerun:
  false.

Create directories lazily. Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
5. COMPLETE EXPORT DEPENDENCY GRAPH
──────────────────────────────────────────────────────────────────────────────

Before writing any export, parse all seven input exports strictly.

Retain:

analysis/export-dependency-graph-v1.json

Enumerate every occurrence of:

- the failed-package absolute root;
- the historical payload package path;
- the plan path;
- the plan size or SHA-256;
- the payload path;
- the payload size or SHA-256;
- any current-export path, size, or digest;
- any field consuming the changed plan.

For every occurrence record:

- source export;
- JSON pointer or source line;
- role;
- value;
- direct or transitive dependency;
- acceptance-bearing status;
- runtime consumer;
- required action:
  unchanged,
  physical-root rebind,
  transitive identity regeneration,
  or historical evidence only.

Require a complete directed dependency graph rooted at:

contract/target-audit-plan-v2.json
#/payload/frozen_source_identity/package_path

Do not change a field unless it is reachable from that root-binding change or
is generated package metadata.

If an executable branch, condition, algorithm, acceptance predicate, authority
flag, or substantive operand must change, stop with:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_BLOCKED

──────────────────────────────────────────────────────────────────────────────
6. EXPLICIT PHYSICAL-ROOT REBINDING CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/package-root-rebinding-v1.json

This is package metadata, not an additional target-audit semantic export.

It must bind:

- predecessor failed-package root;
- predecessor plan identity;
- predecessor pointer:
  /payload/frozen_source_identity/package_path
- predecessor value;
- fresh final package root;
- successor payload absolute path:
  ${PACKAGE_ROOT}/source/target_audit_payload_v2.py
- successor pointer;
- source payload identity;
- exact directly changed pointer set;
- exact transitively regenerated field set;
- classification:
  physical-package-root-rebinding-only;
- semantic effect:
  none;
- executable control-flow effect:
  none;
- target-audit acceptance-rule effect:
  none;
- package immobility:
  required after seal;
- later root rebinding:
  forbidden without a new package and new qualification.

The final plan remains physically root-bound to this exact package.

Do not introduce:

- `<PACKAGE_ROOT>`;
- `${PACKAGE_ROOT}`;
- a movable-package placeholder;
- latest/prefix lookup;
- runtime root discovery;
- silent fallback;
- path scoring;
- symlink indirection.

This task creates a single immutable root-bound successor, not a portable
package abstraction.

──────────────────────────────────────────────────────────────────────────────
7. AUTHORIZED EXPORT CHANGES
──────────────────────────────────────────────────────────────────────────────

The required direct change is:

contract/target-audit-plan-v2.json
#/payload/frozen_source_identity/package_path

Old value:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/source/target_audit_payload_v2.py

New value:

${EXACT_FRESH_PACKAGE_ROOT}/source/target_audit_payload_v2.py

where `${EXACT_FRESH_PACKAGE_ROOT}` is replaced with the literal emitted final
package path before bytes are frozen.

This is not a placeholder in the final file.

Regenerate only acceptance-bearing transitive path, size, and SHA-256 fields
proven by the dependency graph.

Rules:

- If `source/target_audit_payload_v2.py` contains no dependent frozen-plan
  identity, preserve it byte-for-byte.
- If a contract, policy, or template contains no transitive dependency,
  preserve it byte-for-byte.
- A changed JSON field must be either:
  - the exact physical package path; or
  - a size/SHA/path identity that transitively binds a changed export.
- No schema or field-map change is authorized.
- No filename or schema-version change is authorized unless the existing schema
  explicitly forbids a new physical instance at a new root.

If a schema-version change or executable source edit becomes necessary, stop
with:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_BLOCKED

Do not widen the tranche.

──────────────────────────────────────────────────────────────────────────────
8. EXACT SEMANTIC AND BYTE DELTA
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/export-rebinding-delta-v1.json

For every changed export record:

- old path;
- new path;
- old size/SHA-256;
- new size/SHA-256;
- every changed JSON pointer or source range;
- owning direct or transitive dependency;
- before value;
- after value;
- semantic effect:
  none;
- executable control-flow change:
  false;
- acceptance-rule change:
  false.

Require:

- unchanged executable AST when source bytes are expected unchanged;
- exact unchanged JSON projections after replacing only the declared physical
  root and transitive identities;
- zero unrelated field drift.

Retain the exact original and successor bytes for every changed export in
audit-owned evidence.

──────────────────────────────────────────────────────────────────────────────
9. ROOT-REBINDING MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a literal audit-owned matrix covering at minimum:

1. Exact predecessor plan and predecessor root.
2. Exact successor plan and final package root.
3. Successor plan still pointing to predecessor root.
4. Successor plan pointing to a nonexistent root.
5. Successor plan pointing to the blocked closure attempt.
6. Wrong payload relative path.
7. Payload absent.
8. Payload size mismatch.
9. Payload SHA-256 mismatch.
10. Payload mode mismatch.
11. Payload hardlink.
12. Payload symlink.
13. Package root symlink.
14. Package root alias.
15. Parent traversal in package path.
16. Extra direct changed pointer.
17. Missing direct changed pointer.
18. Stale transitive plan digest.
19. Stale carrier-template plan identity.
20. Stale finalizer-template identity.
21. Changed executable source with unchanged declared identity.
22. Root moved after package seal.
23. Latest/prefix selection attempt.
24. Filename-score selection attempt.
25. Runtime fallback to predecessor package.
26. Unknown root-binding field.
27. Duplicate current plan.
28. Historical plan marked current.
29. Rebinding contract missing.
30. Rebinding contract semantic effect not `none`.

Require:

- exact literal names;
- unique names;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/package-root-rebinding-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
10. TWO-ROOT DETERMINISTIC REBINDING CAUSAL
──────────────────────────────────────────────────────────────────────────────

Use two audit-owned temporary candidate package roots.

For each:

1. Copy exact unchanged exports.
2. Rebind the exact physical package path to that candidate root.
3. Regenerate only proven transitive identities.
4. Produce the candidate plan and templates.
5. Verify payload resolution no-follow.
6. Verify all export identities.
7. Produce a normalized projection replacing only each candidate root with
   `<NORMALIZED_PACKAGE_ROOT>`.

Require:

- raw root-bound bytes differ only where expected;
- normalized export bytes are byte-identical;
- source bytes are byte-identical;
- schemas, field maps, algorithms, and acceptance rules are identical;
- no stale predecessor path survives in current exports;
- no candidate-root path survives after normalization.

Retain:

validation/two-root-rebinding-determinism-v1.json

Inventory and remove both temporary roots, with two fresh ENOENT observations
per root.

The final package root itself is not removed.

──────────────────────────────────────────────────────────────────────────────
11. CURRENT CONSUMER-FACING EXPORT SET
──────────────────────────────────────────────────────────────────────────────

Retain:

opening/current-export-registry-v1.json

Require exactly one current instance of each of the seven semantic export
roles:

- target-audit payload;
- target-audit plan;
- support-root binding policy;
- finalizer lifecycle;
- finalizer process custody;
- Carrier 0003 request template;
- finalizer invocation-contract template.

For each bind:

- current path;
- schema/role;
- size;
- SHA-256;
- mode;
- link count;
- producer;
- consumers;
- root-binding status;
- current:
  true.

Historical failed-package exports are externally bound by identity and are not
copied as duplicate current exports.

Exactly one current plan may exist.

──────────────────────────────────────────────────────────────────────────────
12. FRESH QUALIFICATION — NO RETAINED PASS PROMOTION
──────────────────────────────────────────────────────────────────────────────

Because an acceptance-bearing export changed, generate fresh current
qualification evidence.

Do not promote the failed package’s prior pass records as current qualification.

They may be used only as historical comparison inputs.

Freshly run, against the successor exports:

- support-root binding mutation matrix;
- support-root live replay;
- finalizer mutation matrix;
- independent finalizer validator;
- successful synthetic finalization causal;
- required failure finalization causals;
- direct-finalizer process-custody qualification;
- retained failed-audit replay;
- payload compile-only check;
- static source and call-graph gates;
- AST postseal analysis;
- bytecode/exception-table postseal analysis.

Do not run the real target audit.

Do not execute Plan V3 or Plan V4.

Do not import the payload. Compilation must use pinned Python `-I -S -B` and
must not generate bytecode.

Every Python child must use:

PYTHONDONTWRITEBYTECODE=1

and a private audit-owned:

PYTHONPYCACHEPREFIX

that is inventoried and removed before package closure.

No Python process may use the package root as a bytecode-cache destination.

──────────────────────────────────────────────────────────────────────────────
13. SYNTHETIC MATERIALIZATION INTEGRATION
──────────────────────────────────────────────────────────────────────────────

Run two synthetic, audit-owned Carrier 0003 materialization causals using the
final package exports.

Do not use the real target.

For each:

- resolve the package payload through the successor plan’s exact absolute path;
- open no-follow;
- verify root identity and payload identity;
- copy the payload into a synthetic fresh audit root;
- construct the Carrier 0003 request from the current template;
- bind the current plan identity;
- bind the current payload identity;
- verify no predecessor or blocked-attempt root appears;
- do not execute substantive target adjudication.

Require both causals to produce normalized-identical requests and copied payload
bytes.

Retain:

validation/two-carrier-0003-materializations-v1.json

Inventory and remove synthetic roots with double ENOENT observations.

──────────────────────────────────────────────────────────────────────────────
14. SYNTHETIC FINALIZER QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Using synthetic fixture roots only, rerun:

- one successful finalization causal;
- unrelated empty-directory failure;
- manifest-B write failure;
- independent-generator mismatch;
- failure after preseal-ready;
- missing invocation-contract failure;
- stale source-identity failure;
- write-after-seal rejection.

Require exact current plan and template identities in all fixture inputs.

Retain complete process custody:

- argv;
- cwd;
- explicit environment;
- PID;
- streams;
- exit/signal;
- duration;
- reaping;
- descriptor closure;
- paths written;
- fixture inventory;
- cleanup and two ENOENT observations.

No fixture may survive.

──────────────────────────────────────────────────────────────────────────────
15. QUALIFICATION RESULT
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/current-qualification-result-v1.json

Bind:

- exact seven current export identities;
- package-root rebind contract;
- direct changed-pointer set;
- transitive identity set;
- rebinding matrix;
- two-root determinism;
- support-binding qualification;
- finalizer qualification;
- synthetic materializations;
- synthetic finalization causals;
- compilation/static/postseal checks;
- zero cache/bytecode posture;
- target audit executed:
  false;
- semantic change:
  false;
- success;
- first blocker:
  null on success.

Do not use the failed package’s preterminal confirmation record as authority.

──────────────────────────────────────────────────────────────────────────────
16. FAILED PACKAGE AND BLOCKED ATTEMPT LINEAGE
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/package-root-rebinding-lineage-v1.json

Bind:

- failed unsealed package identity;
- failed package freeze identity;
- failed package seven exports;
- blocked closure-attempt identity;
- exact root-independence blocker;
- successor package identity;
- exact changed export set;
- exact unchanged export set;
- semantic effect:
  none;
- historical packages:
  noncurrent,
  nonauthoritative,
  ineligible for runtime or acceptance use.

Do not copy:

- failed preterminal verdict;
- stale temporal inventory;
- failed closure records as current authority;
- `__pycache__`;
- `.pyc`.

Historical identities may be retained only in lineage records.

──────────────────────────────────────────────────────────────────────────────
17. NO ROOT-INDEPENDENCE CLAIM
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/package-immobility-and-root-authority-v1.json

Explicitly state:

- this package is bound to its exact final physical root;
- moving or copying it invalidates the target-audit plan’s package-path binding;
- package relocation requires a new explicit rebinding package and new
  qualification;
- no runtime scanning, discovery, fallback, or rebinding is supported;
- failed-package roots have no runtime authority;
- the final plan is the sole authoritative writer of the frozen payload package
  path.

Do not claim portability or root independence.

──────────────────────────────────────────────────────────────────────────────
18. CACHE AND BYTECODE DISCIPLINE
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/cache-and-bytecode-posture-v1.json

Require:

- no `__pycache__` in the final package;
- no `.pyc`;
- no `.pyo`;
- no bytecode-cache directory;
- no copied historical cache;
- all qualification cache roots external and removed;
- all package-building Python invocations used `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- package Python files were not imported;
- compile-only operations did not write cache files.

A cache artifact in the final package is terminal.

──────────────────────────────────────────────────────────────────────────────
19. EXACT SEMANTIC TOUCHED SET
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/semantic-touched-path-freeze-v1.json

Classify each of the seven exports as:

- byte-identical;
- direct physical-root rebind;
- transitive identity regeneration.

Require:

- executable source control flow unchanged;
- target-audit plan field map unchanged;
- policy field maps unchanged;
- finalizer lifecycle unchanged;
- process-custody semantics unchanged;
- template field maps unchanged;
- acceptance rules unchanged.

If any other semantic path or field changes, stop with:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_BLOCKED

──────────────────────────────────────────────────────────────────────────────
20. FREEZE CURRENT PACKAGE
──────────────────────────────────────────────────────────────────────────────

After qualification passes, retain:

opening/target-audit-harness-package-freeze-v2.json

Bind:

- final package root device/inode/mode;
- exact seven export identities;
- direct root-rebinding identity;
- transitive identity ledger;
- current export registry;
- qualification result;
- lineage;
- cache posture;
- exact copy/write chronology;
- semantic changes:
  physical-root-rebinding-only;
- later modification permitted:
  false;
- real target audit executed:
  false.

Reopen every frozen export no-follow and verify exact identity.

No export may change afterward.

──────────────────────────────────────────────────────────────────────────────
21. FROZEN PACKAGE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen exports:

1. Verify all identities.
2. Rerun the root-rebinding matrix.
3. Rerun two-root normalized comparison in-memory without creating another
   current package.
4. Rerun support-binding qualification.
5. Rerun finalizer matrix.
6. Rerun independent validator.
7. Rerun synthetic materialization checks.
8. Rerun static and postseal checks.
9. Verify no stale predecessor path.
10. Verify package-root immobility contract.

Require equality with pre-freeze results under documented root normalization.

Retain:

validation/frozen-package-requalification-v2.json

Any mismatch requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit frozen exports.

──────────────────────────────────────────────────────────────────────────────
22. NO REAL TARGET AUDIT
──────────────────────────────────────────────────────────────────────────────

Do not:

- execute Carrier 0003 against the real target;
- run the real direct finalizer;
- adjudicate V3 target semantics;
- execute Plan commands;
- run repository tests;
- invoke product code;
- produce a target ACCEPT/BLOCK/REJECT verdict.

This task ends after package qualification, freeze, and terminal closure.

──────────────────────────────────────────────────────────────────────────────
23. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality for:

- failed unsealed package;
- blocked closure attempt;
- reconciliation root;
- accepted bootstrap and accepted bootstrap audit, if opened;
- target and V2 audit roots, if opened;
- qualified launcher and import reconciliation, if opened;
- pinned Python.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
24. FINAL REPORT — INLINE AND RETAINED
──────────────────────────────────────────────────────────────────────────────

Before temporal inventory generation, finalize:

closeout/final-package-report-v2.md
closeout/explicit-confirmations-v2.json

Return the complete report inline. Do not make the retained report the only
substantive response.

The report must clearly distinguish:

- direct physical-root rebinding;
- transitive identity regeneration;
- unchanged semantic exports;
- fresh qualification;
- historical failed-package evidence;
- current package authority;
- no target verdict.

──────────────────────────────────────────────────────────────────────────────
25. TEMPORAL FINAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final, generate:

closeout/temporal-final-inventory-v2.json

Require:

- root represented;
- all current directories represented;
- all current nonmanifest regular files represented;
- exact declared exclusions:
  - temporal inventory itself;
  - future manifest A;
  - future manifest B;
- reserved future `manifest/` directory explicitly declared;
- stable grammar;
- no symlink;
- no special object;
- no multiply linked file;
- all directories mode 0700;
- all regular files mode 0600;
- no empty retained directory except reserved `manifest/` before manifests;
- no cache or bytecode.

Reopen and reverify it before manifest generation.

──────────────────────────────────────────────────────────────────────────────
26. TERMINAL MANIFEST CLOSURE
──────────────────────────────────────────────────────────────────────────────

After temporal inventory verification:

1. Ensure exact reserved `manifest/` directory exists, mode 0700.
2. Independently generate manifest A.
3. Independently generate manifest B.
4. Require generated bytes byte-identical.
5. Exclusively create A, write/fsync/close.
6. Exclusively create B, write/fsync/close.
7. Fsync manifest directory.
8. Reopen both no-follow.
9. Verify size and SHA-256.
10. Require each equals its generated bytes.
11. Require A equals B.
12. Independently reproject the complete root.
13. Require reprojection equals A and B.
14. Require no empty directory.
15. Require no cache or bytecode.
16. Require no symlink, special object, or multiply linked file.
17. Require all modes 0700/0600.

After manifest closure, perform no filesystem write.

The task response may read the sealed package and report the result; no new
verdict file is written after closure.

──────────────────────────────────────────────────────────────────────────────
27. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_READY

only when:

- every supplied root authenticates and closes;
- exact historical exports authenticate;
- complete dependency graph exists;
- direct changed pointer is exact;
- every transitive identity is exact;
- no executable control-flow change occurred;
- no acceptance-rule change occurred;
- no stale predecessor path remains in current exports;
- one current plan exists;
- rebinding matrix passes;
- two-root deterministic normalization passes;
- fresh qualification passes;
- synthetic materializations pass;
- synthetic finalizer causals pass;
- no cache or pyc is retained;
- package is frozen at the final physical root;
- frozen requalification passes;
- temporal inventory verifies;
- terminal manifests exist and match;
- terminal reprojection passes;
- no write follows closure;
- no real target audit ran.

Return:

TARGET_AUDIT_HARNESS_PACKAGE_REBIND_BLOCKED

when:

- executable control flow must change;
- a schema or field map must change;
- more than physical path and transitive identities must change;
- a stale root dependency cannot be removed without redesign;
- current qualification fails;
- a target or bootstrap defect is discovered.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- closing inequality;
- source-authority mismatch;
- unauthorized export drift;
- frozen-package mismatch;
- final package closure failure;
- any write after terminal manifest closure.

──────────────────────────────────────────────────────────────────────────────
28. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Final package-root identity
3. Failed-package identity and closing equality
4. Blocked closure-attempt identity
5. Complete export dependency graph
6. Exact predecessor export identities
7. Exact successor export identities
8. Direct changed pointer
9. Transitive regenerated fields
10. Exact export byte/semantic delta
11. Package-root rebinding contract
12. Rebinding mutation matrix
13. Two-root deterministic rebinding result
14. Current export registry
15. Fresh support-binding qualification
16. Fresh finalizer qualification
17. Synthetic Carrier 0003 materializations
18. Synthetic finalizer causals
19. Current qualification-result identity
20. Failed-package lineage
21. Package immobility/root-authority result
22. Cache and bytecode posture
23. Semantic touched-path freeze
24. Frozen package identity
25. Freeze-record identity
26. Frozen-package requalification
27. Supplied-root closing equality
28. Temporal-final-inventory identity
29. Manifest A identity
30. Manifest B identity
31. Independent terminal reprojection
32. Terminal membership and mode closure
33. No-write-after-closure result
34. Confirmation real target audit did not run
35. Remaining uncertainty and nonclaims
36. Explicit confirmations

Required confirmations:

FAILED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLOSURE_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
HISTORICAL_EXPORT_IDENTITIES_AUTHENTICATED
COMPLETE_EXPORT_DEPENDENCY_GRAPH_PRODUCED
DIRECT_PACKAGE_ROOT_POINTER_REBOUND_EXPLICITLY
TRANSITIVE_IDENTITY_FIELDS_REGENERATED_EXACTLY
NO_SILENT_REBINDING
EXECUTABLE_SOURCE_CONTROL_FLOW_UNCHANGED
TARGET_AUDIT_ACCEPTANCE_RULES_UNCHANGED
SCHEMA_FIELD_MAPS_UNCHANGED
EXACTLY_ONE_CURRENT_TARGET_AUDIT_PLAN
STALE_FAILED_PACKAGE_PATH_ABSENT_FROM_CURRENT_EXPORTS
PACKAGE_ROOT_REBINDING_MATRIX_PASSED
TWO_ROOT_REBINDING_DETERMINISM_PASSED
FRESH_SUPPORT_BINDING_QUALIFICATION_PASSED
FRESH_FINALIZER_QUALIFICATION_PASSED
TWO_SYNTHETIC_CARRIER_0003_MATERIALIZATIONS_PASSED
SYNTHETIC_FINALIZER_CAUSALS_PASSED
CURRENT_QUALIFICATION_RESULT_PASSED
FAILED_PACKAGES_BOUND_AS_HISTORICAL_EVIDENCE
PACKAGE_PHYSICALLY_ROOT_BOUND
PACKAGE_RELOCATION_UNSUPPORTED
NO_RUNTIME_ROOT_DISCOVERY
NO_ROOT_FALLBACK
NO_LATEST_OR_SCORE_SELECTION
NO_BYTECODE_CACHE_RETAINED
NO_PYC_RETAINED
EXACT_SEMANTIC_TOUCHED_SET_FROZEN
FINAL_PACKAGE_FROZEN
FINAL_PACKAGE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_PACKAGE_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
TEMPORAL_FINAL_INVENTORY_CREATED
TEMPORAL_FINAL_INVENTORY_VERIFIED
TERMINAL_MANIFEST_A_CREATED
TERMINAL_MANIFEST_B_CREATED
TERMINAL_MANIFESTS_BYTE_IDENTICAL
INDEPENDENT_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
REAL_TARGET_AUDIT_NOT_EXECUTED
RUNTIME_VALIDATION_NOT_RERUN
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
