## Engineering assessment

This is a **pre-source closure-verifier defect**, not evidence that the reconciliation capsule drifted and not a defect in the sealed implementation package.

The decisive failure was semantic translation inside the new verifier:

- the manifest’s `regular_file` kind was compared with an internal `regular` label;
- manifest `link_count` was compared with internal `nlink`;
- directory `size` was omitted from the internal projection;
- the verifier also needs to preserve the manifest’s exact UID, GID, and modification-time semantics. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The supplied reconciliation root’s fixed identity passed, its temporal inventory and both manifests opened successfully, A/B were byte-identical, and the temporal record had the expected 53 rows. Nothing in this result establishes root mutation. :chatgpt-content-reference{index="2"}

No clean-harness source was created, no final source registry closed, compilation never started, and **zero of three source attempts were consumed**. The implementation package and the other current governing roots were not opened or adjudicated. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

The D01–D14 results were only authoring preflights; operative matrices, process qualification, synthetic verdict lanes, compatibility replay, rehearsals, independent candidate validators, source freeze, and terminal package closure were never reached. :chatgpt-content-reference{index="5"}

The failure closeout’s automatic “input mismatch” classification is also explicitly superseded by the postmortem: the blocker was the verifier’s grammar mapping. :chatgpt-content-reference{index="6"}

### Progression decision

Do **not** attempt the full clean-harness implementation again yet.

The critical path is now a small, separately qualified **current-authority closure-verifier package**. It must freeze exact, per-root manifest and temporal grammars; reproject the current roots without semantic renaming; and independently validate those projections. Once that verifier is sealed, it becomes a fixed current tool for the later clean-harness implementation tranche.

This avoids spending another full clean-generation run on input-authentication code that has not itself been qualified.

```text
IMPLEMENT, QUALIFY, FREEZE, AND TERMINALLY CLOSE A
CURRENT-AUTHORITY FIXED-INPUT CLOSURE VERIFIER

Objective

Implement a small source-external verifier package whose sole responsibility is
to authenticate the current fixed inputs required by the future clean
independent-audit harness.

The verifier must support the exact temporal-inventory, terminal-manifest, and
failure-root grammars of the current authoritative roots.

It must not implement the independent-audit harness.

It must not adjudicate the Generation-2 reconstruction-parent implementation.

It must not execute the implementation production source.

It must not run matrices, rehearsals, or package-verdict logic belonging to the
future full audit.

It must not open any retired or failed audit-harness root.

Implement, qualify, freeze, requalify, and terminally close this verifier
package. A later tranche will use the frozen verifier as a current fixed tool
while implementing the clean source-external audit harness.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not modify a supplied root.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned implementation and qualification process in one
fresh private root.

At most two complete verifier-source attempts are permitted.

The preceding new-generation harness run consumed zero source attempts, but its
failed root is not resumable and is not a source base.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTATION_BLOCKED

CURRENT_AUTHORITY_CLOSURE_VERIFIER_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FIXED CURRENT ROOT SET
──────────────────────────────────────────────────────────────────────────────

Open exactly these eight supplied roots:

A. TERMINAL_FINDINGS_RECONCILIATION

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected root identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  181133295
- mode:
  0600
- link count:
  1
- size:
  19496
- SHA-256:
  fe18b553b3bb18e8bf1b42c75e78baef641ccd8c4257c58653084120049482cf

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  181133296
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  181133297
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920

B. SEALED_IMPLEMENTATION_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected root identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

C. CURRENT_GEN2_SUCCESSOR

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected root identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Expected current registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

D. AUTHORITATIVE_CONTRACT_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected root identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

E. CURRENT_SCHEMA_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected root identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

F. SCHEMA_RECONCILIATION_CAPSULE

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected root identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

G. CURRENT_VALIDATION_SPECIFICATION_PACKAGE

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected root identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Expected closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

H. CURRENT_ATTEMPT_2_FAILURE_SPECIMEN

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected root identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Expected failure-outcome identity:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

This root is an immutable failure specimen, not a successfully sealed package.

Authenticate its exact failure-outcome path through the sealed implementation
package’s current Attempt-2 binding.

Do not infer the path by basename or filesystem search.

──────────────────────────────────────────────────────────────────────────────
2. EXCLUDED ROOTS
──────────────────────────────────────────────────────────────────────────────

Do not open any retired or failed audit-harness root, including:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-independent-audit-fresh-qAGO1c0a

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-4xuh1lon

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b

/Users/ds/Downloads/ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-dz2xlcfd

/Users/ds/Downloads/ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-current-authority-808ounoj

Retain:

opening/excluded-root-registry-v1.json

Every row must say:

- fixed input:
  false;
- opened:
  false;
- inventoried:
  false;
- source read:
  false;
- authority:
  none.

──────────────────────────────────────────────────────────────────────────────
3. FRESH VERIFIER ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` with:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-current-authority-closure-verifier-

Immediately emit:

VERIFIER_ROOT=<absolute-path>

Before supplied-root inspection retain:

opening/bootstrap-start.json
opening/closure-verifier-authority-v1.json
opening/fixed-root-registry-v1.json
opening/excluded-root-registry-v1.json
opening/process-execution-policy-v1.json

Authority is limited to:

- no-follow supplied-root inventory;
- strict closure-record parsing;
- exact grammar extraction;
- manifest and temporal reprojection;
- immutable failure-specimen authentication;
- mutation qualification;
- source freeze and package closure.

Nonauthority includes:

- package acceptance or rejection;
- audit-harness implementation;
- implementation repair;
- implementation-source execution;
- schema-subject construction;
- product/runtime/target/repository activity;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
4. PER-ROOT CLOSURE-GRAMMAR REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before verifier source creation retain:

contract/current-root-closure-grammar-registry-v1.json

Create one exact row for each supplied-root role.

For every successfully sealed root bind:

- role;
- root path;
- root identity;
- temporal path;
- temporal schema;
- temporal entries pointer;
- temporal path field;
- temporal exclusions;
- future-manifest-directory treatment;
- manifest A path;
- manifest B path;
- manifest schema;
- manifest entries pointer;
- manifest path field;
- root represented:
  true or false;
- root binding location;
- manifest self-exclusions;
- exact serialization;
- trailing-newline rule;
- top-level required fields;
- exact field set for each entry kind;
- exact kind vocabulary;
- field types;
- mode encoding;
- UID semantics;
- GID semantics;
- device semantics;
- inode semantics;
- link-count semantics;
- size semantics for directories;
- size semantics for regular files;
- modification-time semantics;
- regular-file hash semantics;
- unknown-field rule;
- duplicate-path rule;
- ordering rule;
- terminal topology rules.

For the terminal reconciliation capsule, the registry must preserve its
declared vocabulary exactly, including:

- kind value:
  `regular_file`, not `regular`;
- field:
  `link_count`, not `nlink`;
- directory `size`;
- exact UID and GID fields;
- exact modification-time field and unit;
- all other fields occurring in its authenticated grammar.

No acceptance comparison may translate a manifest field into a differently
named internal acceptance field.

Operating-system observations may use `stat` concepts internally only when the
grammar registry explicitly maps the OS observation to the manifest’s exact
field name.

Retain both:

- raw filesystem observation;
- manifest-vocabulary projection.

The latter is acceptance-bearing.

For the Attempt-2 failure specimen bind a separate grammar:

- immutable failure root;
- exact root identity;
- exact failure-outcome path and identity;
- complete opening inventory;
- complete closing inventory;
- no success temporal or terminal-manifest claim;
- supplied-root equality required.

Unknown schema or grammar fails closed.

No generic “canonical inventory” may silently replace a root’s owned grammar.

──────────────────────────────────────────────────────────────────────────────
5. GRAMMAR EXTRACTION AND FREEZE
──────────────────────────────────────────────────────────────────────────────

Use source-external strict parsers to extract each grammar from its exact
authenticated temporal and manifest records.

Do not derive grammar from:

- whichever fields happen to occur first;
- a recursive list search;
- a union of all row fields without kind ownership;
- filenames;
- another root’s grammar;
- a hard-coded generic inventory model.

Require:

- strict JSON with duplicate-key rejection;
- exact top-level schema;
- exact entries location;
- exact root policy;
- exact exclusions;
- consistent field sets within each entry kind;
- no contradictory row vocabulary;
- A/B grammar equality;
- A/B byte equality before accepting their grammar.

Retain:

analysis/current-root-closure-grammar-extraction-v1.json
contract/current-root-closure-grammar-registry-v1.json

Run an independent documentary validator against the registry before writing
verifier source.

──────────────────────────────────────────────────────────────────────────────
6. VERIFIER SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Define clean source roles for:

- finite verifier parent;
- child recorder;
- strict JSON parser;
- no-follow inventory;
- grammar interpreter;
- raw filesystem observer;
- manifest-vocabulary projector A;
- independently authored projector B;
- temporal verifier;
- terminal-manifest verifier;
- failure-specimen verifier;
- mutation runner;
- independent end-to-end verifier;
- supplied-root equality;
- fixture cleanup;
- terminal package lifecycle;
- failure closeout.

Production projector A and independent projector B must not import one another.

Independent validation must not import production projector, production
grammar interpreter, or production expected-result maps.

Retain planned and final source registries.

──────────────────────────────────────────────────────────────────────────────
7. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete verifier-source attempts.

An attempt begins only when all final source registries close and compilation
starts.

Any source modification after compilation begins creates a new attempt.

If Attempt 2 fails, stop.

Do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
8. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile all verifier sources with pinned Python using `-I -S -B`.

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- filesystem-operation crosswalk;
- grammar-field crosswalk;
- process-launch crosswalk;
- terminal-operation crosswalk.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- every child through one recorder;
- no shell;
- no PATH executable lookup;
- no Git/VCS;
- no network;
- no broad Downloads scan;
- no excluded-root access;
- no supplied-root mutation;
- no generic manifest-field alias;
- no missing-field coercion;
- no generic truthiness;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
9. CLOSURE-GRAMMAR MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 90 uniquely named cases.

Include:

A. Entry-kind mutations

- exact `regular_file`;
- stale `regular`;
- wrong `file`;
- directory mislabeled as regular file;
- regular file mislabeled as directory;
- unknown kind;
- missing kind;
- wrong kind type.

B. Link-count mutations

- exact `link_count`;
- stale `nlink`;
- missing link count;
- Boolean link count;
- negative count;
- wrong count;
- multiply linked file.

C. Directory-size mutations

- exact directory size;
- omitted directory size;
- stale size;
- regular-file size substituted;
- wrong type;
- negative value.

D. UID/GID mutations

- exact values;
- missing UID;
- missing GID;
- swapped values;
- wrong type;
- stale value.

E. Modification-time mutations

- exact field and unit;
- omitted field;
- wrong field name;
- seconds versus nanoseconds;
- stale value;
- wrong type.

F. Root and path mutations

- exact root row;
- missing root row;
- duplicate root row;
- root forbidden by a descendant-only grammar;
- missing path;
- duplicate path;
- path traversal;
- nonnormalized path;
- extra path;
- missing path.

G. Exclusion mutations

- exact A/B exclusions;
- missing exclusion;
- extra exclusion;
- temporal self-exclusion error;
- future manifest directory omitted or wrongly retained.

H. Mode/type/object mutations

- exact directory and file modes;
- integer/string encoding mismatch;
- symlink;
- special object;
- hard link;
- unknown object type.

I. Hash and regular-file mutations

- exact SHA-256;
- missing SHA;
- wrong hash;
- same-size byte mutation;
- size mismatch;
- nonregular hash field.

J. Grammar-isolation mutations

- reconciliation grammar applied to contract package;
- contract grammar applied to reconciliation;
- generic field union;
- manifest A grammar differs from B;
- unknown schema;
- same-length wrong entries list.

Require zero false acceptance, false rejection, reason mismatch, skip, or
unexpected exception.

Retain:

validation/current-root-closure-grammar-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
10. INDEPENDENT REPROJECTOR AGREEMENT
──────────────────────────────────────────────────────────────────────────────

For every sealed supplied root:

- projector A creates a manifest-vocabulary projection;
- projector B independently creates the same projection;
- neither imports the other;
- both use the frozen grammar registry;
- both retain raw observations;
- both compare field-by-field;
- both reproduce manifest A;
- both reproduce manifest B;
- both verify A/B byte equality;
- both verify temporal projection;
- both verify terminal topology.

Require:

- A projection = B projection;
- A = supplied manifest A;
- A = supplied manifest B;
- temporal projection exact;
- root policy exact;
- no unexplained field difference.

For the Attempt-2 failure specimen:

- both independently reproduce the complete live inventory under the failure
  grammar;
- both authenticate the exact failure outcome;
- both make no success-closure claim.

Retain one detailed row-difference ledger per root, including empty ledgers.

──────────────────────────────────────────────────────────────────────────────
11. CURRENT-ROOT REPLAY RESULT
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/current-authority-root-closure-replay-v1.json

For each of the eight roles include:

- root identity;
- role and authority;
- closure class:
  terminally sealed or immutable failure specimen;
- temporal result or not applicable;
- manifest result or not applicable;
- projector-A result;
- projector-B result;
- difference count;
- topology;
- modes;
- links;
- cache/bytecode;
- overall pass;
- first blocker or null.

The replay does not issue an implementation or package verdict.

Allowed overall posture:

current_authority_inputs_authenticated_for_future_harness_implementation

──────────────────────────────────────────────────────────────────────────────
12. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero exit and empty streams;
- nonzero with both streams;
- timeout and kill;
- one child;
- multiple children;
- empty child ledger;
- lost stdout;
- lost stderr;
- unregistered filesystem effect;
- zero-root cleanup;
- one-root cleanup;
- multiple-root cleanup.

Require complete streams, exit/signal, reaping, descriptor closure, effect
attribution, evidence-before-cleanup, exact cleanup-set equality, double
ENOENT, and zero survivors.

──────────────────────────────────────────────────────────────────────────────
13. TWO VERIFIER QUALIFICATION REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct verifier rehearsals against independent,
audit-owned synthetic roots representing every registered grammar.

Each rehearsal must include:

- valid baseline for each grammar;
- every mutation class;
- immutable failure specimen;
- process custody;
- report generation;
- terminal package closure;
- cleanup.

Use identical verifier candidate bytes.

Retain complete rehearsal roots until:

- independent validation;
- normalized comparison;
- evidence retention.

Normalize only explicit physical fields.

Require zero unexplained semantic differences.

──────────────────────────────────────────────────────────────────────────────
14. INDEPENDENT VERIFIER VALIDATION
──────────────────────────────────────────────────────────────────────────────

Implement an independent validator that imports neither:

- production verifier modules;
- qualification helpers;
- mutation generator;
- expected-result map;
- production projector;
- production grammar interpreter.

It must independently verify:

- fixed-root registry;
- excluded-root registry;
- every grammar;
- all mutation cases;
- projector A/B independence;
- current-root replay;
- process custody;
- both rehearsals;
- normalized comparison;
- evidence retention;
- cleanup;
- terminal closure.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
15. EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before deleting an owned fixture or rehearsal root retain:

- root identity;
- complete inventory;
- all process records and streams;
- all results;
- failure outcome when applicable;
- terminal posture.

Then verify identity, remove the exact root, and observe ENOENT twice.

Require:

created
=
inventoried
=
evidence-retained
=
cleanup rows
=
twice absent

Equal empty sets pass.

──────────────────────────────────────────────────────────────────────────────
16. SOURCE FREEZE AND REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Freeze verifier source only after:

- grammar registry validation;
- compilation and static gates;
- mutation matrix;
- projector agreement;
- current-root replay;
- process custody;
- two rehearsals;
- normalized equality;
- independent validator;
- evidence retention and cleanup;
- supplied-root equality.

Retain:

opening/current-authority-closure-verifier-source-freeze-v1.json

Reopen all source no-follow.

Do not modify source afterward.

Against frozen bytes rerun:

- compilation;
- static gates;
- grammar matrix;
- projector agreement;
- current-root replay;
- process custody;
- independent validator;
- source/result linkage;
- supplied-root equality.

Do not rerun the two complete rehearsals.

Prove that both passing rehearsals used the bytes later frozen.

Retain:

validation/frozen-current-authority-closure-verifier-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
17. VERIFIER PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  current-authority-closure-verifier-implemented-qualified-frozen-ready-for-clean-harness-implementation;
- verifier authority:
  current fixed-input authentication only;
- implementation package adjudicated:
  false;
- independent-audit harness implemented:
  false;
- full audit executed:
  false;
- current subject constructed:
  false;
- product/runtime/target/repository/publication/deployment/A6:
  not performed or authorized.

──────────────────────────────────────────────────────────────────────────────
18. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for exactly the eight roots in Section 1.

Use the same task-local raw observation grammar for each root’s opening and
closing inventories.

Require exact equality.

Do not open Section 2 roots.

Do not mutate or clean a supplied root.

──────────────────────────────────────────────────────────────────────────────
19. VERIFIER-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize all nonclosure outputs;
- create only used directories;
- ensure `closeout/` and `manifest/` already exist;
- retain no empty descendant;
- reserve zero-length manifest A/B;
- retain descriptors;
- freeze the directory set.

Then:

1. generate temporal inventory excluding itself and A/B;
2. write into preexisting `closeout/`;
3. immediately and independently reproject;
4. require equality;
5. independently generate identical A/B excluding A/B;
6. write through retained descriptors;
7. fsync, close, and fsync manifest directory;
8. reopen no-follow;
9. verify path/inode/type/mode/link/size/hash;
10. independently reproject final root;
11. require root row exactly once;
12. require no empty descendant;
13. require no symlink or special object;
14. require no multiply linked file;
15. require modes 0700/0600;
16. require no cache or bytecode;
17. transition seal once;
18. emit only guarded marker and verdict;
19. exit nonreturningly;
20. perform no filesystem or tool operation after seal.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- process ledger and streams;
- complete partial inventory;
- indispensable evidence;
- fixture cleanup;
- supplied-root equality;
- source-freeze posture;
- terminal-seal posture;
- same-root retry false.

Do not create success manifests for a failed verifier package.

Return provenance mismatch for:

- current-root identity mismatch;
- current closure-record identity mismatch;
- supplied-root mutation;
- excluded-root access;
- historical source use;
- unregistered effect;
- indispensable evidence loss;
- cleanup inequality;
- supplied-root closing inequality;
- source drift after freeze;
- package closure failure;
- postseal operation.

──────────────────────────────────────────────────────────────────────────────
21. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

only when:

- fixed and excluded root registries close;
- every supplied root uses its exact owned grammar;
- reconciliation `regular_file`, `link_count`, directory size, UID/GID, and
  modification-time semantics are preserved;
- both projectors agree;
- every current root authenticates;
- grammar mutation matrix passes;
- process custody passes;
- both rehearsals pass;
- normalized comparison passes;
- independent validator passes;
- evidence retention and cleanup pass;
- source freezes;
- frozen requalification passes;
- supplied roots close equal;
- verifier package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTATION_BLOCKED

when:

- a grammar remains ambiguous;
- a current root cannot be authenticated without semantic invention;
- source cannot qualify within two attempts;
- a matrix, rehearsal, or validator fails;
- implementation would require changing supplied semantics.

Return:

CURRENT_AUTHORITY_CLOSURE_VERIFIER_PROVENANCE_MISMATCH

for the provenance failures defined in Section 20.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh verifier-root identity
3. Fixed-root registry
4. Excluded-root registry
5. Confirmation excluded roots were not opened
6. Verifier authority and nonauthority
7. Per-root closure-grammar registry
8. Reconciliation manifest grammar
9. Implementation-package manifest grammar
10. Successor manifest grammar
11. Contract-package manifest grammar
12. Schema-package manifest grammar
13. Schema-reconciliation manifest grammar
14. Validation-package manifest grammar
15. Attempt-2 failure-root grammar
16. Grammar extraction result
17. Source architecture
18. Source-attempt ledger
19. Final source registries
20. Compilation and static gates
21. Closure-grammar mutation matrix
22. Projector-A result
23. Projector-B result
24. Projector agreement
25. Reconciliation-root replay
26. Implementation-root replay
27. Successor-root replay
28. Contract-root replay
29. Schema-source replay
30. Schema-reconciliation replay
31. Validation-source replay
32. Attempt-2 failure replay
33. Consolidated current-root replay
34. Process-custody qualification
35. Verifier rehearsal A
36. Verifier rehearsal B
37. Normalized rehearsal comparison
38. Independent verifier validation
39. Evidence retention
40. Fixture/rehearsal cleanup
41. Source freeze
42. Frozen-source requalification
43. Confirmation no implementation verdict was issued
44. Confirmation audit harness was not implemented
45. Package status
46. Supplied-root closing equality
47. Failure-closeout capability and use
48. Temporal-inventory identity
49. Manifest A identity
50. Manifest B identity
51. Terminal reprojection
52. Terminal topology and modes
53. No-write-after-closure
54. Remaining uncertainty and nonclaims
55. Explicit confirmation registry

Required confirmations:

FIXED_CURRENT_ROOT_REGISTRY_COMPLETE
EXCLUDED_ROOT_REGISTRY_COMPLETE
NO_EXCLUDED_ROOT_OPENED
NO_HISTORICAL_HARNESS_SOURCE_USED
PROMPT_ONLY_ROOT_PROJECTION_NOT_USED_AS_AUTHORITY
PER_ROOT_CLOSURE_GRAMMARS_FROZEN
UNKNOWN_CLOSURE_GRAMMAR_REJECTED
RECONCILIATION_REGULAR_FILE_VOCABULARY_PRESERVED
RECONCILIATION_LINK_COUNT_FIELD_PRESERVED
RECONCILIATION_DIRECTORY_SIZE_PRESERVED
RECONCILIATION_UID_GID_SEMANTICS_PRESERVED
RECONCILIATION_MODIFICATION_TIME_SEMANTICS_PRESERVED
NO_ACCEPTANCE_FIELD_ALIASING
RAW_AND_MANIFEST_VOCABULARY_OBSERVATIONS_RETAINED
PRODUCTION_PROJECTOR_INDEPENDENT_FROM_PROJECTOR_B
INDEPENDENT_VALIDATOR_IMPORTS_NO_PRODUCTION_HELPERS
SOURCE_ATTEMPT_LIMIT_RESPECTED
ALL_VERIFIER_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
CLOSURE_GRAMMAR_MUTATION_MATRIX_PASSED
PROJECTOR_A_B_AGREEMENT_PASSED
ALL_SEVEN_SEALED_CURRENT_ROOTS_AUTHENTICATED
ATTEMPT_2_FAILURE_SPECIMEN_AUTHENTICATED
CURRENT_ROOT_REPLAY_EMITTED_NO_PACKAGE_VERDICT
PROCESS_CUSTODY_QUALIFICATION_PASSED
COMPLETE_VERIFIER_REHEARSAL_A_PASSED
COMPLETE_VERIFIER_REHEARSAL_B_PASSED
TWO_VERIFIER_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_VERIFIER_VALIDATION_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
VERIFIER_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
VERIFIER_SOURCE_FROZEN
VERIFIER_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_VERIFIER_REQUALIFICATION_PASSED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
INDEPENDENT_AUDIT_HARNESS_NOT_IMPLEMENTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
VERIFIER_TEMPORAL_INVENTORY_CREATED
VERIFIER_TEMPORAL_INVENTORY_VERIFIED
VERIFIER_MANIFEST_A_CREATED
VERIFIER_MANIFEST_B_CREATED
VERIFIER_MANIFESTS_BYTE_IDENTICAL
VERIFIER_TERMINAL_REPROJECTION_PASSED
VERIFIER_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CURRENT_AUTHORITY_CLOSURE_VERIFIER_IMPLEMENTED_QUALIFIED_FROZEN_READY

the next tranche is implementation and qualification of the new clean
source-external independent-audit harness, using this frozen verifier as a
current supplied tool.

Do not combine verifier implementation with harness implementation.

Do not execute the fresh full implementation audit until the later harness
package is independently qualified and frozen.
```

### Sources

The report identifies exact manifest-vocabulary mismatches—`regular_file`,
`link_count`, and directory size—and explicitly classifies the failure as a
verifier implementation defect rather than supplied-root drift. :chatgpt-content-reference{index="7"}

It confirms that source creation, final registries, compilation, operative
matrices, synthetic lanes, compatibility replay, rehearsals, source freeze,
and package closure were not reached, preserving the complete source-attempt
budget. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

The report itself states that a later clean generation must implement the
supplied closure grammar exactly, including the declared kind vocabulary,
link-count field, directory size, UID/GID, and modification-time semantics.
:chatgpt-content-reference{index="10"}

**Confidence:** 0.999 that no implementation-package defect was established; 0.999 that zero source attempts were consumed; 0.98 that a separately qualified current-authority closure verifier is the correct critical path; 0.96 that resuming full harness implementation before qualifying this verifier would recreate the same class of failure.
