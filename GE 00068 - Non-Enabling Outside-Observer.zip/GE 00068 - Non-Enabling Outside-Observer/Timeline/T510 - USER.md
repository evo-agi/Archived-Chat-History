Here is Codex's response:

# AUDIT_PROVENANCE_MISMATCH

`FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`

`FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`

The prelaunch authority-coherence gate failed. Consequently:

- Platform-capture preflight was not executed.
- `run-full-audit` launch count is zero.
- No audit parent, locator, root, capsule, streams, or terminal frame exists.
- The single authorized future audit remains unconsumed.
- No qualification, replacement parent, continuation, or direct auditor was launched.

Evidence:

- [Operative report](/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2/operative-report-v1.json)
- [Fixed-input authentication](/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2/prelaunch-fixed-input-authentication-v1.json)
- [Authority/PYZ closure](/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2/prelaunch-authority-and-pyz-closure-v1.json)
- [Closing equality](/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2/closing-fixed-input-equality-v1.json)
- [Wrapper confirmations](/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2/wrapper-confirmations-v1.json)

## Operative report

1. Exact primary verdict: `AUDIT_PROVENANCE_MISMATCH`.
2. PYZ v2: device `16777234`, inode `182181777`, mode `0400`, link count `1`, size `2822218`, SHA-256 `2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2`.
3. Authority v3: device `16777234`, inode `182181917`, mode `0400`, link count `1`, size `7193`, SHA-256 `349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986`.
4. Content bundle: device `16777234`, inode `181651092`, mode `0400`, link count `1`, size `13598758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`.
5. Content authority: device `16777234`, inode `181651098`, mode `0400`, link count `1`, size `19737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`.
6. Stable prelaunch authentication: passed. Each file passed two no-follow byte/metadata-stable reads; both authority JSON files passed strict UTF-8, duplicate-key, and nonfinite-number checks.
7. Authority-v3 coherence: failed. First blocker: `AUTHORITY_V3_DETERMINISTIC_PYZ_A_B_EQUALITY_ESTABLISHED`.
8. PYZ member/governance closure: 124-member ZIP grammar and member registry passed. Required embedded governance-role closure failed.
9. Platform-capture preflight: not executed because Section 3–4 gates did not pass.
10. Exact real argv was derived but not executed:\
    &#x20;  `["/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13","-I","-S","-B","/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz","--mode","run-full-audit","--harness-authority","/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json","--bundle","/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip","--bundle-authority","/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json"]`
11. Exact cwd, derived but unused: `/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk`.
12. Exact environment, derived but not submitted: `PATH=/usr/bin:/bin`, `LANG=C`, `LC_ALL=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`.
13. Top-level platform custody: audit-parent process creation did not occur; launch count `0`.
14. Raw stdout: no audit stdout stream exists.
15. Raw stderr: no audit stderr stream exists.
16. Exit/signal: both null because no audit parent was created.
17. Audit-root locator: none emitted.
18. Audit-root identity: no audit root was created or selected; no audit-root scan was performed.
19. Terminal frame: none emitted.
20. Parent runtime self-authentication: not reached.
21. Three-role interpreter tuple: not reached.
22. Runtime environment crosswalk: not reached.
23. P00–P24 phases: not reached.
24. Child ledger: not reached.
25. Child custody: not reached.
26. Content bundle/role closure: stable bundle identity and content-authority checks passed—479 members, 8 roles, 7 content roles, and 1 bounded failure-evidence role. Capsule-level audit closure was not reached.
27. Attempt/freeze/source closure: authority-to-PYZ source-freeze and three source-registry bindings passed prelaunch; implementation audit inspection was not reached.
28. Production authority/security: not reached.
29. E00/G00–G29 crosswalk: not reached.
30. Documentary lifecycle/writer ownership: not reached.
31. Runtime matrix evidence: audit-mode matrices not reached.
32. 946-case evidence: not reached.
33. 137-case evidence: not reached.
34. 766/333 field-map evidence: not reached.
35. Producer rehearsals: not reached.
36. Attempt-2 failure evidence: not reached.
37. Implementation confirmations: not reached.
38. Constructed-subject evidence: not reached; no subject was constructed.
39. Fresh behavioral causals: not reached.
40. Fresh source-external validation: not reached.
41. Security/authority closure: not reached.
42. Runtime R01–R66 report: not produced.
43. Runtime 81-name confirmations: not produced.
44. Findings registry: no capsule findings registry exists.
45. Finding ownership: not reached.
46. Dependency graph: not reached.
47. Severity-ranked findings: not reached.
48. Preseal disposition: none; no audit parent or capsule existed.
49. Cleanup: no capsule cleanup record; no capsule was created, modified, or cleaned.
50. Fixed-input closing equality: wrapper-level opening/closing equality passed for all four fixed files; capsule-level record was not reached.
51. Temporal inventory: not produced.
52. Manifest A: not produced.
53. Manifest B: not produced.
54. Terminal reprojection: not reached.
55. Terminal topology/modes: not reached.
56. Seal transition/marker: not reached.
57. No-write-after-seal: not reached because no seal or capsule existed.
58. Current subject: confirmed not constructed.
59. Product/runtime/target/A6: confirmed none occurred.
60. Remaining uncertainty/nonclaims: no package verdict exists. This result establishes only a wrapper provenance mismatch. It does not accept or block the Generation-2 implementation.
61. Wrapper confirmations: 21 confirmed; 1 failed; 3 not executed; 31 not reached.

Additional authority discrepancies, after the first blocker:

- No successful independent authority-v3 validation is established; `post_package_qualification.authority_v3_validated` is `false`.
- No frozen-PYZ requalification binding exists.
- No exact stdout/stderr framing contract exists in authority v3.
- The PYZ lacks the required embedded members:
  - `qualification/post-package-qualification-v2.json`
  - `qualification/independent-authority-v3-validator-v1.json`
  - `qualification/frozen-pyz-v2-requalification-v1.json`

## Wrapper confirmations

Confirmed:
```
FINAL_PYZ_V2_IDENTITY_MATCHED
FINAL_AUTHORITY_V3_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
PYZ_V2_MEMBER_SET_CLOSED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
AUDIT_ROOT_SCAN_NOT_PERFORMED
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

Failed:
```
AUTHORITY_V3_CURRENT_AND_COHERENT
```

Not executed:
```
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
```

All remaining audit/capsule confirmations are `NOT_REACHED` because the audit parent was not created.
