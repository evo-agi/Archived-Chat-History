This is the right branch. **Option A should become a separate successor-only Repair 10I-A5P tranche.**

The deciding facts are stronger than “the tests need a terminal”:

- The PTY behavior is material to the four operator tests; replacing it with pipes, files, or socket pairs would weaken what those tests exercise.
- Direct PTY allocation can remain denied inside the sandbox.
- The runner can broker an exact, bounded number of private PTY pairs and pass only their descriptors.
- A controlling-terminal child can receive one runner-derived, literal slave-device `file-ioctl` rule without receiving `/dev/ptmx`, a `/dev/ttys*` wildcard, or access to an existing unrelated terminal.
- The capability can be explicit, denied by default, command-scoped, fingerprinted, externally recomputed, and fully represented in resource custody.

That is a genuine validation-successor capability—not a product/runtime capability and not permission to broaden device access generally. The A5T repository bytes should remain unchanged and unsealed while A5P is implemented. After A5P seals, A5T validation must restart in a **new** child; a bounded successor causal cannot substitute for the newly materialized downstream control. 

Pass this to Codex:

```text
Objective

Implement, validate, and seal Repair 10I-A5P: the private PTY-broker capability
frozen by the sealed A5P reconnaissance.

The capability exists solely in the source-external Repair 10I validation
successor. It enables explicitly declared validation commands to receive a
runner-owned private PTY pair without granting the sandboxed command:

- `/dev/ptmx`;
- a `/dev/ttys*` wildcard;
- broad `/dev` access;
- the operator’s current terminal;
- any unrelated existing terminal;
- authority to allocate another PTY.

The implementation must follow the exact frozen contract in:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66/findings/successor-capability-contract-v1.json

and the source-grounded report in:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66/findings/reconnaissance-report-v1.md

This is a parent-only successor implementation turn.

Do not modify repository source.
Do not modify the current unsealed A5T evidence child.
Do not implement A5C observability-duration canonicalization.
Do not restart A5T validation.
Do not restart the A6 policy-evidence refresh.
Do not implement A6 or start B6.
Do not create a ZIP, handoff, capture child, or snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not claim independent audit or product acceptance.

No subagents. You are the sole writer.

Repository, read-only during this turn

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5S successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Sealed A5P reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66

Current failed and unsealed A5T child

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t-test-fixture-closure-e260e1bb5ac4

Failed and unsealed A6 policy-evidence refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required new A5P implementation child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the repository delta from the sealed A5 opening source to remain
exactly these two existing test files:

1.
remote_alpha_operator_test.go

2.
es/runtimehelper/supervisor_test.go

No addition, deletion, rename, or mode change.

Capture and retain their current mode, size, and SHA-256 from the live
repository. Do not infer them from a report.

Require exact A5S:

- manifest SHA-256:
  57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f
- payloads:
  271
- source T:
  983943e612dd4d48ca4f0fabbc48ad51909c2e11
- source inventory:
  799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a
- members:
  12

A5S binaries:

repair10-runner:
  ce6a44a99d4f53eaa6c8feeadc407e063deb7e6303e68f154fbe1cf0d573e68b

repair10-compare:
  e31887e0d45026d6bad6a6f2e5a4a30dd1f0f7c5bd55847991a9120ef6351e06

repair10-semantic:
  2f28bf8996b4a42d318cb16604804ad90cdb41b17517d30b4c0db85d5fbd0c2e

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require exact A5P reconnaissance:

- manifest SHA-256:
  1a1d3362886deb9b5b8e7358bf711af191f358faa164c0a3c58d7f7539042550
- payloads:
  148
- directories including root:
  7

Reverify every A5P reconnaissance payload, including:

- reconnaissance-report-v1.md;
- successor-capability-contract-v1.json;
- probe-matrix-summary-v2.json;
- exact current-profile EPERM reproduction;
- unsandboxed PTY positive;
- selected broker positive;
- direct `/dev/ptmx` denial;
- unrelated PTY denial;
- no broad `/dev` or `/dev/ttys*` grant;
- cleanup and absence records.

Require the current A5T child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact throughout this turn.

Reverify its retained facts:

- exactly the two repository test files changed;
- three independent private controls produced 45/45 passes;
- zero required skips;
- repaired socket paths were 75–76 bytes;
- the old socket EINVAL failures disappeared;
- all five intended assertions were reached outside A5S;
- A5S blocked the four remote tests at PTY allocation with EPERM;
- no repository production source changed.

Require the failed A6 policy-evidence child and all sealed/unsealed predecessor
lineage to remain unchanged.

Require the A5P implementation target to be absent.

Stop on any mismatch:

REPAIR10I_A5P_BASELINE_MISMATCH

## 2. Frozen capability contract

The active capability is exactly:

repair10i-private-pty-broker-v1

Recover and reproduce the complete frozen contract from
`successor-capability-contract-v1.json` before editing.

The implementation must preserve these invariants:

1. Default denied

   Commands without the explicit capability receive no brokered PTY, no
   terminal-device profile grant, and no change in execution behavior.

2. Runner-owned allocation

   The runner allocates every PTY pair outside the sandboxed command.

   The command cannot allocate its own PTY.

3. Exact finite role and count

   The command specification declares a closed PTY role and exact bounded
   count.

   Arbitrary role strings, arbitrary counts, caller-provided terminal paths,
   and unbounded lists are rejected.

4. Descriptor-only transport

   The child receives only the selected broker-owned descriptors through the
   exact declared descriptor mapping.

   No terminal path is used as a caller-controlled input.

5. Literal slave ioctl grant only when required

   A command requiring controlling-terminal behavior receives exactly one
   runner-derived literal slave-device `file-ioctl` rule for the slave belonging
   to its broker-owned PTY.

   Do not grant:

   - file read or write to arbitrary terminal paths;
   - `/dev/ptmx`;
   - a `/dev/ttys*` prefix or regex;
   - all `/dev`;
   - an operator or unrelated terminal;
   - a caller-supplied terminal pathname.

6. No unrelated terminal access

   A separate parent-owned but ungranted PTY must remain inaccessible.

   The child must not open, read, write, or ioctl an unrelated existing TTY.

7. No secondary allocation

   A broker-enabled command must still receive EPERM/EACCES when attempting a
   new `openpty()` or opening `/dev/ptmx`.

8. Explicit command policy

   PTY capability is represented explicitly in the suite/command
   specification.

   Do not infer it from:

   - command name;
   - package or test name;
   - argv contents;
   - source class;
   - a full-suite special case;
   - environment values.

9. Logical fingerprint

   Every behaviorally material PTY field changes the logical command/suite
   fingerprint, including:

   - capability presence;
   - role;
   - count;
   - controlling-terminal requirement;
   - descriptor mapping;
   - stream attachment mode.

10. External qualification

    Opposite-side qualification independently parses and recomputes the PTY
    policy, fingerprint, descriptor inventory, resource disposition, and
    cleanup result.

11. Complete custody

    Every PTY master/slave descriptor receives:

    - one acquisition generation;
    - stable device/inode/type identity;
    - explicit owner role;
    - transfer record where inherited;
    - exactly one inspected close attempt;
    - stored actual cause;
    - EOF/worker disposition where applicable;
    - EBADF or equivalent post-close verification;
    - absence from the final resource ledger.

12. Terminal and process semantics

    The implementation preserves the command’s declared controlling-terminal,
    session, process-group, signal, stream, readiness, and exit behavior.

    A terminal-backed command must not escape raw stdout/stderr accounting.

13. Cleanup

    Success requires:

    - child reaped exactly once;
    - all PTY workers joined;
    - every PTY descriptor disposed;
    - no surviving process or group;
    - no listener/socket/PTY resource survivor;
    - two fresh zero-observation cleanup epochs;
    - verified-empty next-command barrier.

14. No product authority

    The capability is validation-successor functionality only.

    It changes no repository product API, public schema, runtime contract,
    operational script, installation path, T2A-I, or T2B authority.

## 3. Private schema versioning

The reconnaissance concluded that a private schema change is required.

Recover the exact schema transition and names from the frozen contract before
editing.

Every acceptance-bearing record whose meaning changes must receive the exact
new version identified by the contract.

At minimum, the versioning must cover the command/suite specification and any
result, qualification, effective-policy, fingerprint, resource, or terminal
record whose semantics now include brokered PTYs.

Historical A5S records remain parseable only as explicitly historical evidence.
They cannot qualify an A5P command.

Strict decoding is required:

- unknown PTY fields reject;
- missing required PTY fields reject;
- old-schema substitution rejects;
- new schema without the required PTY semantics rejects.

If the frozen contract does not provide a complete, internally consistent
schema list, stop before editing:

REPAIR10I_A5P_CONTRACT_INCOMPLETE

Do not silently invent a partially versioned dialect.

## 4. Exact successor touched-file scope

The governing touched-file set is the exact source-member array recorded in:

successor-capability-contract-v1.json

Before editing:

- reproduce that exact array;
- verify every path exists in the 12-member A5S source;
- verify each opening mode, size, and SHA-256;
- retain the array in the A5P opening evidence.

Modify no successor source outside that exact array.

Copy all 12 A5S source members independently into the A5P child, with no
hardlinks.

Every source member not listed by the frozen contract must remain byte- and
mode-identical to A5S.

If the contract lacks an exact touched-file array, a required edit falls
outside it, or a thirteenth source member is needed, stop:

REPAIR10I_A5P_SCOPE_EXPANSION_REQUIRED

Do not change repository source.

## 5. Required implementation mechanics

Implement the exact broker architecture from the frozen contract.

At minimum:

### Pair allocation

- allocate each PTY pair before the sandboxed child starts;
- record master/slave identity and role;
- reject aliasing, duplicate descriptors, wrong type, multilink/symlink state,
  and unsupported counts;
- hold the required descriptors until successful child inheritance is proven.

### Profile construction

- begin from the existing default-deny A5S profile;
- add no global device grant;
- for a controlling-terminal command, add only the runner-derived literal
  slave `file-ioctl` rule required by the probe-proven mechanism;
- keep direct `/dev/ptmx` access denied;
- keep every ungranted terminal denied;
- retain the rendered profile and effective-policy record.

### Child launch

- map the exact broker descriptors into the child;
- preserve close-on-exec disposition for every non-inherited alias;
- establish the requested terminal/session/process-group semantics;
- prove the child received the expected role/count;
- prevent another PTY allocation;
- retain one Wait owner and complete stream/resource custody.

### Output and terminal records

- keep stdout/stderr accounting complete even when the PTY carries terminal
  interaction;
- distinguish brokered terminal streams from raw retained stdout/stderr;
- retain observed/retained byte counts and EOF;
- make any PTY read/write/close/worker error qualification-blocking;
- do not let a PTY path or descriptor escape into a public/product record.

### Disposal

- continue cleanup after the first error;
- close each owned descriptor exactly once;
- never retry close after EINTR;
- retain actual causes in stable order;
- verify no reused/stale descriptor was affected;
- prove no PTY or child resource remains.

## 6. Mandatory pre-implementation negative

Before editing, reproduce with the exact A5S runner and exact current A5T
source bytes:

- the four named remote tests progress past repaired socket setup;
- PTY allocation fails with EPERM;
- no PTY descriptor is acquired;
- terminal/resource reconciliation completes;
- test execution is nonqualifying for A5T closure.

Retain this as expected-negative evidence.

## 7. Unit and causal test matrix

Add active successor tests covering all of the following.

### Default denial

- command without capability cannot call `openpty()`;
- command without capability has no PTY profile rule;
- non-PTY command fingerprint remains compatible with its own new schema;
- unrelated commands are not widened.

### Valid brokered PTY

- exact role/count accepted;
- child receives the exact descriptors;
- child observes expected TTY status;
- controlling-terminal behavior works when declared;
- process/session/group semantics match the frozen contract;
- all output and terminal records reconcile;
- all descriptors and workers are disposed.

### No new allocation

Inside a broker-enabled command:

- `openpty()` remains denied;
- `/dev/ptmx` open remains denied;
- no additional PTY can be allocated.

### Unrelated terminal denial

Create at least two parent-owned private PTYs:

- one granted;
- one ungranted.

Require:

- granted pair usable only in its declared role;
- ungranted master/slave cannot be opened, read, written, or ioctled;
- no path-prefix or sibling-device grant exists.

Do not touch the operator’s current terminal.

### Literal ioctl rule

Require:

- exact runner-derived slave literal succeeds for the intended ioctl;
- wrong slave literal fails;
- sibling PTY fails;
- path substitution fails;
- stale/replaced slave identity blocks;
- caller-supplied terminal path is rejected.

### Schema and fingerprint

Independently mutate:

- capability presence;
- role;
- count;
- controlling-terminal flag;
- descriptor mapping;
- stream mode;
- schema version.

Require every material mutation to change the logical fingerprint or reject the
record.

Old A5S schemas must remain historical/nonqualifying on active A5P paths.

### Resource faults

Causally inject:

- pair allocation failure;
- partial pair acquisition;
- identity mismatch;
- duplicate FD;
- cross-role FD alias;
- inherited-FD setup failure;
- child start failure;
- early child exit;
- timeout;
- signal failure;
- Wait failure/uncertainty;
- master read failure;
- slave operation failure;
- EOF failure;
- worker join failure;
- close failure;
- EINTR;
- FD reuse;
- resource-ledger write failure;
- terminal-record failure;
- cleanup-observation failure;
- repeated cleanup entry.

Require:

- no duplicate syscall;
- stored terminal disposition on repeated entry;
- complete later cleanup;
- qualification false;
- no accepted result survives a late fault.

### Security mutants

Reject:

- `/dev` wildcard;
- `/dev/ttys*` prefix or regex;
- `/dev/ptmx` grant;
- operator-terminal literal;
- arbitrary caller-provided device path;
- capability inferred from command or test name;
- capability silently enabled for all full-suite commands;
- capability omitted from external qualification;
- capability omitted from fingerprint;
- PTY descriptor absent from the resource ledger.

## 8. A/B source, tests, races, and deterministic builds

Use pinned Go 1.26.5 under umask 077 in two physically disjoint controls.

Each side must have independent:

- source;
- HOME/XDG;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build root;
- report root;
- PTY probe resources.

No writable state may be shared.

On both sides run:

gofmt -d over all Go source; require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

Require:

- no required skip;
- no race report;
- no malformed stream;
- no survivor;
- no forced cleanup;
- complete terminal records;
- complete PTY resource ledgers.

Build on each side with deterministic flags:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require each A/B binary pair:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- expected mode;
- built from exact A5P source;
- free of unexpected build-info paths.

## 9. Bounded current-A5T causal

After the successor hard gate passes, create one complete private copy of the
current repository T:

ab646e5a0e66a30c00ca405ab43fbf6903224043

with inventory:

c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3

Run only the four affected remote tests through the A5P runner with the
explicit PTY capability enabled.

Require:

- repaired socket fixtures remain at most 100 bytes;
- listener setup succeeds;
- brokered PTY setup succeeds;
- direct child PTY allocation remains denied;
- all four tests reach and pass their named assertions;
- no unrelated terminal is accessible;
- no required skip;
- no race report in a targeted race control;
- complete resource and terminal reconciliation;
- two fresh zero-observation cleanup epochs.

Run the same command without the PTY capability and require the expected PTY
denial.

This is a bounded successor/product integration causal only.

It does not seal A5T and does not replace the fresh A5T validation child
required afterward.

Do not run the complete repository suite in A5P.

## 10. Compatibility requirements

Reverify with retained immutable inputs:

- A5S line-1706 grammar behavior;
- all seven wrong-line negatives;
- overbound/malformed logical-byte negatives;
- historical HEAD semantics;
- historical Repair-9 semantics;
- A5S final/fresh and mutant-direction tool causals;
- non-PTY profile and command behavior.

Require no unrelated semantic or comparison-policy change.

The A5C observability-duration defect remains deliberately unfixed here.

## 11. Evidence child

Create A5P only after the opening gate.

Use private top-level directories exactly as frozen by the reconnaissance
contract. If the contract specifies no complete top-level layout, use:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

Retain:

- complete opening and immutable-lineage verification;
- exact frozen contract and reconnaissance identities;
- expected-negative A5S PTY denial;
- exact A5S→A5P source delta;
- schema transition ledger;
- effective profile and policy records;
- every PTY allocation/custody/disposition record;
- every causal and security mutant;
- A/B source, test, race, and build evidence;
- bounded current-A5T integration causal;
- compatibility results;
- failed and superseded attempts;
- cleanup and two absence epochs;
- implementation report;
- final source inventory and T;
- exact path/mode/size/hash inventory.

No hardlinked evidence.

Do not copy raw private terminal payload. No terminal payload is needed for this
capability proof.

## 12. Closeout

Require:

- exactly the frozen successor touched-file set changed;
- every other A5S source member byte- and mode-identical;
- repository T/inventory/membership unchanged at:
  - T `ab646e5a0e66a30c00ca405ab43fbf6903224043`
  - inventory `c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3`
- repository branch/HEAD/parent/tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged remain zero;
- A5S, A5, A5P reconnaissance, failed A5T, failed A6 refresh, and all
  predecessor lineage remain unchanged;
- no bytecode/cache appears in any predecessor;
- no PTY, terminal FD, process, group, worker, private source, cache, build,
  report, or temporary control root remains;
- two fresh zero-observation epochs pass.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 13. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- frozen contract is incomplete or internally inconsistent;
- touched-file scope is absent or insufficient;
- need for repository source change;
- need for broad `/dev`, `/dev/ptmx`, or `/dev/ttys*` access;
- caller-supplied terminal path;
- direct child PTY allocation succeeds;
- unrelated PTY becomes accessible;
- capability is implicit rather than declared;
- capability omitted from fingerprint or external qualification;
- PTY descriptor omitted from resource custody;
- terminal behavior cannot coexist with complete output accounting;
- any causal, race, deterministic-build, cleanup, or sealing failure;
- current A5T bounded causal cannot pass with explicit capability and fail
  without it;
- schema transition cannot be made complete.

## 14. Verdicts

Opening mismatch:

REPAIR10I_A5P_BASELINE_MISMATCH

Frozen contract incomplete:

REPAIR10I_A5P_CONTRACT_INCOMPLETE

Scope expansion required:

REPAIR10I_A5P_SCOPE_EXPANSION_REQUIRED

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A5P_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A5P_PRIVATE_PTY_BROKER_SEALED_READY_FOR_FRESH_A5T_RESTART

The success report must include:

- A5S and A5P source T/inventory;
- exact successor touched paths;
- complete private schema transition;
- exact profile rule and why it is not broad;
- direct `/dev/ptmx` and unrelated-terminal denial results;
- PTY descriptor custody and cleanup results;
- fingerprint and external qualification results;
- A/B source and binary identities;
- test/race/security-mutant outcomes;
- bounded current-A5T causal with and without capability;
- repository no-mutation evidence;
- manifest SHA-256 and payload count;
- two final absence epochs;
- explicit statement that A5T was not sealed and the A6 refresh was not
  restarted.

No A5T seal.
No A5C.
No A6.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## Sequence after A5P

Do not resume the present A5T child. Start a new A5T validation/closure child and rerun its complete gate from opening. After A5T seals, implement the separately frozen A5C duration amendment, then restart the two-control A6 evidence refresh.

That ordering preserves one authoritative explanation for each changed byte:

- A5P: validation capability and PTY custody;
- A5T: repository test-fixture repair;
- A5C: diagnostic semantic equivalence;
- A6: historical comparison policy.

Repository mutations and independent audit remain separate engagement types, and changed bytes require new validation, provenance, and re-audit.   Exact manifests will bind the A5P bytes but cannot, by themselves, prove that terminal access is safe or correctly constrained. 

### Sources

- Codex’s `REPAIR10I_A5P_SUCCESSOR_CAPABILITY_RECONNAISSANCE_READY` report supplied in this turn.
- Sealed A2 restart/non-substitution precedent. 
- Governed Execution implementation and repair/re-audit protocol.  
- Governed Execution provenance limitations. 

**Confidence:** 0.98 that Option A is the correct path; 0.96 that it can remain validation-only without broad terminal access; 0.90 that the frozen reconnaissance contract is sufficiently complete for implementation; 0.995 that A5T must restart in a new child after A5P; 0.995 that A5C and A6 should remain separate later gates.
