## Operative report — 66/66 sections

### 1. Primary verdict

`GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED`

Terminal blocker: the frozen source record asserts `matrix_case_count = 645`, while the authenticated matrix suite and final qualification evidence both contain exactly 595 cases. The 15 matrix counts sum to 595. This is an implementation/evidence-validation defect, not an input-provenance defect.

### 2. Fresh build-root identity

`/private/tmp/ES-repair10i-v3-gen2-clean-independent-audit-harness-build-h4db6xok`

Device `16777234`; inode `181667101`; mode `0700`. The complete 117-entry inventory was retained. The root was removed and independently observed absent twice.

### 3. Fresh output-root identity

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-output-r9ofqe2r`

Device `16777234`; inode `181667102`; mode `0700`; nonauthoritative. The rejected final-named files were removed after their identities were retained. The directory is now empty.

### 4. Exact input-bundle identity

`/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip`

Device `16777234`; inode `181651092`; mode `0400`; link count `1`; size `13,598,758`; SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`.

### 5. Exact input-authority identity

`/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json`

Device `16777234`; inode `181651098`; mode `0400`; link count `1`; size `19,737`; SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`.

### 6. Bundle/authority authentication

Passed. Strict UTF-8 JSON, duplicate-key rejection, exact schema and archive identity, deterministic-build assertions, role counts, independent validation posture, supplied-root nonmutation, and no implementation/package verdict were validated.

### 7. Bundle index/member closure

Passed for 479 ZIP members: 478 ordinary index rows plus `bundle/index.json` self-membership. All members were stored, raw-UTF-8 sorted, fixed to the 1980 timestamp, `create_system=3`, regular mode semantics, with no duplicate/unsafe/directory/symlink/special/`.DS_Store` members, comments, or uncontrolled extra fields.

### 8. Current role resolution

Exactly eight roles resolved:

- Seven content snapshots: terminal findings `47` members; implementation `97`; successor contract `83`; normative contract `68`; current schema `59`; schema reconciliation `32`; validation specification `77`.
- One bounded failure-evidence subset: Attempt-2 failure evidence, `4` members.

No live authority root was accessed.

### 9. Clean-room source authority

Established. Source was authored in this task from authenticated bundle contracts and evidence. No historical harness/verifier source was opened or used. Implementation production source was read only during bounded compatibility analysis and was never executed or used as harness source.

### 10. Harness authority and nonauthority

Harness authority was limited to the frozen clean source, frozen contracts, qualification evidence, deterministic package members, and external identity observations. The containing directory, historical roots, live roots, implementation behavior, repository state, and prose were nonauthority.

### 11. Mode and future-invocation contract

Both `qualify-harness` and `run-full-audit` were implemented. Only qualification was executed.

The frozen future invocation used pinned Python 3.13 with `-I -S -B`, no shell, `DEVNULL` stdin, and environment:

`LANG=C`, `LC_ALL=C`, `PATH=/usr/bin:/bin`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`.

Because the package was rejected and removed, that invocation is now documentary only and must not be run against the absent path.

### 12. Defect-prevention registry

The registry froze all fifteen required surfaces:

- B00 bundle authority/member closure.
- D01 exact attempt/status semantics.
- D02 transitive freeze binding.
- D03 multiple-role/source joins.
- D04 path-sensitive G01 adjudication.
- D05 confirmation and terminal-marker semantics.
- D06 lane-specific adapters.
- D07 typed 766/333 field-map separation.
- D08 constructed-subject domain.
- D09 typed physical normalization.
- D10 causal finding ownership.
- D11 canonical cleanup results.
- D12 field-alias/path-rendering/normalization separation.
- D13 report-section registry.
- D14 confirmation-name registry.

The terminal blocker reveals an additional missing cross-document aggregate-count check.

### 13. Full-audit phase plan

The 25-phase P00–P24 plan was frozen, covering self-authentication, bundle closure, contract authentication, implementation closure, static security, lifecycle crosswalks, matrices, 946 negative cases, 137 contradiction cases, 766/333 field-map evidence, rehearsals, bounded failure evidence, confirmations, process custody, behavioral causals, independent validation, findings/verdict, cleanup, closing equality, preseal, and terminal closure.

Every phase recorded prerequisites, operands, outputs, authority contribution, pass/failure rules, continuation scope, and cleanup obligations. Terminal status was not equated with pass.

### 14. Report contract

The exact ordered 66-section registry was frozen; the count was derived from the registry. Package, audit, derivative, mixed, unresolved, and provenance findings remained distinct. Prose was not treated as authority.

### 15. Confirmation contract

The exact 81-name registry was frozen; its count was derived from the names. Every confirmation required an evidence pointer. Hard-coded success, absence-as-success, appended verdict confirmations, and conflation of the primary verdict with confirmations were prohibited.

### 16. Source architecture

Twenty source files occupied 35 registered roles. Production audit logic imported no qualification module. Independent validators imported neither production nor qualification helpers. Process creation was owned solely by `harness.custody.ChildRecorder.run`.

### 17. Source-attempt ledger

Two of three permitted attempts were used.

- Attempt 1: compilation/static gates passed, then bounded replay failed closed on a relative-versus-absolute path-rendering mismatch at `requalification.production-registry:path`. Its leaked 14-entry rehearsal root and provisional builds were inventoried, removed, and observed absent twice.
- Attempt 2: repaired only the explicit path-rendering policy. It reached internally successful qualification and freeze.
- Terminal review then found the `645` versus `595` frozen-evidence contradiction. No Attempt 3 or same-root retry was started because the source was already frozen and its build root had been closed.

### 18. Final production-source registry

Registry: size `2,160`; SHA-256 `22321e97c4abb4bc4c1b8564df055d92a5dd938036cb20b10c066d244a7fc66b`.

- `__main__.py`: `1518`, `374f78ea58e710cc076378e5e6b988f6cac4f0dcc5226e4cc482d6db6f3236de`
- `harness/__init__.py`: `97`, `65be7ab6a4d1315fb466683af3817b1c291d0df40c6bc1eb0e11b1307c69d5ef`
- `harness/adapters.py`: `18281`, `bfa2d084ea7fc0dc328255175352098661af50f0529c2616d81cc1a74ac5e622`
- `harness/audit.py`: `15353`, `f7b8d4f5f7438ac8c002c96fe1b279a22337b45233e67ce397b882c84a3c022d`
- `harness/bundle.py`: `17649`, `0c973db8ef7bd2d1c9e1c143ee4f75e1eac8d48447ba462573d3d5b859d8b8a3`
- `harness/confirmations.py`: `6946`, `9fe221dc20db841a49cb0b73196b1d0f8c397b2609b5a047a9faab17f38dd9bc`
- `harness/constants.py`: `4462`, `e30a5a6603f2643113c4a37d5ad5646fe450fe5581fdd7ffd5bad33aa76e780d`
- `harness/custody.py`: `13140`, `31efe73ea2769e08cf6c52b100ccfd0751c2aa1b2a9fad70c4aafcb93e3ad64b`
- `harness/findings.py`: `6774`, `cc77c3604266013fad49bc5db3c55db87b35456ae0234c2ecdc928bbc571a6fc`
- `harness/lifecycle.py`: `5466`, `5d0a0119dbcb15a208bb3b98e78841ef77021acaa99180deeb34ad3efa401c5a`
- `harness/reporting.py`: `3587`, `2807b8a22f22ba268391903949db12fd5d626076e4da7db783f92f21e6f5f549`
- `harness/strictio.py`: `7003`, `aca03c8c23f8625a574a0467dd4f42a2cf8c0b26a4b9b477cc10d2fb99b3c7f0`

### 19. Final qualification-source registry

Registry: size `1,143`; SHA-256 `a614ae8f23d93f3895e2b4c58207b9250c3e2b4cf6a8c7fb0f42d9fd6e7a1e66`.

- `qualification/__init__.py`: `111`, `ce3cd84db3408a4fa20aee3ddbdea1dcf9ce392108efaf3ed5c320457e29f04e`
- `qualification/compatibility.py`: `27535`, `29efd0d96e91ade808ac38e6c3a9eea0f7883a464bf6f645d9057dda6d4171d5`
- `qualification/driver.py`: `19785`, `4a848bd53b08e2a93c0e39f89d7f98a4f16e6965dbf356ea4fa5414d0bc3586d`
- `qualification/matrices.py`: `29110`, `dd69f4251d38d10ae8b4f14e30c3061417e46ddcb6be58b9ce0a0d6694bf7abb`
- `qualification/synthetic.py`: `17942`, `cb82d275f96d800739abc0a907ab3f5e65776a48afe52c34ca20d66934d09517`

### 20. Final independent-source registry

Registry: size `928`; SHA-256 `cd8cfac11c189065f70a073381a7e84c05b81567cfcaad83e88e027f22fea10a`.

- `independent/__init__.py`: `116`, `bddf13350f9b48643a5e65742e01b6e39fbb3773e4289fc837d7312c5858fed0`
- `independent/evidence_validator.py`: `13243`, `77e3cbf16d618791f3773be3047135ee5e8946f9328242edd3113c7d51204020`
- `independent/package_validator.py`: `8324`, `542a3b3b09d8744a8039cea62df903a602410a708164e5a2f9ecfea48cf9de77`

### 21. Cross-module interface registry

Twenty-one interfaces were frozen:

1. `strict-json`: bytes → exact JSON or error.
2. `file-identity`: absolute path/policy → bytes and identity.
3. `total-observation`: JSON/pointer → typed observation.
4. `bundle-authentication`: two paths → bundle view/result.
5. `role-resolution`: bundle view → exact role map.
6. `safe-member-read`: role/path → authenticated bytes.
7. `attempt-status`: typed records → status result.
8. `freeze-binding`: freeze graph → closure result.
9. `role-source-join`: role/source rows → many-to-one result.
10. `lane-adaptation`: lane/document → typed result.
11. `confirmation-adjudication`: names/evidence → confirmations.
12. `process-recording`: registered child specification → complete record.
13. `cleanup-result`: cleanup rows → deterministic projections.
14. `causal-findings`: observations/dependencies → findings/verdict.
15. `report-projection`: registry/evidence → ordered report.
16. `capsule-lifecycle`: audit state → preseal/terminal capsule.
17. `matrix-suite`: frozen registries → B00 and D01–D14.
18. `synthetic-suite`: fixture root → lanes A–G.
19. `compatibility-replay`: current bundle → no-verdict result.
20. `independent-evidence-validation`: serialized evidence → zero-error result.
21. `independent-package-validation`: PYZ/authority → package result.

### 22. Precompilation gate

Passed for all 20 sources: strict UTF-8, AST parsing, all 35 architecture roles occupied, 21 interfaces registered and shape-conformant, final registries closed, 66 report sections and 81 confirmations derived, correct import boundaries, no historical origin, no VCS mechanism, and no production execution.

### 23. Compilation/static gates

Compilation used `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 -I -S -B`; 20/20 sources compiled, exit `0`, empty stdout/stderr, and no bytecode/cache writes.

Static analysis covered 35,064 AST nodes, 2,441 call sites, 163 call-graph nodes/285 edges, 591 CFG branches, 182 returns, 272 raises, 24,985 bytecode instructions, 324 code objects, 1,761 exception-table bytes, 27 filesystem sites, one owned process-launch site, and five terminal-operation sites. All specified prohibitions passed.

### 24. B00 bundle matrix

Passed: `70` cases; unique closed names; false acceptance `0`, false rejection `0`, reason mismatch `0`, skip `0`, unexpected exception `0`.

### 25. D01 matrix result

Passed: `30` cases; all five failure counters `0`.

### 26. D02 matrix result

Passed: `25` cases; all five failure counters `0`.

### 27. D03 matrix result

Passed: `30` cases; all five failure counters `0`.

### 28. D04 matrix result

Passed: `30` cases; all five failure counters `0`.

### 29. D05 matrix result

Passed: `35` cases; all five failure counters `0`.

### 30. D06 matrix result

Passed: `100` cases; all five failure counters `0`.

### 31. D07 matrix result

Passed: `30` cases; all five failure counters `0`.

### 32. D08 matrix result

Passed: `40` cases; all five failure counters `0`.

### 33. D09 matrix result

Passed: `40` cases; all five failure counters `0`.

### 34. D10 matrix result

Passed: `30` cases; all five failure counters `0`.

### 35. D11 matrix result

Passed: `50` cases; all five failure counters `0`; `cleanup_roots` alias rejected.

### 36. D12 matrix result

Passed: `35` cases; all five failure counters `0`; field alias, path rendering, and normalization remained distinct.

### 37. D13 matrix result

Passed: `25` cases; all five failure counters `0`; section-count drift rejected.

### 38. D14 matrix result

Passed: `25` cases; all five failure counters `0`; appended verdict confirmation rejected.

The authenticated total is therefore `595`, not `645`.

### 39. Process-custody qualification

All 18 required custody checks passed, including nonexistent executable, empty and dual streams, nonzero exits, timeout/kill/reap, one/multiple children, empty ledger, lost-stream rejection, unregistered-effect rejection, cleanup cardinalities, evidence-before-cleanup, and separate stream/exit capture. Five actual child records were retained per rehearsal. All children were reaped, descriptors closed, and survivor counts were zero.

### 40. Synthetic ACCEPT lane

Expected and observed accepted result matched, including findings, ownership, dependencies, phases, custody, cleanup, 66 report sections, 81 confirmations, and one terminal seal.

### 41. Synthetic BLOCK lane

Expected and observed substantive block matched without converting audit or derivative defects into package defects.

### 42. Synthetic provenance-failure lane

Expected and observed provenance failure matched, including terminal cleanup and no postseal operation.

### 43. Synthetic subject-pair lane

Two physically distinct subjects normalized to semantic equality. The wrong same-length registry was rejected, incomplete bounded evidence was not treated as complete, and terminal-marker/confirmation mutations were rejected.

### 44. Bounded real-bundle compatibility replay

Internally passed without issuing a verdict. Eight roles, Attempts 1–3, freeze/requalification records, 24 production roles, nine qualification roles, G01, 125 implementation confirmations, ten implementation matrices, 946 negative cases, 137 contradiction cases, the 766/333 field map, producer rehearsals, and bounded failure evidence were parsed. Implementation source was read only and never executed.

Evidence identity: size `14,622`; SHA-256 `2969f56aa7cdf33d29d4694e05d5e2e0b066bbc1711f1610623a46d4ff74a07a`.

### 45. Harness rehearsal A

Exited `0`, empty stderr, internally passed, and cleaned twice absent.

Evidence: size `297,290`; SHA-256 `b16fd464a0b9ec379b7961f511c86b9e0255a023eac65b64f727abf83fbe5d5c`.

Process record: size `694,960`; SHA-256 `e4ab7aaf24567ca82e2224e9a5e7212bc6c8aca038c2fd708b2afc32ed5e0e92`.

### 46. Harness rehearsal B

Exited `0`, empty stderr, internally passed, and cleaned twice absent.

Evidence: size `297,290`; SHA-256 `72f25cdf9d50e7c904ecdb5031a66029f8528332183d15390681d4c65a48a2fc`.

Process record: size `694,960`; SHA-256 `0cec5f777766929c1d4d47becfb0e6c808116370238a382c899c2013f5a37c33`.

### 47. Rehearsal normalized comparison

Both provisional PYZs were byte-identical: size `306,429`; SHA-256 `bb6da926d88420f7a72f54cf78baa71cac150b5ef341d8640397f9de4c43cc92`.

The semantic projection SHA-256 was `4dcacb357b27bd58d868163deda96ad53c705ff0abd89461a76f258d8a540a06`, with zero unexplained differences and no filename heuristics.

### 48. Independent validators

The retained validator emitted ten successful checks and zero errors; identity size `1,190`, SHA-256 `d67cdae8720aee14263cc74d328d07d47639628c9c3a9288f5edee73efc1f8f4`.

Terminal adjudication rejects that pass: the validator did not cross-check the frozen aggregate `645` against the authenticated matrix total `595`. Therefore independent validation is not accepted as complete.

### 49. Evidence retention

Source, registry, compilation, matrix, process, synthetic, compatibility, rehearsal, comparison, package, and rejected-final identities were retained before their corresponding cleanup actions.

### 50. Build/rehearsal cleanup

Attempt-1 fixtures, both final rehearsals, provisional builds, and the 117-entry build root were inventoried and removed with double-ENOENT checks. Process and descriptor survivor counts were zero. No cache or bytecode survived.

The rejected final-named PYZ and authority JSON were likewise removed and observed absent twice. The output root remains empty.

### 51. Source freeze

Freeze record identity: size `7,319`; SHA-256 `c6618c468bb8e76378625e3aa3bf0f7918e85f9a481ddd9a9db0f791e1e9b68c`.

All 20 sources were reopened no-follow and were not modified after freeze. Fatal inconsistency:

- Frozen record: `matrix_count=15`, `matrix_case_count=645`.
- Matrix suite: `matrix_count=15`, `total_case_count=595`.
- Qualification evidence: `total_case_count=595`.
- Exact per-matrix sum: `595`.

### 52. PYZ Build A

Created before rejection: size `2,948,746`; SHA-256 `1427192f8dccba1c719cad0f2ad474b638bcaadb5acff3a267dc9f6cbf053bc2`.

### 53. PYZ Build B

Created independently before rejection: size `2,948,746`; SHA-256 `1427192f8dccba1c719cad0f2ad474b638bcaadb5acff3a267dc9f6cbf053bc2`.

### 54. PYZ Build-A/B equality

Exact byte equality passed.

### 55. Final PYZ member closure

The rejected PYZ contained exactly 69 closed members. Member-registry identity: size `9,722`; SHA-256 `2c9e030929ee086d53c2083372344ae15ea4c4285fdda208d0c40fea57c0c7b4`. ZIP formatting itself passed.

### 56. Final authority-JSON identity

Rejected pre-delete identity: device `16777234`; inode `181743255`; mode `0400`; link count `1`; size `75,905`; SHA-256 `22eb6adb6d3932ee0283eae884e4f63f07503825ff5cc6d3a0bc28bc8f61036e`.

It mechanically bound the rejected PYZ but propagated the defective frozen count. It is nonauthoritative and was removed.

### 57. Frozen-PYZ requalification

The process exited `0` with empty stderr and produced an internal pass; process-record identity size `10,661`, SHA-256 `96ea4de194563da3521e0ea174f1fc3adce43fe78a9a4c02478ce01e9b6364f4`.

Terminal result: failed. The requalification linked identities but did not validate semantic agreement between the frozen aggregate count and the bound matrix evidence.

### 58. Confirmation full real audit was not executed

Confirmed. `run-full-audit` was never invoked.

### 59. Confirmation implementation verdict was not issued

Confirmed. No implementation ACCEPT/BLOCK adjudication was performed.

### 60. Harness-package status

`REJECTED_NONAUTHORITATIVE_MATRIX_COUNT_MISMATCH`.

No final executable or authority JSON remains.

### 61. Input-file closing equality

Passed after failure cleanup. Both input files retained their exact opening device, inode, mode, link count, size, and SHA-256 identities.

### 62. Failure-closeout capability and use

Failure-closeout capability existed and was used for Attempt 1. Terminal closeout recorded:

- First blocker: `/source_freeze/matrix_case_count = 645` contradicts `/matrix_suite/total_case_count = 595`.
- Classification: harness evidence-validation defect.
- Process custody: complete; zero survivors.
- Source posture: frozen and unmodified.
- Package posture: nonauthoritative, rejected, removed.
- Input closing equality: passed.
- Same-root retry: false.
- Attempt 3: not started.

### 63. Final PYZ path and identity

Rejected path:

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-output-r9ofqe2r/gen2-clean-source-external-independent-audit-harness-v1.pyz`

Pre-delete identity: device `16777234`; inode `181734804`; mode `0400`; link count `1`; size `2,948,746`; SHA-256 `1427192f8dccba1c719cad0f2ad474b638bcaadb5acff3a267dc9f6cbf053bc2`.

Current state: absent, verified twice.

### 64. Final authority-JSON path and identity

Rejected path:

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-output-r9ofqe2r/gen2-clean-source-external-independent-audit-harness-v1.authority.json`

Pre-delete identity: device `16777234`; inode `181743255`; mode `0400`; link count `1`; size `75,905`; SHA-256 `22eb6adb6d3932ee0283eae884e4f63f07503825ff5cc6d3a0bc28bc8f61036e`.

Current state: absent, verified twice.

### 65. Remaining uncertainty and nonclaims

No claim is made that the sealed Generation-2 implementation is acceptable or blocked, that its production source executes successfully, or that the current schema subject exists. No target audit, runtime validation rerun, live-service invocation, publication, deployment, or A6 activity occurred.

A corrected package requires a new clean attempt that adds independent cross-document count reconciliation before freeze and requalification. The frozen source and closed root were not silently reopened.

### 66. Explicit confirmation registry

Exact registry count: `81`.

```text
CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED=true
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED=true
BUNDLE_AUTHORITY_JSON_STRICTLY_VALIDATED=true
BUNDLE_ZIP_GRAMMAR_VALIDATED=true
BUNDLE_INDEX_MEMBER_MODEL_VALIDATED=true
BUNDLE_MEMBER_SET_CLOSED=true
EXACTLY_EIGHT_CURRENT_ROLES_RESOLVED=true
SEVEN_CONTENT_SNAPSHOT_ROLES_RESOLVED=true
ONE_BOUNDED_FAILURE_EVIDENCE_ROLE_RESOLVED=true
NO_LIVE_ROOT_ACCESSED=true
NO_HISTORICAL_HARNESS_SOURCE_USED=true
NO_IMPLEMENTATION_SOURCE_USED_AS_HARNESS_SOURCE=true
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED=true
HARNESS_AUTHORITY_SCOPE_CLOSED=true
HARNESS_NONAUTHORITY_SCOPE_CLOSED=true
QUALIFY_HARNESS_MODE_IMPLEMENTED=true
RUN_FULL_AUDIT_MODE_IMPLEMENTED=true
RUN_FULL_AUDIT_MODE_NOT_EXECUTED=true
FUTURE_FULL_AUDIT_INVOCATION_FROZEN=true
DEFECT_PREVENTION_REGISTRY_COMPLETE=true
FULL_AUDIT_PHASE_PLAN_COMPLETE=true
REPORT_SECTION_REGISTRY_FROZEN=true
REPORT_SECTION_COUNT_DERIVED=true
CONFIRMATION_NAME_REGISTRY_FROZEN=true
CONFIRMATION_COUNT_DERIVED=true
PRIMARY_VERDICT_SEPARATE_FROM_CONFIRMATIONS=true
SOURCE_ARCHITECTURE_COMPLETE=true
SOURCE_ATTEMPT_LIMIT_RESPECTED=true
FINAL_SOURCE_REGISTRIES_COMPLETE=true
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS=true
ALL_SOURCES_COMPILED=true
STATIC_SOURCE_GATES_PASSED=true
BUNDLE_AUTHORITY_MATRIX_PASSED=true
D01_D14_MATRICES_PASSED=true
PROCESS_CUSTODY_QUALIFICATION_PASSED=true
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED=true
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED=true
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED=true
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED=true
BOUNDED_COMPATIBILITY_REPLAY_PASSED=true
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT=true
COMPLETE_HARNESS_REHEARSAL_A_PASSED=true
COMPLETE_HARNESS_REHEARSAL_B_PASSED=true
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL=true
INDEPENDENT_HARNESS_VALIDATORS_PASSED=false
EVIDENCE_RETAINED_BEFORE_CLEANUP=true
HARNESS_OWNED_CLEANUP_SET_EQUALITY_PASSED=true
ALL_CREATED_CHILDREN_REAPED=true
ALL_CHILD_DESCRIPTORS_CLOSED=true
NO_PROCESS_SURVIVOR=true
NO_DESCRIPTOR_SURVIVOR=true
NO_CACHE_OR_BYTECODE_RETAINED=true
HARNESS_SOURCE_FROZEN=true
HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE=true
PYZ_DETERMINISTIC_FORMAT_FROZEN=true
PYZ_BUILD_A_CREATED=true
PYZ_BUILD_B_CREATED=true
PYZ_BUILD_A_B_BYTES_IDENTICAL=true
FINAL_PYZ_MEMBER_SET_CLOSED=true
FINAL_AUTHORITY_JSON_BINDS_PYZ=true
FROZEN_PYZ_REQUALIFICATION_PASSED=false
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED=true
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED=true
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED=true
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED=true
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED=true
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED=true
FINAL_PYZ_CREATED=false
FINAL_PYZ_MODE_0400=false
FINAL_PYZ_IDENTITY_VERIFIED=false
FINAL_AUTHORITY_JSON_CREATED=false
FINAL_AUTHORITY_JSON_MODE_0400=false
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED=false
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY=true
NO_NETWORK_CONTACT=true
NO_GIT_INVOCATION=true
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION=true
NO_TARGET_AUDIT_EXECUTED=true
NO_RUNTIME_VALIDATION_RERUN=true
NO_A6_ACTIVITY=true
NO_SUBAGENTS_CREATED=true
```
