Here is Codex's response:



# Independent audit report — Evidence Verification v1 CT-01 repair

## 1. Verdict

**BLOCK.** The current governing documents are coherent, provenance matches, all 31 specified mutations reject, and the qualifying tests and compatibility checks pass. One repairable CT-01 test defect remains: test 89 accepts a contradictory **second marked trusted-host contract with a different identifier**. The sole-authority rule is therefore not fully enforced. AP-06 is closed by four distinct auditor instances.

## 2. Response format

This is the complete audit report inline. Evidence links at the end are supplemental.

## 3. Exact target and input identities

- Implementation worktree: `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`; branch `codex/evidence-verification-v1`.
- HEAD `567bceced5df95ecfe787cc66038d463a854e12c`; tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`; sole parent `05dde14d185b6e022dcc169ef1a658a97961850f`; upstream absent.
- Canonical final manifest SHA-256 `0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0`; tracked binary-diff SHA-256 `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`.
- The request’s candidate manifest path was `provenance/run-1/provenance/manifest-run-1.json`. The implementation inventory **uniquely indexes** `provenance/manifest-run-1.json` instead, with the pinned hash; its closing gate repeats that hash. I used this explicit machine-readable index, as the request permits.
- Unchanged recipe ID `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`, SHA-256 `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`.
- Unchanged verifier: 40,121 bytes, SHA-256 `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`. Test source: 83,542 bytes, SHA-256 `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea`.
- Source-external caller SHA-256 `002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104`.
- Pinned Python was version 3.13.4, a regular single-link 119,424-byte file, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.
- Sealed A6D and amendment manifest SHA-256 values were respectively `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9` and `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`.
- The supplied implementation evidence and prior blocking-audit roots were present. The audit root was absent at opening and was created only after the opening gate passed.

## 4. Opening and closing provenance

The opening gate verified the physical worktree root, branch, HEAD, tree, parent, absent upstream, exact status classifications, modes, sizes, hashes, pinned inputs, and absence of Git operation markers or locks. It passed before correctness inspection.

The unchanged recipe ran twice into separate opening continuations and twice into separate closing continuations. All four owning commands exited 0 with empty stderr. Each stdout equaled its output file; all four files were byte-identical to the indexed canonical manifest. Opening and closing Git status had the same SHA-256, `7cbc827d5a678529209783f6bb9422fc43768a6221a181ceecf4b1316927d862`. The closing tracked diff retained SHA-256 `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`. Staged, deleted, renamed, and unmerged paths remained zero.

The implementation evidence inventory matched all 50 listed files and seven directories; its inventory is the fifty-first file. The candidate’s 389 pinned source-inventory files and index hash matched their earlier recorded identities on a read-only closing check. Caller, recipe, verifier, tests, A6D manifest, and amendment manifest retained their pinned hashes.

## 5. Repository identity and exact 13-path scope

Exactly four tracked paths were modified and nine paths were untracked. Each was regular, single-link, working mode `0644`, logical mode `100644`; there was no extra status path.

| StatusPathBytesSHA-256 |                                                                           |        |                                                                    |
| ---------------------- | ------------------------------------------------------------------------- | ------ | ------------------------------------------------------------------ |
| M                      | `PLANS.md`                                                                | 221718 | `fb3b2590103af1db07f17eac8fbe9c9e65420fd9d2c7fc6a8ccf9e7510e72750` |
| M                      | `.docs/system_overview/boundaries.md`                                     | 65156  | `643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e` |
| M                      | `.docs/system_overview/artifact_hygiene.md`                               | 13721  | `1a3e570167ab7b2238a75d43f678e7121e226950d6202b9e17259317bf5ce1c5` |
| M                      | `.docs/system_overview/capability_probing.md`                             | 10039  | `3333ea9b3c618ae95110273041396a2d7482891fac01b9d29e6b1609a2124d63` |
| ??                     | `.docs/system_overview/evidence_verification.md`                          | 18599  | `fc7d485728b8ba2815ae7a9f3e21b0859f0e35ba28083ba355a64047857f5875` |
| ??                     | `tools/evidence_verify/verify_v1.py`                                      | 40121  | `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c` |
| ??                     | `tools/evidence_verify/test_verify_v1.py`                                 | 83542  | `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea` |
| ??                     | `tools/evidence_verify/registry_v1.json`                                  | 585    | `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880` |
| ??                     | `tools/evidence_verify/layouts/a6d_successor_v1.json`                     | 892    | `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc` |
| ??                     | `tools/evidence_verify/layouts/a6d_amendment_v1.json`                     | 856    | `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4` |
| ??                     | `tools/evidence_verify/layouts/a6_policy_v1.json`                         | 1015   | `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8` |
| ??                     | `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt` | 3338   | `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98` |
| ??                     | `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`  | 14418  | `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f` |

## 6. Four distinct auditor instances

The first three started concurrently. After `/root/contract_authority` completed, `/root/security_artifacts` started as a new fourth instance. All four completed; retries: **zero**.

| InstanceAssigned perspectiveResult |                                           |                                        |
| ---------------------------------- | ----------------------------------------- | -------------------------------------- |
| `/root/contract_authority`         | Contract, authority, complete documents   | No blocker; one observation            |
| `/root/structured_parser`          | Independent parser and 31-case matrix     | 31/31 intended rejections; no blocker  |
| `/root/test_validation`            | Test 89 and producer validation           | **TV-01 blocking finding**             |
| `/root/security_artifacts`         | Security, filesystem, evidence, artifacts | No blocker; one path-index observation |

No auditor ran Git or created a nested agent.

## 7. CT-01 repair summary

The repair establishes one current, private structured v1 contract in `evidence_verification.md`, three bounded references, and test 89’s complete 22-field validation. That closes the original isolated-phrase problem for edits to the recognized v1 block. It does **not** close the requirement to reject a second marked trusted-host authority under another identifier. The current documents contain no such second block; the defect is in regression detection.

## 8. Authoritative contract block

The sole current block is at `.docs/system_overview/evidence_verification.md:114–118`. Its introduction at line 112 makes it private documentation and assurance material and expressly excludes product schema, runtime protocol, public API, readiness decision, and execution authority. Surrounding prose preserves the supported-local trusted-host premise and disclaims atomic loaded-object custody, transient malicious trusted-principal replacement coverage, hostile/shared hosts, production attestation, and fallback launchers.

## 9. Exact parsed field map
```
{"all_interpreter_installation_writers_trusted":true,"atomic_loaded_object_binding_claimed":false,"foreground_validation_process_trusted":true,"interpreter_observation_authority":"corroboration-only","interpreter_trust_model":"trusted-host-stable-path-v1","kernel_and_process_execution_substrate_trusted":true,"operator_controlled_host_required":true,"out_of_contract_argv_and_environment_untrusted":true,"pinned_interpreter_installation_and_ancestors_trusted":true,"preseal_candidate_untrusted":true,"production_host_attestation":false,"remotely_administered_hostile_host_supported":false,"schema":"execution-substrate.evidence-verification.trusted-host-contract.v1","scope":"supported-local","shared_or_adversarial_host_supported":false,"supplied_repository_and_provenance_inputs_trusted":true,"target_content_untrusted":true,"target_controlled_script_paths_untrusted":true,"transient_trusted_principal_replacement_covered":false,"undocumented_launcher_fallback_authorized":false,"unproven_package_registry_layout_inputs_untrusted":true,"verifier_result_authority":"structural-evidence-only"}
```

## 10. JSON, markers, and fences

The current block has one exact v1 begin/end pair, one lowercase `json` fence, one sorted compact ASCII JSON line and terminal LF. Independent decoding rejected duplicate keys and non-JSON constants; exact names, types, and values matched all 22 supplied fields. No second authoritative block exists in the current four documents. The blocking gap concerns what test 89 would accept **after a future alternate-ID block is added**.

## 11. Consumer references

`PLANS.md:3069–3073`, `artifact_hygiene.md:212–216`, and `capability_probing.md:201–205` each have exactly one bounded reference. Each identifies the v1 contract and `evidence_verification.md` as sole authoritative writer and says it does not redefine, override, narrow, or widen the contract. None currently contains a full duplicate contract, local override, or authoritative block.

## 12. Complete-document contradiction review

Review of the complete governing documents and their relevant surrounding passages found no current contradictory claim of atomic interpreter custody, hostile-host support, production attestation, observation-as-proof, undocumented fallback, exclusion of installation writers, or readiness/execution/commit authority. Explanatory prose is subordinate to the sole structured contract. Prose outside marked sections still requires editorial review on later changes; test 89 is not claimed to interpret arbitrary prose.

## 13. Test 89 and oracle independence

`InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim` retains its identity. Its hard-coded `TRUST_FACTS` map is not read from the document under test. The validator checks exact v1 section structure, strict JSON keys/types/values, canonical encoding, three reference sections, and the pinned verifier SHA. It loops through 31 mechanism-specific mutations with expected error reasons. The test and its mutation generator share `TRUST_FACTS`; the audit-owned parser used the separately supplied map, reducing that shared-oracle risk.

**TV-01 causal:** I appended an audit-owned, syntactically valid `trusted-host-contract.v2` marked block to a copy of the authoritative document. It set `atomic_loaded_object_binding_claimed` to `true` while leaving the v1 block and references intact. `_validate_trust_documents` returned the v1 facts **without error**. The code counts and rejects only markers made from the exact v1 ID. The same second block can be placed in a consumer. This directly defeats the stated sole-authority check.

## 14. Independent 31-case contradiction matrix

An audit-owned parser and copies rejected every specified case for its intended reason; all 31 reasons agreed with the implementation ledger. The following is the complete case result, with `contract_value:*`, `contract_type:*`, and reference errors naming the affected field or document.

| #MutationIndependent and producer rejection reason |                                                 |                                                                        |
| -------------------------------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------- |
| 1                                                  | Atomic loaded-object binding true               | `contract_value:atomic_loaded_object_binding_claimed`                  |
| 2                                                  | Transient trusted-principal replacement covered | `contract_value:transient_trusted_principal_replacement_covered`       |
| 3                                                  | Shared/adversarial host supported               | `contract_value:shared_or_adversarial_host_supported`                  |
| 4                                                  | Remotely hostile administration supported       | `contract_value:remotely_administered_hostile_host_supported`          |
| 5                                                  | Production attestation true                     | `contract_value:production_host_attestation`                           |
| 6                                                  | Observations upgraded to proof                  | `contract_value:interpreter_observation_authority`                     |
| 7                                                  | Installation writers untrusted                  | `contract_value:all_interpreter_installation_writers_trusted`          |
| 8                                                  | Fallback authorized                             | `contract_value:undocumented_launcher_fallback_authorized`             |
| 9                                                  | Readiness authority                             | `contract_value:verifier_result_authority`                             |
| 10                                                 | Execution authority                             | `contract_value:verifier_result_authority`                             |
| 11                                                 | Commit authority                                | `contract_value:verifier_result_authority`                             |
| 12                                                 | Widened scope                                   | `contract_value:scope`                                                 |
| 13                                                 | Wrong contract ID                               | `contract_value:schema`                                                |
| 14                                                 | Boolean replaced by string                      | `contract_type:operator_controlled_host_required`                      |
| 15                                                 | String replaced by boolean                      | `contract_type:scope`                                                  |
| 16                                                 | Missing mandatory key                           | `contract_missing_key:scope`                                           |
| 17                                                 | Unknown key                                     | `contract_unknown_key:undocumented_extra`                              |
| 18                                                 | Duplicate key                                   | `contract_duplicate_key:scope`                                         |
| 19                                                 | Duplicate **v1** authoritative block            | `authoritative_section_count`                                          |
| 20                                                 | **v1** authoritative block in consumer          | `unauthorized_authoritative_block:PLANS.md`                            |
| 21                                                 | Wrong consumer ID                               | `reference_contract_id:PLANS.md`                                       |
| 22                                                 | Missing reference                               | `reference:.docs/system_overview/artifact_hygiene.md_section_count`    |
| 23                                                 | Local override                                  | `reference_local_override:.docs/system_overview/capability_probing.md` |
| 24                                                 | Contradiction inside authority section          | `authoritative_section_content`                                        |
| 25                                                 | Contradiction inside reference section          | `reference_unexpected_content:PLANS.md`                                |
| 26                                                 | Malformed marker                                | `authoritative_section_count`                                          |
| 27                                                 | Malformed JSON fence                            | `contract_fence_structure`                                             |
| 28                                                 | Noncanonical JSON                               | `contract_noncanonical_json`                                           |
| 29                                                 | Duplicate reference                             | `reference:PLANS.md_section_count`                                     |
| 30                                                 | Wrong sole-writer declaration                   | `reference_writer:PLANS.md`                                            |
| 31                                                 | Consumer overriding declaration                 | `reference_nonoverriding:PLANS.md`                                     |

The additional alternate-ID causal in §13 was **not** among these 31 and is the blocker.

## 15. Three targeted test-89 runs

All three qualifying invocations used pinned Python with `-I -S -B`, umask `077`. Each owning command exited 0; ran exactly one test; had zero failures, errors, and skips; and left the repository snapshot unchanged. Each stderr SHA-256 was `93b3fe05199866a6e5a42868808df224abda415e7573da99c3a1c0edf22e8d83`. Source inspection confirms the test iterates its 31 cases. The passing results do not negate the extra alternate-ID causal.

## 16. Exact 89-test identity set

The four qualifying suite runs discovered the same set: `ClosureCausals.` followed by each of these **exact 88 method names**, plus the final fully named identity shown after the list:
```
test_01_valid_preseal, test_02_valid_sealed, test_03_missing_manifest,
test_04_missing_sidecar, test_05_wrong_sidecar, test_06_missing_payload,
test_07_unexpected_payload, test_08_wrong_mode, test_09_wrong_size,
test_10_wrong_hash, test_11_wrong_link_count, test_12_directory_mode,
test_13_symlink_every_depth, test_14_special_every_depth,
test_15_post_manifest_same_bytes, test_16_unknown_layout,
test_17_wrong_registered_hash, test_18_missing_required_layout_entry,
test_19_unexpected_layout_entry, test_20_stage_confusion,
test_21_arbitrary_layout_option, test_22_readiness_not_interpreted,
test_23_zero_writes, test_24_repeated_canonical_output,
test_25_source_inside_target, test_26_own_container,
test_27_independent_materialization, test_28_historical_defect,
test_29_fourth_layout_without_verifier_edit, test_30_exact_closeout_identities,
test_31_historical_amendment_exact_modes, test_32_closing_helper_0600_rejects,
test_33_postseal_helper_0600_rejects, test_34_helper_other_modes_reject,
test_35_unrelated_fixed_json_executable_rejects,
test_36_unrelated_fixed_markdown_executable_rejects,
test_37_unenumerated_executable_rejects,
test_38_optional_executable_has_no_required_authority,
test_39_other_layout_spec_bytes_unchanged,
test_40_amendment_registry_hash_mismatch_rejects,
test_41_physical_target_ancestry_and_aliases,
test_42_physical_candidate_ancestry_and_aliases,
test_43_literal_lf_preseal_rejections, test_44_literal_lf_sealed_rejections,
test_45_json_depth_escapes_and_cli_failure, test_46_manifest_declared_budgets,
test_47_scan_budgets_before_read, test_48_isolated_missing_root,
test_49_expected_path_symlink_and_special, test_50_bounded_decimal_parser,
test_51_capability_operation_failures_are_canonical,
test_52_json_source_size_and_spec_failure,
test_53_manifest_stat_caps_precede_body_read,
test_54_manifest_stream_early_row_path_and_count_rejection,
test_55_exact_maximum_count_and_path,
test_56_seal_and_candidate_structural_budgets,
test_57_sidecar_pre_read_size_and_exact_malformed_content,
test_58_decimal_complete_lexical_classification,
test_59_invalid_spec_paths_never_open_target,
test_60_source_by_value_external_source_both_stages,
test_61_direct_source_inside_target_both_stages,
test_62_final_source_symlink_to_target_both_stages,
test_63_parent_symlink_to_target_source_both_stages,
test_64_hardlinked_source_to_target_both_stages,
test_65_source_package_beneath_target, test_66_target_beneath_source_package,
test_67_source_package_equals_target,
test_68_case_alias_of_prohibited_source_relationship,
test_69_source_identity_changes_before_close,
test_70_source_disappears_before_close,
test_71_unsupported_source_nofollow_or_parent_traversal,
test_72_same_source_bytes_distinct_inode_admitted,
test_73_external_source_with_symlinked_parent_rejects,
test_74_relative_direct_script_invocation_rejects,
test_75_final_symlink_to_external_source_rejects,
test_76_direct_and_symlinked_script_launches_are_invocation_errors,
test_77_stdin_and_dev_fd_launches_are_invocation_errors,
test_78_missing_reordered_or_extra_application_arguments,
test_79_extra_combined_or_reordered_interpreter_options,
test_80_source_package_one_byte_mismatch_rejects,
test_81_invalid_package_source_and_size_reject,
test_82_captured_argv_survives_live_argv_mutation,
test_83_package_source_replaced_after_argv_construction,
test_84_unicode_source_round_trip_and_no_output_leak,
test_85_no_package_source_authority_from_file_presence,
test_86_closing_source_validation_failure_is_race,
test_87_file_present_launch_state_rejects,
test_88_missing_isolation_site_or_bytecode_flag_rejects
InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim
```

## 17. Both umask-077 suite results

`full-077-qualified-1` and `full-077-qualified-2` each exited 0 with 89 tests, zero failures/errors/skips, and the exact set above. Their stderr SHA-256 values were `5f02e0199909e5275de0dff72782d67c51d496cd2a2a1918f2a7e366fd1173e8` and `9457d2e00fd1ce2c6e1c6b8e1005126883416222b41004e21e485a6d3896dca6`. The 478-entry repository snapshot hash remained `a974f018be10b44b73f1559ac663b4d4bd18336bbf777eac25d0ab26ed1411dc` before and after each.

## 18. Both umask-022 suite results

`full-022-qualified-1` and `full-022-qualified-2` had the same 0/89/0/0/0 outcome and identity set. Their stderr SHA-256 values were `332c429e711593689992a85df2ec09b6b39980270d53366a7ee7e3a57d95c26c` and `de61bb3938592dc174bcbb0020993bdf61e11a41845b33e670f3d5c259105619`. The same repository snapshot hash remained unchanged.

Four earlier exploratory suite runs without the required outer `-I -S -B` flags exited 1 with 17 failures each. They are retained separately and **not** counted as qualifying results; the corrected owning commands passed. AST parsing, strict canonical registry/layout JSON and hashes, historical fixture parsing/hashes, and rooted `git diff --check` also passed.

## 19. Verifier and caller unchanged-byte review

The verifier and source-external caller retained their pinned hashes. Source review confirmed launch protocol v2 takes authenticated verifier source by value, while direct-script, stdin, and `/dev/fd` launches do not qualify. Verifier source is compared with package bytes for consistency, and registry/layout hashes are independently pinned by the caller. Interpreter observations corroborate the trusted-host premise; they do not establish atomic loaded-object binding. Verifier output and caller records remain structural evidence. No fallback launcher, verifier file-write path, verifier network call, or product authority was found.

## 20. Sealed A6D results

Two audit-owned caller runs exited 0, with empty verifier stderr, accepted canonical results, and byte-identical verifier stdout SHA-256 `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`. Both caller records state atomic binding false, transient replacement coverage false, hostile/shared-host support false, and observations corroboration-only. Per-invocation target, package, and TMPDIR snapshots were unchanged; the sealed manifest retained its pinned hash.

## 21. Sealed amendment results

Two corresponding runs exited 0, had empty verifier stderr, accepted canonical results, and byte-identical verifier stdout SHA-256 `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`. The same nonclaims and unchanged per-invocation snapshots held; the amendment manifest retained its pinned hash.

## 22. Synthetic A6 results

An audit-owned fixture was built from the inspected A6 layout and manifest-writer rules. Pre-seal runs 1 and 2 exited 0 with empty stderr and identical verifier stdout SHA-256 `e4d18d66b1b893c6f7a6221e33b862aa45c4533c31d8ffde6e04547c6d38b600`. After sealing **only that audit-owned fixture**, sealed runs 1 and 2 exited 0 with empty stderr and identical stdout SHA-256 `e8ed4d6c387f8c6b109c9421d93b4e4981e66113f61bb20b7f1e91941fa97b4f`. Target, package, candidate when applicable, and TMPDIR snapshots stayed unchanged during each verifier invocation. The audit-owned fixture and candidate were removed during cleanup.

## 23. Source-by-value SEC-02 causal

A separate audit-owned target contained a target-controlled Python source file that would write a marker if executed. A valid source-by-value pre-seal launch passed, with empty stderr and unchanged snapshots; the marker never appeared. Launching the legitimate verifier in the predecessor direct-script shape returned exit 2, canonical `reject`/`INVOCATION`, and empty stderr. This establishes the causal for the tested target; it does not claim resistance to malicious replacement of an in-boundary trusted interpreter.

## 24. No-write and deterministic-output evidence

All seven qualifying test runs preserved the same whole-worktree snapshot before and after. The four sealed historical and four synthetic verifier invocations preserved their watched target, package, candidate, and TMPDIR snapshots. Repeated verifier outputs were byte-identical within each target and stage. The verifier source inspection found no writer or network path. Caller record files were written only in the audit root by the source-external evidence caller.

## 25. Implementation-evidence review

The implementation inventory matched every retained file’s size, hash, mode, and single-link status. Its final manifest pairs are identical; the closing gate matches the live 13-path identity and reports no lock, operation marker, or unsupported type. The summary selects three final targeted and four final full-suite passes. Failed and superseded wrapper, collector, preliminary targeted, and missing-`-S` full-suite attempts remain separately indexed. The 31-case ledger records mechanism-specific reasons. Verifier and caller are reported unchanged. The implementation did not falsely claim that this repair reran acceptance-bearing A6D/amendment compatibility, promote a prior audit to proof for changed bytes, or classify AP-06 as patch behavior.

## 26. Authority adjudication

The verifier remains an ES-owned **Bounded slice rule** for structural closure evidence. Historical A6D verifiers remain labeled **Temporary compatibility edges**. The trusted-host object is private documentation and assurance, not a public or runtime schema. Proof output and caller records are evidence/projection. No run truth, admission, orchestration, product, durable-state, readiness, execution, commit, or publication authority was granted; no cross-repository framework owner or proof-harness product role appeared.

## 27. Artifact findings

A read-only scan counted 384 repository files excluding the worktree `.git` control file, matching the producer scan. It found no `__pycache__`, `.pyc`, `.pyo`, `.pytest_cache`, database, journal, lock, unsupported file type, or unexpected executable under `tools/evidence_verify/`. The historical `.py.txt` fixtures remain inert mode-`0644` text. Existing `.examples/*/dist` tarballs and tracked `.out/Dockerfile` are outside the 13-path patch; they are not new audit artifacts.

## 28. Prior-finding reconciliation

| ID or groupCurrent adjudication |                                                                                                                                                                                                                                                |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **CT-01**                       | **Open:** v1 structured contract and 31 cases pass, but TV-01 defeats sole-authority regression detection.                                                                                                                                     |
| **AP-06**                       | **Closed:** four separate instances completed in the required scheduling order.                                                                                                                                                                |
| SEC-01                          | Supported-local trusted-host contract and explicit nonclaims are coherent on current bytes.                                                                                                                                                    |
| SEC-02                          | Fresh target-marker source-by-value causal passed.                                                                                                                                                                                             |
| VC-01 / SEC-A1                  | Fresh static, launch-shape, exact-byte, and compatibility checks passed; no new verifier/caller defect observed.                                                                                                                               |
| EV-01 through EV-09             | Current structural, provenance, static, suite, and compatibility controls passed. The supplied prior audit root contains machine evidence but no retained narrative mapping each historical ID; individual historical closure is not inferred. |
| F-01 through F-04               | No current regression found in the inspected boundary and artifact checks; individual historical finding text was unavailable for stronger ID-specific claims.                                                                                 |
| PP-01                           | Current parent-only Git record and provenance replay conform.                                                                                                                                                                                  |
| PE-02                           | Current supplied-evidence inventory and selected final-attempt separation conform.                                                                                                                                                             |
| TA-03                           | Current test identity, qualifier, and mutation checks conform subject to TV-01.                                                                                                                                                                |
| AP-04 / AP-05                   | No current process-boundary violation observed; the prior ID-specific narratives were unavailable.                                                                                                                                             |
| CA-01                           | Current caller and authority nonclaims are coherent; no atomic-custody inference is made.                                                                                                                                                      |

## 29. Severity-ranked residual findings

**AUDIT FINDING**

- **ID:** TV-01
- **Type:** Contradiction-resistance gap in test 89
- **Severity:** medium
- **Classification:** Bounded slice rule; CT-01 documentary regression detection
- **Current contract or strategic target:** Exactly one private authoritative trusted-host contract across all four governing documents
- **Path and line:** `tools/evidence_verify/test_verify_v1.py:1428–1454,1539–1550,1621–1635`; `.docs/system_overview/evidence_verification.md:112–118`
- **Evidence:** An audit-owned second balanced `trusted-host-contract.v2` block with `atomic_loaded_object_binding_claimed:true` was appended to a document copy. `_validate_trust_documents` accepted it and returned unchanged v1 facts.
- **Reachable mechanism:** The validator counts only exact v1 markers; the existing duplicate-block mutation also duplicates only v1.
- **Impact:** A future competing marked authority can pass test 89 and the full suite, contrary to the sole-authority requirement.
- **Required correction:** Scan trusted-host authority markers across identifiers in all four documents; reject an extra or consumer-local block with a specific reason; add an alternate-ID mutation.
- **Containment/nonclaim:** Current documents have no duplicate; verifier and caller behavior is unchanged. This grants no atomic custody, hostile-host, readiness, execution, commit, or publication claim.
- **Uncertainty:** The demonstrated causal covers this alternate-ID form, not arbitrary unmarked prose.
- **Category:** patch defect
- **Blocking:** **yes**

Nonblocking observations: `CA-OBS-01` concerns future prose outside marked sections; `SEC-ART-OBS-01` records the explicitly indexed flat final-manifest path.

## 30. Minority findings and parent resolution

The contract and parser auditors found no blocker in the **current document bytes**; the test auditor identified TV-01. I reproduced TV-01 on an audit-owned copy, so I adopt it as blocking. The contract auditor’s future-prose concern does not describe a current contradiction. The security auditor’s manifest-path observation meets the request’s explicit-index exception and is not a provenance mismatch.

## 31. Remaining uncertainty and explicit nonclaims

This audit does not establish atomic custody of the loaded Python executable, protection against a malicious process already holding trusted writer authority, production host attestation, or support for shared, hostile, remotely administered, or uncertain hosts. It does not infer product readiness or commit fitness from verifier results.

The audit did not capture a new whole-tree opening snapshot of every external prior-audit and candidate artifact. It checked pinned anchors, the implementation’s complete inventory, historical sealed manifests, per-invocation no-write snapshots, and the candidate’s earlier pinned 389-file inventory and index at close. No external mutation was observed; full opening-to-closing metadata identity for every external root is not independently claimed.

## 32. Audit-created paths and cleanup

The audit wrote only under `/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1`. Its seven top-level directories are `opening/`, `provenance/`, `perspectives/`, `validation/`, `findings/`, `closeout/`, and `tmp/`. The final inventory records 20 directories and 116 files including the inventory itself, with no unsupported type. It retains four perspective reports, independent parser/matrix evidence, test and compatibility records, TV-01, opening/closing provenance, and the complete Git record. Only the audit-owned synthetic and SEC-02 fixture directories and their candidate manifests were removed; no repository or supplied-evidence path was removed.

## 33. Complete Git-process record

**Common full command prefix for every invocation:** `git -C "/Users/ds/Repositories/Execution Substrate - evidence-verification-v1"`. Every invocation’s cwd was that same worktree. Every invocation explicitly carried:
```
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

In the record below, each hash key expands to its complete SHA-256 value:

| KeySHA-256       |                                                                    |
| ---------------- | ------------------------------------------------------------------ |
| `Ø`              | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `root`           | `1f804a58891bbf9c02cb9327b9e04cdfae012f7c33e8da514358746fd73be1de` |
| `branch`         | `ea96655087a20eebab1426d7c0d142a4b9ffd1e84bb91454161887efb15cb3af` |
| `head`           | `35a27ba96b6a5737a238ef7b1d2aec9b6ba0817da8a0b0caef6e56e4b08197c7` |
| `tree`           | `90aedb18ba194cdb9aeb6c160585f05f3094ecad77b7d4eadd0c339bd11d342e` |
| `parent`         | `a164dc591945b493ffb184e7b740b7adeadad166b923ae80711f7ba779c107cd` |
| `upstream-error` | `159386b3dbc19a37b4f8f5f1f02e1fe4ba6aef96364cc2ece40983d4075981d2` |
| `status`         | `7cbc827d5a678529209783f6bb9422fc43768a6221a181ceecf4b1316927d862` |
| `ls`             | `e86ee3a2908858dc5647093a7563f75c279b802b3fc97d8fb43c445ced867407` |
| `diff`           | `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb` |

For every row below, the listed arguments follow the common prefix. Columns give **exit / stdout SHA key / stderr SHA key**. Thus they specify each full argv, cwd, environment, exit, and both stream hashes.

| IDPhaseArgumentsExit / stdout / stderr |                                                                        |                                                                             |                                 |
| -------------------------------------- | ---------------------------------------------------------------------- | --------------------------------------------------------------------------- | ------------------------------- |
| 01                                     | opening gate                                                           | `rev-parse --show-toplevel`                                                 | `0 / root / Ø`                  |
| 02                                     | opening gate                                                           | `symbolic-ref --quiet --short HEAD`                                         | `0 / branch / Ø`                |
| 03                                     | opening gate                                                           | `rev-parse HEAD`                                                            | `0 / head / Ø`                  |
| 04                                     | opening gate                                                           | `rev-parse HEAD^{tree}`                                                     | `0 / tree / Ø`                  |
| 05                                     | opening gate                                                           | `rev-list --parents -n 1 HEAD`                                              | `0 / parent / Ø`                |
| 06                                     | opening gate                                                           | `rev-parse --verify @{upstream}`                                            | `128 / Ø / upstream-error`      |
| 07                                     | opening gate                                                           | `status --porcelain=v1 --untracked-files=all -z`                            | `0 / status / Ø`                |
| 08                                     | opening gate                                                           | `diff --cached --name-status`                                               | `0 / Ø / Ø`                     |
| 09                                     | opening gate                                                           | `ls-files -s --` followed by all 13 paths in the exact order of §5          | `0 / ls / Ø`                    |
| 10                                     | opening gate                                                           | `diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --` | `0 / diff / Ø`                  |
| 11, 17, 24, 30                         | opening recipe 1, opening recipe 2, closing recipe 1, closing recipe 2 | `branch --show-current`                                                     | each `0 / branch / Ø`           |
| 12, 18, 25, 31                         | same respective recipe runs                                            | `rev-parse HEAD`                                                            | each `0 / head / Ø`             |
| 13, 19, 26, 32                         | same respective recipe runs                                            | `rev-parse HEAD^{tree}`                                                     | each `0 / tree / Ø`             |
| 14, 20, 27, 33                         | same respective recipe runs                                            | `rev-parse --verify @{upstream}`                                            | each `128 / Ø / upstream-error` |
| 15, 21, 28, 34                         | same respective recipe runs                                            | `status --porcelain=v1 --untracked-files=all -z`                            | each `0 / status / Ø`           |
| 16, 22, 29, 35                         | same respective recipe runs                                            | `diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --` | each `0 / diff / Ø`             |
| 23                                     | static gate                                                            | `diff --check`                                                              | `0 / Ø / Ø`                     |
| 36                                     | closing gate                                                           | `rev-list --parents -n 1 HEAD`                                              | `0 / parent / Ø`                |
| 37                                     | closing gate                                                           | `diff --cached --name-status`                                               | `0 / Ø / Ø`                     |
| 38                                     | closing gate                                                           | `status --porcelain=v1 --untracked-files=all -z`                            | `0 / status / Ø`                |
| 39                                     | closing gate                                                           | `diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --` | `0 / diff / Ø`                  |

The grouped recipe rows each represent four separately recorded invocations, for **39 total**. The expected upstream failure is evidence of absent upstream, not a process failure. The audit parent alone executed Git; all Git invocations were rooted in `IMPL_R`.

## 34. Explicit process confirmations

Repository mutation **not performed**. Formatting **not performed**. Repair **not performed**. Repository cleanup **not performed**. Staging **not performed**. Commit **not performed**. Push **not performed**. PR or merge **not performed**. A6 **not restarted**. Product/live services **not invoked**. Network contact **not performed**. Linux binary execution **not performed**. Nested subagents **not created**.

Supplemental evidence: [TV-01 causal](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1/validation/alternate-authority-causal.json), [independent 31-case matrix](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1/validation/independent-contradiction-matrix.json), [test summary](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1/validation/test-summary-qualified.json), [closing provenance](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1/closeout/closing-provenance.json), and [complete machine-readable Git record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1/closeout/git-process-complete.json).
