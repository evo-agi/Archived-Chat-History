## Assessment

That one-line response is **not a usable audit report**.

Treat the attempt as stopped and nonqualifying, but **do not infer that the repository or correction capsule is defective**. `AUDIT_PROVENANCE_MISMATCH` means the opening target could not be established exactly, so correctness inspection should not proceed. It does not identify whether the mismatch was:

- genuine repository or supplied-root drift;
- a wrong expected identity in the prompt;
- a missing or ambiguous audit input;
- a pre-existing audit root;
- an audit-process boundary failure;
- or an audit-owned provenance-recording defect.

The response also omits the first failing gate, expected and observed values, commands actually run, audit-created paths, mutation status, and whether any auditors or correctness checks started. Those facts must not be reconstructed from inference later—the exact problem that invalidated the preceding audit lineage.  The operating protocol requires an audit to stop before correctness inspection on provenance mismatch and return a documented verdict, not merely the verdict token. 

Do **not** send this to implementation and do **not** start another audit yet. First obtain a closeout report from the same Codex chat.

## Send this to the same Codex chat

```text
CLOSEOUT ONLY — DO NOT CONTINUE, RESTART, OR REPAIR THE AUDIT

Your response was only:

AUDIT_PROVENANCE_MISMATCH

That verdict stops the audit, but it is not a sufficient audit report.

Do not change the verdict. Do not begin correctness inspection. Do not start
auditors. Do not rerun tests, validation, provenance recipes, or causal checks.
Do not mutate, clean, chmod, remove, restore, stage, commit, push, or otherwise
alter the candidate repository, any supplied root, or any prior audit root.

Use only:

- the command transcript and results already produced by this attempt;
- contemporaneous audit-owned records already created by this attempt, if any;
- facts directly retained in the current conversation.

You may read audit-owned records from this attempt only when necessary to
report them. Do not perform new repository or supplied-root inspection merely
to fill a missing record.

Return a complete inline closeout report with these sections:

1. Verdict

   AUDIT_PROVENANCE_MISMATCH

2. Exact first failing gate

   Identify the first failed opening requirement and classify it as exactly one
   of:

   - candidate repository identity mismatch
   - candidate governed inventory mismatch
   - candidate path/mode/size/hash mismatch
   - supplied-root identity or closure mismatch
   - expected-input path missing
   - audit-root freshness mismatch
   - process-boundary violation
   - required process-record failure
   - prompt inconsistency
   - another precisely named category

3. Exact expected versus observed values

   Give the exact path or object involved and every material expected and
   observed value:

   - path
   - existence/type
   - device/inode when relevant
   - mode/link count
   - byte size
   - SHA-256
   - branch/HEAD/tree/parent/upstream when relevant
   - membership or manifest count when relevant

   State whether all checks preceding that gate passed.

4. Causal explanation

   Explain why the observed difference requires
   AUDIT_PROVENANCE_MISMATCH rather than BLOCK.

   State whether the mismatch reflects:

   - actual target drift;
   - an incorrect expected value in the audit prompt;
   - an ambiguous or unavailable input;
   - an audit-process error;
   - or an audit-evidence defect.

   Do not infer or reconstruct a cause that was not retained.

5. Complete process account

   List every process started after the audit epoch, in execution order, with:

   - full argv
   - cwd
   - explicit environment
   - exit or signal
   - stdout and stderr size and SHA-256
   - whether a contemporaneous start/outcome record exists
   - paths read or written

   If any required field was not retained, state:

   UNRECOVERABLE FROM RETAINED EVIDENCE

   Do not reconstruct it by rerunning the command.

6. Audit-created paths

   List every path created by this attempt, including:

   - audit root
   - bootstrap/process records
   - temporary paths
   - stdout/stderr captures
   - partial reports or manifests

   Give current type, mode, size, and disposition where already retained.

7. Mutation and contamination adjudication

   State separately whether the attempt performed or may have performed:

   - repository-content mutation
   - Git-index or Git-administration mutation
   - supplied-root mutation
   - audit-root mutation
   - cache, bytecode, or temporary-artifact creation
   - cleanup or removal
   - chmod or normalization

   Do not certify unchanged state if no closing observation exists.

8. Audit progression at stop

   State whether any of the following began:

   - correctness inspection
   - auditor creation
   - causal execution
   - repository tests
   - compatibility checks
   - closing provenance

   Give auditor identities and statuses if any auditor was started.

9. Salvageability

   State whether the attempt’s retained evidence is sufficient to explain the
   mismatch completely.

   Choose exactly one:

   - COMPLETE_MISMATCH_EVIDENCE_RETAINED
   - PARTIAL_MISMATCH_EVIDENCE_RETAINED
   - NO_QUALIFYING_MISMATCH_EVIDENCE_RETAINED

   This classification does not change the primary verdict.

10. Required next action

   Choose exactly one and explain why:

   - reconcile an actual target/input identity before another audit;
   - correct an audit-prompt identity and run a wholly fresh audit;
   - discard this process-defective attempt and run a wholly fresh audit;
   - obtain a missing exact input before another audit.

   Do not recommend repository implementation unless the retained evidence
   proves repository bytes themselves differ from the authorized target.

11. Explicit confirmations

   Include truthful values for:

   REPOSITORY_MUTATION_NOT_PERFORMED
   SUPPLIED_EVIDENCE_MUTATION_NOT_PERFORMED
   CORRECTION_CAPSULE_MUTATION_NOT_PERFORMED
   BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
   CORRECTNESS_INSPECTION_NOT_PERFORMED
   AUDITORS_NOT_STARTED
   TESTS_NOT_RUN
   FORMATTING_NOT_PERFORMED
   REPAIR_NOT_PERFORMED
   STAGING_NOT_PERFORMED
   COMMIT_NOT_PERFORMED
   PUSH_NOT_PERFORMED
   A6_NOT_STARTED
   NETWORK_CONTACT_NOT_PERFORMED
   NESTED_SUBAGENTS_CREATED: 0

   Replace any confirmation that cannot truthfully be made with:

   <NAME>: NOT_CERTIFIED

Do not create missing evidence now. Do not silently replace missing records
with memory, prose, or inference.
```

Once that report arrives, the next action should be mechanical:

- **Actual identity drift:** reconcile the target before any new audit.
- **Wrong prompt identity or missing input:** correct only the audit inputs, then run a fresh audit.
- **Process or recording failure:** permanently discard this attempt and rerun the same exact target in a new audit chat.
- **No retained causal detail:** treat it as a process-defective attempt, not as evidence against the implementation.

### Sources

The preceding reconciliation established that missing auditor and process records cannot be replaced with retrospective inference, even when the retained parent records otherwise identify the intended target.  The project protocol likewise requires provenance mismatch to stop before implementation judgment. 

**Confidence:** 0.995 that the one-line response is insufficient; 0.98 that closeout reconciliation—not implementation—is the correct immediate next step.
