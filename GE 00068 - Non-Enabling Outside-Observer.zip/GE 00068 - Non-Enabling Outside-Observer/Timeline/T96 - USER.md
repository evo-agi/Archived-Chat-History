Here is Codex's response:

REPAIR10I\_A6R\_RECONNAISSANCE\_READY

The reconnaissance child is sealed and post-seal verified.

Key findings:

- Failed control: 2,753 pass / 137 fail / 8 skip; packages 14 / 11 / 23; zero semantic failures or unknown diagnostics.
- Sole peer failure: `read_policy_verified=false`.
- Root lifecycle fully explains 448→480→512→544 through three expected direct-child insertions: `validation-bin`, the corpus file, and `pty-07`.
- Selected correction: Model B—grant-kind-specific stable identity. Mutable-directory allocation metadata becomes report-only; object identity, ownership, permissions, role/scope, and supported security posture remain acceptance-bearing. File size/digest remain exact.
- Models A, C, E, and F are rejected. Model D remains a later least-privilege hardening seam.
- Future dialect: `effective-read-policy.v2`, complete eight-record outer v5 chain, command records v3, PTY records v2; exactly 24 active schemas.
- Exact successor scope: `FORMAT.md`, `envelope/runner.go`, `envelope/semantic.go`, and `envelope/envelope_test.go`.
- The complete 32-case causal matrix and fresh five-control restart sequence are frozen.
- No self-attestation was found: acceptance records remain external and unreadable to the controlled command.
- Candidate opening/closing capsules matched exactly. The failed A6 control independently binds the intended candidate source.
- No command used the primary checkout as cwd, source root, inventory root, or Git `-C` target.

Evidence:

- [Final report](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9/closeout/final-report-v1.md)
- [Contract freeze](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9/findings/contract-freeze-v1.json)
- [Stable-field table](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9/schemas/stable-versus-volatile-fields-v1.md)
- [Causal matrix](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9/tests/future-causal-matrix-v1.json)
- [Command-root audit](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9/closeout/command-root-audit-v1.json)

Seal: SHA-256 `12ec94fff28d4a861b92ec069abd90ddd1e39f9b026777799b585db755cfcb6c`, 19 payloads, 8 directories. No implementation, repository test/build, repository mutation, predecessor mutation, additional control, comparison, or downstream work occurred.
