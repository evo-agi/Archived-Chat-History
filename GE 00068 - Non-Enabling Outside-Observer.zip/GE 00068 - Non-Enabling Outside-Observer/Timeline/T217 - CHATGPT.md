Do **not** rerun the audit against the unchanged target, and do not limit the next action to rebuilding the evidence manifest. The audit found:

- one genuine **producer-evidence provenance defect**;
- two independently blocking **governance-contract defects** in the seven-path repository patch;
- one **producer process/reporting defect**;
- several low-cost hardening opportunities worth consuming now because the same files must already change.

The correct lifecycle is implementation repair followed by a completely fresh audit. A prior audit no longer qualifies changed bytes, and a provenance mismatch must not be converted into an implementation verdict.  

## Adjudication

### `A4-PROV-001` is valid

The old implementation-evidence capsule is permanently nonqualifying as the authoritative repair capsule. Its manifest authenticated 55 files but not complete directory membership; `commands/` could be added or removed without changing the manifest. This is not a candidate-repository byte defect, but it requires a **new immutable evidence root**. The old root should remain untouched as predecessor evidence.

The new capsule should authenticate both files and directories, avoid unexplained empty directories, and self-exclude only the two canonical manifests. There is no need to mutate or “clean up” the old root.

### `A4-CONTRACT-002` is a real patch defect

The selected allocator contract is supposed to freeze a security-sensitive mechanism, but the sole normative map currently leaves these semantics inferential:

- component-by-component no-follow traversal;
- retaining the opened parent descriptor and physical identity across creation and child verification;
- generating fresh CSPRNG material after each collision;
- retrying only on `EEXIST`.

Reference-only capability prose cannot supply missing normative semantics when the contract says the structured authority block is the only field map. These points need explicit typed fields and contradiction tests.

### `A4-CONTRACT-003` is also a real patch defect

The orchestration contract freezes immutable events and a sole writer, but does not explicitly freeze:

- immutable result records;
- exactly one immutable final orchestration record;
- the complete interruption prohibition, including repair and sealing.

“Inspection-only” suggests some of this, but the point of the structured contract is to prevent future implementations from satisfying the literal map while violating the intended operating model. The map must state these rules directly.

### `A4-ART-004` should be repaired in the new evidence run

The producer report asserted complete temporary-file confinement while its test environments omitted `TMPDIR` and `HOME`; `t.TempDir()` therefore was not proved confined to the producer root. No residue or repository mutation was found, so this is not evidence of a repository defect.

The replacement validation must set, at minimum, private `TMPDIR`, `HOME`, `GOCACHE`, `GOMODCACHE`, and `GOTMPDIR`, then prove their cleanup and absence. The replacement report should make only the confinement claim actually demonstrated.

### Consume the low findings now

Because `docs_contract_test.go` and `capability_probing.md` must already change, this repair should also:

- pin the exact documentary mutation names and count;
- add generic authority-family marker checks over the **closed six-document governing set**, not silently repository-wide;
- state that closed marker scope explicitly in the authoritative map;
- change “current observability rule” to “selected future active rule” or equivalent;
- classify the old apply script accurately as a historical partial edit recipe, not a complete seven-path reproducer.

The repair should remain a narrow documentation-and-test tranche. It must not begin semantic-v7 implementation, allocator implementation, orchestrator implementation, or A6.

## Codex repair prompt

```text
MANDATORY RESPONSE FORMAT

Return exactly one primary verdict:

REPAIR10I_A6_SUCCESSOR_GOVERNANCE_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
REPAIR10I_A6_SUCCESSOR_GOVERNANCE_AUDIT_REPAIR_BLOCKED
BASELINE_MISMATCH
SCOPE_EXPANSION_REQUIRED

Embed the complete implementation report inline in Markdown. Supplemental
evidence paths may be linked, but must not replace the report.

This is a parent-only implementation repair. Do not spawn subagents.

Do not stage, commit, reset, amend, revert, merge, push, create an upstream,
create a PR, install dependencies, contact a network, invoke product or live
services, execute Repair 10I controls or semantic binaries, invoke Evidence
Verification or caller v4, allocate or resume an A6 child, or mutate any
supplied evidence root.

## 1. Objective

Repair the findings from the fresh independent audit of the Repair 10I A6
successor-governance freeze:

- A4-CONTRACT-002: allocation mechanics are incomplete in the sole normative
  structured map;
- A4-CONTRACT-003: result immutability, final-record cardinality, and complete
  interruption prohibitions are incomplete in the sole normative map;
- A4-PROV-001: the previous implementation-evidence manifest did not bind
  complete directory membership;
- A4-ART-004: the previous validation report overclaimed temporary-file
  confinement.

Also consume these bounded hardening findings while the same files are open:

- A2-01: pin the exact documentary mutation name set and count;
- A2-02: generically reject alternate authority-family blocks within the
  contract’s explicitly closed governing-document set;
- A1-OBS-01: replace the locally ambiguous “current observability rule”
  wording with “selected future active rule” or equivalent.

The result must remain a private planning/documentary-contract repair.
Do not implement v7, the semantic successor, allocator, orchestrator, current
five-control instances, or fresh A6.

## 2. Exact repository

CANDIDATE_R:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

All repository-facing commands must use CANDIDATE_R as cwd. Every Git command
must use:

  git -C "$CANDIDATE_R" ...

with these explicit environment values:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

Do not run Git or filesystem searches in the primary checkout.

## 3. Required opening baseline

Require all of the following before editing:

- physical root:
  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
- device/inode:
  16777234 / 122118502
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed membership:
  389 objects, 375 tracked, 14 nonignored untracked
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0/0/0/0
- current source T:
  e01538a45d8b11a332ee6b6fc78239bfd6509303
- current inventory SHA-256:
  29251ed38218cadb5528db1e6b04a60078abf7aea3d9ebfa2b29437fc6c923a7
- inventory size:
  54,314 bytes

Require these exact current path identities:

PLANS.md
  288,739 bytes
  f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f

.docs/system_overview/configuration.md
  129,589 bytes
  f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3

.docs/system_overview/boundaries.md
  96,086 bytes
  0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd

.docs/system_overview/artifact_hygiene.md
  38,322 bytes
  2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910

.docs/system_overview/capability_probing.md
  42,667 bytes
  4730644365b4ad65f56f57573cb39e592ff3eeb88a0a5e10f6df444dcc75a65b

.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
  97,555 bytes
  010d2d6ed46e325ec82eaeeb8f843493f6cd7d52feef53ed140db12e1cc042e6

docs_contract_test.go
  778,632 bytes
  b1f61eed7960d208541c25ac145af0768ab178248c020333841fc619543432d3

Reconstruct the complete 389-object inventory before editing.

Stop with BASELINE_MISMATCH on any discrepancy. Do not absorb newer work.

## 4. Read-only predecessor evidence

The following roots are read-only predecessor evidence:

IMPLEMENTATION_EVIDENCE:

  /Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2

BLOCKING_AUDIT:

  /Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg

Do not delete the old `commands/` directory, modify an old manifest, chmod an
old file, or rewrite an old report. The old implementation capsule remains
nonqualifying predecessor evidence.

Consume these audit findings exactly:

- A4-PROV-001
- A4-CONTRACT-002
- A4-CONTRACT-003
- A4-ART-004
- A2-01
- A2-02
- A1-OBS-01
- A2-03 as a report/evidence classification observation only

## 5. Exact repository mutation scope

Repository mutation is authorized only for:

1. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
2. .docs/system_overview/capability_probing.md
3. docs_contract_test.go

No fourth repository path is authorized.

Keep the contract ID unchanged:

  execution-substrate.repair10i-a6.successor-governance.v1

This is a repair of an unaccepted selected-target governance freeze, not a
versioned migration of an implemented contract.

If complete-document coherence requires another repository path, stop with
SCOPE_EXPANSION_REQUIRED before editing that path.

Do not modify:

- PLANS.md;
- configuration.md;
- boundaries.md;
- artifact_hygiene.md;
- product Go source;
- public schemas;
- module files;
- operational scripts;
- Evidence Verification;
- caller v4;
- any evidence child.

## 6. Required normative allocation repair

The sole authoritative structured block must explicitly and independently
freeze all of the following. Preserve the block’s canonical one-line JSON,
typed closed-map posture, and sole-writer role.

Under the selected allocation contract, add explicit typed facts equivalent to
these exact semantics:

- parent traversal:
  component-by-component, no-follow
- held parent custody:
  the opened parent descriptor and its physical identity remain held from
  parent admission through exclusive child creation and child verification
- collision retry condition:
  EEXIST only
- collision material:
  every retry obtains a fresh 16-byte operating-system CSPRNG value
- collision material reuse:
  forbidden
- non-EEXIST creation failure:
  terminal failure without retry or fallback

Use field names consistent with the existing map, but do not collapse these
into one vague caption. Report the exact final key paths and values.

Existing requirements—exact parent, prefix, 32 lowercase hex suffix, umask
0077, mode 0700, effective owner/group, descriptor-relative exclusive mkdir,
stable device/inode, attempt limit 128, direct allocation-record delivery, and
no scanning/latest/adoption/rename/resume/timestamp/PID/counter/Git-hash
authority—must remain unchanged.

## 7. Required normative orchestration repair

The sole authoritative structured block must explicitly freeze:

- immutable event records;
- immutable result records;
- exactly one final orchestration record;
- that final orchestration record is immutable;
- no second mutable current-state authority;
- after interruption or writer uncertainty, the child is permanently failed
  or superseded and inspection-only;
- the interrupted child may not be:
  adopted, repaired, renamed, resumed, or sealed.

Do not rely on “inspection-only” as an implication for repair or sealing.
Represent the complete forbidden-action set explicitly in the normative map.

The existing sole-writer, fourteen-stage ownership, and selected-not-
implemented posture must remain unchanged.

## 8. Marker scope and authority-family hardening

The contract must state explicitly that authority-marker uniqueness is scoped
to the closed six-document governing set:

- the sole writer;
- PLANS.md;
- configuration.md;
- boundaries.md;
- artifact_hygiene.md;
- capability_probing.md.

It must not claim repository-wide semantic interpretation of arbitrary prose.

In `docs_contract_test.go`, add a generic authority-family marker scanner for
that exact closed set. Derive the family prefix from the current contract
marker family rather than enumerating only the exact v1 marker.

Reject, with specific reasons:

- alternate family IDs in the writer;
- a family authority block in any consumer;
- duplicate authority blocks;
- mismatched BEGIN/END IDs;
- unmatched BEGIN;
- unmatched END;
- nested or overlapping blocks.

Unmarked prose remains prose and must not acquire authority.

Perform a repository-wide literal marker search as validation evidence, but do
not silently widen the normative scope beyond the closed six-document set.

## 9. Documentary test mutation matrix

Preserve all current 14 semantic contradiction cases and their mechanism-
specific reasons.

Add at least these allocation and orchestration contradictions:

1. parent traversal no longer component-by-component no-follow;
2. parent descriptor/identity not held through creation and child verification;
3. retry permitted for an error other than EEXIST;
4. collision retry reuses prior CSPRNG material;
5. result records made mutable;
6. more than one final orchestration record admitted;
7. final orchestration record made mutable;
8. interrupted child repair admitted;
9. interrupted child sealing admitted.

Add the marker-family cases required by §8.

Add a literal expected mutation-name list and assert:

- exact count;
- exact name set;
- no duplicate name;
- every named mutation executed;
- every mutation rejected for its intended specific reason.

The expected list must be independent of the generated mutation slice. Do not
derive expected names from the cases being tested.

Preserve the test as a regression oracle, not as a second normative writer.

## 10. Capability wording repair

In `capability_probing.md`, replace “current observability rule” with wording
that unambiguously means the selected, unimplemented future active rule.

Do not otherwise redefine the contract in the consumer. Preserve its
reference-only, non-overriding role.

## 11. Source-external implementation validation

Create a fresh implementation-repair evidence root beneath
`/Users/ds/Downloads` using `tempfile.mkdtemp`, umask `077`, and a descriptive
prefix.

Do not reuse a fixed or pre-existing suffix.

All retained directories must be mode `0700`.
All retained files must be regular, single-link, mode `0600`.

Before any test, create private locations beneath that root for:

- TMPDIR
- HOME
- GOCACHE
- GOMODCACHE
- GOTMPDIR
- any other Go-generated or audit-generated state

Explicitly bind every test command to those paths.

Use the exact pinned Go 1.26.5 tool identified by the predecessor validation
records. Verify before use:

- `go version go1.26.5 darwin/arm64`
- go SHA-256:
  3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19
- gofmt SHA-256:
  3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81

Use:

  GOTOOLCHAIN=local
  GOPROXY=off
  GOSUMDB=off
  GOENV=off
  GOWORK=off
  GOFLAGS=-mod=readonly

Retain exact argv, cwd, environment, tool identities, exits, stdout, stderr,
test identities, and before/after repository inventories.

## 12. Required validation

Run, at minimum:

1. Static independent parsing of the final authority block:
   - duplicate-key rejection;
   - nonfinite rejection;
   - exact keys/types/values;
   - canonical one-line JSON;
   - exact closed six-document placement;
   - consumer references.

2. An independent source-external documentary validator that:
   - does not import repository test helpers;
   - accepts the live final documents;
   - independently reproduces every semantic, allocation, orchestration, and
     marker-family contradiction;
   - checks the intended specific rejection reason.

3. Focused governance test:
   - exact final `docs_contract_test.go`;
   - `-v`;
   - `-count=1`;
   - verify the exact fixed mutation name set executes.

4. Corrected complete changed-document reader set.

5. Every identity in `docs_contract_test.go`.

6. The complete docs-contract identity set twice:
   - once under umask `077`;
   - once under umask `022`.

7. Pinned `gofmt -d docs_contract_test.go`, requiring empty output.

8. Rooted `git diff --check`, requiring empty output.

Do not run product tests, live services, Repair 10I controls, semantic binaries,
Evidence Verification, caller v4, or A6.

No failure or skipped test is qualifying. Retain failed and superseded attempts
separately and do not overwrite them.

## 13. New evidence provenance requirements

The new implementation-repair evidence capsule must authenticate complete
membership, including directories.

Do not create unused or unexplained empty directories. In particular, do not
create an empty `commands/` directory unless it has an authenticated,
documented purpose.

Produce two byte-identical canonical manifests. Each manifest must:

- contain every retained directory other than no directory exclusion;
- contain every retained nonmanifest file exactly once;
- record relative path, type, mode, and, for files, link count, size, SHA-256;
- record directory path, type, and mode;
- reject symlinks and special objects;
- self-exclude only the two canonical manifest files;
- identify those exact two self-exclusions in canonical content;
- prove an empty private temporary area at closeout.

Create the final implementation report before building the two manifests so
that it is covered by both manifests. The report does not need to contain the
manifest hashes; the inline Codex response can report them afterward.

Retain exact source for:

- the repair edit recipe, if any;
- the repair closeout/provenance recipe;
- the evidence-manifest recipe;
- the independent documentary validator.

Do not represent the old partial apply script as a complete seven-path
reproducer.

## 14. Artifact cleanup and confinement proof

After validation:

- remove only repair-owned caches, homes, temporary directories, and fixtures;
- perform two genuinely fresh absence observations;
- confirm no repository artifact, cache, bytecode, database, journal, lock,
  generated manifest, or unsupported object appeared;
- confirm every generated location was beneath the new evidence root;
- do not make a universal confinement claim unless the retained command
  environments and observations establish it.

Do not modify the old implementation or audit evidence roots.

## 15. Repair provenance

Bind this repair against the exact opening baseline in §3.

Produce:

- exact opening and final 389-object inventories;
- opening and final source T;
- exact repair-only touched path set;
- before/after mode, size, and SHA-256 for each touched path;
- repair-only binary delta, built independently twice;
- exact full dirty-state posture;
- exact documentary authority-block bytes and SHA-256;
- exact documentary mutation names and count;
- exact final test identity sets;
- exact recipe IDs and source hashes;
- two byte-identical complete evidence manifests.

All repository paths outside the authorized three-path scope must remain equal
to the repair opening baseline.

## 16. Stop conditions

Stop immediately with the appropriate blocked verdict if:

- opening baseline differs;
- a fourth repository path is needed;
- contract ID/version must change;
- current-versus-target separation cannot be preserved;
- a consumer must become a normative writer;
- allocator or orchestrator implementation becomes necessary;
- a product or public schema must change;
- a failed test would require weakening a contract;
- private temporary confinement cannot be demonstrated;
- complete evidence-root directory membership cannot be authenticated;
- any supplied evidence root changes;
- staging, commit, push, network, live service, A6, Evidence Verification, or
  caller invocation would be needed.

## 17. Required final report

Report:

1. Verdict.
2. Opening repository identity and complete baseline.
3. Audit findings consumed and their exact disposition.
4. Exact three-path touched scope.
5. Current contract versus selected target.
6. Final authoritative structured-map additions.
7. Exact allocation semantics.
8. Exact orchestration/interruption semantics.
9. Marker family and closed-document scope.
10. Final mutation count and exact names.
11. Independent validator design and outcomes.
12. Every validation command, environment, and result.
13. Failed and superseded attempts.
14. Artifact confinement and two absence observations.
15. Opening/final source T and inventory.
16. Repair-only delta SHA-256.
17. Authority-block SHA-256.
18. Evidence manifest recipe and two manifest SHA-256 values.
19. Complete evidence-root file/directory counts and self-exclusions.
20. Assumptions, remaining seams, and uninspected scope.
21. Explicit confirmations:

    INDEPENDENT_AUDIT_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    A6_NOT_STARTED
    SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
    ORCHESTRATOR_NOT_IMPLEMENTED
    EVIDENCE_VERIFICATION_NOT_INVOKED
    CALLER_NOT_INVOKED
    PRODUCT_SOURCE_NOT_MODIFIED
    PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
    NETWORK_CONTACT_NOT_PERFORMED
    SUBAGENTS_CREATED: 0
```

This prompt deliberately does **not** authorize a pure provenance rerun. The repository governance defects must be repaired first; only the resulting exact bytes and new complete evidence capsule should go to another fresh independent audit.

### Sources

- Codex independent audit report supplied in this turn.
- The project protocol requires audit findings to return to sole-writer implementation repair and then a new independent audit. 
- Provenance establishes byte identity, not contract correctness or authority soundness. 
- Implementation validation and independent audit are intentionally separate engagements. 

**Confidence**

- Audit verdict correctness: **0.98**
- Need for repository contract repair, not just evidence repair: **0.97**
- Proposed three-path repair scope: **0.90**
- New evidence-capsule strategy: **0.98**
- Readiness to begin semantic-v7 implementation now: **0.02**
