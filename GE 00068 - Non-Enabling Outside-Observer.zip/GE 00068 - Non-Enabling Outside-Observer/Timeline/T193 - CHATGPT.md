## Assessment

This is another **process-only failure**. It provides no evidence for or against the successor caller.

The source, producer validation, and implementation provenance remain exactly where they were. Do **not** return to implementation, alter the successor, regenerate producer evidence, or restart A6.

The repeated failure now identifies the real problem: a hard “first tool call” rule is incompatible with the ChatGPT-to-Codex routing layer. That layer may inspect its default checkout before Codex has parsed the audit instructions. Adding more first-command wording will not fix that orchestration behavior.

The audit boundary should therefore begin at an explicit **post-instruction audit epoch**:

- Any automatic operations that happened before Codex received and parsed the prompt must be disclosed.
- Their outputs are discarded and cannot support the audit.
- Read-only pre-epoch activity in an unrelated checkout does not block the audit.
- It blocks only if it modified the actual audit target or supplied evidence, or if Codex cannot establish that those inputs remain exact.
- From the audit epoch onward, the normal strict read-only and provenance boundaries apply.

This does not weaken the audit. The meaningful independent-audit sequence is exact provenance reproduction before correctness inspection, followed by read-only perspectives and closing provenance—not the shell’s inherited startup behavior.   Provenance binds the audit to the same bytes but does not confer correctness or authority.  Generated proof artifacts likewise remain evidence rather than authority. 

Paste the following **directly into a fresh Codex conversation as the first user message, without attaching prior responses**.

---

## Codex prompt — epoch-bounded independent audit

```text
MANDATORY RESPONSE FORMAT

Embed the complete audit report inline in Markdown. Local evidence links may be
supplemental, but must not replace any report section.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH READ-ONLY AUDIT

This must be a fresh Codex conversation.

Do not resume:

- either aborted process-boundary audit;
- the caller-evidence/atomic-publication implementation conversation;
- either caller reusability/depth audit;
- any earlier caller-snapshot or Evidence Verification audit conversation.

Do not repair or modify the caller, repository, or any supplied evidence.

Do not format, clean supplied roots, stage, commit, push, create a PR, merge,
install, deploy, restart A6, invoke product or live-service paths, contact the
network, or execute Linux binaries.

No nested subagents.

All required inputs are inline. Do not read an attachment to obtain the task.

## 1. Audit-epoch boundary

The hosting ChatGPT/Codex layer may have performed automatic operations before
this prompt was delivered and parsed.

Those pre-instruction operations are outside the audit epoch.

After reading this complete prompt:

1. Begin a new audit epoch.
2. Disclose any known pre-epoch commands, cwd values, and effects.
3. Discard all pre-epoch command output. It must not support any audit claim.
4. Do not repeat or continue any pre-epoch exploration.
5. Establish the exact frozen inputs independently from the paths and identities
   below.

Pre-epoch read-only operations against an unrelated default or primary checkout
are NOT, by themselves, a process blocker.

Return PROCESS_BOUNDARY_BLOCK only when:

- a pre-epoch or post-epoch operation modified IMPL_R or a supplied evidence
  root;
- a post-epoch Git or filesystem operation improperly targets the unrelated
  primary/default checkout;
- pre-epoch activity makes the exact target or supplied-input state
  unprovable;
- the audit itself violates its read-only posture.

Do not claim anything about the unrelated primary/default checkout, and do not
use it as an audit input.

From the audit epoch onward:

- run repository Git commands only as `git -C "$IMPL_R" ...`;
- set the Git child cwd to IMPL_R;
- explicitly set:
  - PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  - GIT_OPTIONAL_LOCKS=0
  - GIT_CONFIG_NOSYSTEM=1
  - LC_ALL=C
  - LANG=C
  - PYTHONDONTWRITEBYTECODE=1
- perform no operation against the unrelated primary/default checkout.

A bespoke record for every incidental Git subprocess is not required. Retain
the exact opening and closing provenance commands, exits, and material output
hashes.

## 2. Objective

Independently audit the exact source-external Evidence Verification v1 caller
successor that repairs:

1. record-destination containment relative to caller_evidence_root; and
2. publication of an accepted JSON record before acceptance became
   irrevocable.

The producer returned SCOPE_EXPANSION_REQUIRED only because a supplied
criterion incorrectly required a concurrently created foreign object both to
remain untouched and to be absent.

Section 5 freezes the corrected collision contract.

The producer verdict itself does not disqualify the exact source bytes.

## 3. Exact frozen inputs

Repository:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected repository identity:

- branch:
  codex/evidence-verification-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- canonical manifest SHA-256:
  4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537
- full-index tracked binary-diff SHA-256:
  b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb
- restored governed inventory:
  477 exact objects

Implementation root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1

Exact successor:

SUCCESSOR=$REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py

Expected successor identity:

- size:
  45678
- SHA-256:
  3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631

Exact base caller:

BASE_COPY=$REPAIR_ROOT/source/base_caller_exact.py

Expected base identity:

- size:
  33758
- SHA-256:
  c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24

Source delta:

SOURCE_DELTA=$REPAIR_ROOT/provenance/source-delta.diff

Expected source-delta SHA-256:

a9f1f7d3ec09317126b575ade443fe89e7b9a7d31db7a0466d63c452e0bd3bd2

Required implementation records:

- $REPAIR_ROOT/provenance/semantic-crosswalk.json
- $REPAIR_ROOT/provenance/atomic-publication-capability.json
- $REPAIR_ROOT/provenance/attempt-index-final.json
- $REPAIR_ROOT/closeout/implementation-report.md

Implementation manifests:

MANIFEST_1=$REPAIR_ROOT/provenance/repair-manifest-run-1.json
MANIFEST_2=$REPAIR_ROOT/provenance/repair-manifest-run-2.json

Expected SHA-256 for each manifest:

58b1f0fe386be8fafd3d073a80b99bd9ae3191f0547f40ce8967ccf18669fc00

Expected implementation-root closure:

- 183 regular files;
- 10 directories including root;
- 181 SHA-bearing rows covering every nonmanifest regular file exactly once;
- only the two manifest files self-excluded;
- every retained regular file single-link and mode 0600;
- every retained directory mode 0700;
- private tmp directory empty.

Frozen base-repair root:

BASE_REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-repair-c030f2baf200-v1

Expected base-repair closure:

- 108 regular files;
- 10 directories;
- manifest SHA-256:
  70e2a46949f2bc0eb25a799e60af2c44e73112a408bd119fc8e297a6203eec15

Prior substantive blocking audit:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-independent-audit-70e2a46949f2-v2

Inspect at minimum:

- causals/caller-evidence-ancestor.json
- causals/late-json-full-main-corrected.json
- causals/destination-negatives.json
- causals/output-races-and-retry.json
- causals/sealed-compatibility.json
- causals/caller-negatives-independent.json
- closeout/final-addendum.json

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular and single-link;
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Fresh audit root:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-v3

Require AUDIT_ROOT absent at audit-epoch opening.

## 4. Opening provenance

Before source correctness inspection, independently require:

### Repository

- exact branch, HEAD, tree, parent, and absent upstream;
- exact canonical manifest and full-index tracked diff;
- exact 477-object governed inventory;
- no repository cache, bytecode, test cache, ignored extra, or generated
  artifact;
- zero staged, deleted, renamed, or unmerged paths.

### Implementation root

Inventory REPAIR_ROOT by relative path and require:

- exact successor, base copy, source delta, crosswalk, capability record,
  causals, tests, validation, records, report, and attempt index;
- exactly 183 regular files and 10 directories;
- all retained regular files 0600 and single-link;
- all retained directories 0700;
- tmp empty;
- both manifests canonical and byte-identical;
- exactly 181 SHA-bearing rows;
- every nonmanifest regular file covered exactly once;
- exactly the two manifest files self-excluded;
- every directory covered exactly once;
- no unexplained exclusion or later mutation.

Also bind BASE_REPAIR_ROOT, BLOCKING_AUDIT, A6D, and A6D_AMEND at opening.

Return AUDIT_PROVENANCE_MISMATCH on an actual mismatch and stop before
correctness inspection.

## 5. Corrected concurrent-collision contract

### Universal invariant

For every precommit failure:

- the caller must not publish its staged JSON object as its final accepted
  record;
- the invocation must be nonaccepted;
- shared output must not report successful acceptance;
- no caller-created final JSON may state `outcome="accepted"`;
- a pre-existing or concurrently created foreign final object must not be
  deleted, replaced, relabelled, or taken into caller custody.

### No foreign collision

When no external writer creates the final JSON pathname, a precommit failure
must leave that final pathname absent.

### Concurrent foreign collision

When another writer creates the final pathname after the initial absence check
and before exclusive publication:

- the final pathname may remain present;
- the object is foreign, not caller-published;
- its device/inode, type, mode, link count, size, and bytes must remain
  unchanged by the caller;
- the staged inode must not become the final inode;
- exclusive publication must fail;
- the invocation must be nonaccepted;
- shared output must not attribute the foreign object to this invocation;
- caller-created sidecars or stage are failed-attempt evidence only;
- same-basename retry must fail closed;
- the caller must not delete the foreign object merely to make the pathname
  absent.

Path presence alone is not caller acceptance.

Acceptance requires both:

1. successful exclusive publication by this invocation; and
2. the associated successful caller process outcome.

## 6. Audit-owned evidence

After opening provenance matches, create AUDIT_ROOT under umask 077.

Keep all audit-created material beneath AUDIT_ROOT.

Use a private TMPDIR and bytecode-disabled Python.

Final retained audit material should be private. Exact per-command immutable
ledgers are not required. Do not let audit-record ceremony supersede the
correctness audit.

Only mutation of the repository or supplied roots is a process blocker.
Audit-owned fixtures and temporary files may be created, corrected, and removed
inside AUDIT_ROOT, provided failed attempts are disclosed in the final report.

## 7. Four independent perspectives

Start three distinct read-only auditors concurrently:

1. Contract, protocol, schema, source-delta, and state-machine auditor.
2. Filesystem, descriptor-output, atomic-publication, and collision auditor.
3. Snapshot/depth, resource, test, and provenance auditor.

After one completes, start a fourth distinct auditor:

4. Security, hook reachability, disclosure, compatibility, and artifact auditor.

Retry a failed start once. Return SUBAGENT_UNAVAILABLE only if a required
distinct perspective remains unavailable after that retry.

No nested delegation. Auditors run no Git, mutations, network calls, supplied-
root writes, or repository-module imports.

Each auditor must report:

- exact operands;
- actual cwd;
- evidence;
- inference;
- uncertainty;
- uninspected scope;
- disagreements;
- mutation performed: no;
- nested subagents created: no.

## 8. Exact source-delta audit

Independently regenerate the unified diff between BASE_COPY and SUCCESSOR.

Require the semantic delta to be confined to:

- caller_evidence_root destination disjointness;
- staged JSON naming and collision handling;
- behavior-probed `renameatx_np(..., RENAME_EXCL)` publication;
- state-machine changes required to make publication the sole commit point;
- deterministic private hooks and normal-main guards;
- bounded comments and constants describing the contract.

Require the snapshot/depth block to remain byte-identical to base:

- size:
  7831
- SHA-256:
  287302fb8e96d79898e1ae30f632f346a45a6aa76ea1bc030e26e7267b9fe7ff

Confirm unchanged:

- CLI names, order, required/optional status, and defaults;
- launch protocol v2;
- record schema v3;
- exact 25 fields and meanings;
- source-by-value launch;
- interpreter/source/registry/layout/result checks;
- snapshot semantics and limits;
- trusted-host nonclaims;
- unrelated acceptance gates;
- no fourth public output;
- no product, runtime, readiness, commit, or publication authority.

BLOCK on unexplained semantic widening.

## 9. Caller-evidence containment

Independently inspect and causally test that the record parent rejects before
child launch or output creation:

- equality with caller_evidence_root;
- descendant of caller_evidence_root;
- ancestor containing caller_evidence_root;
- physical inode alias;
- supported case alias;
- symlink-mediated equivalent.

Require descriptor-bound identity and bidirectional physical ancestry, not
lexical prefixes or commonpath.

For every rejected case require:

- no record, sidecar, or stage created;
- no child launch;
- caller_evidence bytes and inventory unchanged;
- exact compatible nonaccepting classification.

Accepted external destinations must preserve equal opening and closing
caller_evidence snapshots.

## 10. Atomic-publication audit

### Capability

Verify:

- the exact Darwin `RENAME_EXCL` value and API use;
- descriptor-relative, same-directory publication;
- behavioral capability probing before public output creation;
- occupied destination produces exclusive failure and changes neither object;
- unoccupied destination receives the exact staged inode;
- the stage name disappears;
- no overwrite rename, copy/delete fallback, or persistent hard-link fallback;
- capability uncertainty fails before accepted publication.

### Precommit state

Require initially absent:

- stdout sidecar;
- stderr sidecar;
- final JSON;
- deterministic stage path.

Require exclusive descriptor-relative 0600 creation, complete write, fsync,
close, and reobservation for the sidecars and stage.

Require every acceptance-bearing provenance, snapshot, relationship, parent,
and output check to complete before publication.

### Commit point

Exclusive stage-to-final publication must be the sole accepted-record commit
point.

After successful publication require:

- exactly one final JSON;
- stage absent;
- final inode equals the verified staged inode;
- final link count one;
- canonical v3 JSON with `outcome="accepted"` and empty errors;
- matching sidecars;
- successful caller process result;
- no later acceptance-bearing operation that can fail;
- no cleanup or shared-output failure that can contradict the committed record.

## 11. Failure and collision matrix

Reproduce:

- before stdout;
- partial stdout;
- stdout fsync;
- between stdout and stderr;
- partial stderr;
- stderr fsync;
- after sidecars;
- partial stage;
- stage fsync;
- stage close/reobservation;
- parent rebinding;
- capability unavailable;
- exclusive-publication failure;
- successful publication;
- attempted postcommit error;
- shared-output failure;
- same-basename retry after each failure;
- retry after success.

For ordinary precommit failures without a foreign collision require:

- final JSON absent;
- no caller-created accepted final record;
- invocation nonaccepted;
- partial artifacts clearly nonaccepted;
- retry fails closed without overwrite.

### Mandatory foreign-final collision cases

Create the foreign final object after initial absence checking and before
exclusive publication.

Run at least:

1. arbitrary non-JSON foreign bytes;
2. schema-valid JSON containing `"outcome":"accepted"`.

For each require:

- exclusive publication fails;
- invocation nonaccepted;
- no successful shared output attributes the object to this caller;
- foreign object device/inode, type, mode, link count, size, and bytes unchanged;
- staged inode does not become final inode;
- caller does not delete or replace the foreign object;
- sidecars/stage remain failed-attempt evidence only;
- retry fails closed;
- the caller does not represent path presence as its own accepted publication.

Do not block merely because the foreign pathname remains present.

Reproduce the prior late-JSON failure and prove that its corresponding
precommit failure leaves no caller-created accepted final JSON.

## 12. Hooks and snapshot/depth regression

Prove:

- private hooks default to null;
- normal `main()` rejects non-null hooks before output or child launch;
- no normal CLI, environment, target, package, verifier result,
  registry/layout, record field, or path can set a hook;
- hooks are unavailable in normal source-by-value execution;
- no exception path retains one.

Rerun:

- root depth 0;
- file and directory depth 12 accepted;
- file and directory depth 13 rejected before observation;
- stable canonical repeat;
- symlink, special-file, hardlink, replacement, mutation, disappearance,
  type/mode/link and resource-limit cases;
- capability and runtime listing failure;
- no watched-root write.

Verify limits precede unbounded allocation or read work.

## 13. Record schema and disclosure

Require:

- launch protocol v2;
- schema v3;
- exact 25 top-level fields;
- unchanged meanings;
- mandatory trusted-host nonclaims;
- no source text, payload, credential, private endpoint, absolute watched-root,
  caller-evidence, output, foreign-final, or stage path;
- no stage name in final record or shared output;
- `outcome="accepted"` only after this caller’s successful exclusive commit;
- foreign collision never yields a caller-accepted record.

## 14. Exact-successor compatibility

Every acceptance-bearing run must execute exact SUCCESSOR bytes.

### A6D

Run sealed twice in fresh external record directories.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- deterministic nonsnapshot fields;
- equal target/package/TMPDIR/caller-evidence snapshots;
- exactly three final 0600 outputs;
- no stage;
- correct committed-record identity and retry behavior;
- unchanged A6D manifest;
- mandatory nonclaims.

### Amendment

Run sealed twice and require canonical stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same conditions.

### Synthetic A6

Create only an audit-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require deterministic output per stage, exact SUCCESSOR bytes, empty verifier
stderr, equal snapshots, correct publication semantics, and only the expected
seal transition.

### SEC-02

Require source-by-value launch, target script never loaded, marker absent, and
direct-script predecessor shape nonqualifying.

Do not claim atomic interpreter custody.

Freshly exercise caller negatives, including caller-evidence containment,
ordinary partial failures, both foreign-final collision forms, invalid
destination, parent replacement, interpreter/source/result mismatches, snapshot
faults, and depth 13.

## 15. Closing provenance

Remove only audit-created temporary fixtures.

Require:

- unchanged repository manifest, tracked diff, and 477-object inventory;
- unchanged BASE_REPAIR_ROOT;
- unchanged BLOCKING_AUDIT;
- unchanged REPAIR_ROOT with exact 183-file/10-directory closure;
- unchanged implementation manifests;
- unchanged A6D and amendment manifests;
- no process, child, descriptor, fixture, or temporary survivor;
- empty audit tmp.

## 16. Verdict rules

ACCEPT only if:

- provenance matches;
- source delta is bounded;
- caller-evidence containment is complete;
- staged publication has one commit point;
- ordinary failures leave no caller-created accepted final JSON;
- foreign collisions preserve the foreign object and remain nonaccepted;
- path presence alone is never treated as caller acceptance;
- hooks are unreachable normally;
- depth/snapshot behavior does not regress;
- exact-successor compatibility passes;
- schema, protocol, authority, and nonclaims remain unchanged;
- no process or artifact blocker remains.

BLOCK for a repairable source, publication, collision-attribution, test,
provenance-format, disclosure, resource, or validation defect.

REJECT only for a fundamental architecture or authority defect.

AUDIT_PROVENANCE_MISMATCH for an opening or closing target-input mismatch.

PROCESS_BOUNDARY_BLOCK only for an audit-epoch process violation, target or
supplied-root mutation, or loss of trustworthy read-only posture.

SUBAGENT_UNAVAILABLE if a required distinct auditor cannot start after one
retry.

## 17. Required inline report

Include:

1. Verdict.
2. Pre-epoch disclosure and audit-epoch start.
3. Exact repository and implementation-root identities.
4. Opening and closing provenance.
5. Four auditor identities, schedule, operands, and status.
6. Exact source delta.
7. Corrected collision-contract adjudication.
8. Caller-evidence containment.
9. Atomic-publication capability.
10. Output state machine and commit point.
11. Ordinary failure behavior.
12. Foreign-final collision behavior.
13. Partial artifacts and retry semantics.
14. Hook reachability.
15. Depth and snapshot regression.
16. Protocol, schema, and field preservation.
17. Record disclosure and attribution.
18. A6D results.
19. Amendment results.
20. Synthetic A6 results.
21. SEC-02 result.
22. Caller negatives.
23. No-write and deterministic-output evidence.
24. Authority and security adjudication.
25. Severity-ranked residual findings.
26. Minority findings and parent resolution.
27. Remaining uncertainty and nonclaims.
28. Audit-created paths and cleanup.
29. Explicit confirmations:
    - repository mutation not performed;
    - supplied-evidence mutation not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not stage, commit, push, or restart A6.
```

## Current disposition

The successor is still:

- **implemented and producer-validated;**
- **not independently accepted;**
- **not ready for commit or A6 restart.**

This should be the final process-only retry. If the next audit again treats pre-instruction wrapper activity as disqualifying, that is an orchestration-layer failure to follow the explicit audit-epoch contract—not a reason to modify the successor.

### Sources

The operating protocol separates implementation from a later fresh read-only audit and requires audit provenance before correctness inspection.   The provenance guidance requires exact-byte reproduction at audit opening and closing while explicitly separating provenance from correctness and authority.  

**Confidence**

- Process-only classification: **0.999**
- No implementation repair is warranted from this response: **0.997**
- Post-instruction audit epoch is the correct orchestration fix: **0.98**
- Exact successor still requires a fresh independent audit: **0.999**
