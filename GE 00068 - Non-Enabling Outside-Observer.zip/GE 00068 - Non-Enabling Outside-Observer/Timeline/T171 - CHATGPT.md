## Assessment

This is another **nonqualifying audit-process failure**, not a repository or repair failure.

The opening gate established the important facts before stopping:

- the restored **477-object** repository inventory matched exactly;
- the 13 patch rows matched canonical manifest `4a3a4244…18537`;
- the tracked diff remained `b2487310…7aceb`;
- no repository mutation was reported;
- no audit root, tests, provenance replay, or subagents were started.

No implementation, restoration, or cleanup turn is needed.

The process boundary was specified incorrectly for a linked Git worktree. This worktree’s `.git` file necessarily points to:

```text
/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---evidence-verification-v1
```

That directory is **shared Git administration**, not the primary checkout’s working-tree content. Reading the exact linked-worktree Git administration directory to check operation markers is normal and necessary. Treating every path lexically beneath `/Users/ds/Repositories/Execution Substrate` as forbidden made the opening gate self-defeating.

The corrected rule needs three distinct surfaces:

1. **Implementation working tree** — allowed read-only audit target.
2. **Primary working-tree content** — forbidden.
3. **Common and linked-worktree Git administration** — narrowly allowed read-only for identity, operation-marker, and lock checks derived from `git -C "$IMPL_R"`; never writable and never broadly traversed.

The failed audit remains permanently nonqualifying because it correctly obeyed its supplied rule. Its `/tmp/es-ev-audit-bootstrap.a33wsJQa` files are outside the repository and require no separate cleanup.

The repository was previously restored by removing exactly the audit-created bytecode file and its empty cache directory, returning to the recorded 477-object baseline without changing patch bytes.  Two post-restoration provenance runs reproduced the unchanged `4a3a4244…18537` manifest. 

## Replacement audit prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete audit report inline in Markdown.

Do not return only:

- a verdict;
- a summary;
- a link to a report;
- “full report available at …”;
- or an attachment reference.

Supplemental evidence links may follow the complete inline report.

This applies to every outcome:

- ACCEPT;
- BLOCK;
- REJECT;
- AUDIT_PROVENANCE_MISMATCH;
- PROCESS_BOUNDARY_BLOCK;
- SUBAGENT_UNAVAILABLE.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a completely fresh, read-only Codex conversation.

Do not resume:

- the process-blocked audit;
- the artifact-restoration conversation;
- the alternate-authority implementation conversation;
- another Evidence Verification implementation or audit conversation.

Objective

Independently audit the exact Evidence Verification v1 alternate-authority-ID
repair after exact artifact restoration.

Do not repair or modify the patch.

The preceding audit stopped before correctness inspection because its process
rule incorrectly treated linked-worktree Git administration beneath the common
repository `.git` directory as forbidden primary-working-tree access.

This prompt corrects that classification:

- primary working-tree content remains forbidden;
- exact linked-worktree and common Git administration paths derived from
  `git -C "$IMPL_R"` are permitted for narrowly bounded read-only identity,
  operation-marker, and lock checks;
- no write to Git administration is authorized;
- no broad traversal of the common Git directory is authorized.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

No repository mutation.
No formatting.
No repair.
No repository cleanup.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No nested subagents.

## 1. Exact audit target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Primary working-tree root:

PRIMARY_WORKTREE=/Users/ds/Repositories/Execution Substrate

Expected common Git administration directory:

COMMON_GIT_DIR=/Users/ds/Repositories/Execution Substrate/.git

Expected linked-worktree Git administration directory:

WORKTREE_GIT_DIR=/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

IMPLEMENTATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f

Expected canonical manifest:

EXPECTED_MANIFEST=$IMPLEMENTATION_EVIDENCE/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe:

- recipe ID:
  execution-substrate.evidence-verification-v1.final-patch-provenance.v1
- SHA-256:
  bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected test source:

TESTS=$IMPL_R/tools/evidence_verify/test_verify_v1.py

- size:
  88127
- SHA-256:
  a106fe923440e4f2b24a7a425f994aa935eaaa9ffb7a68925987c8444df9b568

Expected unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected unchanged source-external caller:

CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Restoration evidence root:

RESTORATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632

Restoration object inventory:

RESTORED_INVENTORY=$RESTORATION_EVIDENCE/restoration/full-object-after.json

Restoration closing gate:

RESTORATION_CLOSING=$RESTORATION_EVIDENCE/closeout/closing-gate.json

Prior substantive process-failed audit, read-only:

FAILED_SUBSTANTIVE_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python:

- version: 3.13.4
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v3

## 2. Correct linked-worktree process boundary

### 2.1 Allowed repository content

Read-only access is permitted to:

- IMPL_R and its descendants;
- absolute implementation-evidence and audit-evidence paths listed in this
  prompt;
- audit-owned paths beneath AUDIT_ROOT;
- audit-owned temporary paths.

### 2.2 Forbidden primary working-tree content

Do not read or execute any path in the primary working tree:

PRIMARY_WORKTREE

except for the narrowly allowed Git administration exception below.

In particular, do not read repository source, docs, tests, configuration,
artifacts, or worktree files through PRIMARY_WORKTREE.

No Git command may use PRIMARY_WORKTREE as cwd or `-C` target.

### 2.3 Narrowly allowed Git-administration exception

The following are not primary-working-tree content:

- COMMON_GIT_DIR
- WORKTREE_GIT_DIR

The audit parent may read them only for narrowly bounded Git identity,
operation-state, and lock checks.

First derive them through conforming Git calls:

```text
git -C "$IMPL_R" rev-parse --absolute-git-dir
git -C "$IMPL_R" rev-parse --git-common-dir
```

Require the results to equal the expected paths above after physical
normalization.

The parent may then perform read-only `lstat`, `stat`, `readlink`,
file-existence, and directory-existence checks only on:

- the IMPL_R `.git` pointer file;
- WORKTREE_GIT_DIR itself;
- COMMON_GIT_DIR itself;
- exact operation-marker or lock paths returned by
  `git -C "$IMPL_R" rev-parse --git-path <name>` for the closed list below.

Closed marker/lock list:

```text
MERGE_HEAD
CHERRY_PICK_HEAD
REVERT_HEAD
BISECT_LOG
BISECT_START
rebase-merge
rebase-apply
sequencer
index.lock
HEAD.lock
packed-refs.lock
config.lock
```

Do not recursively traverse COMMON_GIT_DIR or WORKTREE_GIT_DIR.
Do not inspect objects, refs, logs, hooks, configuration contents, or another
worktree’s administration.
Do not write, chmod, create, remove, rename, lock, refresh, or normalize
anything in Git administration.

A read-only access confined to this exception is explicitly conforming and must
not be classified as `PROCESS_BOUNDARY_BLOCK`.

Any other direct access beneath PRIMARY_WORKTREE is a process blocker.

## 3. Git command boundary

Use this complete environment for every Git invocation:

```text
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

Only the audit parent may execute Git.

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd exactly equal to IMPL_R;
- explicitly carry the complete environment above;
- be captured contemporaneously;
- retain full argv, cwd, environment, exit, stdout SHA-256, and stderr
  SHA-256.

Do not reconstruct a missing Git record afterward.

No auditor may execute Git.

## 4. Python and artifact boundary

Every Python process must use:

- pinned `$PYTHON`;
- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- an audit-owned private `TMPDIR`.

Never import a repository module directly from IMPL_R.

When function-level import is necessary:

1. copy exact source bytes to an audit-owned directory;
2. verify copied SHA-256 equals repository source;
3. import only the audit-owned copy;
4. retain source-copy identity and command;
5. remove only audit-owned temporary copies.

Repository tests may run as child commands against IMPL_R with `-I -S -B`; do
not import their module into an audit controller.

## 5. Clean full-object baseline

At opening require exact equality with RESTORED_INVENTORY:

- exactly 477 governed repository objects;
- exact path, type, mode, size, link-count, and SHA-256 equality;
- no `tools/evidence_verify/__pycache__`;
- no `.pyc`;
- no `.pyo`;
- no `.pytest_cache`;
- no additional ignored artifact.

Checkpoint the exact 477-object inventory:

1. after opening provenance;
2. after first-wave auditors;
3. after fourth auditor;
4. after targeted test 89;
5. after complete suites;
6. after compatibility and SEC-02;
7. before closing provenance;
8. after closing provenance.

On any object drift:

AUDIT_PROVENANCE_MISMATCH

Do not clean repository artifacts inside the audit.

## 6. Opening provenance gate

Require:

- physical root equals lexical IMPL_R;
- expected branch, HEAD, tree, parent, and absent upstream;
- exactly four modified tracked and nine untracked patch paths;
- zero staged, deleted, renamed, or unmerged;
- all 13 manifest rows exact;
- canonical manifest exact;
- tracked binary diff exact;
- recipe bytes and ID exact;
- 477-object inventory exact;
- implementation and restoration evidence present;
- caller exact;
- A6D and amendment manifests exact;
- conforming Git-administration marker/lock checks;
- no Git operation marker or lock.

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

After the complete gate passes, require AUDIT_ROOT absent and create it under
umask `077`:

```text
opening/
provenance/
perspectives/
validation/
findings/
closeout/
tmp/
```

Run RECIPE twice into fresh opening continuations.

Require:

- exits `0`;
- empty stderr;
- byte-identical output files and stdout;
- equality with EXPECTED_MANIFEST;
- manifest SHA-256:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- 477-object inventory unchanged.

## 7. Four distinct auditors

Create four distinct read-only auditor instances.

Start three concurrently:

1. Contract and authority auditor.
2. Marker-family and validator-correctness auditor.
3. Test and validation-adequacy auditor.

After one completes and closes, start a new fourth instance:

4. Security, filesystem, process, evidence, and artifact auditor.

Retry a failed start once.

If a required distinct auditor cannot start after one retry:

SUBAGENT_UNAVAILABLE

No nested delegation.
No auditor Git.
No auditor mutation.
No auditor cleanup.
No repository-module import.

Every auditor must receive:

- the reproduced canonical patch identity;
- IMPL_R as explicit cwd where supported;
- absolute repository and evidence operands;
- the corrected Git-administration exception;
- the prohibition on primary working-tree content;
- generic marker-family requirements;
- current authority and non-goals;
- standard finding format.

Each auditor’s report must state:

- actual cwd;
- exact absolute file operands used;
- whether any path under PRIMARY_WORKTREE was accessed;
- if so, whether it was within the allowed Git-administration exception.

Inherited cwd alone is not evidence of a violation. A violation requires an
actual file operand resolving to forbidden primary working-tree content.

## 8. Validator audit

Expected authority family:

execution-substrate.evidence-verification.trusted-host-contract.

Expected exact authority:

execution-substrate.evidence-verification.trusted-host-contract.v1

Independently establish:

1. marker-family grammar is generic, not a finite alternate-ID list;
2. arbitrary prose is not authority;
3. all four governing documents are scanned;
4. exactly one family block is required globally;
5. it must be in `evidence_verification.md`;
6. it must use exact v1;
7. BEGIN/END IDs must match;
8. unmatched markers reject;
9. nested/overlapping blocks reject;
10. consumer-document authority blocks reject;
11. strict v1 JSON and reference checks remain intact.

## 9. Independent causals

Build an audit-owned parser without importing the repository helper.

Run at least:

- live documents;
- v2, v27, `future-review-17`, and generated non-enumerated alternate IDs;
- alternate blocks in each consumer;
- mismatched IDs;
- unmatched begin;
- unmatched end;
- nested blocks;
- overlapping blocks;
- duplicate v1;
- unmarked family prose;
- unrelated HTML marker;
- lookalike non-family prefix.

Use complete valid contract-shaped JSON in balanced alternate blocks.

Independently reproduce:

- original 31 contradictions;
- seven producer family-marker cases;
- audit-only non-enumerated-ID cases.

Require mechanism-specific reasons.

## 10. Test execution

Run test 89 alone three times with pinned Python `-I -S -B`.

Require each owning command:

- exit 0;
- one test;
- zero failure/error/skip;
- all 38 producer cases execute;
- 477-object inventory unchanged.

Discover exactly 89 tests.

Run complete suite:

- twice under umask `077`;
- twice under umask `022`.

Require each owning command:

- pinned Python `-I -S -B`;
- exit 0;
- 89 tests;
- zero failure/error/skip;
- identical identity set;
- 477-object inventory unchanged.

## 11. Unchanged input audit

Require unchanged exact bytes for:

- all governing documents;
- boundaries;
- verifier;
- source-external caller;
- registry;
- all three layouts;
- both historical fixtures.

Confirm the only repository-byte change from the preceding target is
`test_verify_v1.py`.

## 12. Fresh compatibility

Using an audit-owned reconstruction of the documented caller:

### A6D

Run twice and require canonical stdout SHA-256:

3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606

### Amendment

Run twice and require canonical stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

For each require:

- exit 0;
- empty verifier stderr;
- deterministic output;
- mandatory nonclaims;
- unchanged target/package/TMPDIR snapshots;
- unchanged sealed manifest.

### Synthetic A6

Create an audit-owned fixture outside IMPL_R.

Run pre-seal twice, seal only that fixture, and run sealed twice.

Require deterministic output, empty stderr, and unchanged watched inputs.

### SEC-02

Run an audit-owned target-marker causal.

Require authenticated source-by-value execution never loads the target script,
marker remains absent, and direct-script predecessor shape is nonqualifying.

Do not claim atomic interpreter custody.

## 13. Evidence and authority audit

Inspect IMPLEMENTATION_EVIDENCE completely.

Require:

- vulnerable causals actually accepted;
- repaired causals use identical copied inputs;
- original 31 and added seven reasons remain specific;
- independent implementation validator does not import the test helper;
- final attempts selected correctly;
- failed attempts remain separate;
- compatibility not falsely claimed by implementation;
- no authority widening.

Require:

- verifier remains an ES-owned bounded slice rule;
- documentary contract and test evidence remain private assurance/evidence;
- no readiness, product, runtime, admission, orchestration, durable-state,
  commit, or publication authority;
- no public schema or cross-repository framework owner.

## 14. Prior-finding closure

Reconcile:

- TV-01;
- CT-01;
- AP-06;
- SEC-01;
- SEC-02;
- VC-01 / SEC-A1;
- EV-01 through EV-09;
- F-01 through F-04;
- PP-01;
- PE-02;
- TA-03;
- AP-04;
- AP-05;
- CA-01.

TV-01 closes only if generic scanning rejects non-enumerated identifiers.

AP-06 closes only if four distinct auditors complete.

Do not represent trusted-host scope as atomic custody.

## 15. Closing provenance

Remove only audit-owned fixtures outside IMPL_R.

Run RECIPE twice into fresh closing continuations.

Require:

- exits 0;
- empty stderr;
- byte-identical outputs;
- equality with EXPECTED_MANIFEST;
- manifest SHA-256:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- exact 477-object inventory;
- exact opening/closing repository identity;
- no repository or supplied-evidence mutation.

## 16. Verdict rules

### ACCEPT

Only if:

- opening and closing provenance match;
- 477-object inventory remains exact;
- four distinct auditors complete;
- no forbidden primary-working-tree content is accessed;
- allowed linked-worktree Git-administration checks remain narrowly bounded;
- generic family scanning passes independent causals;
- contradiction and test gates pass;
- compatibility and SEC-02 pass;
- no repository artifact or process blocker remains.

### PROCESS_BOUNDARY_BLOCK

Use only for:

- actual file access to forbidden primary working-tree content;
- nonconforming Git invocation;
- Git-administration access outside the narrow exception;
- Git-administration write;
- broad Git-administration traversal;
- repository-module import without bytecode suppression;
- missing required contemporaneous Git record.

Do not use this verdict merely because the linked-worktree Git directory is
lexically beneath PRIMARY_WORKTREE.

### AUDIT_PROVENANCE_MISMATCH

Use for repository bytes, object inventory, recipe, manifest, scope, or closing
identity mismatch.

### BLOCK

Use for a repairable source, test, evidence, validation, or authority defect.

### REJECT

Use only for a fundamental architecture or authority defect.

### SUBAGENT_UNAVAILABLE

Use when a required distinct auditor cannot start after one retry.

## 17. Complete inline report

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact target and identities.
4. Corrected working-tree versus Git-administration classification.
5. Restoration and 477-object baseline.
6. Opening and closing provenance.
7. Repository scope.
8. Four distinct auditor identities, roles, scheduling, cwd, operands, retries,
   and status.
9. Marker-family grammar and invariants.
10. Independent alternate-ID and location causals.
11. Mismatch/unbalanced/nested/overlap causals.
12. Original 31 and added seven cases.
13. Audit-only non-enumerated-ID cases.
14. Three targeted test-89 results.
15. Exact 89-test set and four suites.
16. Unchanged-input review.
17. A6D results.
18. Amendment results.
19. Synthetic A6 results.
20. SEC-02 result.
21. Eight full-inventory checkpoints.
22. No-write and deterministic-output evidence.
23. Implementation-evidence findings.
24. Authority and artifact adjudication.
25. Prior-finding closure table.
26. Severity-ranked residual findings.
27. Minority findings and parent resolution.
28. Remaining uncertainty and nonclaims.
29. Audit-created paths and cleanup.
30. Complete contemporaneous Git-process record.
31. Exact allowed Git-administration reads.
32. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No staging.
No commit.
No push.
No A6 restart.
```

## After `ACCEPT`

Proceed directly to the exact-byte commit gate for manifest `4a3a4244…18537`. The audit protocol requires a fresh read-only conversation, exact provenance before correctness inspection, and no repair during audit.  It also requires closeout provenance and permits removal only of audit-owned artifacts without changing repository bytes. 

### Sources

- The restoration re-established the exact 477-object baseline and unchanged patch provenance. 
- The implementation target remains the one-file alternate-authority repair and requires a fresh audit. 
- The project audit protocol separates implementation from a later fresh, read-only, provenance-first audit. 
- Provenance guidance treats bytecode and cache files as removable current-activity artifacts but forbids deletion of unrelated artifacts. 

**Confidence**

- The current repository remains on the correct clean audit target: **0.995**
- No restoration or implementation repeat is needed: **0.999**
- The process block was caused by an overbroad linked-worktree rule: **0.999**
- Narrow read-only Git-administration access is necessary and safe: **0.99**
- Correct next step is the revised fresh audit above: **1.00**
