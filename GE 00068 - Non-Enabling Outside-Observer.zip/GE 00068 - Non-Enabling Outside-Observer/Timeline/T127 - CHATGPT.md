## Assessment

This is ready for a **third, fresh independent audit**. It is not ready for commit yet.

The reported repair is properly bounded:

- Only `verify_v1.py` and `test_verify_v1.py` changed during this repair.
- The other eleven paths in the 13-path tranche remained byte-identical.
- All four residual findings from the second audit were addressed.
- The complete suite expanded from 52 to 59 tests and passed four times: twice under umask `077` and twice under `022`.
- Real A6D and amendment verification, synthetic pre-seal/sealed verification, causal replays, no-write checks, and final provenance all passed.
- The new canonical audit target is `5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57`.
- No staging, commit, A6 restart, or product execution occurred.

The architecture remains unchanged: this is still an ES-owned external closure verifier with committed layout specifications, supplied by exact source to an independent audit before its first commit. It neither verifies itself nor makes evidence authoritative.  The fresh audit must bind itself to the new manifest; neither prior audit applies after these byte changes. 

The new audit should be deliberately narrower on the residual causals while still auditing the whole 13-path patch. It must also preserve the procedural correction from EV-09: only the audit parent runs Git, every Git invocation is explicitly rooted at the implementation worktree, and no audit subagent runs Git.

## Codex prompt: third fresh independent audit

```text
Objective

Perform a third, fresh, read-only independent audit of the repaired Evidence
Verification v1 implementation.

Do not repair or modify the implementation.

The first audit found EV-01 through EV-08 plus audit-process finding EV-09.
The second audit confirmed most repairs but found four residual verifier
defects involving:

1. bounded manifest parsing;
2. seal-file scan-byte accounting;
3. malformed decimal suffix classification;
4. malformed layout-spec path classification.

The implementation parent reports those four findings repaired in exactly:

- tools/evidence_verify/verify_v1.py
- tools/evidence_verify/test_verify_v1.py

and reports that every other path in the 13-path tranche remained
byte-identical.

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

This is a new audit of new bytes. Neither previous audit qualifies or rejects
this target.

No repository mutation.
No formatting.
No repair.
No repository cleanup.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, live-service invocation, network contact, or Linux binary
execution.

No nested subagents.

## 1. Inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Repair-v2 implementation report:

EVIDENCE/audit-repair-v2/closeout/implementation-report-v2.json

Human-readable repair-v2 report:

EVIDENCE/audit-repair-v2/closeout/implementation-report-v2.md

Expected repaired canonical patch manifest:

Recover its exact retained path from the machine-readable implementation
report.

Expected canonical patch-manifest SHA-256:

5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57

Expected final provenance recipe source SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Recover from the repair-v2 report, without inference:

- the exact provenance recipe source path and bytes;
- exact tracked binary-diff SHA-256;
- exact verifier SHA-256;
- complete per-file identities;
- exact validation commands;
- exact 59-test identity set;
- exact vulnerable and repaired causal records.

If any required exact input is unavailable, return:

AUDIT_PROVENANCE_MISMATCH

Do not reconstruct, approximate, or substitute a prior value.

Previous audits, read-only:

AUDIT_V1=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

AUDIT_V2=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v2

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v3

## 2. Strict Git and process boundary

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every Git invocation must be exactly rooted as:

git -C "$IMPL_R" ...

and inherit:

GIT_OPTIONAL_LOCKS=0

No audit subagent may execute Git.

Do not execute Git in:

- the primary ES checkout;
- the Repair 10I candidate;
- A6D;
- A6D_AMEND;
- EVIDENCE;
- AUDIT_V1;
- AUDIT_V2;
- AUDIT_ROOT.

Do not use an implicit-current-directory Git invocation.

Record every parent Git argv, cwd, and relevant environment.

Any nonconforming Git command is an audit-process blocker. Disclose it and do
not silently continue.

## 3. Audit root

Require AUDIT_ROOT absent.

Create it under umask 077 with exactly:

opening/
provenance/
perspectives/
validation/
findings/
closeout/

All audit outputs remain beneath AUDIT_ROOT.

Remove only audit-owned temporary fixture roots. Do not remove, chmod,
normalize, or rewrite a repository or supplied-evidence object.

## 4. Opening repository gate

Require IMPL_R:

- physical root equals lexical path;
- root is a real directory;
- branch:
  codex/evidence-verification-v1;
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c;
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338;
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular;
- every working-tree mode 0644;
- every logical mode 100644;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no Git operation marker or lock;
- no path outside the expected set.

Expected paths:

1. PLANS.md
2. .docs/system_overview/boundaries.md
3. .docs/system_overview/artifact_hygiene.md
4. .docs/system_overview/capability_probing.md
5. .docs/system_overview/evidence_verification.md
6. tools/evidence_verify/verify_v1.py
7. tools/evidence_verify/registry_v1.json
8. tools/evidence_verify/layouts/a6d_successor_v1.json
9. tools/evidence_verify/layouts/a6d_amendment_v1.json
10. tools/evidence_verify/layouts/a6_policy_v1.json
11. tools/evidence_verify/test_verify_v1.py
12. tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt
13. tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Exact provenance gate

### 5.1 Exact recipe

Resolve the exact final provenance recipe only from the repair-v2 report and
retained repair-v2 evidence.

Require:

- exact recipe ID;
- complete source bytes;
- source SHA-256:
  bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333;
- explicitly rooted Git commands;
- deterministic locale;
- tracked modifications and untracked additions;
- path classifications;
- file type, logical mode, size, and SHA-256;
- deterministic tracked binary diff;
- deterministic raw-byte path sorting;
- canonical JSON;
- no timestamp, random value, hostname, username, or machine-specific
  absolute path in canonical output;
- output outside IMPL_R.

### 5.2 Reproduce twice

Run the exact recipe twice against IMPL_R.

Require:

- both exits successful;
- byte-identical output;
- exact equality with the retained repair-v2 canonical manifest;
- canonical manifest SHA-256:
  5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57;
- tracked binary-diff SHA-256 equal to the exact repair-v2 reported value;
- exact 13-path set;
- four tracked_modified;
- nine untracked;
- exact current per-file type, mode, size, and SHA-256;
- no extra path.

Stop before source inspection on any difference:

AUDIT_PROVENANCE_MISMATCH

### 5.3 Repair-chain disposition

Require the repair-v2 evidence to state truthfully:

- the first audit applies only to its predecessor bytes;
- the second audit applies only to its predecessor bytes;
- the four second-audit findings were repaired;
- registry and all three layout files remained byte-identical during repair-v2;
- only verify_v1.py and test_verify_v1.py changed during repair-v2;
- new validation and new provenance were generated;
- no stage, commit, push, or A6 restart occurred.

## 6. Audit perspectives

After exact provenance succeeds, create exactly four bounded read-only audit
perspectives.

Subagents may inspect source and audit-owned copies but execute no Git and
perform no repository write.

No nested subagents.

Roles:

1. Contract and authority auditor.
2. Verifier correctness and parser/resource auditor.
3. Test and validation adequacy auditor.
4. Security, filesystem, capability, and artifact auditor.

Every perspective receives:

- the same repaired canonical patch identity;
- exact verifier hash;
- unchanged registry and layout hashes;
- first-audit EV-01 through EV-09 ledger;
- second-audit four-finding ledger;
- repair-v2 implementation report;
- architecture target and non-goals.

Retry a failed perspective once.

Do not replace missing required coverage with silent parent inference.

Preserve minority findings.

## 7. Authority and whole-patch audit

Audit the complete 13-path patch, not only repair-v2 changes.

Require:

- verifier remains an ES-owned Bounded slice rule;
- output remains evidence/projection only;
- no readiness, product, runtime, admission, orchestration, durable-state, or
  execution authority;
- layouts remain structure-only;
- closeout and later audit retain readiness authority;
- no self-verification;
- no evidence-child-local verifier authority;
- no caller-supplied runtime layout;
- no amendment-chain model;
- no product API, schema, route, module, service, or runtime-contract change;
- repair-v2 does not widen authority or filesystem permission.

Generated evidence and proof tooling must remain explicitly
non-authoritative. 

## 8. Full verifier audit

Inspect the entire repaired verify_v1.py.

Re-audit every prior EV-01 through EV-08 mechanism, plus the second-audit
residuals.

### 8.1 Physical boundaries

Confirm:

- descriptor-bound package/target identity;
- physical ancestor-chain checks;
- case-alias resistance;
- candidate identity and parent ancestry;
- symlink and hardlink handling;
- no permissive pathname fallback;
- opening/closing identity stability.

Independently rerun the case-alias and containment adversarial cases in
audit-owned copies.

### 8.2 Literal-LF grammar

Confirm:

- literal byte LF is the sole separator;
- no splitlines or equivalent broad separator handling;
- one terminal LF;
- CR, vertical tab, form feed, NEL, Unicode separators, extra blank line, and
  missing final LF reject canonically.

### 8.3 Bounded package JSON

Confirm:

- source-byte limit;
- lexical depth preflight;
- correct string/escape handling;
- bounded depth;
- duplicate-key and float rejection;
- invalid UTF-8 behavior;
- no RecursionError traceback;
- one canonical failure line.

### 8.4 Bounded manifest reader

Audit the exact repaired algorithm.

Require:

1. Manifest identity and stat bound before read.
2. Derived hard maximum manifest size.
3. Rejection above maximum before body read.
4. Literal-LF incremental reading.
5. Fixed per-line ceiling.
6. Header/count validation before row allocation.
7. Count bound before row-list allocation.
8. Row field and lexical limits before path decoding.
9. Encoded path bound before base64 decoding.
10. Decoded path and segment bounds before storage.
11. Immediate duplicate and ordering rejection.
12. Immediate first-excess-row rejection.
13. Exact missing-row and trailing-data handling.
14. No read_bytes, unbounded split, or equivalent whole-input amplification.

Use audit-owned wrappers or monkeypatch seams to measure read and decode
behavior. Use small limits; do not create a large manifest.

Independently reproduce the second-audit malformed/oversized cases.

### 8.5 Seal-file and aggregate read accounting

Audit:

- pre-seal candidate stat and byte bound before read;
- sealed manifest stat and byte bound before read;
- sidecar exact-size bound before read;
- manifest and sidecar included in the structural scan accounting;
- payload sizes checked before read;
- aggregate payload budget checked before the overflow-causing read;
- each stability pass bounded;
- exact boundary behavior;
- no object read merely to discover it is above an admitted limit.

Instrument reads in small fixtures.

Require the real A6D and amendment children remain within admitted limits.

### 8.6 Decimal token parsing

Audit the canonical unsigned-decimal parser.

Require complete token consumption and rejection of:

- suffix;
- whitespace;
- sign;
- underscore;
- decimal point;
- exponent;
- NUL/control;
- non-ASCII digit;
- illegal leading zero;
- excessive lexical length.

Distinguish:

- lexical malformed:
  MANIFEST_CANONICAL;
- canonical numeric value above resource limit:
  the declared resource/closure error class.

Independently rerun the exact second-audit malformed-suffix causal.

### 8.7 Spec-path prevalidation

Audit one strict validator across:

- required root directories;
- required directories;
- required files;
- optional subtree roots.

Require rejection before any target filesystem operation for:

- absolute path;
- empty segment;
- dot;
- dot-dot;
- slash in segment;
- backslash;
- control/NUL;
- too many segments;
- excessive encoded bytes;
- invalid required-file mode;
- malformed optional subtree.

Instrument all target filesystem entry points and prove zero calls for invalid
specs.

Require malformed spec paths to map to the exact spec-schema error class and
not IO_OR_RACE.

Independently rerun the second-audit malformed-spec reproduction.

### 8.8 Capability, filesystem, and errors

Recheck:

- behavioral capability preflight;
- canonical IO_OR_RACE uncertainty;
- no traceback;
- no path fallback;
- directory descriptor lifetime;
- no-follow behavior;
- bounded hashing;
- exception handling;
- output minimization;
- no writes;
- no process or network invocation.

## 9. Test and validation audit

Inspect the complete current test source and discover the exact test set.

Expected:

- 59 tests;
- four complete runs:
  - twice under umask 077;
  - twice under umask 022;
- zero failure;
- zero error;
- zero skip.

Independently run the complete suite:

1. twice under umask 077;
2. twice under umask 022.

Require:

- identical discovered test identities;
- 59 passes every run;
- no skip;
- no repository artifact;
- deterministic relevant output.

Audit that tests causally cover:

- early manifest-size rejection;
- count-before-allocation;
- line and encoded-path bounds;
- decode-after-bound ordering;
- seal-file budget;
- sidecar exact-size handling;
- aggregate exact boundary and one-byte overflow;
- complete decimal token consumption;
- lexical versus numeric error classification;
- malformed spec rejection before target filesystem access;
- all prior EV-01 through EV-08 regressions;
- umask independence;
- isolated missing-root, expected symlink, and expected FIFO mechanisms.

Check for circular tests whose expected result is generated solely by the same
implementation path without an independent oracle.

## 10. Fresh compatibility validation

Use exact interpreter:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Require:

- version 3.13.4;
- size 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b.

Use:

- -I;
- -B;
- PYTHONDONTWRITEBYTECODE=1;
- LC_ALL=C;
- LANG=C;
- audit-owned private TMPDIR;
- no network.

Run independently:

1. AST parsing of all Python source.
2. Strict registry and three-spec parsing.
3. Complete test suite four times as above.
4. Sealed A6D verification twice.
5. Sealed amendment verification twice.
6. Synthetic A6 pre-seal verification twice.
7. Test-owned sealing.
8. Synthetic A6 sealed verification twice.
9. Repeated output byte comparison.
10. Before/after target and verifier-package snapshots.
11. Parent-only, explicitly rooted:
    git -C "$IMPL_R" diff --check
    with GIT_OPTIONAL_LOCKS=0.

Require real sealed children unchanged.

Require repeated outputs byte-identical.

## 11. Registry, layout, and repair-scope confirmation

Expected unchanged identities:

Registry:
e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

A6D successor layout:
267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc

A6D amendment layout:
3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4

A6 policy layout:
b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

Require exact equality.

Require repair-v2 to have modified only:

- tools/evidence_verify/verify_v1.py
- tools/evidence_verify/test_verify_v1.py

within the existing patch.

## 12. Security and artifact audit

Inspect IMPL_R for:

- __pycache__;
- pyc/pyo;
- .pytest_cache;
- generated manifests;
- databases;
- journals;
- locks;
- fixture roots;
- temporary output;
- unexpected executable modes;
- unsupported object types.

Require historical fixtures remain inert and are never imported or executed.

Review denial-of-service resistance under the declared bounds, including CPU,
memory, and repeated full-file hashing.

Determine whether residual resource amplification remains materially reachable
inside the documented maxima.

## 13. Repair evidence audit

Inspect:

- second-audit finding ledger;
- repair-v2 disposition;
- vulnerable and repaired causal records;
- all four 59-test runs;
- complete test list;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded attempts;
- cleanup;
- implementation report;
- final provenance.

Require:

- every second-audit finding explicitly closed;
- no prior audit represented as qualifying changed bytes;
- final validation bound to final bytes;
- no missing or overwritten failed attempt;
- registry/layout unchanged claim supported;
- no authority or security widening.

## 14. Parent adjudication

After all four perspectives return:

1. Preserve all material findings and disagreements.
2. Distinguish:
   - provenance mismatch;
   - residual patch defect;
   - repaired patch defect;
   - pre-existing issue;
   - audit-process issue;
   - future hardening seam.
3. Reconcile all prior findings against current source and fresh causals.
4. Audit the whole 13-path patch.
5. Do not accept solely because tests pass.
6. Do not reject because the tool is ES-local rather than cross-repository.
7. Perform no repair.

## 15. Closing provenance

Remove only audit-created temporary fixture roots.

Rerun the exact final provenance recipe twice.

Require:

- byte-identical output;
- equality with opening manifest;
- manifest SHA-256:
  5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57;
- exact tracked binary-diff from the repair-v2 report;
- repository identity unchanged;
- path set and per-file identities unchanged;
- staged/deleted/renamed/unmerged remain zero;
- no audit-created repository object;
- A6D and A6D_AMEND unchanged;
- AUDIT_V1 and AUDIT_V2 unchanged.

On difference:

AUDIT_PROVENANCE_MISMATCH

## 16. Finding format

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, pre-existing issue, or audit-process issue:
Blocking: yes | no

## 17. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use for any repository, recipe, manifest, path, byte, diff, or closing
provenance mismatch.

### REJECT

Use only for a fundamental authority or decomposition error that cannot be
repaired inside the bounded tranche.

### BLOCK

Use when any repairable correctness, security, resource, test, artifact, or
evidence defect remains.

### ACCEPT

Use only when:

- opening and closing provenance match;
- every prior blocking source finding is causally closed;
- the four second-audit findings are independently closed;
- authority boundaries remain sound;
- resource and parsing behavior are bounded and fail-closed;
- tests are mechanism-specific and umask-independent;
- real and synthetic compatibility checks pass;
- no artifact or report blocker remains;
- every audit Git command was parent-only and explicitly rooted.

## 18. Required final report

Include:

1. Verdict.
2. Opening and closing provenance.
3. New canonical manifest and tracked-diff digests.
4. Repository identity.
5. All four perspectives and completion status.
6. Closure table for every first- and second-audit finding.
7. Authority adjudication.
8. Full verifier correctness adjudication.
9. Bounded manifest-reader adjudication.
10. Seal-file accounting adjudication.
11. Decimal-classification adjudication.
12. Spec-path-prevalidation adjudication.
13. Test and validation adjudication.
14. Results under umask 077 and 022.
15. Real A6D/amendment checks.
16. Synthetic pre-seal/sealed checks.
17. Security, resource, and artifact adjudication.
18. Severity-ranked residual findings.
19. Minority findings.
20. Uninspected areas and uncertainty.
21. Audit-created files and cleanup.
22. Confirmation:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - every Git command parent-only and explicitly rooted;
    - nested subagents not created.

No repair.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

An `ACCEPT` result moves to the exact-byte commit gate. That gate may stage and commit only the accepted 13-path manifest; it may not repair or reinterpret the implementation. Any byte change returns the tranche to implementation and a new audit. 

The audit must reproduce the exact repaired provenance before reading the source and must repeat it at closeout. 

### Sources

- Codex’s `EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_IMPLEMENTED_READY_FOR_FRESH_REAUDIT` report supplied in this turn.
- Selected non-recursive verifier architecture. 
- Verifier scope and non-authority boundary. 
- Proof tooling and generated evidence remain non-authoritative. 
- Fresh audit required after repaired bytes. 
- Provenance-before-correctness sequence. 

**Confidence**

- Repair-v2 provenance readiness: **0.997**
- Correct next gate: third fresh independent audit, **0.999**
- Likelihood that the four second-audit findings are closed before re-audit: **0.91**
- Confidence that registry/layout/doc bytes should remain unchanged: **0.98**
- Confidence that no commit or A6 restart should occur before `ACCEPT`: **0.999**
