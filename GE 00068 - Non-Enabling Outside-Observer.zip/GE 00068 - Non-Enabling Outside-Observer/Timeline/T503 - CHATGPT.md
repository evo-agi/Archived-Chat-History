## Engineering assessment

The final repair attempt proved that almost the entire `run-full-audit` repair was correct. The only remaining blocker is a **top-level launch-versus-runtime self-authentication model that is too strict for macOS Framework Python**.

The rehearsal parent was launched through:

```text
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
```

but the running interpreter reported:

```text
/Library/Frameworks/Python.framework/Versions/3.13/Resources/Python.app/Contents/MacOS/Python
```

through `sys.orig_argv[0]`. macOS also injected `__CF_USER_TEXT_ENCODING` into the runtime environment. The harness flattened the platform-declared launch contract and the runtime-observed process state into one exact-equality predicate, so all three real-path rehearsals were demoted to `AUDIT_PROVENANCE_MISMATCH`. :chatgpt-content-reference{index="0"}

This is **not** a Generation-2 implementation-package defect. It is not evidence that the capsule lifecycle repair was wrong. In fact, all the difficult capsule mechanics passed:

- the exact 81-name confirmation registry and R01–R66 report registry were preserved;
- explicit P00–P24 terminal records were produced;
- canonical empty cleanup and four-input closing equality passed;
- all 15 fresh behavioral causals passed;
- temporal inventory, root row, byte-identical manifests, terminal reprojection, one seal transition, and no-postseal-write indicators passed in all three rehearsals;
- every capsule JSON had a schema;
- ACCEPT, BLOCK, and provenance-failure capsules all structurally closed. :chatgpt-content-reference{index="1"}

The old B00/D01–D14 suite still passed exactly at `15 / 595`; all repair matrices passed; process custody passed; all synthetic verdict lanes passed; and the current bundle compatibility replay passed without issuing a package verdict. :chatgpt-content-reference{index="2"}

The real-path rehearsals failed only on the same parent self-authentication rule. Each independent capsule validator reported exactly `parent-self-authentication`; their normalized structures otherwise matched. :chatgpt-content-reference{index="3"}

### Why another localized patch is not appropriate

Attempt 3 was consumed when compilation began. The frozen rules explicitly prohibit Attempt 4 and same-root retry. Codex correctly retired the implementation generation and produced no PYZ v2 or authority v3. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

The next step is therefore **not another source repair**. It is a narrow operating-model correction followed by a new clean implementation generation.

The governing model must separate three facts:

1. **Platform-declared launch custody**  
   Exact executable requested, argv, cwd, explicit environment, stdin, shell/TTY/detachment, PID creation, streams, exit, and signal. This remains externally owned.

2. **Runtime-observed interpreter state**  
   `sys.executable`, `sys._base_executable`, `sys.orig_argv`, Python flags, runtime environment, cwd, PID, and source/PYZ identity.

3. **A typed crosswalk between them**  
   The crosswalk may accept only an exact, frozen interpreter-resolution chain and a bounded platform-injected environment delta. It must not use basename matching, path-prefix matching, generic `realpath`, or an arbitrary environment allowlist.

For this Mac, the contract should support:

- an exact declared Framework Python launcher;
- an exact observed Python.app runtime image proven to belong to that launcher and Python installation;
- exact equality of the argument tail after the executable-token distinction;
- exact preservation of every declared environment key/value;
- an optional, specifically classified `__CF_USER_TEXT_ENCODING` runtime injection;
- rejection of every other extra or changed environment entry.

### Progression decision

First create a **sealed successor governing documentary package** that freezes this launch/runtime dual-view model. Do not implement source in the same tranche.

After that package seals, start a **new clean harness implementation generation**. It must not copy or patch the retired Attempt-3 source, although it may use the retained failure records as historical defect evidence.

---

## Complete replacement Codex prompt

```text
FREEZE A SUCCESSOR GOVERNING DOCUMENTARY CONTRACT FOR
TOP-LEVEL LAUNCH/RUNTIME DUAL-VIEW SELF-AUTHENTICATION

MACOS FRAMEWORK PYTHON AND BOUNDED PLATFORM ENVIRONMENT INJECTION

Objective

Create and terminally close a successor governing documentary package that
resolves the sole remaining operating-model defect exposed by the retired
Generation-2 clean audit-harness implementation:

- the platform declared launch through the pinned Framework Python executable;
- the running Python process reported a different exact Python.app runtime
  image through sys.orig_argv[0];
- macOS injected __CF_USER_TEXT_ENCODING into the runtime environment;
- the retired harness incorrectly required flattened exact equality across
  launch-declared and runtime-observed facts.

Freeze a typed dual-view authority model that keeps:

1. platform-declared launch custody;
2. runtime-observed process evidence;
3. the self-authentication crosswalk

separate and explicit.

This is a documentary-contract tranche only.

Do not implement future harness production source.
Do not implement future harness qualification source.
Do not implement future harness independent-validator source.
Do not compile or package a harness.
Do not create a PYZ.
Do not execute run-full-audit.
Do not execute implementation production source.
Do not adjudicate the Generation-2 implementation package.
Do not construct the authoritative current schema subject.
Do not modify the current content bundle or its authority JSON.
Do not modify the current governing documentary package.
Do not modify the predecessor harness PYZ or authority v2.
Do not modify or resume the retired Attempt-3 build root.
Do not perform another historical package-findings reconciliation.

The task may create bounded documentary-package tooling, observation programs,
matrices, and independent validators used solely to freeze and validate this
successor documentary package. They are not future harness source.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read .git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned documentary build in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_BLOCKED

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT GOVERNING DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

CURRENT_GOVERNING_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifest A:

manifest/documentary-manifest-a-v2.json

- device:
  16777234
- inode:
  181887816
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Expected manifest B:

manifest/documentary-manifest-b-v2.json

- device:
  16777234
- inode:
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Expected physical closure:

- total entries including root:
  50;
- directories:
  9;
- regular files:
  41;
- root row:
  exactly one;
- empty directories:
  0;
- symlinks/special objects:
  0;
- multiply linked regular files:
  0;
- directory/file modes:
  0700 / 0600;
- cache/bytecode:
  absent.

Authenticate:

- root identity;
- temporal identity;
- A/B identities;
- A/B byte equality;
- terminal-manifest reprojection;
- root row;
- topology and modes;
- one terminal seal transition;
- no-write-after-seal evidence.

Resolve current documentary roles only through:

contract/current-governing-documentary-role-registry-v2.json

Required predecessor semantics remain unchanged:

- exactly five documentary domains;
- exactly 66 runtime report rows;
- exactly 81 runtime confirmation names;
- exactly 15 runtime matrices;
- exactly 595 runtime matrix cases;
- stale 645 rejected;
- report, confirmation, and matrix domains separate;
- future implementation registries and authenticated inputs represented by
  owner classes rather than new documentary domains.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. RETIRED HARNESS PACKAGE EVIDENCE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_HARNESS_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-attempt2-qw4sqw4r/gen2-clean-source-external-independent-audit-harness-v1.pyz

Expected identity:

- device:
  16777234
- inode:
  181950905
- mode:
  0400
- link count:
  1
- size:
  1442390
- SHA-256:
  19496183b8eb3e7545f9ebda8f966a41839ad67251239d5be2ba801d84cb0174

PREDECESSOR_HARNESS_AUTHORITY_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-authority-v2-output-b1a0mfnn/gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json

Expected identity:

- device:
  16777234
- inode:
  182023548
- mode:
  0400
- link count:
  1
- size:
  81008
- SHA-256:
  782dd6a5d26508bd9bcd7942336d1cab4f1600fde37fabff314d0b8f4291691e

Classify both as:

historical_noncurrent_retired_harness_generation

They are:

- immutable;
- noncurrent;
- nonauthoritative for a future launch;
- evidence-only;
- not future source;
- not cleanable in this task.

Do not copy, patch, import, execute, translate, or use any PYZ source member as
future implementation source.

Permitted evidence use:

- exact CLI contract;
- exact predecessor source/member identities;
- historical matrix and qualification identities;
- historical source-attempt count;
- comparison with the retired failure evidence.

Require exact opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. RETIRED ATTEMPT-3 FAILURE EVIDENCE
──────────────────────────────────────────────────────────────────────────────

RETIRED_ATTEMPT_3_ROOT:

/private/tmp/ES-repair10i-v3-clean-independent-audit-harness-v2-attempt-3-9nguf5ow

Expected root identity:

- device:
  16777234
- inode:
  182077072
- mode:
  0700

Expected disposition:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V2_IMPLEMENTATION_BLOCKED

Open only this exact path.

Do not scan for it.

If present:

- authenticate exact root identity;
- inventory it read-only;
- authenticate exact named records through its retained registries and reports;
- require opening/closing equality;
- do not execute any retained source or tooling.

At minimum authenticate:

validation/repair-qualification-process-v1.json
closing/input-closing-equality-v1.json
closeout/failure-outcome-v1.json

Authenticate the governing defect facts:

- final source attempt 3 was consumed;
- no Attempt 4 is permitted;
- all 25 sources compiled;
- B00 and D01–D14 passed exactly at 15 / 595;
- capsule-evidence matrix passed;
- mode-aware confirmation matrix passed;
- mode-aware report matrix passed;
- terminal-frame matrix passed;
- process-custody qualification passed;
- all 15 fresh behavioral causals passed;
- synthetic ACCEPT/BLOCK/provenance lanes passed;
- bounded compatibility replay passed;
- temporal inventory and byte-identical manifests succeeded in all three
  real-path rehearsals;
- every rehearsal capsule had schema-bearing records;
- parent self-authentication failed because:
  - submitted executable was the pinned Framework Python launcher;
  - sys.orig_argv[0] reported the Python.app runtime image;
  - macOS injected __CF_USER_TEXT_ENCODING;
- every rehearsal capsule validator reported only:
  parent-self-authentication;
- no PYZ v2 or authority v3 was created;
- the retired generation requires a new clean implementation generation.

If the exact root is absent:

- do not search for it;
- retain it as unavailable historical evidence;
- use the fresh platform observations required below as current authority;
- do not infer any missing record.

Classify this root as:

bounded_retired_harness_failure_evidence

It is not source authority.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT-AUTHORITY FILES
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

These files are fixed input identities and closing-equality operands only.

Do not inspect original contaminated package roots.

──────────────────────────────────────────────────────────────────────────────
5. FRESH SUCCESSOR DOCUMENTARY ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-audit-harness-launch-runtime-dual-view-contract-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Before running observation processes retain:

opening/bootstrap-start.json
opening/successor-documentary-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-documentary-package-authentication-v1.json
opening/retired-harness-disposition-v1.json
opening/retired-attempt-3-disposition-v1.json
opening/process-execution-policy-v1.json

Authority is limited to:

- fixed-input authentication;
- platform/runtime observation;
- launch/runtime authority definition;
- interpreter-resolution definition;
- environment-injection definition;
- documentary matrices;
- independent documentary validation;
- supplied-input closing equality;
- successor documentary terminal closure.

Nonauthority includes:

- future harness source implementation;
- implementation repair;
- implementation-package adjudication;
- current-subject construction;
- product/runtime/target/repository activity;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
6. PLATFORM/RUNTIME OBSERVATION SOURCE
──────────────────────────────────────────────────────────────────────────────

Before running any observation, create and freeze one bounded documentary
observation source:

tooling/launch-runtime-observer-v1.py

This is documentary-package tooling only.

It must:

- use Python standard library only;
- read no stdin;
- create no file;
- create no child;
- access no network;
- access no Git/VCS;
- emit exactly one canonical JSON object to stdout;
- emit empty stderr on success;
- exit zero on success.

The object must retain:

- schema;
- PID;
- UID;
- GID;
- cwd;
- sys.executable;
- sys._base_executable when present;
- sys.orig_argv;
- sys.argv;
- sys.flags fields relevant to:
  - isolated;
  - no_site;
  - dont_write_bytecode;
  - ignore_environment;
  - safe_path when present;
- Python version;
- implementation name;
- complete runtime environment as sorted key/value rows;
- runtime timestamp;
- source identity;
- no file effects;
- no child effects.

Compile the source with the pinned interpreter and:

-I -S -B

Require exit zero and empty stderr.

Freeze its exact source identity before execution.

Do not modify it after compilation.

──────────────────────────────────────────────────────────────────────────────
7. EXACT PLATFORM OBSERVATION INVOCATION
──────────────────────────────────────────────────────────────────────────────

Run the observer three physically distinct times.

For each run use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<EXACT_FROZEN_OBSERVER_PATH>

Submitted cwd:

the fresh documentary-contract root

Explicit submitted environment only:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

For each launch retain external platform custody:

- submitted executable path;
- submitted executable no-follow identity;
- argv;
- cwd;
- explicit environment;
- stdin/shell/TTY/detachment;
- PID;
- start/completion;
- duration;
- stdout/stderr;
- exit/signal;
- reaping;
- descriptor closure.

Strict-parse each observer result.

Require:

- three successful runs;
- exact observer source identity;
- no filesystem effect;
- no child effect;
- stable submitted launch contract;
- stable runtime semantic observations except explicitly classified physical
  fields such as PID and timestamp.

Retain:

validation/launch-runtime-observation-run-1-v1.json
validation/launch-runtime-observation-run-2-v1.json
validation/launch-runtime-observation-run-3-v1.json
validation/launch-runtime-observation-stability-v1.json

──────────────────────────────────────────────────────────────────────────────
8. THREE-VIEW AUTHORITY MODEL
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/top-level-launch-runtime-three-view-authority-v1.json

Define exactly three views.

A. PLATFORM_DECLARED_LAUNCH

Externally authoritative for:

- top-level process creation;
- submitted executable path and identity;
- submitted argv;
- submitted cwd;
- submitted explicit environment;
- stdin;
- shell;
- TTY;
- detachment;
- PID creation;
- start/completion;
- raw streams;
- exit/signal;
- reaping;
- descriptor closure.

The audit capsule may reference these expected values but cannot self-attest
top-level creation.

B. RUNTIME_OBSERVED_PROCESS

Process-owned evidence for:

- runtime executable path;
- base executable path;
- sys.orig_argv;
- sys.argv;
- Python flags;
- Python version and implementation;
- runtime environment;
- runtime cwd;
- runtime PID;
- source/PYZ self-identity;
- audit-root identity.

This view does not redefine the submitted launch.

C. SELF_AUTHENTICATION_CROSSWALK

Audit-owned adjudication of:

- exact platform-declared contract;
- exact runtime observation;
- interpreter-resolution chain;
- argv relationship;
- cwd equality;
- PID equality where externally supplied;
- Python flag requirements;
- environment-preservation policy;
- source/PYZ identity;
- authority boundaries.

The crosswalk may pass or fail self-authentication.

It may not claim top-level process creation authority.

Rules:

- no flattened platform/runtime object;
- no generic object equality;
- no basename comparison;
- no prefix comparison;
- no unbounded realpath comparison;
- no first-match fallback;
- no environment-subset success without the exact policy below;
- every difference explicitly classified.

──────────────────────────────────────────────────────────────────────────────
9. INTERPRETER-RESOLUTION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/macos-framework-python-interpreter-resolution-v1.json

Use the fresh observation results to freeze the exact current resolution chain.

At minimum distinguish:

DECLARED_INTERPRETER_LAUNCHER

Expected submitted path:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

and:

RUNTIME_INTERPRETER_IMAGE

Expected observed path derived from fresh runs.

The historical observation suggests:

/Library/Frameworks/Python.framework/Versions/3.13/Resources/Python.app/Contents/MacOS/Python

but do not promote that prose value unless all fresh observations establish it.

For every chain node retain:

- exact path;
- role;
- no-follow type;
- device;
- inode;
- mode;
- link count;
- size;
- SHA-256;
- framework-version root;
- Python version;
- observed fields that bind it.

For every edge retain:

- source node;
- target node;
- relationship classification;
- evidence;
- permitted direction;
- acceptance effect.

Required acceptance rule:

- submitted executable must equal the exact declared-launcher node;
- runtime executable must equal an exact allowed terminal node;
- sys.orig_argv[0] must equal an exact allowed runtime executable token under
  this chain;
- every remaining original-argv token must match the frozen submitted token
  sequence after the exact executable-token distinction;
- Python version and required flags must match;
- no alternate version, inode, hash, or path is accepted;
- no generic symlink, basename, framework-prefix, or realpath-only rule is
  sufficient.

Unknown or ambiguous resolution fails closed.

──────────────────────────────────────────────────────────────────────────────
10. PLATFORM ENVIRONMENT-INJECTION POLICY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/platform-runtime-environment-policy-v1.json

Define:

DECLARED_ENVIRONMENT

The exact five submitted rows:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

RUNTIME_ENVIRONMENT

The complete runtime-observed environment.

Acceptance rules:

1. Every declared key must exist at runtime.
2. Every declared value must match exactly.
3. A runtime key may not override or reinterpret a declared key.
4. Extra runtime keys must be a subset of an exact frozen platform-injection
   allowlist.
5. Every allowlisted key requires:
   - exact name;
   - value grammar;
   - semantic classification;
   - authority:
     none;
   - configuration effect:
     none;
   - verdict effect:
     none when valid;
   - failure behavior when invalid.
6. Unknown extra key fails closed.
7. Missing declared key fails closed.
8. Changed declared value fails closed.
9. Generic “environment superset” acceptance is forbidden.

Use the fresh observations to adjudicate __CF_USER_TEXT_ENCODING.

If all observations establish it, freeze:

- key:
  __CF_USER_TEXT_ENCODING;
- classification:
  MACOS_PLATFORM_INJECTED_NONAUTHORITY_ENVIRONMENT;
- optional presence:
  true, unless fresh evidence and governing semantics require mandatory
  presence;
- exact value grammar derived from observation;
- UID relationship when present;
- no acceptance-bearing configuration effect.

Do not hard-code the historical value from prose.

The future contract should remain valid if the platform omits the optional
injected key, provided every declared key remains exact and no unknown extra
appears.

──────────────────────────────────────────────────────────────────────────────
11. ARGV, CWD, PID, FLAGS, AND SOURCE CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/parent-runtime-observation-crosswalk-v1.json

Freeze exact rules for:

A. argv

- submitted argv retained externally;
- runtime sys.orig_argv retained internally;
- executable token adjudicated through the interpreter-resolution contract;
- all remaining tokens exact;
- no missing, extra, reordered, combined, or duplicated required option;
- script/PYZ operand exact;
- application operands exact.

B. cwd

- submitted cwd exact;
- runtime cwd exact;
- equality required;
- no normalization beyond the exact frozen policy.

C. PID

- platform-created PID retained externally;
- runtime PID retained internally;
- equality required when both are present;
- the capsule does not claim PID creation authority.

D. Python flags

Require exact effective posture for:

- isolated;
- no_site;
- dont_write_bytecode;
- ignore_environment or its exact governing interpretation;
- safe_path when supported.

No environment variable may substitute for a missing command-line flag.

E. source/PYZ identity

- future harness PYZ exact identity;
- runtime-executing archive identity;
- source/member self-authentication;
- source freeze;
- no post-freeze modification.

──────────────────────────────────────────────────────────────────────────────
12. FUTURE CAPSULE SELF-AUTHENTICATION RECORD
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/parent-runtime-self-authentication-record-v2.json

Required future record:

opening/parent-runtime-self-authentication.json

Required top-level fields:

- schema;
- platform_declared_launch;
- runtime_observed_process;
- interpreter_resolution;
- argv_crosswalk;
- environment_crosswalk;
- cwd_crosswalk;
- pid_crosswalk;
- flag_crosswalk;
- source_identity_crosswalk;
- top_level_process_authority;
- self_authentication;
- findings;
- first_blocker;
- timestamp.

Required authority statement:

top_level_process_authority = external_platform_wrapper

The record must never claim to prove process creation.

Self-authentication success must be derived from the typed crosswalk rows, not a
generic aggregate Boolean.

Every failed row retains an exact reason and evidence pointer.

──────────────────────────────────────────────────────────────────────────────
13. LAUNCH/RUNTIME MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 80 uniquely named cases.

A. Exact baselines

- exact declared launcher plus exact observed runtime image;
- exact baseline with allowlisted injected environment key present;
- exact baseline with optional injected key absent.

B. Declared executable

- wrong path;
- wrong inode;
- wrong hash;
- wrong version;
- symlink substitution;
- executable missing;
- special object;
- multiply linked file;
- mode mismatch.

C. Runtime executable

- exact allowed runtime image;
- wrong framework version;
- wrong runtime image path;
- correct path/wrong inode;
- correct path/wrong hash;
- unknown image;
- launcher reported as runtime image when not permitted;
- ambiguous two-terminal chain.

D. argv

- exact token-tail baseline;
- missing -I;
- missing -S;
- missing -B;
- duplicate flag;
- combined flags;
- reordered application operands;
- extra operand;
- missing script/PYZ operand;
- wrong script/PYZ operand;
- executable token differs under a valid resolution edge;
- executable token differs without a valid edge.

E. cwd/PID/flags

- exact cwd;
- wrong cwd;
- normalized-but-not-exact cwd;
- exact PID;
- wrong PID;
- missing external PID;
- missing runtime PID;
- isolated false;
- no_site false;
- dont_write_bytecode false;
- environment substitution for a required flag.

F. environment

- exact declared environment;
- allowed optional injection present;
- allowed optional injection absent;
- missing declared key;
- changed declared value;
- extra unknown key;
- multiple unknown extras;
- injected key wrong value grammar;
- injected key wrong UID relation;
- injected key overrides declared key;
- empty runtime environment;
- generic superset accepted incorrectly;
- generic subset accepted incorrectly.

G. authority boundaries

- external launch record missing;
- runtime observation missing;
- crosswalk missing;
- capsule claims top-level process creation;
- external platform record treated as runtime evidence;
- runtime record treated as platform creation authority;
- flattened equality model;
- basename fallback;
- prefix fallback;
- generic realpath fallback;
- first-match chain selection.

H. source identity

- exact frozen PYZ;
- source drift;
- member drift;
- wrong source freeze;
- missing source identity;
- stale predecessor PYZ.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/launch-runtime-dual-view-mutation-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
14. INDEPENDENT DUAL-VIEW VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a documentary source-external validator that imports neither:

- observation producer helpers;
- mutation generator;
- expected-result map;
- contract projector;
- producer normalizer.

It must independently:

1. authenticate every fixed input;
2. authenticate observer source;
3. authenticate all three platform process captures;
4. parse all three runtime observations;
5. reconstruct the declared launcher identity;
6. reconstruct the runtime-image identity;
7. reconstruct the exact interpreter-resolution chain;
8. independently compare argv tails;
9. independently compare cwd;
10. independently compare PID;
11. independently compare required flags;
12. reconstruct declared and runtime environments;
13. independently identify injected keys;
14. validate the exact injection policy;
15. reject every unknown extra;
16. validate the 80-plus mutation cases independently;
17. validate authority separation;
18. validate the future self-authentication record schema;
19. verify no future harness source exists;
20. require zero errors.

Retain:

validation/independent-launch-runtime-dual-view-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
15. DOCUMENTARY PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain independently authored projections:

analysis/perspective-platform-launch-authority-v1.json
analysis/perspective-runtime-observation-authority-v1.json
analysis/perspective-interpreter-resolution-v1.json
analysis/perspective-environment-injection-v1.json
analysis/perspective-future-capsule-self-authentication-v1.json
analysis/perspective-new-implementation-boundary-v1.json

Reconcile them in:

analysis/launch-runtime-dual-view-perspective-reconciliation-v1.json

Require:

- no disagreement;
- no open operating-model decision;
- no hidden implementation decision;
- no package-verdict change;
- no documentary-domain change;
- no runtime-registry change;
- exact successor-contract identity binding.

──────────────────────────────────────────────────────────────────────────────
16. SUCCESSOR DOCUMENTARY ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-governing-documentary-role-registry-v3.json

The v3 registry must:

- preserve every current v2 governing role through exact predecessor-package
  identity binding;
- add exactly one current role for each new v3 artifact;
- mark v2 package:
  historical predecessor after v3 terminally seals;
- contain no duplicate current role;
- contain no ambiguous role;
- contain no source implementation role;
- contain no harness-package role.

At minimum add current roles for:

- three-view authority model;
- interpreter-resolution contract;
- environment-injection policy;
- argv/cwd/PID/flags/source crosswalk;
- parent self-authentication record v2;
- observation source registry;
- three observation results;
- observation stability result;
- mutation matrix;
- independent validator;
- six perspectives;
- perspective reconciliation;
- package status;
- explicit confirmations.

──────────────────────────────────────────────────────────────────────────────
17. PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/launch-runtime-dual-view-contract-status-v1.json

Required status:

gen2-clean-audit-harness-launch-runtime-dual-view-contract-frozen-pending-new-clean-implementation-generation

Required facts:

- predecessor documentary package authenticated:
  true;
- five documentary domains unchanged:
  true;
- runtime report rows unchanged:
  66;
- runtime confirmation names unchanged:
  81;
- runtime matrix rows unchanged:
  15;
- runtime matrix cases unchanged:
  595;
- platform-declared and runtime-observed views separated:
  true;
- top-level process authority external:
  true;
- interpreter-resolution chain frozen:
  true;
- environment-injection policy frozen:
  true;
- __CF_USER_TEXT_ENCODING posture:
  derived from fresh observation;
- generic environment superset acceptance:
  false;
- basename/prefix/realpath fallback:
  false;
- future self-authentication schema frozen:
  true;
- retired Attempt-3 generation current:
  false;
- future implementation source present:
  false;
- future implementation authority:
  false;
- real audit executed in this task:
  false;
- implementation verdict issued:
  false;
- next treatment:
  NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION.

──────────────────────────────────────────────────────────────────────────────
18. SUPPLIED-INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- predecessor documentary package;
- predecessor harness PYZ;
- predecessor harness authority v2;
- current content bundle;
- current content authority.

If the retired Attempt-3 root was opened, repeat its complete no-follow
inventory.

Require exact opening/closing equality.

Do not mutate or clean any supplied input.

──────────────────────────────────────────────────────────────────────────────
19. TERMINAL SUCCESSOR-PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before terminal projection:

- finalize every nonclosure output;
- create only used directories;
- ensure closeout/ and manifest/ already exist;
- retain no empty descendant;
- reserve temporal, manifest A, and manifest B paths;
- retain their descriptors;
- freeze directory set.

Then:

1. independently generate temporal bytes twice in memory;
2. require equality;
3. write temporal through retained descriptor;
4. fsync and reopen no-follow;
5. independently reproject temporal cut;
6. independently generate manifest A and B from one frozen namespace;
7. require byte equality;
8. write through retained descriptors;
9. fsync files and directories;
10. reopen no-follow;
11. verify path/descriptor inode equality;
12. independently reproject final root;
13. require root row exactly once;
14. require no empty descendant;
15. require no symlink or special object;
16. require no multiply linked regular file;
17. require directory/file modes 0700/0600;
18. require no cache or bytecode;
19. transition seal once;
20. emit guarded verdict and terminal marker;
21. exit nonreturningly;
22. perform no postseal filesystem or tool operation.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process records and streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- supplied-input closing equality;
- terminal posture;
- same-root retry false.

Do not create success manifests on failure.

Return provenance mismatch for:

- fixed-input mismatch;
- observation-process custody failure;
- supplied-input mutation;
- prohibited source use;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- terminal-closure failure;
- postseal activity.

──────────────────────────────────────────────────────────────────────────────
21. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

only when:

- all fixed inputs authenticate;
- predecessor documentary package terminal closure authenticates;
- retired Attempt-3 defect evidence authenticates or is explicitly unavailable;
- observer source freezes;
- three platform observations complete;
- observation stability closes;
- three-view authority model freezes;
- interpreter-resolution contract freezes;
- environment-injection policy freezes;
- argv/cwd/PID/flag/source crosswalk freezes;
- future self-authentication record v2 freezes;
- mutation matrix passes;
- independent validator passes;
- six perspectives reconcile;
- successor role registry closes;
- package status closes;
- supplied inputs close equal;
- successor package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_BLOCKED

when:

- fresh observations disagree materially;
- the interpreter relationship cannot be uniquely authenticated;
- environment-injection semantics remain ambiguous;
- an operating-model decision remains open;
- independent validation fails without a provenance failure.

Return:

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_PROVENANCE_MISMATCH

for provenance failures defined in Section 20.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor-contract root identity
3. Predecessor documentary-package identity
4. Predecessor PYZ identity
5. Predecessor authority-v2 identity
6. Current content-bundle identity
7. Current content-authority identity
8. Retired Attempt-3 evidence identity/disposition
9. Documentary authority and nonauthority
10. Observer-source identity
11. Observer compilation result
12. Observation run 1 platform custody
13. Observation run 1 runtime result
14. Observation run 2 platform custody
15. Observation run 2 runtime result
16. Observation run 3 platform custody
17. Observation run 3 runtime result
18. Observation-stability result
19. Platform-declared launch view
20. Runtime-observed process view
21. Self-authentication crosswalk authority
22. Declared interpreter identity
23. Runtime interpreter identity
24. Exact interpreter-resolution chain
25. Declared environment
26. Runtime environment
27. Injected-environment adjudication
28. __CF_USER_TEXT_ENCODING policy
29. argv crosswalk
30. cwd crosswalk
31. PID crosswalk
32. Python-flag crosswalk
33. Source/PYZ identity crosswalk
34. Future parent self-authentication record v2
35. Launch/runtime mutation matrix
36. Independent dual-view validator
37. Platform-launch perspective
38. Runtime-observation perspective
39. Interpreter-resolution perspective
40. Environment-injection perspective
41. Future-capsule perspective
42. New-implementation-boundary perspective
43. Perspective reconciliation
44. Current v3 documentary-role registry
45. Successor package status
46. Confirmation no future harness source was created
47. Confirmation no real audit was executed
48. Confirmation no implementation verdict was issued
49. Supplied-input closing equality
50. Failure-closeout capability and use
51. Temporal-inventory identity
52. Manifest A identity
53. Manifest B identity
54. Terminal reprojection
55. Terminal topology and modes
56. No-write-after-closure
57. Remaining uncertainty and nonclaims
58. Explicit documentary confirmations

Required confirmations:

PREDECESSOR_DOCUMENTARY_PACKAGE_IDENTITY_MATCHED
PREDECESSOR_DOCUMENTARY_PACKAGE_TERMINAL_CLOSURE_AUTHENTICATED
PREDECESSOR_PYZ_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V2_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
RETIRED_ATTEMPT_3_DISPOSITION_AUTHENTICATED_OR_EXPLICITLY_UNAVAILABLE
NO_RETIRED_SOURCE_USED_AS_IMPLEMENTATION_SOURCE
OBSERVER_SOURCE_FROZEN
OBSERVER_SOURCE_NOT_MODIFIED_AFTER_FREEZE
THREE_PLATFORM_OBSERVATIONS_COMPLETED
THREE_PLATFORM_OBSERVATIONS_STABLE
PLATFORM_DECLARED_LAUNCH_VIEW_FROZEN
RUNTIME_OBSERVED_PROCESS_VIEW_FROZEN
SELF_AUTHENTICATION_CROSSWALK_VIEW_FROZEN
TOP_LEVEL_PROCESS_AUTHORITY_EXTERNAL
DECLARED_INTERPRETER_IDENTITY_AUTHENTICATED
RUNTIME_INTERPRETER_IDENTITY_AUTHENTICATED
INTERPRETER_RESOLUTION_CHAIN_UNIQUE
NO_BASENAME_PREFIX_OR_GENERIC_REALPATH_FALLBACK
DECLARED_ENVIRONMENT_EXACT
RUNTIME_DECLARED_KEYS_PRESERVED
PLATFORM_INJECTED_ENVIRONMENT_POLICY_FROZEN
UNKNOWN_RUNTIME_ENVIRONMENT_KEY_REJECTED
CF_USER_TEXT_ENCODING_POLICY_DERIVED_FROM_FRESH_OBSERVATION
ARGV_EXECUTABLE_TOKEN_DISTINCTION_FROZEN
ARGV_NONEXECUTABLE_TOKENS_EXACT
CWD_CROSSWALK_FROZEN
PID_CROSSWALK_FROZEN
PYTHON_FLAG_CROSSWALK_FROZEN
SOURCE_IDENTITY_CROSSWALK_FROZEN
FUTURE_PARENT_SELF_AUTHENTICATION_SCHEMA_FROZEN
LAUNCH_RUNTIME_MUTATION_MATRIX_PASSED
INDEPENDENT_DUAL_VIEW_VALIDATOR_PASSED
SIX_DOCUMENTARY_PERSPECTIVES_RECONCILED
NO_OPEN_OPERATING_MODEL_DECISION
FIVE_DOCUMENTARY_DOMAINS_UNCHANGED
RUNTIME_REPORT_REGISTRY_UNCHANGED
RUNTIME_CONFIRMATION_REGISTRY_UNCHANGED
RUNTIME_MATRIX_REGISTRY_UNCHANGED
PACKAGE_ACCEPTANCE_SEMANTICS_UNCHANGED
CURRENT_V3_DOCUMENTARY_ROLE_REGISTRY_COMPLETE
FUTURE_IMPLEMENTATION_SOURCE_NOT_CREATED
FUTURE_IMPLEMENTATION_AUTHORITY_FALSE
NEXT_TREATMENT_NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
SUCCESSOR_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_MANIFEST_A_CREATED
SUCCESSOR_MANIFEST_B_CREATED
SUCCESSOR_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

the next tranche is a new clean harness implementation generation governed by:

- the predecessor five-domain documentary package;
- this successor launch/runtime dual-view package;
- the current content snapshot bundle;
- the current content authority JSON.

Do not classify that future generation as Attempt 4 of the retired generation.

Do not copy or patch the retired Attempt-3 source.

Do not combine contract freezing with source implementation.
```

### Sources

The final source attempt failed only because it treated the launch-declared Framework Python path and the runtime-observed Python.app image as the same fact, and rejected macOS’s injected `__CF_USER_TEXT_ENCODING`. :chatgpt-content-reference{index="6"}

All capsule lifecycle, mode-aware projection, matrix, custody, causal, and synthetic-verdict work otherwise passed. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

All real-path rehearsals failed on exactly `parent-self-authentication`, while their structural invariants and cleanup passed. :chatgpt-content-reference{index="9"}

Attempt 3 is consumed, no Attempt 4 is allowed, and the implementation generation is retired. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

**Confidence:** 0.999 that no Generation-2 implementation-package defect was established; 0.999 that the capsule lifecycle repair itself succeeded; 0.995 that the remaining issue is an authority-model defect between launch-declared and runtime-observed state; 0.98 that freezing this dual-view model before a new clean implementation generation is the safest route.
