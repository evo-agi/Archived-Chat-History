## Assessment

This addendum closes the two gaps from the previous pass. The correct next step is a **fresh independent audit**, not another implementation or producer-closeout turn.

The repository manifest is now unambiguous: two fresh runs of the exact retained recipe produced byte-identical 3,193-byte manifests with the full SHA-256:

```text
6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445
```

The shorter 60-character value was correctly classified as a report transcription defect rather than repository drift. 

The stale-source validation gap is also closed. All 54 affected causals—12 caller negatives, 31 descriptor-snapshot cases, and 11 depth cases—were rerun against the exact final caller SHA-256 `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`, with zero unexpected outcomes, failures, errors, or skips. 

The three especially important postcommit behaviors were then exercised on those same final bytes:

- shared-output failure did not downgrade or corrupt a committed accepted bundle;
- parent-descriptor cleanup failure did not downgrade acceptance;
- a post-publication hook fault was contained without rerunning precommit validation or altering the bundle. 

The addendum also verified the retained eight-run compatibility evidence, reproduced opening and closing repository and supplied-root equality, and sealed itself with two byte-identical manifests. 

### Audit attention points, not pre-audit blockers

The independent auditor should still examine:

1. **Harness relocation equivalence.** The addendum relocated retained test sources and strengthened one nested Python command to `-I -S -B`. It reports unchanged causal assertions, but that equivalence should be independently inspected. 
2. **The reconstructed opening-gate summary.** The underlying opening checks preceded allocation, but one retained summary was reconstructed at closeout. The auditor should reproduce repository provenance rather than treating that summary as authority. 
3. **Normal-main failure mapping.** Some internal snapshot causals naturally expose exceptions such as `FileNotFoundError` or `NotImplementedError`. The audit should confirm that full caller execution maps equivalent uncertainty into the intended nonaccepted caller result without traceback or misleading output.
4. **Supported-local ancestry scope.** The audit must judge the implementation against the documented Model C plus Model E contract—not silently reintroduce an in-scope hostile output-ancestry mover that the contract explicitly excludes. The implementation selected atomic bundle-parent publication under a trusted stable-ancestry precondition. 

No source repair is presently justified.

## Codex prompt — fresh independent audit

```text
MANDATORY RESPONSE FORMAT

Embed the complete audit report inline in Markdown. Links may be supplemental
evidence, but must not replace any required section.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

This is a fresh, read-only independent audit. Do not repair or modify the
implementation.

ADMINISTRATIVE PRE-EPOCH RULE

Reading this prompt or its attachment from an unrelated non-repository
directory before the audit epoch is explicitly permitted and is not audit
evidence. It must not be classified as a process violation merely because of
its cwd.

After the prompt has been read, begin the audit epoch. From that point:

- every repository Git command must use `git -C "$IMPL_R" ...`;
- repository-facing subprocess cwd must be exactly IMPL_R unless a private
  audit fixture requires AUDIT_ROOT;
- do not use the primary checkout as cwd or content operand;
- do not inspect or mutate primary-working-tree content;
- narrow read-only Git-administration checks derived from Git for the linked
  worktree are permitted when necessary;
- do not invent additional process-boundary stop conditions beyond this
  prompt.

A corrected audit-owned harness attempt does not by itself invalidate the
audit. Retain failed attempts separately. Block only when a supplied root was
mutated, required provenance was destroyed or unavailable, a required
perspective could not be obtained, or a substantive/provenance defect remains.

## 1. Objective

Independently audit the completed Evidence Verification v1 atomic-bundle-v4
repository patch, exact source-external caller, implementation evidence,
validation output, and read-only closeout addendum.

The audit must determine whether the exact target may receive ACCEPT for this
bounded implementation slice.

Do not infer product readiness, Repair 10I correctness, commit authorization,
or A6 readiness from verifier or caller evidence.

## 2. Frozen repository target

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Require:

- branch:
  `codex/evidence-verification-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- upstream:
  absent
- governed repository inventory:
  exactly 477 objects
- working patch:
  exactly four modified tracked and nine untracked paths
- staged/deleted/renamed/unmerged:
  `0/0/0/0`
- no unexplained ignored artifact, cache, bytecode, or test cache
- canonical repository-manifest SHA-256:
  `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`
- full-index tracked binary-diff SHA-256:
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`
- five-path implementation delta SHA-256:
  `c676ce5dcedb36fdf66cb3fafff9f89c32c0e151e94818aa6e59cf6df284b69f`

Treat the earlier 60-character manifest string as superseded transcription,
not as an audit target.

Required Git-child environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Stop with AUDIT_PROVENANCE_MISMATCH before correctness inspection on any
repository, recipe, path-set, file-identity, manifest, or diff mismatch.

## 3. Exact supplied inputs

REPAIR_V4_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr

OUTPUT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-bundle-output-9228k2d1

ADDENDUM_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-closeout-addendum-643fc7d12dd2-vf2cjujv

RECON_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu

HISTORICAL_BLOCK_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im

FINAL_CALLER=$REPAIR_V4_ROOT/source/launch_v4_trusted_host_atomic_bundle.py

Require FINAL_CALLER:

- size:
  `49047`
- SHA-256:
  `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`

Require v3 base:

- path:
  `$REPAIR_V4_ROOT/source/base_v3_atomic_publish_exact.py`
- size:
  `45678`
- SHA-256:
  `3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631`

Require source delta:

- path:
  `$REPAIR_V4_ROOT/provenance/source-delta.diff`
- SHA-256:
  `53dd0f4d0bc7a41584b76fa530afbdf40aabbe219aecd4c7a0c90989307d8bca`

Require the two repair manifests to be byte-identical at:

`78499711a01ac70a60613b139daf36b25d512d3d121543d5f0dfb94eea30e3ad`

Require the two addendum manifests to be byte-identical at:

`f9690f9ce0822d7f5bcc2daed385bd5461b2ed4febc824724c47ae3cc3d2f6ea`

Require the existing validation-output inventory to match its retained closure.
Do not write into REPAIR_V4_ROOT, OUTPUT_ROOT, ADDENDUM_ROOT, RECON_ROOT, or
HISTORICAL_BLOCK_AUDIT.

## 4. Exact provenance recipe

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Require:

- size:
  `5143`
- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
- recipe ID:
  `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`

Run the exact recipe twice at audit opening into fresh audit-owned continuations.
Require:

- both exits 0;
- empty stderr;
- stdout equals each output file;
- outputs byte-identical to one another;
- outputs byte-identical to the two addendum repository manifests;
- SHA-256 exactly
  `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`;
- every one of the 13 path records matches live bytes;
- tracked binary diff equals
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`.

Repeat provenance at final closeout.

## 5. Fresh audit-root posture

After opening provenance matches, atomically allocate one fresh audit root with
Python `tempfile.mkdtemp` beneath `/Users/ds/Downloads`, prefix:

`ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-`

Use umask `077`.

Parent alone retains audit files. Auditors return reports to the parent; they
do not write files.

Require:

- all retained directories mode `0700`;
- all retained files regular, single-link, mode `0600`;
- exclusive creation for retained files;
- all fixtures, TMPDIRs, caller copies, outputs, and test artifacts beneath
  AUDIT_ROOT;
- no repository or supplied-root write;
- no retained bytecode or cache.

## 6. Four independent audit perspectives

Only after provenance matches, run four distinct read-only auditors.

Start auditors 1–3 concurrently. After one closes, start auditor 4. Retry a
failed start once. If a required perspective cannot be obtained after the
retry, return BLOCK and report the coverage gap. Do not replace it silently
with parent inference.

Each auditor receives the same exact repository manifest, caller hash, source
delta, repair-manifest hash, addendum-manifest hash, current contract, and
non-goals.

No nested subagents.

### Auditor 1 — contract and authority

Inspect:

- `PLANS.md`
- `.docs/system_overview/evidence_verification.md`
- `.docs/system_overview/artifact_hygiene.md`
- `.docs/system_overview/capability_probing.md`
- `.docs/system_overview/boundaries.md`
- contract test in `test_verify_v1.py`
- reconnaissance decision
- implementation and addendum reports

Determine:

- whether trusted-host contract v2 has one authoritative writer;
- whether Model C atomic bundle-parent publication plus Model E stable ancestry
  is expressed consistently;
- whether unsupported hostile/shared/mover cases are honestly excluded;
- whether any text claims race-proof lexical custody, crash durability,
  atomic interpreter custody, production attestation, readiness, execution,
  commit, or publication authority;
- whether the 59 contract mutations adequately protect the 37-field contract;
- whether there is any current or target authority widening.

### Auditor 2 — caller correctness and state semantics

Inspect the complete exact final caller and source delta.

Verify:

- one complete private stage bundle;
- exactly three output files;
- all rejecting checks precede the sole commit point;
- the sole commit is one exclusive directory rename;
- arbitrary and canonical accepted-looking foreign bundles remain foreign,
  unchanged, and unattributed;
- postcommit exceptions cannot downgrade acceptance;
- shared-output projection is non-authoritative and non-gating;
- no postcommit pathname/durability check contradicts the model;
- no hidden fallback;
- containment checks cover target, package, candidate, TMPDIR, caller evidence,
  repair root, and interpreter installation;
- stable-ancestry reliance is explicit rather than represented as a kernel
  guarantee;
- v4 schema and the preserved 25 field names have coherent meanings.

Explicitly inspect why the retained `invalid_record_destination` harness
observed exit 1 and why parent replacement was caught through `SystemExit`.
Determine whether normal full-caller execution still gives a canonical,
nonaccepted, nondisclosing result.

### Auditor 3 — tests, validation, and provenance adequacy

Inspect:

- all 89 repository tests;
- 59 trusted-host mutation cases;
- 17 bundle-publication causals;
- retained 12/31/11 test sources and records;
- addendum harness relocation record and unified deltas;
- producer and addendum failed-attempt indexes;
- eight retained compatibility bundles.

Determine whether:

- relocated harnesses retain the same causal assertions;
- adding `-I -S -B` changes only execution isolation, not expected semantics;
- the complete final-source test evidence binds the exact caller bytes;
- failed harness attempts are correctly excluded;
- no shared oracle hides a material gap;
- the reconstructed opening-gate summary is non-authoritative and adequate
  underlying provenance remains independently reproducible.

### Auditor 4 — security, filesystem, process, and artifacts

Inspect:

- descriptor and no-follow behavior;
- exclusive rename capability and probe;
- stage/final identity;
- parent and ancestry assumptions;
- file modes, links, redaction, and disclosure;
- process and descriptor cleanup;
- repair/output/addendum inventories;
- exact output record contents and shared projection;
- source-by-value SEC-02 behavior;
- secrets and private-path non-disclosure.

Classify generated evidence as evidence/projection only.

Each auditor reports:

- evidence with exact path and line;
- inference;
- uncertainty;
- blocking and nonblocking findings;
- scope not inspected;
- mutation performed: no;
- Git performed: no;
- nested subagents created: no.

Preserve disagreements.

## 7. Parent-owned independent validation

Use pinned Python 3.13.4 with `-I -S -B`,
`PYTHONDONTWRITEBYTECODE=1`, C locale, private AUDIT_ROOT TMPDIRs, and no
repository import that can create bytecode.

### 7.1 Repository tests

Run:

- test 89 alone at least once;
- complete 89-test suite once under umask `077`;
- complete 89-test suite once under umask `022`.

Require exact identity sets and zero failure, error, or skip.

### 7.2 Exact final-source regressions

Independently reproduce against caller SHA-256
`643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`:

- all 12 caller negatives;
- all 31 descriptor-snapshot causals;
- all 11 depth causals.

Use audit-owned byte-exact copies only where hook injection requires import.
Recheck the caller hash before each owning group.

Require:

- 54 expected outcomes;
- no unexpected pass or rejection;
- no failure, error, or skip;
- expected classifications;
- no accepted attribution on failure;
- no traceback or forbidden absolute path in normal caller output;
- no watched-root write;
- no fixture, process, descriptor, cache, or stage survivor.

### 7.3 Bundle and postcommit causals

Independently exercise on exact final caller bytes:

- all 17 bundle-publication causals;
- arbitrary foreign bundle collision;
- canonical accepted-looking foreign bundle collision;
- retry after success;
- retry after precommit failure;
- shared-stdout failure after successful commit;
- parent-close failure after successful commit;
- postcommit hook fault after successful commit;
- one out-of-contract ancestry-mover causal.

For the mover causal:

- retain it as explicit unsupported-host evidence;
- do not count it as qualifying supported-local success;
- verify docs and records make no race-proof path-custody claim;
- do not demand that Model C alone withstand an in-scope hostile mover.

For every accepted bundle require exactly three files, no stage, canonical v4
JSON, empty errors, matching sidecars, and the mandatory nonclaims.

### 7.4 Compatibility

Using fresh audit-owned output roots physically disjoint from the caller
evidence:

- sealed A6D twice;
- sealed amendment twice;
- synthetic A6 twice pre-seal and twice sealed;
- one SEC-02 target-marker causal.

Require deterministic output within each pair/stage, unchanged watched inputs,
expected manifest hashes, no target script execution, and no product or
readiness claim.

## 8. Audit adjudication

Classify findings by:

- contract or authority drift;
- caller correctness;
- filesystem/process/security defect;
- test or validation inadequacy;
- provenance mismatch;
- artifact or disclosure defect;
- audit-process issue;
- pre-existing issue;
- report-only uncertainty.

ACCEPT only if:

- provenance matches exactly;
- no blocking correctness, authority, security, validation, or artifact finding
  remains;
- the supported-local stable-ancestry precondition is coherent and honestly
  bounded;
- final-source validation is independently reproduced sufficiently to support
  the verdict;
- repository and supplied roots remain unchanged.

Use BLOCK for a repairable defect or material required-coverage gap.

Use REJECT only for a fundamental architectural or authority failure that
cannot be repaired within this bounded tranche.

Do not repair the target.

## 9. Closing gates

At closeout:

- rerun the exact recipe twice into fresh closeout continuations;
- require equality with opening and the corrected canonical target;
- repeat repository branch, HEAD, tree, parent, upstream, status, staged state,
  full 477-object inventory, diff digest, and `git diff --check`;
- repeat full read-only inventories of REPAIR_V4_ROOT, OUTPUT_ROOT,
  ADDENDUM_ROOT, RECON_ROOT, and any historical audit input used;
- remove only audit-owned temporary fixtures;
- require audit TMPDIR empty;
- require no process or descriptor survivor;
- verify every retained audit file is mode `0600`, single-link, and every
  retained directory is mode `0700`.

## 10. Required inline report

Include:

1. Verdict.
2. Administrative pre-epoch disclosure.
3. Exact repository and supplied-input identities.
4. Opening and closing provenance.
5. Exact 13-path manifest and corrected manifest hash.
6. Four auditor identities, schedule, operands, findings, and disagreements.
7. Contract and authority adjudication.
8. Complete caller/state-machine adjudication.
9. Stable-ancestry premise and mover-causal disposition.
10. Harness-relocation adjudication.
11. Repository test results.
12. Exact 12 caller-negative results.
13. Exact 31 snapshot results.
14. Exact 11 depth results.
15. Bundle, collision, retry, and postcommit causal results.
16. A6D results.
17. Amendment results.
18. Synthetic A6 results.
19. SEC-02 result.
20. Schema, disclosure, no-write, process, and artifact findings.
21. Prior-finding reconciliation.
22. Severity-ranked residual findings.
23. Minority findings and parent resolution.
24. Inspection limits and explicit nonclaims.
25. Audit-created paths and cleanup.
26. Closing equality and provenance.
27. Explicit confirmations:
    - repository mutation not performed;
    - supplied-evidence mutation not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.
```

## Disposition

- **Producer implementation:** complete.
- **Producer provenance:** reconciled.
- **Final-source regression validation:** reconciled.
- **Fresh independent audit:** now the critical path.
- **Further source edits:** not justified before audit.
- **Commit or A6 restart:** still blocked.

### Sources

The addendum expressly identifies itself as a read-only audit-input capsule rather than an independent correctness assessment. 

It establishes the corrected repository manifest and resolves the earlier malformed value as a transcription defect. 

It binds all 54 rerun causals to the exact final caller bytes and records zero unexpected outcomes. 

It verifies the retained compatibility evidence and states that this remains producer evidence rather than independent qualification. 

**Confidence**

- Provenance confidence: **0.995**
- Producer-validation confidence: **0.97**
- Pre-audit implementation confidence: **0.90**
- Confidence that fresh independent audit is now the correct next step: **0.995**
