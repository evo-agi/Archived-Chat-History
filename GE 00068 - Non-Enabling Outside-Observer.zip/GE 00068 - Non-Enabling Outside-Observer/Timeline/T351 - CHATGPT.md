## Assessment

This is a **real parent-audit source defect**, not another checker false positive. The source was correctly withheld from freeze.

The defect is narrow and well established:

- Both independent analyses found the same reachable path.
- After terminal manifests become authoritative, the source still performs reads and terminal-output operations that can raise.
- Those exceptions can escape to the outer `BaseException` handler.
- That handler can create directories and write/fsync failure files.
- The result would be a filesystem write after terminal closure, invalidating the sealed capsule.

The package under audit remains untouched and unaudited. No package implementation, findings reconciliation, or target work is authorized.

The parent-source repair should make the terminal boundary explicit:

1. Complete both manifest writes, reopenings, byte comparisons, and all potentially failing filesystem checks **before** declaring terminal closure.
2. Set one `terminal_seal_committed` state only after those checks pass.
3. From that point, allow only best-effort writes to stdout/stderr and immediate process termination.
4. Make the outer failure handler fail closed without filesystem writes whenever `terminal_seal_committed` is true.
5. Independently prove through AST and bytecode control-flow analysis that no file-writing sink is reachable after the seal state.

This should be the final bounded source repair. Do not reconstruct the entire audit harness again.

```text
BOUNDED POSTSEAL CONTROL-FLOW REPAIR AND EXACT-BYTE PARENT-SOURCE FREEZE

This task repairs one confirmed structural defect in the finite parent-audit
source, then qualifies and freezes the repaired bytes.

It is not:

- a successor-package audit;
- a successor-package repair;
- a findings reconciliation;
- a V3 target audit;
- a repository or product audit.

Do not inspect or access any successor package, predecessor package, blocking
audit, launcher package, reconciliation package, candidate repository,
Strategic B, V1/V2/V3 target, product source, or unrelated evidence.

Do not use the network.
Do not run Git.
Do not run product or repository tests.
Do not create subagents.
Do not emit `AUDIT_EPOCH_START`.
Do not execute the complete parent audit.

Return exactly one primary verdict:

PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_READY
PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

SOURCE_PREFLIGHT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-preflight-mot27ibm

Expected root identity:

- device/inode:
  16777234 / 179686447
- mode:
  0700

Expected candidate path:

opening/source-attempts/attempt-0001.py

Expected candidate identity:

- size:
  167291
- SHA-256:
  c532092395cadf3517af22aab4275e1f05b0714abe39cf9fb3f7c33c5af2709e
- regular:
  true
- link count:
  1
- mode:
  0600

Expected preflight manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  3539 each
- SHA-256:
  79d85e59ad98771a8eeba299ad6400ba4f7131c2197ae5b00ef7b900c1738f4b
- byte-identical:
  required

Expected preflight temporal inventory:

closeout/temporal-final-inventory.json

- SHA-256:
  93e947e77eec371f0ed73e9b57305853fe8aa20c99e6ca4bb0d06b4bd4c41b5f

Authenticate the root and complete manifest closure before reading the source.

Capture a complete lstat/no-follow opening inventory.

Do not modify, resume, clean, normalize, or chmod this root.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING DEFECT EVIDENCE
──────────────────────────────────────────────────────────────────────────────

POSTSEAL_PREFLIGHT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-freeze-frnjqy83

Expected identity:

- device/inode:
  16777234 / 179745065
- mode:
  0700
- verdict:
  PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED

Expected terminal manifests:

- size:
  4631 each
- SHA-256:
  6e2d42e971b4e8be8db942d4aa47ccf44839be4296c86fcf49c489f2f8ec1ba9
- byte-identical:
  required

Expected temporal inventory:

- SHA-256:
  a6916e8a97fbce21b548f1dab72102359fada0593672f7a673c1b4ec1bb63096

Authenticate and inspect:

validation/postseal-write-check-a.json
validation/postseal-write-check-b.json
validation/postseal-write-reconciliation.json
validation/structural-crosswalk-25.json
validation/final-static-preflight.json
closeout/final-report.md

The adopted defect is exactly:

- both terminal manifests can be finalized;
- later reads or terminal-stream operations can raise;
- the outer `BaseException` handler remains reachable;
- that handler performs filesystem mutation;
- therefore a filesystem-writing path remains reachable after terminal seal.

No other source change is authorized unless it is indispensable to close this
exact control-flow defect.

──────────────────────────────────────────────────────────────────────────────
3. FRESH REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-parent-audit-source-postseal-repair-

Immediately emit:

SOURCE_REPAIR_ROOT=<absolute-path>

Before editing retain:

opening/bootstrap-start.json

including:

- fresh-root identity;
- allocation method;
- umask;
- source-preflight root identity;
- postseal-preflight root identity;
- supplied package roots inspected:
  [];
- audit epoch begun:
  false.

Create directories lazily. Do not retain empty directories.

──────────────────────────────────────────────────────────────────────────────
4. EXACT OPENING SOURCE COPY
──────────────────────────────────────────────────────────────────────────────

Copy the exact 167291-byte source to:

opening/original-parent-source.py

Use:

- no-follow source open;
- exclusive destination creation;
- mode 0600;
- complete byte write;
- fsync;
- close;
- no-follow reopen;
- byte comparison;
- pre/post-read fstat stability.

Retain:

opening/original-source-identity.json

The copied bytes must remain exactly:

- size:
  167291
- SHA-256:
  c532092395cadf3517af22aab4275e1f05b0714abe39cf9fb3f7c33c5af2709e

──────────────────────────────────────────────────────────────────────────────
5. BOUNDED SEMANTIC REPAIR
──────────────────────────────────────────────────────────────────────────────

Create one repaired candidate:

working/parent-source-repaired.py

Only terminal-seal control flow may change.

Preserve all other audit-harness semantics and constants, including:

- supplied roots and identities;
- phase order P00–P18;
- child recorder;
- dynamic root-locator handling;
- materialization commands;
- handoff commands;
- Finding A and C oracles;
- Finding H and I audit phases;
- Finding J and field-map parsers;
- security analysis;
- cleanup-set equality;
- preseal conditions;
- verdict rules.

Do not alter package-audit acceptance rules to obtain a passing source
preflight.

──────────────────────────────────────────────────────────────────────────────
6. REQUIRED TERMINAL-SEAL MODEL
──────────────────────────────────────────────────────────────────────────────

Implement one explicit terminal-seal state:

`terminal_seal_committed`

or an equivalently unambiguous single state.

Initial value:

false

It may become true exactly once.

It may become true only after:

1. every nonmanifest artifact is final;
2. the temporal final inventory is final;
3. manifest A is completely written, fsynced, closed, and reopened;
4. manifest B is completely written, fsynced, closed, and reopened;
5. both manifest bytes are independently regenerated;
6. both on-disk manifest identities match;
7. both manifests are byte-identical;
8. complete root closure is revalidated;
9. no later acceptance-bearing filesystem check remains.

Every filesystem read or observation that can affect seal validity must occur
before this state becomes true.

No manifest reread or filesystem closure check may remain after
`terminal_seal_committed = true`.

──────────────────────────────────────────────────────────────────────────────
7. SUCCESS TERMINAL REGION
──────────────────────────────────────────────────────────────────────────────

After `terminal_seal_committed` becomes true, control must enter one bounded,
nonreturning terminal-success region.

The region may perform only:

- a best-effort write of:
  `AUDIT_TERMINAL_SEAL_COMPLETE\n`
  to file descriptor 1;
- optionally a bounded best-effort stderr diagnostic;
- immediate `os._exit(0)`.

The terminal stream write is report-only and nonauthoritative.

It must be locally guarded so that any catchable stream error cannot escape to
the outer filesystem-writing handler.

An acceptable structure is semantically equivalent to:

```
terminal_seal_committed = True

try:
    os.write(1, b"AUDIT_TERMINAL_SEAL_COMPLETE\n")
except BaseException:
    pass

os._exit(0)
```

or a no-return helper with the same closed behavior.

Do not use:

- `print`;
- high-level stream buffering whose flush escapes the local guard;
- any filesystem read;
- any filesystem write;
- any manifest observation;
- any record creation;
- any cleanup;
- any report finalization;
- any normal `return`.

The success region must not return to the outer handler.

──────────────────────────────────────────────────────────────────────────────
8. OUTER FAILURE-HANDLER GUARD
──────────────────────────────────────────────────────────────────────────────

The outer catchable-failure handler may write failure evidence only while:

`terminal_seal_committed == false`

Add an explicit fail-closed guard before every call or route into the
filesystem-writing failure handler.

Required semantic behavior:

```
except BaseException as exc:
    if terminal_seal_committed:
        os._exit(0)
    retain_preseal_failure(exc)
    ...
```

The exact implementation may differ, but require:

- no filesystem mutation when seal state is true;
- no failure record after authoritative terminal seal;
- no terminal-success downgrade;
- no generic-handler fallthrough after seal;
- no postseal cleanup or continuation;
- no administrative continuation.

The guard is defense in depth. The successful terminal region must already
catch its own stream failures and terminate.

──────────────────────────────────────────────────────────────────────────────
9. SEAL-POINT FIELD MAP
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/terminal-seal-control-flow-v1.json

Record:

- seal-state variable;
- initialization location;
- sole transition location;
- required preconditions;
- manifest-finalization locations;
- last filesystem read before seal;
- last filesystem write before seal;
- success-region location;
- outer-handler guard location;
- allowed postseal operations;
- prohibited postseal operations;
- authority effect;
- nonauthority;
- process-exit semantics.

Require one transition and no reset.

──────────────────────────────────────────────────────────────────────────────
10. EXACT SEMANTIC DELTA
──────────────────────────────────────────────────────────────────────────────

Retain a complete original-to-repaired source delta.

For every changed hunk record:

- original line range;
- repaired line range;
- exact defect repaired;
- control-flow effect;
- filesystem-authority effect;
- unrelated semantics changed:
  false.

Expected repair ownership:

`parent-audit-terminal-seal-control-flow`

No unrelated source hunk is permitted.

If another semantic change is indispensable, stop with:

PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_BLOCKED

Do not widen the repair silently.

──────────────────────────────────────────────────────────────────────────────
11. COMPILATION GATE
──────────────────────────────────────────────────────────────────────────────

Compile the repaired candidate without executing it using:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

with:

-I -S -B

Use in-memory `compile(..., "exec")`.

Do not use `py_compile`.
Do not create `.pyc` or `__pycache__`.

Require:

- exit 0;
- empty stdout;
- empty stderr;
- repaired bytes unchanged.

Retain:

validation/repaired-source-compilation.json
validation/repaired-source-compilation.stdout
validation/repaired-source-compilation.stderr

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT POSTSEAL CHECK A
──────────────────────────────────────────────────────────────────────────────

Implement a path-sensitive AST and call-graph analysis.

It must:

1. Identify the sole seal-state transition.
2. Identify every successor control-flow edge.
3. Classify every reachable call after seal.
4. Resolve `os.write` descriptor values.
5. Treat descriptor 1 and descriptor 2 as terminal streams.
6. Treat unresolved or file-backed descriptors as possible filesystem sinks.
7. Identify every reachable exception edge.
8. Prove no exception edge after seal reaches a filesystem-writing handler.
9. Prove terminal success cannot return.
10. Prove all manifest reads and checks occur before seal.

Retain:

validation/postseal-write-check-a.json

Require pass.

──────────────────────────────────────────────────────────────────────────────
13. INDEPENDENT POSTSEAL CHECK B
──────────────────────────────────────────────────────────────────────────────

Implement a second checker without importing checker A or its traversal helper.

Use compiled bytecode, exception tables, and an independently built control-flow
graph.

It must prove:

- the seal transition;
- no file-mutating opcode/call is reachable afterward;
- terminal-stream `os.write` is locally exception-contained;
- `os._exit(0)` dominates terminal completion;
- the generic failure-handler filesystem sinks are unreachable from the sealed
  state;
- no postseal return reaches ordinary function epilogue.

Retain:

validation/postseal-write-check-b.json

Require pass.

──────────────────────────────────────────────────────────────────────────────
14. POSTSEAL MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create fresh in-memory source mutations and require both checkers to reject:

1. manifest reread after seal;
2. `Path.read_bytes` after seal;
3. file creation after seal;
4. failure-record write after seal;
5. cleanup after seal;
6. unresolved `os.write(fd, ...)` after seal;
7. stdout write without local exception containment;
8. stderr write without local exception containment;
9. terminal helper that can return;
10. generic handler without the seal guard;
11. seal transition before manifest verification;
12. second seal transition;
13. seal reset to false;
14. postseal exception routed into `_top_level_catchable_failure`;
15. normal `return` after seal instead of `os._exit`.

Also require both checkers to accept safe controls:

- locally guarded `os.write(1, ...)`;
- locally guarded `os.write(2, ...)`;
- immediate `os._exit(0)`;
- in-memory constant evaluation;
- no-return terminal helper.

Retain:

validation/postseal-mutation-matrix.json

Require:

- exact case set;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
15. COMPLETE 25-ITEM STRUCTURAL CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Re-run the complete 25-item crosswalk against the repaired source.

Require 25/25.

For item 25, bind:

- seal-state transition;
- allowed postseal stream operations;
- no postseal filesystem sink;
- no handler reachability;
- no-return exit.

Retain:

validation/structural-crosswalk-25-repaired.json

──────────────────────────────────────────────────────────────────────────────
16. STATIC NONINTERACTIVE GATE
──────────────────────────────────────────────────────────────────────────────

Re-run the complete static noninteractive gate.

Require no reachable:

- stdin read;
- interactive loop;
- command socket;
- externally driven phase loop;
- administrative continuation;
- replacement parent;
- import-time audit execution;
- import-time supplied-root access;
- direct child launch outside the recorder;
- direct-auditor or subagent interface.

Require:

- one finite main;
- finite P00–P18 plan;
- bounded failure path;
- bounded nonreturning success path;
- top-level failure handling only before seal.

Retain:

validation/repaired-source-static-preflight.json

──────────────────────────────────────────────────────────────────────────────
17. FREEZE THE REPAIRED SOURCE
──────────────────────────────────────────────────────────────────────────────

Only after all prior gates pass, install the exact repaired bytes at:

provenance/parent-source.py

Use:

- exclusive creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/parent-source-freeze.json

containing:

- original source identity;
- repaired source identity;
- exact delta identity;
- compilation identity;
- seal-control-flow identity;
- checker A identity;
- checker B identity;
- mutation-matrix identity;
- structural-crosswalk identity;
- static-preflight identity;
- source frozen:
  true;
- later modification permitted:
  false;
- audit epoch begun:
  false;
- supplied package roots inspected:
  [].

──────────────────────────────────────────────────────────────────────────────
18. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against `provenance/parent-source.py`:

1. Reopen no-follow and verify identity.
2. Compile again.
3. Re-run checker A.
4. Re-run checker B.
5. Re-run the mutation matrix.
6. Re-run the 25-item crosswalk.
7. Re-run the static noninteractive gate.
8. Compare all results with the repaired-candidate results.

Require complete equality.

Retain:

validation/frozen-source-requalification.json

Any mismatch requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit the frozen source.

──────────────────────────────────────────────────────────────────────────────
19. NO AUDIT EPOCH AND NO PARENT EXECUTION
──────────────────────────────────────────────────────────────────────────────

Do not emit:

AUDIT_EPOCH_START

Do not execute the repaired or frozen parent source.

Do not import it as a module.
Do not invoke `main`.
Do not access supplied package roots.
Do not run package validators, materializations, handoffs, or substantive
audit causals.

This task ends after source freeze and exact-byte qualification.

──────────────────────────────────────────────────────────────────────────────
20. OPENING/CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for:

- source-preflight root;
- postseal-preflight root.

Require opening/closing equality.

Do not modify or clean either historical root.

──────────────────────────────────────────────────────────────────────────────
21. REPAIR-CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before terminal sealing:

- bootstrap start;
- historical-root opening identities;
- source selection;
- original source copy;
- repaired source;
- exact delta;
- seal-control-flow map;
- compilation;
- checker A;
- checker B;
- checker reconciliation;
- postseal mutation matrix;
- repaired structural crosswalk;
- static preflight;
- frozen source;
- freeze record;
- frozen-source requalification;
- historical-root closing equality;
- final report;
- temporal final inventory.

Then generate two independent terminal manifests.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- manifests byte-identical;
- no write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
22. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_READY

only when:

- both historical roots authenticate and close;
- exact source authority is established;
- repair delta is bounded to terminal-seal control flow;
- repaired source compiles;
- seal transition is unique and correctly placed;
- checker A passes;
- checker B passes;
- both independent checkers agree;
- mutation matrix passes;
- all 25 structural items pass;
- static noninteractive gate passes;
- exact repaired bytes are frozen;
- frozen requalification passes;
- historical-root closing equality passes;
- repair capsule closes;
- no supplied package root was inspected;
- audit epoch did not begin;
- parent source was not executed.

Return:

PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_BLOCKED

when:

- the defect cannot be repaired within terminal-seal control flow;
- another semantic source change is indispensable;
- any postseal filesystem-write path remains;
- the success region can return;
- the failure handler remains reachable after seal;
- the exact source cannot pass all static gates.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- historical-root mutation;
- source-authority mismatch;
- unauthorized source drift;
- frozen-source drift;
- requalification mismatch;
- capsule closure failure;
- any supplied package-root inspection.

──────────────────────────────────────────────────────────────────────────────
23. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-root identity
3. Source-preflight-root identity and closure
4. Postseal-preflight-root identity and closure
5. Original source identity
6. Exact repaired-source identity
7. Exact semantic delta
8. Seal-state field map
9. Manifest-finalization sequence
10. Exact authoritative terminal-seal point
11. Postseal allowed-operation set
12. Outer failure-handler guard
13. Repaired-source compilation
14. Independent checker A
15. Independent checker B
16. Checker reconciliation
17. Postseal mutation matrix
18. Complete 25-item structural crosswalk
19. Static noninteractive gate
20. Frozen parent-source identity
21. Freeze-record identity
22. Frozen-source requalification
23. Historical-root closing equality
24. Repair-capsule inventory and manifests
25. Confirmation audit epoch did not begin
26. Confirmation parent source was not executed
27. Remaining uncertainty and nonclaims
28. Explicit confirmations

Required confirmations:

SOURCE_PREFLIGHT_ROOT_MUTATION_NOT_PERFORMED
POSTSEAL_PREFLIGHT_ROOT_MUTATION_NOT_PERFORMED
EXACT_SOURCE_AUTHORITY_VERIFIED
ORIGINAL_SOURCE_BYTES_PRESERVED
REPAIR_BOUNDED_TO_TERMINAL_SEAL_CONTROL_FLOW
UNRELATED_AUDIT_SEMANTICS_UNCHANGED
REPAIRED_SOURCE_COMPILED_SUCCESSFULLY
TERMINAL_SEAL_STATE_UNIQUE
TERMINAL_SEAL_TRANSITION_AFTER_ALL_MANIFEST_VERIFICATION
POSTSEAL_MANIFEST_READS_ABSENT
POSTSEAL_FILESYSTEM_READS_ABSENT
POSTSEAL_FILESYSTEM_WRITES_ABSENT
POSTSEAL_STDOUT_WRITE_LOCALLY_GUARDED
POSTSEAL_STDERR_WRITE_LOCALLY_GUARDED_OR_ABSENT
POSTSEAL_SUCCESS_REGION_NONRETURNING
POSTSEAL_OS_EXIT_ZERO_DOMINATES
OUTER_FAILURE_HANDLER_GUARDED_BY_SEAL_STATE
OUTER_FAILURE_HANDLER_FILESYSTEM_WRITES_UNREACHABLE_AFTER_SEAL
INDEPENDENT_POSTSEAL_CHECK_A_PASSED
INDEPENDENT_POSTSEAL_CHECK_B_PASSED
INDEPENDENT_POSTSEAL_CHECKS_AGREE
POSTSEAL_MUTATION_MATRIX_PASSED
ALL_25_STRUCTURAL_ITEMS_PASSED
STATIC_NONINTERACTIVE_GATE_PASSED
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
ADMINISTRATIVE_CONTINUATION_ENTRY_ABSENT
CHILD_LAUNCHES_ROUTED_THROUGH_RECORDER
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_RECOMPILE_PASSED
FROZEN_SOURCE_REQUALIFICATION_PASSED
AUDIT_EPOCH_NOT_STARTED
FROZEN_PARENT_SOURCE_NOT_EXECUTED
NO_SUPPLIED_PACKAGE_ROOT_INSPECTED
NO_SUPPLIED_PACKAGE_ROOT_MUTATED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS_CREATED
```

After `PARENT_AUDIT_SOURCE_POSTSEAL_REPAIR_READY`, the next audit must execute
the exact frozen `provenance/parent-source.py` bytes from this repair capsule.
It must not regenerate, edit, or re-preflight the parent source.
```

**Source:** Codex’s latest `PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED` report.

**Confidence:** 0.999 that the reachable postseal failure-handler path is a real source defect; 0.99 that the repair is confined to terminal-seal control flow; 0.97 that the guarded nonreturning terminal region described above will permit exact-byte freeze without changing substantive audit semantics.
