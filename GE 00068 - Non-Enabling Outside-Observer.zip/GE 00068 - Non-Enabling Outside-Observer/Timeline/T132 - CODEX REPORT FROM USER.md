# Fourth independent audit — Evidence Verification v1

**Verdict: BLOCK**

The repaired 13-path patch has matching opening and closing provenance, and the previously reported EV and F mechanisms are causally closed on the inspected bytes. A new, repairable executable-source boundary defect remains: the verifier can report `pass` when its executable source is physically inside the target but invoked through a symlink in an external package directory. No repair was performed.

## Exact inputs and provenance

| Item | Exact value or result |
| --- | --- |
| Implementation root | `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1` (physical directory) |
| Branch / HEAD | `codex/evidence-verification-v1` / `567bceced5df95ecfe787cc66038d463a854e12c` |
| HEAD tree / sole parent | `b7cab23732572c2aaea9d5f2f1593338e2e75338` / `05dde14d185b6e022dcc169ef1a658a97961850f` |
| Upstream | absent |
| Patch scope | exactly 13 paths: four modified tracked and nine untracked; all regular, single-link 0644, logical 100644; zero staged, deleted, renamed, or unmerged |
| Recipe source | `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py` (5,143 bytes; SHA-256 `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`) |
| Retained canonical manifest | `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/manifest-run-1.json` (3,192 bytes; SHA-256 `5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57`) |
| Recipe ID | `execution-substrate.evidence-verification-v1.final-patch-provenance.v1` |
| Tracked binary-diff SHA-256 | `7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070` |
| Interpreter | `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`, version 3.13.4, 119,424 bytes, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` |

The recipe and retained manifest were opened with no-follow descriptors and stable before/read/after identity checks. The recipe source was inspected: it requires physical absolute root and continuation paths, confines output to `<continuation>/provenance/manifest-run-{1,2}.json`, creates output exclusively at 0600, writes identical canonical bytes to stdout, uses only `git -C <root>` with `cwd=<root>`, checks branch/HEAD/tree/absent upstream and exact tracked/untracked scope, sorts paths by UTF-8 bytes, runs the exact binary diff command, and emits compact sorted-key ASCII JSON plus one LF without machine-specific fields. The canonical manifest has the expected 13 path records and complete sizes and SHA-256 values.

The [opening gate](../opening/gate-result.json) passed after a disclosed audit-owned script parsing correction. The first gate attempt had stripped leading whitespace from Git porcelain status and stopped before correctness inspection; the corrected parser preserved raw status bytes. Every Git command in both attempts conformed to the required `git -C IMPL_R` root and environment, and every direct call is recorded in [git-argv.jsonl](../opening/git-argv.jsonl). This was an audit-script error, not a repository or Git process-boundary violation. The source-derived argv for the recipe's 24 internal Git calls across four recipe executions are recorded separately in [recipe-git-operations.json](recipe-git-operations.json); these internal calls were not individually intercepted.

Two opening recipe runs and two closing recipe runs exited 0 with empty stderr. Each output file and its separate stdout stream were byte-identical to the retained canonical manifest. Closing used the fresh, initially absent `closeout/provenance-replay-v1/provenance/` continuation, so no opening output was overwritten. [Opening](../opening/provenance-runs.json), [closing](provenance-runs.json), and [closing repository gate](repository-gate.json) records show the same canonical SHA-256, tracked-diff SHA-256, branch, HEAD, tree, parent, absent upstream, 13-path set, modes, and zero staged/deleted/renamed/unmerged paths. `git -C IMPL_R diff --check` passed with empty output. No Git operation marker or lock was present.

The final content and metadata snapshot equals the opening snapshot for the implementation worktree, implementation evidence root, independent audit v1/v2/v3 roots, original sealed A6D child, and sealed amendment: 478, 1,010, 131, 340, 14, 830, and 40 objects respectively. The implementation snapshot excludes its `.git` internals; the explicit Git gates checked repository identity, status, index staging, diff, and operation markers. These are the practical limits of the no-mutation evidence.

## Audit-v3 disposition and four perspectives

Audit v3's [report](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v3/closeout/report.md) states that its repository opening gate passed, correctness inspection never began, its supplied prompt lacked the exact recipe and retained-manifest paths, and it made an initial unrooted Git call in the forbidden primary checkout without bracketing possible primary Git metadata effects. V3 is permanently nonqualifying, was not resumed, and supplied no correctness conclusion here.

| Perspective | Completion | Assessment |
| --- | --- | --- |
| [Contract and authority](../perspectives/01-contract-authority.md) | complete | No authority blocker; one low test-portability observation. |
| [Verifier correctness and parser/resource](../perspectives/02-verifier-correctness.md) | complete | F-01 through F-04 mechanisms closed; minority view treats symlinked-source launch as externally contained for this exact source path. |
| [Test and validation](../perspectives/03-test-validation.md) | complete | 59-test suite and retained repair evidence adequate for prior mechanisms; three low test-oracle/injection observations. |
| [Security, filesystem, capability, artifact](../perspectives/04-security-artifact.md) | complete | Reproduced SEC-01; recommends BLOCK. No other security or artifact blocker. |

All four perspectives received the same reproduced manifest, exact verifier/registry/layout identities, prior EV and F ledgers, repair-v2 report, architecture target/non-goals, and v3 nonqualification. No perspective ran Git or created a nested subagent. I preserve the parser perspective's minority containment argument below.

## Authority and whole-patch adjudication

`PLANS.md:2970-3012` and `.docs/system_overview/evidence_verification.md:3-31` classify this ES-owned external verifier as a **Bounded slice rule**. The tranche exercises no **Reopened redesign seam**. T1 is a **Current invariant**. Historical target-specific A6D verifiers remain **Temporary compatibility edges** and inert `.py.txt` fixtures. All 13 patch paths are documentation, the verifier, registry, three layouts, tests, or historical fixtures; there is no product API, schema, route, module, service, runtime-contract, admission, orchestration, durable-state, or execution change. The tool emits structural evidence/projection only; closeout and later independent audit retain readiness adjudication. Registry/layout records declare structure, not product result predicates. The CLI admits no runtime caller-supplied layout. No evidence-child-local verifier authority, self-certification, verifier-amendment chain, or broader framework appears in the patch. Repair-v2 changed only verifier and test bytes; registry and all layouts retained their pre-repair hashes. SEC-01 does not require changing the architecture or ownership split.

## Verifier correctness and prior-finding closure

| Finding | Fourth-audit disposition |
| --- | --- |
| EV-01 | Package/target/candidate descriptor ancestry, case aliases, symlink/hardlink candidate, and opening/closing identity mechanisms are repaired and exercised. SEC-01 is a distinct remaining executable-source indirection case that limits the categorical source-external claim. |
| EV-02 | Closed: literal-LF grammar rejects VT, FF, NEL, CRLF, missing final LF, extra blank line, and Unicode line/paragraph separators, with canonical `MANIFEST_CANONICAL` output. |
| EV-03 | Closed: 1 MiB package JSON source cap, nonrecursive lexical depth 64, string/escape handling, duplicate-key/float/invalid UTF-8 rejection, and canonical no-traceback failure. |
| EV-04 | Previous broad scan/resource defect repaired. F-01 and F-02 are separately closed below. |
| EV-05 | Closed: behavioral descriptor capability preflight and canonical `IO_OR_RACE`/7 uncertainty; an independent post-preflight injected `NotImplementedError` also returned canonical exit 7. |
| EV-06 | Closed on this host: four fresh 59/59 runs, twice under each umask, no skip or repository artifact. |
| EV-07 | Closed: isolated missing-root and expected symlink/FIFO causals produce the intended rejection classes using self-consistent manifests. |
| EV-08 | Closed: complete lexical decimal consumption precedes overflow classification; F-03 independently closed below. |
| EV-09 | Audit-process issue, not a patch change. Every v4 Git call was parent-only and explicitly rooted; v3 remains nonqualifying. |
| F-01 | Closed: manifest pre-stat rejects above the derived 12,017,724-byte cap before body read; 4,096-byte incremental literal-LF reader checks header/count before row allocation, 1,467-byte row and 1,366-byte encoded-path ceilings before decode, decoded path/segment ceilings before storage, immediate order/duplicate rejection, first excess row, missing row, and trailing data. No whole-input split/read on this path. |
| F-02 | Closed: candidate stat and byte cap precede read; root manifest and exact 65-byte sidecar are pre-statted; both seals and payloads enter each structural scan's 4 GiB budget, with overflow rejected before read. Exact 68/67-byte and candidate 73/72-byte causals passed. |
| F-03 | Closed: `8193x` and `268435457x` map to `MANIFEST_CANONICAL`/5, while canonical count and size overflow map to `LAYOUT`/4 and `SIZE_HASH`/6. Signs, whitespace, underscores, decimal/exponent, NUL/control, non-ASCII digits, leading zeros, lexical overlength, exact maximum, and maximum-plus-one are exercised. |
| F-04 | Closed: roots, directories, required files/modes, and optional subtree paths are prevalidated as ASCII safe paths before target open. The parent ran a 49-case cross-field invalid-spec matrix: every case returned canonical `SPEC_SCHEMA`/3 with zero target-open calls. |

The [independent parser probe](../perspectives/02-fixtures/result.json), [spec matrix](../validation/spec-matrix-result.json), and [post-preflight capability injection](../validation/post-preflight-capability.json) support these mechanism conclusions. This does not waive SEC-01. The verifier's ordinary output is one compact sorted-key JSON line with empty stderr, no traceback, no absolute target path or payload content, and no readiness value. Source inspection found no write, child process, network call, target-code import, permissive pathname fallback, OS-label branch, or runtime layout injection. Directory descriptors are closed on success/failure paths; ancestry traversal has a 512-step cap; file reads and both scans are bounded. The same-child metadata posture does not prove privileged timestamp custody or an atomic filesystem snapshot.

## Fresh tests, compatibility, and repair evidence

The exact interpreter above ran with `-I -B`, `PYTHONDONTWRITEBYTECODE=1`, `LC_ALL=C`, `LANG=C`, and an audit-owned private `TMPDIR`. AST parsing passed for both current Python files and both historical `.py.txt` sources without executing the historical files. Independent strict JSON parsing confirmed canonical registry and three layout bytes, no duplicate keys or floats, and exact registry-to-layout hashes. The complete suite discovered the same 59 identities in each run:

| Umask | Run 1 | Run 2 | Failure / error / skip |
| --- | --- | --- | --- |
| 077 | 59 passed | 59 passed | 0 / 0 / 0 |
| 022 | 59 passed | 59 passed | 0 / 0 / 0 |

Fresh [suite records](../validation/basic-result.json) and raw stdout/stderr are retained. The test source's fixture builder uses separate `stat`/SHA-256/base64 logic, and the tests causally cover early manifest-size rejection, count-before-allocation, line/path/decode ordering, seal/sidecar budget, aggregate exact boundary and overflow, decimal lexical/resource separation, spec rejection before target access, all EV-01 through EV-08 regressions, umask independence, and isolated missing-root/symlink/FIFO mechanisms. Tests 53–55 share verifier-derived numeric threshold functions, so they alone are not an independent numeric-limit oracle; the parent checked the fixed contract constants and formula. Test 59 is representative rather than a full invalid-spec cross-product; the parent ran the separate 49-case matrix. Test 51 omits a committed post-preflight fault injection; the parent ran it separately.

Two fresh sealed A6D runs and two sealed amendment runs exited 0 with canonical, byte-identical outputs and empty stderr. Their stdout SHA-256 values are `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606` and `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`, matching retained repair-v2 output hashes. Both real children remain below admitted structural limits (producer-recorded sizes 72,956,812 and 105,053 bytes; source gates and successful fresh scans independently admit them). An audit-owned A6 pre-seal fixture passed twice, was sealed only within the audit-owned temporary root, then passed sealed verification twice. Each pair's canonical output was byte-identical. Before/after target and verifier-package snapshots matched for every real and synthetic invocation; the private temporary root was removed. [Compatibility records](../validation/compat-result.json) retain argv, stdout digests, and snapshots.

The repair-v2 report and retained causals attribute F-01 to a bounded streaming reader, F-02 to pre-read seal/candidate and structural budgets, F-03 to complete lexical decimal validation, and F-04 to spec-path validation before target opening. Producer predecessor/repaired causal records, seven final single-test runs, four final 59-test runs, complete test identities, real/synthetic checks, no-write snapshots, failed/superseded attempt index, cleanup, final provenance, and implementation reports were inspected. Earlier failed or inconclusive attempts are indexed and not used as final qualification. The producer report does not claim v1/v2 audits qualify changed repair-v2 bytes. A direct [v1-final versus v2-current manifest comparison](../validation/repair-scope-comparison.json) shows exactly verifier and test changed and the other eleven paths byte-identical; the four registry/layout hashes match both the report and live bytes. No authority or filesystem permission widening was found.

## Severity-ranked residual finding

### AUDIT FINDING — SEC-01

- **ID:** SEC-01
- **Type:** executable-source physical-boundary bypass
- **Severity:** high
- **Classification:** newly identified repairable patch defect
- **Current contract or strategic target:** Source-external verifier with no self-verification; its executable source cannot reside under the target (`.docs/system_overview/artifact_hygiene.md:185-188`; `.docs/system_overview/evidence_verification.md:20-31,49-56`).
- **Path and line:** `tools/evidence_verify/verify_v1.py:761` (package path derivation), `:766-774` (package/target opening), `:321-330` (directory-only boundary); test gap at `tools/evidence_verify/test_verify_v1.py:282-289`.
- **Evidence:** [Security perspective fixture](../perspectives/04-fixtures/symlink-source-result.json) and [independent parent reproduction](../validation/source-symlink-repro.json). In two audit-owned layouts, an external `package/verify_v1.py` symlink pointed to exact verifier source bytes physically under `target/tool/verify_v1.py`; the source was a manifest-bound payload, candidate external, registry and selected layout exact. Both invocations exited 0 with canonical `outcome: pass` and empty stderr. The source SHA-256 was `60cdcab597cfc233d9406794886df02b54296cd392d7af4d082c75e87a5bc21e`.
- **Reachable mechanism:** `Path(__file__).absolute().parent` retains the symlink's lexical external parent. Python executes the source inside the target, while `target_boundary` sees only the external package directory and passes. No executable-source object stat, no-follow open, or ancestry comparison occurs.
- **Impact:** A target-contained verifier source can certify closure of that target, contradicting the categorical source-external boundary and weakening the independently audited bootstrap when the launch path is not separately constrained.
- **Required correction:** Physically bind the actual executable source object to the package/target boundary and reject symlink or equivalent indirection into the target; add a causal regression; align the authoritative docs and validation with the chosen enforcement point.
- **Containment/nonclaim:** The canonical repository source used in this audit is regular and externally pinned. This fixture does not show that the real A6D/amendment invocations or their bytes were unsafe. Correction fits the current 13-path verifier/test/docs tranche; no architecture redesign, product change, runtime authority, or new amendment is needed.
- **Uncertainty:** Pre-seal was dynamically exercised; the same source-path derivation is stage independent, but sealed symlink launch was not separately run. Privileged metadata forgery and adversarial concurrent renames were not exercised.
- **Patch defect, pre-existing issue, or audit-process issue:** patch defect.
- **Blocking:** yes.

The parser/resource perspective's minority view is that `PLANS.md:2994-2999` and `.docs/system_overview/evidence_verification.md:49-56` assign executable-source provenance to the external launcher, and this audit's exact regular source path is outside the target. I agree that those facts contain SEC-01 for the specific fresh compatibility invocations. They do not establish a universal launcher gate for the documented verifier contract, while `.docs/system_overview/artifact_hygiene.md:185-188` categorically says source cannot reside under the target. Source checks only the package directory and can emit a pass in the reproduced case. That reachable source-boundary contradiction is repairable, so the audit verdict is BLOCK rather than REJECT or ACCEPT. Low minority observations on fixed host-local historical test inputs, shared numeric test oracles, representative spec mutations, and post-preflight test injection are recorded in [findings ledger](../findings/ledger.json); the parent probes narrowed the latter three.

## Limits, audit-created paths, and prohibited actions

No maximum-size 4 GiB target-pressure test, privileged timestamp-forgery test, or adversarial concurrent-rename test was run. Product runtime, Go/product A/B, live services, network, Linux binary execution, A6 restart, and deployment were outside the authorized audit. The small causal fixtures and source inspection establish ordering and declared bounds, while the real children establish admitted operation below limits. The first audit's terse EV disposition lacks a full narrative ledger; v2's detailed reconciliation and repair causals supplied mechanism history. V3 supplied no correctness result.

The only created objects are beneath `/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4`, with the six required top-level directories. Scripts, logs, captured stdout/stderr, perspective reports, fixture-result JSON, snapshots, and this report remain there; the complete [audit-created path inventory](audit-created-paths.json) lists them. The audit-owned private TMPDIR and temporary fixture roots were removed; [cleanup record](cleanup.json) lists the removed entries. No repository or supplied-evidence object was removed, chmodded, normalized, rewritten, or restored.

No repository mutation, formatting, cleanup, staging, commit, push, PR, merge, installation, deployment, A6 restart, product execution, live-service invocation, network contact, or Linux binary execution was performed. Every Git call was parent-only, explicitly `git -C IMPL_R ...`, with `GIT_OPTIONAL_LOCKS=0` and `GIT_CONFIG_NOSYSTEM=1`; the direct call log and source-derived recipe call list are linked above. No Git call entered the forbidden primary checkout or any evidence/audit/candidate root. No nested subagent was created.
