## Assessment

This is a **clean implementation handoff to independent audit**. Codex repaired the exact acceptance-bearing defect without modifying the repository patch, verifier, layouts, launch protocol, or record schema.

The strongest parts of the result are:

- The old caller defect was demonstrated causally: metadata came from one inode and bytes from another, while the old snapshot still looked stable.
- The replacement snapshot is descriptor-relative, no-follow, bounded, deterministic, and shared across all four watched roots.
- Snapshot equality remains acceptance-bearing; the repair did not weaken the assurance by relabeling it “corroborative.”
- The caller’s launch protocol v2 and record schema v3 were preserved.
- A6D, the amendment, synthetic A6, SEC-02, and nine caller-negative cases passed.
- The repository remained on canonical manifest `4a3a4244…18537` and the exact restored 477-object baseline.
- Existing evidence and the vulnerable caller were preserved rather than amended in place.

No further implementation turn is justified before audit.

The earlier audit-process failure—32 retained audit files with incorrect modes—remains historical and nonqualifying; it was not a repository or implementation defect.  The repository was separately restored to the exact 477-object baseline with the canonical patch bytes unchanged.  The repository repair itself still consists of the one-file alternate-authority test change, with the other twelve patch paths unchanged. 

### Audit issues that must be decided, not silently accepted

The fresh audit should focus on four points:

1. **Descriptor-snapshot correctness.** Independently verify ordering, identity checks, relisting, root rebinding, error propagation, resource limits, and absence of any pathname payload-read fallback.

2. **Test-hook containment.** Prove the internal deterministic race hook has no CLI, environment, target, verifier-input, or normal-execution route, and that `main()` fails closed if it is unexpectedly non-null.

3. **Scope preservation.** Confirm the old-to-new caller diff changes only the record destination, snapshot implementation, and normal-main hook guard. The record-destination change must not alter schema, protocol, caller acceptance semantics, or future usability.

4. **Repair provenance.** Runs 3 and 4 deliberately exclude themselves from their 83 SHA-bearing rows. That can be valid, but the auditor must independently prove:
   - the two manifests are byte-identical and have SHA-256 `dfee2430…b36d`;
   - those two files are the only exclusions;
   - every other retained file is covered exactly once;
   - the actual root contains exactly 85 regular files and 10 directories at the reported modes;
   - no unexplained post-manifest mutation exists.

The absence of a named producer manifest recipe is not automatically fatal if the fresh auditor independently inventories the entire repair root and binds the exact caller and test bytes. It must be disclosed rather than treated as producer self-proof.

## Codex prompt — fresh independent caller-repair audit

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Embed the complete audit report inline in Markdown.

Do not return only a verdict, summary, local-file link, or attachment
reference. Supplemental evidence links may follow the complete inline report.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH-CONVERSATION REQUIREMENT

This must be a completely fresh, read-only Codex conversation.

Do not resume:

- the caller-snapshot implementation conversation;
- the audit that found CALLER-SNAPSHOT-01;
- any prior Evidence Verification audit;
- the alternate-authority repository implementation conversation;
- the artifact-restoration conversation.

Objective

Independently audit the exact source-external Evidence Verification v1 caller
snapshot repair.

The Evidence Verification repository patch is frozen and unchanged. This is a
bounded audit of:

1. the new source-external caller;
2. its descriptor-bound snapshot semantics;
3. its retained repair evidence and provenance;
4. its compatibility with the exact frozen repository verifier and layouts.

Do not repair or modify anything.

No repository or supplied-evidence mutation.
No formatting.
No cleanup of supplied roots.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, live-service invocation, network contact, or Linux binary
execution.

No nested subagents.

## 1. Exact inputs

Frozen repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected repository manifest:

REPO_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f/provenance/manifest-run-1.json

Expected repository-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Expected restored repository inventory:

RESTORED_INVENTORY=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632/restoration/full-object-after.json

Expected governed repository objects:

477

Exact unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Vulnerable source-external caller, immutable historical input:

OLD_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected old-caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Caller-repair evidence root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-repair-4a3a42441632-v1

Repaired caller:

NEW_CALLER=$REPAIR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Expected repaired-caller identity:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

Exact retained old-caller copy:

OLD_CALLER_COPY=$REPAIR_ROOT/source/old_caller_exact.py

Expected old-caller-copy SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Final snapshot test source:

SNAPSHOT_TEST=$REPAIR_ROOT/tests/test_descriptor_snapshot_v5.py

Expected snapshot-test identity:

- size: 11930
- SHA-256:
  6a2acc60ddaac42f9f3782202b9dd797abdb510bad0568bfa9ed22917c42ff58

Producer repair manifests:

REPAIR_MANIFEST_1=$REPAIR_ROOT/provenance/repair-manifest-run-3.json
REPAIR_MANIFEST_2=$REPAIR_ROOT/provenance/repair-manifest-run-4.json

Expected identity of each:

dfee24304dfe57c9e45c1df997bc78ca1a3c61c4f878d3b928e094e199ebb36d

Expected repair-root closure:

- 85 retained regular files;
- 10 directories including the root;
- every regular file mode 0600 and single-link;
- every directory mode 0700;
- private tmp directory empty;
- the two repair manifests byte-identical;
- 83 SHA-bearing rows covering every retained regular file except the two
  self-excluded manifests;
- exactly those two manifest paths listed as self-exclusions.

Old-defect causal:

OLD_CAUSAL=$REPAIR_ROOT/causals/old-defect-v2.json

Producer repaired matrix:

REPAIRED_MATRIX=$REPAIR_ROOT/causals/repaired-matrix-v2.json

Producer implementation report:

PRODUCER_REPORT=$REPAIR_ROOT/closeout/implementation-report.md

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular, single-link;
- size 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-independent-audit-dfee24304dfe-v1

## 2. Authority and scope

Current contract:

- The verifier is an ES-owned Bounded slice rule.
- Verifier output has structural-evidence authority only.
- The source-external caller and caller records are validation/provenance
  evidence only.
- Neither caller nor verifier has product, runtime, admission, orchestration,
  readiness, commit, publication, or durable-state authority.
- Supported-local trusted-host assumptions remain in force.
- Atomic loaded-interpreter custody is not claimed.

Repair classification:

- source-external validation-evidence repair;
- no repository patch change;
- no verifier change;
- no registry/layout change;
- no launch-protocol change;
- no caller-record-schema change;
- no product/public/runtime contract change;
- no authority widening;
- no reopened architectural seam.

MK-01 and the repository authority-family repair are frozen and out of scope
except for exact repository-provenance verification. Do not reopen or re-audit
that design.

## 3. Audit-evidence posture

Before any substantive inspection:

1. Require AUDIT_ROOT absent.
2. Set umask 077.
3. Create all audit-owned directories at 0700.
4. Create all retained audit files exclusively at 0600.
5. Never reuse, truncate, replace, or rewrite a retained record.
6. Store subagent reports through the parent-controlled writer.
7. Keep audit TMPDIR private and empty at closeout.

On a retained evidence-mode or record-custody failure:

PROCESS_BOUNDARY_BLOCK

Do not repair that audit attempt in place.

## 4. Repository and repair-root provenance

At opening and closing:

### Repository

Require:

- exact branch, HEAD, tree, parent, and absent upstream;
- exact canonical repository manifest;
- exact tracked diff;
- exact 477-object restored inventory;
- no repository cache, bytecode, test cache, generated artifact, or new ignored
  path;
- zero staged, deleted, renamed, or unmerged paths.

The repository is read-only context. Do not run its complete 89-test suite;
those bytes did not change.

### Repair root

Independently inventory REPAIR_ROOT by relative-path key.

Require:

- exactly 85 regular files and 10 directories;
- modes and link counts as reported;
- no symlink or special file;
- empty tmp directory;
- exact NEW_CALLER, OLD_CALLER_COPY, SNAPSHOT_TEST, OLD_CAUSAL, and producer
  report identities;
- REPAIR_MANIFEST_1 and REPAIR_MANIFEST_2 byte-identical with the expected
  SHA-256;
- their row format canonical and deterministic;
- exactly 83 SHA-bearing rows;
- every other retained regular file covered exactly once;
- exactly the two manifest paths self-excluded;
- no missing, duplicate, or extra row;
- no unexplained post-manifest mutation.

The producer manifests are evidence, not self-authority.

Independently create and retain an audit-owned complete inventory of all 85
files. If the producer manifest format or its self-exclusion semantics cannot
be independently validated, return BLOCK or AUDIT_PROVENANCE_MISMATCH as
appropriate. Do not silently assume correctness.

## 5. Four distinct audit perspectives

After provenance matches, start three distinct read-only auditors concurrently:

1. Contract, scope, schema, and protocol preservation.
2. Descriptor-snapshot filesystem correctness.
3. Tests, causals, resource bounds, and provenance adequacy.

After one completes and closes, start a fourth distinct auditor:

4. Security, race resistance, record redaction, compatibility, and artifacts.

Retry a failed start once.

If a required distinct auditor cannot start:

SUBAGENT_UNAVAILABLE

No nested delegation.
No auditor Git.
No auditor writes to supplied roots.
No auditor repository-module import.
No network.

Each auditor must receive the exact caller and repair-manifest identities and
must report exact operands inspected, uninspected scope, disagreements, and
whether mutation occurred.

## 6. Exact old-to-new source adjudication

Independently compare OLD_CALLER and NEW_CALLER.

Require the semantic delta to be limited to:

1. the new source-external record destination required by this repair root;
2. the shared descriptor-bound snapshot implementation;
3. the internal deterministic-test-hook support and the normal-main guard.

Confirm all of the following remain unchanged:

- launch protocol:
  `execution-substrate.evidence-closure-launch/v2`;
- caller record schema:
  `execution-substrate.evidence-closure-launch-record.v3`;
- all 25 record field names and meanings;
- CLI argument names, ordering, and defaults, except an evidence destination
  that does not alter target semantics;
- source-by-value verifier launch;
- pinned-interpreter posture;
- verifier-source authentication;
- registry/layout authentication;
- returned verifier-result validation;
- mandatory trusted-host nonclaims;
- all non-snapshot acceptance and error semantics;
- no pathname payload-read fallback;
- no new product, runtime, readiness, or publication claim.

Adjudicate the record-destination change explicitly. If it hardcodes this
repair root in a way that makes the caller unusable for later A6 evidence, or
changes a caller-record field meaning, return BLOCK.

## 7. Descriptor-snapshot source review

Verify that the final implementation:

- accepts only absolute physical roots;
- traverses every root component no-follow;
- opens and retains the root directory descriptor;
- enumerates entries descriptor-relatively;
- sorts names deterministically by encoded bytes;
- observes entries with `dir_fd` and `follow_symlinks=False`;
- opens directories and files with the reported no-follow flags;
- hashes file bytes only from held descriptors;
- binds pre-open observation, descriptor identity, post-read descriptor
  identity, and post-read pathname reobservation;
- verifies the actual byte count;
- rechecks entries after traversal;
- relists and rechecks every directory;
- reopens and rebinds the root at close;
- rejects symlink, special-file, hardlink, replacement, disappearance,
  metadata change, and unsupported-capability states;
- has no pathname-based file-content fallback;
- performs zero writes to watched roots;
- retains no file payload in records;
- emits no sensitive watched-root absolute path in shared output.

Verify the exact reported limits:

- files: 12000;
- directories including root: 2048;
- depth: 12;
- encoded relative-path bytes: 1024;
- absolute-root bytes: 4096;
- per-file bytes: 268435456;
- aggregate bytes: 4294967296.

Check that each limit is enforced before unbounded allocation or read work.

## 8. Internal test-hook adjudication

The deterministic test hook is security-sensitive.

Prove:

- default value is null;
- normal `main()` rejects a non-null hook;
- there is no CLI argument, environment variable, package input, target file,
  verifier result, registry/layout value, or caller-record field that can set
  it;
- the hook is unavailable in normal source-by-value execution;
- no exception path leaves it enabled;
- the production caller cannot be induced to skip or reorder identity checks;
- test-only imports operate solely on audit-owned exact source copies.

If the hook is reachable through normal caller execution, return BLOCK.

## 9. Independent causals

Do not rely solely on producer tests.

### Vulnerable predecessor

Independently reproduce the old caller’s metadata/bytes object split using
audit-owned fixtures and exact OLD_CALLER bytes.

Require:

- two distinct inodes;
- deterministic synchronization after lstat and before pathname read;
- equal mode/size/content where needed;
- old snapshot returns apparently stable output;
- exact nonclaim that this proves the snapshot defect, not a full caller
  acceptance bypass.

### Repaired snapshot

Independently run at least:

1. stable tree twice;
2. byte-identical canonical repeat;
3. empty directory;
4. nested files;
5. final root symlink;
6. symlinked ancestor;
7. internal symlink;
8. special file;
9. regular hardlink;
10. replacement before open;
11. replacement after open;
12. in-place mutation during read;
13. directory replacement;
14. root replacement;
15. disappearance;
16. type change;
17. mode change;
18. link-count change;
19. per-file limit;
20. aggregate limit;
21. file-count limit;
22. directory-count limit;
23. depth limit;
24. path-byte limit;
25. unsupported dir-fd capability;
26. unsupported no-follow capability;
27. unsupported descriptor listing;
28. runtime descriptor-listing failure;
29. normal-main hook guard;
30. no watched-root write.

Use deterministic coordination, not probabilistic timing.

Require specific failure classification and no traceback for caller-level
negative cases. A snapshot-level exception must become a nonaccepting caller
record rather than escaping.

## 10. Record schema and disclosure

Inspect all final producer records and create audit-owned records.

Require:

- exact v3 schema;
- same 25 fields and meanings;
- no watched-root absolute paths;
- no file payload;
- no source text;
- no credentials or private endpoint;
- no readiness, product, or runtime-authority claim;
- mandatory trusted-host nonclaims preserved;
- snapshot errors cannot be erased by later verifier success;
- `outcome="accepted"` requires all snapshot and non-snapshot gates.

## 11. Fresh compatibility

Use an audit-owned reconstruction or exact audited caller source.

### A6D

Run sealed twice.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical verifier stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- deterministic record semantics;
- descriptor-bound target/package/TMPDIR/caller-evidence snapshots equal;
- A6D manifest unchanged;
- mandatory nonclaims present.

### Amendment

Run sealed twice.

Require canonical verifier stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same caller, snapshot, manifest, and nonclaim conditions.

### Synthetic A6

Create only an audit-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require deterministic outputs per stage, empty verifier stderr, accepted
caller results, and only the expected writer-owned seal transition.

### SEC-02

Run an audit-owned target-marker causal.

Require source-by-value execution never loads the target script and the marker
remains absent. Direct-script predecessor shape remains nonqualifying.

Do not claim atomic interpreter custody.

### Caller negatives

Freshly exercise:

- wrong interpreter hash;
- wrong interpreter size;
- source mismatch;
- registry-result mismatch;
- layout-result mismatch;
- package/target containment;
- snapshot uncertainty;
- snapshot replacement;
- unsupported snapshot capability.

Require the exact reported error classes or a stricter compatible failure.

## 12. Closing provenance and artifacts

Remove only audit-owned temporary fixtures.

At closeout require:

- repository still matches manifest `4a3a4244…18537`;
- tracked diff still `b2487310…7aceb`;
- exact restored 477-object repository inventory;
- supplied REPAIR_ROOT unchanged;
- exact 85-file/10-directory repair-root inventory;
- both producer manifests unchanged;
- no process or descriptor survivor;
- audit tmp directory empty;
- every retained audit file regular, single-link 0600;
- every retained audit directory 0700.

## 13. Verdict rules

### ACCEPT

Only if:

- repository and repair-root provenance match;
- old-to-new scope is bounded as reported;
- descriptor-snapshot algorithm is correct and fail-closed;
- test hook is unreachable in normal execution;
- producer manifest self-exclusions and full evidence closure are independently
  validated;
- independent causals pass;
- compatibility and caller negatives pass;
- schema/protocol/authority remain unchanged;
- no process, evidence, or artifact blocker remains.

### BLOCK

Use for a repairable caller, test, evidence, provenance-format, validation,
redaction, or assurance defect.

### REJECT

Use only for a fundamental architecture or authority defect.

### AUDIT_PROVENANCE_MISMATCH

Use for any source, repository, repair-root, manifest, inventory, or closing
identity mismatch.

### PROCESS_BOUNDARY_BLOCK

Use for an audit-process violation, supplied-root mutation, repository import,
missing audit record, or retained audit-file posture failure.

### SUBAGENT_UNAVAILABLE

Use when a required distinct auditor cannot start after one retry.

## 14. Required inline report

Include:

1. Verdict.
2. Exact repository and repair-root identities.
3. Audit-evidence posture.
4. Repository and repair-root provenance.
5. Producer-manifest self-exclusion adjudication.
6. Four auditor identities, roles, scheduling, operands, and status.
7. Exact old-to-new source delta.
8. Record-destination adjudication.
9. Descriptor-snapshot algorithm review.
10. Resource-limit review.
11. Test-hook reachability adjudication.
12. Vulnerable predecessor causal.
13. Independent repaired causal matrix.
14. Record-schema and disclosure review.
15. A6D results.
16. Amendment results.
17. Synthetic A6 results.
18. SEC-02 result.
19. Caller-negative results.
20. No-write and deterministic-output evidence.
21. Authority, protocol, and security adjudication.
22. Severity-ranked residual findings.
23. Minority findings and parent resolution.
24. Remaining uncertainty and nonclaims.
25. Audit-created paths and cleanup.
26. Explicit confirmations:
    - repository mutation not performed;
    - supplied repair-evidence mutation not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not stage, commit, push, or restart A6.
```

## After `ACCEPT`

Proceed to the exact-byte commit gate for the unchanged repository manifest `4a3a4244…18537`, while retaining the independently accepted caller source SHA-256 `c030f2ba…38c1` as the source-external validation input for the later fresh A6 restart. Do not introduce another implementation or producer-validation tranche.

The governing workflow requires a fresh, read-only audit after repair, with provenance reproduced before correctness review; the auditor must not repair the target.  Provenance binds implementation and audit to the same bytes but remains evidence rather than correctness or authority. 

### Sources

- The earlier mode-failed audit is permanently nonqualifying because its own retained files violated the required evidence boundary, even though its direct Git records were intact. 
- The repository was restored to an exact 477-object baseline with canonical manifest `4a3a4244…18537` and no cache or bytecode. 
- The repository implementation itself changes only `test_verify_v1.py`; the remaining twelve paths are byte-identical and the changed bytes require a fresh audit. 
- Repair and re-audit are separate engagements; changed bytes invalidate prior audit acceptance. 
- Independent audit must reproduce exact provenance at opening, inspect relevant source/evidence, and rerun it at closeout. 

**Confidence**

- The caller repair directly addresses CALLER-SNAPSHOT-01: **0.98**
- Repository repair remains unchanged and needs no further implementation: **0.995**
- Fresh audit is now the correct next step: **0.999**
- Producer repair provenance needs explicit independent scrutiny because of self-excluded manifests: **0.90**
- No further implementation should occur before audit: **0.99**
