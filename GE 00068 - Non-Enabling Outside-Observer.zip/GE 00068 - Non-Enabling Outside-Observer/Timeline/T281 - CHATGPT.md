## Assessment

The audit stopped correctly on `AUDIT_PROVENANCE_MISMATCH`: the retained carrier index did not fully correspond to every visible top-level carrier command and result. The target was not qualified.

That process failure is no longer the main issue, however. The audit identified two independently blocking **V3 target defects**:

1. **Competing normative authority.**  
   The failed-attempt subtree contains a byte-identical contract that repeats the current contract ID, pending-effective status, and `sole_normative_writer_for_validation_custody:true`. Directory placement and a superseded-attempt index do not neutralize those self-claims.

2. **Incomplete V2 adoption lineage.**  
   Two adoption rows claim successful eight-command validation and cleanup while citing raw records with `pass:false`. A separate correction record apparently supports the corrected facts, but the V3 adoption rows do not bind it.

The audit also found evidence-quality defects worth repairing in the same bounded pass:

- the V3 inventory implementation can omit directory symlinks;
- two directory link counts in the final inventory reflect a pre-finalization state;
- a retained sensitive-material scan omitted a later final-status record;
- the independent producer validator does not separately pin its mutation intent.

The substantive V3 design did well:

- the primary V3 field map passed;
- Plan V3→V4 semantic equivalence passed;
- the five-source chain and 86-byte derivation passed;
- explicit supported-local nonauthority passed;
- the independent 53-case matrix passed;
- capsule membership and physical closure passed;
- the accepted Strategic B gate passed;
- runtime validation was not replayed.

So this should be a **source-external V3 evidence and authority repair**, not a V4 semantic redesign, repository change, or runtime rerun.

The carrier-index failure must be corrected in the *next independent audit prompt*, not in this implementation tranche. The future carrier index should bind only facts available from the phase wrapper and visible transcript—ordinal, phase, wrapper/payload identity, cwd, environment identity, platform outcome class, and start/outcome records—not demand an unavailable verbatim reconstruction of every tool-internal command representation.

## Codex prompt

```text
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 —
AUDIT FINDING REPAIR AND RECORD-COMPLETION SUCCESSOR

Implement a bounded source-external evidence and authority repair for the exact
Validation-Custody V3 target.

Do not modify the candidate repository.
Do not modify Strategic B.
Do not modify the blocked V1 capsule.
Do not modify the V2 capsule.
Do not modify the V2 independent-audit root.
Do not modify the existing V3 capsule.
Do not modify any prior audit root.
Do not rerun runtime validation, repository tests, product code, or Plan V3/V4.
Do not use the network.
Do not stage or commit.
Do not start A6.
Do not create subagents.

Return exactly one primary verdict:

REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_AUDIT_REPAIR_BLOCKED
AUDIT_REPAIR_PROVENANCE_MISMATCH

OBJECTIVE

Create a new immutable source-external V3 audit-repair capsule that:

1. preserves the exact accepted Validation-Custody V3 contract and Plan V4
   semantics;
2. restores exactly one current normative validation-custody writer;
3. replaces copied failed-attempt normative bytes with bounded external
   historical references;
4. repairs the two incomplete V2 technical-evidence adoption lineages;
5. preserves the V2 audit verdict as BLOCK;
6. closes directory-symlink and complete-membership provenance gaps;
7. removes temporally unstable directory metadata from final inventory
   authority;
8. provides a final sensitive-material scan whose exact exclusions are
   explicit and bounded;
9. strengthens mutation-intent independence;
10. produces a complete immutable capsule ready for a fresh independent audit.

This is not a new contract version. Do not redefine V3 or Plan V4. If an exact
repair requires changing an executable or acceptance-bearing V3 semantic,
stop with the blocked verdict.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed/tracked/untracked:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- F inventory:
  54314 bytes
  SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_GATE_ROOT:

/Users/ds/Downloads/ES-strategic-b-gate-requalification-uTwKU7hS

Accepted gate record:

closeout/accepted-strategic-b-opening-gate-v1.json

- 4173 bytes
- SHA-256:
  555041298ee49db603a7c3ff64e022cdf8bf79cd7d7edc6007dcd32e35998212

Gate manifest pair:

- 10066 bytes each
- SHA-256:
  d58de35fdf630829b1fb7efe80a04f0616a66c98039fdf27a2b49a622c49bd05
- required byte-identical

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Accepted stable identities:

- canonical whole-root projection:
  96657 bytes
  SHA-256:
  4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360

- B source inventory:
  54314 bytes
  SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

- B source T / tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected V2 audit verdict:

BLOCK

Expected V2 audit report:

- 92491 bytes
- SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05

Expected V2 audit inventory:

- 69706 bytes
- SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

VALIDATION_CUSTODY_V3_PREDECESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

Expected fixed V3 identities:

- contract:
  `contract/strategic-b-validation-custody-v3.json`
  4878 bytes
  SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

- Plan V4:
  `contract/validation-plan-v4.json`
  26001 bytes
  SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

- Plan equivalence:
  `contract/plan-v3-v4-semantic-equivalence-v1.json`
  3937 bytes
  SHA-256:
  4855cbd41a4c16a4d0ff52aa2dec75bdd66b1f272d1e1323d7a3b8759efe2f5b

- final implementation report:
  21171 bytes
  SHA-256:
  4cec72ec50ddf41658b9fbf6a48c843ce5a2377bfaf17424bdefada7f1f0d3e6

- final evidence inventory:
  18305 bytes
  SHA-256:
  f7f602952c1a44d442982e883fe6be44c48dca0a908701126463e943964b25c9

- predecessor manifest pair:
  19881 bytes each
  SHA-256:
  94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359
  required byte-identical

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-independent-audit-cjba38lf

Consume the calling-thread audit report and independently verify its retained
artifacts. The audit is nonqualifying because of its carrier-index mismatch,
but its target findings must be independently reproduced before repair.

Do not treat that audit verdict as acceptance or as an authority source.

──────────────────────────────────────────────────────────────────────────────
2. CLASSIFICATION AND EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Classification:

- source-external evidence/provenance repair;
- V3 contract semantics unchanged;
- Plan V4 executable and acceptance semantics unchanged;
- no repository implementation;
- no product implementation;
- no runtime replay;
- no publication or commit authority.

Authorized writes:

- one newly allocated repair capsule beneath `/Users/ds/Downloads`;
- audit-repair source, copied current normative records, bounded historical
  reference records, adoption records, validators, reports, inventories, and
  manifests inside that new capsule.

Forbidden writes:

- CANDIDATE_R;
- Strategic B gate or snapshot;
- V1;
- V2;
- V2 audit;
- predecessor V3;
- blocking audit;
- another repository;
- a supplied evidence root.

──────────────────────────────────────────────────────────────────────────────
3. FRESH REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root with `tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-t2ap-validation-custody-v3-audit-repair-

Create only bounded directories needed by the repair.

Recommended final structure:

opening/
contract/
lineage/
adoption/
validation/
provenance/
closeout/
manifest/
private/

No retained empty directory is permitted.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink or special object is permitted.

Remove `private/` before final closure and make two fresh `lstat` observations
on that exact path, both returning ENOENT.

──────────────────────────────────────────────────────────────────────────────
4. OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Before inspecting target correctness:

1. Verify candidate identity and unchanged status.
2. Verify accepted Strategic B gate root and canonical projection.
3. Verify Strategic B source inventory and tree.
4. Verify complete blocked-V1 root closure.
5. Verify complete V2 root closure.
6. Verify complete V2-audit root closure and verdict BLOCK.
7. Verify complete predecessor-V3 root closure.
8. Verify complete blocking-audit root closure.
9. Verify every fixed identity above.
10. Retain complete opening inventories for all supplied roots.

Stop with `AUDIT_REPAIR_PROVENANCE_MISMATCH` on any mismatch.

No runtime command from Plan V3 or V4 may be executed.

──────────────────────────────────────────────────────────────────────────────
5. REPRODUCE THE TWO TARGET FINDINGS
──────────────────────────────────────────────────────────────────────────────

A. Competing normative authority

Locate every predecessor-V3 file that:

- contains contract ID
  `execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v3`;
- states
  `sole_normative_writer_for_validation_custody:true`;
- states pending-effective or equivalent current status.

Independently prove whether the failed-attempt subtree contains a second
self-normative contract-shaped object.

Retain an exact ledger containing:

- path;
- size;
- SHA-256;
- relevant field map;
- enclosing lineage;
- current/noncurrent disposition.

B. Incomplete V2 adoption lineage

Inspect every predecessor-V3 V2-adoption row.

Independently identify the two rows whose cited raw records report
`pass:false` or `all_accepted:false`.

Locate and authenticate:

`adjudication/replay-and-cleanup-corrections.json`

Record its exact path, schema, size, SHA-256, relevant fields, and relationship
to each raw record.

Do not assume that the correction record supports the adopted fact. Verify it.

Stop with the blocked verdict if either audit finding cannot be reproduced or
if the correction record does not support the claimed observations.

──────────────────────────────────────────────────────────────────────────────
6. CURRENT NORMATIVE RECORDS
──────────────────────────────────────────────────────────────────────────────

Retain exactly one current normative validation-custody contract:

contract/strategic-b-validation-custody-v3.json

Its bytes must be exact copies of the predecessor current contract:

- 4878 bytes
- SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

Retain exactly one current Plan V4:

contract/validation-plan-v4.json

Its bytes must be exact copies of the predecessor Plan V4:

- 26001 bytes
- SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

Retain exact current source-closure and semantic-equivalence records only after
independent revalidation.

Do not change V3 fields, Plan V4 command semantics, source closure, path
budget, authority flags, or nonauthority flags.

Stop if an exact current record cannot be copied and independently validated.

──────────────────────────────────────────────────────────────────────────────
7. FAILED-ATTEMPT AUTHORITY REPAIR
──────────────────────────────────────────────────────────────────────────────

Do not copy a failed-attempt contract, Plan V4, source-closure record, or other
self-normative record into the new current capsule.

The new repair capsule may retain only a bounded historical reference index for
the predecessor failed-attempt bytes.

Create:

lineage/failed-and-superseded-attempt-index-v2.json

For each failed-attempt artifact, bind:

- exact predecessor root;
- exact relative path;
- size;
- SHA-256;
- attempt identity;
- failure reason;
- superseding current record;
- `normative: false`;
- `effective: false`;
- `authoritative: false`;
- `current_contract_writer: false`;
- `current_plan_writer: false`;
- `eligible_for_runtime_or_acceptance_use: false`.

The index must state that historical bytes remain immutable in the predecessor
root and were deliberately not copied into the current repair root.

Create:

lineage/authoritative-supersession-v1.json

It must bind:

- predecessor V3 root identity;
- predecessor current-record identities;
- predecessor failed-attempt identities;
- new repair-root identity;
- exact current contract and Plan V4 identities;
- sole-current-writer disposition;
- bounded supersession scope.

It must not claim to supersede:

- V3 contract semantics;
- Plan V4 semantics;
- V2 dynamic evidence;
- Strategic B source authority;
- runtime results.

Require a whole-root authority scan proving:

- exactly one current contract-shaped V3 normative object;
- no failed-attempt contract-shaped bytes in the new root;
- no other file claims current sole-writer authority;
- reports and validators are explicitly nonnormative.

──────────────────────────────────────────────────────────────────────────────
8. V2 TECHNICAL-EVIDENCE ADOPTION V2
──────────────────────────────────────────────────────────────────────────────

Create:

adoption/v2-technical-evidence-adoption-v2.json

Do not rewrite or copy V2 dynamic result bytes.

For every adopted observation, bind:

- observation ID;
- raw source path;
- raw source size and SHA-256;
- raw schema;
- exact raw status fields;
- correction source when applicable;
- correction source size and SHA-256;
- exact correction field or adjudication;
- adopted fact;
- adoption basis:
  `raw-record`
  or
  `raw-plus-correction-record`;
- evidence authority:
  `bounded-technical-observation`;
- dynamic replay:
  false;
- V2 audit verdict:
  BLOCK;
- verdict promoted:
  false;
- product/runtime/readiness/A6 authority:
  false.

For the eight-command observation:

- preserve that the raw summary reports `all_accepted:false` and/or
  `pass:false`;
- cite the exact correction record and exact field that supports the corrected
  adopted fact;
- do not claim the raw summary alone passed.

For cleanup:

- preserve that the raw cleanup record reports `pass:false`;
- cite the exact correction record and exact field that supports the corrected
  cleanup fact;
- do not claim the raw cleanup record alone passed.

For every other observation, independently verify whether the raw record alone
supports it. Do not copy predecessor adoption wording without rechecking.

Create one complete lineage ledger showing:

raw observation → correction when any → adopted bounded fact.

Return the blocked verdict if any adopted fact remains unsupported,
strengthened, ambiguous, or verdict-promoting.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT STATIC REVALIDATION
──────────────────────────────────────────────────────────────────────────────

Without runtime replay, independently revalidate:

- exact V3 field map;
- Plan V3→V4 field-level semantic equivalence;
- exact five-source closure;
- exact 86-byte path derivation;
- explicit authority and nonauthority;
- accepted Strategic B gate binding;
- V2 adoption V2;
- sole-writer uniqueness.

The predecessor producer results are supplemental only.

Retain new repair-owned records for each revalidation.

──────────────────────────────────────────────────────────────────────────────
10. MUTATION-INTENT INDEPENDENCE
──────────────────────────────────────────────────────────────────────────────

Implement two validators:

A. Producer repair validator.
B. Independently implemented validator using no producer-validator code or
   parsing helper.

Each validator must contain its own literal expected mutation-name and
expected-reason set. Neither set may be generated from mutation fixtures or
from the other validator.

Require exact count, uniqueness, two-way name equality, execution, and
mechanism-specific rejection.

Include at least the previous 41 mutation classes plus these repair-specific
cases:

42. second current V3 normative contract
43. failed-attempt contract copied into the current root
44. failed-attempt index marks historical contract normative
45. failed-attempt index marks historical Plan effective
46. authoritative supersession omits predecessor binding
47. authoritative supersession widens semantic scope
48. raw eight-command `pass:false` treated as direct pass
49. eight-command correction record omitted
50. eight-command correction digest changed
51. correction field does not support adopted fact
52. raw cleanup `pass:false` treated as direct pass
53. cleanup correction record omitted
54. V2 BLOCK promoted
55. adopted observation broadened beyond raw-plus-correction evidence
56. directory symlink omitted by inventory
57. special object omitted by inventory
58. unexplained empty directory admitted
59. final inventory includes unstable directory size or link count
60. final scan omits the final report without declaring the exclusion
61. second current Plan V4 writer
62. report claims normativity
63. validator claims normativity
64. historical failed-attempt bytes eligible for runtime use

Require zero false acceptances.

Retain exact validator sources and complete results.

──────────────────────────────────────────────────────────────────────────────
11. COMPLETE MEMBERSHIP AND DIRECTORY-SYMLINK SAFETY
──────────────────────────────────────────────────────────────────────────────

Use two independently implemented manifest generators.

Both must:

- enumerate root and every descendant with lstat/no-follow semantics;
- detect directory symlinks rather than silently skipping them;
- reject every symlink;
- reject every special object;
- reject multiply linked regular files;
- reject unsupported UTF-8 paths;
- include every retained directory;
- include every nonmanifest regular file;
- sort by complete relative-path UTF-8 bytes;
- include only stable fields.

Directory manifest fields:

- path;
- type;
- physical mode.

Do not include directory size or directory link count.

Regular-file fields:

- path;
- type;
- physical mode;
- link count;
- size;
- SHA-256.

The two final manifests must be byte-identical.

Exactly the two manifests may self-exclude.
No directory exclusion is permitted.
No empty retained directory is permitted.

──────────────────────────────────────────────────────────────────────────────
12. FINAL INVENTORY TEMPORAL CONTRACT
──────────────────────────────────────────────────────────────────────────────

Create:

closeout/final-evidence-inventory-v2.json

Build it after all retained nonmanifest artifacts except itself and the two
manifests are final.

It must represent:

- every directory;
- every regular nonmanifest file except itself;
- no unstable directory size or link-count field.

Its exact declared exclusions are:

1. itself;
2. manifest A;
3. manifest B.

The final manifest pair must subsequently cover the final inventory file.

Do not claim that the final inventory covers its own bytes or the manifest
bytes.

──────────────────────────────────────────────────────────────────────────────
13. FINAL SENSITIVE-MATERIAL SCAN
──────────────────────────────────────────────────────────────────────────────

Finalize the implementation report before the final scan.

Then create:

closeout/final-sensitive-material-scan-v1.json

It must scan every retained regular nonmanifest file existing at that point,
including:

- the final implementation report;
- validators;
- adoption records;
- lineage records;
- revalidation records;
- failed-attempt index;
- final inventory when already present.

Its only content exclusions may be:

- itself;
- the two future manifests.

Record every scanned path, size, and SHA-256.

Do not emit matched payload content.

Classify:

- hashes;
- fixture patterns;
- redaction expressions;
- placeholders;
- plausible live secret findings.

Any plausible live secret blocks completion.

The manifest pair must cover the final scan record.

The implementation report must not falsely claim that the scan covers its own
bytes.

──────────────────────────────────────────────────────────────────────────────
14. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3;
- Plan V4;
- Go repository tests;
- product code;
- V2 allocator;
- V2 causal harnesses;
- services or routes.

Allowed executable work is limited to audit-repair-owned:

- parsers;
- hashers;
- inventory builders;
- static source analyzers;
- plan comparators;
- mutation validators;
- scanners;
- manifest generators;
- cleanup utilities.

──────────────────────────────────────────────────────────────────────────────
15. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Retain every failed audit-repair attempt separately.

No failed attempt may:

- overwrite a successful artifact;
- occupy the current normative namespace;
- be copied as a current contract or plan;
- contribute a final identity or pass count.

The failed-attempt index must bind exact source, output, reason, and superseding
attempt.

Failed attempt source may be retained only when it does not itself claim
current V3 normativity. Otherwise retain its size/hash/path in an external
historical ledger rather than copying the self-normative bytes.

──────────────────────────────────────────────────────────────────────────────
16. CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

After all repair work:

- reverify candidate identity and unchanged status;
- reverify accepted Strategic B gate and snapshot;
- reverify blocked V1;
- reverify V2;
- reverify V2 audit;
- reverify predecessor V3;
- reverify blocking audit;
- verify every supplied root byte-for-byte equal to opening.

Verify:

- no supplied-root mutation;
- no candidate mutation;
- no process survivor;
- no descriptor survivor;
- no audit-owned private state.

Remove the exact repair-owned `private/` path.

Make two fresh `lstat` observations on that exact path and require ENOENT.

──────────────────────────────────────────────────────────────────────────────
17. FINAL MANIFEST AND CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

After final report, final inventory, and final sensitive scan are complete:

1. Generate manifest A.
2. Generate manifest B independently.
3. Require byte identity.
4. Verify complete membership.
5. Reproject both after creation.
6. Require exact closure.

The only self-exclusions are the two manifest files.

Retain no empty directory, symlink, special object, multiply linked file, or
unexplained artifact.

──────────────────────────────────────────────────────────────────────────────
18. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop with `AUDIT_REPAIR_PROVENANCE_MISMATCH` on:

- input identity mismatch;
- supplied-root drift;
- candidate drift;
- missing exact predecessor input;
- opening/closing inequality.

Stop with the blocked verdict on:

- correction record not supporting either V2 adopted fact;
- any remaining competing current normative writer;
- inability to preserve exact V3 contract or Plan V4 semantics;
- incomplete source closure;
- unsupported adopted observation;
- manifest ambiguity;
- unexplained object;
- plausible sensitive material;
- false mutation acceptance;
- requirement for runtime replay or repository modification.

Do not repair outside the new capsule.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete implementation report inline:

1. Primary verdict
2. Repair-root identity
3. Opening candidate and supplied-root identities
4. Audit findings reproduced
5. Exact effect boundary
6. Current normative contract identity
7. Current Plan V4 identity
8. Failed-attempt authority repair
9. Authoritative supersession record
10. Complete V2 adoption V2 field map
11. Exact raw and correction lineage for all adopted observations
12. Confirmation V2 verdict remains BLOCK
13. Independent V3 contract revalidation
14. Independent Plan V3→V4 equivalence
15. Independent exact-source and 86-byte derivation
16. Mutation validators and exact case set
17. Complete membership and directory-symlink adjudication
18. Final inventory temporal treatment
19. Final sensitive-material scan
20. Failed/superseded attempts
21. Closing supplied-root equality
22. Cleanup and exact-private-path ENOENT observations
23. Final manifest identities and capsule closure
24. Remaining uncertainty and nonclaims
25. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_GATE_ROOT_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V3_PREDECESSOR_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
V3_CONTRACT_SEMANTICS_NOT_CHANGED
PLAN_V4_SEMANTICS_NOT_CHANGED
FAILED_ATTEMPT_NORMATIVE_BYTES_NOT_COPIED_AS_CURRENT_AUTHORITY
EXACTLY_ONE_CURRENT_V3_NORMATIVE_WRITER
V2_RAW_FAILURES_PRESERVED
V2_CORRECTION_LINEAGE_EXPLICIT
V2_BLOCK_VERDICT_NOT_PROMOTED
RUNTIME_VALIDATION_NOT_RERUN
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

## Audit-process correction for the later fresh audit

Do not repeat the last audit’s carrier-index requirement verbatim. The next audit should require the retained index to bind only carrier facts that are available and stable:

- contiguous ordinal;
- phase;
- exact wrapper SHA-256;
- exact payload path, size, and SHA-256;
- submitted cwd;
- explicit environment SHA-256 plus retained environment record;
- platform-reported outcome class;
- phase-start and phase-outcome identities;
- child ordinal range.

The Codex transcript remains authoritative for top-level command submission and scheduling. The retained index must not be required to reproduce opaque or unavailable tool-internal command expansions. All target-facing carriers still need wrapper phase records, and no unwrapped diagnostic carrier is permitted.

**Source:** Codex V3 independent-audit report in the preceding message.

**Confidence:** 0.995 that the two high findings require new source-external evidence bytes; 0.99 that V3 and Plan V4 semantics should remain unchanged; 0.98 that repairing the three evidence-quality weaknesses in the same bounded capsule is the lowest-risk path to a clean fresh audit.

Some earlier uploaded artifacts are no longer available in this session. The inline Codex report was sufficient for this assessment; re-upload those artifacts only if you need me to inspect their bytes directly.
