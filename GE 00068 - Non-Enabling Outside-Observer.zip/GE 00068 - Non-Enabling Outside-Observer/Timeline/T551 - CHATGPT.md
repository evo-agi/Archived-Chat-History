## Engineering assessment

This run establishes **no subject acceptance and no subject blocker**. It failed as an audit implementation before lawful substantive adjudication.

The replacement subject itself remained stable and passed the portions that were independently reached:

- terminal physical closure and both retained manifests matched;
- the normative contract identity matched;
- all 15 current schemas passed Draft 2020-12;
- the authenticated subject mapping still says 15 schema roles, 14 generated families, and `normative-construction-parent` intentionally unmapped. :chatgpt-content-reference{index="0"}

The audit failed for multiple audit-owned reasons:

1. **Source qualification never passed.** The source freeze has `pass=false`; the logic qualification and static qualification both failed. Despite that, the substantive parent was launched once. :chatgpt-content-reference{index="1"}
2. **The audit model invented a fifteenth family**, `normative-contract-document`, contradicting the authenticated 14-family mapping. That caused `KeyError('normative-contract-document')` when witness construction began. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}
3. **The governed outcome vocabulary was incomplete.** The 946 qualification still failed three cases; the 137 qualification failed eight cases, generated audit-execution errors, and represented only 136 historical regression ordinals. :chatgpt-content-reference{index="4"}
4. **No real 946 or 137 subject evaluation occurred.** The retained “real” aggregates contain zero rows and mark all cases skipped. :chatgpt-content-reference{index="5"}
5. **The static no-Git gate failed, and the task later actually invoked `git status`.** This independently defeats the requested audit provenance. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}
6. **No audit phases, custody closure, supplied-root equality, temporal inventory, manifests, or terminal seal were produced.** The retained root is partial and unsealed. :chatgpt-content-reference{index="8"}

The report itself correctly classifies every established failure as audit-owned and says the subject’s independent acceptability remains unadjudicated. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

### Progression decision

Do **not** run another substantive subject audit yet.

First implement, qualify, freeze, and package a new clean independent-audit harness in a separate tranche. The real replacement subject must not be used for substantive adjudication until all audit-logic, static, totality, coverage, family-model, no-Git, and capsule-lifecycle gates pass.

This separation is now necessary because the latest task violated its own critical ordering: it launched the substantive parent while source freeze and qualification were already false.

The new audit generation must:

- use exactly 14 generated families;
- derive the complete 946 and 137 outcome vocabulary row by row;
- pass every known regression before source freeze;
- prove total checking of missing, null, and wrong-typed values;
- prohibit any Git/VCS invocation in source **and in the enclosing task**;
- create no real subject verdict during qualification;
- package a deterministic audit executable with one future audit authorization;
- run the real subject audit only in the following task.

---

## Complete replacement Codex prompt

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
INDEPENDENT-AUDIT HARNESS FOR THE UNCHANGED REPLACEMENT
GENERATION-2 SCHEMA SUBJECT

DO NOT EXECUTE THE REAL SUBJECT AUDIT IN THIS TASK

Objective

Create a new clean, source-external independent-audit harness for the unchanged
replacement subject:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

The immediately preceding audit returned:

AUDIT_PROVENANCE_MISMATCH

It did not establish a subject-package blocker.

Its audit implementation failed before lawful substantive adjudication.

The exact demonstrated audit defects were:

1. source freeze was false;
2. audit-logic qualification was false;
3. static qualification was false;
4. the substantive parent was nevertheless launched;
5. the audit model added an unauthorized fifteenth generated family:
   `normative-contract-document`;
6. witness construction then raised:
   `KeyError('normative-contract-document')`;
7. the 946 qualification failed ordinals 896, 897, and 901;
8. the 137 qualification failed ordinals 1, 24, 25, 37, 38, 46, 47,
   and 137;
9. seven 137 qualification rows produced `AUDIT_EXECUTION_ERROR`;
10. only 136 historical 137-regression ordinals were represented;
11. the governed outcome vocabulary was incomplete;
12. no real 946 subject rows were executed;
13. no real 137 subject rows were executed;
14. static `no_git` failed;
15. a later reporting operation invoked `git status`;
16. no A00–A15 phase records were retained;
17. no terminal custody record was retained;
18. no supplied-root closing-equality record was retained;
19. no temporal inventory or canonical audit manifests were created;
20. no terminal seal occurred.

Implement a wholly new clean audit generation.

Do not patch, copy, import, translate, execute, decompile, disassemble into
source, or use as an AST, bytecode, fixture, expected-result, normalizer, or
projector origin:

- the failed audit parent;
- the failed primary oracle;
- the failed secondary oracle;
- the failed qualification runner;
- the failed static qualifier;
- any earlier subject-audit source;
- any findings-reconciliation source;
- reconstruction-parent production source;
- producer validator helpers;
- producer fixture generators;
- producer expected-result maps;
- producer report or confirmation projectors.

The failed reports may be used only as explicit regression requirements stated
in this task.

Do not run the real replacement-subject audit in this task.

Do not issue a subject ACCEPT or BLOCK.

Do not mutate, repair, clean, chmod, relocate, or reseal the subject.

Do not execute subject source.

Do not rerun subject construction.

Do not promote or rebind current schema authority.

Do not use Git or any other VCS for any reason.

Do not run `git status`.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite clean implementation and qualification parent in one fresh
private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_ONE_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FUTURE SUBJECT INPUT
──────────────────────────────────────────────── LIMITED TO IDENTITY AND COMPATIBILITY
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID:
  501
- GID:
  20

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files;
- one root row;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory mode 0700;
- file mode 0600;
- no cache or bytecode.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Authenticate read-only.

The subject may be used only for:

- fixed-input authentication;
- bounded compatibility checking;
- construction of nonauthoritative expected path/role joins;
- final future-invocation binding.

Do not perform substantive 946, 137, witness, field-map, documentary-validator,
confirmation, occupancy, finding, or verdict evaluation against the real
subject in this task.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. REPLACEMENT CONSTRUCTION AUTHORITY
──────────────────────────────────────────────── LIMITED TO PROVENANCE
────────────────────────────────────────────────

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID:
  501
- GID:
  0

Authenticate only:

- exact replacement root allocation;
- construction authorization and consumption;
- accepted production source and freeze;
- production-parent process custody;
- exact root locator;
- supplied-input equality;
- subject terminal closure;
- no second construction;
- no independent audit during construction.

Do not use wrapper prose as semantic subject authority.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED IMPLEMENTATION AUTHORITY
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the current authority chain required to bind:

- accepted reconstruction-parent implementation;
- accepted production source;
- accepted semantic source-freeze role;
- construction contract;
- implementation package unsuperseded;
- replacement wrapper used the accepted parent.

Do not re-audit the implementation package.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT AUTHORITY
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before ZIP.

Require:

- 479 members;
- eight current roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive validation;
- no `.DS_Store`.

Resolve exact current authority for:

- normative contract;
- current schemas;
- schema-role registry;
- generated-family mapping;
- 946-case specification;
- 137-case specification;
- 766/333 field-map specification;
- documentary-validator specification;
- confirmation-evidence specification.

The containing directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
5. FAILED AUDIT DISPOSITION
──────────────────────────────────────────────── LIMITED TO REGRESSION FACTS
────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-independent-audit-v2-qjgwbft7

Do not open or execute source from this root.

Do not make the root a fixed input.

Do not require it to be sealed or complete.

Retain only these externally supplied historical regression facts:

- verdict:
  AUDIT_PROVENANCE_MISMATCH;
- source freeze:
  false;
- static qualification:
  false;
- logic qualification:
  false;
- substantive parent nevertheless launched:
  true;
- generated family incorrectly added:
  normative-contract-document;
- witness construction exception:
  KeyError('normative-contract-document');
- 946 qualification failed:
  896,
  897,
  901;
- 137 qualification failed:
  1,
  24,
  25,
  37,
  38,
  46,
  47,
  137;
- 137 audit-execution-error rows:
  seven;
- historical 137 regression coverage:
  136 of 137;
- Git invocation occurred:
  true;
- real subject 946 execution:
  not performed;
- real subject 137 execution:
  not performed;
- terminal audit capsule:
  absent.

Classify:

HISTORICAL_NONQUALIFYING_AUDIT_IMPLEMENTATION_FAILURE

This root contributes no source, oracle, evidence, verdict, or terminal
authority.

──────────────────────────────────────────────────────────────────────────────
6. FRESH IMPLEMENTATION AND OUTPUT ROOTS
────────────────────────────────────────────────

Allocate one fresh private build root beneath `/private/tmp`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-

Immediately emit:

AUDIT_HARNESS_BUILD_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-

Immediately emit:

AUDIT_HARNESS_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit.pyz

gen2-replacement-schema-subject-independent-audit.authority-v1.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/clean-audit-generation-authority-v1.json
opening/fixed-input-registry-v1.json
opening/clean-source-authority-v1.json
opening/process-execution-policy-v1.json
opening/source-development-policy-v1.json
opening/implementation-operating-freeze-v1.json

──────────────────────────────────────────────────────────────────────────────
7. CLEAN SOURCE AUTHORITY
────────────────────────────────────────────────

Permitted source inputs:

- normative contract bytes;
- current schema bytes;
- current validation-specification bytes;
- current role registries;
- current case registries;
- current field-map specification;
- this task’s explicit regression requirements.

Forbidden source inputs:

- failed audit source;
- failed audit bytecode;
- failed oracle source;
- historical audit source;
- historical reconciliation source;
- producer source;
- producer validators;
- producer fixtures;
- producer expected-result maps;
- producer or audit projectors/normalizers;
- transcript-reconstructed source;
- decompiled/disassembled source;
- similarity-derived source.

Retain:

opening/clean-source-authority-v1.json

Independently validate every source file’s origin before compilation.

──────────────────────────────────────────────────────────────────────────────
8. AUTHORITATIVE 15/14 MODEL
────────────────────────────────────────────────

Before source creation retain:

contract/current-schema-and-family-model-v1.json

Derive from exact current governing rows:

- exactly 15 schema roles;
- exactly 14 generated-record families;
- exact role/family mapping;
- `child-process-record → child-process`;
- exact mappings for the other 13 generated roles;
- `normative-construction-parent` is the sole intentionally unmapped role;
- no `normative-contract-document` family;
- no fifteenth generated family.

All witness constructors, case evaluators, field-map logic, occupancy logic, and
reporting consume this frozen 15/14 model.

Any source path that creates, accepts, indexes, or expects
`normative-contract-document` as a generated family fails qualification.

──────────────────────────────────────────────── LIMITED TO EXACT ROWS
────────────────────────────────────────────────

9. COMPLETE GOVERNED OUTCOME VOCABULARY

Before implementing the oracles, derive and retain:

contract/governed-946-outcome-vocabulary-v1.json
contract/governed-137-outcome-vocabulary-v1.json

For all 946 current cases retain one row containing:

- ordinal;
- literal name;
- case family;
- schema role;
- expected acceptance posture;
- expected exact outcome token;
- expected reason class;
- mutation operator;
- mutation pointer;
- controlling schema/contract/spec pointer;
- documentary checks required;
- missing/null/wrong-type behavior.

For all 137 current cases retain one row containing:

- ordinal;
- literal name;
- contradiction family;
- expected exact outcome token;
- expected reason;
- historical-prefix posture;
- contradiction site;
- governed atomic-member count where applicable;
- controlling specification pointer.

Require exact counts:

- 946 rows;
- 137 rows.

Require unique names and complete ordinal/name closure.

Do not infer a generic vocabulary from a subset.

Do not collapse outcomes to:

- ACCEPT_ALL_14;
- generic ACCEPT;
- generic REJECT;
- truthiness;
- exception presence.

An evaluator must return the exact expected vocabulary domain or an explicit
audit-execution error.

──────────────────────────────────────────────────────────────────────────────
10. TOTAL DOCUMENTARY CHECKING
────────────────────────────────────────────────

Retain:

contract/total-documentary-checking-v2.json

Every documentary operation must be total over:

- missing;
- null;
- Boolean;
- integer;
- string;
- array;
- object;
- malformed members.

No acceptance-bearing operation may:

- iterate an unverified value;
- use `.get` on an unverified value;
- index an unverified array/object;
- treat exception as governed rejection;
- treat absence as success;
- conflate Boolean false with missing;
- conflate integer zero with false.

Required prequalification regressions:

- 946 ordinals:
  80,
  98,
  102,
  110,
  203,
  204,
  518,
  896,
  897,
  900,
  901;

- 137 ordinals:
  1,
  24,
  25,
  37,
  38,
  46,
  47,
  137.

Every regression must:

- execute without exception;
- produce the exact governed outcome;
- produce the exact governed reason;
- retain direct evidence.

──────────────────────────────────────────────── LIMITED TO TWO ORACLES
────────────────────────────────────────────────

11. DUAL-ORACLE INDEPENDENCE

Implement two independently authored evaluators for:

- witness validation;
- 946 cases;
- 137 cases;
- confirmation derivation.

They may share only:

- immutable governing bytes;
- authenticated `jsonschema`;
- frozen outcome-vocabulary contracts;
- exact 15/14 model.

They must not share:

- case interpretation;
- mutation code;
- documentary checker;
- reason classifier;
- error normalizer;
- aggregate projector;
- expected-result map;
- witness constructor.

Retain:

contract/dual-oracle-audit-contract-v3.json

For every qualification case require exact primary/secondary agreement.

Any unexplained disagreement blocks source freeze.

──────────────────────────────────────────────── LIMITED TO REGISTRY IDS
────────────────────────────────────────────────

12. OCCUPANCY ROLE VOCABULARY

Retain:

contract/current-role-occupancy-vocabulary-v2.json

Use exact current role IDs from authenticated registries.

For documentary validators preserve:

documentary-validator:<role>

Do not generate:

validator:<role>

No prefix aliasing or normalization unless governed by an exact current
contract.

Occupancy closure is exact set equality.

──────────────────────────────────────────────── LIMITED TO EVIDENCE
────────────────────────────────────────────────

13. EVIDENCE-DERIVED CONFIRMATIONS

Retain:

contract/evidence-derived-confirmation-v2.json

Every confirmation row contains:

- name;
- evidence path;
- JSON pointer;
- expected;
- observed;
- pass;
- direct or derivative classification;
- dependencies.

No hard-coded values.

No global all-true projection.

No absence-as-success.

No stale or circular evidence.

A false confirmation caused solely by another failed direct domain is
derivative and is not a separate direct package blocker.

──────────────────────────────────────────────── LIMITED TO CAPSULE
────────────────────────────────────────────────

14. PHYSICAL CLOSURE AND A15 CONTRACT

Retain:

contract/audit-capsule-terminal-closure-v2.json

Physical directory emptiness uses the complete physical namespace.

It does not use a self-excluding projection.

Before temporal projection:

- create all final directories;
- reserve temporal inventory;
- reserve manifest A;
- reserve manifest B;
- reserve terminal result;
- retain descriptors;
- freeze namespace.

Reserved files count as physical directory children.

Require separately:

- physical no-empty-descendant result;
- temporal projection;
- manifest projection;
- final whole-root reprojection.

A15 status must equal final `closure_pass`.

A15 cannot report passed when closure is false.

After seal:

- no filesystem read or write;
- no inventory;
- no validation;
- no process;
- only the precomputed terminal frame;
- immediate nonreturning exit.

──────────────────────────────────────────────── LIMITING DRAFTS
────────────────────────────────────────────────

15. SOURCE DEVELOPMENT AND ATTEMPT POLICY

Permit a draft qualification phase before package authority.

At most three draft correction cycles.

Every cycle retains:

- source registry;
- source identities;
- first blocker;
- bounded delta;
- compilation;
- affected qualification results;
- protected regression results.

A draft cycle does not authorize or execute the real subject audit.

No substantive real-subject audit parent may be launched until:

- all source compiles;
- static qualification passes;
- logic qualification passes;
- dual-oracle qualification passes;
- exact 15/14 qualification passes;
- 946 vocabulary closure passes;
- 137 vocabulary closure passes;
- every required regression passes;
- no-Git qualification passes;
- capsule terminal-lifecycle qualification passes;
- source freeze passes.

If no draft passes within three cycles:

- return IMPLEMENTATION_BLOCKED;
- do not execute a real subject audit.

After source freeze:

- source modification forbidden.

────────────────────────────────────────────────

16. SOURCE ARCHITECTURE

Define clean modular roles for:

- executable entrypoint;
- finite qualification/audit parent;
- strict JSON;
- no-follow inventory;
- manifest reprojector;
- Draft 2020-12 adapter;
- 15/14 model reader;
- contract witness constructor;
- schema witness constructor;
- primary 946 evaluator;
- secondary 946 evaluator;
- primary 137 evaluator;
- secondary 137 evaluator;
- governed-outcome resolver;
- total documentary checker A;
- total documentary checker B;
- field-map resolver;
- documentary-validator adjudicator;
- confirmation derivation A;
- confirmation derivation B;
- occupancy/lineage adjudicator;
- finding/repair-owner builder;
- process recorder;
- cleanup owner;
- input-equality owner;
- capsule phase owner;
- temporal/manifest owner;
- terminal-frame owner;
- independent qualification validators;
- deterministic package builder;
- runtime authority builder;
- launch-certificate builder.

Every role maps exactly once to a clean source path.

Independent validators import no implementation helper, fixture generator,
expected-result map, oracle, projector, or normalizer.

──────────────────────────────────────────────── LIMITING PREQUALIFICATION
────────────────────────────────────────────────

17. LOGIC QUALIFICATION MATRICES

Before source freeze run separate matrices.

A. 15/14 model matrix:
at least 25 cases.

Must include:

- exact baseline;
- normative parent unmapped;
- unauthorized normative-contract-document family;
- fifteenth family;
- missing family;
- duplicate family;
- wrong role/family mapping.

B. 946 outcome-vocabulary matrix:
at least 80 cases.

Include all historical failed qualification ordinals and exact baseline.

C. 137 outcome-vocabulary matrix:
at least 160 cases.

Must cover every one of the 137 current cases at least once.

Must explicitly reject `ACCEPT_ALL_14` collapse.

D. Total-documentary-checking matrix:
at least 70 cases.

Cover all JSON shapes and all listed historical exception ordinals.

E. Dual-oracle matrix:
at least 60 cases.

F. Occupancy-role matrix:
at least 30 cases.

G. Confirmation-derivation matrix:
at least 35 cases.

H. Physical-closure/A15 matrix:
at least 40 cases.

I. End-to-end synthetic audit matrix:
at least 30 cases.

Include synthetic:

- ACCEPT;
- direct subject BLOCK;
- audit-provenance failure;
- derivative confirmation failure;
- oracle disagreement;
- terminal closure failure.

Every matrix requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception;
- zero unexplained oracle disagreement.

────────────────────────────────────────────────

18. NO-GIT QUALIFICATION

Retain:

contract/no-vcs-execution-v1.json

The complete task, source, qualification, packaging, validation, and reporting
must not invoke:

- git;
- hg;
- svn;
- fossil;
- any VCS library;
- any `.git` read.

Static qualification must inspect:

- imports;
- subprocess call sites;
- executable literals;
- dynamic executable construction;
- shell strings;
- environment-driven executable paths.

Runtime process custody must retain every child executable.

Any Git/VCS invocation by source, wrapper, qualification, reporting, or
post-run inspection forces:

AUDIT_PROVENANCE_MISMATCH

Do not attempt to confirm no-Git posture by running Git.

────────────────────────────────────────────────

19. COMPILATION, STATIC QUALIFICATION, AND SOURCE FREEZE

Compile all source under pinned Python:

-I -S -B

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- import origin;
- exception paths;
- process effects;
- filesystem effects;
- input boundaries;
- oracle independence;
- vocabulary completeness;
- totality;
- occupancy role IDs;
- confirmation derivation;
- physical closure;
- terminal operations;
- no-VCS posture.

Require:

- no forbidden source origin;
- exact 15/14 model;
- no unauthorized family;
- complete 946 and 137 vocabularies;
- no exception-as-outcome;
- no hard-coded confirmations;
- exact occupancy IDs;
- no Git/VCS;
- no network;
- no shell;
- no broad scan;
- no postseal operation.

Retain:

validation/clean-audit-static-qualification-v2.json

Freeze source only after all matrices and static gates pass.

Retain:

opening/clean-audit-source-freeze-v2.json

Reopen every source no-follow and require identity equality.

Do not modify source afterward.

──────────────────────────────────────────────── LIMITED TO PACKAGED HARNESS
────────────────────────────────────────────────

20. SYNTHETIC PACKAGED REHEARSALS

Before packaging final authority, build a provisional executable audit package
and run physically distinct synthetic rehearsals:

A. ACCEPT

- valid synthetic subject;
- all semantic domains pass;
- full terminal capsule.

B. BLOCK

- one exact direct subject defect;
- exact failed row and repair owner;
- full terminal capsule.

C. AUDIT_PROVENANCE_MISMATCH

- one exact audit provenance defect;
- no subject verdict promotion;
- full terminal provenance capsule.

D. HISTORICAL-REGRESSION REHEARSAL

- all listed 946 and 137 regression cases;
- no exception;
- exact governed outcomes;
- exact 15/14 model;
- exact occupancy IDs;
- evidence-derived confirmations;
- clean terminal closure.

Each rehearsal must:

- use packaged source;
- retain complete custody;
- retain phase records;
- retain cleanup and fixed-input equality;
- create temporal and byte-identical manifests;
- pass final reprojection;
- make A15 equal closure pass;
- perform no postseal operation;
- pass independent capsule validation.

Do not use the real replacement subject in these rehearsals.

────────────────────────────────────────────────

21. INDEPENDENT QUALIFICATION

Independent validators must verify:

- clean source provenance;
- 15/14 model;
- outcome-vocabulary completeness;
- total documentary checking;
- dual-oracle independence;
- no Git/VCS execution;
- occupancy IDs;
- confirmation derivation;
- physical closure;
- logic matrices;
- synthetic packaged rehearsals;
- source freeze;
- evidence retention and cleanup.

Independent validators import no candidate source helpers.

Require zero errors.

──────────────────────────────────────────────── LIMITED TO FINAL PACKAGE
────────────────────────────────────────────────

22. DETERMINISTIC AUDIT PYZ

Build independently twice:

gen2-replacement-schema-subject-independent-audit.pyz

Require byte equality.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special member;
- no comment or uncontrolled extra;
- no cache/bytecode.

Embed:

- clean source;
- source freeze;
- exact current governing contracts and registries;
- complete 946 and 137 outcome vocabularies;
- qualification results;
- future subject-audit invocation contract;
- no historical audit source.

Retain exact member registry and count.

────────────────────────────────────────────────

23. RUNTIME AUTHORITY

Create deterministically twice:

gen2-replacement-schema-subject-independent-audit.authority-v1.json

Bind:

- exact audit PYZ;
- member registry;
- source freeze;
- source registries;
- governing content identities;
- replacement subject identity;
- construction wrapper identity;
- accepted implementation chain;
- all qualification results;
- synthetic rehearsal results;
- future audit invocation;
- real replacement-subject audit executed:
  false;
- subject verdict:
  not issued;
- current authority promotion:
  false.

Require byte equality.

────────────────────────────────────────────────

24. POST-PACKAGE QUALIFICATION

Run exact final audit PYZ in qualification mode exactly once.

Retain complete custody and streams.

Require fresh verification of:

- PYZ/member closure;
- source freeze;
- exact 15/14 model;
- 946/137 vocabulary closure;
- total checking;
- dual-oracle qualification;
- no-Git posture;
- occupancy and confirmation logic;
- capsule lifecycle;
- all matrices;
- all packaged synthetic rehearsals;
- independent validators;
- deterministic package closure;
- real subject audit not executed.

────────────────────────────────────────────────

25. EXTERNAL LAUNCH CERTIFICATE

Create deterministically twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

Bind:

- exact audit PYZ;
- runtime authority;
- replacement subject identity;
- construction wrapper identity;
- content bundle and authority;
- accepted implementation chain;
- source freeze;
- qualification custody/result;
- all logic/static qualification;
- synthetic rehearsals;
- stream/framing contract;
- exact future real-audit invocation;
- wrapper launch authorized:
  true;
- authorized real subject-audit count:
  1;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- current authority promotion:
  false.

The certificate is external wrapper authority and is not passed to the audit
harness unless the exact CLI contract requires it.

Require byte equality.

Run independent certificate-input validation.

────────────────────────────────────────────────

26. FROZEN-PACKAGE REQUALIFICATION

Run exact final audit PYZ in qualification mode with final runtime authority.

Require:

- exit zero;
- empty stderr;
- exact result;
- package/source self-authentication;
- all logic and static gates;
- synthetic rehearsal linkage;
- authority coherence;
- no real subject audit;
- no subject verdict.

Independently recompute all governed aggregates.

Retain:

validation/frozen-audit-pyz-requalification-v1.json

────────────────────────────────────────────────

27. INPUT CLOSING EQUALITY AND CLEANUP

Repeat complete opening/closing equality for every supplied input opened:

- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Do not include the failed audit root because it was not opened.

Before removing disposable roots retain complete evidence.

Then revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

────────────────────────────────────────────────

28. FAILURE CLOSEOUT

On failure retain:

- source-development cycle;
- first blocker;
- structured exception;
- process custody and streams;
- partial inventory;
- qualification results;
- cleanup;
- supplied-input equality;
- freeze/package/authority/certificate posture;
- real subject audit not executed.

Do not create final authority files on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

29. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_ONE_AUDIT

only when:

- all fixed inputs authenticate;
- clean source provenance passes;
- exact 15/14 model freezes;
- complete 946 and 137 vocabularies freeze;
- all historical regression cases pass without exception;
- total documentary checking passes;
- dual-oracle qualification passes;
- no-Git posture passes;
- occupancy and confirmation qualification pass;
- physical closure/A15 qualification passes;
- all matrices pass;
- packaged synthetic ACCEPT/BLOCK/provenance/regression rehearsals pass;
- independent validation passes;
- source freezes;
- deterministic audit PYZ builds match;
- runtime-authority builds match;
- post-package qualification passes;
- launch-certificate builds match;
- certificate validation passes;
- frozen-package requalification passes;
- input equality and cleanup pass;
- final files are mode 0400;
- no real subject audit ran;
- no subject verdict was issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when:

- a substantive audit-implementation or qualification defect remains;
- source cannot qualify within three draft cycles;
- package construction cannot close without changing governing subject
  semantics.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- forbidden source origin;
- any Git/VCS invocation;
- evidence loss;
- process-custody failure;
- cleanup inequality;
- supplied-root mutation;
- source drift after freeze;
- final-output identity failure.

────────────────────────────────────────────────

30. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve successful final audit artifacts;
- do not execute the real subject audit;
- do not promote or rebind authority;
- do not construct another subject;
- do not run product/runtime/target activity;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

31. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Replacement-subject authentication
5. Construction-wrapper authentication
6. Accepted implementation-chain authentication
7. Content identities
8. Clean source authority
9. Source-development ledger
10. Source architecture and registries
11. Exact 15/14 model
12. Complete 946 outcome vocabulary
13. Complete 137 outcome vocabulary
14. Total-documentary-checking contract
15. Dual-oracle contract
16. Occupancy vocabulary
17. Confirmation-derivation contract
18. Physical-closure/A15 contract
19. No-Git contract
20. Logic qualification matrices
21. Compilation/static qualification
22. Independent qualification
23. Synthetic ACCEPT rehearsal
24. Synthetic BLOCK rehearsal
25. Synthetic provenance rehearsal
26. Historical-regression rehearsal
27. Evidence retention and cleanup
28. Source freeze
29. Audit PYZ Build A/B
30. PYZ equality and member closure
31. Runtime-authority Build A/B
32. Post-package qualification
33. Launch-certificate Build A/B
34. Certificate-input validation
35. Frozen-package requalification
36. Confirmation real subject audit not executed
37. Confirmation no subject verdict issued
38. Supplied-input closing equality
39. Failure-closeout capability/use
40. Final PYZ path and identity
41. Final authority path and identity
42. Final certificate path and identity
43. Remaining uncertainty and nonclaims
44. Explicit confirmations

Required confirmations:

REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
FAILED_AUDIT_ROOT_NOT_OPENED
FAILED_AUDIT_SOURCE_NOT_REUSED
CLEAN_AUDIT_SOURCE_AUTHORITY_ESTABLISHED
NO_PRODUCER_OR_HISTORICAL_AUDIT_SOURCE_USED
EXACT_FIFTEEN_SCHEMA_ROLE_MODEL_FROZEN
EXACT_FOURTEEN_GENERATED_FAMILY_MODEL_FROZEN
NORMATIVE_CONSTRUCTION_PARENT_INTENTIONALLY_UNMAPPED
NORMATIVE_CONTRACT_DOCUMENT_NOT_A_GENERATED_FAMILY
COMPLETE_946_OUTCOME_VOCABULARY_FROZEN
COMPLETE_137_OUTCOME_VOCABULARY_FROZEN
TOTAL_DOCUMENTARY_CHECKING_IMPLEMENTED
ALL_REQUIRED_946_REGRESSIONS_PASSED
ALL_REQUIRED_137_REGRESSIONS_PASSED
DUAL_ORACLE_INDEPENDENCE_ENFORCED
DUAL_ORACLE_QUALIFICATION_PASSED
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
CONFIRMATIONS_EVIDENCE_DERIVED
NO_HARDCODED_CONFIRMATION_SUCCESS
PHYSICAL_EMPTY_DIRECTORY_CHECK_USES_FULL_NAMESPACE
A15_STATUS_DERIVED_FROM_CLOSURE_PASS
NO_GIT_OR_VCS_INVOCATION
AUDIT_LOGIC_QUALIFICATION_PASSED
AUDIT_STATIC_QUALIFICATION_PASSED
SYNTHETIC_ACCEPT_REHEARSAL_PASSED
SYNTHETIC_BLOCK_REHEARSAL_PASSED
SYNTHETIC_PROVENANCE_REHEARSAL_PASSED
HISTORICAL_REGRESSION_REHEARSAL_PASSED
INDEPENDENT_QUALIFICATION_PASSED
SOURCE_FROZEN
SOURCE_NOT_MODIFIED_AFTER_FREEZE
AUDIT_PYZ_BUILD_A_B_BYTES_IDENTICAL
AUDIT_PYZ_MEMBER_CLOSURE_PASSED
RUNTIME_AUTHORITY_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
LAUNCH_CERTIFICATE_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_AUDIT_PYZ_REQUALIFICATION_PASSED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_AUDIT_PYZ_CREATED
FINAL_AUDIT_PYZ_MODE_0400
FINAL_AUDIT_PYZ_IDENTITY_VERIFIED
FINAL_RUNTIME_AUTHORITY_CREATED
FINAL_RUNTIME_AUTHORITY_MODE_0400
FINAL_RUNTIME_AUTHORITY_IDENTITY_VERIFIED
FINAL_LAUNCH_CERTIFICATE_CREATED
FINAL_LAUNCH_CERTIFICATE_MODE_0400
FINAL_LAUNCH_CERTIFICATE_IDENTITY_VERIFIED
FUTURE_REAL_SUBJECT_AUDIT_COUNT_AUTHORIZED_ONE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_ONE_AUDIT

the next task is exactly one real audit of the unchanged replacement subject
using:

1. final independent-audit PYZ;
2. final runtime authority;
3. final launch certificate;
4. replacement subject;
5. construction wrapper;
6. current content bundle;
7. current content authority;
8. accepted implementation authority chain.

Do not combine audit-harness implementation with the real subject audit.
```

### Sources and confidence

The attached report establishes that the replacement subject’s closure, current schema roles, metaschema validation, and authoritative 14-family mapping remained intact before the audit implementation failed. :chatgpt-content-reference{index="11"}

It establishes failed source freeze, failed static and logic qualification, incomplete outcome vocabularies, qualification-case errors, and the unauthorized fifteenth-family model. :chatgpt-content-reference{index="12"} :chatgpt-content-reference{index="13"}

It also establishes that no real 946/137 subject audit occurred, no phases or terminal capsule were completed, and all demonstrated failures were audit-owned. :chatgpt-content-reference{index="14"} :chatgpt-content-reference{index="15"}

**Provenance confidence:** 0.999  
**Audit-only defect classification confidence:** 0.999  
**Unchanged-subject posture confidence:** 0.995  
**Clean-harness-first sequencing confidence:** 0.99

The current attachment was fully readable. Some older uploaded files have expired; re-upload an older artifact only if a later review needs its original bytes rather than the retained reports and identities.
