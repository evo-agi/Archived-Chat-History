## Assessment

This is a **clean, narrowly contained BLOCK**.

The audit found no defect in the seven repository paths, the governance contract, allocation/orchestration semantics, marker-family handling, documentary test oracle, or fresh validation. The only blocker is in the **source-external repair evidence**:

- The authenticated repository opening mode for the three repair paths was `100644`.
- The two “complete” deltas instead recorded `100600` as their before-mode because both builders inspected the mode-`0600` **evidence-custody copies**.
- The paths, before/after bytes, sizes, hashes, final modes, repository inventories, source trees, contract, and tests were otherwise correct.

So the builders conflated two distinct facts:

- **Repository logical mode:** `100644`
- **Private evidence-file custody mode:** `0600`

Do not reopen the governance contract or modify repository files again. Do not address the nonblocking per-command membership or diagnostic-hardening observations in this repair. The critical path is:

1. Preserve the repository and all supplied roots read-only.
2. Create a fresh correction capsule outside the repository.
3. Regenerate both independent deltas from the authenticated repository inventories.
4. Supersede the two defective delta artifacts and their identity/report claims.
5. Produce complete new evidence manifests.
6. Return to a fresh, read-only audit.

That is the required repair lifecycle after a blocking audit: new evidence/provenance followed by a fresh independent audit.  File mode is an explicit part of provenance identity, while provenance remains evidence rather than proof of correctness. 

The audit-computed corrected hash, `0ea21358…3ec1`, should be treated as an **independent cross-check**, not as an output to manufacture.

## Codex repair prompt

Send this to a **workspace-write Codex implementation chat**. It is a parent-only source-external evidence repair, not a repository implementation or audit.

```text
MANDATORY RESPONSE FORMAT

Return exactly this primary implementation verdict on success:

REPAIR10I_A6_SUCCESSOR_GOVERNANCE_MODE_PROVENANCE_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Otherwise return one of:

OPENING_PROVENANCE_MISMATCH
EVIDENCE_REPAIR_BLOCKED

Embed the complete report inline in Markdown. Evidence paths may supplement the
report but must not replace it.

This is a parent-only evidence-repair task. Do not create subagents.

## 1. Objective

Repair the sole blocking finding from the fresh independent audit:

PARENT-EVID-001 / A3-PROV-001 / A4-EVID-001

The two retained “complete” repair-only deltas incorrectly encode logical
before-mode `100600` for three repository files whose authenticated repair
opening mode was `100644`.

The cause is known: both delta builders obtained the before-mode by calling
`lstat` on private mode-0600 evidence-custody copies instead of reading the
logical repository mode from the authenticated repair-opening inventory.

Produce a fresh, immutable, source-external correction capsule that:

1. independently regenerates both complete repair-only deltas;
2. obtains logical before-modes from the authenticated repair-opening
   inventory;
3. obtains logical after-modes from the authenticated final inventory and
   checks them against the live repository;
4. proves that only the three erroneous before-mode fields change relative to
   the predecessor delta;
5. regenerates the delta identity, supersession record, final repair report,
   and complete evidence manifests;
6. leaves the repository and every supplied evidence/audit root unchanged.

Do not modify or replace the predecessor evidence root in place.

## 2. Classification

This is a source-external evidence/provenance repair.

It is not:

- a repository patch;
- a governance-contract change;
- a documentary-test change;
- product implementation;
- semantic-successor implementation;
- allocator or orchestrator implementation;
- an independent audit;
- a commit gate;
- an A6 execution.

The accepted repository bytes remain the exact seven-path governance target.
No repository byte is authorized to change.

## 3. Exact roots

CANDIDATE_R:

  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

PREDECESSOR_REPAIR_EVIDENCE:

  /Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

BLOCKING_AUDIT:

  /Users/ds/Downloads/repair10i-a6-governance-independent-audit-5n5vkzxr

Allocate a fresh correction root using Python `tempfile.mkdtemp` under:

  /Users/ds/Downloads

with a prefix containing:

  ES-repair10i-a6-governance-mode-provenance-repair-

Use umask `077`.

Do not use a predetermined suffix. Do not reuse or rename an existing root.

## 4. Mandatory repository opening identity

Before creating the correction root, verify read-only:

- physical root:
  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
- device/inode:
  16777234 / 122118502
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed membership:
  389 objects; 375 tracked; 14 nonignored untracked
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0/0/0/0
- final source T:
  f276536fea579d0842cda43b0290656b200b7f27
- final inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738
- inventory size:
  54,314 bytes

Require the exact seven final changed paths and the exact final path hashes
reported by the blocking audit.

Every Git invocation must use:

  git -C "$CANDIDATE_R" ...

with cwd exactly CANDIDATE_R and:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

No Git command may target an evidence root or the primary checkout.

Stop with OPENING_PROVENANCE_MISMATCH on any discrepancy.

## 5. Mandatory predecessor-evidence gate

Verify PREDECESSOR_REPAIR_EVIDENCE read-only before writing anything.

Require:

- both canonical manifests exist and are byte-identical;
- each is 19,136 bytes;
- each has SHA-256:
  1c07db3979d02afcf7852c6c4819630046950712426a267a4117a6774c28b751
- exact membership:
  - 10 directories including the root;
  - 98 regular files;
  - 96 nonmanifest files covered;
  - exactly two self-excluded manifests;
- directories mode 0700;
- files regular, single-link, mode 0600;
- no symlink or special object;
- no empty or unexplained directory.

Verify the two predecessor repair-only deltas:

- byte-identical;
- size:
  2,474,094 bytes;
- SHA-256:
  641612e748d2764d7a78d066d73b788fbc30b527b3088723a73d4dd8ac771021

Identify through the authenticated predecessor manifest the exact paths for:

- Python delta builder;
- Go delta builder;
- delta A;
- delta B;
- delta identity record;
- opening inventory;
- final inventory or final closeout inventory;
- final implementation report;
- both canonical manifests.

Do not assume filenames beyond what the authenticated manifest establishes.

Verify the blocking defect before repair:

- the authenticated repair-opening inventory records logical mode `100644`
  for:
  - `.docs/system_overview/capability_probing.md`
  - `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md`
  - `docs_contract_test.go`
- both predecessor deltas encode `before 100600` and `after 100644` for those
  three paths;
- before/after sizes and SHA-256 values otherwise match the authenticated
  opening and final inventories.

Stop with OPENING_PROVENANCE_MISMATCH if the observed mechanism differs.

## 6. Blocking-audit custody

Inventory BLOCKING_AUDIT read-only at opening and retain that opening inventory
inside the new correction root.

Do not copy, modify, normalize, chmod, or clean the audit root.

Inspect and bind at least:

- its inline/report record containing PARENT-EVID-001;
- the independently reported corrected delta identity:
  `0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1`;
- its final repository and evidence comparisons.

The audit-computed corrected hash is a cross-check only. Do not hard-code or
force output bytes to match it.

## 7. Repair design

Create a new correction capsule. Do not mutate the predecessor capsule.

The correction capsule must have one authoritative machine-readable
supersession record that maps exact predecessor artifacts to exact successor
artifacts by:

- predecessor root;
- predecessor relative path;
- predecessor size;
- predecessor SHA-256;
- successor relative path;
- successor size;
- successor SHA-256;
- reason;
- disposition.

The supersession record must state:

- predecessor deltas and their delta-identity/report claims are nonqualifying
  for logical mode provenance;
- predecessor repository bytes, tests, validation, authority block, and other
  evidence are not rewritten or reclassified by this repair;
- the new capsule is the sole current writer for the corrected repair-delta
  identity;
- the old capsule remains immutable historical input.

## 8. Two independent corrected builders

Write two new builders under the correction root:

- Builder A in Python.
- Builder B in Go.

They must be independently implemented.

Neither builder may obtain repository logical mode from:

- the physical mode of copied evidence files;
- the correction-root custody mode;
- the predecessor-root custody mode;
- a hard-coded `100644` constant attached only to these three paths.

Both must derive before-mode from the authenticated repair-opening inventory.

Both must derive after-mode from the authenticated final inventory and
independently check that mode against the live repository’s logical mode.

The builders may read exact before/after bytes from authenticated retained
copies or the live final repository, but must bind every source path, size,
hash, and inventory identity used.

For all paths in the three-path repair delta, emit:

- repository-relative path;
- logical before-mode;
- logical after-mode;
- before size and SHA-256;
- after size and SHA-256;
- complete before bytes;
- complete after bytes;

using the predecessor delta’s existing canonical grammar and ordering, except
for the corrected before-mode values.

Do not invent a new delta format.

## 9. Required delta results

Builder A and Builder B must independently produce byte-identical corrected
deltas.

Require:

- size:
  2,474,094 bytes
- both generated outputs byte-identical;
- exactly the three incorrect before-mode values differ from the predecessor
  delta;
- each changes from `100600` to `100644`;
- no path, ordering, payload byte, size, hash, after-mode, delimiter, or
  terminal byte differs;
- the corrected delta parses under an audit-owned independent checker;
- applying or reconstructing the delta against the authenticated repair
  opening yields the exact final three repository files and modes.

Independently hash the corrected bytes.

Expected audit cross-check:

  0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1

If independently generated bytes do not have that hash:

- do not rewrite them to force a match;
- retain the independently generated result;
- stop with EVIDENCE_REPAIR_BLOCKED;
- report the exact discrepancy and all compared bytes/fields safely.

## 10. Independent correction validator

Create a third, read-only validator whose implementation shares no parsing or
mode-source helper with either builder.

It must independently verify:

1. predecessor delta identity;
2. corrected delta identity;
3. exact predecessor-versus-corrected byte differences;
4. authenticated opening logical modes;
5. authenticated final logical modes;
6. live final repository modes;
7. before/after sizes and hashes;
8. complete byte reconstruction;
9. no unauthorized path;
10. no evidence-custody mode used as repository logical mode.

It must fail on at least these audit-owned negative mutations:

- one corrected before-mode changed back to `100600`;
- one before-mode changed to `100755`;
- one after-mode changed;
- one before hash changed;
- one after hash changed;
- one path reordered;
- one path added;
- one path removed;
- one payload byte changed;
- one custody mode substituted for logical mode.

Retain exact mechanism-specific reasons.

## 11. Scope and non-goals

Authorized writes are confined to the fresh correction root.

Do not modify:

- CANDIDATE_R;
- PREDECESSOR_REPAIR_EVIDENCE;
- BLOCKING_AUDIT;
- any other repository or evidence root.

Do not:

- edit the governance contract;
- edit `docs_contract_test.go`;
- change the seven-path target;
- rerun or weaken documentary tests;
- repair A3-PROV-002;
- alter duplicate-key diagnostics;
- implement the semantic successor;
- implement allocator or orchestrator behavior;
- allocate an A6 child;
- invoke Evidence Verification or caller v4;
- stage, commit, push, create a PR, merge, install, deploy, or contact a
  network.

Repository tests are not required because repository bytes are unchanged.
The fresh independent audit will requalify the evidence chain.

## 12. Required correction-capsule contents

Retain at least:

- opening repository identity;
- opening predecessor-evidence inventory;
- opening blocking-audit inventory;
- exact predecessor-artifact identity record;
- exact opening/final inventory source record;
- Builder A source;
- Builder B source;
- corrected delta A;
- corrected delta B;
- independent correction validator source;
- validator positive result;
- validator negative-mutation matrix;
- predecessor-versus-corrected byte-difference record;
- delta identity record;
- supersession record;
- failed-and-superseded attempt index;
- closing repository identity;
- closing predecessor/audit-root comparisons;
- cleanup and absence record;
- complete final implementation report;
- two complete canonical manifests.

Do not create unused directories.

## 13. Evidence modes and manifests

All retained correction-root directories must be mode `0700`.

All retained files must be regular, single-link, mode `0600`.

The final report must be written before manifest creation and be covered by the
manifests.

Create two byte-identical canonical manifests. Each manifest must cover:

- every retained directory;
- every retained nonmanifest file;
- exact relative path;
- type;
- mode;
- link count where applicable;
- size;
- SHA-256.

The only self-exclusions may be the two manifests themselves.

No directory exclusion is permitted.
No empty or unexplained directory is permitted.
No symlink or special object is permitted.

Run an independent read-only complete-membership checker after manifest
creation.

## 14. Closing invariance

At closeout, independently require:

- candidate repository identity and all 389 objects unchanged;
- final source T unchanged:
  f276536fea579d0842cda43b0290656b200b7f27
- final inventory SHA-256 unchanged:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738
- exact seven final repository paths unchanged;
- exact three latest-repair paths unchanged;
- predecessor repair-evidence inventory unchanged;
- blocking-audit inventory unchanged;
- no new repository cache, bytecode, generated artifact, ignored path, staging,
  lock, or operation marker;
- correction-root private temporary area removed;
- two fresh ENOENT observations for any removed private generated-state root;
- no process or descriptor survivor owned by this task.

Do not mutate a supplied root to make a closing gate pass.

## 15. Required final report

Report:

1. Primary verdict.
2. Exact opening repository identity.
3. Exact predecessor evidence and blocking-audit identities.
4. Reproduced defect.
5. Why custody mode and repository logical mode differ.
6. Fresh correction-root identity.
7. Exact artifacts superseded.
8. Builder A and Builder B source identities.
9. Corrected delta size and SHA-256.
10. Whether the independent result matched the audit cross-check.
11. Exact predecessor-versus-corrected byte differences.
12. Independent validator design and positive result.
13. Negative-mutation matrix.
14. Supersession semantics.
15. Complete correction-root membership and manifest identities.
16. Failed and superseded attempts.
17. Closing equality.
18. Assumptions and remaining uncertainty.
19. Explicit confirmations:

    REPOSITORY_MUTATION_NOT_PERFORMED
    PREDECESSOR_EVIDENCE_MUTATION_NOT_PERFORMED
    BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
    GOVERNANCE_CONTRACT_NOT_MODIFIED
    DOCUMENTARY_TEST_NOT_MODIFIED
    PRODUCT_SOURCE_NOT_MODIFIED
    SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
    ORCHESTRATOR_NOT_IMPLEMENTED
    A6_NOT_STARTED
    EVIDENCE_VERIFICATION_NOT_INVOKED
    CALLER_NOT_INVOKED
    INDEPENDENT_AUDIT_NOT_PERFORMED
    STAGING_NOT_PERFORMED
    COMMIT_NOT_PERFORMED
    PUSH_NOT_PERFORMED
    NETWORK_CONTACT_NOT_PERFORMED
    SUBAGENTS_CREATED: 0
```

## What follows

A successful implementation report is **not** commit-ready. The next engagement should be a fresh read-only audit binding:

- the unchanged seven-path repository target;
- the immutable predecessor repair capsule;
- the new correction capsule;
- the blocking audit that identified the mode defect.

That audit can be substantially narrower than the previous one, but it must independently validate the corrected delta semantics and complete capsule membership before issuing `ACCEPT`.

### Sources

- Codex audit report supplied in this turn.
- Repair and re-audit are mandatory after a blocking finding; changed evidence requires new provenance and a fresh read-only audit. 
- File mode is part of provenance identity, while provenance does not by itself establish correctness or authority soundness. 

**Confidence:** 0.98 that the repository implementation should remain untouched; 0.97 that a source-external correction capsule is the correct next tranche; 0.95 that the audit’s proposed `0ea21358…3ec1` hash will independently reproduce, subject to inspecting the exact delta grammar.
