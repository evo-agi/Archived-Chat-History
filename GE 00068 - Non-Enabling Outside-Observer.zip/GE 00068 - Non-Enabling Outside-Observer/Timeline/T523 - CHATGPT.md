## Engineering assessment

The governing model is not the problem. The new clean implementation generation failed on an ordinary constructor-state bug:

```text
DependencyResolver.__init__ did not assign self.archive
```

The first packaged ACCEPT rehearsal reached the first semantic-role lookup, called `self.archive.read_exact(...)`, and failed before dependency access or capsule creation. The BLOCK and provenance rehearsals therefore never ran. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

Everything preceding concrete packaged execution was strong:

- all three governing packages and both content inputs authenticated;
- all 113 dependency roles were classified;
- the clean-room source boundary held;
- 36 sources compiled;
- static analysis reported zero errors;
- B00/D01–D14 passed at 595 cases;
- the 151-case interpreter matrix and 171-case descriptor matrix passed;
- the additional dependency, record-class, capsule, report, confirmation, lifecycle, custody, and causal suites passed;
- all synthetic lanes and the bounded 479-member compatibility replay passed. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

This means the defect is neither an operating-model ambiguity nor an implementation-package finding. It is a harness implementation bug that the qualification process failed to catch before consuming the last source attempt.

### The deeper process finding

The previous source-attempt policy is itself producing avoidable churn. Attempts were consumed by:

1. qualification files being generated outside `source/`;
2. a matrix driver expecting a nonexistent aggregate `pass` field;
3. a missing instance attribute assignment. :chatgpt-content-reference{index="4"}

These are prequalification implementation defects—not meaningful immutable candidate failures. Counting an attempt at compilation time forced retirement before a candidate ever completed one packaged rehearsal.

The next generation should therefore revise **generation-local qualification policy**, not product or package semantics:

- a **draft qualification phase** occurs before attempt consumption;
- source may be corrected during at most two fully recorded draft cycles;
- the draft must pass compilation, static checks, instance-state closure, direct component smoke, and a packaged dependency-resolution smoke;
- only after those gates pass are source registries frozen;
- a source attempt begins when the first full packaged ACCEPT/BLOCK/provenance rehearsal is launched;
- source modification after that launch consumes the next attempt.

This keeps the three-attempt ceiling meaningful: it applies to immutable packaged candidates, not syntax, layout, matrix-driver, or constructor wiring defects.

### Progression decision

Do **not** create another documentary package. The three governing packages already close the relevant architecture and semantics.

Start a new clean implementation generation with:

- a fresh three-attempt packaged-candidate budget;
- a bounded two-cycle draft phase;
- mandatory definite-instance-state analysis;
- direct constructor and method smoke tests for every stateful production component;
- a provisional packaged dependency-resolution smoke that resolves all 113 roles before any full rehearsal.

The retired source remains noncurrent and must not be copied or patched. Its failure records may be used only as regression evidence. No PYZ v3, authority v4, or launch certificate v2 currently exists. :chatgpt-content-reference{index="5"}

---

## Complete replacement Codex prompt

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
GENERATION-2 SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS

WITH PRE-ATTEMPT INSTANCE-STATE AND PACKAGED-DEPENDENCY QUALIFICATION

Objective

Implement a new clean-room source-external independent-audit harness governed
by the three sealed documentary packages and the current content snapshot.

The immediately preceding clean implementation generation is retired. It
exhausted three attempts, and no Attempt 4 is authorized.

Its final packaged rehearsal failed because:

DependencyResolver.__init__ did not assign self.archive

The first semantic-role lookup then attempted:

self.archive.read_exact(...)

before any dependency access or capsule creation.

This is historical regression evidence only.

Do not copy, patch, import, translate, reconstruct, decompile, disassemble into
source, or use any source from the retired implementation generation.

Do not create another documentary package in this task.

Do not change:

- the five documentary domains;
- the R01–R66 runtime report registry;
- the 81-name runtime confirmation registry;
- B00 or D01–D14;
- the exact 15 / 595 runtime-matrix authority;
- the three-role interpreter-observation tuple;
- the runtime environment policy;
- the 113-dependency authority model;
- the two-record-class taxonomy;
- package acceptance semantics;
- finding-ownership semantics;
- capsule terminal-lifecycle semantics.

Do not execute the real independent implementation audit in this task.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run a target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. GOVERNING INPUT A — FIVE-DOMAIN DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

FIVE_DOMAIN_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifests:

manifest/documentary-manifest-a-v2.json
manifest/documentary-manifest-b-v2.json

Expected manifest identities:

- inodes:
  181887816
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478 each
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Authenticate:

- root;
- temporal record;
- A/B equality;
- terminal reprojection;
- root row;
- topology and modes;
- one seal transition;
- no postseal operation.

Resolve governing roles only through:

contract/current-governing-documentary-role-registry-v2.json

Preserve unchanged:

- five documentary domains;
- 66 report rows;
- 81 confirmation names;
- B00 and D01–D14;
- 15 matrices;
- 595 cases;
- stale 645 rejection;
- aggregate ownership;
- package acceptance semantics.

Documentary tooling is not implementation source.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING INPUT B — INTERPRETER-TUPLE PACKAGE
──────────────────────────────────────────────────────────────────────────────

INTERPRETER_TUPLE_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-f5ys2h7f

Expected root identity:

- device:
  16777234
- inode:
  182148007
- mode:
  0700

Expected temporal record:

manifest/interpreter-observation-temporal-inventory-v1.json

- inode:
  182159647
- mode:
  0600
- link count:
  1
- size:
  11608
- SHA-256:
  181015fc4ef80841995af4005e068b0a348a3d0e8cbb2ef9fac6ef6424af0031

Expected manifests:

manifest/interpreter-observation-manifest-a-v1.json
manifest/interpreter-observation-manifest-b-v1.json

Expected identities:

- inodes:
  182159648
  182159649
- mode:
  0600
- link count:
  1
- size:
  11968 each
- SHA-256:
  cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66

Authenticate terminal closure and resolve roles only through:

contract/current-launch-runtime-successor-role-registry-v1.json

Preserve:

- three interpreter roles;
- exact observation tuple;
- three-view process authority;
- argv/cwd/PID/flag/source crosswalks;
- environment policy;
- parent self-authentication schema;
- absence of terminal-runtime-image authority;
- absence of a kernel-image claim.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING INPUT C — EMBEDDED-DEPENDENCY PACKAGE
──────────────────────────────────────────────── LIMITED TO EXACT AUTHORITY
────────────────────────────────────────────────

EMBEDDED_DEPENDENCY_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-embedded-dependency-descriptor-contract-aasznw_h

Expected root identity:

- device:
  16777234
- inode:
  182361207
- mode:
  0700

Expected temporal identity:

- size:
  8885
- SHA-256:
  7e3453d0f8f807bb42452234f5503b68b4eeccb21ba80c57355710b67dfa1b6c

Expected manifest A/B:

- size:
  9156 each
- SHA-256:
  1b0fc86532f0b430b77ae256bf617ae0a37963d633fe7467304877775b92c982

Authenticate:

- additive successor role registry;
- 113 dependency rows;
- 113 member-role rows;
- 113 typed descriptors;
- two-record-class taxonomy;
- 171-case descriptor matrix;
- independent validator;
- perspective reconciliation;
- package status;
- terminal closure.

Required semantics:

- SCHEMA_DISCRIMINATED_JSON:
  108 records;
- SCHEMA_VERSION_DISCRIMINATED_JSON:
  5 records;
- bootstrap-start uses schema_version;
- governed runtime matrix uses schema;
- semantic role owns authority;
- member path is an exact role projection;
- no direct acceptance-bearing path literal;
- no compatibility alias;
- no path/basename/suffix/prefix/version/score/recursive/content fallback;
- stale matrix-suite path noncurrent;
- qualification/runtime-matrix-v2.json current.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT INPUTS
──────────────────────────────────────────────── LIMITED TO SEALED EVIDENCE
────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before archive.

Require:

- 479 archive members;
- eight current roles;
- seven content-snapshot roles;
- one bounded failure-evidence role;
- no `.DS_Store`;
- deterministic equality;
- independent validation;
- no implementation/package verdict.

──────────────────────────────────────────────────────────────────────────────
5. RETIRED IMPLEMENTATION EVIDENCE
──────────────────────────────────────────────── LIMITED TO REGRESSION FACTS
────────────────────────────────────────────────

RETIRED_IMPLEMENTATION_ROOT:

/private/tmp/ES-repair10i-v3-clean-independent-audit-harness-v3-new-generation-r48lzspj

Expected root identity:

- device:
  16777234
- inode:
  182364341
- mode:
  0700

Expected verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTATION_BLOCKED

Open only this exact path if present.

Do not scan for it.

Authenticate:

closeout/failure-closeout-attempt-3-v1.json

Expected SHA-256:

244615e4064b80fb4dba59ba0abe3ecaa71fbac57b743c8d7ef69768cb7b0d92

Authenticate:

closeout/attempt-3-provisional-precleanup-evidence-v1.json

Expected SHA-256:

7c1c8c7899647e4ba7870a4973a50b16e16340cd862b66622f878277791362d0

Authenticate the exact historical facts:

- prior generation consumed three attempts;
- no Attempt 4;
- all 113 roles classified;
- all 36 sources compiled;
- prepackaged static and matrix suites passed;
- packaged ACCEPT rehearsal failed because:
  DependencyResolver.__init__ did not assign self.archive;
- first semantic-role lookup then attempted:
  self.archive.read_exact(...);
- no capsule was created;
- no final PYZ/authority/certificate exists;
- no implementation verdict was issued.

Classify the root as:

historical_noncurrent_dependency_resolver_initialization_failure

It is:

- immutable;
- noncurrent;
- nonresumable;
- not cleanable;
- not source authority.

Do not inspect or copy retired source files.

If the root is absent:

- do not search;
- retain these facts as user-supplied historical regression requirements.

──────────────────────────────────────────────────────────────────────────────
6. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────── LIMITED TO NEW GENERATION
────────────────────────────────────────────────

Allocate one fresh private build root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v3-new-generation-b-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v3-new-generation-b-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-clean-source-external-independent-audit-harness-v3.pyz

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/new-clean-generation-authority-v2.json
opening/fixed-input-registry-v1.json
opening/governing-package-resolution-v1.json
opening/clean-room-source-authority-v1.json
opening/process-execution-policy-v1.json
opening/source-development-and-attempt-policy-v1.json
opening/implementation-operating-freeze-v1.json

──────────────────────────────────────────────────────────────────────────────
7. REVISED SOURCE-DEVELOPMENT AND ATTEMPT POLICY
──────────────────────────────────────────────── LIMITED TO QUALIFICATION PROCESS
────────────────────────────────────────────────

This is a generation-local implementation-qualification policy.

It does not change package acceptance semantics.

Before source creation, check all three governing packages for any explicit
attempt-start rule.

If a governing contract explicitly requires an attempt to start at compilation:

- do not silently override it;
- retain the exact conflict;
- return IMPLEMENTATION_BLOCKED;
- state that another documentary decision is required.

Otherwise freeze this policy.

A. DRAFT QUALIFICATION PHASE

- maximum complete draft correction cycles:
  2;
- attempt count:
  not started;
- source may be corrected only within the fresh build root;
- every revision, source identity, reason, and rerun is retained;
- no source freeze;
- no current package authority;
- no full packaged ACCEPT/BLOCK/provenance rehearsal.

Each draft candidate must pass all pre-attempt gates in Sections 13–17.

If no draft passes within two cycles:

- return IMPLEMENTATION_BLOCKED;
- source attempts consumed:
  0;
- retain complete draft evidence.

B. FROZEN PACKAGED-CANDIDATE ATTEMPT

An attempt starts only when:

1. draft gates pass;
2. final source registries close;
3. candidate sources are frozen for that attempt;
4. a deterministic provisional PYZ and provisional authority are created;
5. the first full packaged ACCEPT/BLOCK/provenance rehearsal process is
   launched.

After an attempt begins:

- source modification is forbidden within that attempt;
- any source change requires the next attempt;
- maximum attempts:
  3;
- Attempt 4:
  forbidden.

Every attempt retains:

- source registries and identities;
- compilation/static results;
- draft-gate inheritance;
- provisional package identities;
- rehearsals reached;
- first blocker;
- failure closeout;
- supersession.

──────────────────────────────────────────────────────────────────────────────
8. DEPENDENCY DISPOSITION AND CURRENT AUTHORITY
────────────────────────────────────────────────

Before source creation classify all 113 roles exactly once:

- COPY_EXACT_GOVERNING_ARTIFACT;
- REGENERATE_CURRENT_GENERATION_EVIDENCE;
- HISTORICAL_REGRESSION_ONLY.

Retain:

analysis/current-generation-dependency-disposition-ledger-v2.json

Require:

- 113 rows;
- no unknown;
- no duplicate;
- no conflict;
- independent validation.

Then freeze:

contract/current-generation-embedded-dependency-registry-v2.json
contract/current-generation-member-role-registry-v2.json
contract/current-generation-record-class-registry-v2.json

For every role bind:

- semantic role;
- current member role;
- current path;
- disposition;
- record class;
- discriminator;
- parser;
- validation;
- producer;
- consumers;
- authority effect;
- predecessor lineage;
- identity timing.

No generation-specific predecessor identity becomes current silently.

Consumers request semantic roles only.

──────────────────────────────────────────────────────────────────────────────
9. CLEAN-ROOM SOURCE AUTHORITY
────────────────────────────────────────────────

Permitted source inputs:

- the three documentary packages;
- normative contract/current schemas/current validation specifications inside
  the content bundle;
- current-generation dependency registries;
- historical defect facts as tests;
- pre-source contracts from this task.

Forbidden source inputs:

- retired harness source;
- retired repair source;
- documentary tooling source;
- implementation-package source;
- transcript-reconstructed source;
- decompiled or disassembled source;
- similarity-derived source;
- source generated from predecessor source.

Implementation-package source may later be parsed read-only by the audit.

It may not be imported or executed.

Retain:

opening/clean-room-source-authority-v1.json

──────────────────────────────────────────────────────────────────────────────
10. CLEAN SOURCE ARCHITECTURE
────────────────────────────────────────────────

Define modular roles for:

- executable entrypoint;
- finite audit parent;
- process recorder;
- strict JSON;
- record-class dispatcher;
- schema parser;
- schema-version parser;
- semantic dependency resolver;
- archive adapter;
- member authority reader;
- content-bundle authority reader;
- governing-document reader;
- interpreter-tuple validator;
- environment validator;
- source/freeze validator;
- phase runner;
- implementation analyzer;
- runtime matrix adapter;
- report projector;
- confirmation projector;
- finding/dependency builder;
- security analyzer;
- cleanup owner;
- input-equality owner;
- capsule lifecycle;
- terminal frame;
- failure closeout;
- qualification fixtures;
- independent validators;
- deterministic package builder;
- runtime authority builder;
- launch-certificate builder.

Every role maps exactly once.

Independent validators import no candidate production or qualification helpers,
generators, fixtures, expected maps, observers, normalizers, or projectors.

──────────────────────────────────────────────────────────────────────────────
11. EMBEDDED DEPENDENCY IMPLEMENTATION
────────────────────────────────────────────────

Implement:

semantic role
→ descriptor
→ member role
→ exact path
→ identity
→ record-class parser
→ discriminator validation
→ typed result

Record classes:

- SCHEMA_DISCRIMINATED_JSON;
- SCHEMA_VERSION_DISCRIMINATED_JSON.

Do not implement:

- acceptance-bearing direct member paths at consumers;
- compatibility aliases;
- path lists;
- fallback;
- basename/suffix/prefix search;
- recursive search;
- first-existing member;
- version/score selection;
- same-byte search;
- generic discriminator fallback;
- blanket schema-field requirement.

Required historical regressions:

- stale matrix-suite path;
- governed matrix role;
- bootstrap schema_version;
- no compatibility alias;
- no fallback;
- complete 113-role closure;
- DependencyResolver archive state initialized before every public lookup.

──────────────────────────────────────────────────────────────────────────────
12. INSTANCE-STATE AUTHORITY MODEL
────────────────────────────────────────────────

Before compiling any draft candidate retain:

contract/stateful-component-instance-state-contract-v1.json
analysis/stateful-component-inventory-v1.json

For every production and qualification class retain:

- class ID;
- source path;
- constructor;
- slots/dataclass/class attributes;
- every `self.<attribute>` write;
- every `self.<attribute>` read;
- methods containing reads;
- constructor paths;
- required initialized attributes;
- optional attributes;
- lazy attributes;
- state transitions;
- immutable dependencies;
- public methods;
- consumers.

Acceptance rules:

1. Every instance attribute read on a successful reachable path must be:
   - definitely assigned on every successful constructor path; or
   - an explicitly frozen class-level immutable; or
   - an explicitly governed lazy attribute with a proven guard.

2. No `hasattr` or exception fallback may hide a missing required dependency.

3. Constructor arguments must be retained in the exact owned attributes when
   required by public methods.

4. Every public method’s required state must be present before invocation.

5. Attribute name similarity is not sufficient.

6. Dynamic `setattr` for acceptance-bearing state is forbidden unless the exact
   attribute set is frozen and independently validated.

For DependencyResolver require at minimum:

- `archive`;
- dependency registry;
- member-role registry;
- record-class registry;
- parser registry;
- validation registry;
- access ledger owner when required.

`self.archive` must be assigned by the constructor before any public lookup.

──────────────────────────────────────────────────────────────────────────────
13. PRE-ATTEMPT STATIC INSTANCE-STATE GATE
──────────────────────────────────────────────── LIMITED TO DRAFTS
────────────────────────────────────────────────

This gate occurs before attempt consumption.

Run source-external AST and control-flow analysis that independently derives:

- classes;
- constructor paths;
- `self` attribute writes;
- `self` attribute reads;
- class-level defaults;
- slots/dataclass fields;
- guarded lazy state;
- public-method state requirements;
- reachable packaged call paths.

Require:

- zero uninitialized required attribute reads;
- zero constructor-path gaps;
- zero dynamic unregistered state;
- zero public-method state gaps;
- exact agreement with the instance-state contract.

At minimum include negative cases for:

- missing `self.archive`;
- assignment on only one branch;
- assignment after first use;
- typo in attribute name;
- class attribute improperly substituted;
- `hasattr` fallback;
- caught `AttributeError`;
- dynamic setattr;
- lazy state without guard;
- method called before initialization;
- constructor returns early;
- optional attribute incorrectly required;
- inherited attribute ambiguity.

Retain:

validation/pre-attempt-instance-state-analysis-v1.json

──────────────────────────────────────────────────────────────────────────────
14. PRE-ATTEMPT DIRECT COMPONENT SMOKE
──────────────────────────────────────────────── LIMITED TO DRAFTS
────────────────────────────────────────────────

Instantiate every stateful production component using source-external typed
fixtures.

Do not execute implementation-package source.

For each component:

- construct under isolated environment;
- inspect exact instance state;
- invoke every public method through its minimal safe path;
- retain returned values or exact expected bounded failures;
- retain filesystem/process effects;
- require cleanup.

For DependencyResolver:

1. create an audit-owned synthetic in-memory or disposable exact archive
   adapter;
2. provide all 113 descriptors and registries;
3. instantiate the resolver;
4. independently assert required instance state;
5. resolve every one of the 113 semantic roles;
6. parse both record classes;
7. validate discriminators;
8. retain a complete access ledger;
9. require access set equality with the 113-role registry;
10. require no stale path, alias, fallback, or missing attribute.

Retain:

validation/pre-attempt-component-smoke-v1.json
validation/pre-attempt-dependency-resolver-smoke-v1.json

──────────────────────────────────────────────────────────────────────────────
15. PRE-ATTEMPT PROVISIONAL PACKAGED SMOKE
──────────────────────────────────────────────── LIMITED TO DRAFTS
────────────────────────────────────────────────

Build one disposable provisional PYZ from the draft candidate.

This is not a full packaged-candidate attempt.

It must not issue package authority or a package verdict.

Execute one qualification-only packaged smoke mode or an exact
qualification-owned internal entrypoint that:

- imports from the provisional PYZ;
- constructs the real DependencyResolver;
- authenticates the provisional member registry;
- resolves all 113 semantic roles;
- opens every required member once;
- dispatches both record classes;
- validates discriminators;
- records every member access;
- exits before implementation-package audit or capsule creation.

Require:

- exact packaged imports;
- no source-tree fallback;
- no current working-directory source import;
- no `embedded-record-unavailable`;
- no `AttributeError`;
- no direct stale path;
- access-set equality;
- no network/Git/product effects.

Retain full platform custody and raw streams.

Remove the provisional PYZ and fixture root after evidence retention and double
ENOENT.

Retain:

validation/pre-attempt-packaged-dependency-smoke-v1.json

No source attempt may begin until this gate passes.

──────────────────────────────────────────────────────────────────────────────
16. OTHER PRE-ATTEMPT DRAFT GATES
────────────────────────────────────────────────

Before attempt consumption require:

- source layout and registry closure;
- compilation under pinned Python `-I -S -B`;
- AST/call graph/dataflow/bytecode/exception/CFG analysis;
- interface closure;
- source/dependency/member/test set equality;
- record-class dispatch analysis;
- process/filesystem operation crosswalk;
- report/confirmation/matrix ownership;
- terminal-operation analysis;
- no historical source origin;
- no network/Git/shell/PATH lookup;
- no broad scan;
- no fallback lookup;
- failure and success closeout reachable.

Compilation during the draft phase does not consume a packaged-candidate
attempt under the generation-local policy frozen in Section 7.

Every draft compilation and revision remains fully retained and nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
17. FROZEN PACKAGED-CANDIDATE ATTEMPTS
────────────────────────────────────────────────

After all draft gates pass:

1. close final source registries;
2. freeze the candidate source for Attempt 1;
3. build deterministic provisional PYZ and authority;
4. launch the first full packaged rehearsal;
5. mark Attempt 1 consumed.

Within an attempt:

- source is immutable;
- no correction is permitted;
- failure requires a new attempt;
- next attempt must retain exact bounded source delta and regression closure.

Maximum:

3 attempts.

No Attempt 4.

──────────────────────────────────────────────────────────────────────────────
18. GOVERNED QUALIFICATION SUITES
────────────────────────────────────────────────

Require unchanged success for:

- B00 and D01–D14:
  15 matrices / 595 cases;
- 151 interpreter-tuple cases;
- 171 descriptor cases;
- dependency-disposition suite;
- semantic-role resolution suite;
- record-class dispatch suite;
- capsule evidence suite;
- mode-aware confirmation suite;
- mode-aware report suite;
- terminal-lifecycle suite;
- process-custody suite;
- behavioral-causal suite.

Add separate instance-state suites:

A. definite-initialization matrix:
at least 60 cases;

B. constructor/public-method matrix:
at least 50 cases;

C. packaged dependency-resolver matrix:
at least 40 cases.

Require in every suite:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

New suites do not alter the governed 15 / 595 authority.

──────────────────────────────────────────────────────────────────────────────
19. SYNTHETIC AND BOUNDED COMPATIBILITY LANES
────────────────────────────────────────────────

Run:

- synthetic ACCEPT;
- synthetic BLOCK;
- synthetic AUDIT_PROVENANCE_MISMATCH;
- semantically equal constructed-subject pair;
- stale-path regression;
- missing-role regression;
- wrong-record-class regression;
- bootstrap-schema-version regression;
- missing-instance-state regression;
- unknown environment injection;
- incomplete custody;
- terminal mutations.

Run bounded current-bundle compatibility replay:

- authenticate 479 members and eight roles;
- resolve 113 semantic dependencies;
- parse under exact record classes;
- resolve governed runtime matrix evidence;
- execute no implementation source;
- issue no verdict.

──────────────────────────────────────────────────────────────────────────────
20. FULL PACKAGED-PATH REHEARSALS
────────────────────────────────────────────────

For each frozen candidate attempt run physically distinct rehearsals using the
exact packaged PYZ and provisional runtime authority.

A. ACCEPT

B. BLOCK

C. AUDIT_PROVENANCE_MISMATCH

Each rehearsal must:

- use exact future CLI;
- pass platform capture;
- pass parent self-authentication;
- construct real stateful components;
- resolve all 113 dependencies;
- retain access-ledger equality;
- generate R01–R66 and 81 confirmations;
- generate P00–P24 phase records;
- retain child custody;
- retain cleanup and fixed-input equality;
- terminally close;
- pass independent capsule validation.

Require no:

- missing instance state;
- `embedded-record-unavailable`;
- stale path;
- compatibility alias;
- fallback;
- schema/schema-version conflation;
- premature terminal frame;
- postseal operation.

Retain all evidence before cleanup.

Remove disposable roots with double ENOENT.

──────────────────────────────────────────────────────────────────────────────
21. INDEPENDENT VALIDATION
────────────────────────────────────────────────

Independent validators verify:

- clean-room provenance;
- all three governing packages;
- dependency dispositions;
- current dependency/member-role/record-class registries;
- instance-state closure;
- component smoke;
- packaged dependency smoke;
- source/dependency/member/test equality;
- matrices;
- process custody;
- synthetic lanes;
- bounded replay;
- all packaged rehearsals;
- capsule terminal closure;
- evidence retention and cleanup.

They may not import production or qualification helpers, fixtures, expected
maps, observers, normalizers, or projectors.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
22. SOURCE FREEZE
────────────────────────────────────────────────

Freeze only after one packaged candidate passes every rehearsal and independent
gate.

Retain:

opening/clean-independent-audit-harness-v3-source-freeze-v2.json

Bind:

- governing packages;
- content inputs;
- source registries and identities;
- dependency registries;
- record-class registry;
- instance-state contract and results;
- all matrices;
- synthetic lanes;
- compatibility replay;
- rehearsal identities;
- independent validation;
- cleanup;
- future invocation;
- real audit not executed;
- later modification forbidden.

Reopen all sources no-follow.

Do not modify afterward.

──────────────────────────────────────────────────────────────────────────────
23. DETERMINISTIC FINAL PYZ V3
────────────────────────────────────────────────

Build independently twice:

gen2-clean-source-external-independent-audit-harness-v3.pyz

Require byte equality.

Require:

- ZIP_STORED;
- raw UTF-8 order;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special members;
- no comments/extras;
- no cache/bytecode;
- exact current dependency and member-role registries;
- exact record-class registry;
- every current governed embedded record once;
- no stale aliases.

Retain member registry and count.

──────────────────────────────────────────────────────────────────────────────
24. RUNTIME AUTHORITY V4
────────────────────────────────────────────────

Build deterministically twice:

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

Bind:

- exact PYZ v3;
- member registry;
- source freeze;
- source registries;
- all governing packages;
- dependency/member-role/record-class registries;
- qualification results;
- packaged rehearsals;
- future invocation;
- current content inputs;
- real audit:
  false;
- implementation verdict:
  not issued;
- current subject:
  false.

Authority v4 is passed through `--harness-authority`.

Require byte equality.

──────────────────────────────────────────────────────────────────────────────
25. POST-PACKAGE QUALIFICATION
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode once with exact authority v4.

Require fresh verification of:

- PYZ/member closure;
- source freeze;
- governing packages;
- dependency and record-class closure;
- instance-state closure;
- packaged dependency smoke;
- all matrices;
- custody;
- synthetic lanes;
- bounded replay;
- packaged ACCEPT/BLOCK/provenance rehearsals;
- independent validators;
- deterministic package closure;
- no real audit;
- no implementation verdict.

Retain complete platform custody and raw streams.

──────────────────────────────────────────────────────────────────────────────
26. EXTERNAL LAUNCH CERTIFICATE V2
────────────────────────────────────────────────

Build independently twice:

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

Bind:

- PYZ v3;
- authority v4;
- content inputs;
- deterministic PYZ replay;
- fresh qualification custody/result;
- governing package identities;
- dependency and record-class closure;
- instance-state and packaged-smoke evidence;
- matrices;
- packaged rehearsals;
- exact stream contracts;
- exact future run-full-audit invocation;
- wrapper launch authorized:
  true;
- future audit count:
  1;
- real audit:
  false;
- implementation verdict:
  not issued.

The certificate is wrapper authority and is not passed to the harness.

Require byte equality.

Run an independent certificate-input validator.

The future wrapper validates final certificate bytes.

──────────────────────────────────────────────────────────────────────────────
27. FROZEN-PYZ V3 REQUALIFICATION
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode with final authority v4.

Require:

- exit zero;
- empty stderr;
- exact result;
- package/source self-authentication;
- dependency closure;
- exact record-class dispatch;
- instance-state closure;
- exact matrix-evidence resolution;
- all old and new matrices;
- packaged rehearsal linkage;
- authority-v4 coherence;
- no run-full-audit execution;
- no implementation verdict.

Independently recompute all aggregates.

Retain:

validation/frozen-pyz-v3-requalification-v2.json

──────────────────────────────────────────────────────────────────────────────
28. INPUT CLOSING EQUALITY AND CLEANUP
────────────────────────────────────────────────

Repeat exact no-follow checks/inventories for:

- all three governing packages;
- content bundle;
- content authority;
- retired failure root if opened.

Require opening/closing equality.

Do not mutate supplied inputs.

Before removing any disposable root retain:

- identity;
- complete inventory;
- streams;
- results;
- failure evidence.

Revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

──────────────────────────────────────────────────────────────────────────────
29. FAILURE CLOSEOUT
────────────────────────────────────────────────

On failure retain:

- draft-cycle posture;
- packaged-attempt posture;
- first blocker;
- structured exception;
- process ledgers/streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- input equality;
- freeze/package/authority/certificate posture;
- same-root retry false.

If three frozen packaged attempts fail:

- generation retired:
  true;
- further localized repair:
  false.

Remove provisional outputs only after evidence retention and double ENOENT.

──────────────────────────────────────────────────────────────────────────────
30. VERDICT RULES
────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- all inputs authenticate;
- generation-local attempt policy does not conflict with governing contracts;
- dependency dispositions close;
- clean-room provenance passes;
- a draft passes all pre-attempt gates within two correction cycles;
- one frozen packaged candidate passes within three attempts;
- exact 15/595 suite passes;
- 151 interpreter cases pass;
- 171 descriptor cases pass;
- instance-state and constructor matrices pass;
- packaged dependency smoke passes;
- all dependency/record-class/capsule/projection/custody matrices pass;
- synthetic lanes pass;
- bounded replay passes;
- packaged ACCEPT/BLOCK/provenance rehearsals pass;
- independent validators pass;
- source freezes;
- PYZ v3 builds match;
- authority-v4 builds match;
- post-package qualification passes;
- certificate-v2 builds match;
- certificate-input validation passes;
- frozen-PYZ v3 requalification passes;
- input equality and cleanup pass;
- final files are mode 0400;
- no real audit or implementation verdict occurs.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTATION_BLOCKED

for substantive non-provenance failure.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_PROVENANCE_MISMATCH

for fixed-input, source-authority, retired-source use, evidence-loss, custody,
cleanup, source-drift, or output-identity failures.

──────────────────────────────────────────────────────────────────────────────
31. REQUIRED INLINE OPERATIVE REPORT
────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Governing-package identities
5. Content identities
6. Fixed-input authentication
7. Retired-generation disposition
8. Generation-local attempt-policy adjudication
9. Draft-cycle ledger
10. Dependency-disposition ledger
11. Clean-room source authority
12. Source architecture
13. Stateful-component inventory
14. Instance-state contract
15. Pre-attempt instance-state result
16. Component-smoke result
17. DependencyResolver smoke result
18. Provisional packaged dependency smoke
19. Packaged-candidate attempt ledger
20. Production-source registry
21. Qualification-source registry
22. Independent-source registry
23. Current dependency registry
24. Current member-role registry
25. Current record-class registry
26. Cross-module interfaces
27. Compilation/static gates
28. B00/D01–D14
29. 151 interpreter cases
30. 171 descriptor cases
31. Instance-state matrices
32. Dependency/record-class matrices
33. Capsule/report/confirmation/lifecycle/custody matrices
34. Synthetic lanes
35. Bounded compatibility replay
36. Packaged ACCEPT rehearsal
37. Packaged BLOCK rehearsal
38. Packaged provenance rehearsal
39. Dependency-access closure
40. Independent validators
41. Evidence retention
42. Cleanup
43. Source freeze
44. PYZ v3 Build A
45. PYZ v3 Build B
46. PYZ equality/member closure
47. Authority-v4 Build A/B
48. Post-package qualification
49. Certificate-v2 Build A/B
50. Certificate-input validation
51. Frozen-PYZ v3 requalification
52. Confirmation no real audit
53. Confirmation no implementation verdict
54. Input closing equality
55. Failure-closeout capability/use
56. Final PYZ v3 path/identity
57. Final authority-v4 path/identity
58. Final certificate-v2 path/identity
59. Remaining uncertainty/nonclaims
60. Explicit confirmations

Required confirmations include:

FIVE_DOMAIN_DOCUMENTARY_PACKAGE_AUTHENTICATED
INTERPRETER_TUPLE_DOCUMENTARY_PACKAGE_AUTHENTICATED
EMBEDDED_DEPENDENCY_DOCUMENTARY_PACKAGE_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_AUTHENTICATED
CURRENT_CONTENT_AUTHORITY_AUTHENTICATED
NEW_CLEAN_IMPLEMENTATION_GENERATION_ESTABLISHED
NO_RETIRED_SOURCE_USED
GENERATION_LOCAL_ATTEMPT_POLICY_FROZEN
DRAFT_CORRECTION_LIMIT_RESPECTED
PACKAGED_ATTEMPT_LIMIT_RESPECTED
DEPENDENCY_DISPOSITION_LEDGER_COMPLETE
ALL_113_DEPENDENCY_ROLES_CLASSIFIED
CURRENT_DEPENDENCY_REGISTRY_COMPLETE
CURRENT_MEMBER_ROLE_REGISTRY_COMPLETE
CURRENT_RECORD_CLASS_REGISTRY_COMPLETE
STATEFUL_COMPONENT_INVENTORY_COMPLETE
INSTANCE_STATE_CONTRACT_COMPLETE
NO_UNINITIALIZED_REQUIRED_INSTANCE_ATTRIBUTE_READ
DEPENDENCY_RESOLVER_ARCHIVE_INITIALIZED
DEPENDENCY_RESOLVER_ALL_REQUIRED_STATE_INITIALIZED
ALL_STATEFUL_COMPONENT_SMOKES_PASSED
PRE_ATTEMPT_PACKAGED_DEPENDENCY_SMOKE_PASSED
PACKAGED_DEPENDENCY_ACCESS_EQUAL_113_ROLE_REGISTRY
SEMANTIC_ROLE_LOOKUP_IMPLEMENTED
NO_ACCEPTANCE_BEARING_DIRECT_MEMBER_PATH_LITERAL
SCHEMA_DISCRIMINATED_JSON_IMPLEMENTED
SCHEMA_VERSION_DISCRIMINATED_JSON_IMPLEMENTED
BOOTSTRAP_START_VALIDATED_BY_SCHEMA_VERSION
GOVERNED_MATRIX_EVIDENCE_RESOLVED_BY_ROLE
NO_COMPATIBILITY_ALIAS
NO_PATH_FALLBACK
FIVE_DOCUMENTARY_DOMAINS_IMPLEMENTED
RUNTIME_REPORT_REGISTRY_66_IMPLEMENTED
RUNTIME_CONFIRMATION_REGISTRY_81_IMPLEMENTED
RUNTIME_MATRIX_REGISTRY_15_595_IMPLEMENTED
INTERPRETER_TUPLE_IMPLEMENTED
RUNTIME_ENVIRONMENT_POLICY_IMPLEMENTED
PARENT_SELF_AUTHENTICATION_IMPLEMENTED
PHASE_TERMINALITY_IMPLEMENTED
PHASE_SPECIFIC_EVIDENCE_IMPLEMENTED
PROCESS_CUSTODY_IMPLEMENTED
CANONICAL_CLEANUP_IMPLEMENTED
FIXED_INPUT_CLOSING_EQUALITY_IMPLEMENTED
CAPSULE_TERMINAL_LIFECYCLE_IMPLEMENTED
ALL_SOURCES_COMPILED
STATIC_GATES_PASSED
PRIOR_GOVERNED_MATRICES_PASSED
INTERPRETER_TUPLE_MATRIX_PASSED
DEPENDENCY_DESCRIPTOR_MATRIX_PASSED
INSTANCE_STATE_MATRICES_PASSED
NEW_DEPENDENCY_AND_RECORD_CLASS_MATRICES_PASSED
CAPSULE_PROJECTION_CUSTODY_MATRICES_PASSED
SYNTHETIC_LANES_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
PACKAGED_ACCEPT_REHEARSAL_PASSED
PACKAGED_BLOCK_REHEARSAL_PASSED
PACKAGED_PROVENANCE_REHEARSAL_PASSED
REHEARSAL_DEPENDENCY_ACCESS_EQUAL_REGISTRY
NO_EMBEDDED_RECORD_UNAVAILABLE
NO_INSTANCE_STATE_FAILURE
INDEPENDENT_VALIDATORS_PASSED
SOURCE_FROZEN
SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_V3_BUILD_A_B_BYTES_IDENTICAL
PYZ_V3_MEMBER_CLOSURE_PASSED
AUTHORITY_V4_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
LAUNCH_CERTIFICATE_V2_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_PYZ_V3_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_PYZ_V3_CREATED
FINAL_PYZ_V3_MODE_0400
FINAL_PYZ_V3_IDENTITY_VERIFIED
FINAL_AUTHORITY_V4_CREATED
FINAL_AUTHORITY_V4_MODE_0400
FINAL_AUTHORITY_V4_IDENTITY_VERIFIED
FINAL_LAUNCH_CERTIFICATE_V2_CREATED
FINAL_LAUNCH_CERTIFICATE_V2_MODE_0400
FINAL_LAUNCH_CERTIFICATE_V2_IDENTITY_VERIFIED
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next task is exactly one fresh audit using:

1. final PYZ v3;
2. final authority v4;
3. final launch certificate v2;
4. current content bundle;
5. current content authority.

Do not combine implementation and audit.

Do not construct the current schema subject until the later audit accepts the
Generation-2 implementation package.
```

### Sources

The report shows that all governing inputs, dependency registries, source architecture, compilation/static gates, twelve qualification suites, synthetic lanes, and bounded compatibility replay passed. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

The first packaged rehearsal failed only because the resolver lacked its required `archive` instance state; no dependency access or capsule construction occurred. :chatgpt-content-reference{index="8"}

The previous generation exhausted all three attempts and produced no final package, authority, or certificate. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

**Confidence:** 0.999 that no implementation-package defect was established; 0.999 that the previous generation is retired; 0.995 that no new documentary decision is needed; 0.97 that moving constructor/state closure and packaged dependency smoke ahead of attempt consumption is the correct process correction.

The current attachment was fully readable. Some older uploaded files have expired; re-upload them if a later review requires their original bytes rather than the retained identities and reports.
