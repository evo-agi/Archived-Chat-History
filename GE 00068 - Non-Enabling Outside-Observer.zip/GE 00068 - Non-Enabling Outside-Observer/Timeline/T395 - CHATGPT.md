## Assessment

Codex stopped correctly. This is a **fixed-input path error in my preceding prompt**, not a contract-package, normative-contract, schema, or supplied-root defect.

I incorrectly specified:

```text
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-independent-audit-sbv__euv
```

The authenticated path bound by both the predecessor package and the closing-equality reconciliation is:

```text
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv
```

The only change is removal of `-v1-` after `bootstrap`.

The correct root is further bound by:

- Role: `accepted_bootstrap_audit`
- Device/inode/mode: `16777234 / 180047263 / 0700`
- Entries: `197`
- Inventory digest: `ed2fa43c432f9350b2429fa744778b7004cad5e1162c986b87849af4bdc65825`

No additional reconciliation is needed. The reseal task should restart in a wholly fresh root with this one corrected fixed path. The stopped root `...-ibf2v5bk` must remain immutable and nonauthoritative.

Forward this prompt:

```text
FRESH RETRY OF THE CONSTRUCTION-PARENT CONTRACT-PACKAGE RESEAL —
ONE EXPLICITLY CORRECTED CANONICAL SUPPLIED-ROOT PATH

The immediately preceding contract-package reseal task stopped correctly with:

CONTRACT_PROVENANCE_MISMATCH

The stop was caused by one incorrect absolute path supplied in the task’s
canonical supplied-root registry.

This prompt explicitly corrects that one fixed path and authorizes a wholly
fresh retry of the immediately preceding:

“FRESH RE-SEAL OF THE VALIDATION-CUSTODY V3
PACKAGE-CONSTRUCTION-PARENT CONTRACT PACKAGE —
CANONICAL SUPPLIED-ROOT EQUALITY AND EVIDENCE-DERIVED CONFIRMATIONS”

task.

All other objectives, authority boundaries, fixed identities, artifact
dispositions, byte-preservation requirements, builder-repair constraints,
validation requirements, equality rules, confirmation rules, package-closure
requirements, verdict rules, report requirements, and stop conditions from
that task remain unchanged and fully in force.

Do not weaken, omit, reinterpret, or replace them.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEAL_BLOCKED
CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT PATH CORRECTION
──────────────────────────────────────────────────────────────────────────────

Canonical role:

accepted_bootstrap_audit

INVALID PATH FROM THE PRIOR PROMPT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-independent-audit-sbv__euv

Classification:

- path exists:
  false, as reported by the stopped retry;
- current authority:
  none;
- permitted future use:
  historical task-error record only.

CORRECT AUTHORITATIVE PATH:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv

Expected identity:

- device:
  16777234
- inode:
  180047263
- mode:
  0700
- entry count:
  197
- complete inventory digest:
  ed2fa43c432f9350b2429fa744778b7004cad5e1162c986b87849af4bdc65825

This correction replaces only the canonical absolute path for the
`accepted_bootstrap_audit` role.

It does not change:

- the role ID;
- physical identity;
- expected entry count;
- expected inventory digest;
- normative contract bytes;
- schema bytes;
- contract semantics;
- equality semantics;
- package outputs;
- construction-parent operating model.

──────────────────────────────────────────────────────────────────────────────
2. CORRECTION AUTHORITY AND AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

The current task instruction explicitly authorizes the corrected path.

Before using it, independently authenticate that the corrected path is also
bound by both:

A. The sealed predecessor contract package:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-lmj3zfrw

B. The closing-equality reconciliation:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-closing-reconciliation-wt5eh322

Locate the exact `accepted_bootstrap_audit` rows through their authenticated
records and manifest membership.

Require exact agreement among:

1. this task’s corrected path and expected identity;
2. predecessor-package retained binding;
3. reconciliation retained binding;
4. live no-follow observation of the corrected path.

Require equality of:

- role ID;
- absolute path;
- device;
- inode;
- mode;
- entry count;
- inventory digest.

If any check fails, return:

CONTRACT_PROVENANCE_MISMATCH

Do not continue.

Do not derive authority merely from filesystem discovery. Authority comes from
this explicit correction plus the authenticated predecessor and reconciliation
bindings.

──────────────────────────────────────────────────────────────────────────────
3. RETAIN CORRECTION PROVENANCE
──────────────────────────────────────────────────────────────────────────────

In the fresh retry root, before copying any normative artifact, retain:

opening/supplied-root-path-correction-v1.json

Required fields:

- role_id:
  accepted_bootstrap_audit;
- invalid_historical_path;
- invalid_historical_path_exists:
  false;
- invalid_historical_path_current_authority:
  false;
- corrected_absolute_path;
- expected device;
- expected inode;
- expected mode;
- expected entry count;
- expected inventory digest;
- predecessor binding record path and pointer;
- predecessor bound value;
- reconciliation binding record path and pointer;
- reconciliation bound value;
- independent live observation;
- all bindings equal:
  true;
- correction scope:
  one-fixed-supplied-root-path-only;
- normative contract effect:
  none;
- schema effect:
  none;
- equality-rule effect:
  none;
- confirmation-rule effect:
  none.

This is audit-owned correction provenance, not a normative contract amendment.

──────────────────────────────────────────────────────────────────────────────
4. IMMUTABLE STOPPED RETRY ROOT
──────────────────────────────────────────────────────────────────────────────

The stopped retry root is:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-ibf2v5bk

Expected identity:

- device:
  16777234
- inode:
  180454877
- mode:
  0700
- retained content:
  opening/bootstrap-start.json only
- bootstrap SHA-256:
  05bf489df20afc2610062c2cd33e4b06c06c63d3759aecfa0411e347c094d472

Treat it as immutable, nonauthoritative failed-retry evidence.

Do not:

- resume it;
- modify it;
- clean it;
- adopt it;
- copy package authority from it;
- use it as the new package root.

It may be opened read-only only to bind its identity and failure reason in
lineage.

If opened, require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. COMPLETE CANONICAL-PATH PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before copying any contract or schema, validate every absolute path in the
canonical four-role supplied-root registry.

The exact corrected registry is:

1. role_id:
   source_sufficiency

   path:
   /Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-qualified-c57x2xh0

   expected:
   - device/inode:
     16777234 / 180357741
   - mode:
     0700
   - entries:
     16

2. role_id:
   sealed_predecessor

   path:
   /Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn

   expected:
   - device/inode:
     16777234 / 180248929
   - mode:
     0700
   - entries:
     74

3. role_id:
   accepted_bootstrap

   path:
   /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

   expected:
   - device/inode:
     16777234 / 179405897
   - mode:
     0700
   - entries:
     1209

4. role_id:
   accepted_bootstrap_audit

   path:
   /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv

   expected:
   - device/inode:
     16777234 / 180047263
   - mode:
     0700
   - entries:
     197
   - inventory digest:
     ed2fa43c432f9350b2429fa744778b7004cad5e1162c986b87849af4bdc65825

For each role require:

- path exists;
- absolute path exactly equals the registry value;
- direct identity matches;
- complete no-follow inventory matches the authenticated expected identity;
- no duplicate role;
- no duplicate path;
- no role/path ambiguity;
- pairwise physical distinction.

Retain:

opening/canonical-supplied-root-path-preflight-v1.json

If any fixed path is missing or mismatched:

- retain the complete result for all four rows;
- return `CONTRACT_PROVENANCE_MISMATCH`;
- do not begin copying.

Do not stop after checking only the first path.

──────────────────────────────────────────────────────────────────────────────
6. FRESH ROOT AND COMPLETE RESEAL RESTART
──────────────────────────────────────────────────────────────────────────────

Allocate a wholly fresh root using the same allocation contract and prefix from
the preceding reseal task:

ES-repair10i-v3-package-construction-parent-contract-resealed-

Do not reuse the stopped root.

Restart the preceding reseal task from the beginning.

Perform every required step, including:

- predecessor package authentication and independent reprojection;
- reconciliation authentication;
- complete artifact-disposition ledger;
- byte-identical normative contract copy;
- byte-identical copy of all 15 schemas;
- byte-identical copy of every root-independent artifact;
- bounded builder V2 repair;
- canonical role/path opening and closing rows;
- display-label exclusion from acceptance equality;
- fresh 25-case equality matrix;
- independent equality validator;
- regeneration of every root-bound artifact;
- fresh contract/schema field-map reconstruction;
- fresh 57-case contract mutation matrix;
- fresh independent contract validator;
- perspective binding and fresh parent reconciliation;
- historical lineage;
- evidence-derived confirmation map;
- confirmation generation from actual source record values;
- canonical supplied-root closing equality V2;
- preterminal report and confirmations;
- temporal final inventory;
- terminal manifests A and B;
- independent terminal reprojection;
- terminal mode/type/link/cache checks;
- no write after terminal closure.

Do not adopt any partially produced record from the stopped retry.

──────────────────────────────────────────────────────────────────────────────
7. FIXED-PATH AND FIXED-IDENTITY FORMAT PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before copying, validate all explicitly supplied absolute paths and SHA-256
literals used by the fresh task.

For each absolute path require:

- nonempty;
- absolute;
- exact supplied spelling;
- no unresolved placeholder;
- existence when required;
- identity matches its governing record.

For each SHA-256 require:

- exactly 64 characters;
- lowercase hexadecimal.

Retain:

opening/fixed-path-and-identity-format-preflight-v1.json

If any other malformed path or digest exists:

- retain every malformed row, not only the first;
- return `CONTRACT_PROVENANCE_MISMATCH`;
- do not begin copying.

The corrected `accepted_bootstrap_audit` path must pass.

──────────────────────────────────────────────────────────────────────────────
8. UNCHANGED EQUALITY AND CONFIRMATION RULES
──────────────────────────────────────────────────────────────────────────────

The canonical pairing key remains exactly:

(role_id, absolute_path)

Display labels remain nonauthoritative diagnostics.

Opening/closing equality must require:

- exact role/path set equality;
- exact physical-root equality;
- exact inventory/content equality;
- no duplicate or ambiguous role/path mapping.

The confirmation:

SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED

must be derived only from:

closing/supplied-root-closing-equality-v2.json#/pass

with:

- exact Boolean type;
- required value:
  true.

Do not hard-code confirmation success.
Do not use display-label equality.
Do not use absence-as-success.

──────────────────────────────────────────────────────────────────────────────
9. UNCHANGED VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return exactly one verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEAL_BLOCKED
CONTRACT_PROVENANCE_MISMATCH

The readiness verdict still requires every artifact-copy, builder-delta,
equality, confirmation, contract validation, schema validation, mutation,
independent-validator, closing-equality, temporal-inventory, manifest,
reprojection, posture, and no-write-after-closure gate from the preceding
reseal prompt.

The path correction alone does not establish readiness.

──────────────────────────────────────────────────────────────────────────────
10. INLINE REPORT ADDITIONS
──────────────────────────────────────────────────────────────────────────────

Return the full inline report required by the preceding reseal task.

Add near the opening section:

- incorrect path;
- corrected path;
- exact role ID;
- expected identity;
- predecessor binding;
- reconciliation binding;
- independent live observation;
- path-correction record identity;
- complete four-role path-preflight result;
- confirmation that only one fixed supplied-root path changed;
- confirmation that no normative contract or schema byte changed because of
  this correction.

Additional required confirmations:

INCORRECT_ACCEPTED_BOOTSTRAP_AUDIT_PATH_REJECTED
CORRECTED_ACCEPTED_BOOTSTRAP_AUDIT_PATH_AUTHENTICATED
CORRECTED_PATH_BOUND_BY_PREDECESSOR
CORRECTED_PATH_BOUND_BY_RECONCILIATION
CORRECTED_PATH_INDEPENDENTLY_OBSERVED
PATH_CORRECTION_SCOPE_ONE_FIXED_INPUT_ONLY
ALL_CANONICAL_SUPPLIED_ROOT_PATHS_PREFLIGHTED
STOPPED_RESEAL_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
STOPPED_RESEAL_ATTEMPT_ROOT_NOT_RESUMED
NO_NORMATIVE_CONTRACT_CHANGE_FROM_PATH_CORRECTION
NO_SCHEMA_CHANGE_FROM_PATH_CORRECTION
```

After `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED`, authorize a
separate construction-parent implementation task bound to the exact normative
contract identity. Do not reinterpret the contract during implementation.
```

## Decision

Retry the contract-package reseal in a new root with the corrected `accepted_bootstrap_audit` path. Do not run another causal reconciliation and do not change the contract or schemas.

**Source:** Codex’s latest `CONTRACT_PROVENANCE_MISMATCH` report and the prior closing-equality reconciliation.  
**Confidence:** 1.00 that Codex stopped correctly; 1.00 that the previous prompt supplied the wrong path; 0.995 that the corrected path is authenticated by both predecessor and reconciliation evidence; 0.98 that the full reseal can now proceed without contract changes.
