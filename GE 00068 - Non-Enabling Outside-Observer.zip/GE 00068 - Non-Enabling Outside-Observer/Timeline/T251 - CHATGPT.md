## Assessment

This producer pass is strong enough to proceed to a **fresh independent exact-source audit of the strategic B snapshot**. It does **not** yet authorize the real H→B commit.

The report establishes the critical facts we needed:

- It constructed the exact B state as 389 files with source tree/Git tree `8de797304ea944b6a155924e0d1e9e8bbe79534e`, the expected inventory hash, and no physical aliases, symlinks, special objects, or multiply linked source files. 
- It recovered exactly 36 H→B changes—22 modifications and 14 additions—and proved that all other 353 H paths retain the same Git blob and logical mode.  
- It preserved the necessary distinction between repository logical modes and private evidence-custody modes, avoiding the earlier `100600` provenance failure. 
- It constructed a deterministic evidence-only synthetic commit with parent H, tree B, and the frozen subject `implement Remote Alpha external TLS T2A-P source`. 
- It recovered and ran the historical acceptance-bearing validation plan. The B version correctly has **105** documentary tests, not F’s later 106-test set. All 105 passed. The remaining bounded commands also met their specified results, including the explicitly governed failure/skip outcomes.  
- It closed the snapshot capsule with two independently generated, byte-identical manifests covering 107 directories and 460 nonmanifest files, with only the manifests self-excluded. Candidate and supplied-root closing identities matched opening. 

The main audit pressure points should be:

1. independently reconstructing the 389-file B tree and 36-path H→B delta;
2. independently recomputing both the Git tree and synthetic commit;
3. checking every byte-origin claim, especially the seven paths sourced from the pre-governance authorized-byte set rather than current F;
4. verifying that the raw-exit-1 external-TLS run has exactly the historically authorized failure and skip identities—not merely matching aggregate counts;
5. verifying that the one permitted skip in the nonroot product-test command is the exact closed helper-process fixture skip;
6. confirming that the retained validation plan is genuinely recovered authority rather than a producer-selected subset;
7. auditing the complete capsule closure and nonauthority claims.

No candidate implementation, governance repair, or publication change is indicated.

## Prompt for a fresh Codex audit

```text
FRESH INDEPENDENT EXACT-SOURCE AUDIT —
REPAIR 10I T2A-P STRATEGIC B SNAPSHOT

Perform a fresh, independent, parent-only, read-only audit of the exact
strategic B snapshot package named below.

Do not create subagents.

This audit evaluates a source-external snapshot package. It does not stage,
commit, edit, publish, deploy, install, or begin A6.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether the exact strategic B snapshot:

1. reconstructs the complete authenticated pre-governance source state B;
2. binds every source byte and repository logical mode to exact provenance;
3. represents exactly H→B as 22 modified and 14 added paths;
4. computes the exact B Git tree independently;
5. constructs a correct evidence-only synthetic commit candidate;
6. recovers and executes the complete acceptance-bearing B validation plan;
7. has complete, private, reproducible capsule closure;
8. preserves the correct evidence-only and nonauthority boundaries;
9. is fit to serve as the accepted input to a later real H→B commit gate.

Do not repair any finding.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate opening state:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- tracked paths:
  375
- nonignored untracked paths:
  14
- governed paths:
  389
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Expected root identity:

- device:
  16777234
- inode:
  178255587
- mode:
  0700

Expected B identities:

- files:
  389
- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- B inventory size:
  54314
- H→B:
  22 modified
  14 added
  0 deleted
  0 renamed

Expected synthetic commit:

- commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- subject:
  implement Remote Alpha external TLS T2A-P source
- author/committer:
  Repair 10I Strategic Snapshot <repair10i-strategic-snapshot.invalid>
- timestamp:
  2001-01-01T00:00:00Z

Expected snapshot closeout identities:

- closeout/final-evidence-inventory.json
  size:
  130182
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb

- closeout/final-report.md
  size:
  151150
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe

- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  139328 each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  expected:
  byte-identical

Expected manifest closure:

- entries:
  567
- directories including root:
  107
- nonmanifest files:
  460
- empty directories:
  0
- self-exclusions:
  exactly the two canonical manifest files
- directories:
  mode 0700
- files:
  regular, single-link, mode 0600
- symlink/special/multiply-linked:
  0

Important retained records include:

- provenance/H-B-36-path-manifest.json
- provenance/B-canonical-source-inventory.json
- provenance/B-source-inventory.txt
- git/non-36-equality.json
- validation/validation-plan.json
- closeout/final-evidence-inventory.json
- closeout/final-report.md

NAMED PROVENANCE ROOTS

Topology reconciliation:

/Users/ds/Downloads/ES-repair10i-predecessor-topology-recon-dupTHGG5

Governance-freeze implementation:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2

Governance audit repair:

/Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

Accepted governance/mode-provenance audit:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-final-audit-fjuro9xw

Failed staged-tree gate:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-commit-gate-v3-qv31qdyj

Commit-scope reconciliation:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-reconciliation-mmaexmlj

Repair 10 lineage:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1

Use only exact paths named by the snapshot, candidate guidance, or these named
roots. Do not broadly scan unrelated Downloads content or sibling repositories.

──────────────────────────────────────────────────────────────────────────────
2. AUTHORITY AND EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read the candidate repository and named supplied roots;
- allocate one fresh private audit root beneath /Users/ds/Downloads;
- create audit-owned materializations, private Git repositories, indexes,
  caches, homes, fixtures, and reports under that root;
- execute bounded offline validation against audit-owned exact B copies;
- remove only audit-owned temporary material.

Forbidden:

- candidate repository edits or index mutation;
- staging or committing in the candidate;
- restore, reset, amend, rebase, stash, merge, checkout, or clean in the
  candidate;
- supplied-root mutation;
- product/live-service invocation;
- installation or deployment;
- network contact;
- A6 work;
- subagents.

Every Git read against the candidate must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to that repository and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

The audit must treat:

- candidate Git and current working-tree identities as repository facts;
- the strategic snapshot as proposed source-external evidence;
- the synthetic commit as evidence only;
- validation outputs as observed results;
- no snapshot record as publication, commit, runtime, readiness, deployment, or
  A6 authority.

──────────────────────────────────────────────────────────────────────────────
3. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable fresh directory beneath
/Users/ds/Downloads using tempfile.mkdtemp with prefix:

ES-repair10i-t2ap-strategic-b-independent-audit-

Retained directories must be mode 0700.

Retained files must be regular, single-link, mode 0600.

Private Git state, materializations, caches, homes, temporary roots, and
fixtures must remain beneath an audit-private transient root and be removed
before closeout.

Do not retain unexplained empty directories.

──────────────────────────────────────────────────────────────────────────────
4. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Read candidate AGENTS.md and applicable nested guidance.
2. Verify candidate physical identity, branch, HEAD, tree, parent, absent
   upstream, index, dirty posture, F source T, and F inventory.
3. Verify STRATEGIC_B_ROOT identity and complete filesystem closure.
4. Verify both canonical manifests independently.
5. Verify the final report and final evidence inventory identities.
6. Verify the named provenance roots required by every source-origin record.
7. Verify no supplied root drift, wrong mode, unsupported object, operation
   marker, or lock.
8. Retain complete opening inventories for the candidate, snapshot, and every
   supplied root actually used.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

Do not normalize, chmod, clean, recreate, or repair a supplied object.

──────────────────────────────────────────────────────────────────────────────
5. COMPLETE B SOURCE AND ORIGIN AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently inspect all 389 B inventory rows.

For every row verify:

- repo-relative path;
- H→B classification;
- authenticated repository logical mode;
- physical snapshot custody mode;
- byte size;
- SHA-256;
- source-origin path and root;
- source-origin device/inode/type/mode/link count where recorded;
- retained snapshot identity;
- H blob identity when present;
- F identity;
- B→F classification.

Require:

- exactly 389 unique paths;
- no extra or missing path;
- exact logical mode set;
- every retained source file regular, single-link, physical mode 0600;
- all retained source directories mode 0700;
- no symlink, special file, hardlink alias, or candidate/supplied-root inode
  alias.

Do not derive repository logical mode from physical snapshot custody mode.

SOURCE ORIGIN RULES

The producer identifies:

- `C`: exact current candidate byte where B=F;
- `G`: exact pre-governance byte from the governance-freeze
  `opening/authorized-bytes` source.

Independently verify every `C` and every `G` claim.

For the seven B→F paths, require the B bytes to come from the authenticated
pre-governance source, not the current F path.

Stop with BLOCK if any origin is ambiguous or relies on inference rather than
exact retained bytes.

──────────────────────────────────────────────────────────────────────────────
6. INDEPENDENT H→B TREE RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not import or execute a producer reconstruction helper.

Independently reconstruct B from:

- exact H tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- exact 22 modified B blobs;
- exact 14 added B blobs;
- authenticated logical modes.

Require exact path classification:

- 22 modified;
- 14 added;
- 0 deleted;
- 0 renamed.

Build a private Git index/tree from those inputs.

Require:

- Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- inventory size:
  54314
- governed files:
  389

Independently compare H and reconstructed B:

- exactly 36 differences;
- all other 353 H paths retain the exact Git blob OID and logical mode;
- no extra B path beyond the 14 additions.

Retain the independently reconstructed 36-path manifest and compare it
byte-semantically with the supplied H-B manifest.

──────────────────────────────────────────────────────────────────────────────
7. SYNTHETIC COMMIT REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

In a private Git repository, independently recreate the synthetic evidence
commit using:

- parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- subject:
  implement Remote Alpha external TLS T2A-P source
- author and committer:
  Repair 10I Strategic Snapshot <repair10i-strategic-snapshot.invalid>
- author and committer timestamp:
  2001-01-01T00:00:00Z

Require resulting commit:

e42aac659299e023df07a842df17e9fc84a135c1

Inspect its raw commit object and ensure no undeclared metadata affects the
identity.

The synthetic commit remains evidence only. Do not treat its identity as the
future publication commit.

──────────────────────────────────────────────────────────────────────────────
8. VALIDATION-PLAN AUTHORITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Audit validation/validation-plan.json completely.

For every command require:

- exact command ID;
- exact argv;
- exact working root;
- exact environment;
- expected exit semantics;
- expected pass/fail/skip identities;
- rationale;
- originating governing or retained evidence record.

Determine whether the complete plan is a recovered acceptance boundary rather
than a producer-selected subset.

Pay particular attention to:

A. `complete-docs-105`

- Require exactly the B-era 105 top-level documentary test identities.
- Verify why B has 105 rather than F’s later 106.
- Verify no B test is omitted.

B. `external-tls-all`

- Raw exit 1 is not automatically acceptable.
- Identify the exact one allowed failing test.
- Identify the exact four allowed skipped tests.
- Verify their exact failure/skip reasons against retained governing evidence.
- Require zero additional fail, error, panic, or skip.
- Verify that neither aggregate counts nor a producer caption substitute for
  identity-level adjudication.

C. `changed-nonroot-product-tests`

- Identify the exact nine intended test identities.
- Verify the exact one allowed helper-process fixture skip and why it is
  acceptance-compatible.
- Require the other eight expected identities to pass.
- Require no other skip or failure.

D. `repair10-current-affected-pass`

- Verify the exact twenty intended identities and that all twenty are
  acceptance-bearing for B.

E. `testsupport-acceptance`

- Verify the exact three named tests and their dependency on B’s added
  test-support sources.

F. shell syntax and private Git diff check

- Verify these are required supplemental checks and not substitutes for source
  or test validation.

If the plan’s authority or exception handling is not independently supported,
return BLOCK even when producer runs passed.

──────────────────────────────────────────────────────────────────────────────
9. FRESH INDEPENDENT VALIDATION
──────────────────────────────────────────────────────────────────────────────

Use an independently reconstructed, physically separate, clean B validation
tree.

Pinned Go:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected:

- version:
  go version go1.26.5 darwin/arm64
- SHA-256:
  3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Use private audit-owned:

- HOME;
- TMPDIR;
- GOTMPDIR;
- GOCACHE;
- GOMODCACHE.

Set:

GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
ES_REPAIR10_SOURCE_ROOT=<exact independent B validation root>

Seed only already-present pinned module-cache objects. Do not contact the
network or install anything.

Run every command in the independently accepted validation plan.

For every run retain:

- complete argv;
- cwd;
- exact explicit environment;
- exit or signal;
- complete stdout/stderr;
- byte counts and SHA-256;
- exact observed top-level identities;
- exact pass/fail/skip/error identities;
- before/after B tree and inventory identities;
- generated-state inventory and cleanup.

Require:

- every command to satisfy its independently adjudicated expected result;
- zero unexplained failure, error, panic, or skip;
- exact B tree unchanged after validation;
- clean private Git state;
- no retained generated artifact in B source.

Do not import producer result parsers when adjudicating fresh output.

──────────────────────────────────────────────────────────────────────────────
10. CAPSULE CLOSURE, SECURITY, AND ARTIFACT AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently enumerate STRATEGIC_B_ROOT.

Require:

- exactly 107 directories including root;
- exactly 460 nonmanifest files;
- exactly 567 represented entries;
- exactly two self-excluded manifest files;
- no empty directory;
- no unrepresented or duplicate path;
- all directories mode 0700;
- all regular files single-link mode 0600;
- no symlink, special file, or multiply linked file.

Independently generate two canonical manifest projections using different
audit-owned traversal implementations. Require both to equal the supplied
manifest bytes exactly and hash to:

df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc

Verify final-evidence-inventory closure and the final-report identity.

Inspect retained `.tar.gz` fixtures and `.out/Dockerfile`:

- classify each as governed source or evidence;
- inspect archive member names, types, modes, and traversal safety;
- reject unexpected special, absolute, or parent-traversal members.

Perform bounded sensitive-material scanning without printing payload contents.
Distinguish governed test/sanitization literals from plausible live secrets.
Do not treat a PEM marker alone as proof of live key material.

──────────────────────────────────────────────────────────────────────────────
11. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Verify that the snapshot claims only:

- exact source bytes and logical modes;
- H→B classification;
- B source T and inventory;
- B Git tree candidate;
- observed validation;
- byte provenance.

Require explicit nonauthority over:

- publication and commit;
- current repository truth;
- future commit identity;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation.

A source-external snapshot is not current repository fact until a later
authorized Git commit is created and independently checked.

──────────────────────────────────────────────────────────────────────────────
12. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After all correctness and validation work:

1. Remove only audit-owned transient Git state, materializations, caches, homes,
   fixtures, and temporary files.
2. Make two fresh observations that transient state is absent.
3. Verify no process or descriptor survivor.
4. Recompute complete candidate identity and current F inventory.
5. Recompute every supplied-root inventory used by the audit.
6. Require opening/closing equality.
7. Recompute retained B source:
   - 389 files;
   - exact logical modes;
   - exact source T;
   - exact inventory;
   - exact Git tree.
8. Verify STRATEGIC_B_ROOT manifests and closure again.
9. Verify retained audit directories are 0700 and retained files are regular,
   single-link, 0600.
10. Retain a complete final audit-root inventory and inline report.

Return AUDIT_PROVENANCE_MISMATCH on any supplied-root mutation or unprovable
opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
13. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- opening and closing provenance qualify;
- all 389 B paths and origins independently qualify;
- H→B independently reconstructs the exact tree;
- the synthetic commit independently reproduces;
- the complete validation plan is independently authorized;
- fresh validation matches all expected identity-level outcomes;
- closure and sensitive-material checks pass;
- no authority widening or residual acceptance-affecting defect remains.

Return BLOCK for a repairable source, provenance, validation-plan, validation,
closure, artifact, security, or authority defect.

Return REJECT only for a fundamental unsoundness that cannot be repaired within
the strategic snapshot scope.

Return AUDIT_PROVENANCE_MISMATCH for input drift, supplied-root mutation,
missing exact source bytes, or failed opening/closing equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return a complete inline report containing:

1. Primary verdict
2. Audit-root identity
3. Candidate and supplied-root opening identities
4. Strategic snapshot closure
5. Complete B source-origin adjudication
6. Logical-mode versus custody-mode adjudication
7. Independent B source T and inventory reconstruction
8. Independent H→B 36-path classification
9. B Git tree identity
10. Synthetic commit reproduction
11. Non-36 H-path equality
12. Validation-plan authority adjudication
13. Exact 105 documentary identities and results
14. Exact external-TLS fail/skip identities and policy
15. Exact nonroot-product pass/skip identities and policy
16. Remaining validation commands and results
17. Capsule manifests and final-inventory closure
18. Archive, artifact, and sensitive-material findings
19. Snapshot authority and nonauthority
20. Severity-ranked residual findings
21. Minority/alternative interpretations and parent resolution
22. Cleanup and two absence observations
23. Candidate and supplied-root closing equality
24. Audit-created paths and final inventory
25. Remaining uncertainty and explicit nonclaims
26. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
EXACT_B_SOURCE_INDEPENDENTLY_RECONSTRUCTED
EXACT_H_B_SCOPE_INDEPENDENTLY_RECONSTRUCTED
B_GIT_TREE_INDEPENDENTLY_REPRODUCED
SYNTHETIC_COMMIT_INDEPENDENTLY_REPRODUCED
VALIDATION_PLAN_INDEPENDENTLY_ADJUDICATED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, the next operation is the real H→B commit gate. That gate should stage the snapshot’s exact 36 paths, validate the exact staged tree against the accepted plan, and create one commit with subject `implement Remote Alpha external TLS T2A-P source`. Only after B is committed should the already-audited B→F governance commit be gated.

### Sources

The attached report states the producer verdict, exact H/B/F topology, and complete 36-path scope.    
It records the exact B tree and evidence-only synthetic commit.   
It reports the recovered validation plan, validation outcomes, complete closure, and the remaining fresh-audit boundary.   

**Confidence:** 0.99 that the snapshot producer pass is ready for independent audit; 0.97 that no candidate implementation repair is needed; 0.96 that the identity-level adjudication of the expected external-TLS failure/skips is the most important remaining audit seam.
