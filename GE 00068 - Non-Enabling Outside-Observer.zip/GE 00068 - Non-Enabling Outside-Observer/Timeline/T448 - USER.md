Here is Codex's response:

# `SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_REPAIR_BLOCKED`

This is an independent-audit-harness repair blockage, not a product-implementation audit result. The package was terminally closed as a failure capsule; no full independent audit was run.

### 1. Verdict

The repaired harness cannot be qualified under the two-attempt limit. Attempt 2 passed its own matrices, bounded replay, synthetic cases, and validator, but a final integration review found an untested terminal-adapter interface mismatch that would make a future full audit raise `KeyError`.

### 2. Scope completed

The failed audit was diagnosed, its seven causal lanes were reconstructed, two permitted source attempts were used, bounded qualification was performed, synthetic terminal behavior was exercised, and the repair package was closed without running the product or full audit.

### 3. Operating constraints honored

No subagents, Git operations, network access, dependency installation, product-source execution, or full independent audit were used. The two-source-attempt ceiling was not exceeded.

### 4. Fresh audit root

The fresh root was:

[`/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6`](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6)

Opening identity:

- Device: `16777234`
- Inode: `181082379`
- Mode: `0700`

### 5. Supplied roots

Eight supplied roots were held in scope: attempt-2 evidence, authoritative contract, failed audit, implementation, reconciliation, schema source, successor, and validation specification.

### 6. Opening custody

Exact opening identities and inventories were captured for all eight roots. Their closing identities and content inventories matched exactly.

### 7. Failed-audit preservation

The failed audit and all supplied evidence were preserved as read-only inputs. The failed harness was diagnosed without modifying its source or evidence.

### 8. Failure classification

The previous result was classified as an audit-harness failure. The seven findings were independent harness defects or contradictions; they did not establish a product defect.

### 9. Causal ledger

The complete seven-lane reconstruction is retained in the [failed-audit defect ledger](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/analysis/failed-independent-audit-defect-ledger-v1.json).

All seven causal lanes were supported.

### 10. Lane A — manifest and temporal grammar

The implementation’s temporal and manifest path sets were exactly equal, with `.` present once. Counts were `109` temporal rows and `110` manifest rows under the package’s self-exclusion grammar.

The failed harness compared package rows using `kind: "regular"` against its own internal spelling `type: "regular_file"`. The first regular file therefore produced a false mismatch. The sealed implementation reprojected exactly under its owned grammar.

### 11. Lane B — 41 current roles

The authoritative registry was `contract/current-gen2-contract-role-registry-v2.json`, pointer `/rows`.

It contained exactly 41 unique current roles using:

- `role_id`
- `current_path`
- `exact_identity`
- `current: true`
- `historical_predecessor_current: false`

The failed generic parser incorrectly treated nested `exact_identity` and `predecessor_identity` keys as additional roles.

### 12. Lane C — invocation validation

Four invocation candidates existed. The exact valid record was `rehearsals/rehearsal-a-evidence-v1.json#/process`.

The failed predicate accepted only `"DEVNULL"`, `"closed"`, or `None`, while the retained valid value was lowercase `"devnull"`.

The reconstructed future invocation was:

```text
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3 -I -S -B
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/production/reconstruct_parent.py
--mode reconstruct-subject
[all six supplied-root arguments]
[final production and qualification registries]
[independent schema validator]
--cwd [implementation root]
```

Its prescribed environment contained only `PYTHONDONTWRITEBYTECODE=1`, with the implementation root as working directory, closed/devnull stdin, and a 600-second timeout. It was not executed.

### 13. Lane D — zero-set cleanup

The created, inventoried, retained, cleaned, and absent sets were all equal and empty. No process, descriptor, or cache survivor existed.

The failed predicate required `bool(created)` in addition to set equality, incorrectly rejecting a legitimate zero-object cleanup result. Classification: `AUDIT_ZERO_SET_PASS_PREDICATE_DEFECT`.

### 14. Lane E — temporal instability

Retained and live path sets were equal. The reported mismatches were:

- Index 13: `closeout.link_count`, retained `3`, live `4`
- Index 37: `manifest.link_count`, retained `2`, live `4`

These arose from directory link-count instability and creation of placeholder descendants after the temporal inventory.

### 15. Lane F — empty descendants

The failed package precreated `causals/` and `evidence/` even though no causal or rehearsal artifact was emitted. Those empty descendants served no semantic purpose and violated terminal-shape expectations.

### 16. Lane G — security contradiction

A later checker lexically tainted every `os.walk` in a file containing `/Users/ds/Downloads` and treated a dynamic `Popen` as unresolved without resolving its exact root or absolute `argv[0]`.

Five bounded operations were disputed: two production walks, one production `Popen`, one qualification walk, and one qualification `Popen`. All were root-bounded or absolute closed flows.

### 17. Authenticated predecessor sources

Exact predecessor identities included:

- Recorder: size `6209`, SHA-256 `ec724c7dd00feb63d918cc8497336b01d681b542b0aa7e76f5b7dc0fec40119a`
- Platform: size `3344`, SHA-256 `1a53f3d74297c42e0e7d9002fed551dca685caed280357a657910c40e2d85670`
- Failed audit parent: size `252541`, SHA-256 `5a8452bcfedf310bfeda3ea7cb9e96f00a413420232b8af756cdca69b8f47c35`
- Authenticated failed-root freeze identity: `200f564e79d141910d34401a4ccb81433c5bdef8b2ab47f04cb641514cc1bb35`

### 18. Repair architecture

The repair kept package-specific grammar and role interpretation explicit, narrowed capability/security decisions to provable behavior, separated zero-set cleanup from nonempty cleanup, and introduced terminal-capsule handling for success, block, and causal-failure paths.

### 19. Source-attempt accounting

Exactly two source attempts were consumed. Source-attempt ledger SHA-256:

`14e377b91e242cb7795fddc49cd62911ff5c8df2e5e07e45c64153ae4c93f5fe`

### 20. Attempt 1

Attempt 1 did not qualify. Its qualification tests contained three test-oracle defects:

- Incorrect expected-reason oracle
- Unsound finite `while`/`break` analysis
- Reversed negative-assertion polarity

The attempt was preserved rather than overwritten.

### 21. Attempt-1 closure

Attempt 1’s evidence closure succeeded, although functional qualification failed. Closure SHA-256:

`59720916282e380a606704005d178d94624afbe1a0c22f7fba25cd6e01875c81`

### 22. Attempt 2

Attempt 2 corrected the Attempt-1 qualification defects and became the current candidate.

Key source identities:

- Audit parent: size `239303`, SHA-256 `1caa2554c923ce2f1e9bc684301860654bfd18b1a18e614613e7115eafce7d6c`
- Repair core: size `46559`, SHA-256 `adaecf6cf565748a95e2afe2059ea811638fbbae60188d8133adb3b69ccb65d5`
- Qualification driver: size `59954`
- Independent validator: size `18809`

Attempt-2 closure SHA-256:

`4a4d558893a985eb1b906ef93d68cacb4d35a257caa17b536edb9d52ad68c274`

### 23. Current source registry

The current registry covered six source files and fourteen source roles. Its SHA-256 was:

`910eb1a344f73bc1d9679b32c9af1ca038a5f6219454fdb0322fbb0f9a1fc6bb`

### 24. Protected-source equivalence

All 109 protected common functions were AST-identical to their required predecessors. Package verdict constants were unchanged.

### 25. Qualification matrices

Attempt 2 self-reported all six matrices passing:

- Manifest/current-role matrix: 44 cases
- Invocation matrix: 39 cases
- Cleanup matrix: 26 cases
- Temporal/terminal matrix: 42 cases
- Security matrix: 32 cases
- Process-custody matrix: 26 cases

### 26. Qualification totals

Across 209 cases, Attempt 2 reported:

- False accepts: `0`
- False rejects: `0`
- Reason mismatches: `0`
- Skips: `0`
- Unexpected exceptions: `0`

### 27. Compilation and local static checks

Compilation and the candidate’s static suite self-reported success. This does not satisfy the final static-gate confirmation because the suite omitted the terminal-adapter interface exercised by the audit parent.

### 28. Bounded live replay

The bounded harness replay self-reported success. It did not run the production reconstruction source or full independent audit.

### 29. Synthetic success case

The success capsule closed and reprojected successfully. It did not create an unused `causals/` directory.

### 30. Synthetic block case

The block capsule remained a substantive `BLOCK`; it was not converted into success or a generic execution failure.

### 31. Independent validator adjudication

The independent validator self-reported zero errors and `PASS`.

Governance confirmation is nevertheless `NOT CONFIRMED`: the validator did not cover the interface between `repair_core.close_capsule()` and `Audit.build_inline_report()`. Its green result was therefore incomplete.

Independent-coverage adjudication SHA-256:

`c910334b39a2d25e4c9d68598073c95062ea66f0c29f53f20beae937dfd69b92`

### 32. Synthetic zero-root failure

The zero-root causal-failure case passed with equal empty cleanup sets.

### 33. Synthetic one-root failure

The one-root causal-failure case passed, including the required double-`ENOENT` behavior.

### 34. Synthetic temporal failure

The temporal-inventory failure produced the intended causal result and left provisional manifests absent.

### 35. Synthetic manifest-B failure

The manifest-B write failure produced the intended causal result and removed the partial manifest pair.

### 36. Repeated synthetic cleanup

All six synthetic cases were exercised across Attempt 1, Attempt 2, and the frozen-candidate replay: 18 synthetic roots total. Every root was inventoried and then independently verified absent twice.

Cleanup-record SHA-256:

`c4ede874bfff70885d521fb5e9c9bc8eb92df2895017c44a02113c51ec5e636a`

### 37. Process custody

The process ledger recorded:

- Surviving processes: `0`
- Surviving descriptors: `0`
- Production-source argv occurrences: `0`
- Full-audit-parent argv occurrences: `0`

Ledger SHA-256:

`a9084cee68dc4d5eb5fba96ceb724cf88c1d78167b0cc6422db29a41707ab6a6`

### 38. Forbidden execution checks

Neither the product reconstruction source nor the full independent audit parent was executed. No result in this package is a product-correctness or producer-readiness finding.

### 39. Static-gate adjudication

`STATIC_HARNESS_GATES_PASSED` is `NOT CONFIRMED`.

The executed static checks passed their declared rules, but failed to detect a concrete consumer/provider schema mismatch in the terminal adapter. Treating those checks as authoritative would be a false qualification.

### 40. Source-freeze adjudication

The repaired harness was not authoritatively frozen as ready. The ready-freeze posture was false:

`bd025aa74348a645a403333d3b3c5eb19f6c32b354b9de3a37f39789a31969bd`

The terminally closed failure snapshot is immutable evidence, but it is not a qualified-source freeze.

### 41. Frozen requalification

Raw frozen-candidate reruns self-reported success, but final adjudication was false because the uncovered adapter mismatch remained:

`733ada195914b3a34adde49cff6619923050e7dee07faf6c542e1e060d1f4459`

### 42. Blocking defect

The exact blocker is:

`FUTURE_AUDIT_PARENT_TERMINAL_ADAPTER_INTERFACE_MISMATCH`

It is recorded in the [Attempt-2 terminal-adapter blocker](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/analysis/attempt-2-terminal-adapter-interface-blocker-v1.json).

### 43. Blocking mechanics

On successful closure:

1. `repair_core.close_capsule()` returns terminal data without a top-level `audit_root_identity`.
2. `repair_core.seal_audit()` forwards that result unchanged.
3. `Audit.build_inline_report()` accesses `terminal["audit_root_identity"]`.
4. A future full audit would raise `KeyError` before emitting its guarded terminal marker and verdict.

The identity exists only at `terminal["inventory"]["root_identity"]`.

Relevant source ranges:

- Audit parent `build_inline_report`: lines 4041–4199
- Audit parent `seal_terminal_capsule`: lines 4201–4349
- Repair core `close_capsule`: lines 891–1025
- Repair core `seal_audit`: lines 1028–1048

### 44. Why it was not repaired

Correcting the provider schema or adapting the consumer—and adding coverage for that interface—would modify current source. That would constitute a third source attempt, which the governing maximum-two-attempt rule prohibits.

No waiver or hidden post-attempt patch was applied.

### 45. Readiness decision

The current candidate must not be used to start a full independent audit. Status-record SHA-256:

`fad5526228906c0845ddc409c13838e666df92aba6dc0556`

### 46. Failure-capsule closeout

The blocked package itself closed successfully as failure evidence. This is not a success seal.

Terminal seal marker:

`5ded2d9cb4532ca100c71407fbd687368849b6109def5cd33a590dd125038b42`

Failure-closeout record SHA-256:

`e2c6fffee7a36a4c9389a318abf6161fe255b47456465bb0273baba7bff4c8c1`

### 47. Final temporal inventory

The [final temporal inventory](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/closeout/temporal-final-inventory-v1.json) had:

- Device: `16777234`
- Inode: `181094949`
- Mode: `0600`
- Link count: `1`
- Size: `32055`
- SHA-256: `c6a3532ff28528f95b61d66ab4c7667f605996db5a65b3ff2abefad13eaad4ab`
- Represented rows: `112`

Immediate and final temporal reprojections both passed.

### 48. Canonical manifests

[Manifest A](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/manifest/canonical-manifest-a-v1.json):

- Inode: `181094947`
- Mode: `0600`
- Link count: `1`
- Size: `33301`
- SHA-256: `0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf`

[Manifest B](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/manifest/canonical-manifest-b-v1.json):

- Inode: `181094948`
- Same mode, link count, size, and SHA-256

The pair was byte-identical and represented 113 rows under the terminal self-exclusion grammar.

### 49. Terminal reprojection

Terminal reprojection passed. Temporal immediate/final reprojection and final Manifest A/B reprojection also passed. The root row occurred exactly once.

### 50. Final filesystem hygiene

Final physical inventory:

- Objects including root: `115`
- Directories including root: `23`
- Regular files: `92`
- Empty descendants: `0`
- Symlinks: `0`
- Special objects: `0`
- Multiply linked files: `0`
- Cache artifacts: `0`
- Incorrect directory modes: `0`
- Incorrect file modes: `0`

All directories were `0700`; all regular files were `0600`.

### 51. Closing equality of supplied roots

The [closing-equality record](/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6/closing/supplied-root-closing-equality-final-v1.json) passed for all eight roots.

Record identity: size `7563`, SHA-256 `392290e4295b1754883c1d276bddcbd6174095983bf7e2743ef8454d9e436095`.

Closing inventory digests:

- Attempt 2: `778d0c6e41b3d80ce8a9f326782a0c868af2b5dad8332a24b1c65af04e6297f1`
- Authoritative contract: `0cb2062afdd960a56792f90420e4f491b65f836886584dca586f0ed161831d36`
- Failed audit: `de3a62f894eafdea54d0af85914d41c614804ea83c1b66add27da08e73c7f3bd`
- Implementation: `d272be8e9ea33eab1cd5f78c8840b4d5d073df6704d916d41981110b9c952b4e`
- Reconciliation: `86ed69482adb4e20cdcdb47aab002178560229a702f91505be137478c0e2c889`
- Schema source: `89b95b973e4e8158668c10dabf04fa66bb3a205ad048579c271e4f3f57fa450a`
- Successor: `8f8f383aae4bf5ebf96ea6c5ca053f6fe6e69f8bb318ee0272c68d7701fac0f6`
- Validation specification: `712600a53799b082cce3e015f497772d96230b9e0a27d8c28e422af450eae019`

### 52. Post-seal discipline

No filesystem read or write was performed after the terminal seal. `NO_WRITE_AFTER_TERMINAL_CLOSURE` is confirmed.

### 53. Nonclaims and required next action

This report does not claim:

- Product correctness
- Producer qualification
- Full-audit success or failure
- Harness readiness
- Authoritative repaired-source freeze

A future repair requires a newly authorized source-attempt budget. That repair must align the terminal provider/consumer schema, add an integration test exercising `seal_audit()` through `build_inline_report()`, rerun all gates from a fresh root, and only then consider a full independent audit.

### 54. Explicit 82-confirmation registry

The five `NOT CONFIRMED` entries are qualification blockers. All other entries are confirmed for the bounded repair operation or terminal failure closure.

```text
C01  NO_SUBAGENTS_USED                                      CONFIRMED
C02  NO_GIT_USED                                            CONFIRMED
C03  NO_NETWORK_USED                                        CONFIRMED
C04  NO_INSTALLS_PERFORMED                                  CONFIRMED
C05  NO_PRODUCT_SOURCE_EXECUTION                            CONFIRMED
C06  NO_FULL_INDEPENDENT_AUDIT_EXECUTED                     CONFIRMED
C07  FRESH_AUDIT_ROOT_USED                                  CONFIRMED
C08  FRESH_AUDIT_ROOT_IDENTITY_RECORDED                     CONFIRMED
C09  FRESH_AUDIT_ROOT_MODE_0700                             CONFIRMED
C10  SUPPLIED_ROOT_OPENING_IDENTITIES_RECORDED              CONFIRMED
C11  FAILED_AUDIT_ARTIFACTS_PRESERVED                       CONFIRMED
C12  AUTHORITATIVE_CONTRACT_ARTIFACTS_PRESERVED             CONFIRMED
C13  IMPLEMENTATION_ARTIFACTS_PRESERVED                     CONFIRMED
C14  RECONCILIATION_ARTIFACTS_PRESERVED                     CONFIRMED
C15  SCHEMA_SOURCE_ARTIFACTS_PRESERVED                      CONFIRMED
C16  SUCCESSOR_ARTIFACTS_PRESERVED                          CONFIRMED
C17  VALIDATION_SPEC_ARTIFACTS_PRESERVED                    CONFIRMED
C18  FAILED_AUDIT_CAUSAL_LEDGER_CREATED                     CONFIRMED
C19  FAILED_AUDIT_MANIFEST_GRAMMAR_DEFECT_CONFIRMED         CONFIRMED
C20  FAILED_AUDIT_ROLE_EXTRACTION_DEFECT_CONFIRMED          CONFIRMED
C21  FAILED_AUDIT_INVOCATION_STDIN_DEFECT_CONFIRMED         CONFIRMED
C22  FAILED_AUDIT_ZERO_SET_CLEANUP_DEFECT_CONFIRMED         CONFIRMED
C23  FAILED_AUDIT_TEMPORAL_LINK_COUNT_DEFECT_CONFIRMED      CONFIRMED
C24  FAILED_AUDIT_EMPTY_DIRECTORY_DEFECT_CONFIRMED          CONFIRMED
C25  FAILED_AUDIT_SECURITY_CLASSIFICATION_DEFECT_CONFIRMED  CONFIRMED
C26  EXACT_PREDECESSOR_RECORDER_REUSED                      CONFIRMED
C27  EXACT_PREDECESSOR_PLATFORM_REUSED                      CONFIRMED
C28  FAILED_AUDIT_PARENT_SOURCE_AUTHENTICATED               CONFIRMED
C29  SOURCE_ATTEMPT_LIMIT_RESPECTED                         CONFIRMED
C30  ATTEMPT_1_SOURCE_PRESERVED                             CONFIRMED
C31  ATTEMPT_1_CLOSURE_PASSED                              CONFIRMED
C32  ATTEMPT_2_SOURCE_PRESERVED                             CONFIRMED
C33  ATTEMPT_2_CLOSURE_PASSED                              CONFIRMED
C34  CURRENT_SOURCE_REGISTRY_CREATED                        CONFIRMED
C35  PROTECTED_COMMON_FUNCTIONS_AST_IDENTICAL               CONFIRMED
C36  PACKAGE_VERDICT_CONSTANTS_UNCHANGED                    CONFIRMED
C37  MANIFEST_AND_CURRENT_ROLE_MATRIX_PASSED                CONFIRMED
C38  INVOCATION_MATRIX_PASSED                               CONFIRMED
C39  CLEANUP_MATRIX_PASSED                                  CONFIRMED
C40  TEMPORAL_AND_TERMINAL_MATRIX_PASSED                    CONFIRMED
C41  SECURITY_MATRIX_PASSED                                 CONFIRMED
C42  PROCESS_CUSTODY_MATRIX_PASSED                          CONFIRMED
C43  QUALIFICATION_CASE_COUNT_209_CONFIRMED                 CONFIRMED
C44  ZERO_FALSE_ACCEPTS_CONFIRMED                           CONFIRMED
C45  ZERO_FALSE_REJECTS_CONFIRMED                           CONFIRMED
C46  ZERO_REASON_MISMATCHES_CONFIRMED                       CONFIRMED
C47  ZERO_SKIPS_CONFIRMED                                   CONFIRMED
C48  ZERO_UNEXPECTED_EXCEPTIONS_CONFIRMED                   CONFIRMED
C49  BOUNDED_LIVE_REPLAY_PASSED                             CONFIRMED
C50  SYNTHETIC_SUCCESS_CASE_PASSED                          CONFIRMED
C51  SYNTHETIC_BLOCK_CASE_PASSED                            CONFIRMED
C52  SYNTHETIC_ZERO_ROOT_FAILURE_CASE_PASSED                CONFIRMED
C53  SYNTHETIC_ONE_ROOT_FAILURE_CASE_PASSED                 CONFIRMED
C54  SYNTHETIC_TEMPORAL_FAILURE_CASE_PASSED                 CONFIRMED
C55  SYNTHETIC_MANIFEST_B_FAILURE_CASE_PASSED               CONFIRMED
C56  SYNTHETIC_CLEANUP_REPEATED_THREE_TIMES                 CONFIRMED
C57  SYNTHETIC_ROOTS_TWICE_ABSENT                           CONFIRMED
C58  PROCESS_CUSTODY_ZERO_SURVIVORS                         CONFIRMED
C59  PROCESS_CUSTODY_ZERO_DESCRIPTORS                       CONFIRMED
C60  PRODUCTION_SOURCE_ARGV_COUNT_ZERO                      CONFIRMED
C61  FULL_AUDIT_PARENT_ARGV_COUNT_ZERO                      CONFIRMED
C62  AUDIT_SUCCESS_CAPSULE_CLOSURE_PASSED                   CONFIRMED
C63  AUDIT_BLOCK_CAPSULE_CLOSURE_PASSED                     CONFIRMED
C64  AUDIT_FAILURE_CAPSULE_CLOSURE_PASSED                   CONFIRMED
C65  INDEPENDENT_REPAIRED_HARNESS_VALIDATOR_PASSED          NOT CONFIRMED
C66  STATIC_HARNESS_GATES_PASSED                            NOT CONFIRMED
C67  REPAIRED_HARNESS_SOURCE_FROZEN                         NOT CONFIRMED
C68  REPAIRED_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE      NOT CONFIRMED
C69  FROZEN_HARNESS_REQUALIFICATION_PASSED                  NOT CONFIRMED
C70  NO_EMPTY_DESCENDANT_AT_HARNESS_TERMINAL_CLOSURE        CONFIRMED
C71  HARNESS_PACKAGE_TEMPORAL_INVENTORY_CREATED             CONFIRMED
C72  HARNESS_PACKAGE_TEMPORAL_INVENTORY_VERIFIED            CONFIRMED
C73  HARNESS_PACKAGE_MANIFEST_A_CREATED                     CONFIRMED
C74  HARNESS_PACKAGE_MANIFEST_B_CREATED                     CONFIRMED
C75  HARNESS_PACKAGE_MANIFESTS_BYTE_IDENTICAL               CONFIRMED
C76  HARNESS_PACKAGE_TERMINAL_REPROJECTION_PASSED           CONFIRMED
C77  HARNESS_PACKAGE_ROOT_ROW_PRESENT_EXACTLY_ONCE          CONFIRMED
C78  NO_SYMLINK_OR_SPECIAL_OBJECT                           CONFIRMED
C79  NO_MULTIPLY_LINKED_FILE                                CONFIRMED
C80  ALL_DIRECTORY_MODES_0700                               CONFIRMED
C81  ALL_FILE_MODES_0600                                    CONFIRMED
C82  NO_WRITE_AFTER_TERMINAL_CLOSURE                        CONFIRMED
```
