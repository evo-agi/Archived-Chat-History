## Engineering assessment

This is a wrapper-contract error, not a harness, authority, certificate, or implementation-package defect.

All five fixed files authenticated, launch certificate v2 authorized one audit, and the 140-member PYZ closed correctly. The process was not created, so the single audit authorization remains unconsumed. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The previous wrapper prompt imposed the wrong invocation. It required:

```text
--bundle
--bundle-authority
```

and prohibited an audit-root operand. The actual sealed CLI requires:

```text
--content-bundle
--content-authority
--audit-root FRESH_PRIVATE_AUDIT_ROOT
```

The certificate, authority v4, embedded invocation contract, and frozen CLI agree on that invocation. :chatgpt-content-reference{index="2"}

The second wrapper error was treating the absence of a certificate-bound `cwd` as a provenance failure. The certificate does not contain a future `cwd` field. That means there is no certificate-level fixed-value predicate for cwd; it does not mean the launch is unauthorized. The external wrapper owns the submitted cwd, while the capsule’s runtime self-authentication must prove that runtime cwd equals the externally submitted value. Treating silence as a missing required authority field invented a stronger rule than the sealed launch contract. :chatgpt-content-reference{index="3"}

### Correct launch semantics

The corrected wrapper should:

1. Allocate one fresh private, empty audit root under `/private/tmp`.
2. Substitute its exact absolute path for `FRESH_PRIVATE_AUDIT_ROOT`.
3. Pass that path through `--audit-root`.
4. Use the fresh audit root as the submitted cwd.
5. Classify cwd selection as external-wrapper launch custody, not harness or certificate authority.
6. Require the runtime self-authentication record to crosswalk runtime cwd to that submitted cwd.
7. Parse the terminal output under the exact frozen stream contract; do not require a separate locator if the audit root is already supplied and the terminal frame binds it.
8. Consume the one authorization only when process creation succeeds.

The findings in this response are wholly external-launch provenance findings, not package findings. No audit phase, capsule, finding registry, or implementation evidence was reached. :chatgpt-content-reference{index="4"}

### Progression decision

Run the fresh independent audit again with a corrected wrapper. No new harness, authority, certificate, documentary, qualification, or source tranche is justified.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE FRESH INDEPENDENT AUDIT OF THE SEALED
GENERATION-2 RECONSTRUCTION-PARENT IMPLEMENTATION EVIDENCE

CORRECTLY INSTANTIATE THE SEALED RUN-FULL-AUDIT INVOCATION,
INCLUDING THE FRESH PRIVATE AUDIT ROOT

Objective

Execute exactly one fresh independent audit using these five exact current
authority files:

1. final harness PYZ v3;
2. final runtime harness authority v4;
3. final external launch certificate v2;
4. current-authority content snapshot ZIP;
5. current content-snapshot authority JSON.

Correct the two external-wrapper mistakes from the immediately preceding
prelaunch attempt:

1. Use the exact sealed CLI option names:

   --content-bundle
   --content-authority
   --audit-root

   Do not use:

   --bundle
   --bundle-authority

2. Do not require the launch certificate to bind a fixed cwd when its schema
   contains no future-cwd field.

   When the sealed certificate is silent about cwd, cwd is external-wrapper
   launch custody rather than a missing authority fact.

   For this execution:

   - allocate one fresh private audit root;
   - pass its exact path through `--audit-root`;
   - use that same exact path as the submitted cwd;
   - require the audit capsule’s runtime self-authentication to prove runtime
     cwd equals the externally submitted cwd.

The single authorized future audit remains unconsumed because the preceding
wrapper never created the audit parent.

Capture the top-level parent’s creation and completion exactly.

After the process completes:

- retain raw streams before parsing;
- parse only under the exact current stream/framing contract;
- authenticate the exact supplied audit root;
- inspect the resulting capsule read-only;
- authenticate terminal closure;
- report the exact final harness disposition;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute `qualify-harness`.

Do not launch a replacement, recovery, continuation, or second audit parent.

Do not run a direct implementation auditor outside the final frozen harness.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run a target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

The wrapper primary verdict must preserve the exact harness disposition.
Expected terminal dispositions include:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

GEN2_IMPLEMENTATION_PACKAGE_BLOCK

AUDIT_PROVENANCE_MISMATCH

Do not normalize a more specific harness verdict to generic ACCEPT or BLOCK.

If a prelaunch gate or platform preflight fails before audit-parent creation,
return:

AUDIT_PROVENANCE_MISMATCH

and state:

FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED
FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. EXACT FIVE-FILE AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

FINAL_HARNESS_PYZ_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v3-adopted-baseline-output-a3ffwvod/gen2-clean-source-external-independent-audit-harness-v3.pyz

Expected identity:

- device:
  16777234
- inode:
  182418324
- mode:
  0400
- link count:
  1
- size:
  2729019
- SHA-256:
  6233e477e68a607bdd01c347af5ca6aaac550eb50b6ffdfe7535a3c129b32071

FINAL_RUNTIME_AUTHORITY_V4:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v3-adopted-baseline-output-a3ffwvod/gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

Expected identity:

- device:
  16777234
- inode:
  182418328
- mode:
  0400
- link count:
  1
- size:
  13197
- SHA-256:
  d51177ab1780316af12b0a0d2c916442d8991056fb958afc65e5e1c33f0033f9

FINAL_EXTERNAL_LAUNCH_CERTIFICATE_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v3-adopted-baseline-output-a3ffwvod/gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

Expected identity:

- device:
  16777234
- inode:
  182418338
- mode:
  0400
- link count:
  1
- size:
  28761
- SHA-256:
  62a5b0ef951529ae9094dac0a9e9518826fd84412e2490c4f19922eacf7e9cd9

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

All containing directories are nonauthoritative.

Do not inspect or depend on unrelated directory members.

Do not open predecessor harness outputs, authorities, certificates, builder
roots, repair roots, draft roots, or historical audit roots.

──────────────────────────────────────────────────────────────────────────────
2. PREVIOUS PRELAUNCH-FAILURE DISPOSITION
──────────────────────────────────────────────── LIMITED TO WRAPPER EVIDENCE
────────────────────────────────────────────────

The preceding wrapper reported:

- verdict:
  AUDIT_PROVENANCE_MISMATCH;
- first blocker:
  LAUNCH_CERTIFICATE_FUTURE_INVOCATION_MISMATCH;
- secondary blocker:
  LAUNCH_CERTIFICATE_FUTURE_CWD_UNBOUND;
- audit-parent launch count:
  0;
- future audit authorization consumed:
  false;
- fixed-input authentication:
  passed;
- PYZ member closure:
  140;
- real audit:
  not executed.

Classify both blockers as:

EXTERNAL_WRAPPER_CONTRACT_MISINTERPRETATION

Retain exact corrections:

- the sealed option names are:
  `--content-bundle`,
  `--content-authority`,
  `--audit-root`;

- `FRESH_PRIVATE_AUDIT_ROOT` is a wrapper-instantiated placeholder;

- absence of a fixed cwd in the certificate is not a launch-authority failure;

- submitted cwd is wrapper-owned platform custody when the certificate is
  silent;

- runtime cwd must equal the wrapper-submitted cwd.

Do not modify any fixed file to correct these wrapper findings.

──────────────────────────────────────────────────────────────────────────────
3. STABLE PRELAUNCH FILE AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO CURRENT FILES
────────────────────────────────────────────────

Before allocating an audit root or launching any process, authenticate all five
files.

For every file:

1. open no-follow;
2. require a regular file;
3. require mode 0400;
4. require link count one;
5. retain device, inode, size, and SHA-256;
6. perform two stable reads;
7. require byte and metadata equality.

Strict-parse:

- authority v4;
- launch certificate v2;
- content authority JSON;

using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any fixed-input predicate fails:

- do not allocate the audit root;
- do not run platform preflight;
- do not create the audit parent;
- return `AUDIT_PROVENANCE_MISMATCH`;
- retain the exact first blocker;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
4. LAUNCH-CERTIFICATE AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO ITS ACTUAL SCHEMA
────────────────────────────────────────────────

Strictly validate launch certificate v2 under its exact current schema.

Require it to establish, through exact current fields:

- current external launch-certificate status;
- exact PYZ-v3 binding;
- exact authority-v4 binding;
- exact content-bundle binding;
- exact content-authority binding;
- exact source freeze;
- exact source registries;
- deterministic PYZ package equality;
- exact 140-member closure;
- all three governing-documentary-package identities;
- exact 113-dependency closure;
- exact two-record-class closure:
  - 108 schema-discriminated;
  - five schema-version-discriminated;
- exact governed matrix evidence role;
- source-adoption authority and lineage;
- semantic source-origin qualification;
- provisional packaged dependency smoke;
- exact 15 / 595 runtime suite;
- 151 interpreter cases;
- 171 descriptor cases;
- current-generation dependency and record-class suites;
- capsule, report, confirmation, lifecycle, custody, initialization, and
  behavioral-causal qualification;
- synthetic lanes;
- bounded compatibility replay;
- packaged ACCEPT rehearsal;
- packaged BLOCK rehearsal;
- packaged provenance rehearsal;
- independent validator results;
- post-package qualification;
- certificate-input validation;
- frozen-PYZ requalification;
- wrapper launch authorized:
  true;
- authorized future audit count:
  1;
- real audit already executed:
  false;
- implementation verdict:
  not issued;
- current schema subject constructed:
  false.

Do not require the certificate to bind:

- `--bundle`;
- `--bundle-authority`;
- omission of `--audit-root`;
- a fixed future cwd when its schema contains no such field.

Do not invent an absent cwd requirement.

The launch certificate is the external wrapper launch authority.

Authority v4 is the runtime authority passed to the harness.

Any actual certificate inconsistency:

- do not allocate the audit root;
- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`;
- leave authorization unconsumed.

──────────────────────────────────────────────────────────────────────────────
5. PYZ V3 MEMBER AND GOVERNANCE CLOSURE
──────────────────────────────────────────────── LIMITED TO CURRENT PACKAGE
────────────────────────────────────────────────

Parse the PYZ directly.

Require exact correspondence with certificate v2, authority v4, and the
embedded member registry.

Require:

- exactly 140 members;
- raw UTF-8 byte-sorted member names;
- ZIP_STORED only;
- fixed timestamps;
- create_system:
  3;
- member mode:
  0600;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no archive or member comment;
- no uncontrolled extra field;
- no cache or bytecode.

Resolve embedded current artifacts only through exact role registries.

Independently recompute:

- documentary domains:
  5;
- report rows:
  66;
- confirmation names:
  81;
- runtime matrices:
  15;
- runtime matrix cases:
  595;
- stale 645 accepted:
  false;
- interpreter roles:
  3;
- terminal-runtime-image role:
  absent;
- governed dependencies:
  113;
- schema-discriminated dependencies:
  108;
- schema-version-discriminated dependencies:
  5;
- content roles:
  8;
- content members:
  479.

Authenticate exact current roles for:

- entrypoint;
- source freeze;
- source registries;
- member registry;
- three governing packages;
- dependency registry;
- member-role registry;
- record-class registry;
- report registry;
- confirmation registry;
- runtime matrix registry;
- phase plan;
- capsule path/writer registry;
- custody contracts;
- cleanup contract;
- terminal lifecycle;
- package status;
- qualification/rehearsal evidence required by the certificate.

Do not invent a stronger launch predicate.

Do not weaken a sealed predicate.

Any discrepancy:

- do not allocate the audit root;
- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
6. WRAPPER AND AUDIT-ROOT ALLOCATION
──────────────────────────────────────────────── LIMITED TO FRESH PRIVATE PATHS
────────────────────────────────────────────────

After Sections 3–5 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Using:

- tempfile.mkdtemp;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-fresh-independent-audit-wrapper-corrected-`;
- umask:
  `077`.

Use it only for wrapper-owned:

- authentication records;
- platform-preflight custody;
- audit-parent custody;
- raw stream copies;
- final wrapper report.

B. FRESH_PRIVATE_AUDIT_ROOT

Using:

- tempfile.mkdtemp;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-fresh-independent-audit-`;
- umask:
  `077`.

Immediately retain:

- exact absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty opening inventory.

Require:

- directory;
- no symlink;
- mode:
  0700;
- empty before platform preflight;
- empty immediately before audit-parent creation.

This exact path instantiates the certificate’s:

FRESH_PRIVATE_AUDIT_ROOT

placeholder.

Use this exact path as:

- the `--audit-root` argument;
- the submitted cwd.

Cwd classification:

EXTERNAL_WRAPPER_NONAUTHORITATIVE_LAUNCH_CONTEXT

The absence of a certificate-level fixed cwd is not a mismatch.

The wrapper owns the submitted cwd.

The capsule must later prove runtime cwd equals this exact submitted value.

If preflight fails before audit-parent creation:

- retain the audit-root identity and empty inventory;
- remove only the wrapper-owned empty audit root;
- observe ENOENT twice;
- authorization remains unconsumed.

After audit-parent creation:

- authorization is consumed;
- preserve the audit root regardless of outcome;
- never remove or clean it in this task.

──────────────────────────────────────────────────────────────────────────────
7. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────── LIMITED TO WRAPPER CUSTODY
────────────────────────────────────────────────

Run exactly one harmless synchronous preflight.

This does not consume the audit authorization.

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

Use a program equivalent to:

import os
os.write(1, b"PLATFORM_CAPTURE_STDOUT_V1\n")
os.write(2, b"PLATFORM_CAPTURE_STDERR_V1\n")
os._exit(23)

Submitted cwd:

the exact FRESH_PRIVATE_AUDIT_ROOT

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Retain:

- exact argv;
- cwd;
- environment;
- PID;
- start/completion;
- duration;
- raw streams;
- stream sizes/hashes;
- exit/signal;
- reaping;
- descriptor closure.

Expected stdout:

- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

Expected exit:

23

Expected signal:

null

After preflight require the audit root remains empty.

If preflight or root-emptiness fails:

- do not launch the audit;
- remove the wrapper-owned empty audit root after evidence retention;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
8. EXACT REAL-AUDIT INVOCATION
──────────────────────────────────────────────── LIMITED TO SEALED CLI
────────────────────────────────────────────────

After preflight passes, require the exact argv:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v3-adopted-baseline-output-a3ffwvod/gen2-clean-source-external-independent-audit-harness-v3.pyz
--mode
run-full-audit
--harness-authority
/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v3-adopted-baseline-output-a3ffwvod/gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json
--content-bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--audit-root
<FRESH_PRIVATE_AUDIT_ROOT>

Do not substitute:

--bundle
--bundle-authority

Do not omit:

--audit-root

Do not pass launch certificate v2 to the harness unless exact current CLI
inspection contradicts the retained architecture. Current authority says it is
wrapper authority, not a harness operand.

Do not pass:

- predecessor authority;
- predecessor certificate;
- documentary roots;
- implementation root;
- historical root;
- continuation/recovery option;
- any unregistered operand.

Submitted cwd:

the exact FRESH_PRIVATE_AUDIT_ROOT

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Immediately before process creation:

- reauthenticate all five fixed files;
- reauthenticate the audit-root identity;
- require the audit root remains empty.

Launch synchronously.

Launch count:

exactly one.

The one authorized audit is consumed only when process creation succeeds.

After process creation it remains consumed regardless of terminal disposition
or later custody failure.

Do not launch:

- qualify-harness;
- replacement/recovery parent;
- continuation;
- direct auditor;
- post-failure validator;
- second audit.

──────────────────────────────────────────────────────────────────────────────
9. TOP-LEVEL PROCESS CUSTODY
──────────────────────────────────────────────── LIMITED TO EXTERNAL PLATFORM
────────────────────────────────────────────────

Retain before parsing output:

- custody ID;
- process-creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- exact cwd;
- submitted environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and hashes;
- exit code;
- signal;
- process error;
- reaping;
- descriptor closure;
- identities of all five fixed files at launch;
- audit-root identity at launch.

The platform wrapper is authoritative for top-level process creation and
completion.

The capsule may retain runtime-observed evidence and crosswalk it to platform
custody. It does not replace platform custody.

If completion capture is missing after process creation:

- do not scan for another root;
- do not retry;
- preserve the exact supplied audit root;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
10. STREAM AND TERMINAL-FRAME CONTRACT
──────────────────────────────────────────────── LIMITED TO CURRENT FROZEN CONTRACT
────────────────────────────────────────────────

Retain raw streams before parsing.

Parse them only under the exact current stream/framing contract embedded in the
final PYZ and bound by certificate v2.

Do not assume a separate locator line.

The audit root is already supplied through `--audit-root`.

Require the handled terminal frame to bind the same exact path.

Require:

- exact handled-terminal stdout posture;
- exact handled-terminal stderr posture;
- no duplicate frame;
- no trailing unframed bytes;
- strict UTF-8 JSON;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact terminal-frame schema;
- exact harness disposition;
- exact audit-root field where required;
- exact preseal, terminal, temporal, and manifest identities;
- exact seal and no-write fields.

Require equality:

terminal-frame audit root
=
submitted `--audit-root`
=
submitted cwd
=
capsule root identity

If the process exits under the exact frozen unhandled-failure posture:

- return `AUDIT_PROVENANCE_MISMATCH`;
- do not scan for an alternative root;
- preserve the exact supplied audit root unchanged;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
11. AUDIT-ROOT AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO SUPPLIED ROOT
────────────────────────────────────────────────

Use only the exact supplied FRESH_PRIVATE_AUDIT_ROOT.

Do not scan any directory.

Do not use:

- emitted alternative path;
- prefix search;
- recency;
- inode search;
- hash search;
- basename;
- score;
- historical root reuse.

Authenticate after process completion:

- exact absolute path;
- same device/inode as opening unless the exact root lifecycle permits and
  authenticates replacement;
- directory;
- no symlink;
- mode 0700;
- equality with terminal-frame references;
- capsule fresh-creation and ownership evidence.

If authentication fails:

- preserve the root unchanged;
- return `AUDIT_PROVENANCE_MISMATCH`;
- inspect no alternative path.

──────────────────────────────────────────────────────────────────────────────
12. READ-ONLY CAPSULE INSPECTION
──────────────────────────────────────────────── LIMITED TO EXACT ROOT
────────────────────────────────────────────────

Inspect only the supplied and authenticated audit root.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute implementation source;
- run another validator;
- regenerate evidence;
- add or replace a record or manifest.

Resolve authoritative capsule paths only through:

- terminal frame;
- capsule path registry;
- capsule indexes;
- manifests.

For each record retain:

- exact relative path;
- schema;
- mode;
- link count;
- size;
- SHA-256;
- authority role.

──────────────────────────────────────────────────────────────────────────────
13. PARENT SELF-AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO THREE-VIEW CROSSWALK
────────────────────────────────────────────────

Authenticate:

opening/parent-runtime-self-authentication.json

Crosswalk it against external platform custody.

Require:

- platform-declared Framework launcher identity;
- runtime `sys.executable` and `_base_executable` equal that launcher;
- `sys.orig_argv[0]` equals the governed Python.app token;
- no terminal-runtime-image role;
- no kernel-image claim;
- no role substitution;
- no path fallback;
- `sys.orig_argv[1:]` equals submitted argv tail;
- `sys.argv` equals the exact application sequence;
- runtime cwd equals submitted fresh audit root;
- runtime PID equals platform PID;
- required Python flags;
- exact executing PYZ identity;
- exact authority-v4 identity;
- exact content inputs;
- exact source freeze.

Runtime environment must preserve the five submitted variables exactly.

Permit only the governed optional:

__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0

when UID relation and zero components pass.

Reject unknown extras.

Require:

top_level_process_authority = external_platform_wrapper

Any failure is an audit-provenance finding, not a package finding.

──────────────────────────────────────────────────────────────────────────────
14. EMBEDDED DEPENDENCY ACCESS CLOSURE
──────────────────────────────────────────────── LIMITED TO 113 ROLES
────────────────────────────────────────────────

Authenticate:

- current dependency registry;
- member-role registry;
- record-class registry;
- runtime dependency-access ledger.

Require:

- exactly 113 roles;
- access set equals registry;
- every dependency resolved by semantic role;
- unique member role;
- exact path/identity;
- correct record-class parser;
- correct discriminator;
- no acceptance-bearing direct member path;
- no stale matrix-suite path;
- governed matrix resolved by role;
- bootstrap parsed by schema_version;
- no alias;
- no fallback;
- no embedded-record-unavailable;
- no missing resolver state.

A failure is audit provenance unless direct current evidence independently
establishes a package defect.

──────────────────────────────────────────────────────────────────────────────
15. PHASES, CUSTODY, REPORTS, CONFIRMATIONS, AND MATRICES
────────────────────────────────────────────────

Authenticate all P00–P24 records.

Require every phase terminal with phase-specific evidence.

Terminal does not imply passed.

Authenticate child ledger and custody.

Require all children reaped and descriptors closed.

Runtime report:

- exact R01–R66;
- exactly 66 rows;
- run-full-audit mode;
- explicit evidence;
- no blanket N/A.

Runtime confirmations:

- exact 81 names;
- exactly 81 rows;
- observed/expected/pass;
- run-full-audit mode;
- no all-true projection.

Runtime matrices:

- B00 and D01–D14;
- exactly 15;
- exactly 595 cases;
- stale 645 rejected;
- zero false outcomes, mismatches, skips, or unexpected exceptions.

Require every evidence pointer to resolve.

──────────────────────────────────────────────────────────────────────────────
16. IMPLEMENTATION AUDIT EVIDENCE
──────────────────────────────────────────────── LIMITED TO SOURCE-EXTERNAL FINDINGS
────────────────────────────────────────────────

Authenticate and report:

- content role and index closure;
- implementation attempt lineage;
- source registries;
- source freeze and requalification;
- production authority and static security;
- E00/G00–G29 crosswalk;
- documentary lifecycle and writer ownership;
- 946-case negative result;
- 137-case contradiction result;
- 766/333 field map;
- producer rehearsals;
- Attempt-2 bounded failure evidence;
- implementation confirmations;
- constructed-subject evidence domain;
- fresh behavioral causals;
- fresh source-external validation;
- security/authority closure.

Do not execute implementation source.

Separate findings:

- direct package;
- audit;
- derivative;
- mixed;
- unresolved.

A direct package blocker requires direct current evidence.

Historical prose is not authority.

──────────────────────────────────────────────────────────────────────────────
17. CLEANUP, INPUT EQUALITY, FINDINGS, AND PRESEAL RESULT
──────────────────────────────────────────────── LIMITING FINAL AUTHORITY
────────────────────────────────────────────────

Authenticate canonical cleanup rows and exact cleanup-set equality.

Equal empty sets pass.

Require no process, descriptor, cache, or bytecode survivors.

Authenticate capsule fixed-input closing equality for:

- PYZ v3;
- authority v4;
- content bundle;
- content authority.

The launch certificate is wrapper-only and is covered by wrapper opening and
closing equality.

Authenticate:

- complete findings;
- ownership;
- dependency graph;
- severity;
- first blocker;
- preseal disposition.

Preseal result remains nonauthoritative until terminal closure.

──────────────────────────────────────────────────────────────────────────────
18. TERMINAL CAPSULE CLOSURE
──────────────────────────────────────────────── LIMITED TO FINAL VERDICT
────────────────────────────────────────────────

Authenticate:

- temporal inventory;
- terminal result;
- manifest A;
- manifest B;
- terminal frame.

Require:

- immediate temporal reprojection;
- root row once;
- A/B existence and equality;
- exact manifest identities;
- independent final reprojection;
- no empty descendant;
- no symlink/special object;
- no multiply linked file;
- modes 0700/0600;
- no cache/bytecode;
- one seal transition;
- terminal marker;
- no postseal operation.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

Do not promote a preseal package disposition through failed closure.

──────────────────────────────────────────────────────────────────────────────
19. WRAPPER FIVE-FILE CLOSING EQUALITY
────────────────────────────────────────────────

After process completion, repeat stable no-follow checks for all five fixed
files.

Require exact equality with opening.

Do not mutate any fixed file.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
20. FINAL VERDICT RULES
────────────────────────────────────────────────

Report:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

only when:

- all five fixed files authenticate;
- certificate authorizes launch;
- platform custody completes;
- parent self-authentication passes;
- dependency closure passes;
- audit evidence is complete;
- no direct package blocker remains;
- preseal disposition is accept;
- exact terminal disposition is GEN2_IMPLEMENTATION_PACKAGE_ACCEPT;
- cleanup, equality, and terminal closure pass.

Scope:

- accepts only the audited Generation-2 implementation package under the
  frozen audit contract;
- does not establish current-subject correctness;
- does not establish product/runtime readiness;
- does not authorize publication, deployment, target audit, or A6.

Report:

GEN2_IMPLEMENTATION_PACKAGE_BLOCK

only when:

- provenance passes;
- at least one direct current package blocker exists;
- findings/dependencies are complete;
- preseal disposition is block;
- exact terminal disposition is GEN2_IMPLEMENTATION_PACKAGE_BLOCK;
- cleanup, equality, and terminal closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for any failure of:

- fixed inputs or certificate;
- process custody or framing;
- root authentication;
- self-authentication;
- dependency closure;
- phase/evidence completeness;
- child custody;
- report/confirmation/matrix closure;
- finding ownership;
- cleanup/equality;
- temporal/manifests/reprojection/seal;
- wrapper closing equality.

Do not retry.

──────────────────────────────────────────────────────────────────────────────
21. NO FOLLOW-ON EXECUTION
────────────────────────────────────────────────

After reporting:

- stop;
- preserve all five fixed files;
- preserve the exact audit root unchanged;
- do not clean the audit root;
- do not construct the current subject;
- do not run product modes;
- do not run target audit or runtime validation;
- do not modify a repository;
- do not commit or push;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE OPERATIVE REPORT
────────────────────────────────────────────────

Return:

1. Exact primary verdict
2. Five fixed-file identities
3. Previous wrapper-mismatch disposition
4. Stable prelaunch authentication
5. Certificate authentication
6. PYZ governance closure
7. Wrapper evidence-root identity
8. Fresh audit-root identity
9. Platform preflight
10. Exact audit argv
11. Exact cwd/environment
12. Top-level process custody
13. Raw streams
14. Exit/signal
15. Terminal frame
16. Audit-root post-run authentication
17. Parent self-authentication
18. Interpreter tuple
19. Environment crosswalk
20. Dependency-access closure
21. P00–P24
22. Child ledger/custody
23. Content closure
24. Implementation source/freeze
25. Production authority/security
26. E00/G00–G29
27. Documentary lifecycle/writers
28. Runtime matrices
29. 946 cases
30. 137 cases
31. 766/333 field map
32. Producer rehearsals
33. Attempt-2 evidence
34. Implementation confirmations
35. Constructed-subject evidence
36. Fresh causals
37. Fresh source-external validation
38. Security/authority closure
39. R01–R66
40. 81 confirmations
41. Complete findings
42. Finding ownership
43. Dependency graph
44. Severity findings
45. Preseal disposition
46. Cleanup
47. Capsule fixed-input equality
48. Wrapper five-file closing equality
49. Temporal identity
50. Manifest A
51. Manifest B
52. Final reprojection
53. Terminal topology/modes
54. Seal/marker
55. No-write result
56. Confirmation current subject not constructed
57. Confirmation no product/runtime/target/A6 activity
58. Remaining uncertainty/nonclaims
59. Explicit wrapper confirmations

Required confirmations:

FINAL_PYZ_V3_IDENTITY_MATCHED
FINAL_AUTHORITY_V4_IDENTITY_MATCHED
FINAL_LAUNCH_CERTIFICATE_V2_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
PREVIOUS_WRAPPER_MISMATCH_CLASSIFIED_AS_WRAPPER_ERROR
LAUNCH_CERTIFICATE_CURRENT_AND_COHERENT
LAUNCH_CERTIFICATE_AUTHORIZED_ONE_AUDIT
PYZ_MEMBER_SET_140_CLOSED
FRESH_PRIVATE_AUDIT_ROOT_ALLOCATED
FRESH_PRIVATE_AUDIT_ROOT_EMPTY_BEFORE_LAUNCH
AUDIT_ROOT_PLACEHOLDER_INSTANTIATED
WRAPPER_OWNED_CWD_USED
CERTIFICATE_SILENT_CWD_NOT_TREATED_AS_MISMATCH
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
CORRECT_CONTENT_BUNDLE_OPTION_USED
CORRECT_CONTENT_AUTHORITY_OPTION_USED
AUDIT_ROOT_OPTION_USED
LAUNCH_CERTIFICATE_NOT_PASSED_TO_HARNESS
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_SUPPLIED_ROOT
PARENT_RUNTIME_SELF_AUTHENTICATION_RETAINED
INTERPRETER_OBSERVATION_TUPLE_PASSED
RUNTIME_ENVIRONMENT_POLICY_PASSED
RUNTIME_CWD_EQUALS_WRAPPER_SUBMITTED_CWD
DEPENDENCY_ACCESS_SET_113_COMPLETE
DEPENDENCY_ACCESS_EQUAL_CURRENT_REGISTRY
NO_EMBEDDED_RECORD_UNAVAILABLE
NO_INSTANCE_STATE_FAILURE
CAPSULE_PRIMARY_VERDICT_REPORTED_EXACTLY
COMPLETE_RUNTIME_REPORT_RETAINED
COMPLETE_RUNTIME_CONFIRMATIONS_RETAINED
EVERY_REQUIRED_PHASE_TERMINAL
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_RESULT_RETAINED
CAPSULE_FIXED_INPUT_CLOSING_EQUALITY_RETAINED
WRAPPER_FIVE_FILE_CLOSING_EQUALITY_PASSED
TEMPORAL_INVENTORY_RETAINED
MANIFEST_A_RETAINED
MANIFEST_B_RETAINED
MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_PASSED
ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_SEAL
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Sources

The latest Codex report shows that all five fixed files and the 140-member PYZ authenticated, but the wrapper rejected the launch because it compared the task’s incorrect `--bundle`/`--bundle-authority` invocation with the sealed `--content-bundle`/`--content-authority`/`--audit-root` invocation. :chatgpt-content-reference{index="5"}

It also shows that no certificate-level cwd field exists and that the wrapper treated this silence as a second blocker. No process or audit root was created, and the authorization remains unconsumed. :chatgpt-content-reference{index="6"}

Both findings were classified as external-launch provenance findings rather than package findings. :chatgpt-content-reference{index="7"}

**Confidence:** 0.999 that the one-audit authorization remains unconsumed; 0.999 that no implementation-package conclusion exists; 0.995 that both blockers were introduced by the previous wrapper prompt rather than the sealed harness artifacts; 0.97 that instantiating the governed fresh audit-root placeholder and treating silent cwd as wrapper custody is the correct next launch path.

The latest attachment was fully readable. Some older uploaded files have expired; re-upload an older file only if a later review needs its original bytes rather than the retained identities and reports.
