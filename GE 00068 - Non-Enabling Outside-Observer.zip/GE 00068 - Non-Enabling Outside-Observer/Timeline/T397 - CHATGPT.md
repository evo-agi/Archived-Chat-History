## Assessment

This is the first clean authority-bearing milestone in this chain.

The resealed package now gives us a stable implementation target:

- **Normative contract:** `contract/package-construction-parent-v1.json`
- **Identity:** 32,038 bytes, SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`
- **Status:** `frozen-pending-implementation`
- **Implementation present:** false
- **Implementation authority:** false
- **Contract package:** `/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n`
- **Terminal manifests:** byte-identical, 17,596 bytes, SHA-256 `a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2`
- **Supplied-root equality:** genuinely passed under canonical `(role_id, absolute_path)` matching.
- **Normative contract and all 15 schemas:** preserved byte-for-byte.
- **No implementation exists yet.**

We should now implement the construction parent from scratch, bound to this exact contract. The next tranche should **not execute `construct` mode** and should not build the real target-audit harness package. It should implement the complete source, run only `process-self-test`, validate the construction state machine through static and synthetic audit-owned tests, freeze the source, and prepare it for a fresh independent audit.

That prevents another premature package-build attempt while still testing the implementation meaningfully.

Forward this prompt to Codex:

```text
IMPLEMENT AND QUALIFY THE VALIDATION-CUSTODY V3
TARGET-AUDIT HARNESS PACKAGE-CONSTRUCTION PARENT
FROM THE FROZEN NORMATIVE CONTRACT

This task implements a new source-external construction parent from the exact
frozen normative contract.

It is a new bounded implementation, not a repair of a historical source.

It does not:

- execute construct mode;
- construct a target-audit harness package;
- run the real target audit;
- execute Plan V3 or Plan V4;
- rerun repository or product validation;
- modify any repository;
- deploy, publish, externally commit, or start A6.

Do not use any historical partial utility or failed construction-parent source
as the implementation basis.

Do not reinterpret, amend, normalize, or replace the normative contract.

Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTED_READY_FOR_FRESH_AUDIT
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED
IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. AUTHORITATIVE CONTRACT PACKAGE
──────────────────────────────────────────────────────────────────────────────

CONTRACT_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected root identity:

- device:
  16777234
- inode:
  180472094
- mode:
  0700

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19
- status:
  frozen-pending-implementation
- sole normative writer:
  true
- implementation present:
  false
- implementation authority:
  false

Expected temporal inventory:

closeout/temporal-final-inventory-v2.json

- size:
  17739
- SHA-256:
  e65b511f4c6fb69be9a14a4702ee32d2e1b670db04f4058b398fcf36d662f0f1

Expected terminal manifests:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- size:
  17596 each
- SHA-256:
  a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2
- byte-identical:
  required

Authenticate and independently reproject the complete contract package before
creating implementation source.

The normative contract is the sole authority for implementation semantics.

The following are evidence and projections only:

- builder V2;
- mutation-matrix results;
- independent-validator results;
- perspectives;
- reports;
- temporal inventories;
- manifests.

They may explain and validate the contract but may not redefine it.

──────────────────────────────────────────────────────────────────────────────
2. IMPLEMENTATION SEAM
──────────────────────────────────────────────────────────────────────────────

Classify this task as:

NEW_BOUNDED_SOURCE_EXTERNAL_IMPLEMENTATION

The implementation must be authored from the frozen contract and source
architecture.

It is not derived from:

- the 11,872-byte historical utility fragment;
- a failed retry parent;
- an earlier bootstrap implementation;
- a package-builder implementation;
- a target-audit payload.

Historical source roots may be opened only for lineage when the normative
contract explicitly requires their identity. They may not provide executable
code or implementation authority.

The implementation package must record:

- governing contract identity;
- governing schema identities;
- source-architecture identity;
- implementation seam classification;
- historical source non-use.

──────────────────────────────────────────────────────────────────────────────
3. FRESH IMPLEMENTATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-implementation-

Immediately emit:

IMPLEMENTATION_ROOT=<absolute-path>

Retain before implementation work:

opening/bootstrap-start.json

Bind:

- fresh-root device/inode/mode;
- allocation method and umask;
- contract-package identity;
- normative-contract identity;
- implementation-source architecture identity;
- implementation authority:
  bounded-source-external;
- construct mode execution authorized:
  false;
- package construction authorized:
  false;
- real target audit authorized:
  false;
- repository mutation authorized:
  false;
- runtime validation rerun:
  false.

Create directories lazily.

Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
4. COPY THE GOVERNING CONTRACT SURFACE
──────────────────────────────────────────────────────────────────────────────

Copy byte-for-byte into the implementation package:

- contract/package-construction-parent-v1.json;
- all 15 governing schemas;
- analysis/implementation-source-architecture-v1.json;
- the contract/schema field map;
- the phase/state-machine projection when separately retained;
- the package-output registry projection when separately retained.

Use:

- no-follow source opens;
- stable pre/post-read fstat;
- exclusive mode-0600 destination creation;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/governing-contract-copy-v1.json

Require:

- normative contract byte-identical;
- all schemas byte-identical;
- source architecture byte-identical;
- no stale predecessor package path used as current implementation authority.

──────────────────────────────────────────────────────────────────────────────
5. IMPLEMENTATION SOURCE
──────────────────────────────────────────────────────────────────────────────

Create exactly one production implementation source:

source/package_construction_parent_v1.py

Use Python standard library only unless the normative contract explicitly
requires otherwise.

The source must implement the complete contract, including:

- strict contract and schema loading;
- source/contract self-authentication;
- exact CLI handling;
- `process-self-test` mode;
- `construct` mode;
- executable-origin registry;
- registry freeze;
- pinned-Python enforcement;
- child-process recorder;
- fixed-output attribution;
- dynamic-root locator attribution;
- cache-root attribution;
- cleanup registry;
- supplied-root authentication;
- six-export byte-exact copying;
- root-bound plan generation;
- generated metadata;
- RFC 6901 pointer resolution;
- qualification coordination;
- synthetic qualification fixtures;
- export freeze;
- metadata coherence;
- frozen-package requalification;
- historical lineage;
- package immobility;
- supplied-root closing equality;
- temporal inventory;
- two independent terminal-manifest generators;
- terminal seal;
- truthful failure closeout.

The implementation must contain all twenty construct phases in the exact
contract order:

C00_SELF_AUTHENTICATE
C01_PROCESS_PROVENANCE_GATE
C02_OPEN_FIXED_INPUTS
C03_ALLOCATE_FINAL_PACKAGE_ROOT
C04_COPY_SIX_UNCHANGED_EXPORTS
C05_GENERATE_ROOT_BOUND_PLAN
C06_GENERATE_CLEAN_METADATA
C07_VALIDATE_TRANSITIVE_POINTERS
C08_RUN_CURRENT_QUALIFICATION
C09_RETAIN_QUALIFICATION_RESULT
C10_FREEZE_EXPORTS
C11_POSTFREEZE_METADATA_COHERENCE
C12_FROZEN_PACKAGE_REQUALIFICATION
C13_RETAIN_LINEAGE_AND_IMMOBILITY
C14_PROCESS_AND_FIXTURE_CLEANUP
C15_SUPPLIED_ROOT_CLOSING_EQUALITY
C16_FINALIZE_NONMANIFEST_OUTPUTS
C17_TEMPORAL_FINAL_INVENTORY
C18_TERMINAL_MANIFEST_CLOSURE
C19_TERMINAL_SEAL

Do not remove, merge, reorder, or silently short-circuit phases.

Every phase implementation must expose, in source or immutable metadata:

- phase ID;
- prerequisites;
- operands;
- outputs;
- commit point;
- pass condition;
- failure condition;
- continuation rule;
- cleanup obligations;
- authority contribution.

──────────────────────────────────────────────────────────────────────────────
6. IMPLEMENTATION AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

The source may own only the exact contract-authorized custody and construction
facts.

It must not claim or implement authority over:

- repository truth;
- target-audit semantic intent;
- Validation-Custody V3 semantics;
- V2 evidence meaning;
- product or runtime behavior;
- deployment;
- publication;
- external Git commit;
- readiness;
- target-audit verdict;
- semantic-successor implementation;
- orchestration;
- A6.

Every prohibited authority must remain explicit false in generated records.

No generated report, trace, log, manifest, validator output, or chat response
may become hidden execution or package truth.

──────────────────────────────────────────────────────────────────────────────
7. EXACT CLI
──────────────────────────────────────────────────────────────────────────────

Implement exactly two modes:

--mode process-self-test
--mode construct

There is no default.

Missing or unknown mode must reject before semantic input inspection.

Pinned interpreter:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Required options for every Python invocation:

-I
-S
-B

as separate argv values in that order.

Implement the contract-defined exit classes:

- success;
- CLI failure;
- semantic failure;
- provenance failure;

using the exact contract values.

Do not invent an additional production mode.

Qualification behavior must live in separate audit-owned harnesses or
`process-self-test`, not an additional production CLI mode.

──────────────────────────────────────────────────────────────────────────────
8. PROCESS-SELF-TEST MODE
──────────────────────────────────────────────────────────────────────────────

`process-self-test` must:

- never open semantic package input roots;
- never allocate the final package root;
- never enter any C00–C19 construct phase;
- never write semantic exports;
- exercise process custody only.

It must execute the contract-required bounded causals, including at minimum:

1. missing executable / ENOENT;
2. `/usr/bin/true`;
3. pinned Python version;
4. registered fresh Python helper;
5. unregistered executable rejection;
6. historical-root executable rejection;
7. unpinned Python rejection;
8. missing `-I`;
9. missing `-S`;
10. missing `-B`;
11. wrong Python-option order;
12. fixed-output attribution;
13. dynamic-root success attribution;
14. dynamic-root nonzero attribution;
15. invalid-locator rejection;
16. timeout with complete custody;
17. duplicate-ordinal rejection;
18. missing-prelaunch rejection;
19. incomplete-stream rejection;
20. direct-process-bypass rejection;
21. cache-root attribution and cleanup;
22. process-survivor rejection;
23. descriptor-survivor rejection;
24. construction-branch reachability rejection.

Retain a complete self-test result and child-process ledger.

──────────────────────────────────────────────────────────────────────────────
9. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Implement the exact top-level and child-process authority split.

Every child must have:

- exclusive prelaunch record written and fsynced before spawn;
- registered executable origin;
- exact argv;
- cwd;
- explicit environment;
- timeout;
- stdin posture;
- stream posture;
- fixed output declarations;
- dynamic output contract;
- prelaunch path observations;
- exact stdout;
- exact stderr;
- process-created or spawn-exception state;
- PID when created;
- exit or signal;
- timeout state;
- reaping;
- descriptor closure;
- fixed-path post-state;
- dynamic locators;
- paths written;
- complete dynamic-root inventories;
- cleanup registrations;
- first blocker;
- disposition.

Require contiguous ordinals with no gaps or duplicates.

No process may bypass the recorder.

No process source may be selected by basename, prefix, recency, scoring, latest
entry, or fallback.

──────────────────────────────────────────────────────────────────────────────
10. FILESYSTEM-EFFECT ATTRIBUTION
──────────────────────────────────────────────────────────────────────────────

Implement fixed-output and dynamic-root attribution.

Dynamic-root contracts must freeze:

- exact permitted parent;
- exact basename prefix;
- exact full-match stdout locator grammar;
- exact locator count;
- type and mode requirements.

Parse dynamic locators on:

- exit 0;
- nonzero exit;
- timeout;
- later parse failure.

For a valid locator:

- retain exact locator bytes;
- lstat exact path;
- verify direct parent and prefix;
- retain root identity and complete no-follow inventory;
- append to `paths_written`;
- append to cleanup registry.

If dynamic root creation may have occurred but no unique valid locator is
available, the result is provenance-fatal.

No directory scan, prefix scan, latest selection, scoring, guessing, or
fallback is permitted.

──────────────────────────────────────────────────────────────────────────────
11. CLEANUP
──────────────────────────────────────────────────────────────────────────────

Construct cleanup registries only from:

- validated dynamic locators;
- declared fixed fixture roots;
- declared cache roots.

For every cleanup root:

1. retain complete pre-removal inventory;
2. require originating process reaped;
3. require descriptors closed;
4. re-lstat and require original device/inode and permitted parent;
5. remove only that exact root;
6. perform two fresh lstat calls;
7. require ENOENT twice.

Require exact set equality:

created roots
=
inventoried roots
=
cleanup rows
=
twice-absent roots

No administrative continuation is permitted after self-test or construct mode.

──────────────────────────────────────────────────────────────────────────────
12. RAW POSTURE AND POSITIVE ASSERTIONS
──────────────────────────────────────────────────────────────────────────────

Implement the contract’s qualification evidence model.

Raw posture:

`payload_imported: false`

Positive assertion:

`payload_imported_is_false: true`

Require exact Boolean types.

Qualification success may aggregate only the positive assertion registry.

Do not place raw posture values in the assertion map.

Do not call `all(...)` over raw posture.

Reject:

- missing raw field;
- integer zero;
- string `"false"`;
- raw true;
- missing assertion;
- wrong assertion name;
- raw false placed directly in assertion map;
- direct aggregation of raw posture.

──────────────────────────────────────────────────────────────────────────────
13. METADATA AND POINTER COHERENCE
──────────────────────────────────────────────────────────────────────────────

Implement exactly four current acceptance-bearing plan-identity consumers:

1. `contract/package-root-rebinding-v2.json`
   pointer:
   `/successor_plan_identity`

2. `opening/current-export-registry-v2.json`
   pointer:
   `/exports/target-audit-plan`

3. `validation/current-qualification-result-v2.json`
   pointer:
   `/plan_identity`

4. `opening/target-audit-harness-package-freeze-v3.json`
   pointer:
   `/plan_identity`

Resolve every pointer token by token using RFC 6901 against the actual current
document.

Require every resolved object to contain exactly:

- path;
- sha256;
- size.

Require exact equality with the current plan identity.

Copied-ledger equality is insufficient.

No unregistered current acceptance-bearing consumer may exist.

──────────────────────────────────────────────────────────────────────────────
14. SUPPLIED-ROOT EQUALITY
──────────────────────────────────────────────────────────────────────────────

Use canonical supplied-root pairing by:

(role_id, absolute_path)

Display labels are nonauthoritative diagnostics.

Require:

- exact opening/closing canonical-key sets;
- exact physical identity equality;
- exact inventory/content equality;
- no duplicate or ambiguous role/path mapping.

Generate confirmation values only through the evidence map.

`SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED` must be derived from:

closing/supplied-root-closing-equality-v2.json#/pass

with exact Boolean type and value true.

No hard-coded confirmation success.

──────────────────────────────────────────────────────────────────────────────
15. TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Implement the exact contract-defined closure:

- premanifest empty-directory policy;
- reserved `manifest/` handling;
- temporal inventory;
- two independent manifest generators;
- byte-identical generated outputs;
- exclusive A/B writes;
- file and directory fsync;
- no-follow read-back;
- identity verification;
- whole-root independent reprojection;
- terminal empty-directory/type/mode/link/cache checks;
- unique terminal-seal transition;
- no filesystem read or write after seal;
- guarded terminal marker;
- immediate nonreturning success exit.

No package authority exists before terminal closure.

Failure before seal must retain a truthful unsealed failure result without a
success caption.

──────────────────────────────────────────────────────────────────────────────
16. SOURCE/CONTRACT IMPLEMENTATION MAP
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/source-contract-implementation-map-v1.json

Classify every one of the 766 normative contract leaves as exactly one:

- implemented in source;
- enforced by schema;
- fixed input invariant;
- generated-record invariant;
- explicit nonauthority;
- documentary-only projection;
- not applicable to implementation, with reason.

For every implementation-bearing leaf retain:

- contract JSON pointer;
- source file;
- source function;
- source range;
- owner;
- consumer;
- test surface.

Require:

- 766/766 classified;
- no unresolved leaf;
- no two authoritative writers for one mutable fact;
- no implementation behavior without a governing contract pointer.

──────────────────────────────────────────────────────────────────────────────
17. PRODUCTION SOURCE SECURITY
──────────────────────────────────────────────────────────────────────────────

Production source must contain no:

- network access;
- Git invocation;
- shell execution;
- broad `/Users/ds/Downloads` traversal;
- prefix/latest/score selection;
- existing-root adoption;
- symlink-following input traversal;
- overwrite fallback;
- hidden target execution;
- production-reachable fault-injection hook;
- dynamic import of qualification helpers;
- import-time filesystem or process activity.

Use source-aware AST and dataflow analysis.

Classify qualification-only helpers separately.

Do not treat contract classification strings as operational paths or sinks.

──────────────────────────────────────────────────────────────────────────────
18. QUALIFICATION HARNESS
──────────────────────────────────────────────────────────────────────────────

Create a separate audit-owned qualification harness under:

validation/

It is not a production dependency.

It may:

- load the production module only after import-time side-effect checks pass;
- use audit-owned fixtures;
- replace side-effect adapters through external monkeypatching;
- inject failures through qualification-only wrappers;
- run pure state-machine functions;
- validate generated records;
- exercise process-self-test.

It may not:

- create a production-reachable fault hook;
- alter production source;
- execute construct mode against real inputs;
- inspect the real target;
- claim implementation authority.

Retain exact harness identity and role.

──────────────────────────────────────────────────────────────────────────────
19. STATIC IMPLEMENTATION GATES
──────────────────────────────────────────────────────────────────────────────

Before executing production source:

1. compile using pinned Python and `-I -S -B`;
2. verify no import-time side effects;
3. parse AST;
4. build call graph;
5. locate every process creation;
6. require all child execution through recorder;
7. locate every filesystem sink;
8. require ownership and no-follow rules;
9. verify explicit mode split;
10. prove self-test cannot reach construct;
11. prove construct cannot run without process qualification;
12. verify phase order C00–C19;
13. verify no postseal filesystem operation;
14. verify failure path cannot write after seal;
15. verify no direct authority widening.

Use two independent analyses:

- AST/call-graph/dataflow;
- bytecode/exception-table CFG.

Require agreement.

──────────────────────────────────────────────────────────────────────────────
20. PROCESS-SELF-TEST EXECUTION
──────────────────────────────────────────────────────────────────────────────

Before execution:

- retain exact source;
- freeze exact source identity;
- retain executable-origin registry;
- freeze executable registry;
- retain process contracts;
- retain self-test case registry.

Then invoke the exact frozen source once:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<IMPLEMENTATION_ROOT>/source/package_construction_parent_v1.py
--mode
process-self-test

Use:

- finite noninteractive top-level carrier;
- DEVNULL stdin;
- explicit environment;
- no later input;
- no replacement parent.

Retain platform-authoritative:

- argv;
- cwd;
- environment;
- PID when exposed;
- raw stdout/stderr;
- exit/signal;
- duration.

Require exit 0.

Do not execute construct mode.

──────────────────────────────────────────────────────────────────────────────
21. PROCESS-ENVELOPE MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a literal matrix covering at minimum:

- unregistered executable;
- historical executable;
- executable identity drift;
- registry mutation after freeze;
- unpinned Python;
- missing/reordered `-I -S -B`;
- missing prelaunch;
- duplicate ordinal;
- missing stream;
- unreaped child;
- open descriptor;
- omitted fixed output;
- omitted dynamic root;
- wrong parent/prefix;
- invalid or multiple locator;
- extra locator output;
- nonzero-exit root omitted;
- timeout effect omitted;
- cleanup row omitted;
- one ENOENT missing;
- process survivor;
- cache survivor;
- direct process bypass;
- self-test enters construct;
- construct runs without process qualification.

Require exact unique names, two-way closure, and zero false acceptance, false
rejection, reason mismatch, or skip.

──────────────────────────────────────────────────────────────────────────────
22. CONSTRUCTION-STATE-MACHINE QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Do not execute top-level construct mode.

Using the separate audit-owned harness and pure or adapter-isolated production
functions, exercise:

- all twenty phases;
- exact prerequisite graph;
- exact phase ordering;
- each phase’s commit point;
- each phase’s failure disposition;
- each phase’s cleanup obligation;
- authority contribution;
- same-root retry rejection;
- failed-root resume rejection;
- historical-tooling rejection;
- partial-output nonpromotion;
- terminal seal ordering.

Create mutations for:

- missing phase;
- reordered phase;
- duplicate phase;
- skipped qualification;
- freeze before qualification;
- pointer validation after freeze omitted;
- cleanup after closing equality omitted;
- temporal inventory omitted;
- one manifest omitted;
- seal before manifests;
- write after seal;
- success before closure;
- failure capsule claiming success.

Require zero false outcomes.

Do not create a real target-audit harness package.

──────────────────────────────────────────────────────────────────────────────
23. OUTPUT AND RECORD VALIDATION
──────────────────────────────────────────────────────────────────────────────

Using audit-owned fixtures, validate every generated-record schema and exact
field map, including:

- executable-origin registry;
- child process;
- phase records;
- package-root rebinding;
- current export registry;
- plan-identity consumer registry;
- pointer resolution;
- qualification result;
- package freeze;
- metadata coherence;
- cleanup;
- failure outcome;
- temporal inventory;
- terminal manifest metadata.

Require unknown, missing, mistyped, stale, contradictory, duplicated, or
premature-authority data to reject.

──────────────────────────────────────────────────────────────────────────────
24. INDEPENDENT IMPLEMENTATION VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a fresh validator that imports neither:

- producer qualification helpers;
- producer mutation fixtures;
- producer expected-result maps.

It must independently:

- authenticate contract and source;
- reconstruct source/contract mapping;
- inspect CLI and mode split;
- inspect process routing;
- inspect phase graph;
- inspect record schemas;
- inspect pointer consumers;
- inspect authority boundaries;
- inspect closure control flow;
- validate process-self-test ledger;
- run its own literal mutation registry.

Retain:

validation/independent-implementation-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
25. NO CONSTRUCT MODE
──────────────────────────────────────────────────────────────────────────────

Do not invoke:

--mode construct

Do not allocate the real final target-audit harness package root.

Do not copy the seven real semantic exports into a new current harness package.

Do not run Carrier 0003 against the real target.

Do not invoke the real direct finalizer.

Do not produce a target-audit verdict.

This implementation package is ready only for a fresh independent
implementation audit.

──────────────────────────────────────────────────────────────────────────────
26. IMPLEMENTATION FREEZE
──────────────────────────────────────────────────────────────────────────────

After all producer qualification passes, freeze:

source/package_construction_parent_v1.py

Retain:

opening/package-construction-parent-implementation-freeze-v1.json

Bind:

- implementation source identity;
- normative contract identity;
- schema identities;
- source/contract map;
- static-check identities;
- process-self-test identity;
- state-machine qualification;
- output-record qualification;
- security review;
- producer matrix;
- independent validator;
- construct mode executed:
  false;
- later modification permitted:
  false.

Reopen source no-follow and verify exact identity.

No source change is permitted afterward.

──────────────────────────────────────────────────────────────────────────────
27. FROZEN IMPLEMENTATION REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source:

- recompile;
- rerun both static checks;
- rerun process-envelope matrix;
- independently validate the actual self-test ledger;
- rerun state-machine qualification;
- rerun output/schema qualification;
- rerun independent implementation validator;
- verify contract/source mapping;
- verify no construct execution;
- verify no semantic export package exists;
- verify no cache or bytecode.

Retain:

validation/frozen-implementation-requalification-v1.json

Any mismatch requires:

IMPLEMENTATION_PROVENANCE_MISMATCH

Do not edit frozen source.

──────────────────────────────────────────────────────────────────────────────
28. IMPLEMENTATION-PACKAGE CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

At minimum:

- authoritative contract package.

If historical roots are opened for lineage, include them.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every implementation-owned fixture/cache root:

- retain pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
29. INLINE REPORT AND RETAINED REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete substantive report inline.

Do not place the full report only in a retained file.

A retained report may mirror the inline report but is supplemental.

Finalize before temporal inventory:

closeout/final-implementation-report-v1.md
closeout/explicit-confirmations-v1.json

The report must distinguish:

- contract-validated current facts;
- implementation facts;
- qualification evidence;
- nonclaims;
- construct mode not executed;
- fresh independent audit still required.

──────────────────────────────────────────────────────────────────────────────
30. IMPLEMENTATION-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final:

1. Generate temporal final inventory.
2. Verify it.
3. Create reserved manifest directory.
4. Independently generate A and B.
5. Require generated bytes identical.
6. Exclusively write/fsync/close A and B.
7. Fsync manifest directory.
8. Reopen both no-follow.
9. Verify identities and byte equality.
10. Independently reproject whole root.
11. Require no empty directory.
12. Require no symlink, special object, or multi-link file.
13. Require directories 0700 and files 0600.
14. Require no cache or bytecode.
15. Perform no write after closure.

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTED_READY_FOR_FRESH_AUDIT

only when:

- contract package authenticates and closes;
- source is newly implemented from the contract;
- source/contract map closes;
- implementation authority remains bounded;
- process envelope closes;
- process-self-test passes;
- process matrix passes;
- static analyses agree;
- construction state-machine qualification passes;
- output/schema qualification passes;
- security review passes;
- independent implementation validator passes;
- source freezes;
- frozen requalification passes;
- construct mode never executes;
- no harness package is constructed;
- supplied roots close equal;
- implementation package seals terminally.

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED

when:

- the contract is insufficient to implement a required behavior;
- two valid implementations would require an unresolved semantic decision;
- implementation requires contract or schema change;
- process, state-machine, or terminal semantics cannot be implemented without
  widening authority;
- producer qualification finds a concrete implementation defect that cannot be
  repaired within the frozen contract.

Return:

IMPLEMENTATION_PROVENANCE_MISMATCH

for:

- contract-package mutation or mismatch;
- supplied-root closing inequality;
- historical source used as implementation authority;
- unauthorized contract drift;
- unregistered or unpinned process;
- incomplete child ledger;
- cleanup-set inequality;
- frozen-source drift;
- implementation-package closure failure;
- any write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh implementation-root identity
3. Authoritative contract-package identity
4. Normative contract identity
5. Schema identities
6. New implementation seam classification
7. Governing contract copy result
8. Production source identity
9. Source architecture
10. Source/contract implementation map
11. Authority and nonauthority implementation
12. CLI implementation
13. Process-envelope implementation
14. Child-process recorder
15. Filesystem-effect attribution
16. Cleanup implementation
17. Raw-posture/assertion implementation
18. Pointer-coherence implementation
19. Supplied-root equality implementation
20. C00–C19 implementation
21. Terminal-seal implementation
22. Production security findings
23. Qualification-harness identity and role
24. Static check A
25. Static check B
26. Exact process-self-test invocation
27. Platform process custody
28. Process-self-test result
29. Child-ledger identity and continuity
30. Process-envelope mutation matrix
31. Construction-state-machine qualification
32. Output/schema qualification
33. Independent implementation validator
34. Implementation freeze identity
35. Frozen implementation requalification
36. Confirmation construct mode did not execute
37. Confirmation no harness package was constructed
38. Supplied-root closing equality
39. Fixture/cache cleanup
40. Temporal inventory identity
41. Manifest A identity
42. Manifest B identity
43. Independent terminal reprojection
44. Terminal membership and modes
45. No-write-after-closure
46. Remaining uncertainty and nonclaims
47. Explicit confirmations

Required confirmations:

AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_IDENTITY_MATCHED
NORMATIVE_CONTRACT_BYTES_COPIED_EXACTLY
ALL_SCHEMA_BYTES_COPIED_EXACTLY
NEW_BOUNDED_IMPLEMENTATION_SEAM_USED
HISTORICAL_PARTIAL_SOURCE_NOT_USED
HISTORICAL_FAILED_TOOLING_NOT_EXECUTED
PRODUCTION_SOURCE_IMPLEMENTED_FROM_FROZEN_CONTRACT
SOURCE_CONTRACT_IMPLEMENTATION_MAP_COMPLETE
ALL_766_CONTRACT_LEAVES_CLASSIFIED
ONE_AUTHORITATIVE_WRITER_PER_MUTABLE_FACT
IMPLEMENTATION_AUTHORITY_SCOPE_CLOSED
IMPLEMENTATION_NONAUTHORITY_SCOPE_CLOSED
EXACT_PROCESS_SELF_TEST_AND_CONSTRUCT_MODES
CONSTRUCT_MODE_NOT_EXECUTED
PROCESS_SELF_TEST_MODE_EXECUTED
PROCESS_SELF_TEST_PASSED
EXECUTABLE_ORIGIN_REGISTRY_FROZEN
ALL_CHILDREN_ROUTED_THROUGH_RECORDER
PRELAUNCH_RECORD_BEFORE_EVERY_SPAWN
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
CHILD_STREAMS_COMPLETE
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
FIXED_OUTPUT_EFFECTS_ATTRIBUTED
DYNAMIC_ROOT_EFFECTS_ATTRIBUTED
NONZERO_EXIT_EFFECTS_ATTRIBUTED
NO_BROAD_ROOT_DISCOVERY
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
RAW_POSTURE_SEPARATE_FROM_POSITIVE_ASSERTIONS
PAYLOAD_IMPORTED_RAW_FALSE_PRESERVED
PAYLOAD_IMPORTED_IS_FALSE_ASSERTION_TRUE
RFC6901_POINTER_RESOLUTION_IMPLEMENTED
EXACTLY_FOUR_CURRENT_PLAN_IDENTITY_CONSUMERS
DISPLAY_LABELS_NONAUTHORITATIVE
SUPPLIED_ROOT_EQUALITY_CONFIRMATION_EVIDENCE_DERIVED
ALL_TWENTY_CONSTRUCTION_PHASES_IMPLEMENTED
CONSTRUCTION_PHASE_ORDER_EXACT
TERMINAL_SEAL_STATE_UNIQUE
NO_POSTSEAL_FILESYSTEM_ACTIVITY
PRODUCTION_NETWORK_ACCESS_ABSENT
PRODUCTION_GIT_INVOCATION_ABSENT
PRODUCTION_SHELL_EXECUTION_ABSENT
PRODUCTION_REACHABLE_FAILURE_HOOK_ABSENT
STATIC_IMPLEMENTATION_CHECK_A_PASSED
STATIC_IMPLEMENTATION_CHECK_B_PASSED
PROCESS_ENVELOPE_MUTATION_MATRIX_PASSED
CONSTRUCTION_STATE_MACHINE_QUALIFICATION_PASSED
OUTPUT_SCHEMA_QUALIFICATION_PASSED
INDEPENDENT_IMPLEMENTATION_VALIDATOR_PASSED
FINAL_IMPLEMENTATION_SOURCE_FROZEN
FINAL_IMPLEMENTATION_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_IMPLEMENTATION_REQUALIFICATION_PASSED
TARGET_AUDIT_HARNESS_PACKAGE_NOT_CONSTRUCTED
REAL_TARGET_AUDIT_NOT_EXECUTED
RUNTIME_VALIDATION_NOT_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_CACHE_OR_BYTECODE_RETAINED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_CREATED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
IMPLEMENTATION_PACKAGE_MANIFEST_A_CREATED
IMPLEMENTATION_PACKAGE_MANIFEST_B_CREATED
IMPLEMENTATION_PACKAGE_MANIFESTS_BYTE_IDENTICAL
IMPLEMENTATION_PACKAGE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After
`TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTED_READY_FOR_FRESH_AUDIT`,
run a fresh independent source-external audit of the implementation package.
Do not execute construct mode until that audit accepts the implementation.

```

**Source:** Codex’s `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED` report in the current turn.  
**Confidence:** 0.995 that the contract package is now the correct implementation baseline; 0.98 that implementation can proceed without another contract tranche; 0.97 that construct mode should remain unexecuted until a fresh independent implementation audit.
