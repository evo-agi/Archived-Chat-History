## Engineering assessment

The wrapper was right not to launch. This is a **final external launch-authority packaging defect**, not a harness-source defect and not an implementation-package finding.

All four fixed files authenticated, the PYZ’s 124-member closure passed, and the content bundle retained its exact 479-member/eight-role authority. No process was created, so the one authorized audit remains unconsumed.

The current gap is that authority v3 does not carry enough post-package evidence to serve as a standalone external launch authorization:

- It does not establish deterministic PYZ Build-A/Build-B equality.
- `post_package_qualification.authority_v3_validated` is explicitly `false`.
- It does not bind frozen-PYZ requalification.
- It does not provide the exact stdout/stderr framing contract needed by the wrapper.
- The PYZ does not embed the named post-package qualification, authority validation, and frozen-requalification artifacts.

This does **not** imply that the PYZ should have embedded evidence created only after the PYZ itself was built. That requirement is structurally circular. Likewise, authority v3 cannot contain proof of an independent validator evaluating authority v3’s final bytes without another layer of authority.

### Correct authority split

Keep both existing files unchanged:

- **PYZ v2** remains the executable package.
- **Authority v3** remains the authority file consumed by the harness through `--harness-authority`.

Add one final, source-external layer:

- **External launch certificate v1** becomes the wrapper’s launch authorization.

The certificate must bind:

- the exact unchanged PYZ v2;
- the exact unchanged authority v3;
- deterministic replay-build equality for the PYZ;
- one fresh `qualify-harness` execution against those exact bytes;
- complete top-level process custody;
- frozen-source and source-registry closure;
- all governed aggregates and qualification lanes;
- an exact extracted stdout/stderr framing contract;
- a source-external independent evidence validation result;
- the exact future `run-full-audit` invocation;
- authorization for exactly one future audit.

The certificate should **not** be passed to the harness. The future wrapper authenticates the certificate, then launches the existing CLI with authority v3.

This avoids both failure modes:

- no PYZ rebuild or source repair;
- no self-referential requirement that a final authority embed a validator result about its own final bytes.

After the certificate is created, the fresh audit will use five fixed files:

1. PYZ v2;
2. authority v3;
3. external launch certificate v1;
4. current content bundle;
5. current content authority JSON.

---

## Complete replacement Codex prompt

```text
CREATE A FINAL SOURCE-EXTERNAL LAUNCH CERTIFICATE FOR THE
UNCHANGED GENERATION-2 CLEAN AUDIT HARNESS

DETERMINISTIC PYZ REPLAY, FRESH QUALIFICATION, AND EXTERNAL
POST-PACKAGE AUTHORITY CLOSURE

Objective

Create one final external launch-certificate JSON for the existing, unchanged
harness PYZ v2 and its unchanged runtime authority v3.

The latest launch wrapper correctly refused to create the audit parent because
authority v3, by itself, does not bind all post-package evidence needed by the
external wrapper:

- deterministic final PYZ Build-A/Build-B equality was not established by
  authority v3;
- `post_package_qualification.authority_v3_validated` is false;
- frozen-PYZ requalification is not bound;
- the exact stdout/stderr framing contract is not externally bound;
- named post-package qualification artifacts are not embedded in the PYZ.

Do not repair or rebuild harness source.

Do not modify or repackage the PYZ.

Do not modify authority v3.

Do not create authority v4.

Do not require the PYZ to embed evidence generated only after the PYZ was
created.

Do not require the launch certificate to embed a validator result about the
launch certificate’s own final bytes.

Instead, create a separate final external launch certificate that binds all
post-package evidence required by the wrapper.

The existing authority split after success will be:

1. PYZ v2
   - immutable executable package;

2. authority v3
   - immutable runtime harness authority consumed by:
     `--harness-authority`;

3. external launch certificate v1
   - immutable source-external authorization consumed by the audit wrapper
     before process creation.

Do not execute the real audit in this task.

Do not run `run-full-audit`.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the current schema subject.

Do not open original contaminated package directories.

Do not open historical harness, verifier, repair, builder, or audit roots except
the exact latest prelaunch-wrapper evidence root if explicitly needed and
authenticated through the exact paths given below.

Do not perform another historical package-findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned source-external certificate build in one fresh
private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_CREATED_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_BLOCKED

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT FIXED INPUTS
──────────────────────────────────────────────────────────────────────────────

UNCHANGED_HARNESS_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz

Expected identity:

- device:
  16777234
- inode:
  182181777
- mode:
  0400
- link count:
  1
- size:
  2822218
- SHA-256:
  2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2

UNCHANGED_HARNESS_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Expected identity:

- device:
  16777234
- inode:
  182181917
- mode:
  0400
- link count:
  1
- size:
  7193
- SHA-256:
  349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

The containing directories are nonauthoritative.

Do not inspect or depend on unrelated directory members.

──────────────────────────────────────────────────────────────────────────────
2. LATEST PRELAUNCH-FAILURE DISPOSITION
──────────────────────────────────────────────────────────────────────────────

The latest wrapper retained evidence beneath:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-wrapper-VZ44d2

This root is optional historical wrapper evidence only.

If it still exists:

- open only this exact path;
- do not scan for it;
- retain its observed root identity;
- authenticate these exact named records:

  operative-report-v1.json
  prelaunch-fixed-input-authentication-v1.json
  prelaunch-authority-and-pyz-closure-v1.json
  closing-fixed-input-equality-v1.json
  wrapper-confirmations-v1.json

- require complete opening/closing equality;
- do not execute any retained file;
- do not modify or clean the root.

Authenticate the historical findings:

- verdict:
  AUDIT_PROVENANCE_MISMATCH;
- audit parent launch count:
  0;
- future audit authorization consumed:
  false;
- PYZ fixed identity:
  passed;
- authority-v3 fixed identity:
  passed;
- content bundle/content authority:
  passed;
- 124-member PYZ closure:
  passed;
- first blocker:
  `AUTHORITY_V3_DETERMINISTIC_PYZ_A_B_EQUALITY_ESTABLISHED`;
- authority-v3 external validation:
  not established;
- frozen-PYZ requalification binding:
  absent;
- exact stream/framing contract:
  absent from external launch authority;
- real audit:
  not executed.

If the root is absent:

- do not search for it;
- retain the findings above as user-supplied historical wrapper disposition;
- independently reproduce every current launch-authority predicate from the
  four fixed files.

Classify the latest wrapper result as:

historical_noncurrent_prelaunch_authority_incomplete

It is not harness source authority.

──────────────────────────────────────────────────────────────────────────────
3. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate one private build root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-harness-external-launch-certificate-build-

Immediately emit:

LAUNCH_CERTIFICATE_BUILD_ROOT=<absolute-path>

Allocate one private output directory beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-harness-external-launch-certificate-output-

Immediately emit:

LAUNCH_CERTIFICATE_OUTPUT_ROOT=<absolute-path>

The output directory is nonauthoritative.

The sole successful authority-bearing output is:

gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json

Before process execution retain:

opening/bootstrap-start.json
opening/launch-certificate-generation-authority-v1.json
opening/fixed-input-file-registry-v1.json
opening/predecessor-authority-v3-disposition-v1.json
opening/process-execution-policy-v1.json
opening/noncircular-final-authority-model-v1.json

Bind:

- PYZ modification:
  forbidden;
- PYZ rebuild as replacement:
  forbidden;
- authority-v3 modification:
  forbidden;
- source repair:
  forbidden;
- `run-full-audit`:
  forbidden;
- implementation verdict:
  forbidden;
- current-subject construction:
  forbidden;
- same-root retry:
  false.

──────────────────────────────────────────────────────────────────────────────
4. NONCIRCULAR AUTHORITY MODEL
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/external-launch-certificate-authority-model-v1.json

Freeze the exact authority split.

A. PYZ V2

Authority over:

- executable package bytes;
- embedded frozen source;
- embedded runtime contracts;
- embedded qualification evidence;
- embedded package-member registry.

B. AUTHORITY V3

Authority over:

- the PYZ/runtime pairing consumed by the harness;
- exact `--harness-authority` operand;
- runtime self-authentication input;
- predecessor package authority and qualification claims.

Authority v3 remains the authority passed to the harness.

C. EXTERNAL LAUNCH CERTIFICATE V1

Authority over:

- external prelaunch authorization;
- current deterministic package replay;
- fresh top-level `qualify-harness` custody;
- fresh post-package qualification result;
- source-external reconciliation;
- exact stdout/stderr framing contract;
- exact future `run-full-audit` invocation;
- one authorized audit count.

The certificate is used by the wrapper.

The certificate is not passed to the harness.

D. FUTURE LAUNCH WRAPPER

Authority over:

- stable file authentication;
- launch-certificate validation;
- platform-capture preflight;
- top-level audit-parent creation and completion custody.

E. AUDIT CAPSULE

Authority over:

- runtime-observed process evidence;
- typed self-authentication crosswalk;
- internal child custody;
- source-external package findings;
- cleanup and terminal closure.

Prohibit circularity:

- PYZ need not embed evidence generated after PYZ creation;
- authority v3 need not embed validation of its own final bytes;
- launch certificate need not embed a validator result about the launch
  certificate’s own final bytes;
- final launch-certificate bytes are deterministically generated twice;
- the future wrapper independently validates those final bytes before launch.

──────────────────────────────────────────────────────────────────────────────
5. STABLE FIXED-INPUT AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

For all four fixed files:

1. open no-follow;
2. require regular file;
3. require mode 0400;
4. require link count one;
5. retain device, inode, size, and SHA-256;
6. perform two stable reads;
7. require byte and metadata equality.

Strict-parse both authority JSON files:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

Any mismatch:

- do not launch a process;
- return:
  GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
6. AUTHORITY-V3 DISPOSITION
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/predecessor-authority-v3-disposition-v1.json

Authenticate what authority v3 does establish:

- exact PYZ v2 identity;
- exact PYZ member count:
  124;
- exact source-freeze identity;
- exact source-registry bindings;
- current content bundle and authority identities;
- governing-document identities;
- package status;
- future run-full-audit argv and cwd;
- no real audit execution;
- no implementation verdict.

Retain what authority v3 does not establish as standalone external launch
authority:

- deterministic PYZ A/B replay established by current external evidence;
- current source-external authority-v3 validation;
- current frozen-PYZ requalification binding;
- exact external stream/framing contract;
- complete post-package launch authorization.

Classify authority v3 as:

current_runtime_harness_authority_incomplete_standalone_launch_authority

It remains:

- immutable;
- required by the harness CLI;
- current for runtime self-authentication;
- not sufficient alone for wrapper launch authorization.

Do not classify it as corrupt or false.

──────────────────────────────────────────────────────────────────────────────
7. EXACT PYZ CLOSURE
──────────────────────────────────────────────────────────────────────────────

Parse the PYZ directly.

Require:

- exactly 124 members;
- exact member-registry/archive equality;
- raw UTF-8 byte-sorted names;
- ZIP_STORED only;
- fixed timestamp;
- create_system:
  3;
- fixed member modes;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no comments;
- no uncontrolled extra fields;
- no cache or bytecode.

Resolve every authority-bearing member only through the exact embedded member
registry and role registries.

Retain:

validation/unchanged-pyz-member-closure-v1.json

At minimum authenticate:

- `__main__.py`;
- source freeze;
- production source registry;
- qualification source registry;
- independent source registry;
- package member registry;
- package status;
- five-domain governing records;
- interpreter-observation governing records;
- report registry;
- confirmation registry;
- matrix registry;
- phase plan;
- capsule path/writer registries;
- process-custody contracts;
- cleanup contract;
- terminal-lifecycle contract;
- embedded qualification results;
- rehearsal results;
- independent-validator results.

Unknown or multiply occupied roles fail closed.

──────────────────────────────────────────────────────────────────────────────
8. DETERMINISTIC PYZ REPLAY
──────────────────────────────────────────────────────────────────────────────

Reconstruct the PYZ twice from the exact 124 embedded member bytes and the exact
observed deterministic ZIP metadata.

Do not modify source or member bytes.

Build in two physically distinct disposable roots:

- deterministic replay A;
- deterministic replay B.

Requirements:

- member set exactly equal to original;
- exact member order;
- exact compression:
  ZIP_STORED;
- exact timestamp;
- exact create_system;
- exact member modes;
- exact flags/comments/extra fields;
- exact archive comment;
- exact central-directory semantics.

Require:

- replay A bytes equal replay B bytes;
- replay A bytes equal the original PYZ bytes;
- replay B bytes equal the original PYZ bytes;
- size and SHA-256 equal the original PYZ;
- no unexplained difference.

Retain:

validation/deterministic-pyz-replay-a-v1.json
validation/deterministic-pyz-replay-b-v1.json
validation/deterministic-pyz-replay-comparison-v1.json

The replay outputs are disposable evidence, not replacement PYZ files.

Remove both replay roots only after evidence retention and independent
validation, with double ENOENT observations.

──────────────────────────────────────────────────────────────────────────────
9. EXACT STREAM/FRAMING CONTRACT
──────────────────────────────────────────────────────────────────────────────

Resolve the exact `qualify-harness` and `run-full-audit` stream/framing
contracts only through exact embedded roles and source-external inspection of
the PYZ.

Do not use human report prose as authority.

Retain:

contract/external-stream-and-framing-contract-v1.json

For `qualify-harness`, freeze:

- stdout framing;
- stderr posture;
- terminal record schema;
- duplicate/trailing-byte policy;
- success exit;
- failure exit;
- root-locator posture when applicable.

For `run-full-audit`, freeze:

- exactly one audit-root locator;
- exact terminal-frame schema;
- stdout ordering;
- stderr posture;
- duplicate/trailing-byte policy;
- success/failure exit posture;
- allowed verdicts;
- locator/frame consistency rules.

If the exact contract cannot be resolved unambiguously from current PYZ bytes:

- do not execute qualification;
- return:
  GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_BLOCKED;
- state:
  source repair may be required;
- do not rebuild or patch source in this task.

──────────────────────────────────────────────────────────────────────────────
10. DERIVE EXACT QUALIFY-HARNESS INVOCATION
──────────────────────────────────────────────────────────────────────────────

Derive the invocation only from:

- exact PYZ CLI contract;
- `__main__.py`;
- package status;
- authority v3;
- embedded qualification contract.

Do not infer from prior prompts.

Do not guess an option.

Require one exact invocation using:

- pinned Framework Python;
- `-I`;
- `-S`;
- `-B`;
- exact unchanged PYZ v2;
- `--mode qualify-harness`;
- every exact required current operand;
- no extra operand.

If authority v3 is an exact required qualification operand, pass it.

If an additional required operand exists but lacks an exact current file
identity among the four fixed files:

- do not launch;
- return:
  GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_BLOCKED;
- retain the exact missing operand contract.

Retain:

contract/fresh-qualify-harness-invocation-v1.json

──────────────────────────────────────────────────────────────────────────────
11. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before qualification, run exactly one harmless synchronous capture preflight.

Use pinned Python with:

-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

The program must:

- emit exactly:
  `PLATFORM_CAPTURE_STDOUT_V1\n`;
- emit exactly:
  `PLATFORM_CAPTURE_STDERR_V1\n`;
- exit:
  23;
- read no stdin;
- create no file;
- create no child.

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Require exact streams, exit, signal, PID, timing, reaping, and descriptor
closure.

Expected stdout:

- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

Failure is:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_PROVENANCE_MISMATCH

Do not retry.

──────────────────────────────────────────────────────────────────────────────
12. FRESH QUALIFY-HARNESS EXECUTION
──────────────────────────────────────────────────────────────────────────────

After Sections 5–11 pass, execute the exact derived qualification invocation.

Use the exact cwd required by the embedded contract.

Use submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Launch count:

exactly one.

Run synchronously.

Do not execute:

- `run-full-audit`;
- replacement qualification;
- recovery;
- continuation;
- direct implementation audit;
- source compiler outside the PYZ;
- a second qualification run.

──────────────────────────────────────────────────────────────────────────────
13. QUALIFICATION PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Retain before parsing:

- custody ID;
- PID;
- process-creation result;
- start/completion;
- duration;
- argv;
- cwd;
- submitted environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and SHA-256;
- exit code;
- signal;
- process error;
- reaping;
- descriptor closure;
- exact PYZ identity at launch;
- exact authority-v3 identity at launch when supplied;
- exact content-bundle identities at launch.

Missing completion custody is:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_PROVENANCE_MISMATCH

Do not retry.

──────────────────────────────────────────────────────────────────────────────
14. STRICT QUALIFICATION OUTPUT PARSING
──────────────────────────────────────────────────────────────────────────────

Retain raw streams before parsing.

Parse only under the exact contract frozen in Section 9.

Require:

- exact framing;
- no progress chatter;
- no duplicate terminal record;
- no trailing unframed bytes;
- exact stderr posture;
- strict UTF-8 JSON;
- duplicate-key rejection;
- nonfinite rejection;
- exact schema;
- successful qualification disposition.

If a qualification evidence root is emitted:

- use only the exact locator;
- do not scan;
- inspect only that exact root read-only;
- retain its identity and complete inventory before cleanup.

If no root is part of the exact contract:

- do not require one.

Retain:

validation/fresh-qualify-harness-platform-result-v1.json
validation/fresh-qualify-harness-result-v1.json

A substantive qualification failure returns:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_BLOCKED

unless it is a provenance failure.

──────────────────────────────────────────────────────────────────────────────
15. POST-PACKAGE QUALIFICATION CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/post-package-qualification-crosswalk-v1.json

Independently require proof of:

1. exact executed PYZ identity;
2. exact 124-member closure;
3. exact source-freeze identity;
4. source unchanged after freeze;
5. exact production source registry;
6. exact qualification source registry;
7. exact independent source registry;
8. exact current content-bundle identity;
9. exact content-authority identity;
10. exact five-domain governing identity;
11. exact interpreter-observation governing identity;
12. exact runtime report rows:
    66;
13. exact runtime confirmation names:
    81;
14. exact runtime matrices:
    15;
15. exact runtime matrix cases:
    595;
16. stale 645 rejected;
17. B00 and D01–D14 results;
18. process-custody qualification;
19. synthetic ACCEPT;
20. synthetic BLOCK;
21. synthetic provenance failure;
22. synthetic constructed-subject lane;
23. bounded compatibility replay;
24. real-path ACCEPT rehearsal;
25. real-path BLOCK rehearsal;
26. real-path provenance rehearsal;
27. rehearsal package equality where required;
28. independent validators passed;
29. deterministic original PYZ replay;
30. final member closure;
31. package status;
32. exact stream/framing contract;
33. full real audit not executed;
34. implementation verdict not issued;
35. current schema subject not constructed;
36. fresh qualification executed against the exact unchanged PYZ;
37. fresh qualification passed;
38. exact future run-full-audit invocation.

Every fact must include:

- evidence pointer;
- direct or transitive authority;
- independently recomputed value when applicable;
- no generic-success substitution.

──────────────────────────────────────────────────────────────────────────────
16. SOURCE-EXTERNAL EVIDENCE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Create one standard-library-only source-external validator.

It may not import:

- any PYZ module;
- qualification helper;
- deterministic replay builder helper;
- crosswalk producer;
- expected-result map;
- certificate builder.

It must independently:

1. authenticate all four fixed inputs;
2. validate authority-v3 disposition;
3. validate exact PYZ member closure;
4. independently replay deterministic PYZ Build A/B;
5. compare both replay builds to the original;
6. resolve and validate the stream/framing contracts;
7. parse raw qualification streams;
8. bind the platform result to the exact executed PYZ;
9. recompute every crosswalk fact;
10. recompute 5/66/81/15/595/124/8/479;
11. validate source freeze and source registries;
12. validate runtime matrix identities;
13. validate custody/synthetic/replay/rehearsal evidence;
14. validate package status and future invocation;
15. verify no source or PYZ modification;
16. verify no real audit execution;
17. require zero errors.

Retain:

validation/independent-launch-certificate-evidence-validator-v1.json

The result of this validator is a launch-certificate input.

It does not validate the launch certificate’s own final bytes.

──────────────────────────────────────────────────────────────────────────────
17. LAUNCH-CERTIFICATE SCHEMA AND CONTENT
──────────────────────────────────────────────────────────────────────────────

Create one self-contained canonical JSON object with schema:

execution-substrate.gen2-clean-harness.external-launch-certificate.v1

Required fields:

- schema;
- certificate_version:
  1;
- certificate_current:
  true;
- harness_id;
- harness_version;
- authority_model identity;
- exact PYZ v2:
  - path;
  - device;
  - inode;
  - mode;
  - link count;
  - size;
  - SHA-256;
  - member count:
    124;
  - member-list digest;
  - member-registry identity;
- exact runtime authority v3:
  - path;
  - complete identity;
  - classification:
    current_runtime_harness_authority_incomplete_standalone_launch_authority;
- exact content bundle identity;
- exact content-authority identity;
- deterministic replay:
  - Build A identity;
  - Build B identity;
  - A/B equality;
  - A/original equality;
  - B/original equality;
- fresh platform-capture preflight result;
- fresh qualify-harness process custody;
- fresh raw-stream identities;
- fresh parsed qualification result embedded as a canonical JSON object;
- qualification-result canonical digest;
- complete post-package qualification crosswalk;
- independent evidence-validator result;
- exact external stream/framing contract;
- exact future run-full-audit invocation;
- exact future cwd;
- exact future submitted environment;
- exact future stdin/shell/TTY/detachment;
- exact documentary/governance identities;
- derived values:
  - documentary domains:
    5;
  - runtime report rows:
    66;
  - runtime confirmation names:
    81;
  - runtime matrices:
    15;
  - runtime matrix cases:
    595;
  - PYZ members:
    124;
  - content roles:
    8;
  - content archive members:
    479;
- source frozen:
  true;
- source unchanged after freeze:
  true;
- deterministic final package:
  true;
- post-package qualification:
  passed;
- external evidence validation:
  passed;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject constructed:
  false;
- source repair:
  false;
- PYZ modification:
  false;
- PYZ rebuild/replacement:
  false;
- wrapper_launch_authorized:
  true;
- authorized_future_audit_count:
  1;
- certificate containing directory:
  nonauthoritative.

The certificate must be self-contained.

The future wrapper may validate it without opening the certificate build root.

──────────────────────────────────────────────────────────────────────────────
18. NONCIRCULAR FINALIZATION
──────────────────────────────────────────────────────────────────────────────

The launch certificate must not contain:

- a claim that an independent validator validated the certificate’s own final
  bytes;
- a self-hash field requiring fixed-point generation;
- a final inode before file creation;
- mutable build-root evidence paths required for future launch.

The source-external evidence validator validates all certificate inputs before
certificate generation.

The future audit wrapper validates the final certificate bytes, schema, content,
and all bound fixed files at launch time.

This is the final validation of certificate bytes.

No additional certificate-validator layer is required.

──────────────────────────────────────────────────────────────────────────────
19. DETERMINISTIC CERTIFICATE BUILDS
──────────────────────────────────────────────── LIMITED TO CERTIFICATE
────────────────────────────────────────────────

Generate certificate bytes independently twice:

- Certificate Build A;
- Certificate Build B.

Use:

- strict canonical UTF-8 JSON;
- deterministic key ordering;
- one trailing LF;
- no uncontrolled timestamp;
- no PID in authority-bearing semantic fields except retained process-custody
  evidence;
- no mutable build-root path required by future launch.

Require:

- A bytes equal B bytes;
- parsed A equals parsed B;
- size equality;
- SHA-256 equality.

Retain:

validation/launch-certificate-build-a-v1.json
validation/launch-certificate-build-b-v1.json
validation/launch-certificate-build-comparison-v1.json

Only after equality may one copy become final.

──────────────────────────────────────────────────────────────────────────────
20. FINAL CERTIFICATE FILE
──────────────────────────────────────────────── LIMITED TO AUTHORITY
────────────────────────────────────────────────

Write:

gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json

into the fresh output directory.

After complete certificate construction:

- set mode 0400;
- reopen no-follow;
- require regular file;
- require link count one;
- retain device and inode;
- verify size;
- verify SHA-256;
- verify exact canonical bytes;
- prohibit later modification.

Do not copy or replace:

- the PYZ;
- authority v3;
- the content bundle;
- the content authority.

Report the final certificate’s exact:

- absolute path;
- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

──────────────────────────────────────────────────────────────────────────────
21. FIXED-INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for all four fixed files.

Require exact equality with opening:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

If the optional historical wrapper root was opened, require complete
opening/closing equality.

Do not mutate or clean supplied inputs.

──────────────────────────────────────────────────────────────────────────────
22. DISPOSABLE-ROOT CLEANUP
──────────────────────────────────────────────── LIMITED TO OWNED ROOTS
────────────────────────────────────────────────

Before removing any certificate-owned disposable root retain:

- root identity;
- complete inventory;
- process records and streams;
- qualification result;
- replay results;
- crosswalk;
- validator result;
- failure outcome when applicable.

Then:

- revalidate root identity;
- remove the exact root;
- observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Do not remove:

- the final output directory;
- the final launch certificate;
- any supplied input.

──────────────────────────────────────────────────────────────────────────────
23. FAILURE CLOSEOUT
──────────────────────────────────────────────── LIMITED TO BUILD
────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process records and raw streams;
- partial build inventory;
- indispensable evidence;
- cleanup;
- fixed-input closing equality;
- certificate posture;
- same-root retry:
  false.

Do not create a current certificate on failure.

If a provisional certificate exists:

- retain identity;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- fixed-input mismatch;
- platform-capture failure;
- missing qualification completion custody;
- source/PYZ drift;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- fixed-input closing inequality;
- final certificate mismatch.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_CREATED_READY_FOR_FRESH_AUDIT

only when:

- all fixed inputs authenticate;
- authority-v3 disposition is retained;
- PYZ closure passes;
- deterministic replay A/B equal each other and the original;
- exact stream/framing contract resolves;
- platform preflight passes;
- `qualify-harness` executes exactly once;
- complete platform custody is retained;
- fresh qualification passes;
- post-package crosswalk closes;
- source-external evidence validator passes;
- certificate Build A/B bytes match;
- final certificate is self-contained;
- fixed inputs close equal;
- disposable roots clean exactly;
- final certificate is mode 0400;
- no real audit ran;
- no implementation verdict was issued.

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_BLOCKED

when:

- fresh qualification fails substantively;
- stream/framing contract is unavailable or ambiguous;
- a required post-package fact cannot be established without source or PYZ
  repair;
- the launch certificate cannot be made self-contained;
- independent evidence validation fails without provenance failure.

Required BLOCKED disposition:

- source repair required:
  exact result;
- PYZ rebuild required:
  exact result;
- audit launch:
  not authorized.

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_PROVENANCE_MISMATCH

for provenance failures in Section 23.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh certificate-build root identity
3. Fresh certificate-output root identity
4. PYZ v2 identity
5. Authority-v3 identity
6. Content-bundle identity
7. Content-authority identity
8. Fixed-input authentication
9. Historical wrapper disposition
10. Noncircular authority model
11. Authority-v3 disposition
12. PYZ member closure
13. Deterministic replay Build A
14. Deterministic replay Build B
15. Deterministic replay comparison
16. Exact qualify-harness stream/framing contract
17. Exact run-full-audit stream/framing contract
18. Exact qualify-harness invocation
19. Platform-capture preflight
20. Qualification argv
21. Qualification cwd and environment
22. Qualification process custody
23. Raw qualification stdout
24. Raw qualification stderr
25. Qualification exit and signal
26. Fresh parsed qualification result
27. Exact final-PYZ binding
28. Source-freeze/source-registry bindings
29. Governance and aggregate bindings
30. Matrix and qualification-lane bindings
31. Rehearsal and validator bindings
32. Post-package qualification crosswalk
33. Independent evidence-validator result
34. Launch-certificate schema
35. Complete launch-certificate content
36. Certificate Build A
37. Certificate Build B
38. Certificate Build-A/B equality
39. Confirmation no source repair occurred
40. Confirmation no PYZ modification/replacement occurred
41. Confirmation no real audit occurred
42. Confirmation no implementation verdict was issued
43. Fixed-input closing equality
44. Disposable-root cleanup
45. Failure-closeout capability and use
46. Final launch-certificate path and identity
47. Mandatory next treatment
48. Remaining uncertainty and nonclaims
49. Explicit confirmations

Required confirmations:

UNCHANGED_PYZ_V2_IDENTITY_MATCHED
UNCHANGED_AUTHORITY_V3_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
AUTHORITY_V3_DISPOSITION_RETAINED
PYZ_MEMBER_SET_124_CLOSED
DETERMINISTIC_REPLAY_A_CREATED
DETERMINISTIC_REPLAY_B_CREATED
DETERMINISTIC_REPLAY_A_B_BYTE_IDENTICAL
DETERMINISTIC_REPLAY_A_EQUALS_ORIGINAL_PYZ
DETERMINISTIC_REPLAY_B_EQUALS_ORIGINAL_PYZ
QUALIFY_HARNESS_STREAM_CONTRACT_FROZEN
RUN_FULL_AUDIT_STREAM_CONTRACT_FROZEN
EXACT_QUALIFY_HARNESS_INVOCATION_DERIVED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
QUALIFY_HARNESS_EXECUTED_EXACTLY_ONCE
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
QUALIFY_HARNESS_PROCESS_CUSTODY_COMPLETE
QUALIFY_HARNESS_RAW_STDOUT_RETAINED
QUALIFY_HARNESS_RAW_STDERR_RETAINED
QUALIFY_HARNESS_EXIT_AND_SIGNAL_RETAINED
FRESH_QUALIFICATION_RESULT_STRICTLY_PARSED
FRESH_QUALIFICATION_PASSED
FRESH_RESULT_BOUND_TO_EXACT_PYZ_V2
SOURCE_FREEZE_IDENTITY_BOUND
SOURCE_NOT_MODIFIED_AFTER_FREEZE
FINAL_SOURCE_REGISTRIES_BOUND
FIVE_DOCUMENTARY_DOMAINS_RECOMPUTED
RUNTIME_REPORT_ROWS_66_RECOMPUTED
RUNTIME_CONFIRMATION_NAMES_81_RECOMPUTED
RUNTIME_MATRICES_15_RECOMPUTED
RUNTIME_MATRIX_CASES_595_RECOMPUTED
STALE_MATRIX_TOTAL_645_REJECTED
PROCESS_CUSTODY_QUALIFICATION_BOUND
SYNTHETIC_LANES_BOUND
BOUNDED_COMPATIBILITY_REPLAY_BOUND
REAL_PATH_ACCEPT_REHEARSAL_BOUND
REAL_PATH_BLOCK_REHEARSAL_BOUND
REAL_PATH_PROVENANCE_REHEARSAL_BOUND
INDEPENDENT_VALIDATORS_BOUND
POST_PACKAGE_QUALIFICATION_CROSSWALK_PASSED
SOURCE_EXTERNAL_EVIDENCE_VALIDATOR_PASSED
NONCIRCULAR_AUTHORITY_MODEL_FROZEN
LAUNCH_CERTIFICATE_SELF_CONTAINED
LAUNCH_CERTIFICATE_BUILD_A_CREATED
LAUNCH_CERTIFICATE_BUILD_B_CREATED
LAUNCH_CERTIFICATE_BUILD_A_B_BYTE_IDENTICAL
HARNESS_SOURCE_REPAIR_NOT_PERFORMED
HARNESS_PYZ_MODIFICATION_NOT_PERFORMED
HARNESS_PYZ_REPLACEMENT_NOT_PERFORMED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_PYZ_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_V3_CLOSING_EQUALITY_PASSED
INPUT_CONTENT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_CONTENT_AUTHORITY_CLOSING_EQUALITY_PASSED
CERTIFICATE_OWNED_CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_LAUNCH_CERTIFICATE_CREATED
FINAL_LAUNCH_CERTIFICATE_MODE_0400
FINAL_LAUNCH_CERTIFICATE_IDENTITY_VERIFIED
FINAL_LAUNCH_CERTIFICATE_BINDS_PYZ_V2
FINAL_LAUNCH_CERTIFICATE_BINDS_AUTHORITY_V3
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_HARNESS_EXTERNAL_LAUNCH_CERTIFICATE_CREATED_READY_FOR_FRESH_AUDIT

the next task is exactly one fresh audit using five fixed files:

1. unchanged PYZ v2;
2. unchanged authority v3;
3. final launch certificate v1;
4. current content bundle;
5. current content authority.

The external wrapper authenticates the launch certificate.

The harness receives authority v3 through `--harness-authority`.

Do not pass the launch certificate to the harness unless the unchanged embedded
CLI expressly requires it, which current evidence does not establish.

Do not combine certificate creation with the real audit.
```

### Source

Codex’s operative report in your message is the sole source for the factual assessment.

**Confidence:** 0.999 that the audit authorization remains unconsumed; 0.999 that no implementation-package conclusion exists; 0.995 that the blocker is external post-package launch authority rather than harness source; 0.97 that a noncircular launch certificate is the shortest safe path to the actual audit.
