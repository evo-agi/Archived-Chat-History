## Engineering assessment

This is the first governing package in the chain that is sufficiently closed to authorize implementation without another retrospective reconciliation.

The Generation‑2 package resolves the recurring causes of failure rather than patching their latest manifestations:

- the exact future subject namespace is frozen before temporal projection;
- `closeout/` and `manifest/` must exist before namespace finalization;
- every final path has one phase/function writer;
- the documentary-evidence lifecycle is acyclic and single-writer;
- process custody and evidence-before-cleanup are explicit;
- external JSON interfaces use exact pointers and typed observation;
- special values such as zero counts, raw `false`, null blockers, root `"."`, and the intentionally unmapped normative role are frozen explicitly;
- two complete rehearsals, source freeze, frozen-byte requalification, and a separate independent implementation audit are mandatory before authoritative use.

The next tranche should now **implement and qualify the new clean parent**. It should not reconstruct the current schema subject. It should end with a terminally closed implementation package whose status is **frozen and pending independent audit**.

There is no reason to audit or reconcile the Generation‑2 documentary contract again before implementation. Conversely, successful producer qualification will not authorize one-shot subject construction: that must remain behind the separate independent implementation-package audit required by the contract.

```text
IMPLEMENT AND QUALIFY THE GENERATION-2 SCHEMA-SUBJECT
RECONSTRUCTION PARENT — DO NOT CONSTRUCT THE CURRENT SUBJECT

Objective

Create a new, clean, source-external implementation of the schema-subject
reconstruction parent from the frozen Generation-2 contract package.

Implement the frozen Generation-2 operating model, complete all required
qualification, execute two full disposable rehearsals, freeze the exact source
bytes used by both rehearsals, requalify those frozen bytes, and terminally
close the implementation package.

Do not construct the current schema subject in this task.

Do not claim independent acceptance of the implementation package. A separate
fresh independent implementation-package audit is required after this task
succeeds and before the frozen parent may be used for authoritative one-shot
subject reconstruction.

This task is not:

- another historical reconciliation;
- a repair of Candidate 2;
- a repair of V1–V4;
- a product construction-parent implementation;
- a target-audit execution;
- runtime validation;
- repository work;
- A6 work.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not install dependencies.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned implementation and qualification process in one
fresh private package root.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, causal findings, validation results,
custody evidence, or the final disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_BLOCKED

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SOLE GOVERNING GENERATION-2 CONTRACT PACKAGE
──────────────────────────────────────────────────────────────────────────────

GEN2_CONTRACT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-contract-vrif4iiw

Expected root identity:

- device:
  16777234
- inode:
  180837095
- mode:
  0700
- governing verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  180842134
- size:
  12486
- SHA-256:
  5b596ae7f0e7af8946a58f1fa261682b72afbc960bb01422788e5c2ae7e192c8

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  180842135
- size:
  12905
- SHA-256:
  8a75a084e1629f65802074c6a237d763c226b2383772b2523f94b99293756e02

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  180842136
- size:
  12905
- SHA-256:
  8a75a084e1629f65802074c6a237d763c226b2383772b2523f94b99293756e02

Before implementation, independently authenticate:

- root identity;
- temporal inventory;
- A/B byte equality;
- complete manifest reprojection;
- root row exactly once;
- terminal topology and modes;
- no cache or bytecode;
- no postseal filesystem activity;
- package status;
- explicit confirmation registry;
- independent Generation-2 contract-validator result.

Treat this package as the sole governing implementation-contract package.

Do not silently substitute a predecessor contract, report, reconciliation,
historical source, or inferred rule.

Require complete opening/closing equality for this root.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING GENERATION-2 RECORDS
──────────────────────────────────────────────────────────────────────────────

Authenticate and consume these exact governing records from GEN2_CONTRACT_ROOT:

Authority and operating model:

- contract/gen2-reconstruction-parent-authority-v1.json
- contract/gen2-reconstruction-state-machine-v1.json

Namespace and closure:

- contract/future-schema-subject-artifact-plan-v1.json
- contract/namespace-finalization-v1.json
- contract/temporal-inventory-lifecycle-v1.json
- contract/terminal-manifest-lifecycle-v1.json

Writers and evidence lifecycle:

- contract/gen2-phase-function-path-writer-registry-v1.json
- contract/gen2-documentary-evidence-lifecycle-v1.json

Process and failure custody:

- contract/gen2-process-custody-v1.json
- contract/gen2-failure-evidence-and-cleanup-v1.json

Input and data interpretation:

- contract/gen2-external-interface-v1.json
- contract/gen2-total-json-observation-v1.json
- contract/gen2-internal-special-cases-v1.json

Implementation architecture and qualification:

- analysis/gen2-source-architecture-v1.json
- contract/gen2-implementation-qualification-v1.json

Validation:

- validation/gen2-contract-witness-matrix-v1.json
- validation/gen2-state-machine-matrix-v1.json
- validation/gen2-namespace-temporal-matrix-v1.json
- validation/gen2-writer-lifecycle-matrix-v1.json
- validation/gen2-process-failure-custody-matrix-v1.json
- validation/independent-gen2-contract-validator-v1.json

Perspectives and reconciliation:

- analysis/perspective-authority-state-machine-v1.json
- analysis/perspective-namespace-closure-v1.json
- analysis/perspective-process-custody-v1.json
- analysis/perspective-validation-evidence-v1.json
- analysis/parent-perspective-reconciliation-v1.json

Status and confirmations:

- analysis/contract-package-status-v1.json
- report/explicit-confirmations-v1.json

Retain an opening record crosswalking every consumed governing path to:

- exact file identity;
- role;
- authority;
- consumer;
- whether it is normative, subordinate enforcement, validation, or report-only
  evidence.

Unknown or missing governing input is a blocker.

──────────────────────────────────────────────────────────────────────────────
3. AUTHORITATIVE EXTERNAL INPUTS
──────────────────────────────────────────────────────────────────────────────

The Generation-2 package must resolve and authenticate the exact external
inputs it freezes.

At minimum these are expected:

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Authenticate all exact paths and identities through the Generation-2 external
interface registry.

Use:

- the normative contract as the sole semantic writer;
- only the current fifteen v2 schemas;
- only root-independent validation specifications and case registries from
  the validation-specification source.

Do not copy historical package status, root-bound results, temporal
inventories, manifests, P06/P18 records, confirmations, reports, or authority
as current evidence.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
4. PROHIBITED IMPLEMENTATION INPUTS
──────────────────────────────────────────────────────────────────────────────

Do not open historical source roots for implementation source.

Do not copy, import, transform, patch, or execute source from:

- Candidate 2;
- the Candidate 2 replay;
- the blocked clean implementation;
- V1;
- V2;
- V3;
- V4;
- any earlier reconstruction parent;
- any earlier process recorder;
- any earlier validator;
- any earlier finalizer;
- any earlier manifest generator.

The Generation-2 package already contains the accepted historical defect
catalogue. That catalogue may guide prevention rules, but historical source
must not become an implementation base.

Retain:

opening/gen2-clean-room-source-authority-v1.json

Require:

- no historical production source copied;
- no historical qualification source copied;
- no historical source patched;
- no historical module imported;
- no historical AST fragment used as the source origin;
- clean source begins absent;
- source provenance derives from the Generation-2 contracts and authoritative
  external inputs only.

A textual-similarity diagnostic may be report-only. Similarity or difference
is not an acceptance oracle.

──────────────────────────────────────────────────────────────────────────────
5. FRESH IMPLEMENTATION-PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-

Immediately emit:

IMPLEMENTATION_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method;
- umask;
- Generation-2 contract-package identity;
- external-input identities;
- clean-room source authority;
- exact implementation authority;
- exact nonauthority;
- implementation attempt limit;
- current subject construction authorized:
  false;
- implementation independent audit performed:
  false;
- one-shot current-subject use authorized:
  false;
- process-self-test authorized:
  false;
- product construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- A6 authorized:
  false;
- same-root retry:
  false.

Create directories lazily.

No empty directory may remain at terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. IMPLEMENTATION-PACKAGE OPERATING RECORDS BEFORE SOURCE
──────────────────────────────────────────────────────────────────────────────

Before writing production or qualification source, retain fresh package-bound
records that bind, without changing:

- Generation-2 authority and nonauthority;
- G00–G29 state-machine identities;
- exact future subject namespace;
- exact future directory set;
- namespace-finalization boundary;
- temporal lifecycle;
- terminal-manifest lifecycle;
- phase/function/path writer registry;
- documentary-evidence lifecycle;
- process custody;
- failure evidence and cleanup;
- external interfaces;
- total JSON observation;
- special cases;
- source architecture;
- implementation qualification.

Retain:

opening/gen2-implementation-operating-freeze-v1.json

It must bind every governing source record by path, size, SHA-256, and role.

Do not write production source before this record passes.

──────────────────────────────────────────────────────────────────────────────
7. SOURCE REGISTRIES AND COMPONENT LAYOUT
──────────────────────────────────────────────────────────────────────────────

Implement all roles required by:

analysis/gen2-source-architecture-v1.json

The architecture reports:

- 24 production component roles;
- 9 qualification-only component roles.

Before source creation, generate:

contract/gen2-implementation-source-layout-v1.json

For every component bind:

- component role;
- exact relative source path;
- production or qualification classification;
- authority;
- nonauthority;
- allowed imports;
- forbidden imports;
- inputs;
- outputs;
- mutable facts written;
- process-launch authority;
- filesystem-write authority;
- consumers.

Requirements:

- every architecture role mapped exactly once;
- no unregistered source file;
- no component silently merged in a way that widens authority;
- no production component imports qualification code;
- independent validators do not import production modules or producer helpers;
- exactly one production child-recorder role;
- exactly two independent terminal-manifest generator implementations;
- exactly one terminal-seal controller;
- exactly one failure-finalization owner;
- exactly one cleanup owner.

Retain separate registries:

contract/gen2-production-source-registry-v1.json
contract/gen2-qualification-source-registry-v1.json

These are planned registries before source creation and must later be closed
with exact file identities.

──────────────────────────────────────────────────────────────────────────────
8. IMPLEMENTATION ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete implementation source attempts are permitted.

A complete attempt begins when:

- its production source registry is closed;
- its qualification source registry is closed;
- compilation begins.

For every attempt retain:

- complete source identities;
- compilation results;
- static results;
- matrix results reached;
- first blocker;
- partial outputs;
- supersession status.

A source modification after an attempt begins creates a new attempt.

No failed or superseded attempt contributes:

- final source identity;
- passing case counts;
- rehearsal identity;
- freeze;
- readiness;
- terminal implementation-package verdict.

If attempt 3 fails any prefreeze gate:

- stop;
- return the blocked verdict;
- do not create attempt 4.

──────────────────────────────────────────────────────────────────────────────
9. CLEAN PRODUCTION IMPLEMENTATION
──────────────────────────────────────────────────────────────────────────────

Implement production sources from the Generation-2 contracts.

The production parent must expose exactly one production mode:

--mode reconstruct-subject

No default mode.

Production restrictions:

- no network imports or dynamic network access;
- no Git operation;
- no shell;
- no PATH lookup for child executables;
- no inherited environment beyond explicitly frozen mechanics;
- no repository/product/target invocation;
- no install or deployment;
- no broad Downloads traversal;
- no prefix/latest/newest/score selection;
- no existing-root adoption;
- no stdin read;
- finite control flow;
- every child through the one recorder;
- exact supplied roots only;
- fresh output root only;
- no overwrite;
- exclusive writes;
- no symlink following;
- no same-root retry;
- no administrative continuation.

Implement G00–G29 exactly.

No phase may be omitted, merged in a way that changes authority, reordered, or
compensated for by a later phase.

──────────────────────────────────────────────────────────────────────────────
10. EXACT NAMESPACE MATERIALIZATION
──────────────────────────────────────────────────────────────────────────────

Implement the exact future subject package namespace from:

contract/future-schema-subject-artifact-plan-v1.json

The Generation-2 contract reports:

- 58 final files;
- 70 total paths including directories and root.

Expected final directories include:

- `.`
- `analysis/`
- `closeout/`
- `closing/`
- `contract/`
- `lineage/`
- `manifest/`
- `opening/`
- `provenance/`
- `report/`
- `schemas/`
- `validation/`

At G04:

- create every final directory;
- set every directory mode to 0700;
- retain namespace-materialization evidence;
- prohibit any later directory creation.

At G25:

- require exact directory-set equality;
- require exact planned-path registry;
- freeze namespace;
- permit after G25 only:
  - creation of the temporal inventory file in preexisting `closeout/`;
  - creation and writing of manifest A/B in preexisting `manifest/`.

Writing the temporal inventory must not create `closeout/`.

Writing manifests must not create `manifest/`.

──────────────────────────────────────────────────────────────────────────────
11. WRITER AND DOCUMENTARY LIFECYCLE ENFORCEMENT
──────────────────────────────────────────────────────────────────────────────

Implement the exact writer registry and documentary lifecycle.

For every final path require:

- exact phase;
- exact component;
- exact function;
- exact write operation;
- maximum successful write count 1;
- exclusive create;
- no overwrite;
- no adoption;
- no staging under the final path.

Documentary sequence must be:

1. nine prerequisite documentary-validator results;
2. confirmation evidence map;
3. confirmation-evidence-map validator result;
4. final ten-role documentary-validator registry;
5. registry-derived documentary-validator regeneration result;
6. independent schema validation;
7. evidence-derived explicit confirmations;
8. occupancy/status/lineage/report;
9. temporal inventory;
10. terminal manifests.

The confirmation-evidence-map validator result must have exactly one writer
and one create event.

The final ten-role registry must be written only after all ten result files
exist and authenticate.

The regeneration result must derive from the final registry.

No result may validate itself.

No hard-coded expected role count may substitute for registry-derived
evidence.

──────────────────────────────────────────────────────────────────────────────
12. EXTERNAL INTERFACES AND JSON OBSERVATION
──────────────────────────────────────────────────────────────────────────────

Implement every interface from:

contract/gen2-external-interface-v1.json

The contract reports 33 exact interfaces.

Rules:

- exact path or authority-based path derivation;
- strict parsing;
- duplicate-key rejection;
- nonfinite rejection;
- no aliases;
- no pointer fallback;
- no generic recursive list selection;
- no first/longest/same-length selection;
- no filename/content/recency scoring;
- missing required field fails;
- wrong type fails;
- counts derive from rows;
- uniqueness derives from row keys;
- digests independently recomputed;
- summaries corroborate only;
- absence never means false, zero, empty, or pass.

For the 946-case registry, bind the exact accepted vocabulary frozen by the
contract, including:

- case-list pointer:
  `/cases`;
- row key:
  `literal_name`;
- summary field:
  `names_unique`;
- derived count:
  946;
- derived unique count:
  946;
- exact name-digest encoding.

Do not recognize `literal_names_unique` as an alias.

Implement total JSON observation statuses exactly:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

Prohibit chained object operations on untrusted or deliberately mutated JSON.

──────────────────────────────────────────────────────────────────────────────
13. SPECIAL-CASE ENFORCEMENT
──────────────────────────────────────────────────────────────────────────────

Implement all fifteen acceptance-bearing special cases from:

contract/gen2-internal-special-cases-v1.json

At minimum:

- `normative-construction-parent` is the sole schema role without a generated
  family;
- exactly fourteen generated families;
- zero child count is valid;
- zero cleanup-root count is valid;
- empty but equal cleanup sets are valid;
- raw false remains raw false;
- positive assertions over raw false use explicit predicates;
- null first blocker is permitted only in the frozen success context;
- empty error arrays are valid;
- root row `"."` is explicit;
- A/B exclusions are explicit;
- reserved `manifest/` is lifecycle-bound;
- implementation absent is false/explicit;
- implementation authority absent is false/explicit;
- independent acceptance remains false before audit.

No generic truthiness for acceptance-bearing numeric, collection, or Boolean
posture.

No direct dictionary indexing where a frozen special-case branch permits null
or absence.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Implement:

- one finite parent;
- one child recorder;
- prelaunch before spawn;
- contiguous ordinals;
- exact argv/cwd/environment/stdin/timeout;
- exact stdout/stderr bytes, sizes, and hashes;
- exit or signal;
- reaping;
- descriptor closure;
- fixed-output attribution;
- dynamic-root attribution;
- nonzero-exit attribution;
- timeout attribution;
- process-group posture;
- no shell;
- no PATH lookup;
- no supervisor loop.

Every child effect must be attributed before cleanup.

An unaccounted process or filesystem effect is provenance-fatal.

──────────────────────────────────────────────────────────────────────────────
15. FAILURE FINALIZATION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Implement the exact failure order:

1. stop dependent work;
2. retain first blocker;
3. retain structured exception;
4. reap children;
5. close descriptors;
6. retain process ledger and streams;
7. retain complete partial-root inventory;
8. retain every generated-artifact identity;
9. retain indispensable evidence in the governing package;
10. derive cleanup registry from created roots;
11. revalidate root identity;
12. remove exact owned roots;
13. observe ENOENT twice;
14. require exact equality:
    created
    =
    inventoried
    =
    evidence-retained
    =
    cleanup rows
    =
    twice absent;
15. repeat supplied-root closing equality;
16. set package authority false;
17. set terminal seal false;
18. forbid same-root retry.

No path inside a subsequently removed root counts as retained evidence.

──────────────────────────────────────────────────────────────────────────────
16. TEMPORAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

At G26:

- namespace already frozen;
- `closeout/` already exists;
- `manifest/` already exists;
- every other nonmanifest output is final.

Generate:

closeout/temporal-final-inventory-v1.json

Projection requirements:

- include root row exactly once;
- include existing `closeout/`;
- include existing `manifest/`;
- exclude:
  - temporal inventory file itself;
  - manifest A;
  - manifest B;
- use stable contract field grammar;
- exclude mtime;
- exclude ctime;
- exclude directory size;
- exclude directory link count;
- canonical compact JSON plus newline.

Then:

- exclusively write;
- fsync;
- close;
- no-follow reopen;
- independently reproject immediately;
- require retained projection equals fresh projection.

Do not set `verified:true` before the independent reprojection passes.

──────────────────────────────────────────────────────────────────────────────
17. TERMINAL MANIFEST PAIR
──────────────────────────────────────────────────────────────────────────────

At G27:

1. `manifest/` already exists.
2. A and B are absent.
3. Exclusively create zero-length A and B.
4. Retain both descriptors.
5. Fsync both empty files.
6. Fsync `manifest/`.
7. Generate A and B independently with both paths excluded.
8. Require generated bytes identical.
9. Write A through retained A descriptor.
10. Fsync and close A.
11. Write B through retained B descriptor.
12. Fsync and close B.
13. Fsync `manifest/`.
14. Reopen A/B no-follow.
15. Verify original path/inode custody.
16. Verify type, mode, links, size, and SHA-256.
17. Require A/B equality.
18. Independently reproject final root.
19. Require final projection equals A/B.
20. Require root row exactly once.
21. Require no empty descendant.
22. Require no symlink or special object.
23. Require no multiply linked regular file.
24. Require modes 0700/0600.
25. Require no cache or bytecode.

At G29:

- transition seal exactly once;
- emit only guarded terminal marker;
- exit nonreturningly;
- perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
18. STATIC IMPLEMENTATION GATES
──────────────────────────────────────────────────────────────────────────────

For each complete source attempt:

1. Compile every source under pinned Python using:
   -I -S -B.

2. Require exit 0 and empty stderr.

3. Run AST/call-graph/dataflow analysis.

4. Run bytecode/exception-table/CFG analysis.

5. Crosswalk every source-level:
   - process launch;
   - filesystem write;
   - directory creation;
   - cleanup operation;
   - terminal operation.

Require:

- exactly one production parent;
- exactly one production recorder;
- no unregistered process launch;
- no unregistered write;
- no post-G25 directory creation;
- no duplicate writer;
- no successful second write;
- no overwrite;
- no result adoption;
- no network;
- no Git;
- no shell;
- no stdin read;
- no persistent loop;
- no import-time execution;
- no repository/product/target access;
- no production-reachable qualification hook;
- total JSON observation on untrusted data;
- all special cases explicit;
- complete failure finalization;
- exactly one terminal seal transition;
- no postseal filesystem operation.

A static aggregate must fail if any required field is false.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED QUALIFICATION MATRICES
──────────────────────────────────────────────────────────────────────────────

Implement and run at least the counts frozen in the Generation-2
qualification contract:

A. External-interface matrix

- at least 50 cases.

B. JSON-observation matrix

- at least 45 cases.

C. Schema/family matrix

- at least 30 cases.

D. Process-custody matrix

- at least 35 cases.

E. Cleanup/failure-evidence matrix

- at least 35 cases.

F. Writer/documentary-lifecycle matrix

- at least 40 cases.

G. Namespace/temporal matrix

- at least 40 cases.

H. Manifest/terminal matrix

- at least 35 cases.

I. Negative-checker robustness matrix

- at least 40 targeted cases in addition to the complete 946-case rehearsal
  execution.

Every matrix requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Each matrix must include the relevant exact historical defects frozen in the
Generation-2 defect catalogue.

──────────────────────────────────────────────────────────────────────────────
20. INDEPENDENT VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Implement all independent qualification roles required by:

analysis/gen2-source-architecture-v1.json

Independent validators may not import:

- production modules;
- producer helpers;
- producer mutation builders;
- producer expected-result maps;
- production JSON observers;
- production manifest row builders.

Independent validators must separately implement:

- strict parsing;
- typed pointer observation;
- root inventory;
- schema/family checks;
- negative-case adjudication;
- process-custody adjudication;
- namespace/temporal adjudication;
- manifest reprojection;
- rehearsal comparison.

An independent validator exception is a qualification failure.

──────────────────────────────────────────────────────────────────────────────
21. COMPLETE REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

After all component gates pass, allocate a disposable root:

ES-repair10i-v3-gen2-reconstruction-rehearsal-a-

Execute the exact production parent in `--mode reconstruct-subject`.

Use:

- pinned Python;
- `-I -S -B`;
- exact supplied roots;
- exact cwd;
- explicit environment;
- DEVNULL stdin;
- finite timeout;
- no shell.

Rehearsal A must execute G00–G29 completely and produce the exact 70-path,
58-file subject package.

Require fresh completion of:

- contract/schema copying;
- 15/14 registries;
- family reconstruction;
- witnesses;
- all 946 negative cases;
- all 137 contradiction cases;
- 766/333 field map;
- nine prerequisite validator results;
- confirmation map;
- confirmation validator;
- final ten-role registry;
- registry-derived regeneration;
- independent schema validator;
- confirmations;
- occupancy/status/lineage/report;
- cleanup;
- supplied-root equality;
- namespace finalization;
- temporal inventory;
- manifests;
- final reprojection;
- terminal topology;
- no postseal activity.

Required status:

rehearsal-passed-nonauthoritative

Rehearsal status must not claim independent package acceptance.

──────────────────────────────────────────────────────────────────────────────
22. COMPLETE REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Allocate a physically distinct root:

ES-repair10i-v3-gen2-reconstruction-rehearsal-b-

Run the same exact source bytes, argv shape, environment, and supplied inputs.

Require the same complete pipeline and terminal closure.

Retain:

validation/two-complete-gen2-rehearsals-v1.json

Normalize only explicitly physical bindings:

- root path;
- root device/inode;
- root-bound identities;
- PIDs;
- nonacceptance-bearing timestamps;
- other explicitly listed physical fields.

Require semantic equality for:

- contract bytes;
- schema identities;
- 15-role rows;
- 14-family rows;
- mapping;
- witnesses;
- all 946 results;
- all 137 results;
- all 766/333 field-map rows;
- ten-role registry;
- all validator results;
- confirmation semantics;
- occupancy;
- status;
- temporal projection semantics;
- normalized terminal manifests.

Require zero unexplained difference.

──────────────────────────────────────────────────────────────────────────────
23. INDEPENDENT REHEARSAL VALIDATION
──────────────────────────────────────────────────────────────────────────────

Run an independently written rehearsal validator against both roots.

It must independently verify:

- exact planned membership;
- no unplanned output;
- exact namespace and directories;
- exact contract and schemas;
- 15/14 closure;
- witness closure;
- 946/137 closure;
- field-map closure;
- ten-validator closure;
- documentary lifecycle;
- process custody;
- cleanup;
- supplied-root equality;
- temporal inventory;
- manifests;
- final reprojection;
- terminal topology;
- normalized determinism.

Require zero errors and no validator exception.

──────────────────────────────────────────────────────────────────────────────
24. EVIDENCE RETENTION AND REHEARSAL CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing either rehearsal root, retain inside the implementation package:

- exact root identity;
- complete physical inventory;
- complete process ledger;
- all stdout/stderr;
- every validation result identity;
- temporal and manifest identities;
- independent validator result;
- normalized comparison;
- terminal posture;
- failure evidence, when any.

Require a passing evidence-retention record before cleanup.

Then:

- re-lstat A and verify original identity;
- remove A;
- observe ENOENT twice;
- re-lstat B and verify original identity;
- remove B;
- observe ENOENT twice;
- require zero process survivor;
- require zero descriptor survivor;
- require zero cache/bytecode survivor.

Require exact set equality:

created rehearsal roots
=
inventoried rehearsal roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

──────────────────────────────────────────────────────────────────────────────
25. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze the production and qualification source registries only after:

- every static gate passes;
- every required matrix passes;
- both complete rehearsals pass;
- normalized determinism passes;
- independent rehearsal validation passes;
- rehearsal evidence retention passes;
- rehearsal cleanup passes.

Retain:

opening/gen2-implementation-source-freeze-v1.json

Bind:

- exact production source registry;
- exact qualification source registry;
- clean-room provenance;
- Generation-2 contract-package identity;
- operating-record identities;
- matrix identities;
- both rehearsal results;
- independent rehearsal result;
- cleanup;
- supplied-input identities;
- later source modification permitted:
  false;
- current schema subject constructed:
  false;
- one-shot authoritative use permitted:
  false;
- independent implementation audit required:
  true.

Reopen every source no-follow and verify exact identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
26. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source bytes, rerun:

- compilation;
- all static gates;
- source/import-boundary checks;
- every literal matrix;
- independent component validators;
- source identity linkage to both rehearsals;
- supplied-root equality.

Do not rerun the two complete rehearsals.

Require proof that both passing rehearsals used the exact bytes later frozen.

Retain:

validation/gen2-frozen-source-requalification-v1.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
27. IMPLEMENTATION-PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate a preterminal status record:

- status:
  gen2-reconstruction-parent-implemented-qualified-frozen-pending-independent-audit;
- authority:
  schema-subject reconstruction tooling only;
- current schema subject constructed:
  false;
- producer qualification:
  passed;
- independent implementation-package audit:
  not performed;
- one-shot current-subject use:
  not authorized;
- product implementation present:
  false;
- process-self-test:
  not executed;
- product construct mode:
  not executed;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- publication/deployment/A6:
  not authorized.

Do not claim implementation acceptance or current-subject readiness.

──────────────────────────────────────────────────────────────────────────────
28. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- Generation-2 contract package;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any other supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every implementation-owned fixture/cache root:

- retain complete pre-removal inventory;
- retain indispensable evidence;
- remove the exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
29. IMPLEMENTATION-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the same namespace discipline frozen for the future subject package.

Before temporal projection:

- create every final implementation-package directory, including
  `closeout/` and `manifest/`;
- finalize every nonclosure output;
- freeze the directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and future A/B;
2. write it into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. exclusively create zero-length A/B in preexisting `manifest/`;
6. retain both descriptors;
7. generate independent A/B bytes with both paths excluded;
8. require equality;
9. write/fsync/close;
10. fsync manifest directory;
11. reopen no-follow;
12. verify path/inode/type/mode/link/size/hash;
13. independently reproject final root;
14. require root row exactly once;
15. require no empty descendant;
16. require no symlink or special object;
17. require no multiply linked regular file;
18. require modes 0700/0600;
19. require no cache or bytecode;
20. transition seal exactly once;
21. emit only a guarded terminal marker;
22. exit nonreturningly;
23. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
30. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- first blocker;
- structured exception;
- complete parent/child ledger;
- stdout/stderr;
- complete partial-root inventory;
- indispensable evidence before cleanup;
- cleanup;
- supplied-root closing equality;
- implementation-package authority false;
- source freeze false unless already frozen;
- terminal seal false;
- same-root retry false.

Do not create success manifests on failure.

Failure to retain indispensable evidence, complete cleanup, or close supplied
roots equally is:

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

only when:

- Generation-2 package authenticates;
- clean-room provenance closes;
- source layout closes;
- implementation completes within three attempts;
- all static gates pass;
- all required matrices pass;
- all independent component validators pass;
- rehearsal A passes;
- rehearsal B passes;
- normalized rehearsal equality passes;
- independent rehearsal validator passes;
- evidence retention precedes cleanup;
- cleanup closes;
- sources freeze;
- frozen-source requalification passes;
- current subject remains unconstructed;
- supplied roots close equal;
- implementation package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_BLOCKED

when:

- implementation cannot satisfy the frozen Generation-2 contract within three
  attempts;
- a required source boundary cannot be implemented;
- a matrix or independent validator fails;
- either rehearsal fails;
- normalized rehearsal outputs diverge;
- implementation would require changing the normative contract, current
  schemas, case semantics, or Generation-2 operating model.

Return:

IMPLEMENTATION_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- fixed governing identity mismatch;
- source drift after freeze;
- unregistered process or filesystem effect;
- indispensable evidence lost before cleanup;
- cleanup inequality;
- supplied-root closing inequality;
- implementation-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh implementation-root identity
3. Generation-2 contract-package authentication
4. External authoritative-input identities
5. Clean-room source-authority result
6. Implementation operating freeze
7. Source-layout registry
8. Source-attempt ledger
9. Final production-source registry
10. Final qualification-source registry
11. Complete authority/nonauthority result
12. G00–G29 implementation crosswalk
13. Future namespace implementation result
14. Writer-registry implementation result
15. Documentary-lifecycle implementation result
16. External-interface implementation result
17. Total JSON-observation implementation result
18. Special-case implementation result
19. Process-custody implementation result
20. Failure-finalization implementation result
21. Compilation and static analyses
22. External-interface matrix
23. JSON-observation matrix
24. Schema/family matrix
25. Process-custody matrix
26. Cleanup/failure-evidence matrix
27. Writer/lifecycle matrix
28. Namespace/temporal matrix
29. Manifest/terminal matrix
30. Negative-checker robustness matrix
31. Independent component-validator results
32. Rehearsal A complete result
33. Rehearsal B complete result
34. Normalized rehearsal comparison
35. Independent rehearsal-validator result
36. Rehearsal evidence retention
37. Rehearsal cleanup
38. Source freeze
39. Frozen-source requalification
40. Confirmation current subject was not constructed
41. Implementation-package status
42. Supplied-root closing equality
43. Fixture/cache cleanup
44. Failure-closeout capability and usage
45. Temporal-inventory identity
46. Manifest A identity
47. Manifest B identity
48. Independent terminal reprojection
49. Terminal membership and modes
50. No-write-after-closure
51. Remaining uncertainty and nonclaims
52. Explicit confirmation registry

Required task-level confirmations:

GEN2_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
GEN2_CONTRACT_PACKAGE_IDENTITY_MATCHED
GEN2_CONTRACT_PACKAGE_TERMINAL_CLOSURE_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
NO_HISTORICAL_SOURCE_COPIED
NO_HISTORICAL_SOURCE_PATCHED
IMPLEMENTATION_OPERATING_FREEZE_COMPLETED_BEFORE_SOURCE
SOURCE_LAYOUT_REGISTRY_COMPLETE
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_PRODUCTION_SOURCE_REGISTRY_COMPLETE
FINAL_QUALIFICATION_SOURCE_REGISTRY_COMPLETE
ALL_24_PRODUCTION_COMPONENT_ROLES_IMPLEMENTED
ALL_9_QUALIFICATION_COMPONENT_ROLES_IMPLEMENTED
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
GEN2_AUTHORITY_SCOPE_PRESERVED
GEN2_NONAUTHORITY_SCOPE_PRESERVED
G00_G29_STATE_MACHINE_IMPLEMENTED
G00_G29_PHASE_ORDER_EXACT
EXACT_70_PATH_FUTURE_NAMESPACE_IMPLEMENTED
EXACT_58_FILE_FUTURE_NAMESPACE_IMPLEMENTED
ALL_FUTURE_DIRECTORIES_CREATED_AT_G04
NO_DIRECTORY_CREATION_AFTER_G25
CLOSEOUT_EXISTS_BEFORE_TEMPORAL_PROJECTION
MANIFEST_EXISTS_BEFORE_TEMPORAL_PROJECTION
TEMPORAL_PROJECTION_INCLUDES_CLOSEOUT
TEMPORAL_PROJECTION_INCLUDES_MANIFEST
PHASE_FUNCTION_PATH_WRITER_REGISTRY_ENFORCED
NO_FINAL_PATH_HAS_MULTIPLE_WRITERS
NO_SUCCESSFUL_SECOND_WRITE
NO_OVERWRITE_OR_FINAL_RESULT_ADOPTION
DOCUMENTARY_EVIDENCE_LIFECYCLE_ENFORCED
CONFIRMATION_VALIDATOR_RESULT_CREATED_EXACTLY_ONCE
FINAL_TEN_ROLE_REGISTRY_AFTER_ALL_RESULTS
DOCUMENTARY_REGENERATION_DERIVED_FROM_FINAL_REGISTRY
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
ALL_33_EXTERNAL_INTERFACES_IMPLEMENTED
NO_ACCEPTANCE_BEARING_POINTER_FALLBACK
TOTAL_JSON_OBSERVATION_IMPLEMENTED
NO_UNGUARDED_OBJECT_ACCESS_ON_UNTRUSTED_JSON
ALL_15_SPECIAL_CASES_IMPLEMENTED
NORMATIVE_CONSTRUCTION_PARENT_INTENTIONALLY_UNMAPPED
EXACTLY_14_GENERATED_FAMILIES
PROCESS_CUSTODY_CONTRACT_IMPLEMENTED
ALL_CHILDREN_ROUTED_THROUGH_SINGLE_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
FAILURE_EVIDENCE_RETAINED_BEFORE_CLEANUP
CLEANUP_SET_EQUALITY_ENFORCED
PRODUCTION_SOURCES_COMPILED
QUALIFICATION_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
EXTERNAL_INTERFACE_MATRIX_PASSED
JSON_OBSERVATION_MATRIX_PASSED
SCHEMA_ROLE_FAMILY_MATRIX_PASSED
PROCESS_CUSTODY_MATRIX_PASSED
CLEANUP_FAILURE_EVIDENCE_MATRIX_PASSED
WRITER_LIFECYCLE_MATRIX_PASSED
NAMESPACE_TEMPORAL_MATRIX_PASSED
MANIFEST_TERMINAL_MATRIX_PASSED
NEGATIVE_CHECKER_ROBUSTNESS_MATRIX_PASSED
INDEPENDENT_COMPONENT_VALIDATORS_PASSED
COMPLETE_REHEARSAL_A_PASSED
COMPLETE_REHEARSAL_B_PASSED
TWO_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_REHEARSAL_VALIDATOR_PASSED
REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP
REHEARSAL_ROOTS_CLEANED
FINAL_SOURCE_REGISTRIES_FROZEN
FINAL_SOURCES_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_PACKAGE_PENDING_INDEPENDENT_AUDIT
ONE_SHOT_CURRENT_SUBJECT_USE_NOT_AUTHORIZED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_CREATED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
IMPLEMENTATION_PACKAGE_MANIFEST_A_CREATED
IMPLEMENTATION_PACKAGE_MANIFEST_B_CREATED
IMPLEMENTATION_PACKAGE_MANIFESTS_BYTE_IDENTICAL
IMPLEMENTATION_PACKAGE_TERMINAL_REPROJECTION_PASSED
IMPLEMENTATION_PACKAGE_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

Also resolve every acceptance-bearing confirmation required by:

contract/gen2-implementation-qualification-v1.json

Do not mark a confirmation true merely because a phase was reached. Bind each
true value to exact retained evidence.

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

the next tranche is a fresh, source-external independent audit of this
implementation package.

Do not execute the frozen parent to construct the current schema subject until
that independent audit accepts the implementation package.
```

**Source:** Codex’s `SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION` report in this turn.  
**Confidence:** 0.99 that the governing operating model is now closed enough for implementation; 0.99 that implementation and current-subject construction must remain separate; 0.98 that the required independent implementation audit should remain the final gate before one-shot use.
