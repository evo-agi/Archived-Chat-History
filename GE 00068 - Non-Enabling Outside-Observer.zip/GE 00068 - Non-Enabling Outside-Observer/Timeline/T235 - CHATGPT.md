This closeout is sufficient. **The attempt is dead, but the audit target is not implicated.**

The first and only determinative failure was administrative prompt intake: the attachment-read process used the primary checkout as its cwd and requested a fixed line range rather than establishing complete intake through EOF. No earlier gate qualified.  No valid audit epoch, fresh audit root, bootstrap record, controlled environment, or correctness inspection followed.  No auditors, tests, causals, candidate inspection, supplied-root inspection, or closing provenance occurred. The retained evidence is therefore only enough to prove the process mismatch, not anything about the repository or correction capsule. 

So:

- **Do not repair the repository or correction capsule.**
- **Do not continue in that Codex chat.**
- **Do not reuse the failed attempt as audit evidence.**
- Run a wholly fresh audit.

There is also a process-design correction to make before retrying. The old prompt made platform-level prompt ingestion acceptance-bearing. That creates repeated no-value failures without strengthening target-byte assurance. Prompt intake should be explicitly **outside** the audit epoch; only the first target-facing process after an explicit epoch boundary should be acceptance-bearing.

The previous reconciliation also exposed the other process gap that the fresh audit must close: the retained root lacked the four auditor reports, auditor operand/process records, and proof that the fourth auditor completed before it was stopped. 

Paste the following **inline into a new Codex chat**, rather than attaching it as a text file.

```text
Perform a wholly fresh, independent, read-only audit of the Repair 10I A6
successor-governance logical-mode provenance correction.

This is a new audit. Do not resume, reinterpret, repair, or qualify any prior
audit attempt. Prior narrative verdicts are context only unless an exact
machine-readable input named below independently supports them.

PRIMARY OBJECTIVE

Determine whether the exact correction capsule validly repairs the predecessor
logical-mode provenance defect while preserving:

- the exact candidate repository bytes;
- the accepted governance-contract and documentary-test bytes;
- the predecessor implementation capsule as immutable historical evidence;
- the blocking audit as immutable finding evidence;
- narrow supersession limited to the three corrected delta records;
- complete capsule closure, builder independence, and nonauthority.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not mutate or repair any supplied input.

──────────────────────────────────────────────────────────────────────────────
A. PROMPT INTAKE AND AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Prompt intake is outside the audit epoch.

Any platform-managed or tool-managed operation used solely to place this full
prompt into model context is administrative and is not audit evidence. Such an
operation does not qualify or disqualify the audit merely because of its cwd,
provided that:

- it reads only the prompt attachment through an absolute operand;
- it does not run Git;
- it does not read repository or supplied-evidence content;
- it is not used to support any audit conclusion.

This prompt is being supplied inline, so do not run sed, cat, head, tail, or
another process merely to reread it.

After the complete prompt is available, state exactly:

AUDIT_EPOCH_START

The first post-epoch process must:

1. use cwd exactly:
   /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

2. explicitly receive:
   PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
   GIT_OPTIONAL_LOCKS=0
   GIT_CONFIG_NOSYSTEM=1
   LC_ALL=C
   LANG=C
   PYTHONDONTWRITEBYTECODE=1

3. set umask 077 internally;

4. perform no Git operation and read no target or supplied-root content;

5. atomically allocate an unpredictable fresh directory beneath
   /Users/ds/Downloads using tempfile.mkdtemp with prefix:

   ES-repair10i-a6-governance-mode-provenance-independent-audit-

6. create beneath it, mode 0700:

   opening/
   auditors/
   records/
   validation/
   closeout/
   tmp/

7. create an exclusive, regular, single-link, mode-0600 bootstrap record at:

   opening/bootstrap.json

The bootstrap record must contain:

- schema;
- audit objective;
- audit-root physical path, device, and inode;
- first-process cwd;
- exact explicit environment;
- effective umask;
- all four supplied-root paths;
- the forbidden primary-checkout path;
- epoch status;
- confirmation that no target content was read before bootstrap creation.

If this first post-epoch process does not satisfy every requirement, stop with
AUDIT_PROVENANCE_MISMATCH. Do not try to repair the attempt.

After bootstrap, all process TMPDIR values must be beneath AUDIT_ROOT/tmp.

Forbidden primary checkout:

/Users/ds/Repositories/Execution Substrate

After AUDIT_EPOCH_START, no process may use that path as cwd, Git target, content
operand, search root, module root, or relative-resolution base.

──────────────────────────────────────────────────────────────────────────────
B. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- device/inode: 16777234 / 122118502
- branch: codex/remote-alpha-external-tls-status-observation-v1
- HEAD: 567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree: b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent: 05dde14d185b6e022dcc169ef1a658a97961850f
- upstream: absent
- governed objects: 389
- tracked/untracked: 375 / 14
- directories: 93
- tracked modifications: 22
- staged/deleted/renamed/unmerged: 0 / 0 / 0 / 0
- source T: f276536fea579d0842cda43b0290656b200b7f27
- inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

The exact seven governed paths are:

1. PLANS.md
   288739 bytes
   f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f

2. .docs/system_overview/configuration.md
   129589 bytes
   f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3

3. .docs/system_overview/boundaries.md
   96086 bytes
   0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd

4. .docs/system_overview/artifact_hygiene.md
   38322 bytes
   2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910

5. .docs/system_overview/capability_probing.md
   42668 bytes
   f177f939932e21e8d53fe521aad9386253e330527b6a85eeb73c0888b1acdeb2

6. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
   99195 bytes
   18cfad593028ea25575d5e9593d95533cbda6400bba52897bba8a9ae4f17f32d

7. docs_contract_test.go
   794256 bytes
   e43d41791758e6e8ebf2e7fe585e7469f342d9eb3013171cc76bece662f02684

Do not substitute path aliases. In particular, do not substitute:

- service_boundaries.md for boundaries.md;
- an execution_lifecycle deployment path for the system_overview deployment
  path;
- an internal package path for docs_contract_test.go.

PREDECESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

Expected predecessor closure:

- device/inode: 16777234 / 177742499
- 10 directories
- 98 files
- inventory SHA-256:
  0036cb2e461a66c94fd29f9cde71fc9c51d2ceceddca0d2f6da421396d4ac2ac
- two canonical manifests:
  19136 bytes each
  SHA-256:
  1c07db3979d02afcf7852c6c4819630046950712426a267a4117a6774c28b751
- predecessor repair-only deltas:
  2474094 bytes each
  SHA-256:
  641612e748d2764d7a78d066d73b788fbc30b527b3088723a73d4dd8ac771021

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/repair10i-a6-governance-independent-audit-5n5vkzxr

Expected closure:

- device/inode: 16777234 / 177779617
- 4 directories
- 86 files
- inventory SHA-256:
  f64183e7bc5bc731afd291d2e773e2f0062796942a5eeff58918863fb3b37cac

CORRECTION_ROOT:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-repair-fsgu2x8c

Expected identity:

- device/inode: 16777234 / 177842688
- 7 directories
- 43 files
- canonical manifests A and B:
  8590 bytes each
  SHA-256:
  d7a0c0f376c1a52c2b9b6cdc2b64d43ce9cd2235602b71a2e15552746f6f7cde

Expected corrected deltas A and B:

- 2474094 bytes each
- byte-identical
- SHA-256:
  0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1

Important retained identities include:

- corrected delta identity record:
  d8682902a3f678a13502b693b1a90d2c309a32df6e23e965ac9973ae8c95ea6e

- authoritative supersession record:
  adb479a081cd8723be1842551a4b27e5ed3cdf4cec0dcd4a48dd47b3972c8495

- final correction report:
  1a79fab0360a9a56b6b6cf832eaab640b4c4f4f95582361c09205facf42dc07b

- builder A:
  8ffc4a85e6fe5765d36e9b2dc291fe742d42e673c394893b949758bd88cce65c

- builder B:
  16ff8dca1f481030834f84fbd18fc8443fcf67d4c04f6b275f4686891a1ae771

- independent validator:
  6a16ddc6f845cbf3a32f73456b3a57461e2ac2ce1ab894e67373411c2bcf558f

The prior narrative audit that lacked complete auditor reports and command
evidence is permanently nonqualifying. Do not use its ACCEPT wording as audit
evidence.

──────────────────────────────────────────────────────────────────────────────
C. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Independently enumerate candidate membership and source identity.
2. Verify every candidate identity above.
3. Verify complete predecessor, blocking-audit, and correction-root membership,
   types, modes, links, sizes, hashes, and manifest closure.
4. Verify that every supplied root is unchanged and read-only for this task.
5. Verify candidate Git identity using only explicitly rooted:
   git -C "$CANDIDATE_R" ...
   with cwd exactly CANDIDATE_R and the controlled environment.
6. Check staged, deleted, renamed, unmerged, ignored-extra, operation-marker,
   and lock posture.
7. Retain complete opening records beneath AUDIT_ROOT/opening.
8. Stop with AUDIT_PROVENANCE_MISMATCH before correctness inspection on any
   mismatch.

Do not chmod, normalize, clean, recreate, or repair any supplied root.

──────────────────────────────────────────────────────────────────────────────
D. REQUIRED FOUR AUDITORS
──────────────────────────────────────────────────────────────────────────────

After the opening gate passes, start exactly three distinct read-only auditors
concurrently:

1. delta_semantics
2. builder_independence
3. supersession_authority

After delta_semantics completes, start a fourth distinct auditor:

4. capsule_closure_security

Permit at most one start retry. If a required auditor cannot complete, stop with
AUDIT_PROVENANCE_MISMATCH.

No auditor may:

- write a file;
- run Git;
- run tests;
- import a repository module;
- use the network;
- inspect the primary checkout;
- create a nested subagent.

Each auditor must receive:

- the exact common target identities;
- absolute operands only;
- cwd exactly CANDIDATE_R;
- its bounded scope;
- explicit non-goals;
- the requirement to disclose uninspected scope and disagreements.

The parent must retain, mode 0600:

auditors/<role>.prompt.txt
auditors/<role>.report.md

Each report must state:

- canonical auditor identity;
- start and completion status;
- actual cwd;
- every absolute content operand read;
- commands used, or an explicit statement that no process was run;
- evidence, inference, and uncertainty separately;
- mutation performed: no;
- Git performed: no;
- nested subagents created: no;
- scope not inspected.

Also retain one schedule record containing all four auditor identities, start
order, completion order, retries, and proof that auditor 4 completed before
parent adjudication.

Do not silently replace a missing auditor report with parent inference.

──────────────────────────────────────────────────────────────────────────────
E. REQUIRED CORRECTNESS WORK
──────────────────────────────────────────────────────────────────────────────

The parent must independently perform and retain the following.

1. Predecessor-defect reproduction

Parse both predecessor deltas and prove that exactly these three logical
before-mode fields are wrong:

- .docs/system_overview/capability_probing.md
- .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
- docs_contract_test.go

For each:

- authenticated opening logical mode: 100644
- predecessor serialized before mode: 100600
- final logical mode: 100644

Confirm that the predecessor payload bytes, sizes, hashes, record order,
after-modes, delimiters, and terminal framing are otherwise authentic.

2. Independent corrected reconstruction

Without importing either correction builder or using the expected corrected
hash to construct output:

- parse the authenticated repair-opening inventory;
- parse the authenticated final inventory;
- bind the three exact authorized paths;
- obtain logical before-mode only from the opening inventory;
- obtain logical after-mode from the final inventory and corroborate it against
  the live candidate;
- bind exact before/after payload bytes;
- reconstruct the complete three-record delta.

Require the reconstructed bytes to equal both corrected delta copies.

3. Exact byte-difference proof

Prove:

- predecessor and corrected deltas have the same length;
- exactly six bytes differ;
- only the three logical before-mode fields change;
- each change is 100600 -> 100644;
- no path, payload, size, hash, after-mode, ordering, delimiter, or terminal byte
  differs.

4. Corrected identity

Independently hash the reconstruction and require:

0ea21358c208771a5dfd1d79d5d298e28cd68d8cd76e5b4c1a1576863df73ec1

5. Builder independence

Inspect both builders completely.

Determine whether:

- they independently parse the opening and final inventories;
- neither derives logical modes from 0600 evidence-custody copies;
- neither consumes the predecessor delta as construction input;
- neither embeds the expected corrected digest;
- neither imports a common local construction helper;
- any shared behavior is required by the frozen record grammar rather than
  hidden coupling.

State any uncertainty about historical authorship separately from executable
independence.

6. Independent mutation matrix

Run an audit-owned parser/validator that imports no correction builder.

It must reject at least these 13 mutations for specific reasons:

1. before mode 100600
2. before mode 100755
3. changed after mode
4. changed before hash
5. changed after hash
6. record reordering
7. added unauthorized path
8. removed required path
9. changed before payload byte
10. changed after payload byte
11. all logical modes forced to 100600
12. added trailing byte
13. truncated terminal byte

7. Supersession and authority

Verify that supersession is limited to:

- corrected delta A;
- corrected delta B;
- corrected delta identity record;
- corrected final report.

Verify that it does not rewrite or reclassify:

- candidate repository bytes;
- governance-contract bytes;
- documentary-test bytes;
- prior repository validation;
- predecessor capsule history;
- product/runtime/readiness/publication authority.

8. Candidate rebinding

Verify that the correction still binds to the exact intended seven paths and
that the sole governance writer remains:

.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md

Verify the five nonoverriding consumers remain:

PLANS.md
.docs/system_overview/configuration.md
.docs/system_overview/boundaries.md
.docs/system_overview/artifact_hygiene.md
.docs/system_overview/capability_probing.md

Verify docs_contract_test.go remains the documentary test.

Do not accept substituted path families.

9. Capsule closure and security

Verify:

- both correction manifests are byte-identical;
- they represent every directory and every nonmanifest file exactly once;
- only the two manifests are self-excluded;
- no empty, undeclared, symlink, special, multiple-link, or wrong-mode object;
- all directories 0700;
- all regular files single-link 0600;
- no secret, credential, private-key, token, or raw sensitive payload exposure;
- failed/superseded attempts remain separately indexed;
- no report overclaims product, runtime, readiness, or commit authority.

10. Repository validation treatment

Repository bytes did not change in the correction task. Do not treat correction
evidence as a substitute for prior repository validation.

Independently verify that retained prior validation and documentary-contract
evidence bind to the exact current candidate bytes. Rerun repository tests only
if required to resolve an actual uncertainty, and only with all generated state
confined beneath AUDIT_ROOT.

──────────────────────────────────────────────────────────────────────────────
F. PROCESS AND EVIDENCE RECORDS
──────────────────────────────────────────────────────────────────────────────

After bootstrap, run parent processes through an audit-owned wrapper that
creates, without overwrite:

- a start record before execution;
- stdout and stderr captures;
- an outcome record after execution.

For each parent process retain:

- ordinal;
- full argv;
- cwd;
- explicit environment;
- effective umask;
- start and end disposition;
- exit or signal;
- stdout and stderr byte counts and SHA-256;
- content operands;
- paths written.

Do not reconstruct missing records after the fact.

Subagent activity is evidenced through the retained prompt, report, and schedule
records required in section D. Do not claim unavailable low-level child process
telemetry.

──────────────────────────────────────────────────────────────────────────────
G. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After all four auditors and parent checks complete:

1. Remove only audit-owned temporary fixtures.
2. Do not chmod supplied roots.
3. Make two fresh observations that audit-private transient state is absent.
4. Recompute complete candidate and supplied-root inventories.
5. Repeat the exact candidate Git identity/status/diff/marker/lock checks.
6. Require opening and closing equality.
7. Verify every retained audit directory is 0700.
8. Verify every retained audit file is regular, single-link, 0600.
9. Verify no empty or unexplained audit directory.
10. Verify no process or open-descriptor survivor.
11. Retain a complete audit-root inventory and closing report.

Any missing process record, auditor report, auditor completion record, opening
or closing mismatch, wrong mode, unexplained object, or supplied-root mutation
requires AUDIT_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
H. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- opening and closing provenance qualify;
- all four auditors complete with retained reports;
- the predecessor defect is independently reproduced;
- both corrected deltas are independently reconstructed exactly;
- the six-byte-only correction is proved;
- the corrected digest is independently derived;
- all 13 audit mutations reject specifically;
- builder independence is sufficient;
- supersession is narrow;
- candidate rebinding is exact;
- capsule closure and security pass;
- no authority widening or acceptance-affecting residual finding remains.

Return BLOCK for a repairable target, correction-capsule, contract, security,
validation, or evidence defect.

Return REJECT only for a fundamental unsoundness that cannot be repaired within
the stated correction scope.

Return AUDIT_PROVENANCE_MISMATCH for process, opening, retained-record,
auditor-evidence, closing, or target-identity failure that prevents a qualified
correctness judgment.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
I. REQUIRED FINAL REPORT
──────────────────────────────────────────────────────────────────────────────

Provide one complete inline report covering:

1. Verdict
2. Administrative intake and exact audit-epoch start
3. Bootstrap and audit-root identity
4. Candidate and supplied-root identities
5. Opening provenance
6. Four auditor identities, schedule, prompts, operands, reports, and completion
7. Predecessor defect reproduction
8. Independent corrected reconstruction
9. Exact six-byte proof
10. Corrected delta identity
11. Builder-independence adjudication
12. Thirteen-case mutation matrix
13. Supersession and lineage
14. Candidate governance rebinding
15. Capsule closure and sensitive-material review
16. Validation treatment
17. Authority and nonauthority
18. Severity-ranked findings
19. Minority findings and parent resolution
20. Remaining uncertainty and explicit nonclaims
21. Audit-created paths and cleanup
22. Complete parent process-record disposition
23. Opening/closing equality
24. Explicit confirmations

The report must include concise provenance, validation, and implementation
confidence assessments.

Mandatory confirmations must truthfully address:

REPOSITORY_MUTATION_NOT_PERFORMED
PREDECESSOR_EVIDENCE_MUTATION_NOT_PERFORMED
CORRECTION_CAPSULE_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
PRIMARY_CHECKOUT_CONTENT_NOT_INSPECTED_POST_EPOCH
FOUR_AUDITOR_REPORTS_RETAINED
FORMATTING_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
A6_NOT_STARTED
NETWORK_CONTACT_NOT_PERFORMED
NESTED_SUBAGENTS_CREATED
```

The important change is not merely “use the right cwd.” It is that **administrative prompt ingestion is no longer part of the audit provenance boundary**. The audit boundary now starts at a deliberate, retained bootstrap process. That preserves strict target provenance while eliminating repeated failures caused by how ChatGPT/Codex happens to ingest an attachment.

**Sources:** The latest closeout establishes the failed intake gate, absence of any valid audit epoch, and the required discard-and-restart disposition.    The prior reconciliation identifies the missing auditor reports, operand/process records, and fourth-auditor completion evidence that the new prompt explicitly retains. 

**Confidence:** 0.99 that no implementation repair is warranted; 0.97 that the revised epoch/bootstrap design is the right way to stop this audit chain from failing repeatedly on non-substantive prompt-intake mechanics.
