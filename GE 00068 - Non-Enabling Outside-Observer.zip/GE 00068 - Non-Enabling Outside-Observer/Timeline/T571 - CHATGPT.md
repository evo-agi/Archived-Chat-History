## Engineering assessment

This run produced a **validly launched and terminally closed audit capsule**, but not a valid subject verdict.

The external path is finally proven end to end:

- current PYZ, runtime authority, profile v4, and certificate v5 authenticated;
- the split-root workspace/capsule lifecycle worked;
- platform preflight passed;
- the audit parent was created exactly once and exited `0`;
- stdout contained one canonical terminal frame;
- the capsule root was created by the frozen runtime at the exact governed child path;
- all fixed inputs closed equal;
- all phases were terminal;
- temporal inventory, manifests, reprojection, topology, A15, seal, and no-postseal checks passed. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The embedded `SUBJECT_AUDIT_BLOCK` is nevertheless nonauthoritative. The wrapper correctly demoted it to `AUDIT_PROVENANCE_MISMATCH`. :chatgpt-content-reference{index="2"}

### Exact defect

The current subject’s retained 946-case matrix says:

- 946 cases present;
- matrix pass;
- zero false acceptances;
- zero false rejections;
- zero reason mismatches;
- zero skips;
- zero exceptions;
- zero nonpassing rows. :chatgpt-content-reference{index="3"}

The 137-case regression also reports all 137 passing, with no nonpassing rows. :chatgpt-content-reference{index="4"}

The frozen audit harness nevertheless projected **907 passing 946 rows as direct subject blockers**. Both audit oracles made the same semantic mistake: they compared a governed reason class such as `required` directly against free-form descriptive reason text. The row remained `pass:true`, but the reason-text comparison generated a false mismatch and was promoted to a blocker. :chatgpt-content-reference{index="5"}

Those 907 findings are not valid blockers:

- every cited row says `pass:true`;
- there are no genuine nonpassing 946 or 137 rows;
- the findings omit mandatory governing pointers and actionable repair fields;
- their generic subject ownership is therefore nonoperative. :chatgpt-content-reference{index="6"}

All other independently reached substantive domains passed:

- 15 schema roles and 14 generated families;
- role/family mapping;
- Draft 2020-12 validation;
- 28 witness rows;
- 766/333 field-map closure;
- all ten documentary validators;
- confirmation derivation;
- role occupancy and lineage. :chatgpt-content-reference{index="7"}

### Current classification

```text
INDEPENDENT_AUDIT_946_REASON_CLASS_AND_FINDING_PROJECTION_DEFECT
```

Primary repair owners:

```text
INDEPENDENT_AUDIT_OUTCOME_PROJECTION
INDEPENDENT_AUDIT_FINDING_PROJECTION
```

This is not an established defect in:

- the replacement subject;
- its schemas or generated families;
- the 946- or 137-case specifications;
- reconstruction;
- the accepted implementation package;
- launch authority;
- capsule closure.

The subject remains unchanged and **independent acceptance remains unadjudicated**. The capsule and wrapper are useful as a regression corpus, but the raw BLOCK cannot be promoted. The certificate-v5 authorization was consumed by the successful process creation, so it cannot be reused. :chatgpt-content-reference{index="8"}

## Progression decision

Create one bounded successor audit-harness generation from the authenticated current clean source.

Do not reconstruct the subject. Do not create another documentary contract generation. Repair only:

1. structured 946 outcome/reason-class projection;
2. dual-oracle projection independence;
3. direct-finding eligibility and ownership;
4. disposition derivation from valid findings;
5. any directly affected confirmations and qualification.

The repaired audit must never compare governed reason classes to free-form report prose. It must derive observed semantic outcomes from structured fields or independent re-execution. If a semantic class cannot be derived unambiguously, that is audit provenance failure—not a subject blocker.

---

## Complete replacement Codex prompt

```text
REPAIR THE CLEAN INDEPENDENT-AUDIT HARNESS’S 946-CASE
REASON-CLASS AND DIRECT-FINDING PROJECTION

REQUALIFY, FREEZE, PACKAGE, AND AUTHORIZE ONE SUCCESSOR REAL AUDIT

DO NOT EXECUTE THE REAL SUBJECT AUDIT IN THIS TASK

Objective

Repair the frozen independent-audit harness after its single authorized real
audit produced a terminally closed but nonpromotable:

SUBJECT_AUDIT_BLOCK

The external wrapper correctly returned:

AUDIT_PROVENANCE_MISMATCH

The real audit completed with valid launch custody and a valid terminal capsule.

The exact demonstrated defect is:

1. the replacement subject’s current 946-case matrix contains exactly 946 rows
   and reports pass;
2. it reports zero false acceptance, false rejection, reason mismatch, skip,
   exception, or nonpassing row;
3. the current 137-case regression contains 137 rows and reports pass with zero
   nonpassing row;
4. the frozen audit harness nevertheless projected 907 passing 946 rows,
   ordinals 1–907, as direct subject blockers;
5. both audit oracles compared a governed expected reason class, for example
   `required`, directly against descriptive reason prose;
6. both oracles therefore agreed on the same invalid projection;
7. every projected blocker’s evidence row retained `pass:true`;
8. no genuine nonpassing 946 or 137 row exists in the retained capsule;
9. the 907 findings omit mandatory governing pointers and actionable repair
   fields;
10. the embedded BLOCK cannot be promoted.

Repair only the clean audit harness.

Do not mutate, repair, reconstruct, clean, chmod, relocate, or reseal the
replacement subject.

Do not execute the real replacement-subject audit in this task.

Do not issue a subject ACCEPT or BLOCK.

Do not promote or rebind current schema authority.

Do not modify the accepted reconstruction-parent implementation.

Do not change:

- the normative contract;
- current schema bytes;
- the 15-role schema model;
- the 14-family model;
- role/family mapping;
- the 946-case registry;
- the 137-case registry;
- case expectations;
- witness semantics;
- field-map semantics;
- documentary-validator semantics;
- confirmation-evidence specifications;
- subject package contents;
- split-root launch lifecycle;
- platform-preflight controls;
- external process posture.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one bounded successor source-repair attempt in one fresh private repair
root.

If that one successor candidate cannot fully qualify, stop with BLOCKED. Do not
continue localized patching in this task.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIR_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT AUDIT PYZ V2
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUDIT_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit-v2.pyz

Expected identity:

- device:
  16777234
- inode:
  182785051
- mode:
  0400
- link count:
  1
- size:
  4216423
- SHA-256:
  d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19

Authenticate with two stable no-follow reads.

Resolve source exclusively through:

- embedded member registry;
- source registry;
- source freeze;
- runtime authority.

Do not select source by basename, similarity, hash search, historical build
root, decompilation, or transcript reconstruction.

Classify after successor closure as:

HISTORICAL_CONSUMED_AUDIT_HARNESS_WITH_946_PROJECTION_DEFECT

Do not mutate it.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. CURRENT RUNTIME AUTHORITY V2
──────────────────────────────────────────────────────────────────────────────

CURRENT_RUNTIME_AUTHORITY_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.authority-v2.json

Expected identity:

- device:
  16777234
- inode:
  182785057
- mode:
  0400
- link count:
  1
- size:
  47750
- SHA-256:
  64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec

Strict-parse using UTF-8, duplicate-key rejection, and nonfinite-number
rejection.

Authenticate:

- current source freeze;
- source registries;
- member registry;
- 15/14 model;
- complete 946 and 137 vocabularies;
- total-documentary-checking contract;
- dual-oracle contract;
- finding contract;
- current package qualification;
- historical real-audit count:
  one;
- historical subject verdict:
  not issued.

Do not mutate it.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO CONSUMED AUTHORITY
────────────────────────────────────────────────

3. CONSUMED PROFILE V4 AND CERTIFICATE V5

CONSUMED_PROFILE_V4:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json

Expected identity:

- device:
  16777234
- inode:
  182800237
- mode:
  0400
- link count:
  1
- size:
  12763
- SHA-256:
  d31ad9f854399f62dcc484f235f707ec3daaf8ad23e123a5e4600ef74cbcafab

CONSUMED_CERTIFICATE_V5:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json

Expected identity:

- device:
  16777234
- inode:
  182800243
- mode:
  0400
- link count:
  1
- size:
  34814
- SHA-256:
  f753ed8adfbee2ff122fe63f54fbcaca833ca1694e6f284baf0edba018f9211a

Authenticate their exact identities.

Required disposition after successor closure:

- profile v4 current:
  false;
- certificate v5 current:
  false;
- certificate-v5 authorization consumed:
  true;
- certificate-v5 active authorization count:
  zero;
- mutation:
  forbidden;
- deletion:
  forbidden.

Do not reuse the consumed authorization.

──────────────────────────────────────────────── LIMITED TO REGRESSION CORPUS
────────────────────────────────────────────────

4. FAILED REAL-AUDIT WRAPPER, WORKSPACE, AND CAPSULE

FAILED_REAL_AUDIT_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-f7fwcw3m

Expected identity:

- device:
  16777234
- inode:
  182808075
- mode:
  0700
- UID/GID:
  501/0

FAILED_REAL_AUDIT_WORKSPACE:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-li_3jihu

Expected identity:

- device:
  16777234
- inode:
  182808076
- mode:
  0700
- UID/GID:
  501/0

FAILED_REAL_AUDIT_CAPSULE:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-li_3jihu/audit-capsule

Expected identity:

- device:
  16777234
- inode:
  182808084
- mode:
  0700
- UID/GID:
  501/0

Expected wrapper verdict:

AUDIT_PROVENANCE_MISMATCH

Expected raw harness disposition:

SUBJECT_AUDIT_BLOCK

Expected audit temporal record:

- mode:
  0600
- size:
  2448
- SHA-256:
  05c4ed679e808f3bffcf7f0568cd92b155b95c6dea4ab697ac0e7e2aca356036

Expected audit manifest pair:

- mode:
  0600
- size:
  2560 each
- SHA-256:
  8d714df8c96cccafb91edae62ce048d064be657e70f66877346de40ec539cffc

Expected terminal-record SHA-256:

f9297204749332b2ac06a94dc3f0e3036ff0568a8f74a6dd5e5cf55a9e0db7a9

Authenticate read-only:

- process custody;
- raw streams;
- terminal frame;
- capsule closure;
- current subject evidence;
- 946 result;
- 137 result;
- dual-oracle crosswalk;
- findings;
- repair-owner registry;
- phases;
- cleanup;
- input equality;
- manifests and terminal record.

Use this capsule only as a regression corpus.

Do not execute source from the wrapper or capsule.

Do not adopt its raw BLOCK.

Require opening/closing equality.

Classify:

HISTORICAL_NONQUALIFYING_946_REASON_CLASS_AND_FINDING_PROJECTION_FAILURE

────────────────────────────────────────────────

5. REPLACEMENT SUBJECT

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID/GID:
  501/20

Expected canonical inventory SHA-256:

eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

Authenticate read-only.

The subject may be used only for:

- manifest/path/role authentication;
- 946 projection compatibility;
- 137 regression preservation;
- subject-input compatibility;
- source-external qualification that issues no subject verdict.

Do not run the real audit.

Do not mutate or clean the subject.

Require opening/closing equality.

────────────────────────────────────────────────

6. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID/GID:
  501/0

Expected canonical inventory SHA-256:

9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e

Authenticate only construction provenance and terminal closure.

Require opening/closing equality.

────────────────────────────────────────────────

7. CURRENT CONTENT AUTHORITY

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before ZIP interpretation.

Resolve current authority for:

- 946-case registry and row schema;
- 137-case registry and row schema;
- subject result-record schemas;
- reason/outcome vocabularies;
- finding schema;
- confirmation schema;
- role registries.

Require opening/closing equality.

────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Authenticate only the accepted implementation chain and construction
provenance.

Do not re-audit implementation.

Require opening/closing equality.

────────────────────────────────────────────────

9. FRESH REPAIR AND OUTPUT ROOTS

Allocate one fresh private repair root beneath `/private/tmp`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:
  ES-repair10i-v3-replacement-subject-audit-outcome-projection-repair-

Immediately emit:

AUDIT_OUTCOME_PROJECTION_REPAIR_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:
  ES-repair10i-v3-replacement-subject-audit-outcome-projection-output-

Immediately emit:

AUDIT_OUTCOME_PROJECTION_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit-v3.pyz

gen2-replacement-schema-subject-independent-audit.authority-v3.json

gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json

The output directory is nonauthoritative.

Before source extraction retain:

opening/bootstrap-start.json
opening/outcome-projection-repair-authority-v1.json
opening/fixed-input-registry-v1.json
opening/consumed-audit-disposition-v1.json
opening/source-adoption-authority-v1.json
opening/process-execution-policy-v1.json
opening/implementation-operating-freeze-v1.json

────────────────────────────────────────────────

10. CURRENT SOURCE ADOPTION

Extract current source only through:

- PYZ member registry;
- source registry;
- source freeze;
- runtime authority.

Copy exact source members byte-for-byte into the fresh repair root using:

- stable ZIP reads;
- exclusive creation;
- mode 0600;
- exact identity verification.

Retain:

opening/adopted-source-registry-v1.json
opening/adopted-source-copy-result-v1.json

Require:

- complete source-role set;
- zero missing source;
- zero extra source;
- zero transformed source;
- no line-ending normalization;
- no generated substitute.

Classify:

AUTHENTICATED_CURRENT_CLEAN_AUDIT_SOURCE_REPAIR_BASE

────────────────────────────────────────────────

11. EXACT DEFECT CROSSWALK

Before source modification retain:

analysis/946-reason-class-projection-defect-crosswalk-v1.json

Crosswalk:

- current 946 case-specification row schema;
- current subject 946 result-row schema;
- current governed outcome vocabulary;
- primary oracle source;
- secondary oracle source;
- shared and independent code paths;
- finding projector;
- repair-owner projector;
- A07 phase projector;
- A13 disposition projector;
- explicit-confirmation projector.

Authenticate the exact historical facts:

- 946 subject rows:
  946;
- subject matrix pass:
  true;
- genuine nonpassing rows:
  zero;
- projected direct blockers:
  907;
- projected blocker ordinals:
  1–907;
- historical 137 nonpassing rows:
  zero;
- both oracles agreed;
- agreement resulted from a shared semantic defect;
- representative expected reason class:
  `required`;
- compared observed value:
  descriptive reason prose;
- direct-blocker standard:
  not satisfied;
- outcome projection:
  invalid.

For every affected source path retain:

- member path;
- function/class;
- AST node;
- call chain;
- input fields;
- output fields;
- authority effect;
- repair owner.

Classify:

INDEPENDENT_AUDIT_946_REASON_CLASS_AND_FINDING_PROJECTION_DEFECT

────────────────────────────────────────────────

12. STRUCTURED 946 RESULT-SEMANTICS CONTRACT

Retain:

contract/structured-946-result-semantics-v1.json

For every 946 row define separate typed fields for:

A. Governed expectation

- expected acceptance posture;
- expected exact outcome token;
- expected semantic reason class;
- governing specification pointer.

B. Independently observed semantics

- observed acceptance posture;
- observed exact outcome token;
- observed semantic reason class;
- validator keyword;
- instance path;
- schema path;
- structured documentary-check result.

C. Report-only fields

- descriptive reason text;
- human-readable explanation;
- producer narrative.

Rules:

1. descriptive reason text is never compared directly with a governed reason
   class;

2. no substring, regular-expression, fuzzy, similarity, or natural-language
   matching may derive a semantic reason class;

3. observed semantic reason class must come from:
   - an exact structured result field;
   - independently observed validator keyword plus frozen exact mapping;
   - independently executed documentary rule plus frozen exact mapping;

4. producer `pass:true` is evidence but not the sole authority;

5. an independent semantic mismatch may override producer `pass`, but only when
   exact structured evidence is retained;

6. when observed semantic classification is absent, ambiguous, or unsupported:
   - classify audit provenance failure;
   - do not emit a subject blocker;

7. one row passes only when all governed semantic dimensions match;

8. a nonpassing row must identify the exact mismatched dimensions;

9. no audit exception counts as a subject rejection.

────────────────────────────────────────────────

13. INDEPENDENT REASON-CLASS PROJECTION

Primary and secondary oracles must independently derive observed reason class.

They may share:

- immutable case bytes;
- immutable schema bytes;
- authenticated JSON Schema library;
- frozen governed vocabulary.

They must not share:

- observed-reason projector;
- validator-keyword mapping implementation;
- documentary-rule implementation;
- error normalization;
- row-pass aggregation;
- finding projection.

Retain:

contract/dual-reason-class-projection-v1.json

Require an independently authored crosswalk validator.

Any unexplained disagreement forces audit provenance failure.

────────────────────────────────────────────────

14. DIRECT-FINDING ELIGIBILITY CONTRACT

Retain:

contract/direct-subject-finding-eligibility-v1.json

A 946 row may create a direct subject finding only when:

- both independent oracles completed without exception;
- both oracles agree on observed semantic outcome;
- observed semantics mismatch governed expectation;
- exact mismatched dimensions are retained;
- direct evidence is non-null;
- governing specification pointer is present;
- primary repair owner is present;
- exact repair surface is present;
- subject-byte-change posture is present;
- reconstruction posture is present;
- unchanged-subject re-audit posture is present.

A row with `pass:true` and no independently established mismatch cannot create a
finding.

A descriptive-text mismatch alone cannot create a finding.

Finding count must equal exact independently nonpassing-row count.

No aggregate finding may exist without member rows.

If finding schema completeness fails:

- audit provenance mismatch;
- no subject BLOCK promotion.

────────────────────────────────────────────────

15. DISPOSITION AND PHASE DERIVATION

Retain:

contract/audit-disposition-from-valid-findings-v1.json

Require:

- A07 evidence derives from all 946 exact row results;
- A07 direct findings derive only from valid nonpassing rows;
- A13 direct blocker count derives only from valid direct findings;
- subject BLOCK requires one or more valid direct findings;
- zero valid direct findings cannot produce BLOCK;
- invalid projected findings produce audit provenance failure;
- derivative confirmations do not affect direct blocker count;
- explicit confirmations derive from actual findings and evidence;
- phase records may not claim successful package BLOCK when blocker validity is
  false.

Do not alter general phase lifecycle or terminal closure semantics.

────────────────────────────────────────────────

16. BOUNDED SOURCE REPAIR

Permit source changes only to:

- primary 946 observed-reason projection;
- secondary 946 observed-reason projection;
- exact structured-reason mapping owned by each oracle;
- 946 row-pass aggregation;
- direct-finding projection;
- repair-owner projection when a valid finding exists;
- A07/A13 disposition derivation;
- directly affected confirmation derivation;
- directly affected qualification and independent-validator sources.

Do not change:

- subject-input resolver;
- ten-role dependency registry;
- 15/14 model;
- 946 case registry or expectations;
- 137 case registry or expectations;
- witness logic;
- field-map logic;
- documentary-validator logic;
- subject semantic contracts;
- split-root launch controls;
- capsule terminal lifecycle;
- no-VCS policy.

Retain:

analysis/predecessor-to-successor-source-delta-v1.json
contract/protected-source-surface-v1.json

Require all unrelated functions AST-identical.

One successor source candidate only.

If qualification fails, stop with BLOCKED.

────────────────────────────────────────────────

17. 946 PROJECTION QUALIFICATION MATRIX

Run at least 100 uniquely named cases.

Required cases include:

A. Historical regression

- all 946 historical capsule rows;
- all 907 historically misprojected rows;
- expected outcome:
  zero direct blockers;
- expected provenance errors:
  zero when structured semantics are complete.

B. Reason class versus prose

- expected class `required`, descriptive prose differs;
- different prose, same structured class;
- identical prose, wrong structured class;
- prose contains expected class as substring;
- prose omits expected class;
- empty prose;
- null prose;
- array/object prose field.

C. Structured semantics

- exact structured reason match;
- structured reason mismatch;
- acceptance mismatch only;
- outcome-token mismatch only;
- validator-keyword mismatch;
- documentary-rule mismatch;
- multiple mismatches;
- missing structured reason;
- ambiguous structured reason;
- unsupported validator keyword.

D. Producer pass field

- producer pass true and independent match;
- producer pass true and independent mismatch;
- producer pass false and independent match;
- producer pass false and independent mismatch;
- pass missing;
- pass wrong type.

E. Oracle independence

- exact agreement;
- intentional primary defect;
- intentional secondary defect;
- disagreement;
- primary exception;
- secondary exception.

F. Finding projection

- zero nonpassing rows;
- one genuine nonpassing row;
- multiple genuine nonpassing rows;
- descriptive-text-only difference;
- missing governing pointer;
- missing repair owner;
- missing repair surface;
- invalid aggregate without rows.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception;
- zero unexplained oracle disagreement.

Retain:

validation/946-outcome-projection-matrix-v1.json

────────────────────────────────────────────────

18. EXACT REPLACEMENT-SUBJECT 946 COMPATIBILITY

Run one source-external read-only compatibility projection over the exact
replacement subject’s current 946 case/result rows.

This is not the real subject audit and issues no subject verdict.

Require:

- exact subject identity;
- exact 946 case registry;
- exact 946 result rows;
- 946 unique names;
- both successor oracles evaluate every row;
- no exception;
- exact oracle agreement;
- zero descriptive-text-only mismatches;
- exact semantic mismatch rows retained, if any;
- no finding or final disposition emitted.

Retain:

validation/replacement-subject-946-projection-compatibility-v1.json

Expected from the historical retained evidence:

- producer matrix pass true;
- producer nonpassing rows zero.

Do not hard-code that expectation into the evaluators.

If the successor compatibility result finds a genuine semantic mismatch, retain
the exact row but do not issue a subject verdict in this task.

────────────────────────────────────────────────

19. REGRESSION PRESERVATION

Rerun unchanged:

- source/input-role resolution qualification;
- exact ten-role dependency closure;
- 15/14 model qualification;
- full 946 vocabulary closure;
- full 137 vocabulary closure;
- complete 137 projection qualification;
- total-documentary checking;
- witness qualification;
- field-map qualification;
- documentary-validator qualification;
- confirmation qualification;
- occupancy vocabulary;
- physical closure/A15 qualification;
- no-Git/VCS qualification;
- split-root launch qualification;
- all prior historical missing-path regressions.

Require exact prior case names and expected outcomes.

No existing semantic expectation may change.

────────────────────────────────────────────────

20. PACKAGED SUCCESSOR REHEARSALS

Build one provisional successor package and run physically distinct rehearsals.

A. ACCEPT

- 946 rows semantically pass;
- descriptive reason prose differs from reason classes where appropriate;
- zero direct findings;
- terminal ACCEPT capsule.

B. DIRECT 946 BLOCK

- one exact structured reason-class mismatch;
- one exact direct finding;
- complete repair-owner fields;
- terminal BLOCK capsule.

C. AUDIT PROVENANCE — AMBIGUOUS REASON

- observed semantic reason cannot be uniquely derived;
- terminal provenance-mismatch capsule;
- no subject verdict promotion.

D. HISTORICAL 907-PROJECTION REGRESSION

- replay the historical capsule’s 946 rows;
- zero direct findings;
- no BLOCK;
- terminally closed expected disposition.

E. FINDING-SCHEMA FAILURE

- one semantic mismatch but incomplete mandatory repair fields;
- provenance mismatch;
- no BLOCK promotion.

Every rehearsal must:

- use packaged successor source;
- retain complete process custody;
- retain exact 946 rows;
- retain phase records;
- retain findings;
- retain cleanup and supplied-input equality;
- create temporal inventory and byte-identical manifests;
- pass final reprojection;
- make A15 equal final closure;
- perform no postseal operation;
- pass independent capsule validation.

Do not run the real replacement-subject audit.

────────────────────────────────────────────────

21. INDEPENDENT SUCCESSOR VALIDATION

Create independently authored validators that import neither:

- successor oracles;
- projection helpers;
- matrix generators;
- expected-result maps;
- finding projectors;
- disposition projectors.

Independently validate:

- structured 946 semantics contract;
- primary/secondary independence;
- all 946 projection matrix cases;
- historical 907-row regression;
- replacement-subject compatibility result;
- finding count equals exact nonpassing-row count;
- every finding satisfies mandatory schema;
- disposition derives from valid direct findings;
- unchanged 137 semantics;
- packaged rehearsal capsules;
- terminal lifecycle;
- no-Git posture.

Require zero errors.

────────────────────────────────────────────────

22. SOURCE FREEZE

Freeze successor source only after:

- compilation passes;
- static qualification passes;
- 946 projection matrix passes;
- subject compatibility completes;
- all regression suites pass;
- packaged rehearsals pass;
- independent validation passes.

Retain:

opening/successor-audit-source-freeze-v2.json

Bind:

- predecessor source identities;
- exact bounded delta;
- projection contracts;
- qualification results;
- compatibility result;
- rehearsals;
- future invocation;
- real audit not executed;
- subject verdict not issued;
- later modification forbidden.

Reopen all sources no-follow.

Do not modify afterward.

────────────────────────────────────────────────

23. DETERMINISTIC SUCCESSOR AUDIT PYZ V3

Build independently twice:

gen2-replacement-schema-subject-independent-audit-v3.pyz

Require byte equality.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- `create_system=3`;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special member;
- no comments or uncontrolled extras;
- no cache/bytecode.

Embed:

- successor source;
- source freeze;
- structured 946 semantics contract;
- dual projection contract;
- finding eligibility contract;
- disposition contract;
- all unchanged governing contracts;
- qualification and rehearsal evidence;
- future real-audit invocation;
- no historical source.

Retain exact member registry and count.

────────────────────────────────────────────────

24. SUCCESSOR RUNTIME AUTHORITY V3

Build independently twice:

gen2-replacement-schema-subject-independent-audit.authority-v3.json

Bind:

- successor PYZ v3;
- successor source freeze;
- source registries;
- predecessor PYZ/authority and consumed disposition;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation chain;
- current root inventories;
- projection repair contracts;
- qualification and rehearsal evidence;
- future invocation;
- real audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Require byte equality.

────────────────────────────────────────────────

25. POST-PACKAGE QUALIFICATION

Run the exact successor PYZ v3 in qualification mode once with authority v3.

Retain full custody.

Require:

- PYZ/member closure;
- source freeze;
- projection-repair contracts;
- 946 matrix;
- historical regression;
- replacement-subject compatibility linkage;
- all unchanged qualification;
- packaged rehearsals;
- independent validators;
- deterministic package closure;
- no real subject audit;
- no subject verdict.

────────────────────────────────────────────────

26. SUCCESSOR LAUNCH PROFILE V5

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-profile-v5.json

Preserve byte-for-byte semantic execution controls from profile v4:

- interpreter and isolation flags;
- split-root workspace/capsule lifecycle;
- cwd;
- five-row environment;
- stdin;
- shell;
- TTY;
- detachment;
- platform preflight;
- stream framing;
- authorization-consumption rule;
- current canonical root inventories.

Update only:

- successor PYZ identity;
- successor runtime-authority identity;
- successor invocation;
- profile identity/version;
- predecessor profile-v4 lineage;
- current/historical posture.

Require deterministic byte equality and mode 0400.

────────────────────────────────────────────────

27. SUCCESSOR LAUNCH CERTIFICATE V6

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v6.json

Bind:

- profile v5;
- successor PYZ v3;
- successor authority v3;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation chain;
- source freeze;
- projection repair contracts;
- qualification and rehearsal evidence;
- unchanged split-root policy;
- unchanged framing contract;
- certificate v5:
  historical and consumed;
- exactly one active successor real-audit authorization;
- real audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Require deterministic byte equality and mode 0400.

Run independent certificate-input validation.

────────────────────────────────────────────────

28. FROZEN-PACKAGE REQUALIFICATION

Run final successor PYZ v3 in qualification mode with final authority v3.

Require:

- exit zero;
- empty stderr;
- package/source self-authentication;
- 946 projection repair closure;
- historical 907-row regression;
- replacement-subject compatibility linkage;
- all unchanged qualification;
- packaged rehearsal linkage;
- authority coherence;
- no real subject audit;
- no subject verdict.

Independently recompute all aggregates.

Retain:

validation/frozen-successor-audit-v3-requalification-v1.json

────────────────────────────────────────────────

29. CURRENT SUCCESSOR AUTHORITY REGISTRY

Retain:

contract/current-successor-audit-authority-role-registry-v2.json

Current roles:

- successor audit PYZ v3;
- successor runtime authority v3;
- successor launch profile v5;
- successor launch certificate v6.

Historical roles:

- audit PYZ v2;
- runtime authority v2;
- profile v4;
- certificate v5;
- all earlier audit and launch artifacts.

Require:

- exactly one current artifact per role;
- no ambiguity;
- predecessor certificate-v5 authorization consumed;
- successor authorization unconsumed;
- total active future real-audit authorization:
  one.

────────────────────────────────────────────────

30. INPUT CLOSING EQUALITY AND CLEANUP

Repeat complete opening/closing equality for every supplied input opened:

- current PYZ v2;
- current authority v2;
- consumed profile v4;
- consumed certificate v5;
- failed real-audit wrapper/workspace/capsule;
- replacement subject;
- construction wrapper;
- content bundle and authority;
- accepted implementation roots.

Do not mutate supplied inputs.

Before removing disposable roots retain complete evidence.

Revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

────────────────────────────────────────────────

31. FAILURE CLOSEOUT

On failure retain:

- first blocker;
- source-development state;
- defect crosswalk;
- bounded delta;
- process custody and streams;
- matrix results;
- compatibility result;
- rehearsal results;
- partial output inventory;
- cleanup;
- input equality;
- predecessor/successor authority posture;
- real audit not executed;
- subject verdict not issued.

Do not create current successor authority on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

32. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

only when:

- every fixed input authenticates;
- exact projection defect crosswalk closes;
- structured 946 result semantics freeze;
- both observed-reason projectors qualify independently;
- direct-finding eligibility closes;
- disposition derivation closes;
- source repair remains bounded;
- 946 projection matrix passes;
- historical 907-row regression passes;
- replacement-subject compatibility completes without oracle disagreement or
  audit error;
- all unchanged semantic qualification passes;
- packaged ACCEPT/BLOCK/provenance/regression rehearsals pass;
- independent validation passes;
- source freezes;
- PYZ-v3 Builds A/B match;
- authority-v3 Builds A/B match;
- post-package qualification passes;
- profile-v5 Builds A/B match;
- certificate-v6 Builds A/B match;
- certificate validation passes;
- frozen-package requalification passes;
- current authority registry closes;
- exactly one unconsumed successor audit authorization exists;
- input equality and cleanup pass;
- final artifacts have mode 0400;
- no real subject audit ran;
- no subject verdict was issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIR_BLOCKED

when:

- governed observed reason semantics cannot be uniquely derived;
- repair requires changing subject semantics or case expectations;
- bounded source surface is insufficient;
- the one successor candidate cannot qualify.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- source-adoption mismatch;
- forbidden source origin;
- evidence loss;
- process-custody failure;
- supplied-input mutation;
- cleanup inequality;
- source drift after freeze;
- deterministic-output mismatch;
- final-output identity failure;
- Git/VCS or network activity.

────────────────────────────────────────────────

33. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve predecessor audit and launch artifacts;
- preserve failed real-audit evidence;
- preserve content and implementation inputs;
- preserve successful successor artifacts;
- do not execute the real subject audit;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

34. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh repair-root identity
3. Fresh output-root identity
4. Predecessor PYZ/authority identities
5. Consumed profile-v4/certificate-v5 disposition
6. Failed real-audit wrapper/workspace/capsule authentication
7. Replacement-subject identity
8. Construction-wrapper identity
9. Content identities
10. Accepted implementation chain
11. Adopted source registry and copy result
12. Exact 946 projection defect crosswalk
13. Current case/result row schemas
14. Governed expectation fields
15. Observed structured semantic fields
16. Report-only descriptive fields
17. Primary observed-reason projection
18. Secondary observed-reason projection
19. Dual-projection independence
20. Direct-finding eligibility contract
21. Disposition derivation contract
22. Bounded source delta
23. Protected-source comparison
24. 946 projection qualification matrix
25. Historical 907-row regression
26. Replacement-subject 946 compatibility result
27. Unchanged regression preservation
28. Packaged ACCEPT rehearsal
29. Packaged direct 946 BLOCK rehearsal
30. Packaged ambiguous-reason provenance rehearsal
31. Historical projection-regression rehearsal
32. Finding-schema-failure rehearsal
33. Independent successor validation
34. Source freeze
35. Successor PYZ-v3 Build A/B
36. Successor member closure
37. Authority-v3 Build A/B
38. Post-package qualification
39. Profile-v5 Build A/B
40. Certificate-v6 Build A/B
41. Certificate-input validation
42. Frozen-package requalification
43. Current successor authority registry
44. Exactly-one-active-authorization result
45. Input closing equality
46. Cleanup
47. Confirmation real subject audit not executed
48. Confirmation no subject verdict
49. Final PYZ-v3 path and identity
50. Final authority-v3 path and identity
51. Final profile-v5 path and identity
52. Final certificate-v6 path and identity
53. Remaining uncertainty/nonclaims
54. Explicit confirmations

Required confirmations:

PREDECESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED
PREDECESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED
CONSUMED_PROFILE_V4_IDENTITY_MATCHED
CONSUMED_CERTIFICATE_V5_IDENTITY_MATCHED
PREDECESSOR_REAL_AUDIT_AUTHORIZATION_CONSUMED
FAILED_REAL_AUDIT_WRAPPER_AUTHENTICATED
FAILED_REAL_AUDIT_CAPSULE_AUTHENTICATED
RAW_SUBJECT_AUDIT_BLOCK_RETAINED_AS_NONPROMOTABLE
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_AUDIT_SOURCE_ADOPTED_BYTE_IDENTICAL
EXACT_946_PROJECTION_DEFECT_REPRODUCED
HISTORICAL_907_INVALID_FINDINGS_RETAINED
SUBJECT_946_RESULT_ROWS_PASSING_RETAINED
SUBJECT_137_RESULT_ROWS_PASSING_RETAINED
STRUCTURED_946_RESULT_SEMANTICS_FROZEN
DESCRIPTIVE_REASON_TEXT_CLASSIFIED_REPORT_ONLY
NO_PROSE_TO_REASON_CLASS_COMPARISON
NO_FUZZY_OR_SUBSTRING_REASON_CLASSIFICATION
PRIMARY_REASON_CLASS_PROJECTION_IMPLEMENTED
SECONDARY_REASON_CLASS_PROJECTION_IMPLEMENTED
DUAL_REASON_CLASS_PROJECTIONS_INDEPENDENT
AMBIGUOUS_REASON_CLASS_PRODUCES_AUDIT_PROVENANCE_FAILURE
DIRECT_FINDING_ELIGIBILITY_ENFORCED
PASSING_ROW_CANNOT_CREATE_DIRECT_FINDING
FINDING_COUNT_EQUALS_NONPASSING_ROW_COUNT
BLOCK_REQUIRES_VALID_DIRECT_FINDING
INVALID_FINDING_SCHEMA_PREVENTS_BLOCK_PROMOTION
AUDIT_DISPOSITION_DERIVED_FROM_VALID_FINDINGS
SOURCE_REPAIR_BOUNDED_TO_PROJECTION_AND_FINDING_SURFACES
ALL_UNRELATED_FUNCTIONS_AST_IDENTICAL
OUTCOME_PROJECTION_MATRIX_PASSED
HISTORICAL_907_ROW_REGRESSION_PASSED
REPLACEMENT_SUBJECT_946_COMPATIBILITY_COMPLETED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
PRIOR_SEMANTIC_QUALIFICATION_PRESERVED
PACKAGED_ACCEPT_REHEARSAL_PASSED
PACKAGED_DIRECT_946_BLOCK_REHEARSAL_PASSED
PACKAGED_AMBIGUOUS_REASON_PROVENANCE_REHEARSAL_PASSED
HISTORICAL_PROJECTION_REGRESSION_REHEARSAL_PASSED
FINDING_SCHEMA_FAILURE_REHEARSAL_PASSED
INDEPENDENT_SUCCESSOR_VALIDATION_PASSED
SUCCESSOR_SOURCE_FROZEN
SUCCESSOR_SOURCE_NOT_MODIFIED_AFTER_FREEZE
SUCCESSOR_AUDIT_PYZ_V3_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_AUDIT_PYZ_V3_MEMBER_CLOSURE_PASSED
SUCCESSOR_RUNTIME_AUTHORITY_V3_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
SUCCESSOR_PROFILE_V5_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_V6_BUILD_A_B_BYTES_IDENTICAL
SUCCESSOR_CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_SUCCESSOR_PYZ_V3_REQUALIFICATION_PASSED
CURRENT_SUCCESSOR_AUTHORITY_REGISTRY_COMPLETE
EXACTLY_ONE_ACTIVE_FUTURE_REAL_AUDIT_AUTHORIZATION
PREDECESSOR_AUTHORIZATION_NOT_REUSED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_OUTCOME_PROJECTION_REPAIRED_READY_FOR_ONE_REAL_AUDIT

the next task is exactly one real audit using:

1. successor audit PYZ v3;
2. successor runtime authority v3;
3. successor launch profile v5;
4. successor launch certificate v6;
5. unchanged replacement subject;
6. construction wrapper;
7. content bundle and authority;
8. accepted implementation authority chain.

Do not combine harness repair with the real audit.
```

## Sources and confidence

The attached report establishes a valid launch and terminal capsule but an invalid embedded BLOCK. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

It establishes that the retained 946 and 137 results have zero genuine nonpassing rows, while the harness projected 907 passing rows as blockers through a reason-class/prose mismatch. :chatgpt-content-reference{index="11"}

It also establishes valid capsule closure, consumed authorization, unchanged subject inputs, and no prohibited product or repository activity. :chatgpt-content-reference{index="12"}

**Provenance confidence:** 0.999  
**Audit-only defect classification confidence:** 0.999  
**Unchanged-subject reuse confidence:** 0.999  
**Bounded successor-repair confidence:** 0.98  
**Replacement-subject acceptance confidence:** 0.00—the validly closed audit did not lawfully adjudicate it.

This review used the latest attachment in full. Some older project uploads have expired; re-upload one only if a later task requires its original bytes rather than the retained identities and reports.
