## Assessment

This is a genuine **ACCEPT** for the exact audited bytes and the bounded supported-local contract. The long evidence-verification reset has finally crossed its independent-audit gate.

The acceptance is deliberately narrow:

- The 13-path repository patch is accepted.
- The exact source-external v4 caller, SHA-256 `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`, is accepted as validation/provenance evidence under the documented supported-local assumptions.
- Model C atomic bundle publication is accepted together with Model E’s trusted stable-output-ancestry precondition. It is **not** a claim that hostile or uncoordinated ancestry movers are defeated.
- Verifier results and caller records remain structural evidence/projection only.
- Repair 10I, product readiness, A6 readiness, commit authorization, and publication authorization do not follow automatically.

That limitation is intentional rather than an unresolved defect: the governing design selected atomic bundle-parent publication only under explicit trusted stable ancestry, and requires blocking when that premise does not hold. 

The earlier closeout addendum was explicitly only an audit-input capsule, not an independent correctness verdict. The newly supplied ACCEPT is therefore the event that actually closes the audit gate. 

**Do not issue another repair or audit prompt.** The critical path is now:

1. Commit exactly the audited 13 repository paths.
2. Verify staged and committed blobs against the accepted manifest.
3. Keep push/publication separate.
4. Then restart fresh A6 using the committed verifier identity and the accepted external caller identity.

The project protocol requires this exact progression after ACCEPT: regenerate the manifest, stage only audited paths, compare staged and committed blobs to the manifest, commit once, and push only when separately authorized.  The provenance guidance imposes the same commit-gate sequence. 

## Codex prompt — exact-byte commit gate

```text
MANDATORY RESPONSE FORMAT

Embed the complete commit-gate report inline in Markdown. Links may be
supplemental, but must not replace any required section.

Return exactly one:

EVIDENCE_VERIFICATION_V1_AUDITED_BYTES_COMMITTED
COMMIT_GATE_BLOCKED
COMMIT_PROVENANCE_MISMATCH

This is an exact-byte commit gate after independent audit ACCEPT.

Do not implement, repair, reformat, normalize, regenerate repository source,
change documentation, add tests, alter the accepted caller, push, create a PR,
merge, deploy, or restart A6.

No subagents. You are the sole commit-gate actor.

## 1. Objective

Stage and commit exactly the independently accepted Evidence Verification v1
repository bytes.

The accepted independent-audit verdict is ACCEPT for the exact bounded
supported-local implementation slice.

This gate authorizes:

- read-only repository and evidence verification;
- creation of private commit-gate evidence outside the repository;
- staging exactly the 13 audited repository paths;
- one commit with the exact subject specified below.

This gate does not authorize:

- source repair;
- any byte or mode change;
- push or upstream creation;
- PR creation;
- merge;
- installation or deployment;
- A6 restart;
- product or live-service invocation;
- mutation of any supplied evidence root.

## 2. Administrative pre-epoch rule

Reading this prompt before the commit-gate epoch is permitted.

After it has been read, every repository-facing subprocess must:

- use cwd exactly IMPL_R;
- use `git -C "$IMPL_R" ...` for every Git command;
- explicitly set:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

Do not use the primary checkout as cwd, Git target, or content operand.

A corrected private harness attempt is not by itself a process blocker.
Retain failed commit-gate attempts separately. Never overwrite retained
evidence.

## 3. Repository and accepted target

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Require before any staging:

- physical root equals IMPL_R;
- branch:
  `codex/evidence-verification-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- upstream:
  absent
- governed inventory:
  exactly 477 objects
- working patch:
  exactly four modified tracked paths and nine untracked paths
- staged/deleted/renamed/unmerged:
  `0/0/0/0`
- no unexplained ignored path, cache, bytecode, test cache, database, journal,
  lock, generated manifest, or temporary artifact
- full-index tracked binary-diff SHA-256:
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`
- canonical audited manifest SHA-256:
  `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`

Stop with COMMIT_PROVENANCE_MISMATCH on any mismatch.

## 4. Exact audit and provenance inputs

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5

AUDITED_MANIFEST=$AUDIT_ROOT/opening/recipe-run-1/provenance/manifest-run-1.json

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

FINAL_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py

Require:

- AUDIT_ROOT exists and is not modified;
- AUDITED_MANIFEST is a regular, single-link file;
- AUDITED_MANIFEST SHA-256 is
  `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`;
- RECIPE is 5,143 bytes and SHA-256
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`;
- recipe ID is
  `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`;
- FINAL_CALLER is 49,047 bytes and SHA-256
  `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`.

FINAL_CALLER is source-external evidence. Do not stage, copy, edit, or relocate
it as part of this gate.

Do not write into AUDIT_ROOT or any existing implementation, repair,
reconnaissance, addendum, validation-output, or historical-audit root.

## 5. Fresh commit-gate evidence root

After the opening gate passes, allocate one fresh private root beneath
`/Users/ds/Downloads` with Python `tempfile.mkdtemp`, prefix:

`ES-evidence-verification-v1-commit-gate-6ca8f5513d9c-`

Use umask `077`.

All retained directories must be direct mode `0700`.
All retained files must be regular, single-link mode `0600`.
Create retained files exclusively.
Keep all TMPDIRs and helper sources beneath this root.

Do not create any helper or evidence file in IMPL_R.

## 6. Pre-stage provenance replay

Before staging, run the exact RECIPE twice into two fresh commit-gate
continuations using:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 -I -B

Require for both runs:

- exit 0;
- empty stderr;
- stdout equals the output file;
- the two outputs are byte-identical;
- each output is byte-identical to AUDITED_MANIFEST;
- SHA-256 is exactly
  `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`;
- all 13 rows match live bytes, classifications, modes, sizes, and SHA-256;
- embedded tracked diff equals
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`.

Do not stage unless this entire gate passes.

## 7. Exact audited path set

Stage exactly these paths and no others:

1. `.docs/system_overview/artifact_hygiene.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/capability_probing.md`
4. `.docs/system_overview/evidence_verification.md`
5. `PLANS.md`
6. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`
7. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
8. `tools/evidence_verify/layouts/a6_policy_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6d_successor_v1.json`
11. `tools/evidence_verify/registry_v1.json`
12. `tools/evidence_verify/test_verify_v1.py`
13. `tools/evidence_verify/verify_v1.py`

Expected commit-relative classification:

Modified:
- `.docs/system_overview/artifact_hygiene.md`
- `.docs/system_overview/boundaries.md`
- `.docs/system_overview/capability_probing.md`
- `PLANS.md`

Added:
- `.docs/system_overview/evidence_verification.md`
- both historical fixture files
- all three layout files
- `registry_v1.json`
- `test_verify_v1.py`
- `verify_v1.py`

Use one explicit `git add -- <all 13 paths>` operation.

Do not use `git add -A`, `git add .`, path globs, or interactive staging.

## 8. Staged-blob identity gate

After staging:

1. Require the staged path set to be exactly the 13 paths above.
2. Require no unstaged repository-byte change.
3. Require every staged entry to be stage 0 and logical mode `100644`.
4. For every AUDITED_MANIFEST row:
   - read the staged Git blob;
   - calculate its byte size and SHA-256;
   - require exact equality with the audited manifest row.
5. Require no extra staged path.
6. Require:
   - `git diff --cached --check` passes;
   - `git diff --check` passes.

Important:

Do not rerun the working-tree provenance recipe after staging and expect its
classification bytes to remain identical. Staging converts the nine audited
untracked paths into staged additions. The acceptance-bearing gate after
staging is per-path staged-blob equality with the audited manifest.

Any mismatch returns COMMIT_PROVENANCE_MISMATCH. Do not unstage and repair.

## 9. Final validation on staged bytes

Use the pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

From IMPL_R, under umask `077`, with a private commit-gate TMPDIR, run exactly
one complete repository Evidence Verification suite:

"$PYTHON" -I -S -B tools/evidence_verify/test_verify_v1.py

Require:

- owning exit 0;
- exactly 89 tests;
- zero failures;
- zero errors;
- zero skips;
- exact identities 01–89;
- no repository artifact, bytecode, cache, generated manifest, database,
  journal, lock, or unsupported object.

Also require:

- FINAL_CALLER still has its accepted size and SHA-256;
- staged blob identities still equal AUDITED_MANIFEST after validation;
- no unstaged change exists;
- full governed repository inventory differs from the opening inventory only
  in Git index state, not filesystem objects or bytes.

You may remove only a commit-gate-created temporary artifact whose exact
identity and creation by this gate are proven. Never alter an audited file.
If cleanup cannot be proven exact, return COMMIT_GATE_BLOCKED.

No implementation repair is permitted if validation fails.

## 10. Commit

Only after every prior gate passes, create exactly one commit with subject:

`add evidence verification v1`

Use the repository’s normal commit path.

Do not:

- amend;
- bypass hooks;
- disable signing or policy checks merely to force success;
- create more than one commit;
- push;
- set an upstream;
- create a PR;
- merge.

If a hook fails or changes any audited or staged byte, stop with
COMMIT_GATE_BLOCKED and report the resulting exact state. Do not repair it.

## 11. Post-commit object gate

After commit, require:

- branch remains `codex/evidence-verification-v1`;
- new HEAD has exactly one parent;
- sole parent is
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- commit subject is exactly `add evidence verification v1`;
- commit touches exactly the accepted 13 paths;
- classifications are exactly four modified and nine added;
- every committed blob has mode `100644`;
- every committed blob’s size and SHA-256 equal its AUDITED_MANIFEST row;
- no extra committed path;
- working tree and index are clean;
- upstream remains absent;
- no repository artifact was created;
- FINAL_CALLER and all supplied evidence roots remain unchanged.

Do not compare the clean post-commit working-tree classification to the old
uncommitted manifest. Compare committed Git blobs directly to that manifest.

## 12. Stop conditions

Stop without commit when any of these occurs before commit:

- baseline identity mismatch;
- audit or recipe input mismatch;
- manifest mismatch;
- path-set mismatch;
- staged blob mismatch;
- unexpected mode;
- validation failure or skip;
- source-external caller drift;
- repository artifact that cannot be safely attributed and removed;
- extra staged path;
- hook or policy uncertainty discovered before commit.

If the commit itself succeeds but a post-commit gate fails, do not reset,
amend, or create a corrective commit. Return COMMIT_GATE_BLOCKED with the
exact committed state.

## 13. Required inline report

Include:

1. Verdict.
2. Administrative pre-epoch disclosure.
3. Opening branch, HEAD, tree, parent, upstream, and status.
4. Audit-manifest, recipe, and external-caller identities.
5. Commit-gate evidence-root identity.
6. Both pre-stage recipe runs and comparison.
7. Exact staged path set.
8. Per-path staged blob modes, sizes, and SHA-256.
9. Staged and unstaged diff checks.
10. Exact validation command and 89-test result.
11. Artifact and cleanup result.
12. Exact commit argv and subject.
13. New commit SHA-1, tree, parent, and subject.
14. Exact committed path classifications.
15. Per-path committed blob modes, sizes, and SHA-256.
16. Post-commit working-tree, index, branch, and upstream state.
17. Confirmation that FINAL_CALLER and supplied evidence roots were unchanged.
18. Audit-created evidence inventory.
19. Failed or superseded attempts.
20. Explicit confirmations:
    - no repair performed;
    - no push performed;
    - no upstream created;
    - no PR or merge performed;
    - no A6 restart performed;
    - no product/live service invoked;
    - no network contact performed;
    - no subagents created.

Successful final verdict:

EVIDENCE_VERIFICATION_V1_AUDITED_BYTES_COMMITTED
```

## After this gate

A successful commit is enough to give the verifier repository-backed Git identity. It does **not** absorb the external caller into Git; its accepted SHA-256 and evidence roots remain separate provenance inputs.

The next substantive operation should be a **fresh Repair 10I A6 restart** bound to:

- the new commit and committed verifier/registry/layout blobs;
- final caller SHA-256 `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`;
- repair manifest `78499711a01ac70a60613b139daf36b25d512d3d121543d5f0dfb94eea30e3ad`;
- addendum manifest `f9690f9ce0822d7f5bcc2daed385bd5461b2ed4febc824724c47ae3cc3d2f6ea`;
- the ACCEPT audit root and exact accepted manifest.

Push can remain a separate publication decision because this branch currently has no upstream.

### Sources

- The closeout addendum was explicitly an audit-input capsule, not an independent verdict. 
- The selected custody model is atomic bundle-parent publication under an explicit trusted stable-ancestry precondition. 
- The project’s commit gate requires exact staging, staged/committed blob comparison, one commit, and separately authorized push. 
- The provenance guidance independently requires the same post-ACCEPT sequence. 

**Confidence**

- Provenance confidence: **0.999**
- Independent-audit confidence: **0.97**
- Confidence in advancing to the exact-byte commit gate: **0.995**
- Confidence in combining commit with push or A6 restart now: **0.08**
