## Assessment

The stop is correct. This is **not** a repository, successor-source, device-security, or five-control validation failure. No source control was launched.

It is a target-contract defect in the corrected evidence verifier:

- The verifier amendment successfully verifies the original A6D implementation child and its own amendment child.
- Its CLI admits only a closed set of target kinds.
- The new A6 policy-evidence child is not one of them.
- Trying every existing target kind cannot work because each target kind also carries layout and identity assertions for a different artifact class.
- The new A6 child therefore cannot satisfy the required pre-seal or sealed verification, even before source-control execution begins.

I also need to correct the preceding prompt: it assumed the amended verifier was a general seal verifier. Codex’s result proves it was intentionally target-specific. Reusing it against A6 without first adding an A6 target contract was an unsupported step.

The current A6 child should remain unsealed negative evidence. It should not be resumed. The next step is **not another A6 run** and not a successor-source repair. It is a bounded read-only freeze of the exact A6 evidence-target contract and, critically, how the new verifier extension itself can be sealed without creating another recursive verifier layer.

There is now a broader warning: the evidence harness is consuming the critical path. This next amendment should have a hard one-layer limit. If an A6-target verifier cannot be sealed using an already sealed verifier contract, stop and simplify the evidence architecture rather than creating an indefinite chain of verifier amendments. Proof tooling must remain bounded scaffolding rather than becoming the de facto product architecture. 

## Codex prompt: A6V evidence-target reconnaissance

```text
Objective

Perform a parent-only, source-read-only Repair 10I-A6V reconnaissance of the
seal-verifier target mismatch that blocked the fresh A6 policy-evidence child.

Determine and freeze the smallest safe evidence-tool amendment that lets a
future Repair 10I-A6 policy-evidence child be verified at both:

- pre-seal stage;
- sealed stage.

The existing corrected verifier must remain strict. Do not add a catch-all
target kind, arbitrary caller-defined layout, or broad “accept any manifest”
mode.

The reconnaissance must also solve the bootstrap question:

How will the future A6-target verifier amendment itself be sealed and verified
without requiring another unbounded verifier-amendment layer?

Do not implement the correction in this turn.

Do not modify repository source.
Do not modify successor source or binaries.
Do not modify the original A6D child.
Do not modify the A6D verifier amendment.
Do not modify any predecessor.
Do not modify, resume, overwrite, or seal the current failed A6 child.
Do not launch a source control.
Do not run a repository full suite, comparison, analyzer, or product A/B.
Do not implement the historical comparator.
Do not create a snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. You are the sole operator.

Candidate repository

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D implementation child

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D verifier amendment

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Current failed and unsealed A6 child

FAILED_A6=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6d-8de797304ea9

Earlier failed A6 children

FAILED_A6O=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

FAILED_A6R=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Required new reconnaissance child, absent at opening

A6V=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6v-evidence-target-recon-8de797304ea9

## 1. Absolute repository-root lock

Before any substantive repository observation:

1. Component-walk and lstat CANDIDATE_R.
2. Require physical path exactly:
   /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
3. Require:
   - directory;
   - device 16777234;
   - inode 122118502;
   - mode 0755;
   - UID/GID 501/20.
4. Require physical pwd -P to equal CANDIDATE_R.
5. Require PRIMARY_R to remain a distinct sibling:
   - device/inode 16777234/47685738;
   - no alias;
   - no equality;
   - no nesting;
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode 0644;
- size 123;
- device/inode 16777234/122118504;
- one link;
- SHA-256:
  79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419;
- exact target:
  /Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1;
- common Git directory:
  /Users/ds/Repositories/Execution Substrate/.git.

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured candidate cwd.

No command may use PRIMARY_R as cwd, Git -C target, source root, or inventory
root.

For inline Python:

- use PYTHONDONTWRITEBYTECODE=1;
- verify os.getcwd() before repository-relative access;
- import no executable module from an evidence child;
- create no __pycache__ or .pyc.

Stop on mismatch:

REPAIR10I_A6V_WORKTREE_MISMATCH

## 2. Repository and lineage gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0/0/0/0.

Require original A6D exact:

- manifest:
  dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9
- manifest size:
  103293
- payloads:
  623
- directories:
  205
- source T:
  8c237318e3a72172e5cbbdf41f5e68244ae15895
- source inventory:
  7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852.

Require verifier amendment exact:

- manifest:
  a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e
- manifest size:
  3801
- payloads:
  29
- directories:
  9.

Require corrected helpers exact:

- tool/corrected/verify-closing-v1.py
  52003d2bb42e96ada233b341543d744dfd288228dd826da6905233d7594249e1

- tool/corrected/verify-postseal-v1.py
  746d63cfab5256766a366b8f829ac0f00de0c6a38f6bc70598231d55d2c08461

Require:

- all 20 verifier fixture cases;
- two byte-identical corrected verification runs against A6D;
- corrected verification of the amendment;
- joint-qualification record;
- original A6D remained unchanged.

Require FAILED_A6 to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact from opening through closing.

Reverify:

- closeout/validation-blocked-closeout-v1.json;
- command-root audit;
- all six rejected verifier invocations;
- their exact argv, cwd, target kind, stage, stdout, stderr, and exit;
- no source control launched;
- no comparison or analyzer ran;
- cleanup and absence records.

Require FAILED_A6O and FAILED_A6R unchanged and unsealed.

Require A6V absent.

Stop on mismatch:

REPAIR10I_A6V_RECONNAISSANCE_BASELINE_MISMATCH

## 3. Reconnaissance child

After the opening gate, create A6V exclusively under umask 077 with exactly:

opening/
source/
schemas/
tests/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, nonsymlink, mode 0600 or 0700.

No hardlinks.

Do not import executable modules from predecessor evidence.

No repository tests or builds are authorized.

## 4. Recover the exact current verifier target model

Inspect exact corrected verifier source:

- A6D_AMEND/tool/corrected/verify-postseal-v1.py
- A6D_AMEND/tool/corrected/verify-closing-v1.py
- their original vulnerable copies;
- all 20 fixture tests;
- joint-qualification record;
- amendment closeout report.

Recover and document:

1. Every accepted CLI target kind.
2. Every accepted stage.
3. Exact CLI grammar.
4. Exact target-kind dispatch at and around line 33.
5. For each target kind:
   - expected root basename or naming rule;
   - expected top-level directories;
   - expected required files;
   - allowed optional files;
   - forbidden files;
   - manifest/sidecar posture;
   - expected source or binary records;
   - required closeout records;
   - expected target identity fields.
6. Whether target-kind checks are:
   - path-name bound;
   - layout bound;
   - manifest-identity bound;
   - child-class bound;
   - a combination.
7. Whether the verifier has any generic manifest-closure core beneath the
   target-specific dispatch.
8. Which checks are reusable without semantic widening.
9. Which checks are target-specific authority.
10. Exact code path and reason for each of the six failed A6 invocations.

Retain the exact six-rejection matrix.

Do not infer a target kind from a similar name.

## 5. Recover the exact current A6 child layout

Inspect FAILED_A6 read-only.

Recover:

- physical root identity;
- current top-level path set;
- current file and directory modes;
- exact files written before the verifier stop;
- exact absent files;
- exact intended top-level directory contract;
- exact intended pre-seal layout;
- exact intended sealed layout;
- exact manifest path;
- exact sidecar path;
- exact files that would be required before sealing;
- exact files that would be acceptance-bearing after five-control execution;
- exact closeout records;
- exact corrected-verifier records expected in the child.

The intended target contract must be recovered from retained A6 construction
records and the supplied A6 instruction, not inferred solely from the
incomplete current directory.

The exact intended top-level directories are expected to be:

opening
tool
sources
commands
controls
validation
comparisons
analysis
findings
closeout

Verify rather than assume this list.

Determine whether any target-specific verification needs facts not available
until after the five-control run.

## 6. Candidate-model adjudication

Evaluate each model.

### Model A — exact new A6 target kind

Add one closed target kind dedicated to Repair 10I-A6 policy-evidence children.

It must carry:

- exact pre-seal layout;
- exact sealed layout;
- required root directories;
- exact manifest and sidecar semantics;
- no arbitrary extra files;
- target-class-specific required closeout records;
- no source-control or policy acceptance logic.

Assess whether this is the preferred bounded model.

### Model B — reuse an existing target kind

Reject unless the exact existing target contract is genuinely identical.

Renaming the A6 child or lying about its class is prohibited.

### Model C — catch-all or caller-supplied layout

Reject.

No arbitrary target kind, arbitrary required-path list, or caller-defined
layout may become qualification authority.

### Model D — generic manifest-closure verifier

Evaluate whether a target-independent manifest verifier can safely check only:

- manifest;
- sidecar;
- path/type/mode/size/hash/link closure;
- directory modes;
- no extras;
- no writes.

If selected, target-class layout checks must remain separately closed and
sealed. Do not combine generic byte closure with caller-controlled target
semantics.

This model is a broader redesign and should not be selected unless the current
target dispatch cannot be safely extended.

### Model E — embed the verifier inside the future A6 child

Evaluate and likely reject because the child would supply the verifier used to
qualify its own layout without a separately sealed tool chain.

### Model F — one-off external script per A6 run

Reject unless it has an independently sealed source and closed target
contract.

## 7. Bootstrap and anti-recursion contract

The reconnaissance must freeze how the future A6-target verifier extension
itself will be sealed and verified.

Evaluate these paths:

### Bootstrap 1

The existing A6D amendment verifier can verify a second amendment-class child
without source modification.

If true, prove:

- exact accepted target kind;
- exact layout compatibility;
- no hardcoded basename or identity conflict;
- no semantic misclassification.

### Bootstrap 2

The future extension uses the same amendment-child layout and is verified by
the existing corrected verifier.

This is preferred when exact source permits it.

### Bootstrap 3

A new verifier must verify its own child.

Reject unless another already sealed verifier independently verifies that
child first.

### Bootstrap 4

A new generic seal verifier is introduced.

Treat this as scope expansion and return blocked unless the existing verifier
cannot safely seal the extension by any closed route.

Hard one-layer limit:

If the A6-target verifier extension cannot itself be sealed and verified by an
already sealed verifier contract, return blocked. Do not design another
amendment layer.

## 8. Exact A6 target contract

If Model A is selected, freeze:

- exact target-kind identifier;
- exact CLI syntax;
- exact pre-seal stage name;
- exact sealed stage name;
- exact root-name rule;
- exact top-level directories;
- exact required and forbidden seal files by stage;
- exact allowed file types;
- exact file and directory modes;
- exact link policy;
- exact manifest coverage;
- exact sidecar binding;
- exact no-extra-file rule;
- exact no-write rule;
- exact required closeout records;
- exact corrected-verifier provenance records;
- exact treatment of failed/superseded records;
- exact treatment of empty directories before execution;
- exact post-cleanup absence records.

Do not encode expected test outcomes, comparison results, or historical-policy
decisions in the seal verifier.

The verifier proves evidence-child structure and bytes, not readiness.

## 9. Versioning and identity

Determine whether the future helper must be named:

- verify-postseal-v2.py;
- verify-closing-v2.py;
- another exact versioned name.

Do not silently change v1 semantics under the same source identity.

Freeze:

- recipe/tool ID;
- source file names;
- source SHA-256 requirements;
- CLI target kinds;
- output schema or canonical output format;
- historical v1 behavior;
- strict target-kind rejection.

The original corrected v1 helper remains authoritative for A6D and the first
amendment only, according to its sealed contract.

## 10. Exact future touched-file set

Freeze the smallest complete future verifier-extension source set.

Inspect whether changes are needed to:

- verify-postseal-v1.py copy;
- verify-closing-v1.py copy;
- fixture generator;
- fixture tests;
- target-layout specification;
- closeout report generator.

No repository file.
No successor source.
No successor binary.
No dependency.
No generalized validation framework.

If more than two verifier implementation files plus bounded fixture/test files
are required, explain why or return scope blocked.

## 11. Mandatory future causal matrix

Freeze tests including:

1. Original A6D child passes under its original target kind.
2. Original amendment passes under its original target kind.
3. Valid future A6 pre-seal layout passes under the exact A6 target kind.
4. Valid future A6 sealed layout passes under the exact A6 target kind.
5. A6 target rejects A6D layout.
6. A6D target rejects A6 layout.
7. Amendment target rejects A6 layout.
8. Unknown target kind rejects.
9. Wrong stage rejects.
10. Wrong root basename or naming rule rejects when governed.
11. Missing required top-level directory rejects.
12. Unexpected top-level directory rejects.
13. Wrong file type rejects.
14. Wrong directory mode rejects.
15. Wrong payload mode rejects.
16. Symlink/special file rejects.
17. Missing manifest rejects at sealed stage.
18. Manifest present rejects at pre-seal stage.
19. Missing sidecar rejects.
20. Wrong sidecar digest rejects.
21. Manifest or sidecar incorrectly listed as payload rejects.
22. Missing manifested payload rejects.
23. Unexpected payload rejects.
24. Payload size/hash/link mismatch rejects.
25. Mutation after manifest installation rejects.
26. Failed/superseded records remain allowed only in their exact bounded
    locations.
27. Acceptance-result content is not interpreted by the seal verifier.
28. Verifier performs zero writes.
29. Repeated canonical output is byte-identical.
30. The future verifier extension child itself is verified by the already
    sealed verifier contract.
31. No fourth verifier layer is required.

## 12. Fresh A6 restart sequence

Freeze:

1. Create a new verifier-extension child from the sealed amendment helper.
2. Implement only the exact A6 target contract.
3. Run the complete target/layout causal matrix.
4. Verify the extension child with the already sealed corrected verifier.
5. Seal the extension.
6. Create a new A6 policy-evidence child.
7. Use the new target verifier at pre-seal and sealed stages.
8. Restart all five source controls from the beginning.
9. Do not resume FAILED_A6.
10. Bind all three evidence inputs:
    - original A6D;
    - first verifier amendment;
    - A6-target verifier extension.
11. Proceed to historical-comparator implementation only after successful
    fresh A6 policy freeze.

## 13. Stop conditions

Freeze mandatory stops for:

- baseline or lineage mismatch;
- current target dispatch cannot be recovered exactly;
- A6 intended layout is ambiguous;
- target kind would require caller-controlled layout;
- existing target kind must be misrepresented;
- extension cannot be sealed by an already sealed verifier;
- fourth verifier layer would be required;
- target verifier would interpret validation readiness;
- source/successor/repository change required;
- arbitrary extra files could pass;
- no-write behavior cannot be proved;
- output is nondeterministic;
- touched-file scope cannot be closed.

## 14. Verdicts

Return exactly one.

### Ready

REPAIR10I_A6V_RECONNAISSANCE_READY

Use only when:

- exact current target model is recovered;
- exact six-rejection mechanism is recovered;
- exact A6 pre-seal and sealed layouts are frozen;
- exact new target kind is frozen;
- verifier extension can itself be sealed by an already sealed verifier;
- no fourth verifier layer is required;
- touched files and tests are complete.

### Blocked

REPAIR10I_A6V_RECONNAISSANCE_BLOCKED

Use when:

- A6 layout is ambiguous;
- existing verifier cannot safely bootstrap the extension;
- a catch-all/generic framework is required;
- another verifier layer would be needed;
- scope or versioning remains unresolved.

## 15. Required report

Include:

1. Opening and closing repository identities.
2. Original A6D and amendment identities.
3. Current verifier source and accepted target kinds.
4. Exact six rejected invocations.
5. Exact current A6 child layout.
6. Exact intended A6 pre-seal layout.
7. Exact intended A6 sealed layout.
8. Candidate-model adjudication.
9. Selected target-kind contract.
10. Bootstrap and anti-recursion proof.
11. Versioning decision.
12. Exact future touched-file set.
13. Complete causal matrix.
14. Future implementation and A6 restart sequence.
15. Stop conditions.
16. Inspection limits and uncertainty.
17. Manifest identity and payload count if A6V is sealed.
18. Confirmation no repository, successor, predecessor, failed-A6, cache,
    bytecode, test, or build artifact was modified.

No implementation.
No verifier extension.
No source control.
No comparison.
No historical analysis.
No B6.
No product A/B.
No snapshot.
No ZIP, handoff, or capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## Strategic stop condition

If A6V concludes that another verifier extension cannot be sealed by the already sealed verifier amendment, stop this chain. Do not create a fourth evidence-verifier layer. At that point the correct move is to replace the target-specific verifier chain with one deliberately designed, independently sealed manifest-closure tool plus separate closed target-layout specifications—not continue patching one tranche at a time.

The project guidance explicitly separates implementation, repair, and later independent audit, and any changed evidence-tool bytes require new provenance and validation.  Provenance can establish exact bytes, but cannot convert a verifier target mismatch into implementation correctness or authority. 

### Sources

- Codex’s `REPAIR10I_A6_VALIDATION_BLOCKED` report supplied in this turn.
- Milestone 0 proof-harness/non-authority boundary. 
- Governed Execution repair and re-audit protocol. 
- Provenance limits. 

**Confidence**

- Correctness of the stop: **0.999**
- Classification as verifier target-coverage defect: **0.999**
- Repository/successor defect probability from this report: **below 0.01**
- Confidence that the current A6 child must remain unsealed and not be resumed: **0.995**
- Confidence that one exact A6 target kind is the likely proportional repair: **0.90**
- Confidence that another recursive verifier layer must be prohibited: **0.99**
