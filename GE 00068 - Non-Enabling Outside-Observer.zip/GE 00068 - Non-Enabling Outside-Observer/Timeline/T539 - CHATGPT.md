## Engineering assessment

The sealed `GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK` is a valid **historical audit result**: provenance passed, the capsule terminally closed, supplied roots remained equal, and no retry occurred.

It is not yet a sufficiently precise repair diagnosis.

The four reported blockers are not equally independent:

- **A07 and A08 are the decisive potential package defects.** They report 33 failures across the 946-case suite and four failures across the 137-case suite, but the inline report does not disclose the exact cases, expected outcomes, observed outcomes, reason taxonomies, mutated pointers, or authoritative contract/schema rules.
- **A11 is derivative.** The report expressly says its 15 false confirmations result from the failed negative and contradiction suites. It should not be repaired independently unless the confirmation map itself is also wrong.
- **A06 is internally inconsistent.** The phase failed, yet both high-level witness confirmations remained true, and the A06 finding’s direct-evidence fields are null. That proves at least an audit evidence/reporting defect. It does not establish whether any witness itself is invalid.

The subject therefore remains blocked and noncurrent, but it would be premature to repair schemas, validation specifications, reconstruction logic, or the subject package based only on the aggregate counts.

### Progression decision

Run one **terminal, read-only findings adjudication** over the sealed subject and sealed audit capsule.

This is the final permitted reconciliation for this subject-audit result. It must:

1. adjudicate A06 independently;
2. enumerate and independently rerun all 33 A07 failures;
3. enumerate and independently rerun all four A08 failures;
4. reconstruct the 15 A11 derivations;
5. identify the exact repair owner for every confirmed defect;
6. immediately select one forward treatment.

The historical audit `BLOCK` must remain unchanged in every outcome. This reconciliation may change only the **forward repair ownership and sequencing**.

The allowed treatments are:

- **Package-only:** repair the exact owning schema, validation, reconstruction, or subject-generation surface; construct a fresh subject; run one fresh audit.
- **Audit-only:** repair the independent subject-audit logic/evidence projection; run one fresh audit of the unchanged sealed subject.
- **Mixed:** repair both exact surfaces; construct a fresh subject only if the package side requires it; then run one fresh audit.
- **Still nonqualifying:** stop retrospective adjudication, preserve both sealed roots as historical evidence, construct a fresh subject from the accepted authorities, and evaluate it with a freshly qualified independent audit. No second reconciliation.

---

## Complete replacement Codex prompt

```text
PERFORM THE FINAL READ-ONLY ADJUDICATION OF THE BLOCKED
GENERATION-2 CURRENT-SCHEMA-SUBJECT AUDIT FINDINGS

EXACT A06 WITNESS CLOSURE, ALL 33 A07 FAILURES,
ALL FOUR A08 FAILURES, AND THE 15 A11 DERIVATIONS

Objective

Perform one final, terminal, read-only adjudication of the sealed independent
audit result:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK

The historical audit result must remain unchanged as historical fact.

This task may determine only:

1. whether the A06 witness-closure failure is:
   - a direct current subject-package defect;
   - an independent-audit evidence, aggregation, or reporting defect;
   - mixed;
   - or unresolved;

2. whether each of the 33 A07 negative-suite failures is:
   - a direct current subject-package defect;
   - an independent-audit oracle/checker/reason-classification defect;
   - mixed;
   - or unresolved;

3. whether each of the four A08 contradiction-regression failures is:
   - a direct current subject-package defect;
   - an independent-audit oracle/checker/reason-classification defect;
   - mixed;
   - or unresolved;

4. whether the 15 A11 false confirmation derivations are:
   - wholly derivative from A06/A07/A08;
   - independently defective confirmation-map behavior;
   - mixed;
   - or unresolved;

5. the exact repair owner and mandatory next treatment.

Do not mutate or repair the constructed subject.

Do not mutate or repair the sealed audit capsule.

Do not rerun subject construction.

Do not rerun the complete subject audit.

Do not promote or rebind current authority.

Do not execute subject source.

Do not execute the reconstruction parent.

Do not copy or patch producer or audit source into current authority.

Do not begin the selected repair in this task.

Do not reinterpret, replace, or supersede the historical sealed BLOCK.

This is the final permitted findings reconciliation for this subject-audit
result.

After this task, no second A06/A07/A08/A11 reconciliation is authorized.

Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not run target audit.
Do not rerun product runtime validation.
Do not publish, deploy, externally commit, or begin A6.
Do not create subagents or direct auditors.

Use one finite source-external reconciliation parent in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_CONFIRMED_PACKAGE_REPAIR_REQUIRED

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILED_AUDIT_REPAIR_REQUIRED

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILED_MIXED_REPAIR_REQUIRED

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILIATION_TERMINAL_STOP_AND_RECONSTRUCT

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILIATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SEALED SUBJECT INPUT
──────────────────────────────────────────────────────────────────────────────

CONSTRUCTED_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-25kljb3m

Expected root identity:

- device:
  16777234
- inode:
  182600670
- mode:
  0700
- UID:
  501
- GID:
  20

Expected physical closure:

- total entries including root:
  73;
- directories:
  12;
- regular files:
  61.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  c3f5e291a35b2bfc0a4d00e93216c298bcc985e7964acaab700bb41c1a80c5bd

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- size:
  16620
- SHA-256:
  43e5e3f726c62d144ca616412252af7fd2073abed71df3279e71581f97049ec8

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- size:
  16620
- SHA-256:
  43e5e3f726c62d144ca616412252af7fd2073abed71df3279e71581f97049ec8

Authenticate before adjudication:

- exact root identity;
- temporal identity;
- manifest identities;
- A/B byte equality;
- manifest grammar;
- represented path set;
- current physical path set;
- independent no-follow reprojection;
- root row exactly once;
- clean topology and modes;
- no cache or bytecode.

Require complete opening/closing equality.

Do not mutate, clean, relocate, chmod, or reseal the root.

──────────────────────────────────────────────────────────────────────────────
2. SEALED SUBJECT-AUDIT CAPSULE
──────────────────────────────────────────────── LIMITED TO HISTORICAL RESULT
────────────────────────────────────────────────

SUBJECT_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-current-schema-subject-independent-audit-u3nnutm4

Expected root identity:

- device:
  16777234
- inode:
  182616808
- mode:
  0700
- UID:
  501
- GID:
  0

Expected historical verdict:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK

Expected audit temporal inventory:

- size:
  14818
- SHA-256:
  9430d301ecba2ab7d5ee1b9e6596221c82e7caaf01d0b2c3d38908f2729be84b

Expected audit manifest A:

- size:
  15350
- SHA-256:
  cd323c84fa1904ae13e1d2b57beb14c06f48d19cc50876d199e4c4f7131fed06

Expected audit manifest B:

- size:
  15350
- SHA-256:
  cd323c84fa1904ae13e1d2b57beb14c06f48d19cc50876d199e4c4f7131fed06

Authenticate:

- root identity;
- temporal identity;
- A/B identities and equality;
- terminal result;
- phase aggregate;
- final reprojection;
- root row exactly once;
- clean topology and modes;
- one seal transition;
- no postseal operation;
- historical primary verdict;
- zero historical provenance errors;
- four historical subject-package blocker findings.

Resolve every audit artifact only through:

- terminal manifests;
- capsule path registry;
- phase records;
- retained indexes;
- exact evidence pointers.

Do not select files by basename, suffix, recency, first match, or score.

Require complete opening/closing equality.

Do not mutate, clean, resume, repair, or reseal the audit root.

──────────────────────────────────────────────────────────────────────────────
3. CONSTRUCTION AND AUTHORITY CHAIN
──────────────────────────────────────────────── LIMITED TO AUTHENTICATION
────────────────────────────────────────────────

CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-current-schema-subject-construction-wrapper-icecat2n

Expected identity:

- device:
  16777234
- inode:
  182600661
- mode:
  0700

Expected final wrapper report:

final-wrapper-report.json

- inode:
  182600749
- mode:
  0600
- size:
  40562
- SHA-256:
  0daa27e908b7ec6f6823ccffddffe157cce9aa41fcb1b07e11ab1534229be51f

Authenticate only the chain needed to establish:

- exact subject construction;
- producer source identity;
- producer source freeze;
- producer qualification result;
- producer-retained witness, 946, 137, field-map, and confirmation artifacts;
- no second construction;
- supplied-root equality;
- terminal subject closure.

Do not use construction-wrapper prose as adjudication authority.

Resolve exact producer artifacts through the subject’s current role registries
and manifests.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT GOVERNING CONTENT AUTHORITY
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate the authority JSON before the ZIP.

Use exact current roles to resolve:

- normative contract;
- current schemas;
- schema-role registry;
- generated-family field freeze;
- validation specifications;
- 946-case registry;
- 137-case contradiction registry;
- 766/333 field-map authority;
- producer documentary-validator specifications;
- confirmation-evidence specifications.

The containing directory is nonauthoritative.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. FRESH RECONCILIATION ROOT
────────────────────────────────────────────────

Allocate one fresh private root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-current-schema-subject-block-final-reconciliation-

Immediately emit:

RECONCILIATION_ROOT=<absolute-path>

Before substantive adjudication retain:

opening/bootstrap-start.json
opening/final-reconciliation-authority-v1.json
opening/fixed-input-registry-v1.json
opening/subject-authentication-v1.json
opening/historical-audit-authentication-v1.json
opening/process-execution-policy-v1.json
opening/terminality-rule-v1.json

Authority is limited to:

- fixed-input authentication;
- read-only artifact resolution;
- independent witness/matrix/confirmation adjudication;
- defect ownership;
- repair-owner selection;
- mandatory next-treatment selection;
- supplied-root equality;
- diagnostic capsule closure.

Nonauthority includes:

- subject mutation;
- audit-root mutation;
- schema or validation repair;
- reconstruction;
- fresh subject audit;
- authority promotion;
- product/runtime/target/repository/publication/deployment/A6 activity.

──────────────────────────────────────────────────────────────────────────────
6. TERMINALITY RULE
────────────────────────────────────────────────

Retain:

opening/terminality-rule-v1.json

Required facts:

- this is the final A06/A07/A08/A11 reconciliation;
- no second findings reconciliation is authorized;
- historical sealed audit verdict remains:
  GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK;
- historical subject and audit roots remain immutable;
- this task may change only:
  - forward repair ownership;
  - subject reuse disposition;
  - audit-source reuse disposition;
  - mandatory next engineering treatment;
- this task cannot:
  - accept the subject;
  - promote current authority;
  - reverse or replace the historical BLOCK;
  - establish product/runtime readiness;
  - authorize target audit, publication, deployment, or A6.

After adjudication one and only one forward treatment must be selected.

──────────────────────────────────────────────────────────────────────────────
7. INDEPENDENT RECONCILIATION SOURCE
────────────────────────────────────────────────

Create fresh source-external reconciliation source inside the reconciliation
root.

It must:

- import no producer reconstruction module;
- import no producer validator helper;
- import no producer fixture generator;
- import no producer expected-result map;
- import no historical audit helper;
- import no historical audit expected-result map;
- import no producer or audit normalizer/projector;
- execute no subject source;
- execute no historical audit source;
- use no network, Git, shell, or broad filesystem scan;
- write only within the fresh reconciliation root;
- be finite;
- read no stdin.

It may use an already installed Draft 2020-12 JSON Schema implementation only
after authenticating:

- distribution;
- version;
- module path;
- source identities;
- validator class.

Do not install a dependency.

Retain:

opening/reconciliation-toolchain-authentication-v1.json
opening/reconciliation-source-registry-v1.json

Compile under the exact pinned interpreter.

Retain complete process custody.

Run source-external AST, call-graph, dataflow, filesystem-effect,
process-effect, import-origin, and terminal-operation checks.

Freeze reconciliation source before substantive adjudication.

Do not modify it afterward.

──────────────────────────────────────────────────────────────────────────────
8. A06 WITNESS-CLOSURE ADJUDICATION
────────────────────────────────────────────────

Resolve exact historical A06 records through the sealed audit capsule:

- A06 phase record;
- A06 finding;
- contract-derived witness audit result;
- schema-derived witness audit result;
- combined witness closure result;
- high-level witness confirmations;
- every direct evidence pointer;
- audit-source code responsible for A06 aggregation and reporting.

Resolve exact producer-side witness records through the subject’s current role
registry.

Independently reconstruct all:

- 14 contract-derived witnesses;
- 14 schema-derived witnesses.

For every witness retain:

- witness ID;
- family ID;
- construction authority;
- exact instance;
- current schema role/path/identity;
- normative-contract pointers;
- schema validation result;
- contract-semantic result;
- exact errors;
- producer result;
- historical audit result;
- fresh reconciliation result.

Require explicit answers:

1. Did any witness actually fail schema validation?
2. Did any witness actually fail contract semantics?
3. Did the combined closure fail because of:
   - witness content;
   - count/uniqueness;
   - registry mismatch;
   - stale identity;
   - aggregation logic;
   - report generation;
   - missing evidence;
   - another exact cause?
4. Why did A06 fail while:
   - FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID remained true;
   - FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID remained true?
5. Why are the A06 finding’s direct-evidence fields null?
6. Does the A06 finding satisfy the audit’s own direct-evidence and ownership
   contract?

Classify A06 as exactly one:

SUBJECT_PACKAGE_DEFECT

INDEPENDENT_AUDIT_ORACLE_DEFECT

INDEPENDENT_AUDIT_EVIDENCE_OR_REPORTING_DEFECT

MIXED_DEFECT

UNRESOLVED

If subject-package defect is selected, identify exact repair owner:

- schema bytes;
- normative contract;
- witness specification;
- reconstruction parent;
- subject evidence generation;
- another exact owner.

If audit defect is selected, identify exact audit-source function and repair
surface.

──────────────────────────────────────────────────────────────────────────────
9. EXACT A07 FAILURE LEDGER
────────────────────────────────────────────────

Resolve the complete historical A07 946-case result.

Do not rely on the aggregate count.

Retain:

analysis/a07-exact-failure-ledger-v1.json

The ledger must contain exactly 33 rows unless independent authentication proves
a different historical count.

For every failed or mismatched row retain:

- ordinal;
- literal_name;
- family ID;
- schema role;
- schema path and identity;
- base-instance identity;
- mutation operator;
- mutation JSON pointer;
- original value;
- mutated value;
- expected acceptance;
- expected rejection;
- expected reason class;
- producer observed acceptance;
- producer observed reason;
- historical audit observed acceptance;
- historical audit observed reason;
- fresh reconciliation observed acceptance;
- fresh reconciliation observed reason;
- jsonschema validity;
- exact validator keyword;
- instance path;
- schema path;
- normalized error set;
- governing contract pointer;
- governing validation-specification pointer;
- whether outcome mismatch occurred;
- whether reason-only mismatch occurred;
- whether producer and audit used identical case bytes;
- whether producer and audit used identical schema bytes;
- whether producer and audit used identical base-instance bytes;
- classification;
- repair owner;
- direct evidence.

Require no omitted historical failed row.

Require no added nonfailed row in the 33-row failure ledger.

──────────────────────────────────────────────────────────────────────────────
10. FRESH COMPLETE 946-CASE ADJUDICATION
────────────────────────────────────────────────

Authenticate the exact current 946-case registry.

Independently require:

- 946 rows;
- 946 unique literal names;
- exact expected-name closure;
- exact current expectations.

Run all 946 cases with fresh source-external logic.

For every case retain:

- expected result;
- producer result;
- historical audit result;
- reconciliation result;
- classification agreement.

Do not import or call either historical checker.

Require an aggregate containing:

- total;
- passed against governing expectation;
- subject defects;
- producer-checker defects;
- independent-audit-checker defects;
- reason-taxonomy defects;
- registry defects;
- mixed defects;
- unresolved cases;
- skips;
- exceptions.

The 33 historical failures must be a named subset of this complete result.

──────────────────────────────────────────────────────────────────────────────
11. EXACT A08 FAILURE LEDGER
────────────────────────────────────────────────

Resolve the complete historical A08 137-case result.

Retain:

analysis/a08-exact-failure-ledger-v1.json

The ledger must contain exactly four rows unless independent authentication
proves a different historical count.

For every failed row retain the same fields required in Section 9, plus:

- historical contradiction family;
- historical 33-case-prefix membership;
- contradiction site;
- atomic member count where governed;
- expected historical closure behavior.

Require no omitted historical failed row.

──────────────────────────────────────────────── LIMITED TO COMPLETE SUITE
────────────────────────────────────────────────

12. FRESH COMPLETE 137-CASE ADJUDICATION

Authenticate the exact current contradiction registry.

Require:

- 137 rows;
- unique literal names;
- exact expected-name closure;
- exact governed historical-prefix semantics.

Run all 137 cases independently.

For every case compare:

- governing expectation;
- producer result;
- historical audit result;
- reconciliation result.

Retain exact defect ownership and reason taxonomy.

The four historical failures must be a named subset of this result.

──────────────────────────────────────────────── LIMITED TO DERIVED FAILURES
────────────────────────────────────────────────

13. A11 CONFIRMATION-EVIDENCE ADJUDICATION

Resolve:

- exact current confirmation-evidence map;
- historical A11 phase;
- historical A11 finding;
- all 66 historical derived confirmation rows;
- the exact 15 false rows;
- high-level explicit-confirmation aggregate;
- audit-source derivation and reporting logic.

Retain:

analysis/a11-false-confirmation-ledger-v1.json

For every false row retain:

- confirmation name;
- evidence path;
- JSON pointer;
- expected value;
- historical observed value;
- fresh observed value;
- source phase/finding dependency;
- whether it depends on A06;
- whether it depends on A07;
- whether it depends on A08;
- whether the confirmation-map logic itself is defective;
- whether absence was treated as success;
- whether stale or historical evidence was used;
- classification;
- repair owner.

Require an explicit answer:

Are all 15 false rows wholly derivative from A06/A07/A08?

Classify A11 as exactly one:

DERIVATIVE_FAILURE_ONLY

CONFIRMATION_MAP_DEFECT

AUDIT_DERIVATION_DEFECT

MIXED_DEFECT

UNRESOLVED

Do not count a wholly derivative A11 result as an independent package blocker.

──────────────────────────────────────────────── LIMITED TO THIRD PERSPECTIVE
────────────────────────────────────────────────

14. THREE-WAY RECONCILIATION

Retain independently authored projections:

analysis/perspective-subject-producer-v1.json
analysis/perspective-historical-independent-audit-v1.json
analysis/perspective-fresh-reconciliation-v1.json

For A06, each A07 failed row, each A08 failed row, and each A11 false row,
crosswalk:

- governing authority;
- producer interpretation;
- historical audit interpretation;
- fresh reconciliation interpretation;
- exact disagreement;
- winning interpretation;
- reason the winning interpretation has authority;
- repair owner.

Do not select a winner by majority vote.

Authority order is:

1. normative contract for semantic requirements;
2. current schemas for representation enforcement;
3. current validation specifications for case definitions and expected
   outcomes;
4. independently observed JSON Schema behavior for schema validity;
5. producer/audit outputs as evidence only.

If the governing sources are ambiguous or contradictory, classify unresolved.

──────────────────────────────────────────────── LIMITED TO REPAIR OWNERSHIP
────────────────────────────────────────────────

15. REPAIR-OWNER REGISTRY

Retain:

analysis/final-repair-owner-registry-v1.json

Allowed owner classes:

- NORMATIVE_CONTRACT_AUTHORITY
- CURRENT_SCHEMA_AUTHORITY
- VALIDATION_SPECIFICATION_AUTHORITY
- SUBJECT_RECONSTRUCTION_PARENT
- SUBJECT_EVIDENCE_GENERATION
- PRODUCER_VALIDATOR_LOGIC
- INDEPENDENT_AUDIT_ORACLE
- INDEPENDENT_AUDIT_EVIDENCE_PROJECTION
- INDEPENDENT_AUDIT_REPORTING
- CONFIRMATION_EVIDENCE_MAP
- MIXED_OWNER
- UNRESOLVED_OWNER

For every confirmed defect retain:

- defect ID;
- owner class;
- exact owning role/path/schema;
- exact source or artifact repair surface;
- whether current sealed subject bytes must change;
- whether reconstruction is required;
- whether the unchanged subject may be re-audited;
- whether a governing documentary decision is required;
- dependent findings;
- mandatory validation after repair.

No defect may have more than one primary owner unless classified mixed.

──────────────────────────────────────────────── LIMITED TO ONE DECISION
────────────────────────────────────────────────

16. MANDATORY NEXT ENGINEERING TREATMENT

Retain:

analysis/mandatory-next-engineering-treatment-v1.json

Select exactly one.

A. PACKAGE_ONLY

Conditions:

- at least one direct current subject-package defect is confirmed;
- no independent audit defect affects the correctness of that package
  diagnosis.

Mandatory treatment:

1. preserve current sealed subject and audit capsule as historical;
2. repair the exact owning authority or generation surface;
3. do not mutate the current sealed subject;
4. construct one fresh subject;
5. run one fresh independent audit;
6. no additional findings reconciliation.

B. AUDIT_ONLY

Conditions:

- zero direct current subject-package defects;
- every A06/A07/A08/A11 failure is audit-owned or derivative.

Mandatory treatment:

1. preserve the subject unchanged;
2. retire the historical failed audit result as nonqualifying for forward
   acceptance;
3. repair the exact audit oracle/evidence/reporting surface;
4. freshly qualify the audit;
5. run one fresh audit of the unchanged subject;
6. no additional findings reconciliation.

C. MIXED

Conditions:

- at least one direct subject-package defect;
- at least one independent audit defect materially affected the result.

Mandatory treatment:

1. preserve historical roots;
2. repair the exact package owner;
3. repair the exact audit owner;
4. construct a fresh subject only if required by the package repair;
5. run one fresh audit;
6. no additional findings reconciliation.

D. TERMINAL_STOP_AND_RECONSTRUCT

Conditions:

- governing evidence remains ambiguous;
- a required case or artifact cannot be authenticated;
- reconciliation provenance is nonqualifying;
- ownership cannot be decided without invention.

Mandatory treatment:

1. preserve historical subject and audit;
2. stop retrospective reconciliation;
3. reconstruct a fresh subject from accepted governing authorities;
4. use a freshly qualified independent audit;
5. no second reconciliation.

The treatment must identify:

- exact repair surface;
- exact source/authority owner;
- whether subject reconstruction is required;
- whether subject reuse is allowed;
- whether audit-source reuse is allowed;
- required fresh validation;
- stop conditions.

────────────────────────────────────────────────

17. HISTORICAL VERDICT AND NONCLAIMS

Retain:

analysis/historical-verdict-and-nonclaims-v1.json

Required facts:

- historical audit verdict remains:
  GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK;
- reconciliation does not accept the subject;
- reconciliation does not promote authority;
- reconciliation does not reverse or replace the BLOCK;
- reconciliation does not establish product/runtime readiness;
- reconciliation does not authorize target audit, publication, deployment, or
  A6;
- reconciliation determines forward repair ownership only.

────────────────────────────────────────────────

18. SUPPLIED-ROOT CLOSING EQUALITY

Repeat complete no-follow opening/closing equality for:

- constructed subject root;
- sealed subject-audit root;
- construction wrapper root;
- content bundle;
- content authority;
- every exact governing root opened by the reconciliation.

Require exact equality.

Do not mutate or clean supplied roots.

────────────────────────────────────────────────

19. RECONCILIATION CLEANUP

Retain:

cleanup/reconciliation-cleanup-result-v1.json

Require exact equality:

created reconciliation-owned fixture roots
=
inventoried fixture roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Equal empty sets pass.

Require zero:

- process survivors;
- descriptor survivors;
- cache survivors;
- bytecode survivors.

────────────────────────────────────────────────

20. TERMINAL RECONCILIATION-CAPSULE CLOSURE

Before temporal projection:

- finalize every nonclosure record;
- create only used directories;
- require no empty descendant;
- reserve temporal and two manifest paths;
- retain descriptors;
- freeze namespace.

Create:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json
terminal/terminal-result-v1.json

Require:

- temporal bytes independently generated twice;
- immediate temporal reprojection;
- independently generated A/B;
- A/B byte equality;
- descriptor/path inode equality;
- independent final whole-root reprojection;
- root row once;
- clean topology and modes;
- no cache or bytecode;
- one seal transition;
- no filesystem/process/validation operation after seal.

Prepare the terminal frame fully in memory before seal.

After seal:

- emit only the terminal frame;
- exit nonreturningly.

────────────────────────────────────────────────

21. VERDICT RULES

Return:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_CONFIRMED_PACKAGE_REPAIR_REQUIRED

only when:

- reconciliation provenance passes;
- at least one direct current subject-package defect is confirmed;
- no audit defect materially undermines the package diagnosis;
- treatment PACKAGE_ONLY is selected;
- diagnostic capsule terminally closes.

Return:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILED_AUDIT_REPAIR_REQUIRED

only when:

- reconciliation provenance passes;
- zero direct current subject-package defects remain;
- all failures are audit-owned or derivative;
- treatment AUDIT_ONLY is selected;
- diagnostic capsule terminally closes.

Return:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILED_MIXED_REPAIR_REQUIRED

only when:

- reconciliation provenance passes;
- both package and audit defects are confirmed;
- treatment MIXED is selected;
- diagnostic capsule terminally closes.

Return:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILIATION_TERMINAL_STOP_AND_RECONSTRUCT

when:

- evidence remains insufficient;
- ownership remains unresolved;
- treatment TERMINAL_STOP_AND_RECONSTRUCT is selected;
- diagnostic capsule terminally closes.

Return:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK_RECONCILIATION_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- source/toolchain provenance failure;
- evidence loss;
- supplied-root mutation;
- process-custody loss;
- cleanup inequality;
- diagnostic-capsule closure failure;
- postseal activity.

────────────────────────────────────────────────

22. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve the sealed subject;
- preserve the sealed audit capsule;
- preserve the construction wrapper;
- preserve all governing inputs;
- preserve the sealed reconciliation capsule;
- do not begin the selected repair;
- do not construct a new subject;
- do not run a fresh subject audit;
- do not promote current authority;
- do not execute product/runtime/target activity;
- do not modify a repository;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

23. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh reconciliation-root identity
3. Subject-root authentication
4. Historical audit-root authentication
5. Historical BLOCK authentication
6. Construction-chain authentication
7. Content/governing authority authentication
8. Reconciliation source and toolchain
9. Reconciliation source freeze
10. A06 exact artifact resolution
11. All 28 fresh witness results
12. A06 causal classification
13. Exact 33-row A07 failure ledger
14. Fresh complete 946-case result
15. A07 defect classifications
16. Exact four-row A08 failure ledger
17. Fresh complete 137-case result
18. A08 defect classifications
19. Exact 15-row A11 false-confirmation ledger
20. A11 derivative/independent classification
21. Producer perspective
22. Historical-audit perspective
23. Fresh-reconciliation perspective
24. Three-way disagreement reconciliation
25. Repair-owner registry
26. Confirmed package defects
27. Confirmed audit defects
28. Derivative findings
29. Mixed findings
30. Unresolved findings
31. Historical-verdict preservation
32. Mandatory next treatment
33. Subject-reuse disposition
34. Audit-source-reuse disposition
35. Supplied-root closing equality
36. Reconciliation cleanup
37. Temporal-inventory identity
38. Manifest A identity
39. Manifest B identity
40. A/B equality
41. Final reprojection
42. Terminal topology and modes
43. Seal transition
44. No-postseal result
45. Remaining uncertainty and nonclaims
46. Explicit reconciliation confirmations

Required confirmations:

CONSTRUCTED_SUBJECT_ROOT_AUTHENTICATED
HISTORICAL_AUDIT_ROOT_AUTHENTICATED
HISTORICAL_BLOCK_AUTHENTICATED
HISTORICAL_BLOCK_NOT_REWRITTEN
CONSTRUCTION_WRAPPER_AUTHENTICATED
CURRENT_CONTENT_AUTHORITY_AUTHENTICATED
RECONCILIATION_SOURCE_EXTERNAL
RECONCILIATION_SOURCE_FROZEN
A06_ALL_WITNESSES_RECONSTRUCTED
A06_COMBINED_CLOSURE_CAUSAL_ADJUDICATED
A06_HIGH_LEVEL_CONFIRMATION_TENSION_ADJUDICATED
A06_NULL_DIRECT_EVIDENCE_ADJUDICATED
A07_EXACT_33_FAILURE_ROWS_RETAINED
A07_COMPLETE_946_CASES_FRESHLY_RUN
EVERY_A07_FAILURE_CLASSIFIED
A08_EXACT_FOUR_FAILURE_ROWS_RETAINED
A08_COMPLETE_137_CASES_FRESHLY_RUN
EVERY_A08_FAILURE_CLASSIFIED
A11_EXACT_15_FALSE_ROWS_RETAINED
EVERY_A11_FALSE_ROW_CROSSWALKED
A11_DERIVATIVE_STATUS_ADJUDICATED
PRODUCER_AUDIT_RECONCILIATION_THREE_WAY_COMPLETE
NO_MAJORITY_VOTE_USED_AS_AUTHORITY
NORMATIVE_CONTRACT_USED_AS_SEMANTIC_AUTHORITY
CURRENT_SCHEMAS_USED_AS_REPRESENTATION_AUTHORITY
VALIDATION_SPECIFICATIONS_USED_AS_CASE_AUTHORITY
JSON_SCHEMA_BEHAVIOR_INDEPENDENTLY_OBSERVED
EVERY_CONFIRMED_DEFECT_HAS_PRIMARY_OWNER
REPAIR_OWNER_REGISTRY_COMPLETE
MANDATORY_NEXT_TREATMENT_SELECTED
SUBJECT_REUSE_DISPOSITION_SELECTED
AUDIT_SOURCE_REUSE_DISPOSITION_SELECTED
FURTHER_FINDINGS_RECONCILIATION_FORBIDDEN
SUBJECT_MUTATION_NOT_PERFORMED
AUDIT_ROOT_MUTATION_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
RECONCILIATION_CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
RECONCILIATION_TEMPORAL_INVENTORY_CREATED
RECONCILIATION_TEMPORAL_INVENTORY_VERIFIED
RECONCILIATION_MANIFEST_A_CREATED
RECONCILIATION_MANIFEST_B_CREATED
RECONCILIATION_MANIFESTS_BYTE_IDENTICAL
RECONCILIATION_TERMINAL_REPROJECTION_PASSED
RECONCILIATION_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Source

The assessment above is grounded only in the Codex operative report in your message.

**Confidence:** 0.999 that the sealed subject remains blocked and noncurrent; 0.999 that A11 is derivative unless the map itself is independently defective; 0.995 that A06 contains an audit evidence/reporting inconsistency; 0.90 that A07/A08 require exact case-level adjudication before a responsible repair owner can be selected.
