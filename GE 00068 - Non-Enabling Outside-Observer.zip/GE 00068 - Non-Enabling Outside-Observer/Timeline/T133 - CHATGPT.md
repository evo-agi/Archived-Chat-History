## Assessment

The fourth audit’s **BLOCK** is correct and narrowly scoped. The existing provenance, authority split, prior parser/resource fixes, 59-test validation, real-child compatibility checks, and audit procedure all passed. One new defect remains: the verifier derives its package boundary from the **lexical** `__file__` path, so an external symlink can launch verifier source physically stored inside the target and still receive `outcome: pass`. 

The reproduction is conclusive: exact verifier bytes were placed inside an audit-owned target, an external package path symlinked to those bytes, and both invocations exited successfully. That contradicts the documented source-external/no-self-verification contract. The minority view correctly notes that the canonical audited invocation was externally pinned and safe, but it does not close the verifier’s general contract: the source currently checks only the external lexical package directory, not the actual executable-source object. 

This needs one bounded repair, not another architecture reset:

- Bind the actual executable source as a physical regular file.
- Reject a symlinked source leaf, symlinked source-path component, multi-link/hardlinked source, or source whose physical parent ancestry intersects the target.
- Derive the package directory from that verified physical source path, not from `Path(__file__).absolute()`.
- Preserve external provenance as the authority for source bytes; do **not** make the verifier self-certify its source hash.
- Add pre-seal and sealed regression cases.
- Update the two authoritative docs only as needed to state the exact physical-source boundary.
- Generate new provenance and submit the changed bytes to a fifth fresh audit.

The architecture decision already requires an external verifier that never verifies its own repository or evidence container.  Proof tooling and generated evidence remain non-authoritative. 

The prompt below also makes your response-format requirement mandatory: **Codex must embed its complete report in the response body. A link may be supplemental, never a substitute.**

## Codex repair prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete report inline in Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

A source-external report file may be created and linked as supplemental
evidence, but the complete contents required by this prompt must also appear
verbatim or equivalently completely in the response body.

This applies to every outcome, including:

- success;
- baseline mismatch;
- scope expansion;
- repair block;
- validation block;
- provenance block.

Do not silently truncate the inline report. If output pressure exists,
prioritize the complete inline report over file links.

Objective

Resume the Evidence Verification v1 implementation in the same implementation
worktree and repair the fourth-audit SEC-01 executable-source physical-boundary
bypass.

The fourth audit returned BLOCK after reproducing this mechanism:

- the verifier’s executable source was physically located beneath the target;
- an external package directory contained a symlink to that source;
- Python executed the target-contained source through the external symlink;
- `Path(__file__).absolute().parent` retained the external lexical package
  spelling;
- package/target ancestry checks therefore missed the actual source location;
- the verifier returned `outcome: pass`.

Adopt a direct-source, physically disjoint, fail-closed enforcement rule.

Do not redesign the external-verifier architecture.
Do not add self-verification authority.
Do not create another worktree.
Do not reset, clean, restore, rebase, or discard the current patch.
Do not modify the Repair 10I candidate.
Do not modify sealed A6D or amendment evidence.
Do not modify any completed audit root.
Do not stage, commit, push, create a PR, install, deploy, restart A6, invoke a
live service, contact a network, or perform an independent audit.

No subagents. You are the sole repository writer.

## 1. Paths

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Implementation branch:

codex/evidence-verification-v1

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Required new repair-evidence root:

REPAIR_EVIDENCE=$EVIDENCE/audit-repair-v3

Require REPAIR_EVIDENCE absent before creation.

Fourth audit, read-only:

AUDIT_V4=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4

Fourth-audit report:

AUDIT_V4/closeout/report.md

Fourth-audit source-symlink reproduction:

AUDIT_V4/validation/source-symlink-repro.json

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as implementation cwd/source root:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Exact provenance recipe source:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Exact retained predecessor manifest:

PREDECESSOR_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/manifest-run-1.json

## 2. Mandatory opening provenance gate

Set:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Every Git command must use:

git -C "$IMPL_R" ...

with `GIT_OPTIONAL_LOCKS=0` and `GIT_CONFIG_NOSYSTEM=1`.

Before editing, require IMPL_R:

- physical root equals lexical path;
- root is a real directory;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular;
- every working-tree mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no path outside the expected set;
- no Git operation marker or lock.

Expected 13 paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Require current fourth-audit target identities:

- canonical patch-manifest SHA-256:
  `5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57`
- tracked binary-diff SHA-256:
  `7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070`
- verifier SHA-256:
  `60cdcab597cfc233d9406794886df02b54296cd392d7af4d082c75e87a5bc21e`
- provenance recipe source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
- registry SHA-256:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`
- A6D successor layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`
- A6D amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`
- A6 policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`.

Run the exact provenance recipe twice before editing, using fresh output paths
beneath REPAIR_EVIDENCE/opening/provenance after REPAIR_EVIDENCE is created.

Require:

- byte-identical recipe outputs;
- equality with PREDECESSOR_MANIFEST;
- exact current per-file identities;
- exact 13-path scope;
- exact tracked binary-diff digest.

Require AUDIT_V4 byte-exact, including:

- `closeout/report.md`;
- `validation/source-symlink-repro.json`;
- all perspective reports;
- opening and closing provenance;
- audit-created path inventory.

Require CANDIDATE_R unchanged:

- physical device/inode:
  `16777234/122118502`;
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`;
- source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
- membership:
  `389 / 375 / 14`;
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require A6D manifest unchanged:

`dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`

Require A6D_AMEND manifest unchanged:

`a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_BASELINE_MISMATCH

## 3. Repair-evidence root

Create REPAIR_EVIDENCE under umask `077` with:

- `opening/`
- `findings/`
- `validation/`
- `provenance/`
- `closeout/`

All directories mode `0700`.
All files regular, single-link, mode `0600`.

Do not overwrite previous implementation or audit evidence.

Create a finding-disposition record for SEC-01 containing:

- exact audit finding;
- minority containment view;
- parent adjudication;
- vulnerable mechanism;
- selected enforcement policy;
- authorized files;
- required causal matrix;
- final disposition.

## 4. Finding disposition and selected enforcement model

Adopt the fourth audit’s parent adjudication:

- The canonical audited invocation was externally pinned and used a direct
  regular source outside the target.
- That contains the finding for those specific invocations only.
- The verifier’s documented contract is categorical:
  executable source must be physically source-external.
- Lexical external package spelling is insufficient.
- A verifier invocation through a source symlink or equivalent alias is
  nonqualifying.
- This is a repairable implementation defect, not an architecture,
  ownership, readiness, product, or runtime defect.

Freeze this enforcement policy:

### Direct-source-only rule

A qualifying invocation requires:

1. The invocation source path is absolute.
2. The final source path component is a regular file, not a symlink.
3. Every path component from filesystem root through the source parent is
   opened or observed no-follow and is not a symlink.
4. The source file has link count exactly one.
5. The source file opening identity is stable:
   - device;
   - inode;
   - regular-file type;
   - link count;
   - mode;
   - size.
6. The source file remains stable through the verifier invocation’s boundary
   checks and at closing re-observation.
7. The physical source parent/package ancestry is disjoint from the target.
8. The target is neither equal to nor an ancestor or descendant of the
   physical source package.
9. The pre-seal manifest candidate remains disjoint from both source package
   and target under the already implemented candidate rules.
10. Any source identity, ancestry, or capability uncertainty fails closed.

Invocation through any of the following is nonqualifying:

- final source symlink;
- symlinked source-path component;
- source hardlink or other multi-link file;
- direct source physically beneath the target;
- target physically beneath the source package;
- source package physically beneath the target;
- case-variant path that resolves to a prohibited physical relationship;
- source identity substitution during the invocation.

The tool need not support symlink-based launch, even when the resolved source
would otherwise be outside the target.

## 5. Preserve non-self-verification architecture

Do not add:

- expected verifier source hash as a CLI argument;
- source hash as verifier authority;
- a verifier-produced claim that its source is trusted;
- target-contained provenance;
- runtime source registration;
- self-certification;
- a new verifier version;
- a new layout version;
- a registry change.

External implementation/audit provenance remains responsible for proving the
exact executable-source bytes.

The verifier enforces only physical source/package/target separation and
stable source identity.

Its canonical output must not include:

- source path;
- source inode;
- source digest;
- target path;
- hostname;
- username;
- readiness claim.

## 6. Exact repair scope

The final patch remains the same 13-path tranche.

This repair may modify only:

1. `tools/evidence_verify/verify_v1.py`
2. `tools/evidence_verify/test_verify_v1.py`
3. `.docs/system_overview/evidence_verification.md`
4. `.docs/system_overview/artifact_hygiene.md`

Modify only the files genuinely required.

Keep byte-identical during this repair:

- `PLANS.md`
- `.docs/system_overview/boundaries.md`
- `.docs/system_overview/capability_probing.md`
- `tools/evidence_verify/registry_v1.json`
- all three layout files
- both historical fixture files.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No product/public schema.
No Go source.
No runtime route.

If another repository path is required, stop:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_SCOPE_EXPANSION_REQUIRED

## 7. Executable-source binding implementation

Replace lexical package derivation as the security authority.

Do not use:

- `Path(__file__).absolute().parent`;
- `Path.resolve()` alone;
- case folding;
- lowercase comparison;
- `realpath()` string comparison;
- `commonpath()` string comparison;

as the deciding source boundary.

A permissible implementation shape is:

1. Read both `__file__` and `sys.argv[0]`.
2. Require the selected invocation-source spelling to be absolute.
3. Require any relevant `__file__`/argv relationship to be internally
   consistent; disagreement fails closed.
4. Component-walk the invocation source from filesystem root with no-follow
   observations.
5. Reject any symlink component.
6. Open the source with `O_RDONLY | O_NOFOLLOW` and any safe nonblocking flag
   required by the existing platform contract.
7. Require:
   - regular file;
   - link count one;
   - stable opening/fstat/path identity.
8. Bind the source’s physical parent directory and ancestor chain using
   descriptor-relative traversal.
9. Derive the verifier package directory from that verified physical parent,
   not from the lexical source string.
10. Use the existing descriptor-bound physical ancestry machinery to compare:
    - source package versus target;
    - target versus source package;
    - source parent chain versus target.
11. Reobserve source path, source descriptor identity where still applicable,
    and package ancestry before producing `pass`.
12. Any substitution, disappearance, reuse, or unprovable relationship blocks.

Classification:

- definite source/package/target alias, containment, symlink, or multi-link
  condition:
  - outcome `reject`;
  - error class `TARGET_BOUNDARY`;
  - exit `2`.
- unsupported operation, source identity race, closing uncertainty, or
  inability to prove the relationship:
  - outcome `indeterminate`;
  - error class `IO_OR_RACE`;
  - exit `7`.

Exactly one canonical stdout line.
Empty stderr.
No traceback.

## 8. Required vulnerable and repaired causals

First reproduce the audit’s vulnerable predecessor using an audit-repair-owned
copy of the predecessor verifier. Do not execute or modify AUDIT_V4 fixtures.

Require the vulnerable predecessor to show:

- source bytes physically inside target;
- external source symlink;
- lexical package outside target;
- pre-seal exit 0;
- canonical `pass`.

Then require the repaired verifier to reject.

Add at least these isolated causals:

1. **Direct regular external source, disjoint target**
   - pre-seal passes;
   - sealed passes.

2. **Source physically inside target, direct path**
   - pre-seal `TARGET_BOUNDARY`;
   - sealed `TARGET_BOUNDARY`.

3. **External final-component symlink to target-contained source**
   - pre-seal `TARGET_BOUNDARY`;
   - sealed `TARGET_BOUNDARY`.

4. **External parent-directory symlink leading to target-contained source**
   - pre-seal `TARGET_BOUNDARY`;
   - sealed `TARGET_BOUNDARY`.

5. **External hardlink to target-contained source**
   - source link count greater than one;
   - pre-seal `TARGET_BOUNDARY`;
   - sealed `TARGET_BOUNDARY`.

6. **Source package beneath target**
   - rejects.

7. **Target beneath source package**
   - rejects.

8. **Source package equals target**
   - rejects.

9. **Case-variant spelling of a prohibited physical relationship**
   - rejects identically on this case-insensitive filesystem.

10. **Source replaced or identity-changed before closing adjudication**
    - `IO_OR_RACE`;
    - no pass.

11. **Source disappears before closing adjudication**
    - `IO_OR_RACE`;
    - no pass.

12. **Unsupported no-follow or parent-traversal operation**
    - canonical `IO_OR_RACE`;
    - exit 7;
    - no pathname fallback.

13. **Direct external source with same bytes as a target payload, but distinct
    inode and single link**
    - remains admissible;
    - byte equality alone does not create containment.

14. **Source path outside target but source parent is a symlink**
    - rejects under the direct-source-only rule.

Every negative must assert exact:

- outcome;
- error class;
- exit;
- one stdout line;
- empty stderr;
- no traceback.

No required test skip.

## 9. Documentation alignment

Update `.docs/system_overview/evidence_verification.md` only as needed to state:

- “source-external” refers to the physical executable-source object and its
  physical package ancestry, not merely lexical invocation spelling;
- direct regular, single-link, non-symlink source invocation is required;
- symlinked or hardlinked launch is deliberately unsupported and fail-closed;
- source/package/target physical relationships are checked;
- external provenance still authenticates exact source bytes;
- the verifier does not self-certify its source.

Update `.docs/system_overview/artifact_hygiene.md` only as needed to align its
categorical source-external rule with that enforcement.

Do not change the verifier’s authority, tool ID, layout schema, or readiness
boundary.

If the existing text already states an item exactly, avoid redundant prose.

## 10. Preserve every previous repair

Rerun and preserve all current coverage for:

- physical target/package ancestry;
- target and manifest-candidate case aliases;
- manifest-candidate symlink/hardlink handling;
- literal-LF grammar;
- bounded package JSON;
- bounded manifest reader;
- seal-file accounting;
- bounded decimal parser;
- strict spec-path prevalidation;
- capability uncertainty;
- umask independence;
- isolated missing-root/symlink/FIFO checks;
- exact helper `0700` modes;
- fixed-record `0600` modes;
- no runtime layout injection;
- no writes;
- deterministic output;
- readiness-content noninterpretation;
- real A6D and amendment compatibility.

Do not weaken or remove an existing test to obtain a pass.

## 11. Complete fresh validation

After repair, rerun the entire validation program from the beginning.

Use:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Require:

- version `3.13.4`;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Use:

- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- private repair-owned `TMPDIR`;
- no network.

Required gates:

1. Parse all current Python source with `ast.parse`.
2. Parse both historical `.py.txt` fixtures without executing them.
3. Strictly parse registry and all three layouts.
4. Require registry and all layout bytes/hashes unchanged.
5. Discover and retain the complete final test set.
6. Run the complete suite twice under umask `077`.
7. Run the complete suite twice under umask `022`.
8. Require identical discovered identities and zero failure/error/skip.
9. Run every new source-boundary causal separately.
10. Retain vulnerable predecessor and repaired outcomes.
11. Verify sealed A6D twice.
12. Verify sealed amendment twice.
13. Verify synthetic A6 pre-seal twice.
14. Seal the synthetic fixture with the existing test-owned writer.
15. Verify synthetic A6 sealed twice.
16. Require repeated canonical stdout byte equality.
17. Snapshot each real/synthetic target and the verifier package before and
    after invocation.
18. Require exact equality.
19. Verify historical fixture hashes unchanged.
20. Run:
    `git -C "$IMPL_R" diff --check`
    with `GIT_OPTIONAL_LOCKS=0` and `GIT_CONFIG_NOSYSTEM=1`.
21. Scan IMPL_R for:
    - `__pycache__`;
    - `.pyc` or `.pyo`;
    - `.pytest_cache`;
    - generated manifests;
    - databases;
    - journals;
    - locks;
    - fixture roots;
    - temporary outputs;
    - unexpected executable modes;
    - unsupported objects.

Remove every repair-owned temporary fixture root after its owning check.

No Go suite.
No product execution.
No live service.
No target mutation.
No child process from the verifier.
No network.

## 12. Repair evidence

Retain beneath REPAIR_EVIDENCE:

- opening provenance;
- exact SEC-01 report and disposition;
- minority-view disposition;
- predecessor vulnerable reproduction;
- repaired causal records;
- complete final test list;
- all four complete test runs;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded attempt index;
- cleanup;
- implementation-report inputs.

Preserve AUDIT_V4 byte-exact.

## 13. Final provenance

After all validation passes, use the exact existing provenance recipe:

- path:
  `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py`
- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`.

Do not modify or reconstruct it.

Run it twice against IMPL_R using fresh, absent output paths beneath
REPAIR_EVIDENCE/provenance.

Require:

- both exits 0;
- empty stderr;
- byte-identical outputs;
- exact same 13-path scope;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deletion;
- zero rename;
- zero unsupported type;
- no path outside scope.

Retain:

- exact recipe source;
- both canonical outputs;
- new canonical patch-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities.

The fourth audit and all earlier audits become predecessor evidence only and
do not qualify changed bytes.

## 14. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- every path regular logical mode `100644`;
- `git diff --check` clean;
- no repository cache, bytecode, generated manifest, fixture, database, lock,
  journal, or temporary output.

Require CANDIDATE_R closing identity equal to opening.

Require A6D and A6D_AMEND unchanged.

Require AUDIT_V4 unchanged.

Require PRIMARY_R never used as implementation cwd or source root.

Do not remove IMPL_R or EVIDENCE.

## 15. Mandatory stops

Stop on:

- opening provenance mismatch;
- audit evidence mutation;
- need for a fifth repair path;
- need to change registry, layout, fixture, boundary document, capability
  document, or PLANS.md;
- inability to bind the actual source without self-verification;
- any symlinked source invocation still passes;
- a multi-link source still passes;
- source physically beneath target still passes;
- source/package ancestry uncertainty falls back to string/path logic;
- source identity race can still produce pass;
- source boundary output leaks source or target paths;
- any earlier EV/F repair regresses;
- tests differ by umask;
- real A6D or amendment verification fails;
- target, package, audit, or candidate mutation;
- unstable final provenance.

## 16. Verdicts

Opening mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_BASELINE_MISMATCH

Scope expansion:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_SCOPE_EXPANSION_REQUIRED

Repair or validation failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_BLOCKED

Final provenance failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_PROVENANCE_BLOCKED

Complete success:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR3_IMPLEMENTED_READY_FOR_FRESH_REAUDIT

## 17. Required inline final report

Your final response must contain this entire report inline, even if the same
report is also written to a source-external file.

Include every section below in the response body:

1. Verdict.
2. Mandatory response-format confirmation.
3. Opening repository and provenance identity.
4. Exact fourth-audit report and SEC-01 evidence consumed.
5. Minority-view disposition.
6. Exact repair path subset.
7. Direct-source-only policy.
8. Executable-source binding algorithm.
9. Source/package/target physical-boundary behavior.
10. Definite boundary failures versus `IO_OR_RACE` uncertainty.
11. Vulnerable predecessor reproduction.
12. Every new causal and result.
13. Documentation changes or explicit no-change adjudication.
14. Complete discovered test set and count.
15. Results of both umask-077 runs.
16. Results of both umask-022 runs.
17. Regression validation for every earlier EV/F finding.
18. Real A6D checks.
19. Real amendment checks.
20. Synthetic A6 pre-seal and sealed checks.
21. No-write and deterministic-output evidence.
22. Final verifier SHA-256.
23. Registry and three layout hashes, confirming unchanged bytes.
24. Exact final 13-path manifest.
25. Provenance recipe identity and source SHA-256.
26. New tracked binary-diff SHA-256.
27. New canonical patch-manifest SHA-256.
28. Artifact hygiene and cleanup.
29. Authority/security widening:
    explicitly none, or exact contrary finding.
30. Remaining uncertainty and uninspected areas.
31. Explicit statements:
    - all previous audits no longer qualify changed bytes;
    - fresh fifth audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - no subagents were created.

Do not replace any section with a link.

Links may follow the inline report as supplemental references only.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## Next gate

A successful repair requires a **fifth fresh independent audit** with a new audit root. That audit must receive the new exact recipe source path, canonical-manifest path, complete tracked-diff digest, and full inline implementation report. It should independently rerun the symlinked-source and hardlink-source causals before inspecting the remaining patch.

Any changed byte invalidates the fourth audit and requires new provenance and a new independent audit.  Exact provenance must again be reproduced before correctness inspection. 

### Sources

- Attached fourth independent-audit report: verdict and new executable-source defect. 
- Prior findings and validations were otherwise causally closed. 
- Full SEC-01 finding and preserved minority view. 
- Selected non-recursive external-verifier architecture. 
- Proof scaffolding and generated evidence remain non-authoritative. 
- Repair requires new provenance and fresh re-audit. 
- Provenance-before-correctness audit sequence. 

**Confidence**

- Fourth-audit BLOCK verdict: **0.998**
- SEC-01 reproduction and severity: **0.997**
- Architecture remains sound: **0.995**
- Repairability within the four authorized files: **0.96**
- Direct-source-only enforcement as the safest bounded policy: **0.97**
- Correct next gate after repair: fifth fresh independent audit, **0.999**
