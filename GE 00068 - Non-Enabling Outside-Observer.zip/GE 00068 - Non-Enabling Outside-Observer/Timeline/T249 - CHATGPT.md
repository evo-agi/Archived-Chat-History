## Assessment

This resolves the publication topology:

```text
H 567bceced… / tree b7cab237…
  └─ one cumulative predecessor commit:
     "implement Remote Alpha external TLS T2A-P source"
     36 paths: 22 modified + 14 added
     └─ B source T 8de797304…
        └─ audited governance commit:
           7 modified paths
           └─ F source T f276536f…
```

The important conclusions are:

- **H→B is one authoritative logical tranche**, not a speculative collection of smaller commits.
- The exact B bytes already exist and privately simulated to a clean, passing tree. No repository implementation is needed.
- The 36-path commit cannot be published yet because its exact-source package has not received a fresh independent audit.
- Once B is committed, the deployment document is tracked. The existing B→F governance delta is therefore **seven modified paths**, and the accepted governance audit remains usable.
- After B publication, B→F needs only a fresh parent-only commit gate—not another implementation pass or broad independent audit.
- A6 remains blocked until both commits are properly published and the later successor programs are implemented and qualified.

Do not attempt another commit gate yet. The next step is to produce a source-external **strategic B snapshot package** that an independent auditor can reconstruct without relying on the mutable candidate worktree.

A critical requirement is to keep **repository logical mode** separate from **evidence-custody mode**. Snapshot files may physically be `0600`, but their repository logical modes must come from the authenticated B inventory. The earlier provenance defect came from conflating those two facts.

## Prompt for Codex

```text
REPAIR 10I T2A-P STRATEGIC B SNAPSHOT IMPLEMENTATION

Create a source-external, immutable, exact-source strategic snapshot of the
authenticated pre-governance state B for fresh independent audit.

Do not create subagents.

This task does not stage, commit, edit, reset, restore, clean, or otherwise
mutate the candidate repository. It does not publish B. It creates only a
source-external snapshot and its validation/provenance evidence.

Return exactly one primary verdict:

REPAIR10I_T2AP_STRATEGIC_B_SNAPSHOT_READY_FOR_FRESH_AUDIT
REPAIR10I_T2AP_STRATEGIC_B_SNAPSHOT_BLOCKED
SNAPSHOT_PROVENANCE_MISMATCH

OBJECTIVE

Create one exact, complete, source-external representation of B:

- complete 389-file governed source;
- exact logical modes, sizes, and SHA-256 values;
- exact source T and inventory identity;
- exact H→B 36-path classification and byte delta;
- deterministic Git tree identity for B;
- one private synthetic commit candidate with parent H and the frozen subject;
- clean-tree validation using the acceptance-bearing retained command set;
- complete private evidence closure suitable for a fresh independent audit.

The package is evidence and a publication candidate only. It grants no
repository, product, runtime, readiness, commit, publication, or A6 authority.

──────────────────────────────────────────────────────────────────────────────
1. EXACT STATES AND DECISION INPUT
──────────────────────────────────────────────────────────────────────────────

Candidate repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

H — current committed parent:

- commit:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f

B — exact strategic snapshot target:

- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- inventory size:
  54314 bytes
- governed files:
  389
- relative to H:
  - 22 modified tracked paths
  - 14 added paths
  - 0 deleted
  - 0 renamed
  - 36 changed paths total

F — current live working-tree target after governance:

- source T:
  f276536fea579d0842cda43b0290656b200b7f27
- inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

Frozen H→B logical commit:

- subject:
  implement Remote Alpha external TLS T2A-P source
- topology:
  one cumulative commit
- status:
  exact bytes recoverable; publication requires strategic snapshot and fresh
  independent audit

Authoritative topology reconciliation:

/Users/ds/Downloads/ES-repair10i-predecessor-topology-recon-dupTHGG5

Required retained records:

- closeout/final-report.md
  SHA-256:
  c63d10db5637d0f6f9aefce8a8a4675db5d46aa3547039abe8d09639e4040ffd

- closeout/final-evidence-inventory.json
  SHA-256:
  61dab1a05527bcb57ebd9faf7f880ad366ba954f0fa870a547697113a953d0dc

Read the complete final report and its referenced exact records. Do not treat
the short calling-thread summary as the complete 36-path manifest.

──────────────────────────────────────────────────────────────────────────────
2. NAMED SOURCE AND EVIDENCE INPUTS
──────────────────────────────────────────────────────────────────────────────

Governance-freeze implementation evidence:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2

Governance audit-repair evidence:

/Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

Accepted governance/mode-provenance audit:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-final-audit-fjuro9xw

Failed staged-tree gate:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-commit-gate-v3-qv31qdyj

Commit-scope reconciliation:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-reconciliation-mmaexmlj

Repair 10 lineage:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1

Use only exact paths named by these records, candidate governing documents, and
repository guidance. Do not broadly scan unrelated Downloads content or sibling
repositories.

Treat every supplied input as immutable and read-only.

──────────────────────────────────────────────────────────────────────────────
3. EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read the candidate repository and named evidence;
- allocate one fresh private snapshot root beneath /Users/ds/Downloads;
- create retained source-external evidence beneath that root;
- create private temporary Git repositories, indexes, materializations, caches,
  homes, and test roots beneath that root;
- run bounded local validation with no network;
- create a private synthetic Git commit candidate inside a private repository;
- clean only task-owned temporary state.

Forbidden:

- repository edits;
- index mutation;
- staging or committing in the candidate;
- restore, reset, amend, stash, checkout, rebase, merge, clean, or worktree
  mutation in the candidate;
- supplied-evidence mutation;
- product/live-service invocation;
- installation;
- network contact;
- A6 work;
- subagents.

Every Git read against the candidate must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to that repository and:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

──────────────────────────────────────────────────────────────────────────────
4. FRESH SNAPSHOT ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable fresh directory beneath
/Users/ds/Downloads using tempfile.mkdtemp with prefix:

ES-repair10i-t2ap-strategic-b-snapshot-

Retained directories must be mode 0700.

Retained files must be regular, single-link, mode 0600.

The retained source bytes may be custody-mode 0600. Repository logical mode is
a separate authenticated field and must never be derived from physical custody
permissions.

Do not retain an unexplained empty directory.

Recommended retained structure:

opening/
source/
provenance/
validation/
git/
manifest/
closeout/

Private temporary materializations, Git repositories, homes, caches, and temp
roots must be beneath a task-owned private area that is removed before closeout.

──────────────────────────────────────────────────────────────────────────────
5. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before snapshot construction:

1. Read candidate AGENTS.md and applicable nested guidance.
2. Verify candidate physical root, branch, H commit/tree/parent, absent upstream,
   index posture, and current F source identity.
3. Verify B source T, inventory, membership, and 36-path scope from independent
   authenticated records.
4. Verify the complete topology-reconciliation root and required hashes.
5. Verify the named source/evidence roots needed for every B byte.
6. Build an exact source-origin map for all 389 B paths.
7. Require each B path to have:
   - exact repo-relative path;
   - logical mode;
   - size;
   - SHA-256;
   - one named authenticated byte source.
8. Require the 36 H→B changed paths to classify exactly:
   - 22 modified;
   - 14 added;
   - no deleted or renamed path.
9. Verify no supplied root has drifted.
10. Verify no repository Git operation marker or lock.

Stop with SNAPSHOT_PROVENANCE_MISMATCH on any mismatch or missing exact byte.

Do not silently reconstruct an unavailable byte from prose, inference, current
F, or a generated patch.

──────────────────────────────────────────────────────────────────────────────
6. COMPLETE B SOURCE CONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Construct retained `source/` with all 389 B files.

Rules:

- Read every byte through no-follow, bounded operations.
- Create every retained source file exclusively at physical mode 0600.
- Do not create symlinks, hardlinks, special files, or aliases.
- Record each file’s repository logical mode separately.
- Do not infer logical mode from retained source-file mode.
- Preserve exact byte size and SHA-256.
- Require one file per governed path and no extra path.
- Require physical separation from the candidate and every supplied source.

Retain a canonical complete B source inventory containing, for each path:

- path;
- classification relative to H;
- repository logical mode;
- physical custody mode;
- size;
- SHA-256;
- source-origin record;
- H blob identity where applicable;
- B byte-source identity;
- current F identity;
- whether B→F later changes the path.

The complete inventory must reproduce:

- 389 paths;
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Create and retain an exact 36-row H→B path manifest, sorted canonically by
repo-relative path.

──────────────────────────────────────────────────────────────────────────────
7. PRIVATE GIT TREE AND SYNTHETIC COMMIT CANDIDATE
──────────────────────────────────────────────────────────────────────────────

Create a private Git repository beneath task-owned temporary state.

The private repository must:

1. contain exact H as its parent state;
2. apply exactly the 22 modified and 14 added B paths;
3. apply repository logical modes from the authenticated B inventory;
4. contain no current F governance changes beyond B;
5. contain no untracked, ignored, cache, or generated state.

Stage all 36 H→B changes in the private repository.

Require:

- path set exactly 36;
- 22 modified;
- 14 added;
- every staged mode, blob size, and SHA-256 equals B;
- no deleted or renamed path;
- clean `git diff --cached --check`;
- no unstaged difference.

Run `git write-tree` and retain the exact B Git tree SHA-1.

Create one private synthetic commit candidate with:

- parent: H commit
  `567bceced5df95ecfe787cc66038d463a854e12c`
- subject:
  `implement Remote Alpha external TLS T2A-P source`
- tree: exact retained B tree

Use deterministic, explicitly recorded synthetic author/committer identities
and timestamps. The synthetic commit is evidence only and is not the future
published commit identity.

Check out or materialize that synthetic commit in a physically separate private
validation root and require a clean Git tree.

Retain:

- B Git tree identity;
- synthetic commit identity;
- parent;
- subject;
- complete private diff classification;
- proof every path outside the 36 equals H;
- proof the synthetic committed source reproduces exact B source T and inventory.

Do not retain a mutable private Git repository as authority. Retain only the
necessary canonical records and any explicitly classified immutable projection.
Remove private Git state at closeout.

──────────────────────────────────────────────────────────────────────────────
8. VALIDATION PLAN RECOVERY
──────────────────────────────────────────────────────────────────────────────

Recover the acceptance-bearing B validation plan from:

- the topology reconciliation;
- governance-freeze opening evidence;
- retained T2A-P implementation and audit evidence;
- repository governing documents;
- exact historical validation records.

Do not invent a reduced test set merely to obtain a pass.

Retain a validation-plan record listing:

- every command;
- exact reason it is acceptance-bearing;
- exact source tree;
- expected identities;
- pinned tools;
- environment;
- expected result;
- originating authority/evidence record.

At minimum, unless retained authority proves a different boundary:

1. Discover all top-level identities in B’s `docs_contract_test.go`.
2. Run the complete exact identity set.
3. Run every package/source test that directly exercises a modified or added
   product or test-support package in the 36-path tranche.
4. Run every script/documentary contract test retained as acceptance-bearing
   for the cumulative T2A-P source.
5. Run formatting or static checks required by retained tranche authority.
6. Run rooted private `git diff --check`.

If the exact acceptance-bearing validation plan cannot be recovered, return
REPAIR10I_T2AP_STRATEGIC_B_SNAPSHOT_BLOCKED. Do not silently substitute a new
plan.

──────────────────────────────────────────────────────────────────────────────
9. PRIVATE CLEAN-TREE VALIDATION
──────────────────────────────────────────────────────────────────────────────

Run validation only against the exact private clean B tree.

Use pinned tool identities and offline environments from retained evidence.
Generated state must be confined beneath task-owned private roots.

At minimum:

- no network;
- no installation;
- private HOME;
- private TMPDIR;
- private GOTMPDIR;
- private GOCACHE;
- private GOMODCACHE;
- GOTOOLCHAIN=local;
- GOPROXY=off;
- GOSUMDB=off;
- GOENV=off;
- GOWORK=off;
- GOFLAGS=-mod=readonly;
- source-root variable bound to the exact private B materialization.

Require:

- every acceptance-bearing command exits as expected;
- zero unexplained failure, error, or skip;
- clean complete raw streams;
- no repository or supplied-root mutation;
- no artifact remains in the retained B source;
- private Git tree remains clean after validation;
- B source T, inventory, Git tree, and all file identities remain unchanged.

Retain exact argv, cwd, environment, exit, stdout/stderr sizes and hashes for
every owning validation command.

Retain failed or superseded validation attempts separately; do not count them
as qualification.

──────────────────────────────────────────────────────────────────────────────
10. SNAPSHOT AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

The strategic B snapshot may claim only:

- exact source bytes;
- exact repository logical modes;
- exact H→B path classifications;
- exact B source T and inventory;
- exact B Git tree candidate;
- observed validation results;
- provenance to retained sources.

It may not claim:

- publication or commit authority;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation;
- that the synthetic commit is the future published commit;
- that B is current repository fact before actual Git publication.

The snapshot is a source-external evidence package pending fresh independent
audit.

──────────────────────────────────────────────────────────────────────────────
11. COMPLETE EVIDENCE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Retain:

- opening identities;
- complete 389-path B source inventory;
- complete 36-path H→B manifest;
- byte-source provenance map;
- logical-mode provenance;
- B source T and inventory records;
- B Git tree and synthetic commit records;
- validation plan;
- exact validation commands and results;
- failed/superseded attempt index;
- cleanup record;
- final report;
- two independently generated canonical manifests.

The two canonical manifests must:

- be byte-identical;
- cover every retained directory;
- cover every retained nonmanifest file exactly once;
- self-exclude only the two manifest files;
- encode path, type, physical mode, link count, size, and SHA-256;
- leave no empty, unexplained, symlink, special, or multiply linked object.

Retain source-inventory logical modes separately from evidence physical modes.

──────────────────────────────────────────────────────────────────────────────
12. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After validation:

1. Remove only task-owned private Git state, materializations, caches, homes,
   temp roots, and fixtures.
2. Make two fresh observations that private transient state is absent.
3. Verify no process or descriptor survivor.
4. Reverify candidate identity and current F working-tree inventory unchanged.
5. Reverify every supplied evidence root unchanged.
6. Reverify retained B source:
   - 389 exact files;
   - exact source T;
   - exact inventory;
   - exact logical modes;
   - exact B Git tree identity.
7. Verify retained capsule closure and both canonical manifests.
8. Verify retained directories are 0700 and files are regular, single-link,
   0600.
9. Retain a complete final evidence inventory and full inline report.

Return SNAPSHOT_PROVENANCE_MISMATCH on opening/closing drift.

──────────────────────────────────────────────────────────────────────────────
13. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop immediately on:

- candidate or supplied-evidence drift;
- unavailable exact B byte;
- unavailable authenticated logical mode;
- any reconstruction from inference rather than exact retained bytes;
- a path set other than 22 modified and 14 added;
- B source T or inventory mismatch;
- private Git tree containing any non-B byte;
- validation-plan ambiguity;
- acceptance-bearing validation failure;
- unexplained test skip or omitted owning command;
- source snapshot aliasing the candidate or supplied root;
- custody-mode/logical-mode conflation;
- extra, missing, empty, or unexplained evidence object;
- candidate, index, or supplied-root mutation;
- product/live-service/network/A6 activity.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return a complete inline report containing:

1. Primary verdict
2. Opening candidate and supplied-root identities
3. Snapshot-root identity
4. Exact H/B/F state map
5. Complete 36-path H→B manifest
6. Complete B source inventory and byte-source provenance
7. Logical-mode versus custody-mode treatment
8. B source T and inventory reproduction
9. B Git tree SHA
10. Synthetic commit identity, parent, subject, and nonauthority
11. Proof every non-36 path equals H
12. Recovered validation plan and governing sources
13. Exact validation commands, environments, and results
14. Failed/superseded attempts
15. Snapshot authority and nonauthority
16. Artifact and sensitive-material findings
17. Cleanup and absence observations
18. Candidate and supplied-root closing equality
19. Complete evidence membership and manifest identities
20. Remaining uncertainty
21. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
SUPPLIED_EVIDENCE_NOT_MUTATED
EXACT_B_SOURCE_CONSTRUCTED
EXACT_36_PATH_SCOPE_RECONSTRUCTED
B_GIT_TREE_COMPUTED
SYNTHETIC_COMMIT_IS_EVIDENCE_ONLY
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

After this producer pass, the next step is a **fresh independent exact-source audit of the strategic B snapshot**. Only an accepted snapshot audit should unlock the real H→B commit gate.

### Source

Codex’s predecessor-topology reconciliation in the preceding message, including its recovered one-commit topology, private exact-B simulation, and B→F audit disposition.

**Confidence:** 0.99 that strategic B snapshot construction is the correct next step; 0.97 that no candidate repository implementation is needed; 0.96 that the existing B→F audit remains usable once exact B is published as its parent.
