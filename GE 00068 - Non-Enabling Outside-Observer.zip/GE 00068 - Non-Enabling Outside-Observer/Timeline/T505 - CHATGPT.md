## Engineering assessment

This is a genuine operating-model ambiguity, and Codex correctly stopped before freezing the wrong contract.

The three fresh observations establish a stable four-field fact pattern:

- the **platform-declared executable** was the pinned Framework launcher;
- `sys.executable` was that same Framework launcher;
- `sys._base_executable` was that same Framework launcher;
- `sys.orig_argv[0]` was the distinct Python.app executable token.

The missing decision is not “which path is the real runtime executable?” That framing caused the blockage. These values serve different roles and should not be collapsed into one terminal interpreter-image field.

### The operating-model decision

Freeze an exact **three-role interpreter observation tuple**:

1. **Declared launcher**  
   Externally owned by platform custody.

2. **Runtime API executable**  
   Owned by the running Python process and represented by both `sys.executable` and `sys._base_executable`. For the current pinned installation, both must equal the declared launcher’s exact path and identity.

3. **Original-argv executable token**  
   Owned by `sys.orig_argv[0]`. For the current pinned installation, it must equal the exact Python.app path and identity observed in all three runs.

There is **no acceptance-bearing “terminal runtime image” role**. The contract must not claim which file the kernel ultimately executed; the retained evidence does not establish that question, and the harness does not need it.

Acceptance is based on the exact tuple and relationships:

- declared launcher matches the frozen launcher identity;
- `sys.executable` and `_base_executable` match the same frozen launcher identity;
- `sys.orig_argv[0]` matches the frozen Python.app token identity;
- `sys.orig_argv[1:]` equals the submitted argv tail exactly;
- `sys.argv` equals the expected application argument sequence after interpreter options are removed;
- cwd, PID, Python flags, source/PYZ identity, and declared environment crosswalk independently.

The environment decision is also ready to freeze:

- the five submitted variables must exist at runtime with identical values;
- the only permitted extra key is optional `__CF_USER_TEXT_ENCODING`;
- when present, its exact current value is `0x1F5:0x0:0x0`;
- its first hexadecimal component must equal UID 501;
- its remaining components must be zero;
- it is platform-injected, nonauthoritative, and has no configuration or verdict effect;
- every other extra key fails closed.

The prior observation work remains useful historical evidence. There is no reason to rerun the observer merely to rediscover the same values. The next task should authenticate those retained records, freeze this explicit decision in a fresh additive successor package, validate it independently, and terminally seal it.

The successor should be an **overlay**, not a replacement for the five-domain documentary package:

- the v2 package remains authoritative for documentary domains, runtime report rows, runtime confirmation names, runtime matrices, and aggregate ownership;
- the new package governs only top-level launch/runtime self-authentication;
- future implementation must consume both exact packages;
- no predecessor artifact becomes source implementation authority.

## Complete replacement Codex prompt

```text
FREEZE AN ADDITIVE SUCCESSOR GOVERNING CONTRACT FOR
TOP-LEVEL LAUNCH/RUNTIME SELF-AUTHENTICATION

EXACT THREE-ROLE INTERPRETER OBSERVATION TUPLE

Objective

Create and terminally close an additive governing documentary package that
resolves the sole operating-model ambiguity retained by the preceding
launch/runtime observation tranche.

The fresh observations established all of these facts consistently:

- the platform submitted the pinned Framework Python launcher;
- runtime `sys.executable` equaled that Framework launcher;
- runtime `sys._base_executable` equaled that Framework launcher;
- runtime `sys.orig_argv[0]` was the distinct Python.app executable token;
- every remaining `sys.orig_argv` token matched the submitted argument tail;
- runtime cwd and PID matched platform custody;
- required Python flags were effective;
- the five submitted environment rows were preserved exactly;
- macOS injected `__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0`.

Freeze the explicit operating-model decision that these are separate typed
facts.

Do not attempt to choose one of them as a single terminal runtime image.

There is no acceptance-bearing `terminal_runtime_image` role.

The exact interpreter observation model has three roles:

1. PLATFORM_DECLARED_LAUNCHER
2. RUNTIME_API_EXECUTABLE
3. ORIG_ARGV_EXECUTABLE_TOKEN

`RUNTIME_API_EXECUTABLE` is represented by both:

- `sys.executable`;
- `sys._base_executable`.

Both must equal the exact declared launcher identity.

`ORIG_ARGV_EXECUTABLE_TOKEN` is represented only by:

- `sys.orig_argv[0]`.

It must equal the exact frozen Python.app token identity.

The contract must not claim which file the operating-system kernel ultimately
executed.

This is a documentary-contract tranche only.

Do not implement future harness production source.
Do not implement future harness qualification source.
Do not implement future harness independent-validator source.
Do not compile or package a future harness.
Do not create a PYZ.
Do not execute `run-full-audit`.
Do not execute implementation production source.
Do not adjudicate the Generation-2 implementation package.
Do not construct the authoritative current schema subject.
Do not modify any supplied root or file.
Do not resume the prior failed documentary root.
Do not copy or patch retired harness source.
Do not perform another historical package-findings reconciliation.

The task may create bounded documentary-package tooling, matrices, and
source-external validators solely to validate and terminally close this
successor package. They are not future harness source.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned documentary build in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_BLOCKED

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PREDECESSOR FIVE-DOMAIN DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifest A:

manifest/documentary-manifest-a-v2.json

- device:
  16777234
- inode:
  181887816
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Expected manifest B:

manifest/documentary-manifest-b-v2.json

- device:
  16777234
- inode:
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Authenticate:

- root identity;
- temporal identity;
- A/B identities;
- A/B byte equality;
- terminal reprojection;
- root row exactly once;
- physical closure;
- one seal transition;
- no-write-after-seal evidence.

Resolve current predecessor roles only through:

contract/current-governing-documentary-role-registry-v2.json

Preserve unchanged:

- five documentary domains;
- 66 runtime report rows;
- 81 runtime confirmation names;
- 15 runtime matrices;
- 595 matrix cases;
- aggregate owner classes;
- aggregate owner/consumer semantics;
- stale 645 rejection;
- package acceptance semantics.

The predecessor package remains current authority for those seams.

The successor package created in this task is additive and governs only:

TOP_LEVEL_LAUNCH_RUNTIME_SELF_AUTHENTICATION

Require complete predecessor-root opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. PRIOR BLOCKED DUAL-VIEW ROOT
──────────────────────────────────────────────────────────────────────────────

PRIOR_BLOCKED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-launch-runtime-dual-view-contract-nyimig3b

Expected root identity:

- device:
  16777234
- inode:
  182117592
- mode:
  0700
- verdict:
  GEN2_CLEAN_AUDIT_HARNESS_LAUNCH_RUNTIME_DUAL_VIEW_CONTRACT_BLOCKED

Open only this exact root.

Do not scan for it.

Authenticate:

closeout/failure-outcome-v1.json

Expected identity:

- device:
  16777234
- inode:
  182137087
- mode:
  0600
- size:
  23747
- SHA-256:
  6c9f2e9c735106e84c7c0cb3b9806054817caab7392797dd829ce952a5ff4642

Authenticate exact retained observation artifacts when present:

tooling/launch-runtime-observer-v1.py

validation/launch-runtime-observation-run-1-v1.json
validation/launch-runtime-observation-run-2-v1.json
validation/launch-runtime-observation-run-3-v1.json
validation/launch-runtime-observation-stability-v1.json

Resolve exact platform-custody record paths only through the failure outcome and
retained observation records.

Do not select them by basename, inode, size, recency, or first match.

Authenticate the governing historical findings:

- three distinct PIDs;
- exact stable submitted launch contract;
- exact stable runtime semantics;
- zero file effects;
- zero child effects;
- `sys.executable` equals the declared launcher;
- `sys._base_executable` equals the declared launcher;
- `sys.orig_argv[0]` equals the Python.app token;
- every remaining original-argv token matches;
- exact cwd equality;
- exact PID equality;
- required flags effective;
- declared environment preserved;
- only `__CF_USER_TEXT_ENCODING` added;
- no successor contract sealed;
- no implementation source created;
- no real audit executed;
- no implementation verdict issued.

Classify the root as:

historical_noncurrent_interpreter_role_ambiguity_evidence

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- not source authority;
- not cleanable in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. RETIRED HARNESS EVIDENCE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_HARNESS_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-attempt2-qw4sqw4r/gen2-clean-source-external-independent-audit-harness-v1.pyz

Expected identity:

- device:
  16777234
- inode:
  181950905
- mode:
  0400
- link count:
  1
- size:
  1442390
- SHA-256:
  19496183b8eb3e7545f9ebda8f966a41839ad67251239d5be2ba801d84cb0174

PREDECESSOR_HARNESS_AUTHORITY_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-authority-v2-output-b1a0mfnn/gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json

Expected identity:

- device:
  16777234
- inode:
  182023548
- mode:
  0400
- link count:
  1
- size:
  81008
- SHA-256:
  782dd6a5d26508bd9bcd7942336d1cab4f1600fde37fabff314d0b8f4291691e

Classify both as:

historical_noncurrent_retired_harness_generation

They may be used only for:

- exact prior CLI evidence;
- exact predecessor identities;
- historical failure classification.

Do not copy, patch, import, execute, translate, or use any member as future
implementation source.

Require exact opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT-AUTHORITY FILES
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

These are fixed identity and closing-equality operands only.

Do not reopen original contaminated package roots.

──────────────────────────────────────────────────────────────────────────────
5. FRESH ADDITIVE SUCCESSOR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Before generating successor artifacts retain:

opening/bootstrap-start.json
opening/additive-successor-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-documentary-authentication-v1.json
opening/prior-blocked-observation-evidence-authentication-v1.json
opening/retired-harness-disposition-v1.json
opening/process-execution-policy-v1.json

Authority is limited to:

- fixed-input authentication;
- historical observation authentication;
- interpreter-role taxonomy;
- exact identity tuple;
- launch/runtime crosswalk;
- environment policy;
- future self-authentication schema;
- documentary matrices;
- independent validation;
- supplied-input closing equality;
- successor package terminal closure.

Nonauthority includes:

- future harness source implementation;
- implementation repair;
- implementation-package adjudication;
- current-subject construction;
- product/runtime/target/repository activity;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
6. INTERPRETER OBSERVATION ROLE TAXONOMY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/interpreter-observation-role-taxonomy-v1.json

Define exactly these three semantic roles.

A. PLATFORM_DECLARED_LAUNCHER

Owner:

external platform custody

Observed field:

submitted argv[0]

Current exact value:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Current exact identity:

- device:
  16777234;
- inode:
  2301718;
- mode:
  0775;
- size:
  119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b.

B. RUNTIME_API_EXECUTABLE

Owner:

runtime-observed process

Observed fields:

- `sys.executable`;
- `sys._base_executable`.

Current exact required value for both:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Current exact identity:

the same identity as PLATFORM_DECLARED_LAUNCHER.

Both fields must be present and exact.

C. ORIG_ARGV_EXECUTABLE_TOKEN

Owner:

runtime-observed process

Observed field:

`sys.orig_argv[0]`

Current exact value:

/Library/Frameworks/Python.framework/Versions/3.13/Resources/Python.app/Contents/MacOS/Python

Current exact identity:

- device:
  16777234;
- inode:
  2301997;
- mode:
  0775;
- size:
  118384;
- SHA-256:
  5904c8166ae6b6569bf5a2e74a595194422c0e0f4580e8268d47ee0b56a02446.

Rules:

- all three roles are acceptance-bearing;
- all three roles are distinct;
- no role may substitute for another;
- no one role is designated terminal;
- no field named `terminal_runtime_image` is current or permitted;
- no claim is made about the kernel’s executable image;
- no equality is required between RUNTIME_API_EXECUTABLE and
  ORIG_ARGV_EXECUTABLE_TOKEN;
- the exact tuple is required;
- unknown role fails closed.

Derived role count:

3.

No independent numeric role-count writer is permitted.

──────────────────────────────────────────────────────────────────────────────
7. EXACT INTERPRETER OBSERVATION TUPLE
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-interpreter-observation-tuple-v1.json

Bind the exact tuple:

{
  platform_declared_launcher,
  runtime_sys_executable,
  runtime_base_executable,
  orig_argv_executable_token
}

Required relationships:

- runtime_sys_executable identity equals platform_declared_launcher identity;
- runtime_base_executable identity equals platform_declared_launcher identity;
- orig_argv_executable_token identity equals the exact frozen Python.app token;
- runtime_sys_executable equals runtime_base_executable;
- orig_argv_executable_token is distinct from the other three observed path
  fields;
- all roles belong to this exact pinned Python 3.13 installation by explicit
  tuple membership, not by prefix or path-normalization inference.

The tuple itself is the authority.

No transitive chain search is performed.

No alternative terminal node is selected.

No basename, path prefix, symlink resolution, generic realpath, or scoring rule
may admit an unregistered identity.

──────────────────────────────────────────────────────────────────────────────
8. THREE-VIEW PROCESS AUTHORITY MODEL
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/top-level-process-three-view-authority-v2.json

A. PLATFORM_DECLARED_LAUNCH

Externally authoritative for:

- process creation;
- declared launcher;
- submitted argv;
- submitted cwd;
- submitted explicit environment;
- stdin;
- shell;
- TTY;
- detachment;
- PID creation;
- start/completion;
- raw streams;
- exit/signal;
- reaping;
- descriptor closure.

B. RUNTIME_OBSERVED_PROCESS

Runtime-owned evidence for:

- `sys.executable`;
- `sys._base_executable`;
- `sys.orig_argv`;
- `sys.argv`;
- Python flags;
- Python version and implementation;
- runtime cwd;
- runtime PID;
- runtime environment;
- source/PYZ self-identity;
- audit-root identity.

C. SELF_AUTHENTICATION_CROSSWALK

Audit-owned adjudication of:

- exact three-role interpreter tuple;
- argv relationship;
- cwd equality;
- PID equality;
- Python flags;
- environment policy;
- source/PYZ identity;
- authority boundaries.

Rules:

- views remain separate;
- no flattened object equality;
- no view silently overwrites another;
- every difference classified;
- capsule may validate but not attest top-level creation;
- external platform custody owns top-level launch authority.

──────────────────────────────────────────────────────────────────────────────
9. ARGV CROSSWALK CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/argv-crosswalk-v2.json

Freeze these relationships.

Platform submitted argv:

[
  PLATFORM_DECLARED_LAUNCHER,
  interpreter options,
  script or PYZ operand,
  application operands
]

Runtime `sys.orig_argv`:

[
  ORIG_ARGV_EXECUTABLE_TOKEN,
  the exact same interpreter options,
  the exact same script or PYZ operand,
  the exact same application operands
]

Runtime `sys.argv`:

[
  the exact script or PYZ operand,
  the exact same application operands
]

Acceptance rules:

- platform argv[0] matches the declared-launcher identity;
- orig_argv[0] matches the frozen Python.app token identity;
- orig_argv[1:] equals platform argv[1:] exactly;
- sys.argv equals the exact application sequence after interpreter options are
  removed;
- required `-I`, `-S`, and `-B` are separate exact tokens;
- missing, combined, duplicated, or substituted flags fail;
- missing, extra, reordered, or changed application operands fail;
- environment variables may not substitute for command-line flags.

──────────────────────────────────────────────────────────────────────────────
10. CWD, PID, FLAGS, AND SOURCE CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/cwd-pid-flags-source-crosswalk-v2.json

CWD:

- external submitted cwd exact;
- runtime cwd exact;
- exact equality required;
- no generic normalization.

PID:

- external platform PID retained;
- runtime PID retained;
- exact equality required;
- capsule does not claim PID creation authority.

Python flags:

Require:

- isolated:
  1;
- no_site:
  1;
- dont_write_bytecode:
  1;
- ignore_environment:
  1;
- safe_path:
  true when supported in the pinned runtime.

Python identity:

- version:
  exact pinned 3.13 runtime version observed by predecessor evidence;
- implementation:
  CPython;
- no alternate major/minor installation.

Source/PYZ:

- exact future PYZ path and identity;
- runtime executing archive identity;
- source/member self-authentication;
- exact source freeze;
- no post-freeze modification.

──────────────────────────────────────────────────────────────────────────────
11. RUNTIME ENVIRONMENT POLICY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/platform-runtime-environment-policy-v2.json

Declared environment must be exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

Rules:

- every declared key exists at runtime;
- every declared value equals exactly;
- no declared key may be overridden;
- runtime environment may contain no extra key except the exact optional
  injection below;
- missing declared key fails;
- changed declared value fails;
- unknown extra key fails;
- generic environment-superset acceptance is forbidden;
- generic environment-subset acceptance is forbidden.

Permitted optional injected key:

__CF_USER_TEXT_ENCODING

Classification:

MACOS_PLATFORM_INJECTED_NONAUTHORITY_ENVIRONMENT

Presence:

optional

When present, current accepted exact value:

0x1F5:0x0:0x0

Required parsed relationship:

- first hexadecimal component:
  0x1F5;
- parsed decimal value:
  501;
- value equals runtime UID;
- second component:
  zero;
- third component:
  zero.

Authority:

none

Configuration effect:

none

Verdict effect when valid:

none

The key may not satisfy or override any declared environment requirement.

No other extra key is accepted.

──────────────────────────────────────────────────────────────────────────────
12. FUTURE PARENT SELF-AUTHENTICATION RECORD V3
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/parent-runtime-self-authentication-record-v3.json

Required future record:

opening/parent-runtime-self-authentication.json

Required fields:

- schema;
- platform_declared_launch;
- runtime_observed_process;
- interpreter_observation_tuple;
- argv_crosswalk;
- environment_crosswalk;
- cwd_crosswalk;
- pid_crosswalk;
- flag_crosswalk;
- source_identity_crosswalk;
- top_level_process_authority;
- self_authentication_rows;
- findings;
- first_blocker;
- timestamp.

Required authority statement:

top_level_process_authority = external_platform_wrapper

Required self-authentication derivation:

- exact required row set;
- every row independently evaluated;
- no generic object equality;
- no generic all-values truthiness;
- no Boolean/int conflation;
- no absence-as-success;
- exact first failed row retained.

The record must not claim:

- kernel executable-image identity;
- process-creation authority;
- equality between runtime API executable and orig-argv executable token.

──────────────────────────────────────────────────────────────────────────────
13. DUAL-VIEW SUCCESSOR MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 120 uniquely named cases.

A. Exact baselines

- exact full tuple;
- optional injected environment present;
- optional injected environment absent.

B. Role taxonomy

- missing declared-launcher role;
- missing runtime-API role;
- missing orig-argv-token role;
- extra terminal-runtime-image role;
- duplicate role;
- unknown role;
- runtime role substituted by orig-argv token;
- orig-argv role substituted by runtime API executable;
- collapsed two-role model;
- flattened equality model.

C. Declared launcher

- exact identity;
- wrong path;
- wrong inode;
- wrong hash;
- wrong mode;
- wrong version;
- symlink substitution;
- missing file;
- special object;
- multiply linked file.

D. Runtime API executable

- both exact;
- sys.executable wrong;
- base executable wrong;
- fields differ;
- one missing;
- both set to Python.app token;
- same path/wrong inode;
- same path/wrong hash.

E. Orig-argv executable token

- exact Python.app token;
- launcher token substituted;
- wrong Python.app path;
- wrong inode;
- wrong hash;
- wrong version;
- missing token;
- ambiguous two-token set.

F. argv relationships

- exact baseline;
- exact executable-token distinction;
- tail mismatch;
- missing -I;
- missing -S;
- missing -B;
- combined flags;
- duplicate flag;
- wrong script/PYZ operand;
- missing operand;
- extra operand;
- reordered application operands;
- sys.argv mismatch.

G. cwd/PID/flags

- exact cwd;
- wrong cwd;
- normalized-only cwd;
- exact PID;
- wrong PID;
- missing platform PID;
- missing runtime PID;
- isolated false;
- no_site false;
- dont_write_bytecode false;
- ignore_environment false;
- safe_path false;
- environment substitute for flag.

H. Environment

- exact declared rows;
- optional injection present and valid;
- optional injection absent;
- missing declared key;
- changed declared value;
- unknown extra key;
- two unknown extras;
- injection wrong exact value;
- injection first component wrong UID;
- injection second component nonzero;
- injection third component nonzero;
- injection overrides declared key;
- empty runtime environment;
- generic superset accepted incorrectly;
- generic subset accepted incorrectly.

I. Authority boundaries

- exact three-view baseline;
- external launch missing;
- runtime observation missing;
- crosswalk missing;
- capsule claims process creation;
- external record used as runtime evidence;
- runtime record used as platform custody;
- basename fallback;
- prefix fallback;
- generic realpath fallback;
- first-match selection;
- score-based selection;
- kernel-image claim invented.

J. Source identity

- exact future PYZ;
- source drift;
- member drift;
- stale freeze;
- missing identity;
- predecessor PYZ substituted.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/interpreter-observation-tuple-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
14. INDEPENDENT SUCCESSOR VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Create a documentary source-external validator that imports neither:

- producer helpers;
- matrix generator;
- expected-result map;
- producer observer;
- producer projector;
- producer normalizer.

It must independently:

1. authenticate all supplied inputs;
2. authenticate the prior blocked-root evidence;
3. reconstruct the three exact semantic roles;
4. reconstruct every exact identity;
5. verify runtime API executable is launcher-valued;
6. verify orig-argv token is Python.app-valued;
7. verify no terminal-runtime-image role exists;
8. verify the exact tuple relationships;
9. verify argv tail equality;
10. verify sys.argv relationship;
11. verify cwd and PID;
12. verify Python flags;
13. verify declared environment;
14. verify optional injected-key policy;
15. reject every unknown extra key;
16. validate all matrix cases independently;
17. validate authority separation;
18. validate future self-authentication schema;
19. validate additive predecessor/successor authority;
20. verify no future harness source exists;
21. require zero errors.

Retain:

validation/independent-interpreter-observation-tuple-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
15. DOCUMENTARY PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain independently authored projections:

analysis/perspective-platform-launch-authority-v2.json
analysis/perspective-runtime-api-executable-v1.json
analysis/perspective-orig-argv-executable-token-v1.json
analysis/perspective-environment-injection-v2.json
analysis/perspective-future-self-authentication-v2.json
analysis/perspective-additive-successor-boundary-v1.json

Reconcile them in:

analysis/interpreter-observation-tuple-perspective-reconciliation-v1.json

Require:

- no disagreement;
- no open operating-model decision;
- no hidden implementation decision;
- no package-verdict change;
- no documentary-domain change;
- no runtime-registry change;
- exact predecessor/successor authority split;
- exact successor-package identity binding.

──────────────────────────────────────────────────────────────────────────────
16. ADDITIVE SUCCESSOR ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-launch-runtime-successor-role-registry-v1.json

The registry must:

- identify the predecessor five-domain package by exact root and terminal
  identities;
- state that predecessor v2 remains current for all preexisting roles;
- identify this successor package as current only for:
  TOP_LEVEL_LAUNCH_RUNTIME_SELF_AUTHENTICATION;
- contain exactly one current successor artifact per new role;
- contain no duplicate current role;
- contain no ambiguous role;
- contain no future source implementation role;
- contain no harness package role.

Required successor roles include:

- role taxonomy;
- current observation tuple;
- three-view authority model;
- argv crosswalk;
- cwd/PID/flags/source crosswalk;
- environment policy;
- self-authentication record v3;
- matrix;
- independent validator;
- six perspectives;
- perspective reconciliation;
- package status;
- explicit confirmations.

──────────────────────────────────────────────────────────────────────────────
17. PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/interpreter-observation-tuple-contract-status-v1.json

Required status:

gen2-clean-audit-harness-interpreter-observation-tuple-contract-frozen-pending-new-clean-implementation-generation

Required facts:

- predecessor documentary package authenticated:
  true;
- predecessor package remains current:
  true;
- successor is additive:
  true;
- successor authority seam:
  TOP_LEVEL_LAUNCH_RUNTIME_SELF_AUTHENTICATION;
- five documentary domains unchanged:
  true;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrix rows:
  15;
- runtime matrix cases:
  595;
- interpreter role count:
  3;
- terminal runtime-image role:
  absent;
- declared launcher identity frozen:
  true;
- runtime API executable identity frozen:
  true;
- orig-argv executable token identity frozen:
  true;
- kernel executable image claimed:
  false;
- environment-injection policy frozen:
  true;
- optional CF_USER_TEXT_ENCODING:
  true;
- generic environment-superset acceptance:
  false;
- basename/prefix/realpath fallback:
  false;
- future self-authentication schema frozen:
  true;
- retired harness generation current:
  false;
- future implementation source present:
  false;
- future implementation authority:
  false;
- real audit executed in this task:
  false;
- implementation verdict issued:
  false;
- next treatment:
  NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION.

──────────────────────────────────────────────────────────────────────────────
18. SUPPLIED-INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- predecessor documentary package;
- prior blocked root;
- predecessor harness PYZ;
- predecessor authority v2;
- current content bundle;
- current content authority.

Require exact opening/closing equality.

Do not mutate or clean supplied inputs.

──────────────────────────────────────────────────────────────────────────────
19. TERMINAL SUCCESSOR-PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use explicit closure paths:

manifest/interpreter-observation-temporal-inventory-v1.json
manifest/interpreter-observation-manifest-a-v1.json
manifest/interpreter-observation-manifest-b-v1.json

Before projection:

- finalize all nonclosure outputs;
- create only used directories;
- ensure closeout/ and manifest/ already exist;
- retain no empty descendant;
- exclusively reserve all three closure paths;
- retain descriptors;
- freeze directory set.

Then:

1. independently generate temporal bytes twice;
2. require equality;
3. write through retained descriptor;
4. fsync and reopen no-follow;
5. independently reproject temporal cut;
6. independently generate A and B from the identical frozen namespace;
7. require A/B byte equality;
8. write through retained descriptors;
9. fsync files and directories;
10. reopen no-follow;
11. verify descriptor/path inode equality;
12. independently reproject final root;
13. require root row exactly once;
14. require no empty descendant;
15. require no symlink or special object;
16. require no multiply linked regular file;
17. require directory/file modes 0700/0600;
18. require no cache or bytecode;
19. transition seal once;
20. emit guarded verdict and marker;
21. exit nonreturningly;
22. perform no postseal filesystem or tool operation.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process records and streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- supplied-input equality;
- terminal posture;
- same-root retry false.

Do not create success manifests on failure.

Return provenance mismatch for:

- fixed-input mismatch;
- supplied-input mutation;
- prohibited source use;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- terminal-closure failure;
- postseal activity.

──────────────────────────────────────────────────────────────────────────────
21. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

only when:

- all supplied inputs authenticate;
- predecessor package terminal closure authenticates;
- prior observation evidence authenticates;
- three-role taxonomy freezes;
- exact tuple freezes;
- three-view authority freezes;
- argv crosswalk freezes;
- cwd/PID/flag/source crosswalk freezes;
- environment policy freezes;
- future self-authentication record v3 freezes;
- matrix passes;
- independent validator passes;
- six perspectives reconcile;
- additive successor registry closes;
- package status closes;
- supplied inputs close equal;
- successor package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_BLOCKED

when:

- exact observation evidence conflicts;
- one of the three roles remains ambiguous;
- environment semantics remain ambiguous;
- an operating-model decision remains open;
- independent validation fails without provenance failure.

Return:

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_PROVENANCE_MISMATCH

for provenance failures in Section 20.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor-root identity
3. Predecessor documentary-package identity
4. Prior blocked-root identity and disposition
5. Predecessor PYZ identity
6. Predecessor authority-v2 identity
7. Current content-bundle identity
8. Current content-authority identity
9. Documentary authority and nonauthority
10. Prior observation-record authentication
11. Interpreter role taxonomy
12. Derived interpreter-role count
13. Declared-launcher identity
14. Runtime sys.executable identity
15. Runtime base-executable identity
16. Orig-argv executable-token identity
17. Exact interpreter observation tuple
18. Confirmation no terminal-runtime-image role exists
19. Confirmation no kernel-image claim is made
20. Three-view process-authority model
21. argv crosswalk
22. sys.argv crosswalk
23. cwd crosswalk
24. PID crosswalk
25. Python-flag crosswalk
26. Source/PYZ identity crosswalk
27. Declared environment
28. Runtime environment
29. Injected-environment policy
30. CF_USER_TEXT_ENCODING policy
31. Future parent self-authentication record v3
32. Interpreter-observation tuple matrix
33. Independent successor validator
34. Platform-launch perspective
35. Runtime-API-executable perspective
36. Orig-argv-token perspective
37. Environment-injection perspective
38. Future-self-authentication perspective
39. Additive-successor-boundary perspective
40. Perspective reconciliation
41. Additive successor role registry
42. Package status
43. Confirmation no future source was created
44. Confirmation no real audit was executed
45. Confirmation no implementation verdict was issued
46. Supplied-input closing equality
47. Failure-closeout capability and use
48. Temporal-inventory identity
49. Manifest A identity
50. Manifest B identity
51. Terminal reprojection
52. Terminal topology and modes
53. No-write-after-closure
54. Remaining uncertainty and nonclaims
55. Explicit documentary confirmations

Required confirmations:

PREDECESSOR_DOCUMENTARY_PACKAGE_IDENTITY_MATCHED
PREDECESSOR_DOCUMENTARY_PACKAGE_TERMINAL_CLOSURE_AUTHENTICATED
PRIOR_BLOCKED_OBSERVATION_ROOT_AUTHENTICATED
THREE_OBSERVATION_RESULTS_AUTHENTICATED
OBSERVATION_STABILITY_AUTHENTICATED
PREDECESSOR_PYZ_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V2_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
NO_RETIRED_SOURCE_USED_AS_IMPLEMENTATION_SOURCE
INTERPRETER_ROLE_TAXONOMY_FROZEN
INTERPRETER_ROLE_COUNT_THREE_DERIVED
PLATFORM_DECLARED_LAUNCHER_ROLE_FROZEN
RUNTIME_API_EXECUTABLE_ROLE_FROZEN
ORIG_ARGV_EXECUTABLE_TOKEN_ROLE_FROZEN
TERMINAL_RUNTIME_IMAGE_ROLE_ABSENT
KERNEL_EXECUTABLE_IMAGE_NOT_CLAIMED
DECLARED_LAUNCHER_IDENTITY_AUTHENTICATED
RUNTIME_SYS_EXECUTABLE_IDENTITY_AUTHENTICATED
RUNTIME_BASE_EXECUTABLE_IDENTITY_AUTHENTICATED
ORIG_ARGV_EXECUTABLE_TOKEN_IDENTITY_AUTHENTICATED
EXACT_INTERPRETER_OBSERVATION_TUPLE_FROZEN
NO_ROLE_SUBSTITUTION_PERMITTED
NO_BASENAME_PREFIX_REALPATH_OR_SCORE_FALLBACK
THREE_VIEW_PROCESS_AUTHORITY_FROZEN
TOP_LEVEL_PROCESS_AUTHORITY_EXTERNAL
ARGV_EXECUTABLE_TOKEN_DISTINCTION_FROZEN
ARGV_TAIL_EXACT
SYS_ARGV_APPLICATION_SEQUENCE_EXACT
CWD_CROSSWALK_FROZEN
PID_CROSSWALK_FROZEN
PYTHON_FLAG_CROSSWALK_FROZEN
SOURCE_IDENTITY_CROSSWALK_FROZEN
DECLARED_ENVIRONMENT_EXACT
RUNTIME_DECLARED_KEYS_PRESERVED
OPTIONAL_PLATFORM_INJECTION_POLICY_FROZEN
CF_USER_TEXT_ENCODING_EXACT_VALUE_FROZEN
CF_USER_TEXT_ENCODING_UID_RELATION_FROZEN
UNKNOWN_RUNTIME_ENVIRONMENT_KEY_REJECTED
FUTURE_PARENT_SELF_AUTHENTICATION_SCHEMA_V3_FROZEN
INTERPRETER_OBSERVATION_TUPLE_MATRIX_PASSED
INDEPENDENT_SUCCESSOR_VALIDATOR_PASSED
SIX_DOCUMENTARY_PERSPECTIVES_RECONCILED
NO_OPEN_OPERATING_MODEL_DECISION
PREDECESSOR_FIVE_DOMAIN_AUTHORITY_PRESERVED
FIVE_DOCUMENTARY_DOMAINS_UNCHANGED
RUNTIME_REPORT_REGISTRY_UNCHANGED
RUNTIME_CONFIRMATION_REGISTRY_UNCHANGED
RUNTIME_MATRIX_REGISTRY_UNCHANGED
PACKAGE_ACCEPTANCE_SEMANTICS_UNCHANGED
ADDITIVE_SUCCESSOR_ROLE_REGISTRY_COMPLETE
FUTURE_IMPLEMENTATION_SOURCE_NOT_CREATED
FUTURE_IMPLEMENTATION_AUTHORITY_FALSE
NEXT_TREATMENT_NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
SUCCESSOR_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_MANIFEST_A_CREATED
SUCCESSOR_MANIFEST_B_CREATED
SUCCESSOR_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_AUDIT_HARNESS_INTERPRETER_OBSERVATION_TUPLE_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

the next tranche is a new clean harness implementation generation governed by:

- the predecessor five-domain documentary package;
- this additive interpreter-observation-tuple successor package;
- the current content snapshot bundle;
- the current content authority JSON.

Do not classify that future generation as Attempt 4 of the retired generation.

Do not copy or patch retired harness source.

Do not combine contract freezing with source implementation.
```

### Sources

Codex’s report establishes that the three observations were stable and that `sys.executable` and `_base_executable` remained launcher-valued while `sys.orig_argv[0]` was consistently Python.app-valued. It also establishes the exact identities and environment injection.

The report further establishes that the task stopped only because the governing contract had not decided how those separate facts should be typed; no future harness source, package authority, or implementation verdict was created.

**Confidence:** 0.999 that no Generation-2 implementation-package defect was established; 0.999 that the missing decision is the interpreter-role taxonomy rather than another measurement; 0.995 that an exact three-role tuple avoids both false rejection and unsafe path equivalence; 0.98 that the optional exact `__CF_USER_TEXT_ENCODING` policy is appropriately bounded for the current platform and user identity.
