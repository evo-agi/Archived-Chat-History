A5C is a clean successor implementation result. It removed exactly the duration-equality false distinction while preserving the ten historical socket-fixture differences, the observability allowlist, trace/request/timestamp topology, A5P2 PTY custody, active schemas, and repository bytes.

The next gate is the fresh A6 policy-evidence refresh, but it needs one explicit construction guard that was not relevant when A6 was first planned:

**Historical HEAD and Repair 9 still contain the pre-A5T4 test-private process-substitution harness.** Running those exact sources under A5P2/A5C can recreate the `/dev/fd/N` cascade that A5T4 corrected. A6 must not silently grant `/dev/fd`, compare distorted historical runs, or pretend that an unrecorded source modification is exact historical source.

The refresh should therefore proceed only if A5C’s existing base/effective source and mutation-provenance contracts can honestly represent an exact, validation-only historical harness overlay. Otherwise, it must stop for a bounded successor contract amendment before executing the historical controls.

That overlay is not a product migration. It is proof scaffolding and must remain labeled accordingly; the MVP freeze expressly prohibits proof-harness behavior from becoming architecture or authority by inertia. 

## Codex prompt: Repair 10I-A6 policy-evidence refresh

```text
Permission is workspace-write for one new source-external evidence child only.

Objective

Perform, close out, and seal the fresh Repair 10I-A6 policy-evidence refresh
against:

- the exact final Repair 10I repository source;
- the sealed Repair 10I-A5C successor;
- independently materialized final, fresh-final, intentional-mutant,
  historical-HEAD, and historical-Repair-9 controls.

The refresh has two purposes:

1. Re-establish the mandatory fresh semantic matrix:
   - final ↔ fresh;
   - final ↔ intentional mutant;
   - mutant ↔ fresh;
   - HEAD ↔ final;
   - Repair 9 ↔ final.

2. Produce the exact source-grounded transition matrices, hazard ledger,
   package no-test evidence, and structural historical-direction policy needed
   to freeze the next historical-comparator implementation.

This turn is validation, evidence refresh, and policy reconnaissance only.

Do not modify repository source.
Do not modify sealed A5C.
Do not implement the historical-comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole evidence writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5P2 successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p2-successor-closure-ab646e5a0e66

Sealed A5T4 repository-validation lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5C successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A5FD historical harness analysis

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5fd-devfd-recon-ab646e5a0e66

Old failed and unsealed A6 evidence refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required new A6 child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5c-8de797304ea9

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the repository delta from sealed A5 to be exactly these three existing
test files:

1. remote_alpha_operator_test.go
2. es/runtimehelper/supervisor_test.go
3. remote_alpha_prepare_external_tls_status_test.go

Recover and retain each exact current mode, size, and SHA-256 from the sealed
A5T4 inventory.

Require:

- zero additions;
- zero deletions;
- zero renames;
- zero mode changes;
- every other 386 source tuple byte- and mode-identical to sealed A5.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Reverify completely:

- production-wrapper unchanged identity;
- exact three-file delta;
- derivative transformation and inversion proof;
- all 64 affected-identity results;
- full-suite raw and semantic records;
- producer and peer qualifications;
- historical matrices;
- cleanup and two absence epochs.

Bind the A5T4 full-suite facts:

- test terminals:
  2753 pass / 137 fail / 8 skip
- package terminals:
  14 pass / 11 fail / 23 skip
- raw SHA-256:
  0a97bd3a3ca7e162feac63795da125dd05bae7d13987faa61e3712479df83d25
- A5P2 producer/peer semantic SHA-256:
  f692595d3611e13ef90babafbdb8726407190155b02c0ae60d3c9a15152f57f8
- zero unknown diagnostics;
- zero socket-fixture EINVAL diagnostics;
- zero `/dev/fd/N: Operation not permitted` diagnostics;
- producer and peer qualifications:
  qualified.

Require exact sealed A5C:

- manifest SHA-256:
  05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489
- manifest size:
  31421
- payloads:
  216
- directories:
  71
- source T:
  2c2d0b36f52d5949d023a36400f0e0748149875a
- source inventory:
  810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9
- source members:
  12

Recover the exact A5C A/B binary sizes and SHA-256 identities from the sealed
manifest and final report.

Require:

- each A/B binary pair byte-identical;
- each copy inode-distinct;
- complete post-seal verification;
- all seven A5C tests;
- A5P2 nonregression;
- no schema-ID changes;
- active observability rule:
  observability-inbound-request-complete-v2.

Require exact sealed A5FD:

- manifest SHA-256:
  f4bfa2b8479a8679d4a2af4173f2bc9d76bc6f4085cdda3bb4c60d06c0b9b768
- size:
  4951
- payloads:
  37
- directories:
  6

Require the old failed A6 child and all other sealed/unsealed lineage to remain
present and byte-exact.

Require the new A6 target to be absent.

Stop on any mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create the A6 child exclusively under umask 077.

Use exactly:

opening/
tool/
sources/
commands/
controls/
validation/
comparisons/
analysis/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, mode 0600 or 0700 as intended.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy the sealed A5C A and B binaries independently into private tool roots.

Require:

- origin-to-copy byte equality;
- A/B byte equality;
- every copied binary inode distinct;
- link count one;
- expected modes;
- no shared writable tool state.

No repository file may be edited.

## 3. A5C successor hard gate

Before any source-control execution:

1. Verify all 12 A5C source members.
2. Verify the exact three-file A5P2→A5C delta.
3. Verify all A5C binary identities.
4. Reopen:
   - all seven A5C grammar tests;
   - retained-A5 vulnerable and postrepair causal;
   - A5T4 raw re-extraction compatibility;
   - historical HEAD re-extraction;
   - Repair-9 compatibility causal;
   - intentional-mutant compatibility causal;
   - A5P2 PTY and policy nonregression;
   - cleanup and absence records.
5. Require:
   - active rule ID is v2;
   - no active extraction emits v1;
   - trace/request/timestamp topology remains material;
   - duration is diagnostic-position keyed;
   - no schema change;
   - no PTY/policy regression.

Stop on mismatch:

REPAIR10I_A6_SUCCESSOR_INPUT_MISMATCH

## 4. Historical-control construction gate

This gate is mandatory before running HEAD or Repair 9.

### 4.1 Exact historical identities

Historical HEAD:

- commit:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree/source T:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- expected source inventory:
  291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a
- expected members:
  375

Repair 9:

- source T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- source inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
- expected members:
  382
- retained ZIP SHA-256, when used:
  4363b63a758c02a43945ef8b4f092df951967c295e6b428d20c7d80a00cfab6b

Do not approximate a missing historical source.

### 4.2 Historical process-substitution inspection

In each historical source, inspect the exact test-private derivative
construction in:

remote_alpha_prepare_external_tls_status_test.go

Determine whether it retains the pre-A5T4 process-substitution form that renders
dynamic `/dev/fd/N`.

Retain:

- exact source block;
- path and line;
- before hash;
- whether its owning tests are active;
- whether exact execution under A5C/A5P2 would require forbidden `/dev/fd`
  pathname reopening.

No generic `/dev/fd` grant is authorized.

### 4.3 Existing-schema capability inspection

Inspect the exact sealed A5C active source-class and mutation-provenance
contracts.

Determine whether `historical-head` and `historical-repair9` controls may
honestly bind:

- base T/inventory;
- effective T/inventory;
- one validation-only, exact-path mutation provenance record;
- immutable materialization;
- external qualification;
- semantic comparison.

The validation-only overlay, when required, is exactly the A5T4 derivative
transformation:

- one existing test file;
- unique exact match;
- line-count preserving;
- production wrapper unchanged;
- loop body unchanged;
- fully reversible;
- shell-scrub equivalence already established by sealed A5T4;
- no test declaration added or removed;
- no product source changed.

Construct a fresh source-specific overlay provenance payload before execution.

Require exact before/after path, mode, size, SHA-256, base/effective T, and
base/effective inventory.

The overlay must be explicitly classified as:

validation-harness-overlay

It is not historical product source and not a product repair.

If A5C cannot represent and independently qualify this base/effective
historical control without source or schema changes, stop before launching any
historical full suite:

REPAIR10I_A6_HISTORICAL_CONTROL_CONSTRUCTION_REQUIRED

Do not silently patch historical controls.

Do not reuse an intentional-mutant class for this overlay.

### 4.4 Historical path and PTY preflight

For HEAD and Repair 9 independently:

- use a short exclusive `/private/tmp` execution root;
- compute every prospective socket and broker path;
- require each at most 100 bytes;
- derive exact source-specific PTY roles and counts;
- do not reuse the final-source request inventory blindly;
- omit PTY capability from commands that do not require it;
- require no undeclared PTY request.

## 5. Five fresh source controls

Materialize five physically disjoint controls:

1. Final
   - source class:
     pristine-final
   - T:
     8de797304ea944b6a155924e0d1e9e8bbe79534e
   - inventory:
     64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

2. Fresh independent final
   - source class:
     pristine-final
   - same T and inventory as final
   - distinct source, Git, cache, runtime, command, evidence, PTY, socket, and
     process state

Do not invent or use a `fresh-pristine-final` source class.

3. Intentional mutant
   - source class:
     intentional-mutant
   - base source:
     exact final
   - recover the exact active A5C intentional-mutant contract
   - sole changed path:
     es/externaltls/internal/statusobservation/remoteobserver/observe_test.go
   - mutation must target the exact active
     TestRepair10IStructuralPrivacyProjectionCausalControlsV1 anchor
   - exact mutation provenance must be written and frozen before execution
   - same logical mode
   - exactly one changed path
   - exact declared diagnostic and lifecycle delta
   - no other source or semantic change

Stop if the active mutant contract is ambiguous.

4. Historical HEAD
   - source class:
     historical-head
   - base identity exactly as above
   - effective identity includes only the explicitly qualified historical
     validation-harness overlay when required

5. Historical Repair 9
   - source class:
     historical-repair9
   - base identity exactly as above
   - effective identity includes only the explicitly qualified historical
     validation-harness overlay when required

Every control must use:

- no-hardlink source materialization;
- private Git administration/object store where required;
- private HOME/XDG;
- private GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- private runtime and command roots;
- private PTY/broker state;
- exact source-specific path-budget and PTY-policy preflight.

No writable state may be shared.

## 6. Exact command and qualification

For each control run literal:

go test -json -count=1 -p=1 -parallel=1 ./...

Expected process exit membership:

{0,1}

Exit alone never qualifies a control.

Run final with A5C side A and fresh final with side B.

Distribute the other source controls across sides, but every control must receive
opposite-side external re-extraction and qualification.

Require for every control:

- exact source-class validation;
- base/effective T and inventory validation;
- exact mutation or overlay provenance where applicable;
- complete raw stdout/stderr through EOF;
- exactly one Wait;
- terminal reconciliation complete;
- resource disposition complete;
- no forced cleanup;
- no survivor;
- no malformed or truncated JSONL;
- no duplicate or missing terminal;
- semantic integrity pass;
- zero unknown diagnostics;
- producer and peer canonical semantics byte-identical;
- producer and peer qualifications both `qualified`;
- logical suite fingerprint bound;
- PTY-policy fingerprint bound;
- all declared PTY requests consumed exactly;
- no undeclared PTY request;
- direct `/dev/ptmx` denied;
- arbitrary `/dev/fd/*` denied;
- unrelated terminals inaccessible;
- real PTY EOF/EIO evidence reconciled;
- every socket path at most 100 bytes;
- two cleanup epochs;
- verified-empty next-command barrier.

## 7. Final and fresh acceptance gate

Require final and fresh to have:

- equal lifecycle;
- equal diagnostics;
- equal canonical semantics;
- equal logical suite fingerprints;
- both independently qualified;
- zero unknowns;
- accepted equality true;
- outcome:
  qualified-equal
- comparator exit:
  0.

Require exact terminal universe:

- tests:
  2753 pass / 137 fail / 8 skip
- packages:
  14 pass / 11 fail / 23 skip

Require exact test/package terminal identity-set equality, not counts alone.

Raw bytes may differ.

Any terminal, lifecycle, diagnostic, or unknown difference blocks A6.

## 8. Intentional-mutant gates

Require final ↔ mutant:

- both controls qualified;
- zero unknowns;
- exact declared diagnostic tuple;
- exact declared test and package terminal delta;
- no other lifecycle or diagnostic difference;
- accepted equality false;
- outcome:
  qualified-different
- comparator exit:
  2.

Require mutant ↔ fresh:

- exact inverse declared delta;
- both qualified;
- zero unknowns;
- no additional difference;
- outcome:
  qualified-different
- exit:
  2.

Require:

- full mutant provenance retained before execution;
- exact sole changed path;
- no producer-caption substitution;
- external requalification of mutant source and semantics.

## 9. Historical comparison posture

Run the current sealed A5C comparator for:

- HEAD ↔ final;
- Repair 9 ↔ final.

Retain its factual outputs and exit.

Do not use the inherited historical-policy acceptance result as A6 readiness
authority.

The current historical policy is under evaluation.

A historical comparator exit of 0 or 2 does not, by itself, freeze the next
policy.

A blocked current historical policy does not invalidate qualified raw controls.

## 10. Deterministic structural transition analysis

From the independently qualified semantic envelopes, compute separately:

- HEAD → final;
- Repair 9 → final.

Use a retained, versioned, source-external analyzer written inside the A6
evidence child.

The analyzer is evidence tooling only and does not become successor authority.

### 10.1 Exact identity model

A terminal identity contains:

- package;
- test/subtest, empty for package terminal;
- occurrence;
- terminal action.

Use raw UTF-8 byte ordering.

Retain canonical arrays with:

- count;
- byte length;
- SHA-256;
- complete embedded identity list.

### 10.2 Test/subtest transition matrix

Compute every class:

- absent→pass
- absent→fail
- absent→skip
- pass→pass
- pass→fail
- pass→skip
- pass→absent
- fail→pass
- fail→fail
- fail→skip
- fail→absent
- skip→pass
- skip→fail
- skip→skip
- skip→absent

### 10.3 Package transition matrix

Compute the same complete matrix for packages.

Separately classify:

- package no-test skip;
- package failure with failing tests;
- package failure abort;
- setup/build failure where the raw stream supports that classification;
- unclassified package failure.

### 10.4 Diagnostic and integrity hazards

Compute exact baseline/final deltas for:

- panic identities;
- race identities;
- warning identities;
- fatal-runtime identities;
- unknown diagnostics;
- malformed/truncated stream;
- duplicate start/run/terminal;
- missing start/run/terminal;
- terminal without start;
- impossible association;
- mapping errors;
- package failure aborts;
- final exit inconsistency.

Retain exact identity arrays and hashes.

### 10.5 Final-only passing diagnostics

For every absent→pass test or package:

- retain its package/test identity;
- prove final terminal pass;
- require zero unknown diagnostics;
- require no hazardous diagnostic class;
- bind all diagnostics to the admitted identity;
- preserve exact recognized grammar/rule identities.

Do not require a finite name allowlist.

Do not let new passes mask any blocking transition.

## 11. Candidate structural historical policy

Adjudicate this structural relation separately for HEAD and Repair 9.

### Test/subtest transitions

Admit:

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

Block:

- absent→fail
- absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent

### Package transitions

Admit:

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

Admit absent→skip only when all of the following hold:

- package is absent from baseline;
- final has exactly one package skip;
- exact raw `[no test files]` evidence exists;
- zero test run/terminal identities exist for the package;
- zero unknown diagnostics;
- zero package abort;
- terminal reconciliation and qualification are clean.

Block:

- absent→fail
- unclassified absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent
- any package abort or setup/build uncertainty.

### Hazard rules

Block independently on any:

- new panic;
- new race;
- new warning;
- new fatal runtime;
- new unknown diagnostic;
- malformed/truncated stream;
- missing/duplicate/impossible lifecycle state;
- new package abort;
- terminal disappearance;
- final exit inconsistency unexplained by admitted fail→pass improvements.

Aggregate exit-code equality is not required.

A baseline exit 1 may become final exit 0 through clean admitted improvements.

### Diagnostic rules

- Diagnostics for baseline identities must retain every material semantic
  distinction unless a separately governed typed canonicalization applies.
- Diagnostics for final-only passing identities are admitted only when fully
  recognized, zero-unknown, nonhazardous, and bound to those passing
  identities.
- No finite compiled allowlist of final-only passing test names.
- No policy generated from one run’s observed pass set.
- Exact observed arrays remain evidence, not authority.

## 12. Required A6 policy decision

If both historical directions satisfy the candidate structural relation with:

- zero blocked transition;
- zero hazard;
- zero unexplained disappearance;
- zero unknown;
- complete qualified evidence;

freeze the exact future successor contract:

- spec schema:
  execution-substrate.repair10i.semantic-comparison-spec.v4
- result schema:
  execution-substrate.repair10i.semantic-comparison-result.v4
- historical policy:
  historical-directional-no-regression-v2

The final report must freeze:

- exact fields;
- exact canonical encodings;
- transition arrays;
- package no-test evidence;
- hazard arrays;
- reason codes;
- exit policy;
- v3 historical-policy deprecation behavior;
- exact future touched-file set;
- complete causal-test matrix.

Do not implement v4 during this turn.

If either direction contains a blocking or unresolved transition, stop and
report it without freezing the policy.

Do not introduce identity exceptions to obtain success.

## 13. Required future v4 result content

When the policy can be frozen, require the future result to retain all current
factual fields and add an embedded `HistoricalAnalysis` containing:

- baseline exit code;
- final exit code;
- accepted historical-no-regression boolean;
- test terminal transition sets;
- package terminal transition sets;
- final-only passing tests;
- final-only passing packages;
- admitted package-no-test records;
- blocked transitions;
- improvements;
- inherited failures;
- missing baseline identities;
- package-failure-abort deltas;
- hazardous diagnostic-class deltas;
- unknown and integrity deltas.

Every transition set contains:

- from action;
- to action;
- count;
- complete identities;
- canonical byte length;
- canonical SHA-256.

Do not authorize external array references as the sole acceptance record.

## 14. Required future reason-code and exit freeze

Recover all existing A5C reason codes.

Add only a source-grounded finite historical set.

At minimum distinguish:

- historical-no-regression-satisfied
- historical-no-regression-not-satisfied
- final-only-pass-observed
- final-only-package-pass-observed
- package-no-tests-admitted
- inherited-failure-observed
- baseline-fail-became-pass
- baseline-skip-became-pass
- final-only-fail
- final-only-test-skip
- final-only-package-fail
- final-only-package-skip-unclassified
- final-only-package-abort
- baseline-pass-regressed
- baseline-terminal-disappeared
- baseline-fail-became-skip
- baseline-skip-became-fail
- new-panic
- new-race
- new-warning
- new-fatal-runtime
- malformed-stream
- truncated-stream
- unknown-diagnostic
- lifecycle-integrity-failed.

Exit policy to freeze:

- 0:
  only qualified-equal with accepted equality true;
- 2:
  both controls qualified, zero unknowns, and either:
  - exact intentional-mutant difference; or
  - historical-directional-no-regression-v2 satisfied;
- 1:
  every qualification, custody, unknown, integrity, policy, or late fault.

Do not derive exit 2 from a joined mismatch sentinel.

## 15. Policy causal matrix to freeze

The final report must freeze future tests for:

1. Hundreds of arbitrary absent→pass tests accepted without a name allowlist.
2. Arbitrary final-only passing subtests accepted structurally.
3. Final-only test fail blocks.
4. Final-only test skip blocks.
5. Final-only package fail blocks.
6. Final-only package abort blocks.
7. Pass→fail blocks.
8. Pass→skip blocks.
9. Pass→absent blocks.
10. Fail→pass admitted and reported.
11. Skip→pass admitted and reported.
12. Fail→skip blocks.
13. Skip→fail blocks.
14. Fail→absent blocks.
15. Skip→absent blocks.
16. Exact package no-test skip admitted only with bound raw proof.
17. No-test marker/package/test-count/diagnostic mutation blocks.
18. Any number of new passes cannot mask one blocking transition.
19. New panic, race, warning, fatal runtime, unknown, malformed, truncated,
    missing, duplicate, impossible, or package-abort state blocks.
20. HEAD and Repair 9 are independently evaluated.
21. Reversing historical direction fails validation.
22. V3 historical-policy specs parse only as historical/nonqualifying.
23. Final/fresh and mutant policies remain unchanged.
24. Exact transition arrays, lengths, and hashes are deterministic.
25. Aggregate exit improvement does not block a clean fail→pass transition.
26. Renaming a baseline test is pass→absent plus absent→pass and therefore
    blocks.
27. Deleting a failing baseline test is fail→absent and blocks.

## 16. Validation-construction consistency

Require all five controls to use:

- the same pinned Go 1.26.5 toolchain;
- the same logical full-suite command;
- equivalent finite execution policy;
- source-specific PTY declarations only where required;
- short path-budgeted control roots;
- offline private caches;
- no network or live service;
- no shared writable state.

Differences caused solely by declared historical harness overlays must be
reported explicitly and excluded from product-source claims.

The overlay must not add/remove test declarations or change production bytes.

## 17. Security and authority controls

Require:

- no repository mutation;
- no generic `/dev/fd` grant;
- no broad `/dev` or terminal grant;
- no public/product schema change;
- no product execution authority change;
- no `.out` traversal or write;
- no live PackageFloor or fixed runtime slot access;
- no credential, keychain, TLS, SPIFFE, Vault, private endpoint, or unrelated
  user-data exposure;
- no raw PTY payload retained;
- historical overlays classified as validation scaffolding only;
- evidence remains non-authoritative.

## 18. Evidence requirements

Retain:

- complete opening and lineage verification;
- A5C tool hard gate and binary identities;
- exact five source controls;
- historical base/effective identities and overlay provenance;
- exact mutant provenance before execution;
- source-specific path and PTY policies;
- all suite specs;
- command intents, argv, cwd, environments;
- rendered profiles and effective policies;
- raw streams through EOF;
- command/terminal/resource records;
- PTY journals;
- producer and peer semantic envelopes;
- producer and peer qualifications;
- all five current comparator results;
- structural transition analyzer source and tests;
- complete matrices, hazard arrays, and hashes;
- proposed v4 contract and causal matrix when supported;
- failed and superseded attempts;
- cleanup and two absence epochs;
- final policy report;
- exact path/mode/size/hash inventory.

No raw terminal payload.
No sensitive environment dump.

## 19. Closeout and sealing

Require:

- repository T/inventory/membership unchanged;
- exact three-file repository delta unchanged;
- branch/HEAD/parent/tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged remain zero;
- A5P2, A5T4, A5C, A5FD, old A6, and every predecessor unchanged;
- no predecessor bytecode or cache;
- no private source, Git store, cache, runtime, PTY, process/group, worker,
  socket, listener, descriptor, build, or report root remains;
- two fresh absence epochs pass.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 20. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- A5C input mismatch;
- unsupported or dishonest historical overlay construction;
- need for repository or successor edits;
- missing exact HEAD or Repair-9 source;
- final/fresh difference;
- final/fresh terminal universe differs from A5T4;
- mutant delta differs from the exact contract;
- any control unqualified;
- unknown diagnostic;
- malformed or incomplete lifecycle;
- undeclared PTY request;
- path above 100 bytes;
- direct PTY allocation succeeds;
- unrelated terminal accessible;
- historical transition unresolved;
- blocking historical transition or hazard;
- analyzer nondeterminism;
- survivor, forced cleanup, or seal failure.

## 21. Verdicts

Opening mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

A5C input mismatch:

REPAIR10I_A6_SUCCESSOR_INPUT_MISMATCH

Historical source cannot be executed and qualified honestly under current
A5C contracts:

REPAIR10I_A6_HISTORICAL_CONTROL_CONSTRUCTION_REQUIRED

Fresh validation or comparison failure:

REPAIR10I_A6_VALIDATION_BLOCKED

Historical transition or hazard prevents the structural policy:

REPAIR10I_A6_POLICY_BLOCKED

Complete evidence refresh and policy freeze:

REPAIR10I_A6_POLICY_REFRESH_SEALED_READY_FOR_HISTORICAL_COMPARATOR_IMPLEMENTATION

The success report must include:

1. Repository and A5C opening/closing identities.
2. A5C A/B binary identities.
3. Exact five source-control base/effective identities.
4. Historical overlay provenance and qualification treatment.
5. Final/fresh raw and semantic identities.
6. Final/fresh accepted-equality result and exit 0.
7. Exact mutant provenance and both mutant comparison results.
8. HEAD and Repair-9 control qualifications.
9. Existing comparator factual outputs for both historical directions.
10. Complete test/package transition matrices for both directions.
11. Complete diagnostic/integrity hazard matrices.
12. Exact arrays, lengths, and hashes.
13. Package no-test evidence.
14. Structural-policy adjudication for each direction.
15. Frozen v4 schemas, fields, reason codes, exits, touched-file set, and
    causal matrix when supported.
16. Manifest SHA-256, size, and payload count.
17. Cleanup and two absence epochs.
18. Explicit statement that no historical comparator was implemented, B6 was
    not started, product A/B was not run, and no snapshot or audit occurred.

No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The historical-construction gate is essential. Without it, the new refresh could compare the current final against historical controls distorted by a validation restriction that those historical test harnesses were never written to satisfy.

The required five-pair shape and the rule that final/fresh must be accepted equal—not merely configured for an expected exit—have already been established in the project’s semantic-restoration design.  A bounded tool causal still does not replace the required freshly materialized downstream control. 

Any later comparator implementation changes the successor bytes and must return through fresh validation and a fresh independent audit.  Exact manifests will establish which controls and bytes were used, but they cannot establish that the structural historical policy is correct or that its hazard lattice is sufficient. 

### Sources

- Codex’s `REPAIR10I_A5C_OBSERVABILITY_DURATION_PATCH_SEALED_READY_FOR_A6_REFRESH` report supplied in the current turn.
- Repair 10H semantic-restoration comparison matrix and acceptance rule. 
- Milestone 0 proof-harness/non-authority boundary. 
- Sealed A2 downstream-control non-substitution boundary. 
- Governed Execution repair and re-audit protocol. 
- Governed Execution provenance limitations. 

**Confidence:** 0.999 that A5C is ready to advance; 0.97 that the next gate is the fresh A6 policy-evidence refresh; 0.90 that historical sources will require the explicit validation-harness overlay; 0.98 that a generic `/dev/fd` grant or unrecorded historical patch would be invalid; 0.96 that the structural directional policy can now be decided from fresh qualified evidence.
