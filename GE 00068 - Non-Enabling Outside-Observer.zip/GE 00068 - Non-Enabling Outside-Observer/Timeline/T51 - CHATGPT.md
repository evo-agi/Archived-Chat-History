The stop is correct. **My frozen A6 declaration set assigned the structural-privacy test to the wrong package.** Package is part of the terminal identity, so Codex could not safely treat that as a cosmetic correction.

This is not a new successor defect, not a scope expansion, and not a reason to create A7. A6 was never created or mutated, so the existing A6 design remains valid after correcting one tuple.

## Correct declaration set

Using the existing test-terminal identity representation, the finite `declared_final_only_passes` set must contain these four exact identities, all with an empty subtest:

| Package | Test |
|---|---|
| `execution-substrate` | `TestRepair10IDualSetpgidRaceReconciliationV1` |
| `execution-substrate` | `TestRepair10ISetpgidFailureRequiresExactGroupProofV1` |
| `execution-substrate` | `TestRepair10ISetpgidInverseMutantsV1` |
| `execution-substrate/es/externaltls/internal/statusobservation/remoteobserver` | `TestRepair10IStructuralPrivacyProjectionCausalControlsV1` |

The source-grounding result already establishes the essential predicates:

- all four are active top-level tests;
- none has a subtest component;
- all four are present in A5;
- all four are absent from historical HEAD;
- all four are absent from Repair 9.

No package-terminal declaration should be added: both packages already existed historically, and the intended exception concerns only these four newly introduced passing test identities.

Pass this continuation to Codex:

```text
Continue Repair 10I-A6 under the preceding frozen A6 instruction.

The prior A6 instruction remains controlling in full except for the corrected
finite declaration set below. Do not reopen or reinterpret its schema,
comparison-policy, scope, validation, sealing, non-goal, or stop-condition
decisions.

The preceding stop was correct: A6 was not created or mutated because one
frozen package identity was wrong.

## 1. Re-run the complete opening gate

Reverify the exact repository, A4, A5, Phase H, A/A2/A3, failed B/B2/B3/B4/B5,
and divergence-reconciliation identities required by the preceding A6 prompt.

Require:

- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- A5 manifest:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- A4 T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- A4 inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- A4 manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf

Require the A6 target to remain absent:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-successor-closure-e260e1bb5ac4

Stop on any drift:

REPAIR10I_A6_BASELINE_MISMATCH

## 2. Corrected exact declaration set

The complete finite `declared_final_only_passes` set consists of exactly four
test-terminal identities.

Express them using the existing lifecycle test-terminal identity type. The
semantic tuples are:

1.
package:
  execution-substrate

test:
  TestRepair10IDualSetpgidRaceReconciliationV1

subtest:
  empty

2.
package:
  execution-substrate

test:
  TestRepair10ISetpgidFailureRequiresExactGroupProofV1

subtest:
  empty

3.
package:
  execution-substrate

test:
  TestRepair10ISetpgidInverseMutantsV1

subtest:
  empty

4.
package:
  execution-substrate/es/externaltls/internal/statusobservation/remoteobserver

test:
  TestRepair10IStructuralPrivacyProjectionCausalControlsV1

subtest:
  empty

All four are test identities, not package-terminal identities.

Do not add a package-terminal declaration for either package.

The declaration serializer must apply the existing canonical terminal-identity
ordering. Do not depend on the human presentation order above.

## 3. Corrected source-grounding requirements

Before implementing, independently reproduce and retain that:

- the structural-privacy test is declared in:
  es/externaltls/internal/statusobservation/remoteobserver/observe_test.go
- its Go package identity is exactly:
  execution-substrate/es/externaltls/internal/statusobservation/remoteobserver
- the other three tests are declared in:
  remote_alpha_prepare_external_tls_status_test.go
- their Go package identity is exactly:
  execution-substrate
- all four are active top-level tests;
- all four have an empty subtest component;
- all four are present in exact A5;
- all four are absent from exact historical HEAD;
- all four are absent from exact Repair 9.

Use pinned-Go test discovery plus independent source parsing. Bind both evidence
paths.

If this corrected four-identity set does not reproduce exactly, stop:

REPAIR10I_A6_DECLARATION_SET_MISMATCH

## 4. Implementation remains unchanged

Implement the previously frozen A6 design:

- modify exactly:
  - tool/source/FORMAT.md
  - tool/source/envelope/semantic.go
  - tool/source/envelope/envelope_test.go
- introduce:
  - execution-substrate.repair10i.semantic-comparison-spec.v2
  - execution-substrate.repair10i.semantic-comparison-result.v2
- add the finite exact `declared_final_only_passes` field;
- require observed-final-only-pass set equality with the declared set;
- remove the compiled-in passing-test exception from the active acceptance path;
- keep v1 comparison records historical and nonqualifying;
- preserve every hazardous-regression prohibition;
- permit declarations only for:
  - historical-head → pristine-final
  - historical-repair9 → pristine-final
- reject declarations in final/fresh and mutant comparisons.

The preceding A6 positive and negative causal matrix remains mandatory.

In particular, add a direct wrong-package mutant for the structural-privacy
identity:

- declaring it under `execution-substrate` must fail;
- declaring it under its exact remoteobserver package must pass when every
  other predicate holds.

Also retain the inverse package mutation for one root test:

- moving a root test declaration to the remoteobserver package must fail.

## 5. No other plan change

Retain all previously frozen requirements for:

- exact observed/declaration set equality;
- missing, extra, duplicate, wrong-kind, wrong-package, wrong-test, and wrong
  outcome controls;
- hazardous regression controls;
- declaration-policy placement;
- strict v1/v2 schema handling;
- removal of the built-in structural-privacy exception;
- two disjoint A/B source/build/test/race controls;
- deterministic binary equality;
- final/fresh and mutant compatibility causals;
- exact three-file successor delta;
- evidence retention;
- cleanup and two absence epochs;
- detached digest followed by final manifest installation;
- complete read-only post-seal verification.

Do not modify repository source.

Do not modify a fourth successor source file.

Do not start B6.

Do not create a ZIP, handoff, capture child, or snapshot.

## 6. Verdicts

Opening mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

Corrected declaration still does not reproduce:

REPAIR10I_A6_DECLARATION_SET_MISMATCH

Scope expansion required:

REPAIR10I_A6_SCOPE_EXPANSION_REQUIRED

Implementation, validation, cleanup, or seal failure:

REPAIR10I_A6_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6_HISTORICAL_POLICY_PATCH_SEALED_READY_FOR_B6_RESTART

The success report must state the exact package/test/subtest tuple for all four
declarations and explicitly confirm that the structural-privacy declaration is
owned by the remoteobserver package, not the repository-root package.

No B6.
No snapshot.
No integrated ZIP.
No handoff.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A6, downstream work restarts as a fresh **B6**. A bounded successor repair does not substitute for freshly materialized source controls; the established A2 closeout states this explicitly.  Any changed successor bytes also require new validation and later re-audit rather than promotion of B5 evidence. 

### Sources

- Codex’s `REPAIR10I_A6_DECLARATION_SET_MISMATCH` response supplied in this turn.
- Sealed A2 restart precedent. 
- Governed Execution repair and re-audit protocol. 

**Confidence:** 0.999 that the stop was correct; 0.995 that the corrected four-identity set above is the intended declaration; 0.99 that no scope or schema redesign beyond the existing A6 plan is required; 0.995 that downstream validation must restart as fresh B6 after A6 changes the successor bytes.
