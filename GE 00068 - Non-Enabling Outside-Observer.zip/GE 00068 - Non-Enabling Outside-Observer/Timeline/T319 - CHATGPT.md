## Assessment

This package is ready for a fresh independent audit. The implementation report closes the entire process-bootstrap chain that caused the previous failures:

- literal, authenticated Carrier 0001 inputs;
- exact five-artifact import boundary;
- corrected three-field fixed-environment record;
- exact twelve-pointer rebinding proof;
- correctly polarized `target_content_inspected_is_false` assertion;
- no vacuous payload-identity fallback;
- explicit same-PID, constructed-environment, wrapper-SHA, CLI-conformance, no-child, and no-target assertions;
- two distinct materializations and two successful Carrier 0002 handoffs;
- producer and independently implemented 50-case validators;
- ten failure-atomicity causals;
- complete source-external package closure.

No further implementation should occur unless an independent audit finds a concrete defect.

The audit process itself needs one important constraint to prevent another recursive provenance failure: **the platform transcript is authoritative for top-level audit-driver invocations; the audit capsule is authoritative for every subprocess the driver creates.** The audit must not demand that its filesystem self-attest the platform’s creation of the driver process. It must contemporaneously record every child it actually launches. That is a closed, achievable evidence boundary.

## Prompt for Codex

```text
FRESH INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP PACKAGE V1

This is an independent audit of one source-external audit-process package.

Do not modify or repair the audit target.
Do not modify any supplied root.
Do not inspect the candidate repository, Strategic B source, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact full-audit bootstrap package and its bounded
process-bootstrap behavior.

It grants no authority over:

- the candidate repository;
- Strategic B;
- any V1/V2/V3 target;
- product or runtime behavior;
- publication;
- commit;
- deployment;
- readiness;
- the eventual V3 audit verdict;
- A6.

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

FULL_AUDIT_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-be5v9nny

Expected root identity:

- device/inode:
  16777234 / 179120828
- physical mode:
  0700
- expected producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected terminal manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  33552 each
- SHA-256:
  cec56d4c9ac08c79ae7da58107fd56cd3389ba879ed566e327b4582ae27e259b
- required:
  byte-identical

Expected closure statement:

- 177 represented entries;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

Independently derive and report:

- exact represented-directory count;
- exact represented-nonmanifest-file count;
- exact physical-file count including manifests;
- exact package-root membership;
- exact final temporal-inventory path, size, and SHA-256;
- exact implementation-report identity;
- exact source identities.

Expected primary semantic source files:

source/full_audit_bootstrap_v1.py
source/process_self_check_payload_v1.py
source/qualification_harness_v1.py

Do not assume their identities from prose. Derive them from the independently
verified manifests and live bytes.

Expected contracts:

contract/full-audit-bootstrap-contract-v1.json
contract/process-self-check-contract-v1.json
contract/fixed-environment-record-contract-v1.json
contract/launcher-identity-record-contract-v1.json
contract/root-rebinding-proof-contract-v1.json
contract/qualification-result-contract-v1.json

Expected schemas:

schemas/full-audit-bootstrap-contract-v1.schema.json
schemas/process-self-check-result-v1.schema.json
schemas/fixed-environment-record-v1.schema.json
schemas/launcher-identity-record-v1.schema.json
schemas/root-rebinding-proof-v1.schema.json

Expected producer validation:

- producer matrix:
  50/50;
- independent validator:
  50/50;
- two successful materializations;
- two successful Carrier 0002 handoffs;
- ten successful failure-atomicity injections;
- zero false acceptance;
- zero false rejection.

These are claims to audit, not audit oracles.

──────────────────────────────────────────────────────────────────────────────
2. IMMUTABLE INPUT ROOTS AND LINEAGE
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-3_22cefi

Expected root identity:

- device/inode:
  16777234 / 179114399
- mode:
  0700

Use only as immutable historical process-failure evidence.

Expected bounded identities include:

opening/carrier-0001-source.py

- size:
  87292
- SHA-256:
  d8c341721670cb4ace79d44f5e662260b040f9a430d2b4ef890785b51977e5d5

payloads/audit_supervisor.py

- size:
  64431
- SHA-256:
  f3a0ca539d2f7f4498a5612f17d242a1e2e2b67c4c4e5b7779304fe376e24408

opening/process-self-check-payload-result.json

- size:
  1723
- SHA-256:
  4ea6997cb82258c1efe1b8204581cb8a15ab57eb023ea2473571430bc279d967

opening/launch-contract-root-rebinding-v1.json

- size:
  869
- SHA-256:
  df8374bcc4bc4549361b4cb0a06d7cf9ad32d537a54241fe5a6094b8c30d8dc3

opening/fixed-environment-observation.json

- size:
  849
- SHA-256:
  1b900a6b4f56826dc36780355a30b81b6a52437a46cac0b3a72bccb17cde18cd

Required historical disposition:

- failed audit remains nonqualifying;
- raw `target_content_inspected:false` polarity was defective;
- failed fixed-environment record had an extra `policy` field;
- failed rebinding proof was malformed;
- failed result remains historical process evidence only.

Do not resume, repair, clean, or adopt this root.

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700
- expected verdict:
  WRAPPED_CARRIER_LAUNCHER_READY

Fixed input identities:

Wrapper:

source/phase_runner.py

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Launcher:

source/wrapped_carrier_launcher.py

- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

Phase-runner CLI contract:

contract/phase-runner-cli-contract-v1.json

- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Carrier-request contract:

contract/carrier-request-contract-v1.json

- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Environment-observation policy:

contract/environment-observation-policy-v1.json

- size:
  530
- SHA-256:
  7004617e0b15cf563fdac60f7144d0066384a44debd77b2174c55819816cf82f

Qualification-root launch contract:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Qualified-package manifest pair:

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- required:
  byte-identical

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Expected root identity:

- device/inode:
  16777234 / 179045387
- mode:
  0700

Expected verdict:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

Required verdict record:

closeout/verdict.json

- size:
  414
- SHA-256:
  5361158b8d8f57181bae449f2f7bf5994b3eeede681a4dd64187155e64ad6a63
- required `/verdict`:
  LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

REPAIRED_IMPORTER_REFERENCE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-v1-audit-repair-h585ymcr

Expected root identity:

- device/inode:
  16777234 / 179080164
- mode:
  0700

Use only as bounded lineage and producer-handoff reference evidence.

Expected source:

source/bootstrap_importer_v1.py

- size:
  84255
- SHA-256:
  1a7032d6ade79c3c5046f922fccbf870c716ede8100abc1969da5fad580b27bd

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Permission bits and all other host metadata are report-only.

Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
3. AUDIT PROCESS-AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking a tool.

Then state exactly:

AUDIT_EPOCH_START

The process-evidence boundary for this audit is:

A. Top-level audit-driver invocations

The Codex platform transcript is authoritative for:

- top-level tool-call ordering;
- submitted top-level command;
- submitted cwd;
- platform-reported completion or failure;
- direct-auditor scheduling.

The audit root does not and cannot self-attest the platform’s creation of the
top-level audit-driver process.

State:

`top_level_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not require an audit-root phase-start record to predate the platform launch
that creates it.

B. Audit-driver child processes

Every subprocess created by an audit-owned program after the audit root exists
must be recorded contemporaneously by the audit-owned child recorder.

For every child retain:

- start record before spawn;
- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- reaping;
- descriptor closure;
- contiguous child ordinal.

A missing child-process record requires:

AUDIT_PROVENANCE_MISMATCH

C. Pure in-process work

Filesystem reads, parsing, hashing, static analysis, and record generation
performed within a top-level audit-driver process do not constitute additional
subprocesses and do not require fictitious carrier records.

Do not create an impossible requirement for the audit root to attest invisible
platform-internal carrier details.

D. Direct auditors

Direct auditor interactions are not local subprocesses.

Record them separately through:

- interaction ordinal;
- auditor identity;
- prompt identity;
- authorized operands;
- start ordering;
- completion ordering;
- report identity;
- nested-agent count;
- platform outcome.

No direct auditor may create a nested agent.

──────────────────────────────────────────────────────────────────────────────
4. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh audit root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-independent-audit-

Retain at minimum:

opening/
auditors/
analysis/
validation/
causals/
provenance/
fixtures/
closeout/
private/

No retained empty directory is permitted at close.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or multiply linked file is permitted.

The first top-level audit driver must:

1. retain its exact source;
2. retain bootstrap-start;
3. retain the fresh root identity;
4. establish the child recorder;
5. inspect no target before bootstrap-start is durable.

──────────────────────────────────────────────────────────────────────────────
5. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Capture a complete lstat/no-follow inventory of the bootstrap package.
2. Independently regenerate both package manifests.
3. Verify the complete package closure.
4. Derive exact source, contract, schema, test, validation, lineage,
   provenance, closeout, and manifest identities.
5. Verify the failed-audit historical root.
6. Verify the qualified-launcher root.
7. Verify the import-reconciliation root.
8. Verify the repaired-importer reference root.
9. Verify pinned Python.
10. Verify no supplied root aliases the fresh audit root.
11. Verify no supplied input changed during opening.
12. Run child-recorder self-causals:
    - nonexistent executable / ENOENT;
    - `/usr/bin/true` / exit 0;
    - empty streams;
    - reaping;
    - descriptor closure;
    - contiguous ordinals.

Stop with AUDIT_PROVENANCE_MISMATCH on any opening identity, membership,
manifest, type, mode, link, lineage, process, or alias mismatch.

Do not start direct auditors or target correctness work before the opening gate
passes.

──────────────────────────────────────────────────────────────────────────────
6. FOUR DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes:

- Start Auditors 1–3 concurrently.
- Start Auditor 4 only after the first of Auditors 1–3 completes.
- No completed auditor may be retried.
- No auditor may create a nested agent.

Auditor 1 — contract and authority

Inspect:

- package authority and nonauthority;
- CLI;
- input contract;
- exact five-artifact boundary;
- lineage;
- consumer interface;
- no-target guarantee.

Auditor 2 — Carrier 0001 materialization

Inspect:

- literal exact-path selection;
- manifest verification;
- exact verdict lookup;
- fixed-environment record;
- launcher identity;
- root-bound launch contract;
- exact rebinding proof;
- failure atomicity.

Auditor 3 — Carrier 0002 self-check and qualification

Inspect:

- payload assertion map;
- target-inspection polarity;
- payload-identity treatment;
- same PID;
- environment;
- CLI;
- wrapper SHA;
- output posture;
- producer and independent matrices;
- two handoffs.

Auditor 4 — provenance, filesystem, security, and artifacts

Inspect:

- every package object;
- modes and links;
- package manifests;
- final inventory chronology;
- attempts;
- process records;
- cleanup;
- source-level network/Git/shell/target behavior;
- sensitive-material posture.

Auditors:

- run no Git;
- execute no package, test, or product command;
- use no network;
- write no file;
- mutate no supplied root;
- create no nested agent.

Retain exact prompts, operands, reports, schedule, findings, uncertainty, and
uninspected scope.

──────────────────────────────────────────────────────────────────────────────
7. EXACT PRODUCTION EXPORT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Independently determine which package files are required by a future full V3
audit.

At minimum adjudicate:

source/full_audit_bootstrap_v1.py
source/process_self_check_payload_v1.py

Determine whether either source imports or reads:

- source/qualification_harness_v1.py;
- tests;
- validation results;
- lineage reports;
- producer fixtures;
- closeout reports;
- package manifests beyond input verification.

Require:

- production bootstrap behavior does not depend on qualification-harness
  source;
- production behavior does not depend on tests or producer results;
- qualification_harness_v1.py is qualification-only;
- process package has one closed consumer interface;
- exact CLI and required package-relative source paths are unambiguous.

Retain:

analysis/production-export-boundary.json

Classify every package source file as:

- future-audit executable input;
- runtime template input;
- qualification-only;
- test-only;
- provenance-only;
- report-only.

Any hidden dependency on qualification-only evidence blocks acceptance.

──────────────────────────────────────────────────────────────────────────────
8. SOURCE AND STATIC SECURITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Inspect every executable source file completely.

Require production bootstrap source to contain no:

- network API;
- Git;
- shell;
- product or target path;
- candidate path;
- V1/V2/V3 path;
- broad `/Users/ds/Downloads` scan;
- latest/prefix selection;
- existing-root adoption;
- symlink-following fallback;
- overwrite;
- credential output;
- raw additional environment values;
- automatic progression into target audit.

The package may execute the bounded Carrier 0002 self-check only through the
explicit qualification harness or future audit driver. Production Carrier 0001
must not automatically start target work.

The qualification harness may spawn only the exact bounded Carrier 0002 and
implementation-owned test processes declared by its contract.

Perform bounded sensitive-material scans over every package file.

Do not emit matching sensitive payload content.

──────────────────────────────────────────────────────────────────────────────
9. AUTHORITY AND NONAUTHORITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Require the positive authority set to be limited to:

- exact process-input verification;
- fresh audit-root allocation;
- bootstrap provenance;
- exact five-artifact materialization;
- auxiliary-record generation;
- launch-contract generation;
- rebinding-proof generation;
- Carrier 0002 payload/request generation;
- process-self-check qualification.

Require explicit false authority for:

- candidate repository;
- repository;
- source;
- product;
- runtime;
- deployment;
- publication;
- commit;
- V3 target correctness;
- V3 audit verdict;
- readiness;
- A6.

Require exact agreement among:

- main contract;
- applicable schemas;
- bootstrap-start/outcome/result records;
- generated authority-boundary records;
- process-self-check result;
- implementation report classification.

Reject omission, implicit inheritance, duplicate conflicting synonyms,
narrowing, widening, or a true authority value.

Construct independent audit-only mutations for every authority dimension.

──────────────────────────────────────────────────────────────────────────────
10. CLI AND FRESH-ROOT ALLOCATION AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the exact CLI from source.

Expected invocation:
```
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  source/full_audit_bootstrap_v1.py \
  --qualified-launcher-root \
  /Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38 \
  --import-reconciliation-root \
  /Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s \
  --audit-parent \
  /Users/ds/Downloads \
  --audit-prefix \
  ES-validation-custody-v3-full-audit-
```

Require:

- exact option closure;
- no target-root option;
- pinned absolute interpreter;
- no shell;
- no PATH lookup;
- no fallback;
- no existing-root adoption;
- `tempfile.mkdtemp`;
- exact parent and caller-supplied prefix;
- umask 077;
- durable bootstrap-start before root locator output;
- exactly one `AUDIT_ROOT=<absolute-path>\n` line;
- no earlier stdout;
- handled success/failure stderr empty.

Audit exit classes and ensure success and handled failure cannot be confused.

──────────────────────────────────────────────────────────────────────────────
11. CARRIER 0001 LITERAL-INPUT AUDIT
──────────────────────────────────────────────────────────────────────────────

Require Carrier 0001 to use exactly:

Pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Wrapper:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/source/phase_runner.py

Launcher:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/source/wrapped_carrier_launcher.py

CLI contract:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/phase-runner-cli-contract-v1.json

Request contract:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/carrier-request-contract-v1.json

Environment policy:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38/contract/environment-observation-policy-v1.json

Require source-level absence of:

- globbing;
- recursive candidate discovery;
- filename/content/role scoring;
- first-viable selection;
- fallback candidates;
- PATH lookup;
- newest/latest selection;
- prefix scanning;
- adoption.

Independently execute literal-path negative fixtures:

- missing exact wrapper;
- wrong wrapper hash;
- missing exact launcher;
- wrong launcher hash;
- missing policy;
- wrong policy identity;
- extra alternative candidate present.

Require failure without considering an alternative.

──────────────────────────────────────────────────────────────────────────────
12. QUALIFIED-PACKAGE AND RECONCILIATION VERIFIERS
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the qualified-package manifest grammar.

Require exact:

- type `directory`;
- type `regular`;
- root `.`;
- `os.fsencode(path)` ordering;
- directory field set;
- regular-file field set;
- exactly two exclusions;
- type/mode/link/size/hash checks;
- no-follow traversal;
- symlink rejection;
- special-object rejection;
- hardlink rejection;
- exact package membership.

Prove `type:"file"` is not used.

For reconciliation:

- resolve exactly `closeout/verdict.json`;
- authenticate it through the covering manifest;
- verify exact identity;
- strictly parse canonical JSON;
- reject duplicate keys and nonfinite values;
- read `/verdict` directly;
- require:
  `LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT`;
- verify no addendum required and no package repair required.

Require source-level absence of recursive string or filename discovery.

──────────────────────────────────────────────────────────────────────────────
13. FIVE-ARTIFACT COPY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Require exactly five copied process artifacts:

1. wrapper;
2. launcher;
3. phase-runner CLI contract;
4. carrier-request contract;
5. environment-observation policy.

For each require:

- source no-follow open;
- exact source identity;
- exclusive destination creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte identity.

Require no qualification result, phase record, carrier index, report, final
inventory, manifest, or failed-attempt record copied as fresh truth.

Independently inject one missing and one extra copy case per artifact class.

──────────────────────────────────────────────────────────────────────────────
14. FIXED-ENVIRONMENT RECORD AUDIT
──────────────────────────────────────────────────────────────────────────────

Require exact top-level fields:

- `authority`
- `environment`
- `schema`

No `policy` field or other unknown field is permitted.

Require the exact six-key environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<FRESH_ROOT>/private/home
TMPDIR=<FRESH_ROOT>/private/tmp

Require:

- fresh-root values;
- record final before launch-contract generation;
- exact path/size/SHA bound in launch contract;
- strict schema;
- no stale qualification exemplar;
- no copied policy body.

Independently mutate every required field and add unknown fields.

──────────────────────────────────────────────────────────────────────────────
15. LAUNCHER IDENTITY AND ROOT-BOUND CONTRACT
──────────────────────────────────────────────────────────────────────────────

Require the launcher identity record to describe the final copied launcher.

Require the root-bound launch contract to derive from the exact 2260-byte
qualified launch contract.

Require final auxiliary records before contract finalization.

Verify exact copied paths and identities, pinned interpreter, interpreter flags,
fixed environment, no shell, no fallback, no path lookup, same-PID exec, and
wrapper SHA.

Require no stale qualification-root path except where retained as the explicit
predecessor value in the rebinding proof.

──────────────────────────────────────────────────────────────────────────────
16. EXACT TWELVE-POINTER REBINDING PROOF
──────────────────────────────────────────────────────────────────────────────

Require schema:

execution-substrate.launcher-qualification.launch-contract-root-rebinding.v1

Require exactly these direct pointers:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

Require:

- changed-field count 12;
- no transitive substituted pointer;
- no nonexistent pointer;
- predecessor and successor values;
- classification:
  `physical-audit-root-rebinding-only`;
- semantic effect:
  none;
- normalized predecessor projection;
- normalized successor projection;
- normalized identities;
- normalized equality true;
- non-root difference count 0;
- success true.

Independently recompute the proof from source contracts.

Reject any discrepancy between retained and recomputed proof.

──────────────────────────────────────────────────────────────────────────────
17. CARRIER 0002 ASSERTION MAP
──────────────────────────────────────────────────────────────────────────────

Inspect the exact payload template and generated payload.

Require every value in the positive assertion map to mean success when true.

At minimum require:

- carrier ordinal is 2;
- audit root equals the exact context root;
- constructed environment equals launch-contract environment;
- observed contract-owned environment values exact;
- launcher PID present;
- payload PID present;
- same PID true;
- wrapper SHA exact;
- wrapper SHA occurrence count 1;
- CLI conformance `pass`;
- missing required options empty;
- unknown options empty;
- duplicate singleton options empty;
- malformed options empty;
- canonical order true;
- payload arguments exact;
- authorized operands exact;
- expected outputs exact and complete;
- request contains no invariant override;
- no child process;
- target content inspected is false.

Require raw posture separately:

- `child_process_created:false`;
- `target_content_inspected:false`;
- additional environment key names;
- no additional values.

Reject:

- raw false negative state inserted into positive assertion map;
- whole observed-environment map equality;
- vacuous payload-identity self-comparison;
- fallback-to-self payload identity;
- missing same-PID assertion;
- missing constructed-environment assertion;
- missing wrapper-SHA cardinality;
- missing CLI-conformance assertion.

──────────────────────────────────────────────────────────────────────────────
18. SAME-PID, ENVIRONMENT, CLI, AND OUTPUT AUDIT
──────────────────────────────────────────────────────────────────────────────

Require dynamic handoff evidence to retain:

- launcher PID immediately before `execve`;
- payload PID after wrapper entry;
- equality.

Require the launcher to use terminal same-process `os.execve`.

Environment:

A. constructed environment exactly equals fixed contract map;

B. every contract-owned observed value exact;

C. additional post-exec key names diagnostic only;

D. additional values not retained.

CLI:

- exact required options;
- exact canonical order;
- wrapper SHA exact and once;
- payload path/size/hash exact;
- audit root exact;
- carrier/phase/entry exact;
- expected outputs exact;
- authorized operands exact.

Outputs:

- every expected output present;
- every output type/mode/link/identity valid;
- no forbidden extra output.

──────────────────────────────────────────────────────────────────────────────
19. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import producer test helpers or derive audit cases from producer
fixtures.

Construct a fresh matrix covering at least all 50 reported mechanisms plus:

A. Literal-path selection

- missing exact source with decoy candidate present;
- wrong exact source with valid alternative present;
- fallback attempted;
- discovery/scoring code path.

B. Target-inspection polarity

- false posture passes;
- true posture fails;
- raw false inserted into positive map;
- renamed assertion with reversed polarity.

C. Payload identity

- self-comparison;
- fallback-to-self;
- wrapper-authenticated mismatch;
- missing authenticated context.

D. Fixed-environment record

- exact three-field shape;
- added `policy`;
- added unknown;
- missing authority/environment/schema;
- stale root;
- wrong size/hash binding.

E. Rebinding proof

- each actual pointer omitted;
- transitive pointer added;
- nonexistent pointer added;
- count not 12;
- normalized mismatch;
- non-root difference nonzero;
- missing projection;
- `success:false`.

F. PID

- equal;
- mismatch;
- missing launcher PID;
- missing payload PID;
- wrong fields compared.

G. Environment

- constructed map exact;
- constructed extra key;
- observed extra diagnostic key;
- missing required observed key;
- changed observed value;
- additional value retained.

H. CLI and wrapper SHA

- wrong SHA;
- missing SHA;
- duplicate SHA;
- missing option;
- unknown option;
- duplicate singleton;
- malformed value;
- wrong order.

I. Output and target posture

- missing expected output;
- forbidden extra output;
- child process true;
- target inspection true.

Pin exact audit case names and expected mechanism-specific reasons.

Require:

- uniqueness;
- exact count;
- zero false acceptance;
- zero false rejection;
- no producer fixture as oracle.

──────────────────────────────────────────────────────────────────────────────
20. TWO FRESH MATERIALIZATIONS
──────────────────────────────────────────────────────────────────────────────

Run the exact production bootstrap twice into distinct audit-owned roots.

For each retain:

- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit;
- emitted root;
- complete resulting inventory;
- bootstrap start/outcome;
- copied artifacts;
- auxiliary records;
- root-bound launch contract;
- rebinding proof;
- Carrier 0002 payload;
- Carrier 0002 request.

Require:

- distinct device/inode roots;
- exactly one root-locator line;
- empty handled stderr;
- exit 0;
- exact copied bytes;
- normalized records equal;
- normalized contracts equal;
- payload source byte-identical;
- normalized requests equal;
- target inspection false;
- Carrier 0002 not yet executed.

──────────────────────────────────────────────────────────────────────────────
21. TWO FRESH CARRIER 0002 HANDOFFS
──────────────────────────────────────────────────────────────────────────────

Execute Carrier 0002 in both audit-owned roots through:

pinned Python
→ copied qualified launcher
→ same-PID execve
→ pinned Python
→ copied mode-0600 wrapper
→ generated process-self-check payload

For both require:

- request admission;
- constructed launch;
- parser admission;
- phase start/outcome;
- compilation;
- execution;
- same PID;
- exact constructed environment;
- exact observed owned values;
- diagnostic-only additional names;
- wrapper SHA exact and once;
- CLI conformance pass;
- no child;
- no target inspection;
- all expected outputs;
- payload success;
- wrapper exit 0.

Normalize only permitted root and PID fields.

Require normalized self-check results byte-identical.

──────────────────────────────────────────────────────────────────────────────
22. FAILURE-ATOMICITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently inject failures at minimum during:

1. exact input verification;
2. package-manifest verification;
3. reconciliation-verdict verification;
4. process-artifact copying;
5. launcher identity retention;
6. fixed-environment retention;
7. launch-contract retention;
8. normalized projection retention;
9. rebinding-proof retention;
10. payload retention;
11. request retention;
12. Carrier 0002 self-check.

For each require:

- root locator retained;
- bootstrap start retained;
- canonical failure/outcome;
- accurate partial-artifact inventory;
- no success result;
- no retry in the root;
- no overwrite;
- no later progression;
- no target inspection;
- failed root retained.

Do not rely solely on producer causal summaries.

──────────────────────────────────────────────────────────────────────────────
23. PRODUCER AND INDEPENDENT VALIDATION ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Inspect:

- producer source;
- producer 50-case result;
- independent-validator source;
- independent 50-case result;
- deterministic-materialization record;
- handoff record;
- failure-atomicity record;
- attempt index.

Require:

- producer and independent case definitions materially independent;
- no shared parser/helper that makes independence circular;
- independently literal expected case sets;
- exact name and reason closure;
- failed attempts excluded;
- two successful materializations genuinely distinct;
- two handoffs genuinely separate;
- no target process executed.

Fresh audit execution remains authoritative over producer reports.

──────────────────────────────────────────────────────────────────────────────
24. ROOT-LAYOUT AND PLACEHOLDER AUDIT
──────────────────────────────────────────────────────────────────────────────

Inspect every importer-created file in an output audit root.

For each classify:

- schema;
- owner;
- lifecycle stage;
- consumer;
- authority;
- whether required before Carrier 0002;
- whether retained merely to make a directory nonempty.

Reject any file whose sole purpose is to evade an empty-directory rule without
an explicit lifecycle contract.

Require no file to falsely imply:

- auditor completion;
- target analysis;
- child execution;
- V3 result;
- closeout completion;
- target audit progression.

Explicit ownership or namespace records are acceptable only when:

- schema-bound;
- nonauthoritative;
- semantically accurate;
- required by the full-audit layout contract.

──────────────────────────────────────────────────────────────────────────────
25. ATTEMPT AND LINEAGE AUDIT
──────────────────────────────────────────────────────────────────────────────

Inspect all retained attempts.

Require:

- failed attempts distinct;
- attempt 1 whole-environment oracle classified correctly;
- attempt 2 token-scanner self-match classified correctly;
- failed artifacts do not supply final pass identities or counts;
- successful qualification results come from the final attempt;
- no failed source presented as current;
- lineage binds exact source and result identities;
- failed audit remains historical;
- qualified launcher and reconciliation authority remain unchanged;
- no V3 target conclusion inherited.

──────────────────────────────────────────────────────────────────────────────
26. PACKAGE MANIFEST AND INVENTORY CHRONOLOGY
──────────────────────────────────────────────────────────────────────────────

Inspect both package manifest generators completely.

Independently reproduce both manifests byte-for-byte.

Require:

- exact root representation;
- complete directory membership;
- complete nonmanifest-file membership;
- exactly two manifest exclusions;
- no duplicate or missing path;
- no unexplained object;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory modes 0700;
- file modes 0600.

Locate and verify the temporal final inventory.

Require:

- exact declared exclusions;
- report and all other nonmanifest files finalized before inventory where
  claimed;
- inventory finalized before terminal manifests;
- terminal manifests cover the inventory;
- no file written after manifest closure;
- no unstable directory size/link-count authority unless explicitly
  classified noncontent and excluded from stable identity.

──────────────────────────────────────────────────────────────────────────────
27. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all auditors and parent work:

- repeat complete inventories for package and every supplied root opened;
- verify pinned Python unchanged;
- verify opening/closing equality;
- verify every audit-created child-process record complete;
- verify no process or descriptor survivor;
- retain complete inventories of audit-owned fixture roots;
- remove only audit-owned fixtures and private state;
- perform two fresh `lstat` calls per removed root;
- require ENOENT twice.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
28. FINAL AUDIT CAPSULE
──────────────────────────────────────────────────────────────────────────────

Retain:

- opening inventories;
- complete child-process ledger;
- direct-auditor interaction index;
- four auditor reports;
- exact package-source identities;
- export-boundary analysis;
- authority audit;
- CLI/root-allocation audit;
- literal-path audit;
- package/reconciliation verifier audit;
- copy-boundary audit;
- auxiliary-record audit;
- rebinding-proof audit;
- self-check assertion audit;
- fresh mutation matrix;
- two materializations;
- two handoffs;
- failure-atomicity causals;
- layout adjudication;
- security review;
- attempt adjudication;
- manifest chronology;
- closing equality;
- cleanup;
- final report;
- final inventory;
- two independent covering manifests.

Use two independent lstat/no-follow manifest generators.

Require:

- root and every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no unexplained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests.

No later filesystem-writing audit step may occur after terminal manifest
closure.

──────────────────────────────────────────────────────────────────────────────
29. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- opening and closing provenance qualify;
- package manifests and inventory qualify;
- production export boundary is closed;
- package authority remains process-only;
- CLI and root allocation qualify;
- literal input selection qualifies;
- package and reconciliation verification qualify;
- exactly five artifacts are copied;
- auxiliary records qualify;
- root-bound launch contract qualifies;
- twelve-pointer proof qualifies;
- self-check assertion semantics qualify;
- independent mutation matrix passes;
- two materializations pass;
- two Carrier 0002 handoffs pass;
- failure atomicity passes;
- layout artifacts are legitimate;
- source/security review passes;
- attempts and lineage qualify;
- four auditors complete;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable package, contract, validator, materialization,
handoff, artifact, lineage, or evidence defect.

Return REJECT only for fundamental unsoundness outside the bounded package.

Return AUDIT_PROVENANCE_MISMATCH for:

- child-process ledger gaps;
- supplied-input drift or mutation;
- missing fixed input;
- opening/closing inequality;
- audit-capsule closure failure;
- process execution outside the declared authority boundary.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
30. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Package identity and closure
4. Immutable-input identities
5. Process-authority and child-ledger posture
6. Four auditor identities, schedule, findings, and limits
7. Exact source identities
8. Production export boundary
9. Authority and nonauthority
10. CLI and fresh-root allocation
11. Literal process-input selection
12. Qualified-package verifier
13. Reconciliation exact-path verdict verifier
14. Exact five-artifact copy boundary
15. Fixed-environment record
16. Launcher identity and root-bound contract
17. Exact twelve-pointer rebinding proof
18. Carrier 0002 assertion map
19. Target-inspection polarity
20. Payload-identity treatment
21. Same-PID evidence
22. Environment evidence
23. CLI and wrapper-SHA evidence
24. Fresh independent mutation matrix
25. Two fresh materializations
26. Two Carrier 0002 handoffs
27. Failure-atomicity causals
28. Root-layout artifact adjudication
29. Security and sensitive-material findings
30. Producer/independent-validation adjudication
31. Failed/superseded attempts
32. Manifest and inventory chronology
33. Supplied-root closing equality
34. Fixture cleanup and ENOENT observations
35. Audit-capsule inventory and manifests
36. Severity-ranked findings
37. Minority findings and parent resolution
38. Remaining uncertainty and nonclaims
39. Explicit confirmations

Required confirmations:

FULL_AUDIT_BOOTSTRAP_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
REPAIRED_IMPORTER_REFERENCE_MUTATION_NOT_PERFORMED
PACKAGE_SOURCE_IDENTITIES_INDEPENDENTLY_BOUND
PRODUCTION_EXPORT_BOUNDARY_CLOSED
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
LITERAL_EXACT_PATH_SELECTION_VERIFIED
EXACT_FIVE_PROCESS_ARTIFACTS_COPIED
FIXED_ENVIRONMENT_RECORD_EXACT_THREE_FIELD_SHAPE
REBINDING_PROOF_EXACT_SCHEMA
REBINDING_PROOF_EXACT_TWELVE_POINTERS
NORMALIZED_LAUNCH_CONTRACTS_EQUAL
NON_ROOT_DIFFERENCE_COUNT_ZERO
TARGET_INSPECTION_POLARITY_CORRECT
RAW_FALSE_TARGET_STATE_NOT_USED_AS_POSITIVE_ASSERTION
VACUOUS_PAYLOAD_IDENTITY_ASSERTION_ABSENT
SAME_PID_DYNAMIC_EVIDENCE_VERIFIED
CONSTRUCTED_ENVIRONMENT_VERIFIED
OBSERVED_OWNED_ENVIRONMENT_VERIFIED
ADDITIONAL_ENVIRONMENT_KEYS_DIAGNOSTIC_ONLY
WRAPPER_SHA_VALUE_AND_CARDINALITY_VERIFIED
CLI_CONFORMANCE_VERIFIED
NO_CHILD_PROCESS_VERIFIED
NO_TARGET_INSPECTION_VERIFIED
FRESH_INDEPENDENT_MUTATION_MATRIX_PASSED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_CARRIER_0002_HANDOFFS_PASSED
FAILURE_ATOMICITY_CAUSALS_PASSED
NO_PLACEHOLDER_ONLY_ARTIFACT_ADMITTED
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
FOUR_AUDITOR_INTERACTIONS_RECONCILED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
FULL_V3_AUDIT_NOT_STARTED
A6_NOT_STARTED
NO_NESTED_SUBAGENTS
```

After an `ACCEPT`, the next step is the fresh full Validation-Custody V3
independent audit consuming the exact accepted bootstrap package. No further
process-infrastructure implementation or audit tranche is justified absent a
new substantive finding.

**Source:** Codex’s full-audit bootstrap implementation report above.

**Confidence:** 0.99 that the package is ready for independent audit; 0.98 that the explicit process-authority split avoids the prior impossible self-attestation loop; 0.98 that an `ACCEPT` would close process infrastructure and permit returning to the substantive V3 audit.
