## Assessment

Do **not** run another producer qualification replay.

The latest response is formally correct under the prompt it received, but that prompt imposed an unnecessarily brittle rule: it made an unrelated read-only `cat` command fatal merely because the shell’s inherited working directory happened to be the primary checkout. No Git command ran, no repository-relative primary-checkout file was read, no implementation byte changed, and no validation claim was made. Repeating the producer qualification again would add ceremony without adding material evidence.

The prior implementation already produced:

- exact final provenance for the unchanged 13-path patch;
- four successful 88-test runs across umasks `077` and `022`;
- independent launch-protocol causals;
- a source-external SEC-02 timed negative;
- repeated A6D, amendment, and synthetic-A6 compatibility results;
- artifact cleanup and no-write evidence.

Its formal `BLOCKED` verdict came solely from one read-only Git command whose environment bindings were not explicitly captured. That should remain disclosed as a producer-process deviation, but it does not demonstrate byte drift, failed validation, or a verifier defect.

The proportionate next gate is therefore a **fresh independent audit of the exact `ed268…` patch**, not another producer replay. The auditor must independently reproduce provenance and validation rather than treating the blocked producer report as qualification. This preserves the required separation: implementation validation is producer evidence, while independent audit occurs later in a fresh read-only conversation.  Provenance establishes that everyone is examining the same bytes; it does not itself establish correctness or authority. 

The process rule should also be corrected:

- Every **Git** command must be explicitly rooted at the implementation worktree with the frozen Git environment.
- Repository-relative reads must not occur from the primary checkout.
- A non-Git read-only command that happens to inherit the primary checkout as cwd is **not automatically disqualifying** when it accesses only an absolute external path.
- Producer command deviations are findings to adjudicate, not automatic audit blockers unless they undermine provenance, source identity, validation, or supplied evidence.

That prevents another meaningless first-command failure without weakening the actual Git and repository boundaries.

Start a **new Codex conversation**, preferably with the implementation worktree selected as its working directory, and paste the following prompt inline rather than attaching it as a file.

---

## Codex prompt: fresh independent audit of launch protocol v2

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete audit report inline in Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

You may create and link a source-external report as supplemental evidence, but
the complete report required by this prompt must also appear in the response
body.

This applies to every outcome:

- ACCEPT;
- BLOCK;
- REJECT;
- AUDIT_PROVENANCE_MISMATCH;
- PROCESS_BOUNDARY_BLOCK;
- SUBAGENT_UNAVAILABLE.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh, read-only Codex conversation.

Do not resume:

- the implementation conversation that returned
  EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_BLOCKED; or
- the failed qualification-replay conversation that returned
  EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROCESS_BOUNDARY_VIOLATION.

Those conversations remain predecessor process evidence only.

Objective

Perform a fresh, independent, read-only audit of the existing Evidence
Verification v1 launch-protocol-v2 patch.

Do not repair or modify the patch.

The current implementation bytes already exist. The producer reported complete
technical validation but returned a formal blocked verdict because one
read-only Git command lacked explicit frozen environment bindings.

A later attempted qualification replay stopped before repository inspection
because its first command was a non-Git `cat` executed while the shell inherited
the primary checkout as cwd.

For this audit, apply this adjudication rule:

- A prior producer process deviation is not automatically a patch defect.
- It is not an AUDIT_PROVENANCE_MISMATCH unless the current bytes, path set,
  repository identity, validation target, or supplied evidence differ.
- It is not an automatic BLOCK when the independent audit itself reproduces
  provenance and all acceptance-bearing validation cleanly.
- Preserve and report the deviations.
- Independently determine correctness of the current exact bytes.

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

No repository mutation.
No formatting.
No repair.
No cleanup that alters repository or supplied-evidence bytes.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No nested subagents.

## 1. Exact audit target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Exact canonical patch manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/provenance/qualified/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98

Expected tracked binary-diff SHA-256:

6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7

Expected verifier:

- path:
  tools/evidence_verify/verify_v1.py
- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected tests:

- path:
  tools/evidence_verify/test_verify_v1.py
- size:
  70730
- SHA-256:
  7e2dcf579c5e4bf3fd72762662e3a66f96668af1470be00a665e893a9efa15a1

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe:

- recipe ID:
  execution-substrate.evidence-verification-v1.final-patch-provenance.v1
- size:
  5143
- SHA-256:
  bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Source-external validation launch capsule:

LAUNCH_CAPSULE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/commands/launch_v2.py

Expected launch-capsule SHA-256:

856cc81650330deb776cbf9bff74644176405acf3163839547acfce3d73ba1e2

Producer evidence root, read-only:

PRODUCER_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4

Producer validation index:

PRODUCER_VALIDATION=$PRODUCER_EVIDENCE/closeout/validation-index-qualified.json

Producer evidence inventory:

PRODUCER_INVENTORY=$PRODUCER_EVIDENCE/closeout/final-evidence-inventory-qualified.json

Producer Git-process deviation:

PRODUCER_DEVIATION=$PRODUCER_EVIDENCE/closeout/git-command-deviation.json

Load-custody reconnaissance, read-only:

RECON=/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f

Fifth independent audit, read-only:

AUDIT_V5=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- version:
  3.13.4
- regular single-link file;
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-ed26813371b3-v1

Forbidden primary checkout for Git or repository-relative reads:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

## 2. Process and Git boundary

Use:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - GIT_OPTIONAL_LOCKS=0;
  - GIT_CONFIG_NOSYSTEM=1;
  - LC_ALL=C;
  - LANG=C;
  - PYTHONDONTWRITEBYTECODE=1;
- be recorded with full argv, cwd, relevant environment, exit, stdout SHA-256,
  and stderr SHA-256.

No audit subagent may execute Git.

No Git command may run in:

- PRIMARY_R;
- CANDIDATE_R;
- A6D;
- A6D_AMEND;
- PRODUCER_EVIDENCE;
- RECON;
- AUDIT_V5;
- AUDIT_ROOT;
- any other evidence or audit root.

Do not use implicit-cwd Git.

PROCESS-BOUNDARY CLARIFICATION

The first Git command must be:

git -C "$IMPL_R" rev-parse --show-toplevel

with the required Git environment.

Non-Git read-only commands may occur before that command when necessary to
read this prompt or inspect an absolute, source-external input.

A non-Git command is not disqualifying merely because its inherited cwd is
PRIMARY_R, provided that:

- it uses no repository-relative operand;
- it does not read a PRIMARY_R repository path;
- it does not write or mutate PRIMARY_R;
- it does not invoke Git.

Before any repository-relative read, use IMPL_R as cwd or use an absolute
IMPL_R path.

Any nonconforming Git command is a process-boundary blocker.

Any read or mutation of a repository-relative PRIMARY_R path is a
process-boundary blocker.

## 3. Audit root

Require AUDIT_ROOT absent.

Only after the opening identity gate passes, create it under umask `077` with:

opening/
provenance/
perspectives/
validation/
findings/
closeout/
tmp/

All outputs remain beneath AUDIT_ROOT.

Remove only audit-owned temporary fixtures.

Do not chmod, normalize, restore, or otherwise alter repository or supplied
evidence.

## 4. Opening repository gate

Require IMPL_R:

- physical root equals lexical path;
- direct real directory;
- branch:
  codex/evidence-verification-v1;
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c;
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338;
- parent count exactly one;
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f;
- upstream absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular and single-link;
- every working mode 0644;
- every logical mode 100644;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

Expected 13 paths:

1. PLANS.md
2. .docs/system_overview/boundaries.md
3. .docs/system_overview/artifact_hygiene.md
4. .docs/system_overview/capability_probing.md
5. .docs/system_overview/evidence_verification.md
6. tools/evidence_verify/verify_v1.py
7. tools/evidence_verify/registry_v1.json
8. tools/evidence_verify/layouts/a6d_successor_v1.json
9. tools/evidence_verify/layouts/a6d_amendment_v1.json
10. tools/evidence_verify/layouts/a6_policy_v1.json
11. tools/evidence_verify/test_verify_v1.py
12. tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt
13. tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt

Open EXPECTED_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact recipe source;
- exact recipe ID;
- exact expected manifest SHA-256;
- exact branch, HEAD, and absent upstream;
- exact 13 manifest rows;
- exact four/nine classifications;
- every manifest row equals live path, type, mode, size, and SHA-256;
- tracked binary diff equals:
  6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7;
- verifier/test identities equal section 1;
- registry and three layout hashes equal the manifest;
- historical fixture hashes equal the manifest.

Require LAUNCH_CAPSULE, PRODUCER_VALIDATION, PRODUCER_INVENTORY,
PRODUCER_DEVIATION, RECON, and AUDIT_V5 present and stable.

Require A6D and A6D_AMEND manifests exact.

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Opening provenance reproduction

Create under AUDIT_ROOT:

opening/provenance-replay-v1/provenance/

Run the exact unchanged RECIPE twice against IMPL_R using fresh absent output
paths.

Require:

- both exits 0;
- stderr empty;
- both output files byte-identical;
- both stdout streams byte-identical;
- stdout byte-identical to each output file;
- all outputs byte-identical to EXPECTED_MANIFEST;
- manifest SHA-256:
  ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98;
- tracked binary diff:
  6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7;
- no repository or supplied-evidence mutation.

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 6. Producer-process deviation adjudication

Inspect PRODUCER_DEVIATION.

Require the audit to distinguish:

1. current target provenance and correctness;
2. producer validation evidence;
3. producer-process conformance.

The producer reported one read-only `git status --short` command that:

- was rooted at the correct implementation worktree;
- did not explicitly carry or record the frozen Git environment;
- exited zero;
- was followed by fully compliant closing Git and provenance checks;
- produced no reported repository mutation.

The earlier producer formal verdict remains blocked and must not be rewritten.

However, do not automatically BLOCK the current patch solely because of that
historical producer-process deviation when this audit independently verifies:

- exact opening and closing provenance;
- exact repository identity;
- all validation required by this prompt;
- no mutation or hidden target drift;
- no dependence on the nonconforming command as a correctness oracle.

Report the deviation as:

- producer-process issue;
- predecessor evidence limitation;
- non-authoritative for current correctness.

If inspection reveals another undisclosed source, validation, provenance, or
mutation problem, treat that problem on its merits.

The failed qualification replay that ran only a source-external `cat` before
stopping supplies no correctness result and need not be treated as a patch
finding.

## 7. Audit perspectives

Only after opening provenance passes, create exactly four bounded read-only
audit perspectives:

1. Contract and authority auditor.
2. Launch-protocol and verifier-correctness auditor.
3. Test and validation-adequacy auditor.
4. Security, filesystem, process, and artifact auditor.

No nested subagents.

No subagent Git commands.

Every perspective receives:

- the exact canonical patch identity;
- exact verifier, test, registry, layout, and launch-capsule identities;
- producer validation index and process deviation;
- load-custody reconnaissance;
- fifth-audit SEC-02 finding;
- current contracts and non-goals;
- the requirement to preserve disagreements.

Retry one failed perspective once.

Do not silently replace missing required coverage with parent inference.

## 8. Whole-patch authority audit

Audit all 13 patch paths.

Require:

- verifier remains an ES-owned Bounded slice rule;
- output remains structural evidence/projection only;
- no readiness, product, runtime, admission, orchestration, durable-state, or
  execution authority;
- external caller owns source trust;
- verifier owns source/package consistency and structural closure only;
- no source self-certification;
- no repository launcher;
- no runtime caller-supplied layout;
- no product API, schema, route, service, module, or runtime-contract change;
- registry/layout records remain structure-only;
- launch capsule remains source-external validation/provenance evidence;
- launch capsule is not treated as an independent correctness oracle;
- direct-script invocation is explicitly nonqualifying under launch protocol
  v2;
- output schema and tool ID retain their documented meanings.

Generated proof evidence must not become product or run authority by drift.

## 9. Launch-protocol-v2 source audit

Inspect the complete current `verify_v1.py`.

Establish:

- early immutable copies of `sys.orig_argv` and `sys.argv`;
- whether capture occurs before ordinary application imports and logic;
- whether `__file__` presence is captured;
- exact accepted interpreter flag order;
- exact accepted `-c` argv shape;
- exact application argument order;
- explicit `--package-root`;
- direct-script, stdin, `/dev/fd`, symlink-script, reordered, omitted, and
  extra-argument rejection;
- package root physical and lexical equality;
- package root no-symlink ancestry;
- source regular/single-link/no-follow binding;
- canonical UTF-8, no NUL/BOM, terminal LF, and source-size checks;
- exact byte comparison between captured `-c` source and package file;
- registry/layout loading relative to the bound package;
- package/target/candidate disjointness;
- closing source/package identity and ancestry checks;
- canonical error and exit mapping;
- output non-disclosure;
- no self-authentication claim.

Determine whether mutation of live `sys.argv` or `sys.orig_argv` after early
capture can affect the decision.

Determine whether the implementation relies on interpreter spelling in
`sys.orig_argv[0]` as trust; it must not.

## 10. Independent caller construction

Inspect LAUNCH_CAPSULE but do not treat it as an oracle.

Create an audit-owned minimal launch implementation beneath AUDIT_ROOT that
independently performs the frozen caller responsibilities:

- pin interpreter identity;
- no-follow open package/source;
- check physical package/target/candidate separation;
- read exact source bytes;
- compare source bytes to EXPECTED_MANIFEST;
- validate UTF-8, NUL, terminal LF, round trip, size, and local argv capacity;
- build an argv list without shell transformation;
- launch:
  PYTHON -I -S -B -c SOURCE_TEXT ...
- use a private environment and TMPDIR;
- pin expected registry/layout hashes;
- capture child exit/stdout/stderr;
- compare returned registry/layout hashes;
- snapshot target/package/candidate/TMPDIR before and after.

Retain the audit-owned launcher source and hash.

Compare its behavior with LAUNCH_CAPSULE.

Do not place the audit-owned launcher in IMPL_R.

## 11. Independent SEC-02 audit

Run a fresh timed SEC-02 adversarial sequence outside the repository test
wrapper.

At minimum:

1. Create target-contained marker source.
2. Create a mutable external launch path or symlink reproducing the old
   path-based race precondition.
3. Construct source-by-value argv from the externally authenticated package
   source before launch.
4. Perform multiple early and late swaps of the unrelated mutable path.
5. Require:
   - marker source never executes;
   - marker does not appear in stdout or stderr;
   - any pass originates only from the authenticated argv source;
   - package mismatch detected after argv construction rejects or blocks;
   - no forged pass from target-contained code.

Do not claim exhaustive race proof.

Retain every timing attempt.

## 12. Test audit and fresh suite replay

Inspect the complete `test_verify_v1.py`.

Independently discover the final test set.

Expected:

- exactly 88 unique tests;
- identities 01 through 88;
- the two reported one-to-one migrations for tests 60 and 74;
- no silent removal of prior tests.

Audit that the tests independently cover the reported mechanisms, especially:

- direct-script/stdin/FD rejection;
- exact interpreter/app argument order;
- early captured argv;
- package-source exact-byte comparison;
- one-byte mismatch;
- package replacement after argv construction;
- closing race handling;
- caller-side UTF-8/NUL/LF/size/ARG_MAX rejection;
- source/output path nondisclosure;
- SEC-02 target marker nonexecution;
- registry/layout caller hash rejection.

Run the complete suite fresh:

- twice under umask 077;
- twice under umask 022.

Require every owning command:

- exits 0;
- discovers 88 tests;
- has zero failures;
- zero errors;
- zero skips;
- identical identity set;
- creates no repository artifact.

Do not accept a successful inner unittest result when its owning shell command
fails afterward.

## 13. Static and documentation gates

Freshly run:

1. `ast.parse` for verifier and test source.
2. Parse both historical `.py.txt` fixtures without executing them.
3. Strict canonical JSON parsing of registry and all three layouts.
4. Registry-to-layout hash verification.
5. Historical fixture hash verification.
6. Documentation contract review for:
   - launch protocol v2;
   - external caller/verifier responsibility split;
   - source-by-value transport;
   - direct-script nonqualification;
   - unchanged output and structural evidence meaning;
   - no readiness authority;
   - package/target/candidate disjointness;
   - fail-closed capability behavior.
7. Parent-only rooted `git diff --check`.

## 14. Targeted launch causals

Independently run every final positive and negative launch causal, including:

- exact v2 pre-seal pass;
- exact v2 sealed pass;
- direct script reject;
- final-symlink script reject;
- parent-symlink script reject;
- stdin reject;
- `/dev/fd/N` reject;
- missing package root;
- reordered/extra application arguments;
- extra/combined/reordered interpreter options;
- `__file__` present;
- missing isolation/no-site/no-bytecode flags;
- live argv mutation after early capture;
- exact source/package equality;
- one-byte mismatch;
- package replacement after argv construction;
- package/source change or disappearance during checking;
- invalid UTF-8 caller rejection before exec;
- NUL caller rejection before exec;
- missing terminal LF caller rejection before exec;
- Unicode round trip;
- over-limit source caller rejection;
- insufficient local argv capacity;
- target-contained source present but never loaded;
- registry returned-hash mismatch and caller reject;
- layout returned-hash mismatch and caller reject;
- canonical output source/path/hash nondisclosure.

For verifier failures require:

- exact outcome;
- error class;
- exit;
- one canonical stdout line;
- empty stderr;
- no traceback;
- no forbidden path or source leak.

For caller-side rejection require:

- no child launch;
- no child stdout/stderr;
- exact audit-owned caller reason;
- unchanged target/package/candidate.

## 15. Real A6D compatibility

Using the audit-owned caller, run sealed A6D twice.

Require:

- launch protocol v2;
- exact source by value;
- explicit package root;
- pinned registry/layout;
- both exits 0;
- empty stderr;
- byte-identical canonical stdout;
- expected stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- no target/package/TMPDIR mutation;
- A6D manifest unchanged:
  dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9.

Treat this as structural compatibility evidence only.

## 16. Real amendment compatibility

Using the audit-owned caller, run the sealed amendment twice.

Require:

- both exits 0;
- empty stderr;
- byte-identical canonical stdout;
- expected stdout SHA-256:
  be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc;
- no target/package/TMPDIR mutation;
- amendment manifest unchanged:
  a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e.

Treat this as structural compatibility evidence only.

## 17. Synthetic A6 compatibility

Create an audit-owned synthetic A6 fixture using independently inspected test
writer logic.

Run:

1. pre-seal twice through the audit-owned v2 caller;
2. seal only the audit-owned fixture;
3. sealed twice through the audit-owned v2 caller.

Require:

- all exits 0;
- empty stderr;
- deterministic pairwise output;
- target/package/candidate/TMPDIR unchanged by verifier invocation;
- verifier installs nothing;
- fixture removed at cleanup.

## 18. Security and artifact audit

Inspect:

- source transport and argv construction;
- process-list source visibility classification;
- interpreter and package pinning;
- no-follow source/package traversal;
- package/source closing identity;
- target/candidate boundaries;
- registry/layout substitution behavior;
- bounded manifest/file reads;
- exception mapping;
- output minimization;
- no writes;
- no verifier child process;
- no network;
- no target-code import;
- no runtime layout injection;
- no source-hash self-authority.

Scan IMPL_R for:

- `__pycache__`;
- `.pyc`;
- `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixture roots;
- databases;
- journals;
- locks;
- build outputs;
- unexpected executable modes;
- unsupported file types.

Historical fixtures must remain inert.

## 19. Producer-evidence adjudication

Inspect:

- PRODUCER_VALIDATION;
- PRODUCER_INVENTORY;
- PRODUCER_DEVIATION;
- LAUNCH_CAPSULE;
- blocked implementation report evidence available beneath PRODUCER_EVIDENCE.

Require:

- validation records bind final `ed268…` bytes;
- reported 88-test and compatibility results are internally consistent;
- failed and superseded attempts remain distinguished;
- process deviation is disclosed accurately;
- no prior audit is portrayed as qualifying changed bytes;
- launch capsule is treated as producer evidence, not correctness authority;
- no source or authority widening is hidden.

The producer process deviation may remain a nonblocking audit-process finding
when independent provenance and validation succeed.

## 20. Closing provenance

Remove only audit-owned temporary fixtures.

Create a fresh closing provenance continuation beneath AUDIT_ROOT.

Run the exact RECIPE twice.

Require:

- both exits 0;
- stderr empty;
- both outputs byte-identical;
- stdout equals output files;
- outputs equal EXPECTED_MANIFEST;
- manifest SHA-256:
  ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98;
- tracked diff:
  6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7;
- exact opening/closing file identity equality;
- zero staged/deleted/renamed/unmerged;
- no repository or supplied-evidence mutation;
- A6D, amendment, producer evidence, reconnaissance, AUDIT_V5, and candidate
  unchanged.

On mismatch:

AUDIT_PROVENANCE_MISMATCH

## 21. Parent adjudication

After all four perspectives finish:

- preserve disagreements;
- distinguish patch defect, producer-process issue, audit-process issue,
  pre-existing issue, and future hardening;
- reconcile SEC-01 and SEC-02;
- audit the complete 13-path patch;
- do not accept solely because tests pass;
- do not block solely because the producer report’s formal verdict was blocked;
- decide whether the exact current bytes satisfy the repository contract and
  launch-protocol-v2 strategic target;
- perform no repair.

## 22. Finding format

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, pre-existing issue, producer-process issue, or audit-process issue:
Blocking: yes | no

## 23. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use for repository, recipe, manifest, path, classification, mode, size, hash,
diff, or closing-provenance mismatch.

Stop before correctness inspection on opening mismatch.

### REJECT

Use only for a fundamental authority or architecture defect that cannot be
repaired within the bounded tranche.

### BLOCK

Use when a repairable correctness, security, launch-custody, validation,
artifact, evidence, or current-audit-process defect remains.

Do not use BLOCK solely because of the historical producer Git-environment
deviation when current independent audit evidence is complete.

### ACCEPT

Use only when:

- opening and closing provenance match exactly;
- launch protocol v2 is independently source-grounded;
- the audit-owned caller reproduces required behavior;
- SEC-02 is independently closed;
- all prior EV/F mechanisms remain closed;
- all 88-test and targeted causal gates pass;
- real and synthetic compatibility checks pass;
- authority and non-self-verification boundaries remain sound;
- no artifact or current-audit-process blocker remains.

## 24. Required complete inline report

Your final response must contain the complete audit report inline.

Do not replace any section with a link.

Supplemental links may follow the complete report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact audit target and inputs.
4. Opening and closing provenance.
5. Repository identity and 13-path scope.
6. Four perspectives and completion status.
7. Producer blocked-run disposition.
8. Producer Git deviation adjudication.
9. Authority and non-self-verification adjudication.
10. Launch-protocol-v2 source review.
11. Early captured argv review.
12. External caller responsibility review.
13. Verifier consistency responsibility review.
14. Audit-owned caller construction and identity.
15. SEC-02 independent adversarial results.
16. Whole-verifier correctness.
17. Exact test set and all four suite results.
18. Targeted causal results.
19. Real A6D results.
20. Real amendment results.
21. Synthetic A6 results.
22. No-write and deterministic-output evidence.
23. Security, resource, and artifact findings.
24. Producer evidence findings.
25. Closure table for SEC-01, SEC-02, EV-01–EV-09, and F-01–F-04.
26. Severity-ranked residual findings.
27. Minority findings and parent resolution.
28. Uninspected areas and uncertainty.
29. Audit-created path inventory and cleanup.
30. Complete Git-process record.
31. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

An `ACCEPT` result should proceed directly to the exact-byte commit gate. There should be no additional producer replay. The commit gate must regenerate the accepted manifest, stage only the accepted 13 paths, compare staged and committed Git blobs to that manifest, run byte-preserving validation, and perform no implementation repair. 

### Sources

- Codex’s process-boundary stop supplied in this turn.
- Implementation validation and independent audit are distinct stages; audit occurs in a fresh read-only conversation. 
- Audit must reproduce provenance before correctness inspection. 
- Provenance establishes common bytes, not correctness or authority. 
- Proof harnesses and generated evidence must remain non-authoritative. 
- Commit is permitted only after audit acceptance and exact staged/committed blob equality. 

**Confidence**

- Current implementation bytes remain the reported `ed268…` target: **0.98**
- Latest qualification attempt adds no substantive implementation evidence: **0.999**
- Another producer qualification replay would be wasteful: **0.97**
- Fresh independent audit is now the correct gate: **0.995**
- Historical producer Git deviation should be nonblocking if the audit independently reproduces everything: **0.94**
