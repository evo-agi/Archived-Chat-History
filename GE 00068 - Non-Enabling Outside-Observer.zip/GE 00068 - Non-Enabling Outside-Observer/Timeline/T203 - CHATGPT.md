## Assessment

The implementation is **substantively on the right architecture**, but I would not launch the independent audit from this report yet.

The important design work appears correctly implemented:

- Model C atomic bundle-parent publication is combined with the explicit Model E supported-local stable-ancestry premise.
- The repository change stayed within the corrected five-path scope, while `boundaries.md`, the verifier, registry, layouts, and historical fixtures remained unchanged. 
- The private trusted-host contract moved to v2, the caller record moved to v4, and the launch protocol stayed v2.
- The sole commit point is now one exclusive rename of the complete staged bundle directory. Postcommit cleanup and shared-output projection are explicitly non-gating. 
- Exact-final-source A6D, amendment, and synthetic A6 runs passed, as did the repository tests and bundle-publication causals. 

### Two closeout defects should be repaired without changing source

**First, the repository canonical-manifest digest printed in the report is malformed.** The reported value is:

```text
6ca8f5513d9c4bcd8fe930c1f28144e4f7a91abd5445f0dfb94eea30e3ad
```

That is only **60 hexadecimal characters**, not a 64-character SHA-256. The report also does not identify the exact two repository-manifest output paths alongside that value. An independent auditor should not be asked to guess the four missing characters or select a manifest by inference. 

**Second, part of the regression validation does not bind the final caller bytes.** The report candidly says the 12 caller negatives, 31 snapshot cases, and 11 depth cases ran before the final postcommit exception-handling adjustment. That is **54 causals** whose passing results predate the final successor hash. The final bundle causals and eight compatibility runs did use the final source, but the earlier 54 should be rerun rather than left for the auditor to infer as unaffected. 

Neither issue warrants another implementation change. The correct next activity is a **parent-only, read-only closeout addendum** that:

1. produces an exact 64-character repository-manifest hash and names the two fresh manifest paths;
2. reruns the 54 affected causals against exact final successor bytes;
3. rechecks the two crucial postcommit-failure cases;
4. creates new source-external evidence without touching the repository or existing repair root.

After that addendum returns ready, proceed to the fresh independent audit. Commit and A6 restart remain blocked; the report itself confirms that neither an audit nor any publication effect has occurred. 

## Codex prompt — provenance and final-byte validation addendum

```text
MANDATORY RESPONSE FORMAT

Embed the complete report inline in Markdown. Evidence links may be
supplemental, but must not replace any report section.

Return exactly one:

EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_RECONCILED_READY_FOR_AUDIT
EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_BASELINE_MISMATCH
EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_PROVENANCE_AMBIGUOUS
EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_VALIDATION_BLOCKED

PARENT-ONLY, READ-ONLY CLOSEOUT ADDENDUM

This is not implementation and not an independent audit.

Do not edit repository files, source-external caller files, tests, existing
evidence, supplied manifests, or reports. Do not format, clean supplied roots,
stage, commit, push, create a PR, merge, install, deploy, restart A6, invoke
product/live-service paths, contact the network, or create subagents.

The only writes authorized are fresh addendum evidence beneath one newly and
atomically allocated source-external root under `/Users/ds/Downloads`.

## 1. Objective

Resolve two closeout defects in the completed Evidence Verification v1 atomic
bundle v4 implementation without changing implementation bytes:

1. Establish the exact repository provenance target because the inline report's
   repository canonical-manifest value is only 60 hexadecimal characters and
   therefore cannot be a SHA-256 digest.

2. Rerun, against the exact final successor bytes, the 12 caller-negative,
   31 descriptor-snapshot, and 11 depth causals that the implementation report
   says ran before the final postcommit exception-handling adjustment.

Also rerun the key postcommit projection/cleanup causals that establish that a
committed accepted bundle cannot be downgraded by later non-gating failures.

The output of this task is a precise audit-input capsule. It is not an
independent correctness verdict.

## 2. Frozen repository

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Require:

- branch:
  `codex/evidence-verification-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- upstream:
  absent
- governed inventory:
  exactly 477 objects
- working status:
  exactly four modified tracked paths and nine untracked paths;
  zero staged, deleted, renamed, or unmerged paths
- no cache, bytecode, test cache, generated repository manifest, or unexplained
  ignored artifact
- final full-index tracked binary-diff SHA-256:
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`
- five-path implementation delta SHA-256:
  `c676ce5dcedb36fdf66cb3fafff9f89c32c0e151e94818aa6e59cf6df284b69f`

Every Git invocation must use:

git -C "$IMPL_R" ...

with Git-child cwd exactly IMPL_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Stop with
`EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_BASELINE_MISMATCH`
on any mismatch.

## 3. Frozen implementation evidence

REPAIR_V4_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr

FINAL_CALLER=$REPAIR_V4_ROOT/source/launch_v4_trusted_host_atomic_bundle.py

Require final caller:

- size:
  49047 bytes
- SHA-256:
  `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`

Require base caller:

- path:
  `$REPAIR_V4_ROOT/source/base_v3_atomic_publish_exact.py`
- size:
  45678 bytes
- SHA-256:
  `3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631`

Require source delta:

- path:
  `$REPAIR_V4_ROOT/provenance/source-delta.diff`
- SHA-256:
  `53dd0f4d0bc7a41584b76fa530afbdf40aabbe219aecd4c7a0c90989307d8bca`

Require both repair manifests to be canonical and byte-identical, SHA-256:

`78499711a01ac70a60613b139daf36b25d512d3d121543d5f0dfb94eea30e3ad`

Verify the repair-root inventory, modes, link counts, path closure, empty private
temporary directories, and the retained validation/output-root inventory
without changing any supplied object.

The existing validation output root is read-only for this task:

OUTPUT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-bundle-output-9228k2d1

Do not write another bundle there.

## 4. Atomically allocate the addendum root

Only after the opening gates pass:

- set umask 077;
- use Python `tempfile.mkdtemp`;
- allocate one direct physical directory beneath `/Users/ds/Downloads` with
  prefix:

  `ES-evidence-verification-v1-atomic-bundle-v4-closeout-addendum-643fc7d12dd2-`

Call it ADDENDUM_ROOT.

Require:

- direct physical directory;
- effective-user ownership;
- mode 0700;
- no symlink component.

All retained files must be regular, single-link, mode 0600. All retained
directories must be mode 0700. Keep its private TMPDIR empty at closeout.

## 5. Exact provenance recipe and repository-manifest reconciliation

Use the unchanged exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Require:

- regular, single-link file;
- size 5143 bytes;
- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
- recipe ID:
  `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`

Run the exact recipe twice from IMPL_R with pinned Python 3.13.4, `-I -B`,
bytecode disabled, C locale, and fresh distinct continuation/output paths under
ADDENDUM_ROOT.

Requirements:

- both owning commands exit 0;
- stderr is empty;
- stdout equals its output file for each run;
- the two canonical manifests are byte-identical;
- the canonical digest is exactly 64 lowercase hexadecimal characters;
- each manifest has exactly the live 13-path set;
- every path classification, type, mode, size, and SHA-256 matches the live
  repository;
- branch, HEAD, upstream, and tracked binary-diff fields are exact;
- the tracked binary-diff field equals
  `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`;
- the final five changed repository paths agree with the retained
  `$REPAIR_V4_ROOT/provenance/repository-scope.json` and
  `$REPAIR_V4_ROOT/provenance/repository-five-path-delta.diff`.

Retain:

- exact recipe source identity;
- both argv vectors;
- cwd and complete controlled environment;
- exits;
- complete stdout and stderr hashes and sizes;
- both exact output paths;
- the exact 64-character canonical-manifest SHA-256;
- complete canonical manifest bytes.

Explicitly state that the implementation report's 60-character printed value
was a report transcription defect if, and only if, the two fresh exact recipe
outputs establish one unambiguous manifest.

If the recipe source, output selection, or manifest identity is ambiguous,
return
`EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_PROVENANCE_AMBIGUOUS`
without source inspection or validation claims.

## 6. Final-source causal reruns

The implementation report states that these ran before the final postcommit
exception-handling adjustment:

- 12 caller-negative cases;
- 31 descriptor-snapshot cases;
- 11 depth cases.

Rerun all 54 against bytes whose SHA-256 is exactly:

`643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`

Do not invent or approximate the retained tests. Inspect the repair root's:

- `validation/summary.json`
- final attempt index
- test-source inventory
- causal records
- semantic crosswalk
- exact command/result records

and select the retained final test sources and command shapes that generated
the reported 12/31/11 groups.

If those retained records do not unambiguously identify exact test source,
argv, expected identities, and outcomes, return
`EVIDENCE_VERIFICATION_V1_ATOMIC_BUNDLE_V4_CLOSEOUT_PROVENANCE_AMBIGUOUS`.

Execution rules:

- use pinned Python 3.13.4 with `-I -S -B`;
- use `PYTHONDONTWRITEBYTECODE=1`;
- use a private ADDENDUM_ROOT TMPDIR;
- import only an ADDENDUM_ROOT byte-exact copy of FINAL_CALLER when test hooks
  require import;
- verify the copy's SHA-256 before every owning test group;
- do not import from or create bytecode beneath REPAIR_V4_ROOT or IMPL_R;
- fixtures and outputs must remain beneath ADDENDUM_ROOT;
- no supplied-root cleanup.

Require:

- exactly 12 caller-negative identities;
- exactly 31 snapshot identities;
- exactly 11 depth identities;
- 54 expected outcomes;
- zero unexpected pass;
- zero unexpected rejection;
- zero failure, error, or skip;
- exact expected error classifications where the retained test contract names
  one;
- stable and canonical output where required;
- no watched-root write;
- no process, descriptor, stage, or fixture survivor.

## 7. Final postcommit behavior reruns

Against the exact final caller bytes, independently rerun at least:

1. shared-stdout projection failure after a successful directory commit;
2. postcommit descriptor-cleanup failure after a successful directory commit;
3. any retained postcommit hook case used by the final exact bundle causals.

For each require:

- the complete v4 bundle was atomically committed first;
- the final directory and its exact three files remain present and unchanged;
- canonical JSON says `outcome="accepted"` with empty errors;
- no stage remains;
- no foreign bundle is adopted;
- the owning caller process retains the documented successful disposition;
- the injected postcommit exception is contained;
- no postcommit pathname recheck or durability check downgrades acceptance;
- shared output, when successfully emitted, contains only the documented four
  projection fields;
- a projection write failure does not corrupt the bundle.

These are source-external validation causals, not product runs.

## 8. Existing final-source compatibility evidence

Do not rerun or modify the existing A6D, amendment, or synthetic validation
bundles in OUTPUT_ROOT.

Read-only verify that the retained final compatibility record:

- binds final caller SHA-256
  `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`;
- contains two accepted A6D runs;
- contains two accepted amendment runs;
- contains two accepted synthetic pre-seal and two accepted synthetic sealed
  runs;
- records the expected canonical verifier stdout hashes;
- records exact v4 schema and 25-field set;
- records exact three-file bundle publication and no stage;
- records equal watched snapshots;
- records the mandatory stable-ancestry and interpreter-custody nonclaims.

Do not promote producer compatibility evidence into independent qualification.

## 9. Closing gates

At closeout:

- rerun repository identity, status, full 477-object inventory, diff digest, and
  `git diff --check`;
- rerun complete read-only repair-root and output-root inventories;
- require every supplied root unchanged;
- require ADDENDUM_ROOT private modes and complete path inventory;
- remove only ADDENDUM_ROOT temporary fixtures created by this task;
- require private TMPDIR empty;
- require no process or descriptor survivor;
- create two byte-identical canonical addendum manifests, self-excluding only
  their own two files if necessary;
- include exact path, type, mode, size, link count, and SHA-256 for every other
  retained file.

## 10. Required inline report

Include:

1. Verdict.
2. Opening repository and supplied-root identities.
3. Fresh ADDENDUM_ROOT identity.
4. Exact final caller identity.
5. Exact recipe identity and both invocations.
6. Exact two repository-manifest paths.
7. Exact corrected 64-character canonical-manifest SHA-256.
8. Disposition of the malformed 60-character report value.
9. Complete final 13-path manifest.
10. Final tracked binary-diff SHA-256.
11. Exact 12 caller-negative identities and results.
12. Exact 31 snapshot identities and results.
13. Exact 11 depth identities and results.
14. Proof all 54 ran against exact final source bytes.
15. Postcommit shared-output-failure result.
16. Postcommit cleanup-failure result.
17. Other final postcommit causal results.
18. Read-only compatibility-record verification.
19. No-write and cleanup evidence.
20. Opening and closing repository/supplied-root equality.
21. Addendum evidence inventory and two canonical manifests.
22. Provenance confidence.
23. Validation confidence.
24. Implementation confidence remains for independent audit.
25. Explicit confirmations:
    - repository mutation not performed;
    - implementation/source mutation not performed;
    - supplied-evidence mutation not performed;
    - independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - subagents created: 0.

Do not claim ACCEPT, commit readiness, or A6 readiness.
```

## Current disposition

- **Architecture and implementation direction:** correct.
- **Repository/source mutation:** complete.
- **Fresh independent audit:** not ready to start from the current report because the repository-manifest hash is malformed.
- **Final-source regression binding:** incomplete for 54 retained causals.
- **Next step:** the read-only closeout addendum above.
- **Commit and A6 restart:** blocked.

### Sources

The implementation reports completion and identifies the exact five-path scope and unchanged verifier/data surfaces.  

The directory commit point and postcommit non-gating model match the frozen design. 

The printed repository-manifest value is malformed, while the report separately provides a valid repair-manifest digest. 

The report explicitly discloses that 54 regression causals ran before the final caller adjustment. 

**Confidence**

- Architecture and five-path implementation scope are correct: **0.97**
- The printed repository-manifest hash is invalid: **1.00**
- A read-only closeout addendum should precede audit: **0.98**
- No further source edit is presently justified: **0.95**
- Commit and A6 restart must remain blocked: **0.999**
