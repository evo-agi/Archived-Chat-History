## Engineering assessment

The stale launch-profile bindings are corrected, qualified, and superseded cleanly. All four root inventories now agree across certificate v5, runtime authority v2, and two independent live projections; the correction did not change argv, cwd, environment, split-root lifecycle, preflight, framing, process posture, or authorization-consumption semantics. :chatgpt-content-reference{index="0"}

The correction path itself closed:

- both builder and independent-validator sources compiled and passed static qualification;
- the 61-case correction matrix passed with zero false outcomes, skips, or exceptions;
- the independent successor-authority validator returned zero errors;
- platform preflight passed under the unchanged execution controls;
- profile-v4 and certificate-v5 Build A/B outputs were byte-identical;
- certificate-input validation passed all 21 checks. :chatgpt-content-reference{index="1"}

Exactly one current launch profile and one current launch certificate now exist. Certificate v5 owns exactly one active, unconsumed real-audit authorization; certificate v4 and all earlier launch artifacts are historical and hold no active authorization. :chatgpt-content-reference{index="2"}

### Current launch-authority artifacts

```text
/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json
```

- device/inode: `16777234 / 182800237`
- mode/link count: `0400 / 1`
- size: `12,763`
- SHA-256: `d31ad9f854399f62dcc484f235f707ec3daaf8ad23e123a5e4600ef74cbcafab`

```text
/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json
```

- device/inode: `16777234 / 182800243`
- mode/link count: `0400 / 1`
- size: `34,814`
- SHA-256: `f753ed8adfbee2ff122fe63f54fbcaca833ca1694e6f284baf0edba018f9211a` :chatgpt-content-reference{index="3"}

No real audit ran and no subject verdict was issued. :chatgpt-content-reference{index="4"}

## Progression decision

Execute exactly **one** real audit now.

There is no remaining justification for another launch-profile, certificate, input-role, audit-source, package, construction, or reconciliation tranche before process creation.

The wrapper must use the corrected canonical root bindings in profile v4 and certificate v5. It must preserve the qualified split-root lifecycle: an existing wrapper workspace as `cwd`, and its absent `audit-capsule` child as `--output-root`.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE REAL INDEPENDENT AUDIT OF THE UNCHANGED
REPLACEMENT GENERATION-2 SCHEMA SUBJECT

USING SUCCESSOR AUDIT PYZ V2, RUNTIME AUTHORITY V2,
CURRENT LAUNCH PROFILE V4, AND CURRENT LAUNCH CERTIFICATE V5

Objective

Execute exactly one real independent audit of:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Use these exact current artifacts:

1. successor independent-audit PYZ v2;
2. successor runtime authority v2;
3. current external launch profile v4;
4. current external launch certificate v5;
5. unchanged replacement subject;
6. replacement construction wrapper;
7. current content bundle and content authority;
8. accepted implementation authority chain.

Profile v4 and certificate v5 are the sole current external launch authority.

Profile v3, certificate v4, and all earlier launch artifacts are historical and
must not contribute execution controls or authorization.

Exactly one real-audit authorization is active and unconsumed.

Authenticate all current authority before allocating any wrapper workspace or
creating a process.

Use the exact qualified split-root lifecycle:

- allocate an existing wrapper-owned workspace;
- submit that workspace as cwd;
- derive the exact absent child:
  <workspace>/audit-capsule;
- pass that absent child as `--output-root`;
- do not precreate the child;
- require the frozen audit runtime to create it;
- require the terminal frame and capsule records to bind that child, not the
  workspace.

Execute the governed platform preflight exactly once.

Then execute the real audit parent exactly once.

Capture top-level process creation and completion exactly.

After completion:

- retain raw streams before parsing;
- parse only under the current framing contract;
- authenticate only the profile-derived capsule child;
- inspect the capsule read-only;
- independently authenticate its substantive result and terminal closure;
- retain the raw harness disposition;
- issue the corresponding wrapper verdict;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute qualification, rehearsal, or synthetic mode.

Do not launch a replacement, recovery, continuation, post-failure validator, or
second audit parent.

Do not run another direct subject auditor outside the frozen harness.

Do not execute subject source.

Do not rerun construction.

Do not promote or rebind current schema authority.

Do not combine audit with authority promotion.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

Return exactly one wrapper primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

Retain the exact raw harness disposition separately.

Map only the exact current governed dispositions. Expected mapping:

SUBJECT_AUDIT_ACCEPT
→ GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

SUBJECT_AUDIT_BLOCK
→ GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

SUBJECT_AUDIT_PROVENANCE_MISMATCH
→ AUDIT_PROVENANCE_MISMATCH

If current runtime authority binds different exact disposition tokens, use
those exact tokens and retain the explicit mapping. Do not normalize an unknown
token.

If any prelaunch gate fails before audit-parent process creation, return:

AUDIT_PROVENANCE_MISMATCH

and explicitly state:

REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
CURRENT_REAL_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. SUCCESSOR AUDIT PYZ V2
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_AUDIT_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit-v2.pyz

Expected identity:

- device:
  16777234;
- inode:
  182785051;
- mode:
  0400;
- link count:
  1;
- size:
  4216423;
- SHA-256:
  d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19.

──────────────────────────────────────────────────────────────────────────────
2. SUCCESSOR RUNTIME AUTHORITY V2
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_RUNTIME_AUTHORITY_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.authority-v2.json

Expected identity:

- device:
  16777234;
- inode:
  182785057;
- mode:
  0400;
- link count:
  1;
- size:
  47750;
- SHA-256:
  64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec.

──────────────────────────────────────────────────────────────────────────────
3. CURRENT LAUNCH PROFILE V4
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_PROFILE_V4:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json

Expected identity:

- device:
  16777234;
- inode:
  182800237;
- mode:
  0400;
- link count:
  1;
- size:
  12763;
- SHA-256:
  d31ad9f854399f62dcc484f235f707ec3daaf8ad23e123a5e4600ef74cbcafab.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT LAUNCH CERTIFICATE V5
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_CERTIFICATE_V5:

/Users/ds/Downloads/ES-repair10i-v3-audit-launch-profile-binding-correction-output-bxpo6kwq/gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json

Expected identity:

- device:
  16777234;
- inode:
  182800243;
- mode:
  0400;
- link count:
  1;
- size:
  34814;
- SHA-256:
  f753ed8adfbee2ff122fe63f54fbcaca833ca1694e6f284baf0edba018f9211a.

──────────────────────────────────────────────── LIMITED TO LINEAGE
────────────────────────────────────────────────

5. HISTORICAL PROFILE V3 AND CERTIFICATE V4

HISTORICAL_PROFILE_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.launch-profile-v3.json

Expected SHA-256:

c5707b91fbf8e05f5bb926f01c93d65791386e9dc1ba08924d11659cf66298fa

HISTORICAL_CERTIFICATE_V4:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.launch-certificate-v4.json

Expected SHA-256:

b98a9f32d89ba69c14050e1fd6194a8a981c4007ad063eb54e2aae43a21f79b5

Open them only when certificate-v5 lineage validation requires external bytes.

Require:

- profile v3 current:
  false;
- certificate v4 current:
  false;
- their active authorization count:
  zero;
- their mutation:
  forbidden.

Do not use their stale root-inventory bindings or execution authority.

Do not add them to the wrapper fixed-input set when certificate v5 closes their
lineage internally.

──────────────────────────────────────────────────────────────────────────────
6. REPLACEMENT SUBJECT
──────────────────────────────────────────────── LIMITED TO AUDIT TARGET
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234;
- inode:
  182649818;
- mode:
  0700;
- UID/GID:
  501/20.

Expected canonical inventory SHA-256:

eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

Expected closure:

- 73 entries including root;
- 12 directories;
- 61 regular files.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

Expected manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Authenticate through:

- certificate v5;
- authority v2;
- two stable no-follow live inventory projections;
- subject temporal inventory and manifests.

Require all current subject identities and canonical inventory bindings to
agree.

Open only this exact root.

Do not scan for another subject.

──────────────────────────────────────────────── LIMITING CONSTRUCTION PROVENANCE
────────────────────────────────────────────────

7. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234;
- inode:
  182648782;
- mode:
  0700;
- UID/GID:
  501/0.

Expected canonical inventory SHA-256:

9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e

Authenticate only the current chain necessary to establish:

- replacement-subject allocation;
- accepted implementation use;
- construction authorization and consumption;
- production-parent custody;
- subject terminal closure;
- no second construction;
- pending-independent-audit posture.

Require certificate-v5, authority-v2, and two live projections to agree on the
current inventory binding.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING ACCEPTED IMPLEMENTATION
────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234;
- inode:
  182593190;
- mode:
  0700.

Expected canonical inventory SHA-256:

3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234;
- inode:
  182593189;
- mode:
  0700.

Expected canonical inventory SHA-256:

6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only:

- accepted reconstruction-parent implementation;
- accepted production source and freeze;
- construction contract;
- implementation package unsuperseded;
- replacement construction used the accepted parent.

Require certificate-v5, authority-v2, and two live projections to agree on both
root bindings.

Do not re-audit the implementation package.

Require opening/closing equality.

────────────────────────────────────────────────

9. CURRENT CONTENT INPUTS

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234;
- inode:
  181651092;
- mode:
  0400;
- link count:
  1;
- size:
  13598758;
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671.

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234;
- inode:
  181651098;
- mode:
  0400;
- link count:
  1;
- size:
  19737;
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563.

Authenticate the content authority before interpreting the ZIP.

Require:

- exact bundle identity;
- 479 members;
- eight current roles;
- deterministic closure;
- no `.DS_Store`.

──────────────────────────────────────────────── LIMITING CURRENT AUTHORITY
────────────────────────────────────────────────

10. STABLE PRELAUNCH AUTHENTICATION

Before allocating wrapper or workspace roots, authenticate:

- successor PYZ v2;
- runtime authority v2;
- current profile v4;
- current certificate v5;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Open historical profile/certificate only when required by certificate-v5
external lineage validation.

For every file:

- no-follow open;
- regular-file check;
- governed mode and link count;
- device/inode/size/SHA-256;
- two stable byte and metadata reads.

For every root:

- exact identity;
- two complete canonical no-follow inventory projections;
- equality of the two projections;
- equality with the current certificate/authority binding.

Strict-parse all authority JSON using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any prelaunch predicate fails:

- do not allocate wrapper/workspace roots;
- do not execute platform preflight;
- do not create the audit parent;
- return:
  AUDIT_PROVENANCE_MISMATCH;
- state:
  REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED;
- state:
  CURRENT_REAL_AUDIT_AUTHORIZATION_NOT_CONSUMED.

────────────────────────────────────────────────

11. CURRENT AUTHORITY CLOSURE

Validate profile v4 and certificate v5 under their exact schemas.

Require exact agreement among:

- successor PYZ v2;
- authority v2;
- profile v4;
- certificate v5;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content inputs;
- successor source freeze;
- package member registry;
- ten-role subject audit-dependency registry;
- compatibility preflight;
- qualification results;
- split-root policy;
- framing contract.

Require:

- profile v4 current:
  true;
- certificate v5 current:
  true;
- every predecessor profile/certificate current:
  false;
- every predecessor active authorization:
  zero;
- certificate-v5 active authorization:
  one;
- total active future authorization:
  one;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Require all four corrected root-inventory bindings to match current canonical
projections.

Any discrepancy:

- do not launch;
- return provenance mismatch;
- authorization remains unconsumed.

────────────────────────────────────────────────

12. SUCCESSOR PYZ MEMBER CLOSURE

Parse successor PYZ v2 directly.

Require exact correspondence with:

- authority v2;
- profile v4;
- certificate v5;
- embedded member registry.

Derive exact member count and registry count from current authority.

Do not substitute a predecessor package count.

Require:

- exact member set;
- exact non-self registry closure;
- raw UTF-8 sorted names;
- ZIP_STORED;
- governed timestamps and Unix metadata;
- member mode 0600;
- no duplicate;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no comment or uncontrolled extra;
- no cache or bytecode;
- no historical source.

Authenticate current embedded roles for:

- entrypoint;
- successor source freeze;
- source registries;
- ten-role subject dependency registry;
- semantic input resolver;
- compatibility preflight;
- exact 15/14 model;
- 946 and 137 vocabularies;
- total documentary checking;
- dual-oracle contract;
- occupancy vocabulary;
- confirmation contract;
- terminal-capsule lifecycle;
- no-VCS contract;
- qualification and rehearsal results;
- post-package qualification;
- frozen-package requalification;
- future invocation contract.

Any discrepancy:

- do not launch;
- return provenance mismatch.

────────────────────────────────────────────────

13. WRAPPER EVIDENCE ROOT AND SPLIT-ROOT WORKSPACE

After Sections 10–12 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Use the exact profile-v4 wrapper-evidence policy.

B. FRESH_PRIVATE_AUDIT_WORKSPACE

Use the exact profile-v4 workspace policy.

Immediately retain:

- absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty inventory.

Derive the exact capsule child according to profile v4.

Require:

- workspace exists;
- workspace is empty;
- capsule child is absent;
- wrapper did not create the child;
- no scan or fallback;
- no alternate candidate.

Use:

- workspace as submitted cwd;
- absent child as `--output-root`.

On prelaunch failure:

- retain evidence;
- remove only wrapper-owned empty roots after identity revalidation;
- observe ENOENT twice;
- authorization remains unconsumed.

After audit-parent process creation:

- authorization is consumed;
- preserve workspace and capsule regardless of outcome.

────────────────────────────────────────────────

14. PLATFORM-CAPTURE PREFLIGHT

Execute exactly once under profile v4.

Do not reconstruct the preflight from profile v3 or an earlier prompt.

Retain:

- requested and resolved interpreter identities;
- exact argv;
- cwd;
- submitted environment;
- process posture;
- PID;
- start/completion;
- raw streams;
- sizes and SHA-256;
- exit/signal;
- reaping;
- descriptor closure.

Require exact profile-v4 preflight fields.

Require after preflight:

- workspace remains empty;
- capsule child remains absent.

If preflight fails:

- do not create the audit parent;
- authorization remains unconsumed;
- return provenance mismatch;
- do not retry.

────────────────────────────────────────────────

15. EXACT REAL-AUDIT INVOCATION

Derive exact argv exclusively from:

- profile v4;
- certificate v5;
- runtime authority v2;
- successor embedded invocation contract.

Do not copy predecessor argv when any current field differs.

Require current bindings for:

- successor PYZ v2;
- runtime authority v2;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- workspace cwd;
- absent capsule-child output root;
- submitted environment;
- process posture.

Do not pass profile v4 or certificate v5 to the harness unless the exact current
CLI explicitly requires it.

Immediately before process creation:

- reauthenticate every fixed input;
- reauthenticate workspace;
- require workspace empty;
- require capsule child absent.

Launch exactly once, synchronously.

The certificate-v5 authorization is consumed only when process creation
succeeds.

After successful creation, consumption is final regardless of disposition.

Do not launch:

- qualification;
- rehearsal;
- synthetic mode;
- replacement or recovery parent;
- continuation;
- post-failure validator;
- second audit.

────────────────────────────────────────────────

16. TOP-LEVEL PROCESS CUSTODY

Retain before parsing:

- custody ID;
- process-creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- cwd;
- environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and SHA-256;
- exit;
- signal;
- process error;
- reaping;
- descriptor closure;
- fixed-input identities at launch;
- workspace identity;
- capsule-child absence at launch.

The wrapper is authoritative for process creation and completion.

If completion custody is missing:

- authorization remains consumed;
- do not scan for another capsule;
- do not retry;
- return provenance mismatch.

────────────────────────────────────────────────

17. STREAM AND TERMINAL-FRAME PARSING

Retain raw streams before parsing.

Parse only under the current profile-v4/certificate-v5/runtime-authority framing
contract.

Require:

- governed handled-terminal stream posture;
- one terminal frame;
- no trailing bytes;
- strict UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact current frame schema;
- exact raw harness disposition;
- exact capsule-root binding;
- exact closure fields.

Require:

terminal-frame capsule root
=
profile-v4-derived capsule child.

If the process exits under an unhandled-failure posture:

- return provenance mismatch;
- do not scan for another capsule;
- preserve workspace and any capsule child;
- do not retry.

────────────────────────────────────────────────

18. CAPSULE-ROOT AUTHENTICATION

Authenticate only the profile-v4-derived capsule child.

Require:

- absent before launch;
- created only after process creation;
- exact governed relationship to workspace;
- directory;
- no symlink;
- mode 0700;
- terminal-frame equality;
- capsule records bind the same root;
- workspace is not treated as capsule root.

Do not scan or select another path.

Failure forces provenance mismatch.

────────────────────────────────────────────────

19. READ-ONLY CAPSULE INSPECTION

Inspect only the authenticated capsule root.

Do not modify, clean, chmod, resume, execute capsule source, execute subject
source, launch another validator, or regenerate evidence.

Resolve authoritative records only through:

- terminal frame;
- capsule path/role registry;
- capsule indexes;
- manifests;
- exact evidence pointers.

Authenticate:

- successor source identities and freeze;
- no-VCS posture;
- ten-role subject-input resolution;
- no acceptance-bearing direct subject path;
- exact 15/14 model;
- complete 946 and 137 vocabularies;
- subject terminal closure;
- normative contract;
- schema roles and families;
- Draft 2020-12 results;
- witness rows;
- complete 946 rows;
- complete 137 rows;
- dual-oracle crosswalk;
- 766/333 field map;
- documentary validators;
- confirmation derivation;
- occupancy/lineage/producer status;
- findings and repair owners;
- A00–A15;
- child custody;
- cleanup;
- supplied-root equality;
- temporal inventory;
- manifests;
- final reprojection;
- physical topology;
- A15/closure agreement;
- seal/no-postseal result.

────────────────────────────────────────────────

20. DIRECT BLOCKER STANDARD

A raw terminal disposition indicating subject BLOCK may be promoted to:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when every direct blocker contains:

- exact failed witness or case row;
- non-null direct evidence;
- governing contract/schema/specification pointer;
- primary repair owner;
- exact repair surface;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is allowed.

For 946- or 137-suite blockers, require exact failed per-case rows.

A required semantic input role may be a direct package blocker only when:

- its role is authenticated as governed and required;
- absence is independently established;
- package ownership is exact;
- no resolver ambiguity or provenance defect exists.

Derivative confirmations are not separate direct blockers.

Any:

- unhandled exception;
- resolver ambiguity;
- unauthenticated role;
- dual-oracle disagreement;
- invalid outcome projection;
- incomplete direct evidence;
- hard-coded confirmation;
- occupancy-role defect;
- capsule-closure defect;

forces:

AUDIT_PROVENANCE_MISMATCH

rather than subject BLOCK.

────────────────────────────────────────────────

21. CAPSULE TERMINAL CLOSURE

Authenticate:

- temporal inventory;
- manifest A;
- manifest B;
- A/B byte equality;
- independent final reprojection;
- root row exactly once;
- no physical empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- directory/file modes 0700/0600;
- no cache or bytecode;
- A15 status equals final closure result;
- one seal transition;
- no filesystem/process/validation operation after seal.

A terminal frame alone is insufficient.

Failure forces provenance mismatch and prevents promotion of an embedded ACCEPT
or BLOCK.

────────────────────────────────────────────────

22. WRAPPER FIXED-INPUT CLOSING EQUALITY

After process completion, repeat opening/closing authentication for every fixed
input actually opened:

- successor PYZ v2;
- authority v2;
- profile v4;
- certificate v5;
- historical launch artifacts only when externally opened for lineage;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Require:

- exact fixed-role set;
- one row per role;
- no missing or extra row;
- every row passes.

For the four roots, use the canonical inventory algorithm bound by profile v4
and certificate v5.

Do not mutate any supplied input.

Failure forces provenance mismatch.

────────────────────────────────────────────────

23. FINAL VERDICT RULES

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- all fixed inputs authenticate;
- current authority closes;
- all four canonical root bindings agree;
- preflight passes;
- audit process custody completes;
- terminal framing passes;
- capsule provenance passes;
- ten-role input resolution closes;
- subject terminal closure passes;
- exact 15/14 model passes;
- all schemas pass Draft 2020-12;
- all witness rows pass;
- all 946 rows pass;
- all 137 rows pass;
- dual oracles agree;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy/lineage/status close;
- no direct subject blocker remains;
- cleanup/equality/capsule closure pass;
- wrapper closing equality passes.

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- at least one direct subject blocker exists;
- every blocker satisfies Section 20;
- findings and dependencies are complete;
- cleanup/equality/capsule closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input or current-authority mismatch;
- root-inventory mismatch;
- preflight failure;
- process-custody loss;
- framing/root failure;
- subject drift;
- source/toolchain/freeze failure;
- resolver ambiguity or unauthenticated role;
- unhandled exception;
- oracle exception or disagreement;
- invalid outcome projection;
- incomplete direct evidence;
- hard-coded confirmation;
- occupancy-role defect;
- cleanup inequality;
- supplied-root inequality;
- capsule-closure failure;
- A15/closure contradiction;
- postseal activity;
- wrapper closing-equality failure.

Do not retry.

────────────────────────────────────────────────

24. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all current and historical launch artifacts;
- preserve workspace and capsule;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

25. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact wrapper verdict
2. Exact raw harness disposition
3. Successor PYZ identity
4. Authority-v2 identity
5. Profile-v4 identity
6. Certificate-v5 identity
7. Historical launch-lineage posture
8. Replacement-subject identity and canonical inventory
9. Construction-wrapper identity and canonical inventory
10. Accepted implementation-root identities and canonical inventories
11. Content identities
12. Stable prelaunch authentication
13. Current authority closure
14. Current PYZ/member closure
15. Wrapper-root identity
16. Workspace identity
17. Capsule-child absence proof
18. Platform preflight
19. Exact audit argv/cwd/environment
20. Top-level process custody
21. Raw streams
22. Exit/signal
23. Terminal frame
24. Capsule-root authentication
25. Successor source/freeze/no-VCS posture
26. Ten-role subject-input resolution
27. Subject terminal closure
28. Normative contract
29. Fifteen schema roles
30. Fourteen generated families
31. Role/family mapping
32. Draft 2020-12
33. Contract-witness rows
34. Schema-witness rows
35. Witness aggregate
36. Complete 946 result
37. Exact failed 946 rows if any
38. Complete 137 result
39. Exact failed 137 rows if any
40. Dual-oracle crosswalk
41. 766/333 field map
42. Documentary-validator closure
43. Confirmation derivation
44. Derivative-confirmation ledger
45. Occupancy, lineage, and producer status
46. Findings
47. Repair-owner registry
48. Dependency graph
49. A00–A15
50. Child custody
51. Audit cleanup
52. Capsule supplied-root equality
53. Wrapper fixed-input equality
54. Audit temporal identity
55. Audit manifest identities
56. A/B equality
57. Final reprojection
58. Physical topology/modes
59. A15/closure agreement
60. Seal/no-postseal result
61. Confirmation subject unchanged
62. Confirmation no authority promotion
63. Confirmation no product/runtime/target/A6 activity
64. Remaining uncertainty/nonclaims
65. Explicit wrapper confirmations

Required confirmations:

SUCCESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED
SUCCESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED
CURRENT_PROFILE_V4_IDENTITY_MATCHED
CURRENT_CERTIFICATE_V5_IDENTITY_MATCHED
PROFILE_V3_NOT_CURRENT
CERTIFICATE_V4_NOT_CURRENT
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_INVENTORY_BINDING_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
CONSTRUCTION_WRAPPER_INVENTORY_BINDING_MATCHED
ACCEPTED_IMPLEMENTATION_AUDIT_ROOT_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_INVENTORY_BINDING_MATCHED
ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_WRAPPER_INVENTORY_BINDING_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
CURRENT_LAUNCH_AUTHORITY_COHERENT
CURRENT_PYZ_MEMBER_SET_CLOSED
WRAPPER_WORKSPACE_ALLOCATED
WRAPPER_WORKSPACE_EMPTY_BEFORE_LAUNCH
CAPSULE_CHILD_ABSENT_BEFORE_LAUNCH
WRAPPER_DID_NOT_PRECREATE_CAPSULE_ROOT
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PREFLIGHT_WORKSPACE_REMAINED_EMPTY
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE
CURRENT_REAL_AUDIT_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
REHEARSAL_MODE_NOT_EXECUTED
SYNTHETIC_MODE_NOT_EXECUTED
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_PROFILE_DERIVED_CAPSULE_CHILD
SUCCESSOR_CLEAN_SOURCE_FREEZE_AUTHENTICATED
NO_GIT_OR_VCS_INVOCATION
SUBJECT_INPUT_ACCESS_SET_10_COMPLETE
SUBJECT_INPUT_ACCESS_EQUAL_DEPENDENCY_REGISTRY
NO_ACCEPTANCE_BEARING_DIRECT_SUBJECT_PATH_LITERAL
NO_UNHANDLED_ENOENT
SUBJECT_TERMINAL_REPROJECTION_PASSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

## Sources and confidence

The attached report establishes exact four-way agreement on all corrected root inventories, bounded profile/certificate deltas, deterministic successor artifacts, independent validation, one active unconsumed authorization, supplied-input equality, and successful cleanup. :chatgpt-content-reference{index="5"}

It expressly confirms that no real audit or subject verdict occurred. :chatgpt-content-reference{index="6"}

**Provenance confidence:** 0.999  
**Launch-profile correction confidence:** 0.999  
**One-audit readiness confidence:** 0.999  
**Replacement-subject acceptance confidence before audit:** 0.00
