Here is Codex's response:

PREFLIGHT\_PROVENANCE\_MISMATCH

1. **Primary verdict** — Repair-package closure failed. The required temporal inventory and terminal manifest pair are absent, while an undeclared bytecode-cache directory remains. The retained [preterminal verdict record](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/closeout/primary-verdict.json) explicitly says terminal closure was pending and therefore is not authoritative.
2. **Fresh repair-root identity** — [Repair root](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli): device/inode `16777234/180115518`, mode `0700`.
3. **Failed target-audit identity** — Device/inode `16777234/180052628`, mode `0700`; 86-entry opening/closing digest `54688f952abc68128b8d983168974bce60dc75cc715ded9ac40e663d91143ea6`. Historical evidence only; unchanged.
4. **Reconciliation identity** — Device/inode `16777234/180074421`, mode `0700`; 30-entry closure digest `8b444c6a245e66c989be20312f29cf89d00beca7a70438692a872a224629a3cd`. Governing harness-defect classification authenticated.
5. **Target identity and closure** — Device/inode `16777234/178948757`, mode `0700`; 70 entries, exact opening/closing equality, digest `0ed16aef919f6a93023b596450650ee42d4d15799624b72930feec9a8d2ad0c2`.
6. **V2 audit identity and closure** — Device/inode `16777234/178646858`, mode `0700`; 218 entries, exact closure digest `3fbe88885ff70cc498b3fe31c859f1e0901a9e4871aec2bcccb25a78b2cdca36`; target-grammar digest `d724b872ca99a7339f05c9dcd94318fbce0d1e69e8b24b736dbc6f0aab1f33e3`.
7. **Accepted bootstrap identities** — Bootstrap: `16777234/179405897`, 1,209 entries. Bootstrap audit: `16777234/180047263`, 197 entries. Both mode `0700` and exactly equal at closing.
8. **Original target-audit source identity** — [Exact retained copy](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/opening/original-target-audit-payload.py): 165,052 bytes, SHA-256 `5dfd0d9a77ed0dcae6c4a32954916f607ac582fcbb453e5955da6adfb701528f`, mode `0600`, single link.
9. **Repaired target-audit source identity** — [Frozen source](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/source/target_audit_payload_v2.py): device/inode `16777234/180125885`, 203,704 bytes, SHA-256 `3528fc8b06665c4a1ec18a12b6ae0e0bbd0c1496767420139627d8064af7ee42`, mode `0600`, single link.
10. **Exact semantic delta** — [Delta record](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/exact-semantic-delta-v1.json) passes: 12 hunks, 77 protected shared functions unchanged, all exact operands preserved, and no substantive target-audit semantic change.
11. **Authoritative support-binding policy** — Only `opening/accepted-opening-gate-v2.json#/complete_opening_inventories/<role>` is authoritative. Diagnostic, adoption, report, lineage, supersession, historical, smallest-object, filename, and first-match fallbacks are rejected.
12. **Support-binding mutation matrix** — [25/25 cases passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/support-binding-mutation-matrix-v1.json), with zero false acceptance, false rejection, reason mismatch, or skip.
13. **Support-binding live replay** — [Passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/support-binding-live-replay-v1.json): exact gate, pointer, inventory, live identity, membership, and digest; zero ambiguity and no writes.
14. **Finalizer process-authority split** — Platform transcript owns process creation and termination; capsule owns invocation, self-start, preseal state, closeout, temporal inventory, manifests, failure outcome, and marker contract.
15. **Finalizer invocation contract** — Exact pinned Python, `-I -S -B`, source identity, argv, cwd, environment, `/dev/null` stdin, outputs, exit behavior, operands, failure behavior, and no-write-after-seal are bound.
16. **Finalizer self-start contract** — Source, argv, cwd, environment, flags, PID, invocation-contract identity, root identity, timestamp, and stdin posture are required without claiming top-level process authority.
17. **Premanifest empty-directory policy** — The repaired logic accepts only `[]` or `["manifest"]`; absent-creatable and present-empty reserved manifest states pass, while unrelated empties fail.
18. **Preseal-ready nonauthority** — Qualification verified `authoritative=false`, `terminal_success=false`, and no completion or terminal-closure claim.
19. **Temporal inventory policy** — The policy and synthetic qualification passed, but the repair package’s required `closeout/temporal-final-inventory-v1.json` is absent.
20. **Manifest generation and read-back** — Synthetic success qualification proved independent generation, exclusive writes, fsync, no-follow read-back, identity verification, equality, and reprojection. The repair package itself has neither canonical manifest A nor B.
21. **Terminal empty-directory policy** — The present root has no empty directory, symlink, special object, or multiply linked file. Terminal closure nevertheless fails because required terminal paths are missing and `source/__pycache__` has mode `0755`, not `0700`.
22. **Terminal-seal control flow** — AST and bytecode analyses prove one false-to-true transition and only marker output plus immediate exit afterward. The repair package never reached that transition.
23. **Failure-outcome treatment** — Qualification verified explicit unsealed failure outcomes with exception, operation, source line, written paths, manifest posture, intended nonzero exit, and no success claim.
24. **Finalizer mutation matrix** — [32/32 cases passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/finalizer-mutation-matrix-v2.json), with zero errors or skips.
25. **Independent finalizer validator** — [Passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/independent-finalizer-validator-v1.json) without importing the repaired source or first matrix helper.
26. **Successful finalization causal** — Passed using a synthetic root: exit `0`, exact terminal marker, empty stderr, equal manifests, successful reprojection, and no postseal write.
27. **Failure qualification causals** — Unrelated empty directory, B-write failure, generator mismatch, and post-preseal-ready failure all failed closed with explicit outcomes.
28. **Direct-finalizer process custody** — [Five launches](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/qualification/direct-finalizer-process-custody-v1.json) retained exact argv, cwd, environment, PID, streams, exit, duration, reaping, and descriptor closure. Fixture and variant roots were removed and observed `ENOENT` twice.
29. **Retained failed-audit replay** — [Passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/retained-failed-audit-replay-v1.json); no target verdict or supplied-root write occurred.
30. **Compilation and static gates** — Pinned-Python compilation passed with exit `0`, empty streams, and unchanged source. AST, call-graph, bytecode, and exception-table analyses agree.
31. **Frozen exported package identities** — All seven exported files remain byte-for-byte equal to their frozen identities:
    - Payload: 203,704 bytes, `3528fc8b…7ee42`
    - Target-audit plan: 8,544 bytes, `5ea0060b…0e00`
    - Binding policy: 4,051 bytes, `0cc44dc9…a87d`
    - Finalizer lifecycle: 2,261 bytes, `73f30bed…fef8`
    - Process custody: 1,068 bytes, `b9e3ccd4…7bd7`
    - Carrier template: 2,941 bytes, `89bb7eb2…20e7`
    - Invocation template: 3,557 bytes, `569509be…0dab`
32. **Freeze-record identity** — [Freeze record](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/opening/target-audit-harness-freeze-v1.json): 12,063 bytes, SHA-256 `d37288c835598be83841c58163847817da333c08c38df8cd6f3edd2584f98e1a`.
33. **Frozen-package requalification** — [Recorded requalification passed](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/validation/frozen-harness-requalification-v1.json), and the seven frozen exports remain exact. That result cannot cure the later package-namespace closure defect.
34. **Supplied-root closing equality** — [All nine inputs closed exactly equal](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli/closing/supplied-root-closing-equality-v1.json), including launcher `16777234/179032804`, import reconciliation `16777234/179045387`, and pinned Python `16777234/2301718`.
35. **Repair-package inventory and manifests** — Read-only terminal inspection found 54 retained paths: 10 directories and 44 regular files. Missing are the temporal inventory, reserved `manifest/` directory, and both canonical manifests. Extra paths are `source/__pycache__` and its `.pyc`; the cache directory is mode `0755`. No corrective writes were made after detection.
36. **Confirmation real target audit did not run** — No real Carrier 0003 target adjudication, real-capsule finalizer, Plan V3/V4, runtime validation, repository test, product code, live service, or A6 activity occurred.
37. **Remaining uncertainty and nonclaims** — The package is unsealed and must not be used for a fresh audit. No target verdict, deployment/readiness claim, runtime-currentness claim, or target/bootstrap repair authority is asserted.
38. **Explicit confirmations** — The retained confirmation JSON says 49/49 true, but it is preterminal and unauthenticated because the terminal pair is absent. Final task-level disposition is:
```
FAILED_TARGET_AUDIT_ROOT_MUTATION_NOT_PERFORMED=PASS
TARGET_ROOT_MUTATION_NOT_PERFORMED=PASS
V2_INDEPENDENT_AUDIT_ROOT_MUTATION_NOT_PERFORMED=PASS
ACCEPTED_BOOTSTRAP_ROOT_MUTATION_NOT_PERFORMED=PASS
ACCEPTED_BOOTSTRAP_AUDIT_ROOT_MUTATION_NOT_PERFORMED=PASS
QUALIFIED_LAUNCHER_ROOT_MUTATION_NOT_PERFORMED=PASS
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED=PASS
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED=PASS
EXACT_BASE_TARGET_AUDIT_SOURCE_VERIFIED=PASS
ORIGINAL_TARGET_AUDIT_SOURCE_BYTES_PRESERVED=PASS
REPAIR_BOUNDED_TO_BINDING_AND_FINALIZER_LIFECYCLE=PASS
SUBSTANTIVE_TARGET_AUDIT_SEMANTICS_UNCHANGED=PASS
AUTHORITATIVE_OPENING_BINDING_PATH_FIXED=PASS
DIAGNOSTIC_REPRODUCTION_RECORD_REJECTED_AS_AUTHORITY=PASS
SUPPORT_BINDING_MUTATION_MATRIX_PASSED=PASS
SUPPORT_BINDING_LIVE_REPLAY_PASSED=PASS
RESERVED_MANIFEST_DIRECTORY_ALLOWED_PREMANIFEST=PASS
UNRELATED_EMPTY_DIRECTORY_REJECTED=PASS
PREMATURE_SUCCESS_AUTHORITY_REMOVED=PASS
PRESEAL_READY_RECORD_NONAUTHORITATIVE=PASS
MANIFEST_A_READ_BACK_VERIFIED=QUALIFICATION_PASS_FINAL_PACKAGE_NOT_ESTABLISHED
MANIFEST_B_READ_BACK_VERIFIED=QUALIFICATION_PASS_FINAL_PACKAGE_NOT_ESTABLISHED
MANIFEST_PAIR_BYTE_EQUALITY_VERIFIED=QUALIFICATION_PASS_FINAL_PACKAGE_NOT_ESTABLISHED
TERMINAL_EMPTY_DIRECTORY_CHECK_PASSED=QUALIFICATION_PASS_FINAL_PACKAGE_NOT_ESTABLISHED
TERMINAL_SEAL_STATE_UNIQUE=PASS
NO_POSTSEAL_FILESYSTEM_WRITE=PASS
FINALIZER_FAILURE_OUTCOME_EXPLICIT=PASS
DIRECT_FINALIZER_PROCESS_AUTHORITY_SPLIT_FROZEN=PASS
FINALIZER_MUTATION_MATRIX_PASSED=PASS
INDEPENDENT_FINALIZER_VALIDATOR_PASSED=PASS
SUCCESSFUL_FINALIZATION_CAUSAL_PASSED=PASS
FAILURE_FINALIZATION_CAUSALS_PASSED=PASS
DIRECT_FINALIZER_PROCESS_CUSTODY_COMPLETE=PASS
RETAINED_FAILED_AUDIT_REPLAY_PASSED=PASS
REPAIRED_TARGET_AUDIT_SOURCE_COMPILED_SUCCESSFULLY=PASS
STATIC_TARGET_AUDIT_GATES_PASSED=PASS
FROZEN_TARGET_AUDIT_PACKAGE_CREATED=PASS
FROZEN_TARGET_AUDIT_PACKAGE_NOT_MODIFIED_AFTER_FREEZE=EXPORT_IDENTITIES_PASS_PACKAGE_CLOSURE_FAILED
FROZEN_TARGET_AUDIT_PACKAGE_REQUALIFIED=PASS
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED=PASS
REAL_TARGET_AUDIT_NOT_EXECUTED=PASS
TARGET_BYTES_NOT_MODIFIED=PASS
ACCEPTED_BOOTSTRAP_BYTES_NOT_MODIFIED=PASS
RUNTIME_VALIDATION_NOT_RERUN=PASS
NO_NETWORK_CONTACT=PASS
NO_GIT_INVOCATION=PASS
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION=PASS
NO_A6_ACTIVITY=PASS
NO_SUBAGENTS_CREATED=PASS
```
