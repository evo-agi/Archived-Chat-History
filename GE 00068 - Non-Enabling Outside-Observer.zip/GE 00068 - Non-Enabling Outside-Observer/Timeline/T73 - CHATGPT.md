A5P2 is a clean implementation success. It closes the validation-substrate blocker without widening repository or product authority:

- The retained-slave deadlock is eliminated by closing runner aliases **after peer-bound, role-specific acknowledgment and before process completion**.
- `LOCAL_PEERPID` was validated against live process identity rather than assumed from the OS version.
- Direct `/dev/ptmx` allocation, unrelated-terminal access, broad device grants, and undeclared PTY use remain denied.
- The new ownership model distinguishes runner aliases, child-owned descriptors, process epochs, literal ioctl grants, and sentinel PTYs.
- Both openpty and forkpty paths have real EOF/hangup evidence, exact close cardinality, cleanup, and external recomputation.
- The current A5T repository bytes passed the bounded capability integration and failed as expected without the capability.
- Repository bytes remained unchanged at `T=ab646e5a…`, while A5P2 is independently sealed at `T=ff7a4688…`.

The next critical path is therefore exactly what the A5P2 closeout says: **start a new A5T validation/closure child and rerun the entire A5T gate from the beginning.** Do not resume the old A5T child, and do not move to A5C yet.

A5P2 remains implementation evidence rather than independent acceptance. Its bounded integration cannot replace the freshly materialized downstream repository control; the earlier sealed A2 closeout states that boundary explicitly.  Implementation validation and independent audit also remain separate engagement types. 

Pass this to Codex:

```text
Permission is workspace-write for a new source-external evidence child only.

Objective

Freshly validate, close out, and seal the already implemented Repair 10I-A5T
repository test-fixture repair using the sealed Repair 10I-A5P2 successor.

The live repository already contains the exact two-file A5T patch:

- remote_alpha_operator_test.go
- es/runtimehelper/supervisor_test.go

Do not edit those files or any other repository file in this turn.

Run the complete A5T validation program from newly materialized private source
controls using the sealed A5P2 runner, its active v3/v2/v1 schema dialect, and
explicit finite PTY command policies.

The old failed A5T child remains immutable, unsealed negative evidence. Do not
resume, overwrite, seal, or promote it.

This is a parent-only validation and evidence-closeout turn.

Do not implement A5C.
Do not restart the A6 policy-evidence refresh.
Do not implement A6 or start B6.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole evidence writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 product predecessor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5S predecessor successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Sealed A5P reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66

Sealed A5P2 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p2-successor-closure-ab646e5a0e66

Failed old A5P implementation, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66

Failed old A5T child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t-test-fixture-closure-e260e1bb5ac4

Failed A6 policy-evidence refresh, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required new A5T validation child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t2-test-fixture-closure-ab646e5a0e66

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- inventory size:
  54314
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the complete repository delta from sealed A5 to be exactly these two
existing files:

1.
remote_alpha_operator_test.go

- logical mode:
  100644
- size:
  333580
- SHA-256:
  f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578

2.
es/runtimehelper/supervisor_test.go

- logical mode:
  100644
- size:
  5293
- SHA-256:
  842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226

Require:

- zero additions;
- zero deletions;
- zero renames;
- zero mode changes;
- every other 387 repository tuple byte- and mode-identical to sealed A5.

Require exact sealed A5:

- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact sealed A5P2:

- manifest SHA-256:
  67002939082d25a46ec50fdb4a5725e936816ea930e6ed9ac684608238a833a4
- manifest size:
  114860
- payloads:
  613
- directories:
  112
- source T:
  ff7a4688b1244277eccc8eee26b57eb4f0858d01
- source inventory:
  a17d8e3d5925b17d2eda187a51953dcf0d171d81d5e5409ea70827d92a6cda2e
- members:
  12

A5P2 binaries:

repair10-runner:
  153013c19a717a37a677c0c5fa4e91837c78ccc16db909a9b1e360ff2efb483d

repair10-compare:
  d09e0e0d510872fb457f1308219f471bcbd147c7fc6d4a19da29a026182055a3

repair10-semantic:
  25893d292a20e0af99e494779802dbd73c1fe1e180f3c9e2873c5ea52e86d325

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the complete A5P2 active dialect:

Outer v3:

- execution-substrate.repair10i.suite-spec.v3
- execution-substrate.repair10i.ab-suite-spec.v3
- execution-substrate.repair10i.command-intent.v3
- execution-substrate.repair10i.command-result.v3
- execution-substrate.repair10i.terminal-reconciliation.v3
- execution-substrate.repair10i.suite-result.v3
- execution-substrate.repair10i.binding-recomputation.v3
- execution-substrate.repair10i.control-qualification.v3
- execution-substrate.repair10i.semantic-comparison-spec.v3
- execution-substrate.repair10i.semantic-comparison-result.v3
- execution-substrate.repair10i.semantic-comparison-custody.v3

Private PTY v2:

- execution-substrate.repair10i.private-pty-command.v2
- execution-substrate.repair10i.private-pty-broker-journal.v2
- execution-substrate.repair10i.private-pty-allocation.v2
- execution-substrate.repair10i.private-pty-reconciliation.v2

Unchanged v1:

- execution-substrate.repair10i.control-observation.v1
- execution-substrate.repair10i.mutable-inventory.v1
- execution-substrate.repair10i.effective-read-policy.v1
- execution-substrate.repair10i.intentional-mutant-provenance.v1
- execution-substrate.repair10i.go-test-semantics.v1
- execution-substrate.repair10i.byte-capture.v1
- execution-substrate.repair10i.byte-comparison-spec.v1
- execution-substrate.repair10i.byte-comparison-result.v1

Require A5P2’s complete read-only post-seal verification to reproduce.

Require exact sealed A5S and A5P reconnaissance identities.

Require the failed old A5P, failed old A5T, failed A6 refresh, and all earlier
sealed and unsealed lineage to remain byte-exact.

Require the new A5T2 child to be absent.

Stop on any mismatch:

REPAIR10I_A5T2_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create the A5T2 child exclusively under umask 077.

Use exactly:

opening/
tool/
commands/
controls/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, with intended mode 0600 or 0700.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy the sealed A5P2 A and B binaries independently into private tool roots.

Require:

- origin-to-copy byte equality;
- side-A/side-B byte equality;
- all copied binary inodes distinct;
- link count one;
- expected mode;
- no shared writable tool state.

No repository file may be edited.

## 3. A5P2 input hard gate

Before any repository command:

1. Verify all 12 A5P2 source members.
2. Verify the exact five-file A5S→A5P2 delta.
3. Verify all four A5P2 binary identities.
4. Reopen the live `LOCAL_PEERPID` preflight evidence.
5. Reopen the openpty and forkpty acknowledged-handoff controls.
6. Reopen:
   - retained-parent-slave vulnerable causal;
   - repaired EOF causal;
   - early-close mutant;
   - retained-alias mutant;
   - duplicate-child-alias rejection;
   - direct `/dev/ptmx` denial;
   - unrelated-terminal denial;
   - external requalification;
   - cleanup and two absence epochs.
7. Require the exact parent disposition invariant:
   - slave close exactly once;
   - master close exactly once;
   - both before acceptance;
   - both before process wait;
   - no retry;
   - no raw terminal payload retained.
8. Require old A5S and failed-A5P schema records to remain nonqualifying on
   active A5P2 paths.

Stop on any A5P2 identity or hard-gate mismatch:

REPAIR10I_A5T2_SUCCESSOR_INPUT_MISMATCH

## 4. Source-line and semantic-compatibility gate

Before launching repository tests, inspect the final two-file A5T patch against
the exact A5P2 semantic grammar.

Retain:

- every exact source-line-bound A5P2 grammar that refers to either changed
  repository file;
- current path, package, test, subtest, and source line;
- whether the A5T patch shifted that line;
- whether the diagnostic remains reachable;
- whether the grammar still matches exactly.

Require:

- all relevant active templates remain valid; or
- a formerly matched fixture-failure diagnostic is now absent because the
  repaired test reaches its intended assertion.

No generic source-line normalization is permitted.

If a new unknown diagnostic or active exact-line incompatibility is found,
stop:

REPAIR10I_A5T2_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

Do not repair the successor here.

## 5. Exact test identities

The five repaired tests are:

1.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand

2.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection

3.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure

4.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution

5.
execution-substrate/es/runtimehelper /
TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir

Require pinned-Go discovery to list all five exactly once.

Require no test-level skip.

## 6. Exact PTY policy derivation

Before each PTY-capable command, derive an exact finite request inventory from:

- active test discovery;
- the exact repository helper call graph;
- the sealed A5P2 bounded integration records.

Retain:

- command ID;
- selected test identities;
- PTY roles;
- exact count by role;
- `max_total_pairs`;
- controlling-terminal requirement;
- descriptor-mapping and stream mode;
- source evidence supporting each request.

Do not infer capability from command name, package, test name, argv, or
environment.

Do not adaptively widen counts after a run.

A runtime request outside the predeclared role/count inventory is a blocking
failure.

Every command without PTY use must omit the capability entirely.

## 7. Three disjoint targeted controls

Create three physically independent repository controls.

Each control independently owns:

- no-hardlink source copy;
- private Git administration and object store where required;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- command/evidence roots;
- runtime roots;
- broker sockets and PTY resources.

No mutable state may be shared.

Use intentionally long outer control roots sufficient to reproduce the old
socket-length risk while the repaired actual socket paths remain compact.

### Root/operator command

Run in each control:

go test -json -count=3 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure)$'

Use the exact explicit A5P2 PTY policy derived for the command.

### Runtimehelper command

Run in each control:

go test -json -count=3 -p=1 -parallel=1 ./es/runtimehelper \
  -run '^TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir$'

This command must receive no PTY capability unless source inspection proves a
request. Do not infer one.

For all three controls require:

- all five tests pass three times;
- 45 total passing test executions across the three controls;
- zero test-level skips;
- complete JSONL and terminals;
- every actual Unix-socket path is at most 100 bytes;
- listener setup succeeds;
- old socket `EINVAL` diagnostics are absent;
- all five intended assertions are reached;
- root/operator commands complete peer-bound PTY acknowledgment;
- runner master/slave aliases close before process wait;
- real helper EOF/hangup is observed;
- no direct child PTY allocation succeeds;
- no unrelated terminal is accessible;
- complete PTY and ordinary resource reconciliation;
- two absence epochs per control;
- opposite A5P2 side external requalification passes.

## 8. No-capability negative

Run the four root/operator tests once under an otherwise equivalent private
control without any PTY capability.

Require:

- repaired listener setup succeeds;
- actual socket paths remain at most 100 bytes;
- all four tests fail at the expected default-denied PTY boundary;
- zero PTY descriptors are acquired by the command;
- direct `/dev/ptmx` remains denied;
- terminal and resource reconciliation completes;
- no survivor or residue remains.

This negative must not contribute to readiness beyond proving default denial.

## 9. Boundary and isolation controls

Run and require pass:

go test -json -count=1 -p=1 -parallel=1 ./internal/testsupport

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRepair10ControlRootPolicyV1|TestRepair10ValidationIsolationASTV1|TestRepair10ExplicitStartInventoryV1)$'

Retain or freshly prove:

- complete socket path of exactly 100 bytes is admitted;
- 101 bytes is rejected before `net.Listen`;
- every physical socket is beneath an owned compact root;
- no shared `/tmp` mutation root is introduced;
- no unmanaged listener is introduced;
- no raw `Cmd.Start` is introduced;
- logical remote path remains exactly:
  `/run/spire/server/private/api.sock`;
- no production fixed slot or PackageFloor is contacted;
- cleanup errors are test failures.

## 10. Socket negative controls

Require visible, fail-closed behavior for:

- wrong socket basename;
- wrong endpoint role;
- wrong containing-root role;
- wrong logical remote prefix;
- wrong path topology;
- wrong address family where the existing fixture supports it;
- missing compact parent;
- source is a directory;
- source is a regular file;
- reused live socket collision;
- bind at a 101-byte complete path;
- rebind before listener close/removal;
- missing socket;
- multiple source sockets.

Require valid rebind only after complete listener close and path removal.

Do not canonicalize any of these failures.

## 11. Targeted race controls

Using the pinned race toolchain and race-only read policy, run:

go test -race -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure)$'

with the exact explicit A5P2 PTY policy.

Also run:

go test -race -json -count=1 -p=1 -parallel=1 ./es/runtimehelper \
  -run '^TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir$'

Require:

- all five tests pass;
- zero required skips;
- zero race reports;
- zero survivor;
- zero forced cleanup;
- complete PTY and ordinary resource reconciliation;
- two absence epochs.

## 12. Syntax, format, diff, module, and vet gates

Run:

- pinned `gofmt -d` on exactly:
  - remote_alpha_operator_test.go
  - es/runtimehelper/supervisor_test.go
- require empty output;
- `git diff --check`;
- `/bin/bash -n` on protected public scripts whose bytes must remain unchanged;
- `go mod verify` from a complete private offline cache;
- `go vet ./...`.

Require all to pass.

Do not run a general formatting sweep.

## 13. Broader affected-package validation

Run through A5P2 with exact finite PTY policy only where required:

1. Complete runtimehelper package:

go test -json -count=1 -p=1 -parallel=1 ./es/runtimehelper

2. Affected root/operator family including:

- the four repaired tests;
- nearby vault/bootstrap recovery tests;
- PTY/forkpty signal and ordering tests;
- Repair 10I setpgid tests;
- operator facade signal test;
- structural isolation guards.

Use a source-grounded exact `-run` expression and retain it literally.

Require:

- repaired tests pass;
- no new required skip;
- no unknown diagnostic;
- no source-line incompatibility;
- no PTY policy request outside the declared inventory;
- inherited unrelated failures remain explicit if the selected family includes
  them.

## 14. Complete private repository suite

Create one new complete, private, no-hardlink source control bound to:

- T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership:
  389

Before launch, produce and seal within the control:

- exact active test inventory;
- exact PTY-capable test/helper call graph;
- exact finite PTY role/count declaration;
- proof that every non-PTY command/test receives no implicit capability.

Run literal:

go test -json -count=1 -p=1 -parallel=1 ./...

through one A5P2 side.

Use the opposite A5P2 side for external raw re-extraction and control
qualification.

Expected process exit membership:

{0,1}

Exit membership alone does not qualify the control.

Require:

- containment enforced;
- complete raw stdout/stderr through EOF;
- one Wait;
- complete terminal reconciliation;
- complete resource disposition;
- no forced cleanup;
- no survivor;
- no malformed/truncated JSONL;
- no duplicate or missing package/test terminal;
- semantic integrity pass;
- zero unknown diagnostics;
- producer and opposite-side canonical semantics byte-equal;
- producer and opposite-side qualification both `qualified`;
- logical suite fingerprint bound;
- PTY policy fingerprint bound;
- every declared PTY request consumed exactly;
- no undeclared PTY request;
- direct child `/dev/ptmx` remains denied;
- unrelated terminal remains inaccessible;
- parent aliases close before process wait;
- actual helper EOF/EIO records reconcile;
- two cleanup epochs;
- verified-empty next-command barrier.

The five repaired tests must pass.

The seven previously required A5 tests must retain their expected outcomes:

- TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
  one_pipe_closes_first
- TestRepair10IDualSetpgidRaceReconciliationV1
- TestRepair10ISetpgidFailureRequiresExactGroupProofV1
- TestRepair10ISetpgidInverseMutantsV1
- TestRepair10IStructuralPrivacyProjectionCausalControlsV1
- TestRemoteAlphaExternalTLST2APRepair10Contract
- TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2

Require the five old socket-`EINVAL` fixture diagnostics to be absent.

Inherited unrelated repository failures remain failures and must be reported.
Do not describe the suite as green unless it is actually green.

This single full-suite control is A5T implementation validation only.

Do not compare it against a second control.
Do not derive the A6 historical policy from it.

## 15. Artifact, security, and privacy controls

Require:

- no `.out` traversal or write;
- no repository-local validation artifact;
- no live PackageFloor or fixed-runtime slot access;
- no credential, keychain, TLS, SPIFFE, Vault, private endpoint, or unrelated
  user-data exposure;
- no raw PTY payload retained;
- no broad terminal-device rule;
- no source absolute path leaked into public records;
- retained evidence contains only safe metadata and bounded diagnostics.

Build outputs, if any arise incidentally, must stay private and be removed.

Do not run Linux binaries.

## 16. Evidence requirements

Retain:

- complete opening identity and lineage verification;
- exact A5P2 input hard gate;
- source-line compatibility record;
- exact PTY request inventories;
- all private source inventories and T values;
- every suite specification;
- every command intent;
- exact argv, cwd, and bounded environment;
- rendered sandbox profiles and effective policies;
- raw stdout/stderr through EOF;
- command results;
- terminal reconciliations;
- PTY broker journals;
- owner-generation and disposition records;
- external qualifications;
- socket-path length and role records;
- negative and boundary controls;
- race records;
- broader package/family records;
- complete full-suite records;
- failed and superseded attempts;
- source/admin closing verification;
- cleanup and two absence epochs;
- implementation-validation report;
- exact path/mode/size/hash inventory.

Do not copy raw terminal payload into evidence.

## 17. Closeout and sealing

Require:

- repository T remains:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- repository inventory remains:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership remains:
  389 / 375 / 14
- exact two-file delta remains unchanged;
- every other 387 source tuple remains byte- and mode-identical;
- branch/HEAD/parent/HEAD tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged remain zero;
- A5, A5S, A5P reconnaissance, A5P2, failed A5P, failed A5T, failed A6, and
  every named predecessor remain unchanged;
- no predecessor bytecode/cache is created;
- no private source, Git store, Go cache, runtime root, PTY, process/group,
  worker, broker socket, listener, descriptor, build, or report root remains;
- two fresh zero-observation epochs pass.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification of:

- path set;
- file types;
- modes;
- sizes;
- hashes;
- link counts;
- directory modes;
- source T/inventory;
- A5P2 input identities;
- repository identity;
- predecessor identities;
- final absence state.

## 18. Mandatory stop conditions

Stop immediately on:

- baseline or lineage mismatch;
- repository byte change;
- need for a third repository file;
- need for A5P2 source change;
- active source-line grammar incompatibility;
- any repaired test still fails in fixture setup;
- actual socket path exceeds 100 bytes;
- listener setup fails;
- intended assertion is bypassed;
- PTY policy count or role mismatch;
- implicit PTY capability;
- direct child PTY allocation succeeds;
- unrelated terminal becomes accessible;
- parent alias remains open after acknowledged handoff;
- missing real EOF/EIO evidence;
- raw PTY payload retained;
- required test skip;
- race report;
- unknown diagnostic;
- malformed/incomplete semantic stream;
- incomplete terminal/resource reconciliation;
- survivor or forced cleanup;
- full-suite external qualification failure;
- cleanup or sealing failure.

## 19. Verdicts

Opening mismatch:

REPAIR10I_A5T2_BASELINE_MISMATCH

A5P2 input mismatch:

REPAIR10I_A5T2_SUCCESSOR_INPUT_MISMATCH

A5P2 semantic/source-line compatibility expansion required:

REPAIR10I_A5T2_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

Repository test or validation repair required:

REPAIR10I_A5T2_SOURCE_OR_TEST_REPAIR_REQUIRED

Complete validation and seal:

REPAIR10I_A5T_SOCKET_FIXTURE_REPAIR_SEALED_READY_FOR_A5C

The success report must include:

1. Opening and closing repository T/inventory.
2. Exact two-file delta.
3. A5P2 source, manifest, and binary identities.
4. Source-line compatibility result.
5. Old and new socket-path lengths.
6. Proof all five tests reached their intended assertions.
7. Three-control/count-three outcomes.
8. Race outcomes.
9. Boundary and negative-control outcomes.
10. PTY role/count and broker-custody results.
11. Full-suite source and semantic identities.
12. Full-suite producer and peer qualification.
13. Five repaired-test outcomes in the full suite.
14. Confirmation the five old socket-EINVAL diagnostics disappeared.
15. Inherited full-suite failures and skips, without reclassification as
    success.
16. Manifest SHA-256, size, and payload count.
17. Cleanup and two final absence epochs.
18. Explicit statement that A5C was not started and the A6 refresh was not
    restarted.

No A5C.
No A6.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A5T seals, the next tranche is the already frozen **A5C observability-duration semantic amendment**. Only after A5C seals should the two-control A6 policy-evidence refresh restart from fresh materializations.

Changed bytes require fresh validation and later a fresh independent audit; a prior audit cannot remain binding after repair.  Provenance can establish that A5P2 and the A5T repository patch are the intended bytes, but it does not establish that the PTY protocol or socket-fixture repair is correct. 

### Sources

- Codex’s `REPAIR10I_A5P2_ACKNOWLEDGED_PTY_HANDOFF_PATCH_SEALED_READY_FOR_FRESH_A5T_RESTART` report in the current turn.
- Sealed Repair 10I-A2 non-substitution boundary. 
- Governed Execution implementation versus independent-audit boundary. 
- Governed Execution repair and re-audit protocol. 
- Governed Execution provenance limitations. 

**Confidence:** 0.995 that A5P2 clears the only known A5T validation-substrate blocker; 0.98 that the next correct gate is a completely fresh A5T validation child; 0.95 that the current two-file repository patch should now pass the full A5T gate under explicit A5P2 capability; 0.995 that A5C and A6 must remain later, separate gates.
