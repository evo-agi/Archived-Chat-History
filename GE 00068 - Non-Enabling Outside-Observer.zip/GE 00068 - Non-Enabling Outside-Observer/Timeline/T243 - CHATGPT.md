## Assessment

This gate behaved correctly after its own checker failed:

- The opening provenance passed.
- The **single staging operation was substantively correct**: six modified files and one added file, with no unrelated path staged.
- The failure was an **audit-owned validator defect**. Git’s name-status output is lexicographically ordered; it has no obligation to preserve the order of the `git add` arguments.
- Codex restored only the seven index entries, verified the index was clean, and returned the repository to the exact opening state.
- No staged tree, validation result, or commit exists.

Unlike the previous gate, **the prompt was not wrong**. It required an exact path set and classifications, not argument-order preservation. Codex introduced an extra invalid invariant locally.

No implementation repair or new independent audit is warranted. The accepted audit still applies to the exact repository bytes and reports no substantive residual finding.  Its opening and closing checks also established the exact candidate inventory and no repository mutation.  

The next attempt should be a **fresh parent-only commit gate**. The important procedural improvement is that audit-owned checker defects may be repaired and rerun against the same unchanged staged index. A checker bug should not automatically destroy a correct staging result.

## Prompt for Codex

```text
Perform a fresh parent-only commit gate for the independently accepted Repair
10I A6 successor-governance freeze.

This prompt supersedes both previous commit-gate attempts.

Do not create subagents.

PRIMARY OBJECTIVE

Stage, independently validate, and commit exactly the seven accepted paths:

- six tracked modifications;
- one added path that is currently nonignored and untracked.

Return exactly one primary verdict:

REPAIR10I_A6_SUCCESSOR_GOVERNANCE_COMMITTED
COMMIT_GATE_PROVENANCE_MISMATCH
COMMIT_GATE_BLOCKED

IMPORTANT CORRECTION TO THE LAST ATTEMPT

Git output order is not an acceptance condition.

For every staged-path, status, or blob comparison:

- parse records into a map keyed by exact repo-relative path;
- compare exact path sets, classifications, modes, sizes, and hashes;
- do not compare Git output ordering with `git add` argument ordering;
- canonicalize retained reports by sorting paths lexicographically only after
  parsing them.

The prior v2 gate correctly staged the seven paths but failed because its
audit-owned checker imposed an invalid order requirement. Treat that gate as
nonqualifying historical evidence.

──────────────────────────────────────────────────────────────────────────────
1. AUTHORIZED EFFECTS
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read the repository and the named evidence roots;
- create one fresh private commit-gate evidence root;
- create and repair audit-owned checker scripts inside that root;
- stage the exact seven paths once;
- rerun audit-owned checks against the same staged index when a checker itself
  fails;
- materialize the exact staged Git tree outside the repository;
- run the bounded offline validation below;
- create exactly one normal Git commit with the exact subject below.

Not authorized:

- editing, formatting, repairing, regenerating, or normalizing repository
  bytes;
- staging any path outside the seven-path set;
- reset, amend, rebase, revert, cherry-pick, merge, stash, or a second commit;
- deleting or cleaning pre-existing repository or supplied-evidence objects;
- push, upstream creation, PR, merge, installation, deployment, or A6;
- product or live-service invocation;
- network contact;
- subagents.

AUDIT-OWNED CHECKER FAILURE RULE

A failure caused solely by an audit-owned parser, reporter, order assumption,
or checker implementation is not a substantive gate failure.

When such a failure occurs:

1. retain the failed checker source, command, output, and adjudication;
2. prove that repository bytes and the staged index remain unchanged;
3. correct only the audit-owned checker beneath the fresh gate root;
4. rerun it against the same staged index;
5. do not repeat `git add`.

Restore the index and stop only on a substantive target, staged-blob,
validation, provenance, or artifact mismatch—or if staging/index integrity can
no longer be proved.

──────────────────────────────────────────────────────────────────────────────
2. REPOSITORY AND EXPECTED OPENING STATE
──────────────────────────────────────────────────────────────────────────────

Repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected opening identity:

- physical device/inode: 16777234 / 122118502
- branch: codex/remote-alpha-external-tls-status-observation-v1
- HEAD: 567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree: b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent: 05dde14d185b6e022dcc169ef1a658a97961850f
- upstream: absent
- governed files: 389
- tracked/untracked: 375 / 14
- directories: 93
- tracked modifications: 22
- staged/deleted/renamed/unmerged: 0 / 0 / 0 / 0
- source T: f276536fea579d0842cda43b0290656b200b7f27
- inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

The prior v2 gate reports that it restored the index and reproduced this exact
opening state. Verify it independently; do not trust the report as a substitute
for the fresh opening gate.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED AUDIT AND CORRECTION CAPSULE
──────────────────────────────────────────────────────────────────────────────

Accepted audit root:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-final-audit-fjuro9xw

Required records:

1. opening/opening_record.json
   size 422701
   SHA-256
   362bd6c4b39b9180b8d8551fa14eb3f3c00e41447ebd5a85cae4e8352a54bc46

2. validation/technical_results.json
   size 37748
   SHA-256
   60d8fb88dc51d191ee4124b1a2eaacd4fd7c09efe620e52a286fd856cdb7048d

3. closeout/closing_record.json
   size 246391
   SHA-256
   976fd3dca592d9ce4f635060957aa38fdaa530b798e67fdb2108b2640e97a1b9

4. closeout/final_report.md
   size 8046
   SHA-256
   0ff52343284123dc7a7c16a9f4c89612a12a6c2460d8eba467f9ec3582ad742d

5. closeout/final_audit_root_inventory.json
   size 1765
   SHA-256
   5e385245b9cea8667e8f101965c52a98bfffa9f8ca6d184f6703860a7a21c4b8

Required verdict: ACCEPT.

Correction capsule:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-repair-fsgu2x8c

Both manifests:

- manifest/canonical-manifest-a-v1.txt
- manifest/canonical-manifest-b-v1.txt
- size 8590
- SHA-256:
  d7a0c0f376c1a52c2b9b6cdc2b64d43ce9cd2235602b71a2e15552746f6f7cde

Prior failed gate roots are historical and nonqualifying. Do not mutate them.

──────────────────────────────────────────────────────────────────────────────
4. EXACT SEVEN-PATH SCOPE
──────────────────────────────────────────────────────────────────────────────

Expected tracked modifications and staged/committed classification `M`:

1. PLANS.md
   mode 100644
   size 288739
   SHA-256
   f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f

2. .docs/system_overview/configuration.md
   mode 100644
   size 129589
   SHA-256
   f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3

3. .docs/system_overview/boundaries.md
   mode 100644
   size 96086
   SHA-256
   0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd

4. .docs/system_overview/artifact_hygiene.md
   mode 100644
   size 38322
   SHA-256
   2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910

5. .docs/system_overview/capability_probing.md
   mode 100644
   size 42668
   SHA-256
   f177f939932e21e8d53fe521aad9386253e330527b6a85eeb73c0888b1acdeb2

6. docs_contract_test.go
   mode 100644
   size 794256
   SHA-256
   e43d41791758e6e8ebf2e7fe585e7469f342d9eb3013171cc76bece662f02684

Expected untracked addition and staged/committed classification `A`:

7. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
   mode 100644
   size 99195
   SHA-256
   18cfad593028ea25575d5e9593d95533cbda6400bba52897bba8a9ae4f17f32d

Opening classification requirements:

- paths 1–6 are tracked in HEAD and modified in the working tree;
- path 7 is absent from HEAD and the tracked index, and is one nonignored
  untracked regular file;
- no classification is silently normalized.

Exact commit subject:

freeze Repair 10I A6 successor governance

──────────────────────────────────────────────────────────────────────────────
5. FRESH EVIDENCE ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable fresh root with tempfile.mkdtemp
beneath /Users/ds/Downloads using prefix:

ES-repair10i-a6-successor-governance-commit-gate-v3-

Retained directories: mode 0700.
Retained files: regular, single-link, mode 0600.

Retain:

- opening repository and supplied-root inventories;
- exact opening classifications and identities;
- staging command start/outcome;
- parsed path-keyed staged classification map;
- staged blob report;
- staged-tree SHA;
- isolated-tree membership and validation;
- all failed/superseded audit-owned checker attempts;
- exact commit start/outcome;
- post-commit object report;
- closing equality report;
- final report and self-excluding evidence inventory.

Do not leave unexplained empty directories.

──────────────────────────────────────────────────────────────────────────────
6. GIT PROCESS CONTRACT
──────────────────────────────────────────────────────────────────────────────

Every repository Git invocation, including `git add`, `write-tree`, validation
materialization, restore, and commit, must:

- use cwd exactly equal to the candidate repository;
- begin with:
  git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"
- explicitly receive:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Do not rely on inherited values for those variables.

──────────────────────────────────────────────────────────────────────────────
7. OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Before staging:

1. Read repository AGENTS.md and applicable nested guidance.
2. Verify the exact identity and opening state in §2.
3. Verify zero staged, deleted, renamed, or unmerged paths.
4. Verify no active Git operation marker or lock.
5. Run rooted `git diff --check`; require exit 0 and empty streams.
6. Verify all accepted-audit records and complete root closure.
7. Verify correction-capsule closure and both manifests.
8. Verify all seven live file identities and opening classifications.
9. Record every unrelated dirty path and its identity.

Return COMMIT_GATE_PROVENANCE_MISMATCH on substantive opening drift.

──────────────────────────────────────────────────────────────────────────────
8. STAGING AND PATH-KEYED VALIDATION
──────────────────────────────────────────────────────────────────────────────

Issue one explicit command naming exactly the seven paths:

git -C "$CANDIDATE_R" add -- \
  PLANS.md \
  .docs/system_overview/configuration.md \
  .docs/system_overview/boundaries.md \
  .docs/system_overview/artifact_hygiene.md \
  .docs/system_overview/capability_probing.md \
  .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md \
  docs_contract_test.go

Do not use globs, `git add .`, `git add -A`, patch staging, or interactive
staging.

Parse `git diff --cached --name-status -z --` into a map keyed by path.

Require, without any ordering assumption:

- exact staged path set equals the seven paths;
- six classifications are `M`;
- one classification is `A`;
- the sole `A` is the deployment document;
- no extra staged path exists.

Parse `git ls-files --stage -z -- <seven paths>` into another path-keyed map.

Require:

- exactly seven stage-0 entries;
- every staged mode is 100644;
- every staged blob’s bytes, size, and SHA-256 equal §4;
- no unstaged difference remains on a staged path.

Require unrelated dirty state to be exactly:

- 16 tracked modifications;
- 13 nonignored untracked paths;

with every unrelated path unstaged and byte-identical to opening.

Run and retain:

- `git diff --cached --check`
- `git diff --check`

Both must pass.

Run `git write-tree`; retain the staged-tree SHA.

AUDIT-TOOL RETRY RULE

When an audit-owned checker fails but direct Git evidence shows the staged path
map, blob map, and tree remain unchanged, retain the failure, repair the checker,
and rerun it. Do not restore or restage solely because an audit script was
wrong.

──────────────────────────────────────────────────────────────────────────────
9. ISOLATED STAGED-TREE VALIDATION
──────────────────────────────────────────────────────────────────────────────

Materialize the exact index tree into a fresh private external directory, for
example:

git -C "$CANDIDATE_R" checkout-index --all --prefix="$STAGED_TREE_ROOT/"

Require the materialized tree to equal the staged Git tree and contain:

- the opening HEAD content;
- the six staged modified blobs;
- the staged added deployment document;
- none of the 16 unrelated working-tree modifications;
- none of the 13 remaining untracked files.

Verify materialized bytes directly against staged blobs.

Pinned Go:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected:

- `go version go1.26.5 darwin/arm64`
- SHA-256:
  3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Use offline, private gate-owned:

- HOME
- TMPDIR
- GOTMPDIR
- GOCACHE
- GOMODCACHE

Set:

GOTOOLCHAIN=local
GOPROXY=off
GOSUMDB=off
GOENV=off
GOWORK=off
GOFLAGS=-mod=readonly
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
ES_REPAIR10_SOURCE_ROOT="$STAGED_TREE_ROOT"

Seed only already-present pinned module-cache objects. No network or install.

Against the isolated staged tree:

1. Discover top-level `Test...` identities from `docs_contract_test.go` with an
   audit-owned AST parser.
2. Require exactly 106 unique identities and equality with accepted retained
   identity evidence.
3. Run:
   `go test -modcacherw . -run '^TestRepair10IA6SuccessorGovernanceContract$' -count=1 -v`
4. Require the one top-level test and all 33 contradiction subtests to pass.
5. Run the exact anchored 106-identity set with `-count=1 -v`.
6. Require 106 unique tests, zero failure, zero skip.
7. Run pinned `gofmt -d docs_contract_test.go`; require empty streams.
8. Verify no materialized-tree artifact remains.

After validation, reverify:

- all live accepted bytes;
- the seven staged blobs;
- staged-tree SHA;
- exact unrelated dirty-state identities;
- repository inventory and artifact posture.

On a substantive pre-commit mismatch, restore only the seven index entries to
opening HEAD, verify zero staging and unchanged working bytes, and return
COMMIT_GATE_BLOCKED.

──────────────────────────────────────────────────────────────────────────────
10. COMMIT
──────────────────────────────────────────────────────────────────────────────

Only after all gates pass, retain an exclusive pre-execution record containing:

- full argv;
- cwd;
- explicit environment;
- opening HEAD;
- expected sole parent;
- expected staged tree;
- subject;
- six-modified/one-added path map.

Then run exactly:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1" commit -m "freeze Repair 10I A6 successor governance"

The commit subprocess must explicitly receive the six Git environment variables
in §6.

Do not use `--no-verify`.

Retain complete stdout/stderr bytes, sizes, SHA-256 values, exit, and signal.

If HEAD advances, never reset, amend, or replace the commit.

──────────────────────────────────────────────────────────────────────────────
11. POST-COMMIT OBJECT GATE
──────────────────────────────────────────────────────────────────────────────

Require:

- new HEAD is exactly one commit beyond opening HEAD;
- sole parent is opening HEAD;
- exact subject matches;
- committed tree equals the retained staged-tree SHA;
- parent-to-commit diff contains exactly seven paths;
- exactly six are modified and one is added;
- the added path is the deployment document;
- all seven modes are 100644;
- all committed blob sizes and SHA-256 values equal §4;
- deployment document is absent in the parent and present in the commit;
- every other commit-tree path equals the parent tree;
- no other untracked file entered the commit;
- index is clean;
- remaining working-tree state is exactly 16 modified and 13 untracked;
- every remaining dirty path equals its opening bytes;
- governed working-tree membership remains 389;
- source T remains:
  f276536fea579d0842cda43b0290656b200b7f27
- inventory remains:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738
- no ignored/cache/bytecode/database/journal/lock/generated artifact exists;
- accepted-audit and correction roots equal opening;
- upstream remains absent;
- no push occurred;
- rooted `git diff --check` passes.

If the commit succeeded but a post-commit gate fails, return
COMMIT_GATE_BLOCKED, report the exact commit and mismatch, and do not alter it.

──────────────────────────────────────────────────────────────────────────────
12. FINAL REPORT
──────────────────────────────────────────────────────────────────────────────

Report:

1. Primary verdict
2. Opening repository identity and dirty posture
3. Accepted-audit and correction-capsule verification
4. Exact six-M/one-A opening classification
5. Exact path identities
6. Exact staging argv and outcome
7. Order-independent staged classification map
8. Direct staged blob identities
9. Staged-tree SHA
10. Isolated materialization membership
11. Exact validation commands/environments/results
12. Audit-owned checker failures and corrections
13. Exact commit argv/cwd/environment/outcome
14. Commit SHA/tree/parent/subject
15. Exact committed classifications and blob identities
16. Proof all other tree paths equal the parent
17. Post-commit index and remaining dirty state
18. Artifact and cleanup result
19. Supplied-root closing equality
20. Commit-gate evidence inventory
21. Remaining uncertainty and nonclaims
22. Explicit confirmations

Required confirmations:

REPOSITORY_BYTES_NOT_EDITED_BY_GATE
EXACTLY_SEVEN_PATHS_STAGED
SIX_MODIFIED_PATHS_STAGED
ONE_ADDED_PATH_STAGED
STAGED_PATH_VALIDATION_ORDER_INDEPENDENT
EXACTLY_ONE_COMMIT_CREATED
COMMIT_NOT_AMENDED_OR_RESET
UNRELATED_DIRTY_STATE_NOT_STAGED
UNRELATED_DIRTY_STATE_NOT_MODIFIED
SUPPLIED_EVIDENCE_NOT_MUTATED
PUSH_NOT_PERFORMED
UPSTREAM_NOT_CREATED
PR_NOT_CREATED
MERGE_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
DEPLOYMENT_NOT_PERFORMED
A6_NOT_STARTED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

### Sources

The accepted independent audit found no substantive residual defect and qualified the exact correction bytes.  It also established exact opening/closing equality and no repository mutation. 

**Confidence:** 0.999 that the latest failure was solely an audit-owned ordering bug; 0.998 that the accepted audit remains valid; 0.995 that a fresh order-independent commit gate can proceed without implementation or re-audit.
