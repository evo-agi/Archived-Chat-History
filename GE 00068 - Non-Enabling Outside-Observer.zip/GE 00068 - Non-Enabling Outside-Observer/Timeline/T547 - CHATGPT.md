## Engineering assessment

The replacement construction succeeded and is ready for a **freshly authored independent audit**.

The earlier wrapper defects are closed:

- the accepted source-freeze role was resolved semantically and uniquely to `opening/gen2-implementation-source-freeze-v1.json`;
- the guessed legacy path was not used;
- the 38-case resolution matrix and independent source-freeze validator passed;
- all 18 fixed construction roles authenticated;
- the replacement authorization was consumed only when the production parent was actually created. :chatgpt-content-reference{index="0"}

The accepted parent then executed exactly once, exited `0`, emitted one governed subject-root locator, and produced a fresh root distinct from the historical blocked subject:

```text
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
```

- device/inode: `16777234 / 182649818`
- mode: `0700`
- no root scan or preexisting-root adoption occurred. :chatgpt-content-reference{index="1"}

Producer-side semantic qualification closed completely:

- 15 current schema roles;
- 14 generated-record families;
- exact role/family mapping;
- all 15 schemas Draft 2020-12 valid;
- 14 contract witnesses and 14 schema witnesses;
- zero joint unsatisfiability and zero baseline under-enforcement;
- all 946 negative cases passed;
- all 137 contradiction cases passed;
- the 766/333 field map closed;
- all ten documentary-validator results were present and passing;
- confirmation evidence and current-role occupancy passed. :chatgpt-content-reference{index="2"}

Terminal closure also passed:

```text
closeout/temporal-final-inventory-v1.json
```

- size: `16,051`
- SHA-256: `905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4`

```text
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json
```

- size: `16,620` each
- SHA-256: `5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758`

The manifests are byte-identical, temporal and terminal reprojections passed, topology and modes are clean, there was one seal transition, and the parent performed no post-seal operation. :chatgpt-content-reference{index="3"}

### Current authority posture

The replacement subject is:

- freshly constructed;
- producer-qualified;
- terminally closed;
- distinct from the historical subject;
- **pending fresh independent audit**;
- not current authority;
- not product/runtime/target-audit/A6 authority. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

## Progression decision

Run exactly one newly implemented, source-external independent audit of the replacement subject.

Do **not** reuse the historical subject-audit source. Its sealed BLOCK remains historical, and its unexplained A06/A07/A08/A11 findings were never successfully reconciled. The fresh audit must independently derive its oracles from the normative contract, current schemas, and current validation specifications.

The new audit must also be **self-diagnosing**:

- a witness blocker requires exact failed witness rows and non-null direct evidence;
- a 946- or 137-suite blocker requires every exact failing case, mutation, expected outcome, observed outcome, validator keyword, and governing pointer;
- confirmation failures that merely derive from another failed domain cannot become separate independent blockers;
- aggregate counts alone cannot support `BLOCK`.

An authoritative `BLOCK` from this audit must already contain enough direct evidence and repair ownership to proceed without another retrospective findings reconciliation.

---

## Complete replacement Codex prompt

```text
EXECUTE ONE FRESHLY AUTHORED, SOURCE-EXTERNAL INDEPENDENT AUDIT
OF THE REPLACEMENT GENERATION-2 CURRENT SCHEMA SUBJECT

Objective

Independently audit the freshly constructed replacement schema subject:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

The replacement producer reports:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTED_AND_TERMINALLY_CLOSED_PENDING_FRESH_INDEPENDENT_AUDIT

This task must determine whether that exact replacement subject is independently
acceptable.

Create fresh independent audit source.

Do not reuse, copy, import, patch, execute, translate, or use as an AST,
bytecode, fixture, expected-result, normalization, or projection origin:

- the historical subject-audit source;
- the historical findings-reconciliation source;
- the reconstruction-parent production source;
- producer validator helpers;
- producer fixture generators;
- producer expected-result maps;
- producer report/confirmation projectors.

Historical audit findings may be retained only as regression requirements for
the new audit logic.

Do not mutate, repair, clean, relocate, chmod, or reseal the replacement
subject.

Do not execute subject source.

Do not rerun subject construction.

Do not promote or rebind current schema authority.

Do not combine independent audit with authority promotion.

Do not execute product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite independent-audit parent in one fresh private audit root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. REPLACEMENT SUBJECT
──────────────────────────────────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected root identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID:
  501
- GID:
  20

Expected physical closure:

- total entries including root:
  73;
- directories:
  12;
- regular files:
  61;
- root row:
  exactly one;
- empty descendants:
  0;
- symlinks:
  0;
- special objects:
  0;
- multiply linked regular files:
  0;
- directory mode:
  0700;
- file mode:
  0600;
- cache/bytecode:
  absent.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- size:
  16620
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Open only this exact root.

Do not scan for another subject.

Do not infer a newer subject from prefix, recency, inode, hash, basename, score,
or first match.

──────────────────────────────────────────────────────────────────────────────
2. REPLACEMENT CONSTRUCTION WRAPPER
──────────────────────────────────────────────── LIMITED TO PROVENANCE
────────────────────────────────────────────────

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected root identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID:
  501
- GID:
  0

Expected final operative report:

report/final-operative-report-v1.json

Resolve its exact identity through the wrapper’s own terminal records and
manifest or retained report registry.

Authenticate:

- forward-treatment directive;
- historical-subject preservation;
- historical-audit preservation;
- failed-reconciliation exclusion;
- source-freeze semantic resolution;
- accepted implementation authority;
- one-shot replacement authorization;
- authorization consumption;
- platform preflight;
- exact production-parent argv;
- top-level process custody;
- raw streams;
- governed subject-root locator;
- fresh allocation and nonadoption;
- wrapper fixed-input opening/closing equality;
- second construction not attempted.

Do not use wrapper prose as subject-semantic authority.

Require complete opening/closing equality for the wrapper root.

──────────────────────────────────────────────────────────────────────────────
3. ACCEPTED IMPLEMENTATION AUTHORITY
──────────────────────────────────────────────── LIMITED TO CHAIN OF AUTHORITY
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the current chain needed to establish:

- accepted reconstruction-parent implementation;
- accepted production source;
- accepted source freeze;
- accepted construction contract;
- implementation package remained unsuperseded;
- construction wrapper used the accepted parent.

Do not re-audit the implementation package.

Do not open historical failed implementation-audit or harness-repair roots.

Require complete opening/closing equality for both accepted roots.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT CONTENT AUTHORITY
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate content authority before ZIP access.

Require:

- exact archive identity;
- 479 members;
- eight current roles;
- seven content-snapshot roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive validation;
- no `.DS_Store`.

Use exact current content roles to resolve:

- normative contract;
- current schemas;
- schema-role registry;
- generated-family specification;
- 946-case registry;
- 137-case contradiction registry;
- 766/333 field-map authority;
- documentary-validator specifications;
- confirmation-evidence specifications.

The containing directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
5. FRESH INDEPENDENT-AUDIT ROOT
────────────────────────────────────────────────

Allocate one fresh private root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-independent-audit-

Immediately emit:

SUBJECT_AUDIT_ROOT=<absolute-path>

Before substantive execution retain:

opening/bootstrap-start.json
opening/audit-authority-v1.json
opening/fixed-input-registry-v1.json
opening/subject-opening-inventory-v1.json
opening/process-execution-policy-v1.json
opening/audit-source-authority-v1.json
opening/historical-audit-regression-requirements-v1.json

Audit authority is limited to:

- fixed-input authentication;
- read-only replacement-subject inspection;
- independent semantic validation;
- exact finding ownership;
- audit-owned fixture cleanup;
- supplied-input closing equality;
- audit-capsule terminal closure.

Audit nonauthority includes:

- subject mutation;
- subject repair;
- authority promotion or rebinding;
- construction;
- product/runtime/target activity;
- repository mutation;
- publication/deployment/A6.

──────────────────────────────────────────────────────────────────────────────
6. HISTORICAL AUDIT REGRESSION REQUIREMENTS
────────────────────────────────────────────────

Retain:

opening/historical-audit-regression-requirements-v1.json

These are audit-logic regression requirements, not current subject findings.

A. Witness closure

The audit must reject:

- a failed aggregate with all constituent witness rows passing and no exact
  aggregation cause;
- a blocker finding with null direct evidence;
- a phase failure unsupported by exact witness rows.

B. 946-case suite

The audit must reject:

- an aggregate failed-case count without exact failed rows;
- a reason mismatch without the expected and observed reason classes;
- a failed row without exact mutation pointer, values, schema path, instance
  path, and validator keyword.

C. 137-case suite

The audit must retain the same direct-evidence fields for every nonpassing row.

D. Confirmation evidence

A confirmation failure that is wholly derivative from another failed evidence
domain must be marked derivative.

It must not become an additional independent package blocker.

E. Block self-diagnosis

Every direct package blocker must include:

- exact direct evidence;
- exact governing contract/schema/specification pointer;
- primary repair owner;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is permitted.

No later findings reconciliation should be required to identify the blocker.

──────────────────────────────────────────────────────────────────────────────
7. INDEPENDENT AUDIT SOURCE
────────────────────────────────────────────────

Create fresh audit source inside the audit root.

It must:

- import no producer reconstruction module;
- import no producer validator helper;
- import no producer fixture generator;
- import no producer expected-result map;
- import no historical subject-audit source;
- import no historical findings-reconciliation source;
- import no producer/audit normalizer or projector;
- execute no subject source;
- use no network, Git, shell, or broad filesystem scan;
- write only inside the fresh audit root;
- be finite;
- read no stdin.

An installed Draft 2020-12 JSON Schema implementation may be used only after
authenticating:

- distribution name;
- version;
- module path;
- source identities;
- validator class.

Do not install a dependency.

If no suitable validator exists:

- do not substitute a partial validator;
- return `AUDIT_PROVENANCE_MISMATCH`.

Retain:

opening/audit-toolchain-authentication-v1.json
opening/independent-audit-source-registry-v1.json

Compile under the pinned interpreter.

Retain complete compilation custody.

Run source-external:

- AST;
- call graph;
- dataflow;
- import-origin;
- process effects;
- filesystem effects;
- input-boundary analysis;
- terminal-operation analysis.

Freeze audit source before substantive execution.

Do not modify it afterward.

──────────────────────────────────────────────────────────────────────────────
8. DUAL-ORACLE AUDIT DESIGN
────────────────────────────────────────────────

Implement two independently authored evaluators for:

- witness closure;
- 946-case suite;
- 137-case suite;
- confirmation derivation.

They may both use the authenticated Draft 2020-12 library.

They must not share:

- case interpretation helpers;
- mutation application helpers;
- expected-result maps;
- reason normalizers;
- aggregate projectors.

For every domain require:

- independently parsed governing input;
- independently generated result;
- exact result crosswalk;
- zero unexplained disagreement.

Any unexplained oracle disagreement is:

AUDIT_PROVENANCE_MISMATCH

not a subject-package blocker.

Retain:

contract/dual-oracle-audit-contract-v1.json
validation/dual-oracle-crosswalk-v1.json

──────────────────────────────────────────────────────────────────────────────
9. AUDIT-LOGIC QUALIFICATION
────────────────────────────────────────────────

Before auditing the replacement subject, run audit-owned disposable fixtures.

At minimum cover:

- exact valid baseline;
- manifest mismatch;
- missing manifest;
- extra path;
- missing root row;
- duplicate root row;
- wrong mode;
- symlink;
- multiply linked file;
- duplicate schema role;
- missing schema role;
- duplicate `$id`;
- normative parent counted as generated family;
- missing generated family;
- wrong mapping;
- metaschema-invalid schema;
- invalid contract witness;
- invalid schema witness;
- all witnesses valid but aggregate forced false;
- aggregate witness blocker with null evidence;
- 946 aggregate count without exact rows;
- 946 reason mismatch;
- 946 outcome mismatch;
- 137 aggregate count without exact rows;
- 137 reason mismatch;
- confirmation derivative incorrectly counted as an independent blocker;
- hard-coded confirmation success;
- absence-as-success;
- stale evidence;
- missing documentary-validator role;
- duplicate validator role;
- failing current validator;
- duplicate occupancy;
- historical artifact current;
- failed artifact current;
- package self-promotion;
- terminal inventory mismatch;
- postseal mutation.

Require:

- unique case names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception;
- both oracles agree.

Retain:

validation/independent-audit-logic-matrix-v1.json

Remove fixtures only after evidence retention.

Require exact cleanup-set equality and double ENOENT.

──────────────────────────────────────────────────────────────────────────────
10. REPLACEMENT SUBJECT TERMINAL CLOSURE
────────────────────────────────────────────────

Authenticate:

- root identity;
- temporal record;
- manifest A;
- manifest B;
- A/B byte equality;
- manifest grammar;
- exclusions;
- represented path set;
- physical path set;
- every represented file’s bytes;
- governed directory/file metadata;
- no-follow whole-root reprojection;
- root row once;
- topology and modes;
- cache/bytecode absence.

Require current physical closure equal both retained manifests.

Any subject drift is:

AUDIT_PROVENANCE_MISMATCH

not semantic BLOCK.

Crosswalk no-postseal evidence to:

- producer source control flow;
- replacement construction-wrapper custody;
- terminal records.

──────────────────────────────────────────────────────────────────────────────
11. NORMATIVE CONTRACT AND CURRENT SCHEMA ROLES
────────────────────────────────────────────────

Authenticate normative contract bytes:

- size:
  32038;
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19.

Require:

- strict JSON;
- duplicate-key rejection;
- nonfinite rejection;
- sole normative-writer posture;
- implementation-present/authority posture.

Independently reconstruct the schema-role registry.

Require:

- exactly 15 current roles;
- one schema per role;
- unique paths;
- unique `$id` values;
- exact source identities;
- all rows current and nonhistorical;
- no hidden sixteenth role.

Do not accept producer aggregate counts without reconstructing rows.

──────────────────────────────────────────────────────────────────────────────
12. GENERATED-FAMILY AND MAPPING AUDIT
────────────────────────────────────────────────

Independently reconstruct:

- exactly 14 generated families;
- normative authority pointers for every family;
- exact role-to-family mapping;
- `child-process-record` to `child-process`;
- governed mappings for the other generated roles;
- `normative-construction-parent` as the sole intentionally unmapped role;
- no fifteenth family;
- no unauthorized or missing family.

Retain all resolved pointers and rows.

──────────────────────────────────────────────── LIMITED TO METASCHEMA
────────────────────────────────────────────────

13. DRAFT 2020-12 VALIDATION

Validate all 15 current schemas against Draft 2020-12.

For every schema retain:

- role;
- path;
- `$id`;
- byte identity;
- validator identity;
- result;
- exact errors.

Require:

- 15 evaluated;
- 15 valid;
- zero errors;
- no invalid empty `prefixItems`;
- no unresolved reference;
- no unsupported-keyword substitution.

A validly established metaschema error is a direct package blocker.

──────────────────────────────────────────────── LIMITED TO WITNESSES
────────────────────────────────────────────────

14. FRESH WITNESS AUDIT

Independently create:

A. fourteen contract-derived witnesses;

B. fourteen schema-derived witnesses.

Do not reuse producer witness bytes or fixtures.

For every witness retain:

- witness ID;
- family;
- exact instance;
- construction authority;
- current schema role/path/identity;
- normative pointers;
- schema result;
- contract-semantic result;
- errors;
- primary oracle result;
- secondary oracle result.

Require:

- 14/14 contract witnesses schema-valid;
- 14/14 schema witnesses contract-valid;
- zero joint unsatisfiability;
- zero baseline under-enforcement;
- dual-oracle agreement.

Aggregate closure derives only from the exact witness rows.

If aggregate fails, retain every exact failed row and non-null direct evidence.

──────────────────────────────────────────────── LIMITED TO 946 CASES
────────────────────────────────────────────────

15. FRESH COMPLETE 946-CASE AUDIT

Authenticate the exact current 946-case registry.

Require:

- 946 rows;
- 946 unique literal names;
- exact expected-name closure;
- exact current expectations.

Run all cases independently through both oracles.

For every case retain:

- ordinal;
- literal name;
- family;
- schema role/path/identity;
- base-instance identity;
- mutation operator;
- mutation pointer;
- original value;
- mutated value;
- expected acceptance;
- expected reason;
- primary observed acceptance/reason;
- secondary observed acceptance/reason;
- JSON Schema keyword;
- instance path;
- schema path;
- normalized error set;
- governing validation-spec pointer;
- agreement;
- classification.

Require aggregate counts for:

- passed;
- false acceptance;
- false rejection;
- reason mismatch;
- oracle disagreement;
- skip;
- exception.

A direct package blocker requires an exact failed-case row.

An aggregate count without rows is invalid audit evidence.

──────────────────────────────────────────────── LIMITED TO 137 CASES
────────────────────────────────────────────────

16. FRESH COMPLETE 137-CASE AUDIT

Authenticate the current 137-case registry.

Require:

- 137 rows;
- unique literal names;
- expected-name closure;
- governed historical-prefix semantics.

Run all 137 independently through both oracles.

Retain all per-case fields required in Section 15, plus:

- contradiction family;
- contradiction site;
- historical-prefix membership;
- atomic-member count when governed.

A direct package blocker requires an exact failed-case row.

──────────────────────────────────────────────── LIMITED TO FIELD MAP
────────────────────────────────────────────────

17. FRESH 766/333 FIELD-MAP AUDIT

Independently resolve:

- 766 normative leaves;
- 333 generated-enforcement rows;
- every JSON pointer;
- schema identity;
- contract identity;
- family mapping.

Require:

- 766 unique normative rows;
- 333 unique enforcement rows;
- zero unresolved;
- zero duplicate;
- zero wrong identity;
- zero unclassified field.

Do not claim implementation consistency beyond governed field-map scope.

────────────────────────────────────────────────

18. DOCUMENTARY-VALIDATOR AUDIT

Independently derive exact current validator roles.

Require:

- exact governed role count and names;
- one current result per role;
- no duplicate role/path;
- no missing role;
- no failed or superseded result current;
- source/result identities exact;
- every result passing under its own schema;
- confirmation-map validator ownership exact;
- dependency graph acyclic.

Producer result files are evidence, not independent proof of their semantics.

────────────────────────────────────────────────

19. CONFIRMATION-EVIDENCE AUDIT

Authenticate the exact current confirmation map.

Derive its row count from exact rows.

For every confirmation:

- resolve evidence path;
- resolve JSON pointer;
- validate type and expected value;
- derive the observed value;
- reject hard-coded success;
- reject absence-as-success;
- reject stale/historical evidence;
- reject circularity.

If a confirmation is false solely because another direct evidence domain failed:

- classify:
  DERIVATIVE_CONFIRMATION_FAILURE;
- do not count it as an additional independent package blocker.

Retain:

analysis/confirmation-derivation-dependency-ledger-v1.json

Independently derive the complete explicit-confirmation result.

────────────────────────────────────────────────

20. CURRENT OCCUPANCY, LINEAGE, AND STATUS

Independently inventory all current roles.

Require:

- exactly one current artifact per schema role;
- exactly one current artifact per validator role;
- no duplicate current role;
- no failed artifact current;
- no historical closure output current;
- explicit supersession edges;
- exact lineage;
- implementation_present:
  false;
- implementation_authority:
  false;
- producer construction:
  passed;
- producer qualification:
  passed;
- terminal closure:
  passed;
- independent acceptance:
  false before this audit;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- no package self-promotion.

────────────────────────────────────────────────

21. FINDINGS, OWNERSHIP, AND REPAIR SURFACE

Retain:

analysis/findings-and-dependency-graph.json
analysis/repair-owner-registry.json

Every finding contains:

- finding ID;
- severity;
- ownership:
  subject_package,
  audit,
  derivative,
  mixed,
  unresolved;
- exact direct evidence;
- governing contract/schema/spec pointer;
- affected phases;
- dependency edges;
- verdict effect;
- primary repair owner;
- exact repair surface;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is allowed.

Allowed primary owners:

- NORMATIVE_CONTRACT_AUTHORITY
- CURRENT_SCHEMA_AUTHORITY
- VALIDATION_SPECIFICATION_AUTHORITY
- SUBJECT_RECONSTRUCTION_PARENT
- SUBJECT_EVIDENCE_GENERATION
- PRODUCER_VALIDATOR_LOGIC
- INDEPENDENT_AUDIT_ORACLE
- INDEPENDENT_AUDIT_EVIDENCE_PROJECTION
- CONFIRMATION_EVIDENCE_MAP
- MIXED_OWNER
- UNRESOLVED_OWNER

Only direct current subject-package findings can force BLOCK.

Audit-source, oracle disagreement, custody, evidence-loss, cleanup, or capsule
closure failures force `AUDIT_PROVENANCE_MISMATCH`.

Derivative confirmation failures do not become separate direct blockers.

No direct blocker may have null direct evidence.

────────────────────────────────────────────────

22. AUDIT PHASES AND PROCESS CUSTODY

Retain terminal audit phases:

A00 fixed-input authentication
A01 construction-chain authentication
A02 subject terminal closure
A03 normative-contract and schema roles
A04 generated families and mappings
A05 Draft 2020-12 metaschema
A06 dual-oracle witnesses
A07 dual-oracle 946 cases
A08 dual-oracle 137 cases
A09 766/333 field map
A10 documentary-validator authority
A11 confirmation evidence
A12 occupancy, lineage, and status
A13 findings and substantive disposition
A14 cleanup and supplied-root equality
A15 audit-capsule terminal closure

Every phase contains:

- explicit status;
- terminal true;
- phase-specific evidence;
- findings;
- first blocker or null;
- continuation;
- cleanup obligations;
- authority contribution.

Retain a complete child ledger.

Require:

- prelaunch rows;
- contiguous ordinals;
- streams;
- exit/signal;
- timeout posture;
- reaping;
- descriptor closure;
- effects and cleanup.

Explicit zero-child evidence is valid.

────────────────────────────────────────────────

23. AUDIT-OWNED CLEANUP AND INPUT EQUALITY

Retain:

cleanup/cleanup-result.json
closing/supplied-root-closing-equality.json

Require exact equality:

created audit-owned roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots.

Equal empty sets pass.

Require zero process, descriptor, cache, and bytecode survivors.

Repeat complete opening/closing equality for:

- replacement subject root;
- replacement construction-wrapper root;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority;
- every exact fixed root opened.

Do not mutate or clean supplied roots.

────────────────────────────────────────────────

24. AUDIT-CAPSULE TERMINAL CLOSURE

Before temporal projection:

- finalize all nonclosure evidence;
- create only used directories;
- require no empty descendant;
- reserve temporal and manifest paths;
- retain descriptors;
- freeze namespace.

Create:

closeout/temporal-final-inventory.json
manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json
terminal/terminal-result.json

Require:

- temporal bytes independently generated twice;
- immediate temporal reprojection;
- independently generated A/B;
- A/B byte equality;
- descriptor/path inode equality;
- independent final whole-root reprojection;
- root row exactly once;
- clean topology and modes;
- no cache or bytecode;
- one seal transition;
- no filesystem/process/validation operation after seal.

Prepare terminal frame entirely before seal.

After seal:

- emit only the terminal frame;
- exit nonreturningly.

────────────────────────────────────────────────

25. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- provenance and authority chain pass;
- subject terminal closure passes;
- 15/14 role-family model passes;
- all schemas pass Draft 2020-12;
- all witnesses pass with dual-oracle agreement;
- all 946 cases pass;
- all 137 cases pass;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy/lineage/status close;
- no direct subject-package blocker remains;
- cleanup, equality, and audit-capsule closure pass.

Scope:

- accepts this exact replacement subject package;
- does not promote or rebind current authority;
- does not establish product/runtime readiness;
- does not authorize target audit, publication, deployment, or A6.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- at least one direct current subject-package blocker is established;
- every blocker has exact non-null direct evidence;
- exact failed witness/case rows are retained;
- repair ownership is retained;
- findings/dependencies are complete;
- cleanup/equality/audit-capsule closure pass.

Return:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input or authority-chain mismatch;
- audit toolchain failure;
- dual-oracle unexplained disagreement;
- process-custody loss;
- subject drift;
- incomplete direct evidence;
- aggregate blocker without exact rows;
- null blocker evidence;
- audit cleanup inequality;
- supplied-root inequality;
- audit-capsule closure failure;
- postseal activity.

Do not retry in this task.

────────────────────────────────────────────────

26. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve audit capsule;
- do not promote or rebind current authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

27. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh audit-root identity
3. Replacement subject identity
4. Replacement construction-wrapper identity
5. Accepted implementation authority chain
6. Content identities
7. Audit source/toolchain
8. Audit source freeze
9. Historical-regression requirements
10. Audit-logic qualification matrix
11. Dual-oracle contract and validator identities
12. Subject terminal-closure authentication
13. Temporal and manifest identities
14. Independent physical reprojection
15. Normative-contract identity
16. Fifteen current schema roles
17. Fourteen generated families
18. Role/family mapping
19. Draft 2020-12 results
20. Contract-witness per-row results
21. Schema-witness per-row results
22. Witness aggregate and direct evidence
23. Complete 946-case aggregate
24. Exact failed 946 rows, if any
25. Complete 137-case aggregate
26. Exact failed 137 rows, if any
27. Dual-oracle crosswalk
28. 766/333 field-map result
29. Documentary-validator registry/result closure
30. Confirmation-evidence result
31. Derivative-confirmation ledger
32. Current-role occupancy
33. Lineage/supersession
34. Producer package status
35. Findings registry
36. Repair-owner registry
37. Finding ownership and dependency graph
38. A00–A15 phase results
39. Child ledger and custody
40. Audit cleanup
41. Supplied-root equality
42. Audit temporal identity
43. Audit manifest identities
44. A/B equality
45. Final reprojection
46. Audit topology/modes
47. Audit seal/no-postseal
48. Confirmation subject mutation not performed
49. Confirmation authority promotion not performed
50. Confirmation no product/runtime/target/A6 activity
51. Remaining uncertainty/nonclaims
52. Explicit audit confirmations

Required confirmations:

REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
INDEPENDENT_AUDIT_SOURCE_CREATED
INDEPENDENT_AUDIT_SOURCE_IMPORTS_NO_PRODUCER_OR_HISTORICAL_AUDIT_HELPERS
INDEPENDENT_AUDIT_SOURCE_FROZEN
HISTORICAL_AUDIT_REGRESSION_REQUIREMENTS_RETAINED
DUAL_ORACLE_AUDIT_CONTRACT_FROZEN
AUDIT_LOGIC_QUALIFICATION_MATRIX_PASSED
SUBJECT_TEMPORAL_INVENTORY_IDENTITY_MATCHED
SUBJECT_MANIFEST_A_IDENTITY_MATCHED
SUBJECT_MANIFEST_B_IDENTITY_MATCHED
SUBJECT_MANIFESTS_BYTE_IDENTICAL
SUBJECT_TERMINAL_REPROJECTION_PASSED
SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
SUBJECT_PHYSICAL_CLOSURE_MATCHED_MANIFESTS
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_NON_NULL_DIRECT_EVIDENCE
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_INDEPENDENT_BLOCKERS
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_SUBJECT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Sources and confidence

The latest report establishes successful semantic source-freeze resolution, wrapper qualification, one-shot production execution, fresh subject allocation, producer qualification, and terminal closure. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

It establishes the complete 15/14 model, 946/137 success, 766/333 closure, documentary-validator and confirmation closure, and pending-independent-audit posture. :chatgpt-content-reference{index="8"}

It also establishes supplied-input equality, manifest equality, final reprojection, clean topology, one seal transition, and no post-seal parent activity. :chatgpt-content-reference{index="9"}

**Provenance confidence:** 0.995  
**Producer-validation confidence:** 0.998  
**Terminal-closure confidence:** 0.998  
**Fresh-audit readiness:** 0.995  
**Current-authority confidence before audit:** 0.00

Some older project uploads have expired. Re-upload one only if a later review requires its original bytes rather than the retained identities and reports.
