## Engineering assessment

The one authorized audit was consumed, but the implementation package was **not audited**. The harness failed before creating an audit root because its `run-full-audit` path requested an embedded member that does not exist:

```text
qualification/runtime-matrix-suite-v2.json
```

The frozen failure frame was:

```json
{
  "detail": "qualification/runtime-matrix-suite-v2.json",
  "reason": "embedded-record-unavailable",
  "schema": "harness-v2-failure-v1"
}
```

Everything outside that runtime lookup worked:

- all five launch files authenticated;
- the launch certificate authorized the audit;
- the 124-member PYZ closed exactly;
- platform preflight passed;
- the real parent was created exactly once;
- top-level process custody completed;
- the parent exited cleanly under the frozen unhandled-failure posture;
- all five launch files closed equal afterward;
- no root scan, retry, continuation, capsule mutation, product activity, or implementation execution occurred.

This is therefore a confirmed **harness embedded-record binding defect**, not an implementation-package defect and not another external-authority defect.

### Exact classification

**Defect:** `RUN_FULL_AUDIT_EMBEDDED_RECORD_ROLE_RESOLUTION_DEFECT`

**Observed failure:** the runtime consumer requested a literal package path that is absent.

**Important counter-evidence:** prelaunch inspection authenticated both:

- the governed `15 / 595` runtime-matrix registry;
- an existing current `runtime-matrix-v2` record.

That strongly indicates a stale literal path or an incomplete role-to-member binding in `run-full-audit`. It does not support adding a duplicate compatibility file at the missing path.

The repair should resolve embedded evidence by a unique semantic role through the exact member registry. It should not:

- add an alias member named `qualification/runtime-matrix-suite-v2.json`;
- use first-match or basename lookup;
- add a path fallback;
- silently duplicate the current matrix evidence;
- change any matrix definition, count, expected outcome, or package acceptance rule.

### Why the previous qualification missed it

The failure occurred only after the final packaged PYZ entered its actual `run-full-audit` path. Prepackage and qualification checks proved that matrix evidence existed, but did not prove that every packaged runtime consumer could resolve every required embedded member through the final archive’s role registry.

The repair must add a complete **run-full-audit embedded-dependency closure**:

```text
source lookup sites
=
embedded dependency registry
=
member-role registry
=
actual final PYZ members
=
post-package run-full-audit rehearsal accesses
```

A post-package rehearsal must execute the exact final candidate PYZ—not a source tree or provisional unpacked layout.

### Progression decision

Use one bounded repair attempt **only if the exact embedded source-attempt ledger says an attempt remains**.

If no attempt remains, stop and retire this implementation generation. Do not infer a fresh budget.

If one remains:

1. diagnose the exact stale consumer and authoritative current member;
2. replace path-literal resolution with exact role resolution;
3. enumerate every `run-full-audit` embedded dependency;
4. requalify all unchanged suites;
5. execute post-package ACCEPT, BLOCK, and provenance rehearsals through the exact candidate PYZ;
6. produce new immutable artifacts:
   - harness PYZ v3;
   - runtime authority v4;
   - external launch certificate v2;
7. authorize one new future audit.

The consumed certificate v1 must remain historical and cannot be reused.

---

## Complete replacement Codex prompt

```text
REPAIR THE RUN-FULL-AUDIT EMBEDDED-RECORD ROLE RESOLUTION,
REQUALIFY THE FINAL PACKAGED PATH, AND ISSUE NEW AUDIT AUTHORITY

Objective

Diagnose and repair the exact harness failure produced by the first authorized
real `run-full-audit` execution:

{
  "detail": "qualification/runtime-matrix-suite-v2.json",
  "reason": "embedded-record-unavailable",
  "schema": "harness-v2-failure-v1"
}

The audit parent was created exactly once, so the prior one-audit authorization
is consumed.

No audit root or capsule was created.

No implementation-package verdict exists.

Repair only the clean audit-harness implementation and package metadata needed
to resolve the current authoritative runtime-matrix evidence through the final
PYZ’s exact member-role registry.

Do not repair or modify the Generation-2 implementation package.

Do not change:

- the five documentary domains;
- the R01–R66 runtime report registry;
- the exact 81-name runtime confirmation registry;
- B00 or D01–D14 definitions;
- the 15-matrix / 595-case aggregate;
- the 946-case negative evidence;
- the 137-case contradiction evidence;
- the 766/333 field-map semantics;
- package acceptance or finding-ownership semantics;
- the three-role interpreter-observation tuple;
- the runtime environment policy;
- capsule terminal-lifecycle semantics.

Do not add a compatibility member at:

qualification/runtime-matrix-suite-v2.json

unless exact current governing records establish that this path itself is the
unique authoritative role path. The supplied audit report does not establish
that.

Do not implement basename, suffix, recursive, first-match, recency, similarity,
or fallback member selection.

Do not execute the real implementation audit in this task.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not invoke product or live-service behavior.
Do not run a target audit.
Do not rerun product runtime validation.
Do not publish, deploy, externally commit, or begin A6.
Do not create subagents or direct auditors.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_AUDIT_HARNESS_V3_EMBEDDED_RECORD_BINDING_REPAIRED_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_BLOCKED

GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT CURRENT HARNESS INPUTS
──────────────────────────────────────────────────────────────────────────────

CURRENT_HARNESS_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz

Expected identity:

- device:
  16777234
- inode:
  182181777
- mode:
  0400
- link count:
  1
- size:
  2822218
- SHA-256:
  2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2

CURRENT_RUNTIME_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Expected identity:

- device:
  16777234
- inode:
  182181917
- mode:
  0400
- link count:
  1
- size:
  7193
- SHA-256:
  349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986

CONSUMED_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-launch-certificate-v2-output-mchfmdqd/gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json

Expected identity:

- device:
  16777234
- inode:
  182301064
- mode:
  0400
- link count:
  1
- size:
  67057
- SHA-256:
  eaee84d823cbea4ae88ccf0a7ed01429e2b451f5bac128190e760e4d4e528bb8

Classify the certificate as:

historical_consumed_single_audit_authorization

It is:

- immutable;
- noncurrent for any future launch;
- evidence-only;
- not renewable in place;
- not reusable.

──────────────────────────────────────────────────────────────────────────────
2. EXACT CURRENT CONTENT INPUTS
──────────────────────────────────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

──────────────────────────────────────────────────────────────────────────────
3. FAILED AUTHORIZED AUDIT EVIDENCE
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-gen2-fresh-independent-audit-wrapper-8qz1_nhg

Open only this exact path if it exists.

Do not scan for it.

Authenticate exact named records:

report/operative-report-v1.json
raw/run-full-audit-stdout.bin
raw/run-full-audit-stderr.bin

Expected operative-report SHA-256:

88f41f40488bc9023cc211fae3b468de20ea11fd398779484a1ea4494357f151

Expected stdout:

- size:
  0;
- SHA-256:
  e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855

Expected stderr:

- size:
  128;
- SHA-256:
  8b5e4c03ed2006ce66803b4aa1eb3b314c7e1d63e0047d3fac61a299f194dac8

Expected strict stderr object:

{
  "detail": "qualification/runtime-matrix-suite-v2.json",
  "reason": "embedded-record-unavailable",
  "schema": "harness-v2-failure-v1"
}

Expected process result:

- exit:
  1;
- signal:
  null;
- process created:
  true;
- future authorization consumed:
  true;
- terminal frame:
  absent;
- audit root:
  absent;
- root scan:
  false;
- replacement launch:
  false.

Classify:

historical_noncurrent_run_full_audit_embedded_record_failure

Require complete opening/closing equality if the wrapper root is opened.

Do not modify or clean it.

If absent:

- do not search;
- reproduce the failure from exact current PYZ source and member evidence.

──────────────────────────────────────────────────────────────────────────────
4. FRESH REPAIR BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────── LIMITED TO HARNESS REPAIR
────────────────────────────────────────────────

Allocate a fresh private build root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-audit-harness-v3-embedded-record-repair-

Immediately emit:

HARNESS_REPAIR_BUILD_ROOT=<absolute-path>

Allocate a fresh output directory beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-audit-harness-v3-output-

Immediately emit:

HARNESS_REPAIR_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-clean-source-external-independent-audit-harness-v3.pyz

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

The output directory is nonauthoritative.

Before source extraction retain:

opening/bootstrap-start.json
opening/embedded-record-repair-authority-v1.json
opening/fixed-input-registry-v1.json
opening/consumed-audit-disposition-v1.json
opening/process-execution-policy-v1.json

──────────────────────────────────────────────────────────────────────────────
5. CURRENT SOURCE AUTHORITY AND ATTEMPT BUDGET
──────────────────────────────────────────────────────────────────────────────

Extract exact frozen source members only through:

- the PYZ member registry;
- production source registry;
- qualification source registry;
- independent source registry;
- source-freeze record.

No source may be selected by path guess, basename, hash search, similarity,
decompilation, transcript reconstruction, or external historical root.

Authenticate:

- all source identities;
- source freeze;
- source unchanged after freeze;
- exact current source-attempt ledger.

Derive:

- maximum attempts;
- consumed attempts;
- remaining attempts.

Do not assume an attempt remains.

If remaining attempts are zero:

- do not modify source;
- return:
  GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_BLOCKED;
- disposition:
  CURRENT_IMPLEMENTATION_GENERATION_RETIRED;
- next treatment:
  NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION_REQUIRED;
- stop.

If at least one attempt remains:

- authorize exactly one bounded repair attempt in this task;
- no second repair attempt in this task;
- any modification after compilation begins is forbidden;
- if the attempt fails, retire the implementation generation.

Retain:

opening/current-source-and-attempt-authority-v1.json

──────────────────────────────────────────────────────────────────────────────
6. EXACT DEFECT CROSSWALK
──────────────────────────────────────────────── LIMITED TO OBSERVED FAILURE
────────────────────────────────────────────────

Before changing source retain:

analysis/embedded-record-failure-causal-crosswalk-v1.json

Identify exactly:

1. source module;
2. function;
3. line or AST node;
4. call chain from `run-full-audit`;
5. requested literal or computed member path;
6. requested semantic purpose;
7. requested schema;
8. first failing lookup;
9. PYZ member registry state;
10. exact current runtime-matrix registry role;
11. exact current runtime-matrix result role;
12. exact actual member path or paths;
13. exact member identities;
14. current consumers;
15. why qualification and earlier rehearsals did not expose the packaged
    failure.

Classify exactly one primary cause:

A. STALE_HARDCODED_MEMBER_PATH

B. MEMBER_ROLE_NOT_REGISTERED

C. PACKAGE_ASSEMBLY_MEMBER_OMISSION

D. ROLE_REGISTRY_AND_PACKAGE_DIVERGENCE

E. MIXED_EMBEDDED_RECORD_BINDING_DEFECT

Do not continue until the classification is exact.

The report supplied by the user establishes that:

- the governed 15/595 registry authenticated;
- an existing current `runtime-matrix-v2` record authenticated;
- the requested
  `qualification/runtime-matrix-suite-v2.json`
  member was unavailable.

Do not infer the actual current path from that prose. Resolve it from exact
registries and archive members.

──────────────────────────────────────────────────────────────────────────────
7. COMPLETE RUN-FULL-AUDIT EMBEDDED-DEPENDENCY REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/run-full-audit-embedded-dependency-registry-v1.json
analysis/derived-run-full-audit-embedded-dependency-set-v1.json

Derive every embedded-record dependency reachable from:

- `run-full-audit` startup;
- P00 through P24;
- report projection;
- confirmation projection;
- matrix evidence;
- source freeze;
- source registries;
- governing documents;
- rehearsals;
- validators;
- package status;
- capsule closure.

Every row must bind:

- dependency ID;
- semantic role;
- owning registry;
- exact member role;
- exact member path;
- exact schema;
- exact member identity;
- source consumer role;
- source lookup site;
- phase consumers;
- report/confirmation consumers;
- required/optional status;
- missing-member failure reason;
- duplicate-role failure reason;
- wrong-schema failure reason;
- wrong-identity failure reason.

Require exact equality:

derived source dependency IDs
=
registered dependency IDs
=
unique member-role IDs
=
actual final PYZ members required by run-full-audit
=
direct dependency tests
=
independent dependency tests

Unknown, duplicate, missing, or unregistered dependency fails closed.

No acceptance-bearing runtime consumer may directly open an embedded package
path literal.

All acceptance-bearing embedded access must use:

semantic role
→ exact current member-role registry
→ exact member path
→ exact schema and identity.

──────────────────────────────────────────────────────────────────────────────
8. PROHIBITED COMPATIBILITY ALIAS
──────────────────────────────────────────────── LIMITED TO PACKAGE SHAPE
────────────────────────────────────────────────

Do not add an alias member at:

qualification/runtime-matrix-suite-v2.json

unless the exact current governing member-role registry establishes that path
as the unique current authoritative role.

Do not:

- duplicate an existing matrix-result record;
- copy bytes under two paths;
- preserve a stale source literal by adding a compatibility member;
- use fallback path lists;
- use path-version scoring;
- use first existing path;
- use recursive member search.

Retain:

analysis/stale-member-path-and-alias-disposition-v1.json

Required preferred repair, when supported by exact evidence:

source consumer resolves the current unique semantic role.

──────────────────────────────────────────────────────────────────────────────
9. BOUNDED SOURCE REPAIR
──────────────────────────────────────────────── LIMITED TO ROLE RESOLUTION
────────────────────────────────────────────────

Permit changes only to functions/modules that own:

- embedded dependency registry;
- member-role resolution;
- `run-full-audit` embedded-record access;
- package assembly/member registry when required;
- qualification checks for dependency closure;
- independent validation of dependency closure.

Retain:

analysis/source-v2-v3-bounded-delta-v1.json
contract/protected-source-surface-v1.json

Require:

- exact changed functions;
- exact added functions;
- no removed unrelated function;
- every unrelated common function/class AST-identical;
- no package acceptance-semantic change;
- no matrix definition change;
- no report/confirmation registry change;
- no interpreter/environment change;
- no capsule-lifecycle change;
- no product/implementation source change.

The repair must not widen authority.

──────────────────────────────────────────────────────────────────────────────
10. DEPENDENCY-RESOLUTION MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 60 uniquely named cases.

Include:

- exact current matrix-evidence role baseline;
- exact complete dependency registry baseline;
- stale literal path requested;
- missing role;
- duplicate role;
- duplicate path under two roles;
- two paths under one role;
- missing member;
- member not in registry;
- registry member absent from archive;
- archive member absent from registry;
- wrong schema;
- wrong hash;
- wrong size;
- wrong member mode;
- directory member;
- symlink/special member;
- compatibility alias present;
- fallback list;
- first-existing path;
- basename match;
- suffix match;
- version-score match;
- recursive search;
- same bytes under stale and current path;
- required dependency marked optional;
- optional dependency marked required;
- report consumer not registered;
- confirmation consumer not registered;
- phase consumer not registered;
- source lookup site not registered;
- registered lookup site unreachable;
- dependency set missing P00 record;
- dependency set missing matrix evidence;
- dependency set missing source freeze;
- dependency set missing package status;
- complete final-member baseline.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/embedded-dependency-resolution-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
11. INDEPENDENT DEPENDENCY VALIDATOR
──────────────────────────────────────────────── LIMITED TO SOURCE-EXTERNAL CHECKS
────────────────────────────────────────────────

Create one standard-library-only independent validator that imports neither:

- repaired production modules;
- qualification helpers;
- package builder;
- dependency producer;
- mutation generator;
- expected-result map.

It must independently:

1. authenticate exact source base;
2. derive run-full-audit embedded lookup sites;
3. derive semantic purposes;
4. parse member registries;
5. parse actual PYZ members;
6. reconstruct complete dependency closure;
7. resolve the runtime matrix evidence role;
8. confirm the stale path is not current;
9. reject compatibility aliases;
10. reject every fallback mechanism;
11. run independent negative cases;
12. require zero errors.

Retain:

validation/independent-embedded-dependency-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
12. SOURCE ATTEMPT, COMPILATION, AND STATIC GATES
──────────────────────────────────────────────────────────────────────────────

The bounded repair attempt begins only when:

- final repaired production registry closes;
- final repaired qualification registry closes;
- final repaired independent registry closes;
- compilation begins.

Retain:

analysis/bounded-repair-source-attempt-ledger-v1.json

Compile all sources with pinned Python:

-I -S -B

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception tables;
- CFG;
- embedded-member lookup crosswalk;
- member-role/source-consumer join;
- package assembly crosswalk;
- forbidden literal embedded-path analysis;
- fallback-path analysis;
- writer/terminal-operation regression analysis.

Require:

- no direct acceptance-bearing member-path literal outside the exact registry
  implementation;
- no fallback lookup;
- complete dependency closure;
- all children through recorder;
- no network;
- no Git;
- no shell/PATH executable lookup;
- no broad filesystem scan;
- no postseal operation;
- success/failure closeout reachable.

No source modification is permitted after compilation begins.

If the attempt fails, stop and retire the generation.

──────────────────────────────────────────────────────────────────────────────
13. FULL REGRESSION PRESERVATION
──────────────────────────────────────────────── LIMITED TO UNCHANGED SEMANTICS
────────────────────────────────────────────────

Rerun and require exact unchanged success for:

- five documentary domains;
- R01–R66 report registry;
- 81-name confirmation registry;
- B00;
- D01–D14;
- exact 15 / 595 suite;
- 151-case interpreter tuple matrix;
- capsule-evidence matrix;
- mode-aware confirmation matrix;
- mode-aware report matrix;
- terminal-frame matrix;
- process-custody matrix;
- fresh causal matrix;
- synthetic ACCEPT;
- synthetic BLOCK;
- synthetic provenance failure;
- synthetic constructed-subject pair;
- bounded current-bundle compatibility replay;
- source-external validators;
- capsule terminal lifecycle;
- cleanup and fixed-input equality.

Case names and expected outcomes for existing matrices must remain exact.

The new dependency matrix is separate and does not alter 15 / 595.

──────────────────────────────────────────────────────────────────────────────
14. POST-PACKAGE RUN-FULL-AUDIT REHEARSALS
──────────────────────────────────────────────────────────────────────────────

This gate is mandatory.

Prepackage or unpacked-source rehearsals are insufficient.

Build one complete candidate PYZ v3 and provisional runtime authority v4.

Run the exact packaged candidate PYZ through `run-full-audit` in physically
distinct disposable rehearsals.

A. ACCEPT rehearsal

- synthetic accepted package;
- exact packaged candidate PYZ;
- provisional authority v4;
- exact future CLI;
- platform capture;
- complete sealed ACCEPT capsule.

B. BLOCK rehearsal

- one direct synthetic package blocker;
- exact packaged candidate PYZ;
- provisional authority v4;
- complete sealed BLOCK capsule.

C. AUDIT_PROVENANCE_MISMATCH rehearsal

- one exact synthetic audit-provenance blocker;
- exact packaged candidate PYZ;
- provisional authority v4;
- complete sealed provenance-failure capsule.

Every rehearsal must prove:

- no `embedded-record-unavailable`;
- every registered dependency resolves;
- exact runtime-matrix evidence resolves;
- exact terminal frame;
- complete capsule closure;
- exact runtime report and confirmations;
- cleanup and input equality;
- one seal transition;
- no postseal operation.

Retain before cleanup:

- candidate PYZ identity;
- provisional authority identity;
- platform custody;
- raw streams;
- audit-root identity;
- complete capsule inventory;
- terminal identities;
- dependency-access ledger;
- independent capsule-validation result.

Require the independent validator to enumerate every dependency actually opened
by each rehearsal and compare it with the dependency registry.

Remove rehearsal roots only after evidence retention and independent
validation, with double ENOENT.

──────────────────────────────────────────────────────────────────────────────
15. FINAL PYZ V3
──────────────────────────────────────────────── LIMITED TO SUCCESSFUL REPAIR
────────────────────────────────────────────────

After all source and rehearsal gates pass, freeze sources.

Retain:

opening/clean-audit-harness-v3-source-freeze-v1.json

Build independently twice:

gen2-clean-source-external-independent-audit-harness-v3.pyz

Require:

- byte equality;
- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special members;
- no comments or uncontrolled extras;
- no cache or bytecode;
- complete dependency registry embedded;
- exact current matrix evidence embedded once;
- stale alias absent.

Retain exact member registry and member count.

──────────────────────────────────────────────────────────────────────────────
16. RUNTIME AUTHORITY V4
──────────────────────────────────────────────── LIMITED TO HARNESS INPUT
────────────────────────────────────────────────

Create:

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

Authority v4 is the runtime authority passed through:

--harness-authority

It must bind:

- exact PYZ v3 identity;
- member registry;
- source freeze;
- source registries;
- governing packages;
- dependency registry;
- exact runtime matrix role/path/identity;
- complete qualification evidence;
- post-package run-full-audit rehearsals;
- future invocation;
- current content inputs;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject:
  false.

Use the noncircular authority model already established:

- authority v4 need not prove final external launch authorization alone;
- external launch certificate v2 supplies wrapper authorization.

Generate authority v4 deterministically twice and require byte equality.

──────────────────────────────────────────────────────────────────────────────
17. POST-PACKAGE QUALIFICATION
──────────────────────────────────────────────── LIMITED TO FINAL PYZ
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode exactly once using authority
v4 and exact required operands.

Retain complete platform custody and raw streams.

Require fresh qualification to establish:

- exact PYZ v3;
- exact member closure;
- source freeze;
- dependency-registry closure;
- no stale path;
- exact matrix-evidence role resolution;
- all unchanged matrices;
- dependency matrix;
- synthetic lanes;
- packaged ACCEPT/BLOCK/provenance rehearsals;
- independent validators;
- no real implementation audit;
- no implementation verdict.

──────────────────────────────────────────────────────────────────────────────
18. EXTERNAL LAUNCH CERTIFICATE V2
──────────────────────────────────────────────── LIMITED TO WRAPPER AUTHORITY
────────────────────────────────────────────────

Create:

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

The certificate must bind:

- exact PYZ v3;
- exact authority v4;
- exact content inputs;
- deterministic PYZ replay A/B and original equality;
- fresh qualification platform custody;
- fresh qualification result;
- complete dependency closure;
- post-package rehearsal results;
- stream/framing contracts;
- exact future run-full-audit invocation;
- wrapper launch authorization:
  true;
- authorized future audit count:
  1;
- full real audit:
  false;
- implementation verdict:
  not issued.

The certificate is not passed to the harness.

Generate independently twice and require byte equality.

Run one source-external certificate-input validator.

The future wrapper validates final certificate bytes.

Do not require certificate self-validation.

──────────────────────────────────────────────────────────────────────────────
19. FROZEN-PYZ V3 REQUALIFICATION
──────────────────────────────────────────────── LIMITED TO FINAL PACKAGE
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode with exact final authority v4.

Require:

- exit zero;
- empty stderr;
- exact result;
- PYZ/member self-authentication;
- source-freeze linkage;
- dependency closure;
- exact runtime-matrix record resolution;
- all old and new matrices;
- packaged real-path rehearsal linkage;
- authority-v4 coherence;
- no run-full-audit execution;
- no implementation verdict.

Independently recompute every governed aggregate.

Retain:

validation/frozen-pyz-v3-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
20. INPUT CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────── LIMITED TO OWNED EFFECTS
────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- predecessor PYZ v2;
- predecessor authority v3;
- consumed launch certificate v1;
- current content bundle;
- current content authority.

If the failed audit wrapper root was opened, require opening/closing equality.

Do not mutate or clean supplied inputs.

For every disposable build/rehearsal/replay root:

- retain identity and inventory;
- retain process streams and results;
- revalidate identity;
- remove exact root;
- observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

──────────────────────────────────────────────────────────────────────────────
21. FAILURE CLOSEOUT
──────────────────────────────────────────────── LIMITED TO THIS REPAIR
────────────────────────────────────────────────

On failure retain:

- attempt-budget result;
- source-attempt posture;
- first blocker;
- structured exception;
- process ledgers and streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- input equality;
- package/authority/certificate posture;
- same-root retry false.

If the bounded repair attempt fails:

- implementation generation retired:
  true;
- further localized repair:
  false.

Do not create current final outputs on failure.

Remove provisional outputs after evidence retention and double ENOENT.

──────────────────────────────────────────────────────────────────────────────
22. VERDICT RULES
──────────────────────────────────────────────── LIMITED TO REPAIR OUTCOME
────────────────────────────────────────────────

Return:

GEN2_CLEAN_AUDIT_HARNESS_V3_EMBEDDED_RECORD_BINDING_REPAIRED_READY_FOR_FRESH_AUDIT

only when:

- fixed inputs authenticate;
- an attempt remains and exactly one attempt is used;
- exact failure causal is crosswalked;
- complete dependency registry closes;
- no compatibility alias is used;
- bounded source repair passes;
- dependency matrix passes;
- independent dependency validator passes;
- compilation/static gates pass;
- all unchanged suites pass;
- final packaged ACCEPT/BLOCK/provenance rehearsals pass;
- source freezes;
- deterministic PYZ v3 builds match;
- authority v4 builds match;
- post-package qualification passes;
- launch certificate v2 builds match;
- certificate-input validation passes;
- frozen-PYZ v3 requalification passes;
- input equality and cleanup pass;
- final files are mode 0400;
- no real implementation audit runs;
- no implementation verdict is issued.

Return:

GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_BLOCKED

when:

- no source attempt remains;
- the exact authoritative current matrix-evidence role cannot be resolved;
- repair would require changing package acceptance semantics;
- the single repair attempt fails without provenance failure;
- another source attempt would be required.

Required BLOCKED disposition:

- current generation retired;
- further localized repair false;
- new clean implementation generation required.

Return:

GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_PROVENANCE_MISMATCH

for fixed-input, source-authority, evidence-retention, custody, cleanup, source
drift, or final-output identity failures.

──────────────────────────────────────────────────────────────────────────────
23. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────── LIMITED TO COMPLETE RESULT
────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair build-root identity
3. Fresh output-root identity
4. Five fixed-input identities
5. Stable authentication
6. Consumed-audit disposition
7. Current source authority
8. Source-attempt budget
9. Exact embedded-record failure causal
10. Source call site and call chain
11. Requested stale path
12. Authoritative current semantic role
13. Authoritative current member path and identity
14. Primary defect classification
15. Complete derived dependency set
16. Complete dependency registry
17. Dependency/member/source closure
18. Compatibility-alias disposition
19. Bounded source delta
20. Protected-source comparison
21. Final repaired production registry
22. Final repaired qualification registry
23. Final repaired independent registry
24. Compilation/static gates
25. Dependency-resolution matrix
26. Independent dependency validator
27. B00/D01–D14 regression
28. Interpreter-tuple regression
29. Capsule/projection/custody regression
30. Synthetic ACCEPT
31. Synthetic BLOCK
32. Synthetic provenance failure
33. Current-bundle compatibility replay
34. Post-package ACCEPT rehearsal
35. Post-package BLOCK rehearsal
36. Post-package provenance rehearsal
37. Rehearsal dependency-access reconciliation
38. Independent capsule validators
39. Evidence retention
40. Cleanup
41. Source freeze
42. PYZ v3 Build A
43. PYZ v3 Build B
44. PYZ v3 equality
45. PYZ v3 member closure
46. Authority-v4 Build A
47. Authority-v4 Build B
48. Authority-v4 equality
49. Fresh post-package qualification
50. Launch-certificate-v2 Build A
51. Launch-certificate-v2 Build B
52. Launch-certificate-v2 equality
53. Certificate-input validation
54. Frozen-PYZ v3 requalification
55. Confirmation no real audit ran
56. Confirmation no implementation verdict was issued
57. Input closing equality
58. Failure-closeout capability/use
59. Final PYZ v3 path and identity
60. Final authority-v4 path and identity
61. Final launch-certificate-v2 path and identity
62. Mandatory next treatment
63. Remaining uncertainty/nonclaims
64. Explicit confirmations

Required confirmations:

CURRENT_PYZ_V2_IDENTITY_MATCHED
CURRENT_AUTHORITY_V3_IDENTITY_MATCHED
CONSUMED_LAUNCH_CERTIFICATE_V1_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
FAILED_AUTHORIZED_AUDIT_EVIDENCE_AUTHENTICATED_OR_REPRODUCED
PRIOR_AUDIT_AUTHORIZATION_CONSUMED
NO_AUDIT_ROOT_WAS_CREATED
CURRENT_SOURCE_AUTHORITY_AUTHENTICATED
SOURCE_ATTEMPT_BUDGET_DERIVED
EXACTLY_ONE_BOUNDED_REPAIR_ATTEMPT_USED
RUN_FULL_AUDIT_EMBEDDED_RECORD_FAILURE_CROSSWALKED
AUTHORITATIVE_MATRIX_EVIDENCE_ROLE_IDENTIFIED
AUTHORITATIVE_MATRIX_EVIDENCE_MEMBER_IDENTIFIED
STALE_MEMBER_PATH_CLASSIFIED
COMPLETE_RUN_FULL_AUDIT_DEPENDENCY_SET_DERIVED
EMBEDDED_DEPENDENCY_REGISTRY_COMPLETE
SOURCE_LOOKUPS_EQUAL_REGISTERED_DEPENDENCIES
REGISTERED_DEPENDENCIES_EQUAL_FINAL_PYZ_MEMBERS
NO_COMPATIBILITY_ALIAS_MEMBER_ADDED
NO_EMBEDDED_PATH_FALLBACK_IMPLEMENTED
REPAIR_BOUNDED_TO_EMBEDDED_RECORD_ROLE_RESOLUTION
PACKAGE_ACCEPTANCE_SEMANTICS_UNCHANGED
MATRIX_DEFINITIONS_UNCHANGED
RUNTIME_REPORT_REGISTRY_UNCHANGED
RUNTIME_CONFIRMATION_REGISTRY_UNCHANGED
INTERPRETER_TUPLE_CONTRACT_UNCHANGED
CAPSULE_TERMINAL_LIFECYCLE_UNCHANGED
PROTECTED_SOURCE_AST_IDENTICAL
ALL_SOURCES_COMPILED
STATIC_GATES_PASSED
DEPENDENCY_RESOLUTION_MATRIX_PASSED
INDEPENDENT_DEPENDENCY_VALIDATOR_PASSED
PRIOR_RUNTIME_MATRICES_STILL_PASSED
INTERPRETER_TUPLE_MATRIX_STILL_PASSED
CAPSULE_AND_CUSTODY_MATRICES_STILL_PASSED
SYNTHETIC_LANES_STILL_PASSED
POST_PACKAGE_ACCEPT_REHEARSAL_PASSED
POST_PACKAGE_BLOCK_REHEARSAL_PASSED
POST_PACKAGE_PROVENANCE_REHEARSAL_PASSED
NO_EMBEDDED_RECORD_UNAVAILABLE_IN_REHEARSALS
REHEARSAL_DEPENDENCY_ACCESS_MATCHED_REGISTRY
INDEPENDENT_CAPSULE_VALIDATORS_PASSED
SOURCE_FROZEN
SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_V3_BUILD_A_B_BYTES_IDENTICAL
PYZ_V3_MEMBER_CLOSURE_PASSED
AUTHORITY_V4_BUILD_A_B_BYTES_IDENTICAL
FRESH_POST_PACKAGE_QUALIFICATION_PASSED
LAUNCH_CERTIFICATE_V2_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_PYZ_V3_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_PYZ_V3_CREATED
FINAL_PYZ_V3_MODE_0400
FINAL_PYZ_V3_IDENTITY_VERIFIED
FINAL_AUTHORITY_V4_CREATED
FINAL_AUTHORITY_V4_MODE_0400
FINAL_AUTHORITY_V4_IDENTITY_VERIFIED
FINAL_LAUNCH_CERTIFICATE_V2_CREATED
FINAL_LAUNCH_CERTIFICATE_V2_MODE_0400
FINAL_LAUNCH_CERTIFICATE_V2_IDENTITY_VERIFIED
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_AUDIT_HARNESS_V3_EMBEDDED_RECORD_BINDING_REPAIRED_READY_FOR_FRESH_AUDIT

the next task is exactly one fresh audit using:

1. final PYZ v3;
2. final authority v4;
3. final launch certificate v2;
4. current content bundle;
5. current content authority.

The wrapper authenticates launch certificate v2.

The harness receives authority v4 through `--harness-authority`.

Do not combine the audit with this repair task.

If the bounded repair attempt fails, retire the implementation generation and
do not issue another localized repair prompt.
```

### Source

Codex’s operative report in your message is the basis for this assessment.

**Confidence:** 0.999 that the prior audit authorization was consumed; 0.999 that no implementation-package verdict or audit capsule exists; 0.995 that the failure is an embedded-record resolution/package-binding defect; 0.93 that the exact causal is a stale hardcoded member path rather than a deeper registry omission—hence the prompt requires exact source/member crosswalking before repair.
