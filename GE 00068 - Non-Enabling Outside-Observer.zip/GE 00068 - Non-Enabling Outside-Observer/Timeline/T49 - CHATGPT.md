This is another **correct early stop**, but the defect is narrower than the preceding amendments.

A5 changed repository test identities. A4’s historical-regression policy is compiled into the successor and has no specification-level mechanism for declaring the newly added passing tests. Consequently, no valid B5 spec can express the frozen policy. Relaxing the comparison to permit arbitrary final-only passes would weaken regression detection; hardcoding the three A5 names into another function would preserve the design defect and force another successor patch whenever a legitimate test is added.

The right correction is a **successor-only Repair 10I-A6**:

- add a finite, exact declaration of permitted final-only passing identities to the historical-comparison spec;
- version the changed comparison spec/result schemas;
- remove the compiled-in passing-test allowlist from the acceptance path;
- require the declared set to equal the observed final-only passing set exactly;
- preserve all existing prohibitions on new failures, skips, disappearances, package aborts, panics, races, warnings, malformed streams, and unknown diagnostics.

A6 must not alter repository bytes. B5 remains unsealed and immutable. After A6, downstream validation should restart as **B6**, not resume B5. This follows the same precedent already recorded by A2: a bounded successor causal does not replace fresh downstream source controls. 

Pass this to Codex:

```text
Objective

Implement and seal a successor-only Repair 10I-A6 amendment that allows the
historical HEAD→final and Repair-9→final comparison specifications to declare
a finite, exact set of permitted final-only passing test identities.

The current sealed A4 successor cannot express that policy:

- SemanticComparisonSpecV1 has no declaration field.
- Strict decoding rejects an added field.
- declaredRepair10INewPassingIdentityV1 admits only the earlier structural
  privacy test.
- Repair 10I-A5 introduced three additional active passing root tests absent
  from both historical sources.

Do not weaken historical regression detection.
Do not permit arbitrary new passes.
Do not merely append the three names to a compiled-in allowlist.

Replace the compiled-in acceptance rule with one authoritative, exact,
comparison-spec declaration.

This is a parent-only successor implementation and validation turn.

Do not edit repository source.
Do not edit Repair 10I-A5.
Do not resume, seal, overwrite, or mutate B5.
Do not start B6.
Do not create a ZIP, handoff, capture child, or snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or claim independent acceptance.

No subagents. You are the sole writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A4 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Sealed A5 product repair

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Failed B5 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b5-closure-e260e1bb5ac4

Required new A6 child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-successor-closure-e260e1bb5ac4

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- protected package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require exact A5 identity:

- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- final T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- final inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A4 identity:

- successor T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- successor inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- members:
  12
- manifest SHA-256:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

A4 binaries:

repair10-runner:
  9df605f44e2a5fa10cd8bbc9360a7709a739f209fa4bf386353c8a790ef45961

repair10-compare:
  e53c6878acddb2e601376486ee8994d73bf30f176606ca7f42dea8434ddc6f0f

repair10-semantic:
  ef378cfe85c26f1e45eb6f4a0895d58c53647c1b74a685d1636bccbb81a52a66

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Completely reverify:

- Repair 10I-A;
- Repair 10I-A2;
- Repair 10I-A3;
- Repair 10I-A4;
- Repair 10I-A5;
- Phase H;
- B, B2, B3, B4;
- the B4 divergence-reconciliation child;
- failed B5.

Require B5 to remain unsealed. Verify that no B5 source control, comparison,
mutant execution, or product A/B execution occurred.

The generated bytecode incident in A5 must remain reconciled exactly as
reported: the governed A5 manifest path set must be exact, with no recreated
__pycache__ or pyc member.

Require A6 to be absent before creation.

Stop on any mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

## 2. Exact defect

Adopt:

ID:
REPAIR10I-A6-HISTORICAL-NEW-PASS-POLICY-001

Type:
successor historical-regression comparison policy defect

Severity:
HIGH

Classification:
validation successor; no product-source defect

Current mechanism:

- SemanticComparisonSpecV1 cannot carry a finite new-passing declaration.
- Strict JSON decoding rejects an unknown declaration field.
- declaredRepair10INewPassingIdentityV1 is compiled into semantic.go.
- The compiled rule admits only:

  execution-substrate::
  TestRepair10IStructuralPrivacyProjectionCausalControlsV1

Repair 10I-A5 added these additional root tests, absent from both historical
HEAD and Repair 9 and passing in exact A5 validation:

- execution-substrate::
  TestRepair10IDualSetpgidRaceReconciliationV1
- execution-substrate::
  TestRepair10ISetpgidFailureRequiresExactGroupProofV1
- execution-substrate::
  TestRepair10ISetpgidInverseMutantsV1

Therefore the complete finite declaration needed by each historical comparison
contains exactly four passing test identities:

1. execution-substrate::
   TestRepair10IStructuralPrivacyProjectionCausalControlsV1
2. execution-substrate::
   TestRepair10IDualSetpgidRaceReconciliationV1
3. execution-substrate::
   TestRepair10ISetpgidFailureRequiresExactGroupProofV1
4. execution-substrate::
   TestRepair10ISetpgidInverseMutantsV1

Before implementation, independently confirm from exact source and test-list
discovery that:

- all four identities exist in A5 final;
- all four are absent from historical HEAD;
- all four are absent from exact Repair 9;
- their package identity is exactly `execution-substrate`;
- no subtest component is part of these four identities.

Stop if this exact set is wrong:

REPAIR10I_A6_DECLARATION_SET_MISMATCH

## 3. Exact authorized successor scope

Copy all 12 A4 source members into A6 as independent regular files with no
hardlinks.

Exactly these three source files may change:

1. tool/source/FORMAT.md
2. tool/source/envelope/semantic.go
3. tool/source/envelope/envelope_test.go

The following nine members must remain byte- and mode-identical to A4:

- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-fixture/main.go
- tool/source/envelope/runner.go
- tool/source/envelope/source.go
- tool/source/envelope/testdata/evidence-manifest-v1.golden
- tool/source/envelope/testdata/source-inventory-v1.golden
- tool/source/go.mod

No repository source file may change.

If implementation requires a fourth successor source file, stop:

REPAIR10I_A6_SCOPE_EXPANSION_REQUIRED

## 4. Schema versioning

The comparison-spec acceptance semantics are changing. Do not silently widen
the existing v1 schema.

Introduce:

execution-substrate.repair10i.semantic-comparison-spec.v2

and:

execution-substrate.repair10i.semantic-comparison-result.v2

The v1 comparison spec and result remain parseable only as historical,
nonqualifying records. They cannot yield an A6/B6 qualifying comparison.

All other active Repair 10I schemas remain at their existing versions unless
compilation proves an unavoidable incompatibility. Stop rather than silently
versioning additional schemas.

Strict decoding remains mandatory.

A v1 document containing the new declaration field must be rejected.

A qualifying B6 comparison must consume v2 spec and produce v2 result.

## 5. Finite declaration model

Add one exact field to comparison-spec v2:

declared_final_only_passes

Use the existing lifecycle terminal-identity representation. Do not create a
second package/test/subtest grammar if the existing identity type can be
reused safely.

The declaration is an exact set, not a prefix, regex, glob, package allowlist,
or test-name convention.

Each entry must identify the complete terminal identity necessary to distinguish:

- package;
- test;
- subtest, where the lifecycle representation has one;
- identity kind, if the representation distinguishes package and test records.

Declaration validation requires:

- canonical byte ordering;
- no duplicate;
- no empty package;
- no empty test for a test identity;
- no package wildcard;
- no prefix or regex form;
- no unknown fields;
- no declaration of a package-terminal outcome as a substitute for its tests.

The field may be nonempty only when:

- left source class is `historical-head` or `historical-repair9`; and
- right source class is `pristine-final`; and
- the requested policy is historical no-regression.

It must be empty for:

- final↔fresh;
- final↔mutant;
- mutant↔fresh;
- fixture or other comparison classes.

A nonempty declaration in a prohibited comparison blocks qualification.

## 6. Exact comparison semantics

For a historical comparison, derive the complete observed set of identities
that are:

- absent from the historical baseline; and
- terminal `pass` in final.

Require exact set equality:

observed_final_only_passes == declared_final_only_passes

For every declaration require:

- baseline identity is absent;
- final identity exists exactly once;
- final terminal action is pass;
- no associated malformed or duplicate terminal exists.

Reject:

- a missing declared identity;
- an extra declaration;
- an undeclared final-only pass;
- a declaration already present in baseline;
- a declaration whose final outcome is fail or skip;
- a declaration used to mask a disappearance or changed existing outcome.

The declaration can permit only a final-only passing test identity.

It must never permit or mask:

- final-only failure;
- final-only skip;
- disappearance of a baseline identity;
- baseline pass→fail;
- baseline pass→skip;
- package abort;
- panic;
- race;
- warning;
- malformed JSON;
- incomplete or duplicate terminal;
- unknown diagnostic;
- qualification failure;
- custody/resource/terminal failure.

HEAD→final and Repair-9→final continue to be evaluated independently. Never
union their baselines or declarations.

## 7. One authoritative policy source

Remove `declaredRepair10INewPassingIdentityV1` from the active acceptance path.

Do not preserve a compiled-in privacy-test exception beside the new spec field.

The comparison spec is the sole mutable declaration source.

A6 source may retain a historical parser or compatibility helper only if it is
provably unreachable from v2 qualification and explicitly labeled historical.

FORMAT.md must say:

- the declaration is finite and comparison-local;
- it is installed before execution;
- it is not inferred from name prefixes;
- it admits only exact absent→pass identities;
- exact equality with the observed final-only pass set is mandatory;
- it does not weaken any hazardous regression rule;
- v1 comparison records cannot qualify A6/B6.

## 8. Result and reason-code requirements

Comparison-result v2 must report at least:

- DeclaredFinalOnlyPasses
- ObservedFinalOnlyPasses
- MissingDeclaredFinalOnlyPasses
- UndeclaredFinalOnlyPasses
- invalid declaration identities, if any
- existing factual lifecycle/diagnostic/canonical equality fields
- accepted outcome
- reason codes

Use a closed reason-code set including:

- declared-final-only-pass-admitted
- declared-final-only-pass-missing
- undeclared-final-only-pass
- declared-final-only-pass-present-in-baseline
- declared-final-only-pass-not-pass-in-final
- declared-final-only-pass-policy-not-applicable
- declared-final-only-pass-duplicate
- historical-comparison-v1-nonqualifying

Do not issue `declared-final-only-pass-admitted` unless exact observed/declared
set equality holds and every individual declaration satisfies its predicates.

Historical comparisons may still return `qualified-different`, exit 2, because
their overall semantics differ. The new declaration affects only the
no-final-regression adjudication.

A late qualification, custody, resource, terminal, or close fault remains exit
1 and cannot be converted to exit 2 by a valid pass declaration.

## 9. Mandatory vulnerable-precondition proof

Before editing, preserve a bounded A4 negative demonstrating:

- v1 strict decoding rejects a comparison-spec declaration field; and
- without source changes, A4 cannot authorize all four A5 final-only passing
  identities for HEAD→A5 or Repair-9→A5.

Do not run full B5 controls.

Synthetic lifecycle fixtures or exact retained semantics may be used to prove
the policy defect, provided their identities and construction are retained.

The negative is expected evidence and must remain nonqualifying.

## 10. Required A6 causal tests

Add active tests covering:

### Exact positive

Historical baseline omits exactly the four governed identities.

Final contains exactly those four identities as pass.

The v2 spec declares exactly those four.

Require:

- no final-only regression;
- declared and observed sets byte-equal;
- zero missing;
- zero undeclared;
- qualifying historical difference outcome;
- exit 2 at CLI level where the remaining historical semantic difference is
  otherwise clean.

Run separately for historical HEAD and Repair 9 source classes.

### Missing declaration

Omit each of the four identities one at a time.

Require blocked/rejected outcome and
`undeclared-final-only-pass`.

### Extra declaration

Add an identity absent from both baseline and final.

Require `declared-final-only-pass-missing`.

### Wrong identity

Mutate independently:

- package;
- test;
- subtest or equivalent identity component;
- identity kind where applicable.

Require rejection.

### Wrong outcomes

Require rejection when a declared identity is:

- already pass in baseline;
- fail in final;
- skip in final;
- duplicated in final;
- missing a terminal;
- accompanied by malformed or duplicate terminal evidence.

### Hazardous differences remain visible

With a correct pass declaration, independently add:

- final-only failure;
- final-only skip;
- baseline identity disappearance;
- package abort;
- panic;
- race;
- warning;
- malformed stream;
- unknown diagnostic.

Each must continue to block historical no-regression.

### Policy placement

Require rejection when a nonempty declaration appears in:

- final↔fresh;
- final↔mutant;
- mutant↔fresh;
- unsupported source-class ordering.

### Schema handling

Require:

- v2 strict decode and round trip;
- v1 with new field rejected;
- v1 historical input explicitly nonqualifying;
- unknown v2 field rejected;
- result v2 retains exact declarations and observations.

### Compiled-in rule removal

Add a causal control proving the structural privacy test is no longer admitted
when absent from the spec.

Adding it to the spec must admit it when the exact lifecycle condition holds.

No hidden built-in pass identity may remain.

## 11. Source-grounding control

Using complete private, no-hardlink source copies, produce a finite declaration
record binding:

- exact A5 T and inventory;
- exact HEAD identity;
- exact Repair 9 T/inventory;
- package/test identities;
- source files containing the declarations;
- test-list outputs or an independently parsed active-test inventory;
- proof each test is absent from HEAD and Repair 9 and present in A5.

The source-grounding record is evidence for future B6 spec construction. It is
not itself a comparison qualification.

Do not modify repository source or create generated files in the repository.

## 12. Build and hard gate

Use pinned Go 1.26.5 in two fully disjoint private controls.

Each side must have:

- independently copied A6 source;
- private HOME/XDG;
- private GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- no shared writable cache or build root;
- umask 077;
- offline module posture.

Run on each side:

gofmt -d FORMAT.md is not applicable; run no-write gofmt over all Go members.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

Build:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require all four A/B binary pairs to be:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- mode 0700;
- built from exact A6 source;
- free of unexpected paths in build information.

Retain exact source inventories, T values, environments, argv, raw streams,
exits, terminal records, and binary identities.

## 13. Compatibility causals

Using bounded synthetic or retained semantic fixtures, require A6 to preserve:

- final↔fresh:
  qualified-equal, accepted true, zero unknowns, exit 0;
- final↔mutant:
  exact declared mutant delta, qualified-different, zero unknowns, exit 2;
- mutant↔fresh:
  exact inverse delta, qualified-different, zero unknowns, exit 2.

These are successor tool causals only. They do not qualify B6.

Also require historical fixtures with the exact four declarations to reach the
historical no-regression result without permitting any hazardous delta.

## 14. Evidence child and seal

A6 must contain private top-level directories appropriate to:

- opening;
- tool;
- controls;
- commands;
- validation;
- findings;
- closeout.

Retain:

- opening repository/A4/A5/lineage verification;
- B5 incompatibility finding and blocked adjudication;
- bytecode side-effect restoration record copied by identity, not modified;
- complete A4 vulnerable-precondition control;
- exact A4→A6 source delta;
- schema-versioning decision;
- finite declaration source-grounding record;
- all positive and negative causal results;
- two A/B source and binary controls;
- command intents, argv, cwd, environment, raw streams, exits, terminal and
  resource records;
- failed and superseded attempts;
- cleanup and two absence epochs;
- implementation report;
- A6 source inventory and T;
- literal assertion mapping;
- exact path/mode/size/hash list.

At closeout require:

- exactly the three authorized successor paths changed;
- the other nine members byte-identical to A4;
- repository T/inventory/membership unchanged;
- A/A2/A3/A4/A5/H/B/B2/B3/B4/B5 and divergence reconciliation unchanged;
- no private control, source, cache, binary-temporary, process, descriptor,
  listener, socket, or report residue;
- two fresh absence epochs.

Install the detached digest before the evidence manifest.

Install evidence-manifest-v1.txt as the final A6 mutation.

Write nothing into A6 afterward.

Perform a complete read-only post-seal verification.

## 15. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- wrong exact declaration set;
- need for a fourth successor source file;
- repository-source mutation;
- inability to remove the compiled-in pass exception from active policy;
- declaration acting as a prefix, regex, or package-wide exception;
- missing exact observed/declaration set equality;
- any hazardous regression admitted by a valid declaration;
- declaration admitted outside historical comparisons;
- v1 comparison input qualifying A6;
- A/B source or binary inequality;
- test, race, cleanup, or sealing failure;
- unknown diagnostic or malformed causal stream;
- surviving resource or private root.

## 16. Verdicts

Opening mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

Wrong frozen declaration set:

REPAIR10I_A6_DECLARATION_SET_MISMATCH

Scope expansion required:

REPAIR10I_A6_SCOPE_EXPANSION_REQUIRED

Source/tool implementation or validation failure:

REPAIR10I_A6_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6_HISTORICAL_POLICY_PATCH_SEALED_READY_FOR_B6_RESTART

The success report must include:

- A4 and A6 source T/inventory;
- exact three-file delta;
- schema v2 identities;
- exact four declared identities;
- vulnerable A4 negative;
- all declaration positives/negatives;
- proof hazardous regressions remain blocked;
- proof the compiled-in exception is absent from active policy;
- A/B source and binary identities;
- compatibility causal outcomes;
- manifest SHA-256 and payload count;
- cleanup and two absence epochs;
- explicit statement that B6 was not started.

No B6.
No snapshot.
No ZIP or handoff.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A6, start a completely new B6 child and rerun the five controls, five comparisons, and product A/B. No B5 record can qualify B6. Any successor byte amendment requires a fresh downstream cycle; a prior bounded causal remains only predecessor evidence.  Any later byte-changing repair likewise requires new validation, new provenance, and a fresh independent audit. 

### Sources

- Codex’s `REPAIR10I_B5_SOURCE_OR_TOOL_REPAIR_REQUIRED` report in the current turn.
- Sealed A2 restart precedent. 
- Governed Execution repair and re-audit protocol. 
- Provenance limits: identical bytes and manifests do not establish correctness or sufficient validation. 

**Confidence:** 0.995 that B5 stopped correctly; 0.98 that this is a successor-only policy/schema defect; 0.96 that a finite spec-carried declaration is the right durable correction; 0.99 that hardcoding the three A5 names would be the wrong repair; 0.995 that the post-A6 validation must restart as fresh B6.
