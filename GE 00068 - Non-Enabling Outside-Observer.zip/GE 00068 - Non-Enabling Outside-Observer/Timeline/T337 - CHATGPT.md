## Assessment

The successor is ready for a **decisive fresh independent audit**, not acceptance.

The report claims a coherent repair of all four blockers:

- **A:** effective Python isolation state and literal `-I -S -B` tokens are now checked independently.
- **C:** copied destinations are reopened through fresh no-follow descriptors and rehashed rather than “reverified” from cached identities.
- **H:** success is staged and fully qualified before one exclusive `renameatx_np(..., RENAME_EXCL)` publication establishes the authoritative internal commit point.
- **I:** producer case 28 now genuinely crosses the wrapper boundary and rejects a payload changed after request binding.
- **J:** the accepted schema closure reportedly remains intact.

The highest-risk surface is still **H**. The audit must independently establish that the exclusive rename is the sole linearization point, that no incomplete or foreign final commit can be adopted, and that all postpublication failures are consistently non-downgrading without implying crash durability. A and C also require adversarial causals beyond the producer’s own cases. I requires case-level inspection across the full producer matrix, not just case 28.

One provenance detail should be treated proportionally: the report mentions several recorder continuations and preseal failed checks. Those are relevant evidence-lineage inputs, but they do not replace fresh behavioral validation and should not automatically disqualify the package if the final bytes and retained qualifying evidence close exactly.

Proceed directly to one parent-owned independent audit. No additional findings reconciliation is warranted before that audit.

```text
FRESH INDEPENDENT PARENT-OWNED AUDIT —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP A/C/H/I REPAIR SUCCESSOR

This is an independent audit of one exact source-external package.

Do not modify or repair the audit target.
Do not modify any supplied root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 targets, product source, or unrelated
evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents or direct auditors.

Use one parent-owned audit execution path.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact audited bootstrap-package bytes and their
bounded source-external process behavior.

ACCEPT grants no authority over:

- a candidate repository;
- Strategic B;
- V1/V2/V3 targets;
- product or runtime behavior;
- deployment;
- external publication;
- Git commit;
- readiness;
- the eventual V3 target-audit verdict;
- A6.

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected root identity:

- device/inode:
  16777234 / 179405897
- physical mode:
  0700
- expected producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_A_C_H_I_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected temporal final inventory:

closeout/temporal-final-inventory-a-c-h-i-v1.json

- size:
  313198
- SHA-256:
  7e3f7103e057a251a674c18508c043b7b7257bf3cfe1d7f7c2e39fa5f4213f81
- entries:
  1205

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

Expected represented closure:

- 1207 represented entries;
- 334 directories including root;
- 873 represented nonmanifest regular files;
- 875 physical regular files including the two manifests;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- regular files mode 0600 and link count 1;
- no write after terminal manifest closure.

Independently derive and authenticate:

- the package’s primary verdict record;
- the sealed implementation report;
- the complete semantic path set;
- every validation result;
- every failed/superseded-attempt record;
- every retained replay fixture;
- the temporal inventory chronology;
- the exact terminal write chronology.

Do not use the implementation report as artifact authority.

──────────────────────────────────────────────────────────────────────────────
2. EXACT PREDECESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

CURRENT_PREDECESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

Expected identity:

- device/inode:
  16777234 / 179272855
- mode:
  0700

Expected manifests:

- size:
  237800 each
- SHA-256:
  adf2a6f8314327b07883153f95eae567ecd802413d2b0acdeebfc2bf56d47f8e
- byte-identical:
  required

Expected represented closure:

- 1140 entries;
- 333 directories including root;
- 807 nonmanifest files;
- 809 physical files including manifests.

Expected predecessor semantic identities:

source/full_audit_bootstrap_v1.py

- size:
  92561
- SHA-256:
  2764bc8b7972c199df4bfc80f04ede124931247f74e52325e47dd74071228f79

contract/full-audit-bootstrap-contract-v1.json

- size:
  14481
- SHA-256:
  9fc27aa61dcff5e19a57936c1002de97d567e62d873cb787c562477002b7a652

contract/qualification-result-contract-v1.json

- size:
  2275
- SHA-256:
  d3b0cba5926a86a1a40db9034034120b7f9f2f691af4a11dbc37a6b275041dda

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  9785
- SHA-256:
  08714f519f88bdc636c11c353b2eeadc32c5951689799629834637934c0a599e

schemas/process-self-check-result-v1.schema.json

- size:
  6554
- SHA-256:
  8a73bd13ee61b1a31d072d2a93c4e635cae14f0ad9f399dbef63954bd053abbf

schemas/root-rebinding-proof-v1.schema.json

- size:
  4662
- SHA-256:
  010a2d604980a914f8460b615dbfa62f125cb8f8d3a9584caf22499b9a7964cd

tests/failure_injection_driver_v1.py

- size:
  10506
- SHA-256:
  393f6b927bd245a1dd8901fa08f06fe5ca4a68d8d1389f4a5a8d25bec3f1c527

tests/test_full_audit_bootstrap_v1.py

- derive and authenticate from the predecessor manifests and the successor
  owner/hunk ledger.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING BLOCKING AUDIT
──────────────────────────────────────────────────────────────────────────────

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

Expected primary verdict:

BLOCK

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  243162 each
- SHA-256:
  8438d5d1571e8cfa462f53a6df0744749aab281fb9181e602bd02f82f9dc0063
- byte-identical:
  required

Authenticate and inspect completely:

closeout/primary-verdict.json
closeout/final-audit-report.md
analysis/severity-ranked-residual-findings.json
causals/finding-a-interpreter-flags.json
causals/finding-c-post-copy.json
causals/predecessor-h-causal.json
validation/fresh-publication-boundary-matrix.json
analysis/commit-point-semantics.json
analysis/producer-case-level-adjudication.json
causals/finding-i-wrong-payload-mutation.json
validation/fresh-predecessor-j-reproduction-v2.json
validation/fresh-independent-j-matrix-v3.json
analysis/qualification-result-closure.json
analysis/replay-evidence-closure.json
analysis/failure-hook-reachability.json
analysis/predecessor-successor-delta.json
analysis/repair-authority-hunk-ledger.json
closeout/explicit-confirmations.json
closeout/supplied-root-closing-equality.json

Treat that audit as the repair-authority source for A, C, H, and I and as the
accepted Finding J regression baseline.

──────────────────────────────────────────────────────────────────────────────
4. OPTIONAL IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

Open only when required by a concrete check:

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter mode is report-only.

Every optional supplied root opened becomes subject to complete opening/closing
equality.

The older predecessor and findings-reconciliation roots are not required
unless an exact target record cannot otherwise be adjudicated.

──────────────────────────────────────────────────────────────────────────────
5. PROCESS AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Read this prompt completely before invoking a tool.

Then emit:

AUDIT_EPOCH_START

Use:

top_level_launch_authority = "codex-platform-tool-transcript"

and:

audit_root_does_not_self_attest_parent_process_creation = true

Use one parent-owned execution path.

Do not create direct auditors.
Do not create subagents.

Retain four parent-generated analytical perspectives:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

They are analytical projections, not separate authorities.

Every subprocess must use one contemporaneous child recorder.

For every child retain:

- contiguous ordinal;
- durable start record before spawn;
- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- reaping;
- descriptor closure;
- purpose;
- paths written;
- qualifying or failed/superseded disposition.

Pure in-process parsing, hashing, and filesystem inspection do not require
fictional process records.

A child-ledger gap requires:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
6. FRESH AUDIT ROOT AND OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-

Before supplied-root inspection retain:

opening/bootstrap-start.json
provenance/parent-source.py
provenance/parent-process-start.json

Run recorder self-causals:

- nonexistent executable / ENOENT;
- `/usr/bin/true` / exit 0;
- empty streams;
- reaping;
- descriptor closure.

Then:

1. Verify successor identity and complete manifest closure.
2. Verify predecessor identity and complete manifest closure.
3. Verify blocking-audit identity and complete manifest closure.
4. Bind every fixed identity above.
5. Verify supplied roots are pairwise distinct and do not alias the audit root.
6. Capture complete lstat/no-follow opening inventories.
7. Retain:
   `opening/opening-gate-result.json`

Do not begin substantive inspection before this gate passes.

Stop with AUDIT_PROVENANCE_MISMATCH for:

- actual supplied-root drift;
- mutation;
- aliasing;
- missing fixed input;
- manifest failure;
- process-record failure.

──────────────────────────────────────────────────────────────────────────────
7. EXACT PREDECESSOR-TO-SUCCESSOR DELTA
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the complete delta.

The report claims exactly six changed semantic paths:

source/full_audit_bootstrap_v1.py
contract/full-audit-bootstrap-contract-v1.json
contract/qualification-result-contract-v1.json
schemas/full-audit-bootstrap-contract-v1.schema.json
tests/failure_injection_driver_v1.py
tests/test_full_audit_bootstrap_v1.py

It claims these two authorized J-owned schemas remain byte-identical:

schemas/process-self-check-result-v1.schema.json

- size:
  6554
- SHA-256:
  8a73bd13ee61b1a31d072d2a93c4e635cae14f0ad9f399dbef63954bd053abbf

schemas/root-rebinding-proof-v1.schema.json

- size:
  4662
- SHA-256:
  010a2d604980a914f8460b615dbfa62f125cb8f8d3a9584caf22499b9a7964cd

Expected known successor identities:

source/full_audit_bootstrap_v1.py

- size:
  116052
- SHA-256:
  57b6a3f51bce996287dd0a7e302b1885560fae3a45956130d02b6d3aa88e4a35

contract/full-audit-bootstrap-contract-v1.json

- size:
  17461
- SHA-256:
  15fb94cfd94fd0467650dca4e56a5e7e5d3fea70de5eb79d084991cb2cfd4ac0

contract/qualification-result-contract-v1.json

- size:
  3753
- SHA-256:
  0a25d2b65b60fed54877bd7bdcf17ffa0005063c9c967dd8fcb00d15d2a9d803

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  12477
- SHA-256:
  f4bc62ae7cfc7c968fac3ae48658316ed3b25270b29ddb043f9abb70be4f3693

Derive the exact predecessor and successor identities for both changed test
files from the package manifests and:

analysis/final-owner-and-hunk-ledger-a-c-h-i-v1.json

Expected ledger identity:

- size:
  35497
- SHA-256:
  4a96e0bee16042628a83bb050aa5f3d66b14e1c02651ab6c5443da3c69bf9d28

Require:

- exactly six semantic changes;
- two explicitly authorized unchanged J schemas;
- every other common semantic path byte-identical;
- no executable production source hidden under evidence namespaces;
- no evidence path imported by future consumer production source;
- all added paths classified.

Reconstruct the claimed added-path set rather than trusting a reported count.

──────────────────────────────────────────────────────────────────────────────
8. REPAIR-AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

For every changed hunk record:

- path;
- old/new line range;
- finding owner:
  A, C, H, or I;
- blocking-audit evidence;
- behavior change;
- contract change;
- schema change;
- authority effect;
- validation-only status.

Require every semantic hunk to be authorized by A, C, H, or I.

Verify Finding J was preserved rather than silently redefined.

Return BLOCK for:

- an unauthorized semantic change;
- a hidden process redesign;
- authority widening;
- an unversioned incompatible contract redefinition.

──────────────────────────────────────────────────────────────────────────────
9. FINDING A — STATIC CONTRACT AND SOURCE
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the complete interpreter-invocation contract.

Determine exact required evidence for:

- pinned interpreter path and bytes;
- effective `sys.flags.isolated`;
- effective `sys.flags.no_site`;
- effective `sys.flags.dont_write_bytecode`;
- literal `-I`;
- literal `-S`;
- literal `-B`;
- sanitized `sys.orig_argv`;
- script operand;
- owning contract;
- authority and nonauthority;
- pass/fail;
- first blocker.

Inspect exact token parsing.

Test for:

- separate tokens `-I -S -B`;
- reordered tokens;
- duplicate tokens;
- combined option forms, if Python accepts them;
- options after the script operand;
- a payload argument equal to `-I`, `-S`, or `-B`;
- a script path containing a flag-like substring;
- stale or forged observation;
- missing observation;
- contradictory effective/token state.

Do not let an argument after the script operand satisfy an interpreter-option
requirement.

──────────────────────────────────────────────────────────────────────────────
10. FINDING A — FRESH DYNAMIC CAUSALS
──────────────────────────────────────────────────────────────────────────────

Run fresh audit-owned invocations using only audit-owned output roots:

1. exact `-I -S -B`;
2. missing `-I`;
3. missing `-S`;
4. missing `-B`;
5. missing all;
6. missing `-B` plus `PYTHONDONTWRITEBYTECODE=1`;
7. required tokens placed only after the script operand;
8. one required token duplicated but another absent;
9. stale observation injected into a validator;
10. missing observation;
11. contradictory observation;
12. wrong interpreter identity with correct flags, using a safe fixture when
    possible.

For each retain:

- exact argv;
- cwd;
- environment;
- stdout/stderr;
- exit;
- generated records;
- success-commit posture;
- target-inspection posture;
- child-process posture;
- cleanup.

Require all invalid forms to reject before authoritative success.

──────────────────────────────────────────────────────────────────────────────
11. FINDING C — STATIC REVERIFICATION ANALYSIS
──────────────────────────────────────────────────────────────────────────────

Identify the exact production functions for:

- source observation;
- copy;
- initial destination observation;
- file fsync;
- close;
- fresh reopen;
- pre-read fstat;
- byte read/hash;
- post-read fstat;
- pathname rebind, if any;
- final comparison;
- record production.

Prove the fresh reverification does not use cached initial identity as its
acceptance oracle.

Determine race coverage for:

- replacement before open;
- replacement after open;
- path replacement while the old descriptor remains held;
- in-place mutation during read;
- mode mutation;
- link-count mutation;
- disappearance;
- type change.

A held descriptor alone is insufficient if the final pathname may silently
rebind to a different object and the contract claims path-to-byte custody.

──────────────────────────────────────────────────────────────────────────────
12. FINDING C — FRESH DYNAMIC CAUSALS
──────────────────────────────────────────────────────────────────────────────

Run fresh audit-owned causals:

1. stable copied destination;
2. same-size in-place mutation before reopen;
3. same-size replacement before reopen;
4. replacement between pathname observation and descriptor open;
5. replacement after descriptor open;
6. pathname replacement while descriptor remains on old object;
7. in-place mutation during held read;
8. mode change;
9. hardlink/link-count change;
10. truncate;
11. append;
12. disappearance;
13. regular-to-symlink change;
14. regular-to-directory or special-type change, where safely possible;
15. cached-observation substitution;
16. unsupported no-follow capability;
17. read error or partial-read simulation, when a supported test boundary
    exists.

For each require the exact expected classification.

Determine whether final path rebinding is checked. Return BLOCK if altered
destination bytes or an unintended replacement can qualify.

──────────────────────────────────────────────────────────────────────────────
13. FINDING H — PUBLICATION MODEL SOURCE REVIEW
──────────────────────────────────────────────────────────────────────────────

Reconstruct the publication state machine directly from source.

Identify:

- result creation;
- outcome creation;
- staged commit creation;
- stage write/fsync/close;
- stage-directory synchronization;
- stage no-follow reopen;
- stage identity and byte verification;
- final destination preflight;
- exclusive publication;
- final authority transition;
- postcommit operations;
- cleanup;
- retry rules.

Verify stage and final destination:

- share the required filesystem;
- use the correct parent or bounded sibling relationship;
- remain inside the fresh audit-owned root;
- cannot alias supplied roots;
- cannot alias result/outcome;
- cannot be symlinked or hardlinked into eligibility.

──────────────────────────────────────────────────────────────────────────────
14. FINDING H — EXCLUSIVE PUBLICATION PRIMITIVE
──────────────────────────────────────────────────────────────────────────────

Inspect the exact Darwin binding for:

`renameatx_np(..., RENAME_EXCL)`

Verify:

- function signature;
- integer constants;
- argument encoding;
- directory-relative or absolute-path semantics;
- source/destination identity;
- error handling;
- `EEXIST` classification;
- unsupported-capability classification;
- no fallback;
- no overwrite-capable rename branch;
- no copy/delete branch;
- no link/unlink emulation;
- no shell or external command.

Run a capability causal proving:

- absent destination succeeds;
- existing destination fails without mutation;
- foreign destination remains unchanged;
- source stage remains or is disposed according to the contract;
- no alternate branch executes.

Return BLOCK if exclusive no-replace publication is not established.

──────────────────────────────────────────────────────────────────────────────
15. FINDING H — AUTHORITATIVE COMMIT RECORD
──────────────────────────────────────────────────────────────────────────────

Independently derive the exact final success-commit field map.

Require binding to:

- schema;
- owning contract ID and exact identity;
- invocation or audit-root identity;
- result path/size/SHA-256;
- outcome path/size/SHA-256;
- source identity;
- completed step;
- staged-publication protocol;
- exclusive-publication mechanism;
- success status;
- authority:
  internal evidence-state commitment only;
- nonauthority:
  no Git, external publication, product, runtime, deployment, readiness, V3
  verdict, or A6 authority.

Verify an unrelated invocation cannot construct a byte-valid commit that the
current invocation adopts.

Verify a stale commit cannot be accepted after result/outcome replacement.

──────────────────────────────────────────────────────────────────────────────
16. FINDING H — FRESH INDEPENDENT PUBLICATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not use the producer 30-case matrix as the audit oracle.

Derive all reachable boundaries from source and execute a fresh matrix covering
at minimum:

1. before result creation;
2. result write;
3. result fsync;
4. result close;
5. before outcome creation;
6. outcome write;
7. outcome fsync;
8. outcome close;
9. stage creation;
10. stage write;
11. stage fsync;
12. stage close;
13. stage-directory synchronization;
14. stage reopen;
15. stage byte verification;
16. stage identity verification;
17. before exclusive publication;
18. publication capability failure;
19. exclusive publication failure;
20. successful exclusive publication;
21. arbitrary preexisting final;
22. byte-valid preexisting final;
23. preexisting final from another invocation/root identity;
24. foreign final arriving immediately before publication;
25. stage/destination cross-filesystem condition;
26. postpublication final-parent synchronization fault;
27. postpublication final-path observation fault;
28. postpublication cleanup fault;
29. postpublication stdout/reporting fault;
30. postpublication descriptor-close fault;
31. precommit fragment-cleanup fault;
32. fresh-root retry after precommit failure;
33. same-root retry after precommit failure;
34. second invocation after committed success;
35. result mutation after commit;
36. outcome mutation after commit;
37. final commit mutation after publication;
38. stage residue after successful publication.

Add every further reachable boundary found in source.

For each retain:

- source identity;
- test-driver identity;
- exact injection point;
- reachability;
- argv/cwd/environment;
- streams;
- exit/signal;
- result/outcome/stage/final posture;
- complete fixture inventory;
- expected and actual classification;
- retry posture;
- cleanup;
- replay recipe.

Require zero false acceptance, zero false rejection, zero skip, and complete
replay closure.

Do not classify an unsupported injection as a pass.

──────────────────────────────────────────────────────────────────────────────
17. FINDING H — PRECOMMIT AND POSTCOMMIT SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Independently establish:

A. Before exclusive publication

- no authoritative success;
- final path absent;
- stage nonauthoritative;
- any failure produces canonical failure evidence;
- same root nonresumable;
- fresh-root retry permitted only when contractually safe.

B. At successful exclusive publication

- one linearization point;
- final commit becomes authoritative;
- stage no longer authoritative;
- no adoption.

C. After publication

For every operation after the rename identify:

- exact purpose;
- whether it can alter final bytes;
- whether failure changes process exit;
- whether failure writes an observation;
- whether failure can create contradictory failure authority;
- whether retry can occur;
- whether success remains independently consumable.

Postcommit failures may be non-downgrading only if the contract and records make
that unambiguous.

Verify the package makes no crash/power-loss durability claim when final-parent
sync is postcommit and non-downgrading.

──────────────────────────────────────────────────────────────────────────────
18. FINDING H — PRODUCER MATRIX AND REPLAY CLOSURE
──────────────────────────────────────────────────────────────────────────────

Audit every producer publication case.

Require:

- exact 30-case registry;
- exact name digest:
  `7e22e5e9f8362e1605f78fac137479b2c48745d1a38a1b88264ccfb6b0142bb4`;
- exact source identity;
- exact driver identity;
- retained fixture source;
- retained immutable operands;
- exact injection;
- replay recipe;
- process evidence;
- result/outcome/stage/final evidence;
- cleanup;
- expected and actual classification.

Verify no producer case depends on a deleted fixture or generated state not
covered by the package manifests.

Compare producer cases with the fresh independent matrix and identify any
boundary omitted or misclassified by the producer.

──────────────────────────────────────────────────────────────────────────────
19. FINDING I — CASE 28 REAL WRAPPER EXECUTION
──────────────────────────────────────────────────────────────────────────────

Inspect the exact producer implementation for case 28.

Require that it:

1. materializes a fresh root through the bootstrap;
2. binds request payload size and SHA-256;
3. mutates payload bytes afterward while preserving size;
4. invokes the copied wrapper using pinned Python and exact wrapper CLI;
5. receives wrapper rejection at `payload_identity:sha256`;
6. records that compilation did not begin;
7. records that execution did not begin;
8. produces no expected payload output;
9. creates no child;
10. inspects no target;
11. retains phase start/outcome, streams, exit, and fixture identity.

Independently rerun the case without producer helper functions.

Require the producer’s recorded mechanism classification to match the actual
execution path.

──────────────────────────────────────────────────────────────────────────────
20. FINDING I — COMPLETE PRODUCER CASE CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Inspect all 50 producer cases individually.

For each record:

- name;
- claimed mechanism;
- actual source path and function;
- source/static check;
- schema mutation;
- local data mutation;
- production-input mutation;
- wrapper integration;
- bootstrap integration;
- hard-coded fixture;
- synthetic result;
- child process used;
- production boundary actually reached;
- report description accurate;
- retained replay input;
- acceptance role.

Return BLOCK if another materially inaccurate integration claim exists or if
qualification materially depends on a self-fulfilling case represented as an
external rejection causal.

Static checks are permitted when described accurately.

──────────────────────────────────────────────────────────────────────────────
21. FINDING J REGRESSION
──────────────────────────────────────────────────────────────────────────────

Independently authenticate the successor’s J regression:

validation/a-c-h-i-repair/fresh-independent-j-regression-final-v1.json

Expected:

- cases:
  928
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero duplicate;
- zero missing name;
- zero skip;
- case-name digest:
  1182d02ab865ca2f504dc69d0a88ff118022e98a75433b30701ee0cbd0032d80

Independently explain and validate:

- the 919 preserved applicable cases;
- the nine obsolete H cases removed;
- the nine repaired H cases added.

Run a fresh audit-owned targeted J matrix against every changed contract/schema
surface, including:

- interpreter observation;
- fresh copy reverification;
- staged commit;
- final commit;
- postcommit observation;
- qualification result;
- producer case registry;
- publication matrix.

Require accepted Finding J closure to remain intact.

──────────────────────────────────────────────────────────────────────────────
22. CONTRACT–SCHEMA–SOURCE–RECORD CONSISTENCY
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct complete field maps for all affected record families.

The producer claims:

- 14 record families;
- 1052 field rows.

Do not accept those counts without reconstruction.

For every field record:

- JSON pointer;
- owner;
- required/optional;
- type;
- enum or constant;
- cardinality;
- unknown-key rule;
- lifecycle applicability;
- success/failure/precommit/postcommit applicability;
- cross-field rule;
- contract identity;
- authority role;
- producer function;
- consumer.

Require agreement among:

- contract;
- JSON Schema;
- source;
- actual record;
- runtime validator, if any;
- tests;
- independent validator.

Determine whether any current contract/schema ID was silently redefined
incompatibly. Return BLOCK for an unauthorized versioning conflict.

──────────────────────────────────────────────────────────────────────────────
23. FRESH INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Construct one audit-owned validator that imports neither producer helper code
nor producer fixtures as its oracle.

It must independently test:

- A interpreter-token and effective-state closure;
- C fresh-reopen and race closure;
- H staged/final publication protocol;
- exclusive no-replace publication;
- no existing-final adoption;
- precommit/postcommit behavior;
- retry behavior;
- producer case 28;
- complete producer mechanism classification;
- qualification-result consistency;
- Finding J preservation.

Use an independently literal case-name and expected-reason registry.

Require:

- exact count;
- uniqueness;
- two-way name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Compare against, but do not inherit, the producer’s reported `104/104` result.

──────────────────────────────────────────────────────────────────────────────
24. TWO FRESH MATERIALIZATIONS
──────────────────────────────────────────────────────────────────────────────

Run the successor bootstrap twice into physically distinct audit-owned roots.

For each retain:

- exact argv;
- cwd;
- explicit environment;
- stdout/stderr;
- exit;
- root locator;
- complete inventory;
- interpreter observation;
- copy observations;
- fresh post-copy reverifications;
- auxiliary records;
- launch contract;
- rebinding proof;
- Carrier 0002 payload;
- Carrier 0002 request;
- staged commit posture;
- final commit posture.

Before Carrier 0002 require:

- distinct roots;
- exact copied bytes;
- every copied destination freshly reverified;
- normalized auxiliary records equal;
- normalized launch contracts equal;
- payload bytes equal;
- normalized requests equal;
- no child;
- no target inspection;
- correct success-publication state.

Independently determine whether materialization itself is intended to publish
the internal success commit before the handoff. Require behavior to match the
closed contract.

──────────────────────────────────────────────────────────────────────────────
25. TWO FRESH CARRIER 0002 HANDOFFS
──────────────────────────────────────────────────────────────────────────────

Execute Carrier 0002 in both roots.

Require:

- request admission;
- constructed launch;
- wrapper admission;
- phase start/outcome;
- compilation/execution;
- same PID;
- exact constructed environment;
- exact observed owned values;
- diagnostic-only additional names;
- wrapper SHA exact and once;
- CLI conformance;
- no child;
- no target inspection;
- expected outputs complete;
- payload success;
- wrapper exit 0;
- authoritative final commit remains consistent with result/outcome;
- no second publication or adoption.

Normalize:

- root-bound paths;
- PIDs;
- root-derived environment values;
- hashes derived from normalized maps.

Require normalized semantic equality.

──────────────────────────────────────────────────────────────────────────────
26. PRODUCTION EXPORT, SECURITY, AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Inspect all changed and executable package source.

Require no:

- network;
- Git;
- shell;
- candidate or target path;
- broad Downloads scan;
- latest/prefix selection;
- existing-root adoption;
- unsafe symlink fallback;
- overwrite-capable publication fallback;
- hidden production test hook;
- credential output;
- dependency on evidence-only materialization copies;
- automatic V3 target progression.

Classify every newly added evidence path.

Require:

- no executable production source hidden under evidence namespaces;
- no future-consumer dependency on qualification-only files;
- all fault hooks qualification-only and production-inaccessible;
- internal commit clearly non-Git and nonpublication;
- package remains process-only.

Perform bounded sensitive scans without emitting matched payloads.

──────────────────────────────────────────────────────────────────────────────
27. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Inspect completely:

provenance/failed-and-superseded-attempts-a-c-h-i-v1.json
provenance/failed-and-superseded-attempts-a-c-h-i-addendum-v1.json
provenance/recorder-continuation-3-recovery-v1.json
provenance/preseal-failed-checks-a-c-h-i-v1.json

For every attempt determine:

- source identity;
- operation;
- first blocker;
- filesystem effects;
- child-process effects;
- retained outputs;
- superseding attempt;
- whether it contributes any final identity, count, causal, or verdict.

Verify no superseded output contaminates:

- final test counts;
- publication matrix;
- J regression;
- independent validator;
- manifest;
- readiness verdict.

Recorder continuation is evidence only; determine whether any process gap or
unrecorded mutation exists. A qualifying implementation does not require
perfect producer-process aesthetics, but it does require truthful final
provenance and no unexplained supplied-root mutation.

──────────────────────────────────────────────────────────────────────────────
28. FOUR PARENT-GENERATED PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

Each must record:

- exact operands;
- findings;
- limits;
- unresolved questions;
- uninspected scope.

These are parent-owned analyses, not separate auditors.

Do not create direct auditors or subagents.

──────────────────────────────────────────────────────────────────────────────
29. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all work:

- repeat complete lstat/no-follow inventories for every supplied root opened;
- require opening/closing equality;
- verify pinned Python unchanged;
- retain complete inventories for all audit-owned fixtures;
- remove only audit-owned fixture/private roots;
- perform two fresh `lstat` observations per removed root;
- require ENOENT twice;
- verify zero process survivor;
- verify zero descriptor survivor.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
30. FINAL AUDIT CAPSULE
──────────────────────────────────────────────────────────────────────────────

Finalize before sealing:

- opening records;
- parent source;
- child-process ledger;
- complete package delta;
- repair-authority analysis;
- A static and dynamic adjudication;
- C static and dynamic adjudication;
- H source model;
- exclusive-publication proof;
- fresh independent publication matrix;
- commit-point semantics;
- replay closure;
- hook reachability;
- I case-28 causal;
- complete 50-case classification;
- J regression;
- contract/schema/source/record maps;
- independent validator;
- two materializations;
- two handoffs;
- four parent perspectives;
- security/authority analysis;
- attempt adjudication;
- closing equality;
- cleanup;
- final report;
- temporal final inventory.

Then create `manifest/` and two independently generated terminal manifests.

Require:

- root represented;
- every directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- regular files mode 0600 and link count 1;
- byte-identical manifests;
- no filesystem write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- audit provenance qualifies;
- exact six-path semantic delta qualifies;
- no unauthorized semantic drift exists;
- A effective-state and token verification pass independently;
- all invalid A invocations reject;
- C fresh no-follow reverification passes;
- all C mutation and race causals classify correctly;
- staged success is nonauthoritative;
- exclusive atomic no-replace publication is established;
- no fallback exists;
- no preexisting final is adopted;
- the authoritative commit point is unambiguous;
- precommit failures are nonauthoritative;
- postcommit dispositions are explicit and non-downgrading;
- fresh independent publication matrix passes;
- replay evidence is complete;
- no production-reachable hook exists;
- case 28 genuinely executes the wrapper;
- all 50 producer cases are accurately classified;
- Finding J remains closed;
- independent validator passes;
- two materializations pass;
- two handoffs pass;
- production export/security/authority checks pass;
- opening/closing equality passes;
- audit capsule closes;
- no acceptance-affecting residual finding remains.

Return BLOCK for any repairable:

- implementation defect;
- contract/schema defect;
- validation/evidence defect;
- false acceptance;
- unresolved publication boundary;
- ambiguous commit point;
- unsafe retry behavior;
- existing-final adoption;
- interpreter-flag bypass;
- cached or incomplete copy reverification;
- misleading producer case;
- Finding J regression;
- production-reachable hook;
- incomplete replay evidence.

Return REJECT only for fundamental unsoundness outside a bounded repair.

Return AUDIT_PROVENANCE_MISMATCH only for:

- supplied-root drift or mutation;
- missing fixed input;
- child-process ledger gap;
- uncaught parent failure;
- closing inequality;
- terminal audit-capsule failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Successor identity and closure
4. Predecessor identity and closure
5. Blocking-audit identity and governing evidence
6. Process authority and child ledger
7. Exact predecessor-successor delta
8. Semantic changed set and unchanged J schemas
9. Repair-authority adjudication
10. Finding A field map and source analysis
11. Finding A fresh causal matrix
12. Finding C source and custody model
13. Finding C fresh causal matrix
14. Finding H publication state machine
15. `renameatx_np(RENAME_EXCL)` binding and capability result
16. Final success-commit field map
17. Authoritative commit point
18. Fresh independent publication matrix
19. Precommit/postcommit/retry adjudication
20. Publication replay closure
21. Failure-hook reachability
22. Finding I case 28 execution
23. Complete producer 50-case classification
24. Finding J regression
25. Contract/schema/source/record consistency
26. Fresh independent validator
27. Two fresh materializations
28. Two fresh Carrier 0002 handoffs
29. Production export boundary
30. Security and sensitive-material findings
31. Failed/superseded-attempt adjudication
32. Four parent perspectives
33. Supplied-root closing equality
34. Fixture cleanup and ENOENT observations
35. Audit-capsule inventory and manifests
36. Severity-ranked residual findings
37. Remaining uncertainty and nonclaims
38. Explicit confirmations

Required confirmations:

SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_PACKAGE_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
EXACT_SIX_PATH_SEMANTIC_SCOPE_VERIFIED
FINDING_J_OWNED_SCHEMAS_BYTE_IDENTICAL
UNAUTHORIZED_SEMANTIC_DRIFT_ABSENT
A_REPAIR_AUTHORITY_VERIFIED
C_REPAIR_AUTHORITY_VERIFIED
H_REPAIR_AUTHORITY_VERIFIED
I_REPAIR_AUTHORITY_VERIFIED
INTERPRETER_EFFECTIVE_FLAGS_VERIFIED
INTERPRETER_LITERAL_FLAG_TOKENS_VERIFIED
MISSING_I_REJECTED
MISSING_S_REJECTED
MISSING_B_REJECTED
ENVIRONMENT_CANNOT_SUBSTITUTE_FOR_MISSING_B
POST_COPY_DESTINATION_FRESHLY_REOPENED
POST_COPY_BYTES_FRESHLY_READ_AND_HASHED
CACHED_IDENTITY_NOT_ACCEPTANCE_BEARING
PATH_REBINDING_OR_REPLACEMENT_DETECTED
SAME_SIZE_IN_PLACE_MUTATION_REJECTED
STAGED_SUCCESS_COMMIT_NONAUTHORITATIVE
EXCLUSIVE_ATOMIC_NO_REPLACE_PUBLICATION_VERIFIED
NO_PUBLICATION_FALLBACK
PREEXISTING_FINAL_NOT_ADOPTED
AUTHORITATIVE_COMMIT_POINT_UNAMBIGUOUS
PRECOMMIT_FAILURES_NONAUTHORITATIVE
POSTCOMMIT_DISPOSITION_EXPLICIT
POSTCOMMIT_FAILURES_NON_DOWNGRADING
RETRY_BEHAVIOR_VERIFIED
PUBLICATION_BOUNDARY_MATRIX_INDEPENDENTLY_PASSED
PUBLICATION_REPLAY_EVIDENCE_COMPLETE
NO_DELETED_REPLAY_FIXTURE_REQUIRED
NO_PRODUCTION_REACHABLE_FAILURE_HOOK
PRODUCER_CASE_28_EXECUTED_WRAPPER
WRONG_PAYLOAD_REJECTED_AT_PAYLOAD_IDENTITY
PRODUCER_50_CASES_ACCURATELY_CLASSIFIED
FINDING_J_928_CASE_REGRESSION_PASSED
ACCEPTANCE_SCHEMA_CLOSURE_PRESERVED
CONTRACT_SCHEMA_SOURCE_RECORD_CONSISTENCY_VERIFIED
FRESH_INDEPENDENT_VALIDATOR_PASSED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_FRESH_CARRIER_0002_HANDOFFS_PASSED
PRODUCTION_EXPORT_BOUNDARY_CLOSED
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY
INTERNAL_COMMIT_NOT_GIT_OR_EXTERNAL_PUBLICATION_AUTHORITY
NO_DIRECT_AUDITORS_USED
NO_SUBAGENTS_CREATED
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
FULL_V3_TARGET_AUDIT_NOT_STARTED
A6_NOT_STARTED
```

An `ACCEPT` closes the bootstrap-package line. The next action after acceptance
is the substantive fresh independent Validation-Custody V3 audit using the
exact accepted package. Do not create another process-package implementation
or findings-reconciliation tranche without a new concrete defect.

**Source:** Codex’s A/C/H/I repair implementation report in the current turn and the preceding independent `BLOCK` audit.

**Confidence:** 0.98 that the successor is ready for a decisive audit; 0.97 that exclusive publication and destination-rebinding causals are the most important remaining technical risks; 0.99 that another implementation tranche should not begin before this audit.
