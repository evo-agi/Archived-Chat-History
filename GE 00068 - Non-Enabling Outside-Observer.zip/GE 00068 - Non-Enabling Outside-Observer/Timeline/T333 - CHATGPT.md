## Assessment

The successor package is ready for a **fresh parent-owned independent audit**, not yet acceptance.

The implementation report is internally coherent on scope:

- exactly the eight authorized semantic paths changed;
- predecessor and reconciliation roots reportedly remained unchanged;
- Finding H was addressed through retained, replayable publication-boundary evidence;
- Finding J was addressed through closed contracts and schemas;
- predecessor regressions, two materializations, and two Carrier 0002 handoffs reportedly passed;
- Findings A, C, and I remain explicitly unresolved rather than silently folded into the repair.

Three issues deserve particular scrutiny in the audit:

1. **The new `bootstrap-success-commit.json` changes the acceptance commit point.** This may be justified by the newly reproduced predecessor causal, but the auditor must independently prove that this implementation change was authorized by Finding H, that the causal is genuine, and that the new commit cannot create stale, duplicate, downgraded, or ambiguous success.

2. **The schema repair is acceptance-critical.** The audit must test the actual schemas, contracts, source producers, and generated records—not rely on the reported 82-case matrix or `jsonschema` results.

3. **Findings A, C, and I now have to be resolved.** An `ACCEPT` is inappropriate if any remains materially unresolved:
   - A: whether the package truthfully verifies or merely reports `-I -S -B`;
   - C: whether post-copy reverification genuinely reopens the copied bytes;
   - I: whether claimed negative cases exercise real rejection boundaries or merely hard-code expected outcomes.

The next audit should use one parent-owned execution path with four retained analytical perspectives. Tool-enabled direct auditors should not be used again.

```text
FRESH INDEPENDENT PARENT-OWNED AUDIT —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP V1 H/J AUDIT-REPAIR SUCCESSOR

This is an independent audit of one exact source-external package.

Do not modify or repair the audit target.
Do not modify any supplied root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents or direct auditors.

Use one parent-owned audit execution path.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact successor bootstrap-package bytes and their
bounded source-external process behavior.

ACCEPT grants no authority over:

- the candidate repository;
- Strategic B;
- V1/V2/V3 targets;
- product or runtime behavior;
- deployment;
- publication;
- external commit;
- readiness;
- the eventual V3 target-audit verdict;
- A6.

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

Expected root identity:

- device/inode:
  16777234 / 179272855
- physical mode:
  0700
- expected producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected temporal final inventory:

- size:
  237721
- SHA-256:
  1284fb7ed2bc19fe67b017404dfa4f749cf228dda4d010d1ed2a690ea0f766e9

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  237800 each
- SHA-256:
  adf2a6f8314327b07883153f95eae567ecd802413d2b0acdeebfc2bf56d47f8e
- byte-identical:
  required

Expected represented closure:

- 1140 represented entries;
- 333 directories including root;
- 807 represented nonmanifest regular files;
- 809 physical regular files including both manifests;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- regular files mode 0600 and link count 1.

Independently derive:

- exact temporal-inventory relative path;
- exact implementation-report identity;
- exact package verdict record, if any;
- complete source, contract, schema, test, validation, lineage, provenance,
  closeout, and manifest membership;
- exact terminal write chronology.

Do not use the implementation report as artifact authority.

──────────────────────────────────────────────────────────────────────────────
2. EXACT PREDECESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-be5v9nny

Expected identity:

- device/inode:
  16777234 / 179120828
- mode:
  0700

Expected predecessor manifests:

- size:
  33552 each
- SHA-256:
  cec56d4c9ac08c79ae7da58107fd56cd3389ba879ed566e327b4582ae27e259b
- byte-identical:
  required

Expected predecessor closure:

- 177 represented entries;
- 12 directories including root;
- 165 represented nonmanifest files;
- 167 physical files including manifests.

Expected predecessor semantic identities:

source/full_audit_bootstrap_v1.py

- size:
  81613
- SHA-256:
  01fb237ef588241e7147abf92baa59009d0b159dd5bc5543e70f7f83d82b01f5

contract/full-audit-bootstrap-contract-v1.json

- size:
  10516
- SHA-256:
  819000733aed1dede52f022f646e406b13b244753b14000903847ce29e31762c

contract/qualification-result-contract-v1.json

- size:
  542
- SHA-256:
  5e0e8a5dda56b8f71950f8d16b2146b94288ff7ba28c0ff0ec7a9c6da739938d

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  1232
- SHA-256:
  14dd22f66af5b123b5a56c00a010af0cab859a797929c3bd774fc9c55b61ae55

schemas/process-self-check-result-v1.schema.json

- size:
  1046
- SHA-256:
  0790ba9485803accc35fdfc42d56805e315252daad31252c513d669fc3741366

schemas/root-rebinding-proof-v1.schema.json

- size:
  1016
- SHA-256:
  24ff517e8c6191aa4f7b6327382afbf72418857d9774553799dcd72ba69433ea

tests/failure_injection_driver_v1.py

- size:
  5043
- SHA-256:
  25ae0028a7c384afdbd669a992a136fe533cfeef0935e8fbb7b43243729e23dc

tests/test_full_audit_bootstrap_v1.py

- size:
  26990
- SHA-256:
  74f7f2676ade0a93210b0e6a924b127cb62b6dad87ed275075d73a92793e18d1

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING FINDINGS RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

FINDINGS_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-findings-reconciliation-51v6ry1w

Expected identity:

- device/inode:
  16777234 / 179266473
- mode:
  0700
- verdict:
  BOOTSTRAP_PACKAGE_FINDINGS_RECONCILED_REPAIR_REQUIRED

Expected terminal manifests:

- size:
  18119 each
- SHA-256:
  2c617919acd164b7c7eae6f62c28eaee116b12c5036128bfd394e52e2d2804a9
- byte-identical:
  required

Authenticate and inspect completely:

analysis/bounded-repair-contract.json

- size:
  2119
- SHA-256:
  fea165ed38eb5cbabdacdc9583856b64bd57642080b901768c28042115ca09e3

analysis/complete-finding-ledger.json

- size:
  19992
- SHA-256:
  b221b3a377cd1bc9c65093a8092bdb3b3479c3674de0fb6eb3991b3f55f19c2b

causals/finding-H-atomicity.json

- size:
  3378
- SHA-256:
  120ac6614d48e5bccdd57288b0a9aa793906be2d008b0fb38dd79e488c791062

analysis/finding-J-schema-alignment.json

- size:
  1722
- SHA-256:
  0a028c2361bdbd0d6e89e9eb8d06673c6b828c998178ccdc4089a687c5dcc6a2

analysis/finding-I-case-adjudication.json

- size:
  26106
- SHA-256:
  26fc00b9c06895dd8d9d89c4ae4b8b1ad3ba7c880c01bf590e73dd2e38ddbb0d

closeout/final-reconciliation-report.md

- size:
  3224
- SHA-256:
  02880515547d8cc0a4055ff04af66c78af1889cc209cc5fa4cb8b08277bc4ce3

opening/opening-gate-result.json

- size:
  10582
- SHA-256:
  d10607510ea1f1fd86cb82999717e9e0251bddf928fe198da87ba700e213994b

The bounded repair contract governs allowed H/J implementation scope.

──────────────────────────────────────────────────────────────────────────────
4. FAILED PACKAGE AUDIT — A/C/I ALLEGATION SOURCE
──────────────────────────────────────────────────────────────────────────────

FAILED_PACKAGE_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv

Expected identity:

- device/inode:
  16777234 / 179156020
- mode:
  0700

Expected manifests:

- size:
  12860 each
- SHA-256:
  6935ae04a130a5f1f27fd8c2f0cd9b829ba50213c909652292ab4da2f006d12b
- byte-identical:
  required

Use only as nonqualifying allegation and evidence source.

Authenticate and inspect:

analysis/severity-ranked-findings.json
auditors/auditor-1-report.md
auditors/auditor-2-report.md
auditors/auditor-3-report.md
closeout/final-audit-report.md
provenance/complete-child-process-ledger.json

Auditor 3’s unauthorized `/tmp` writes remain a failed-audit process defect and
are not attributed to either package.

──────────────────────────────────────────────────────────────────────────────
5. OPTIONAL IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

Open only when required by a concrete package check:

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Python mode is report-only.

Every optional root opened becomes subject to complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
6. PROCESS-AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking a tool.

Then state exactly:

AUDIT_EPOCH_START

Use:

`top_level_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Use one parent-owned audit execution path.

Do not create direct auditors.
Do not create subagents.

The parent may retain four analytical-perspective records:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

These are parent-generated analyses, not separately authoritative auditors.

Every subprocess created by the parent must use one contemporaneous child
recorder.

For every child retain:

- contiguous ordinal;
- start before spawn;
- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- reaping;
- descriptor closure;
- purpose;
- paths written;
- qualifying or failed/superseded disposition.

Pure in-process inspection does not require fictitious process records.

A child-record gap requires:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
7. FRESH AUDIT ROOT AND OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-

Retain before supplied-root inspection:

opening/bootstrap-start.json
provenance/parent-source.py
provenance/parent-process-start.json

Run child-recorder self-causals:

- missing executable / ENOENT;
- `/usr/bin/true` / exit 0;
- empty streams;
- reaping;
- descriptor closure.

Then:

1. Verify successor package root and full manifest closure.
2. Verify predecessor package root and closure.
3. Verify findings-reconciliation root and closure.
4. Verify failed package-audit root and closure.
5. Bind every fixed identity above.
6. Verify no supplied root aliases the audit root or another supplied root.
7. Capture complete opening inventories.
8. Retain:
   `opening/opening-gate-result.json`

Do not start substantive inspection before the opening gate passes.

Stop with AUDIT_PROVENANCE_MISMATCH on actual opening drift, mutation, alias,
missing fixed input, manifest mismatch, or process-record failure.

──────────────────────────────────────────────────────────────────────────────
8. PREDECESSOR-TO-SUCCESSOR DELTA
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the complete predecessor-to-successor delta.

Require the semantic changed set to be exactly:

source/full_audit_bootstrap_v1.py
contract/full-audit-bootstrap-contract-v1.json
contract/qualification-result-contract-v1.json
schemas/full-audit-bootstrap-contract-v1.schema.json
schemas/process-self-check-result-v1.schema.json
schemas/root-rebinding-proof-v1.schema.json
tests/failure_injection_driver_v1.py
tests/test_full_audit_bootstrap_v1.py

Expected successor identities:

source/full_audit_bootstrap_v1.py

- size:
  92561
- SHA-256:
  2764bc8b7972c199df4bfc80f04ede124931247f74e52325e47dd74071228f79

contract/full-audit-bootstrap-contract-v1.json

- size:
  14481
- SHA-256:
  9fc27aa61dcff5e19a57936c1002de97d567e62d873cb787c562477002b7a652

contract/qualification-result-contract-v1.json

- size:
  2275
- SHA-256:
  d3b0cba5926a86a1a40db9034034120b7f9f2f691af4a11dbc37a6b275041dda

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  9785
- SHA-256:
  08714f519f88bdc636c11c353b2eeadc32c5951689799629834637934c0a599e

schemas/process-self-check-result-v1.schema.json

- size:
  6554
- SHA-256:
  8a73bd13ee61b1a31d072d2a93c4e635cae14f0ad9f399dbef63954bd053abbf

schemas/root-rebinding-proof-v1.schema.json

- size:
  4662
- SHA-256:
  010a2d604980a914f8460b615dbfa62f125cb8f8d3a9584caf22499b9a7964cd

tests/failure_injection_driver_v1.py

- size:
  10506
- SHA-256:
  393f6b927bd245a1dd8901fa08f06fe5ca4a68d8d1389f4a5a8d25bec3f1c527

tests/test_full_audit_bootstrap_v1.py

- size:
  40478
- SHA-256:
  72845b61360f5390b9f8890589e8d36fef565bb75a4537161923b3b40e8eb7aa

Require:

- every semantic path outside this set byte-identical;
- no hidden executable production source under an evidence namespace;
- new evidence paths have no future-consumer runtime role;
- production source does not import validation/materialization copies;
- no unauthorized semantic drift.

Independently reconstruct the claimed 642 new evidence files and 321 new
evidence directories from the successor membership and classify their roles.

──────────────────────────────────────────────────────────────────────────────
9. REPAIR-AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Determine whether every changed semantic hunk is authorized by Finding H or
Finding J.

For each changed hunk retain:

- path;
- old line range;
- new line range;
- finding owner:
  H or J;
- governing repair-contract field or requirement;
- behavior changed:
  yes/no;
- acceptance semantics changed:
  yes/no;
- authority changed:
  yes/no;
- validation-only:
  yes/no.

Pay special attention to the new:

`opening/bootstrap-success-commit.json`

Determine whether introducing this record:

- is necessary to repair an independently demonstrated predecessor defect;
- stays inside the bounded H authority;
- is internal evidence-instance commitment only;
- does not grant external commit or publication authority;
- does not silently change unrelated process semantics;
- should have required a contract or schema generation transition.

If any semantic change lacks explicit H/J authority, return BLOCK.

──────────────────────────────────────────────────────────────────────────────
10. FINDING H — PREDECESSOR CAUSAL
──────────────────────────────────────────────────────────────────────────────

Independently reproduce the claimed predecessor behavior:

A failure after successful outcome close could retain a success result and
success outcome while failure-outcome creation collided.

Use:

- exact predecessor source;
- audit-owned fixtures;
- no supplied-root mutation;
- no target inspection.

Retain:

- exact injection point;
- exact source identity;
- result posture;
- outcome posture;
- failure-outcome posture;
- process exit;
- partial inventory;
- retry posture.

Determine whether the reproduced behavior is:

- an implementation atomicity defect;
- a validation-only ambiguity;
- an impossible or artificial injection;
- or not reproducible.

The new implementation-level commit-point change is authorized only if this
causal is genuine and acceptance-affecting.

──────────────────────────────────────────────────────────────────────────────
11. FINDING H — SUCCESS COMMIT CONTRACT
──────────────────────────────────────────────────────────────────────────────

Inspect the exact source, contract, schemas, and actual records governing:

opening/bootstrap-success-commit.json

Independently construct its complete field map.

Require it to bind at minimum:

- schema;
- owning contract ID and identity;
- result path, size, SHA-256;
- outcome path, size, SHA-256;
- completed ordinal or stable step;
- directory-synchronization result;
- postpublication verification result;
- authority classification;
- nonauthority;
- success status;
- unique invocation or audit-root binding.

Determine the exact commit point.

Require:

1. no authoritative success before the commit exists and qualifies;
2. exclusive creation;
3. complete write;
4. fsync;
5. close;
6. containing-directory synchronization;
7. no overwrite;
8. no duplicate commit;
9. identity reopening and verification;
10. one invocation cannot adopt another invocation’s commit;
11. failure records cannot masquerade as the commit;
12. external Git/publication/commit authority remains false.

The term `commit` must be explicitly classified as internal evidence-state
commitment, not repository or publication authority.

──────────────────────────────────────────────────────────────────────────────
12. FINDING H — FRESH PUBLICATION-BOUNDARY MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not accept the producer’s ten-case matrix as the audit oracle.

Independently reconstruct all publication boundaries from source.

Run fresh audit-owned causals covering at least:

1. before result creation;
2. result write;
3. result fsync;
4. result close;
5. before outcome write;
6. outcome write;
7. outcome fsync;
8. outcome close;
9. directory synchronization before commit;
10. postpublication verification before commit;
11. commit creation;
12. commit write;
13. commit fsync;
14. commit close;
15. commit-directory synchronization;
16. commit identity reopening;
17. failure immediately after commit;
18. postcommit cleanup failure;
19. duplicate commit collision;
20. retry after precommit failure;
21. retry after committed success.

For each retain:

- stable case ID;
- exact source and driver identity;
- hook reachability;
- exact injection;
- argv/cwd/environment;
- stdout/stderr;
- exit or signal;
- result/outcome/commit posture;
- partial-artifact inventory;
- classification;
- retry posture;
- cleanup;
- replay recipe.

Require causal fixtures and source to remain retained and manifest-covered.

Do not count unsupported or structurally unreachable boundaries as dynamic
passes.

──────────────────────────────────────────────────────────────────────────────
13. FINDING H — COMMIT-POINT SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Adjudicate:

- precommit failures;
- success at the commit point;
- postcommit failures;
- result/outcome/commit consistency;
- downgrade behavior;
- retry behavior.

Require one closed rule:

A. Before commit:
   no authoritative success.

B. At valid commit:
   success becomes authoritative.

C. After commit:
   failures either:
   - are explicitly non-downgrading observations; or
   - make the commit nonqualifying under an independently checkable rule.

The package must not leave ambiguous coexistence of:

- authoritative success commit;
- authoritative failure outcome;
- partial success fragments;
- reusable destination.

Verify exact cleanup behavior for nonauthoritative precommit fragments.

──────────────────────────────────────────────────────────────────────────────
14. FINDING H — REPLAY EVIDENCE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Audit every producer H causal.

For each require:

- exact case name;
- exact production source identity;
- exact driver identity;
- exact fixture identity;
- exact injection point;
- replay command or structured recipe;
- all immutable operands;
- stdout/stderr;
- result/outcome/commit records;
- complete fixture inventory;
- cleanup record;
- expected and actual classification.

Verify that no required replay source or fixture was deleted.

Verify the retained publication matrix:

- exact case count;
- exact name set or digest;
- pass/fail counts;
- false-acceptance count;
- replay-complete count;
- source identity;
- first blocker;
- nonauthority.

A summary without independently replayable operands is insufficient.

──────────────────────────────────────────────────────────────────────────────
15. FAILURE-HOOK REACHABILITY
──────────────────────────────────────────────────────────────────────────────

Inspect every injection mechanism.

For each report whether it is reachable from:

- ordinary CLI;
- environment;
- carrier request;
- copied process artifact;
- target input;
- import path;
- qualification harness;
- direct source import;
- future consumer export.

Require every audit-only hook to be:

- absent from ordinary CLI;
- absent from accepted environment;
- absent from request schema;
- absent from copied artifact interface;
- absent from future consumer exports;
- fail-closed on unexpected exposure.

Run negative reachability causals.

If a hook is production-reachable, return BLOCK.

──────────────────────────────────────────────────────────────────────────────
16. FINDING J — REPRODUCE PREDECESSOR FAIL-OPEN CASES
──────────────────────────────────────────────────────────────────────────────

Independently reproduce every predecessor mutation listed in:

analysis/finding-J-schema-alignment.json

At minimum include the reported six cases:

- missing classification;
- `cli.path_lookup = true`;
- empty copy boundary;
- target authorization true;
- production executes Carrier 0002 true;
- unknown field.

Verify:

- exact predecessor mutation bytes or canonical mutated object;
- predecessor schema/validator result;
- exact reason;
- whether the two claimed predecessor false acceptances reproduce.

Do not use the repaired validator as the predecessor oracle.

──────────────────────────────────────────────────────────────────────────────
17. FINDING J — COMPLETE CONTRACT FIELD MAPS
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the repaired field map for every acceptance-bearing
record family, including:

- main bootstrap contract;
- bootstrap start;
- bootstrap outcome;
- bootstrap result;
- bootstrap failure;
- bootstrap success commit;
- process-self-check result;
- root-rebinding proof;
- qualification result;
- H publication matrix;
- J mutation matrix.

For every field record:

- JSON pointer;
- required/optional;
- type;
- enum or constant;
- cardinality;
- unknown-field rule;
- success/failure applicability;
- cross-field rule;
- owning contract identity;
- authority role;
- producer function;
- consumer.

Require exact agreement among contract, schema, source producer, actual record,
and validator.

──────────────────────────────────────────────────────────────────────────────
18. FINDING J — SCHEMA-SEMANTIC AUDIT
──────────────────────────────────────────────────────────────────────────────

Inspect every repaired schema completely.

Verify actual Draft 2020-12 semantics, including:

- `$schema`;
- `$id`, if used;
- `$ref`;
- `$defs`;
- `type`;
- `required`;
- `properties`;
- `const`;
- `enum`;
- `additionalProperties`;
- `unevaluatedProperties`;
- `allOf`;
- `oneOf`;
- `anyOf`;
- `if/then/else`;
- array item and uniqueness rules;
- numeric bounds;
- string patterns;
- property dependencies.

Do not infer closure from textual presence alone.

Check for fail-open combinations involving `$ref`, `allOf`, and
`additionalProperties`.

Verify no schema relies on a validator-specific behavior without binding that
validator and draft.

Determine whether production depends on `jsonschema 4.24.0`.

If `jsonschema` is validation-only:

- confirm production bootstrap has no dependency on it.

If production depends on it:

- treat that as a potentially unauthorized semantic/dependency change and
  adjudicate separately.

Bind exact validator version and invocation used for schema tests.

──────────────────────────────────────────────────────────────────────────────
19. FINDING J — ASSERTION REGISTRY
──────────────────────────────────────────────────────────────────────────────

Derive the exact governed positive assertion set from:

- process-self-check contract;
- repaired schema;
- payload source;
- actual successful results.

Require exactly 30 names if that is the repaired contract.

Verify:

- same names;
- same spelling;
- no duplicate;
- no missing assertion;
- no unknown assertion;
- Boolean values only;
- raw posture names excluded;
- aggregate success equals all governed assertion values;
- an empty map rejects;
- a renamed assertion rejects;
- a false governed assertion with success true rejects.

Determine whether the assertion set is frozen literally or through an exact
registry digest. Require one authoritative mechanism, not two conflicting ones.

──────────────────────────────────────────────────────────────────────────────
20. FINDING J — REBINDING-PROOF CLOSURE
──────────────────────────────────────────────────────────────────────────────

Require the exact ordered twelve-pointer set:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

Verify:

- count 12;
- no duplicates;
- no unknown pointer;
- no missing pointer;
- predecessor/successor values;
- classification exact;
- semantic effect exact;
- normalized projections present;
- normalized identities present;
- equality true;
- non-root difference zero;
- success true.

An empty proof or empty changed-field set must reject.

──────────────────────────────────────────────────────────────────────────────
21. FINDING J — QUALIFICATION-RESULT CLOSURE
──────────────────────────────────────────────────────────────────────────────

Inspect the qualification-result contract, schema, producer, and actual final
qualification records.

Require exact binding to:

- owning contract identity;
- repaired source identity;
- H matrix identity and case set;
- J matrix identity and case set;
- producer result;
- independent validator result;
- replay-complete count;
- retained-fixture closure;
- materializations;
- handoffs;
- authority and nonauthority;
- first blocker;
- success/failure status.

Reject:

- empty evidence maps;
- empty causal sets;
- absent name binding;
- contradictory counts;
- stale source identity;
- stale contract identity;
- omitted replay completeness;
- success with blocker;
- failure without required blocker;
- failure relabeled through one Boolean.

──────────────────────────────────────────────────────────────────────────────
22. FRESH INDEPENDENT J MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import producer validators or fixtures as the oracle.

Construct a fresh audit-owned matrix covering at minimum:

- every exact predecessor J case;
- every required top-level field removed;
- every required nested field removed;
- unknown field at every acceptance-bearing depth;
- wrong primitive type;
- wrong enum;
- stale schema ID;
- stale contract ID;
- authority omitted;
- authority widened;
- nonauthority omitted;
- success with failure-only field;
- failure with success-only field;
- success missing evidence;
- failure missing blocker;
- contradictory status/outcome;
- negative count;
- count mismatch;
- duplicate case name;
- missing case name;
- empty assertion map;
- missing assertion;
- unknown assertion;
- renamed assertion;
- non-Boolean assertion;
- aggregate inconsistency;
- raw posture inserted into positive assertions;
- empty rebinding proof;
- missing pointer;
- extra pointer;
- duplicate pointer;
- wrong pointer count;
- normalized equality false;
- non-root difference nonzero;
- missing normalized projection;
- missing source identity;
- missing replay evidence;
- replay count mismatch;
- empty H matrix;
- stale producer-source identity;
- stale qualification result;
- mixed-generation contract/schema/result.

Pin exact case names and expected mechanism-specific reasons independently.

Require:

- exact count;
- uniqueness;
- two-way name-set closure;
- zero false acceptance;
- zero false rejection;
- zero skip;
- zero reason mismatch.

──────────────────────────────────────────────────────────────────────────────
23. PRODUCER VALIDATION AND CASE-LEVEL ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Inspect and execute:

- repaired producer tests;
- repaired independent validator;
- predecessor producer regression;
- predecessor independent-validator regression;
- H matrix;
- J matrix;
- materialization validator;
- handoff validator;
- security validator;
- package closure validator.

For every reported producer and independent case classify:

- static/source check;
- schema mutation;
- actual production-input mutation;
- integration rejection causal;
- hard-coded result fixture;
- self-fulfilling outcome.

Require reporting level to match actual mechanism.

This section must resolve prior Finding I.

Return BLOCK if acceptance depends materially on a hard-coded or
self-fulfilling case presented as a production-boundary causal.

──────────────────────────────────────────────────────────────────────────────
24. FINDING A — INTERPRETER FLAGS
──────────────────────────────────────────────────────────────────────────────

Resolve Finding A.

Inspect:

- CLI contract;
- production source;
- bootstrap-start/result/outcome records;
- pinned-interpreter checks;
- generated launch contract;
- implementation report.

Determine whether `-I -S -B` is:

- required caller configuration;
- submitted argv;
- observed importer runtime state;
- future launcher/wrapper configuration.

Run audit-owned bootstrap invocations with:

- exact `-I -S -B`;
- missing `-I`;
- missing `-S`;
- missing `-B`;
- no isolation flags.

Use only audit-owned output roots and no target access.

Determine whether any invocation lacking a contractually required flag can
qualify while claiming the flag was verified or observed.

Return BLOCK for a confirmed implementation, contract, or evidence defect.

Do not invent a requirement not present in the closed contract.

──────────────────────────────────────────────────────────────────────────────
25. FINDING C — POST-COPY REVERIFICATION
──────────────────────────────────────────────────────────────────────────────

Resolve Finding C.

Inspect exact production copy and reverify functions.

Determine whether copied destinations are reopened no-follow after initial copy
verification.

Run a fresh audit-owned causal:

1. copy an exact process artifact using the production boundary;
2. alter or replace the destination after initial copy observation;
3. invoke the production post-copy reverification;
4. observe the result.

Require fresh observation of:

- type;
- mode;
- link count;
- size;
- SHA-256;
- complete bytes;
- identity stability.

If cached identity dictionaries can qualify an altered destination, return
BLOCK.

──────────────────────────────────────────────────────────────────────────────
26. TWO FRESH MATERIALIZATIONS
──────────────────────────────────────────────────────────────────────────────

Run the successor production bootstrap twice into physically distinct
audit-owned roots.

For each retain:

- exact argv;
- cwd;
- explicit environment;
- stdout/stderr;
- exit;
- root locator;
- complete inventory;
- bootstrap records;
- copied artifacts;
- auxiliary records;
- launch contract;
- rebinding proof;
- Carrier 0002 payload;
- Carrier 0002 request;
- success commit, when applicable.

Before Carrier 0002:

- roots distinct;
- exact copied bytes;
- normalized auxiliary records equal;
- normalized launch contracts equal;
- payload bytes equal;
- normalized requests equal;
- no target inspection;
- no Carrier 0002 execution.

──────────────────────────────────────────────────────────────────────────────
27. TWO FRESH CARRIER 0002 HANDOFFS
──────────────────────────────────────────────────────────────────────────────

Execute Carrier 0002 in both audit-owned roots.

Require:

- request admission;
- constructed launch;
- wrapper parsing;
- phase start/outcome;
- compilation and execution;
- same PID;
- exact constructed environment;
- exact observed owned values;
- diagnostic-only additional environment names;
- wrapper SHA exact and once;
- CLI conformance;
- no child;
- no target inspection;
- all outputs;
- payload success;
- wrapper exit 0;
- authoritative success commit consistent with result/outcome.

Normalize:

- root-bound paths;
- PIDs;
- root-derived environment values;
- derived hashes computed from normalized root-bound maps.

Require normalized semantic equality.

Do not claim raw byte equality if only normalized equality is required.

──────────────────────────────────────────────────────────────────────────────
28. PRODUCTION EXPORT, SECURITY, AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Inspect all changed source and all executable package source.

Require no:

- network;
- Git;
- shell;
- candidate path;
- target path;
- broad Downloads scan;
- latest/prefix selection;
- existing-root adoption;
- symlink-following fallback;
- overwrite;
- credential output;
- production-reachable test hook;
- hidden dependency on validation/materialization copies;
- automatic progression into target audit.

Classify all new evidence files and retained materializations.

Require:

- no future-consumer runtime dependency on evidence-only files;
- no executable source hidden under evidence namespaces;
- no authority widening;
- internal bootstrap-success commit explicitly non-Git and nonpublication;
- package remains process-only.

Perform bounded sensitive-material scans without emitting matched payloads.

──────────────────────────────────────────────────────────────────────────────
29. UNRESOLVED FINDINGS A/C/I — VERDICT REQUIREMENT
──────────────────────────────────────────────────────────────────────────────

A, C, and I must be resolved in this audit.

ACCEPT is forbidden if any remains materially unresolved.

Permitted final classifications:

- disproved;
- report-only hardening;
- confirmed nonblocking evidence limitation;
- confirmed repairable defect.

A confirmed repairable defect requires BLOCK.

Evidence insufficiency affecting acceptance requires BLOCK, not silent
acceptance.

──────────────────────────────────────────────────────────────────────────────
30. FOUR PARENT-GENERATED PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

Each must record:

- exact operands;
- findings;
- limits;
- uncertainty;
- uninspected scope.

These are parent-generated analytical perspectives, not separate auditors.

Do not create direct auditors or subagents.

──────────────────────────────────────────────────────────────────────────────
31. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all work:

- repeat complete lstat/no-follow inventories for every supplied root opened;
- require opening/closing equality;
- verify pinned Python unchanged;
- retain complete fixture inventories;
- remove only audit-owned fixture/private roots;
- perform two fresh `lstat` observations per removed root;
- require ENOENT twice;
- verify no process or descriptor survivor.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
32. FINAL AUDIT CAPSULE
──────────────────────────────────────────────────────────────────────────────

Finalize before sealing:

- opening records;
- parent source;
- child-process ledger;
- complete package delta;
- H authority analysis;
- predecessor causal;
- fresh H matrix;
- replay closure;
- hook reachability;
- success-commit adjudication;
- J predecessor reproduction;
- complete repaired field maps;
- schema-semantic analysis;
- fresh J matrix;
- producer case-level adjudication;
- A/C/I adjudication;
- two materializations;
- two handoffs;
- four parent perspectives;
- export/security analysis;
- closing equality;
- cleanup;
- final report;
- temporal final inventory.

Then create `manifest/` and two independently generated terminal manifests.

Require:

- root represented;
- every directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- regular files mode 0600 and link count 1;
- byte-identical manifests;
- no filesystem write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
33. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- provenance qualifies;
- exact eight-path semantic scope qualifies;
- no unauthorized semantic drift exists;
- the H implementation change is authorized;
- the predecessor H causal reproduces;
- the new success commit is correct and unambiguous;
- the fresh H matrix passes;
- replay evidence is complete;
- hooks are unreachable in production;
- every J contract/schema/source/record family is closed and consistent;
- fresh J matrix passes;
- producer validation is accurately characterized;
- A, C, and I are resolved without a blocking defect;
- two materializations pass;
- two handoffs pass;
- production export/security/authority checks pass;
- opening/closing equality passes;
- final capsule closes;
- no acceptance-affecting residual finding remains.

Return BLOCK for any repairable:

- implementation defect;
- contract/schema defect;
- validation/evidence defect;
- unresolved acceptance-bearing A/C/I issue;
- unauthorized semantic change;
- stale or ambiguous success commitment;
- production-reachable audit hook;
- misleading validation case;
- incomplete replay closure.

Return REJECT only for fundamental unsoundness outside the bounded repair.

Return AUDIT_PROVENANCE_MISMATCH only for:

- supplied-root drift or mutation;
- missing fixed input;
- child-process ledger gap;
- uncaught parent-process failure;
- closing inequality;
- audit-capsule closure failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
34. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Successor package identity and closure
4. Predecessor identity and closure
5. Findings-reconciliation identity and governing records
6. Failed package-audit evidence identity
7. Process-authority and child-ledger posture
8. Exact predecessor-to-successor delta
9. Exact semantic changed set
10. New evidence-path classification
11. Repair-authority adjudication
12. Finding H predecessor causal
13. Success-commit field map and authority
14. Exact success commit point
15. Fresh publication-boundary matrix
16. Precommit/postcommit/retry adjudication
17. Replay-evidence closure
18. Failure-hook reachability
19. Finding J predecessor mutation reproduction
20. Repaired contract field maps
21. Repaired schema field maps
22. Contract/schema/source/record consistency
23. Assertion-registry closure
24. Rebinding-proof closure
25. Qualification-result closure
26. Fresh independent J matrix
27. Producer case-level validation adjudication
28. Finding A resolution
29. Finding C resolution
30. Finding I resolution
31. Two fresh materializations
32. Two fresh Carrier 0002 handoffs
33. Production export boundary
34. Security and sensitive-material findings
35. Authority and nonauthority
36. Four parent-generated perspectives
37. Supplied-root closing equality
38. Fixture cleanup and ENOENT observations
39. Audit-capsule inventory and manifests
40. Severity-ranked residual findings
41. Remaining uncertainty and nonclaims
42. Explicit confirmations

Required confirmations:

SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_PACKAGE_MUTATION_NOT_PERFORMED
FINDINGS_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
FAILED_PACKAGE_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
EXACT_EIGHT_PATH_SEMANTIC_SCOPE_VERIFIED
UNAUTHORIZED_SEMANTIC_DRIFT_ABSENT
H_REPAIR_AUTHORITY_VERIFIED
J_REPAIR_AUTHORITY_VERIFIED
PREDECESSOR_H_CAUSAL_INDEPENDENTLY_REPRODUCED
SUCCESS_COMMIT_INTERNAL_EVIDENCE_ONLY
SUCCESS_COMMIT_NOT_GIT_OR_PUBLICATION_AUTHORITY
SUCCESS_COMMIT_POINT_UNAMBIGUOUS
PRECOMMIT_FAILURES_NONAUTHORITATIVE
POSTCOMMIT_DISPOSITION_EXPLICIT
RETRY_BEHAVIOR_VERIFIED
PUBLICATION_BOUNDARY_MATRIX_INDEPENDENTLY_PASSED
PUBLICATION_REPLAY_EVIDENCE_COMPLETE
NO_DELETED_REPLAY_FIXTURE_REQUIRED
NO_PRODUCTION_REACHABLE_FAILURE_HOOK
PREDECESSOR_J_FALSE_ACCEPTANCES_REPRODUCED
ACCEPTANCE_SCHEMAS_INDEPENDENTLY_CLOSED
CONTRACT_SCHEMA_SOURCE_RECORD_CONSISTENCY_VERIFIED
EXACT_ASSERTION_SET_VERIFIED
EXACT_TWELVE_POINTER_SET_VERIFIED
QUALIFICATION_RESULT_CLOSURE_VERIFIED
FRESH_J_MATRIX_PASSED
PRODUCER_CASES_ACCURATELY_CLASSIFIED
FINDING_A_RESOLVED
FINDING_C_RESOLVED
FINDING_I_RESOLVED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_FRESH_CARRIER_0002_HANDOFFS_PASSED
PRODUCTION_EXPORT_BOUNDARY_CLOSED
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY
NO_DIRECT_AUDITORS_USED
NO_SUBAGENTS_CREATED
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
FULL_V3_TARGET_AUDIT_NOT_STARTED
A6_NOT_STARTED
```

After an `ACCEPT`, the process-bootstrap infrastructure is closed. The next
step is the substantive fresh independent Validation-Custody V3 audit using
the exact accepted successor package. Do not create another process-package
implementation or findings-reconciliation tranche absent a new concrete
defect.

**Source:** Codex’s audit-repair implementation report in the current turn and the preceding accepted findings reconciliation.

**Confidence:** 0.98 that the successor is ready for a decisive independent audit; 0.96 that the new internal success-commit semantics are the principal audit risk; 0.97 that ACCEPT must require affirmative resolution of A, C, and I rather than another deferral.
