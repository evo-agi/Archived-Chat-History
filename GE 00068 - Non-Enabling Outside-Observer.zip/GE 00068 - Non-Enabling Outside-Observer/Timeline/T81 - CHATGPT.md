A5T4 is a clean implementation-validation success. It closes the repository-test side of the problem without widening product authority:

- The final repository contains exactly the three intended test-file changes.
- The production wrapper stayed byte-identical.
- The shell derivative is uniquely matched, reversible, line-count preserving, and directly checked for scrub equivalence.
- The five socket fixtures now reach their intended assertions.
- The `/dev/fd` cascade is eliminated without granting `/dev/fd`.
- A5P2’s PTY custody and security boundary remain intact.
- The full suite recovered the exact intended terminal universe: 2,753 passes, 137 inherited failures, and 8 inherited skips, with zero unknown diagnostics.
- All 69 former pass→fail and 38 pass→absent regressions were restored.
- The 5 A5T and 18 A5P2 improvements remained.

This remains implementation validation rather than independent acceptance. The project separates implementation from a later fresh read-only audit, and any later byte change returns the work through fresh validation and re-audit.  

The next critical path is now the already isolated **A5C successor-only observability-duration amendment**. It should change no repository bytes. Its job is narrow:

- Preserve correlation topology for timestamps, trace IDs, and request IDs.
- Stop treating accidental equality between raw duration measurements as identity topology.
- Assign duration tokens by diagnostic position within the exact package/test/occurrence sequence.
- Keep route, status, event, service, field order, multiplicity, event ordering, lifecycle, and terminal outcomes material.
- Prove that only the two retained observability-sided differences collapse; the ten historical broken-socket diagnostics must remain material in the retained negative corpus.

The proof harness must remain classified as proof scaffolding rather than silently becoming product architecture or authority. 

## Codex prompt: Repair 10I-A5C

```text
Permission is workspace-write for one new source-external successor/evidence
child only.

Objective

Implement, validate, close out, and seal Repair 10I-A5C: the bounded
observability-duration canonicalization amendment.

The current successor canonicalization rule
`observability-inbound-request-complete-v1` correctly preserves meaningful
event, route, status, trace-ID, request-ID, ordering, and lifecycle semantics,
but incorrectly treats equality between raw duration measurements as
correlation topology.

The amendment must introduce:

observability-inbound-request-complete-v2

For this exact rule only:

- timestamp, trace ID, and request ID remain raw-value keyed within the exact
  package/test/occurrence scope;
- trace/request repeated-versus-distinct topology remains material;
- duration syntax, field presence, positivity, ordering, and diagnostic
  position remain material;
- raw duration-value equality or inequality is not identity topology;
- each valid duration token is canonicalized by its exact diagnostic ordinal
  within the scoped occurrence:
  `<OBSERVABILITY_DURATION:<ordinal>>`.

No repository source changes are authorized.

This is a parent-only successor implementation turn.

Do not modify repository source.
Do not modify sealed A5P2.
Do not modify sealed A5T4.
Do not resume or seal any failed A5T/A5T2/A5T3/A6 child.
Do not implement A6 or start B6.
Do not run product A/B.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Repository, read-only throughout this turn

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5P2 successor baseline

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p2-successor-closure-ab646e5a0e66

Sealed A5T4 repository-validation lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Retained qualified A5 final/fresh negative corpus

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Sealed A5FD classification evidence

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5fd-devfd-recon-ab646e5a0e66

Required new A5C child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the repository delta from sealed A5 to be exactly these three existing
mode-100644 test files:

1.
remote_alpha_operator_test.go

- SHA-256:
  f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578

2.
es/runtimehelper/supervisor_test.go

- SHA-256:
  842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226

3.
remote_alpha_prepare_external_tls_status_test.go

Capture and report its exact current mode, size, and complete SHA-256 from the
live repository and verify it against the sealed A5T4 source inventory.

Require:

- zero additions;
- zero deletions;
- zero renames;
- zero mode changes;
- every other 386 repository tuple byte- and mode-identical to sealed A5.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Reverify completely:

- closeout/final-report-v1.md;
- the exact three-file delta;
- production-wrapper unchanged identity;
- shell-equivalence and inverse-mutant records;
- all 64 affected-identity results;
- full-suite raw and semantic records;
- producer and peer qualifications;
- exact historical matrices;
- cleanup and absence records.

Bind the sealed A5T4 full-suite facts:

- process exit:
  1
- test terminals:
  2753 pass / 137 fail / 8 skip
- package terminals:
  14 pass / 11 fail / 23 skip
- raw SHA-256:
  0a97bd3a3ca7e162feac63795da125dd05bae7d13987faa61e3712479df83d25
- producer/peer semantic SHA-256:
  f692595d3611e13ef90babafbdb8726407190155b02c0ae60d3c9a15152f57f8
- zero unknown diagnostics;
- no socket-EINVAL fixture diagnostics;
- no `/dev/fd/N: Operation not permitted` diagnostics;
- both qualifications:
  qualified.

Require exact sealed A5P2:

- manifest SHA-256:
  67002939082d25a46ec50fdb4a5725e936816ea930e6ed9ac684608238a833a4
- manifest size:
  114860
- payloads:
  613
- directories:
  112
- source T:
  ff7a4688b1244277eccc8eee26b57eb4f0858d01
- source inventory:
  a17d8e3d5925b17d2eda187a51953dcf0d171d81d5e5409ea70827d92a6cda2e
- members:
  12

A5P2 binaries:

repair10-runner:
  153013c19a717a37a677c0c5fa4e91837c78ccc16db909a9b1e360ff2efb483d

repair10-compare:
  d09e0e0d510872fb457f1308219f471bcbd147c7fc6d4a19da29a026182055a3

repair10-semantic:
  25893d292a20e0af99e494779802dbd73c1fe1e180f3c9e2873c5ea52e86d325

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the complete A5P2 v3/v2/v1 schema dialect and acknowledged-PTY
hard-gate evidence to reverify.

Require exact sealed A5FD:

- manifest SHA-256:
  f4bfa2b8479a8679d4a2af4173f2bc9d76bc6f4085cdda3bb4c60d06c0b9b768
- size:
  4951
- payloads:
  37
- directories:
  6

Require the retained A5 final/fresh corpus to remain present, unsealed, and
byte-exact.

Bind its exact observability facts:

- package:
  execution-substrate/es/api
- test:
  TestWorkstreamCExecutionCompatibilityRoutesRemainAvailable
- occurrence:
  1
- exact ordered routes:
  1. GET /v1/executions:contract
  2. POST /v1/executions:prepare
  3. POST /v1/executions:submit
- event:
  inbound_request_complete
- service:
  execution
- status:
  success
- final duration topology under v1:
  1,2,3
- fresh duration topology under v1:
  1,2,1
- lifecycle equal;
- both controls qualified;
- zero unknowns;
- the two sided observability records are the only retained differences
  attributable to duration-equality topology;
- ten sided socket-fixture diagnostics remain separately material in that old
  vulnerable corpus.

Require the A5C target to be absent.

Stop on any mismatch:

REPAIR10I_A5C_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create A5C exclusively under umask 077.

Use exactly:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, with intended mode 0600 or 0700.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy all 12 A5P2 source members independently into:

tool/source/

Requirements:

- no hardlinks;
- opening bytes and logical modes equal A5P2;
- complete source inventory and pure T retained;
- all unchanged members reverified at closeout.

## 3. Exact authorized source scope

Modify exactly these three copied successor files:

1.
tool/source/FORMAT.md

2.
tool/source/envelope/semantic.go

3.
tool/source/envelope/envelope_test.go

The other nine source members must remain byte- and mode-identical to A5P2:

- tool/source/envelope/runner.go
- tool/source/envelope/source.go
- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-fixture/main.go
- both golden files
- go.mod

No thirteenth member.
No dependency change.
No golden-file change.
No repository change.

If another file is required, stop:

REPAIR10I_A5C_SCOPE_EXPANSION_REQUIRED

## 4. Schema and rule-ID disposition

Do not change any JSON schema identifier.

The complete A5P2 active v3/v2/v1 schema dialect remains active and unchanged.

This amendment changes only the typed canonicalization rule identity and
semantics:

old:
  observability-inbound-request-complete-v1

new:
  observability-inbound-request-complete-v2

Active A5C extraction must never emit the v1 rule ID.

Retained v1 semantic envelopes remain historical evidence. They cannot
substitute for raw re-extraction under the A5C extractor.

Qualification continues to require:

- raw-stream identity;
- extractor identity;
- mapping identity;
- canonical recomputation;
- exact retained-envelope equality.

No schema version is introduced merely for this finite grammar amendment.

## 5. Exact v2 rule scope

Recover the exact current v1 allowlist from A5P2 source before editing.

The v2 rule must retain exactly the same:

- package scope:
  execution-substrate/es/api
- test/subtest allowlist;
- occurrence handling;
- complete anchored record grammar;
- event:
  inbound_request_complete
- field set and field order;
- service grammar;
- route grammar;
- status grammar;
- timestamp grammar;
- trace-ID grammar;
- request-ID grammar;
- duration grammar;
- exact newline framing.

Do not add a package, test, or subtest.

Do not widen the grammar.

## 6. Exact canonicalization semantics

Within the exact package/test/occurrence scope:

### Timestamp

Preserve existing timestamp canonicalization and equality topology.

A repeated timestamp remains distinguishable from distinct timestamps.

### Trace ID

Preserve existing raw-value-keyed topology:

- same trace ID repeated:
  same canonical token;
- distinct trace IDs:
  distinct canonical tokens;
- missing, malformed, uppercase, wrong length, reordered, or extra trace ID:
  material or unknown/blocking according to the existing grammar.

### Request ID

Preserve existing raw-value-keyed topology using the same rules as trace ID.

### Duration

Change only this field.

A valid duration canonicalizes by exact diagnostic ordinal within the scoped
occurrence:

ordinal 1:
  <OBSERVABILITY_DURATION:1>

ordinal 2:
  <OBSERVABILITY_DURATION:2>

ordinal 3:
  <OBSERVABILITY_DURATION:3>

and so on within the finite bounded record set.

Two equal raw durations at different ordinals must receive different tokens.

Two different raw durations at the same ordinal in independent controls must
receive the same token.

The ordinal must come from the acceptance-bearing semantic record position,
not from:

- raw duration value;
- sort order;
- route name;
- global stream position;
- a post-hoc multiset;
- a caller-supplied caption.

Duration remains material through:

- presence;
- valid positive canonical Go-duration syntax;
- exact field position;
- record multiplicity;
- diagnostic ordinal;
- event ordering.

Do not normalize an invalid, zero, signed, leading-zero, malformed-unit,
overflowing, missing, reordered, duplicated, or appended duration record.

## 7. Preserved material semantics

The following remain material and must not be erased:

- package;
- test/subtest;
- occurrence;
- diagnostic ordinal;
- event name;
- service;
- route;
- status;
- record count;
- record order;
- field order;
- trace-ID equality topology;
- request-ID equality topology;
- timestamp equality topology;
- missing or extra event;
- lifecycle terminal;
- pass/fail/skip;
- package terminal;
- panic/race/warning/fatal/malformed classifications;
- unknown text.

Cross-package scheduler ordering may remain outside semantic equality only to
the extent already documented by A5P2.

Do not introduce sorting or multiset comparison inside one package/test
occurrence.

## 8. Vulnerable-precondition causal

Before editing, use the exact A5P2 source and retained A5 final/fresh raw
streams to reproduce:

- both controls qualified;
- lifecycle equal;
- zero unknowns;
- v1 final observability duration topology:
  1,2,3;
- v1 fresh topology:
  1,2,1;
- canonical semantics different;
- the exact two sided observability entries;
- the ten sided broken-socket diagnostics remain separately material.

Retain this as expected-negative evidence.

## 9. Exact positive causals

After implementation, re-extract both retained A5 streams under A5C.

Require:

- the final observability sequence canonicalizes duration ordinals as 1,2,3;
- the fresh sequence also canonicalizes duration ordinals as 1,2,3;
- the two observability sided differences disappear;
- trace-ID topology remains three distinct identities per side;
- request-ID topology remains three distinct identities per side;
- route/status/event/service/order remain exact;
- lifecycle remains unchanged;
- exactly the intended observability records change rule ID/canonical duration
  representation;
- no nonobservability diagnostic changes except for source-wide deterministic
  effects of the explicit rule-ID replacement where the same exact grammar is
  legitimately matched.

The old retained A5 streams must remain non-equal overall because the ten sided
broken-socket fixture diagnostics remain material.

They must not become accepted-equal.

This proves A5C does not conceal the old repository-test defect.

## 10. Exact negative corpus

Add active causals that independently mutate:

- package;
- test;
- subtest;
- occurrence;
- ordinal;
- event name;
- service;
- route;
- status;
- event count;
- event order;
- field order;
- trace ID;
- request ID;
- trace alias topology;
- request alias topology;
- timestamp topology;
- missing duration;
- zero duration;
- signed duration;
- leading-zero duration;
- malformed unit;
- uppercase or invalid unit;
- overflow or parser rejection;
- duplicated duration field;
- appended text;
- partial text;
- pass/fail/skip terminal.

Require every mutation to remain material or unknown/blocking.

Specific topology controls:

1. Equal raw duration at ordinal 1 and 3:
   canonical tokens remain 1 and 3.

2. Different raw durations at corresponding ordinal 3 across two controls:
   canonical token is 3 on both sides.

3. Reordered events:
   remains different even if the duration values and token multiset match.

4. Route swap:
   remains different.

5. Trace-ID alias introduced or removed:
   remains different.

6. Request-ID alias introduced or removed:
   remains different.

7. Missing middle record:
   remains different and is not renumbered into equality.

8. Extra record:
   remains different.

9. Same record duplicated:
   remains different through multiplicity and ordinal.

## 11. Exact allowlist exhaustiveness

Add a table-driven test enumerating every package/test/subtest in the existing
v1 allowlist.

For each entry prove:

- exact complete valid record accepted;
- wrong package rejected;
- wrong test/subtest rejected;
- wrong occurrence rejected;
- partial or appended record rejected;
- duration receives position-based v2 token;
- trace/request topology remains raw-keyed.

Any typed-looking observability text outside the allowlist remains unknown and
blocking.

No generic observability-log fallback.

## 12. Current A5T4 compatibility re-extraction

Use the sealed A5T4 full-suite raw stream as read-only input.

Re-extract it independently with A5C side A and side B.

Require:

- A/B extracted semantics byte-identical;
- lifecycle byte-identical to the sealed A5T4 lifecycle;
- terminal identity sets unchanged;
- zero unknown diagnostics;
- no package/test terminal change;
- no panic/race/warning/fatal/malformed change;
- every changed diagnostic belongs to the exact observability v1→v2 rule
  migration;
- every nonobservability diagnostic byte-identical;
- route/status/event/order/topology checks remain exact;
- producer-caption values from A5T4 are not trusted as A5C qualification.

This is compatibility/re-extraction evidence only.

It does not become the fresh A6 final control.

## 13. Historical and mutant compatibility

Using retained immutable raw streams where available, re-extract:

- historical HEAD;
- Repair 9;
- prior final;
- prior fresh final;
- intentional mutant.

For each:

- enumerate every legitimate v2 application;
- require zero new unknowns;
- require no lifecycle change;
- require no terminal change;
- require no unrelated canonicalization change;
- preserve all A5S/A5P2 exact-line and logical-byte bounds;
- preserve mutant exact-delta behavior outside the v2 rule.

Do not use old retained semantic envelopes as active A5C output without raw
re-extraction.

## 14. Active successor tests

Add exact active tests named:

1.
TestRepair10IA5CObservabilityDurationUsesDiagnosticPositionV1

2.
TestRepair10IA5CObservabilityIdentityTopologyRemainsMaterialV1

3.
TestRepair10IA5CObservabilityOrderMultiplicityAndLifecycleRemainMaterialV1

4.
TestRepair10IA5CRetainedA5CorpusRemovesOnlyDurationTopologyDifferenceV1

5.
TestRepair10IA5CA5T4RawReextractionCompatibilityV1

6.
TestRepair10IA5CObservabilityGrammarAndAllowlistRejectionsV1

7.
TestRepair10IA5CNoSchemaOrNonObservabilityDriftV1

The retained A5 corpus test must assert that:

- exactly the two observability sided entries disappear;
- the ten socket sided entries remain;
- accepted equality remains false for that historical broken-source pair.

## 15. Two disjoint successor controls

Use pinned Go 1.26.5 under umask 077.

Each side independently owns:

- source;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build root;
- command output;
- report root.

No writable state may be shared.

Verify source copies are no-hardlink and inode-disjoint.

On both sides run:

gofmt -d over all Go source members

Require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10IA5C'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10IA5C'

Require:

- zero required skips;
- zero race reports;
- zero malformed streams;
- zero missing/duplicate terminals;
- no survivor;
- no forced cleanup;
- complete resource and terminal disposition.

## 16. Deterministic builds

Build on both sides:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require each A/B binary pair:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- expected mode;
- built from exact A5C source;
- no unexpected absolute build path.

## 17. A5P2 nonregression

The A5C patch must preserve A5P2 behavior.

Re-run or independently reverify:

- active v3/v2/v1 schema inventory;
- historical-schema rejection;
- `LOCAL_PEERPID` binding tests;
- openpty/forkpty acknowledged handoff tests;
- retained-parent-slave negative;
- repaired EOF positive;
- early-close and duplicate-alias negatives;
- direct `/dev/ptmx` denial;
- unrelated-terminal denial;
- PTY custody and late-fault rejection;
- byte-comparison behavior;
- logical command/suite fingerprinting.

No PTY or execution-policy field may change.

## 18. Security and authority controls

Require:

- repository remains read-only and byte-exact;
- no product/public schema change;
- no execution-authority change;
- no new filesystem/device/network capability;
- no generic duration, timestamp, hexadecimal, decimal, path, PID, UUID, or
  observability normalization;
- no raw private log payload beyond existing bounded test evidence;
- no `.out` access;
- no credential, keychain, TLS, SPIFFE, Vault, private endpoint, or unrelated
  user-data exposure;
- all evidence remains non-authoritative.

## 19. Evidence requirements

Retain:

- complete opening and lineage verification;
- exact A5P2 source copy and inventory;
- exact three-file source delta;
- rule-v1 vulnerable reproduction;
- complete rule-v2 contract;
- exact allowlist inventory;
- positive and negative grammar corpus;
- retained A5 final/fresh re-extractions;
- A5T4 raw re-extraction;
- historical and mutant re-extractions;
- all A/B test, race, and build records;
- binary identities;
- failed and superseded attempts;
- source and repository closing verification;
- cleanup and two absence epochs;
- implementation report;
- exact path/mode/size/hash inventory.

No evidence record may claim fresh A6 final/fresh equality.

## 20. Closeout and sealing

Require:

- exactly the three authorized successor source files changed;
- the other nine A5P2 source members byte- and mode-identical;
- repository remains:
  - T `8de797304ea944b6a155924e0d1e9e8bbe79534e`
  - inventory
    `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
  - membership `389/375/14`
  - staged/deleted/renamed/unmerged `0/0/0/0`;
- branch/HEAD/parent/HEAD tree/upstream/index unchanged;
- A5P2, A5T4, A5FD, retained A5 controls, and every predecessor unchanged;
- no predecessor bytecode or cache;
- no private source, cache, build, process, descriptor, socket, report, or
  temporary root remains;
- two fresh absence epochs pass.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification of:

- membership;
- path set;
- modes;
- sizes;
- hashes;
- links;
- directory modes;
- final source T/inventory;
- A/B binary identities;
- repository and predecessor identities;
- absence state.

## 21. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- need for a fourth successor source file;
- repository mutation;
- schema-ID change;
- allowlist widening;
- generic duration normalization;
- trace/request/timestamp topology loss;
- route/status/event/order/multiplicity hidden;
- retained A5 socket diagnostics collapse or become accepted-equal;
- any nonobservability diagnostic changes unexpectedly;
- A5T4 lifecycle or terminal set changes;
- old rule ID emitted by active A5C extraction;
- required skip;
- race;
- malformed or incomplete stream;
- unknown diagnostic introduced;
- PTY or execution-policy regression;
- A/B source or binary mismatch;
- survivor, forced cleanup, or sealing failure.

## 22. Verdicts

Opening mismatch:

REPAIR10I_A5C_BASELINE_MISMATCH

Scope expansion required:

REPAIR10I_A5C_SCOPE_EXPANSION_REQUIRED

Canonicalization contract incomplete or unsafe:

REPAIR10I_A5C_CANONICALIZATION_REPAIR_REQUIRED

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A5C_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A5C_OBSERVABILITY_DURATION_PATCH_SEALED_READY_FOR_A6_REFRESH

The success report must include:

1. A5P2 and A5C source T/inventory.
2. Exact three-file delta.
3. Confirmation all JSON schema IDs remain unchanged.
4. Exact v1→v2 rule contract.
5. Complete allowlist identity.
6. Retained A5 vulnerable result.
7. Postrepair retained-A5 result:
   - two observability sided entries removed;
   - ten socket sided entries retained;
   - historical pair still non-equal.
8. A5T4 re-extraction identity and exact changed-record inventory.
9. Historical and mutant compatibility.
10. Positive and negative grammar results.
11. A5P2 PTY and policy nonregression.
12. A/B source and binary identities.
13. Test and race outcomes.
14. Manifest SHA-256, size, and payload count.
15. Cleanup and two absence epochs.
16. Explicit statement that A6 was not restarted and no fresh final/fresh
    acceptance was claimed.

No A6.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After A5C

After A5C seals, restart the **complete A6 policy-evidence refresh** from fresh materializations:

1. fresh final;
2. fresh independent final;
3. deliberate mutant;
4. historical HEAD;
5. historical Repair 9;
6. external qualification of all five;
7. all five comparisons;
8. historical directional transition matrices and hazard adjudication.

No A5P2, A5T4, or A5C bounded causal substitutes for those fresh controls. The earlier A2 closeout explicitly states that a bounded tool causal does not replace the required freshly materialized downstream control. 

Exact manifests will bind the A5C bytes, but provenance alone does not prove that the canonicalization preserves every material semantic distinction or that the tests are sufficient. 

### Sources

- Codex’s `REPAIR10I_A5T_SOCKET_AND_DEVFD_HARNESS_REPAIR_SEALED_READY_FOR_A5C` report supplied in the current turn.
- Milestone 0 proof-harness/non-authority boundary. 
- Sealed Repair 10I-A2 downstream-control non-substitution boundary. 
- Governed Execution implementation, audit, and repair lifecycle.  
- Governed Execution provenance limits. 

**Confidence:** 0.999 that A5T4 is complete enough to advance; 0.98 that A5C is now the only known blocker before the fresh A6 policy refresh; 0.97 that position-keyed duration tokens are the correct narrow amendment; 0.95 that the three-file successor scope is sufficient; 0.995 that fresh A6 controls remain mandatory after A5C changes the successor bytes.
