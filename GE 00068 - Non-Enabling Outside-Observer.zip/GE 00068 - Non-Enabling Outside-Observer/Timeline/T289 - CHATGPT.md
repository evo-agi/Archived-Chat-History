## Assessment

`AUDIT_PROVENANCE_MISMATCH` is correct. Carrier 0018 has no phase records, so the audit cannot qualify regardless of the work completed before it.

This is another **audit-harness transcription failure**, not a V3 target finding:

- Carrier 0018 used the wrong expected wrapper digest.
- Its `PATH` omitted `/opt/homebrew/bin`.
- The wrapper correctly rejected the launch before creating a phase-start record.
- The target and supplied inputs were not mutated.
- The 74-case mutation payload was never executed.
- No correctness conclusion from the partially completed audit is acceptance-bearing.

The deeper problem is now clear: invariant launch fields are being reproduced independently for every carrier. Correcting the Carrier 0018 literals alone would leave the same failure mode available to Carrier 0019 or any later carrier.

The next audit should use **one bootstrap-owned canonical launch contract and one immutable carrier launcher**. Per-carrier requests must not contain or override the interpreter identity, wrapper identity, interpreter flags, or fixed environment. This removes the source of both Carrier 0018 errors.

No new V3 implementation, wrapper modification, runtime replay, or capability probe is warranted.

Send the following as a continuation in the Codex chat holding the full audit brief. For a new Codex chat, prepend the complete prior independent-audit prompt.

```text
FRESH RETRY — CANONICAL WRAPPED-CARRIER LAUNCH CONTRACT FOR THE
VALIDATION-CUSTODY V3 AUDIT-REPAIR INDEPENDENT AUDIT

Repeat the immediately preceding full independent-audit brief from the
beginning using a wholly fresh audit root.

The target scope, supplied inputs, fixed identities, four-auditor schedule,
normative-authority audit, V2 adoption audit, static semantic audit, mutation
matrix, manifest causals, closing equality, verdict rules, and required inline
report remain unchanged.

The only authorized change is the wrapped-carrier launch mechanism defined
below.

Do not modify or repair:

- the candidate repository;
- Strategic B or its accepted gate;
- blocked V1;
- V2;
- the V2 audit;
- predecessor V3;
- the V3 audit-repair capsule;
- the generic phase wrapper;
- any prior audit root.

Do not rerun runtime validation.
Do not run repository tests or product code.
Do not use the network.
Do not stage or commit.
Do not start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PRECEDING ATTEMPT DISPOSITION
──────────────────────────────────────────────────────────────────────────────

The immediately preceding audit root is:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-07bocx43

Treat it as immutable, nonqualifying process-failure evidence.

Do not:

- resume it;
- repair it;
- reuse any payload or process record from it;
- clean it;
- adopt an auditor report from it;
- use its partially completed correctness work as acceptance evidence.

Its failure was process-local:

- Carrier 0018 supplied the wrong expected wrapper SHA-256:
  6e911ca03787cefe5a317b9e502ad5f8e58474317bbd135409b5d8e46b54bf56

- The accepted wrapper SHA-256 is:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

- Carrier 0018 also supplied a PATH that omitted:
  /opt/homebrew/bin

The wrapper correctly rejected the launch before creating phase records.

This is not a V3 target defect and does not authorize a target repair.

──────────────────────────────────────────────────────────────────────────────
2. CLOSED INVARIANT LAUNCH CONTRACT
──────────────────────────────────────────────────────────────────────────────

During bootstrap, create and retain:

opening/wrapped-carrier-launch-contract.json

This record is the sole writer for every invariant local-carrier launch fact.

It must contain at least:

{
  "schema":
    "execution-substrate.audit.wrapped-carrier-launch-contract.v1",

  "interpreter": {
    "path":
      "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "version":
      "Python 3.13.4",
    "regular":
      true,
    "links":
      1,
    "size":
      119424,
    "sha256":
      "f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b",
    "flags": ["-I", "-S", "-B"]
  },

  "wrapper": {
    "path":
      "<AUDIT_ROOT>/provenance/phase_runner.py",
    "size":
      15300,
    "sha256":
      "6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56",
    "mode":
      "0600",
    "regular":
      true,
    "links":
      1
  },

  "fixed_environment": {
    "PATH":
      "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
    "LC_ALL":
      "C",
    "LANG":
      "C",
    "PYTHONDONTWRITEBYTECODE":
      "1",
    "HOME":
      "<AUDIT_ROOT>/private/home",
    "TMPDIR":
      "<AUDIT_ROOT>/private/tmp"
  },

  "invocation": {
    "type":
      "interpreter-mediated-python-source",
    "direct_wrapper_execution":
      false,
    "shell_fallback":
      false,
    "path_lookup_for_interpreter":
      false,
    "path_lookup_for_wrapper":
      false,
    "same_pid_exec_to_wrapper":
      true
  }
}

Use strict canonical JSON with duplicate-key and nonfinite-value rejection.

The contract may add fields required by the exact accepted wrapper CLI, but it
may not weaken or contradict the values above.

No per-carrier artifact may redefine these invariant values.

──────────────────────────────────────────────────────────────────────────────
3. WRAPPED-CARRIER LAUNCHER
──────────────────────────────────────────────────────────────────────────────

During bootstrap, create and retain:

provenance/wrapped_carrier_launcher.py

Retain it as regular, single-link mode 0600.

The launcher is audit-owned process infrastructure. It is not target evidence,
a normative V3 writer, or a replacement for the accepted wrapper.

Invoke the launcher through the same pinned Python interpreter:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  "$AUDIT_ROOT/provenance/wrapped_carrier_launcher.py" \
  --launch-contract \
  "$AUDIT_ROOT/opening/wrapped-carrier-launch-contract.json" \
  --request \
  "$AUDIT_ROOT/provenance/carrier-NNNN.request.json"

The launcher must:

1. Strictly parse the launch contract.
2. Strictly parse the carrier request.
3. Verify its own retained identity against the launch contract or a separate
   bootstrap-owned launcher identity record.
4. Verify the pinned interpreter using exactly the closed six-field identity
   contract from the preceding retry:
   - exact path;
   - version;
   - regular type;
   - link count 1;
   - size;
   - SHA-256.
5. Treat interpreter permission bits, uid, gid, device, inode, timestamps,
   flags, xattrs, and ancestors as report-only.
6. Verify the wrapper path, size, SHA-256, mode 0600, regular type, and one
   link.
7. Reject any carrier request containing an invariant launch field.
8. Construct the complete wrapper argv from:
   - the launch contract’s invariant values; and
   - the request’s phase-varying values.
9. Construct the wrapper environment from the launch contract.
10. Ignore inherited PATH and replace it with the exact fixed PATH.
11. Use `os.execve` to replace itself with:

    /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
    -I
    -S
    -B
    <AUDIT_ROOT>/provenance/phase_runner.py
    <exact accepted wrapper CLI arguments>

12. Preserve the same process ID across launcher-to-wrapper exec.
13. Use no shell.
14. Use no PATH lookup.
15. Use no direct payload execution.
16. Use no fallback launch.
17. Perform no target or supplied-root inspection.

The launcher must not use `__file__` or import metadata to discover its source.
Its absolute source path and identity must come from a bootstrap-owned record.

──────────────────────────────────────────────────────────────────────────────
4. PER-CARRIER REQUEST SCHEMA
──────────────────────────────────────────────────────────────────────────────

Create one canonical request file per carrier:

provenance/carrier-NNNN.request.json

The request may contain only phase-varying data required by the accepted
wrapper, such as:

- carrier ordinal;
- phase name;
- payload absolute path;
- payload size;
- payload SHA-256;
- payload entry function;
- submitted cwd;
- authorized operands;
- expected outputs;
- phase-specific record paths;
- phase-specific nonsecret metadata.

Derive the exact field map from the accepted wrapper CLI and freeze it in the
launch contract.

The request must not contain or override:

- interpreter path;
- interpreter version;
- interpreter size;
- interpreter SHA-256;
- interpreter flags;
- wrapper path;
- wrapper size;
- wrapper SHA-256;
- wrapper mode;
- PATH;
- LC_ALL;
- LANG;
- PYTHONDONTWRITEBYTECODE;
- HOME;
- TMPDIR;
- direct-execution disposition;
- shell disposition;
- fallback disposition.

Reject unknown request fields.

Every request must bind the exact launch-contract path, size, and SHA-256.

No wrapper SHA-256 or fixed PATH value may be manually repeated in an
individual request.

──────────────────────────────────────────────────────────────────────────────
5. BOOTSTRAP ORDER
──────────────────────────────────────────────────────────────────────────────

The bootstrap remains the sole permitted unwrapped local-process carrier.

It must:

1. Set umask 077.
2. Allocate a wholly fresh audit root using the exact prefix required by the
   preceding full-audit brief.
3. Retain and emit the exact audit-root path before later checks.
4. Create the required directory structure.
5. Copy and verify the accepted wrapper at mode 0600.
6. Verify the pinned interpreter using the closed acceptance field set.
7. Create `wrapped_carrier_launcher.py`.
8. Create the canonical launch-contract record.
9. Create and retain:
   - launcher source identity;
   - launch-contract identity;
   - wrapper identity;
   - interpreter identity;
   - fixed-environment identity;
   - first carrier request.
10. Inspect no target or supplied evidence content.

Always retain bootstrap-start and bootstrap-outcome records.

If bootstrap fails, retain the exact fresh root and failure before returning.

──────────────────────────────────────────────────────────────────────────────
6. CARRIER 0002 — LAUNCHER AND WRAPPER SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must use the canonical launcher and one audit-owned no-op payload.

The payload must:

- read no target or supplied root;
- launch no child process;
- use only the Python standard library;
- create one expected mode-0600 result under the fresh audit root;
- return success.

Require:

- launcher source identity exact;
- launch-contract identity exact;
- request identity exact;
- invariant fields absent from the request;
- interpreter identity exact;
- fixed PATH exact;
- wrapper identity exact;
- wrapper mode 0600;
- same-PID launcher-to-wrapper exec;
- wrapper phase-start created before payload read or compilation;
- wrapper phase-outcome created after success;
- payload compiled and executed;
- expected result created;
- no bytecode;
- no direct wrapper execution;
- no shell;
- no fallback.

Stop with AUDIT_PROVENANCE_MISMATCH if Carrier 0002 fails.

Do not attempt an alternate launch shape in the same audit.

──────────────────────────────────────────────────────────────────────────────
7. CHILD-RECORDER SELF-CAUSALS
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 passes, use the canonical launcher for the child-recorder
setup phase.

Require the two causals from the full audit:

- missing executable / ENOENT;
- `/usr/bin/true` / exit 0.

Do not inspect target or supplied content until both pass.

Every later child process must use the same recorder.

──────────────────────────────────────────────────────────────────────────────
8. EVERY LATER CARRIER
──────────────────────────────────────────────────────────────────────────────

Every later local-process carrier must invoke exactly:

pinned Python
→ wrapped_carrier_launcher.py
→ same-PID exec
→ pinned Python
→ phase_runner.py
→ retained payload

For all later carriers:

- use the same launcher bytes;
- use the same launch-contract bytes;
- use the same interpreter;
- use the same wrapper bytes;
- use the same interpreter flags;
- use the same fixed environment;
- vary only the canonical request and payload.

Do not manually transcribe:

- wrapper SHA-256;
- interpreter SHA-256;
- PATH;
- interpreter flags;
- wrapper path;
- interpreter path.

Do not create one-off shell commands containing copied invariant values.

Carrier-request files must be created only by:

- bootstrap; or
- a prior successfully wrapped phase.

No unwrapped process may create or edit a carrier request.

──────────────────────────────────────────────────────────────────────────────
9. LAUNCH-CONTRACT DRIFT CAUSALS
──────────────────────────────────────────────────────────────────────────────

Before target inspection, run one audit-owned static causal phase through the
accepted wrapper.

It must inspect only audit-owned launch infrastructure and establish:

1. A request containing a wrapper-SHA field is rejected by request-schema
   validation.
2. A request containing a PATH field is rejected.
3. A request containing interpreter flags is rejected.
4. A request containing an unknown field is rejected.
5. The valid request contains none of those fields.
6. Fixed PATH comes only from the launch contract.
7. Fixed wrapper SHA-256 comes only from the launch contract.
8. Every later request is checked against the same schema.

Do not launch malformed requests as top-level carriers. Exercise these as
in-memory request-schema causals inside one valid wrapped payload.

Retain the causal source and result.

──────────────────────────────────────────────────────────────────────────────
10. CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

For each carrier retain:

- ordinal;
- phase;
- launcher path, size, SHA-256, and mode;
- launch-contract path, size, and SHA-256;
- request path, size, and SHA-256;
- interpreter path, version, size, and SHA-256;
- interpreter flags;
- wrapper path, size, SHA-256, and mode;
- fixed-environment record path and SHA-256;
- submitted cwd;
- platform-reported outcome class;
- phase-start identity;
- phase-outcome identity;
- child ordinal range;
- artifacts;
- discrepancy status.

State:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

The carrier index must not reproduce unavailable opaque tool-internal command
expansions.

Return AUDIT_PROVENANCE_MISMATCH for:

- a missing visible local carrier;
- an indexed carrier without a visible tool call;
- a carrier using a different launcher or launch contract;
- a request containing invariant overrides;
- a fixed environment differing from the launch contract;
- a carrier missing wrapper records;
- ambiguous ordering;
- submitted cwd conflict;
- an unwrapped local-process diagnostic.

──────────────────────────────────────────────────────────────────────────────
11. FULL AUDIT REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

After the launcher, wrapper, child-recorder, and launch-drift causals pass,
execute the complete preceding full independent-audit brief unchanged:

- opening provenance gate;
- accepted Strategic B gate;
- four direct auditors;
- normative-authority and supersession audit;
- failed-attempt lineage audit;
- complete V2-adoption audit;
- OBS-05 and OBS-07 correction-lineage audit;
- V2 BLOCK preservation;
- V3 field-map audit;
- Plan V3→V4 equivalence;
- five-source closure and 86-byte derivation;
- independent mutation matrix;
- manifest-generator source review;
- dynamic symlink/special/hardlink/empty-directory causals;
- real repair-capsule closure;
- final inventory temporal adjudication;
- terminal sensitive-material scan;
- no-runtime-replay confirmation;
- closing supplied-root equality;
- process and child audits;
- exact-private-path cleanup;
- final audit inventory.

No target requirement is removed or weakened.

Do not reuse auditor reports from the failed attempt.

──────────────────────────────────────────────────────────────────────────────
12. STOP RULES
──────────────────────────────────────────────────────────────────────────────

Return AUDIT_PROVENANCE_MISMATCH for:

- bootstrap failure before retained root/outcome;
- mismatch in a closed interpreter identity field;
- unauthorized interpreter predicate;
- wrapper mismatch;
- launcher mismatch;
- launch-contract mismatch;
- request invariant override;
- fixed PATH drift;
- wrapper-SHA drift;
- direct wrapper execution;
- failed launcher/wrapper self-check;
- missing phase record;
- missing child quartet;
- unrecorded local carrier;
- supplied-input drift;
- failed opening or closing equality.

After process gates pass, use the original target verdict rules:

- ACCEPT for complete qualification;
- BLOCK for repairable target-level defects;
- REJECT only for fundamental unsoundness.

Do not repair within the audit.

──────────────────────────────────────────────────────────────────────────────
13. REQUIRED REPORT ADDITIONS
──────────────────────────────────────────────────────────────────────────────

In addition to every item required by the full audit brief, report:

1. Launcher source identity.
2. Launch-contract identity and complete invariant field map.
3. Carrier-request schema.
4. Carrier 0002 launcher/wrapper self-check.
5. Same-PID exec result.
6. Request-schema drift causals.
7. Confirmation no request repeated the wrapper digest or PATH.
8. Confirmation every carrier used the exact same launcher and contract.
9. Exact failed-root disposition.

Add these confirmations:

CANONICAL_LAUNCH_CONTRACT_RETAINED
CANONICAL_LAUNCH_CONTRACT_HASH_BOUND
WRAPPED_CARRIER_LAUNCHER_RETAINED
WRAPPED_CARRIER_LAUNCHER_HASH_BOUND
LAUNCHER_INVOKED_THROUGH_PINNED_PYTHON
LAUNCHER_USED_SAME_PID_EXEC_TO_WRAPPER
PER_CARRIER_REQUESTS_CONTAIN_NO_INVARIANT_OVERRIDES
WRAPPER_SHA_SOURCED_ONLY_FROM_LAUNCH_CONTRACT
FIXED_PATH_SOURCED_ONLY_FROM_LAUNCH_CONTRACT
REQUEST_SCHEMA_DRIFT_CAUSALS_PASSED
WRAPPER_RETAINED_MODE_0600
WRAPPER_NOT_EXECUTED_DIRECTLY
ALL_WRAPPED_CARRIERS_USED_SAME_LAUNCH_CONTRACT
FAILED_AUDIT_ROOT_NOT_RESUMED
FAILED_AUDIT_ROOT_NOT_MUTATED

Retain every confirmation required by the preceding full-audit brief.

Do not otherwise narrow, simplify, or alter that brief.
```

This changes the process from “repeat fixed launch literals correctly dozens of times” to “freeze them once and mechanically consume them.” That is the appropriate correction after Carrier 0018.

**Source:** Codex’s latest `AUDIT_PROVENANCE_MISMATCH` report.

**Confidence:** 0.999 that Carrier 0018 failed because of per-carrier launch-field drift; 0.995 that a single canonical launcher contract eliminates that class of failure; 0.98 that the V3 audit-repair capsule still requires no additional target change.

Some older uploaded artifacts are no longer available in this session. The inline report is sufficient for this process adjudication; re-upload the artifacts only for direct byte-level inspection.
