## Assessment

Codex made the right readiness decision, but the defect should be classified more narrowly:

**The successor implementation is not presently shown defective. The sealed evidence package is nonqualifying because its packaged post-seal verifier is wrong.**

The reported facts separate cleanly:

- Both disjoint controls passed 59 commands per side.
- All 46 frozen causals, race gates, and deterministic A/B builds passed.
- Repository and predecessor identities passed.
- The manifest was installed as the final mutation.
- An independent read-only verification checked all 623 payloads, 205 directories, and both absence epochs.
- The packaged verifier fails because its post-seal layout assertion still expects the **pre-seal** layout and omits the manifest and detached digest.
- The equivalent corrected assertion passed in memory, but that does not repair the packaged bytes.

So the current A6D child is:

```text
sealed and byte-exact
implementation-validation evidence present
post-seal closure independently reproduced
packaged verification tool defective
not qualifying for downstream A6
```

Do not rerun the implementation or start fresh A6 yet. Also do not mutate or “repair” the sealed A6D child.

The proportional next step is a **new sealed evidence-verifier amendment**, not another successor-source patch. It should preserve the exact successor source, binaries, test records, manifest, and validation outputs; reproduce the packaged-verifier failure; package the minimal corrected verifier; and verify the original A6D child read-only.

A full A/B successor rebuild is unnecessary unless the amendment discovers that source, binaries, validation payloads, or the original manifest are not exact. The proof tooling remains bounded scaffolding and does not become product authority merely because its verifier is repaired. 

## Codex prompt: A6D seal-verifier amendment

```text
Permission is workspace-write for one new source-external evidence-amendment
child only.

Objective

Create, validate, close out, and seal a Repair 10I-A6D post-seal-verifier
amendment.

The sealed Repair 10I-A6D successor implementation child is not currently
qualifying because its packaged post-seal verifier invokes a closing-layout
assertion that omits the manifest and detached digest.

The successor implementation itself must remain byte-exact.

Reported current state:

- both disjoint successor controls passed 59 commands per side;
- all 46 frozen causals passed;
- all required race gates passed;
- all A/B binaries were byte-identical;
- repository and predecessor checks passed;
- the evidence manifest was installed as the final mutation;
- a separate read-only check verified:
  - 623 manifested payloads;
  - 205 directories;
  - complete path/type/mode/size/hash/link closure;
  - two private-root absence epochs;
- original manifest:
  SHA-256
  dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9
- original manifest size:
  103293 bytes;
- packaged verifier:
  commands/verify-postseal-v1.py
- packaged-verifier failure:
  its invoked closing-layout assertion treats the manifest and detached digest
  as unexpected because it uses a pre-seal layout expectation against a
  sealed child;
- the corrected assertion passed in memory only;
- no original sealed byte changed after manifest installation.

This turn must create a new amendment child. It must not modify the original
A6D child.

Do not modify repository source.
Do not modify successor source.
Do not rebuild or replace successor binaries.
Do not modify any sealed predecessor.
Do not modify either failed A6 child.
Do not restart fresh A6.
Do not implement the historical comparator.
Do not run product A/B.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Candidate repository, read-only throughout

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D implementation child

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D reconnaissance

A6D_RECON=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-recon-8de797304ea9

Sealed A6R implementation predecessor

A6R=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

Current failed A6 evidence child, immutable and unsealed

FAILED_A6=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

Required new amendment child, absent at opening

AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

## 1. Physical repository-root lock

Before any repository observation:

1. Component-walk and lstat CANDIDATE_R.
2. Require physical path exactly:
   /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
3. Require:
   - type directory;
   - device 16777234;
   - inode 122118502;
   - mode 0755;
   - UID/GID 501/20.
4. Require physical pwd -P to equal CANDIDATE_R.
5. Require PRIMARY_R to remain a physically distinct sibling:
   - device/inode 16777234/47685738;
   - no equality;
   - no alias;
   - no nesting;
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode 0644;
- size 123;
- device/inode 16777234/122118504;
- link count 1;
- SHA-256:
  79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419;
- exact target:
  /Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1;
- common Git directory:
  /Users/ds/Repositories/Execution Substrate/.git.

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured candidate cwd.

No command may use PRIMARY_R as cwd, Git -C target, source root, or inventory
root.

For inline Python:

- use PYTHONDONTWRITEBYTECODE=1;
- verify os.getcwd() before repository-relative access;
- import no executable module from an evidence child;
- create no __pycache__ or .pyc.

Stop on mismatch:

REPAIR10I_A6D_SEAL_AMENDMENT_WORKTREE_MISMATCH

## 2. Repository and lineage gate

Require exact candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0/0/0/0.

Require A6D_RECON exact:

- manifest SHA-256:
  006d5c51f54fc350f857423014296ea0559996604a723997e56b7f0ac0713da1
- manifest size:
  2357
- payloads:
  18
- directories:
  8 including root.

Require A6R exact:

- manifest SHA-256:
  fe8954e4401005e85059fc0d44684b89bce38c7019d239ebcd5dfa000030f983
- manifest size:
  26785
- payloads:
  193
- directories:
  28.

Require FAILED_A6 to remain present, unsealed, and byte-exact.

Require AMEND to be absent.

Stop on mismatch:

REPAIR10I_A6D_SEAL_AMENDMENT_BASELINE_MISMATCH

## 3. Verify the original A6D seal independently

Before creating AMEND, inspect A6D read-only.

Require:

- root is an existing private directory;
- no root or descendant symlink;
- regular files are single-link;
- directory modes are exact;
- manifest path exists;
- detached digest exists;
- manifest size:
  103293;
- manifest SHA-256:
  dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9;
- manifest payload count:
  623;
- descendant directory count:
  205;
- detached digest content equals the manifest digest;
- complete manifested path set matches actual governed payloads;
- every governed mode, size, and SHA-256 matches;
- no unexpected governed payload;
- successor source inventory and T match the original A6D final report;
- every A/B binary size and SHA-256 matches the original A6D final report;
- repository and predecessor closeout records match;
- two absence epochs are present and internally exact;
- manifest was the final original-child mutation.

Recover the exact successor source T/inventory, four-file delta, schema dialect,
and binary identities from A6D/closeout/final-report-v1.md and the original
manifest.

Do not infer missing identities.

Stop on any seal or payload mismatch:

REPAIR10I_A6D_ORIGINAL_SEAL_MISMATCH

## 4. Reproduce the packaged-verifier defect

Run the original packaged verifier read-only:

A6D/commands/verify-postseal-v1.py

Use its required exact argv, environment, and cwd recovered from the original
evidence.

Require reproduction of the disclosed failure.

Prove that:

- source verification does not fail;
- manifest digest does not fail;
- manifested payload closure does not fail;
- directory-mode closure does not fail;
- private-root absence does not fail;
- the only failing predicate is the closing-layout assertion;
- that assertion expects a pre-seal layout and omits:
  - evidence-manifest-v1.txt;
  - evidence-manifest-v1.txt.sha256.

Retain:

- exact verifier SHA-256;
- exact invoked closing-check helper path and SHA-256;
- exact failing assertion;
- exact expected set;
- exact actual set;
- exact two-path difference;
- stdout/stderr/exit.

If any other predicate fails, stop:

REPAIR10I_A6D_SEAL_AMENDMENT_SCOPE_EXPANSION_REQUIRED

## 5. Create the amendment child

After sections 1–4 pass, create AMEND exclusively under umask 077.

Use exactly:

opening/
tool/
tests/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, nonsymlink, mode 0600 or 0700.

No hardlinks.

The amendment must reference A6D by exact root identity, manifest SHA-256,
manifest size, payload count, source T/inventory, and binary identities.

Do not copy all 623 original payloads into AMEND.

## 6. Minimal authorized amendment scope

Copy into AMEND/tool/original exactly:

- commands/verify-postseal-v1.py;
- the exact closing-check helper it invokes;
- any exact, directly required nonstandard helper dependency.

No other original helper may be changed.

Create corrected copies under:

AMEND/tool/corrected/

Authorize modification of no more than two helper source files:

1. verify-postseal-v1.py, only if necessary;
2. the exact closing-layout/check helper.

The preferred correction is in the helper that owns the incorrect layout
assertion.

If more than two helper files require modification, stop:

REPAIR10I_A6D_SEAL_AMENDMENT_SCOPE_EXPANSION_REQUIRED

Do not change:

- successor source;
- successor binaries;
- original validation records;
- original manifest;
- original sidecar;
- original implementation report;
- repository source;
- any predecessor.

## 7. Frozen verifier semantics

The corrected verifier must distinguish two explicit states.

### Pre-seal layout

Before installation:

- evidence-manifest-v1.txt absent;
- evidence-manifest-v1.txt.sha256 absent;
- all intended pre-seal payloads present;
- no unexpected payload.

### Sealed layout

After installation:

- evidence-manifest-v1.txt present;
- evidence-manifest-v1.txt.sha256 present;
- both excluded from the manifest payload rows under the existing seal format;
- both have exact required mode/type/link posture;
- detached digest content equals manifest SHA-256;
- manifest path set equals every other governed payload;
- no additional unexpected file.

The corrected verifier must never:

- ignore arbitrary extra files;
- accept a missing manifest;
- accept a missing sidecar;
- accept a wrong sidecar digest;
- accept the manifest or sidecar as an unclassified extra;
- accept a post-manifest governed mutation;
- modify A6D;
- restore timestamps;
- normalize permissions;
- remove artifacts.

## 8. Mandatory verifier tests

Create bounded private fixture trees under AMEND tests.

Required cases:

1. Valid pre-seal layout passes pre-seal verification.
2. Valid sealed layout passes sealed verification.
3. Original vulnerable packaged helper rejects the valid sealed layout for
   exactly the disclosed two-path reason.
4. Missing manifest rejects.
5. Missing sidecar rejects.
6. Wrong detached digest rejects.
7. Unexpected third extra file rejects.
8. Manifest incorrectly listed as a payload rejects.
9. Sidecar incorrectly listed as a payload rejects.
10. Missing manifested payload rejects.
11. Unexpected governed payload rejects.
12. Payload mode mismatch rejects.
13. Payload size mismatch rejects.
14. Payload hash mismatch rejects.
15. Payload link-count mismatch rejects.
16. Directory-mode mismatch rejects.
17. Symlink or special file rejects.
18. Mutation after manifest installation rejects.
19. Corrected verifier performs zero writes.
20. Repeated corrected-verifier output is byte-identical.

All fixtures must be amendment-owned and removed before sealing.

## 9. Verify the original A6D child with the corrected verifier

Run the corrected verifier against A6D twice.

Require:

- both exits 0;
- byte-identical canonical output;
- exact A6D manifest identity;
- 623 payloads;
- 205 directories;
- exact detached digest;
- complete path/type/mode/size/hash/link closure;
- exact source T/inventory;
- exact binary identities;
- repository/predecessor closeout equality;
- both absence epochs;
- no write to A6D.

Bracket A6D before and after with complete safe identity observations.

Require no path, mode, size, hash, link, directory-mode, manifest, sidecar, or
root-identity change.

## 10. Read-only original validation adjudication

Reopen the original A6D validation records read-only.

Require:

- 59 commands per side;
- all 46 frozen causals executed and passed;
- all required race gates passed;
- no required skip;
- no race report;
- no malformed stream;
- no missing/duplicate terminal;
- deterministic A/B builds;
- byte-identical binary pairs;
- complete cleanup;
- no source or binary mismatch.

Do not rerun the full successor tests or builds unless a retained identity or
record fails verification.

If any validation record is missing, inconsistent, or does not bind the exact
original source and binaries, stop:

REPAIR10I_A6D_SEAL_AMENDMENT_VALIDATION_MISMATCH

## 11. Amendment classification

The final amendment must classify the original A6D result as:

- successor implementation bytes unchanged;
- original validation bytes unchanged;
- original manifest bytes unchanged;
- original evidence child sealed but packaged-verifier-defective;
- corrected verifier supplied by separately sealed amendment;
- original helper superseded for qualification;
- original child plus amendment jointly form the qualifying successor evidence
  input.

Do not claim the original packaged helper passed.

Do not rewrite the original final report.

Do not call this a source repair, schema repair, or repository repair.

## 12. Amendment closeout and sealing

Require:

- only AMEND was written;
- A6D remained byte-exact;
- repository remained:
  - T `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
  - inventory
    `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
  - membership `389/375/14`;
  - staged/deleted/renamed/unmerged `0/0/0/0`;
- branch/HEAD/parent/tree/upstream/index unchanged;
- every predecessor unchanged;
- no predecessor cache or bytecode;
- all amendment fixture roots removed;
- two amendment absence epochs pass;
- command-root audit proves no command used PRIMARY_R as cwd or source root.

Install the amendment detached digest before its manifest.

Install AMEND/evidence-manifest-v1.txt as the final mutation.

Write nothing afterward.

Run the corrected verifier against:

1. original A6D;
2. sealed AMEND, using the amendment’s own seal contract.

Perform complete read-only post-seal verification.

## 13. Fresh-A6 input contract

Freeze downstream input as the pair:

1. original sealed A6D implementation child:
   manifest
   dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

2. sealed A6D verifier amendment:
   exact new manifest identity from this turn.

A future fresh A6 opening gate must verify both.

It must use the corrected verifier from AMEND.

It must not use the defective verifier from A6D for qualification.

This amendment remains a bounded evidence-tool correction. It does not
substitute for the fresh five-control A6 refresh.

## 14. Mandatory stop conditions

Stop on:

- physical-root mismatch;
- repository or lineage mismatch;
- original A6D manifest/payload mismatch;
- original packaged failure cannot be reproduced exactly;
- any original verification predicate other than layout fails;
- more than two helper files require modification;
- successor source or binary change;
- original validation mismatch;
- corrected verifier ignores arbitrary extras;
- corrected verifier mutates A6D;
- repeated output differs;
- original A6D changes during verification;
- fixture residue;
- amendment seal failure.

## 15. Verdicts

Opening mismatch:

REPAIR10I_A6D_SEAL_AMENDMENT_BASELINE_MISMATCH

Original A6D seal mismatch:

REPAIR10I_A6D_ORIGINAL_SEAL_MISMATCH

Scope expansion required:

REPAIR10I_A6D_SEAL_AMENDMENT_SCOPE_EXPANSION_REQUIRED

Original validation mismatch:

REPAIR10I_A6D_SEAL_AMENDMENT_VALIDATION_MISMATCH

Amendment implementation, verification, cleanup, or seal failure:

REPAIR10I_A6D_SEAL_AMENDMENT_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6D_SEAL_VERIFIER_AMENDMENT_SEALED_READY_FOR_FRESH_A6_RESTART

## 16. Required success report

Include:

1. Repository opening/closing identity.
2. Original A6D manifest, source, binary, and validation identities.
3. Exact original packaged-verifier failure.
4. Exact corrected helper path set and hashes.
5. Pre-seal versus sealed-layout contract.
6. All verifier-test outcomes.
7. Two corrected read-only verification runs against original A6D.
8. Confirmation all 623 payloads and 205 directories verify.
9. Confirmation original A6D bytes never changed.
10. Confirmation successor source/binaries were not rebuilt or modified.
11. Original-validation adjudication.
12. Amendment manifest SHA-256, size, and payload count.
13. Cleanup and two absence epochs.
14. Joint downstream-input contract.
15. Explicit statement that fresh A6 was not restarted, the historical
    comparator was not implemented, product A/B was not run, and no snapshot
    or audit occurred.

No fresh A6 restart.
No successor source repair.
No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After the amendment seals

Restart A6 from the beginning in a new child, binding **both** the original A6D implementation manifest and the amendment manifest. Do not resume either failed A6 child.

The amendment changes evidence-tool bytes, so it needs its own exact provenance and validation. It does not invalidate the already completed successor-source tests unless the amendment exposes a mismatch in those retained records. Implementation, independent audit, and repair remain separate engagements; any substantive byte change later returns the chain through validation and re-audit. 

Provenance can establish that the original A6D child and amendment were verified exactly, but it does not by itself prove that the device-security contract is correct or that the eventual five-control A6 matrix is sufficient. 

### Sources

- Codex’s `REPAIR10I_A6D_SOURCE_OR_TOOL_REPAIR_REQUIRED` report supplied in this turn.
- Milestone 0 proof-scaffolding and non-authority boundary. 
- Governed Execution repair and re-audit protocol. 
- Governed Execution provenance limits. 

**Confidence**

- Successor implementation likely correct on the supplied validation evidence: **0.98**
- Original seal bytes likely internally exact: **0.995**
- Current downstream readiness without amendment: **0.00**
- Confidence that a separate evidence-verifier amendment is the proportional repair: **0.96**
- Confidence that full successor A/B reimplementation is unnecessary unless the amendment finds a retained mismatch: **0.93**
