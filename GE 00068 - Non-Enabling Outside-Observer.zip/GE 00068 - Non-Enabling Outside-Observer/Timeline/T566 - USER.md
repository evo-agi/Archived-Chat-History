Here is Codex's response:

1. **Exact wrapper verdict — `AUDIT_PROVENANCE_MISMATCH`**

`REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED`  
`SUCCESSOR_REAL_AUDIT_AUTHORIZATION_NOT_CONSUMED`

The mandatory prelaunch exact-agreement gate failed. Profile v3 contains four stale directory-inventory digests, while certificate v4, runtime authority v2, and two stable no-follow filesystem projections agree with one another:

| Role | Profile v3 | Certificate v4 / authority v2 / observed |
|---|---|---|
| Replacement subject | `336539da…920e` | `eb46c6784…ea3` |
| Construction wrapper | `444847c4…16b7` | `9c6736d6…60e` |
| Accepted implementation audit | `8545cfdb…c89` | `3e88e9c4…22d` |
| Accepted implementation wrapper | `dff89a86…975b` | `6d1d2176…108` |

Profile v3 defines no alternate inventory-digest algorithm. Consequently, Section 11’s exact-authority agreement requirement is unsatisfied.

## Operative report

1. Exact wrapper verdict: shown above.
2. Raw harness disposition: not produced; the harness was never launched.
3. Successor PYZ: device `16777234`, inode `182785051`, mode `0400`, link count `1`, size `4216423`, SHA-256 `d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19`.
4. Authority v2: device `16777234`, inode `182785057`, mode `0400`, link count `1`, size `47750`, SHA-256 `64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec`.
5. Profile v3: device `16777234`, inode `182785068`, mode `0400`, link count `1`, size `11778`, SHA-256 `c5707b91fbf8e05f5bb926f01c93d65791386e9dc1ba08924d11659cf66298fa`.
6. Certificate v4: device `16777234`, inode `182785073`, mode `0400`, link count `1`, size `31870`, SHA-256 `b98a9f32d89ba69c14050e1fd6194a8a981c4007ad063eb54e2aae43a21f79b5`.
7. Predecessor posture: predecessor identities matched. Certificate v4 classifies profile v2 and certificate v3 as immutable, historical, consumed, non-current, with zero active authorization.
8. Replacement subject: inode `182649818`, mode `0700`, UID/GID `501/20`; 73 entries, 12 directories, 61 files; stable inventory `eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3`.
9. Construction wrapper: inode `182648782`; 49 entries, 12 directories, 37 files; stable inventory `9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e`.
10. Accepted implementation: audit inventory `3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d`; wrapper inventory `6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108`; accepted disposition authenticated.
11. Content: bundle and authority identities matched. Bundle closed at 479 unique sorted `ZIP_STORED` members, eight roles, valid 478-row index plus self, and no `.DS_Store`.
12. Stable prelaunch authentication: all files passed two stable no-follow reads; all four roots passed two identical inventory projections. Physical identities matched the requested values.
13. Successor authority closure: failed solely on the four profile-v3 inventory bindings above.
14. Successor PYZ closure: passed after direct parsing—75 members, 74 registered non-self members, exact set, fixed timestamps, Unix metadata, mode `0600`, no unsafe paths, comments, extras, cache, bytecode, or special members.
15. Wrapper evidence root: not allocated.
16. Workspace: not allocated.
17. Capsule-child absence: no workspace or capsule path was instantiated.
18. Platform preflight: not executed, as required after a prelaunch failure.
19. Audit invocation: exact argv, five-variable environment, workspace cwd, and `audit-capsule` child policy were derived, but placeholders were not resolved because allocation was forbidden.
20. Top-level process custody: no audit-parent process was created.
21. Raw audit streams: none produced.
22. Audit exit/signal: none.
23. Terminal frame: none.
24. Capsule root: none created or scanned.
25. Source/freeze/no-VCS: 11-source freeze and package bindings authenticated; no VCS invocation occurred.
26. Ten-role resolution: embedded ten-role registry authenticated; live resolution was not executed.
27. Subject terminal closure: not audited.
28. Normative contract: remained within the unchanged two-pass subject inventory; substantive validation not executed.
29. Fifteen schema roles: exact embedded 15-role model authenticated.
30. Fourteen generated families: exact embedded 14-family model authenticated.
31. Role/family mapping: embedded model passed, including the intentionally unmapped normative parent.
32. Draft 2020-12: real-audit result not produced.
33. Contract-witness rows: not executed.
34. Schema-witness rows: not executed.
35. Witness aggregate: not produced.
36. Complete 946 result: not executed.
37. Failed 946 rows: none produced.
38. Complete 137 result: not executed.
39. Failed 137 rows: none produced.
40. Dual-oracle crosswalk: not executed.
41. 766/333 field map: not audited.
42. Documentary-validator closure: not audited.
43. Confirmation derivation: not executed.
44. Derivative-confirmation ledger: not produced.
45. Occupancy, lineage, and producer status: not substantively adjudicated.
46. Findings: one prelaunch provenance finding—the four stale profile-v3 inventory bindings.
47. Repair owner: successor launch-authority/profile producer; repair surface is profile v3 and its dependent certificate chain. Subject bytes do not need to change.
48. Dependency graph: launch is blocked at profile-v3/current-root agreement, before workspace allocation.
49. A00–A15: not created.
50. Child custody: no preflight or audit child created.
51. Audit cleanup: not applicable; nothing was allocated.
52. Capsule supplied-root equality: not applicable.
53. Wrapper fixed-input equality: stable prelaunch equality passed; post-process equality is not applicable.
54. Audit temporal identity: not produced.
55. Audit manifests: not produced.
56. A/B equality: not applicable.
57. Final reprojection: not executed.
58. Audit topology/modes: no audit root exists.
59. A15/closure agreement: not applicable.
60. Seal/no-postseal: no seal transition occurred.
61. Subject unchanged: confirmed by identical two-pass inventories; no mutation or cleanup was performed.
62. Authority promotion/rebinding: neither performed.
63. Product/runtime/target/A6: none performed.
64. Remaining uncertainty: no subject verdict exists because the real audit did not execute.
65. Explicit confirmations:

```text
SUCCESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED = TRUE
SUCCESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED = TRUE
CURRENT_PROFILE_V3_IDENTITY_MATCHED = TRUE
CURRENT_CERTIFICATE_V4_IDENTITY_MATCHED = TRUE
PREDECESSOR_REAL_AUDIT_AUTHORIZATION_CONSUMED = TRUE
EXACTLY_ONE_ACTIVE_SUCCESSOR_AUDIT_AUTHORIZATION = TRUE
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED = TRUE
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED = TRUE
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED = TRUE
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED = TRUE
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED = TRUE
SUCCESSOR_AUTHORITY_CURRENT_AND_COHERENT = FALSE
SUCCESSOR_PYZ_MEMBER_SET_75_CLOSED = TRUE
PLATFORM_CAPTURE_PREFLIGHT_PASSED = NOT_EXECUTED
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE = FALSE
SUCCESSOR_AUDIT_AUTHORIZATION_CONSUMED = FALSE
QUALIFICATION_MODE_NOT_EXECUTED = TRUE
REHEARSAL_MODE_NOT_EXECUTED = TRUE
SYNTHETIC_MODE_NOT_EXECUTED = TRUE
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED = TRUE
ADMINISTRATIVE_CONTINUATION_NOT_USED = TRUE
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS = TRUE
RAW_STDOUT_RETAINED = NOT_APPLICABLE
RAW_STDERR_RETAINED = NOT_APPLICABLE
PLATFORM_EXIT_AND_SIGNAL_RETAINED = NOT_APPLICABLE
AUDIT_ROOT_SCAN_NOT_PERFORMED = TRUE
TERMINAL_FRAME_STRICTLY_PARSED = NOT_EXECUTED
TERMINAL_FRAME_ROOT_EQUALS_PROFILE_DERIVED_CAPSULE_CHILD = NOT_EXECUTED
SUCCESSOR_CLEAN_SOURCE_FREEZE_AUTHENTICATED = TRUE
NO_GIT_OR_VCS_INVOCATION = TRUE
SUBJECT_INPUT_ACCESS_SET_10_COMPLETE = NOT_EXECUTED
SUBJECT_INPUT_ACCESS_EQUAL_DEPENDENCY_REGISTRY = NOT_EXECUTED
NO_ACCEPTANCE_BEARING_DIRECT_SUBJECT_PATH_LITERAL = PRELAUNCH_PACKAGE_ASSERTION_ONLY
NO_UNHANDLED_ENOENT = NOT_APPLICABLE
SUBJECT_TERMINAL_REPROJECTION_PASSED = NOT_EXECUTED
NORMATIVE_CONTRACT_BYTES_UNCHANGED = TRUE_PRELAUNCH
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES = TRUE_EMBEDDED_CONTRACT
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES = TRUE_EMBEDDED_CONTRACT
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY = TRUE
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE = TRUE_EMBEDDED_CONTRACT
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID = NOT_EXECUTED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID = NOT_EXECUTED
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID = NOT_EXECUTED
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE = NOT_EXECUTED
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED = NOT_EXECUTED
EVERY_NONPASSING_946_ROW_RETAINED = NOT_APPLICABLE
CONTRADICTION_REGRESSION_137_COMPLETED = NOT_EXECUTED
EVERY_NONPASSING_137_ROW_RETAINED = NOT_APPLICABLE
DUAL_ORACLE_RESULTS_AGREE = NOT_EXECUTED
NO_ORACLE_EXCEPTION = NOT_EXECUTED
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED = NOT_EXECUTED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED = NOT_EXECUTED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET = NOT_EXECUTED
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT = NOT_EXECUTED
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED = NOT_EXECUTED
CONFIRMATION_EVIDENCE_MAP_COMPLETED = NOT_EXECUTED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS = NOT_EXECUTED
NO_HARDCODED_CONFIRMATION_SUCCESS = NOT_EXECUTED
CURRENT_ROLE_OCCUPANCY_COMPLETE = NOT_EXECUTED
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED = NOT_EXECUTED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT = TRUE_CURRENT_LINEAGE
NO_FAILED_ARTIFACT_CURRENT = TRUE_CURRENT_LINEAGE
IMPLEMENTATION_PRESENT_FALSE = NOT_ADJUDICATED
IMPLEMENTATION_AUTHORITY_FALSE = NOT_ADJUDICATED
PRODUCER_PACKAGE_NOT_SELF_PROMOTED = NOT_ADJUDICATED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED = NOT_ADJUDICATED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE = NOT_APPLICABLE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER = NOT_APPLICABLE
FINDING_OWNERSHIP_COMPLETE = TRUE_FOR_PRELAUNCH_FINDING
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL = NOT_EXECUTED
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS = NOT_EXECUTED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS = NOT_APPLICABLE
ALL_CREATED_CHILDREN_REAPED = TRUE_ZERO_CHILDREN
ALL_CHILD_DESCRIPTORS_CLOSED = TRUE_ZERO_CHILDREN
AUDIT_CLEANUP_SET_EQUALITY_PASSED = NOT_APPLICABLE
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED = NOT_EXECUTED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED = NOT_APPLICABLE_NO_LAUNCH
AUDIT_TEMPORAL_INVENTORY_CREATED = FALSE
AUDIT_TEMPORAL_INVENTORY_VERIFIED = NOT_EXECUTED
AUDIT_MANIFEST_A_CREATED = FALSE
AUDIT_MANIFEST_B_CREATED = FALSE
AUDIT_MANIFESTS_BYTE_IDENTICAL = NOT_EXECUTED
AUDIT_TERMINAL_REPROJECTION_PASSED = NOT_EXECUTED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE = NOT_EXECUTED
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE = NOT_EXECUTED
NO_SYMLINK_OR_SPECIAL_OBJECT = NOT_EXECUTED_FOR_AUDIT_ROOT
NO_MULTIPLY_LINKED_FILE = NOT_EXECUTED_FOR_AUDIT_ROOT
ALL_AUDIT_DIRECTORY_MODES_0700 = NOT_EXECUTED
ALL_AUDIT_FILE_MODES_0600 = NOT_EXECUTED
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED = TRUE_NO_AUDIT_ROOT
SINGLE_AUDIT_SEAL_TRANSITION = FALSE
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL = NOT_APPLICABLE
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED = TRUE
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED = TRUE
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED = TRUE
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED = TRUE
NO_NETWORK_CONTACT = TRUE
NO_GIT_INVOCATION = TRUE
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION = TRUE
NO_TARGET_AUDIT_EXECUTED = TRUE
NO_RUNTIME_VALIDATION_RERUN = TRUE
NO_A6_ACTIVITY = TRUE
```

No repository, audit input, authority artifact, or subject file was modified. No wrapper/workspace/capsule root was created.
