## Assessment

Codex stopped at the correct evidentiary boundary. The file’s **bytes are known**, but its **role was not retained** inside the failed root. Selecting it because it was the only Python file would have turned filesystem circumstance into authority.

The missing authority can now be supplied explicitly and prospectively. The next prompt should designate the exact path, size, and SHA-256 as the candidate construction-parent source. That designation does **not** retroactively validate the failed execution or invent its missing argv, environment, or outcome. It only makes the exact bytes lawful input to a new forward-looking qualification.

The new task should therefore:

- bind the candidate through an external source-designation record;
- determine whether its construction semantics are sufficient to preserve;
- repair only its process envelope;
- qualify and freeze it through process-self-test mode;
- never execute construct mode;
- stop if the candidate requires reconstruction of package-construction semantics rather than bounded process-envelope repair.

Forward this prompt to Codex:

```text
EXTERNAL SOURCE-AUTHORITY BINDING,
PROCESS-ENVELOPE REPAIR, QUALIFICATION, AND FREEZE OF THE
TARGET-AUDIT HARNESS PACKAGE-CONSTRUCTION PARENT

This task explicitly designates one exact historical file as the candidate
source for a new forward-looking construction-parent qualification.

The designation in this task is the source-selection authority.

Do not infer the source role from:

- filename;
- uniqueness;
- content;
- directory location;
- recency;
- scoring;
- fallback.

Do not claim that this designation retroactively validates the failed attempt’s
execution, argv, cwd, environment, process result, or filesystem effects.

It authorizes only:

- read-only authentication of the exact candidate bytes;
- copying those bytes into a fresh qualification capsule;
- determining whether their package-construction semantics are sufficient;
- bounded repair of their process envelope;
- process-self-test qualification;
- exact-byte freeze.

It does not authorize:

- package construction;
- semantic export creation;
- metadata repair;
- a target audit;
- runtime validation;
- repository or product work.

Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXPLICIT EXTERNAL SOURCE DESIGNATION
──────────────────────────────────────────────────────────────────────────────

For this task, the following exact file is explicitly designated as:

historical_failed_retry_construction_parent_candidate

FAILED_PROCESS_CLEAN_RETRY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-y3vg_lqk

Expected root identity:

- device/inode:
  16777234 / 180354266
- mode:
  0700
- retained verdict:
  PREFLIGHT_PROVENANCE_MISMATCH

DESIGNATED_CANDIDATE_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-y3vg_lqk/provenance/package-construction-parent-source.py

Required identity:

- size:
  11872
- SHA-256:
  0e4006ca3492e66f60f54a9b2983f573574e9c82985fa85e31a96abc4a1e6bbd
- mode:
  0600
- link count:
  1

This instruction—not the failed root—is the authority for selecting this exact
file as the candidate.

Permitted use:

- authenticate;
- copy;
- compile without import;
- parse;
- inspect;
- use as the source basis for bounded process-envelope repair.

Forbidden use:

- execute from the historical root;
- import from the historical root;
- treat as current authority;
- infer prior invocation or runtime success;
- claim it was the source actually executed in the failed attempt;
- adopt any other historical output as current qualification.

If the root or candidate identity differs, return:

PREFLIGHT_PROVENANCE_MISMATCH

Do not continue.

──────────────────────────────────────────────────────────────────────────────
2. EXTERNAL SOURCE-AUTHORITY RECORD
──────────────────────────────────────────────────────────────────────────────

In the fresh qualification root, retain before copying or repair:

opening/external-source-designation-v1.json

Required fields:

- designation_authority:
  current-task-instruction;
- historical_root;
- historical_root device/inode/mode;
- candidate absolute path;
- candidate relative path;
- candidate size;
- candidate SHA-256;
- candidate mode;
- candidate link count;
- designated role:
  historical_failed_retry_construction_parent_candidate;
- permitted use:
  input-to-fresh-forward-qualification;
- current authority:
  false;
- prior execution authority:
  false;
- prior invocation known:
  false;
- prior runtime result known:
  false;
- retroactive execution claim:
  false;
- filename-based selection:
  false;
- uniqueness-based selection:
  false;
- external designation required:
  true.

This record makes the exact bytes a lawful input. It does not repair the failed
root or establish historical execution truth.

──────────────────────────────────────────────────────────────────────────────
3. OTHER HISTORICAL ROOTS
──────────────────────────────────────────────────────────────────────────────

The following root is also historical and nonauthoritative:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-repair-gd5twfqb

Expected verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

Do not use:

- its candidate-selection logic;
- its report as source authority;
- any builder, validator, source, fixture, or generated result from it.

It need not be opened unless required to authenticate the historical lineage
statement. If opened, require complete opening/closing equality.

Do not open earlier failed retry roots unless indispensable to resolve a
specific fixed-input identity. Do not execute or import anything from them.

──────────────────────────────────────────────────────────────────────────────
4. FRESH QUALIFICATION CAPSULE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-qualified-

Immediately emit:

PARENT_QUALIFICATION_ROOT=<absolute-path>

Retain:

opening/bootstrap-start.json

before substantive inspection beyond the exact designated source.

Record:

- fresh-root identity;
- allocation method;
- umask;
- external source designation;
- candidate identity;
- source-qualification-only authority;
- package construction authorized:
  false;
- construct mode authorized:
  false;
- semantic exports may be written:
  false;
- target audit executed:
  false;
- runtime validation rerun:
  false.

Create directories lazily.

Do not retain empty directories.

──────────────────────────────────────────────────────────────────────────────
5. EXACT CANDIDATE COPY
──────────────────────────────────────────────────────────────────────────────

Copy the designated candidate to:

opening/original-package-construction-parent.py

Use:

- no-follow source open;
- stable pre-read and post-read fstat;
- exclusive destination creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/original-parent-source-identity-v1.json

The copied original must never be executed or imported.

──────────────────────────────────────────────────────────────────────────────
6. SOURCE-SUFFICIENCY GATE
──────────────────────────────────────────────────────────────────────────────

Before repairing anything, determine whether the designated source contains a
coherent package-construction implementation whose substantive semantics can be
preserved.

Compile it without execution using pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B

Then parse its AST and retain:

analysis/candidate-source-sufficiency-v1.json

Identify:

- top-level entry points;
- package-construction functions;
- export-construction functions;
- metadata-generation functions;
- qualification functions;
- freeze functions;
- terminal-inventory functions;
- manifest functions;
- process-launch functions;
- process-recording functions;
- cleanup functions;
- any existing execution-mode handling.

For each function retain:

- source range;
- AST SHA-256;
- role;
- construction-semantic or process-envelope classification;
- completeness assessment;
- consumers.

Require all of the following:

1. The source contains a coherent package-construction path.
2. That path corresponds to the intended metadata-repair package task.
3. Construction-semantic functions can remain AST-identical.
4. Missing work is bounded to the process envelope and admission controls.
5. The source is not merely a stub, diagnostic, partial extractor, or bootstrap
   fragment.
6. A self-test/construct mode split can be added without changing construction
   semantics.
7. All child creation can be routed through one recorder without changing the
   child commands’ substantive meaning.

If any requirement fails, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

Report the exact missing or inseparable construction semantics.

Do not create a replacement parent from scratch in this task.

──────────────────────────────────────────────────────────────────────────────
7. FRESH REPAIRED SOURCE
──────────────────────────────────────────────────────────────────────────────

Only after the source-sufficiency gate passes, create:

working/package_construction_parent_v1.py

Repair authority is exactly:

target-audit-harness-package-construction-process-envelope

Only these surfaces may change:

1. explicit execution modes;
2. construction admission gate;
3. executable-origin policy;
4. executable-origin registry;
5. registry freeze;
6. pinned-Python invocation enforcement;
7. child-process recorder;
8. prelaunch records;
9. spawn-failure records;
10. stdout/stderr retention;
11. exit/signal retention;
12. reaping and descriptor closure;
13. fixed-output attribution;
14. dynamic-root locator attribution;
15. process/cache cleanup registry;
16. process-ledger completeness gate;
17. process self-test;
18. failure closeout for the process envelope.

Construction-semantic functions must remain AST-identical.

No change is authorized to:

- semantic export contents;
- package root-rebinding rules;
- metadata pointer requirements;
- qualification oracles;
- package freeze semantics;
- package terminal inventory;
- package manifest grammar;
- target-audit operands;
- target-audit acceptance rules;
- verdict rules.

If a process repair requires changing one of those surfaces, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

Do not widen the repair.

──────────────────────────────────────────────────────────────────────────────
8. EXECUTION-MODE SPLIT
──────────────────────────────────────────────────────────────────────────────

Require one explicit mode:

--mode process-self-test
--mode construct

There is no default.

Missing or unknown mode must fail before opening any semantic package input.

For this task:

- only `process-self-test` may execute;
- `construct` must not execute;
- no semantic export may be created;
- no final package root may be allocated.

Retain static and bytecode control-flow evidence that:

- process-self-test cannot reach construction;
- construct cannot begin before the process-provenance gate;
- neither branch falls through into the other.

──────────────────────────────────────────────────────────────────────────────
9. TOP-LEVEL PROCESS AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/top-level-process-authority-v1.json

Freeze:

- Codex platform transcript is authority for:
  - top-level parent creation;
  - submitted argv;
  - cwd;
  - explicit environment;
  - PID when exposed;
  - raw stdout/stderr;
  - exit or signal;
  - elapsed duration.
- Capsule is authority for:
  - source identity;
  - executable registry;
  - child prelaunch records;
  - child outcomes;
  - stream bytes;
  - filesystem effects;
  - cleanup;
  - self-test result.
- Capsule does not self-attest top-level parent creation or post-exit state.

No administrative continuation is allowed.

──────────────────────────────────────────────────────────────────────────────
10. EXECUTABLE-ORIGIN POLICY AND REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before any repaired-parent execution, retain:

contract/executable-origin-policy-v1.json
opening/executable-origin-registry-v1.json
opening/executable-origin-registry-freeze-v1.json

Allowed origins:

A. Pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

B. Exact absolute-path OS executables explicitly registered.

C. Fresh self-test helpers retained in this fresh root and hash-bound before
   execution.

D. Exact frozen repaired parent.

Forbidden:

- all historical or failed roots;
- unretained here-doc source;
- unretained temporary source;
- PATH-resolved scripts;
- basename, prefix, recency, scoring, or fallback;
- symlinked or multi-linked source;
- source modified after registry freeze.

Every registry row must bind:

- role;
- absolute path;
- file identity;
- source or binary;
- producer;
- permitted consumers;
- permitted argv shape;
- cwd;
- environment;
- first permitted ordinal;
- current:
  true.

No child or repaired parent may execute before the registry-freeze record
exists.

──────────────────────────────────────────────────────────────────────────────
11. PINNED PYTHON CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/pinned-python-invocation-v1.json

Every Python process must use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B

as separate argv elements in that order.

Required explicit stable environment includes:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Use audit-owned HOME, TMPDIR, and PYTHONPYCACHEPREFIX paths.

Reject before spawn:

- `python`;
- `python3`;
- `/usr/bin/python3`;
- `/usr/bin/env python`;
- shebang-direct Python execution;
- missing or reordered flags;
- unregistered source;
- package-root cache destination.

──────────────────────────────────────────────────────────────────────────────
12. CHILD-PROCESS RECORD CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/child-process-record-v1.json

For every child ordinal require:

A. Prelaunch record created exclusively and fsynced before spawn:

- ordinal;
- purpose;
- registered executable origin;
- argv;
- cwd;
- explicit environment;
- timeout;
- stdin;
- stdout/stderr policy;
- fixed outputs;
- dynamic-output contract;
- prelaunch path state;
- permitted filesystem scope.

B. Exact stdout bytes.

C. Exact stderr bytes.

D. Outcome:

- process-created;
- spawn exception;
- PID;
- exit/signal;
- timeout;
- reaped;
- descriptor closure;
- fixed-output post-state;
- dynamic locators;
- paths written;
- complete dynamic-root inventories;
- cleanup registrations;
- first blocker;
- disposition.

Require contiguous ordinals, no duplicates, and no bypass.

──────────────────────────────────────────────────────────────────────────────
13. FILESYSTEM-EFFECT ATTRIBUTION
──────────────────────────────────────────────────────────────────────────────

Support:

A. Fixed outputs declared before launch.

B. Dynamic roots declared before launch with:

- exact parent;
- exact prefix;
- full-match stdout locator grammar;
- expected locator count;
- type/mode requirements.

Parse locators on:

- exit 0;
- nonzero exit;
- timeout;
- later parse failure.

For every valid locator:

- retain exact stdout;
- require exactly one locator and no extra bytes;
- lstat exact path;
- verify direct parent and prefix;
- retain root identity and full inventory;
- add to `paths_written`;
- add to cleanup registry.

Missing or ambiguous dynamic attribution is provenance-fatal.

No scans, newest selection, scoring, guessing, or fallback.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS SELF-TEST
──────────────────────────────────────────────────────────────────────────────

The process-self-test mode must exercise only audit-owned causals:

1. missing executable / ENOENT;
2. `/usr/bin/true`;
3. pinned Python version;
4. registered fresh helper and fixed output;
5. unregistered executable rejection;
6. historical-root executable rejection;
7. unpinned Python rejection;
8. missing `-I`;
9. missing `-S`;
10. missing `-B`;
11. wrong flag order;
12. fixed-output attribution;
13. dynamic-root success attribution;
14. dynamic-root nonzero attribution;
15. invalid locator rejection;
16. timeout with complete custody;
17. duplicate ordinal rejection;
18. missing prelaunch rejection;
19. incomplete stream record rejection;
20. direct subprocess bypass rejection.

No causal may inspect or write a semantic package input.

──────────────────────────────────────────────────────────────────────────────
15. PROCESS-LEDGER MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/process-ledger-mutation-matrix-v1.json

Cover every causal above plus:

- source identity drift;
- registry mutation after freeze;
- executable symlink;
- multi-link source;
- wrong cwd;
- environment drift;
- undeclared output;
- wrong dynamic-root parent/prefix;
- duplicate locator;
- extra stdout;
- omitted `paths_written`;
- omitted cleanup registration;
- root identity rebinding;
- missing ENOENT observation;
- process survivor;
- descriptor survivor;
- cache survivor;
- package-local `.pyc`;
- failed child counted as passing;
- child launched before registry freeze;
- construct branch entered by self-test.

Require zero false acceptance, false rejection, reason mismatch, and skip.

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT PROCESS VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports neither:

- repaired parent;
- recorder implementation;
- first matrix helper;
- producer fixtures.

Independently validate:

- registry closure;
- origins;
- pinned Python;
- flags;
- prelaunch-before-spawn;
- ordinal continuity;
- stream custody;
- outcomes;
- effect attribution;
- cleanup equality;
- no bypass;
- no construction entry.

Retain:

validation/independent-process-envelope-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
17. STATIC PRE-EXECUTION GATES
──────────────────────────────────────────────────────────────────────────────

Before executing the repaired parent:

1. Compile with pinned Python and exact flags.
2. Parse AST.
3. Build call graph.
4. Locate all subprocess/spawn/exec/system/shell calls.
5. Require every permitted child creation through the recorder.
6. Require no import-time execution.
7. Require no stdin or persistent loop.
8. Require explicit mode split.
9. Require self-test cannot reach construction.
10. Require construct gated by complete process provenance.
11. Require self-test cannot write semantic exports.
12. Require no historical executable source.

Use two independent analyses:

- AST/call graph;
- bytecode/exception-table CFG.

Require agreement.

──────────────────────────────────────────────────────────────────────────────
18. EXACT SOURCE DELTA
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/exact-parent-source-delta-v1.json

For every changed hunk record:

- original/repaired ranges;
- owning process defect;
- before and after;
- authority effect;
- construction-semantic effect:
  none.

Require function-level AST equality for every construction-semantic function.

If the gate cannot prove this, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

──────────────────────────────────────────────────────────────────────────────
19. FREEZE BEFORE EXECUTION
──────────────────────────────────────────────────────────────────────────────

Only after all contracts, registry, self-test definitions, validators, static
checks, and delta records pass, install exact repaired bytes at:

provenance/package-construction-parent.py

Use exclusive mode-0600 creation, fsync, close, no-follow reopen, and exact byte
comparison.

Retain:

opening/package-construction-parent-freeze-v1.json

Bind:

- external source designation;
- original identity;
- repaired identity;
- exact delta;
- process contracts;
- executable registry and freeze;
- self-test registry;
- validator identities;
- static-check identities;
- source frozen:
  true;
- later modification permitted:
  false;
- construct mode executed:
  false.

No repaired-parent execution is permitted before this record exists.

──────────────────────────────────────────────────────────────────────────────
20. EXECUTE ONLY SELF-TEST MODE
──────────────────────────────────────────────────────────────────────────────

Invoke the exact frozen source once:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FRESH_ROOT>/provenance/package-construction-parent.py
--mode
process-self-test

Use:

- one finite noninteractive top-level carrier;
- DEVNULL stdin;
- exact registered cwd/environment;
- no later input;
- no replacement parent.

Retain platform-authoritative argv, cwd, environment, PID when exposed, raw
streams, exit/signal, and duration.

Require exit 0.

Do not run `--mode construct`.

──────────────────────────────────────────────────────────────────────────────
21. CLEANUP AND SELF-TEST RESULT
──────────────────────────────────────────────────────────────────────────────

Build cleanup registry only from:

- validated dynamic locators;
- declared fixture roots;
- registered cache roots.

For every root:

- retain pre-removal inventory;
- require child reaped;
- require descriptors closed;
- revalidate identity;
- remove exact root;
- observe ENOENT twice.

Require:

created
=
inventoried
=
cleanup rows
=
twice absent

Retain:

validation/process-self-test-result-v1.json

Require:

- exact source;
- registry frozen first;
- construct mode not entered;
- all required causals run;
- expected classifications pass;
- ordinals contiguous;
- streams/outcomes complete;
- effects complete;
- cleanup equality;
- no cache/bytecode;
- success true;
- first blocker null.

──────────────────────────────────────────────────────────────────────────────
22. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

After self-test:

- reopen frozen source;
- verify identity;
- recompile;
- rerun both static checks;
- rerun the process-ledger matrix in memory;
- rerun independent validator;
- validate actual self-test ledger independently;
- verify construct mode unexecuted;
- verify no semantic export exists.

Retain:

validation/frozen-construction-parent-requalification-v1.json

Require complete equality.

Do not edit frozen source.

──────────────────────────────────────────────────────────────────────────────
23. NO PACKAGE CONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not create any consumer-facing target-audit harness export or package
metadata.

The task ends with a qualified, frozen construction parent.

──────────────────────────────────────────────────────────────────────────────
24. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventory of every supplied root opened.

At minimum require the failed retry root to close exactly equal.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
25. QUALIFICATION-CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before manifests:

- bootstrap start;
- source designation;
- failed-root authentication;
- original source;
- source-sufficiency result;
- repaired source;
- exact delta;
- process contracts;
- executable registry and freeze;
- static checks;
- source freeze;
- self-test platform custody;
- complete child ledger;
- self-test result;
- mutation matrix;
- independent validator;
- cleanup;
- frozen-source requalification;
- supplied-root equality;
- final report;
- temporal inventory.

Then independently generate two byte-identical manifests.

Require:

- root represented;
- all retained directories and files represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink or special object;
- no multi-link file;
- modes 0700/0600;
- no cache or bytecode;
- independent reprojection exact;
- no write after closure.

──────────────────────────────────────────────────────────────────────────────
26. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY

only when every source, process, self-test, cleanup, freeze, requalification,
supplied-root equality, and capsule-closure gate passes.

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

when:

- candidate source is not sufficient;
- repair requires changing construction semantics;
- process custody cannot be closed;
- mode separation cannot be proved;
- dynamic effects cannot be attributed.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source identity mismatch;
- unauthorized source drift;
- pre-freeze execution;
- unregistered process;
- unpinned Python;
- missing flags;
- incomplete ledger;
- cleanup inequality;
- capsule closure failure;
- write after closure.

──────────────────────────────────────────────────────────────────────────────
27. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh qualification-root identity
3. External source-designation record
4. Historical failed-root identity
5. Candidate identity
6. Source-sufficiency result
7. Original source identity
8. Repaired source identity
9. Exact process-only delta
10. Mode split
11. Process-authority split
12. Executable-origin policy
13. Executable-origin registry
14. Registry-freeze identity
15. Pinned-Python contract
16. Child-process record contract
17. Filesystem-effect attribution
18. Self-test causal registry
19. Process-ledger matrix
20. Independent process validator
21. Static analysis A
22. Static analysis B
23. Frozen source identity
24. Source-freeze identity
25. Exact self-test invocation
26. Platform process custody
27. Complete child-ledger result
28. Self-test result
29. Cleanup equality
30. Frozen-source requalification
31. Construct-mode nonexecution
32. Semantic-export absence
33. Supplied-root closing equality
34. Qualification-capsule inventory/manifests
35. Remaining uncertainty/nonclaims
36. Explicit confirmations

Required confirmations:

FAILED_PROCESS_CLEAN_RETRY_ROOT_MUTATION_NOT_PERFORMED
FAILED_PROCESS_CLEAN_RETRY_ROOT_NOT_RESUMED
EXTERNAL_SOURCE_DESIGNATION_RETAINED
EXACT_DESIGNATED_CANDIDATE_AUTHENTICATED
HISTORICAL_EXECUTION_NOT_RETROACTIVELY_CLAIMED
ORIGINAL_PARENT_SOURCE_BYTES_PRESERVED
CANDIDATE_SOURCE_SUFFICIENCY_PASSED
REPAIR_BOUNDED_TO_PROCESS_ENVELOPE
CONSTRUCTION_SEMANTICS_UNCHANGED
EXPLICIT_SELF_TEST_AND_CONSTRUCT_MODES
CONSTRUCT_MODE_NOT_EXECUTED
TOP_LEVEL_PROCESS_AUTHORITY_SPLIT_FROZEN
EXECUTABLE_ORIGIN_POLICY_COMPLETE
EXECUTABLE_ORIGIN_REGISTRY_COMPLETE
EXECUTABLE_ORIGIN_REGISTRY_FROZEN_BEFORE_EXECUTION
NO_HISTORICAL_TOOLING_EXECUTED
NO_UNREGISTERED_EXECUTABLE_LAUNCHED
PINNED_PYTHON_IDENTITY_VERIFIED
ALL_PYTHON_CHILDREN_USED_LITERAL_I_S_B
CHILD_PROCESS_RECORD_SCHEMA_COMPLETE
PRELAUNCH_RECORD_CREATED_BEFORE_EVERY_SPAWN
SPAWN_FAILURE_CAUSAL_RECORDED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
CHILD_STREAMS_COMPLETE
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
FIXED_OUTPUT_EFFECTS_ATTRIBUTED
DYNAMIC_ROOT_EFFECTS_ATTRIBUTED
NONZERO_EXIT_EFFECTS_ATTRIBUTED
NO_BROAD_ROOT_DISCOVERY
PROCESS_LEDGER_MUTATION_MATRIX_PASSED
INDEPENDENT_PROCESS_VALIDATOR_PASSED
STATIC_PROCESS_CHECK_A_PASSED
STATIC_PROCESS_CHECK_B_PASSED
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PROCESS_SELF_TEST_MODE_EXECUTED
PROCESS_SELF_TEST_PASSED
PACKAGE_CONSTRUCTION_NOT_PERFORMED
NO_SEMANTIC_EXPORT_WRITTEN
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FROZEN_SOURCE_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_READY`, execute the exact frozen
source once in `--mode construct` under a separate authorization. Do not
regenerate or edit it.
```

## Decision

Proceed with explicit external source designation and forward qualification. Do not attempt to reconstruct or validate the missing historical invocation.

**Source:** Codex’s `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED` report in the current turn.  
**Confidence:** 1.00 that Codex correctly refused inference; 0.99 that explicit external designation removes the prerequisite without rewriting history; 0.94 that the candidate can be qualified through bounded process-envelope repair, subject to the source-sufficiency gate.
