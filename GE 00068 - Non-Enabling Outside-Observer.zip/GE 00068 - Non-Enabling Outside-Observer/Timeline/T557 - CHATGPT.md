## Engineering assessment

The external launch authority is now complete and qualified. No real subject audit has run, no subject verdict exists, and exactly one current audit authorization remains active and unconsumed. :chatgpt-content-reference{index="0"}

The successor authority closes the gaps that blocked the preceding launch:

- exact interpreter and isolation flags;
- exact audit argv;
- wrapper-owned fresh audit-root allocation;
- cwd equal to that root;
- exact five-row environment with no inheritance;
- `DEVNULL` stdin, no shell, no TTY, no detachment;
- exact platform-preflight markers and exit;
- authorization consumed only upon successful audit-parent creation;
- preserved terminal-frame contract. :chatgpt-content-reference{index="1"}

The predecessor certificate is now historical and contributes zero current authorizations. The successor profile and certificate provide exactly one active authorization rather than adding a second one. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

The launch-authority implementation itself qualified:

- all four builder/validator sources compiled and passed static analysis;
- the 76-case launch-authority matrix passed;
- the independent validator returned zero errors;
- the exact platform preflight passed and left its root empty;
- qualification mode passed without executing the real audit or issuing a subject verdict;
- deterministic profile and certificate builds matched;
- certificate-input validation passed;
- all nine supplied inputs closed equal. :chatgpt-content-reference{index="4"}

### Current authority-bearing launch artifacts

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json
```

- device/inode: `16777234 / 182723650`
- mode/link count: `0400 / 1`
- size: `9,131`
- SHA-256: `14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568`

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json
```

- device/inode: `16777234 / 182723661`
- mode/link count: `0400 / 1`
- size: `12,987`
- SHA-256: `f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f` :chatgpt-content-reference{index="5"}

## Progression decision

Execute exactly **one** real audit now.

No further launch-authority, audit-source, packaging, qualification, certificate, construction, or reconciliation work is justified beforehand.

The wrapper must use:

1. the unchanged audit PYZ;
2. the unchanged runtime authority;
3. successor launch profile v1;
4. successor launch certificate v2;
5. the unchanged replacement subject and construction chain;
6. the current content bundle and authority;
7. the accepted implementation authority chain.

It must not use predecessor certificate v1 as current authority. It must preserve the exact harness disposition and stop without promoting current schema authority.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE REAL INDEPENDENT AUDIT OF THE UNCHANGED
REPLACEMENT GENERATION-2 SCHEMA SUBJECT

USING THE CURRENT EXTERNAL LAUNCH PROFILE V1 AND
SUCCESSOR LAUNCH CERTIFICATE V2

Objective

Execute exactly one real independent audit of:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Use the exact current audit artifacts:

1. unchanged final audit PYZ;
2. unchanged runtime authority;
3. current external launch profile v1;
4. current successor launch certificate v2;
5. replacement subject;
6. replacement construction wrapper;
7. current content bundle;
8. current content authority;
9. accepted implementation authority chain.

The predecessor launch certificate v1 is historical, superseded, and
nonauthoritative for this launch.

Authenticate the current launch profile and successor certificate before
allocating an audit root or creating a process.

Execute the exact governed platform preflight.

Then execute the real audit parent exactly once under the exact launch profile.

Capture top-level process creation and completion exactly.

After completion:

- retain raw streams before parsing;
- parse only under the exact governed framing contract;
- authenticate the exact wrapper-supplied audit root;
- inspect the resulting capsule read-only;
- authenticate substantive audit evidence and terminal closure;
- preserve the exact harness disposition;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute qualification mode.

Do not launch a replacement, recovery, continuation, or second audit parent.

Do not run a direct subject auditor outside the frozen harness.

Do not execute subject source.

Do not rerun construction.

Do not promote or rebind current schema authority.

Do not combine audit and authority promotion.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

If any prelaunch gate fails before process creation, return:

AUDIT_PROVENANCE_MISMATCH

and explicitly state:

REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. UNCHANGED FINAL AUDIT PYZ
──────────────────────────────────────────────────────────────────────────────

FINAL_AUDIT_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz

Expected identity:

- device:
  16777234;
- inode:
  182699827;
- mode:
  0400;
- link count:
  1;
- size:
  4589679;
- SHA-256:
  00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0.

──────────────────────────────────────────────────────────────────────────────
2. UNCHANGED RUNTIME AUTHORITY
──────────────────────────────────────────────────────────────────────────────

FINAL_RUNTIME_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182699838;
- mode:
  0400;
- link count:
  1;
- size:
  56463;
- SHA-256:
  9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0.

──────────────────────────────────────────────────────────────────────────────
3. CURRENT EXTERNAL LAUNCH PROFILE
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_PROFILE:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182723650;
- mode:
  0400;
- link count:
  1;
- size:
  9131;
- SHA-256:
  14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT SUCCESSOR LAUNCH CERTIFICATE
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_CERTIFICATE_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json

Expected identity:

- device:
  16777234;
- inode:
  182723661;
- mode:
  0400;
- link count:
  1;
- size:
  12987;
- SHA-256:
  f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f.

──────────────────────────────────────────────────────────────────────────────
5. HISTORICAL PREDECESSOR CERTIFICATE
──────────────────────────────────────────────── LIMITED TO LINEAGE
────────────────────────────────────────────────

PREDECESSOR_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182699841;
- mode:
  0400;
- link count:
  1;
- size:
  3572;
- SHA-256:
  525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c.

Authenticate only:

- exact predecessor identity;
- predecessor schema;
- predecessor PYZ and authority bindings;
- predecessor unconsumed historical posture;
- successor supersession.

Require:

- predecessor current:
  false;
- predecessor active authorization count:
  0;
- predecessor may authorize this launch:
  false;
- predecessor mutation:
  forbidden.

Do not use predecessor execution controls.

──────────────────────────────────────────────────────────────────────────────
6. REPLACEMENT SUBJECT
──────────────────────────────────────────────── LIMITED TO AUDIT TARGET
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234;
- inode:
  182649818;
- mode:
  0700;
- UID/GID:
  501/20.

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files;
- root row exactly once;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory/file modes:
  0700/0600;
- no cache or bytecode.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051;
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4.

Expected manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16620 each;
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758.

Open only this exact root.

Do not scan for another subject.

──────────────────────────────────────────────── LIMITING CONSTRUCTION PROVENANCE
────────────────────────────────────────────────

7. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234;
- inode:
  182648782;
- mode:
  0700;
- UID/GID:
  501/0.

Authenticate only the chain necessary to establish:

- forward-treatment authority;
- semantic source-freeze resolution;
- accepted implementation chain;
- one-shot construction authorization and consumption;
- exact production-parent invocation;
- top-level process custody;
- exact subject locator;
- fresh allocation and nonadoption;
- producer terminal closure;
- pending-independent-audit posture;
- no second construction.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING ACCEPTED IMPLEMENTATION CHAIN
────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234;
- inode:
  182593190;
- mode:
  0700.

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234;
- inode:
  182593189;
- mode:
  0700.

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only:

- accepted reconstruction-parent implementation;
- accepted production source;
- accepted semantic source freeze;
- construction contract;
- unsuperseded implementation package;
- replacement construction used the accepted parent.

Do not re-audit the implementation package.

Require opening/closing equality.

────────────────────────────────────────────────

9. CURRENT CONTENT INPUTS

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234;
- inode:
  181651092;
- mode:
  0400;
- link count:
  1;
- size:
  13598758;
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671.

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234;
- inode:
  181651098;
- mode:
  0400;
- link count:
  1;
- size:
  19737;
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563.

Authenticate content authority before ZIP interpretation.

Require:

- exact archive identity;
- 479 members;
- eight roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive-validation evidence;
- no `.DS_Store`.

──────────────────────────────────────────────── LIMITING CURRENT EXTERNAL AUTHORITY
────────────────────────────────────────────────

10. STABLE PRELAUNCH AUTHENTICATION

Before allocating any fresh root, authenticate:

- final audit PYZ;
- runtime authority;
- current launch profile;
- successor certificate v2;
- historical predecessor certificate v1;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

For every file:

- open no-follow;
- require regular file;
- require governed mode and link count;
- retain device/inode/size/SHA-256;
- perform two stable reads;
- require byte and metadata equality.

For every root:

- require exact identity;
- retain a stable complete opening inventory when governed.

Strict-parse:

- runtime authority;
- launch profile;
- certificate v2;
- predecessor certificate;
- content authority;

using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any predicate fails:

- do not allocate wrapper or audit roots;
- do not run platform preflight;
- do not create the audit parent;
- return:
  AUDIT_PROVENANCE_MISMATCH;
- state:
  REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED;
- state:
  FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED.

────────────────────────────────────────────────

11. CURRENT LAUNCH-AUTHORITY CLOSURE

Validate the profile and successor certificate under their exact schemas.

Require exact correspondence among:

- profile;
- certificate v2;
- PYZ;
- runtime authority;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- source freeze;
- qualification evidence;
- 89-member PYZ registry;
- current stream/framing references.

Require:

- profile current:
  true;
- successor certificate current:
  true;
- predecessor certificate current:
  false;
- predecessor authorization count:
  0;
- successor authorization count:
  1;
- total active current authorization count:
  1;
- real audit already executed:
  false;
- subject verdict:
  not-issued;
- authority promotion:
  false.

Any discrepancy:

- do not launch;
- return provenance mismatch;
- authorization remains unconsumed.

────────────────────────────────────────────────

12. PYZ MEMBER AND GOVERNANCE CLOSURE

Parse the PYZ directly.

Require exact correspondence with the runtime authority, profile, certificate,
and embedded member registry.

Require:

- exactly 89 members;
- 88 non-self member rows;
- raw UTF-8 sorted names;
- ZIP_STORED;
- frozen timestamp;
- `create_system=3`;
- member mode 0600;
- no duplicate;
- no unsafe path;
- no directory member;
- no symlink/special member;
- no comments or uncontrolled extras;
- no cache or bytecode;
- no historical audit source.

Independently authenticate embedded roles for:

- executable entrypoint;
- source freeze;
- source registries;
- authoritative 15/14 model;
- complete 946 vocabulary;
- complete 137 vocabulary;
- total-checking contract;
- dual-oracle contract;
- occupancy vocabulary;
- confirmation contract;
- physical-closure/A15 contract;
- no-VCS contract;
- qualification matrices;
- synthetic rehearsal results;
- independent qualification;
- post-package qualification;
- frozen-package requalification;
- future invocation contract.

Any discrepancy:

- do not launch;
- return provenance mismatch.

────────────────────────────────────────────────

13. WRAPPER AND FRESH AUDIT ROOTS

After Sections 10–12 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Using:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-subject-real-audit-wrapper-`;
- umask:
  `077`.

Use it only for:

- prelaunch authentication evidence;
- profile/certificate validation;
- platform-preflight custody;
- audit-parent custody;
- raw streams;
- read-only capsule adjudication;
- fixed-input closing equality;
- final wrapper report.

B. FRESH_PRIVATE_AUDIT_ROOT

Using the exact current launch profile:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-schema-subject-real-audit-`;
- umask:
  `077`.

Immediately retain:

- absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty opening inventory.

Require:

- absolute path;
- directory;
- no symlink;
- mode 0700;
- empty before preflight;
- empty immediately before audit-parent creation.

Use this exact path as:

- the `<FRESH_PRIVATE_AUDIT_ROOT>` argv substitution;
- submitted cwd.

Do not scan or adopt a preexisting root.

On prelaunch failure:

- retain evidence;
- remove only wrapper-owned empty roots;
- observe ENOENT twice;
- authorization remains unconsumed.

After audit-parent creation:

- authorization is consumed;
- preserve the audit root unchanged regardless of outcome.

────────────────────────────────────────────────

14. PLATFORM-CAPTURE PREFLIGHT

Run exactly once using the current profile:

```text
/usr/local/bin/python3.13
-I
-S
-B
-c
import os;os.write(1,b"PLATFORM_CAPTURE_STDOUT_V1\n");os.write(2,b"PLATFORM_CAPTURE_STDERR_V1\n");os._exit(23)
```

Submitted cwd:

the exact fresh audit root.

Submitted environment exactly, with no inherited environment:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

Process posture:

- stdin:
  DEVNULL;
- shell:
  false;
- TTY:
  false;
- detachment:
  false;
- foreground:
  true;
- synchronous:
  true.

Retain:

- requested interpreter symlink identity;
- resolved executable identity;
- argv;
- cwd;
- environment;
- PID;
- timing;
- streams;
- hashes;
- exit/signal;
- reaping;
- descriptor closure.

Require:

- stdout exact bytes:
  `PLATFORM_CAPTURE_STDOUT_V1\n`;
- stdout size:
  27;
- stdout SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2;
- stderr exact bytes:
  `PLATFORM_CAPTURE_STDERR_V1\n`;
- stderr size:
  27;
- stderr SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5;
- exit:
  23;
- signal:
  null;
- no file;
- no child;
- audit root still empty.

If preflight fails:

- do not create the audit parent;
- authorization remains unconsumed;
- clean only wrapper-owned empty roots after evidence retention;
- return provenance mismatch;
- do not retry.

────────────────────────────────────────────────

15. EXACT REAL-AUDIT INVOCATION

After preflight passes, require exactly:

```text
/usr/local/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz
--mode
audit
--runtime-authority
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json
--subject-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
--construction-wrapper
/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a
--content-bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--accepted-implementation-audit
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04
--accepted-implementation-wrapper
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg
--output-root
<FRESH_PRIVATE_AUDIT_ROOT>
```

Do not pass the launch profile or launch certificate to the harness.

Do not add or omit an operand.

Submitted cwd:

the exact fresh audit root.

Submitted environment exactly:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

No inherited environment.

Process posture:

- stdin:
  DEVNULL;
- shell:
  false;
- TTY:
  false;
- detachment:
  false;
- foreground:
  true;
- synchronous:
  true.

Immediately before process creation:

- reauthenticate all fixed inputs;
- reauthenticate the fresh audit-root identity;
- require the audit root still empty.

Launch exactly once.

The authorization is consumed only when process creation succeeds.

After creation, it remains consumed regardless of outcome.

Do not launch:

- qualification mode;
- replacement parent;
- recovery parent;
- continuation;
- direct auditor;
- post-failure validator;
- second audit.

────────────────────────────────────────────────

16. TOP-LEVEL PROCESS CUSTODY

Retain before parsing streams:

- custody ID;
- creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- cwd;
- environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- sizes and SHA-256;
- exit;
- signal;
- process error;
- reaping;
- descriptor closure;
- identities of fixed inputs at launch;
- fresh audit-root identity at launch.

The wrapper is authoritative for top-level process creation and completion.

If completion custody is missing after process creation:

- authorization remains consumed;
- do not scan for another root;
- do not retry;
- preserve the supplied audit root;
- return provenance mismatch.

────────────────────────────────────────────────

17. STREAM AND TERMINAL-FRAME PARSING

Retain raw streams before parsing.

For a handled terminal result require:

- stdout consists of exactly one strict UTF-8 JSON object plus one LF;
- stderr is empty;
- no duplicate frame;
- no trailing bytes;
- duplicate keys rejected;
- nonfinite numbers rejected;
- exact frame schema:
  `clean-audit-harness.synthetic-terminal-frame.v1`;
- exact fields:
  `capsule_root`,
  `closure_pass`,
  `disposition`,
  `scenario`,
  `schema`.

Validate `scenario` and each field under the exact runtime authority and
certificate-bound framing contract.

Require:

- `capsule_root` equals the wrapper-supplied fresh audit root;
- `closure_pass` is true before promoting ACCEPT or BLOCK;
- `disposition` is exactly one governed terminal disposition.

If the process exits under an unhandled-failure posture:

- return provenance mismatch;
- do not scan for another root;
- preserve the supplied root;
- do not retry.

────────────────────────────────────────────────

18. READ-ONLY CAPSULE INSPECTION

Inspect only the exact supplied audit root.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute subject source;
- launch another validator;
- regenerate evidence;
- add or replace any record.

Resolve authoritative records only through:

- terminal frame;
- capsule role/path registry;
- capsule indexes;
- manifests;
- exact evidence pointers.

Authenticate at minimum:

- audit source identities and freeze;
- no-Git/VCS posture;
- exact 15/14 model;
- complete 946/137 outcome vocabularies;
- subject terminal closure;
- normative contract;
- current schemas and families;
- Draft 2020-12 results;
- witness rows;
- complete 946 rows;
- complete 137 rows;
- dual-oracle crosswalk;
- 766/333 field map;
- documentary-validator authority;
- confirmation derivation;
- occupancy, lineage, and producer status;
- findings and repair owners;
- A00–A15 phase records;
- child custody;
- cleanup;
- supplied-root equality;
- temporal inventory;
- manifests;
- final reprojection;
- physical topology;
- A15/closure agreement;
- one seal transition;
- no postseal operation.

────────────────────────────────────────────────

19. DIRECT SUBJECT-BLOCKER EVIDENCE STANDARD

A terminal:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

is authoritative only when every direct blocker contains:

- exact failed witness or case row;
- non-null direct evidence;
- exact governing contract/schema/specification pointer;
- primary repair owner;
- exact repair surface;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is allowed.

For a 946- or 137-suite blocker, require exact failed per-case rows.

An aggregate count without the rows is invalid evidence.

Derivative confirmation failures are not independent blockers.

Any:

- evaluator exception;
- dual-oracle disagreement;
- invalid outcome-vocabulary projection;
- incomplete direct evidence;
- hard-coded confirmation;
- occupancy-role defect;
- audit cleanup failure;
- terminal-capsule failure;

forces:

AUDIT_PROVENANCE_MISMATCH

not subject BLOCK.

────────────────────────────────────────────────

20. AUDIT-CAPSULE TERMINAL CLOSURE

Authenticate:

- closeout temporal inventory;
- manifest A;
- manifest B;
- A/B byte equality;
- independent final reprojection;
- root row exactly once;
- no physical empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- directory/file modes 0700/0600;
- no cache or bytecode;
- A15 status equals final closure result;
- one seal transition;
- no filesystem/process/validation operation after seal.

A terminal frame alone does not substitute for capsule closure.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

and prevents promotion of an embedded ACCEPT or BLOCK.

────────────────────────────────────────────────

21. WRAPPER FIXED-INPUT CLOSING EQUALITY

After process completion, repeat opening/closing authentication for:

- final audit PYZ;
- runtime authority;
- current launch profile;
- successor certificate v2;
- predecessor certificate v1;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Require:

- exact fixed-role set;
- one row per role;
- no missing or extra row;
- every row passes.

Do not mutate any supplied input.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

────────────────────────────────────────────────

22. FINAL VERDICT RULES

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- all prelaunch inputs authenticate;
- current launch authority closes;
- platform preflight passes;
- parent process custody completes;
- frame parsing passes;
- capsule provenance passes;
- subject terminal closure passes;
- exact 15/14 model passes;
- all schemas pass Draft 2020-12;
- all witnesses pass;
- all 946 rows pass;
- all 137 rows pass;
- dual oracles agree;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy, lineage, and producer status close;
- no direct subject blocker remains;
- audit cleanup and supplied-root equality pass;
- audit capsule terminal closure passes;
- wrapper fixed-input equality passes.

Scope:

- accepts this exact replacement subject;
- does not promote or rebind current authority;
- does not establish product/runtime readiness;
- does not authorize target audit, publication, deployment, or A6.

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- at least one direct subject blocker exists;
- every blocker satisfies Section 19;
- findings and dependencies are complete;
- cleanup, equality, and terminal closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input or launch-authority mismatch;
- process-custody loss;
- framing or root failure;
- subject drift;
- source/toolchain/freeze failure;
- oracle exception or disagreement;
- invalid governed outcome;
- incomplete direct evidence;
- hard-coded confirmations;
- occupancy-role defect;
- cleanup inequality;
- supplied-root inequality;
- capsule closure failure;
- A15/closure contradiction;
- postseal activity;
- wrapper closing-equality failure.

Do not retry.

────────────────────────────────────────────────

23. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all launch artifacts;
- preserve the replacement subject unchanged;
- preserve the construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve the audit capsule;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product or live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

24. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Final PYZ identity
3. Runtime-authority identity
4. Current launch-profile identity
5. Current successor-certificate identity
6. Historical predecessor-certificate disposition
7. Replacement-subject identity
8. Construction-wrapper authentication
9. Accepted implementation-chain authentication
10. Content identities
11. Stable prelaunch authentication
12. Current launch-authority closure
13. PYZ member/governance closure
14. Wrapper-root identity
15. Fresh audit-root identity
16. Platform preflight
17. Exact real-audit argv
18. Exact cwd/environment/process posture
19. Top-level process custody
20. Raw streams
21. Exit/signal
22. Terminal-frame result
23. Audit-root authentication
24. Audit-source/freeze/no-Git posture
25. Subject terminal closure
26. Normative contract
27. Fifteen schema roles
28. Fourteen generated families
29. Role/family mapping
30. Draft 2020-12 result
31. Contract-witness rows
32. Schema-witness rows
33. Witness aggregate
34. Complete 946 result
35. Exact failed 946 rows, if any
36. Complete 137 result
37. Exact failed 137 rows, if any
38. Dual-oracle crosswalk
39. 766/333 field map
40. Documentary-validator closure
41. Confirmation derivation
42. Derivative-confirmation ledger
43. Occupancy, lineage, and producer status
44. Findings
45. Repair-owner registry
46. Dependency graph
47. A00–A15
48. Child custody
49. Audit cleanup
50. Capsule supplied-root equality
51. Wrapper fixed-input equality
52. Audit temporal identity
53. Audit manifest identities
54. A/B equality
55. Final reprojection
56. Physical topology/modes
57. A15/closure agreement
58. Seal/no-postseal result
59. Confirmation subject unchanged
60. Confirmation no authority promotion
61. Confirmation no product/runtime/target/A6 activity
62. Remaining uncertainty/nonclaims
63. Explicit wrapper confirmations

Required confirmations:

FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
CURRENT_LAUNCH_PROFILE_IDENTITY_MATCHED
CURRENT_SUCCESSOR_CERTIFICATE_IDENTITY_MATCHED
PREDECESSOR_LAUNCH_CERTIFICATE_IDENTITY_MATCHED
PREDECESSOR_CERTIFICATE_NOT_CURRENT
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
CURRENT_LAUNCH_AUTHORITY_CURRENT_AND_COHERENT
AUDIT_PYZ_MEMBER_SET_89_CLOSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_SUPPLIED_ROOT
CLEAN_AUDIT_SOURCE_FREEZE_AUTHENTICATED
NO_GIT_OR_VCS_INVOCATION
SUBJECT_TERMINAL_REPROJECTION_PASSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

## Source and confidence

The attached report establishes complete launch-profile and successor-certificate authority, exact execution controls, preflight qualification, deterministic output equality, independent validation, predecessor supersession, and one active unconsumed audit authorization. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

**Provenance confidence:** 0.999  
**Launch-readiness confidence:** 0.999  
**One-audit authorization confidence:** 0.999  
**Subject acceptance confidence before audit:** 0.00

The latest attachment was fully readable. Some earlier uploaded artifacts have expired; re-upload one only when a future review needs its original bytes rather than the retained reports and identities.
