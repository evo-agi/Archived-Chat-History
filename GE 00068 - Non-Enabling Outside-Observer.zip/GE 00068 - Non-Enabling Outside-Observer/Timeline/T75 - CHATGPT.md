This is **not a new A5T source defect**. It is a validation-construction defect introduced by the previous gate: the requirement to use “intentionally long outer control roots” is incompatible with the same gate’s absolute 100-byte Unix-socket limit.

`ShortDir` behaved correctly. It rejected a prospective 101-byte path before `net.Listen`. The repair should **not**:

- weaken or raise the 100-byte boundary;
- modify the two repository test files again;
- modify A5P2;
- place the positive controls under a deliberately overlong root;
- canonicalize or ignore the failure.

The correct separation is:

- **Qualifying controls:** use short, exclusive physical roots whose worst-case socket paths are proven ≤100 bytes before launch.
- **Boundary causals:** separately prove that exactly 100 bytes is admitted and 101 bytes is rejected.
- **Failed A5T2 child:** retain as nonqualifying evidence that the validation root itself exceeded the supported path budget.

This is also a case where the proof harness must not silently redefine the product or test contract: the MVP freeze explicitly warns against implementation work widening around whatever the current proof harness happens to do. 

No further reconnaissance is needed. Start a fresh **A5T3** validation child with corrected control-root construction.

```text
Permission is workspace-write for a new source-external evidence child only.

Objective

Freshly validate, close out, and seal the already implemented Repair 10I-A5T
repository test-fixture repair using the sealed Repair 10I-A5P2 successor.

The preceding A5T2 attempt failed because its validation control root made the
minimum prospective Unix-socket path 101 bytes while the governing limit is
100 bytes.

That failure is classified as:

REPAIR10I-A5T2-VALIDATION-CONTROL-ROOT-BUDGET-001

Type:
validation-construction defect

It is not:

- a repository source defect;
- a failure of `ControlRoot.ShortDir`;
- a reason to widen the 100-byte socket-path limit;
- a reason to modify A5P2;
- permission to normalize the resulting error.

Use short, exclusive physical execution roots whose worst-case socket paths
are proven at or below 100 bytes before command launch. Exercise the 100/101
boundary separately through dedicated causal controls.

Do not edit any repository file.
Do not edit A5P2.
Do not resume, overwrite, seal, or promote the failed A5T or A5T2 children.
Do not implement A5C.
Do not restart the A6 policy-evidence refresh.
Do not implement A6 or start B6.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole evidence writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 product predecessor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5P2 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p2-successor-closure-ab646e5a0e66

Failed old A5T child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t-test-fixture-closure-e260e1bb5ac4

Failed A5T2 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t2-test-fixture-closure-ab646e5a0e66

Failed A6 policy-evidence refresh, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required new A5T3 validation child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t3-test-fixture-closure-ab646e5a0e66

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- inventory size:
  54314
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the complete repository delta from sealed A5 to remain exactly these
two existing files:

1.
remote_alpha_operator_test.go

- logical mode:
  100644
- size:
  333580
- SHA-256:
  f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578

2.
es/runtimehelper/supervisor_test.go

- logical mode:
  100644
- size:
  5293
- SHA-256:
  842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226

Require:

- zero additions;
- zero deletions;
- zero renames;
- zero mode changes;
- every other 387 repository tuple byte- and mode-identical to sealed A5.

Require exact sealed A5:

- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact sealed A5P2:

- manifest SHA-256:
  67002939082d25a46ec50fdb4a5725e936816ea930e6ed9ac684608238a833a4
- manifest size:
  114860
- payloads:
  613
- directories:
  112
- source T:
  ff7a4688b1244277eccc8eee26b57eb4f0858d01
- source inventory:
  a17d8e3d5925b17d2eda187a51953dcf0d171d81d5e5409ea70827d92a6cda2e
- members:
  12

A5P2 binaries:

repair10-runner:
  153013c19a717a37a677c0c5fa4e91837c78ccc16db909a9b1e360ff2efb483d

repair10-compare:
  d09e0e0d510872fb457f1308219f471bcbd147c7fc6d4a19da29a026182055a3

repair10-semantic:
  25893d292a20e0af99e494779802dbd73c1fe1e180f3c9e2873c5ea52e86d325

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the A5P2 complete post-seal verification and active v3/v2/v1 dialect
to reproduce exactly.

Require the failed A5T and A5T2 children to remain:

- present;
- unsealed;
- without manifests or detached digests;
- byte-exact from opening through closing.

For A5T2, bind and retain:

- mandatory-stop classification:
  validation-control-root path-budget mismatch;
- control:
  a5t2-targeted-one-v3;
- minimum prospective socket path:
  101 bytes;
- maximum admitted:
  100 bytes;
- four root tests failed three times each during short-directory allocation;
- listener setup not reached;
- PTY requests consumed:
  0 of 12;
- complete cleanup and two absence epochs.

Require the failed A6 refresh and all sealed/unsealed predecessor lineage to
remain exact.

Require the A5T3 target to be absent.

Stop on any mismatch:

REPAIR10I_A5T3_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create A5T3 exclusively under umask 077.

Use exactly:

opening/
tool/
commands/
controls/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, with intended mode 0600 or 0700.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy the sealed A5P2 A and B binaries independently into private tool roots.

Require:

- origin-to-copy byte equality;
- side-A/side-B byte equality;
- copied binary inodes all distinct;
- link count one;
- expected modes;
- no shared writable tool state.

No repository file may be edited.

## 3. A5P2 input hard gate

Before any repository command:

1. Verify all 12 A5P2 source members.
2. Verify the exact five-file A5S→A5P2 delta.
3. Verify all four binary identities.
4. Reopen and verify:
   - live `LOCAL_PEERPID` preflight;
   - openpty acknowledged handoff;
   - forkpty post-login-tty acknowledgment;
   - retained-parent-slave negative;
   - repaired EOF causal;
   - early-close mutant;
   - retained-alias mutant;
   - duplicate-child-alias rejection;
   - `/dev/ptmx` denial;
   - unrelated-terminal denial;
   - external requalification;
   - cleanup and two absence epochs.
5. Require:
   - runner slave closes exactly once;
   - runner master closes exactly once;
   - both close before acceptance and process wait;
   - no close retry;
   - no raw terminal payload retained.
6. Require old A5S and failed-A5P active-schema records to remain
   nonqualifying on A5P2 paths.

Stop on mismatch:

REPAIR10I_A5T3_SUCCESSOR_INPUT_MISMATCH

## 4. Corrected execution-root path-budget contract

Withdraw the failed A5T2 requirement that qualifying controls use
intentionally overlong outer roots.

The evidence child and the execution roots are distinct surfaces:

- evidence stays beneath the A5T3 evidence child;
- each execution control uses a short, exclusive physical root directly under
  `/private/tmp`;
- every execution root is mode 0700, same effective UID/GID, no-follow
  resolved, and inode-bound;
- every write performed by the controlled command remains beneath that
  execution root or another exact A5P2-admitted input/output surface.

Before launching any command:

1. Inspect the exact current `ControlRoot` and `ShortDir` implementation.
2. Compute the worst-case complete Unix-socket path length using:
   - the actual physical control-root path;
   - the exact compact-directory label;
   - the maximum suffix width admitted by the implementation;
   - every separator;
   - the exact fixed socket basename or tail.
3. Compute this separately for:
   - the remote fake-SPIRE `api.sock` role;
   - the runtimehelper source `api.sock` role;
   - every A5P2 broker socket involved in the command.
4. Require every prospective path to be at most 100 bytes.
5. Record:
   - control-root bytes and length;
   - fixed suffix/tail bytes and length;
   - nonce-width assumption;
   - computed maximum;
   - actual created path and length after allocation.
6. Abort before command launch on any prospective length above 100.

Use compact control-root and internal directory names.

Do not locate positive controls underneath the long evidence-child pathname.

Do not shorten paths adaptively after a command begins.

Do not raise the 100-byte limit.

## 5. Dedicated 100/101 boundary controls

Prove the hard boundary separately from qualifying repository controls.

Require:

### Exactly 100 bytes

- a complete test-owned Unix-socket path of exactly 100 bytes;
- accepted by the path-budget preflight;
- `net.Listen("unix", ...)` succeeds;
- listener closes;
- path is removed;
- rebind succeeds only after close/removal;
- cleanup and two absence observations pass.

### Exactly 101 bytes

- a complete prospective path of exactly 101 bytes;
- rejected before `net.Listen`;
- no socket node is created;
- no listener exists;
- no cleanup uncertainty remains.

Also prove:

- path calculation counts bytes, not Unicode code points;
- the fixed `api.sock` basename remains material;
- no generic long-path normalization or truncation occurs;
- wrong root, basename, endpoint role, or topology remains visible.

The failed A5T2 101-byte result is predecessor corroboration only. The new
boundary controls must run freshly.

## 6. Source-line and semantic compatibility

Before repository commands, inspect the final two-file A5T patch against exact
A5P2 semantic grammars.

Retain:

- every exact line-bound template referring to either changed file;
- current package, test/subtest, path, and line;
- whether the A5T patch shifted it;
- whether the diagnostic remains reachable;
- whether it still matches exactly.

Require:

- every relevant active template remains valid; or
- an old fixture-failure template is now unreachable because the intended
  test path succeeds.

No generic line normalization.

Stop on a new unknown or active incompatibility:

REPAIR10I_A5T3_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

## 7. Test discovery and exact identities

Require pinned-Go discovery to list exactly once:

1.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand

2.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection

3.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure

4.
execution-substrate /
TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution

5.
execution-substrate/es/runtimehelper /
TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir

Required test-level skips: zero.

## 8. Exact PTY-policy derivation

Before each PTY-capable command, derive and retain a finite request inventory
from:

- exact test discovery;
- repository helper call graph;
- sealed A5P2 bounded-integration evidence.

Record:

- command ID;
- selected test identities;
- PTY role and exact count;
- max_total_pairs;
- controlling-terminal requirement;
- descriptor mapping;
- stream mode;
- source evidence supporting each request.

No adaptive count widening.

No inference from command name, package, test name, argv, source class, or
environment.

Every non-PTY command must omit the capability.

Any undeclared runtime request blocks the control.

## 9. Three disjoint qualifying controls

Create three physically independent short execution roots.

Each independently owns:

- no-hardlink source copy;
- private Git administration/object store where required;
- HOME and XDG roots;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- runtime root;
- command and evidence staging roots;
- broker sockets and PTY resources.

No mutable state may be shared.

Run in every control:

### Root/operator tests

go test -json -count=3 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure)$'

Use the exact explicit A5P2 PTY policy.

### Runtimehelper test

go test -json -count=3 -p=1 -parallel=1 ./es/runtimehelper \
  -run '^TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir$'

Do not grant PTY capability to runtimehelper unless source inspection proves a
request.

Require across the three controls:

- 45 total passing test executions;
- zero skips;
- complete JSONL and terminals;
- every prospective and actual socket path at most 100 bytes;
- listener setup succeeds;
- old socket EINVAL diagnostics absent;
- all five intended assertions reached;
- root/operator PTY acknowledgment succeeds;
- parent master/slave aliases close before process wait;
- actual helper EOF/EIO reconciles;
- direct child PTY allocation remains denied;
- unrelated terminals remain inaccessible;
- complete PTY and ordinary resource reconciliation;
- two absence epochs per control;
- opposite A5P2-side external qualification succeeds.

## 10. No-capability negative

Run the four root/operator tests once in an otherwise equivalent short private
control with no PTY capability.

Require:

- path-budget preflight passes;
- repaired listener setup succeeds;
- paths are at most 100 bytes;
- all four tests fail at the expected default-denied PTY boundary;
- zero PTY descriptors are acquired by the command;
- `/dev/ptmx` remains denied;
- terminal/resource reconciliation completes;
- no survivor or residue.

This negative does not contribute to readiness beyond default-denial proof.

## 11. Isolation, path, and socket negatives

Run and require pass:

go test -json -count=1 -p=1 -parallel=1 ./internal/testsupport

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRepair10ControlRootPolicyV1|TestRepair10ValidationIsolationASTV1|TestRepair10ExplicitStartInventoryV1)$'

Freshly prove or retain exact active controls for:

- 100-byte acceptance;
- 101-byte pre-listen rejection;
- physical socket under owned compact root;
- no shared `/tmp` mutation root;
- no unmanaged listener;
- no raw `Cmd.Start`;
- logical path remains:
  `/run/spire/server/private/api.sock`;
- no fixed runtime slot or PackageFloor access;
- cleanup errors fail the test.

Require visible fail-closed behavior for:

- wrong socket basename;
- wrong endpoint role;
- wrong root role;
- wrong logical prefix;
- wrong topology;
- wrong address family where supported;
- missing compact parent;
- source is directory;
- source is regular file;
- live-socket collision;
- rebind before close/removal;
- missing socket;
- multiple source sockets.

Valid rebind succeeds only after complete close and removal.

Do not canonicalize these failures.

## 12. Race controls

Using the pinned race toolchain and A5P2 race-only read policy, run:

go test -race -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution|TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure)$'

with exact explicit PTY policy.

Also run:

go test -race -json -count=1 -p=1 -parallel=1 ./es/runtimehelper \
  -run '^TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir$'

Require:

- all five pass;
- zero test skips;
- zero race reports;
- zero survivors;
- zero forced cleanup;
- complete PTY and ordinary resource reconciliation;
- two absence epochs.

## 13. Static and repository gates

Run:

- pinned `gofmt -d` on exactly the two changed files; require empty output;
- `git diff --check`;
- `/bin/bash -n` on protected public scripts;
- `go mod verify` from a complete private offline cache;
- `go vet ./...`.

Require all pass.

Do not run a general formatting sweep.

## 14. Broader affected validation

Run through A5P2 with explicit PTY capability only where source inspection
requires it:

1. Complete `./es/runtimehelper`.
2. A source-grounded root/operator family containing:
   - all four repaired remote tests;
   - adjacent Vault/bootstrap recovery tests;
   - PTY/forkpty signal and ordering tests;
   - Repair 10I setpgid tests;
   - operator facade signal test;
   - structural isolation guards.

Retain the exact `-run` expression.

Require:

- repaired tests pass;
- no required skip;
- no unknown diagnostic;
- no exact-line incompatibility;
- no undeclared PTY role/count;
- inherited unrelated failures remain explicit if present.

## 15. Complete private full-suite control

Create one fresh, short, private control bound to:

- T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership:
  389

Before launch, retain:

- active test inventory;
- exact PTY-capable helper call graph;
- finite role/count declaration;
- proof no non-PTY command receives implicit capability;
- prospective path-budget report for every declared socket/broker role.

Run literal:

go test -json -count=1 -p=1 -parallel=1 ./...

through one A5P2 side.

Use the opposite side for raw re-extraction and qualification.

Expected process exit membership:

{0,1}

Exit alone does not qualify.

Require:

- containment enforced;
- complete raw streams through EOF;
- exactly one Wait;
- complete terminal/resource reconciliation;
- no forced cleanup;
- no survivor;
- well-formed complete JSONL;
- semantic integrity pass;
- zero unknown diagnostics;
- producer/peer canonical semantics byte-equal;
- producer/peer qualification both `qualified`;
- logical and PTY fingerprints bound;
- every declared PTY request consumed exactly;
- no undeclared PTY request;
- direct `/dev/ptmx` denied;
- unrelated terminal inaccessible;
- parent aliases close before process wait;
- actual helper EOF/EIO reconciles;
- every prospective/actual socket path at most 100 bytes;
- two cleanup epochs;
- verified-empty next-command barrier.

The five repaired tests must pass.

The seven previously required A5 identities must preserve their expected
outcomes:

- TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
  one_pipe_closes_first
- TestRepair10IDualSetpgidRaceReconciliationV1
- TestRepair10ISetpgidFailureRequiresExactGroupProofV1
- TestRepair10ISetpgidInverseMutantsV1
- TestRepair10IStructuralPrivacyProjectionCausalControlsV1
- TestRemoteAlphaExternalTLST2APRepair10Contract
- TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2

Require the five old socket-EINVAL diagnostics to be absent.

Inherited unrelated failures and skips remain explicit. Do not claim a green
suite unless it is green.

This one full-suite control is implementation validation only.

Do not derive A6 policy from it.

## 16. Evidence and closeout

Retain:

- opening and lineage verification;
- failed A5T2 root-budget record;
- A5P2 input hard gate;
- source-line compatibility;
- exact path-budget calculations;
- 100/101 boundary causals;
- PTY request inventories;
- every source inventory/T;
- suite specs and command intents;
- argv/cwd/environments;
- rendered profiles and effective policies;
- raw streams through EOF;
- command and terminal records;
- PTY journals and owner dispositions;
- peer qualifications;
- socket-length and listener-success records;
- negative/race/broader/full-suite evidence;
- failed/superseded attempts;
- closing source/admin verification;
- cleanup and two absence epochs;
- implementation-validation report;
- exact path/mode/size/hash inventory.

Do not retain raw terminal payload.

At closeout require:

- repository T/inventory/membership unchanged;
- exact two-file delta unchanged;
- all other 387 source tuples unchanged;
- branch/HEAD/parent/tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged zero;
- A5, A5S, A5P reconnaissance, A5P2, failed A5P, failed A5T, failed A5T2,
  failed A6, and every predecessor unchanged;
- no predecessor cache or bytecode;
- no private source, Git store, Go cache, runtime, PTY, process/group, worker,
  broker socket, listener, descriptor, build, or report root;
- two fresh zero-observation epochs.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 17. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- repository byte change;
- need for a third repository file;
- need for A5P2 source change;
- source-line compatibility expansion;
- positive control prospective path above 100 bytes;
- repaired test fails before its intended assertion;
- listener setup failure;
- actual socket path above 100 bytes;
- PTY role/count mismatch;
- implicit PTY capability;
- direct PTY allocation succeeds;
- unrelated terminal accessible;
- parent alias retained after acknowledgment;
- missing real EOF/EIO;
- raw PTY payload retained;
- required skip;
- race;
- unknown diagnostic;
- malformed/incomplete stream;
- incomplete terminal/resource reconciliation;
- survivor or forced cleanup;
- external full-suite qualification failure;
- cleanup or sealing failure.

## 18. Verdicts

Opening mismatch:

REPAIR10I_A5T3_BASELINE_MISMATCH

A5P2 input mismatch:

REPAIR10I_A5T3_SUCCESSOR_INPUT_MISMATCH

Successor/source-line expansion required:

REPAIR10I_A5T3_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

Repository test or validation repair required:

REPAIR10I_A5T3_SOURCE_OR_TEST_REPAIR_REQUIRED

Complete validation and seal:

REPAIR10I_A5T_SOCKET_FIXTURE_REPAIR_SEALED_READY_FOR_A5C

The success report must include:

1. Opening and closing T/inventory.
2. Exact two-file delta.
3. A5P2 manifest, source, and binary identities.
4. Failed A5T2 101-byte classification.
5. Exact qualifying-control root-budget calculations.
6. Fresh 100-byte and 101-byte causal outcomes.
7. Old and new actual socket lengths.
8. Proof all five tests reached intended assertions.
9. Three-control/count-three results.
10. Race results.
11. Boundary and socket-negative results.
12. PTY role/count, ownership, EOF, and cleanup results.
13. Full-suite raw/semantic identities.
14. Producer and peer qualification.
15. Five repaired-test outcomes in the full suite.
16. Confirmation old socket-EINVAL diagnostics disappeared.
17. Inherited failures and skips.
18. Manifest SHA-256, size, and payload count.
19. Cleanup and two absence epochs.
20. Explicit statement that A5C was not started and A6 was not restarted.

No A5C.
No A6.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The failed A5T2 run remains useful: it proved that the 100-byte guard is real and fail-closed. It simply cannot be the positive qualification control.

### Sources

- Codex’s `REPAIR10I_A5T2_SOURCE_OR_TEST_REPAIR_REQUIRED` report supplied in this turn.
- The project’s Milestone 0 freeze, which prevents proof-harness behavior from silently widening product claims. 
- Sealed A2’s explicit statement that a bounded tool causal does not replace the required fresh downstream control. 
- Governed Execution’s implementation/audit separation and repair lifecycle.  
- Provenance establishes byte identity, not correctness or validation sufficiency. 

**Confidence:** 0.999 that A5T2 correctly stopped; 0.995 that the failure was caused by the validation control-root budget rather than repository or A5P2 bytes; 0.98 that short `/private/tmp` execution roots plus separate 100/101 causals are the correct correction; 0.96 that the unchanged two-file A5T patch should now complete its full validation gate.
