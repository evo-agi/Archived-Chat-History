## Assessment

This is a narrow, well-grounded **BLOCK**. The audit accepted the provenance, current trusted-host contract, source-external caller, unchanged verifier, host posture, 89-test suite, targeted causals, and real/synthetic compatibility. The only repository-patch blocker is **CT-01**: test 89 proves the presence of isolated phrases, but not the coherence of the complete contract, so contradictory text could be added while the test remained green.   

No verifier or caller repair is indicated. The audit expressly found the current governing text coherent, the trusted-host premise appropriately bounded for supported-local proof, and no conflicting atomic-custody claim. It also confirmed that verifier source stayed unchanged and that the caller/verifier security causals and compatibility runs passed.   

The separate **AP-06** finding is audit orchestration, not a repository defect. The audit delivered all four subject perspectives but only three distinct subagent instances because the fourth concurrent spawn hit the platform limit. That should be corrected in the next audit by running three auditors concurrently and a fourth distinct security auditor sequentially after one slot closes—not by changing repository bytes.  The project protocol supports three auditors by default, a fourth when security is material, at most one retry, and preservation of missing coverage rather than silent parent substitution.  

### Recommended repair

Use one authoritative, machine-readable trusted-host contract in `evidence_verification.md`, with the other governing documents acting as explicit non-overriding references. Rewrite test 89 to parse and validate the complete contract and exercise contradictory mutations. Do not continue adding prose substrings.

This follows the one-authoritative-writer rule and keeps the proof tooling within its bounded role. The MVP freeze explicitly says documentation and proof surfaces must not promote proof-harness behavior into architecture or authority.  Provenance will bind the new bytes to the next audit, but it will not establish correctness by itself. 

## Codex prompt: CT-01 trusted-host contract-test repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete implementation report inline in
Markdown.

Do not respond with only:

- a verdict;
- a summary;
- a link to a report;
- “full report available at …”;
- or an attachment reference.

A source-external report may be linked as supplemental evidence, but every
required report section must also appear inline.

This requirement applies to every outcome:

- implemented and ready for audit;
- baseline mismatch;
- scope expansion;
- validation block;
- provenance block;
- process-boundary block.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh, parent-only workspace-write Codex conversation.

Do not resume the independent audit conversation.

Do not spawn subagents. You are the sole writer.

Objective

Repair the single blocking repository finding CT-01 from the trusted-host-
boundary independent audit.

CT-01 states:

- the current governing documents are coherent;
- the verifier and source-external caller have no demonstrated defect;
- test 89 checks isolated phrases with `assertIn`;
- contradictory contract prose could coexist with every required phrase while
  test 89 still passed;
- the regression guard must validate complete relevant clauses or a structured
  contract representation and must include contradictory negative cases.

Implement a contradiction-resistant documentation contract and test.

Do not change the verifier.
Do not change launch protocol v2.
Do not change the source-external caller.
Do not reopen interpreter custody.
Do not change the accepted trusted-host threat model.
Do not repair the audit-process finding AP-06 in repository source.

No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

## 1. Repository and exact opening target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Current canonical manifest:

OPENING_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/provenance/run-1/provenance/manifest-run-1.json

Expected opening manifest SHA-256:

2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e

Expected opening tracked binary-diff SHA-256:

d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c

Expected verifier:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected tests:

- size: 72141
- SHA-256:
  71dfd3602b2c81a34d2d45ba1bc7fd350d3503813a82fd8503b890844adf9a1c

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Blocking audit root, read-only:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-2aedcf930bfa-v1

Blocking finding:

CT-01 — documentary regression-test adequacy

Audit-process finding, not a patch defect:

AP-06 — only three distinct subagent instances were available; four subject
perspectives were nevertheless delivered.

New implementation evidence root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/trusted-host-contract-test-repair-2aedcf930bfa

Require REPAIR_ROOT absent before creation.

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and process boundary

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - GIT_OPTIONAL_LOCKS=0;
  - GIT_CONFIG_NOSYSTEM=1;
  - LC_ALL=C;
  - LANG=C;
  - PYTHONDONTWRITEBYTECODE=1;
- be recorded with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in PRIMARY_R, AUDIT_ROOT, REPAIR_ROOT, or another evidence root.

Non-Git absolute-path reads are allowed from another inherited cwd.

No repository-relative operand may resolve through PRIMARY_R.

Any nonconforming Git command is an immediate process-boundary block.

## 3. Opening provenance gate

Require IMPL_R:

- exact physical root;
- expected branch, HEAD, tree, parent, and absent upstream;
- exactly 13 patch paths;
- four modified tracked and nine untracked;
- every path regular, single-link, working mode `0644`, logical mode `100644`;
- zero staged, deleted, renamed, or unmerged;
- no extra path;
- no Git operation marker or lock.

Open OPENING_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact manifest and recipe hashes;
- every manifest row equals live bytes;
- exact tracked binary diff;
- exact verifier and test identities;
- exact registry, layout, historical-fixture, boundaries, and governing-doc
  identities;
- AUDIT_ROOT present and stable.

Run RECIPE twice against IMPL_R into fresh paths beneath REPAIR_ROOT/opening
after REPAIR_ROOT is created.

Require both outputs byte-identical to OPENING_MANIFEST.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_BASELINE_MISMATCH

## 4. New evidence root

After the repository gate passes, create REPAIR_ROOT under umask `077`:

opening/
decision/
validation/
provenance/
closeout/
tmp/

Directories must be `0700`.
Retained files must be regular, single-link, mode `0600`.

Do not overwrite earlier implementation or audit evidence.

Retain an audit-finding disposition record that binds:

- CT-01 as the only repository repair objective;
- current docs as coherent but inadequately regression-tested;
- caller and verifier as unchanged;
- AP-06 as an audit-process issue requiring no repository repair;
- exact authorized repository scope;
- validation and provenance requirements.

## 5. Exact repository scope

The maximum authorized repository scope is:

1. `PLANS.md`
2. `.docs/system_overview/evidence_verification.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `tools/evidence_verify/test_verify_v1.py`

Prefer the smallest actual touched set that fully closes CT-01.

Keep byte-identical:

- `.docs/system_overview/boundaries.md`
- `tools/evidence_verify/verify_v1.py`
- `tools/evidence_verify/registry_v1.json`
- all three layout JSON files
- both historical `.py.txt` fixtures.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No runtime/public schema.
No product or runtime source.
No caller source in the repository.

If closing CT-01 requires changing `verify_v1.py`, `boundaries.md`, a registry,
a layout, a fixture, or adding a fourteenth patch path, stop:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_SCOPE_EXPANSION_REQUIRED

## 6. Required implementation design

Use one authoritative writer for the trusted-host contract.

### 6.1 Authoritative structured contract

Add exactly one private normative structured contract to:

`.docs/system_overview/evidence_verification.md`

Recommended contract ID:

`execution-substrate.evidence-verification.trusted-host-contract.v1`

The representation must be strict JSON inside uniquely identifiable begin/end
markers or an equivalently strict, unambiguous representation.

It is:

- a private documentation/assurance contract;
- not a product schema;
- not a runtime protocol;
- not a public API;
- not a source of readiness or execution authority.

It must encode, at minimum, exact typed values for:

- contract ID or schema;
- supported scope is `supported-local`;
- interpreter trust model is `trusted-host-stable-path-v1`;
- operator-controlled host is required;
- kernel/process execution substrate is trusted;
- foreground validation process is trusted;
- pinned interpreter installation and ancestors are trusted;
- every principal allowed to modify that installation is trusted;
- supplied repository/provenance inputs are trusted;
- target, candidate, target-controlled script paths, and unproven package,
  registry, layout, argv, and environment inputs remain untrusted;
- atomic loaded-object binding is not claimed;
- transient replacement by a trusted principal is not covered;
- shared or adversarial host support is false;
- remotely administered hostile-host support is false;
- production host attestation is false;
- interpreter opening/closing observations are `corroboration-only`;
- undocumented FD, `/dev/fd`, ctypes, native, copied-interpreter, or privileged
  fallback authorization is false;
- verifier result authority is `structural-evidence-only`.

Use exact booleans and exact closed strings. Do not encode those facts only as
free-form prose.

Reject duplicate keys, unknown keys, missing keys, wrong types, wrong values,
or multiple authoritative blocks.

### 6.2 Consumer-document references

`PLANS.md`, `artifact_hygiene.md`, and `capability_probing.md` must reference
the authoritative contract ID and explicitly state that they do not redefine,
override, or widen it.

Do not duplicate another independently editable full contract.

Where those documents retain explanatory prose, make it clearly subordinate to
the authoritative structured contract.

Use a uniquely bounded reference clause or another complete-section mechanism
that test 89 can validate as a whole rather than through unrelated phrase
presence.

### 6.3 No change in substantive threat model

Preserve the current audited semantics:

- trusted supported-local host;
- all interpreter-installation writers trusted;
- no atomic interpreter-object claim;
- transient trusted-principal replacement out of scope;
- shared/adversarial/remotely hostile hosts unsupported;
- structural evidence only;
- no hidden fallback.

This repair strengthens regression detection. It must not widen or narrow the
accepted threat model without a separate decision.

## 7. Test 89 repair

Preserve the identity:

`InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`

Do not add another numbered test solely to evade the finding.

Replace isolated `assertIn` phrase checks with a strict contract-validation
mechanism.

At minimum, test 89 must:

1. Locate exactly one authoritative contract block in
   `evidence_verification.md`.
2. Strictly parse it:
   - reject duplicate keys;
   - reject unknown keys;
   - reject missing keys;
   - reject wrong types;
   - require exact values.
3. Require the complete contract representation, not selected phrases.
4. Require exactly one bounded reference section in each consumer document.
5. Require every reference to name the exact contract ID.
6. Require every reference to state that it is non-overriding.
7. Require no second authoritative contract block in any consumer document.
8. Require `verify_v1.py` to retain its exact pinned SHA-256.
9. Require the current complete documents to pass.
10. Exercise contradictory negative mutations in memory and require rejection.

The negative matrix must include at least:

- `atomic_loaded_object_binding = true`;
- `transient_trusted_principal_replacement_covered = true`;
- `shared_or_adversarial_host_supported = true`;
- remotely hostile administration supported;
- `production_host_attestation = true`;
- interpreter observations upgraded from corroboration to proof;
- one interpreter-installation writer classified as untrusted;
- fallback launcher authorization enabled;
- verifier result granted readiness, execution, commit, or runtime authority;
- supported scope widened beyond supported-local;
- missing mandatory field;
- unknown field;
- duplicate key;
- wrong field type;
- duplicate authoritative block;
- wrong contract ID in a consumer reference;
- missing consumer reference;
- consumer reference that declares a local override;
- contradictory text inserted inside a bounded relevant contract/reference
  section.

Each mutation must fail for the intended contract reason, not merely because of
an unrelated parse failure.

A test helper may be added within `test_verify_v1.py`. No new repository module
is authorized.

## 8. AP-06 disposition

Do not change repository files to “fix” AP-06.

Retain an implementation-report statement:

- AP-06 is an independent-audit orchestration issue;
- it is not a patch defect;
- no repository behavior is changed for it;
- the fresh audit must use four distinct audit perspectives.

The next audit should schedule:

1. three distinct auditors concurrently;
2. after one closes and a slot becomes available, a fourth distinct security
   auditor sequentially.

If that fourth distinct auditor cannot start after one retry, the next audit
must return `SUBAGENT_UNAVAILABLE` rather than reuse another auditor for two
roles.

## 9. Validation

Use the pinned Python 3.13.4 interpreter already recorded by the project.

Run fresh validation against final bytes.

### Static and contract validation

- `ast.parse` verifier and test source;
- parse both historical `.py.txt` files without executing them;
- strict-parse registry and all three layouts;
- require registry/layout/historical-fixture bytes unchanged;
- parse the authoritative structured contract independently of test 89;
- independently execute the complete contradiction matrix;
- require consumer reference sections exact and non-overriding;
- require verifier SHA-256 unchanged;
- run rooted `git diff --check`.

### Targeted test

Run test 89 alone at least three times.

Require:

- all runs pass;
- all contradiction subcases execute;
- zero skip;
- no repository artifact.

### Complete suite

Discover the complete test identities.

Require exactly 89 identities unless a justified identity-preserving unittest
discovery difference is found.

Run the complete suite:

- twice under umask `077`;
- twice under umask `022`.

Require every owning command:

- exit `0`;
- 89 tests;
- zero failure;
- zero error;
- zero skip;
- identical identity set;
- no repository artifact.

Do not accept an inner successful unittest result when its owning shell command
fails.

### Regression scope

Because `verify_v1.py`, caller bytes, registry, layouts, and fixtures are
unchanged, a new repository-source compatibility implementation is not
required solely for this documentary-test repair.

Nevertheless, confirm from exact hashes that:

- verifier source is unchanged;
- source-external caller source is unchanged;
- registry/layouts are unchanged;
- historical fixtures are unchanged.

Preserve prior A6D, amendment, and synthetic results as predecessor evidence
only. The fresh independent audit will rerun acceptance-bearing compatibility.

## 10. Artifact and no-write checks

Scan IMPL_R for:

- `__pycache__`;
- `.pyc` and `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixtures;
- databases;
- journals;
- locks;
- build output;
- unexpected executable modes;
- unsupported file types.

Remove only artifacts created by this repair activity.

Do not remove or normalize pre-existing repository objects.

Require no mutation to:

- blocking audit evidence;
- earlier implementation evidence;
- FD-exec evidence;
- A6D or amendment evidence;
- Repair 10I candidate;
- primary checkout.

## 11. Provenance

After validation and cleanup, run the exact unchanged RECIPE twice against
IMPL_R into fresh paths beneath REPAIR_ROOT/provenance.

Require:

- both exits `0`;
- empty stderr;
- byte-identical canonical manifests;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- all paths regular, single-link, mode `100644`;
- no extra path;
- deterministic tracked binary diff.

Retain:

- exact recipe source and SHA-256;
- both canonical manifests;
- new canonical-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities;
- exact actual touched-file subset;
- final test file hash;
- unchanged verifier hash;
- targeted and full-suite results;
- contradiction-matrix result;
- failed/superseded attempt index;
- artifact and cleanup record.

## 12. Closing gate

Require final IMPL_R:

- branch, HEAD, tree, parent, and absent upstream unchanged;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- no extra path;
- every patch object regular and single-link;
- logical mode `100644`;
- `git diff --check` clean;
- no generated repository artifact;
- verifier, boundaries, registry, layouts, and historical fixtures
  byte-identical to opening.

Require supplied evidence roots unchanged.

Do not stage or commit.

## 13. Mandatory stops

Stop immediately if:

- opening provenance differs;
- verifier source must change;
- caller source must change;
- a sixth repository file is needed;
- a fourteenth patch path is needed;
- registry/layout/output schema must change;
- the structured contract becomes a runtime or public schema;
- contradictory negative cases cannot be made mechanism-specific;
- current coherent contract text would need semantic widening;
- test count differs without a justified cause;
- any full suite differs by umask;
- validation creates repository artifacts;
- final provenance is unstable.

Use exactly one verdict:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_SCOPE_EXPANSION_REQUIRED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_VALIDATION_BLOCKED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

## 14. Required complete inline report

Include inline:

1. Verdict.
2. Response-format confirmation.
3. Opening repository and provenance identity.
4. CT-01 finding consumed.
5. AP-06 disposition.
6. Exact actual touched files.
7. One-authoritative-writer design.
8. Authoritative contract ID and full typed field inventory.
9. Consumer-reference mechanism.
10. Test 89 implementation.
11. Complete contradictory mutation matrix and results.
12. Targeted test-89 runs.
13. Final complete test count and identities.
14. Both umask-077 results.
15. Both umask-022 results.
16. Static and documentation validation.
17. Unchanged verifier SHA-256.
18. Unchanged caller SHA-256.
19. Unchanged registry/layout/fixture hashes.
20. Artifact and no-write results.
21. Exact final 13-path manifest.
22. Provenance recipe identity and SHA-256.
23. New tracked binary-diff SHA-256.
24. New canonical-manifest SHA-256.
25. Evidence inventory and cleanup.
26. Authority and non-authority adjudication.
27. Remaining uncertainty and nonclaims.
28. Explicit confirmations:
    - prior audit no longer qualifies changed bytes;
    - fresh independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
```

## After implementation

The next audit should not reopen the trusted-host decision or demand atomic interpreter custody. It should focus on whether:

- the structured contract is the single authoritative representation;
- consumer documents cannot independently override it;
- test 89 rejects every contradictory mutation for the intended reason;
- current documents remain coherent;
- verifier and caller bytes stayed unchanged;
- all 89 tests and provenance reproduce exactly.

Run three auditors concurrently and the fourth distinct security auditor after a slot becomes available. That satisfies the required perspective independence without requiring four simultaneous child slots.

### Sources

- The attached independent audit returns `BLOCK` solely because CT-01’s phrase-based assertions can pass alongside contradictory contract text; it separately records AP-06 as an audit-process limitation.  
- The audit found the current trusted-host contract coherent, appropriately bounded, and free of conflicting atomic-custody claims. 
- It also confirmed four clean 89-test runs and successful caller, SEC-02, A6D, amendment, and synthetic causals. 
- The operating protocol separates parent-only repair from a later fresh independent audit, and changed bytes require new provenance and re-audit. 
- Provenance binds implementation and audit to the same bytes but does not establish correctness or authority. 

**Confidence**

- CT-01 is the only repository-patch blocker: **0.995**
- Verifier or caller source should remain unchanged: **0.995**
- Structured single-authority contract is the strongest proportional repair: **0.97**
- AP-06 should be handled only in the fresh audit orchestration: **0.99**
- Correct next gate after repair: fresh independent audit, **0.999**
