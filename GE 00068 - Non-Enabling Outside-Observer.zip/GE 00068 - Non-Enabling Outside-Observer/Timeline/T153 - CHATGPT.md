## Assessment

This is a clean implementation closeout on the evidence presented. The next gate is a **fresh independent audit of the new `2aedcf…` manifest**, not another implementation or reconnaissance turn.

The important change is no longer executable custody machinery. It is an explicit, bounded threat-model decision:

- source-by-value launch protocol v2 still protects verifier-source selection;
- the local validation host and Python installation are now an admitted trusted precondition;
- opening and closing interpreter observations are corroborative, not atomic proof of the executable object loaded by the kernel;
- transient replacement by a principal already inside that trusted boundary is expressly out of scope;
- shared or adversarial validation hosts are unsupported.

That is an honest termination of the trust chain, provided the fresh audit verifies that the documents, tests, and source-external caller all say exactly the same thing and do not smuggle back a stronger custody claim.

The scope also remains proportionate. Codex reports five repository files changed, while `verify_v1.py`, the registry, layouts, historical fixtures, and ownership boundary document stayed byte-identical. The new caller is source-external validation evidence rather than repository authority. This preserves the MVP rule that proof harnesses and generated evidence must not widen into architecture or authority by inertia. 

The audit should **not** reimpose atomic interpreter-object custody as an acceptance criterion. It should instead determine whether the supported-local trusted-host premise is explicit, coherent, enforceable enough for the stated bounded proof, and free of overclaim. Provenance can bind the audit to the exact bytes, but it cannot establish correctness or authority by itself. 

A fresh audit is mandatory before any commit. The project protocol separates parent-only implementation from a later read-only audit and permits commit only after `ACCEPT`.  

## Codex prompt: fresh independent audit of trusted-host boundary repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete audit report inline in Markdown.

Do not respond with only:

- a verdict;
- a summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

You may create and link a source-external report as supplemental evidence, but
the complete report required by this prompt must also appear in the response
body.

This applies to every outcome:

- ACCEPT;
- BLOCK;
- REJECT;
- AUDIT_PROVENANCE_MISMATCH;
- PROCESS_BOUNDARY_BLOCK;
- SUBAGENT_UNAVAILABLE.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a new read-only Codex conversation.

Do not resume:

- the trusted-host implementation conversation;
- the prior VC-01 audit conversation;
- the FD-exec capability conversation;
- any earlier producer or audit conversation.

Objective

Independently audit the exact Evidence Verification v1 trusted-host-boundary
repair.

Do not repair or modify the patch.

The implementation intentionally terminates interpreter custody at an explicit
bounded trusted-host premise:

- launch protocol v2 continues to pass externally authenticated verifier source
  by value through Python `-c`;
- the validation host, kernel, foreground execution substrate, pinned Python
  installation, and every principal permitted to modify that installation are
  inside the supported-local trusted boundary;
- interpreter opening and closing observations are corroborative drift
  detection only;
- no atomic claim is made that the kernel loaded the exact executable object
  observed before launch;
- transient replacement by a principal already inside the trusted boundary is
  out of scope;
- shared, adversarial, or remotely administered validation hosts are
  unsupported;
- verifier and caller output remains evidence/projection only.

Audit whether that boundary is explicit, internally consistent, honestly
implemented, and appropriate for the stated bounded supported-local proof.

Do not require resistance to an attack that the contract now explicitly places
inside the trusted boundary.

Do block if:

- the contract is ambiguous;
- caller behavior contradicts the contract;
- the host posture does not satisfy the declared premise;
- opening/closing observations are described as atomic custody;
- unsupported environments can silently qualify;
- the caller, evidence, or verifier acquires readiness or execution authority;
- provenance, tests, or source differ from the supplied target.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

No repository mutation.
No formatting.
No repair.
No repository cleanup that changes bytes or metadata.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product test, product A/B, live-service invocation, network contact, or Linux
binary execution.

No nested subagents.

## 1. Exact audit target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

IMPLEMENTATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3

Exact canonical manifest:

EXPECTED_MANIFEST=$IMPLEMENTATION_EVIDENCE/provenance/run-1/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e

Expected tracked binary-diff SHA-256:

d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe:

- recipe ID:
  execution-substrate.evidence-verification-v1.final-patch-provenance.v1
- SHA-256:
  bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected tests:

TESTS=$IMPL_R/tools/evidence_verify/test_verify_v1.py

- size:
  72141
- SHA-256:
  71dfd3602b2c81a34d2d45ba1bc7fd350d3503813a82fd8503b890844adf9a1c

Source-external trusted-host caller:

CALLER=$IMPLEMENTATION_EVIDENCE/commands/launch_v3_trusted_host.py

Expected caller:

- size:
  21530
- SHA-256:
  002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Trusted-host decision record:

DECISION=$IMPLEMENTATION_EVIDENCE/decision/trusted-host-boundary.json

Static validation record:

STATIC_RECORD=$IMPLEMENTATION_EVIDENCE/validation/static.json

Suite record:

SUITES=$IMPLEMENTATION_EVIDENCE/validation/suites.json

Caller-causal record:

CALLER_CAUSALS=$IMPLEMENTATION_EVIDENCE/validation/caller-causals.json

Targeted launch record:

TARGETED=$IMPLEMENTATION_EVIDENCE/validation/targeted-launch.json

Compatibility record:

COMPATIBILITY=$IMPLEMENTATION_EVIDENCE/validation/compatibility.json

Validation index:

VALIDATION_INDEX=$IMPLEMENTATION_EVIDENCE/validation/index.json

Failed and superseded index:

FAILED_INDEX=$IMPLEMENTATION_EVIDENCE/validation/failed-superseded-index.json

Final provenance record:

FINAL_PROVENANCE=$IMPLEMENTATION_EVIDENCE/provenance/final-provenance.json

Closing gate:

IMPLEMENTATION_CLOSING=$IMPLEMENTATION_EVIDENCE/closeout/closing-gate.json

FD-exec capability evidence, read-only:

FDEXEC_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-fdexec-caller-ed26813371b3

Expected FD probe source SHA-256:

3f9942247701c84a71e431a428f517a31102347d221aa7cf67257d8be801c195

Expected FD probe record SHA-256:

2215d45eff7f6c808bbd3e54b2cc77f3d9f414a492d565e7600fbf2da54042c1

Prior blocking audit, read-only:

PRIOR_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-ed26813371b3-v1

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter path:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular single-link opening object;
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-2aedcf930bfa-v1

Forbidden primary checkout for Git or repository-relative reads:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

## 2. Expected 13-path patch

Require exactly these paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Expected classification:

- four modified tracked;
- nine untracked;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged.

Expected final hashes:

`PLANS.md`
89e38a4e630b8a49bf105da3944d7f7dcdab7abb4f6ee180dd3f07bd081f4a39

`.docs/system_overview/boundaries.md`
643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e

`.docs/system_overview/artifact_hygiene.md`
3f16bccd5ddad9f3957dde6c9016b93e107d0aec30565694d5ee4187ecbdcfa6

`.docs/system_overview/capability_probing.md`
1c0b665dc990f6794c6dc01561948e0cd6bf0abe12dc02b8ebdfb4b17a6fc2ef

`.docs/system_overview/evidence_verification.md`
95969e82a356aed478e620806d07284c84ebc7bdae7d5902736bdc05f9fcd581

`tools/evidence_verify/verify_v1.py`
bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

`tools/evidence_verify/test_verify_v1.py`
71dfd3602b2c81a34d2d45ba1bc7fd350d3503813a82fd8503b890844adf9a1c

`tools/evidence_verify/registry_v1.json`
e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

`tools/evidence_verify/layouts/a6d_successor_v1.json`
267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc

`tools/evidence_verify/layouts/a6d_amendment_v1.json`
3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4

`tools/evidence_verify/layouts/a6_policy_v1.json`
b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

`tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98

`tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`
5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f

All paths must be regular, single-link, working mode `0644`, logical mode
`100644`.

## 3. Process and Git boundary

Use:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry every environment value above;
- be recorded with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

No subagent may execute Git.

No Git command may run in:

- PRIMARY_R;
- CANDIDATE_R;
- A6D;
- A6D_AMEND;
- IMPLEMENTATION_EVIDENCE;
- FDEXEC_EVIDENCE;
- PRIOR_AUDIT;
- AUDIT_ROOT;
- any evidence or audit root.

Non-Git absolute-path reads before the first Git command are allowed.

A non-Git command is not disqualifying merely because its inherited cwd is
PRIMARY_R when it:

- uses only absolute external operands;
- reads no PRIMARY_R-relative repository path;
- writes nothing to PRIMARY_R;
- invokes no Git.

Before any repository-relative read, use IMPL_R as cwd or an absolute IMPL_R
path.

Any nonconforming Git call or PRIMARY_R-relative repository access is a current
audit-process blocker.

## 4. Opening provenance gate

Require IMPL_R:

- physical root equals lexical path;
- direct real directory;
- expected branch, HEAD, tree, sole parent, and absent upstream;
- exact 13-path scope and classifications;
- every patch path regular and single-link;
- every working mode `0644`;
- every logical mode `100644`;
- zero staged/deleted/renamed/unmerged;
- no extra path;
- no Git operation marker or lock.

Open EXPECTED_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact recipe bytes and recipe ID;
- exact canonical-manifest SHA-256;
- exact tracked binary-diff SHA-256;
- every manifest row equals the live path, classification, type, mode, size,
  and SHA-256;
- verifier and test identities exact;
- registry, layouts, historical fixtures, and boundaries hash exact;
- CALLER, DECISION, validation records, final provenance, and closing gate
  present and stable;
- FD probe files present with expected hashes;
- PRIOR_AUDIT present and stable;
- A6D and A6D_AMEND manifests exact.

Stop before correctness inspection on any mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Opening provenance reproduction

After the complete gate passes, require AUDIT_ROOT absent.

Create under umask `077`:

opening/
provenance/
perspectives/
validation/
findings/
closeout/
tmp/

Run the exact unchanged RECIPE twice against IMPL_R into fresh opening
continuations.

Require:

- both exits `0`;
- empty stderr;
- both manifest files byte-identical;
- both stdout streams byte-identical;
- stdout equals its output file;
- all outputs equal EXPECTED_MANIFEST;
- canonical SHA-256:
  `2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e`;
- tracked binary diff:
  `d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c`;
- no repository or supplied-evidence mutation.

Stop before source inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 6. Four required audit perspectives

Only after provenance succeeds, spawn exactly four bounded read-only
perspectives:

1. Contract, authority, and threat-model auditor.
2. Caller/verifier correctness and state-semantics auditor.
3. Test and validation-adequacy auditor.
4. Security, filesystem, process, capability, and artifact auditor.

No nested subagents.
No subagent Git command.
Retry a failed perspective once.

Every perspective receives:

- the reproduced canonical patch identity;
- exact verifier, test, registry, layout, and caller identities;
- trusted-host decision record;
- FD-exec negative evidence;
- prior blocking audit;
- implementation validation index;
- current contracts and explicit non-goals.

Preserve disagreements.

Do not silently replace missing perspective coverage with parent inference.

## 7. Threat-model and contract audit

Audit the governing documents together:

- `PLANS.md`;
- `.docs/system_overview/evidence_verification.md`;
- `.docs/system_overview/artifact_hygiene.md`;
- `.docs/system_overview/capability_probing.md`;
- unchanged `.docs/system_overview/boundaries.md`;
- Milestone 0 MVP freeze and relevant project guidance.

Require the contract to distinguish clearly:

### Trusted

- operator-controlled supported-local host;
- kernel and process-execution substrate;
- already-running validation process;
- pinned Python installation path and ancestors;
- every principal able to modify that installation;
- externally supplied repository/provenance inputs.

### Untrusted

- target content;
- pre-seal candidate;
- target-controlled script paths;
- package/source substitutions outside exact provenance;
- registry/layout substitutions;
- arguments or environment outside the closed launch protocol.

### Out of scope

- malicious transient replacement by a principal already inside the trusted
  host boundary;
- administrator or root compromise;
- kernel compromise;
- debugger/process-memory compromise;
- compromised Codex execution substrate;
- compromised pinned interpreter;
- privileged filesystem identity forgery;
- cryptographic collision.

Require the documents to state:

- shared/adversarial/remotely administered hosts are unsupported;
- this is supported-local proof, not production host attestation;
- opening and closing interpreter observations are corroboration only;
- no atomic executed-interpreter-object claim;
- source-by-value protocol v2 remains the verifier-source custody mechanism;
- pass remains structural evidence, not readiness;
- no fallback launcher is authorized.

Block if the accepted risk is hidden in an implementation report but absent
from governing docs.

Block if the docs imply atomic custody anywhere else.

## 8. Authority audit

Require:

- verifier remains an ES-owned `Bounded slice rule`;
- output remains evidence/projection only;
- no run truth, readiness, product, runtime, admission, orchestration, durable
  state, commit, or publication authority;
- source-external caller remains validation/provenance evidence;
- caller record does not become source authentication or readiness;
- no repository launcher;
- no product API, public schema, route, service, module, or runtime-contract
  change;
- registry and layouts remain structural only;
- no new cross-repository framework owner;
- proof scaffolding does not become architecture by drift.

The MVP freeze says proof harnesses and generated evidence must not become
architecture or authority; evaluate this patch against that rule.

## 9. FD-exec disposition audit

Inspect FDEXEC_EVIDENCE and independently establish on this host:

- `os.execve` is absent from `os.supports_fd`;
- passing the open interpreter descriptor to `os.execve` does not execute it
  and fails as recorded;
- no qualifying fd-bound caller exists;
- the implementation did not introduce:
  - `/dev/fd` fallback;
  - ctypes;
  - native launcher;
  - copied interpreter;
  - privileged helper;
  - undocumented code-signing/attestation mechanism;
  - recursive launcher trust.

A bounded independent capability recheck is authorized under the audit root,
without modifying supplied evidence.

Do not block merely because atomic fd execution is unavailable; that
unavailability is part of the audited design decision.

## 10. Caller-source audit

Inspect the complete `launch_v3_trusted_host.py`.

Require:

- standard-library-only;
- argv-list child launch;
- `shell=False`;
- exact launch protocol v2 source-by-value behavior;
- no direct-script fallback;
- no stdin or `/dev/fd` verifier-source fallback;
- no alternate interpreter fallback;
- no source self-authentication claim;
- no readiness claim.

Inspect interpreter path and ancestor checks:

- absolute and physical path;
- no symlink component;
- final interpreter regular and single-link;
- expected size/hash;
- owner/group/mode posture;
- world-write rejection;
- admitted group-write rule;
- opening and closing observations;
- stable device/inode/type/link/mode/owner/group/size/hash;
- uncertainty or observation failure blocks;
- child wait/reap before closing observation.

Determine whether the hardcoded root/admin group IDs `0` and `80` accurately
match the documented supported-local premise on this host.

Determine whether all users able to modify a group-writable interpreter or
ancestor are expressly included in the trusted boundary.

Block if the caller treats those users as untrusted while simultaneously
accepting their write access.

Inspect the four mandatory record fields:

- `interpreter_trust_model = "trusted-host-stable-path-v1"`
- `atomic_loaded_object_binding = false`
- `transient_trusted_principal_replacement_covered = false`
- `shared_or_adversarial_host_supported = false`

Require:

- exact values;
- present in acceptance-bearing records;
- no contradictory caption;
- `observations_are_corroboration_only = true`.

Inspect output minimization and ensure no source text, private path, credential,
or readiness claim appears in shared output.

## 11. Verifier-source audit

Require `verify_v1.py` to be byte-identical to its prior accepted target:

bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Re-audit enough of it to establish no documentary repair weakened:

- source-by-value launch protocol;
- early immutable argv capture;
- direct-script/stdin/FD nonqualification;
- package/source exact-byte comparison;
- package/target/candidate disjointness;
- registry/layout binding;
- closure semantics;
- canonical output;
- no-write/no-network/no-child behavior;
- non-readiness posture.

Do not require verifier changes merely to encode the caller’s trusted-host
assumption; that responsibility belongs to the external caller and governing
contract.

## 12. Test audit

Inspect all current tests.

Expected:

- exactly 89 unique tests;
- original tests 01–88 preserved;
- new:
  `InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`.

Audit test 89 independently.

Require it to prove at least:

- governing docs name the trusted-host assumption;
- atomic loaded-object identity is expressly disclaimed;
- trusted-principal transient replacement is outside scope;
- shared/adversarial host is unsupported;
- undocumented fallback is prohibited;
- verifier source remains unchanged.

Check that test 89 does not merely search for isolated words that could coexist
with contradictory contract text.

Preserve the prior nonblocking test-precision observation concerning old
pseudo-closeout argv records if still applicable.

## 13. Fresh suite replay

Discover the exact test identities independently.

Run the complete suite:

- twice under umask `077`;
- twice under umask `022`.

Use the pinned interpreter and isolated private roots.

Require every owning command:

- exit `0`;
- 89 tests;
- zero failures;
- zero errors;
- zero skips;
- identical identity set;
- no repository artifact.

Do not accept a successful inner suite when the owning shell exits nonzero.

## 14. Independent caller construction

Inspect the producer caller, but do not treat it as an oracle.

Create an audit-owned minimal caller beneath AUDIT_ROOT that independently
implements the documented supported-local boundary:

- pins interpreter expected path, size, and SHA-256;
- no-follow inspects every interpreter path component;
- captures owner/group/mode/type/link/device/inode;
- enforces the documented root/admin write policy;
- explicitly accepts that admitted writers are trusted;
- records opening and closing observations as corroboration only;
- validates source-by-value verifier bytes against EXPECTED_MANIFEST;
- launches through argv-list `-I -S -B -c`;
- uses no shell;
- checks returned registry/layout hashes;
- snapshots target/package/candidate/TMPDIR;
- emits all mandatory nonclaim fields.

Retain the audit caller source and SHA-256.

Compare its behavior and threat-model record to the producer caller.

## 15. Caller and threat-boundary causals

Run independently at minimum:

1. Expected interpreter path and posture passes.
2. Wrong interpreter hash blocks.
3. Wrong interpreter size blocks.
4. Final interpreter symlink blocks.
5. Ancestor symlink blocks.
6. Opening/closing inode or byte change blocks.
7. Opening/closing mode change blocks.
8. Opening/closing owner/group change blocks.
9. World-writable path component blocks.
10. Group-writable component with admitted group `80`:
    - qualifies only because that group is explicitly trusted;
    - record identifies the posture.
11. Group-writable component with an unadmitted group blocks.
12. Unsupported metadata capability blocks.
13. Shared/adversarial host mode blocks.
14. Mandatory nonclaim fields are exact.
15. No record claims atomic loaded-object identity.
16. No FD/native/copy/ctypes fallback exists.
17. Returned registry mismatch is caller-rejected.
18. Returned layout mismatch is caller-rejected.
19. Direct-script/stdin/FD verifier launch remains nonqualifying.
20. Caller shared output leaks no source text or sensitive absolute path.

For caller-side rejection require:

- child not launched when rejection is pre-exec;
- zero child stdout/stderr;
- exact reason;
- unchanged target/package/candidate.

For post-launch drift rejection, require the result remain nonqualifying even if
the verifier itself returned pass.

## 16. Source-by-value SEC-02 regression

Run a fresh audit-owned target-marker causal.

Require:

- target-controlled script exists;
- valid caller supplies authenticated verifier source through `-c`;
- target script is never loaded or executed;
- marker never appears;
- pre-seal and sealed valid cases behave as expected;
- direct-script predecessor shape remains nonqualifying.

Do not claim resistance to an in-trust-boundary malicious interpreter swap.
That attack is expressly out of scope and must remain a nonclaim.

## 17. Real A6D compatibility

Run sealed A6D twice through the final audit-owned caller.

Require:

- both exits `0`;
- empty verifier stderr;
- byte-identical canonical verifier stdout;
- expected stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- caller records contain all mandatory nonclaims;
- target/package/TMPDIR unchanged;
- A6D manifest unchanged:
  `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`.

Treat this as structural compatibility only.

## 18. Real amendment compatibility

Run the sealed amendment twice through the audit-owned caller.

Require:

- both exits `0`;
- empty verifier stderr;
- byte-identical canonical stdout;
- expected SHA-256:
  `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`;
- mandatory nonclaims present;
- unchanged target/package/TMPDIR;
- amendment manifest unchanged:
  `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`.

Treat this as structural compatibility only.

## 19. Synthetic A6 compatibility

Create an audit-owned synthetic A6 fixture using independently inspected writer
logic.

Run:

1. pre-seal twice;
2. seal only the audit-owned fixture;
3. sealed twice.

Require:

- all exits `0`;
- empty stderr;
- deterministic output within each stage;
- mandatory caller nonclaims in every record;
- target/package/candidate/TMPDIR unchanged by verifier invocation;
- verifier installs nothing;
- fixture removed at cleanup.

## 20. No-write, resource, and artifact audit

Snapshot before and after every verifier launch:

- target;
- package;
- candidate where applicable;
- private TMPDIR;
- caller evidence root excluding the intended record.

Inspect:

- no repository write;
- no target/package/candidate mutation;
- no verifier child beyond the intended Python child;
- no network;
- no target-code import;
- no runtime layout injection;
- bounded source, JSON, manifest, and structural reads;
- canonical exception handling;
- output minimization.

Scan IMPL_R for:

- `__pycache__`;
- `.pyc` and `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixtures;
- databases;
- journals;
- locks;
- build outputs;
- unexpected executable modes;
- unsupported objects.

Historical `.py.txt` files remain inert.

## 21. Implementation-evidence audit

Inspect the complete IMPLEMENTATION_EVIDENCE tree.

Require:

- decision record matches governing docs;
- FD-exec unavailability is represented accurately;
- no unsupported fallback is hidden;
- validation index selects final 89-test runs;
- failed/superseded attempts remain separated;
- compatibility records bind final caller bytes;
- mandatory nonclaim fields are present in all eight final records;
- final provenance binds current repository bytes;
- caller is evidence only;
- no prior audit is portrayed as qualifying the changed docs/tests;
- no readiness or product-authority claim.

Inspect the reported early-command reconstruction limitation. Classify it on
its merits; do not automatically block if current audit independently
reproduces exact provenance and validation.

## 22. Prior finding closure

Reconcile:

- SEC-01;
- SEC-02;
- VC-01 / SEC-A1;
- EV-01 through EV-09;
- F-01 through F-04;
- PP-01;
- PE-02;
- TA-03;
- AP-04;
- AP-05;
- CA-01.

VC-01 may be closed only as follows:

- atomic interpreter custody is no longer claimed;
- the trusted-host premise is explicit;
- accepted writers are explicitly trusted;
- unsupported environments are rejected;
- caller observations are correctly labeled corroborative;
- no hidden fallback or stronger caption remains.

Do not describe VC-01 as cryptographically or atomically solved.

## 23. Parent adjudication

After all four perspectives complete:

- preserve disagreements;
- distinguish:
  - patch defect;
  - contract/threat-model defect;
  - producer-process issue;
  - audit-process issue;
  - pre-existing issue;
  - future production-hardening seam;
- audit the entire 13-path patch;
- do not accept solely because tests pass;
- do not block solely because atomic custody is absent when the current
  explicit contract does not claim it;
- decide whether this threat model is appropriate and honest for a
  supported-local bounded proof;
- perform no repair.

## 24. Closing provenance

Remove only audit-owned temporary fixtures.

Run the exact unchanged RECIPE twice into a fresh closing continuation.

Require:

- both exits `0`;
- empty stderr;
- byte-identical manifest files and stdout;
- outputs equal EXPECTED_MANIFEST;
- canonical SHA-256:
  `2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e`;
- tracked binary diff:
  `d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c`;
- exact opening/closing repository identity;
- zero staged/deleted/renamed/unmerged;
- no repository or supplied-evidence mutation;
- A6D, amendment, implementation evidence, FD evidence, prior audit, and
  candidate unchanged.

On mismatch:

AUDIT_PROVENANCE_MISMATCH

## 25. Finding format

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, contract defect, pre-existing issue, producer-process issue, or
audit-process issue:
Blocking: yes | no

## 26. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use on any repository, recipe, manifest, path, classification, mode, size,
hash, diff, or closing-provenance mismatch.

Stop before correctness inspection on opening mismatch.

### REJECT

Use only for a fundamental authority or architectural defect that cannot be
repaired within the bounded verifier/docs/tests tranche.

### BLOCK

Use when a repairable defect remains in:

- threat-model clarity;
- caller behavior;
- supported-host gating;
- documentation;
- tests;
- validation;
- artifacts;
- current audit process;
- authority boundaries.

Do not use BLOCK merely because a malicious trusted administrator could defeat
the local proof. That is now an explicit out-of-scope condition.

### ACCEPT

Use only when:

- opening and closing provenance match;
- the explicit trusted-host boundary is coherent and consistently implemented;
- actual host posture is within that boundary;
- caller and records make no atomic-custody overclaim;
- shared/adversarial hosts are nonqualifying;
- verifier source remains unchanged and sound;
- all 89 tests and targeted causals pass;
- source-by-value SEC-02 remains closed;
- A6D, amendment, and synthetic checks pass;
- evidence remains non-authoritative;
- no artifact or current-audit-process blocker remains.

## 27. Complete inline final report

Your final response must include the complete report inline.

Do not replace any section with a link.

Supplemental links may follow the complete inline report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact audit target.
4. Opening and closing provenance.
5. Repository identity and 13-path scope.
6. Four perspectives and completion status.
7. Trusted-host decision adjudication.
8. Exact threat model.
9. Accepted risk and unsupported environments.
10. Authority and non-self-verification adjudication.
11. FD-exec capability disposition.
12. Caller-source review.
13. Interpreter path/ancestor posture review.
14. Root/admin group-write adjudication.
15. Mandatory caller nonclaim fields.
16. Verifier-source no-change and source-by-value adjudication.
17. Test 89 adequacy.
18. Exact test count and four suite results.
19. Every caller/threat-boundary causal result.
20. Source-by-value SEC-02 result.
21. A6D results.
22. Amendment results.
23. Synthetic A6 results.
24. No-write and deterministic-output evidence.
25. Security, resource, and artifact findings.
26. Implementation-evidence findings.
27. Prior-finding closure table.
28. Severity-ranked residual findings.
29. Minority findings and parent resolution.
30. Remaining uncertainty and explicit nonclaims.
31. Audit-created paths and cleanup.
32. Complete Git-process record.
33. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No staging.
No commit.
No push.
No A6 restart.
```

An `ACCEPT` result should proceed to a separate exact-byte commit gate. There should be no additional implementation or threat-model redesign between audit acceptance and staging. The commit gate must regenerate the accepted manifest, stage only those 13 paths, compare staged and committed blobs to the accepted manifest, run byte-preserving final validation, and stop on any drift. 

### Sources

- Codex’s complete interpreter-trust implementation report supplied in this turn.
- Milestone 0 explicitly prevents proof scaffolding and generated evidence from becoming architecture or authority. 
- The original architecture decision makes the verifier ES-owned, source-external, and non-self-verifying. 
- Independent audit must occur in a fresh read-only conversation and must reproduce provenance before correctness inspection. 
- Provenance establishes byte identity, not correctness, sufficiency, or authority. 
- Commit is a later gate available only after audit acceptance. 

**Confidence**

- Implementation is ready for fresh audit: **0.99**
- Verifier code should remain unchanged during this audit: **0.995**
- Trusted-host threat model is a defensible supported-local boundary: **0.94**
- Primary audit risk is contract/caller inconsistency rather than verifier logic: **0.96**
- Correct next step is fresh independent audit, not further implementation: **0.999**
