## Assessment

This is the first clean handoff that closes both classes of audit-parent defects:

- The **postseal control-flow repair** remains qualified: one terminal-seal transition, no postseal filesystem access, locally guarded terminal output, nonreturning `os._exit(0)`, and a seal-aware outer failure handler.
- The **P00 opening-gate repair** is narrowly bounded to the three reconciled defects:
  - successor terminal-manifest scope;
  - successor temporal-projection and chronology semantics;
  - blocking-audit descendant-only manifest semantics.
- The repaired P00 logic passed:
  - a 70-case mutation matrix;
  - an independent 60-case validator;
  - read-only replay over all fixed P00 operands;
  - compilation;
  - all 25 structural checks;
  - both postseal analyses and their mutation regression;
  - frozen-byte requalification.
- All supplied inputs closed equal, and no package or evidence root was modified.

The exact execution authority is now:

`/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq/provenance/parent-source.py`

- Size: `190827`
- SHA-256: `85cb475093deb1cfd1496c6e1284a823bf0b217fd4a2dcdea61986986ef1b6e6`
- Mode/link count: `0600 / 1`

No further source construction, preflight, P00 reconciliation, or harness work is warranted. Execute these exact frozen bytes once.

```text
EXECUTE THE EXACT FROZEN P00-REPAIRED PARENT AUDIT SOURCE ONCE

This task executes one already-qualified finite parent-audit source.

Do not regenerate, edit, patch, normalize, reformat, copy, wrap, import,
re-preflight, or reinterpret the parent source.

Do not create another:

- parent source;
- audit harness;
- process wrapper;
- supervisor;
- importer;
- source-preflight capsule;
- P00 reconciliation;
- findings-reconciliation capsule;
- capability probe.

Do not create subagents or direct auditors.

The frozen source owns the complete audit plan, opening gate, child recorder,
A/C/H/I/J audit, validation commands, materializations, handoffs, security
analysis, cleanup, closing equality, verdict selection, failure closeout, and
terminal sealing.

Return exactly the primary verdict produced by the frozen audit:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

Do not substitute another headline.

──────────────────────────────────────────────────────────────────────────────
1. FROZEN SOURCE CAPSULE
──────────────────────────────────────────────────────────────────────────────

FROZEN_SOURCE_CAPSULE:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq

Expected root identity:

- device/inode:
  16777234 / 179906468
- mode:
  0700
- producer verdict:
  PARENT_AUDIT_SOURCE_P00_REPAIR_READY

Expected temporal inventory:

closeout/temporal-final-inventory.json

- size:
  14265
- SHA-256:
  be98d7f5d176ed2ef217afee3f6da030c3530e036c0eeffbb2c66c7e8f8cc1f5
- represented entries:
  74

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  13502 each
- SHA-256:
  23586b791a5856199518bcaa1acf9fda20a91f557cdeb42319ea0622c164c4ab
- byte-identical:
  required
- represented paths:
  77
- exactly two manifest self-exclusions

Expected freeze record:

opening/parent-source-freeze.json

- size:
  6398
- SHA-256:
  9170750be2ac907506de73326e13ac98b589d685052e833cc7c10e3d3e1feba8

Before execution, perform only a bounded read-only identity check of this
capsule and the exact parent source.

Do not open any package or audit target before launching the parent. The parent
owns those opening observations.

If the capsule, freeze record, terminal manifests, or parent-source identity
does not match, do not execute the source. Return:

AUDIT_PROVENANCE_MISMATCH

with the exact expected-versus-observed discrepancy.

──────────────────────────────────────────────────────────────────────────────
2. EXACT FROZEN PARENT SOURCE
──────────────────────────────────────────────────────────────────────────────

FROZEN_PARENT_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq/provenance/parent-source.py

Required identity:

- device/inode:
  16777234 / 179932225
- size:
  190827
- SHA-256:
  85cb475093deb1cfd1496c6e1284a823bf0b217fd4a2dcdea61986986ef1b6e6
- mode:
  0600
- link count:
  1

The source has already been:

- compiled using Python 3.13 with `-I -S -B`;
- qualified by the closed P00 mutation matrix;
- qualified by an independent P00 validator;
- replayed read-only against all fixed P00 inputs;
- checked by the complete 25-item structural crosswalk;
- checked by the static noninteractive gate;
- checked by both independent postseal analyses;
- checked by the postseal mutation matrix;
- requalified after exact-byte freeze.

Do not repeat those qualification tasks.

Do not execute a copied source. Execute this exact path.

──────────────────────────────────────────────────────────────────────────────
3. PINNED INTERPRETER
──────────────────────────────────────────────────────────────────────────────

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected identity:

- version:
  Python 3.13.4
- device/inode:
  16777234 / 2301718
- regular:
  true
- link count:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter mode `0775` is report-only.

If the identity does not match, do not execute the parent. Return
`AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
4. EXACT EXECUTION
──────────────────────────────────────────────────────────────────────────────

Invoke exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  /Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq/provenance/parent-source.py

Use cwd:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq

Use these explicit stable environment values:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Do not add parent-source arguments.

Do not replace the source path with a temporary copy.

Do not alter HOME, TMPDIR, package roots, materialization parent, audit prefix,
launcher paths, validator paths, or any other contract-owned value. The frozen
source owns those values.

Use one noninteractive top-level carrier.

When a shell carrier is unavoidable, use terminal `exec` so the shell is
replaced by the pinned Python process.

Do not:

- read from stdin;
- feed later commands;
- create an interactive session;
- start a second parent;
- launch an administrative continuation;
- interrupt the process while it is making progress;
- patch the parent following any failure.

Use the maximum available bounded noninteractive timeout.

──────────────────────────────────────────────────────────────────────────────
5. TOP-LEVEL EXECUTION CUSTODY
──────────────────────────────────────────────────────────────────────────────

Retain the exact platform-observed:

- submitted argv;
- cwd;
- explicit environment;
- process PID;
- raw stdout;
- raw stderr;
- exit or signal;
- elapsed duration.

The Codex platform transcript is authoritative for creation and termination of
the top-level process.

Do not parse heartbeats or intermediate progress lines as the verdict.

The source may emit:

- exactly one audit-root locator;
- progress or heartbeat lines;
- a `PRIMARY_VERDICT=` line on a failure path;
- a retained failure report;
- on successful terminal sealing:
  `AUDIT_TERMINAL_SEAL_COMPLETE`.

Retain raw output byte-for-byte.

──────────────────────────────────────────────────────────────────────────────
6. AUDIT-ROOT LOCATOR
──────────────────────────────────────────────────────────────────────────────

Use only the exact audit-root locator emitted by the frozen parent.

Do not:

- scan `/Users/ds/Downloads`;
- search by prefix;
- select a newest entry;
- score possible roots;
- adopt a historical root;
- infer a path from prior attempts.

If no unique valid audit-root locator is emitted, return:

AUDIT_PROVENANCE_MISMATCH

Do not launch another parent.

The emitted root is the sole audit root for this attempt.

──────────────────────────────────────────────────────────────────────────────
7. AFTER PROCESS EXIT
──────────────────────────────────────────────────────────────────────────────

After the parent exits, perform read-only inspection only.

Do not modify, clean, resume, repair, complete, or seal the audit root.

A. FAILURE CAPSULE

When the audit root contains a failure closeout, read only:

- primary-verdict record;
- final or failure report;
- parent outcome or preseal record;
- phase-terminal results;
- complete child ledger;
- opening-gate result;
- closing-equality record, when present;
- cleanup-set record;
- temporal final inventory;
- terminal manifests, when present.

Return the capsule’s exact primary verdict.

Do not reinterpret a substantive `BLOCK` as a provenance mismatch.

Do not promote evidence generated after a failed opening-provenance gate into a
package finding unless the capsule itself qualifies it.

B. SUCCESS CAPSULE

When the process:

- exits zero;
- emits `AUDIT_TERMINAL_SEAL_COMPLETE`;
- and the capsule contains terminal manifests;

read only:

- primary-verdict record;
- final audit report;
- parent preseal outcome;
- complete child ledger;
- opening result;
- closing equality;
- cleanup-set equality;
- temporal final inventory;
- manifest A;
- manifest B.

Independently confirm only the terminal handoff facts:

- both manifests exist;
- both manifests are byte-identical;
- their reported identities match the capsule;
- the platform-authoritative parent exit is zero;
- the terminal marker was emitted;
- no parent filesystem write occurred after terminal closure according to the
  capsule and platform timing.

Do not conduct another audit of the audit.

──────────────────────────────────────────────────────────────────────────────
8. STOP RULES
──────────────────────────────────────────────────────────────────────────────

Do not relaunch following any failure.

Do not edit the frozen source.

Do not create a replacement parent.

Do not create an administrative continuation.

Do not remove audit-owned roots after the parent has sealed or failed unless
the frozen parent itself performed and recorded that cleanup.

Do not convert:

- a parent-process or capsule failure into a successor-package defect;
- a package `BLOCK` into `AUDIT_PROVENANCE_MISMATCH`;
- an opening-provenance mismatch into package repair authority;
- an `AUDIT_PROVENANCE_MISMATCH` into substantive package evidence.

A package repair is authorized only by a qualifying substantive `BLOCK` report
that identifies a concrete package defect.

──────────────────────────────────────────────────────────────────────────────
9. COMPLETE REPORT REQUIREMENT
──────────────────────────────────────────────────────────────────────────────

Do not return only the verdict token.

Return the exact verdict as the primary headline, followed by the complete
read-only execution and capsule report.

At minimum include:

1. Primary verdict
2. Frozen source-capsule identity
3. Frozen parent-source identity
4. Pinned Python identity
5. Exact invocation
6. Cwd and explicit environment
7. Parent PID and duration
8. Process exit or signal
9. Raw stdout size and SHA-256
10. Raw stderr size and SHA-256
11. Fresh audit-root locator and path
12. Audit-root identity
13. Audit epoch status
14. Parent runtime self-check
15. Frozen-plan identity
16. Last completed phase
17. Last qualifying child ordinal
18. Child-ledger identity and continuity
19. Opening-gate result
20. Materialization and handoff status
21. Package-validation status
22. Primary-verdict-record identity
23. Final/failure-report identity
24. Closing-equality status
25. Cleanup-set status
26. Temporal-inventory identity
27. Terminal marker status
28. Terminal-manifest identities or explicit absence
29. Exact substantive package findings, when qualification reached them
30. Severity-ranked residual findings
31. Audit-created paths and retained root status
32. Remaining uncertainty and nonclaims
33. Explicit confirmations

Required confirmations:

FROZEN_SOURCE_CAPSULE_MUTATION_NOT_PERFORMED
FROZEN_PARENT_SOURCE_MUTATION_NOT_PERFORMED
FROZEN_PARENT_SOURCE_IDENTITY_MATCHED
FROZEN_PARENT_SOURCE_EXECUTED_EXACTLY_ONCE
PINNED_PYTHON_IDENTITY_MATCHED
LITERAL_I_S_B_OPTIONS_USED
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
HISTORICAL_AUDIT_ROOT_NOT_ADOPTED
FRESH_AUDIT_ROOT_FROM_PARENT_LOCATOR_USED
PARENT_RAW_STDOUT_RETAINED
PARENT_RAW_STDERR_RETAINED
PLATFORM_PROCESS_EXIT_RETAINED
CAPSULE_PRIMARY_VERDICT_REPORTED_EXACTLY
FAILED_AUDIT_ROOT_NOT_RESUMED
FAILED_AUDIT_ROOT_NOT_REPAIRED
NO_POSTSEAL_PARENT_FILESYSTEM_WRITE
NO_GIT_INVOCATION_OUTSIDE_FROZEN_AUDIT
NO_NETWORK_CONTACT_OUTSIDE_FROZEN_AUDIT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION_OUTSIDE_FROZEN_AUDIT
NO_SUBAGENTS_CREATED
```

An `ACCEPT` closes the bootstrap-package line. The next step would then be the
substantive fresh independent Validation-Custody V3 target audit using the
accepted bootstrap package.

A qualifying `BLOCK` authorizes only a bounded repair of the concrete package
findings reported by that audit.

An `AUDIT_PROVENANCE_MISMATCH` authorizes no package repair.
```

**Source:** Codex’s `PARENT_AUDIT_SOURCE_P00_REPAIR_READY` report in the current turn.  
**Confidence:** 0.997 that the parent source is now ready for one exact execution; 0.99 that no further source preflight or P00 work is warranted; 0.97 that the next result should finally be a substantive package verdict unless a new runtime-provenance defect appears.
