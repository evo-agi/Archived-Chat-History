Here is Codex's response:

# ACCEPT

## 1. Verdict

The exact Evidence Verification v1 atomic-bundle-v4 target qualifies for **ACCEPT as a bounded supported-local implementation slice**. Opening and closing provenance matched, the required fresh validation passed, and no blocking correctness, authority, security, validation, or artifact finding remains.

This verdict does not grant product readiness, Repair 10I correctness, commit authorization, or A6 readiness.

## 2. Administrative pre-epoch disclosure

I read the pasted prompt attachment before the audit epoch. That read used the primary checkout as its process cwd, but its sole content operand was the attachment; I did not inspect primary-working-tree content. The audit epoch began immediately afterward. Every subsequent repository-facing command used the specified linked worktree as cwd, and every repository Git invocation used `git -C "$IMPL_R"`.

An initial attempt to locate Python at `/opt/homebrew/bin/python3.13` failed without running an audit operation. All validation used the pinned Python **3.13.4** at `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`.

## 3. Exact repository and supplied-input identities

`IMPL_R` was `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`.

| IdentityObserved value                                                                                                                                                                      |                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| Branch                                                                                                                                                                                      | `codex/evidence-verification-v1`                                   |
| HEAD                                                                                                                                                                                        | `567bceced5df95ecfe787cc66038d463a854e12c`                         |
| Tree                                                                                                                                                                                        | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                         |
| Sole parent                                                                                                                                                                                 | `05dde14d185b6e022dcc169ef1a658a97961850f`                         |
| Upstream                                                                                                                                                                                    | Absent                                                             |
| Governed inventory                                                                                                                                                                          | 477 objects                                                        |
| Working patch                                                                                                                                                                               | Four modified tracked paths; nine untracked paths                  |
| Staged/deleted/renamed/unmerged                                                                                                                                                             | `0/0/0/0`                                                          |
| Ignored or cache artifacts in repository                                                                                                                                                    | None observed                                                      |
| Full-index tracked binary diff SHA-256                                                                                                                                                      | `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24` |
| [Five-path implementation delta](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/provenance/repository-five-path-delta.diff) SHA-256 | `c676ce5dcedb36fdf66cb3fafff9f89c32c0e151e94818aa6e59cf6df284b69f` |

The five changed paths against the frozen prior inventory were `PLANS.md`, `.docs/system_overview/artifact_hygiene.md`, `.docs/system_overview/capability_probing.md`, `.docs/system_overview/evidence_verification.md`, and `tools/evidence_verify/test_verify_v1.py`. The other **472 governed objects** matched the frozen rows.

| Supplied inputExact identity |                                                                                                                                                                                                                                    |
| ---------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `REPAIR_V4_ROOT`             | `/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr`; 198 files                                                                                                                |
| `OUTPUT_ROOT`                | `/Users/ds/Downloads/ES-evidence-verification-v1-bundle-output-9228k2d1`; 48 files; retained output-inventory SHA-256 `f34d4b19d16e3115aaf15083ec1ad68d097bc281d59fbf490955a4a3debed245`                                           |
| `ADDENDUM_ROOT`              | `/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-closeout-addendum-643fc7d12dd2-vf2cjujv`; 95 files                                                                                                               |
| `RECON_ROOT`                 | `/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu`; 15 files; final-inventory SHA-256 `70fe43eb8432eaac6aa6c8d0630bb9a97d404d2098235fdbb091bc950eb19c15`                                     |
| `HISTORICAL_BLOCK_AUDIT`     | `/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im`; 94 files; final-inventory SHA-256 `267d6df463bc09e65babd312faab1441d2516227e10241b24b38f710d6778296` |

The [final caller](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py) is **49,047 bytes**, SHA-256 `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`. The [v3 base](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/base_v3_atomic_publish_exact.py) is **45,678 bytes**, SHA-256 `3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631`. The [source delta](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/provenance/source-delta.diff) has SHA-256 `53dd0f4d0bc7a41584b76fa530afbdf40aabbe219aecd4c7a0c90989307d8bca`; applying its hunks in memory to the exact base reproduced the exact final caller.

Both repair manifests were byte-identical at SHA-256 `78499711a01ac70a60613b139daf36b25d512d3d121543d5f0dfb94eea30e3ad`. Both addendum manifests were byte-identical at SHA-256 `f9690f9ce0822d7f5bcc2daed385bd5461b2ed4febc824724c47ae3cc3d2f6ea`. The live validation-output inventory matched its retained closure, including paths, identities, modes, links, sizes, and hashes.

## 4. Opening and closing provenance

The exact [provenance recipe](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py) was **5,143 bytes**, SHA-256 `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`, recipe ID `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`.

Two fresh opening runs and two fresh closing runs each exited **0**, had **empty stderr**, and wrote bytes exactly equal to their stdout. All four outputs were byte-identical to one another and to both addendum repository manifests: **3,193 bytes**, SHA-256 `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445`. Every path record matched live bytes. The earlier 60-character manifest string is a superseded report transcription, not a second target.

## 5. Exact 13-path repository manifest

All entries below were regular, single-link files with physical mode `0644` and manifest logical mode `100644`. The four marked `M` were tracked modifications; the nine marked `?` were untracked. These are the complete [opening manifest’s](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/opening/recipe-run-1/provenance/manifest-run-1.json) path records.

| ClassPathBytesSHA-256 |                                                                           |         |                                                                    |
| --------------------- | ------------------------------------------------------------------------- | ------- | ------------------------------------------------------------------ |
| M                     | `.docs/system_overview/artifact_hygiene.md`                               | 14,292  | `b5e6d44c442905b95b3006f47ce96b38bc6ea7a4097aef467057163162fe1fa7` |
| M                     | `.docs/system_overview/boundaries.md`                                     | 65,156  | `643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e` |
| M                     | `.docs/system_overview/capability_probing.md`                             | 10,569  | `80857e6e6b90d01ac72f91f6c1c6d23de69824d74febd59ad0f0194e95204f95` |
| ?                     | `.docs/system_overview/evidence_verification.md`                          | 23,125  | `0980d65adf5af833fefcbb2cf0354e8154a5ee69a1eee0e595fedd40f5caa6f6` |
| M                     | `PLANS.md`                                                                | 223,126 | `187effc20ab50cf42c08e0be7b9fa45c5db9ba0a0aa66c6b8c07ac0280b52226` |
| ?                     | `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`  | 14,418  | `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f` |
| ?                     | `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt` | 3,338   | `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98` |
| ?                     | `tools/evidence_verify/layouts/a6_policy_v1.json`                         | 1,015   | `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8` |
| ?                     | `tools/evidence_verify/layouts/a6d_amendment_v1.json`                     | 856     | `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4` |
| ?                     | `tools/evidence_verify/layouts/a6d_successor_v1.json`                     | 892     | `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc` |
| ?                     | `tools/evidence_verify/registry_v1.json`                                  | 585     | `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880` |
| ?                     | `tools/evidence_verify/test_verify_v1.py`                                 | 91,210  | `721bfc331f051292f249a343fe69c2e7730d08a94bc2a5418ab9d20524bae6a5` |
| ?                     | `tools/evidence_verify/verify_v1.py`                                      | 40,121  | `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c` |

## 6. Four independent perspectives

Auditors **1–3 started concurrently** after opening provenance matched. Auditor **4 started after auditor 1 closed**. Each received the same exact manifest, caller and delta identities, repair and addendum manifest hashes, current contract, and non-goals. No start retry was needed. They returned reports to the parent; none wrote a file, ran Git, or created a nested subagent.

| AuditorOperands and findingLimits |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                                            |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------ |
| `/root/contract_authority`        | Inspected `PLANS.md`, governing docs, contract test, reconnaissance decision, implementation report, and addendum. Found one 37-field authoritative v2 contract and no authority widening. Evidence: [contract:112 (line 112)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:112>), [test:1393 (line 1393)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/test_verify_v1.py:1393>), [PLANS:3075 (line 3075)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/PLANS.md:3075>).                                                                                                                            | Did not execute caller or tests.                                                           |
| `/root/caller_state`              | Inspected the complete caller and source delta. Found one complete stage, one exclusive whole-directory commit, foreign-bundle non-attribution, and postcommit non-downgrade. Evidence: [caller:564 (line 564)](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py:564), [caller:607 (line 607)](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py:607), [caller:1030 (line 1030)](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py:1030). | Did not run the parent-owned regressions.                                                  |
| `/root/validation_provenance`     | Inspected 89 repository tests, 59 contract mutations, 17 bundle causals, 12/31/11 sources and records, relocation deltas, attempt indexes, and eight compatibility bundles. Found no material assertion change or counted failed attempt. Evidence: [test:1557 (line 1557)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/test_verify_v1.py:1557>), [relocation record](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-closeout-addendum-643fc7d12dd2-vf2cjujv/provenance/harness-relocation.json), [attempt index](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-closeout-addendum-643fc7d12dd2-vf2cjujv/provenance/addendum-attempt-index.json).                 | Reused harness assertions were a conditional concern until the parent’s fresh runs passed. |
| `/root/security_artifacts`        | Inspected descriptor and no-follow behavior, capability probe, process boundary, inventories, records, redaction, and survivors. Found no blocking security or artifact defect. Evidence: [caller:142 (line 142)](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py:142), [caller:875 (line 875)](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py:875), [output inventory](/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/provenance/output-root-inventory.json).                    | Static and retained-evidence review; parent replayed mutating audit-owned causals.         |

Their reports had no substantive disagreement. The two conditional or clarifying observations are resolved in §§10 and 23.

## 7. Contract and authority adjudication

The sole authoritative trusted-host v2 block is in `.docs/system_overview/evidence_verification.md`. `PLANS.md`, artifact hygiene, capability probing, and boundaries refer to it without defining another writer. The test validates **37 exact keys, types, values, canonical JSON, one authority marker, and consumer references**; test 89 exercises **59 distinct in-memory mutations** and passed fresh.

Model C means publication of the complete three-file bundle by one exclusive directory rename. Model E is the stated trusted, stable output-ancestry premise through the consumer’s opening. The docs consistently exclude hostile, shared, remote, and uncoordinated mover cases. They make no race-proof lexical-custody, crash-durability, atomic loaded-interpreter-object, production-attestation, product-readiness, execution, commit, or publication-authority claim. The verifier and caller produce **evidence and projection only**. No current or target ES authority widening was found.

## 8. Caller and state-machine adjudication

The exact caller checks the destination and output relationships, ownership, modes, physical containment, and exclusive-rename capability before accepting a record destination. Containment includes target, package, candidate parent, TMPDIR, caller evidence root, and interpreter parent. When the exact supplied caller runs from `REPAIR_V4_ROOT/source`, its derived evidence root is `REPAIR_V4_ROOT`; an audit copy derives its own copy root, so the audit outputs were kept physically disjoint from **both**.

The caller checks pinned interpreter bytes and posture, source, registry, layout, candidate, snapshots, and launch arguments. It launches verifier source **by value** using isolated `-I -S -B -c`, a closed environment, `shell=False`, and closed inherited descriptors. There is no hidden fallback.

For output, it creates one private `0700` sibling stage containing **exactly** `<name>.json`, `<name>.stdout`, and `<name>.stderr`. Each file is regular, single-link, `0600`, closed, fsynced, and reobserved by bytes and identity. All acceptance-bearing checks precede the sole commit: one root-relative `renameatx_np(RENAME_EXCL)` of that complete stage to the absent bundle-parent name. A foreign arbitrary or accepted-looking final bundle stays unchanged and is never attributed to this invocation. A retry after a precommit failure uses a fresh stage; a retry after success cannot republish over the final bundle. Postcommit hook, close, and shared-stdout failures cannot downgrade acceptance. Shared stdout is a best-effort four-field projection, not an authority check.

The v4 schema retains the v3 **25 top-level field names**: `argv_shape`, `argv_shape_sha256`, `atomic_loaded_object_binding`, `candidate`, `environment`, `errors`, `exit`, `interpreter`, `interpreter_trust_model`, `launch_protocol`, `layout_expected_sha256`, `outcome`, `package_root`, `registry_expected_sha256`, `schema`, `shared_or_adversarial_host_supported`, `snapshots`, `source`, `stderr_sha256`, `stderr_size`, `stdout_sha256`, `stdout_size`, `target`, `transient_trusted_principal_replacement_covered`, and `verifier_child_launched`. The versioned change is that `outcome=accepted` is attributable only after whole-bundle publication.

Two prepublication failures need precise wording. `invalid_record_destination` deliberately gives CLI exit **1** with fixed `RECORD_DESTINATION_PARENT` on stderr and **no record**: its `0750` parent is not a valid output destination. The injected parent replacement is caught as `RECORD_PARENT_RACE` through `SystemExit`, also with **no committed record or shared projection**. Both are nonaccepted and nondisclosing; neither yields canonical v4 JSON. With a valid destination, a normal forced source mismatch produced a **canonical rejected v4 bundle**, exit **2**, and empty process stderr.

## 9. Stable ancestry and mover causal

The supported-local qualification assumes every principal with rename authority over the output ancestry is trusted and keeps that ancestry stable from preflight through evidence-consumer opening. The [contract:153–163 (line 153)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:153>) states this premise; the [reconnaissance decision](/Users/ds/Downloads/ES-evidence-verification-v1-record-custody-reconnaissance-fg101qmu/design_decision.json) records Model C plus that explicit dependency.

The fresh displaced-grandparent causal passed: moving `records/` before publication made that attempt nonqualifying, and a subsequent attempt with stable ancestry succeeded. This is **unsupported-host boundary evidence**, not a supported-local success under a hostile mover. Model C is not claimed to defeat an uncoordinated ancestry move at every race interleaving.

## 10. Harness relocation

The retained addendum’s four unified deltas alter fixture roots, a copied predecessor-input path, and one nested Python call from `-B` to `-I -S -B`. Their causal assertions are unchanged. The added flags change interpreter isolation, but the invalid-destination preflight still occurs before verifier execution and retained its expected fixed classification.

I made audit-owned relocated copies and independently ran them against a **byte-exact caller copy**, rechecking its SHA-256 before each group. A first audit compatibility attempt failed because my copied accepted-looking collision exemplar occupied the same `final-a6d-1` name needed by the compatibility run. I retained that failed attempt separately, gave compatibility its own audit-owned output root, and reran successfully. No supplied root was written. The producer’s earlier-source negatives, the addendum’s first missing-exemplar bundle attempt, its first postcommit observation wrapper, and this audit-owned collision attempt were **excluded** from qualifying pass counts.

The addendum’s reconstructed opening-gate summary labels itself non-contemporaneous and was treated as non-authoritative. The exact recipe and live bytes supplied independent opening and closing provenance.

## 11. Repository tests

Pinned Python 3.13.4 ran with `-I -S -B`, C locale, `PYTHONDONTWRITEBYTECODE=1`, private audit TMPDIRs, and no bytecode creation.

| RunResultIdentity check     |                                      |                                 |
| --------------------------- | ------------------------------------ | ------------------------------- |
| Test 89 alone               | 1 passed; 0 failures, errors, skips  | Trusted-host contract test      |
| Complete suite, umask `077` | 89 passed; 0 failures, errors, skips | Tests 01–89, each once          |
| Complete suite, umask `022` | 89 passed; 0 failures, errors, skips | Same exact 89-test identity set |

The [fresh logs](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/validation/repo-suite077.stderr) and their `022` counterpart are retained in the audit root.

## 12. Exact 12 caller-negative results

All twelve expected classifications passed against caller SHA-256 `643fc7…27bf5`; there was no unexpected pass or rejection.

| CaseExact result                  |                                                                 |
| --------------------------------- | --------------------------------------------------------------- |
| `wrong_interpreter_hash`          | rejected — `INTERPRETER_PROVENANCE`                             |
| `wrong_interpreter_size`          | rejected — `INTERPRETER_SIZE`                                   |
| `source_mismatch`                 | rejected — `SOURCE_PROVENANCE`                                  |
| `registry_result_mismatch`        | rejected — `REGISTRY_RESULT_PROVENANCE`                         |
| `layout_result_mismatch`          | rejected — `LAYOUT_RESULT_PROVENANCE`                           |
| `package_target_boundary`         | rejected — `PACKAGE_TARGET_CONTAINMENT`                         |
| `snapshot_uncertainty`            | rejected — `SNAPSHOT_UNCERTAINTY`                               |
| `snapshot_replacement`            | rejected — `SNAPSHOT_CHANGED`                                   |
| `unsupported_snapshot_capability` | rejected — `SNAPSHOT_CAPABILITY`                                |
| `regular_file_depth13`            | rejected — `SNAPSHOT_DEPTH_LIMIT`                               |
| `invalid_record_destination`      | rejected — `RECORD_DESTINATION_PARENT`; CLI exit 1, no record   |
| `record_parent_replacement`       | rejected — `RECORD_PARENT_RACE`; caught `SystemExit`, no record |

The first ten emitted canonical nonaccepted v4 records with matching `0600` sidecars. Rejected records can truthfully contain `exit=0` when the verifier child passed but a later caller provenance check failed; the nonaccepted outcome and error class remain decisive. The last two fail before a usable record commit. The [fresh summary](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/caller/validation/caller-negatives-v4-final.json) records all twelve.

## 13. Exact 31 descriptor-snapshot results

| CasesExact results                                                                                       |                                           |
| -------------------------------------------------------------------------------------------------------- | ----------------------------------------- |
| `stable_tree_twice`; `stable_tree_twice_and_canonical_repeat`; `empty_directory`; `nested_regular_files` | accepted; repeat canonical bytes equal    |
| `final_root_symlink`; `symlinked_root_ancestor`                                                          | rejected — `DIRECTORY_SYMLINK_OR_TYPE`    |
| `symlink_entry`; `special_file_fifo`                                                                     | rejected — `SNAPSHOT_UNSUPPORTED_TYPE`    |
| `regular_file_hardlink`                                                                                  | rejected — `SNAPSHOT_HARDLINK`            |
| `file_replacement_between_observe_open`                                                                  | rejected — `SNAPSHOT_FILE_OPEN_RACE`      |
| `file_replacement_after_open`; `in_place_size_mutation_during_read`                                      | rejected — `SNAPSHOT_FILE_HELD_RACE`      |
| `directory_replacement_during_traversal`                                                                 | rejected — `SNAPSHOT_DIRECTORY_HELD_RACE` |
| `root_replacement_during_traversal`                                                                      | rejected — `SNAPSHOT_ROOT_HELD_RACE`      |
| `entry_disappearance`                                                                                    | rejected — `FileNotFoundError`            |
| `entry_type_change`                                                                                      | rejected — `SNAPSHOT_FILE_OPEN_RACE`      |
| `mode_change`; `link_count_change`                                                                       | rejected — `SNAPSHOT_FILE_HELD_RACE`      |
| `per_file_byte_limit`                                                                                    | rejected — `SNAPSHOT_FILE_LIMIT`          |
| `aggregate_byte_limit`                                                                                   | rejected — `SNAPSHOT_TOTAL_LIMIT`         |
| `file_count_limit`                                                                                       | rejected — `SNAPSHOT_FILE_COUNT_LIMIT`    |
| `directory_count_limit`                                                                                  | rejected — `SNAPSHOT_DIRECTORY_LIMIT`     |
| `depth_limit`                                                                                            | rejected — `SNAPSHOT_DEPTH_LIMIT`         |
| `path_byte_limit`                                                                                        | rejected — `SNAPSHOT_PATH_LIMIT`          |
| `absolute_root_byte_limit`                                                                               | rejected — `SNAPSHOT_ROOT_LIMIT`          |
| `unsupported_dir_fd`; `unsupported_no_follow`; `unsupported_descriptor_listing`                          | rejected — `SNAPSHOT_CAPABILITY`          |
| `descriptor_listing_runtime_failure`                                                                     | rejected — `NotImplementedError`          |
| `test_hook_inaccessible_from_normal_main`; `no_watched_root_write`                                       | accepted causal assertions                |

These are **31** individually named outcomes. The [fresh matrix](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/caller/causals/successor-snapshot-matrix-final.json) retains their records; all expected classifications matched the retained addendum comparison.

## 14. Exact 11 depth results

| CaseExact result                                                   |                                                                 |
| ------------------------------------------------------------------ | --------------------------------------------------------------- |
| `root_only`; `file_depth_1`; `directory_depth_12`; `file_depth_12` | accepted                                                        |
| `directory_depth_13`; `file_depth_13`; `child_of_depth_12`         | rejected — `SNAPSHOT_DEPTH_LIMIT`                               |
| `blocking_audit_shape`                                             | v3 base and v4 successor both rejected — `SNAPSHOT_DEPTH_LIMIT` |
| `depth_before_file_stat_open_read`                                 | rejected — `SNAPSHOT_DEPTH_LIMIT`; zero over-depth observations |
| `depth_before_directory_descent`                                   | rejected — `SNAPSHOT_DEPTH_LIMIT`; zero over-depth opens        |
| `path_bytes_distinct`                                              | rejected — `SNAPSHOT_PATH_LIMIT`                                |

The [fresh depth record](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/caller/causals/depth-boundaries-final.json) contains all eleven. The addendum’s flattened comparison leaves the nested `blocking_audit_shape` classification blank; its underlying record and this fresh run both show the two expected rejections.

## 15. Bundle, collision, retry, and postcommit causals

All **17** [bundle-publication tests](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/validation/test_bundle_causals.py.stderr) passed with no error or skip. They exercised: complete commit and same-name retry; arbitrary and canonical accepted-looking foreign bundles; a foreign bundle arriving at exclusive rename; fresh retry after precommit failure; incomplete or partial writes; precommit event, file-fsync, directory-fsync, and reobservation faults; capability failure before stage; output containment and symlink cases; the out-of-contract mover; hook guard; and the three postcommit cases.

The three postcommit observations were **hook fault, shared-stdout failure, and parent-close failure** after successful commit. Each left the accepted bundle accepted. Foreign bundles remained byte-for-byte unchanged and unattributed. Each accepted bundle checked had exactly three files, canonical v4 JSON, empty errors, matching sidecar hashes and sizes, no remaining stage, and the mandatory nonclaims.

## 16. Sealed A6D

`final-a6d-1` and `final-a6d-2` both passed as accepted sealed bundles. Each reported manifest SHA-256 `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`; their verifier stdout bytes matched at SHA-256 `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`. The watched A6D target snapshot remained **829 entries**, SHA-256 `375b2bf996a23367b8a07a8e1f51db0d7b4cc75a27a6e0844bc55c53a1a5073d`.

## 17. Amendment

`final-amend-1` and `final-amend-2` both passed as accepted sealed bundles. Each reported manifest SHA-256 `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`; their verifier stdout bytes matched at SHA-256 `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`. The watched amendment target snapshot remained **39 entries**, SHA-256 `8919b9369d7946c6b609f2e5c4e985cd28ebcdfa32ce18ed87354ff142c98774`.

## 18. Synthetic A6

`final-a6-pre-1` and `final-a6-pre-2` passed as accepted pre-seal bundles with identical verifier stdout SHA-256 `044d55daadf00f4f99c7a1b02242a8a46d2b4d7aacdc81b8636d248774a3c586`. `final-a6-sealed-1` and `final-a6-sealed-2` passed as accepted sealed bundles with identical verifier stdout SHA-256 `9317eed411ac55481597314411f667b9ecb90164f4a86cd03205a56436fda92e`. All four referred to this audit-owned fixture’s deterministic manifest SHA-256 `a56a347857cd3d0f20a1b99ebcdce579f5bfebab7b218d10604a2c88e5c79a8a`. The fixture’s original payload stayed unchanged; sealing added only the manifest and its checksum.

## 19. SEC-02

The target-script marker was absent throughout. A direct attempt to run `verify_v1.py` as a script exited **2** with `INVOCATION`; it did not load the target script. The successful caller path used verifier source by value. No atomic loaded-interpreter-object claim was made.

## 20. Schema, disclosure, no-write, process, and artifact findings

All eight fresh accepted compatibility bundles were canonical 25-field v4 records with `outcome=accepted`, `exit=0`, `errors=[]`, matching sidecars, and exactly three `0600` single-link files in `0700` directories. Their explicit nonclaim fields `atomic_loaded_object_binding`, `transient_trusted_principal_replacement_covered`, and `shared_or_adversarial_host_supported` were all `false`. Shared stdout contained exactly `errors`, `exit`, `outcome`, and `record_role`.

The checked normal caller outputs and bundle content contained no traceback, forbidden absolute private path, stage name, or secret-token pattern. Repository and supplied-root inventories at close matched their openings exactly, including inode, mode, link count, size, and SHA-256 where applicable. A6D, amendment, and package snapshots matched their retained read-only baselines. No watched-root write was observed. Fresh process inspection found **zero** surviving caller/verifier processes; `lsof +D` found **no** open descriptor under the audit, repair, output, or addendum roots. No stage, bytecode, or cache artifact remained.

## 21. Prior-finding reconciliation

The historical independent audit found that a destination ancestor could move between final rebinding and exclusive rename, leaving an accepted report whose declared path was absent. The present v4 contract does **not** claim to make hostile ancestry moves race-proof. It qualifies Model C whole-bundle publication only under Model E’s explicit stable-ancestry precondition; the mover case is documented and tested as nonqualifying unsupported-host evidence.

The malformed prior 60-character manifest text was a transcription defect. Four fresh exact-recipe captures plus the two retained addendum captures establish the one corrected 64-character manifest. Earlier producer records tied to superseded caller hashes, the addendum’s failed fixture/instrumentation attempts, and my failed audit-owned compatibility harness attempt were retained or disclosed and excluded from passing evidence.

## 22. Severity-ranked residual findings

**No blocking finding** remains in contract/authority, caller correctness, filesystem/process/security, validation, provenance, or artifacts.

| SeverityClassificationDisposition |                                                                                                    |                                                                                                      |
| --------------------------------- | -------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| Report-only                       | Stable ancestry is a required supported-local precondition; hostile movers remain unsupported.     | Explicit in governing docs and tested as nonqualifying.                                              |
| Report-only                       | Invalid destination and displaced parent produce no canonical record.                              | Fixed-reason, nondisclosing prepublication failures; the contract does not promise a record there.   |
| Report-only                       | Retained addendum harnesses reused producer assertions, and its opening summary was reconstructed. | Fresh parent execution, record inspection, and four exact recipe runs supplied independent evidence. |
| Report-only                       | Superseded and failed harness attempts exist.                                                      | Kept separate from qualification; corrected audit-owned compatibility run passed.                    |

## 23. Minority findings and parent resolution

There was no substantive minority finding. Auditor 3 conditioned adequacy on fresh independent execution; §§11–19 satisfy that condition. Auditor 2 emphasized that preflight failures must not be described as canonical rejected records; §8 adopts that precise distinction. The parent found no additional blocking issue.

## 24. Inspection limits and explicit nonclaims

This audit qualifies the **exact bytes and bounded supported-local behavior** inspected here. It does not establish hostile/shared-host custody, permanent lexical pathname stability, crash or power-loss durability, machine attestation, atomic binding to a loaded interpreter object, correctness of Repair 10I, product readiness, A6 readiness, or authority to stage, commit, push, publish, or restart anything. Generated records and shared stdout are evidence/projection for a consumer that independently opens and validates the complete bundle.

## 25. Audit-created paths and cleanup

The atomically allocated private audit root is:

`/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5`

It retains opening and closing recipe continuations, an opening watched-root inventory, byte-exact caller/base copies, relocated harness sources and deltas, fresh validation logs and records, the failed compatibility attempt separately, and eight audit-owned compatibility bundles. The [cleanup record](/Users/ds/Downloads/ES-evidence-verification-v1-atomic-bundle-v4-independent-audit-643fc7d12dd2-ym76amx5/reports/cleanup.json) lists the ten empty private TMPDIRs, copied collision exemplar, and predecessor fixture copy removed after use. `AUDIT_ROOT/tmp` and `caller/tmp` are empty. The final retained audit inventory has **36 directories, all&#x20;****`0700`**, and **121 regular single-link files, all&#x20;****`0600`**; no other file type, stage, or cache remains.

## 26. Closing equality

Both closing recipe continuations matched both opening continuations and the corrected canonical target byte-for-byte. Closing Git checks repeated the exact branch, HEAD, tree, sole parent, absent upstream, 13-path status, empty staged and unmerged state, full **477-object** inventory, and tracked diff SHA-256 `d69be3d1c16307c030613ce33329b5515715343e5fe1f9c60467590a18b69f24`. `git diff --check` passed; ignored-artifact count was zero.

Full closing read-only inventories of the repository, repair root, output root, addendum root, reconnaissance root, and historical audit root matched the audit opening inventories **exactly**.

## 27. Explicit action confirmations

Repository mutation **not performed**. Supplied-evidence mutation **not performed**. Repair **not performed**. Staging **not performed**. Commit **not performed**. Push **not performed**. A6 restart **not performed**. Product or live services **not invoked**. Network contact **not performed**. Nested subagents **not created**.
