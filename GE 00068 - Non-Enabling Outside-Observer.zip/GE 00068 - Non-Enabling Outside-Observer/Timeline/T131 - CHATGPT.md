## Assessment

The reconciliation succeeded. The audit-input gap is closed without changing the implementation or its evidence:

* Exact recipe source:
  `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py`
* Recipe source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`
* Exact retained canonical manifest:
  `/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/manifest-run-1.json`
* Manifest SHA-256:
  `5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57`
* Complete tracked binary-diff SHA-256:
  `7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070`

The manifest contains the expected 13 complete file identities—four tracked modifications and nine untracked additions—and every recorded path, classification, mode, size, and SHA-256 matches the live worktree. 

The duplicate recipe and manifest copies do not create unresolved ambiguity. The required selection rule chooses the recipe beneath `audit-repair-v2/provenance`, while the repair-v2 human-readable report explicitly selects `manifest-run-1.json`. 

Audit v3 is permanently nonqualifying for two independent reasons: it stopped before correctness inspection because the exact paths were not supplied, and it ran an initial Git command in the forbidden primary checkout. It must not be resumed. 

No implementation repair, revalidation, or report amendment is needed. The next gate is a **fourth fresh independent audit** using the exact paths directly in the prompt.

One procedural refinement is important: the recipe creates its output with exclusive mode and only permits `manifest-run-1.json` or `manifest-run-2.json`. Opening provenance can use the audit root itself as `--continuation`; closing provenance must use a fresh continuation subroot so it does not attempt to overwrite the opening outputs. The exact execution contract and environment are now fully recovered. 

## Codex prompt: fourth fresh independent audit

```text
Objective

Perform a fourth, fresh, read-only independent audit of the repaired Evidence
Verification v1 implementation.

Do not repair or modify the implementation.

The third audit returned AUDIT_PROVENANCE_MISMATCH before correctness
inspection because its prompt did not directly supply the exact retained
provenance recipe-source and canonical-manifest paths. A later read-only input
reconciliation recovered and cross-checked those exact inputs.

Audit v3 also executed an initial Git command in the forbidden primary
checkout. Audit v3 is permanently nonqualifying and must not be resumed or
used as a correctness result.

Return exactly one verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

No repository mutation.
No formatting.
No repair.
No repository cleanup.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, live-service invocation, network contact, or Linux binary
execution.

No nested subagents.

## 1. Exact audit inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Repair-v2 implementation report:

EVIDENCE/audit-repair-v2/closeout/implementation-report-v2.json

Human-readable repair-v2 report:

EVIDENCE/audit-repair-v2/closeout/implementation-report-v2.md

Exact provenance recipe source:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Exact recipe source size:

5143 bytes

Exact recipe source SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected recipe ID:

execution-substrate.evidence-verification-v1.final-patch-provenance.v1

Exact retained canonical manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/manifest-run-1.json

Exact retained manifest size:

3192 bytes

Expected canonical-manifest SHA-256:

5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57

Expected tracked binary-diff SHA-256:

7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070

Exact Python interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- version: 3.13.4
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Prior independent audits, read-only:

AUDIT_V1=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

AUDIT_V2=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v2

Nonqualifying audit v3, read-only:

AUDIT_V3=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v3

Audit-v3 report:

AUDIT_V3/closeout/report.md

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v4

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and process boundary

Set:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every direct audit Git invocation must be exactly rooted as:

git -C "$IMPL_R" ...

and inherit:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1

The supplied provenance recipe may invoke Git internally only because its exact
source has been separately verified. Its source must show that every Git call
uses:

git -C <root>

with cwd equal to that same root.

No audit subagent may execute Git.

Do not execute Git in:

- PRIMARY_R;
- a Repair 10I candidate;
- A6D;
- A6D_AMEND;
- EVIDENCE;
- AUDIT_V1;
- AUDIT_V2;
- AUDIT_V3;
- AUDIT_ROOT.

Do not use an implicit-current-directory Git invocation.

Record every parent Git argv, cwd, and relevant environment.

Any nonconforming Git operation is an audit-process blocker. Disclose it
immediately; do not silently continue.

## 3. Audit root

Require AUDIT_ROOT absent.

Create it under umask 077 with:

opening/
provenance/
perspectives/
validation/
findings/
closeout/

All audit outputs remain beneath AUDIT_ROOT.

Opening provenance outputs use:

AUDIT_ROOT/provenance/

Closing provenance must use a fresh continuation subtree because the recipe
creates outputs exclusively and cannot overwrite opening outputs:

CLOSING_CONTINUATION=$AUDIT_ROOT/closeout/provenance-replay-v1

At closing, require CLOSING_CONTINUATION absent before creation, then create:

CLOSING_CONTINUATION/provenance/

Remove only audit-owned temporary fixture roots. Do not remove, chmod,
normalize, rewrite, or restore metadata on a repository or supplied-evidence
object.

## 4. Opening repository gate

Require IMPL_R:

- physical root equals lexical path;
- root is a real directory and not a symlink;
- branch:
  codex/evidence-verification-v1;
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c;
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338;
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular;
- every working-tree mode 0644;
- every logical mode 100644;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no Git operation marker or lock;
- no path outside the expected set.

Expected paths:

1. PLANS.md
2. .docs/system_overview/boundaries.md
3. .docs/system_overview/artifact_hygiene.md
4. .docs/system_overview/capability_probing.md
5. .docs/system_overview/evidence_verification.md
6. tools/evidence_verify/verify_v1.py
7. tools/evidence_verify/registry_v1.json
8. tools/evidence_verify/layouts/a6d_successor_v1.json
9. tools/evidence_verify/layouts/a6d_amendment_v1.json
10. tools/evidence_verify/layouts/a6_policy_v1.json
11. tools/evidence_verify/test_verify_v1.py
12. tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt
13. tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt

Stop before correctness inspection on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Exact input identity gate

Before running the recipe, inspect RECIPE and EXPECTED_MANIFEST through
no-follow, stable before/read/after observations.

Require RECIPE:

- exact absolute physical path stated above;
- regular;
- single-link;
- size 5143;
- SHA-256:
  bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333.

Require EXPECTED_MANIFEST:

- exact absolute physical path stated above;
- regular;
- single-link;
- size 3192;
- SHA-256:
  5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57.

Require the manifest to contain:

- recipe ID:
  execution-substrate.evidence-verification-v1.final-patch-provenance.v1;
- exactly 13 files;
- exactly four tracked_modified;
- exactly nine untracked;
- exact expected path set;
- regular type throughout;
- logical mode 100644 throughout;
- complete size and SHA-256 for every file;
- tracked binary-diff SHA-256:
  7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070.

Inspect RECIPE source and require:

- exact `--root`, `--continuation`, and `--output` arguments;
- root and continuation must be absolute physical paths;
- output must be under `<continuation>/provenance/`;
- output basename must be `manifest-run-1.json` or `manifest-run-2.json`;
- output is created with exclusive mode;
- output mode is set to 0600;
- identical canonical bytes are emitted to stdout;
- every internal Git operation uses `git -C <root>`;
- branch, HEAD, tree, absent upstream, tracked and untracked set are checked;
- paths are sorted by UTF-8 bytes;
- tracked diff command is exactly:
  git diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --
- canonical JSON is compact, sorted-key ASCII plus one LF;
- canonical output contains no timestamp, random value, hostname, username, or
  machine-specific absolute path.

Stop on any mismatch:

AUDIT_PROVENANCE_MISMATCH

## 6. Opening provenance reproduction

Before running:

- require AUDIT_ROOT/provenance/manifest-run-1.json absent;
- require AUDIT_ROOT/provenance/manifest-run-2.json absent;
- require all stdout/stderr capture targets absent.

Run exactly from cwd IMPL_R with environment bindings:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Run 1 argv:

"$PYTHON" -I -B "$RECIPE" \
  --root "$IMPL_R" \
  --continuation "$AUDIT_ROOT" \
  --output "$AUDIT_ROOT/provenance/manifest-run-1.json"

Run 2 argv:

"$PYTHON" -I -B "$RECIPE" \
  --root "$IMPL_R" \
  --continuation "$AUDIT_ROOT" \
  --output "$AUDIT_ROOT/provenance/manifest-run-2.json"

Capture stdout and stderr separately beneath AUDIT_ROOT/provenance without
altering the recipe argv.

Require:

- both exits 0;
- stderr empty;
- both output manifest files byte-identical;
- both stdout byte streams byte-identical;
- each stdout stream byte-identical to its corresponding output file;
- output files byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57;
- tracked binary-diff:
  7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070;
- exact 13-path set;
- exact four/nine classifications;
- every live file identity matches the manifest;
- no repository or supplied-evidence mutation.

Stop before source correctness inspection on any difference:

AUDIT_PROVENANCE_MISMATCH

## 7. Audit-v3 disposition

Inspect AUDIT_V3/closeout/report.md read-only.

Require the final audit report to state:

- audit v3’s repository opening gate passed;
- correctness inspection did not begin;
- v3 lacked the exact recipe and manifest paths in its supplied input;
- v3 executed an initial Git command in PRIMARY_R;
- the effect on primary-checkout Git metadata was not bracketed;
- v3 is permanently nonqualifying;
- v3 was not resumed;
- this audit does not inherit a correctness result from v3.

Do not treat v3 as evidence for or against current implementation correctness.

## 8. Audit perspectives

Only after opening provenance passes, create exactly four bounded read-only
audit perspectives.

Subagents may inspect source and audit-owned copies but execute no Git and
perform no repository write.

No nested subagents.

Roles:

1. Contract and authority auditor.
2. Verifier correctness and parser/resource auditor.
3. Test and validation adequacy auditor.
4. Security, filesystem, capability, and artifact auditor.

Every perspective receives:

- the exact canonical patch manifest;
- exact verifier, registry, and layout identities recovered from the manifest;
- first-audit EV-01 through EV-09 ledger;
- second-audit residual finding ledger;
- repair-v2 implementation report;
- architecture target and non-goals;
- audit-v3 nonqualification.

Retry a failed perspective once.

Do not replace missing required coverage with silent parent inference.

Preserve minority findings.

## 9. Authority and whole-patch audit

Audit the complete 13-path patch.

Require:

- verifier remains an ES-owned Bounded slice rule;
- verifier output remains evidence/projection only;
- no readiness, product, runtime, admission, orchestration, durable-state, or
  execution authority;
- layout specs remain structural declarations only;
- closeout and later independent audit retain readiness adjudication;
- no self-verification;
- no evidence-child-local verifier authority;
- no runtime caller-supplied layout;
- no verifier-amendment chain;
- no product API, schema, route, module, service, or runtime-contract change;
- repair-v2 does not widen authority or filesystem permission.

The selected architecture is an ES-owned committed external verifier whose
exact source is independently audited before first commit; it never certifies
its own repository or evidence container. :contentReference[oaicite:4]{index=4}

Generated evidence and proof tooling remain non-authoritative. :contentReference[oaicite:5]{index=5}

## 10. Full verifier correctness audit

Inspect the complete current `verify_v1.py`, not only repair-v2 changes.

Re-audit every first-audit and second-audit mechanism.

### 10.1 Physical boundaries

Confirm and independently test:

- descriptor-bound package/target identity;
- physical ancestor-chain checks;
- case-alias resistance;
- candidate identity and parent ancestry;
- symlink and hardlink handling;
- no permissive pathname fallback;
- opening/closing identity stability.

### 10.2 Literal-LF grammar

Confirm and independently test rejection of:

- vertical tab;
- form feed;
- NEL;
- CRLF;
- missing final LF;
- extra blank line;
- Unicode line and paragraph separators.

Require `MANIFEST_CANONICAL`, canonical one-line stdout, empty stderr, and no
traceback.

### 10.3 Bounded package JSON

Confirm:

- source-byte limit;
- nonrecursive lexical nesting preflight;
- string and escape handling;
- depth bounds;
- duplicate-key and float rejection;
- invalid UTF-8 behavior;
- no RecursionError traceback;
- one canonical failure line.

### 10.4 Bounded manifest reader

Audit and instrument:

1. stat/identity bound before read;
2. derived hard maximum manifest size;
3. rejection above maximum before body read;
4. incremental literal-LF reading;
5. fixed line ceiling;
6. header/count validation before row allocation;
7. count bound before row allocation;
8. field and lexical limits before path decoding;
9. encoded-path bound before base64 decoding;
10. decoded-path and segment bounds before storage;
11. immediate duplicate and ordering rejection;
12. first-excess-row rejection;
13. exact missing-row/trailing-data handling;
14. absence of whole-input `read_bytes`, broad split, or equivalent
    amplification.

Use small audit-owned fixtures and instrumented read/decode seams. Do not
create a large manifest.

### 10.5 Seal-file and aggregate accounting

Audit and instrument:

- pre-seal candidate stat and byte bound before read;
- sealed manifest stat and bound before read;
- sidecar exact-size bound before read;
- manifest and sidecar included in structural scan accounting;
- payload size checked before read;
- aggregate budget checked before the overflow-causing read;
- both stability traversals bounded;
- exact-boundary behavior;
- no object read merely to discover that it exceeds the limit.

Require real A6D and amendment children to remain within admitted limits.

### 10.6 Decimal parser

Independently test:

- exact second-audit malformed suffix;
- trailing ASCII;
- whitespace;
- sign;
- underscore;
- decimal point;
- exponent;
- NUL/control;
- non-ASCII digit;
- illegal leading zero;
- excessive lexical length;
- exact maximum and maximum plus one.

Require:

- malformed lexical token:
  `MANIFEST_CANONICAL`;
- canonical numeric resource overflow:
  the declared resource/closure class.

### 10.7 Spec-path prevalidation

Across required roots, required directories, required files, and optional
subtree roots, test:

- absolute path;
- empty segment;
- dot;
- dot-dot;
- slash;
- backslash;
- control/NUL;
- too many segments;
- excessive encoded bytes;
- invalid required-file mode;
- malformed optional-subtree root.

Instrument target filesystem entry points and require zero target filesystem
calls for each invalid spec.

Require exact spec-schema rejection rather than `IO_OR_RACE`.

### 10.8 Capability and error boundary

Confirm:

- behavioral capability preflight;
- canonical `IO_OR_RACE` uncertainty;
- exit 7;
- no traceback;
- no pathname fallback;
- canonicalization of capability failure arising after preflight;
- bounded hashing and traversal;
- no writes;
- no child process;
- no network;
- no target-code import.

## 11. Test and validation audit

Inspect the complete current test source and discover the exact test set.

Expected:

- 59 tests;
- four implementation runs:
  - twice under umask 077;
  - twice under umask 022;
- zero failure;
- zero error;
- zero skip.

Independently run the complete suite:

1. twice under umask 077;
2. twice under umask 022.

Require:

- identical discovered test identities;
- 59 passes every run;
- zero skip;
- no repository artifact;
- deterministic relevant output.

Audit that tests independently and causally cover:

- early manifest-size rejection;
- count-before-allocation;
- line and encoded-path bounds;
- decode-after-bound ordering;
- seal-file budget;
- sidecar exact-size handling;
- aggregate exact boundary and one-byte overflow;
- complete decimal token consumption;
- lexical versus numeric classification;
- malformed spec rejection before target filesystem access;
- all prior EV-01 through EV-08 regressions;
- umask independence;
- isolated missing-root, expected symlink, and expected FIFO mechanisms.

Flag circular tests whose expected results are generated solely through the
same implementation path without an independent oracle.

## 12. Fresh compatibility validation

Use exact interpreter:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Require:

- version 3.13.4;
- size 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b.

Use:

- -I;
- -B;
- PYTHONDONTWRITEBYTECODE=1;
- LC_ALL=C;
- LANG=C;
- audit-owned private TMPDIR;
- no network.

Run independently:

1. AST parsing of all Python source.
2. Strict registry and all three layout specs.
3. Complete suite four times under the two umasks.
4. Sealed A6D verification twice.
5. Sealed amendment verification twice.
6. Synthetic A6 pre-seal verification twice.
7. Test-owned synthetic sealing.
8. Synthetic A6 sealed verification twice.
9. Repeated canonical-output comparisons.
10. Before/after target and verifier-package snapshots.
11. Parent-only explicitly rooted:
    git -C "$IMPL_R" diff --check
    with GIT_OPTIONAL_LOCKS=0 and GIT_CONFIG_NOSYSTEM=1.

Require real sealed children unchanged.

Require all repeated outputs byte-identical.

## 13. Registry, layouts, and repair scope

Recover exact current verifier, registry, and three layout SHA-256 values from
the reproduced canonical manifest and repair-v2 report.

Require:

- live bytes equal both;
- repair-v2 changed only:
  - tools/evidence_verify/verify_v1.py
  - tools/evidence_verify/test_verify_v1.py;
- registry and all three layout files remained byte-identical during
  repair-v2;
- complete 13-path scope remains exact.

Audit the full registry/layout semantics, not only repair-v2 scope.

## 14. Security and artifact audit

Inspect:

- descriptor and no-follow behavior;
- directory descriptor lifetime;
- ancestor traversal termination;
- candidate read stability;
- concurrent replacement handling;
- resource-amplification bounds;
- exception behavior;
- output minimization;
- no writes;
- no process/network invocation;
- no runtime layout injection.

Inspect IMPL_R for:

- `__pycache__`;
- `.pyc` or `.pyo`;
- `.pytest_cache`;
- generated manifests;
- databases;
- journals;
- locks;
- fixture roots;
- temporary outputs;
- unexpected executable modes;
- unsupported objects.

Historical fixtures must remain inert and never be imported or executed as
repository code.

## 15. Repair-evidence audit

Inspect:

- repair-v2 finding dispositions;
- vulnerable and repaired causal records;
- all four 59-test runs;
- complete test list;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded attempts;
- cleanup;
- implementation reports;
- final provenance.

Require:

- every second-audit finding explicitly and causally closed;
- no previous audit represented as qualifying changed bytes;
- final validation binds final bytes;
- no failed attempt overwritten or omitted;
- registry/layout unchanged claim supported;
- no authority or security widening.

## 16. Parent adjudication

After all four perspectives return:

1. Preserve every material finding and disagreement.
2. Distinguish:
   - provenance mismatch;
   - residual patch defect;
   - repaired patch defect;
   - pre-existing issue;
   - audit-process issue;
   - future hardening seam.
3. Reconcile all prior findings against current source and fresh causals.
4. Audit the entire 13-path patch.
5. Do not accept solely because tests pass.
6. Do not reject because the verifier is ES-local rather than a general
   cross-repository framework.
7. Perform no repair.

## 17. Closing provenance replay

Opening provenance outputs cannot be overwritten. Use a fresh continuation
subroot.

Require CLOSING_CONTINUATION absent.

Create under umask 077:

CLOSING_CONTINUATION/
CLOSING_CONTINUATION/provenance/

Require closing output and stdout/stderr capture paths absent.

Run twice from cwd IMPL_R with the same fixed environment and exact RECIPE
source.

Closing run 1:

"$PYTHON" -I -B "$RECIPE" \
  --root "$IMPL_R" \
  --continuation "$CLOSING_CONTINUATION" \
  --output "$CLOSING_CONTINUATION/provenance/manifest-run-1.json"

Closing run 2:

"$PYTHON" -I -B "$RECIPE" \
  --root "$IMPL_R" \
  --continuation "$CLOSING_CONTINUATION" \
  --output "$CLOSING_CONTINUATION/provenance/manifest-run-2.json"

Require:

- both exits 0;
- stderr empty;
- both closing output files byte-identical;
- both closing stdout streams byte-identical;
- outputs and stdout byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  5830b7fdc335ea55ee61f93dc6075129e3ee397f4c6d1f221f74f53679d41a57;
- tracked binary-diff:
  7a5c52163ed9c4b11776460dd8be819901d8d39b876c6fb0680a96d06aa2e070;
- repository identity unchanged;
- exact 13-path identities unchanged;
- staged/deleted/renamed/unmerged remain zero;
- no audit-created repository object;
- A6D and A6D_AMEND unchanged;
- AUDIT_V1, AUDIT_V2, and AUDIT_V3 unchanged.

On any difference:

AUDIT_PROVENANCE_MISMATCH

## 18. Finding format

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, pre-existing issue, or audit-process issue:
Blocking: yes | no

## 19. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use for any repository, recipe, manifest, path, byte, diff, recipe-output, or
closing-provenance mismatch.

### REJECT

Use only for a fundamental authority or decomposition defect that cannot be
repaired within the bounded 13-path tranche.

### BLOCK

Use when any repairable correctness, security, resource, validation, test,
artifact, or evidence defect remains.

### ACCEPT

Use only when:

- opening and closing provenance match;
- exact recipe inputs were supplied directly;
- every prior blocking source finding is causally closed;
- all second-audit residuals are independently closed;
- audit v3 is not reused;
- no prohibited Git operation occurred;
- authority boundaries remain sound;
- parser, filesystem, resource, and capability behavior are fail-closed;
- tests are mechanism-specific and umask-independent;
- real and synthetic compatibility checks pass;
- no artifact or report blocker remains.

## 20. Required final report

Include:

1. Verdict.
2. Exact recipe-source and retained-manifest paths used.
3. Opening and closing provenance.
4. Canonical manifest and tracked-diff SHA-256 values.
5. Repository identity.
6. All four audit perspectives and completion status.
7. Audit-v3 nonqualification.
8. Closure table for every first- and second-audit finding.
9. Authority adjudication.
10. Full verifier correctness adjudication.
11. Bounded manifest-reader adjudication.
12. Seal-file accounting adjudication.
13. Decimal classification adjudication.
14. Spec-path prevalidation adjudication.
15. Test and validation adjudication.
16. Results under umask 077 and 022.
17. Real A6D/amendment checks.
18. Synthetic pre-seal/sealed checks.
19. Security, resource, and artifact adjudication.
20. Severity-ranked residual findings.
21. Minority findings.
22. Uninspected areas and uncertainty.
23. Audit-created paths and cleanup.
24. Confirmation:
    - repository mutation not performed;
    - formatting not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - every Git command was parent-only and explicitly rooted;
    - nested subagents not created.

No repair.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

An `ACCEPT` verdict should proceed to a separate exact-byte commit gate. The commit gate may stage and commit only the accepted 13-path manifest; it cannot repair or reinterpret the patch. Any byte change returns the work to implementation and a new audit. 

### Sources

* Attached `EVIDENCE_VERIFICATION_V1_AUDIT_INPUTS_RECONCILED` response. 
* Duplicate-copy and selection analysis. 
* Exact future execution contract. 
* Audit-v3 nonqualification. 
* Selected non-recursive external-verifier architecture. 
* Proof scaffolding remains non-authoritative. 
* Independent audit requires exact recipe source and manifest inputs. 
* Exact source—not only its hash—must be available. 

**Confidence**

* Audit-input reconciliation: **0.999**
* Evidence of current implementation drift: **none found**
* Readiness for a fourth fresh independent audit: **0.998**
* Need to abandon audit v3 permanently: **0.999**
* Need for any further implementation repair before audit v4: **0.01**
* Confidence that the exact-path prompt above closes the prior provenance-input failure: **0.995**
