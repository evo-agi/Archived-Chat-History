Codex stopped at the correct boundary. The fresh A5 run did not expose a product failure or a historical-policy counterexample; it exposed a **sealed A4 semantic-extractor incompatibility with the exact A5 source layout**:

- The test itself passed.
- The suite reached semantic extraction normally.
- One exact diagnostic remained unknown solely because A4 recognizes that template only at historical source lines `1364` and `1375`, while A5 emits it at line `1706`.
- Without zero unknown diagnostics, the control cannot qualify, so running `a5-fresh` or deriving historical matrices would have produced non-authoritative evidence.

This should **not** become the historical-policy A6 amendment. That policy is still unfrozen. I recommend a narrowly named, successor-only **Repair 10I-A5S** compatibility amendment. It preserves “A6” for the actual historical-comparison redesign after the missing A5 evidence is successfully produced.

The repair should add one exact A5 template to the existing `fresh-bootstrap-logical-bytes-bound-v1` grammar—not normalize arbitrary source lines and not change repository bytes. After A5S seals, restart the evidence refresh from scratch in a new child; the failed `a5-final` run remains negative predecessor evidence only.

Pass this to Codex:

```text
Objective

Implement and seal a successor-only Repair 10I-A5S amendment that makes the
sealed semantic extractor compatible with the exact Repair 10I-A5 diagnostic
emitted by:

TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2

at the exact governed A5 source line 1706.

The current sealed A4 matcher recognizes the same typed diagnostic only at
historical source lines 1364 and 1375. The exact A5 full-suite test passed, but
A4 classified its line-1706 diagnostic as:

unknown-typed-candidate-v1

This is a source-line compatibility defect in the validation successor.

It is not:

- a product-source defect;
- a test failure;
- a Repair 10I-A6 historical-policy decision;
- permission to normalize arbitrary line numbers;
- permission to resume the failed policy-evidence refresh.

Repair 10I-A5S must preserve all existing exact grammar and boundary behavior,
add only the exact A5 source form, and prove that no unrelated diagnostic is
newly recognized.

This is a parent-only successor implementation and validation turn.

Do not edit repository source.
Do not edit A4, A5, B5, or the failed A6 policy-evidence child.
Do not implement the historical directional comparison policy.
Do not restart the A5 full-suite evidence refresh.
Do not start A6 or B6.
Do not create a ZIP, handoff, capture child, or snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or claim independent audit or acceptance.

No subagents. You are the sole writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A4 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Sealed A5 product repair

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Failed B5, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b5-closure-e260e1bb5ac4

Failed policy-evidence refresh, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-e260e1bb5ac4

Required new A5S child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- protected package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require exact A5:

- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800
- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A4:

- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800
- source T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- source inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- members:
  12
- manifest SHA-256:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

A4 binaries:

repair10-runner:
  9df605f44e2a5fa10cd8bbc9360a7709a739f209fa4bf386353c8a790ef45961

repair10-compare:
  e53c6878acddb2e601376486ee8994d73bf30f176606ca7f42dea8434ddc6f0f

repair10-semantic:
  ef378cfe85c26f1e45eb6f4a0895d58c53647c1b74a685d1636bccbb81a52a66

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the failed policy-evidence refresh to remain exact and unsealed.

Verify its bound failing inputs, including:

- a5-final exact source T/inventory;
- full-suite raw stdout and stderr;
- command result;
- terminal reconciliation;
- producer semantic envelope;
- unknown diagnostic count exactly one;
- exact unknown classification:
  unknown-typed-candidate-v1;
- exact package/test identity:
  execution-substrate /
  TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2;
- exact source line:
  1706;
- test terminal:
  pass.

Require B5 and the policy-evidence child to remain unsealed and unchanged.

Reverify A, A2, A3, Phase H, B/B2/B3/B4, and the B4 divergence
reconciliation sufficiently to establish unchanged lineage.

Require the A5S target to be absent.

Stop on any mismatch:

REPAIR10I_A5S_BASELINE_MISMATCH

## 2. Exact defect classification

Adopt:

ID:
REPAIR10I-A5S-FRESH-BOOTSTRAP-LINE-001

Type:
validation-successor exact-template compatibility defect

Severity:
HIGH for validation qualification; no product severity assigned

Classification:
source-external successor tool

Current behavior:

- Rule:
  fresh-bootstrap-logical-bytes-bound-v1
- Exact package:
  execution-substrate
- Exact test:
  TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2
- Existing recognized historical source lines:
  1364 and 1375
- Exact governed A5 source line:
  1706
- Test outcome in the failed refresh:
  pass
- A4 result:
  one unknown typed candidate, causing semantic-integrity and qualification
  failure

Required behavior:

- retain all existing exact historical forms;
- add the exact governed A5 full-text form at line 1706;
- canonicalize only the already governed in-bound logical_bytes token;
- preserve entries and depth exactly;
- preserve package, test, subtest, source file, source line, punctuation, field
  order, and remaining text;
- keep values at or above 134217728 visible and blocking;
- keep malformed, signed, leading-zero, overflow, partial, appended, wrong-line,
  wrong-package, and wrong-test forms unknown and blocking.

Do not introduce:

- generic source-line normalization;
- a source-line range;
- arbitrary decimal replacement;
- a package-wide or test-wide fallback;
- prefix matching;
- regex acceptance of an unspecified line number;
- a schema change;
- a repository change.

## 3. Exact authorized successor scope

Copy all 12 A4 source members into A5S as independent, single-link regular
files without hardlinks.

Exactly these three copied source members may change:

1. tool/source/FORMAT.md
2. tool/source/envelope/semantic.go
3. tool/source/envelope/envelope_test.go

The following nine members must remain byte- and mode-identical to A4:

- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-fixture/main.go
- tool/source/envelope/runner.go
- tool/source/envelope/source.go
- tool/source/envelope/testdata/evidence-manifest-v1.golden
- tool/source/envelope/testdata/source-inventory-v1.golden
- tool/source/go.mod

No active schema identifier changes in this amendment.

If a fourth source member or a schema change is required, stop:

REPAIR10I_A5S_SCOPE_EXPANSION_REQUIRED

## 4. Vulnerable-precondition control

Before editing, preserve a bounded A4 negative using the exact retained A5
full-suite raw stream.

Require:

- A4 extraction completes through EOF;
- lifecycle and terminal evidence are complete;
- the target test terminal is pass;
- unknown count is exactly one;
- the sole unknown is the line-1706 fresh-bootstrap diagnostic;
- rule classification is unknown-typed-candidate-v1;
- every other semantic record remains valid;
- the control is labeled expected-negative and nonqualifying.

Do not rerun the repository full suite in A5S.

## 5. Exact grammar amendment

Recover the exact raw line-1706 diagnostic from the retained failed refresh.

Do not reconstruct its punctuation or spacing approximately.

Add exactly one current-source template to the same closed grammar used by
fresh-bootstrap-logical-bytes-bound-v1.

The exact accepted templates after repair must be finite and enumerable:

- historical line 1364 form;
- historical line 1375 form;
- governed A5 line 1706 form.

The accepted line number remains literal in each template. It is not itself a
capture.

For line 1706 require:

- exact package:
  execution-substrate;
- exact top-level test:
  TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2;
- empty subtest;
- exact source file token;
- exact source line 1706;
- exact surrounding text;
- canonical nonnegative decimal fields;
- logical_bytes strictly less than 134217728;
- existing entries/depth predicates and topology;
- exact occurrence/ordinal/correlation behavior already required by the rule.

Use the existing rule ID if doing so leaves historical canonical semantics
byte-identical. Do not rename the rule merely because one additional exact
source template is admitted.

FORMAT.md must explicitly document that the rule has a finite source-version
template table and that unlisted source lines remain unknown.

## 6. Mandatory causal tests

### Exact A5 positive

Feed the exact retained line-1706 diagnostic.

Require:

- recognized rule:
  fresh-bootstrap-logical-bytes-bound-v1;
- classification:
  recognized/canonicalizable under the existing vocabulary;
- expected typed captures;
- zero unknowns;
- entries and depth preserved;
- logical_bytes canonicalized only according to the existing bounded rule.

### Historical nonregression

Feed exact recognized diagnostics at lines 1364 and 1375.

Require canonical output byte-identical to sealed A4 behavior.

### Wrong-line rejection

Independently test at least:

- line 1363;
- line 1365;
- line 1374;
- line 1376;
- line 1705;
- line 1707;
- another same-width arbitrary line.

Every form must remain unknown and blocking.

### Exact identity rejection

Mutate independently:

- package;
- test;
- subtest;
- source file;
- source-line punctuation;
- field name;
- field order;
- entries;
- depth;
- trailing text;
- duplicated text;
- occurrence;
- ordinal;
- correlation topology.

Require rejection or unknown classification according to the existing
contract.

### Logical-byte boundary

Require:

- representative valid in-bound values pass;
- 134217727 passes;
- 134217728 blocks;
- larger blocks;
- negative blocks;
- leading-zero blocks;
- signed form blocks;
- overflow blocks;
- malformed decimal blocks.

### Retained A5 raw-stream causal

Re-extract the exact failed `a5-final` raw stream with both independently built
A5S sides.

Require:

- zero unknown diagnostics;
- exactly one prior unknown becomes recognized;
- the target test remains pass;
- lifecycle records byte-identical to A4 extraction;
- package/test terminal sets byte-identical;
- every diagnostic other than the target record remains byte-identical;
- panic/race/fatal/warning/intrinsic-integrity classifications unchanged;
- side A and side B canonical semantic bytes identical.

This is a bounded tool causal. It is not the policy-evidence refresh and must
not be represented as such.

### No unrelated broadening

Build a corpus of typed-looking near misses drawn from the existing rule and
require no new recognition beyond the exact A5 record.

## 7. Successor build and hard gate

Use pinned Go 1.26.5 in two physically disjoint private controls under umask
077.

Each side must have independent:

- source copy;
- HOME and XDG roots;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build output;
- command and report roots.

No writable cache or mutable state may be shared.

Run on both sides:

gofmt -d over every Go source member; require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

No required skip, malformed stream, race report, timeout, survivor, forced
cleanup, or missing/duplicate terminal is permitted.

Build on each side:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require every A/B pair to be:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- mode 0700;
- built from exact A5S source;
- free of unexpected build-info paths.

Retain exact source inventories, T values, environments, argv, streams,
terminal records, and binary identities.

## 8. Historical and A4 compatibility

Using sealed, retained raw inputs:

1. Re-extract the qualified historical HEAD stream.
2. Re-extract the qualified historical Repair-9 stream.
3. Re-extract the nearest qualified pre-A5 final stream.
4. Re-extract A4’s sealed final/fresh and mutant causal inputs.

Require:

- existing historical recognized records remain canonical-byte-identical;
- existing unknown counts do not increase;
- lifecycle and terminal sets remain identical;
- final/fresh remains the same sealed tool causal;
- exact mutant and inverse-mutant causals remain unchanged;
- no comparison-policy behavior changes;
- no active schema changes.

Do not attempt to derive or freeze the historical transition policy here.

## 9. Evidence child

Create A5S only after the opening gate.

Use private top-level directories:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

Retain:

- complete opening and immutable-lineage verification;
- failed policy-evidence refresh identity;
- exact failed a5-final raw/result/semantic bindings;
- vulnerable A4 negative;
- exact A4→A5S three-path delta;
- recovered exact line-1706 tuple;
- finite-template decision;
- all positive and negative grammar causals;
- A/B source controls;
- A/B test, race, and build records;
- retained A5 raw-stream re-extraction;
- historical and A4 compatibility checks;
- failed and superseded attempts;
- cleanup and two absence epochs;
- implementation report;
- final A5S inventory and T;
- exact path/mode/size/hash list.

## 10. Closeout

Require:

- exactly the three authorized successor paths changed;
- the other nine source members byte- and mode-identical to A4;
- repository T/inventory/membership unchanged;
- repository branch/HEAD/parent/tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged remain zero;
- A, A2, A3, A4, A5, H, B/B2/B3/B4/B5, divergence-recon, and the failed
  policy-evidence refresh unchanged;
- no recreated bytecode or cache in a sealed predecessor;
- no private source, cache, build, process, descriptor, stream, socket,
  listener, or temporary report residue;
- two fresh absence epochs.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final A5S mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 11. Mandatory stop conditions

Stop on:

- baseline or immutable-lineage mismatch;
- exact retained A5 tuple cannot be recovered;
- need for a fourth source file;
- need for a schema change;
- repository-source mutation;
- generic or ranged source-line normalization;
- any near miss becomes recognized;
- existing historical canonical semantics change;
- target A5 raw stream retains an unknown;
- more than the one exact diagnostic changes classification;
- A/B source or binary inequality;
- test, race, cleanup, or sealing failure;
- surviving private resource or root.

## 12. Verdicts

Opening mismatch:

REPAIR10I_A5S_BASELINE_MISMATCH

Scope expansion required:

REPAIR10I_A5S_SCOPE_EXPANSION_REQUIRED

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A5S_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A5S_SEMANTIC_LINE_COMPATIBILITY_PATCH_SEALED_READY_FOR_A6_EVIDENCE_REFRESH

The success report must include:

- A4 and A5S T/inventory;
- exact three-file delta;
- exact finite source-line template set;
- vulnerable A4 unknown;
- repaired A5 raw-stream result;
- exact count of changed semantic records;
- wrong-line and overbound results;
- historical and A4 compatibility results;
- A/B binary identities;
- manifest SHA-256 and payload count;
- cleanup and two absence epochs;
- explicit statement that the policy-evidence refresh was not restarted.

No A6 implementation.
No evidence-refresh retry.
No B6.
No snapshot.
No integrated ZIP.
No handoff.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A5S, start a **new** policy-evidence refresh child and rerun both A5 full-suite controls from the beginning. The failed refresh remains nonqualifying negative evidence. The established A2 precedent is explicit that a bounded successor causal does not replace newly materialized downstream source controls. 

This does not alter the larger conclusion from reconnaissance: the historical policy still cannot be frozen until exact A5 full-suite matrices exist. A5S merely makes those observations representable. Exact provenance can bind the new successor bytes, but it cannot establish that its grammar or the eventual historical policy is correct without the new validation cycle. 

### Sources

- Codex’s `REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED` response in the current turn.
- Sealed Repair 10I-A2 restart boundary and non-substitution rule. 
- Governed Execution provenance limitations. 
- Repair/audit lifecycle requiring new validation and audit after changed bytes. 

**Confidence:** 0.999 that the evidence-refresh stop was correct; 0.99 that this is a narrow successor grammar incompatibility rather than a product defect; 0.96 that the three-file A5S amendment is sufficient; 0.995 that A5S must not be promoted into historical-policy authority; 0.995 that the two-control evidence refresh must restart from fresh materializations after A5S seals.
