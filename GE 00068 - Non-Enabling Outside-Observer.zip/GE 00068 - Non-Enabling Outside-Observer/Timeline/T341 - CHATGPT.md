## Assessment

This result is **audit-harness failure only**. It establishes no successor-package defect and does not authorize another package implementation or findings-reconciliation tranche.

The finite, noninteractive parent model worked: there was no idle input loop, interruption, continuation, direct auditor, or subagent. The failure moved downstream into the audit implementation:

- Three materialization children created roots that the child ledger reported as writing nothing. The cleanup record then falsely claimed completion while those roots remained.
- The audit changed materialization operands and environment from the package’s accepted invocation contract, causing all materializations to exit `20`.
- The independent validator was invoked without its mandatory `--package-root` and `--result` arguments.
- Finding A and C rejections were misclassified because the audit hard-coded one expected reason rather than respecting the target’s actual invariant-detection order.
- The Finding J and field-map parsers did not match the actual retained record schemas.
- The security lane used an overbroad literal-path heuristic rather than a source-aware production-access analysis.

Several substantive observations are encouraging—the source model for A/C/H, the `RENAME_EXCL` capability causal, and the parent-derived publication classifications—but none qualifies after the false ledger and cleanup assertions.

The next step should be a **small, read-only reconciliation of this failed audit harness**, not another full audit and not another package repair. It must derive the exact corrected commands, parser contracts, output-root attribution, and cleanup algorithm before the full audit is retried.

```text
READ-ONLY FAILED-AUDIT HARNESS RECONCILIATION —
A/C/H/I SUCCESSOR INDEPENDENT AUDIT `fbta52kj`

This is a bounded reconciliation of the failed audit implementation.

It is not:

- a successor-package audit;
- a package repair;
- a findings reconciliation;
- a V3 target audit;
- a product or repository audit.

Do not modify or repair the successor package.
Do not modify, resume, clean, or seal the failed audit root.
Do not modify or remove the three surviving materialization roots.
Do not modify any other supplied root.
Do not inspect the candidate repository, Strategic B, V1/V2/V3 targets,
product source, or unrelated evidence.
Do not run Git.
Do not run repository or product tests.
Do not use the network.
Do not create subagents or direct auditors.
Do not execute the full independent audit.

Do not create another process wrapper, supervisor, recorder package, importer,
or capability-probe package.

Use direct, read-only inspection. The Codex platform transcript is sufficient
process authority for this diagnostic.

Return exactly one primary verdict:

FAILED_AUDIT_HARNESS_RECONCILED_READY_FOR_FRESH_AUDIT
FAILED_AUDIT_HARNESS_RECONCILIATION_BLOCKED
RECONCILIATION_PROVENANCE_MISMATCH

OBJECTIVE

Identify and reconcile every concrete audit-harness defect that caused the
`fbta52kj` attempt to be nonqualifying.

Produce one exact corrected full-audit execution contract covering:

1. child filesystem-effect attribution;
2. dynamic materialization-root discovery;
3. materialization invocation;
4. cleanup and ENOENT verification;
5. Finding A reason adjudication;
6. Finding C reason adjudication;
7. Finding J record parsing;
8. field-map parsing;
9. independent-validator invocation;
10. security/export analysis;
11. preseal completion assertions.

Do not adjudicate the successor package itself.

──────────────────────────────────────────────────────────────────────────────
1. EXACT FAILED AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj

Expected root identity:

- device/inode:
  16777234 / 179539317
- mode:
  0700
- primary verdict:
  AUDIT_PROVENANCE_MISMATCH

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  37614 each
- SHA-256:
  19561231e769b6d9dc794eb5060732c39b18123b8165d70a5584fd0f8370f7c1
- byte-identical:
  required

Expected represented capsule closure:

- 175 represented entries;
- 31 represented directories;
- 144 represented nonmanifest regular files;
- exactly two manifest self-exclusions.

Required retained records include:

closeout/final-audit-report.md
closeout/parent-process-preseal-outcome.json
provenance/complete-child-process-ledger.json
opening/frozen-audit-plan.json
analysis/fixed-identity-and-discovery-results.json

and every retained A/C/H/I/J, materialization, validation, cleanup, perspective,
security, equality, and attempt record referenced by the final report.

Independently locate those records from the capsule inventory. Do not infer a
path solely from a report label.

──────────────────────────────────────────────────────────────────────────────
2. EXACT SUCCESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected root identity:

- device/inode:
  16777234 / 179405897
- mode:
  0700

Expected manifests:

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

Open this root only to adjudicate the failed audit commands, source interfaces,
record grammars, and accepted producer invocation evidence.

Do not re-audit A/C/H/I behavior in this task.

──────────────────────────────────────────────────────────────────────────────
3. SURVIVING AUDIT-OWNED ROOTS
──────────────────────────────────────────────────────────────────────────────

The failed audit reported these surviving roots:

1. /Users/ds/Downloads/ES-validation-custody-v3-full-audit-vg7cmoay
2. /Users/ds/Downloads/ES-validation-custody-v3-full-audit-oz_rmxfq
3. /Users/ds/Downloads/ES-validation-custody-v3-full-audit-0fv56xan

Treat all three as immutable failed-audit evidence.

For each record:

- device/inode/mode;
- complete lstat/no-follow inventory;
- creation-time and modification-time evidence;
- package files and records present;
- whether bootstrap outcome exists;
- failure classification;
- whether Carrier 0002 ran;
- whether a success commit exists;
- whether the root is partial, failed, or complete;
- the child process that created it;
- the exact stdout locator, result record, or argv field that binds it;
- whether the failed audit knew or should have known its exact path.

Do not remove, normalize, chmod, or clean these roots.

──────────────────────────────────────────────────────────────────────────────
4. COMPLETE CHILD LEDGER CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Parse the retained child ledger strictly.

For every child retain in the reconciliation report:

- ordinal;
- purpose;
- argv;
- cwd;
- explicit environment;
- stdout identity;
- stderr identity;
- exit or signal;
- `paths_written`;
- declared output arguments;
- stdout root-locator lines;
- result files;
- actual filesystem effects;
- discrepancy, if any.

Identify exactly which children created each of the three surviving roots.

Determine why their outcomes contain:

`paths_written: []`

Classify the cause as one or more of:

- recorder never attempted filesystem attribution;
- recorder inspected only fixed output arguments;
- dynamic root locator was ignored;
- child exited before expected result parsing;
- result parser failed;
- stdout parser failed;
- child record was created before post-exit attribution;
- cleanup registry depended on an empty `paths_written`;
- another exact mechanism.

No inference is sufficient: bind the classification to exact audit-parent
source lines and retained child records.

──────────────────────────────────────────────────────────────────────────────
5. CORRECT CHILD FILESYSTEM-EFFECT CONTRACT
──────────────────────────────────────────────────────────────────────────────

Define the exact child filesystem-effect contract required for the next audit.

For every materialization/bootstrap child, the recorder must retain:

- fixed paths declared in argv;
- exact dynamic root locator from stdout;
- exact structured result path, when emitted;
- pre-exit and post-exit existence of those exact paths;
- complete inventory identity of every audit-owned root written;
- failed-root retention posture;
- cleanup eligibility;
- cleanup disposition.

Do not permit broad prefix scans, “latest” selection, recursive Downloads
discovery, or pathname guessing.

When a child emits:

`AUDIT_ROOT=<absolute-path>`

the recorder must:

1. validate the exact one-line grammar;
2. require an absolute path;
3. require direct parentage under the contractually permitted parent;
4. require the exact permitted prefix;
5. reject multiple root locators;
6. lstat the exact path;
7. retain it in `paths_written`;
8. retain its identity and complete post-child inventory;
9. add it to the cleanup registry even when the child exits nonzero.

If no valid root locator is emitted but a dynamic root may have been created,
the child outcome must not claim complete filesystem-effect attribution.

Freeze a mechanism-specific failure reason for that case.

──────────────────────────────────────────────────────────────────────────────
6. MATERIALIZATION INVOCATION RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Identify the exact three failed materialization children.

For each report:

- exact argv;
- cwd;
- environment;
- stdout;
- stderr;
- exit;
- root locator;
- created root;
- first blocker;
- package failure record.

Compare each invocation field-by-field against:

A. The production bootstrap CLI and contract in the successor package.

B. The exact successful producer materialization invocations retained in the
successor package, including:

validation/a-c-h-i-repair/two-final-materializations-v2.json

and all bound command/process records it references.

C. Any exact CLI field map or contract in the successor package.

Identify every altered operand, including:

- audit parent;
- prefix;
- environment;
- cwd;
- package root;
- qualified-launcher root;
- reconciliation root;
- interpreter;
- flags;
- output/result arguments.

Determine the exact cause of exit `20` for each child.

Do not describe a changed value as harmless unless the package contract makes
it parameterizable and the new value remains valid.

Produce the exact corrected materialization argv, cwd, and environment for the
future audit.

The corrected command must preserve the package’s accepted invocation contract.
The audit may not invent a different parent, prefix, or environment merely to
place roots beneath the audit capsule.

Audit-owned roots created under the package-authorized parent remain
audit-owned and must be captured through their root locators and cleaned before
preseal.

──────────────────────────────────────────────────────────────────────────────
7. CLEANUP FAILURE RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Read the exact failed-audit cleanup implementation and retained cleanup record.

Determine:

- how roots entered the cleanup registry;
- whether the registry was derived solely from `paths_written`;
- whether all three surviving roots were absent from the registry;
- whether cleanup ran against any of them;
- why the preseal record asserted `cleanup_complete: true`;
- why the final report and capsule repeated that claim;
- whether the code checked exact root absence;
- whether it performed two fresh ENOENT observations;
- whether process/descriptor-survivor checks covered these roots.

Produce the exact corrected cleanup algorithm:

1. Build the root registry from validated child root locators and fixed
   audit-owned output paths.
2. Retain a complete pre-removal inventory for every registered root.
3. Require no process or descriptor survivor.
4. Remove only the exact registered audit-owned root.
5. Perform two fresh `lstat` calls on the exact path.
6. Require ENOENT twice.
7. Retain each row with:
   - child ordinal;
   - root identity;
   - inventory identity;
   - removal result;
   - absence observations;
   - process/descriptor result.
8. Reconcile:
   `created roots == inventoried roots == cleanup rows == absent roots`.
9. `cleanup_complete` may be true only when all four sets are exactly equal.
10. Preseal and final reports must derive cleanup status from this equality,
    not from attempted-cleanup count.

No administrative continuation may remove roots after sealing.

──────────────────────────────────────────────────────────────────────────────
8. FINDING A AUDIT-ORACLE RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Inspect the failed audit’s A causal records, source, and expected-reason map.

Report every case:

- invocation;
- actual first blocker;
- expected blocker;
- target accepted/rejected;
- audit classified pass/fail;
- whether any false acceptance occurred.

The report states that missing `-S` and missing `-B` were rejected, but the
audit expected a different reason ordering.

Determine whether the package contract freezes one exact first-blocker order.

If it does:

- derive the order from the contract and source;
- identify whether the package or audit was wrong.

If it does not:

- define a closed allowed rejection set for causals that violate multiple
  invariants;
- require rejection before authoritative success;
- preserve actual first blocker as evidence;
- do not fail the package merely because a different valid invariant was
  detected first.

Produce the exact future A causal oracle.

Do not adjudicate Finding A itself beyond reconciling the failed audit oracle.

──────────────────────────────────────────────────────────────────────────────
9. FINDING C AUDIT-ORACLE RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Inspect the two replacement causals that returned:

`destination:link-count`

instead of:

`destination:path-rebinding`

For each determine:

- mutation performed;
- actual destination posture;
- exact source check order;
- first failing invariant;
- whether destination qualified;
- whether a false acceptance occurred.

Determine whether the package contract freezes one exact reason.

If multiple closed rejection reasons are valid, define the future oracle as:

- destination must reject;
- no authoritative success;
- reason must belong to the exact case-specific allowed set;
- actual reason retained;
- no fallback to generic failure.

Do not weaken cases where one exact mechanism is contractually required.

Produce the exact future C causal reason map.

──────────────────────────────────────────────────────────────────────────────
10. INDEPENDENT VALIDATOR INVOCATION
──────────────────────────────────────────────────────────────────────────────

Identify the failed audit child that invoked the package validator without:

- `--package-root`
- `--result`

Inspect the validator source and parser completely.

Report:

- exact executable/source path;
- exact required options;
- exact option order, if constrained;
- exact failed argv;
- exact corrected argv;
- cwd;
- environment;
- expected result path;
- expected output schema;
- exit semantics.

Determine why the audit command builder omitted the two required options.

Freeze one corrected validator invocation record for the future audit.

Do not run the complete validator suite in this reconciliation.

A bounded `--help` or parser-only in-process check is permitted only when it
does not create package validation output.

──────────────────────────────────────────────────────────────────────────────
11. FINDING J RECORD-GRAMMAR RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Identify every failed-audit J or field-map parser that reconstructed:

- zero J metrics;
- zero field rows;
- an invalid qualification result;
- or another empty projection.

For each input record report:

- path;
- size;
- SHA-256;
- top-level JSON shape;
- schema;
- actual field names;
- nested location of counts, cases, rows, or metrics;
- failed parser assumption;
- exact corrected extraction.

At minimum reconcile:

- the 928-case Finding J regression record;
- the 14-family / 1,052-field consistency record;
- the qualification-result record;
- producer and independent-validator result records.

Create exact read-only parser fixtures using copied bytes or in-memory data.

Require corrected parsers to produce the package-reported counts from the
actual records.

Do not treat package-reported counts as correct merely because the parser now
finds them; this task only freezes record grammar for the next audit.

──────────────────────────────────────────────────────────────────────────────
12. SECURITY-ORACLE RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Identify the broad literal-path heuristic that produced a nonqualifying
security/export failure.

Report:

- exact scanner source;
- exact match;
- source file and line;
- why the match was benign or ambiguous;
- whether any actual file open, process launch, Git, network, or target access
  path existed.

Replace the heuristic for the future audit with source-aware checks:

- AST or equivalent call-site analysis;
- literal path classified by operation;
- distinction among:
  - contract data;
  - test fixture;
  - report text;
  - error message;
  - actual filesystem access;
  - actual process invocation;
- bounded allowlist only for proven nonoperational literals;
- dynamic causals for production access claims where necessary.

Do not declare production export closed in this reconciliation.

Freeze the corrected security-analysis algorithm and exact stop conditions.

──────────────────────────────────────────────────────────────────────────────
13. PRESEAL ASSERTION RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

Inspect:

closeout/parent-process-preseal-outcome.json

Expected identity from the report:

- size:
  791
- SHA-256:
  b3e646f4568243b97129b03496d434920255f335b1dba4f544600f1b008fb8e4

Identify every claimed Boolean or status derived from an incomplete or
incorrect audit result.

At minimum adjudicate:

- `cleanup_complete`;
- materialization completion;
- validator completion;
- A completion;
- C completion;
- H completion;
- I completion;
- J completion;
- field-map completion;
- security completion;
- readiness to seal.

Define the exact future preseal gate:

- every required phase has a terminal result;
- every terminal result passes its own schema;
- all child-created roots are accounted for;
- cleanup-set equality passes;
- all supplied roots close equal;
- all required parsers produced nonempty, internally consistent records;
- no substantive phase remains not reached;
- no required confirmation is false;
- no failed child is silently treated as completed.

If any condition fails, preseal must not claim successful completion and
terminal acceptance manifests must not be produced.

A failed audit may still retain a failure capsule, but must not use the
successful preseal outcome schema or terminal-success caption.

──────────────────────────────────────────────────────────────────────────────
14. CORRECTED FULL-AUDIT EXECUTION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Produce one machine-readable corrected execution contract for the next audit.

It must include:

- exact fixed supplied roots and identities;
- finite one-shot parent model;
- frozen phase order;
- child recorder;
- exact successor materialization commands;
- exact independent-validator command;
- exact A causal reason oracle;
- exact C causal reason oracle;
- exact J record parsers;
- exact field-map parser;
- source-aware security algorithm;
- dynamic root-locator attribution;
- complete cleanup-set reconciliation;
- preseal success gate;
- terminal failure-capsule gate;
- verdict rules;
- no administrative continuation;
- no direct auditors or subagents.

For every phase specify:

- phase ID;
- prerequisites;
- exact operands;
- child/in-process classification;
- expected outputs;
- pass rule;
- failure rule;
- may-continue-on-failure:
  true/false;
- cleanup obligations;
- preseal contribution.

Do not execute the corrected full audit.

──────────────────────────────────────────────────────────────────────────────
15. NEXT FULL-AUDIT COMMAND PLAN
──────────────────────────────────────────────────────────────────────────────

Produce exact command templates for:

1. successor materialization 1;
2. successor materialization 2;
3. Carrier 0002 handoff 1;
4. Carrier 0002 handoff 2;
5. package independent validator;
6. every required external security or capability causal;
7. cleanup.

Bind:

- interpreter;
- isolation flags;
- script;
- argv;
- cwd;
- environment;
- result path;
- expected root-locator grammar;
- expected exit semantics;
- timeout.

Use parameter placeholders only for values that the package contract makes
parameterizable.

Do not substitute an audit-preferred value for a contract-fixed parent,
prefix, environment, or root.

──────────────────────────────────────────────────────────────────────────────
16. CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- failed audit root;
- successor package;
- each surviving materialization root;
- any optional package root opened.

Require exact opening/closing equality.

Do not remove the surviving materialization roots.

Do not mutate or clean any supplied root.

If a diagnostic output root is created:

- remove only its private temporary state;
- retain one final report;
- retain one final inventory;
- no terminal manifest pair is required;
- do not create a sealed audit capsule.

──────────────────────────────────────────────────────────────────────────────
17. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

FAILED_AUDIT_HARNESS_RECONCILED_READY_FOR_FRESH_AUDIT

only when:

- every child is crosswalked;
- all three surviving roots are attributed exactly;
- the materialization exit-20 causes are exact;
- corrected materialization commands are frozen;
- validator invocation is corrected;
- A/C reason oracles are frozen;
- J and field-map record grammars are frozen;
- security algorithm is corrected;
- cleanup-set and preseal rules are closed;
- supplied-root closing equality passes.

Return:

FAILED_AUDIT_HARNESS_RECONCILIATION_BLOCKED

when indispensable process evidence is genuinely absent or commands cannot be
reconstructed without guessing.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

only for supplied-root mutation or opening/closing inequality during this
diagnostic.

Do not return a successor-package verdict.

──────────────────────────────────────────────────────────────────────────────
18. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Failed-audit-root identity and closure
3. Successor-package identity and closure
4. Surviving-root identities and classifications
5. Failed parent-source identity
6. Complete child-ledger crosswalk
7. Exact child-to-root attribution
8. Cause of empty `paths_written`
9. Corrected filesystem-effect contract
10. Failed materialization commands
11. Exact exit-20 causes
12. Corrected materialization commands
13. Cleanup-registry defect
14. Corrected cleanup algorithm
15. Finding A reason-oracle reconciliation
16. Finding C reason-oracle reconciliation
17. Independent-validator invocation defect
18. Corrected independent-validator command
19. Finding J record grammar
20. Field-map record grammar
21. Qualification-result grammar
22. Corrected parser specifications
23. Security-heuristic defect
24. Corrected security-analysis algorithm
25. Preseal false assertions
26. Corrected preseal gate
27. Corrected full-audit execution contract
28. Exact next full-audit command plan
29. Supplied-root closing equality
30. Remaining uncertainty and nonclaims
31. Explicit confirmations

Required confirmations:

FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
SURVIVING_MATERIALIZATION_ROOTS_MUTATION_NOT_PERFORMED
SURVIVING_MATERIALIZATION_ROOTS_NOT_CLEANED
PACKAGE_FINDINGS_NOT_READJUDICATED
NO_SUCCESSOR_REPAIR_PERFORMED
EVERY_CHILD_CROSSWALKED
EVERY_SURVIVING_ROOT_ATTRIBUTED
DYNAMIC_ROOT_LOCATOR_CONTRACT_FROZEN
PATHS_WRITTEN_FALSE_CLAIM_CAUSE_IDENTIFIED
MATERIALIZATION_EXIT_20_CAUSES_IDENTIFIED
CORRECTED_MATERIALIZATION_COMMANDS_FROZEN
INDEPENDENT_VALIDATOR_COMMAND_CORRECTED
FINDING_A_REASON_ORACLE_CORRECTED
FINDING_C_REASON_ORACLE_CORRECTED
FINDING_J_RECORD_GRAMMAR_RECONSTRUCTED
FIELD_MAP_RECORD_GRAMMAR_RECONSTRUCTED
SECURITY_ORACLE_CORRECTED
CLEANUP_SET_EQUALITY_RULE_FROZEN
PRESEAL_SUCCESS_GATE_FROZEN
NO_FULL_AUDIT_EXECUTED
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS_CREATED
```

Do not start another full audit until this reconciliation freezes the exact corrected execution contract and command plan.

**Source:** Codex’s `AUDIT_PROVENANCE_MISMATCH` report above.  
**Confidence:** 0.999 that no successor-package defect was established; 0.995 that the immediate blockers are confined to the audit command/oracle/parser/cleanup implementation; 0.98 that this bounded reconciliation is the shortest safe route to a decisive package audit.
