## Assessment

The harness reconciliation is sufficient to authorize a **new full audit using the existing successor package unchanged**. It closes the audit-side defects that invalidated `fbta52kj`:

- Dynamic `AUDIT_ROOT=` locators must be parsed and attributed even when the child exits nonzero.
- The three materializations failed because the audit changed contract-fixed `--audit-parent` and `--audit-prefix` values.
- Cleanup must reconcile the exact sets of created, inventoried, removed, and twice-absent roots.
- Finding A and C cases need closed sets of valid rejection reasons rather than one hard-coded first blocker.
- The producer and independent-validator invocations now have exact CLIs.
- The Finding J, field-map, qualification, and validator record grammars are now known.
- Security analysis must be operation-aware rather than based on arbitrary string matches.
- Successful preseal must derive from actual phase outcomes and cleanup-set equality.

One likely substantive blocker is already visible but not yet authority-bearing: the package accepted duplicate `-I` despite its exact-one-token contract. The next audit should classify that as a Finding A package defect if it reproduces. It must not be converted into another audit mismatch.

No further harness implementation or package repair should occur before this audit.

Forward this prompt to Codex unchanged:

FRESH FINITE PARENT-OWNED INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP A/C/H/I REPAIR SUCCESSOR

This is a fresh independent audit of one exact source-external package.

It incorporates the corrected audit-harness execution contract from the
immediately preceding:

FAILED_AUDIT_HARNESS_RECONCILED_READY_FOR_FRESH_AUDIT

response.

Do not modify or repair the audit target.
Do not modify or clean any supplied root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, downstream V3 targets, product source, or
unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents or direct auditors.

Use exactly one finite, noninteractive, parent-owned audit process.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact audited bootstrap-package bytes and their
bounded source-external process behavior.

ACCEPT grants no authority over:

- any candidate repository;
- Strategic B;
- V1/V2/V3 target behavior;
- product or runtime behavior;
- deployment;
- external publication;
- Git commit;
- readiness;
- the eventual V3 target-audit verdict;
- A6.

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected root identity:

- device/inode:
  16777234 / 179405897
- physical mode:
  0700
- expected producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_A_C_H_I_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected temporal final inventory:

closeout/temporal-final-inventory-a-c-h-i-v1.json

- size:
  313198
- SHA-256:
  7e3f7103e057a251a674c18508c043b7b7257bf3cfe1d7f7c2e39fa5f4213f81
- entries:
  1205

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

Expected represented closure:

- 1207 represented entries;
- 334 directories including root;
- 873 represented nonmanifest regular files;
- 875 physical regular files including the manifests;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- zero writes after manifest closure.

Independently derive and authenticate:

- the package verdict record;
- the sealed implementation report;
- all semantic source, contract, schema, and test identities;
- every validation result;
- every failed/superseded-attempt record;
- all retained replay fixtures;
- temporal-inventory chronology;
- terminal write chronology.

Do not use a narrative report as artifact authority.

──────────────────────────────────────────────────────────────────────────────
2. PREDECESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

Expected identity:

- device/inode:
  16777234 / 179272855
- mode:
  0700

Expected terminal manifests:

- size:
  237800 each
- SHA-256:
  adf2a6f8314327b07883153f95eae567ecd802413d2b0acdeebfc2bf56d47f8e
- byte-identical:
  required

Expected closure:

- 1140 represented entries;
- 333 directories including root;
- 807 represented nonmanifest files;
- 809 physical files including manifests.

Use this root only for exact predecessor-to-successor delta and repair-authority
adjudication.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING BLOCKING AUDIT
──────────────────────────────────────────────────────────────────────────────

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

Expected primary verdict:

BLOCK

Expected terminal manifests:

- size:
  243162 each
- SHA-256:
  8438d5d1571e8cfa462f53a6df0744749aab281fb9181e602bd02f82f9dc0063
- byte-identical:
  required

Authenticate and inspect completely:

closeout/primary-verdict.json
closeout/final-audit-report.md
analysis/severity-ranked-residual-findings.json
causals/finding-a-interpreter-flags.json
causals/finding-c-post-copy.json
causals/predecessor-h-causal.json
validation/fresh-publication-boundary-matrix.json
analysis/commit-point-semantics.json
analysis/producer-case-level-adjudication.json
causals/finding-i-wrong-payload-mutation.json
validation/fresh-predecessor-j-reproduction-v2.json
validation/fresh-independent-j-matrix-v3.json
analysis/qualification-result-closure.json
analysis/replay-evidence-closure.json
analysis/failure-hook-reachability.json
analysis/predecessor-successor-delta.json
analysis/repair-authority-hunk-ledger.json
closeout/explicit-confirmations.json
closeout/supplied-root-closing-equality.json

The audit’s confirmed A, C, H, and I findings govern repair scope.

Finding J’s accepted closure is the regression baseline.

──────────────────────────────────────────────────────────────────────────────
4. OPTIONAL FIXED INPUTS
──────────────────────────────────────────────────────────────────────────────

Open only when a concrete check requires them:

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python identity:

- version:
  Python 3.13.4
- regular:
  true
- link count:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter mode is report-only.

Every optional root opened becomes subject to complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. HISTORICAL FAILED AUDIT NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Do not open, resume, mutate, clean, or reuse:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj

Do not open, mutate, clean, or reuse its surviving roots:

/Users/ds/Downloads/ES-validation-custody-v3-full-audit-vg7cmoay

/Users/ds/Downloads/ES-validation-custody-v3-full-audit-oz_rmxfq

/Users/ds/Downloads/ES-validation-custody-v3-full-audit-0fv56xan

Their only adopted status is:

- immutable historical audit-process evidence;
- no reusable package qualification;
- no reusable opening, causal, validation, or closing result.

Retain one fresh historical disposition record stating those facts.

──────────────────────────────────────────────────────────────────────────────
6. AUDIT EPOCH AND PARENT MODEL
──────────────────────────────────────────────────────────────────────────────

Read this prompt completely before invoking a tool.

Then emit exactly:

AUDIT_EPOCH_START

Use:

top_level_launch_authority = "codex-platform-tool-transcript"

and:

audit_root_does_not_self_attest_parent_process_creation = true

Use one finite, noninteractive, one-shot parent audit process.

Forbidden:

- `input()`;
- stdin reads after launch;
- interactive command loops;
- persistent supervisors awaiting commands;
- later administrative continuation;
- replacement parent after failure;
- resume of a failed audit root.

The complete ordered plan must be frozen before supplied-root inspection as:

opening/frozen-audit-plan.json

At minimum freeze these phases:

P00 opening and fixed identities
P01 child-recorder causals
P02 static interface and package delta
P03 Finding A
P04 Finding C
P05 Finding H
P06 Finding I
P07 Finding J and field-map parsing
P08 producer package validation
P09 materialization 1
P10 materialization 2
P11 Carrier 0002 handoff 1
P12 Carrier 0002 handoff 2
P13 package independent validator
P14 export/security/authority
P15 cleanup
P16 closing equality
P17 preseal
P18 terminal success or failure closeout

Do not add, remove, reorder, or redefine substantive phases after supplied-root
inspection begins.

──────────────────────────────────────────────────────────────────────────────
7. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-

Before supplied-root inspection retain:

opening/bootstrap-start.json
opening/frozen-audit-plan.json
provenance/parent-source.py
provenance/parent-process-start.json

Emit the exact fresh audit-root path once.

Do not scan for or adopt any existing prefix match.

──────────────────────────────────────────────────────────────────────────────
8. CHILD-PROCESS RECORDER
──────────────────────────────────────────────────────────────────────────────

Every child must use one contemporaneous recorder.

Before spawn retain:

- contiguous ordinal;
- purpose;
- argv;
- cwd;
- explicit environment;
- timeout;
- fixed output paths;
- whether a dynamic audit root may be created;
- permitted dynamic-root parent;
- permitted dynamic-root prefix.

After exit retain:

- stdout bytes and identity;
- stderr bytes and identity;
- exit or signal;
- timeout posture;
- reaping;
- descriptor closure;
- fixed-path poststate;
- validated dynamic root locators;
- `paths_written`;
- complete inventory of every child-created root;
- cleanup-registry rows;
- qualifying or failed/superseded disposition.

Run recorder self-causals before supplied-root inspection:

1. nonexistent executable:
   `FileNotFoundError` / `ENOENT`;
2. `/usr/bin/true`:
   exit 0;
3. empty streams;
4. complete records;
5. reaping;
6. descriptor closure.

A child-record gap requires:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
9. DYNAMIC ROOT-LOCATOR CONTRACT
──────────────────────────────────────────────────────────────────────────────

For every bootstrap/materialization child, parse stdout using a byte-exact full
match equivalent to:

\AAUDIT_ROOT=(/Users/ds/Downloads/ES-validation-custody-v3-full-audit-[a-z0-9_]{8})\n\Z

Require:

- exactly one locator;
- no additional stdout bytes;
- absolute path;
- direct parent:
  `/Users/ds/Downloads`;
- basename prefix:
  `ES-validation-custody-v3-full-audit-`;
- no `..`;
- no symlink-based parent substitution;
- exact lstat of the emitted path;
- directory mode 0700;
- complete no-follow inventory;
- addition to `paths_written`;
- addition to the cleanup registry;
- attribution even when the child exits nonzero.

Prohibited:

- broad prefix scans;
- recursive Downloads scans;
- latest selection;
- scoring;
- maximum-selection fallback;
- pathname guessing.

If a dynamic root may have been created but no unique valid locator exists,
record:

filesystem_effect_attribution:dynamic-root-locator-missing-or-invalid

and return:

AUDIT_PROVENANCE_MISMATCH

Do not continue root-creating phases.

──────────────────────────────────────────────────────────────────────────────
10. OPENING GATE
──────────────────────────────────────────────────────────────────────────────

Before substantive audit work:

1. Authenticate successor root and complete closure.
2. Authenticate predecessor root and complete closure.
3. Authenticate governing blocking-audit root and complete closure.
4. Authenticate every optional root opened.
5. Verify pairwise physical distinction.
6. Capture complete lstat/no-follow opening inventories.
7. Bind all fixed semantic and evidence identities.
8. Retain:
   `opening/opening-gate-result.json`

Do not begin substantive inspection until this gate passes.

Return AUDIT_PROVENANCE_MISMATCH for actual:

- fixed-input drift;
- missing input;
- root alias;
- manifest mismatch;
- supplied-root mutation;
- recorder failure.

──────────────────────────────────────────────────────────────────────────────
11. EXACT PREDECESSOR-TO-SUCCESSOR DELTA
──────────────────────────────────────────────────────────────────────────────

Independently reconstruct the complete delta.

The claimed changed semantic set is exactly:

source/full_audit_bootstrap_v1.py
contract/full-audit-bootstrap-contract-v1.json
contract/qualification-result-contract-v1.json
schemas/full-audit-bootstrap-contract-v1.schema.json
tests/failure_injection_driver_v1.py
tests/test_full_audit_bootstrap_v1.py

Expected known successor identities:

source/full_audit_bootstrap_v1.py

- size:
  116052
- SHA-256:
  57b6a3f51bce996287dd0a7e302b1885560fae3a45956130d02b6d3aa88e4a35

contract/full-audit-bootstrap-contract-v1.json

- size:
  17461
- SHA-256:
  15fb94cfd94fd0467650dca4e56a5e7e5d3fea70de5eb79d084991cb2cfd4ac0

contract/qualification-result-contract-v1.json

- size:
  3753
- SHA-256:
  0a25d2b65b60fed54877bd7bdcf17ffa0005063c9c967dd8fcb00d15d2a9d803

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  12477
- SHA-256:
  f4bc62ae7cfc7c968fac3ae48658316ed3b25270b29ddb043f9abb70be4f3693

Authenticate exact test-file identities through the manifests and:

analysis/final-owner-and-hunk-ledger-a-c-h-i-v1.json

Expected ledger:

- size:
  35497
- SHA-256:
  4a96e0bee16042628a83bb050aa5f3d66b14e1c02651ab6c5443da3c69bf9d28

Require these Finding J-owned schemas to remain byte-identical:

schemas/process-self-check-result-v1.schema.json

- size:
  6554
- SHA-256:
  8a73bd13ee61b1a31d072d2a93c4e635cae14f0ad9f399dbef63954bd053abbf

schemas/root-rebinding-proof-v1.schema.json

- size:
  4662
- SHA-256:
  010a2d604980a914f8460b615dbfa62f125cb8f8d3a9584caf22499b9a7964cd

Require:

- exactly six semantic changes;
- no unauthorized semantic drift;
- no executable production source hidden under evidence namespaces;
- no production dependency on evidence-only files;
- complete role classification of all added paths.

──────────────────────────────────────────────────────────────────────────────
12. REPAIR-AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

For every changed hunk retain:

- path;
- old/new ranges;
- finding owner:
  A, C, H, or I;
- governing blocking-audit evidence;
- behavior change;
- contract change;
- schema change;
- authority effect;
- validation-only status.

Require every semantic hunk to be authorized by A, C, H, or I.

Verify Finding J was preserved rather than silently redefined.

Return BLOCK for unauthorized semantic change or authority widening.

──────────────────────────────────────────────────────────────────────────────
13. FINDING A ORACLE
──────────────────────────────────────────────────────────────────────────────

Audit both effective interpreter state and literal interpreter-option tokens.

Required effective state:

- `sys.flags.isolated == 1`
- `sys.flags.no_site == 1`
- `sys.flags.dont_write_bytecode == 1`

Required pre-script literal tokens:

- exactly one `-I`;
- exactly one `-S`;
- exactly one `-B`.

Arguments after the script operand cannot satisfy this requirement.

Environment cannot substitute for a missing `-B`.

Use this corrected oracle:

Accept:

- exact separate `-I -S -B`;
- reordered complete separate tokens, when the contract permits order
  independence;
- payload arguments containing flag-like text only after the script operand.

Reject:

- duplicate required token, even when the complete set is present;
- combined option forms when they do not produce exactly one literal token of
  each required option;
- missing `-I`;
- missing `-S`;
- missing `-B`;
- missing all;
- environment substitution for missing `-B`;
- tokens only after the script;
- duplicate `-I` with absent `-S`;
- flag-like script filename;
- wrong interpreter identity;
- stale observation;
- missing observation;
- contradictory observation.

For cases violating multiple invariants:

- require rejection before authoritative success;
- retain the actual first blocker;
- accept the blocker only when it belongs to a closed case-specific allowed
  reason set derived from the contract and source;
- do not fail the package solely because a different valid invariant is
  checked first.

Important:

The earlier probe accepted duplicate `-I`. Reproduce this against the actual
successor bootstrap, not merely an audit helper.

If the successor accepts duplicate `-I` despite its exact-one contract, return
BLOCK as a substantive Finding A defect.

Retain complete argv, environment, streams, records, success-commit posture,
target-inspection posture, child posture, and cleanup for every case.

──────────────────────────────────────────────────────────────────────────────
14. FINDING C ORACLE
──────────────────────────────────────────────────────────────────────────────

Independently inspect the source implementation of fresh post-copy
reverification.

Require:

- no-follow reopen of the destination;
- pre-read fstat;
- complete byte read;
- fresh SHA-256;
- post-read fstat;
- mode/link/type/size checks;
- stable held-file identity;
- final pathname-to-held-object rebinding check when path custody is claimed;
- fresh observation distinct from cached initial copy identity.

Run causals covering:

- stable copy;
- same-size in-place mutation;
- same-size replacement;
- replacement between observation and open;
- replacement after open;
- pathname replacement while descriptor remains on the old object;
- mutation during held read;
- mode change;
- hardlink/link-count change;
- truncate;
- append;
- disappearance;
- regular-to-symlink;
- regular-to-directory or safe special type;
- cached-observation substitution;
- unsupported no-follow capability;
- read error/partial read when safely injectable.

Use this reason treatment:

- require rejection before authoritative success;
- exact reason when contractually unique;
- a closed case-specific reason set where check ordering can validly detect
  more than one violated invariant.

For the two replacement cases, either:

- `destination:link-count`; or
- `destination:path-rebinding`

may be valid if the retained trace proves the corresponding invariant failed.

No rejection may be converted into a pass merely because a different valid
invariant was detected first.

Return BLOCK for any altered destination that qualifies.

──────────────────────────────────────────────────────────────────────────────
15. FINDING H — PUBLICATION MODEL
──────────────────────────────────────────────────────────────────────────────

Reconstruct the complete publication state machine directly from source:

- result creation;
- outcome creation;
- staged success-commit creation;
- stage write/fsync/close;
- stage-directory synchronization;
- stage no-follow reopen;
- stage identity and byte verification;
- final-destination preflight;
- exclusive publication;
- authority transition;
- postcommit observation;
- cleanup;
- retry rules.

Verify the Darwin binding for:

`renameatx_np(..., RENAME_EXCL)`

Require:

- exact signature and constant;
- correct path encoding;
- absent destination success;
- existing destination `EEXIST`;
- no overwrite;
- no fallback;
- no copy/delete or link/unlink emulation;
- no existing-final adoption;
- stage/final same-filesystem treatment;
- final-path invocation binding.

The staged record must be nonauthoritative.

The exclusive no-replace publication must be the sole authoritative internal
commit point.

The internal commit must explicitly carry no:

- Git authority;
- external publication authority;
- product/runtime/deployment/readiness/V3/A6 authority.

──────────────────────────────────────────────────────────────────────────────
16. FRESH INDEPENDENT PUBLICATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not use the producer matrix as the audit oracle.

Derive every reachable boundary from source.

At minimum test:

1. before result creation;
2. result write;
3. result fsync;
4. result close;
5. before outcome creation;
6. outcome write;
7. outcome fsync;
8. outcome close;
9. stage creation;
10. stage write;
11. stage fsync;
12. stage close;
13. stage-directory synchronization;
14. stage reopen;
15. stage byte verification;
16. stage identity verification;
17. before exclusive publication;
18. capability failure;
19. exclusive-publication failure;
20. successful exclusive publication;
21. arbitrary preexisting final;
22. byte-valid preexisting final;
23. preexisting final from another invocation;
24. foreign final arriving immediately before publication;
25. cross-filesystem condition;
26. postpublication parent-sync fault;
27. postpublication final-observation fault;
28. postpublication cleanup fault;
29. postpublication reporting fault;
30. postpublication descriptor-close fault;
31. precommit-fragment cleanup fault;
32. fresh-root retry after precommit failure;
33. same-root retry after precommit failure;
34. second invocation after committed success;
35. result mutation after commit;
36. outcome mutation after commit;
37. final-commit mutation after publication;
38. stage residue after publication.

Add every further reachable source boundary.

For every case retain complete replay evidence.

Require:

- zero false acceptance;
- zero false rejection;
- zero skip;
- complete retained replay inputs;
- exact result/outcome/stage/final posture;
- explicit retry and cleanup posture.

Unsupported injections must be classified as unsupported, not passed.

──────────────────────────────────────────────────────────────────────────────
17. FINDING H — COMMIT AND RETRY SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Require:

A. Precommit

- no authoritative success;
- final path absent;
- stage nonauthoritative;
- canonical failure;
- same root nonresumable;
- fresh-root retry only.

B. Commit point

- successful exclusive publication is the one linearization point;
- no adoption;
- exact invocation binding.

C. Postcommit

For every later operation identify:

- whether it can alter final bytes;
- whether its failure changes exit;
- whether it emits a non-downgrading observation;
- whether it can create contradictory failure authority;
- whether retry can occur.

Success may remain authoritative after a later fault only when the contract and
record make the non-downgrading disposition explicit.

Require no crash/power-loss durability claim beyond proven supported-local
semantics.

──────────────────────────────────────────────────────────────────────────────
18. FINDING H PRODUCER MATRIX AND REPLAY
──────────────────────────────────────────────────────────────────────────────

Authenticate:

validation/a-c-h-i-repair/publication-boundary-matrix-final-v3.json

Expected:

- case count:
  30
- case-name digest:
  7e22e5e9f8362e1605f78fac137479b2c48745d1a38a1b88264ccfb6b0142bb4
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- replay-complete:
  30.

For each producer case verify:

- exact source and driver;
- retained fixture;
- immutable inputs;
- injection point;
- actual process/record evidence;
- result/outcome/stage/final posture;
- cleanup;
- replay recipe.

Compare producer coverage against the fresh independent matrix.

Report every omitted or differently classified boundary.

──────────────────────────────────────────────────────────────────────────────
19. FINDING I — REAL CASE 28
──────────────────────────────────────────────────────────────────────────────

Authenticate and inspect the producer’s case 28.

Require that it actually:

1. materializes a fresh package root using the canonical command;
2. binds payload size/hash in the request;
3. mutates payload bytes afterward while preserving size;
4. invokes the copied wrapper through pinned Python and exact wrapper CLI;
5. receives rejection at `payload_identity:sha256`;
6. proves compilation did not begin;
7. proves execution did not begin;
8. produces no expected payload output;
9. creates no child;
10. inspects no target;
11. retains phase start/outcome, streams, exit, and fixture identity.

Independently rerun the case without importing producer helpers.

The static ownership analysis must follow behavior to the owning wrapper layer.
A lexical check confined to `full_audit_bootstrap_v1.py` is insufficient.

──────────────────────────────────────────────────────────────────────────────
20. COMPLETE PRODUCER 50-CASE CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Inspect all 50 producer cases.

For each record:

- name;
- claimed mechanism;
- actual source/function;
- static/source check;
- schema mutation;
- local data mutation;
- production-input mutation;
- wrapper integration;
- bootstrap integration;
- hard-coded fixture;
- synthetic result;
- child process used;
- actual production boundary reached;
- report description accurate;
- retained replay input;
- acceptance role.

Return BLOCK if another materially inaccurate integration claim exists or
qualification depends on a self-fulfilling case described as an external
rejection causal.

Static checks are permitted when described accurately.

──────────────────────────────────────────────────────────────────────────────
21. FINDING J RECORD PARSERS AND REGRESSION
──────────────────────────────────────────────────────────────────────────────

Parse:

validation/a-c-h-i-repair/fresh-independent-j-regression-final-v1.json

Expected identity:

- size:
  299513
- SHA-256:
  7a97496c7c38315dd51773b40d710f12c7eb1c5d541ea4f7fca8adc056fe9145
- schema:
  execution-substrate.validation-custody-v3.fresh-independent-j-regression.v1

Use:

- `/cases`;
- `/case_names`;
- empty arrays for:
  - false_acceptances;
  - false_rejections;
  - reason_mismatches;
  - duplicate_names;
  - missing_expected_names;
- integer `/skip_count`;
- Boolean `/success`.

Expected:

- 928 cases;
- 928 unique names;
- zero error-array entries;
- skip count 0;
- success true;
- name digest:
  1182d02ab865ca2f504dc69d0a88ff118022e98a75433b30701ee0cbd0032d80

The digest encoding is compact, sorted-key, ASCII JSON over `case_names`, plus
one terminal LF.

Independently validate the claimed:

- 919 preserved applicable cases;
- nine obsolete H cases removed;
- nine repaired H cases added.

Run a fresh targeted J matrix against every changed A/C/H/I acceptance surface.

──────────────────────────────────────────────────────────────────────────────
22. FIELD-MAP AND QUALIFICATION PARSERS
──────────────────────────────────────────────────────────────────────────────

Parse:

analysis/a-c-h-i-field-map-and-consistency-v1.json

Expected identity:

- size:
  786291
- SHA-256:
  c013aee294e9efbffc9cca79ed5b16982bf64b521187ec5480a74433d3b9fdcb
- schema:
  execution-substrate.validation-custody-v3.a-c-h-i-repair.field-map-and-consistency.v1

Use:

- `/families`;
- flatten `/families/*/fields/*`;
- require family count 14;
- require flattened row count 1052;
- require each family’s declared count to equal its field-list length;
- require unique `(family, json_pointer)`.

Parse:

validation/qualification-result-v1.json

Expected identity:

- size:
  5338
- SHA-256:
  a2cfaaa9c326aab3628d1929ab6f8e0dfe8412a2d6a0c8dd0baff398e4c46811
- schema:
  execution-substrate.validation-custody-v3.audit-repair.qualification-result.v1

Require its exact 21-field top-level shape and explicit nested structures.

Grammar parsing is separate from independent truth verification.

Absence must never be interpreted as zero.

Do not recursively select arbitrary same-length arrays.

──────────────────────────────────────────────────────────────────────────────
23. PACKAGE VALIDATION COMMANDS
──────────────────────────────────────────────────────────────────────────────

Use this exact common package environment:

HOME=/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private
LANG=C
LC_ALL=C
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
PYTHONDONTWRITEBYTECODE=1
TMPDIR=/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private/tmp

Producer matrix:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I -S -B
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/tests/test_full_audit_bootstrap_v1.py
--package-root
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t
--result
${AUDIT_ROOT}/validation/producer-matrix-fresh.json

- cwd:
  successor package root
- timeout:
  1800 seconds
- result absent before launch
- exit 0 required
- semantic failure exit 1
- CLI failure exit 2.

Do not substitute an audit-generated circular validator for a package validator.

──────────────────────────────────────────────────────────────────────────────
24. CANONICAL MATERIALIZATION COMMAND
──────────────────────────────────────────────────────────────────────────────

Run twice with identical argv, cwd, and environment:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I -S -B
source/full_audit_bootstrap_v1.py
--qualified-launcher-root
/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38
--import-reconciliation-root
/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s
--audit-parent
/Users/ds/Downloads
--audit-prefix
ES-validation-custody-v3-full-audit-

Cwd:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Environment: the exact package environment in §23.

Timeout:

1800 seconds.

Success exit:

0.

Parse the exact stdout root locator using §9.

The two roots must be physically distinct.

Do not substitute:

- another audit parent;
- another prefix;
- another cwd;
- another HOME;
- another TMPDIR;
- a shortened PATH;
- an extra environment variable.

──────────────────────────────────────────────────────────────────────────────
25. CARRIER 0002 HANDOFFS
──────────────────────────────────────────────────────────────────────────────

For each `${ROOT_N}` run:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I -S -B
${ROOT_N}/source/wrapped_carrier_launcher.py
--launch-contract
${ROOT_N}/contract/wrapped-carrier-launch-contract-v1.json
--request
${ROOT_N}/provenance/carrier-0002.request.json

Cwd:

`${ROOT_N}`

Environment:

- exact six-key fixed environment from that root’s launch contract;
- HOME `${ROOT_N}/private/home`;
- TMPDIR `${ROOT_N}/private/tmp`.

Timeout:

600 seconds.

Require:

- exit 0;
- empty stderr;
- request admission;
- constructed launch;
- wrapper admission;
- phase start/outcome;
- same PID;
- exact environment;
- wrapper SHA exact and once;
- CLI conformance;
- no child;
- no target inspection;
- complete expected outputs;
- payload success;
- authoritative commit consistent with result/outcome;
- no second publication or adoption.

──────────────────────────────────────────────────────────────────────────────
26. PACKAGE INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

After both roots and handoffs qualify, run:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I -S -B
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/tests/independent_bootstrap_validator_v1.py
--package-root
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t
--root-a
${ROOT_1}
--root-b
${ROOT_2}
--result
${AUDIT_ROOT}/validation/independent-bootstrap-validator-result-v1.json

Cwd:

successor package root.

Environment:

the exact package environment in §23.

Timeout:

1800 seconds.

Require:

- result absent before launch;
- exit 0;
- exact expected schema;
- both roots bound;
- success true.

──────────────────────────────────────────────────────────────────────────────
27. FRESH INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Separately implement an audit-owned validator that imports neither producer
helpers nor producer fixtures as its oracle.

It must independently test:

- A effective-state and token closure;
- C fresh destination reverification;
- H staged/final publication semantics;
- exclusive no-replace behavior;
- no existing-final adoption;
- precommit/postcommit semantics;
- retry behavior;
- real producer case 28;
- complete producer case classification;
- Finding J preservation;
- qualification-result consistency.

Its literal case registry and expected reasons must be audit-owned and
independent.

Require:

- exact count;
- unique names;
- two-way name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
28. SECURITY AND EXPORT ANALYSIS
──────────────────────────────────────────────────────────────────────────────

Use source-aware AST or equivalent operation-aware analysis.

Distinguish:

- contract data;
- test fixture;
- report text;
- error text;
- actual filesystem operand;
- actual process operand;
- actual network operand;
- actual Git operand.

A string such as:

`v3-target-correctness`

inside nonauthority data is not an operational target path.

Track literals and bounded expressions into sensitive sinks.

Stop for:

- parse failure;
- candidate/target operand reaching an operational sink;
- broad Downloads traversal;
- latest/prefix selection;
- shell/Git/network execution;
- unresolved dynamic sink flow;
- production-reachable fault hook;
- hidden dependency on evidence-only files.

Use behavioral causals when static flow is insufficient.

Do not declare export closure solely from absence of suspicious substrings.

──────────────────────────────────────────────────────────────────────────────
29. FAILED AND SUPERSEDED PRODUCER ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Inspect completely:

provenance/failed-and-superseded-attempts-a-c-h-i-v1.json
provenance/failed-and-superseded-attempts-a-c-h-i-addendum-v1.json
provenance/recorder-continuation-3-recovery-v1.json
provenance/preseal-failed-checks-a-c-h-i-v1.json

For every attempt determine:

- identity;
- operation;
- blocker;
- effects;
- outputs;
- superseding attempt;
- contribution to final result.

Require contribution:

none

for every failed or superseded attempt.

Determine whether any recorder gap or unexplained mutation affects final
package provenance.

Do not fail merely for imperfect producer-process aesthetics when final byte
provenance and qualifying evidence are complete and truthful.

──────────────────────────────────────────────────────────────────────────────
30. CLEANUP
──────────────────────────────────────────────────────────────────────────────

Build the cleanup registry only from:

- validated dynamic root locators;
- fixed audit-owned roots;
- exact audit-owned causal fixture roots.

For each registered root:

1. retain complete pre-removal inventory;
2. require originating child reaped;
3. require descriptors closed;
4. re-lstat and verify original device/inode;
5. remove only the exact registered root;
6. perform two fresh lstat calls;
7. require ENOENT twice;
8. retain cleanup row.

Require exact equality:

created roots
=
inventoried roots
=
cleanup rows
=
twice-absent roots

`cleanup_complete` may be true only when this equality passes.

No broad prefix removal.
No glob deletion.
No latest selection.
No administrative continuation after sealing.

──────────────────────────────────────────────────────────────────────────────
31. PRESEAL GATE
──────────────────────────────────────────────────────────────────────────────

Successful preseal requires:

- every required phase has a terminal result;
- each result passes its exact schema and consistency rules;
- every child effect is attributed;
- every dynamic root is bound by a valid locator;
- no required phase is not reached;
- both materializations pass;
- both handoffs pass;
- package producer validation passes;
- package independent validator passes;
- fresh audit-owned validator passes;
- A/C/H/I/J pass their corrected oracles;
- field-map parsing yields 14 families and 1052 rows;
- J parsing yields 928 cases and the exact name digest;
- security/export analysis passes;
- cleanup-set equality passes;
- supplied-root closing equality passes;
- no required confirmation is false;
- no failed child is treated as a pass;
- no process, descriptor, or audit-owned root survives.

If any condition fails:

- do not claim successful preseal;
- do not create terminal acceptance manifests;
- retain a failure capsule;
- return BLOCK, REJECT, or AUDIT_PROVENANCE_MISMATCH according to the
  substantive verdict rules;
- do not use an administrative continuation.

──────────────────────────────────────────────────────────────────────────────
32. CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Verify pinned Python unchanged.

Do not mutate or clean supplied roots.

Retain all cleanup and closing records before finalization.

──────────────────────────────────────────────────────────────────────────────
33. FOUR PARENT-GENERATED PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

Each must identify:

- exact operands;
- findings;
- limits;
- uncertainty;
- uninspected scope.

They are analytical projections, not separate authorities.

Do not create direct auditors or subagents.

──────────────────────────────────────────────────────────────────────────────
34. TERMINAL CAPSULE
──────────────────────────────────────────────────────────────────────────────

On the success path finalize, before `manifest/`:

- opening records;
- frozen plan;
- parent source;
- complete child ledger;
- package delta and repair authority;
- A evidence;
- C evidence;
- H evidence;
- I evidence;
- J evidence;
- parsers and field maps;
- producer and independent validation;
- materializations and handoffs;
- attempt adjudication;
- four parent perspectives;
- security/export analysis;
- closing equality;
- cleanup;
- final report;
- parent preseal outcome;
- temporal final inventory.

Then create `manifest/` and independently generate manifest A and B.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests;
- no write after manifest closure.

On a failed substantive audit, retain a truthful failure capsule but do not use
the success-preseal or terminal-acceptance captions.

──────────────────────────────────────────────────────────────────────────────
35. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- audit provenance qualifies;
- exact semantic scope qualifies;
- A effective flags and exact-one tokens qualify;
- all invalid A invocations reject;
- C fresh no-follow reverification qualifies;
- every C alteration rejects;
- H exclusive no-replace publication qualifies;
- no preexisting final is adopted;
- commit point is unambiguous;
- precommit failures are nonauthoritative;
- postcommit dispositions are explicit;
- fresh publication matrix passes;
- replay evidence is complete;
- no production-reachable hook exists;
- producer case 28 actually executes the wrapper;
- all 50 producer cases are accurately classified;
- Finding J remains closed;
- field-map and qualification records parse and verify;
- all validators pass;
- two materializations pass;
- two handoffs pass;
- export/security/authority checks pass;
- closing equality passes;
- cleanup-set equality passes;
- terminal capsule closes;
- no acceptance-affecting residual finding remains.

Return BLOCK for any repairable:

- package implementation defect;
- contract/schema defect;
- validation/evidence defect;
- false acceptance;
- ambiguous commit point;
- interpreter-token defect;
- copy-custody defect;
- misleading producer case;
- Finding J regression;
- incomplete replay evidence;
- failed materialization or handoff;
- unresolved security/export concern.

Return REJECT only for fundamental unsoundness outside bounded repair.

Return AUDIT_PROVENANCE_MISMATCH for:

- supplied-root drift or mutation;
- missing fixed input;
- incomplete child effect attribution;
- child-record gap;
- dynamic root without valid locator;
- cleanup-set inequality;
- closing inequality;
- uncaught parent failure;
- terminal capsule failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
36. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Successor identity and closure
4. Predecessor identity and closure
5. Blocking-audit identity and governing findings
6. Process authority and frozen plan
7. Child-ledger and filesystem-effect closure
8. Exact predecessor-successor delta
9. Repair-authority adjudication
10. Finding A source field map
11. Finding A fresh causal matrix
12. Finding C custody model
13. Finding C fresh causal matrix
14. Finding H publication state machine
15. `renameatx_np(RENAME_EXCL)` capability evidence
16. Final success-commit field map
17. Authoritative commit point
18. Fresh publication matrix
19. Precommit/postcommit/retry adjudication
20. Replay-evidence closure
21. Failure-hook reachability
22. Finding I case 28
23. Complete producer 50-case classification
24. Finding J regression
25. Field-map and qualification-result parsing
26. Contract/schema/source/record consistency
27. Package producer validation
28. Package independent validator
29. Fresh audit-owned validator
30. Two materializations
31. Two Carrier 0002 handoffs
32. Security and export analysis
33. Failed/superseded attempt adjudication
34. Four parent perspectives
35. Supplied-root closing equality
36. Cleanup-set equality and ENOENT observations
37. Audit-capsule inventory and manifests
38. Severity-ranked residual findings
39. Remaining uncertainty and nonclaims
40. Explicit confirmations

Required confirmations:

SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_PACKAGE_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_AUDIT_ROOT_NOT_RESUMED
PRIOR_FAILED_AUDIT_ROOT_NOT_MUTATED
PRIOR_FAILED_AUDIT_EVIDENCE_NOT_REUSED
SURVIVING_HISTORICAL_ROOTS_NOT_OPENED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
FINITE_ONE_SHOT_PARENT_USED
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
FROZEN_AUDIT_PLAN_RETAINED
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
CHILD_FILESYSTEM_EFFECTS_COMPLETELY_ATTRIBUTED
DYNAMIC_ROOT_LOCATORS_VALIDATED
EXACT_SIX_PATH_SEMANTIC_SCOPE_VERIFIED
UNAUTHORIZED_SEMANTIC_DRIFT_ABSENT
FINDING_J_OWNED_SCHEMAS_BYTE_IDENTICAL
INTERPRETER_EFFECTIVE_FLAGS_VERIFIED
INTERPRETER_LITERAL_TOKENS_VERIFIED
DUPLICATE_INTERPRETER_TOKEN_REJECTED
MISSING_I_REJECTED
MISSING_S_REJECTED
MISSING_B_REJECTED
ENVIRONMENT_CANNOT_SUBSTITUTE_FOR_MISSING_B
POST_COPY_DESTINATION_FRESHLY_REOPENED
POST_COPY_BYTES_FRESHLY_READ_AND_HASHED
CACHED_IDENTITY_NOT_ACCEPTANCE_BEARING
PATH_REBINDING_OR_REPLACEMENT_DETECTED
SAME_SIZE_IN_PLACE_MUTATION_REJECTED
STAGED_SUCCESS_COMMIT_NONAUTHORITATIVE
EXCLUSIVE_ATOMIC_NO_REPLACE_PUBLICATION_VERIFIED
NO_PUBLICATION_FALLBACK
PREEXISTING_FINAL_NOT_ADOPTED
AUTHORITATIVE_COMMIT_POINT_UNAMBIGUOUS
PRECOMMIT_FAILURES_NONAUTHORITATIVE
POSTCOMMIT_DISPOSITION_EXPLICIT
POSTCOMMIT_FAILURES_NON_DOWNGRADING
RETRY_BEHAVIOR_VERIFIED
PUBLICATION_BOUNDARY_MATRIX_INDEPENDENTLY_PASSED
PUBLICATION_REPLAY_EVIDENCE_COMPLETE
NO_DELETED_REPLAY_FIXTURE_REQUIRED
NO_PRODUCTION_REACHABLE_FAILURE_HOOK
PRODUCER_CASE_28_EXECUTED_WRAPPER
WRONG_PAYLOAD_REJECTED_AT_PAYLOAD_IDENTITY
PRODUCER_50_CASES_ACCURATELY_CLASSIFIED
FINDING_J_928_CASE_REGRESSION_PASSED
FIELD_MAP_14_FAMILIES_1052_ROWS_VERIFIED
QUALIFICATION_RESULT_CLOSURE_VERIFIED
CONTRACT_SCHEMA_SOURCE_RECORD_CONSISTENCY_VERIFIED
PACKAGE_PRODUCER_VALIDATION_PASSED
PACKAGE_INDEPENDENT_VALIDATOR_PASSED
FRESH_AUDIT_OWNED_VALIDATOR_PASSED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_FRESH_CARRIER_0002_HANDOFFS_PASSED
PRODUCTION_EXPORT_BOUNDARY_CLOSED
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY
INTERNAL_COMMIT_NOT_GIT_OR_EXTERNAL_PUBLICATION_AUTHORITY
NO_DIRECT_AUDITORS_USED
NO_SUBAGENTS_CREATED
CREATED_ROOTS_EQUAL_CLEANUP_ROWS
CREATED_ROOTS_TWICE_ABSENT
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
FULL_V3_TARGET_AUDIT_NOT_STARTED
A6_NOT_STARTED
```

Do not begin another package implementation or findings-reconciliation tranche
unless this audit reaches a concrete successor-package defect.
:::

**Source:** Codex’s `FAILED_AUDIT_HARNESS_RECONCILED_READY_FOR_FRESH_AUDIT` report in the current turn.

**Confidence:** 0.99 that the audit harness is now sufficiently specified for a decisive retry; 0.98 that the duplicate-`-I` case is the most likely substantive blocker; 0.995 that no further package change is presently authorized.
