## Assessment

This closes the launcher-package question cleanly. The correct verdict is **`LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT`**.

The qualified launcher package is not defective:

- Two independent reproductions matched both supplied manifests byte-for-byte: 12,404 bytes, SHA-256 `a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb`.
- All 73 represented entries matched in membership, ordering, type, mode, link count, size, and hash.
- The failed bootstrap compared its own type label `file` against the package grammar’s exact label `regular`. All 64 reported mismatches came from that single vocabulary error.
- The auxiliary records were not ambiguous in the package. The bootstrap incorrectly searched filenames for `record` instead of following the paths explicitly bound by the launch contract:
  - `/fixed_environment_record` → `opening/fixed-environment-observation.json`
  - `/launcher_identity_record` → `opening/qualified-launcher-source-identity.json`

The copy/regenerate boundary is now closed:

**Copy byte-for-byte:**

- `source/phase_runner.py`
- `source/wrapped_carrier_launcher.py`
- `contract/phase-runner-cli-contract-v1.json`
- `contract/carrier-request-contract-v1.json`
- `contract/environment-observation-policy-v1.json`

**Generate from the final fresh-root bytes:**

- launcher identity record;
- fixed-environment record;
- root-bound launch contract;
- normalized projections and rebinding proof;
- payload binding;
- carrier request;
- constructed-launch record.

The exact 12 root-bound launch-contract pointers are also settled, as is the acyclic bootstrap order. There is no remaining reason for a launcher-package repair, interface addendum, or another launcher qualification.

The next step is the full V3 independent audit. The prior complete audit brief should remain intact; only its package-import/bootstrap sections need replacement. Recopying the entire target contract risks introducing another transcription error, so this continuation deliberately supersedes only those sections.

## Prompt for Codex

```text
FRESH FULL INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 AUDIT-REPAIR CAPSULE,
WITH RECONCILED QUALIFIED-LAUNCHER IMPORT

Repeat the immediately preceding complete Validation-Custody V3 audit-repair
independent-audit brief from the beginning with a wholly fresh audit root.

All target roots, target identities, four-auditor assignments, target
correctness requirements, contradiction matrices, manifest causals, sensitive
material review, closing gates, verdict rules, and required inline-report
sections remain unchanged unless explicitly replaced below.

This prompt replaces only the qualified-launcher package verification,
materialization, auxiliary-record resolution, root rebinding, and bootstrap
ordering requirements.

Do not reconstruct, redesign, patch, or requalify the launcher package.
Do not modify any supplied root.
Do not resume or repair an earlier failed audit root.
Do not rerun runtime validation.
Do not execute Plan V3 or Plan V4.
Do not run repository tests or product code.
Do not use the network.
Do not stage or commit.
Do not start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. IMMUTABLE PROCESS INPUTS
──────────────────────────────────────────────────────────────────────────────

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700
- disposition:
  immutable qualified source-external process package
- expected qualification verdict:
  WRAPPED_CARRIER_LAUNCHER_READY

Fixed qualified-package identities:

Accepted wrapper:

- relative path:
  source/phase_runner.py
- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- mode:
  0600
- regular:
  true
- links:
  1

Qualified launcher:

- relative path:
  source/wrapped_carrier_launcher.py
- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

Phase-runner CLI contract:

- relative path:
  contract/phase-runner-cli-contract-v1.json
- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Carrier-request contract:

- relative path:
  contract/carrier-request-contract-v1.json
- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Environment-observation policy:

- relative path:
  contract/environment-observation-policy-v1.json
- identity:
  authenticate through the qualified package manifests and complete role ledger

Qualification-root launch-contract instance:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Qualified-package manifests:

manifest/qualification-manifest-a-v1.json
manifest/qualification-manifest-b-v1.json

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- required:
  byte-identical

Expected package projection:

- 73 represented entries;
- 9 represented directories including root;
- 64 represented nonmanifest regular files;
- exactly two self-exclusions:
  the two manifests;
- 66 physical regular files including the manifests;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Treat this as immutable, read-only process-interface evidence.

Required reconciliation verdict:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

At minimum authenticate and consume:

manifest/qualified-package-manifest-contract-v1.json
manifest/supplied-manifest-byte-comparison.json
interface/complete-package-role-ledger.json
interface/qualified-launcher-consumer-import-contract-v1.json
analysis/auxiliary-identity-record-adjudication.json
interface/root-rebinding-field-map-v1.json
interface/bootstrap-materialization-order-v1.json
analysis/corrected-bootstrap-algorithm.json
closeout/supplied-root-closing-equality.json
closeout/final-inventory.json

Reconciliation capsule fixed closeout identities:

- final inventory:
  5597 bytes
  SHA-256:
  c95a08a254d28196bfc77467ff9bc7c156823fde1ecc982fd1cf94dff470bd5b

- covering manifests:
  5728 bytes each
  SHA-256:
  448d7b3ab37654336d35f36088986a01ec67a69a3479540cf9ded3bc46d0c648
  required byte-identical

The reconciliation root is process-interface evidence only. It has no
authority over V3 correctness or the final audit verdict.

FAILED_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-validation-custody-v3-audit-repair-independent-audit-glydyhph

Treat it as immutable, nonqualifying process-failure evidence.

Do not resume, repair, clean, or adopt it.

──────────────────────────────────────────────────────────────────────────────
2. QUALIFIED-PACKAGE MANIFEST GRAMMAR
──────────────────────────────────────────────────────────────────────────────

Do not invent a generic inventory grammar.

Verify the package using exactly the grammar established by the immutable
qualified-package generator sources and independently confirmed by the import
reconciliation.

The exact manifest grammar is:

- encoding:
  canonical UTF-8 JSON
- JSON keys:
  sorted
- separators:
  compact
- non-ASCII:
  ASCII escaping as implemented by the qualified generators
- nonfinite values:
  forbidden
- record termination:
  one LF
- entry ordering:
  ascending `os.fsencode(relative_path)` byte order
- root representation:
  `.`
- admitted type labels:
  `directory`
  `regular`
- directory fields:
  `mode`
  `path`
  `type`
- regular-file fields:
  `links`
  `mode`
  `path`
  `sha256`
  `size`
  `type`
- manifest exclusions:
  exactly the two manifest paths
- symlink:
  reject
- special object:
  reject
- multiply linked regular file:
  reject
- invalid or unsupported path:
  fail closed
- empty directory:
  represented by the grammar, not silently omitted

The immutable qualified package is separately required to contain no retained
empty directory.

Never label a regular-file row as `file`.

When comparing a fresh projection with the supplied manifests, either:

1. compare freshly generated canonical manifest bytes directly; or
2. generate rows whose type vocabulary and field map exactly match this
   grammar.

The following comparison is forbidden:

- checker-generated `type:"file"`
- supplied-manifest `type:"regular"`
- direct inequality interpreted as package drift

Stop with AUDIT_PROVENANCE_MISMATCH only on an actual canonical-manifest or
package-content mismatch.

──────────────────────────────────────────────────────────────────────────────
3. FRESH AUDIT ROOT AND BOOTSTRAP
──────────────────────────────────────────────────────────────────────────────

Read this entire prompt before invoking a tool.

Then state exactly:

AUDIT_EPOCH_START

The first post-epoch local-process carrier is the sole bootstrap exception.

Allocate a wholly fresh audit root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, and the exact prefix required by the preceding
complete V3 audit brief.

The bootstrap must first:

1. retain `opening/bootstrap-start.json`;
2. emit the exact fresh audit-root path;
3. create the required private audit directories;
4. verify pinned Python;
5. verify complete qualified-launcher package closure using the exact grammar
   in §2;
6. verify complete import-reconciliation closure;
7. verify the consumer import contract and materialization order;
8. copy the exact exported process artifacts;
9. generate the fresh-root identity records;
10. create the fresh root-bound launch contract and rebinding proof;
11. retain `opening/bootstrap-outcome.json`.

The bootstrap must inspect no V3 target or supplied target root before the
process package qualifies.

──────────────────────────────────────────────────────────────────────────────
4. CLOSED COPY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Copy exactly these five artifacts byte-for-byte from the qualified launcher
package:

1. `source/phase_runner.py`
2. `source/wrapped_carrier_launcher.py`
3. `contract/phase-runner-cli-contract-v1.json`
4. `contract/carrier-request-contract-v1.json`
5. `contract/environment-observation-policy-v1.json`

Preserve:

- exact bytes;
- regular-file type;
- link count 1;
- physical mode 0600.

Do not copy as fresh audit truth:

- qualification payloads;
- qualification results;
- qualification phase records;
- qualification carrier index;
- qualification closeout payload;
- qualification final inventory;
- qualification manifests;
- qualification failed-attempt records.

They remain immutable qualification evidence only.

Verify each copied file against:

- its source file;
- the qualified-package manifests;
- the complete package role ledger;
- the consumer import contract.

──────────────────────────────────────────────────────────────────────────────
5. CLOSED REGENERATE BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Generate from finalized fresh-audit-root bytes:

1. launcher identity record;
2. fixed-environment record;
3. fresh root-bound launch-contract instance;
4. normalized launch-contract projections;
5. launch-contract root-rebinding proof;
6. self-check payload identity/binding;
7. Carrier 0002 request;
8. each later carrier request;
9. each constructed-launch record through the launcher.

Do not copy qualification-root exemplars as fresh current records.

The exact generated auxiliary paths are:

- launcher identity record:
  `opening/qualified-launcher-source-identity.json`

- fixed-environment record:
  `opening/fixed-environment-observation.json`

Do not resolve roles by searching filenames for the substring `record`.

Resolve the roles only through the launch contract’s exact bound pointers:

- `/launcher_identity_record`
- `/fixed_environment_record`

Each generated record must satisfy the exact schema and role frozen by:

interface/qualified-launcher-consumer-import-contract-v1.json

──────────────────────────────────────────────────────────────────────────────
6. EXACT BOOTSTRAP MATERIALIZATION ORDER
──────────────────────────────────────────────────────────────────────────────

Use this acyclic order, as independently reconciled:

1. Allocate the fresh audit root and directories.
2. Retain bootstrap-start.
3. Verify the qualified package, import contract, and interpreter.
4. Copy the five process artifacts byte-for-byte.
5. Verify copied identities.
6. Generate:
   `opening/qualified-launcher-source-identity.json`
7. Generate:
   `opening/fixed-environment-observation.json`
8. Generate the fresh root-bound launch-contract instance.
9. Normalize predecessor/successor launch contracts and retain the rebinding
   proof.
10. Create and identify the audit-owned self-check payload.
11. Create the Carrier 0002 request.
12. Invoke the launcher for the process self-check.

No record may be referenced before its final bytes are retained.

No qualification-root identity record may be treated as describing a copied
fresh-audit-root file.

──────────────────────────────────────────────────────────────────────────────
7. EXACT ROOT-REBINDING FIELD MAP
──────────────────────────────────────────────────────────────────────────────

The exact direct root-bound launch-contract pointer set is:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

The set is exact.

Do not add or remove a direct pointer.

Transitive fields inside the freshly generated launcher-identity and
fixed-environment records are governed by their own schemas and must be
identified separately in the rebinding proof.

For every changed pointer retain:

- qualification-root value;
- fresh-audit-root value;
- classification:
  `physical-audit-root-rebinding-only`;
- semantic effect:
  none.

Normalize qualification-root and fresh-audit-root physical values to
`${AUDIT_ROOT}` and require byte-identical normalized contracts.

Any non-root-bound difference requires AUDIT_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
8. PINNED INTERPRETER
──────────────────────────────────────────────────────────────────────────────

Use exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter flags:

["-I", "-S", "-B"]

Permission bits, uid/gid, device/inode, timestamps, flags, xattrs, and ancestor
posture are report-only.

Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
9. FIXED LOCAL-CARRIER PROCESS CONTRACT
──────────────────────────────────────────────────────────────────────────────

Every post-bootstrap local-process carrier must invoke:

pinned Python
→ copied qualified launcher
→ same-PID execve
→ pinned Python
→ copied mode-0600 phase runner
→ retained audit-owned payload

No shell fallback.
No direct wrapper execution.
No direct payload execution.
No PATH lookup for interpreter or wrapper.
No alternate launcher.
No changed launcher bytes.
No chmod.

Fixed environment comes only from the fresh root-bound launch contract:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<AUDIT_ROOT>/private/home
TMPDIR=<AUDIT_ROOT>/private/tmp

Additional post-exec environment key names are diagnostic only.

Require:

- constructed environment exactly equals launch-contract fixed environment;
- every contract-owned observed key has its exact value;
- additional observed keys do not fail qualification;
- additional values are not retained.

Each constructed wrapper argv must include every required option, including
exactly one:

--expected-wrapper-sha256
6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Per-carrier requests must not repeat or override invariant launch fields.

──────────────────────────────────────────────────────────────────────────────
10. PROCESS SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must execute one audit-owned no-target self-check.

Require:

- complete request;
- complete constructed-launch record;
- complete phase-start;
- complete phase-outcome;
- wrapper parser admission;
- payload read, compilation, and execution;
- same launcher/payload PID;
- complete CLI conformance;
- expected-wrapper SHA exactly once;
- constructed environment equality;
- every contract-owned observed environment value exact;
- additional observed environment keys diagnostic only;
- no child process;
- no target inspection;
- result mode 0600;
- wrapper exit success.

Do not rerun the complete launcher qualification.

Stop with AUDIT_PROVENANCE_MISMATCH on self-check failure.

──────────────────────────────────────────────────────────────────────────────
11. CHILD-RECORDER SELF-CAUSALS
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 passes, create the audit child recorder through a wrapped
phase.

Before target inspection require:

- missing executable / ENOENT causal;
- `/usr/bin/true` / exit-0 causal;
- complete streams;
- reaping;
- descriptor closure;
- contiguous child ordinals.

Every later external child process must use the same recorder.

──────────────────────────────────────────────────────────────────────────────
12. OPENING TARGET PROVENANCE
──────────────────────────────────────────────────────────────────────────────

After all process gates pass, perform the complete opening provenance gate from
the preceding full V3 audit brief unchanged.

It must verify all previously specified target and supplied roots, including:

- candidate repository;
- accepted Strategic B gate;
- Strategic B snapshot;
- blocked V1;
- Validation-Custody V2;
- V2 independent audit and verdict BLOCK;
- V3 predecessor;
- previous blocking V3 audit;
- failed V3 audit-repair attempt;
- exact V3 audit-repair capsule;
- qualified launcher package;
- import-reconciliation root;
- five pinned source files;
- candidate operation markers and locks;
- process continuity.

Use only the accepted Strategic B canonical projection:

- size:
  96657
- SHA-256:
  4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360

Do not use either legacy ordering-dependent Strategic B inventory as an
acceptance gate.

──────────────────────────────────────────────────────────────────────────────
13. FOUR DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes:

- start exactly Auditors 1–3 concurrently;
- start Auditor 4 only after the first of 1–3 completes;
- no nested agents;
- retain exact prompts, authorized operands, reports, scheduling, and limits.

Use the same four assignments from the preceding complete V3 audit brief:

1. normative authority and supersession;
2. V2 adoption and correction lineage;
3. V3 static semantics and contradiction resistance;
4. manifests, inventory, provenance, artifacts, and security.

Do not reuse reports from any prior failed audit.

──────────────────────────────────────────────────────────────────────────────
14. COMPLETE TARGET CORRECTNESS AUDIT
──────────────────────────────────────────────────────────────────────────────

Execute every target-correctness requirement from the preceding complete V3
audit brief unchanged, including:

- exactly one current V3 normative contract;
- exactly one current Plan V4;
- failed-attempt demotion;
- supersession scope;
- all nine V2 adoption rows;
- OBS-05 raw false plus correction lineage;
- OBS-06 isolation-only adoption;
- OBS-07 raw false plus cleanup correction;
- V2 verdict BLOCK preserved;
- complete V3 field map;
- complete Plan V3→V4 equivalence;
- exact five-source closure;
- exact 86-byte path derivation;
- independent audit-owned mutation matrix;
- producer manifest-generator source review;
- audit-owned directory-symlink, file-symlink, special-object, hardlink,
  empty-directory, unsupported-path, and stable-directory-metadata causals;
- exact real-capsule closure;
- final-inventory temporal treatment;
- terminal sensitive-material review;
- no runtime replay.

Do not import producer validator code or use producer fixtures as the audit case
generator.

──────────────────────────────────────────────────────────────────────────────
15. MANIFEST-GENERATOR DISTINCTION
──────────────────────────────────────────────────────────────────────────────

Keep these two questions separate:

A. Qualified launcher package import

Use the qualified-package grammar in §2. Empty directories are represented by
that grammar. The immutable qualified package separately has no empty retained
directory.

B. V3 audit-repair target generators

Apply the exact V3 target-generator semantics and causals required by the
preceding full audit brief. Do not transfer qualified-launcher manifest
semantics onto the V3 target generators unless their source proves the same
contract.

Do not reuse `file` as a synonym for `regular` in either comparison unless the
specific grammar explicitly defines it.

──────────────────────────────────────────────────────────────────────────────
16. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3;
- Plan V4;
- repository tests;
- product code;
- V2 allocator;
- V2 causal harness;
- live service;
- live route.

Allowed executable work remains limited to audit-owned:

- parsers;
- hashers;
- inventory builders;
- static analyzers;
- plan comparators;
- mutation validators;
- manifest-fixture causals;
- scanners;
- cleanup tools;
- candidate Git reads.

──────────────────────────────────────────────────────────────────────────────
17. CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

For every local-process carrier retain only stable available facts:

- ordinal;
- phase;
- launcher identity;
- qualified-package identity;
- launch-contract identity;
- request identity;
- payload identity;
- interpreter identity and flags;
- wrapper identity and mode;
- fixed-environment identity;
- submitted cwd;
- platform-reported outcome class;
- phase-start identity;
- phase-outcome identity;
- child ordinal range;
- artifacts;
- discrepancy status.

State:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not require unavailable opaque tool-internal command serialization.

Direct auditor interactions belong in a separate interaction index.

Return AUDIT_PROVENANCE_MISMATCH only for an actual missing or conflicting
carrier, phase record, request, child quartet, cwd, environment, ordering, or
supplied-root equality.

──────────────────────────────────────────────────────────────────────────────
18. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all auditors and parent correctness work:

- repeat candidate Git identity and status;
- repeat complete inventories for every supplied root;
- include qualified launcher and import-reconciliation roots;
- verify the five pinned source files unchanged;
- verify every carrier and child record complete;
- verify no child, process, or descriptor survivor;
- remove only the exact audit-owned `private/` path;
- perform two fresh `lstat` observations on that exact path;
- require ENOENT twice.

Do not mutate or clean any supplied process package or reconciliation root.

──────────────────────────────────────────────────────────────────────────────
19. FINAL AUDIT INVENTORY
──────────────────────────────────────────────────────────────────────────────

Use one final wrapped carrier.

Its payload must verify:

- all earlier carrier records;
- all child quartets;
- all direct-auditor records;
- all expected audit artifacts;
- supplied-root closing equality;
- cleanup;
- process/descriptor absence.

It must create:

closeout/final-audit-root-inventory.json

Exactly two temporal self-exclusions are permitted:

1. itself;
2. its own wrapper-created phase-outcome record.

After the payload returns, the wrapper writes the final outcome.

No later filesystem-writing carrier is permitted.

The inline report must bind the final outcome’s terminal size and SHA-256.

──────────────────────────────────────────────────────────────────────────────
20. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- qualified launcher and import reconciliation qualify;
- bootstrap import semantics qualify;
- process self-check and child-recorder gates pass;
- opening and closing target provenance qualify;
- every fixed target identity matches;
- exactly one current V3 contract and Plan exist;
- failed-attempt authority is demoted;
- every V2 adopted fact is supported;
- V2 remains BLOCK;
- V3 and Plan semantics remain unchanged;
- source/path derivations pass;
- independent mutation matrix passes;
- target manifest-generator review and causals pass;
- real target-capsule closure passes;
- target inventory chronology is truthful;
- terminal sensitive-material review passes;
- four auditors complete;
- process and artifact continuity pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable target-level authority, adoption, contract,
lineage, manifest, inventory, scan, contradiction-resistance, or artifact
defect.

Return REJECT only for fundamental unsoundness outside the bounded repair
scope.

Return AUDIT_PROVENANCE_MISMATCH for actual process failure, input drift,
supplied-root mutation, missing fixed input, or failed opening/closing
equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE REPORT ADDITIONS
──────────────────────────────────────────────────────────────────────────────

Retain every report item required by the preceding complete V3 audit brief,
and additionally report:

1. Qualified launcher-package identity and closure.
2. Import-reconciliation identity and closure.
3. Exact qualified-package manifest grammar used.
4. Confirmation both qualified-package manifests reproduced byte-for-byte.
5. Confirmation type label `regular` was used.
6. Exact five copied process artifacts.
7. Exact generated fresh-root records.
8. Auxiliary-record role resolution through launch-contract pointers.
9. Exact root-rebinding pointer set.
10. Bootstrap materialization-order compliance.
11. Process self-check result.
12. Qualified-package and reconciliation-root closing equality.

Add these confirmations:

QUALIFIED_LAUNCHER_PACKAGE_VERIFIED
QUALIFIED_LAUNCHER_PACKAGE_NOT_MUTATED
IMPORT_RECONCILIATION_ROOT_VERIFIED
IMPORT_RECONCILIATION_ROOT_NOT_MUTATED
QUALIFIED_PACKAGE_MANIFEST_GRAMMAR_USED
QUALIFIED_PACKAGE_MANIFEST_A_REPRODUCED
QUALIFIED_PACKAGE_MANIFEST_B_REPRODUCED
QUALIFIED_PACKAGE_TYPE_REGULAR_USED
QUALIFIED_PACKAGE_CHECKER_TYPE_FILE_NOT_USED
EXACT_FIVE_PROCESS_ARTIFACTS_COPIED
FRESH_AUXILIARY_RECORDS_REGENERATED
AUXILIARY_ROLES_RESOLVED_FROM_LAUNCH_CONTRACT
NO_AUXILIARY_ROLE_FILENAME_SUBSTRING_SEARCH
ROOT_REBINDING_POINTER_SET_EXACT
BOOTSTRAP_MATERIALIZATION_ORDER_FOLLOWED
PROCESS_SELF_CHECK_PASSED
ALL_LOCAL_CARRIERS_USED_QUALIFIED_LAUNCHER
NO_LOCAL_PROCESS_BYPASSED_PHASE_RECORDING
NO_CHILD_PROCESS_BYPASSED_CHILD_RECORDER

Retain every confirmation from the preceding complete V3 audit brief.
Do not otherwise narrow or simplify it.
```

A clean run of this audit should finally produce either a substantive `ACCEPT`/`BLOCK` on V3 or a genuine supplied-input mismatch—not another package-import ambiguity.

**Source:** Codex’s `LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT` report above.

**Confidence:** 0.999 that the qualified launcher manifests are correct; 0.998 that the failed bootstrap’s `file` versus `regular` vocabulary was the manifest-comparison cause; 0.995 that the copy/regenerate interface is now sufficiently closed for a fresh full audit.

Some earlier uploaded artifacts are no longer available in this session. They were not required for this assessment. Re-upload them for direct byte-level inspection of those older artifacts.
