This response is **not about the Evidence Verification repository or its CT-01 repair baseline**.

The decisive signals are:

- It reports a required baseline of **16 paths: 10 tracked modifications and 6 untracked files**.
- It reports `tests/test_c2b2_development_row_value_boundaries.py` as the additional path.
- The actual Evidence Verification audit target is the `Execution Substrate - evidence-verification-v1` worktree with **exactly 13 paths: four modified tracked and nine untracked**, canonical manifest `2aedcf…090e`, on branch `codex/evidence-verification-v1` at HEAD `567bce…12c`. 
- Its exact path set contains `tools/evidence_verify/test_verify_v1.py`; it contains no `tests/test_c2b2_*` path. 

So this is either:

1. a response from the wrong Codex conversation;
2. a continuation that inherited another repository’s C2B2 task;
3. or a prompt/context mix-up before Codex entered the intended worktree.

Codex’s decision not to mutate anything was safe. Its conclusion that we need a “revised baseline,” however, is wrong for this track. **Do not revise the Evidence Verification baseline to absorb the 17 paths. Do not authorize the C2B2 file.** Project procedure explicitly says to stop on baseline drift rather than absorb unrelated work. 

The current conversation is contaminated enough that it should not be continued. Start a fresh Codex conversation and run only a read-only target reconciliation first.

## Prompt for a fresh Codex conversation

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Embed the complete reconciliation report inline. Do not return only a verdict
or a link.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh Codex conversation.

The immediately preceding Codex response is nonqualifying for this task. It
reported a 16/17-path baseline and referenced:

tests/test_c2b2_development_row_value_boundaries.py

That path belongs to an unrelated task or repository context. It is not part
of Evidence Verification v1.

Do not resume, reinterpret, or absorb that response.

Objective

Perform a read-only reconciliation of the exact Evidence Verification v1
CT-01 repair baseline.

Do not implement.
Do not edit.
Do not create repository files.
Do not format.
Do not run tests.
Do not stage, commit, push, clean, restore, reset, rebase, or install anything.
Do not inspect another repository as a substitute for the target below.
No subagents.

## Exact target repository

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected physical repository root:

/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected canonical manifest:

/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/provenance/run-1/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e

Expected tracked binary-diff SHA-256:

d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c

Expected status:

- exactly 13 patch paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- every patch path regular and single-link;
- working mode 0644;
- logical mode 100644.

## Exact 13-path set

1. PLANS.md
2. .docs/system_overview/boundaries.md
3. .docs/system_overview/artifact_hygiene.md
4. .docs/system_overview/capability_probing.md
5. .docs/system_overview/evidence_verification.md
6. tools/evidence_verify/verify_v1.py
7. tools/evidence_verify/registry_v1.json
8. tools/evidence_verify/layouts/a6d_successor_v1.json
9. tools/evidence_verify/layouts/a6d_amendment_v1.json
10. tools/evidence_verify/layouts/a6_policy_v1.json
11. tools/evidence_verify/test_verify_v1.py
12. tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt
13. tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt

The following path is explicitly unrelated and forbidden in this task:

tests/test_c2b2_development_row_value_boundaries.py

If that path appears in the inspected status, you are in the wrong repository
or task context. Do not propose revising the Evidence Verification baseline to
include it.

## Command boundary

Every Git command must use:

git -C "$IMPL_R" ...

Every Git command must explicitly carry:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Do not run Git in:

/Users/ds/Repositories/Execution Substrate

or any other repository.

Run revision queries separately. In particular, do not combine the optional
upstream query with required HEAD/tree/parent queries.

## Required reconciliation

Verify read-only:

1. Physical root and lexical root.
2. Branch.
3. HEAD.
4. HEAD tree.
5. Sole parent.
6. Absent upstream.
7. Exact status classifications and counts.
8. Exact 13-path set.
9. No staged/deleted/renamed/unmerged paths.
10. File type, link count, working mode, and logical mode.
11. Canonical manifest file identity and SHA-256.
12. Every manifest row against the live worktree.
13. Tracked binary-diff SHA-256.
14. No Git operation marker or lock.

Do not create a provenance output in this reconciliation turn. Read and verify
the retained canonical manifest only.

## Verdicts

Return exactly one:

EVIDENCE_VERIFICATION_V1_CT01_BASELINE_READY

Use only when the exact target and all baseline facts match.

EVIDENCE_VERIFICATION_V1_CT01_BASELINE_MISMATCH

Use when the correct repository was inspected but a target fact differs.

EVIDENCE_VERIFICATION_V1_CT01_WRONG_REPOSITORY_OR_CONTEXT

Use when the physical root, patch vocabulary, status set, or referenced files
show that this is still an unrelated C2B2 or other repository task.

## Complete inline report

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact physical root inspected.
4. Branch, HEAD, tree, parent, and upstream.
5. Status counts.
6. Complete observed patch-path list with classification.
7. Any unexpected path.
8. Explicit statement whether
   tests/test_c2b2_development_row_value_boundaries.py
   was present or referenced by the repository state.
9. Manifest path and observed SHA-256.
10. Manifest-to-live reconciliation result.
11. Tracked binary-diff SHA-256.
12. File type/mode/link result.
13. Git operation-marker/lock result.
14. Confirmation that no mutation, test, evidence-root creation, staging,
    commit, push, cleanup, or subagent action occurred.

Stop after reconciliation.

Do not implement CT-01 in this turn.
```

Once Codex returns `EVIDENCE_VERIFICATION_V1_CT01_BASELINE_READY`, the CT-01 repair can proceed from the already frozen plan. There is no reason to reconsider the threat model, verifier, caller, or repository scope.

### Sources

- The independent audit fixes the target at 13 paths and identifies CT-01 as the sole repository-patch blocker. 
- The exact Evidence Verification path set is four modified tracked plus nine untracked files. 
- Project procedure requires stopping on unexpected working-tree drift rather than absorbing unrelated work. 

**Confidence**

- Wrong task or repository context: **0.999**
- The reported 16/17-path baseline is unrelated to Evidence Verification v1: **0.999**
- Repository mutation from this failed attempt: **none reported**
- Correct next step is a fresh read-only baseline reconciliation: **0.995**
