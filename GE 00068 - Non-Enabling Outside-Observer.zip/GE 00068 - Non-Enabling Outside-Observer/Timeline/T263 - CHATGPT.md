## Assessment

This is a **pure audit-process failure**, and Codex classified it correctly as `AUDIT_PROVENANCE_MISMATCH`.

The decisive event was simple: process sequence 8 attempted to launch absent `/opt/homebrew/bin/rg`; `FileNotFoundError` occurred before the audit runner created the mandatory contemporaneous process record. Because the audit contract prohibited reconstructing missing process evidence, the attempt became nonqualifying immediately.

Nothing in this report warrants another V3 producer repair:

- Candidate and supplied-root opening/closing identities matched.
- The V3 physical capsule posture matched its expected directories, files, modes, and fixed artifact identities.
- All pinned source files, including `itoa.go`, matched.
- No supplied input was mutated.
- No target-level contract, plan, authority, or provenance defect was established.

The raw observations about the V3 contract and Plan V3→V4 are encouraging but correctly excluded. They are not audit findings because strict parsing, normalization, evidence adoption, contradiction testing, and the four-auditor pass never began.

The next action is a **wholly fresh retry of the same narrow independent audit**, with no change to V3. The retry needs one material procedural improvement: the process recorder must persist its start record **before attempting process creation** and must retain a complete outcome even when `exec`/spawn fails. It should also avoid optional tools such as `rg`; Python standard-library traversal and matching are sufficient.

## Prompt for Codex

```text
FRESH NARROW INDEPENDENT AUDIT RETRY —
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 RECORD COMPLETION

Perform a wholly fresh, independent, read-only audit of the combined target:

1. the immutable Repair 10I T2A-P strategic B snapshot;
2. the immutable blocked V1 validation-custody capsule;
3. the immutable V2 validation-custody capsule;
4. the immutable V2 independent audit; and
5. the immutable V3 record-completion capsule.

Do not repair anything.
Do not create nested subagents.
Do not reuse the failed audit root.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether V3:

- completely and unambiguously freezes the validation-custody contract;
- preserves all Plan V3 executable and acceptance semantics in Plan V4;
- completes the exact source closure of the 86-byte path-budget derivation;
- adds the required explicit nonauthority statements;
- correctly composes bounded V2 technical evidence without promoting the V2
  audit’s BLOCK verdict;
- has independent contradiction resistance;
- has complete provenance and artifact closure;
- creates no competing B-source authority or competing normative writer.

An ACCEPT qualifies the record-complete validation-custody contract. It does
not grant publication, commit, product, deployment, runtime, readiness, or A6
authority.

──────────────────────────────────────────────────────────────────────────────
1. ADMINISTRATIVE INTAKE AND AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Read the complete prompt before invoking any tool or process.

Administrative prompt intake before the audit epoch is excluded from evidence.
Do not inspect the candidate repository or any supplied evidence root during
administrative intake.

After the complete prompt has been read, state exactly:

AUDIT_EPOCH_START

The first post-epoch process must:

- use the candidate repository as cwd;
- carry the explicit environment in §4;
- set umask 077;
- allocate the fresh audit root using `tempfile.mkdtemp`;
- create the required private directories;
- create an exclusive mode-0600 bootstrap record before target inspection;
- create the audit-owned process runner specified in §2.

No correctness or target-content inspection may begin until the process runner
has passed its self-causal.

──────────────────────────────────────────────────────────────────────────────
2. MANDATORY PROCESS-RECORDING HARDENING
──────────────────────────────────────────────────────────────────────────────

The preceding audit is permanently nonqualifying because an attempted launch
of absent `/opt/homebrew/bin/rg` raised `FileNotFoundError` before
`provenance/process-0008.json` was created.

Do not use `rg`, `fd`, or any optional search binary. Use Python standard
library traversal and matching for content discovery.

After bootstrap, every parent-owned external child-process attempt must use one
audit-owned process runner. No direct `subprocess.run`, `subprocess.Popen`,
shell helper, or equivalent launch outside this runner is permitted.

For each process ordinal N, the runner must perform these operations in order:

1. Allocate the next contiguous ordinal.
2. Exclusively create and fsync:
   `provenance/process-NNNN.start.json`
3. Record before spawn:
   - full argv array;
   - cwd;
   - complete explicit environment supplied to the child;
   - effective umask;
   - intended stdout/stderr capture paths;
   - process purpose and phase;
   - start timestamp;
   - runner source identity.
4. Exclusively create stdout and stderr capture files.
5. Attempt child creation.
6. Catch all process-creation failures, including:
   - `FileNotFoundError`;
   - `PermissionError`;
   - other `OSError`;
   - invalid cwd;
   - malformed argv.
7. Whether creation succeeds or fails, exclusively retain:
   - complete stdout;
   - complete stderr or canonical runner exception bytes;
   - `provenance/process-NNNN.outcome.json`
8. The outcome record must include:
   - process-created Boolean;
   - PID when created;
   - exit or signal when applicable;
   - exception type, errno, and message when spawn failed;
   - stdout/stderr size and SHA-256;
   - end timestamp;
   - whether the child was reaped;
   - whether descriptors were closed.
9. Fsync all four retained records before advancing the ordinal.
10. Never overwrite, renumber, omit, or reconstruct a process record.

Before target-content inspection, run one audit-owned process-recorder causal:

- attempt to execute a deliberately nonexistent executable beneath the audit
  root;
- require a start record, empty or canonical stdout/stderr captures, and an
  outcome recording `FileNotFoundError`;
- require the next ordinal to be contiguous;
- classify the causal as a successful recorder test, not an audit failure.

If this causal does not produce complete records, return
AUDIT_PROVENANCE_MISMATCH immediately.

At closeout, independently require:

- contiguous ordinals from 0001 through the final ordinal;
- exactly one start, stdout, stderr, and outcome record per ordinal;
- every captured stream matching its retained size and SHA-256;
- no launch known from audit records or parent state without a complete quartet.

──────────────────────────────────────────────────────────────────────────────
3. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed/tracked/untracked:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory:
  54314 bytes
  SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Expected identities:

- root device/inode/mode:
  16777234 / 178255587 / 0700
- complete-tree inventory:
  164555 bytes
  SHA-256:
  797aad807f76e93a92642b7b3ef798ebab856ecea242325daa623ec08866c201
- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory:
  54314 bytes
  SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- governed files:
  389
- H→B:
  22 modified, 14 added, 0 deleted, 0 renamed
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- synthetic parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- synthetic subject:
  implement Remote Alpha external TLS T2A-P source
- closeout/final-evidence-inventory.json:
  130182 bytes
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb
- closeout/final-report.md:
  151150 bytes
  SHA-256:
  2a853c551635c223eec38feb229535285541a653dfa5f1ce59855fd5b2082b2fe
- both strategic manifests:
  139328 bytes each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  byte-identical

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Expected identities:

- root device/inode/mode:
  16777234 / 178515489 / 0700
- complete-tree inventory:
  20758 bytes
  SHA-256:
  7e202a82f642124f952c288ae5ba6f4056150e8163df60101f6d7d630257d3b0
- final inventory SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- both manifest SHA-256 values:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498
- disposition:
  historical, immutable, non-effective sibling-root design

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

Expected identities:

- root device/inode/mode:
  16777234 / 178558083 / 0700
- complete-tree inventory:
  29434 bytes
  SHA-256:
  33a659bc82d8fe67778e9806674c8a5f5b0477ea7a36a67af9cb902c3c186b76
- contract:
  execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2
- Plan V3:
  28590 bytes
  SHA-256:
  fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee
- final inventory:
  22990 bytes
  SHA-256:
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658
- final report:
  1355 bytes
  SHA-256:
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd
- both manifests:
  24408 bytes
  SHA-256:
  2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628
  byte-identical

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected identities:

- root device/inode/mode:
  16777234 / 178646858 / 0700
- complete-tree inventory:
  64018 bytes
  SHA-256:
  e8824a5f0b36b5d4c3b93e71a92b443257e3c1c1f4e97bfba9d4509d8a63ba5e
- verdict:
  BLOCK
- final audit report:
  92491 bytes
  SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05
- final audit inventory:
  69706 bytes
  SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

VALIDATION_CUSTODY_V3_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

Expected root:

- device/inode/mode:
  16777234 / 178799785 / 0700

Expected fixed identities:

- contract/strategic-b-validation-custody-v3.json
  4878 bytes
  SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

- contract/validation-plan-v4.json
  26001 bytes
  SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

- contract/plan-v3-v4-semantic-equivalence-v1.json
  3937 bytes
  SHA-256:
  4855cbd41a4c16a4d0ff52aa2dec75bdd66b1f272d1e1323d7a3b8759efe2f5b

- validation/producer-documentary-validator-result-v1.json
  18211 bytes
  SHA-256:
  796c295ae899fe386e268939e6a8c1bdad53559ac8d5cb9ffd066ec9454a0f04

- validation/independent-documentary-validator-result-v1.json
  19104 bytes
  SHA-256:
  5411a9a2c3b36d4d8af0c724319d6c1e0451576d9c0f8bb90adb403b48d9f19d

- validation/mutation-matrix-v1.json
  22410 bytes
  SHA-256:
  77c844a8261f55110c8900b42cef0d3d47ec39205209f089467c8c0c4cb9fe60

- closeout/final-implementation-report-v1.md
  21171 bytes
  SHA-256:
  4cec72ec50ddf41658b9fbf6a48c843ce5a2377bfaf17424bdefada7f1f0d3e6

- closeout/final-evidence-inventory-v1.json
  18305 bytes
  SHA-256:
  f7f602952c1a44d442982e883fe6be44c48dca0a908701126463e943964b25c9

- both manifests:
  19881 bytes
  SHA-256:
  94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359
  byte-identical

Expected V3 closure:

- 12 directories including root;
- 88 physical files including manifests;
- 86 nonmanifest files;
- 98 represented manifest entries;
- exactly two self-excluded manifests;
- no empty directory;
- all directories mode 0700;
- all files regular, single-link, mode 0600.

PINNED GO SOURCE

Go executable:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected SHA-256:

3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Expected source closure:

- B `internal/testsupport/controlroot.go`
  8695 bytes
  SHA-256:
  3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3

- B `internal/testsupport/controlroot_test.go`
  1359 bytes
  SHA-256:
  de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f

- B `es/runtimehelper/helper_test.go`
  5017 bytes
  SHA-256:
  715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0

- pinned Go `src/os/tempfile.go`
  4002 bytes
  SHA-256:
  a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16

- pinned Go `src/internal/strconv/itoa.go`
  6171 bytes
  SHA-256:
  cfda0d39152dc8ad8e2eb0407682c399ea0a321796211e015096fa57b17a35d5

Do not use the failed audit root as an input to qualification:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-independent-audit-38nbh2u1

Leave it immutable as historical process-failure evidence.

──────────────────────────────────────────────────────────────────────────────
4. REQUIRED CANDIDATE GIT ENVIRONMENT
──────────────────────────────────────────────────────────────────────────────

Every candidate Git read must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to CANDIDATE_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

No Git command may target a supplied evidence root or the primary checkout.

──────────────────────────────────────────────────────────────────────────────
5. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate a fresh retained root under `/Users/ds/Downloads`
using `tempfile.mkdtemp` with prefix:

ES-repair10i-t2ap-validation-custody-v3-independent-audit-

Create:

opening/
auditors/
contract/
validation/
provenance/
closeout/
manifest/
private/

Retained directories:

- physical;
- mode 0700.

Retained files:

- regular;
- single-link;
- mode 0600.

Remove `private/` before closeout and make two fresh ENOENT observations.

Do not retain an unexplained empty directory.

──────────────────────────────────────────────────────────────────────────────
6. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

After the process-recorder causal passes and before correctness inspection:

1. Read candidate `AGENTS.md` and applicable nested guidance.
2. Verify the complete candidate identity and current F inventory.
3. Verify complete closure of all four predecessor/supplied roots.
4. Verify complete V3 closure and every fixed identity.
5. Verify the pinned Go executable and all five source files.
6. Retain complete opening inventories for every supplied root.
7. Verify candidate operation markers and locks are absent.
8. Verify audit bootstrap and complete process records.
9. Independently verify V3 manifest represented-entry semantics and
   self-exclusions.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

Do not inspect V3 contract semantics before this gate has passed.

──────────────────────────────────────────────────────────────────────────────
7. FOUR DIRECT READ-ONLY AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes, start exactly three direct auditors
concurrently. After the first closes, start a fourth distinct auditor.

Auditor 1 — contract and authority

Inspect:

- V3 contract;
- supersession record;
- V3/V4 plan records;
- complete reports;
- failed-attempt classification.

Adjudicate:

- one sole normative writer;
- complete allocator contract;
- complete nonauthority;
- no B-source authority;
- no verdict promotion;
- failed-attempt copies create no competing authority.

Auditor 2 — plan equivalence and source closure

Inspect:

- complete Plan V3 and Plan V4;
- exact B and Go source files;
- producer equivalence record only as supplemental evidence.

Independently derive:

- field-level normalized plan equivalence;
- exact eight-command preservation;
- source dependency closure;
- decimal maximum 10;
- generated-component maximum 12;
- worst-case path 86;
- limit 100.

Auditor 3 — V2 evidence adoption and lineage

Inspect:

- V2 audit report and inventory;
- every adopted V2 record;
- adoption record;
- supersession lineage;
- failed/superseded attempts.

Adjudicate:

- every adopted observation is supported;
- the V2 verdict remains BLOCK;
- no runtime evidence is invented or copied into a competing lineage;
- V3 claims only bounded composition.

Auditor 4 — provenance, artifacts, and security

Inspect every V3 capsule object, including:

- manifests and final inventory;
- failed-attempt directories;
- validator sources and fixtures;
- report and closeout records.

Adjudicate:

- complete membership;
- modes, links, types, and self-exclusions;
- no unexplained empty object;
- no competing normative file;
- bounded sensitive-material posture;
- no supplied-root mutation.

Auditors must:

- use exact absolute operands;
- run no Git;
- run no tests or product code;
- write no files;
- make no network contact;
- create no nested agent.

Retain their prompts, exact operands, start/finish order, reports,
uncertainties, uninspected scope, and minority findings.

If four distinct auditors cannot complete, return BLOCK.

──────────────────────────────────────────────────────────────────────────────
8. INDEPENDENT CONTRACT RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Do not import producer validator code.

Independently parse the V3 contract with:

- duplicate-key rejection;
- nonfinite rejection;
- canonical-encoding enforcement;
- exact key-set validation;
- exact nested key-set validation;
- exact types and values;
- exact enumeration and list order where semantic.

Require all allocator semantics literally, including:

- OS CSPRNG;
- fresh material per attempt;
- no-follow component traversal;
- held parent descriptor and identity;
- descriptor-relative exclusive creation;
- EEXIST-only retry;
- fresh collision material;
- attempt limit 128;
- terminal non-EEXIST behavior;
- direct-child identity requirements;
- forbidden authority sources and actions.

Require all six explicit nonauthority fields to be false.

Require all eight authority booleans to be false.

Require:

- V3 is sole validation-custody writer;
- the strategic B snapshot remains sole B source/provenance package;
- V3 status is proposed-effective pending independent audit.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT PLAN V3→V4 EQUIVALENCE
──────────────────────────────────────────────────────────────────────────────

Do not use the producer checker as the oracle.

Parse complete Plan V3 and Plan V4.

The audit normalization may remove only:

- schema/version captions;
- V2→V3 contract-reference update;
- exact source-closure references;
- explicit nonauthority references;
- lineage/status metadata;
- V3-generated record identities.

It must not remove:

- command definitions;
- command order;
- argv;
- cwd semantics;
- environment parameter names or values;
- pinned tools;
- expected exits;
- exact pass/fail/skip identity policies;
- governing reasons;
- B source/tree/inventory/synthetic-commit identities;
- shared `r` custody;
- authority boundaries.

Require:

- exactly eight commands;
- identical order;
- canonical normalized equality;
- a complete field-level difference record.

Return BLOCK on any executable or acceptance-bearing difference. Do not respond
by running runtime validation.

──────────────────────────────────────────────────────────────────────────────
10. INDEPENDENT SOURCE-CLOSURE AND PATH DERIVATION
──────────────────────────────────────────────────────────────────────────────

Read the five exact source files independently.

Trace the actual chain through:

- control-root containment and path checks;
- runtime-helper socket construction;
- temporary-name generation;
- decimal conversion.

Derive independently:

- short root: 57 bytes;
- shared root: 59 bytes;
- generated prefix: 2 bytes;
- unsigned 32-bit decimal maximum: 10 bytes;
- generated component maximum: 12 bytes;
- separators: 2 bytes;
- `identity.sock`: 13 bytes;
- worst case: 86 bytes;
- limit: 100;
- 86 <= 100.

Establish whether `itoa.go` is an actual dependency of the formatting chain.

If another acceptance-bearing exact source file is required but absent from
V3’s source-closure set, return BLOCK.

──────────────────────────────────────────────────────────────────────────────
11. V2 TECHNICAL-EVIDENCE ADOPTION
──────────────────────────────────────────────────────────────────────────────

For each adopted observation:

1. Open the exact V2 audit record.
2. Verify path, size, SHA-256, schema, and relevant fields.
3. Verify the claimed observation is supported.
4. Verify V3 does not strengthen or broaden it.
5. Verify no dynamic output was copied into V3 as competing evidence.
6. Verify the V2 verdict remains BLOCK everywhere.
7. Verify V3 claims no new runtime execution.

Required observations:

- allocator causals;
- independent path derivation;
- four causals;
- exact B materialization;
- eight-command validation;
- cross-command isolation;
- cleanup;
- closing equality;
- V2 capsule closure.

Inspect raw acceptance-bearing records whenever a summary is insufficient.

Return BLOCK if any adopted claim cannot be independently substantiated.

──────────────────────────────────────────────────────────────────────────────
12. FAILED ATTEMPT AND SOLE WRITER
──────────────────────────────────────────────────────────────────────────────

Inspect:

validation/failed-attempts/build-attempt-1/

Require:

- it is explicitly indexed and superseded;
- it is outside the normative namespace;
- no current record references it as authority;
- it claims no authority;
- its contract/plan copies are clearly incomplete historical attempt bytes;
- the final contract remains the sole normative writer.

Return BLOCK for unresolved competing authority.

──────────────────────────────────────────────────────────────────────────────
13. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import either producer validator.
Do not use producer mutation fixtures to generate cases.

Create independent in-memory baselines and at least these 50 mutations:

Allocator:
1–15 exactly covering CSPRNG, exclusive creation, no-follow traversal,
EEXIST-only retry, collision material, attempt limit, fallback, scanning,
adoption, rename, PID, counter, timestamp, and Git-hash authority.

Nonauthority:
16–21 setting each unsupported-host or alias field to true.

Source closure/path budget:
22. omit `itoa.go`
23. change `itoa.go` hash
24. change `tempfile.go` hash
25. change decimal maximum
26. change generated-component maximum
27. change worst-case path
28. change socket limit

Plan:
29. remove command
30. reorder command
31. change argv
32. remove expected identity
33. reclassify expected failure
34. reclassify expected skip
35. change B source/tree identity
36. change shared-`r` custody

Lineage/authority:
37. promote V2 BLOCK to ACCEPT
38. describe Plan V3 as previously effective
39. describe Plan V4 as current without audit
40. grant V3 source authority
41. grant publication/commit/readiness/A6 authority

Strict parsing/provenance:
42. duplicate JSON key
43. unknown contract key
44. missing mandatory key
45. wrong field type
46. introduce second normative V3 contract outside `contract/`
47. reference failed-attempt contract as authority
48. change adopted V2 path or digest
49. strengthen a V2 observation
50. permit normalization to remove an acceptance-bearing Plan field

Require every mutation to reject with a specific, mechanism-appropriate
classification.

Retain audit-owned validator source and result matrix.

──────────────────────────────────────────────────────────────────────────────
14. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- the eight-command validation plan;
- Go repository tests;
- product code;
- the V2 allocator;
- V2 causal harnesses;
- live services.

Allowed executable work is limited to audit-owned parsers, hashers, inventory
builders, semantic-comparison utilities, and mutation validators.

If Plan V4 differs semantically, return BLOCK; do not replay runtime commands.

──────────────────────────────────────────────────────────────────────────────
15. CAPSULE CLOSURE AND SECURITY
──────────────────────────────────────────────────────────────────────────────

Independently enumerate V3_ROOT and require:

- 12 directories including root;
- 88 physical files including manifests;
- 86 nonmanifest files;
- 98 represented entries;
- exactly two self-excluded manifests;
- no missing, extra, or duplicate entry;
- no empty or unexplained directory;
- directories mode 0700;
- files regular, single-link, mode 0600;
- no symlink or special object.

Generate two independent manifest projections. Require both to equal the
supplied bytes and hash:

94ae9bf8eea0c96b37dfc0aac9134e0acd727510a936621606d7923febced359

Verify the fixed report and inventory identities.

Perform bounded sensitive-material scanning without printing matching payload
content. Distinguish fake fixtures, redaction patterns, and hashes from
plausible live secrets.

──────────────────────────────────────────────────────────────────────────────
16. AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Require this split:

Strategic B owns:

- B source bytes;
- logical modes;
- byte origins;
- inventory;
- source T / Git tree;
- synthetic evidence commit;
- H→B classification.

V2 evidence owns only its retained dynamic observations.

V3 owns only:

- complete validation-custody contract;
- record-complete Plan V4;
- exact source closure;
- explicit nonauthority;
- semantic equivalence with V2 behavior;
- bounded technical-evidence references.

Neither V2 nor V3 owns publication, commit, current repository truth for B,
product/runtime/deployment readiness, A6 readiness, semantic-successor
implementation, orchestrator implementation, hostile/shared-host support, or
symlink/mount-alias support.

Return BLOCK on authority drift.

──────────────────────────────────────────────────────────────────────────────
17. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After all work:

1. Remove only audit-owned private fixtures and temporary state.
2. Reap every audit-owned child process.
3. Verify no process or descriptor survivor.
4. Make two fresh observations that `private/` is absent.
5. Recompute candidate opening/closing equality.
6. Recompute STRATEGIC_B_ROOT equality.
7. Recompute BLOCKED_V1_REPAIR_ROOT equality.
8. Recompute VALIDATION_CUSTODY_V2_ROOT equality.
9. Recompute V2_INDEPENDENT_AUDIT_ROOT equality.
10. Recompute VALIDATION_CUSTODY_V3_ROOT equality.
11. Reverify the five exact source files.
12. Independently validate complete process-record continuity.
13. Retain complete audit process and artifact inventories.
14. Require retained directories mode 0700 and files regular, single-link,
    mode 0600.
15. Require no unexplained empty directory.

Return AUDIT_PROVENANCE_MISMATCH on any supplied-root drift, missing process
record, process-record gap, or unprovable opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
18. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- opening and closing provenance qualify;
- process records are complete and contiguous;
- four auditors complete;
- V3 contract is complete and unambiguous;
- Plan V4 is independently semantically identical to Plan V3;
- path-source closure is complete;
- explicit nonauthority is complete;
- V2 technical-evidence adoption is exact and bounded;
- the independent mutation matrix passes;
- failed attempts create no competing authority;
- capsule closure and security pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable target-level contract, plan, closure, lineage,
adoption, authority, contradiction-resistance, artifact, or security defect.

Return REJECT only for fundamental target unsoundness not repairable within the
record-completion scope.

Return AUDIT_PROVENANCE_MISMATCH for input drift, supplied-root mutation,
missing exact input, process-record incompleteness, or failed opening/closing
equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete audit report inline, including:

1. Primary verdict
2. Audit-root and bootstrap identity
3. Process-recorder design and missing-executable causal
4. Candidate and supplied-root opening identities
5. Four auditor identities, schedule, operands, and reports
6. V3 capsule closure
7. Independently parsed V3 field map
8. Plan V3→V4 field-level equivalence
9. Exact path-source dependency derivation
10. Explicit nonauthority adjudication
11. V2 evidence-adoption adjudication
12. Failed-attempt and sole-writer adjudication
13. Independent 50-case-or-greater mutation matrix
14. Confirmation no runtime replay occurred
15. Capsule authority and nonauthority
16. Artifact and sensitive-material findings
17. Severity-ranked residual findings
18. Minority findings and parent resolution
19. Cleanup and two absence observations
20. Candidate and supplied-root closing equality
21. Complete process-record audit
22. Audit-created paths and complete inventory
23. Remaining uncertainty and explicit nonclaims
24. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V3_CAPSULE_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
VALIDATION_COMMAND_SEMANTICS_NOT_CHANGED
PATH_SOURCE_CLOSURE_INCLUDES_PINNED_ITOA_GO
HOSTILE_SHARED_HOST_SUPPORT_EXPLICITLY_FALSE
SYMLINK_MOUNT_ALIAS_SUPPORT_EXPLICITLY_FALSE
V2_BLOCK_VERDICT_NOT_PROMOTED
RUNTIME_VALIDATION_NOT_RERUN
PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
MISSING_EXECUTABLE_CAUSAL_RECORDED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, proceed to the real H→B commit gate. That gate should stage
the exact accepted 36-path H→B scope, validate the exact staged tree under the
accepted custody contract, create exactly one commit with subject:

`implement Remote Alpha external TLS T2A-P source`

and perform no push or upstream change.

Only after B is committed should the already-audited B→F governance commit be
gated.
```

No producer-side repair is needed before this retry.

### Source

:chatgpt-content-reference{index="0"}

**Confidence:** 0.999 that this was solely an audit-runner provenance failure; 0.995 that V3 itself should remain unchanged; 0.98 that pre-spawn process-record creation plus the deliberate missing-executable causal will prevent recurrence.
