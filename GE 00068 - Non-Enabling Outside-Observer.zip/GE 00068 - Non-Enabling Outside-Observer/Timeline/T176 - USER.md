Here is Codex's response:



# BLOCK

## 1. Verdict and response format

This is the complete audit report inline. The alternate-authority-ID repair passes the provenance, marker, test, compatibility, and artifact checks described below. Acceptance is blocked by **CALLER-SNAPSHOT-01**: the unchanged source-external caller uses a pathname-based snapshot as a required condition of its `accepted` outcome. That fails the request’s explicit caller adjudication rule. The finding is a repairable assurance defect, so the verdict is BLOCK.

## 2. Exact target

The audited worktree was `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1` (`R` below).

| IdentityObserved value           |                                                                                                   |
| -------------------------------- | ------------------------------------------------------------------------------------------------- |
| Branch                           | `codex/evidence-verification-v1`                                                                  |
| HEAD                             | `567bceced5df95ecfe787cc66038d463a854e12c`                                                        |
| HEAD tree                        | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                                        |
| Sole parent                      | `05dde14d185b6e022dcc169ef1a658a97961850f`                                                        |
| Upstream                         | Absent                                                                                            |
| Patch scope                      | Four modified tracked paths; nine untracked paths; no staged, deleted, renamed, or unmerged paths |
| Final canonical manifest SHA-256 | `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`                                |
| Tracked binary diff SHA-256      | `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`                                |

The verifier is an ES-owned **Bounded slice rule**. Its output has structural evidence authority only; it grants no product, runtime, admission, orchestration, readiness, commit, publication, or durable-state authority. The trusted-host contract is private documentary assurance. Historical A6D verifiers remain **Temporary compatibility edges**. This repair exercises no **Reopened redesign seam**. See [the governing contract (line 3)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:3>) and [PLANS.md (line 2970)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/PLANS.md:2970>).

## 3. Controlled audit-evidence writer and modes

The fresh audit root was absent before creation:

`/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5` (`A` below).

The parent set umask `077` before creation. Its evidence writer created directories directly at `0700` and retained files with `os.open(O_CREAT | O_EXCL | O_WRONLY | O_NOFOLLOW, 0600)`, immediate `fchmod(0600)`, `fsync`, close, and immediate no-follow `lstat` verification. It never reused, truncated, replaced, or rewrote a retained path. Child stdout and stderr were captured in memory and stored by that writer.

The pinned provenance recipe creates its own output with `open("xb")`. Those recipe outputs were temporary, checked against stdout, copied into **new retained files through the controlled writer**, and deleted with their temporary continuations. At the final gate, all **five retained audit directories** were direct `0700` directories and all **169 retained files** were regular, single-link `0600` files. The private audit `TMPDIR` was empty. The preceding v4 audit had 32 files outside this mode policy and was treated only as supplemental evidence. [Final gate](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/final-gate.json).

## 4. Opening and closing provenance

The physical worktree root equaled its lexical path. The recipe source matched SHA-256 `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333` and recipe ID `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`.

Opening recipe invocations **6 and 7** and closing invocations **25 and 26** each exited zero with empty stderr. In every run, stdout equaled the recipe’s temporary output. All four outputs were byte-identical to the expected manifest, with SHA-256 `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`; each contained the same exact 13 rows and tracked diff SHA-256 `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`.

The plain exploratory Git diff in invocation 5 used fewer normalization flags and had SHA-256 `8253cfb5…`; invocation 30 used the recipe’s full flags and matched the required tracked-diff hash. This is a command-shape difference, not repository drift. Opening and closing branch, HEAD, tree, parent, upstream absence, status, and worktree contents matched. No Git operation marker or lock was present at close. [Opening record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/opening-provenance.json) · [Closing record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/closing-provenance.json).

## 5. Repository scope and 477-object baseline

The restored inventory supplied 477 governed paths. Opening, post-opening-recipe, each targeted test, each full-suite run, pre-closing, post-closing-recipe, and final checks found exact path, type, mode, size, link-count, and SHA-256 equality across all 477 objects. There was no additional ignored artifact, `__pycache__`, `.pyc`, `.pyo`, or `.pytest_cache`.

An initial *list-order* comparison raised a false alarm despite 477 matching paths. The parent recorded the comparison error, compared rows by path, found zero differing objects, and used that path-keyed equality for subsequent checkpoints. It did not clean or alter the worktree. [Inventory correction](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/inventory-compare-correction.json) · [full opening inventory](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/inventory-opening.json).

## 6. Complete parent-issued Git-process record

For every row below, the full argv begins `git -C "/Users/ds/Repositories/Execution Substrate - evidence-verification-v1"` and cwd is exactly that worktree. The required environment was identical in every start record:

`PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin`; `GIT_OPTIONAL_LOCKS=0`; `GIT_CONFIG_NOSYSTEM=1`; `LC_ALL=C`; `LANG=C`; `PYTHONDONTWRITEBYTECODE=1`. The private audit `TMPDIR` was also supplied.

Each numbered `.start.json` was created exclusively **before** execution. Separate immutable `.stdout`, `.stderr`, and `.outcome.json` files contain the complete byte streams, exit, sizes, and hashes. Here `E` means the full empty-stream SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| #Remaining argvExitStdout bytes / SHA-256Stderr bytes / SHA-256 |                                                                             |     |                                                                             |                                                                         |
| --------------------------------------------------------------- | --------------------------------------------------------------------------- | --- | --------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| 1                                                               | `branch --show-current`                                                     | 0   | 31 / `ea96655087a20eebab1426d7c0d142a4b9ffd1e84bb91454161887efb15cb3af`     | 0 / E                                                                   |
| 2                                                               | `rev-parse HEAD HEAD^{tree} HEAD^`                                          | 0   | 123 / `ff422dcbfcdb5919143625ae1319e8b26409c5ee40b9eb35576b1b31670f945e`    | 0 / E                                                                   |
| 3                                                               | `rev-parse --abbrev-ref --symbolic-full-name @{upstream}`                   | 128 | 0 / E                                                                       | 74 / `159386b3dbc19a37b4f8f5f1f02e1fe4ba6aef96364cc2ece40983d4075981d2` |
| 4                                                               | `status --porcelain=v1 --untracked-files=all`                               | 0   | 626 / `83b5ab14c78828fcf7f67728b55c94743b62fc45d985eedefa30252a140609f1`    | 0 / E                                                                   |
| 5                                                               | `diff --binary HEAD`                                                        | 0   | 18,084 / `8253cfb5c468fe05671825fc064ec57a3d41921398c702b0eb112982ebe42a3b` | 0 / E                                                                   |
| 27                                                              | `rev-parse HEAD HEAD^{tree} HEAD^`                                          | 0   | 123 / `ff422dcbfcdb5919143625ae1319e8b26409c5ee40b9eb35576b1b31670f945e`    | 0 / E                                                                   |
| 28                                                              | `branch --show-current`                                                     | 0   | 31 / `ea96655087a20eebab1426d7c0d142a4b9ffd1e84bb91454161887efb15cb3af`     | 0 / E                                                                   |
| 29                                                              | `status --porcelain=v1 --untracked-files=all`                               | 0   | 626 / `83b5ab14c78828fcf7f67728b55c94743b62fc45d985eedefa30252a140609f1`    | 0 / E                                                                   |
| 30                                                              | `diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --` | 0   | 18,348 / `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb` | 0 / E                                                                   |
| 31                                                              | `rev-parse --abbrev-ref --symbolic-full-name @{upstream}`                   | 128 | 0 / E                                                                       | 74 / `159386b3dbc19a37b4f8f5f1f02e1fe4ba6aef96364cc2ece40983d4075981d2` |

All **31** numbered parent process invocations had one start, one outcome, one stdout, and one stderr record; their recorded sizes and hashes matched the stored streams. The recipe’s internal Git calls were bound through each complete recipe invocation, as specified. [Process-record audit](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/process-record-audit.json) · [final record audit](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/final-gate.json).

## 7. Four distinct auditors

Auditors 1–3 started concurrently on their first attempt. Auditor 4 started after auditor 1 completed. No retry was needed. Each returned a read-only report to the parent; the parent stored all four through the controlled writer. None ran Git, wrote files, imported repository modules, used the network, or created a nested subagent.

| AuditorRole and statusActual cwd and content operands |                                        |                                                                                                                                                                                                                                                                                                                                                                                                     |
| ----------------------------------------------------- | -------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `contract_authority`                                  | Completed; MK-01 adjudication          | Cwd `R`. Read `R/AGENTS.md`, `R/PLANS.md`, `R/.docs/system_overview/{evidence_verification,boundaries,artifact_hygiene,capability_probing}.md`, `R/tools/evidence_verify/test_verify_v1.py`; read-only source searches.                                                                                                                                                                             |
| `marker_validator`                                    | Completed; grammar and invariants      | Cwd `R`. Read `R/AGENTS.md`, `R/PLANS.md`, the contract, artifact-hygiene and capability pages, `R/tools/evidence_verify/test_verify_v1.py`, `R/es/internal/ownershipnorm/{marker.go,marker_test.go}`; read-only searches under `R/.docs`, `R/es`, and `R/tools/evidence_verify`.                                                                                                                   |
| `test_validation`                                     | Completed; tests and producer evidence | Cwd `R`. Read the governing docs, test and verifier under `R`, and the specifically named decision, validation, vulnerable-input, provenance, opening, and closeout records under the supplied implementation-evidence root. Its [stored report](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/auditor-3-test-validation.md) enumerates those operands. |
| `security_artifacts`                                  | Completed; caller and artifacts        | Initially cwd `/Users/ds/Repositories/Execution Substrate`, then `R` for source reads. Read the supplied caller, `R`’s governing docs/test/verifier, the prior security perspective, and all implementation-evidence files indexed by `closeout/evidence-inventory.json`.                                                                                                                           |

The [four stored reports](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/auditor-1-contract-authority.md) record their detailed operands and findings. Their scheduling closes AP-06’s four-distinct-auditor condition.

## 8. Marker grammar and validator invariants

The live family is `execution-substrate.evidence-verification.trusted-host-contract.`; the sole admitted authority ID is that family plus `v1`. The test validator scans generic suffixes with `r"[^\s<>]+"`, not a finite list of IDs. It accepts exactly one matched v1 BEGIN/END block in the admitted authority document and rejects a family authority block in a consumer. Exact unmatched, mismatched, nested, overlapping, duplicate, and alternate-family markers receive specific reasons. Strict v1 JSON checks cover duplicate keys, nonfinite constants, field set, types, values, and canonical encoding; the three consumer references must carry the exact contract ID, writer, and non-override declaration. [Validator source (line 1386)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/test_verify_v1.py:1386>).

The exact-marker grammar does not treat arbitrary prose mentioning the family as a marker. It also does not semantically inspect every sentence outside the bounded reference blocks. Those limits are recorded as observations below.

## 9. Independent marker and contradiction causals

An audit-owned parser, built without importing the repository helper, accepted the live four documents and reproduced **all 38** supplied contradiction reasons: the original 31 and seven producer-added cases. The parent separately imported only an exact-SHA-verified, audit-owned copy of the test source to generate and compare those inputs. [Independent 38-case record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/independent-38-contradictions.json) · [parser source](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/independent_parser.py).

The original 31 covered contract value/type, missing/unknown/duplicate JSON fields, duplicate v1 authority, consumer-local v1 authority, missing/duplicate/incorrect references, malformed v1 marker or fence, noncanonical JSON, and contradictory text within the bounded sections. All 31 produced their specified reasons.

The seven added cases produced, respectively:

| CaseSpecific reason              |                                          |
| -------------------------------- | ---------------------------------------- |
| Alternate authority v2           | `unauthorized_authoritative_contract_id` |
| Alternate v2 block in `PLANS.md` | `unauthorized_authoritative_block`       |
| v2 BEGIN / v3 END                | `authoritative_marker_mismatch`          |
| Unmatched alternate BEGIN        | `authoritative_marker_unbalanced`        |
| Unmatched alternate END          | `authoritative_marker_unbalanced`        |
| Nested alternate block           | `authoritative_marker_overlap`           |
| Alternate authority v27          | `unauthorized_authoritative_contract_id` |

The parent added **25 audit-only cases** covering v2, v27, `future-review-17`, a generated non-enumerated ID, an alternate block in each consumer, mismatched IDs, unmatched markers, nested and overlapping blocks, duplicate v1, unmarked family prose, an unrelated HTML marker, and a lookalike non-family prefix. Every result agreed between the independent parser and the copied test validator, including the intended acceptance of the three non-markers. [Audit-only results](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/audit-only-marker-causals.json).

The two vulnerable copied document sets matched their recorded byte hashes. With the predecessor’s missing family scan reconstructed in audit-owned code, both were accepted; the repaired validator rejected the **same copied inputs** with their specific authority-document and consumer-document reasons. This demonstrates the causal, while the exact predecessor test source bytes were unavailable for direct execution. [Causal comparison](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/predecessor-and-repair-causals.json).

## 10. Targeted test 89 and complete suites

Test 89 ran alone three times with the pinned Python 3.13.4 interpreter and `-I -S -B`. Invocations **8, 9, and 10** each exited zero, reported exactly one unittest, had zero failure/error/skip, traversed the current 38-case subtest generator, and left the 477-object inventory exact. The test’s method count of one must not be confused with its 38 contradiction cases. [Targeted results](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/targeted-test-results.json).

AST discovery found exactly **89** unittest methods. The following is the exact identity set, using `ClosureCausals.test_` as the prefix for entries 01–88:
```
01_valid_preseal, 02_valid_sealed, 03_missing_manifest,
04_missing_sidecar, 05_wrong_sidecar, 06_missing_payload,
07_unexpected_payload, 08_wrong_mode, 09_wrong_size,
10_wrong_hash, 11_wrong_link_count, 12_directory_mode,
13_symlink_every_depth, 14_special_every_depth,
15_post_manifest_same_bytes, 16_unknown_layout,
17_wrong_registered_hash, 18_missing_required_layout_entry,
19_unexpected_layout_entry, 20_stage_confusion,
21_arbitrary_layout_option, 22_readiness_not_interpreted,
23_zero_writes, 24_repeated_canonical_output,
25_source_inside_target, 26_own_container,
27_independent_materialization, 28_historical_defect,
29_fourth_layout_without_verifier_edit,
30_exact_closeout_identities, 31_historical_amendment_exact_modes,
32_closing_helper_0600_rejects, 33_postseal_helper_0600_rejects,
34_helper_other_modes_reject,
35_unrelated_fixed_json_executable_rejects,
36_unrelated_fixed_markdown_executable_rejects,
37_unenumerated_executable_rejects,
38_optional_executable_has_no_required_authority,
39_other_layout_spec_bytes_unchanged,
40_amendment_registry_hash_mismatch_rejects,
41_physical_target_ancestry_and_aliases,
42_physical_candidate_ancestry_and_aliases,
43_literal_lf_preseal_rejections, 44_literal_lf_sealed_rejections,
45_json_depth_escapes_and_cli_failure,
46_manifest_declared_budgets, 47_scan_budgets_before_read,
48_isolated_missing_root, 49_expected_path_symlink_and_special,
50_bounded_decimal_parser,
51_capability_operation_failures_are_canonical,
52_json_source_size_and_spec_failure,
53_manifest_stat_caps_precede_body_read,
54_manifest_stream_early_row_path_and_count_rejection,
55_exact_maximum_count_and_path,
56_seal_and_candidate_structural_budgets,
57_sidecar_pre_read_size_and_exact_malformed_content,
58_decimal_complete_lexical_classification,
59_invalid_spec_paths_never_open_target,
60_source_by_value_external_source_both_stages,
61_direct_source_inside_target_both_stages,
62_final_source_symlink_to_target_both_stages,
63_parent_symlink_to_target_source_both_stages,
64_hardlinked_source_to_target_both_stages,
65_source_package_beneath_target,
66_target_beneath_source_package,
67_source_package_equals_target,
68_case_alias_of_prohibited_source_relationship,
69_source_identity_changes_before_close,
70_source_disappears_before_close,
71_unsupported_source_nofollow_or_parent_traversal,
72_same_source_bytes_distinct_inode_admitted,
73_external_source_with_symlinked_parent_rejects,
74_relative_direct_script_invocation_rejects,
75_final_symlink_to_external_source_rejects,
76_direct_and_symlinked_script_launches_are_invocation_errors,
77_stdin_and_dev_fd_launches_are_invocation_errors,
78_missing_reordered_or_extra_application_arguments,
79_extra_combined_or_reordered_interpreter_options,
80_source_package_one_byte_mismatch_rejects,
81_invalid_package_source_and_size_reject,
82_captured_argv_survives_live_argv_mutation,
83_package_source_replaced_after_argv_construction,
84_unicode_source_round_trip_and_no_output_leak,
85_no_package_source_authority_from_file_presence,
86_closing_source_validation_failure_is_race,
87_file_present_launch_state_rejects,
88_missing_isolation_site_or_bytecode_flag_rejects
InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim
```

Full-suite invocations **11–14** used the pinned interpreter with `-I -S -B`. Two ran under umask `077`, two under `022`. Each owning command exited zero, reported exactly 89 tests with zero failure/error/skip, matched the discovered identity set, and preserved the 477 objects. The first report parser initially missed the fully qualified test names; its corrected, separately retained report parsed invocation 11’s original stored stderr and all later runs without replacing any record. [Discovery](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/test-discovery.json) · [four corrected suite results](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/full-suite-results-corrected.json).

## 11. Unchanged inputs and implementation evidence

The producer’s opening and final 13-row manifests have the same path set. Their only changed row is `tools/evidence_verify/test_verify_v1.py`, from SHA-256 `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea` to the live `a106fe923440e4f2b24a7a425f994aa935eaaa9ffb7a68925987c8444df9b568`. The live test is 88,127 bytes; the unchanged verifier is 40,121 bytes with SHA-256 `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`. All governing docs, `boundaries.md`, registry, three layouts, and two historical fixtures had unchanged manifest rows. The source-external caller separately matched SHA-256 `002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104`. [Row comparison](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/unchanged-input-comparison.json).

The complete supplied implementation-evidence tree had 56 files and 16 directories, including its inventory file and root. All 55 files indexed by that inventory matched path, type, mode, link count, size, and SHA-256, with no extra file. The two final producer manifests were byte-identical. Its first failed full-suite attempt is explicitly separate and nonqualifying; four corrected runs are listed as replacements. The independent producer marker validator imports only `hashlib`, `json`, `pathlib`, and `re`, not the test helper. The producer’s vulnerable and repaired records use identical copied inputs and preserve specific rejection reasons. Its evidence makes no claim that the prior v4 audit qualifies the changed test bytes or that a new compatibility rerun occurred there. [Implementation inventory check](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/implementation-evidence-inventory-check.json).

## 12. Fresh compatibility, no-write, and SEC-02

An audit-owned reconstruction authenticated the source, registry, and selected layout through descriptor-relative, no-follow, bounded reads. Its watched target, package, and private TMPDIR snapshots also used descriptor-relative, no-follow, bounded traversal. Each verifier child used pinned Python `-I -S -B -c` with authenticated source bytes by value, a private TMPDIR, and the documented closed argv. Returned registry and layout hashes were checked independently. [Reconstruction source](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/compatibility_reconstruction.py).

| RunCountExit / stderrCanonical stdout SHA-256Watched inputs |   |                |                                                                    |                                                 |
| ----------------------------------------------------------- | - | -------------- | ------------------------------------------------------------------ | ----------------------------------------------- |
| A6D sealed                                                  | 2 | Both 0 / empty | `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606` | Target, package, TMPDIR, and manifest unchanged |
| A6D amendment sealed                                        | 2 | Both 0 / empty | `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc` | Target, package, TMPDIR, and manifest unchanged |
| Audit-owned synthetic A6 pre-seal                           | 2 | Both 0 / empty | `c8fea47874d6c022e631edf6fbfb15391f44e048c2a21070ea4e6b769a4b4ac7` | Unchanged during each run                       |
| Same A6 fixture after sealing                               | 2 | Both 0 / empty | `8535b9875405399f02f4e9729180af60168eab293aa36ba2482c27fb2e383111` | Unchanged during each run                       |
| SEC-02 target-marker causal                                 | 1 | 0 / empty      | `3c0f2118606bb91e6eddbdbca6b9932f7275dfa99f0bb3a5d788c7e1dee46df1` | Target script was not loaded; marker absent     |

A6D and amendment sealed manifests remained at SHA-256 `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9` and `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`. The synthetic fixture was created and sealed only under `A`; its expected transition between pre-seal and sealed stages was intentional. SEC-02’s direct-script predecessor argv shape was recorded as nonqualifying and was **not executed**. The records preserve supported-local scope, structural-evidence-only output, and the nonclaims about atomic interpreter custody and transient trusted-principal replacement.

## 13. MK-01 adjudication

**Nonblocking hardening observation under the current contract.** [The sole-writer declaration (line 110)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:110>) places the private normative trusted-host record in `evidence_verification.md`. Its three bounded references are in [PLANS.md (line 3069)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/PLANS.md:3069>), [artifact\_hygiene.md (line 212)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/artifact_hygiene.md:212>), and [capability\_probing.md (line 201)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/capability_probing.md:201>). The test expressly admits that four-document set at [lines 1390–1392 and 1485–1488 (line 1390)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/test_verify_v1.py:1390>); [PLANS.md lines 3036–3043 (line 3036)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/PLANS.md:3036>) describe this refinement as the plan plus three governing pages.

[Boundaries.md lines 895–911 (line 895)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/boundaries.md:895>) govern the tooling boundary, but are outside this four-document trusted-host contract family and presently contain no competing marker or custody claim. A marker placed there would conflict with the sole-writer rule; it would not acquire trusted-host contract authority. Current docs and tests establish uniqueness **within the closed four-document set**, without claiming repository-wide marker detection. MK-01 therefore does not block this exact scope. Broadening that guarantee would require an explicit documentary decision first.

## 14. CALLER-SNAPSHOT-01 adjudication and blocking finding

**Blocking assurance defect.** The unchanged source-external caller’s `snapshot()` uses `os.scandir(directory)`, `Path.lstat()`, then a separate `Path.read_bytes()` before recursing by pathname. Its size check precedes that separate read, leaving the read susceptible to a pathname swap. See [caller lines 214–237 (line 214)](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py:214).

The caller compares pathname snapshots of target, package, TMPDIR, and caller evidence around the child, appends `SNAPSHOT_CHANGED` on inequality, then sets `outcome="accepted"` only if the error list is empty ([lines 365–381 and 415 (line 365)](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py:365)). Snapshot equality is therefore an **acceptance-bearing gate** and its before/after no-write observation. The explicit `observations_are_corroboration_only` field applies to **interpreter** observations ([lines 282–285 (line 282)](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py:282)); no equivalent designation limits the pathname snapshots.

Separate descriptor-bound source checks in the caller and descriptor-bound closure in the verifier remain intact. A matching pathname snapshot alone cannot produce a verifier pass, authenticate source, or establish target closure. The audit-owned compatibility caller independently used descriptor-relative no-follow bounded reads. Those facts limit the defect’s scope, but do not change the unchanged caller’s snapshot-gated accepted outcome. Under the request’s §12 disposition, the finding blocks acceptance. The governing contract requires source-external authentication and restricts verifier output to structural evidence, while expressly disallowing atomic-custody claims ([contract lines 33–61, 102–151 (line 33)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:33>)).

## 15. Prior-finding reconciliation

The supplied v4 audit is permanently nonqualifying because of its retained file modes. Its substantive observations inform this table; current audit checks provide the stated fresh evidence. Where the supplied artifacts did not define a historical label’s exact allegation, no individual historical closure is invented.

| FindingCurrent disposition |                                                                                                                                                                                                                                                                      |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TV-01                      | Closed for the named four-document scope: generic scanning rejected v27 and a generated non-enumerated ID, as well as v2 and `future-review-17`.                                                                                                                     |
| CT-01                      | Current sole-writer contract, strict v1 JSON, and exact consumer references passed; the historical label’s separate allegation was not supplied for narrower attribution.                                                                                            |
| AP-06                      | Closed: four distinct auditors completed in the required schedule.                                                                                                                                                                                                   |
| SEC-01                     | Supported-local interpreter checks and documented nonclaims held; no atomic executed-object custody is asserted.                                                                                                                                                     |
| SEC-02                     | Fresh source-by-value target-marker causal passed; direct-script predecessor shape remains nonqualifying.                                                                                                                                                            |
| VC-01 / SEC-A1             | Source, registry, and layout identities, descriptor checks, and canonical verifier outputs passed; unchanged source retains bounded authority.                                                                                                                       |
| EV-01–EV-08                | Verifier and layouts are byte-unchanged from the compared target; all 89 current tests and compatibility runs passed. Individual historical descriptions were not present in the supplied v4 files, so this is regression evidence rather than a new per-code proof. |
| EV-09                      | Prior process evidence remains nonqualifying; this fresh audit used exclusive records and verified all retained modes.                                                                                                                                               |
| F-01–F-04                  | Current source, suite, compatibility, and inventory gates passed. Exact historical allegations were not supplied for per-code closure attribution.                                                                                                                   |
| PP-01, PE-02, TA-03        | Current process, external source, and artifact boundaries passed where exercised; exact historical allegations were not supplied for per-code closure attribution.                                                                                                   |
| AP-04, AP-05, CA-01        | Current provenance, audit records, test runs, and compatibility checks passed where exercised; exact historical allegations were not supplied for per-code closure attribution.                                                                                      |
| MK-01                      | Adjudicated nonblocking within the intentionally closed four-document contract set.                                                                                                                                                                                  |
| CALLER-SNAPSHOT-01         | **Open and blocking** for the unchanged caller’s accepted outcome.                                                                                                                                                                                                   |

## 16. Residual findings, minority views, and nonclaims

1. **Blocking — CALLER-SNAPSHOT-01.** The supplied caller’s pathname snapshot equality is a required acceptance condition. Repair and a fresh audit are needed before this exact target can be accepted.
2. **Nonblocking — documentary marker scope.** The validator recognizes the documented exact HTML-comment marker shape; variants with altered spacing are outside that grammar. It does not semantically reject contradictory prose outside the bounded consumer references. Current governing documents contain no observed competing trusted-host claim.
3. **Minor — case-count guard.** Test 89 loops over the current 38 mutation cases but does not assert `len(cases) == 38`. The current source and this audit establish 38; deletion of a case would not by itself fail that count.
4. **Evidence limit.** Producer opening evidence gives the preceding test source hash, not its full bytes. The present 31 cases and predecessor semantics were checked, but byte-for-byte preservation of those 31 from the exact preceding source cannot be independently proved from those artifacts.

The contract auditor’s conditional concern about repository-wide uniqueness is resolved by the closed four-document scope; MK-01 is not carried as a blocker. The marker auditor’s malformed-spacing and out-of-block-prose concerns remain bounded observations. The test auditor withdrew a preliminary regex concern after checking the exact source backslash; the parent independently confirmed generated IDs match. The security auditor’s caller finding is adopted as the blocker.

The pinned interpreter was Python 3.13.4, a regular single-link 119,424-byte file with SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`. Its opening and closing observations support the documented **supported-local** trust assumption. They do **not** prove atomic kernel-loaded interpreter identity, resist a trusted principal’s transient replacement, establish production host attestation, or qualify a shared or adversarial host.

## 17. Created paths, cleanup, and explicit activity confirmations

All retained evidence is under `A`, in `records/`, `reports/`, and `continuations/`, with `audit_writer.py`, `bootstrap.json`, and an empty private `tmp/`. Audit-owned parser/test copies and synthetic A6/SEC-02 fixtures were removed after the retained source and results were written through the evidence writer. Only audit-owned temporary paths were removed. [Cleanup record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v5/reports/temporary-cleanup.json).

**Confirmed:** no repository mutation, formatting, repair, staging, commit, push, or A6 restart was performed. No product or live-service path was invoked; no network contact occurred; no nested subagent was created.
