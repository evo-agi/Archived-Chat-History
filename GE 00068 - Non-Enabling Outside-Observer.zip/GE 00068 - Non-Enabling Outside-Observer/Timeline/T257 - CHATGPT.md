## Assessment

The producer pass closes the prior blocker cleanly. It changed only the **validation-custody contract and observed validation evidence**; B itself remains unchanged.

The critical correction is now explicit and source-supported:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/r
```

That simultaneously satisfies:

- B’s physical containment rule;
- the supported-local private-custody boundary;
- the 100-byte Unix-socket path limit;
- independent replay without writing into the immutable strategic-snapshot root.

The causals are well formed:

- a long shared root reproduces the path-length failures without producing an “outside control root” error;
- the sibling-root V1 layout reproduces the exact containment failures;
- the shared-root V2 layout makes both previously failing identities pass;
- the audit-only boundary harness admits 100 bytes and rejects 101 before bind or process launch.

The producer then replayed the **full original eight-command plan**, not merely the two repaired tests. The result matches the expected B-era acceptance boundary:

- all 105 documentary identities pass;
- all three test-support identities pass;
- external TLS retains exactly its one governed failure and four governed skips;
- all 20 Repair 10 affected identities pass;
- the nonroot group has exactly eight passes and the one governed fixture skip;
- shell syntax and private Git diff checks pass;
- B source T, inventory, Git tree, and synthetic commit remain unchanged.

This is ready for a fresh independent audit. No repository repair, B-source change, governance revision, or additional producer pass is indicated.

### Audit pressure points

The fresh auditor should concentrate on five questions:

1. **Replayability:** independently allocate a different `r10b-<32hex>` root and reproduce the same result without relying on the producer’s pathname.
2. **Path-budget proof:** independently derive the 12-byte temporary-name maximum and the 86-byte worst-case socket path from exact B and pinned Go source.
3. **Plan supersession:** prove that validation plan V3 changes only custody/environment and preserves all eight command semantics and identity policies.
4. **Cross-command isolation:** inspect the shared `r` directory before and after every owning command, ensuring no socket, temporary directory, or acceptance-affecting residue flows into the next command.
5. **Capsule closure:** independently reconstruct the 12-directory/90-file correction capsule and both canonical manifests.

The transient `mdworker` reads are not automatically blocking under the supported-local trusted-host model, but the auditor should preserve and adjudicate them explicitly. Persistent descriptors, mutation, or unexplained external access would block.

## Prompt for the fresh independent audit

```text
FRESH INDEPENDENT AUDIT —
REPAIR 10I T2A-P STRATEGIC B VALIDATION-CUSTODY V2

Perform a fresh, independent, parent-only, read-only audit of the combined
target:

1. the immutable Repair 10I T2A-P strategic B snapshot; and
2. the source-external validation-custody V2 correction capsule.

Do not create subagents.

This audit does not stage, commit, edit, publish, install, deploy, or begin A6.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether validation-custody V2:

- correctly supersedes the unusable sibling-root validation plans;
- is independently replayable with a newly allocated short transient root;
- preserves the strategic B source, tree, synthetic commit, command set, and
  identity-level acceptance policies;
- proves the 100-byte Unix-socket path boundary from exact source;
- produces the required complete eight-command validation result;
- has complete private evidence closure;
- remains evidence-only and nonauthoritative for publication, product, runtime,
  readiness, and A6.

Do not repair any finding.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed files:
  389
- tracked/untracked:
  375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Required strategic B identities:

- root device/inode/mode:
  16777234 / 178255587 / 0700
- B source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- B inventory size:
  54314
- governed files:
  389
- H→B:
  22 modified, 14 added, 0 deleted, 0 renamed
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- synthetic parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- synthetic subject:
  implement Remote Alpha external TLS T2A-P source

Required strategic-snapshot closeout identities:

- closeout/final-evidence-inventory.json
  size:
  130182
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb

- closeout/final-report.md
  size:
  151150
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe

- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  139328 each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  required:
  byte-identical

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9

Required identities:

- root device/inode/mode:
  16777234 / 178361381 / 0700
- retained/final-audit-report.md
  size:
  34460
  SHA-256:
  b7e959a5785af954c6be556da594b39fc3c2da37e8d1b09dd775ddcae623ea65
- retained/final-audit-root-inventory.json
  size:
  25624
  SHA-256:
  d514e99ce2833bdf6bb36dc5e3b9ced3b9eb52651425f9d6057c13e5fb4a8475
- verdict:
  BLOCK

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Required identities:

- root device/inode/mode:
  16777234 / 178515489 / 0700
- closeout/final-evidence-inventory-v1.json
  size:
  16030
  SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  17363 each
  SHA-256:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498
  required:
  byte-identical
- historical verdict:
  REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_REPAIR_BLOCKED

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

Expected root identity:

- device/inode/mode:
  16777234 / 178558083 / 0700

Expected contract:

- contract ID:
  execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2

Expected validation-plan lineage:

- base strategic-snapshot plan
  size:
  28615
  SHA-256:
  b8627359a3df382d8a9d9bb40b03c3e864f632304581bb614557ab36a74fa8ad

- blocked sibling-root plan V2
  size:
  28443
  SHA-256:
  177ea4e983a3d3eae5b23302bf5ae7ac7cf1aedaa7335027607f3e4e5ad65ea4

- proposed effective validation plan V3
  size:
  28590
  SHA-256:
  fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee

Expected retained closure:

- directories:
  12
- regular files:
  90
- nonmanifest files:
  88
- manifest entries:
  100
- empty directories:
  0

- closeout/final-evidence-inventory-v1.json
  size:
  22990
  SHA-256:
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658

- closeout/final-implementation-report-v1.md
  size:
  1355
  SHA-256:
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd

- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  24408 each
  SHA-256:
  2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628
  required:
  byte-identical

Expected producer verdict:

REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_V2_READY_FOR_FRESH_AUDIT

Use other supplied roots only through exact paths referenced by these four
inputs. Do not broadly scan unrelated Downloads content or repository siblings.

──────────────────────────────────────────────────────────────────────────────
2. EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read CANDIDATE_R and the four named supplied roots;
- allocate one fresh retained audit root beneath /Users/ds/Downloads;
- allocate one new short transient execution root beneath
  /Users/ds/Downloads;
- create audit-owned exact-B materializations, private Git state, module caches,
  homes, temporary roots, causal fixtures, reports, and records;
- execute the complete eight-command validation plan offline;
- remove only audit-owned transient state.

Forbidden:

- candidate repository edits or index mutation;
- mutation of any supplied root;
- staging or committing in the candidate;
- restore, reset, amend, rebase, stash, merge, checkout, or clean in the
  candidate;
- changing B source bytes, tests, modes, source T, inventory, Git tree,
  synthetic commit, or H→B classification;
- using the producer’s short-root path as execution authority;
- weakening the containment or 100-byte policies;
- omitting or reclassifying a validation command or expected identity;
- symlink, bind-mount, mount, pathname-alias, or rename workaround;
- product/live-service invocation;
- installation or deployment;
- network contact;
- A6 work;
- subagents.

Every candidate Git read must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to CANDIDATE_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

──────────────────────────────────────────────────────────────────────────────
3. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable retained root beneath
/Users/ds/Downloads using tempfile.mkdtemp with prefix:

ES-repair10i-t2ap-validation-custody-v2-independent-audit-

Retained directories must be direct physical mode-0700 directories.

Retained files must be regular, single-link, mode 0600.

Private transient Git state, source materializations, caches, homes, fixtures,
and temporary state must remain beneath an audit-owned transient area and be
removed before closeout.

Do not retain an unexplained empty directory.

──────────────────────────────────────────────────────────────────────────────
4. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Read candidate AGENTS.md and applicable nested guidance.
2. Verify complete candidate identity and current F inventory.
3. Verify complete STRATEGIC_B_ROOT closure and fixed identities.
4. Verify complete BLOCKING_AUDIT_ROOT closure and verdict.
5. Verify complete BLOCKED_V1_REPAIR_ROOT closure and historical blocked
   disposition.
6. Verify complete VALIDATION_CUSTODY_V2_ROOT closure.
7. Verify all three validation-plan identities and exact lineage.
8. Verify the pinned Go toolchain and the 20 named offline module-cache source
   roots before use.
9. Retain complete opening inventories of every supplied root used.
10. Verify no candidate Git operation marker or lock.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

Do not clean, normalize, chmod, recreate, or repair a supplied object.

──────────────────────────────────────────────────────────────────────────────
5. CONTRACT AND SUPERSESSION AUDIT
──────────────────────────────────────────────────────────────────────────────

Audit these complete records:

- contract/strategic-b-validation-custody-v2.json
- contract/validation-plan-v3.json
- contract/validation-plan-supersession-v2.json
- contract/path-budget-v2.json
- contract/short-root-allocation-v2.json

Require that V2 freezes:

- short-root parent `/Users/ds/Downloads`;
- basename `r10b-<32-lowercase-hex>`;
- fresh 16-byte OS-CSPRNG material per attempt;
- descriptor-relative exclusive mode-0700 creation;
- component-by-component no-follow parent traversal;
- EEXIST-only retry;
- fresh collision material;
- 128-attempt maximum;
- all other failures terminal;
- retained parent and child descriptor/identity checks;
- no scan/latest/adoption/rename/PID/counter/timestamp/Git-hash authority;
- exact direct children `s,h,u,c,m,r`;
- no persistent `t`;
- exact equality of TMPDIR and control-root lexical path and physical identity.

Require plan V3 to preserve:

- all eight command IDs;
- exact ordering;
- argv semantics except parameterized private paths;
- pinned tools;
- expected exits;
- exact pass/fail/skip identity policies;
- governing rationale;
- B source/tree/synthetic-commit identities.

Require the supersession record to state exactly:

- base plan remains historical source plan;
- sibling-root V1/V2 plans are historical and non-effective;
- V2 custody/plan V3 is proposed effective only after this independent audit;
- B source, origin, logical modes, inventory, tree, synthetic commit, H→B
  classification, and authority boundaries are unchanged.

Return BLOCK on any silent redefinition or authority widening.

──────────────────────────────────────────────────────────────────────────────
6. INDEPENDENT SHORT-ROOT ALLOCATION
──────────────────────────────────────────────────────────────────────────────

Do not import or call the producer allocator.

Independently implement the frozen allocation contract and allocate a new root:

/Users/ds/Downloads/r10b-<new-32-lowercase-hex>

Require:

- path byte length exactly 57;
- direct physical parentage;
- UID/GID/mode conformance;
- stable device/inode;
- no symlink component;
- no alias or containment with any supplied root or the candidate;
- exact child set `s,h,u,c,m,r`;
- each child mode 0700;
- no persistent `t`.

Retain an audit allocation record.

Perform bounded allocator causals using audit-owned fixtures:

- occupied candidate name produces EEXIST and a fresh token;
- non-EEXIST injected failure is terminal;
- symlinked parent component is rejected;
- wrong mode or unstable identity is rejected;
- no existing path is adopted.

Do not let causal fixtures become retained execution authority.

──────────────────────────────────────────────────────────────────────────────
7. INDEPENDENT PATH-BUDGET PROOF
──────────────────────────────────────────────────────────────────────────────

Inspect exact B bytes for:

- `internal/testsupport/controlroot.go`
- `internal/testsupport/controlroot_test.go`
- `es/runtimehelper/helper_test.go`

Inspect pinned Go 1.26.5:

- `src/os/tempfile.go`
- every exact source needed to establish the generated-name grammar.

Independently derive:

- short-root length:
  57
- shared `r` path length:
  59
- generated-name maximum:
  12
- separator bytes:
  2
- `identity.sock`:
  13
- worst-case complete path:
  86
- policy limit:
  100
- result:
  86 <= 100

Verify that TMPDIR/control-root lexical equality and device/inode equality
satisfy exact B’s containment implementation.

Reject an observed random generated name as sufficient proof; use the grammar’s
maximum.

──────────────────────────────────────────────────────────────────────────────
8. INDEPENDENT FOUR-CAUSAL MATRIX
──────────────────────────────────────────────────────────────────────────────

Use audit-owned exact-B copies only.

A. Long shared-root negative

Use one long physical directory for both TMPDIR and control root.

Require:

- `TestRepair10ControlRootPolicyV1` rejects for path length;
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` rejects at or before
  bind for the overlong path;
- neither fails as outside control root.

B. Sibling-root historical negative

Use audit-owned sibling `r` and `t`.

Require both identities to reject specifically because TMPDIR is outside the
control root, without a path-length classification.

C. Shared-root positive

Use the newly allocated audit `r` as both TMPDIR and control root.

Require:

- both identities pass;
- zero skip;
- no path above 100 bytes;
- no B source/tree mutation;
- no supplied-root write;
- no unexplained socket or temporary residue.

D. 100/101 boundary

Use an audit-only same-package harness against an audit-owned exact-B copy.

Require:

- exact 100-byte candidate admitted;
- exact 101-byte candidate rejected before unsafe bind or process launch;
- harness not counted as B/product validation;
- primary B validation source unchanged.

Compare each result with the producer causal, but do not use producer result
parsers as the audit oracle.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT EXACT-B MATERIALIZATION
──────────────────────────────────────────────────────────────────────────────

Create a fresh exact-B source beneath `<AUDIT_SHORT_ROOT>/s`.

Independently require:

- 389 governed files;
- B source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- B inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- inventory size:
  54314
- Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- synthetic parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- synthetic subject:
  implement Remote Alpha external TLS T2A-P source
- H→B:
  22 modified, 14 added, 0 deleted, 0 renamed
- clean private Git state;
- no inode alias with candidate or supplied roots.

Do not import the producer materializer. Use the accepted strategic snapshot’s
authenticated source inventory and origin records as inputs, then independently
check the resulting bytes and logical modes.

──────────────────────────────────────────────────────────────────────────────
10. OFFLINE ENVIRONMENT
──────────────────────────────────────────────────────────────────────────────

Pinned Go:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Require:

- version:
  go version go1.26.5 darwin/arm64
- SHA-256:
  3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Use:

HOME=<AUDIT_SHORT_ROOT>/h
TMPDIR=<AUDIT_SHORT_ROOT>/r
GOTMPDIR=<AUDIT_SHORT_ROOT>/u
GOCACHE=<AUDIT_SHORT_ROOT>/c
GOMODCACHE=<AUDIT_SHORT_ROOT>/m
ES_REPAIR10_SOURCE_ROOT=<AUDIT_SHORT_ROOT>/s
ES_REPAIR10_CONTROL_ROOT=<AUDIT_SHORT_ROOT>/r

and:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GOROOT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64
GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Independently seed only the 80 already-present pinned module-cache objects
across the exact 20 required modules. Retain source and destination identities
and prove physical separation.

No network or installation.

──────────────────────────────────────────────────────────────────────────────
11. FRESH COMPLETE EIGHT-COMMAND REPLAY
──────────────────────────────────────────────────────────────────────────────

Extract the exact argv arrays from validation-plan V3. Compare them structurally
with the base strategic-snapshot plan and prove that only parameterized physical
paths/custody changed.

Run all eight commands in the exact retained order:

1. go-version
2. complete-docs-105
3. testsupport-acceptance
4. external-tls-all
5. repair10-current-affected-pass
6. changed-nonroot-product-tests
7. bash-syntax
8. private-git-diff-check

For every owning command retain:

- full argv;
- cwd;
- exact explicit environment;
- exit/signal;
- complete stdout/stderr;
- sizes and SHA-256 values;
- exact pass/fail/skip/error/panic identities;
- B tree and inventory before/after;
- private Git status before/after;
- generated-state inventory;
- `r` directory inventory before and after;
- live socket/process/descriptor observations.

CROSS-COMMAND ISOLATION

Before and after every command:

- require no unexplained socket under `r`;
- require no surviving process using `r`;
- require no acceptance-affecting temporary entry from an earlier command;
- classify any retained entry and prove it cannot influence the next command;
- require B source and private Git state unchanged.

Expected outcomes:

A. complete-docs-105

- exactly 105 top-level identities;
- 105 pass;
- zero skip, fail, error, or panic.

B. testsupport-acceptance

- PASS `TestRepair10ControlRootPolicyV1`
- PASS `TestRepair10OwnedProcessLifecycleV1`
- PASS `TestRepair10SignalBirthMismatchNeverSignalsV1`
- raw exit 0.

C. external-tls-all

Exactly one allowed failure:

- `execution-substrate/es/externaltls/internal/statuspackage::TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2`

Required failure mechanism:

- `lifetime_lock_identity_invalid`

Exactly four allowed skips:

- `TestPrivateExactCandidateCompilerInputOracleAndOmissionsV2`
- `TestPrivateExactCandidateDeterministicPreparationAndReuseV2`
- `TestRepair10ECombinedErrorExactCloseCardinalityV2`
- `TestRepair10PublishedStageCombinedErrorRealPreparationV2`

Require zero additional fail, skip, error, panic, timeout, duplicate terminal, or
malformed event.

D. repair10-current-affected-pass

- exact retained 20 identities;
- 20 pass;
- zero fail or skip.

E. changed-nonroot-product-tests

Required passes:

- `TestExecutionWorkspaceTempDirUsesControlRoot`
- `TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir`
- `TestNomadHarnessProcessCustodianWithoutServiceV1`
- `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`
- `TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess`
- `TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath`
- `TestValidateExecutionRuntimeInputsRejectsNonRegularBinary`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`

Required governed skip:

- `TestNomadHarnessProcessCustodianFixtureV1`
  exact reason:
  `private custodian fixture only`

Require eight passes, one governed skip, zero fail/error/panic.

F. bash-syntax

- exit 0;
- empty stdout and stderr.

G. private-git-diff-check

- exit 0;
- empty stdout and stderr.

Require all streams complete and B source/tree/private Git state unchanged after
every command.

Do not use producer summary records as the result oracle.

──────────────────────────────────────────────────────────────────────────────
12. HOST-SERVICE AND DESCRIPTOR ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Record any non-task process that opens a descriptor beneath the audit short
root, including macOS metadata/indexing services.

Classify separately:

- task-owned process/descriptor survivor;
- trusted host-service transient read;
- supplied-root access;
- mutation;
- persistent survivor.

A transient trusted host-service read is not automatically blocking under the
supported-local trust model when:

- it performs no observed mutation;
- it closes before cleanup;
- no descriptor survives;
- all authenticated bytes remain unchanged.

Persistent descriptors, mutation, unexpected write access, or unclassified
process custody block acceptance.

Do not suppress or omit such observations.

──────────────────────────────────────────────────────────────────────────────
13. CAPSULE CLOSURE AND SECURITY
──────────────────────────────────────────────────────────────────────────────

Independently enumerate VALIDATION_CUSTODY_V2_ROOT.

Require:

- 12 directories including root;
- 90 regular files;
- 88 nonmanifest files;
- exactly two self-excluded manifests;
- 100 represented entries;
- no empty or unexplained directory;
- all directories mode 0700;
- all files regular, single-link, mode 0600;
- no symlink, special file, or multiple-link file.

Independently generate two manifest projections using different audit-owned
traversal implementations. Require both to equal the supplied manifest bytes
and hash to:

2bcff6abee571388a37d30d956abb9012630796911f4aa57380806a67bc90628

Verify:

- final-evidence-inventory-v1.json
  22990 bytes
  c17800c69c02565864f8f82a2d70cd5654b729c775c6503627c9742abac6d658

- final-implementation-report-v1.md
  1355 bytes
  9e7fd3f059c2cd6e2e3fe306a28a47449b478c63203c82e73f717e1941ad25cd

Audit the full machine records; do not treat the short retained narrative as a
substitute for those records.

Perform bounded sensitive-material scanning without printing payload content.
Distinguish test fixtures, redaction patterns, and fake tokens from plausible
live secrets.

──────────────────────────────────────────────────────────────────────────────
14. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Require that the combined target claims only:

Strategic B snapshot:

- B source bytes and logical modes;
- H→B classification;
- B source T, inventory, Git tree;
- synthetic evidence commit;
- source provenance.

V2 custody capsule:

- short-root allocation semantics;
- shared control/TMP identity;
- path-budget proof;
- validation-plan V3 environment/custody;
- observed validation;
- narrow supersession of blocked plans/results.

Require explicit nonauthority over:

- publication and commit;
- current repository truth for B;
- future publication commit identity;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation;
- hostile/shared-host support;
- symlink/mount aliases.

The strategic snapshot remains the sole B source/provenance package. The V2
capsule must not become a second B source authority.

──────────────────────────────────────────────────────────────────────────────
15. CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After all validation:

1. Reap every task-owned process.
2. Verify no task-owned socket or descriptor survivor.
3. Wait through bounded host-service descriptor observations until zero or
   adjudicate a persistent survivor as blocking.
4. Remove only the audit-owned short root and all descendants.
5. Do not chmod supplied or retained objects for cleanup.
6. Make two fresh `lstat` observations returning ENOENT.
7. Verify no audit-owned `r10b-*` sibling remains.
8. Recompute candidate opening/closing equality.
9. Recompute all four supplied-root opening/closing equalities.
10. Recompute every pinned module-cache source identity actually used.
11. Verify B source/tree/inventory from retained strategic records again.
12. Verify V2 capsule closure and manifests again.
13. Retain a complete audit-root inventory and inline report.
14. Require retained audit directories mode 0700 and retained files regular,
    single-link, mode 0600.
15. Require no unexplained empty directory.

Return AUDIT_PROVENANCE_MISMATCH on any supplied-root drift or unprovable
opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
16. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- opening and closing provenance qualify;
- contract V2 and plan V3 independently qualify;
- an independently allocated short root satisfies the frozen contract;
- the path-budget proof is independently reproduced;
- all four causals match;
- complete eight-command validation matches at identity level;
- no cross-command generated-state contamination exists;
- B identities remain exact;
- V2 capsule closure and security pass;
- no authority widening or acceptance-affecting finding remains.

Return BLOCK for a repairable contract, allocator, path-budget, plan,
validation, isolation, closure, security, artifact, or authority defect.

Return REJECT only for fundamental unsoundness not repairable within the
validation-custody scope.

Return AUDIT_PROVENANCE_MISMATCH on input drift, supplied-root mutation,
missing exact input, or failed opening/closing equality.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
17. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete report inline, including:

1. Primary verdict
2. Audit-root identity
3. Candidate and supplied-root opening identities
4. V2 capsule closure
5. Contract V2 field-map adjudication
6. Plan V1/V2/V3 lineage adjudication
7. Independent short-root allocation
8. Independent path-budget derivation
9. Long-root negative
10. Sibling-root historical negative
11. Shared-root positive
12. 100/101 boundary
13. Exact B materialization identities
14. Exact eight command argv/environment records
15. Exact identity-level validation outcomes
16. Cross-command generated-state isolation
17. Host-service descriptor observations and resolution
18. Capsule manifest and final-inventory closure
19. Sensitive-material and artifact findings
20. Authority and nonauthority adjudication
21. Severity-ranked residual findings
22. Alternative interpretations and parent resolution
23. Cleanup and two ENOENT observations
24. Candidate and supplied-root closing equality
25. Audit-created paths and final inventory
26. Remaining uncertainty and explicit nonclaims
27. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
CONTROL_ROOT_AND_TMPDIR_SHARED_EXACT_PHYSICAL_DIRECTORY
SHORT_TRANSIENT_ROOT_INDEPENDENTLY_ALLOCATED
SHORT_TRANSIENT_ROOT_REMOVED
TWO_ABSENCE_OBSERVATIONS_COMPLETED
VALIDATION_PLAN_INDEPENDENTLY_ADJUDICATED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, the next authorized operation is the real H→B commit gate:

- stage the exact 36 accepted paths;
- validate the exact staged tree under the accepted V2 custody contract;
- create one commit with subject  
  `implement Remote Alpha external TLS T2A-P source`;
- make no push or upstream change.

Only after B is committed should the already-audited B→F governance commit be gated.

### Source

Codex producer report in the preceding message.

**Confidence:** 0.995 that the V2 producer pass is ready for independent audit; 0.99 that the shared-root correction closes both prior validation failures without changing B; 0.97 that cross-command transient-state isolation is the most important remaining dynamic audit seam.
