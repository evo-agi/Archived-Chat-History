## Engineering assessment

Codex stopped at the right boundary. The blocker is a **governing taxonomy defect in our documentary prompt**, not a source, bundle, implementation-package, or provenance failure.

The contract declared a closed four-domain set:

- `HARNESS_RUNTIME_REPORT`
- `HARNESS_RUNTIME_CONFIRMATIONS`
- `IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT`
- `IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS`

but the mandatory aggregate registry assigned the matrix suite to a fifth domain, `HARNESS_RUNTIME_MATRICES`. Because unknown domains were required to fail closed, Codex could not lawfully freeze either interpretation. :chatgpt-content-reference{index="0"}

The correct operating-model decision is:

> **Matrices are a distinct runtime evidence domain. Add `HARNESS_RUNTIME_MATRICES` as the fifth closed domain. Do not subordinate matrices to the runtime report or confirmation domains.**

The other documentary authorities are now unambiguous:

- runtime report registry: exactly 66 ordered sections, `R01–R66`; :chatgpt-content-reference{index="1"}
- runtime confirmation registry: exactly 81 unique names, verdict excluded; :chatgpt-content-reference{index="2"}
- runtime matrix registry: exactly 15 rows and 595 total cases;
- stale total `645`: rejected and nonauthoritative;
- unavailable historical writer of `645`: nonblocking, provided future aggregates have one owner and independent recomputation. :chatgpt-content-reference{index="3"}

Future implementation aggregates such as source counts, interface counts, PYZ member count, and authenticated bundle counts should **not create more documentary domains**. They should use an orthogonal `owner_class` and exact owner registry. That prevents another taxonomy failure:

- `DOCUMENTARY_REGISTRY`
- `FUTURE_IMPLEMENTATION_REGISTRY`
- `AUTHENTICATED_INPUT`

The previous documentary attempt created no implementation or validator source, ran no harness, issued no package verdict, and left the bundle, authority JSON, and historical blocked evidence unchanged. :chatgpt-content-reference{index="4"}

### Progression decision

Run one fresh documentary-contract tranche with the corrected five-domain model. After it seals, begin a **new clean harness implementation generation**. Do not classify that future generation as Attempt 3 of the retired implementation.

---

```text
FREEZE THE CORRECTED GOVERNING DOCUMENTARY CONTRACT FOR THE NEXT
CLEAN GENERATION-2 SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS

FIVE-DOMAIN RUNTIME MODEL

Objective

Create and terminally close a documentary governing package that resolves the
sole blocker from the preceding documentary attempt:

- the previous domain contract enumerated four domains;
- the runtime matrix registry required a fifth domain;
- unknown domains were required to fail closed.

This task makes the explicit operating-model decision that runtime matrices
constitute their own documentary domain:

HARNESS_RUNTIME_MATRICES

The future harness documentary model therefore has exactly five closed domains:

1. HARNESS_RUNTIME_REPORT
2. HARNESS_RUNTIME_CONFIRMATIONS
3. HARNESS_RUNTIME_MATRICES
4. IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT
5. IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS

Do not bind runtime matrices to the report or confirmation domains.

Future source-registry, interface-registry, PYZ-member, and authenticated-input
aggregates do not create additional documentary domains. They use a separate
`owner_class` field and exact owner registry.

This is a documentary-contract tranche only.

Do not implement future harness production source.
Do not implement future harness qualification source.
Do not implement future harness independent-validator source.
Do not compile or package a harness.
Do not create a PYZ.
Do not execute a full audit.
Do not adjudicate the Generation-2 implementation package.
Do not execute implementation production source.
Do not construct the authoritative current schema subject.
Do not reopen original contaminated package directories.
Do not perform another historical findings reconciliation.

The task may create bounded documentary-package builders and source-external
documentary validators needed to validate and terminally close this package.
Those are package tooling, not future harness source.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned documentary build in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_BLOCKED

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT FILE-LEVEL AUTHORITY
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate both exact files.

The containing directory is nonauthoritative.

Open no original package root.

──────────────────────────────────────────────────────────────────────────────
2. PRIOR BLOCKED DOCUMENTARY ATTEMPT
──────────────────────────────────────────────────────────────────────────────

PRIOR_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-aeqwa63b

Expected identity:

- device:
  16777234
- inode:
  181849301
- mode:
  0700
- verdict:
  GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_BLOCKED
- disposition:
  precontract blocked, noncurrent, nonauthoritative
- implementation source:
  absent
- harness package:
  absent
- real audit:
  not executed
- success terminal closure:
  false
- same-root retry:
  false

Authenticate only exact retained evidence:

analysis/documentary-domain-authority-conflict-v1.json
validation/precontract-documentary-consistency-v1.json
validation/supplied-file-closing-equality-v1.json
closeout/failure-closeout-v1.json
closeout/failure-root-inventory-v1.json
closeout/explicit-documentary-confirmations-v1.json

Authenticate the exact blocker:

- four-domain closed set;
- mandatory aggregate row using:
  HARNESS_RUNTIME_MATRICES;
- unknown domains fail closed;
- exact runtime report registry otherwise contained 66 rows;
- exact runtime confirmation registry otherwise contained 81 names;
- exact runtime matrix registry otherwise contained 15 rows / 595 cases;
- no source or validator source was created;
- no harness was packaged;
- no real audit ran;
- supplied inputs closed equal.

Classify this root as:

historical_noncurrent_missing_runtime_matrix_domain

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- not a future harness source base;
- not cleanable in this task.

Require exact opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
3. FRESH DOCUMENTARY-CONTRACT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Before supplied-file inspection retain:

opening/bootstrap-start.json
opening/documentary-contract-authority-v2.json
opening/fixed-input-file-registry-v2.json
opening/prior-documentary-attempt-disposition-v1.json
opening/process-execution-policy-v2.json

Authority is limited to:

- exact input authentication;
- documentary-domain definition;
- exact runtime registries;
- aggregate-owner rules;
- documentary mutation qualification;
- source-external documentary validation;
- supplied-input closing equality;
- documentary-package terminal closure.

Nonauthority includes:

- future harness implementation;
- implementation repair;
- implementation-package adjudication;
- current-subject construction;
- product/runtime/target/repository activity;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
4. CORRECTED FIVE-DOMAIN CONTRACT
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/documentary-domain-separation-v2.json

Define exactly five future harness documentary domains.

D-A. HARNESS_RUNTIME_REPORT

Purpose:

The exact report projected by the future harness and by its qualification
evidence.

Owner:

contract/harness-runtime-report-section-registry-v1.json

D-B. HARNESS_RUNTIME_CONFIRMATIONS

Purpose:

The exact confirmation set projected by the future harness and qualified as
part of its authority.

Owner:

contract/harness-runtime-confirmation-name-registry-v1.json

D-C. HARNESS_RUNTIME_MATRICES

Purpose:

The exact B00 and D01–D14 matrix registry and the results derived from those
rows.

Owner:

contract/harness-runtime-matrix-registry-v1.json

This is a first-class runtime evidence domain.

It is not part of:

- HARNESS_RUNTIME_REPORT;
- HARNESS_RUNTIME_CONFIRMATIONS.

D-D. IMPLEMENTATION_TRANCHE_OPERATIVE_REPORT

Purpose:

The report returned by a future harness implementation tranche.

It is not the future harness runtime report.

Its rows and count are owned solely by the exact implementation-tranche task
registry.

D-E. IMPLEMENTATION_TRANCHE_SAFETY_CONFIRMATIONS

Purpose:

Task-level safety and nonactivity confirmations used while implementing the
future harness.

They are not the harness runtime confirmation registry.

Their names and count are owned solely by the exact implementation-tranche task
registry.

Closed-domain rules:

- the five IDs above are exact;
- duplicate IDs fail;
- missing IDs fail;
- extra IDs fail;
- unknown domain fails;
- a consumer must identify its exact domain;
- no report, confirmation, or matrix aggregate may cross domains;
- no task-level registry may satisfy a runtime-domain consumer;
- no runtime-domain registry may silently replace a task registry;
- counts are derived from exact owner rows;
- prose and copied summary counts are nonauthoritative.

Derived domain count:

5

No independent numeric domain-count writer is permitted.

──────────────────────────────────────────────────────────────────────────────
5. NONDOCUMENTARY AGGREGATE OWNER CLASSES
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/aggregate-owner-classification-v1.json

Future aggregates that are not report, confirmation, or matrix documentary
domains use `owner_class`, not a new documentary domain.

Define exactly these owner classes:

1. DOCUMENTARY_REGISTRY

Used only for the five documentary domains.

Required fields:

- documentary_domain;
- owner record;
- row pointer;
- unique-ID pointer;
- value pointer;
- derivation.

2. FUTURE_IMPLEMENTATION_REGISTRY

Used for future:

- production-source count;
- qualification-source count;
- independent-source count;
- architecture-role count;
- cross-module-interface count;
- PYZ member count.

Required fields:

- registry role;
- owner record;
- row pointer;
- unique-ID pointer;
- derivation;
- future consumer contract.

`documentary_domain` must be absent.

3. AUTHENTICATED_INPUT

Used for current input-bundle aggregates:

- role count:
  8;
- archive member count:
  479.

Required fields:

- authority record;
- authenticated file identity;
- exact value pointer;
- independent recomputation method.

`documentary_domain` must be absent.

Rules:

- owner class and documentary domain are orthogonal;
- only DOCUMENTARY_REGISTRY may carry `documentary_domain`;
- FUTURE_IMPLEMENTATION_REGISTRY and AUTHENTICATED_INPUT may not create
  documentary domains;
- every aggregate has exactly one owner;
- every consumer binds one aggregate ID;
- every consumer independently recomputes or consumes one immutable validated
  aggregate result;
- copied summaries are nonauthoritative;
- generic truthiness is forbidden;
- absence is never zero or success.

──────────────────────────────────────────────────────────────────────────────
6. EXACT HARNESS RUNTIME REPORT REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/harness-runtime-report-section-registry-v1.json

Freeze exactly these 66 ordered rows:

R01  Primary verdict
R02  Fresh build-root identity
R03  Fresh output-root identity
R04  Exact input-bundle identity
R05  Exact input-authority identity
R06  Bundle/authority authentication
R07  Bundle index/member closure
R08  Current role resolution
R09  Clean-room source authority
R10  Harness authority and nonauthority
R11  Mode and future-invocation contract
R12  Defect-prevention registry
R13  Full-audit phase plan
R14  Report contract
R15  Confirmation contract
R16  Source architecture
R17  Source-attempt ledger
R18  Final production-source registry
R19  Final qualification-source registry
R20  Final independent-source registry
R21  Cross-module interface registry
R22  Precompilation gate
R23  Compilation/static gates
R24  B00 bundle matrix
R25  D01 matrix result
R26  D02 matrix result
R27  D03 matrix result
R28  D04 matrix result
R29  D05 matrix result
R30  D06 matrix result
R31  D07 matrix result
R32  D08 matrix result
R33  D09 matrix result
R34  D10 matrix result
R35  D11 matrix result
R36  D12 matrix result
R37  D13 matrix result
R38  D14 matrix result
R39  Process-custody qualification
R40  Synthetic ACCEPT lane
R41  Synthetic BLOCK lane
R42  Synthetic provenance-failure lane
R43  Synthetic subject-pair lane
R44  Bounded real-bundle compatibility replay
R45  Harness rehearsal A
R46  Harness rehearsal B
R47  Rehearsal normalized comparison
R48  Independent validators
R49  Evidence retention
R50  Build/rehearsal cleanup
R51  Source freeze
R52  PYZ Build A
R53  PYZ Build B
R54  PYZ Build-A/B equality
R55  Final PYZ member closure
R56  Final authority-JSON identity
R57  Frozen-PYZ requalification
R58  Confirmation full real audit was not executed
R59  Confirmation implementation verdict was not issued
R60  Harness-package status
R61  Input-file closing equality
R62  Failure-closeout capability and use
R63  Final PYZ path and identity
R64  Final authority-JSON path and identity
R65  Remaining uncertainty and nonclaims
R66  Explicit confirmation registry

Derive:

- row count:
  66;
- unique IDs:
  66;
- first:
  R01;
- last:
  R66.

No other runtime report row is current.

No independent report-count literal is authoritative.

──────────────────────────────────────────────────────────────────────────────
7. EXACT HARNESS RUNTIME CONFIRMATION REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/harness-runtime-confirmation-name-registry-v1.json

Freeze exactly these 81 unique names:

CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
BUNDLE_AUTHORITY_JSON_STRICTLY_VALIDATED
BUNDLE_ZIP_GRAMMAR_VALIDATED
BUNDLE_INDEX_MEMBER_MODEL_VALIDATED
BUNDLE_MEMBER_SET_CLOSED
EXACTLY_EIGHT_CURRENT_ROLES_RESOLVED
SEVEN_CONTENT_SNAPSHOT_ROLES_RESOLVED
ONE_BOUNDED_FAILURE_EVIDENCE_ROLE_RESOLVED
NO_LIVE_ROOT_ACCESSED
NO_HISTORICAL_HARNESS_SOURCE_USED
NO_IMPLEMENTATION_SOURCE_USED_AS_HARNESS_SOURCE
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
HARNESS_AUTHORITY_SCOPE_CLOSED
HARNESS_NONAUTHORITY_SCOPE_CLOSED
QUALIFY_HARNESS_MODE_IMPLEMENTED
RUN_FULL_AUDIT_MODE_IMPLEMENTED
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
FUTURE_FULL_AUDIT_INVOCATION_FROZEN
DEFECT_PREVENTION_REGISTRY_COMPLETE
FULL_AUDIT_PHASE_PLAN_COMPLETE
REPORT_SECTION_REGISTRY_FROZEN
REPORT_SECTION_COUNT_DERIVED
CONFIRMATION_NAME_REGISTRY_FROZEN
CONFIRMATION_COUNT_DERIVED
PRIMARY_VERDICT_SEPARATE_FROM_CONFIRMATIONS
SOURCE_ARCHITECTURE_COMPLETE
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_SOURCE_REGISTRIES_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
BUNDLE_AUTHORITY_MATRIX_PASSED
D01_D14_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
HARNESS_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
HARNESS_SOURCE_FROZEN
HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_DETERMINISTIC_FORMAT_FROZEN
PYZ_BUILD_A_CREATED
PYZ_BUILD_B_CREATED
PYZ_BUILD_A_B_BYTES_IDENTICAL
FINAL_PYZ_MEMBER_SET_CLOSED
FINAL_AUTHORITY_JSON_BINDS_PYZ
FROZEN_PYZ_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED
FINAL_PYZ_CREATED
FINAL_PYZ_MODE_0400
FINAL_PYZ_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

Derived:

- unique-name count:
  81.

The primary verdict is not a confirmation.

No task-level confirmation may be appended to this runtime registry.

──────────────────────────────────────────────────────────────────────────────
8. EXACT HARNESS RUNTIME MATRIX REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/harness-runtime-matrix-registry-v1.json

Documentary domain:

HARNESS_RUNTIME_MATRICES

Exact rows:

B00  70
D01  30
D02  25
D03  30
D04  30
D05  35
D06  100
D07  30
D08  40
D09  40
D10  30
D11  50
D12  35
D13  25
D14  25

Derive exclusively from these rows:

- matrix count:
  15;
- matrix case total:
  595.

Reject:

- 645;
- independent matrix-total writers;
- copied totals not checked against the exact rows;
- duplicate IDs;
- missing IDs;
- extra IDs;
- Boolean, string, float, null, or negative counts;
- absence-as-zero.

Each future consumer must independently recompute the exact totals or consume
one immutable validated aggregate result that binds all exact row identities.

──────────────────────────────────────────────────────────────────────────────
9. HISTORICAL 645 DISPOSITION
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/historical-matrix-total-645-disposition-v2.json

Required conclusions:

- 595 is authoritative;
- 645 is rejected;
- exact historical source writer is unavailable;
- source-byte recovery and guessing are prohibited;
- exact historical writer identification is not required for future
  implementation acceptance;
- future prevention is:
  one owner plus independent recomputation;
- historical uncertainty:
  report-only;
- package-verdict effect:
  none;
- implementation-semantic effect:
  none.

Do not include `MATRIX_COUNT_645_ROOT_CAUSE_IDENTIFIED` in the future runtime
confirmation registry.

──────────────────────────────────────────────────────────────────────────────
10. AGGREGATE OWNER/CONSUMER REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/aggregate-owner-consumer-registry-v2.json

Current mandatory rows:

A. Runtime report

- aggregate ID:
  runtime-report-row-count;
- owner class:
  DOCUMENTARY_REGISTRY;
- documentary domain:
  HARNESS_RUNTIME_REPORT;
- owner:
  harness-runtime-report-section-registry-v1.json#/rows;
- unique ID:
  section_id;
- derivation:
  count exact unique rows;
- current value:
  66.

B. Runtime confirmations

- aggregate ID:
  runtime-confirmation-name-count;
- owner class:
  DOCUMENTARY_REGISTRY;
- documentary domain:
  HARNESS_RUNTIME_CONFIRMATIONS;
- owner:
  harness-runtime-confirmation-name-registry-v1.json#/names;
- unique ID:
  confirmation name;
- derivation:
  count exact unique names;
- current value:
  81.

C. Runtime matrices

- aggregate ID:
  runtime-matrix-count;
- owner class:
  DOCUMENTARY_REGISTRY;
- documentary domain:
  HARNESS_RUNTIME_MATRICES;
- owner:
  harness-runtime-matrix-registry-v1.json#/rows;
- unique ID:
  matrix_id;
- derivation:
  count exact unique rows;
- current value:
  15.

- aggregate ID:
  runtime-matrix-case-total;
- owner class:
  DOCUMENTARY_REGISTRY;
- documentary domain:
  HARNESS_RUNTIME_MATRICES;
- owner:
  harness-runtime-matrix-registry-v1.json#/rows;
- unique ID:
  matrix_id;
- value:
  case_count;
- derivation:
  sum exact integer case_count values;
- current value:
  595.

D. Current authority bundle roles

- aggregate ID:
  current-bundle-role-count;
- owner class:
  AUTHENTICATED_INPUT;
- authority:
  current authority JSON;
- independent recomputation:
  role registry in bundle;
- current value:
  8.

E. Current authority bundle members

- aggregate ID:
  current-bundle-member-count;
- owner class:
  AUTHENTICATED_INPUT;
- authority:
  current authority JSON;
- independent recomputation:
  ZIP central directory plus bundle index self-member model;
- current value:
  479.

Future templates:

- production-source count;
- qualification-source count;
- independent-source count;
- architecture-role count;
- interface count;
- PYZ member count.

All future template rows use:

owner_class = FUTURE_IMPLEMENTATION_REGISTRY

They must not carry `documentary_domain`.

Every aggregate row binds:

- owner class;
- aggregate ID;
- owner artifact;
- row pointer;
- unique-ID pointer;
- value pointer when applicable;
- derivation;
- expected type;
- consumers;
- independent validation method;
- failure reason;
- unknown-field rule.

Exactly one authoritative owner per aggregate.

──────────────────────────────────────────────────────────────────────────────
11. DOCUMENTARY MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 65 uniquely named cases.

Include:

Domain cases:

- exact five-domain baseline;
- missing matrix domain;
- four-domain predecessor;
- extra sixth domain;
- duplicate domain;
- unknown domain;
- matrix assigned to report;
- matrix assigned to confirmations;
- task report assigned to runtime report;
- task confirmations assigned to runtime confirmations;
- future source count incorrectly creates documentary domain;
- authenticated input incorrectly creates documentary domain.

Report cases:

- exact 66 rows;
- missing row;
- extra row;
- duplicate ID;
- reordered row;
- renamed row;
- copied 66 with 68 rows;
- task report rows presented as runtime rows.

Confirmation cases:

- exact 81 names;
- 76-name predecessor;
- invented five names;
- missing name;
- duplicate name;
- appended verdict;
- copied 81 with 76 names;
- task confirmations presented as runtime names.

Matrix cases:

- exact 15/595 baseline;
- stale 645;
- duplicate D11;
- missing B00;
- extra matrix;
- right total with wrong row;
- wrong total with right rows;
- Boolean/string/float/null/negative count;
- absence-as-zero.

Owner-class cases:

- exact DOCUMENTARY_REGISTRY row;
- exact FUTURE_IMPLEMENTATION_REGISTRY template;
- exact AUTHENTICATED_INPUT row;
- documentary domain on future source row;
- documentary domain on input row;
- missing documentary domain on runtime matrix row;
- two owners for one aggregate;
- copied summary without recomputation.

Historical-writer cases:

- unavailable writer treated as blocking;
- unavailable writer treated as report-only;
- guessed writer;
- exact nonblocking baseline.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/documentary-domain-and-aggregate-matrix-v2.json

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT DOCUMENTARY VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Create a source-external validator that imports neither documentary producer
helpers, matrix generators, nor expected-result maps.

It must independently:

1. reconstruct the exact five-domain set;
2. verify matrix domain presence;
3. reconstruct the exact 66 report rows;
4. verify report order and uniqueness;
5. reconstruct the exact 81 confirmation names;
6. verify uniqueness and verdict separation;
7. reconstruct the exact 15 matrix rows;
8. recompute 595;
9. reject 645;
10. validate owner classes independently from documentary domains;
11. validate aggregate-owner uniqueness;
12. validate bundle role/member counts from the input files;
13. validate future registry templates;
14. run independent negative cases;
15. verify historical writer unavailability is nonblocking;
16. verify no implementation source exists.

Require zero errors.

Retain:

validation/independent-governing-documentary-contract-validator-v2.json

──────────────────────────────────────────────────────────────────────────────
13. DOCUMENTARY PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain independently authored projections:

analysis/perspective-domain-taxonomy-v1.json
analysis/perspective-runtime-report-authority-v2.json
analysis/perspective-runtime-confirmation-authority-v2.json
analysis/perspective-runtime-matrix-authority-v1.json
analysis/perspective-aggregate-owner-classes-v1.json
analysis/perspective-implementation-boundary-v2.json

Reconcile them in:

analysis/documentary-contract-perspective-reconciliation-v2.json

Require:

- no disagreement;
- no open operating-model decision;
- no hidden source-implementation decision;
- no harness acceptance claim;
- exact contract identity binding.

──────────────────────────────────────────────────────────────────────────────
14. CURRENT DOCUMENTARY ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/current-governing-documentary-role-registry-v2.json

Exactly one current artifact per role.

Required roles include:

- documentary domain separation;
- aggregate owner classification;
- runtime report registry;
- runtime confirmation registry;
- runtime matrix registry;
- historical 645 disposition;
- aggregate owner/consumer registry;
- mutation matrix;
- independent validator result;
- six perspectives;
- perspective reconciliation;
- package status;
- explicit documentary confirmations.

No prior blocked artifact is current.

──────────────────────────────────────────────────────────────────────────────
15. PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/governing-documentary-contract-status-v2.json

Required status:

gen2-clean-audit-harness-governing-documentary-contract-frozen-pending-new-clean-implementation-generation

Required facts:

- documentary contract current:
  true;
- documentary domain count:
  5;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrix rows:
  15;
- runtime matrix cases:
  595;
- runtime matrices distinct domain:
  true;
- task report domain separated:
  true;
- task confirmation domain separated:
  true;
- future implementation aggregate owner class separated:
  true;
- authenticated input aggregate owner class separated:
  true;
- historical 645 writer:
  unavailable;
- exact historical writer required:
  false;
- implementation source present:
  false;
- implementation source authority:
  false;
- harness package present:
  false;
- real audit executed:
  false;
- implementation verdict issued:
  false;
- next treatment:
  NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION.

──────────────────────────────────────────────────────────────────────────────
16. SUPPLIED-INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact identity checks for:

- current authority bundle;
- current authority JSON.

If the prior documentary root was opened, repeat its complete no-follow
inventory and require exact opening/closing equality.

Do not mutate or clean supplied inputs.

──────────────────────────────────────────────────────────────────────────────
17. TERMINAL DOCUMENTARY-PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before terminal projection:

- finalize all nonclosure outputs;
- create only used directories;
- ensure `closeout/` and `manifest/` already exist;
- retain no empty descendant;
- reserve temporal and A/B paths;
- freeze directory set.

Then:

1. independently generate temporal bytes twice in memory;
2. require equality;
3. write temporal through its retained descriptor;
4. independently generate A/B;
5. require A/B equality;
6. write through retained descriptors;
7. fsync files and directories;
8. reopen no-follow;
9. verify identities;
10. independently reproject final root;
11. require root row exactly once;
12. require clean topology and modes;
13. require no cache or bytecode;
14. transition seal once;
15. emit guarded verdict and marker;
16. exit nonreturningly;
17. perform no postseal filesystem or tool operation.

──────────────────────────────────────────────────────────────────────────────
18. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process records and streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- supplied-input equality;
- terminal posture;
- same-root retry false.

Do not create success manifests on failure.

Return provenance mismatch for:

- fixed-input mismatch;
- supplied-input mutation;
- historical source use;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- input closing inequality;
- terminal-closure failure;
- postseal activity.

──────────────────────────────────────────────────────────────────────────────
19. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

only when:

- input files authenticate;
- prior blocked result authenticates;
- five-domain taxonomy freezes;
- runtime matrices occupy their own domain;
- aggregate owner classes freeze;
- exact 66 report rows freeze;
- exact 81 confirmation names freeze;
- exact 15/595 matrix registry freezes;
- historical 645 disposition closes;
- aggregate owner/consumer registry closes;
- mutation matrix passes;
- independent validator passes;
- documentary perspectives reconcile;
- current role registry closes;
- package status closes;
- supplied inputs close equal;
- documentary package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_BLOCKED

when:

- an exact registry remains ambiguous;
- an operating-model decision remains open;
- independent validation fails without provenance failure.

Return:

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_PROVENANCE_MISMATCH

for the provenance failures in Section 18.

──────────────────────────────────────────────────────────────────────────────
20. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return this exact documentary-tranche report registry:

1. Primary verdict
2. Fresh contract-root identity
3. Input-bundle identity
4. Input-authority identity
5. Prior documentary-root identity and disposition
6. Documentary authority and nonauthority
7. Corrected five-domain contract
8. Documentary domain count
9. Aggregate owner classification
10. Runtime report registry
11. Derived runtime report count
12. Runtime confirmation registry
13. Derived runtime confirmation count
14. Runtime matrix registry
15. Derived matrix count and total
16. Historical 645 disposition
17. Aggregate owner/consumer registry
18. Documentary mutation matrix
19. Independent documentary validator
20. Domain-taxonomy perspective
21. Runtime-report perspective
22. Runtime-confirmation perspective
23. Runtime-matrix perspective
24. Aggregate-owner-class perspective
25. Implementation-boundary perspective
26. Perspective reconciliation
27. Current documentary-role registry
28. Documentary package status
29. Confirmation no source was created
30. Confirmation no harness was packaged
31. Confirmation no real audit was executed
32. Supplied-input closing equality
33. Failure-closeout capability and use
34. Temporal-inventory identity
35. Manifest A identity
36. Manifest B identity
37. Terminal reprojection
38. Terminal topology and modes
39. No-write-after-closure
40. Remaining uncertainty and nonclaims
41. Explicit documentary confirmation registry

Derive this tranche report count from the exact 41 rows.

Do not compare 41 with runtime report count 66.

Freeze exactly these documentary-tranche confirmation names:

CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
PRIOR_DOCUMENTARY_BLOCKED_RESULT_AUTHENTICATED
NO_IMPLEMENTATION_SOURCE_CREATED
NO_HARNESS_PACKAGE_CREATED
NO_REAL_AUDIT_EXECUTED
FIVE_DOCUMENTARY_DOMAINS_FROZEN
DOCUMENTARY_DOMAIN_COUNT_FIVE_DERIVED
HARNESS_RUNTIME_MATRIX_DOMAIN_FROZEN
RUNTIME_REPORT_REGISTRY_EXACT
RUNTIME_REPORT_ROW_COUNT_66_DERIVED
RUNTIME_CONFIRMATION_REGISTRY_EXACT
RUNTIME_CONFIRMATION_NAME_COUNT_81_DERIVED
PRIMARY_VERDICT_SEPARATE_FROM_RUNTIME_CONFIRMATIONS
RUNTIME_MATRIX_REGISTRY_EXACT
RUNTIME_MATRIX_COUNT_15_DERIVED
RUNTIME_MATRIX_CASE_TOTAL_595_DERIVED
STALE_MATRIX_TOTAL_645_REJECTED
HISTORICAL_645_WRITER_UNAVAILABLE
HISTORICAL_645_WRITER_UNAVAILABILITY_NONBLOCKING
AGGREGATE_OWNER_CLASSES_FROZEN
ONE_AUTHORITATIVE_OWNER_PER_AGGREGATE
TASK_REPORT_DOMAIN_NOT_USED_AS_RUNTIME_AUTHORITY
TASK_CONFIRMATION_DOMAIN_NOT_USED_AS_RUNTIME_AUTHORITY
FUTURE_IMPLEMENTATION_REGISTRY_NOT_A_DOCUMENTARY_DOMAIN
AUTHENTICATED_INPUT_NOT_A_DOCUMENTARY_DOMAIN
DOCUMENTARY_DOMAIN_AND_AGGREGATE_MATRIX_PASSED
INDEPENDENT_DOCUMENTARY_VALIDATOR_PASSED
SIX_DOCUMENTARY_PERSPECTIVES_RECONCILED
NO_OPEN_OPERATING_MODEL_DECISION
CURRENT_DOCUMENTARY_ROLE_REGISTRY_COMPLETE
DOCUMENTARY_PACKAGE_STATUS_CURRENT
IMPLEMENTATION_SOURCE_AUTHORITY_FALSE
NEXT_TREATMENT_NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED
PRIOR_DOCUMENTARY_ROOT_CLOSING_EQUALITY_PASSED
DOCUMENTARY_TEMPORAL_INVENTORY_CREATED
DOCUMENTARY_TEMPORAL_INVENTORY_VERIFIED
DOCUMENTARY_MANIFEST_A_CREATED
DOCUMENTARY_MANIFEST_B_CREATED
DOCUMENTARY_MANIFESTS_BYTE_IDENTICAL
DOCUMENTARY_TERMINAL_REPROJECTION_PASSED
DOCUMENTARY_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

Derive the documentary-tranche confirmation count from this exact name set.

Do not compare it with runtime confirmation count 81.

After:

GEN2_CLEAN_AUDIT_HARNESS_GOVERNING_DOCUMENTARY_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

the next tranche is a new clean harness implementation generation governed by
this exact documentary package.

Do not classify it as Attempt 3 of the retired implementation.

Do not combine documentary freezing with source implementation.
```

### Sources

The report identifies the sole blocker as the missing `HARNESS_RUNTIME_MATRICES` domain in an otherwise closed four-domain taxonomy. :chatgpt-content-reference{index="5"}

The exact substantive registries are already coherent: 66 runtime report rows, 81 runtime confirmation names, and 15 matrices totaling 595 cases. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

No implementation or validator source was created, no harness was packaged, no real audit ran, and supplied inputs closed equal. :chatgpt-content-reference{index="8"}

**Confidence:** 0.999 that no implementation-package or input-provenance defect was established; 0.999 that the correct immediate repair is adding `HARNESS_RUNTIME_MATRICES` as a fifth domain; 0.99 that separating future implementation and input aggregates through `owner_class` prevents another domain-taxonomy failure; 0.98 that a successfully sealed documentary package should be followed by a new clean harness implementation generation rather than another repair of the retired source lineage.
