## Assessment

The FD-exec branch is conclusively closed for this host. Python documents open-file-descriptor execution as platform-dependent and discoverable through `os.supports_fd`; the pinned interpreter reported it unsupported and rejected the integer descriptor.  Apple’s documented `execve` and `posix_spawn` interfaces are pathname-based, so there is no supported standard-library mechanism here that atomically executes the already-hashed interpreter object. 

**Do not proceed to `/dev/fd`, `ctypes`, undocumented Mach tricks, a compiled launcher, or another recursive custody layer.** That would turn a bounded proof helper into a new security product and trust framework. The MVP freeze explicitly says this planning slice must not promote proof-harness behavior into architecture or make generated evidence authoritative; proof-only runners and helper mechanisms are not product runtime guarantees.  

The remaining issue is not “find one more clever exec mechanism.” It is **terminate the root of trust honestly**.

### Strategic decision

Freeze this bounded threat model:

- The operator-controlled validation host, kernel, already-running foreground execution substrate, pinned Python installation path, and every principal permitted to modify that installation are part of the trusted validation boundary.
- The source-external caller must verify the interpreter path, its ancestors, metadata, size, and SHA-256 before launch and reobserve them after child completion.
- Any **observed** interpreter drift, symlink, identity mismatch, unsupported capability, or security-posture uncertainty blocks validation.
- The tool does **not** claim atomic identity between the preflighted file and the executable object loaded by the kernel.
- Transient replacement by a malicious process already holding the trusted operator identity, admin-group authority, root authority, debugger access, kernel control, or process-memory access is outside this bounded local-proof threat model.
- On a shared or adversarial host, this validation posture is unsupported.
- Source-by-value launch protocol v2 remains valuable: it prevents the evidence target or a raced script pathname from choosing the verifier source. The accepted host assumption applies only to the already trusted Python runtime used to execute that source.
- A verifier pass remains structural evidence, never readiness or execution authority.

This is an **accepted bounded-proof precondition**, not a claim of cryptographic measured boot. It must be explicit in `PLANS.md` and the governing evidence-verification documents before a new audit. Provenance still only proves that implementation and audit addressed the same bytes; it does not prove correctness or authority. 

My earlier recommendation to probe FD execution was worth one finite check. The result is decisive; continuing along that line would now be architecture-by-ceremony.

## Codex prompt: trusted-host boundary repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete implementation report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a report;
- “full report available at …”;
- or an attachment reference.

A source-external report may be linked as supplemental evidence, but every
required report section must also appear inline.

This applies to success, baseline mismatch, scope expansion, validation block,
provenance block, and process-boundary block.

Objective

Repair the Evidence Verification v1 contract and validation evidence to state
the bounded trusted-host interpreter assumption honestly.

Do not attempt another executable-object custody mechanism.

The previous bounded probe established:

- the pinned Python 3.13.4 reports `os.execve` absent from `os.supports_fd`;
- passing the open interpreter descriptor to `os.execve` raises TypeError;
- no FD-bound caller was created;
- repository provenance remained unchanged.

The project decision is now frozen:

THE VALIDATION HOST AND PINNED INTERPRETER INSTALLATION ARE PART OF THE
BOUNDED TRUSTED COMPUTING BASE.

The verifier does not claim atomic proof that the executable object loaded by
the kernel is the exact object preflighted by the caller.

This is an explicit bounded local-proof threat model, not production host
attestation.

Implement only the contract, tests, and source-external validation evidence
needed to make that boundary exact and auditable.

Do not redesign launch protocol v2.
Do not alter verifier closure semantics.
Do not add a launcher.
Do not add FD exec, `/dev/fd`, ctypes, native code, code-signing APIs, a copied
interpreter, a privileged helper, or a recursive attestation layer.

No subagents. The parent is the sole writer.

No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

## 1. Repository and exact opening target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Current canonical manifest:

OPENING_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/provenance/qualified/provenance/manifest-run-1.json

Expected opening manifest SHA-256:

ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98

Expected opening tracked binary-diff SHA-256:

6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7

Expected verifier:

- size 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected tests:

- size 70730
- SHA-256:
  7e2dcf579c5e4bf3fd72762662e3a66f96668af1470be00a665e893a9efa15a1

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Source-by-value producer caller, read-only predecessor:

OLD_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/commands/launch_v2.py

Expected old-caller SHA-256:

856cc81650330deb776cbf9bff74644176405acf3163839547acfce3d73ba1e2

FD-exec capability evidence, read-only:

FDEXEC_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-fdexec-caller-ed26813371b3

Expected FD probe source SHA-256:

3f9942247701c84a71e431a428f517a31102347d221aa7cf67257d8be801c195

Expected FD probe record SHA-256:

2215d45eff7f6c808bbd3e54b2cc77f3d9f414a492d565e7600fbf2da54042c1

Blocking independent audit, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-ed26813371b3-v1

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4
- regular single-link file at opening
- size 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

New implementation evidence root:

TRUST_REPAIR=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3

Require TRUST_REPAIR absent before creation.

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and process boundary

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - GIT_OPTIONAL_LOCKS=0;
  - GIT_CONFIG_NOSYSTEM=1;
  - LC_ALL=C;
  - LANG=C;
  - PYTHONDONTWRITEBYTECODE=1;
- be retained with exact argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in PRIMARY_R or an evidence/audit root.

Non-Git absolute-path reads are permitted from another inherited cwd.
No repository-relative operand may resolve through PRIMARY_R.

A nonconforming Git call is an immediate process-boundary block.

## 3. Opening provenance gate

Require IMPL_R:

- exact physical root;
- expected branch, HEAD, tree, parent, and absent upstream;
- exactly 13 patch paths;
- four modified tracked and nine untracked;
- every path regular, single-link, working mode 0644, logical mode 100644;
- zero staged, deleted, renamed, or unmerged;
- no extra path;
- no Git operation marker or lock.

Open OPENING_MANIFEST and RECIPE with stable no-follow reads.

Require:

- exact manifest and recipe hashes;
- every manifest row equals live bytes;
- exact tracked binary diff;
- exact verifier and test identities;
- exact registry/layout/historical-fixture identities;
- OLD_CALLER present and exact;
- FDEXEC_EVIDENCE present and exact;
- BLOCKING_AUDIT present and stable;
- A6D and A6D_AMEND manifests exact.

Run RECIPE twice into fresh external paths beneath TRUST_REPAIR/opening only
after TRUST_REPAIR is created.

Require both outputs byte-identical to OPENING_MANIFEST.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_BASELINE_MISMATCH

## 4. New evidence root

After opening identity succeeds, create TRUST_REPAIR under umask 077:

opening/
decision/
commands/
validation/
provenance/
closeout/
tmp/

Directories must be 0700.
Retained files must be regular, single-link, mode 0600 unless explicitly
classified otherwise.

Do not overwrite any earlier evidence root.

## 5. Frozen threat model

Record the following as the authoritative implementation decision.

### Trusted boundary

For this bounded, supported-local validation proof, trust includes:

- the operator-controlled host;
- the host kernel and process execution substrate;
- the already-running foreground validation process;
- the exact pinned Python installation path and its path ancestors;
- every local principal permitted to modify that interpreter installation;
- the externally supplied repository and provenance inputs.

### Untrusted inputs

Treat as untrusted:

- evidence target contents;
- pre-seal manifest candidates;
- target-controlled script paths;
- registry/layout substitutions not matching external provenance;
- verifier package changes not matching external provenance;
- caller arguments and environment not matching the closed launch contract.

### Out-of-scope attacks and nonclaims

Explicitly do not claim resistance to:

- transient interpreter replacement by a malicious process already holding a
  trusted operator UID, admin-group write authority, or root authority;
- kernel compromise;
- debugger/process-memory compromise;
- compromised Codex execution substrate;
- compromised pinned Python runtime;
- privileged filesystem identity forgery;
- cryptographic collision.

A shared, multi-user, adversarial, or remotely administered validation host is
not supported by this posture.

The proof is supported-local evidence only, not production host attestation.

## 6. Exact repository scope

This repair may modify at most:

1. `PLANS.md`
2. `.docs/system_overview/evidence_verification.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `tools/evidence_verify/test_verify_v1.py`

Modify the test file only when needed to enforce the documentary contract or
prevent a false interpreter-custody claim.

Keep byte-identical:

- `.docs/system_overview/boundaries.md`
- `tools/evidence_verify/verify_v1.py`
- `tools/evidence_verify/registry_v1.json`
- all three layouts
- both historical fixtures.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No product/public schema.
No runtime route.
No shared package.

If verifier source or a sixth repository path is required, stop:

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_SCOPE_EXPANSION_REQUIRED

## 7. Documentation requirements

### PLANS.md

Record:

- FD-bound exec was behaviorally unavailable on the pinned macOS/Python host;
- no `/dev/fd`, ctypes, native-launcher, copied-interpreter, or recursive
  attestation fallback is authorized;
- the host/interpreter installation is an explicit trusted precondition;
- launch protocol v2 remains the verifier-source custody mechanism;
- interpreter opening/closing identity is corroboration, not atomic
  executed-object proof;
- the accepted risk and unsupported-host conditions;
- fresh audit required before commit.

Classify this as a bounded proof-contract refinement, not a product or runtime
seam.

### evidence_verification.md

Define normatively:

- exact trusted-host boundary;
- exact unsupported threat classes;
- source-by-value verifier trust split;
- interpreter path preflight and closing observation;
- no claim of loaded-executable-object identity;
- no claim against transient trusted-principal replacement;
- direct-script remains nonqualifying;
- verifier output remains structural evidence only;
- callers and auditors must not label the interpreter observation as
  cryptographic or atomic custody.

### artifact_hygiene.md

State:

- interpreter identity observations are source-external evidence;
- they do not become run truth or readiness authority;
- the local interpreter installation is a supported-local proof precondition;
- proof records must carry the nonclaim;
- no raw source text or sensitive paths enter shared reports.

### capability_probing.md

State:

- FD `execve` support is behaviorally probed and unavailable on this host;
- unsupported FD execution is a capability result, not permission to add an
  undocumented fallback;
- pathname launch is admitted only under the frozen trusted-host assumption;
- opening/closing identity drift, symlink, hash mismatch, or security-posture
  uncertainty remains fail-closed;
- inability to establish the trusted-host precondition blocks validation.

## 8. Verifier source disposition

`tools/evidence_verify/verify_v1.py` must remain byte-identical.

Launch protocol v2 and source-by-value behavior remain unchanged.

The verifier is not responsible for interpreter attestation.

Do not weaken:

- package/source exact-byte consistency;
- target/package/candidate disjointness;
- direct-script/stdin/FD nonqualification;
- registry/layout binding;
- no-write behavior;
- canonical failure output.

## 9. Test disposition

Preserve all 88 existing tests and their identities unless a documentary
contract assertion requires a narrowly documented addition.

Add or update only tests needed to prove:

1. governing docs explicitly name the trusted-host/interpreter assumption;
2. governing docs explicitly disclaim atomic loaded-interpreter identity;
3. governing docs classify concurrent trusted-principal replacement as outside
   the bounded threat model;
4. governing docs prohibit undocumented FD/native/copy fallbacks;
5. caller-side opening/closing identity is described as corroboration;
6. no test or caption claims FD-exec support;
7. no test or caption claims atomic interpreter custody;
8. verifier source hash remains unchanged;
9. all existing launch-protocol-v2 causals remain unchanged.

Do not encode “perfect interpreter custody” as a test expectation.

## 10. Source-external caller evidence revision

Create a new source-external validation caller under:

TRUST_REPAIR/commands/

It may derive from OLD_CALLER but must have a new exact identity.

Classification:

source-external validation/provenance evidence

It must retain current source-by-value behavior and:

- no-follow inspect the interpreter path and ancestors;
- record owner, group, mode, type, link count, device/inode, size, SHA-256, and
  ancestor symlink posture at opening;
- record the same safe observations after child reap;
- fail on observed mismatch, symlink, wrong hash/size, or unsupported path
  posture;
- state explicitly in its private record:
  - `interpreter_trust_model = "trusted-host-stable-path-v1"`
  - `atomic_loaded_object_binding = false`
  - `transient_trusted_principal_replacement_covered = false`
  - `shared_or_adversarial_host_supported = false`
- never represent these observations as source authentication or readiness;
- use no shell;
- retain launch protocol v2;
- retain source-by-value verifier source;
- print no source text or sensitive path in canonical verifier output.

Suggested private record schema:

`execution-substrate.evidence-closure-launch-record.v3`

The caller record itself remains evidence/projection only.

## 11. Validation

Run fresh validation against final bytes.

### Static gates

- parse verifier, tests, and new external caller with `ast.parse`;
- parse historical `.py.txt` files without executing them;
- strict-parse registry and three layouts;
- require registry/layout/historical fixtures and verifier source unchanged;
- verify documentation contract;
- run rooted `git diff --check`.

### Repository tests

Discover the complete final test set.

Run the complete suite:

- twice under umask 077;
- twice under umask 022.

Require every owning command:

- exit 0;
- all discovered tests pass;
- zero failure/error/skip;
- identical test set;
- no repository artifact.

### Caller and threat-boundary causals

At minimum:

1. Expected interpreter path and security posture passes.
2. Wrong interpreter hash blocks.
3. Wrong interpreter size blocks.
4. Interpreter final symlink blocks.
5. Interpreter ancestor symlink blocks.
6. Opening/closing identity change blocks.
7. Opening/closing mode or ownership change blocks.
8. Unsupported or ambiguous metadata capability blocks.
9. Private record contains all four mandatory nonclaim fields.
10. Shared/adversarial-host mode is rejected.
11. No record claims atomic loaded-object identity.
12. No FD-exec, `/dev/fd`, ctypes, native, or copied-interpreter fallback exists.
13. Source-by-value SEC-02 target marker remains unexecuted.
14. Direct script/stdin/FD verifier launch remains nonqualifying.
15. Registry/layout returned-hash mismatch remains caller-rejected.

Do not construct a hidden transient-swap “pass” test and then claim resistance.
That attack is explicitly outside the selected threat model.

### Compatibility

Using the final external caller:

- sealed A6D twice;
- sealed amendment twice;
- synthetic A6 pre-seal twice;
- seal only the private synthetic fixture;
- synthetic A6 sealed twice.

Require deterministic canonical output, empty stderr, expected output hashes,
and unchanged snapshots.

## 12. Required no-write and artifact checks

Snapshot before and after every verifier invocation:

- target;
- package;
- candidate when applicable;
- private TMPDIR;
- caller evidence root excluding the intended new record.

Require no verifier mutation.

Scan IMPL_R for caches, bytecode, generated manifests, databases, journals,
locks, fixtures, build output, unexpected modes, and unsupported types.

Remove only TRUST_REPAIR-owned temporary artifacts.

## 13. Provenance

After all validation passes, run the exact unchanged RECIPE twice against
IMPL_R into fresh TRUST_REPAIR/provenance paths.

Require:

- both exits 0;
- empty stderr;
- byte-identical canonical manifests;
- same 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- no unsupported object;
- no extra path.

Retain:

- exact recipe source;
- new canonical-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities;
- final docs and test hashes;
- unchanged verifier hash;
- external caller source and hash;
- validation index;
- failed/superseded index;
- threat-model decision record.

## 14. Closing gate

Require:

- branch, HEAD, tree, parent, and upstream unchanged;
- exact expected 13-path scope;
- zero staged/deleted/renamed/unmerged;
- no repository artifact;
- `verify_v1.py`, registry, layouts, historical fixtures, and boundaries bytes
  unchanged;
- A6D and amendment unchanged;
- FDEXEC_EVIDENCE and BLOCKING_AUDIT unchanged;
- all private fixtures removed;
- no surviving child process or descriptor;
- no network/product operation.

## 15. Mandatory stops

Stop if:

- opening provenance differs;
- verifier source must change;
- a sixth repository file is needed;
- a fourteenth patch path is needed;
- registry/layout/output schema must change;
- docs imply atomic interpreter-object custody;
- validation tries to hide or “close” the explicitly out-of-scope transient
  trusted-principal race;
- a fallback launcher mechanism is introduced;
- source-by-value SEC-02 protection regresses;
- real or synthetic compatibility fails;
- repository or supplied evidence mutates;
- final provenance is unstable.

Verdicts:

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_SCOPE_EXPANSION_REQUIRED

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_VALIDATION_BLOCKED

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_INTERPRETER_TRUST_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

## 16. Complete inline report

Include inline:

1. Verdict.
2. Response-format confirmation.
3. Opening repository and provenance.
4. FD-exec capability disposition.
5. Strategic trusted-host decision.
6. Exact threat model.
7. Exact accepted risk.
8. Exact unsupported environments.
9. Exact repository touched files.
10. Verifier-source no-change confirmation.
11. Documentation changes.
12. Test changes.
13. External caller source, size, and SHA-256.
14. Caller record schema and mandatory nonclaims.
15. Complete test identities and count.
16. Both umask-077 results.
17. Both umask-022 results.
18. Every caller/threat-boundary causal.
19. SEC-02 source-by-value result.
20. A6D results.
21. Amendment results.
22. Synthetic results.
23. No-write evidence.
24. Final verifier hash confirming unchanged bytes.
25. Registry/layout/historical-fixture hashes.
26. Exact final 13-path manifest.
27. Provenance recipe identity.
28. New tracked binary-diff SHA-256.
29. New canonical-manifest SHA-256.
30. Evidence inventory and cleanup.
31. Authority/non-authority adjudication.
32. Remaining uncertainty and explicit nonclaims.
33. Confirmation:
    - prior audit no longer qualifies changed documentation/test bytes;
    - fresh audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
```

## Next gate

A successful repair needs one fresh independent audit of the new exact manifest. That audit should evaluate whether the trusted-host boundary is:

- explicit;
- internally consistent;
- appropriate for a supported-local bounded proof;
- not misrepresented as production host attestation;
- not used to promote launch evidence into authority.

It should **not** reintroduce atomic child-interpreter custody as an unstated acceptance condition. Any later desire for hostile local-admin resistance is a separate hardening or deployment architecture decision, not another hidden requirement on this proof tool.

### Sources

- Codex’s complete inline FD-exec capability report supplied in this turn.
- Python’s official documentation states that file-descriptor `execve` support is platform-dependent and detectable through `os.supports_fd`; unsupported platforms reject it. 
- Apple’s documented `execve` and `posix_spawn` interfaces are pathname-based. 
- The MVP freeze prohibits proof-harness behavior and generated evidence from silently becoming architecture or authority. 
- The current MVP explicitly does not promote proof-only runners or helper behavior into product guarantees. 
- Provenance is an evidence mechanism, not correctness, authority, or runtime truth. 
- An audit block returns work to bounded repair and requires new validation, provenance, and a fresh audit. 

**Confidence**

- FD-exec capability branch is closed on this host: **0.999**
- Further launcher escalation would be disproportionate: **0.97**
- Trusted-host boundary is the correct architectural termination point: **0.94**
- Need for explicit docs/evidence repair before audit: **0.98**
- Repository verifier source should remain unchanged: **0.99**
