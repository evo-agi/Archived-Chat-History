## Engineering assessment

This is the first recent failure that reflects a **real change to every current fixed-input root**, rather than another parser, path, or lifecycle-model defect.

Each of the eight current roots—and the prior verifier root—now contains one unregistered, mode-`0644` `.DS_Store`. Their fixed root identities and all designated closure-file identities still match, but each physical path count is exactly one above its sealed count. The unexpected file has a different hash in each root. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

That establishes three things:

1. The roots were modified after sealing by an actor outside this task.
2. The original whole-directory closure assertions no longer describe their current live namespaces.
3. The failure is not evidence that the manifest-covered semantic files changed. The task confirmed the fixed closure records remained exact and all roots stayed unchanged during this run. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"}

The `.DS_Store` files are **incidental macOS metadata contamination**. They are not product artifacts, governing evidence, or implementation defects. But they also cannot be silently ignored: permitting arbitrary unmanifested files would destroy the meaning of exact capsule closure.

Deleting the files in place is not the right repair:

- it would mutate historical roots;
- it would not restore original directory modification metadata;
- the files could reappear;
- it would preserve dependence on mutable directory capsules in `Downloads`.

Whitelisting `.DS_Store` in the verifier is also the wrong repair. That would weaken every current package’s closure contract merely to accommodate an environmental contaminant.

Nothing from the verifier implementation tranche was consumed. No source was created, compilation never began, and both source attempts remain unused. The three-profile model was not evaluated. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

### Progression decision

Stop treating the live directory roots as current physical authority.

Create a **deterministic, content-addressed current-authority snapshot bundle** from the manifest-authenticated members of the seven sealed packages and the explicitly bound Attempt-2 failure evidence. The bundle must:

- authenticate every copied regular-file byte through the original package’s manifest or an exact current binding;
- exclude `.DS_Store` and retain its identity only as contamination evidence;
- preserve the original manifests and temporal records as historical evidence;
- carry a typed index that distinguishes sealed-package snapshots from the bounded failure-evidence subset;
- use a single deterministic archive file as the future fixed input;
- make the archive’s exact path, size, and SHA-256—not its containing directory—the authority boundary.

This converts mutable Finder-exposed directories into one file-level, content-addressed input. The future closure verifier and clean audit harness should consume that archive without reopening the contaminated roots.

```text
CREATE A DETERMINISTIC CONTENT-ADDRESSED CURRENT-AUTHORITY
SNAPSHOT BUNDLE FROM THE CONTAMINATED GENERATION-2 INPUT ROOTS

Objective

Create one deterministic, content-addressed, single-file snapshot bundle
containing the exact manifest-authenticated bytes required by the future
current-authority verifier and clean source-external independent-audit harness.

The live supplied directory roots have been contaminated after sealing by
unregistered macOS `.DS_Store` files.

Do not repair, clean, delete from, rename within, reseal, or otherwise mutate
any supplied root.

Do not declare any contaminated live root currently terminally sealed.

Do not whitelist `.DS_Store` as part of an original package grammar.

Do not implement the closure verifier.

Do not implement the independent-audit harness.

Do not adjudicate the Generation-2 reconstruction-parent implementation.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

The output authority must be exact file-level identities:

- one deterministic uncompressed ZIP archive;
- one external authority JSON file identifying that archive.

The containing output directory is not authority-bearing and need not have a
closed path set.

A later task will consume the archive and authority JSON directly without
reopening the contaminated roots.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned build and qualification process in one fresh
private working root.

At most two complete builder-source attempts are permitted.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

GEN2_CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_BUILD_BLOCKED

CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT INPUT ROLES
──────────────────────────────────────────────────────────────────────────────

Open exactly the eight roles below.

Seven roles are `sealed_package_snapshot`.

One role is `failure_evidence_subset`.

Do not open any retired or failed audit-harness or verifier root.

A. TERMINAL_FINDINGS_RECONCILIATION

Role ID:
terminal-findings-reconciliation

Root:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected root identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700

Role class:

sealed_package_snapshot

Exact temporal path:

closeout/temporal-final-inventory-v1.json

Exact manifest paths:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

B. SEALED IMPLEMENTATION PACKAGE

Role ID:
gen2-implementation-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected root identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

C. CURRENT GENERATION-2 SUCCESSOR

Role ID:
gen2-successor-contract-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected root identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

D. AUTHORITATIVE NORMATIVE-CONTRACT PACKAGE

Role ID:
normative-contract-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected root identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v2.json
manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

Expected temporal identity:

- size:
  17739
- SHA-256:
  e65b511f4c6fb69be9a14a4702ee32d2e1b670db04f4058b398fcf36d662f0f1

Expected manifest identity:

- size:
  17596
- SHA-256:
  a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

E. CURRENT SCHEMA PACKAGE

Role ID:
current-schema-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected root identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

F. SCHEMA RECONCILIATION CAPSULE

Role ID:
schema-reconciliation-capsule

Root:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected root identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

G. CURRENT VALIDATION-SPECIFICATION PACKAGE

Role ID:
current-validation-specification-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected root identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Role class:

sealed_package_snapshot

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

H. CURRENT ATTEMPT-2 FAILURE EVIDENCE

Role ID:
attempt-2-failure-evidence

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected root identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Role class:

failure_evidence_subset

Expected failure outcome:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Resolve the exact failure-outcome path and every additional required evidence
path only through the sealed implementation package’s current Attempt-2
binding and authenticated inventory records.

No basename, recursive path, inode, size, hash, first-match, latest, or scoring
selection is allowed.

──────────────────────────────────────────────────────────────────────────────
2. EXCLUDED ROOTS
──────────────────────────────────────────────────────────────────────────────

Do not open any audit-harness or verifier root, including all retired, blocked,
or failed roots from earlier tranches.

Retain:

opening/excluded-root-registry-v1.json

For each excluded path record:

- fixed_input:
  false;
- opened:
  false;
- inventoried:
  false;
- source_read:
  false;
- authority:
  none.

No historical harness or verifier source may be copied, imported, executed,
translated, or used as an AST or bytecode origin.

──────────────────────────────────────────────────────────────────────────────
3. FRESH WORKING ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private working root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-current-authority-snapshot-bundle-build-

Immediately emit:

BUNDLE_BUILD_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json
opening/snapshot-bundle-authority-v1.json
opening/fixed-input-registry-v1.json
opening/excluded-root-registry-v1.json
opening/process-execution-policy-v1.json

Authority is limited to:

- supplied-root read-only authentication;
- manifest-scoped member extraction;
- bounded Attempt-2 evidence extraction;
- contamination adjudication;
- deterministic archive construction;
- archive qualification;
- supplied-root closing equality;
- build-root cleanup or failure closeout.

Nonauthority includes:

- declaring live roots currently sealed;
- repairing supplied roots;
- deleting `.DS_Store`;
- implementation adjudication;
- audit-harness implementation;
- verifier implementation;
- implementation production execution;
- current-subject construction;
- product/runtime/target/repository activity;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
4. CONTAMINATION CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

For each current supplied root perform one complete no-follow traversal.

Classify every path as exactly one:

- MANIFEST_AUTHENTICATED_MEMBER;
- CLOSURE_RECORD;
- AUTHENTICATED_FAILURE_EVIDENCE;
- INCIDENTAL_OS_METADATA_CONTAMINATION;
- UNKNOWN_OR_FORBIDDEN.

The only permitted incidental path is:

.DS_Store

at the supplied root’s top level.

When present it must be:

- exactly one path;
- root-relative path exactly `.DS_Store`;
- regular file;
- not symlink;
- not hard linked;
- mode `0644`;
- not referenced by a temporal inventory, manifest, current registry, binding,
  confirmation, or evidence record.

Retain its:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256;
- mtime_ns;
- ctime_ns.

Classification:

FORBIDDEN_INCIDENTAL_OS_METADATA_CONTAMINATION

Disposition:

- record identity;
- do not copy bytes;
- do not delete;
- do not mutate;
- do not treat as current package content;
- do not weaken original package closure rules.

Acceptable current extra-path sets are only:

- empty set; or
- `{".DS_Store"}`.

Any other unregistered path is:

CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

Retain:

analysis/current-root-contamination-ledger-v1.json

──────────────────────────────────────────────────────────────────────────────
5. SEALED-PACKAGE SNAPSHOT AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

For every `sealed_package_snapshot` role:

1. Authenticate exact root identity.
2. Authenticate temporal file identity.
3. Authenticate manifest A identity.
4. Authenticate manifest B identity.
5. Require A/B byte equality.
6. Strict-parse with duplicate-key rejection.
7. Recover the exact root-owned manifest grammar.
8. Recover the exact represented member set.
9. Perform a complete live no-follow traversal.
10. Require every represented regular file:
    - present;
    - regular;
    - single-link unless its grammar explicitly says otherwise;
    - exact mode;
    - exact size;
    - exact SHA-256;
    - exact stable metadata owned by the grammar.
11. Require every represented directory:
    - present;
    - directory;
    - exact stable identity fields owned by the grammar.
12. Require no represented symlink or special object.
13. Require no missing represented path.
14. Require no duplicate represented path.
15. Require the only unrepresented live paths to be:
    - manifest A;
    - manifest B;
    - optional root-level `.DS_Store`.

Directory contamination exception:

When root-level `.DS_Store` exists, only the supplied root directory’s
contamination-sensitive fields may differ from its historical manifest row:

- directory size;
- mtime_ns or root-owned modification-time field;
- ctime_ns when the grammar owns it.

No difference is allowed in:

- path;
- type/kind;
- device;
- inode;
- mode;
- uid;
- gid;
- any non-root directory;
- any regular file;
- any other field.

Retain the original manifest row and live row separately.

Do not rewrite either.

Required classification when all tests pass:

MANIFEST_SCOPED_SEMANTIC_SNAPSHOT_RECOVERABLE

This does not mean the live directory root remains terminally sealed.

Retain one record per role:

analysis/roles/<role-id>-manifest-scoped-snapshot-authentication-v1.json

──────────────────────────────────────────────────────────────────────────────
6. ATTEMPT-2 FAILURE-EVIDENCE EXTRACTION
──────────────────────────────────────────────────────────────────────────────

For `attempt-2-failure-evidence`:

1. Authenticate the implementation package’s exact current Attempt-2 binding.
2. Resolve:
   - failure root path;
   - failure outcome path;
   - failure outcome identity;
   - any current complete-inventory record;
   - every additional evidence path expressly required by the binding.
3. Authenticate the failure root identity.
4. Authenticate the failure outcome exactly.
5. Require current live extras to be empty or only root-level `.DS_Store`.
6. Do not require success temporal or manifest closure.
7. Do not copy unbound paths.
8. Do not infer the full failure-root namespace without an authenticated
   inventory.

If an authenticated complete inventory exists:

- authenticate every listed regular file;
- include its listed regular files and evidence records in the snapshot.

If no authenticated complete inventory exists:

- include only:
  - the exact implementation-package binding record;
  - the exact failure outcome;
  - the exact records explicitly named by that binding;
- classify the role as:
  BOUNDED_FAILURE_EVIDENCE_SUBSET;
- do not claim a complete failure-root snapshot.

Retain:

analysis/attempt-2-failure-evidence-extraction-v1.json

──────────────────────────────────────────────────────────────────────────────
7. SNAPSHOT MEMBER NAMESPACE
──────────────────────────────────────────────────────────────────────────────

Use archive member prefixes:

bundle/index.json
bundle/build-provenance.json
bundle/contamination-ledger.json
bundle/role-registry.json
roles/<role-id>/root-authority.json
roles/<role-id>/original-temporal/<basename>
roles/<role-id>/original-manifests/<basename>
roles/<role-id>/files/<original-relative-path>
roles/attempt-2-failure-evidence/bindings/<relative-path>
roles/attempt-2-failure-evidence/evidence/<relative-path>
validation/<validation-records>
report/operative-report.json

Rules:

- no absolute archive member path;
- no leading slash;
- no `..`;
- no empty segment;
- no duplicate member name;
- UTF-8 paths only;
- no symlink member;
- no hard-link member;
- no device or special member;
- `.DS_Store` must not be an archive member;
- original absolute paths may appear only as JSON string data;
- every payload member must be owned by exactly one role.

──────────────────────────────────────────────────────────────────────────────
8. BUNDLE INDEX
──────────────────────────────────────────────────────────────────────────────

Generate:

bundle/index.json

The index must contain:

- schema;
- bundle ID;
- format version;
- creation authority;
- current-authority role count:
  8;
- seven sealed-package snapshot rows;
- one bounded failure-evidence row;
- original root paths and identities;
- original closure-file identities;
- original manifest schemas;
- contamination classification per role;
- member count;
- member registry;
- for every member:
  - archive path;
  - owning role;
  - source root;
  - original relative path;
  - source authority path;
  - kind;
  - original mode;
  - original size;
  - original SHA-256;
  - archive storage method;
- omitted contamination rows;
- excluded historical-root registry;
- claim limits;
- implementation verdict:
  not issued;
- package verdict:
  not issued;
- future permitted use:
  fixed read-only current-authority evidence input.

No archive self-hash may be stored inside the archive.

The external authority JSON will bind the final archive hash.

──────────────────────────────────────────────────────────────────────────────
9. DETERMINISTIC ZIP FORMAT
──────────────────────────────────────────────────────────────────────────────

Create an uncompressed deterministic ZIP using Python standard library only.

Required format:

- `ZIP_STORED`;
- members sorted by raw UTF-8 member-name bytes;
- fixed timestamp:
  1980-01-01T00:00:00;
- `create_system = 3`;
- no archive comment;
- no member comments;
- no uncontrolled extra fields;
- no data descriptors when avoidable;
- fixed member permissions:
  - JSON and copied regular files:
    `0600`;
- no directory members unless indispensable;
- no symlink or special-file attributes;
- UTF-8 names;
- no duplicate names.

Build the final archive independently twice:

- Build A;
- Build B.

Require byte-identical output.

Retain:

validation/deterministic-bundle-build-comparison-v1.json

A and B must have the same:

- size;
- SHA-256;
- member count;
- central-directory order;
- member CRCs;
- member sizes;
- member bytes.

Only after equality may one copy become the final archive.

──────────────────────────────────────────────────────────────────────────────
10. FINAL OUTPUT FILES
──────────────────────────────────────────────────────────────────────────────

The final outputs are exact files, not a directory closure.

Create in a fresh private output directory:

current-authority-snapshot-bundle-v1.zip
current-authority-snapshot-bundle-v1.authority.json

Set both files to mode `0400` after final verification.

The containing directory is nonauthoritative.

The authority JSON must contain:

- schema;
- bundle ID;
- archive absolute path;
- archive file identity:
  - device;
  - inode;
  - mode;
  - link count;
  - size;
  - SHA-256;
- ZIP format;
- archive member count;
- archive index-member identity;
- role count:
  8;
- sealed-package role count:
  7;
- failure-evidence role count:
  1;
- contamination rows:
  8;
- `.DS_Store` members included:
  0;
- deterministic Build-A identity;
- deterministic Build-B identity;
- Build-A/B byte equality:
  true;
- independent archive validation:
  passed;
- supplied roots mutated:
  false;
- current implementation adjudicated:
  false;
- clean audit harness implemented:
  false;
- full audit executed:
  false;
- current schema subject constructed:
  false.

The future authority boundary is:

exact authority-JSON bytes
+
exact archive bytes

not the containing directory’s member set or metadata.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete builder-source attempts.

An attempt begins only when:

- final builder-source registry closes;
- final independent-validator registry closes;
- compilation begins.

Any source change after compilation begins creates a new attempt.

If Attempt 2 fails, stop.

Do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
12. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every builder and validator source under pinned Python using:

-I -S -B

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- process-launch crosswalk;
- supplied-root operation crosswalk;
- archive-member writer crosswalk;
- terminal output crosswalk.

Require:

- finite flow;
- no stdin read;
- no persistent supervisor;
- every child through one recorder;
- no shell;
- no PATH executable lookup;
- no Git/VCS;
- no network;
- no broad Downloads scan;
- no excluded-root access;
- supplied roots read-only;
- no deletion from supplied roots;
- no `.DS_Store` copying;
- no path traversal archive member;
- no duplicate archive member;
- no archive overwrite after finalization;
- no post-finalization output mutation.

──────────────────────────────────────────────────────────────────────────────
13. SNAPSHOT-BUNDLE MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 100 uniquely named cases.

Include:

A. Contamination cases

- no extra path;
- exact root `.DS_Store`;
- nested `.DS_Store`;
- two `.DS_Store` files;
- wrong mode;
- symlink `.DS_Store`;
- hard-linked `.DS_Store`;
- arbitrary extra file;
- arbitrary extra directory.

B. Manifest-member cases

- exact baseline;
- missing member;
- extra member;
- wrong bytes;
- same-size mutation;
- wrong size;
- wrong mode;
- wrong inode where owned;
- wrong stable directory field;
- root volatile contamination field difference;
- non-root directory metadata difference;
- A/B mismatch;
- wrong temporal identity.

C. Failure-evidence cases

- exact binding;
- missing failure outcome;
- stale failure outcome;
- wrong root;
- unbound evidence file;
- missing complete inventory;
- bounded subset baseline;
- false complete-snapshot claim.

D. Archive-member cases

- exact safe path;
- absolute path;
- `..`;
- duplicate name;
- empty segment;
- invalid UTF-8 representation;
- symlink entry;
- hard-link entry;
- special-file entry;
- `.DS_Store` included;
- member omitted;
- member added;
- wrong role ownership.

E. Determinism cases

- reordered source iteration;
- changed timestamp;
- changed compression method;
- archive comment;
- member extra field;
- changed mode;
- changed ZIP host system;
- Build-A/B mismatch.

F. Authority cases

- authority JSON wrong archive hash;
- wrong archive size;
- wrong member count;
- wrong index hash;
- containing-directory closure treated as authority;
- package verdict incorrectly issued;
- implementation verdict incorrectly issued.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/current-authority-snapshot-bundle-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
14. INDEPENDENT ARCHIVE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement an independent validator that imports neither:

- builder modules;
- builder helpers;
- builder member registry;
- mutation generator;
- expected-result map.

It must independently:

1. parse the authority JSON strictly;
2. authenticate archive file size and SHA-256;
3. parse the ZIP central directory;
4. reject duplicate members;
5. reject unsafe names;
6. reject nonregular entries;
7. reject compression;
8. reject comments and uncontrolled extras;
9. authenticate `bundle/index.json`;
10. authenticate every member hash and size;
11. require exact index/member-set equality;
12. require exactly eight roles;
13. require no `.DS_Store` member;
14. require seven sealed-package roles;
15. require one failure-evidence role;
16. verify every copied source member against its original current root and
    original manifest or binding;
17. verify Build-A/B identity evidence;
18. verify supplied-root equality;
19. verify no implementation/package verdict was issued.

Require zero errors.

Retain:

validation/independent-current-authority-snapshot-bundle-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
15. TWO BUNDLE-BUILD REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete bundle-build rehearsals using independent
working roots and the exact same builder source bytes.

Each rehearsal must:

- authenticate all eight roles;
- classify contamination;
- generate the same index semantics;
- create deterministic Build A and Build B;
- pass internal Build-A/B equality;
- pass independent archive validation;
- retain complete process custody;
- retain cleanup evidence.

Compare the two rehearsal final archives after normalizing only:

- external absolute output path;
- archive inode;
- build-process PIDs;
- permitted build timestamps stored outside the archive.

The archive bytes themselves must be exactly equal without normalization.

Retain both rehearsal archives until:

- independent validation;
- rehearsal comparison;
- evidence retention.

Then remove rehearsal working roots and archives, observing ENOENT twice.

──────────────────────────────────────────────────────────────────────────────
16. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero exit and empty streams;
- nonzero exit with both streams;
- timeout/kill/reap;
- one child;
- multiple children;
- empty child ledger;
- lost stdout;
- lost stderr;
- unregistered working-root effect;
- zero-root cleanup;
- one-root cleanup;
- multiple-root cleanup.

Require:

- prelaunch record;
- exact argv/cwd/environment;
- complete stdout/stderr;
- exit or signal;
- reaping;
- descriptor closure;
- effect attribution;
- evidence retained before cleanup;
- cleanup-set equality;
- double ENOENT;
- zero process, descriptor, cache, or bytecode survivor.

──────────────────────────────────────────────────────────────────────────────
17. SOURCE FREEZE AND REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- all input roles authenticate;
- contamination ledger closes;
- every sealed-package snapshot is recoverable;
- Attempt-2 evidence extraction closes;
- compilation/static gates pass;
- mutation matrix passes;
- deterministic Build-A/B comparison passes;
- independent validator passes;
- both rehearsals pass;
- rehearsal archive bytes match;
- process custody passes;
- evidence retention and cleanup pass;
- supplied roots close equal.

Retain:

opening/current-authority-snapshot-bundle-builder-source-freeze-v1.json

Reopen every source no-follow.

Do not modify source afterward.

Against frozen bytes rerun:

- compilation;
- static gates;
- mutation matrix;
- one deterministic bundle build in a disposable root;
- independent validation;
- source/result linkage;
- supplied-root equality.

Do not rerun both complete rehearsals.

Prove both passing rehearsals used the bytes later frozen.

Retain:

validation/frozen-current-authority-snapshot-bundle-builder-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
18. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for exactly the eight current roots.

Use the same raw observation grammar for opening and closing.

Require exact equality.

Do not open excluded roots.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
19. WORKING-ROOT CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any owned working or rehearsal root retain:

- root identity;
- complete inventory;
- process records and streams;
- all validation results;
- failure outcome when applicable.

Then:

- revalidate identity;
- remove exact root;
- observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Do not remove the final output directory or the final archive/authority files.

──────────────────────────────────────────────────────────────────────────────
20. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- complete process ledger and streams;
- complete partial build inventory;
- contamination ledger;
- indispensable evidence;
- working-root cleanup;
- supplied-root equality;
- source-freeze posture;
- same-root retry false.

Do not create an authoritative final bundle or authority JSON on failure.

If a provisional archive exists, classify it nonauthoritative and remove it
after retaining its identity and observing ENOENT twice.

Return provenance mismatch for:

- supplied-root identity mismatch;
- manifest-covered file mismatch;
- unknown extra path;
- supplied-root mutation;
- excluded-root access;
- historical source use;
- unregistered process or filesystem effect;
- indispensable evidence loss;
- cleanup inequality;
- supplied-root closing inequality;
- source drift after freeze;
- final archive/authority mismatch.

──────────────────────────────────────────────────────────────────────────────
21. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

only when:

- all eight root identities match;
- every sealed package’s manifests and temporal record authenticate;
- every manifest-covered regular-file byte authenticates;
- every live extra is empty or exactly root-level `.DS_Store`;
- `.DS_Store` is classified and excluded;
- no other contamination exists;
- Attempt-2 bounded evidence extraction closes;
- bundle index closes;
- deterministic Build A/B bytes match;
- independent archive validation passes;
- two build rehearsals pass;
- rehearsal archive bytes match;
- process custody passes;
- source freezes;
- frozen requalification passes;
- supplied roots close equal;
- final archive and authority JSON are mode `0400`;
- final archive and authority JSON identities are reported inline;
- no implementation or package verdict is issued.

Return:

GEN2_CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_BUILD_BLOCKED

when:

- complete current semantic bytes cannot be recovered without invention;
- Attempt-2 required evidence lacks an authenticated binding;
- deterministic construction cannot qualify within two attempts;
- a matrix, rehearsal, or validator fails without a provenance failure.

Return:

CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

for the provenance failures defined in Section 20.

──────────────────────────────────────────────────────────────────────────────
22. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh working-root identity
3. Fixed-input registry
4. Excluded-root registry
5. Confirmation excluded roots were unopened
6. Snapshot-bundle authority and nonauthority
7. Contamination ledger
8. Per-role contamination classification
9. Reconciliation snapshot authentication
10. Implementation-package snapshot authentication
11. Successor snapshot authentication
12. Normative-contract snapshot authentication
13. Schema-package snapshot authentication
14. Schema-reconciliation snapshot authentication
15. Validation-package snapshot authentication
16. Attempt-2 failure-evidence extraction
17. Complete role registry
18. Complete member registry
19. Bundle index identity
20. Builder-source attempt ledger
21. Final builder-source registry
22. Final independent-validator registry
23. Compilation and static gates
24. Snapshot-bundle mutation matrix
25. Deterministic Build A
26. Deterministic Build B
27. Build-A/B byte equality
28. Independent archive validation
29. Bundle rehearsal A
30. Bundle rehearsal B
31. Rehearsal archive byte equality
32. Process custody
33. Evidence retention
34. Working/rehearsal cleanup
35. Source freeze
36. Frozen-source requalification
37. Confirmation no implementation verdict
38. Confirmation no package verdict
39. Confirmation verifier and audit harness were not implemented
40. Supplied-root closing equality
41. Final archive path and file identity
42. Final authority-JSON path and file identity
43. Final archive member count
44. Final role count
45. Confirmation `.DS_Store` member count is zero
46. Remaining uncertainty and nonclaims
47. Explicit confirmation registry

Required confirmations:

FIXED_CURRENT_ROOT_REGISTRY_COMPLETE
EXCLUDED_ROOT_REGISTRY_COMPLETE
NO_EXCLUDED_ROOT_OPENED
SUPPLIED_ROOTS_NOT_MUTATED
LIVE_ROOTS_NOT_CLAIMED_CURRENTLY_SEALED
CONTAMINATION_LEDGER_COMPLETE
ONLY_PERMITTED_EXTRA_PATHS_OBSERVED
DS_STORE_CLASSIFIED_AS_INCIDENTAL_OS_METADATA
DS_STORE_BYTES_NOT_COPIED
ORIGINAL_CLOSURE_RULES_NOT_WEAKENED
SEVEN_SEALED_PACKAGE_MANIFESTS_AUTHENTICATED
SEVEN_SEALED_PACKAGE_TEMPORAL_RECORDS_AUTHENTICATED
ALL_MANIFEST_COVERED_REGULAR_FILE_BYTES_AUTHENTICATED
ALL_MANIFEST_COVERED_PATHS_PRESENT
NO_UNKNOWN_PACKAGE_MEMBER_COPIED
ATTEMPT_2_BINDING_AUTHENTICATED
ATTEMPT_2_FAILURE_OUTCOME_AUTHENTICATED
ATTEMPT_2_EVIDENCE_SCOPE_EXPLICIT
BUNDLE_ROLE_REGISTRY_COMPLETE
BUNDLE_MEMBER_REGISTRY_COMPLETE
NO_ABSOLUTE_ARCHIVE_MEMBER
NO_ARCHIVE_PATH_TRAVERSAL
NO_DUPLICATE_ARCHIVE_MEMBER
NO_SYMLINK_OR_SPECIAL_ARCHIVE_MEMBER
NO_DS_STORE_ARCHIVE_MEMBER
DETERMINISTIC_ZIP_FORMAT_FROZEN
BUILD_A_CREATED
BUILD_B_CREATED
BUILD_A_B_BYTES_IDENTICAL
INDEPENDENT_ARCHIVE_VALIDATOR_PASSED
SNAPSHOT_BUNDLE_MUTATION_MATRIX_PASSED
COMPLETE_BUNDLE_REHEARSAL_A_PASSED
COMPLETE_BUNDLE_REHEARSAL_B_PASSED
REHEARSAL_ARCHIVE_BYTES_IDENTICAL
PROCESS_CUSTODY_QUALIFICATION_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
BUILD_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
BUILDER_SOURCE_FROZEN
BUILDER_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_BUILDER_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
FINAL_ARCHIVE_CREATED
FINAL_ARCHIVE_MODE_0400
FINAL_ARCHIVE_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_BINDS_ARCHIVE
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CLOSURE_VERIFIER_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_HARNESS_NOT_IMPLEMENTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

the next tranche is implementation and qualification of the current-authority
closure verifier or clean source-external audit harness using only:

- the exact final archive;
- the exact authority JSON;
- their pinned identities.

Do not reopen the contaminated current directory roots in that later tranche.

Do not combine snapshot-bundle construction with verifier or harness
implementation.
```

### Sources

The report establishes that all nine opened roots now carry one additional, unregistered `.DS_Store`, while their fixed record identities remain intact. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

It also confirms that the contamination predated the task, every root remained unchanged during the task, no source was created, and zero verifier-source attempts were consumed. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

No implementation verdict, audit harness, current subject, target audit, runtime validation, Git operation, network operation, or product invocation occurred. :chatgpt-content-reference{index="10"} :chatgpt-content-reference{index="11"}

**Confidence:** 0.999 that the live directory capsules are genuinely post-seal contaminated; 0.999 that no implementation defect was established; 0.98 that a manifest-scoped, deterministic single-file authority bundle is the correct critical-path repair; 0.96 that deleting or ignoring `.DS_Store` in place would be materially less trustworthy.

The current attachment was available. Some older project uploads have expired and would need to be uploaded again if we need to inspect their original contents in a future pass.
