## Assessment

This is a **pure audit-process failure**. It is not a repository, restoration, provenance, validator, or compatibility failure.

The report says the repository remained on the exact `4a3a4244…18537` target, every performed inventory checkpoint matched the restored 477-object baseline, the generic authority-family validator passed independent non-enumerated-ID causals, all 38 contradictions rejected correctly, test 89 passed three times, four 89-test suites passed, and the A6D, amendment, synthetic A6, and SEC-02 checks passed. The audit is nonqualifying solely because its corrected preflight reused a record path and overwrote the first 21 Git records.

**No repository repair, cleanup, restoration, or implementation replay is warranted.** The repaired patch remains the correct audit target. The audit root and temporary preflight root should remain as nonqualifying evidence; neither needs to be cleaned before the next audit.

The next audit should correct the audit harness rather than impose another repository change:

1. Create the fresh audit root **before the first Git invocation**, after only checking that the path is absent. This avoids a disposable bootstrap ledger.
2. Use immutable attempt directories: `opening/attempt-1/`, `opening/attempt-2/`, and so on.
3. Create every Git-call record with exclusive creation. Never truncate, reuse, or overwrite a record.
4. If an attempt fails, retain it and start a new numbered attempt. Do not “correct” an attempt in place.
5. Compare inventories by relative-path key, never row order.
6. Capture every **parent-issued** Git call contemporaneously. For the provenance recipe, bind the exact recipe source and parent invocation and verify deterministic output twice; do not add fragile tracing around its internal Git subprocesses. The project provenance contract requires exact recipe bytes, two identical runs, and matching manifests—not separate interception of every child process. 
7. Stop immediately on a process-ledger failure. Do not continue into auditors and tests once the run is already nonqualifying.

The clean baseline is still the restored 477-object inventory with no cache or bytecode, and two post-restoration provenance replays reproduced the same canonical manifest.  The implementation remains a one-file test repair and explicitly requires a fresh independent audit. 

## Final fresh-audit prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Embed the complete audit report inline in Markdown.

Do not return only a verdict, summary, local-file link, or attachment
reference. Supplemental evidence links may follow the complete report.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH-CONVERSATION REQUIREMENT

This must be a completely fresh, read-only Codex conversation.

Do not resume:

- the Git-ledger-overwrite audit;
- the linked-worktree-process audit;
- the artifact-restoration conversation;
- the alternate-authority implementation conversation;
- another Evidence Verification audit conversation.

Objective

Independently audit the exact Evidence Verification v1 alternate-authority-ID
repair.

Do not repair, edit, format, normalize, clean, stage, commit, push, publish,
install, deploy, restart A6, invoke product or live-service paths, contact a
network, or execute Linux binaries.

No nested subagents.

The immediately preceding audit is permanently nonqualifying because its
second preflight overwrote 21 contemporaneously captured Git records. Its
substantive results are supplementary evidence only.

This audit must use immutable, append-only process evidence and must stop
immediately if that evidence becomes incomplete.

## 1. Exact target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence:

IMPLEMENTATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f

Expected canonical manifest:

EXPECTED_MANIFEST=$IMPLEMENTATION_EVIDENCE/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe ID:

execution-substrate.evidence-verification-v1.final-patch-provenance.v1

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected test source:

TESTS=$IMPL_R/tools/evidence_verify/test_verify_v1.py

Expected test identity:

- size: 88127
- SHA-256:
  a106fe923440e4f2b24a7a425f994aa935eaaa9ffb7a68925987c8444df9b568

Expected unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected source-external caller:

CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Restored clean inventory:

RESTORED_INVENTORY=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632/restoration/full-object-after.json

Expected governed object count:

477

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4
- regular, single-link
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Fresh audit root:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v4

Require AUDIT_ROOT absent before creation.

Primary working-tree root:

PRIMARY_WORKTREE=/Users/ds/Repositories/Execution Substrate

Expected common Git administration:

COMMON_GIT_DIR=/Users/ds/Repositories/Execution Substrate/.git

Expected linked-worktree administration:

WORKTREE_GIT_DIR=/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---evidence-verification-v1

## 2. Audit-root and immutable-attempt rule

Before the first Git command:

1. Confirm AUDIT_ROOT is absent using a non-Git absolute-path check.
2. Create AUDIT_ROOT under umask 077.
3. Create:

   opening/
   provenance/
   perspectives/
   validation/
   findings/
   closeout/
   tmp/

All directories must be mode 0700.

All retained files must be regular, single-link, mode 0600.

Every audit attempt must use a new, exclusively created directory:

opening/attempt-001/
opening/attempt-002/
...

Never reuse, truncate, replace, or overwrite an attempt directory or record.

If a preflight attempt fails:

- retain it unchanged;
- record its disposition;
- create the next numbered attempt;
- never correct the old attempt in place.

Use exclusive file creation for every process record. If a record path already
exists, stop immediately:

PROCESS_BOUNDARY_BLOCK

Do not reconstruct a missing or overwritten process record.

## 3. Git-process recording

Use for every parent-issued Git invocation:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Every parent-issued Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd exactly IMPL_R;
- explicitly receive the complete environment above;
- receive a monotonic invocation number before execution;
- write exactly one immutable record with exclusive creation;
- retain:
  - invocation number;
  - full argv;
  - cwd;
  - complete required environment;
  - start disposition;
  - exit;
  - stdout byte count and SHA-256;
  - stderr byte count and SHA-256.

No auditor may execute Git.

The exact provenance recipe is a pinned audit input. For each recipe run,
capture the parent recipe invocation, exact recipe bytes, argv, cwd,
environment, exit, stdout, stderr, and output file.

Do not instrument or separately reconstruct the recipe’s internal Git child
calls. Their behavior is reviewed from the exact pinned recipe source and from
the deterministic canonical output. This audit requires the recipe twice at
opening and twice at closing, not child-process tracing.

Any missing, reused, overwritten, reconstructed, or nonconforming direct Git
record is an immediate:

PROCESS_BOUNDARY_BLOCK

Stop immediately. Do not continue with auditors, source review, or tests.

## 4. Inventory comparison rule

Compare repository inventories by normalized repo-relative path key.

Do not compare inventories by row order.

Require exact equality of:

- path set;
- type;
- mode;
- size;
- link count;
- SHA-256.

Opening must equal RESTORED_INVENTORY and contain exactly 477 governed
objects.

Require absent:

- `tools/evidence_verify/__pycache__`;
- `*.pyc`;
- `*.pyo`;
- `.pytest_cache`;
- any additional ignored audit artifact.

On any object mismatch:

AUDIT_PROVENANCE_MISMATCH

Do not clean it inside the audit.

## 5. Python and bytecode boundary

Every Python process must use:

- `$PYTHON`;
- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- an audit-owned private TMPDIR.

Never import a Python module directly from IMPL_R.

When function-level access is required:

1. copy exact source bytes to AUDIT_ROOT;
2. verify copied SHA-256;
3. import only the audit-owned copy;
4. retain its identity and command;
5. remove only audit-owned copies at cleanup.

Repository tests may execute as child commands against IMPL_R using
`-I -S -B`. Do not import their test module into an audit controller.

## 6. Linked-worktree Git-administration boundary

Primary working-tree content beneath PRIMARY_WORKTREE is forbidden.

Narrow read-only Git-administration access is permitted only after deriving:

```text
git -C "$IMPL_R" rev-parse --absolute-git-dir
git -C "$IMPL_R" rev-parse --git-common-dir
```

Require the physically normalized results to equal WORKTREE_GIT_DIR and
COMMON_GIT_DIR.

The audit parent may perform nonrecursive, read-only existence/stat checks only
for:

- IMPL_R’s `.git` pointer;
- WORKTREE_GIT_DIR itself;
- COMMON_GIT_DIR itself;
- exact paths returned by
  `git -C "$IMPL_R" rev-parse --git-path <name>`
  for:
  - MERGE_HEAD
  - CHERRY_PICK_HEAD
  - REVERT_HEAD
  - BISECT_LOG
  - BISECT_START
  - rebase-merge
  - rebase-apply
  - sequencer
  - index.lock
  - HEAD.lock
  - packed-refs.lock
  - config.lock

No recursive Git-administration traversal.
No objects, refs, logs, hooks, or config-content reads.
No Git-administration write.

This narrow exception is conforming even though the paths are lexically beneath
PRIMARY_WORKTREE.

Any other actual operand resolving to primary working-tree content is:

PROCESS_BOUNDARY_BLOCK

## 7. Opening gate and provenance

Verify:

- physical root equals lexical IMPL_R;
- branch, HEAD, tree, parent, and absent upstream;
- exactly four modified tracked and nine untracked patch paths;
- zero staged, deleted, renamed, or unmerged;
- exact 13 manifest rows;
- exact canonical manifest;
- exact tracked binary diff;
- exact recipe source and ID;
- exact 477-object inventory;
- caller exact;
- A6D and amendment manifests exact;
- no Git operation marker or lock.

Run RECIPE twice into distinct fresh opening continuations.

Require:

- both exits 0;
- empty stderr;
- stdout equals its output file;
- both outputs byte-identical;
- both equal EXPECTED_MANIFEST;
- canonical SHA-256:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- inventory remains 477 objects.

On mismatch:

AUDIT_PROVENANCE_MISMATCH

## 8. Four distinct auditors

Start exactly three distinct read-only auditors concurrently:

1. Contract and authority.
2. Marker-family and validator correctness.
3. Test and validation adequacy.

After one completes and closes, start a fourth distinct auditor:

4. Security, filesystem, process, evidence, and artifacts.

Retry a failed start once.

If a required distinct auditor cannot start after one retry:

SUBAGENT_UNAVAILABLE

No nested delegation.
No auditor Git.
No auditor mutation.
No auditor cleanup.
No repository-module import.

Each auditor receives:

- explicit cwd IMPL_R;
- only absolute operands from a closed list in its prompt;
- the reproduced canonical patch identity;
- authority family and exact v1 identity;
- read-only posture;
- no-goals;
- the standard finding format.

Each report must state:

- actual cwd;
- exact absolute operands read;
- whether any operand resolved to primary working-tree content;
- whether any Git-administration operand was used;
- mutation performed: no;
- nested subagents: no.

An auditor reading an unlisted external file is a process finding. Do not use
that material in parent adjudication.

Checkpoint the exact 477-object inventory after the first wave and after the
fourth auditor.

## 9. Marker-family audit

Expected family:

execution-substrate.evidence-verification.trusted-host-contract.

Expected exact authority:

execution-substrate.evidence-verification.trusted-host-contract.v1

Independently establish:

- family grammar is generic;
- arbitrary prose is not authority;
- all four governing documents are scanned;
- exactly one family authority exists globally;
- it is in evidence_verification.md;
- it uses exact v1;
- BEGIN and END IDs match;
- unmatched markers reject;
- nested or overlapping markers reject;
- consumer authority blocks reject;
- strict v1 JSON and references remain intact.

Build an audit-owned parser. Do not import the repository test helper as the
sole oracle.

Run at least:

- live documents;
- v2;
- v27;
- future-review-17;
- one generated non-enumerated ID;
- alternate blocks in every consumer;
- mismatched IDs;
- unmatched begin and end;
- nested blocks;
- overlapping blocks;
- duplicate v1;
- unmarked family prose;
- unrelated HTML marker;
- lookalike non-family prefix.

Use complete valid contract-shaped JSON in alternate balanced blocks.

Independently reproduce:

- original 31 contradictions;
- seven producer marker cases;
- audit-only non-enumerated-ID cases.

Require specific intended reasons.

## 10. Test execution

Run test 89 alone three times with pinned Python `-I -S -B`.

Require each owning command:

- exit 0;
- one test;
- zero failure/error/skip;
- all 38 producer cases execute;
- 477-object inventory unchanged.

Discover exactly 89 tests.

Run complete suite:

- twice under umask 077;
- twice under umask 022.

Require each owning command:

- pinned Python `-I -S -B`;
- exit 0;
- exactly 89 tests;
- zero failure/error/skip;
- identical identity set;
- 477-object inventory unchanged.

Do not count an inner successful result when its owning command exits nonzero.

## 11. Unchanged input review

Require unchanged exact bytes for:

- PLANS.md;
- boundaries.md;
- artifact_hygiene.md;
- capability_probing.md;
- evidence_verification.md;
- verify_v1.py;
- source-external caller;
- registry;
- all three layouts;
- both historical fixtures.

Confirm the only byte change from the preceding target is
`test_verify_v1.py`.

## 12. Fresh compatibility

Using an audit-owned reconstruction of the documented caller:

### A6D

Run twice.

Require:

- exit 0;
- empty verifier stderr;
- deterministic canonical stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- mandatory trusted-host nonclaims;
- target, package, and TMPDIR unchanged;
- A6D manifest unchanged.

### Amendment

Run twice and require canonical stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same exit, stderr, nonclaim, and no-write conditions.

### Synthetic A6

Create only an audit-owned fixture outside IMPL_R.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require deterministic output, empty stderr, and unchanged watched inputs.

### SEC-02

Run an audit-owned target-marker causal.

Require authenticated source-by-value execution never loads the target script,
the marker remains absent, and direct-script predecessor shape is
nonqualifying.

Do not claim atomic interpreter custody.

Checkpoint the 477-object inventory after all compatibility checks.

## 13. Evidence, authority, and artifacts

Inspect IMPLEMENTATION_EVIDENCE completely.

Require:

- vulnerable causals actually accepted;
- repaired causals use identical copied inputs;
- original 31 and added seven reasons remain specific;
- independent implementation validator does not import the test helper;
- final attempts are selected correctly;
- failed attempts remain separate;
- no false compatibility claim;
- no authority widening.

Require:

- verifier remains an ES-owned bounded slice rule;
- documentation and tests remain private assurance/evidence;
- no readiness, product, runtime, admission, orchestration, durable-state,
  commit, or publication authority;
- no public schema or cross-repository framework owner.

## 14. Prior-finding closure

Reconcile:

- TV-01;
- CT-01;
- AP-06;
- SEC-01;
- SEC-02;
- VC-01 / SEC-A1;
- EV-01 through EV-09;
- F-01 through F-04;
- PP-01;
- PE-02;
- TA-03;
- AP-04;
- AP-05;
- CA-01.

TV-01 closes only if generic family scanning rejects non-enumerated IDs.

AP-06 closes only if four distinct auditors complete.

Do not represent supported-local trust as atomic interpreter custody.

## 15. Closing provenance

Remove only audit-owned fixtures outside IMPL_R.

Checkpoint the 477-object inventory before closing.

Run RECIPE twice into distinct fresh closing continuations.

Require:

- exits 0;
- empty stderr;
- stdout equals output files;
- byte-identical outputs;
- equality with EXPECTED_MANIFEST;
- manifest SHA-256:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- exact repository identity;
- exact 477-object inventory;
- no repository or supplied-evidence mutation.

## 16. Verdict rules

### ACCEPT

Only if:

- opening and closing provenance match;
- 477-object inventory remains exact;
- process records are complete, immutable, and contemporaneous;
- four distinct auditors complete;
- no forbidden primary-working-tree content is accessed;
- generic family causals pass;
- all contradiction and test gates pass;
- unchanged inputs remain exact;
- compatibility and SEC-02 pass;
- no artifact or process blocker remains.

### PROCESS_BOUNDARY_BLOCK

Use for:

- missing, reused, overwritten, reconstructed, or nonconforming direct Git
  records;
- forbidden primary-working-tree access;
- Git-administration access outside the narrow exception;
- unlisted auditor operands used in adjudication;
- repository-module import;
- other explicit audit-process violation.

Stop immediately when detected.

### AUDIT_PROVENANCE_MISMATCH

Use for repository bytes, inventory, recipe, manifest, path scope, or closing
identity mismatch.

### BLOCK

Use for a repairable source, test, evidence, validation, or authority defect.

### REJECT

Use only for a fundamental architecture or authority defect.

### SUBAGENT_UNAVAILABLE

Use when a required distinct auditor cannot start after one retry.

## 17. Complete inline report

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact target and identities.
4. Audit attempt and immutable-ledger design.
5. Opening and closing provenance.
6. Repository scope and 477-object baseline.
7. Complete contemporaneous parent Git-process record.
8. Recipe invocation records and deterministic outputs.
9. Four distinct auditor identities, roles, schedules, cwd, operands, retries,
   and status.
10. Marker-family grammar and invariants.
11. Independent alternate-ID/location causals.
12. Mismatch/unbalanced/nested/overlap causals.
13. Original 31 and producer seven cases.
14. Audit-only non-enumerated-ID cases.
15. Three targeted test-89 results.
16. Exact 89-test set and four suites.
17. Eight inventory checkpoints.
18. Unchanged-input review.
19. A6D results.
20. Amendment results.
21. Synthetic A6 results.
22. SEC-02 result.
23. No-write and deterministic-output evidence.
24. Implementation-evidence findings.
25. Authority and artifact adjudication.
26. Prior-finding closure table.
27. Severity-ranked residual findings.
28. Minority findings and parent resolution.
29. Remaining uncertainty and nonclaims.
30. Audit-created paths and cleanup.
31. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No staging.
No commit.
No push.
No A6 restart.
```

## After `ACCEPT`

Proceed directly to the exact-byte commit gate for manifest `4a3a4244…18537`. Do not add another implementation or producer-validation turn. The project protocol permits the commit/publication gate only after audit acceptance and forbids implementation repair during that gate. 

### Sources

- The restoration established an exact 477-object baseline and reproduced the unchanged canonical manifest twice. 
- The implementation changed only `test_verify_v1.py`, added generic family scanning, preserved the original 31 cases, and requires a fresh audit.  
- Independent audit is required to be fresh, provenance-first, read-only, and non-repairing. 
- Provenance requires exact recipe bytes and two deterministic runs, but it is evidence rather than correctness or authority.  

**Confidence**

- The current patch and 477-object baseline remain intact: **0.995**
- This audit failed solely on immutable process-record custody: **0.999**
- No cleanup or repository repair is needed: **0.999**
- Append-only attempt directories eliminate the observed failure mode: **0.995**
- Correct next step is the final fresh audit above: **1.00**
