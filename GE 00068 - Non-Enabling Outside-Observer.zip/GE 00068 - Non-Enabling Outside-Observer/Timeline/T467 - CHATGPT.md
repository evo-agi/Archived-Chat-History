## Engineering assessment

This result is a **pre-source fixed-input failure**, not a clean-harness implementation failure.

The run stopped because the prompt supplied `a3659edc…` as an acceptance-bearing whole-root projection for the blocked historical harness, while a fresh traversal produced `090fd237…`. Device, inode, mode, and the 423-entry count still matched. Critically, Codex found no permitted in-root JSON record that authenticated the prompt-supplied projection, so it could neither accept the supplied value nor determine whether the discrepancy represented historical drift or a projection-grammar difference. :chatgpt-content-reference{index="0"}

Nothing downstream was consumed:

- candidate `source/` was never created;
- final source registries were never created;
- compilation never began;
- zero source attempts were consumed;
- the implementation package was not opened, executed, or adjudicated;
- the other current governing roots were not opened. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

The pre-source documentary work does not constitute operative qualification. The D01–D14 matrices reported there were only authoring preflights; process custody, synthetic verdict lanes, compatibility replay, rehearsals, independent candidate validators, source freeze, and package closure were all not reached. :chatgpt-content-reference{index="3"}

### Progression decision

The historical blocked-clean root should no longer be an acceptance-bearing input to the new generation. It is noncurrent, nonauthoritative, and unnecessary to derive either semantics or source.

The replacement tranche should authenticate only:

1. the terminal findings-reconciliation capsule through its own temporal inventory and manifests;
2. the unchanged implementation package;
3. the current Generation‑2 successor and role registry;
4. the authoritative normative contract;
5. current schemas and schema reconciliation;
6. current validation specifications;
7. the retained Attempt‑2 failure specimen.

All retired or failed audit-harness roots must remain unopened. Their source is already prohibited, and requiring their historical whole-root projection creates risk without supplying current authority.

A whole-root projection supplied only in prompt prose must never be acceptance-bearing. Such a value is authoritative only when it is bound by an authenticated manifest, inventory, closing-equality record, or another explicitly governed record inside the supplied root.

The fresh three-attempt source budget remains intact.

```text
NEW CLEAN IMPLEMENTATION GENERATION OF THE SOURCE-EXTERNAL
INDEPENDENT AUDIT HARNESS FOR THE SEALED GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION-PARENT IMPLEMENTATION

CURRENT-AUTHORITY-ONLY FIXED-INPUT MODEL

Objective

Implement a new clean-room generation of the source-external independent audit
harness from:

- the terminal findings-reconciliation capsule;
- the current Generation-2 governing package;
- the authoritative normative contract;
- current schemas;
- current validation specifications;
- the unchanged sealed implementation package;
- the retained current Attempt-2 failure specimen.

Do not use any retired or failed audit-harness root as a fixed input.

Do not open, inventory, authenticate, compare, or clean any retired or failed
audit-harness root.

Do not copy, patch, transform, import, execute, translate, or use as an
AST/bytecode/source origin any historical audit-harness source.

Implement, qualify, freeze, requalify, and terminally close the new harness
package.

Do not execute the fresh full implementation-package audit in this task.

Do not execute the implementation reconstruction parent.

Do not modify or adjudicate the implementation package.

Do not construct the authoritative current schema subject.

Do not perform another historical findings reconciliation.

Do not perform another localized repair of a retired audit-harness lineage.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

At most three complete clean-source attempts are permitted.

The preceding run stopped before source creation, source-registry closure, or
compilation. It consumed zero source attempts. The full 0/3 source-attempt
budget is available.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, source authority, interface contracts,
process custody, qualification results, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FIXED-INPUT AUTHORITY RULE
──────────────────────────────────────────────────────────────────────────────

Before inspecting any supplied root, retain:

opening/fixed-input-authority-policy-v1.json

Freeze these rules:

1. Only roots explicitly listed in Sections 2–8 are supplied fixed inputs.
2. A root path, device, inode, and mode may be externally fixed and directly
   verified by no-follow lstat.
3. A file identity may be externally fixed and directly verified by stable
   no-follow read.
4. A whole-root projection, inventory digest, path-set digest, closure count,
   or terminal claim is acceptance-bearing only when bound by:
   - an authenticated manifest;
   - an authenticated temporal inventory;
   - an authenticated complete inventory record;
   - an authenticated closing-equality record;
   - another explicitly governed record inside that supplied root.
5. Prompt prose alone is not authority for a whole-root projection.
6. A historical report’s unbound projection value is diagnostic only.
7. No supplied root may be selected by:
   - basename;
   - first match;
   - recency;
   - prefix scan;
   - inode scan;
   - size scoring;
   - content scoring;
   - “latest” selection;
   - fallback.
8. Unknown or ambiguous current authority fails closed.
9. A retired or noncurrent historical root is not opened merely to establish
   current implementation authority.
10. No historical source is read as implementation input.

Retain for each opened root:

- role;
- exact path;
- root identity;
- authoritative closure records;
- exact closure grammar;
- permitted use;
- prohibited use;
- whether source bytes may be read;
- opening inventory identity;
- closing inventory identity.

──────────────────────────────────────────────────────────────────────────────
2. TERMINAL FINDINGS-RECONCILIATION CAPSULE
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected root identity:

- device:
  16777234
- inode:
  181119472
- mode:
  0700
- verdict:
  GEN2_IMPLEMENTATION_AUDIT_BLOCK_RECONCILED_AUDIT_HARNESS_REIMPLEMENTATION_REQUIRED

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  181133295
- mode:
  0600
- link count:
  1
- size:
  19496
- SHA-256:
  fe18b553b3bb18e8bf1b42c75e78baef641ccd8c4257c58653084120049482cf
- represented rows:
  53

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  181133296
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920
- represented rows:
  54

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  181133297
- mode:
  0600
- link count:
  1
- size:
  20479
- SHA-256:
  751909828cbfafbe361ebf397c42e6ea52f3f6fb0f096edaca5e39bcc7ed0920

Authenticate terminal closure only through:

- the temporal inventory;
- manifest A;
- manifest B;
- byte equality;
- independent reprojection under their declared grammar;
- root row;
- exclusions;
- terminal topology and modes;
- guarded terminal marker;
- no-write-after-seal evidence.

Authenticate through exact manifest membership:

findings/complete-29-finding-ledger-v1.json
analysis/audit-source-predicate-crosswalk-v1.json
analysis/confirmation-and-terminal-marker-adjudication-v1.json
analysis/fresh-validation-lane-adjudication-v1.json
analysis/fresh-rehearsal-a-b-adjudication-v1.json
analysis/29-finding-dependency-graph-v1.json
closeout/mandatory-next-engineering-treatment-v1.json
validation/audit-block-findings-reconciliation-matrix-v1.json
closing/supplied-root-closing-equality-v1.json
report/explicit-confirmations-v1.json

Require the mandatory treatment to be exactly:

CLEAN_SOURCE_EXTERNAL_AUDIT_HARNESS_REIMPLEMENTATION_THEN_FRESH_AUDIT

Authenticate the retained conclusions:

- 23 primary audit-side defects;
- six derivative failures;
- zero verified implementation-package defects;
- zero mixed findings;
- zero evidence-insufficient findings;
- ten deduplicated original audit-harness defect surfaces;
- incremental harness lineage retired;
- fresh source-external audit harness required;
- implementation package unchanged;
- fresh audit required;
- further read-only findings reconciliation not authorized.

Treat this capsule as:

- authoritative for historical defect ownership;
- authoritative for retirement and mandatory treatment;
- nonauthoritative regarding implementation-package acceptance.

Do not reopen or reinterpret F01–F29.

Require complete opening/closing equality using the same no-follow inventory
grammar within this task.

──────────────────────────────────────────────────────────────────────────────
3. SEALED IMPLEMENTATION PACKAGE — FUTURE AUDIT SUBJECT
──────────────────────────────────────────────────────────────────────────────

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700
- producer verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

Expected physical closure:

- entries:
  112
- directories including root:
  17
- regular files:
  95
- temporal represented rows:
  109
- manifest represented rows:
  110

Expected current production registry:

- inode:
  180895418
- size:
  704
- SHA-256:
  1ded4df7836c16a153b6aab587d7d41903f1d8e907903a0000ae0efb518962c4

Expected current production source:

- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

Expected qualification registry:

- inode:
  180895419
- size:
  4391
- SHA-256:
  57c22b15bab5667d32f9949867f198eddd41b0d345ad1d30111370c6c1548a8c

Expected source freeze:

- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

Expected frozen requalification:

- size:
  31819
- SHA-256:
  5e48332bec6610032ea14067eeecda20f653a14af03d0d27f9edc09db862e21f

Authenticate closure through the package’s own temporal inventory, terminal
manifest pair, and declared grammar.

Use this root only for bounded read-only compatibility qualification.

Do not:

- execute the production reconstruction parent;
- run its qualification driver as the audit parent;
- mutate, resume, repair, or reseal the package;
- issue an implementation ACCEPT or BLOCK verdict in this task.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. CURRENT GENERATION-2 SUCCESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

Authenticate:

- package temporal inventory;
- manifest pair;
- exact 41-role registry;
- exactly one current artifact per role;
- historical/noncurrent exclusions;
- package closing equality.

Use only roles resolved through this exact current registry.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. AUTHORITATIVE NORMATIVE-CONTRACT PACKAGE
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Authenticate the package through its own temporal inventory and manifest pair.

Treat this contract as the sole semantic authority.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
6. CURRENT SCHEMA AUTHORITIES
──────────────────────────────────────────────────────────────────────────────

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Authenticate current schemas and supersession solely through the current
schema package’s manifests, role registry, and the reconciliation records.

Use current schema roles only.

Require complete opening/closing equality for both roots.

──────────────────────────────────────────────────────────────────────────────
7. CURRENT VALIDATION-SPECIFICATION PACKAGE
──────────────────────────────────────────────────────────────────────────────

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Authenticate through its own temporal inventory, manifest pair, role occupancy,
and current evidence registry.

Use as authority for:

- fourteen generated families;
- 946-case registry;
- 137-case registry;
- 766/333 field-map model;
- ten documentary-validator roles;
- subject-domain grammar;
- current confirmation evidence.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
8. CURRENT ATTEMPT-2 FAILURE SPECIMEN
──────────────────────────────────────────────────────────────────────────────

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Expected failure-outcome identity:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Use only as the governed current failure-custody specimen.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
9. EXCLUDED HISTORICAL ROOTS
──────────────────────────────────────────────────────────────────────────────

Do not open any of the following:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-5u3oi458

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-independent-audit-fresh-qAGO1c0a

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-4xuh1lon

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b

/Users/ds/Downloads/ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-dz2xlcfd

They are not fixed inputs.

They are not required for current authority.

They must not gate the new implementation.

Their source, inventories, projections, reports, and process-local state must
not be inspected or reused.

Historical defect requirements are supplied exclusively through the terminal
findings-reconciliation capsule and this task’s frozen pre-source contracts.

Retain:

opening/excluded-historical-root-registry-v1.json

Bind:

- every excluded path;
- reason:
  retired, blocked, or pre-source noncurrent;
- current authority:
  none;
- opened:
  false;
- inspected:
  false;
- source used:
  false.

──────────────────────────────────────────────────────────────────────────────
10. FRESH NEW-GENERATION HARNESS ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- `tempfile.mkdtemp`;
- umask `077`;
- prefix:

ES-repair10i-v3-gen2-new-clean-source-external-audit-harness-current-authority-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Before opening supplied roots retain:

opening/bootstrap-start.json
opening/new-clean-generation-source-authority-v2.json
opening/fixed-input-authority-policy-v1.json
opening/excluded-historical-root-registry-v1.json
opening/task-process-execution-policy-v1.json

Bind:

- fresh-root identity;
- allocation method and umask;
- exact acceptance-bearing root list:
  Sections 2–8 only;
- excluded historical roots:
  Section 9;
- clean source initially absent:
  true;
- implementation package mutation:
  unauthorized;
- implementation adjudication:
  unauthorized in this task;
- full independent audit:
  unauthorized in this task;
- real implementation rehearsals:
  unauthorized;
- current-subject construction:
  unauthorized;
- target audit/runtime/product/repository/publication/deployment/A6:
  unauthorized;
- source-attempt maximum:
  3;
- source attempts already consumed:
  0;
- same-root retry:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
11. PROCESS-EXECUTION POLICY
──────────────────────────────────────────────────────────────────────────────

Freeze before the first child process:

contract/new-clean-harness-process-execution-policy-v2.json

Permit only exact registered executables and argv shapes for:

- pinned Python compilation;
- source-external validators;
- bounded causals;
- synthetic fixture parents;
- harness qualification rehearsals;
- platform-capture preflight.

Every child must pass through one recorder.

Prelaunch record:

- ordinal;
- executable;
- argv;
- cwd;
- explicit environment;
- stdin posture;
- timeout;
- fixed effects;
- dynamic-root contract;
- purpose;
- phase.

Outcome record:

- exit or signal;
- stdout;
- stderr;
- timeout;
- reaping;
- descriptor closure;
- fixed effects;
- dynamic effects.

Forbid:

- Git and every VCS executable;
- Git/VCS libraries;
- `.git` metadata;
- repository-root discovery;
- VCS status/diff;
- shell;
- PATH-based executable lookup;
- network.

Use no-follow lstat, stable reads, hashes, inventories, byte comparison, and
AST comparison.

Any actual Git/VCS process, library use, or `.git` access is:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
12. PRE-SOURCE OPERATING MODEL
──────────────────────────────────────────────────────────────────────────────

Before source creation retain:

contract/new-clean-audit-harness-operating-model-v2.json
contract/new-clean-audit-harness-authority-v2.json
analysis/new-clean-audit-harness-source-architecture-v2.json

Authority:

- authenticate current supplied roots;
- inspect implementation source/evidence read-only in future audit mode;
- run audit-owned matrices and causals;
- create disposable audit-owned synthetic fixtures;
- retain evidence;
- clean owned roots after retention;
- issue package verdicts only in future full-audit mode;
- close audit capsules.

Nonauthority:

- implementation repair;
- contract/schema repair;
- current-subject construction;
- product/runtime invocation;
- repository mutation;
- publication/deployment;
- A6.

Process model:

- one finite parent;
- one recorder;
- no stdin;
- no persistent supervisor;
- no administrative continuation;
- complete streams;
- exit/signal;
- reaping;
- descriptor closure;
- effect attribution before cleanup;
- no shell/PATH/network/Git;
- no broad scan/latest/fallback/adoption.

No source may be created before this freeze and an independent documentary
validator pass.

──────────────────────────────────────────────────────────────────────────────
13. FOURTEEN DEFECT-PREVENTION SURFACES
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/new-clean-audit-harness-defect-prevention-registry-v2.json

D01 — attempt/status semantics
D02 — transitive freeze binding
D03 — role-layout/source-registry join
D04 — path-sensitive G01 analysis
D05 — confirmation and terminal-marker semantics
D06 — lane-specific validation adapters
D07 — typed 766/333 field-map model
D08 — constructed-subject domain and grammar
D09 — contract-wide physical normalization
D10 — causal findings and report projection
D11 — canonical cleanup-result semantics
D12 — typed interface-metadata policy separation
D13 — ordered report-section registry and derived count
D14 — exact confirmation-name registry and verdict separation

Every surface must bind:

- governing current authority;
- interface contract;
- production owner;
- qualification owner;
- independent-validator owner;
- direct tests;
- negative tests;
- historical regression case represented as data, not historical source.

D12 must maintain separate fields:

- `field_alias_policy`;
- `path_rendering_policy`;
- `normalization_policy`.

A path-rendering policy is not a semantic alias.

D13 must derive report-section count only as:

`len(section_registry)`

D14 must derive confirmation count only as:

`len(confirmation_names)`

The primary verdict must never be a confirmation entry.

──────────────────────────────────────────────────────────────────────────────
14. EXTERNAL-INTERFACE, JSON, REPORT, AND CONFIRMATION CONTRACTS
──────────────────────────────────────────────────────────────────────────────

Before source create:

contract/new-clean-audit-harness-external-interface-registry-v2.json
contract/new-clean-audit-harness-total-json-observation-v2.json
contract/new-clean-audit-harness-report-contract-v2.json
contract/new-clean-audit-harness-confirmation-contract-v2.json
contract/new-clean-audit-harness-report-section-registry-v2.json
contract/new-clean-audit-harness-confirmation-name-registry-v2.json

Require exact typed supplied interfaces for:

- 41-role successor registry;
- implementation registries and attempt lineage;
- freeze and requalification;
- producer rehearsals;
- component-role layout;
- implementation confirmations;
- matrix lanes;
- 946 cases;
- 137 cases;
- 766/333 field map;
- constructed-subject records;
- subject confirmation domain;
- subject temporal/manifest grammar;
- Attempt-2 failure;
- process and cleanup records;
- terminal capsule records.

Total JSON statuses:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

No chained `.get()` on untrusted data.

No missing-as-zero/false/null/empty/success.

No generic truthiness for acceptance facts.

Report contract:

- ordered unique section IDs;
- derived count;
- exact applicability;
- no independent numeric count;
- no report prose as authority.

Confirmation contract:

- exact unique name set;
- derived count;
- no verdict token;
- evidence pointer per name;
- no hard-coded success;
- no absence-as-success;
- terminal confirmations governed by terminal evidence.

Run an independent documentary validator before source creation.

──────────────────────────────────────────────────────────────────────────────
15. SOURCE ARCHITECTURE AND REGISTRIES
──────────────────────────────────────────────────────────────────────────────

Define clean modules for:

- finite parent;
- recorder;
- strict JSON;
- total observer;
- no-follow inventory;
- current-role resolver;
- grammar registry;
- attempt/status adapter;
- freeze validator;
- role/source joiner;
- path-sensitive analyzer;
- qualification-independence analyzer;
- confirmation adjudicator;
- lane adapters;
- field-map adjudicator;
- constructed-subject validator;
- root normalizer;
- cleanup-result owner;
- evidence retention/cleanup;
- process/failure custody;
- security/authority;
- causal reconciliation;
- report projection;
- capsule lifecycle;
- failure closeout;
- platform capture;
- independent validators.

Every role maps once to one clean source path.

Independent validators import no candidate production or qualification module,
generator, expected map, observer, normalizer, or projector.

Retain planned and final:

contract/new-clean-harness-production-source-registry-v2.json
contract/new-clean-harness-qualification-source-registry-v2.json
contract/new-clean-harness-independent-source-registry-v2.json

──────────────────────────────────────────────────────────────────────────────
16. CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Before compilation derive:

analysis/derived-cross-module-interface-set-v2.json
contract/new-clean-harness-cross-module-interface-registry-v2.json

Derive from AST imports, direct calls, resolved attribute calls, return sites,
constructors, serialized-record producers/readers, and statically resolvable
bytecode targets.

Every interface binds:

- ID;
- provider;
- consumer;
- call sites;
- provider shape;
- consumer shape;
- fields/pointers;
- type/nullability;
- exception contract;
- authority;
- verdict applicability;
- field-alias policy;
- path-rendering policy;
- normalization policy;
- direct test;
- independent test.

Require exact equality:

derived
=
registered
=
directly tested
=
independently tested

No unresolved acceptance-bearing edge.

──────────────────────────────────────────────────────────────────────────────
17. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete source attempts.

An attempt begins only when all three final source registries close and
compilation begins.

For each retain:

- clean-room source identities;
- compilation;
- static/interface gates;
- matrices reached;
- synthetic lanes;
- rehearsal posture;
- first blocker;
- supersession.

Any source change after compilation begins creates a new attempt.

If Attempt 3 fails, stop. Do not create Attempt 4.

──────────────────────────────────────────────────────────────────────────────
18. STATIC AND PRECOMPILATION GATES
──────────────────────────────────────────────────────────────────────────────

Before compilation require:

- all sources parse as AST;
- every architecture role occupied;
- every interface set closes;
- provider/consumer shapes conform;
- report implementation matches section registry;
- confirmation implementation matches name registry;
- no alias/path-policy conflation;
- no historical source import;
- no Git/VCS mechanism.

Then compile every source using pinned Python `-I -S -B`.

Require exit zero and empty stderr.

Run source-external AST, call-graph, dataflow, bytecode, exception-table, CFG,
provider/consumer, report, confirmation, process, filesystem, and terminal
crosswalks.

Require finite flow, one recorder, no stdin/supervisor/network/Git/shell/PATH,
no broad scan, no unregistered interface, no postseal operation, and reachable
success/failure closeout.

──────────────────────────────────────────────────────────────────────────────
19. D01–D14 MATRICES
──────────────────────────────────────────────────────────────────────────────

Minimum cases:

- D01: 30
- D02: 25
- D03: 30
- D04: 30
- D05: 35
- D06: 100
- D07: 30
- D08: 40
- D09: 40
- D10: 30
- D11: 50
- D12: 35
- D13: 25
- D14: 25

Require unique names, exact closure, zero false acceptance/rejection, zero
reason mismatch, zero skip, and zero exception.

D11 must cover canonical cleanup rows and reject `cleanup_roots` aliasing.

D12 must independently validate field alias, path rendering, and normalization
policies.

D13 must reject section-count drift.

D14 must reject appended verdict confirmations.

──────────────────────────────────────────────────────────────────────────────
20. PROCESS CUSTODY AND SYNTHETIC END-TO-END LANES
──────────────────────────────────────────────────────────────────────────────

Exercise process causals for nonexistent executable, empty streams, nonzero
streams, timeout, dynamic roots, missing results, empty/multiple ledgers, lost
streams, unregistered effects, and zero/one/multiple-root cleanup.

Run synthetic:

- ACCEPT implementation package;
- substantive BLOCK implementation package;
- audit provenance failure;
- two semantically equal constructed subjects;
- wrong-registry/same-length matrix corpus.

Require exact verdicts, findings, process custody, report and confirmation
contracts, terminal capsule closure, cleanup, and no postseal operation.

──────────────────────────────────────────────────────────────────────────────
21. BOUNDED REAL-PACKAGE COMPATIBILITY REPLAY
──────────────────────────────────────────────────────────────────────────────

Without executing implementation source or full-audit mode:

- authenticate implementation closure;
- resolve 41 roles;
- resolve Attempts 1–3;
- validate freeze chain;
- resolve 24 production and nine qualification roles;
- adjudicate G01 path-sensitively;
- audit 125 implementation confirmations;
- parse all matrix lanes;
- parse 946, 137, and 766/333 records;
- parse retained producer rehearsals under subject grammar;
- normalize rehearsals to zero unexplained differences;
- authenticate Attempt-2 failure;
- derive one exact future audit invocation;
- emit no package verdict.

Retain:

validation/new-clean-harness-bounded-compatibility-replay-v2.json

──────────────────────────────────────────────────────────────────────────────
22. TWO COMPLETE HARNESS REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete rehearsals against independent synthetic
fixture sets using identical candidate bytes.

Each must complete D01–D14, process custody, all synthetic lanes,
compatibility replay, report generation, exact confirmation registry, terminal
closure, and cleanup.

Retain complete roots until independent validation and normalized comparison
pass.

Require zero unexplained semantic difference.

──────────────────────────────────────────────────────────────────────────────
23. INDEPENDENT VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Independent validators must not import candidate modules or helpers.

Independently verify:

- clean provenance;
- all pre-source contracts;
- D01–D14;
- cross-module interfaces;
- policy-field separation;
- report registry/count;
- confirmation registry/count/verdict separation;
- process custody;
- synthetic lanes;
- compatibility replay;
- both rehearsals;
- normalization;
- evidence retention;
- cleanup;
- capsule closure.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
24. EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing owned roots retain exact identities, complete inventories,
process streams, indispensable results, failure outcome, and terminal posture.

Then verify identity, remove exact root, and observe ENOENT twice.

Require:

created
=
inventoried
=
evidence-retained
=
cleanup rows
=
twice absent

Empty equal sets pass.

──────────────────────────────────────────────────────────────────────────────
25. SOURCE FREEZE AND REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Freeze only after all static, interface, matrix, process, synthetic,
compatibility, rehearsal, independent-validator, evidence, cleanup, and
supplied-root gates pass.

Retain:

opening/new-clean-audit-harness-source-freeze-v2.json

Reopen all source no-follow and forbid modification.

Against frozen bytes rerun compilation, static/interface gates, D01–D14,
process custody, synthetic lanes, compatibility replay, independent validators,
source/result linkage, and supplied-root equality.

Do not rerun the two complete rehearsals.

Prove they used the bytes later frozen.

Retain:

validation/new-clean-audit-harness-frozen-source-requalification-v2.json

──────────────────────────────────────────────────────────────────────────────
26. PACKAGE STATUS AND SUPPLIED-ROOT EQUALITY
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- new clean harness implemented, qualified, and frozen;
- historical harness roots excluded and unopened;
- implementation unchanged and unadjudicated;
- full audit not executed;
- fresh audit required;
- current-subject construction unauthorized;
- product/runtime/target/repository/publication/deployment/A6 not performed.

Repeat complete no-follow opening/closing inventories for Sections 2–8 only.

Require exact equality.

Do not open Section 9 roots.

──────────────────────────────────────────────────────────────────────────────
27. TERMINAL PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize nonclosure outputs, create only used directories, precreate
`closeout/` and `manifest/`, reserve A/B, freeze the directory set, and prohibit
later directory creation.

Then:

- temporal projection excluding itself and A/B;
- immediate independent reprojection;
- independent identical A/B generation;
- descriptor writes and fsync;
- no-follow identity checks;
- final independent reprojection;
- root row once;
- no empty descendant;
- no invalid object or multilink;
- modes 0700/0600;
- no cache/bytecode;
- one seal transition;
- report from exact section registry;
- confirmation artifact from exact name registry;
- verdict separate;
- guarded marker;
- nonreturning exit;
- no postseal operation.

──────────────────────────────────────────────────────────────────────────────
28. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain source attempt or pre-attempt posture, first blocker,
exception, process ledger/streams, partial inventory, indispensable evidence,
cleanup, supplied-root equality, source-freeze posture, terminal posture, and
same-root retry false.

Do not create success manifests for a failed package.

Fixed-current-input mismatch, historical-root access, source-provenance
violation, Git/VCS use, unregistered effect, evidence loss, cleanup inequality,
supplied-root inequality, source drift, terminal-closure failure, or postseal
operation is:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
29. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when every current-authority, clean-source, interface, matrix, process,
synthetic, compatibility, rehearsal, independent-validation, evidence,
cleanup, freeze, requalification, supplied-root, and terminal-closure gate
passes.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when a clean implementation cannot qualify within three attempts or would
require changing governing semantics.

Return:

NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTATION_PROVENANCE_MISMATCH

for the provenance conditions listed in Section 28.

──────────────────────────────────────────────────────────────────────────────
30. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the exact ordered report-section registry frozen before source.

At minimum include:

1. Primary verdict
2. Fresh root identity
3. Fixed-input authority policy
4. Terminal reconciliation authentication
5. Excluded historical-root registry
6. Confirmation excluded roots were not opened
7. Implementation-package preservation
8. Current governing-root preservation
9. Clean-room source authority
10. Process-execution policy
11. Operating-model freeze
12. D01–D14 registry
13. External-interface registry
14. Total JSON contract
15. Report contract
16. Confirmation contract
17. Source architecture
18. Source-attempt ledger
19. Production registry
20. Qualification registry
21. Independent registry
22. Cross-module interfaces
23. Static gates
24–37. D01–D14 matrices
38. Process custody
39. Synthetic ACCEPT
40. Synthetic BLOCK
41. Synthetic provenance failure
42. Synthetic subject pair
43. Compatibility replay
44. Rehearsal A
45. Rehearsal B
46. Normalized comparison
47. Independent validators
48. Evidence retention
49. Cleanup
50. Source freeze
51. Frozen requalification
52. Confirmation full audit not executed
53. Package status
54. Supplied-root equality
55. Failure closeout
56. Temporal inventory
57. Manifest A
58. Manifest B
59. Terminal reprojection
60. Terminal topology/modes
61. No-write-after-closure
62. Remaining uncertainty/nonclaims
63. Explicit confirmations

The actual count must be derived from the frozen registry. No separate numeric
literal is authoritative.

Freeze the exact confirmation-name set before source. The confirmation artifact
must contain exactly that set and no verdict token.

Required confirmations include:

FIXED_INPUT_AUTHORITY_POLICY_FROZEN
PROMPT_ONLY_PROJECTION_NOT_USED_AS_AUTHORITY
FINAL_RECONCILIATION_AUTHENTICATED
HISTORICAL_FINDINGS_PRESERVED
HISTORICAL_HARNESS_ROOTS_EXCLUDED
NO_EXCLUDED_HISTORICAL_ROOT_OPENED
NO_HISTORICAL_HARNESS_SOURCE_COPIED
NO_HISTORICAL_HARNESS_SOURCE_PATCHED
NO_HISTORICAL_HARNESS_SOURCE_IMPORTED
NO_HISTORICAL_HARNESS_SOURCE_USED_AS_AST_ORIGIN
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
CURRENT_GOVERNING_ROOTS_AUTHENTICATED
CURRENT_GOVERNING_ROOTS_MUTATION_NOT_PERFORMED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
SOURCE_ATTEMPT_LIMIT_RESPECTED
PROCESS_EXECUTION_POLICY_FROZEN
NO_GIT_OR_VCS_USE
OPERATING_MODEL_FROZEN_BEFORE_SOURCE
D01_D14_REGISTRY_COMPLETE
INTERFACE_METADATA_POLICIES_SEPARATED
REPORT_SECTION_REGISTRY_FROZEN
REPORT_SECTION_COUNT_DERIVED
CONFIRMATION_NAME_REGISTRY_FROZEN
CONFIRMATION_COUNT_DERIVED
PRIMARY_VERDICT_SEPARATE_FROM_CONFIRMATIONS
EXTERNAL_INTERFACE_REGISTRY_COMPLETE
TOTAL_JSON_OBSERVATION_IMPLEMENTED
SOURCE_ARCHITECTURE_COMPLETE
FINAL_SOURCE_REGISTRIES_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
D01_D14_MATRICES_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NEW_CLEAN_HARNESS_SOURCE_FROZEN
NEW_CLEAN_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
HARNESS_TEMPORAL_INVENTORY_CREATED
HARNESS_TEMPORAL_INVENTORY_VERIFIED
HARNESS_MANIFEST_A_CREATED
HARNESS_MANIFEST_B_CREATED
HARNESS_MANIFESTS_BYTE_IDENTICAL
HARNESS_TERMINAL_REPROJECTION_PASSED
HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_NEW_CLEAN_AUDIT_HARNESS_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged sealed
implementation package.

Do not combine that audit with this implementation task.

Do not construct the authoritative current schema subject until the later
fresh audit accepts the implementation package.
```

### Sources

The report shows that the new-generation run stopped solely on an unsupported whole-root projection mismatch for a historical, noncurrent blocked harness: root identity and entry count matched, but the prompt-supplied projection differed from the fresh result and had no authenticated in-root authority record. :chatgpt-content-reference{index="4"}

It also confirms that source creation, final source registries, compilation, process qualification, synthetic lanes, rehearsals, freeze, and closure were never reached, so zero source attempts were consumed. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

The implementation package and current governing roots were not opened or adjudicated, no supplied-root mutation occurred, and failure closeout retained the mismatch without success manifests or same-root retry. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

**Confidence:** 0.998 that no source-attempt budget was consumed; 0.99 that the failed historical-root projection was an unnecessary acceptance dependency; 0.97 that restricting fixed inputs to current authoritative roots is the correct next tranche; 0.95 that another current-authority mismatch should stop the task rather than reopen historical harness reconciliation.
