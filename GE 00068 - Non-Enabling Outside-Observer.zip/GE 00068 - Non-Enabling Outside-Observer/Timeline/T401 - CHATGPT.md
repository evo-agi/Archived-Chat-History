## Assessment

This is a decisive schema-layer result, not another implementation failure.

The normative contract remains coherent and authoritative. The implementation was correctly blocked because the generated-record schemas cannot represent several records the contract requires. The key findings are now exact:

- **Six record families are jointly unsatisfiable** under the current contract/schema pair.
- **Ten semantic contradiction sites** exclude **39 contract-required fields**.
- The normative-contract schema itself has **21 Draft 2020-12 violations** caused by invalid empty `prefixItems`.
- The remaining schemas are not safe merely because they are satisfiable: all fourteen generated-record schemas admit at least one contract-forbidden minimal record.
- The previous 766-leaf map and validators were valid only in their narrow lanes. They never instantiated contract-required generated records against their governing schemas.
- The blocked implementation candidate remains historical, unfrozen, unexecuted, and without patch authority.

I would not split the work into “repair seven now, harden eight later.” That would produce another package that is still not implementation-ready. The next tranche should preserve the normative contract byte-for-byte while revising **all fifteen schemas**, adding joint contract/schema satisfiability as a mandatory package gate, regenerating the documentary validators, and resealing a fresh contract package. Only after that package independently proves all record families satisfiable and sufficiently constrained should implementation restart from a new root.

Forward this prompt to Codex:

```text
REVISE AND RESEAL THE VALIDATION-CUSTODY V3
PACKAGE-CONSTRUCTION-PARENT CONTRACT PACKAGE —
PRESERVE THE NORMATIVE CONTRACT, REPAIR ALL FIFTEEN SCHEMAS,
AND ADD JOINT CONTRACT/SCHEMA SATISFIABILITY GATES

This task creates a fresh authoritative contract package whose normative
construction-parent contract is byte-identical to the current authoritative
contract, while all fifteen subordinate schemas are revised to express and
enforce that contract correctly.

This is a schema and documentary-validation repair.

It is not:

- a normative-contract amendment;
- a construction-parent implementation task;
- a patch to the blocked implementation candidate;
- target-audit harness package construction;
- a target audit;
- runtime validation;
- repository or product work.

Do not modify, resume, clean, finish, or reseal any supplied root.
Do not modify the normative contract.
Do not patch or execute the blocked implementation candidate.
Do not execute process-self-test or construct mode.
Do not create construction-parent implementation source.
Do not build a target-audit harness package.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_PACKAGE_REPAIRED
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_REPAIR_BLOCKED
CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. AUTHORITATIVE CONTRACT PACKAGE
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700
- verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19
- status:
  frozen-pending-implementation
- sole normative writer:
  true
- implementation present:
  false
- implementation authority:
  false

Temporal inventory:

closeout/temporal-final-inventory-v2.json

- size:
  17739
- SHA-256:
  e65b511f4c6fb69be9a14a4702ee32d2e1b670db04f4058b398fcf36d662f0f1

Terminal manifests:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- size:
  17596 each
- SHA-256:
  a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2
- byte-identical:
  required

Authenticate and independently reproduce the complete package closure before
using any contract or schema byte.

The normative contract is the sole semantic authority.

No schema, validator, field map, witness, report, or implementation candidate
may redefine, narrow, widen, or override it.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING SCHEMA-SATISFIABILITY RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700
- verdict:
  CONSTRUCTION_PARENT_SCHEMA_SATISFIABILITY_RECONCILED_SCHEMA_REPAIR_REQUIRED

Expected terminal manifests:

- size:
  8309 each
- SHA-256:
  adf5f56574fcc5d82d874057b8b2916c294982318c6e4f6fb300d1bb82c61c82
- byte-identical:
  required

Authenticate and inspect at minimum:

analysis/fifteen-schema-inventory-v1.json
analysis/contract-record-family-inventory-v1.json
analysis/contract-schema-contradiction-ledger-v1.json
analysis/contradiction-count-reconciliation-v1.json
analysis/normativity-and-repair-authority-v1.json
analysis/prior-documentary-validation-blind-spot-v1.json
analysis/contract-schema-repair-surface-v1.json
validation/minimal-contract-witness-matrix-v1.json
validation/minimal-schema-witness-matrix-v1.json
validation/independent-contract-schema-satisfiability-v1.json
validation/contract-schema-satisfiability-matrix-v1.json
closing/supplied-root-closing-equality-v1.json
closeout/final-reconciliation-report-v1.md
closeout/explicit-confirmations-v1.json

The governing findings are:

- normative contract repair required:
  false;
- schema repair required:
  true;
- validator repair required:
  true;
- field-map/projection regeneration required:
  true;
- blocked implementation patch authorized:
  false;
- fresh implementation root required after schema repair:
  true.

──────────────────────────────────────────────────────────────────────────────
3. BLOCKED IMPLEMENTATION PACKAGE
──────────────────────────────────────────────────────────────────────────────

BLOCKED_IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-implementation-kuk4deit

Expected identity:

- device/inode:
  16777234 / 180474934
- mode:
  0700
- verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED

Candidate source:

source/package_construction_parent_v1.py

- size:
  74057
- SHA-256:
  6cb3dec3f7c72d1465ff1cbbc848a630c50fbac431f61ad548d4953b39a91ad2
- frozen:
  false
- executed:
  false
- implementation authority:
  false
- patch authority:
  false

Treat this entire root as immutable historical evidence.

Do not:

- execute the candidate;
- import the candidate;
- patch the candidate;
- copy it into the new package;
- use it to select schema semantics;
- promote its records as current validation.

It may be opened read-only only for fixed evidence and closing equality.

If opened, require exact opening/closing equality.

Retain its final disposition as:

historical_unfrozen_blocked_candidate

──────────────────────────────────────────────────────────────────────────────
4. EXACT HISTORICAL FIFTEEN-SCHEMA REGISTRY
──────────────────────────────────────────────────────────────────────────────

Authenticate the fifteen historical schema roles and identities:

1. child-process-record

- size:
  807
- SHA-256:
  955d49aa7b1e9d9e03c3fa516a3aa13c669843e2cac31f47a1b676ef5442969a

2. cleanup-result

- size:
  789
- SHA-256:
  8863af0bd3279e9f4e533422ee5d7f8f38a22a697bb4325b0405ef4f780d2c2d

3. current-export-registry

- size:
  736
- SHA-256:
  e188168d4df23d0ac72251457f5edcdf6d7e1543862f27e2856eb81c1eb29a84

4. executable-origin-registry

- size:
  630
- SHA-256:
  e0a78dd0d3ead71bd8f3e540dea4a22daee0d3fe69c018a8c9af8ee4a7820fcb

5. failure-outcome

- size:
  990
- SHA-256:
  00eb7332481b8439fb1c9c6a3b6f0f8bcb84a9f2e5cc4192e8425a134fbe99eb

6. metadata-coherence

- size:
  721
- SHA-256:
  361cb5c23bb54fe0a9bbfd38df7ebd3c88ce6b4bfa109285f916a3371ff900fb

7. normative-construction-parent

- size:
  79984
- SHA-256:
  52b76f0d558c42d5c58d40c8983dc1d49b11fcd835a2ab17439dfc7c9738b8a7

8. package-freeze

- size:
  882
- SHA-256:
  ca95e24f5989ed929d17647850e7be951f019271ea6b76066235c618bd6993e6

9. package-root-rebinding

- size:
  904
- SHA-256:
  fbd5aebd37142e229ae052c25b8ddc8321eb846dee426b97031aad0b6aa151d2

10. phase-record

- size:
  1035
- SHA-256:
  18c1930d1f14d27b447c1c814fcdd580ef93f5ff5b7f6219a8ecd03d9396a7e1

11. plan-identity-consumer-registry

- size:
  657
- SHA-256:
  7cbc025dee6a8fc5e9295982d782cbb91d9788d65450809d5f34176c143c6728

12. pointer-resolution-result

- size:
  639
- SHA-256:
  b5fa9cc3a2c6b79630d516844d290484d814c35163defb7910cdce83e9e12824

13. qualification-result

- size:
  955
- SHA-256:
  e6ae173a472b4bc44405fc6eedc38b2367a581ea01c9656e87e3056749760a1b

14. temporal-inventory

- size:
  784
- SHA-256:
  7c0b6f70dca69f4a7369c8bc6653d4999a2b740a8d29f132b84d88e09c7ecc86

15. terminal-manifest-metadata

- size:
  820
- SHA-256:
  b5cef8297ef16ee49212de32d54b01e74c550d20668a12106907aa2f124f37c3

These identities are historical inputs and supersession operands.

None remains current governing schema authority after a successful fresh repair
package.

──────────────────────────────────────────────────────────────────────────────
5. FRESH SCHEMA-REPAIR PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-schema-repair-

Immediately emit:

SCHEMA_REPAIR_ROOT=<absolute-path>

Retain before semantic work:

opening/bootstrap-start.json

Bind:

- fresh-root device/inode/mode;
- allocation method and umask;
- authoritative contract-package identity;
- schema-reconciliation identity;
- blocked implementation identity;
- exact normative-contract identity;
- exact historical fifteen-schema registry;
- schema-repair-only authority;
- normative contract change authorized:
  false;
- implementation creation authorized:
  false;
- implementation patch authorized:
  false;
- process-self-test authorized:
  false;
- construct mode authorized:
  false;
- package construction authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false.

Create directories lazily.

Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
6. NORMATIVE CONTRACT PRESERVATION
──────────────────────────────────────────────────────────────────────────────

Copy byte-for-byte:

contract/package-construction-parent-v1.json

Use:

- no-follow source open;
- stable pre/post-read fstat;
- exclusive mode-0600 destination creation;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/normative-contract-preservation-v1.json

Require:

- size:
  32038;
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19;
- byte-identical:
  true;
- semantic change:
  false;
- sole normative writer:
  true.

No task-generated record may claim a normative-contract amendment.

──────────────────────────────────────────────────────────────────────────────
7. SCHEMA VERSIONING AND ROLE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before writing revised schemas, determine from the normative contract and
current package records whether schema file paths or `$id` values are
acceptance-bearing contract facts.

Retain:

analysis/schema-versioning-and-role-preflight-v1.json

For every schema role record:

- historical package-relative path;
- historical `$id`;
- historical `$schema`;
- whether the normative contract pins:
  - role;
  - file path;
  - `$id`;
  - version string;
  - digest;
- permitted successor path;
- permitted successor `$id`;
- supersession method.

Rules:

1. The semantic role must remain unchanged.
2. The historical schema identity must remain externally bound.
3. A repaired schema must not silently reuse an incompatible globally
   authoritative `$id`.
4. Do not change the normative contract.
5. If the contract pins an exact schema path or `$id` that cannot lawfully
   identify repaired bytes, return:

   TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_REPAIR_BLOCKED

6. Otherwise use a versioned successor identity and retain an exact
   role/supersession registry.

Do not decide versioning through filename convention alone.

──────────────────────────────────────────────────────────────────────────────
8. SOLE GENERATED-RECORD REPRESENTATION AUTHORITY
──────────────────────────────────────────────────────────────────────────────

The normative contract remains the sole semantic writer.

The repaired schema set is the sole writer for serialized generated-record
shape.

Retain:

contract/generated-record-schema-role-registry-v1.json

For all fifteen roles bind:

- schema role;
- successor file path;
- successor `$id`;
- governing normative-contract pointers;
- record family;
- serialization authority:
  true;
- semantic authority:
  false;
- may redefine contract:
  false;
- may narrow contract:
  false;
- may widen authority:
  false;
- superseded historical schema identity.

Require exactly one current schema per role.

Do not create a second semantic contract.

──────────────────────────────────────────────────────────────────────────────
9. COMPLETE FOURTEEN-FAMILY FIELD FREEZE
──────────────────────────────────────────────────────────────────────────────

Using:

analysis/contract-record-family-inventory-v1.json

from the reconciliation root and the exact normative contract, retain:

analysis/generated-record-family-field-freeze-v1.json

For every one of the fourteen generated-record families freeze:

- family ID;
- governing contract pointers;
- exact required fields;
- exact optional fields;
- exact nested field names;
- exact field types;
- constants and enums;
- minimum/maximum cardinalities;
- exact role names;
- unknown-field policy;
- authority fields;
- nonauthority fields;
- cross-field rules expressible in JSON Schema;
- cross-document rules requiring documentary validators;
- fields whose representation is schema-owned but semantically neutral.

A schema-owned representation field must be explicitly classified:

- serialization-only;
- no authority;
- cannot alter a contract fact;
- one authoritative schema writer.

If any record-family semantic requirement is genuinely ambiguous under the
normative contract, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_REPAIR_BLOCKED

Do not invent a semantic choice.

──────────────────────────────────────────────────────────────────────────────
10. REVISE ALL FIFTEEN SCHEMAS
──────────────────────────────────────────────────────────────────────────────

Generate a repaired current schema for every one of the fifteen roles.

All repaired schemas must:

- declare Draft 2020-12 correctly;
- pass Draft 2020-12 metaschema validation;
- use closed object semantics appropriate to the full evaluated object;
- permit every contract-required field;
- reject every contract-forbidden field or value expressible in schema;
- reject unknown fields;
- enforce exact constants and enums where the contract is exact;
- enforce nonempty registries where required;
- enforce exact cardinality where required;
- contain no placeholder empty-object schema for a contract-populated object;
- contain no invalid empty `prefixItems`;
- contain no duplicate JSON keys;
- contain no ambiguous `$ref`/`allOf` closure interaction;
- avoid `additionalProperties:false` at a level that prevents fields introduced
  by valid applicators;
- use `unevaluatedProperties:false` only with correct Draft 2020-12 evaluated
  property semantics.

Do not merely add the 39 excluded fields.

Repair both:

- narrowness defects;
- broad under-enforcement defects.

──────────────────────────────────────────────────────────────────────────────
11. IMMEDIATE JOINT-UNSATISFIABILITY REPAIRS
──────────────────────────────────────────────────────────────────────────────

At minimum, implement these exact repairs:

A. Child-process record

`prelaunch` must permit and require the contract’s eight custody members.

`outcome` must permit and require the contract’s seven outcome members.

Both nested objects must reject unknown fields.

B. Current export registry

`exports` must permit and require exactly the seven semantic role keys.

It must include exactly one:

`target-audit-plan`

entry.

Every export identity must use the exact contract-required identity shape.

C. Package-root rebinding

`successor_plan_identity` must permit and require exactly:

- path;
- sha256;
- size.

D. Phase record

The top-level record must permit and require:

`required_actions`

with the contract-required type and cardinality.

E. Qualification result

It must permit and require:

- `raw_posture.payload_imported`;
- `positive_assertions.payload_imported_is_false`;
- top-level `plan_identity`.

Use the authoritative spelling:

`positive_assertions`

Do not use `/assertions`.

Require:

- `payload_imported` exact Boolean false;
- `payload_imported_is_false` exact Boolean true;
- `plan_identity` exact path/SHA-256/size shape.

F. Package freeze

`plan_identity` must permit and require exactly:

- path;
- sha256;
- size.

`export_identities` must permit and require exactly the seven semantic roles.

It must constrain package authority and terminal closure to the contract’s
preterminal false posture.

G. Normative-construction-parent schema

Correct all 21 Draft violations.

Remove or replace every invalid empty `prefixItems`, including the sites
covering:

- eighteen phase `cleanup_obligations` arrays;
- C00 `prerequisites`;
- `premanifest_empty_directories/0`;
- `terminal_empty_directories`.

Preserve the normative contract’s accepted values and ordering.

──────────────────────────────────────────────────────────────────────────────
12. HARDEN THE OTHER EIGHT SCHEMAS
──────────────────────────────────────────────────────────────────────────────

The following eight historical schemas were jointly satisfiable but
under-enforced:

- cleanup-result;
- executable-origin-registry;
- failure-outcome;
- metadata-coherence;
- plan-identity-consumer-registry;
- pointer-resolution-result;
- temporal-inventory;
- terminal-manifest-metadata.

Revise all eight now.

Do not defer them to another implementation-blocking tranche.

At minimum enforce:

A. Cleanup result

- exact required sets;
- set-equality posture;
- no duplicate roots;
- pass cannot be true when sets differ;
- no survivor posture.

B. Executable-origin registry

- nonempty entries;
- exact required entry fields;
- unique roles and paths;
- frozen/current posture;
- no historical executable current;
- no unregistered origin.

C. Failure outcome

- explicit terminal failure;
- no success authority;
- blocker and effect fields;
- cleanup disposition;
- no package authority.

D. Metadata coherence

- exact success posture;
- transitive resolution true;
- package authority and terminal closure false before seal;
- current plan binding.

E. Consumer registry

- exactly four consumers;
- exact document/pointer/role fields;
- exact unique roles;
- complete true;
- no duplicates or empty rows.

F. Pointer-resolution result

- exactly four rows;
- every row resolved;
- exact RFC 6901 tokens;
- resolved value and expected value;
- all equal true;
- no unresolved row;
- aggregate success true.

G. Temporal inventory

- root and identity;
- nonempty entries;
- exact exclusions;
- future manifest directory;
- verified true;
- no invalid object posture.

H. Terminal-manifest metadata

- root and identity;
- entries and exclusions;
- exact terminal posture;
- no-write-after-seal true;
- no empty/symlink/special/multilink/cache posture.

Cross-document or filesystem facts that JSON Schema cannot prove must remain
explicit documentary-validator obligations.

Do not fake those facts through schema constants alone.

──────────────────────────────────────────────────────────────────────────────
13. HISTORICAL SCHEMA SUPERSESSION
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/generated-record-schema-supersession-v1.json

For every role bind:

- historical schema path;
- historical size/SHA-256;
- historical `$id`;
- historical status:
  defective-noncurrent;
- exact defect classes;
- successor schema path;
- successor size/SHA-256;
- successor `$id`;
- normative contract unchanged;
- semantic role unchanged;
- serialized representation repaired;
- current:
  true only for successor.

Historical schema bytes remain immutable evidence.

Do not copy a historical schema to a current path unchanged.

──────────────────────────────────────────────────────────────────────────────
14. DRAFT 2020-12 METASCHEMA GATE
──────────────────────────────────────────────────────────────────────────────

Validate every repaired schema using a current Draft 2020-12 metaschema
implementation.

Retain:

validation/fifteen-schema-metaschema-validation-v1.json

For every schema bind:

- path;
- size;
- SHA-256;
- `$schema`;
- `$id`;
- validator implementation and version;
- result;
- complete errors.

Require:

- fifteen schemas evaluated;
- fifteen passes;
- zero errors.

No repaired schema may proceed to witness validation until all fifteen pass.

──────────────────────────────────────────────────────────────────────────────
15. MINIMAL CONTRACT-COMPLIANT WITNESSES
──────────────────────────────────────────────────────────────────────────────

Construct a minimal contract-compliant witness for each of the fourteen
generated-record families.

Retain:

validation/minimal-contract-witness-matrix-v2.json

For every witness bind:

- family;
- governing contract pointers;
- complete instance;
- why every field is present;
- why every omitted field is optional;
- governing repaired schema;
- validation result.

Require:

- fourteen witnesses;
- fourteen schema-valid results;
- zero validation errors.

No typed placeholder may stand in for a contract-required nested object.

──────────────────────────────────────────────────────────────────────────────
16. MINIMAL SCHEMA-COMPLIANT WITNESSES
──────────────────────────────────────────────────────────────────────────────

Independently construct a minimal schema-valid witness for every generated
record family without using the contract witness as the starting object.

Then validate every witness against the normative contract using a separate
documentary validator.

Retain:

validation/minimal-schema-witness-matrix-v2.json

Require:

- fourteen schema-valid witnesses;
- every witness contract-valid;
- no schema-valid contract-forbidden baseline;
- zero jointly unsatisfiable family;
- zero under-enforced baseline family.

A single passing witness is not sufficient to prove universal enforcement; it
is one required gate alongside mutation matrices.

──────────────────────────────────────────────────────────────────────────────
17. CONTRACT-REQUIRED FIELD NEGATIVE MATRIX
──────────────────────────────────────────────────────────────────────────────

For every generated-record family, mutate the valid contract witness to cover:

- each required field removed;
- each required field mistyped;
- every exact constant changed;
- unknown field added at every closed object level;
- empty required registry;
- duplicate logical role;
- stale identity;
- contradictory success/authority posture;
- forbidden authority true;
- missing nonauthority;
- invalid cardinality;
- wrong nested object shape.

Retain:

validation/generated-record-schema-negative-matrix-v1.json

Require:

- literal unique case names;
- complete expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

The case registry must include all ten historical contradiction sites, all 39
historically excluded atomic members, and the under-enforcement cases from all
eight additional schemas.

──────────────────────────────────────────────────────────────────────────────
18. CONTRADICTION-REGRESSION MATRIX
──────────────────────────────────────────────────────────────────────────────

Freshly rerun the exact 33-case registry from:

validation/contract-schema-satisfiability-matrix-v1.json

in the reconciliation root.

Extend it with repaired-schema positive and negative cases, including:

- all ten semantic contradiction sites now accepted when valid;
- all 39 required fields accepted in their correct locations;
- malformed alternatives rejected;
- all 21 old Draft violations absent;
- `$ref` and `allOf` closure mutations;
- `unevaluatedProperties:false` mutations;
- empty-object placeholder mutations;
- wrong-schema selection;
- missing witness generation.

Retain:

validation/contract-schema-satisfiability-matrix-v2.json

Require zero false outcomes, mismatches, or skips.

──────────────────────────────────────────────────────────────────────────────
19. CONTRACT/SCHEMA FIELD MAP V2
──────────────────────────────────────────────────────────────────────────────

Regenerate:

analysis/contract-schema-field-map-v2.json

It must contain two linked layers:

A. Normative contract layer

- all 766 normative contract leaves;
- exact contract pointers;
- types;
- constants/enums;
- authority roles.

B. Generated-record enforcement layer

- every contract-required generated-record field;
- record family;
- repaired schema pointer;
- required/optional status;
- type;
- const/enum;
- unknown-field rule;
- cardinality;
- cross-field rule;
- documentary-validator requirement.

Require:

- all 766 contract leaves accounted for;
- every record-family requirement mapped;
- no unresolved field;
- no schema field without a classified source:
  contract-semantic,
  schema-owned-serialization-only,
  or documentary evidence;
- no implementation-consistency claim.

──────────────────────────────────────────────────────────────────────────────
20. REVISE DOCUMENTARY VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Create fresh current validators that include joint satisfiability.

At minimum revise:

- contract/schema validation;
- construction-parent contract mutation matrix;
- independent contract validator;
- producer satisfiability validator;
- independent satisfiability validator;
- record-family witness validator;
- schema negative-matrix validator;
- phase/state-machine projection validator;
- output-registry validator;
- confirmation-evidence-map validator.

The prior validators remain historical evidence and may not be promoted as
current results.

Each current validator must bind:

- exact normative contract identity;
- exact fifteen repaired schema identities;
- exact witness identities;
- exact case registry;
- complete result.

──────────────────────────────────────────────────────────────────────────────
21. FRESH INDEPENDENT SCHEMA VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement an independent validator that imports neither:

- schema producer helpers;
- first witness generator;
- first mutation helper;
- producer expected-result maps.

It must independently:

- strict-parse the contract;
- strict-parse all repaired schemas;
- metaschema-validate all fifteen;
- reconstruct all fourteen record families;
- build its own witnesses;
- validate contract witnesses against schemas;
- validate schema witnesses against the contract;
- run its own negative registry;
- verify zero historical contradictions;
- verify under-enforcement closure;
- verify schema supersession.

Retain:

validation/independent-generated-record-schema-validator-v1.json

Require zero errors and exact agreement on family and contradiction counts.

──────────────────────────────────────────────────────────────────────────────
22. CONTRACT PACKAGE REVALIDATION
──────────────────────────────────────────────────────────────────────────────

Against the unchanged normative contract and repaired schema set, rerun:

- strict contract parse;
- normative-contract schema validation;
- authority/nonauthority checks;
- CLI/mode checks;
- C00–C19 phase-graph checks;
- seven semantic export-role checks;
- exactly four plan-consumer policy;
- raw-posture/positive-assertion policy;
- terminal-closure policy;
- failure/retry policy;
- 57-case normative-contract mutation matrix;
- fresh independent contract validator.

Require every historical bounded-lane valid claim to remain valid.

Do not claim implementation consistency.

──────────────────────────────────────────────────────────────────────────────
23. BLOCKED IMPLEMENTATION LINEAGE
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/blocked-implementation-and-schema-repair-v1.json

Bind:

- blocked implementation-package identity;
- blocked candidate identity;
- implementation never executed;
- implementation never frozen;
- source map documentary only;
- ten semantic contradiction sites;
- 39 atomic field conflicts;
- 21 Draft violations;
- historical candidate disposition:
  historical-unfrozen-blocked-candidate;
- current patch authority:
  false;
- future implementation must use a fresh root after this schema package is
  independently accepted.

Do not copy the candidate source.

──────────────────────────────────────────────────────────────────────────────
24. NEW CONTRACT-PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Retain:

opening/contract-schema-package-authority-v1.json

Before terminal closure it must state:

- normative contract unchanged:
  true;
- repaired schema set current:
  false;
- implementation present:
  false;
- implementation authority:
  false;
- joint satisfiability:
  pending or passed as actually observed;
- terminal closure:
  false;
- package authority:
  false.

Do not create current schema-package authority before terminal manifests close.

──────────────────────────────────────────────────────────────────────────────
25. NO IMPLEMENTATION
──────────────────────────────────────────────────────────────────────────────

Do not create or copy:

- construction-parent implementation source;
- executable implementation skeleton;
- process-self-test implementation;
- construct-mode implementation;
- target-audit harness package exports.

Allowed executable code is limited to audit-owned:

- schema generators;
- documentary validators;
- witness generators;
- mutation drivers;
- inventory and manifest generators.

No process-self-test.
No construct mode.
No target audit.
No runtime validation.

──────────────────────────────────────────────────────────────────────────────
26. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for:

- authoritative contract package;
- schema reconciliation root;
- blocked implementation package.

Any other supplied root opened also requires exact equality.

Do not modify or clean supplied roots.

For every audit-owned temporary validation root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
27. PRETERMINAL REPORTING
──────────────────────────────────────────────────────────────────────────────

Before temporal inventory, finalize:

closeout/final-schema-repair-report-v1.md
closeout/explicit-confirmations-v1.json

The report must state:

- normative contract unchanged;
- all fifteen historical schemas superseded;
- exact current fifteen-schema identities;
- six formerly unsatisfiable families now satisfiable;
- all fourteen family baselines jointly satisfiable;
- all fourteen schemas hardened against contract-forbidden baselines;
- 21 Draft violations repaired;
- validators regenerated;
- implementation absent;
- fresh implementation still required.

No current authority claim before closure.

──────────────────────────────────────────────────────────────────────────────
28. TEMPORAL FINAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final, generate:

closeout/temporal-final-inventory-v1.json

Require:

- root represented;
- all current directories represented;
- all current nonmanifest regular files represented;
- exact exclusions:
  - temporal inventory itself;
  - future manifest A;
  - future manifest B;
- reserved manifest directory declared;
- no symlink;
- no special object;
- no multi-link file;
- directories 0700;
- files 0600;
- no cache or bytecode;
- no empty directory except reserved premanifest `manifest/`.

Reopen and verify before manifest generation.

──────────────────────────────────────────────────────────────────────────────
29. TERMINAL MANIFEST CLOSURE
──────────────────────────────────────────────────────────────────────────────

After temporal-inventory verification:

1. Ensure reserved `manifest/` exists, mode 0700.
2. Independently generate manifest A.
3. Independently generate manifest B.
4. Require generated bytes identical.
5. Exclusively write/fsync/close A.
6. Exclusively write/fsync/close B.
7. Fsync manifest directory.
8. Reopen both no-follow.
9. Verify identities and generated-byte equality.
10. Require A equals B.
11. Independently reproject the whole root.
12. Require reprojection equals A and B.
13. Require no empty directory.
14. Require no symlink, special object, or multi-link file.
15. Require all modes 0700/0600.
16. Require no cache or bytecode.

After terminal closure, perform no filesystem write.

Do not write a later verdict or confirmation record.

──────────────────────────────────────────────────────────────────────────────
30. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_PACKAGE_REPAIRED

only when:

- supplied roots authenticate and close;
- normative contract is byte-identical;
- all fifteen historical schemas authenticate;
- all fifteen repaired schemas metaschema-validate;
- all fourteen contract witnesses satisfy schemas;
- all fourteen schema witnesses satisfy the contract;
- zero jointly unsatisfiable family remains;
- zero under-enforced baseline family remains;
- all ten contradiction sites are resolved;
- all 39 fields are admitted correctly;
- all 21 Draft violations are gone;
- schema negative matrix passes;
- contradiction-regression matrix passes;
- field map V2 closes;
- current documentary validators pass;
- independent schema validator passes;
- normative-contract revalidation passes;
- blocked implementation remains historical and noncurrent;
- no implementation exists;
- temporal inventory verifies;
- terminal manifests verify;
- no write follows closure.

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_REPAIR_BLOCKED

when:

- a normative-contract amendment becomes necessary;
- record representation remains semantically ambiguous;
- schema versioning cannot be resolved without contract change;
- any family remains jointly unsatisfiable;
- schema hardening requires authority not provided by the contract;
- documentary validators cannot close.

Return:

CONTRACT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- closing inequality;
- normative-contract byte drift;
- historical-schema identity mismatch;
- unauthorized semantic drift;
- stale current schema binding;
- terminal closure failure;
- write after closure.

──────────────────────────────────────────────────────────────────────────────
31. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh schema-package root identity
3. Authoritative contract-package identity and closure
4. Schema-reconciliation identity and closure
5. Blocked implementation identity and closure
6. Normative contract preservation result
7. Historical fifteen-schema registry
8. Schema versioning/role result
9. Current fifteen-schema role registry
10. Fourteen-family field freeze
11. Historical contradiction summary
12. Repaired child-process schema
13. Repaired current-export-registry schema
14. Repaired normative-construction-parent schema
15. Repaired package-freeze schema
16. Repaired package-root-rebinding schema
17. Repaired phase-record schema
18. Repaired qualification-result schema
19. Repaired other eight schemas
20. Schema supersession lineage
21. Fifteen-schema metaschema result
22. Minimal contract-witness matrix
23. Minimal schema-witness matrix
24. Generated-record negative matrix
25. Contradiction-regression matrix
26. Contract/schema field map V2
27. Revised documentary validators
28. Independent schema validator
29. Normative-contract revalidation
30. Blocked implementation lineage
31. Confirmation no implementation exists
32. Supplied-root closing equality
33. Fixture cleanup
34. Temporal inventory identity
35. Manifest A identity
36. Manifest B identity
37. Independent terminal reprojection
38. Terminal membership and modes
39. No-write-after-closure
40. Remaining uncertainty and nonclaims
41. Explicit confirmations

Required confirmations:

AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
NORMATIVE_CONTRACT_SEMANTICS_UNCHANGED
ALL_FIFTEEN_HISTORICAL_SCHEMA_IDENTITIES_AUTHENTICATED
ALL_FIFTEEN_HISTORICAL_SCHEMAS_SUPERSEDED
EXACTLY_ONE_CURRENT_SCHEMA_PER_ROLE
SCHEMA_SERIALIZATION_AUTHORITY_CLOSED
SCHEMAS_DO_NOT_REDEFINE_CONTRACT
SCHEMAS_DO_NOT_NARROW_CONTRACT
SCHEMAS_DO_NOT_WIDEN_AUTHORITY
ALL_FIFTEEN_REPAIRED_SCHEMAS_METASCHEMA_VALID
ALL_TWENTY_ONE_DRAFT_VIOLATIONS_REPAIRED
ALL_TEN_SEMANTIC_CONTRADICTION_SITES_REPAIRED
ALL_THIRTY_NINE_REQUIRED_FIELDS_ADMITTED
CHILD_PRELAUNCH_FIELDS_ADMITTED_AND_ENFORCED
CHILD_OUTCOME_FIELDS_ADMITTED_AND_ENFORCED
SEVEN_EXPORT_ROLES_ADMITTED_AND_ENFORCED
SUCCESSOR_PLAN_IDENTITY_ADMITTED_AND_ENFORCED
PHASE_REQUIRED_ACTIONS_ADMITTED_AND_ENFORCED
PAYLOAD_IMPORTED_RAW_POSTURE_ADMITTED_AND_ENFORCED
PAYLOAD_IMPORTED_POSITIVE_ASSERTION_ADMITTED_AND_ENFORCED
QUALIFICATION_PLAN_IDENTITY_ADMITTED_AND_ENFORCED
PACKAGE_FREEZE_PLAN_IDENTITY_ADMITTED_AND_ENFORCED
PACKAGE_FREEZE_EXPORT_IDENTITIES_ADMITTED_AND_ENFORCED
OTHER_EIGHT_SCHEMAS_HARDENED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_PASSED
CONTRADICTION_REGRESSION_MATRIX_PASSED
CONTRACT_SCHEMA_FIELD_MAP_V2_CLOSED
DOCUMENTARY_VALIDATORS_REGENERATED
INDEPENDENT_SCHEMA_VALIDATOR_PASSED
NORMATIVE_CONTRACT_REVALIDATION_PASSED
BLOCKED_IMPLEMENTATION_REMAINS_NONCURRENT
BLOCKED_IMPLEMENTATION_NOT_PATCHED
NO_CONSTRUCTION_PARENT_IMPLEMENTATION_CREATED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_HARNESS_PACKAGE_CONSTRUCTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SCHEMA_PACKAGE_TEMPORAL_INVENTORY_CREATED
SCHEMA_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
SCHEMA_PACKAGE_MANIFEST_A_CREATED
SCHEMA_PACKAGE_MANIFEST_B_CREATED
SCHEMA_PACKAGE_MANIFESTS_BYTE_IDENTICAL
SCHEMA_PACKAGE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After
`TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_PACKAGE_REPAIRED`,
run a fresh independent audit of the schema package. Only after that audit
accepts the package should a new construction-parent implementation be created
in a new root.

Do not patch the historical blocked implementation candidate.
```

## Decision

Repair and reseal the schema package before any further implementation attempt. Preserve the normative contract exactly, supersede all fifteen schemas, and add joint satisfiability as a mandatory acceptance gate.

**Source:** Codex’s `CONSTRUCTION_PARENT_SCHEMA_SATISFIABILITY_RECONCILED_SCHEMA_REPAIR_REQUIRED` report in the current turn.  
**Confidence:** 1.00 that implementation must remain blocked; 0.99 that the normative contract should remain byte-identical; 0.98 that all fifteen schemas—not only the seven immediately unsatisfiable ones—should be repaired before implementation restarts.
