Here is Codex's response:

# AUDIT\_PROVENANCE\_MISMATCH

Fresh audit root:

`/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99`

Carrier 0002 failed the mandatory launcher/wrapper self-check. The launcher successfully reached the wrapper through same-process `execve`, but constructed an incomplete wrapper CLI: it omitted the required `--expected-wrapper-sha256` argument.

The wrapper exited `2` during argument parsing:
```
phase_runner.py: error: the following arguments are required: --expected-wrapper-sha256
```

Consequently:

- No Carrier 0002 phase-start or phase-outcome record exists.
- The no-op payload was not read, compiled, or executed.
- No supplied root or target content was inspected.
- The child-recorder and request-schema causals were not reached.
- No direct auditors were created.
- No alternate launch was attempted.
- No supplied root, candidate index, wrapper source, contract, Plan, runtime surface, or prior audit root was mutated.
- This root is now immutable, nonqualifying process-failure evidence and must not be resumed.

Retained bootstrap artifacts include:

- [bootstrap-start.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99/opening/bootstrap-start.json)
- [bootstrap-outcome.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99/opening/bootstrap-outcome.json)
- [wrapped-carrier-launch-contract.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99/opening/wrapped-carrier-launch-contract.json)
- [wrapped\_carrier\_launcher.py](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99/provenance/wrapped_carrier_launcher.py)
- [carrier-0002.request.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99/provenance/carrier-0002.request.json)
```
CANONICAL_LAUNCH_CONTRACT_RETAINED — CONFIRMED
CANONICAL_LAUNCH_CONTRACT_HASH_BOUND — CONFIRMED
WRAPPED_CARRIER_LAUNCHER_RETAINED — CONFIRMED
WRAPPED_CARRIER_LAUNCHER_HASH_BOUND — CONFIRMED
LAUNCHER_INVOKED_THROUGH_PINNED_PYTHON — CONFIRMED
LAUNCHER_USED_SAME_PID_EXEC_TO_WRAPPER — ATTEMPTED; END-TO-END SELF-CHECK NOT ESTABLISHED
PER_CARRIER_REQUESTS_CONTAIN_NO_INVARIANT_OVERRIDES — CONFIRMED FOR CARRIER 0002
WRAPPER_SHA_SOURCED_ONLY_FROM_LAUNCH_CONTRACT — NOT SATISFIED
FIXED_PATH_SOURCED_ONLY_FROM_LAUNCH_CONTRACT — NOT ESTABLISHED
REQUEST_SCHEMA_DRIFT_CAUSALS_PASSED — NOT EXECUTED
WRAPPER_RETAINED_MODE_0600 — CONFIRMED
WRAPPER_NOT_EXECUTED_DIRECTLY — CONFIRMED
ALL_WRAPPED_CARRIERS_USED_SAME_LAUNCH_CONTRACT — NOT ESTABLISHED
FAILED_AUDIT_ROOT_NOT_RESUMED — CONFIRMED
FAILED_AUDIT_ROOT_NOT_MUTATED — CONFIRMED
NESTED_SUBAGENTS_CREATED — 0
```
