## Assessment

`REPAIR10G_RECONNAISSANCE_PARTIAL` is the correct formal verdict, but the **design is not materially partial**. Codex completed the four required perspectives, reconciled their findings into a coherent architecture, preserved the repository baseline, and froze the implementation and audit sequence. The sole disqualifying event was the unintended creation of:

```text
/tmp/r10g-e2-rg.txt
size: 77,902 bytes
sha256: a777ef684345b642904eb0ed135503dce436dffa28326a9295964978849deac0
```

That is a protocol breach in a read-only reconnaissance turn. It does not invalidate the custody, barrier, successor, A/B, or audit-venue design. The operating protocol requires reconnaissance to stop without editing, close all explorers, verify the unchanged baseline, and return a readiness verdict before implementation begins.  Exploration and mutation are intentionally separated into different turns. 

There is no reason to repeat the four-explorer investigation. The right next step is a **narrow reconciliation turn** that removes only the exact audit-created scratch file, rechecks the baseline, adopts the frozen design unchanged, and upgrades the verdict to `REPAIR10G_RECONNAISSANCE_READY`.

## Design decisions I adopt

The frozen design is suitable for implementation with these interpretations made explicit:

- **Universal custody remains the target.** We are not narrowing the contract merely to preserve fallback raw-FD paths.
- Owned descriptors must be **opaque, pointer-owned handles**. Production code must not pass ownership by copying value structs, recover ownership from an integer FD, or dispose through a raw FD.
- Unknown or unregistered descriptors are blockers. They must not be opportunistically adopted and closed.
- Private evidence schemas may receive new `repair10g` versions. The prohibition applies to public/product schemas, not source-external evidence records.
- The documented causal order governs error reporting even when dependency-required cleanup executes earlier physically.
- Phase F remains historical evidence only. Fresh audits must rerun A/B qualification.
- `refs/codex/turn-diffs/**` is not silently ignored. A fallback project-attached audit must prove that every excluded ref/object belongs solely to the host’s self-recording delta. A detached audit remains preferred.
- The scratch-file deletion is a one-time reconciliation effect, not part of implementation.

This is consistent with the project’s narrower planning/evidence boundary: planning work does not widen ES contracts or make generated evidence authoritative. 

## Prompt for Codex

Use this in the same reconnaissance conversation. Keep it read-only with the single expressly authorized external cleanup.

```text
REPAIR 10G — RECONCILE EXTERNAL SCRATCH SIDE EFFECT AND FINALIZE THE FROZEN RECONNAISSANCE

Objective

Reconcile the sole protocol breach from the preceding Repair 10G
reconnaissance, verify that the exact repository and immutable evidence
baseline remains unchanged, adopt the already-frozen Repair 10G design, and
return the final readiness verdict.

Do not repeat the four-explorer investigation. Do not create subagents.

This is not implementation.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected repository baseline

branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

upstream:
absent

candidate T:
624ece774f7cdc01a9abace85785c0418f66cdda

inventory SHA-256:
65280783ea3149589912cf589caf6d52ba7a1eb45a324c1141544da526ab1763

membership:
389 total
375 tracked
14 nonignored untracked
21 tracked modifications

expected staged/deleted/renamed/unmerged:
0/0/0/0

index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

Immutable lineage

Phase F:
/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-f-closure-q4n8vz

Phase F manifest:
cf38650361ab8def4deea41726893ee0c8017406d4ef0d3ebcbd7473de6e9726

Recovery capture:
/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-624ece774f7c-q4n8vz-r1

Recovery manifest:
d63f41db3435ef250da00f4ed6d398674e15d658ba5ec41de3b13e28e9834b0a

Recovered ZIP:
/Users/ds/Downloads/ES-T2AP-repair10-integrated-624ece774f7c-q4n8vz-r1.zip

Recovered ZIP SHA-256:
b6f3a3a207a997539050d11e89a26ff8bfeccce09d7b1d5df732088ea51e5fa0

Recovered handoff:
/Users/ds/Downloads/ES-T2AP-repair10-integrated-624ece774f7c-q4n8vz-r1-audit-handoff.md

Recovered handoff SHA-256:
2b89ff15ba1322523f6a5e1c14770dba7d1c2dde23e903d3d1ff7604059fb824

Posture

No repository, Git-administration, source, evidence, ZIP, handoff, or Phase F
mutation is authorized.

No test, build, formatter, snapshot, provenance capture, implementation,
staging, commit, push, installation, live route, remote action, or network
access is authorized.

Do not create temporary files.

Do not use subagents.

The only authorized mutation is the guarded removal of the exact
reconnaissance-created external scratch file described below.

Authorized scratch reconciliation

Lexical path:
/tmp/r10g-e2-rg.txt

Expected:
size: 77902
SHA-256:
a777ef684345b642904eb0ed135503dce436dffa28326a9295964978849deac0

Before unlinking:

1. Resolve the lexical path physically without following an unexpected
   intermediate or final symlink.
2. Require the physical target to be the expected macOS private-temp spelling
   of that exact basename.
3. Open or inspect it no-follow.
4. Require:
   - regular file;
   - current user ownership;
   - link count one;
   - size 77902;
   - exact SHA-256 above;
   - no alternate hardlink;
   - no directory, symlink, FIFO, socket, or device substitution.
5. Do not print, summarize, parse, or expose its contents.
6. If any identity differs, do not delete it. Stop with:
   REPAIR10G_RECONCILIATION_BLOCKED

If the identity matches:

1. Unlink that exact file only.
2. Do not remove or traverse its parent directory.
3. Verify the exact lexical and physical path are absent.
4. Record the containing temporary-directory timestamp change as the expected
   consequence of this expressly authorized unlink.
5. Do not search for or delete any similarly named files.

Baseline revalidation

After the exact scratch removal:

1. Reverify the repository baseline using the same nonmutating,
   optional-lock-free procedure used in the preceding reconnaissance.
2. Reverify candidate T, source inventory, membership, index digest, branch,
   HEAD, parent, upstream absence, and staged/deleted/renamed/unmerged posture.
3. Reverify Phase F and recovery manifests read-only.
4. Confirm no new repository, Git-administration, evidence, ZIP, handoff, or
   source mutation occurred.
5. Confirm no subagent remains active.
6. Confirm no other temporary artifact was created by this turn.

Frozen design adoption

Adopt sections 1–15 of the preceding
REPAIR10G_RECONNAISSANCE_PARTIAL report without substantive change.

Make these interpretations explicit in the final reconciliation report:

- Owned descriptor handles are opaque and pointer-owned.
- Production ownership is never transferred by copying a value handle.
- No production disposition API accepts a raw integer FD.
- activeByFD is a collision guard only, never an ownership lookup.
- Unknown or unregistered descriptors block; they are not adopted or closed.
- Repeated or concurrent disposal returns the stored terminal disposition and
  exact stored cause without another close.
- Private Repair 10G evidence schemas may be versioned; no public or product
  schema may change.
- The documented causal order governs the private error chain even when
  dependency-required cleanup physically occurs earlier.
- Phase F captions cannot qualify Repair 10G controls.
- Fresh A/B must be rerun by implementation validation and again where
  required by the independent audit.
- A detached/projectless independent audit is preferred.
- A project-attached fallback may exclude only fully adjudicated
  refs/codex/turn-diffs deltas and their exclusively reachable objects; it may
  not exclude generic refs, objects, packs, index, configuration, or
  candidate-authoritative state.

Do not expand or redesign the frozen implementation plan.

Required report

Return:

1. Scratch-file opening identity.
2. Exact unlink disposition.
3. Verification that the scratch path is absent.
4. Repository and immutable-evidence opening/closing identities.
5. Statement that the preceding four-explorer findings and synthesis are
   adopted unchanged, subject only to the explicit interpretations above.
6. Statement that implementation remains a separate parent-only,
   workspace-write turn.
7. Statement that independent audit remains a later fresh read-only
   conversation.
8. All deviations or uncertainties.

Final verdict

Return exactly one:

REPAIR10G_RECONNAISSANCE_READY

or, on any mismatch:

REPAIR10G_RECONCILIATION_BLOCKED
```

## What follows after `READY`

Do not run the explorers again. Switch the same Codex parent to workspace-write and authorize the parent-only implementation of the frozen plan. No subagents should exist during mutation. That separation is the prescribed workflow: the parent implements and validates, while a fresh later conversation performs the independent audit. 

The new implementation bytes will require a new provenance target and a new audit; exact provenance binds everyone to the same bytes but does not itself establish correctness or sufficient validation. 

### Sources

- Codex Repair 10G reconnaissance response supplied in this turn.
- Governed Execution Codex Subagent Operating Protocol. 
- Milestone 0 MVP Claim Freeze. 
- Governed Execution Provenance Guidance. 

**Confidence:** 0.98 that the frozen design does not require another explorer pass; 0.99 that implementation should remain blocked until the exact scratch artifact is reconciled; 0.95 that the frozen custody and successor designs address the audit’s underlying causes rather than merely its individual symptoms.
