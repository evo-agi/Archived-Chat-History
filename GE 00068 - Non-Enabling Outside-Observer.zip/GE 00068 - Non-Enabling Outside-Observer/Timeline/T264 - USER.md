Here is Codex's response:

# AUDIT\_PROVENANCE\_MISMATCH

Audit root:

`/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-independent-audit-1aq5vxm8`

The mandatory process-recorder causal failed before `process-0001.start.json` could be created. The runner attempted to derive its source identity using `__file__`, but the bootstrap-loaded runner had no `__file__` binding and raised:
```
NameError: name '__file__' is not defined
```

Per §2, this requires immediate termination with `AUDIT_PROVENANCE_MISMATCH`.

No candidate, supplied-root, V3 semantic, plan-equivalence, source-closure, or correctness inspection occurred. No auditors were started and no runtime validation, tests, product code, Git reads, or live services were invoked.

Audit-created material is limited to the fresh root, required directories, `opening/bootstrap.json`, `private/process_runner.py`, and `private/process-runner.lock`. The failed root remains retained as process-failure evidence. Closing equality, cleanup, and the required process-continuity confirmations cannot be claimed.

Confirmed from the attempted operation:

- `CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED`
- `CANDIDATE_INDEX_MUTATION_NOT_PERFORMED`
- `STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED`
- `BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED`
- `VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED`
- `V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED`
- `VALIDATION_CUSTODY_V3_CAPSULE_MUTATION_NOT_PERFORMED`
- `OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED`
- `B_SOURCE_BYTES_NOT_MODIFIED`
- `B_LOGICAL_MODES_NOT_MODIFIED`
- `B_SOURCE_T_NOT_MODIFIED`
- `B_GIT_TREE_NOT_MODIFIED`
- `VALIDATION_COMMAND_SET_NOT_REDUCED`
- `VALIDATION_COMMAND_SEMANTICS_NOT_CHANGED`
- `RUNTIME_VALIDATION_NOT_RERUN`
- `PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED`

Not confirmable:

- `PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS`
- `MISSING_EXECUTABLE_CAUSAL_RECORDED`
- All target-level qualification findings and closing-equality claims.
