## Engineering assessment

The Candidate 2 path is finished.

The replay did recover the evidence that the earlier qualification attempt lost, and that evidence consistently identifies a **production output-ordering defect**:

- Both Candidate 2 rehearsals exited successfully and otherwise closed their substantive validation lanes.
- Both retained temporal inventories had 66 entries.
- The independently observed final projection required 67 entries.
- The sole omitted object was the `closeout/` directory.
- Candidate 2 created `closeout/` while writing the temporal inventory, after it had already projected the purported preterminal namespace.
- The independently authored rehearsal validator found the same defect in both roots.
- The two rehearsals were otherwise semantically equal after permitted physical normalization.

The replay capsule then repeated the same class of defect in its own closure. That makes the replay nonqualifying, but it does not create a plausible path back to Candidate 2. The governing disposition is already explicit: `RETIRE_CANDIDATE_QUALIFICATION_LINEAGE`, with no further Candidate 2 replay.

Another source implementation attempt would be premature. The repeated failures show that the missing authority is now an **executable implementation contract for namespace and evidence lifecycle**, not another code patch. Before writing a new clean parent, the next tranche should freeze a subordinate Generation 2 implementation contract that establishes:

- the exact future subject namespace before temporal projection;
- all directories, including `closeout/` and `manifest/`, before the projection boundary;
- one phase/function writer for every final path;
- the documentary-evidence dependency order;
- typed JSON observation and sentinel handling;
- process and failure custody;
- two independent manifest implementations;
- complete qualification and independent-audit requirements.

This is not another retrospective reconciliation and not another Candidate 2 repair. Candidate 2 and the failed replay become defect-catalogue evidence only.

```text
FREEZE THE GENERATION-2 IMPLEMENTATION CONTRACT FOR THE
SCHEMA-SUBJECT RECONSTRUCTION PARENT

This task creates a fresh, authoritative, source-external implementation
contract package for a new Generation-2 schema-subject reconstruction parent.

It creates no reconstruction-parent implementation source.

It does not patch, replay, resume, qualify, freeze, or reuse Candidate 2.

It does not construct the current schema subject.

It does not perform another historical provenance reconciliation.

The governing forward disposition is:

RETIRE_CANDIDATE_QUALIFICATION_LINEAGE

Candidate 2 and its qualification lineage are historical defect evidence only.

This task freezes the complete operating model, state machine, namespace,
evidence lifecycle, writer ownership, process custody, validation architecture,
and acceptance evidence required before a new clean implementation may begin.

It does not:

- modify the normative construction-parent contract;
- modify any of the fifteen current schemas;
- change the fifteen-schema-role model;
- change the fourteen-generated-record-family model;
- add a fifteenth generated-record family;
- change any of the 946 negative cases or their expected outcomes;
- change any of the 137 contradiction-regression cases or expected outcomes;
- use Candidate 2 source as an implementation base;
- use V1–V4 source as an implementation base;
- create production implementation source;
- execute process-self-test;
- execute construct mode;
- construct a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- qualify the product;
- authorize A6.

Do not modify, resume, clean, finish, or reseal any supplied root.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned documentary-contract process in one fresh private
root.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace the governing decisions, material identities,
matrices, findings, and disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_BLOCKED

CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. TERMINAL CANDIDATE-2 DISPOSITION
──────────────────────────────────────────────────────────────────────────────

FAILED_REPLAY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-parent-exact-qualification-replay-b6pbc620

Expected identity:

- device:
  16777234
- inode:
  180821288
- mode:
  0700
- retained verdict:
  QUALIFICATION_REPLAY_PROVENANCE_MISMATCH
- mandatory next treatment:
  RETIRE_CANDIDATE_QUALIFICATION_LINEAGE

Expected failure outcome:

closing/replay-failure-outcome-v1.json

- SHA-256:
  c1249f41672d41dea05ca66d86763ca68940ee7219d2cfc645168593e3a20f8c

Authenticate, at minimum:

- bootstrap start;
- exact Candidate 2 source registries;
- exact source-copy record;
- replay-supervisor identity;
- custody preflight;
- rehearsal invocation contract;
- rehearsal A process and inventory;
- rehearsal B process and inventory;
- independent-validator invocation;
- validator process record;
- validator stdout;
- validator stderr;
- validator result;
- validator-error adjudication;
- normalized rehearsal comparison;
- Candidate 2 classification;
- evidence-retention record;
- rehearsal cleanup;
- supplied-root closing equality;
- replay temporal-inventory failure;
- replay failure outcome;
- final report.

Classify this root as:

historical_nonqualifying_terminal_candidate_2_replay

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- not cleanable in this task;
- ineligible to supply current implementation or qualification results.

Candidate 2 source bytes may be examined only to bind the defect catalogue.
They may not be copied, patched, transformed, imported, or executed.

Require complete opening/closing equality if the root is opened.

──────────────────────────────────────────────────────────────────────────────
2. CANDIDATE-2 DEFECT CATALOGUE
──────────────────────────────────────────────────────────────────────────────

FAILED_CANDIDATE_2_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-clean-parent-evidence-ownership-repair-no81sk4_

Expected identity:

- device/inode:
  16777234 / 180805755
- mode:
  0700
- retained verdict:
  IMPLEMENTATION_PROVENANCE_MISMATCH

BLOCKED_CLEAN_IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-clean-reconstruction-parent-2e9xutl_

Expected identity:

- device/inode:
  16777234 / 180758397
- mode:
  0700
- retained verdict:
  SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED

Use these roots only to bind a complete defect catalogue.

At minimum classify:

A. Documentary-evidence double writer

- path:
  validation/confirmation-evidence-map-validator-v1.json;
- premature generic write;
- later semantically final write;
- exclusive-create collision;
- no overwrite;
- no adoption.

B. Failed-rehearsal custody loss

- validator stdout lost;
- validator process ledger lost;
- rehearsal B identity/inventory lost;
- rehearsal B cleanup proof lost;
- cleanup occurred before indispensable evidence retention.

C. Candidate 2 temporal namespace defect

For both rehearsals:

- parent exit:
  0;
- substantive validation:
  otherwise passed;
- temporal entries:
  66;
- independently required entries:
  67;
- sole missing row:
  closeout;
- cause:
  temporal projection occurred before the parent created the closeout directory
  used to retain the temporal inventory itself.

D. Failed replay-capsule temporal namespace defect

- replay temporal projection:
  245 entries;
- replay created closeout while writing the inventory;
- immediate independent reprojection failed;
- terminal manifests absent;
- replay capsule nonqualifying.

E. Repeated governance/process defects from V1–V4

Bind through the already retained lineage rather than reopening every root
unless indispensable:

- unsafe dereference of deliberately invalid record shapes;
- wrong external field vocabulary;
- acceptance-bearing fallback;
- intentionally unmapped normative schema role;
- generic truthiness over numeric zero;
- stale source identity in qualification results;
- contradictory aggregate/static fields;
- premature success-status records;
- insufficiently independent validators.

Retain:

analysis/historical-reconstruction-parent-defect-catalogue-v1.json

For every defect bind:

- exact source/evidence identity;
- immediate cause;
- first failed predicate or operation;
- authority classification;
- affected lifecycle phase;
- effect on contract:
  none, or exact established effect;
- effect on schemas:
  none, or exact established effect;
- future prevention rule;
- whether the defect is relevant to Generation 2.

Do not promote any historical result as current authority.

Require opening/closing equality for every historical root opened.

──────────────────────────────────────────────────────────────────────────────
3. TERMINAL HISTORICAL DECISION
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-final-subject-p06-p18-reconciliation-v4j7a04y

Expected identity:

- device/inode:
  16777234 / 180632969
- mode:
  0700
- verdict:
  FINAL_SUBJECT_SCHEMA_P06_P18_RECONCILIATION_STOP_AND_RECONSTRUCT
- mandatory progression:
  FRESH_SUBJECT_RECONSTRUCTION_AND_FRESH_HARNESS_EVALUATION
- historical reconciliation terminal:
  true
- further historical reconciliation authorized:
  false

Expected final inventory:

closeout/final-diagnostic-inventory-v1.json

- inode:
  180633002
- size:
  14272
- SHA-256:
  a80260149b05ca1f173426165ae41559696029b2a972149bdcc2c373644fe304

Authenticate this decision.

This task must not reopen its unresolved historical questions.

──────────────────────────────────────────────────────────────────────────────
4. AUTHORITATIVE NORMATIVE CONTRACT
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Authenticate:

- package closure;
- contract path and byte identity;
- strict JSON parse;
- duplicate-key rejection;
- nonfinite-value rejection;
- sole normative writer:
  true;
- implementation present:
  false;
- implementation authority:
  false.

The normative contract remains the sole semantic writer.

The Generation-2 contract is subordinate. It may freeze implementation
mechanics, custody, serialization, and validation, but may not alter normative
semantics or authority.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
5. CURRENT SCHEMA AUTHORITY
──────────────────────────────────────────────────────────────────────────────

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Authenticate:

- exactly fifteen current schema roles;
- exact schema paths;
- exact schema sizes and hashes;
- unique `$id` values;
- historical supersession;
- Draft 2020-12 validity;
- schema-repair authority;
- contract/schema satisfiability.

Use only the current v2 schemas.

No historical schema may become current.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
6. VALIDATION-SPECIFICATION AUTHORITY
──────────────────────────────────────────────────────────────────────────────

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use this root only to authenticate root-independent specifications and case
registries for:

- fourteen generated-record families;
- contract-derived witnesses;
- schema-derived witnesses;
- the 946 negative cases;
- the 137 contradiction-regression cases;
- the 766/333 field-map rules;
- ten documentary-validator roles;
- confirmation-evidence semantics;
- current-role occupancy;
- fresh-subject manifest grammar.

Do not copy historical result files as current results.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
7. FRESH GENERATION-2 CONTRACT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-contract-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- Candidate 2 retirement decision;
- failed replay identity;
- terminal historical decision;
- normative-contract identity;
- current-schema authority;
- validation-specification authority;
- subordinate implementation-contract authority;
- production source creation authorized:
  false;
- qualification source creation authorized:
  false;
- current subject construction authorized:
  false;
- contract semantic change authorized:
  false;
- schema change authorized:
  false;
- case-registry change authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- A6 authorized:
  false.

Create directories lazily.

No empty directory may remain at terminal closure.

──────────────────────────────────────────────────────────────────────────────
8. GENERATION-2 AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-reconstruction-parent-authority-v1.json

Owned implementation mechanics:

- supplied-input authentication;
- exact external-interface binding;
- fresh subject-root allocation;
- artifact-plan enforcement;
- exact contract/schema copying;
- generated documentary evidence;
- process and child custody;
- reconstruction-owned filesystem effects;
- cleanup;
- temporal inventory;
- terminal manifest generation;
- failure disposition;
- terminal seal.

Explicit nonauthority:

- normative semantic authorship;
- schema semantic authorship;
- repository truth;
- product/runtime behavior;
- target-audit verdict;
- publication;
- deployment;
- external Git commit;
- readiness;
- orchestration;
- A6.

Require one authoritative writer per mutable fact.

Retain a writer-of-record table for every mutable fact.

──────────────────────────────────────────────────────────────────────────────
9. COMPLETE GENERATION-2 STATE MACHINE
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-reconstruction-state-machine-v1.json

Freeze the exact ordered phases:

G00 — parent self-authentication
G01 — supplied-input provenance gate
G02 — executable-origin and external-interface freeze
G03 — fresh subject-root allocation
G04 — exact directory-namespace materialization
G05 — normative-contract copy
G06 — fifteen-schema copy
G07 — fifteen-role schema registry
G08 — fourteen-family authority and role mapping
G09 — metaschema and fresh family reconstruction
G10 — contract and schema witnesses
G11 — complete 946-case negative matrix
G12 — complete 137-case contradiction regression
G13 — 766/333 field map
G14 — nine prerequisite documentary-validator results
G15 — confirmation evidence map
G16 — confirmation-evidence-map validator result
G17 — final ten-role documentary-validator registry
G18 — registry-derived documentary-validator regeneration
G19 — independent schema validator
G20 — evidence-derived confirmations
G21 — current-role occupancy, status, and lineage
G22 — reconstruction-owned fixture cleanup
G23 — supplied-root closing equality
G24 — nonmanifest output finalization
G25 — namespace-finalization gate
G26 — temporal inventory
G27 — terminal manifest namespace and pair
G28 — independent final reprojection
G29 — terminal seal and nonreturning exit

For every phase bind:

- prerequisites;
- exact inputs;
- exact outputs;
- authoritative writer;
- pass rule;
- first-blocker rule;
- may continue on failure;
- cleanup obligations;
- authority contribution;
- next permitted phase.

No phase may be skipped on success.

No later phase may compensate for an earlier failed phase.

──────────────────────────────────────────────────────────────────────────────
10. EXACT FUTURE SUBJECT NAMESPACE
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/future-schema-subject-artifact-plan-v1.json

Derive and freeze the exact future subject package path set.

For every path bind:

- relative path;
- artifact role;
- file or directory;
- producer phase;
- producer component;
- producer function;
- maximum successful write count;
- mode;
- lifecycle:
  planned, staged, final, closure output;
- consumers;
- whether root-bound;
- whether terminal-self-excluded.

Requirements:

- exact path set, not only role categories;
- no unknown output;
- no dynamically invented directory;
- one final path per artifact;
- no path used both for staging and final output;
- no directory first created by writing a late file;
- every directory in the final package exists by G04;
- all directories, including `closeout/` and `manifest/`, exist before G25;
- no directory creation after G25;
- `closeout/` exists before temporal projection;
- `manifest/` exists before temporal projection;
- temporal inventory path is declared before G25;
- both final manifest paths are declared before G25;
- every terminal directory is nonempty by G28.

If the exact path set cannot be derived from the normative contract and
accepted validation specifications, return the blocked verdict.

Do not use a historical package’s physical path set as authority.

──────────────────────────────────────────────────────────────────────────────
11. NAMESPACE-FINALIZATION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/namespace-finalization-v1.json

Freeze two distinct boundaries:

A. Namespace finalized

At G25:

- every final directory already exists;
- every nonclosure output except the temporal inventory is final;
- the temporal inventory path is planned but absent;
- manifest A and B paths are planned but absent;
- no later directory creation is permitted;
- no later nonmanifest artifact other than the temporal inventory is
  permitted;
- exact directory set is frozen;
- exact planned final path set is frozen.

B. Terminal seal

At G29:

- temporal inventory verified;
- manifest A/B verified;
- independent reprojection passed;
- terminal topology passed;
- no filesystem operation remains.

Rules:

- writing the temporal inventory must not create `closeout/`;
- writing A/B must not create `manifest/`;
- no success-status file may be written after G25;
- no in-package record may claim terminal success before G29;
- terminal success authority derives from verified manifests, final
  reprojection, terminal topology, and the external terminal marker;
- no postseal filesystem read or write.

──────────────────────────────────────────────────────────────────────────────
12. TEMPORAL-INVENTORY CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/temporal-inventory-lifecycle-v1.json

Freeze:

- exact path:
  closeout/temporal-final-inventory-v1.json;
- `closeout/` already exists before projection;
- all other nonmanifest output final;
- exact self exclusion;
- exact future manifest exclusions;
- reserved manifest directory included;
- root row included exactly once;
- exact final directory set included;
- stable field grammar;
- no mtime;
- no ctime;
- no directory size;
- no directory link count;
- compact canonical JSON;
- terminal newline;
- exclusive create;
- fsync;
- close;
- no-follow reopen;
- independent reprojection immediately after write.

Required equality:

retained temporal projection
=
fresh physical projection excluding:
- temporal inventory file;
- manifest A;
- manifest B.

The projection must include the already existing:

- closeout directory;
- manifest directory.

A temporal inventory may not set `verified:true` until the independent
reprojection passes.

──────────────────────────────────────────────────────────────────────────────
13. TERMINAL-MANIFEST CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/terminal-manifest-lifecycle-v1.json

Freeze the stable final-namespace protocol:

1. `manifest/` already exists.
2. A and B are absent.
3. Exclusively create zero-length A and B before either projection.
4. Retain both file descriptors.
5. Fsync both empty files.
6. Fsync `manifest/`.
7. Generate A and B independently with both paths excluded.
8. Require generated bytes identical.
9. Write A through retained A descriptor.
10. Fsync and close A.
11. Write B through retained B descriptor.
12. Fsync and close B.
13. Fsync `manifest/`.
14. Reopen both no-follow.
15. Require original path/inode custody.
16. Verify type, mode, links, size, and SHA-256.
17. Require A/B byte equality.
18. Independently reproject the final root.
19. Require final reprojection equals A/B.
20. Require root row exactly once.
21. Require no empty descendant.
22. Require no symlink or special object.
23. Require no multiply linked regular file.
24. Require modes `0700/0600`.
25. Require no cache or bytecode.
26. Transition seal exactly once.
27. Emit guarded terminal marker.
28. Exit nonreturningly.
29. No filesystem operation after seal.

No terminal success file may be written after the manifest pair.

──────────────────────────────────────────────────────────────────────────────
14. PHASE/FUNCTION/PATH WRITER REGISTRY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-phase-function-path-writer-registry-v1.json

For every future subject path bind:

- phase;
- component role;
- function role;
- write operation;
- maximum successful writes;
- creation posture;
- final/staged posture;
- prerequisites;
- consumers.

Require:

- exactly one final writer tuple per path;
- no parent-wide generic writer ownership;
- no two phases own the same final path;
- no two functions own the same final path;
- no second successful write;
- no overwrite;
- no adoption of preexisting final output;
- no staged and final artifact under the same path;
- bounded dynamic path templates only.

Explicitly require one writer for:

- each of the nine prerequisite documentary-validator results;
- confirmation evidence map;
- confirmation-evidence-map validator result;
- final ten-role registry;
- registry-derived regeneration;
- explicit confirmations;
- report/status;
- temporal inventory;
- manifest A;
- manifest B;
- failure outcome;
- partial failure inventory.

──────────────────────────────────────────────────────────────────────────────
15. DOCUMENTARY-EVIDENCE LIFECYCLE
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-documentary-evidence-lifecycle-v1.json

Freeze this dependency order:

1. stable validator source identities;
2. nine prerequisite documentary-validator results;
3. confirmation evidence map;
4. confirmation-evidence-map validator result;
5. final ten-role documentary-validator registry;
6. registry-derived documentary-validator regeneration result;
7. independent schema validation;
8. evidence-derived explicit confirmations;
9. current-role occupancy;
10. package status;
11. historical lineage;
12. final report data;
13. temporal inventory;
14. terminal manifests.

For every stage bind:

- prerequisites;
- output paths;
- writer tuple;
- creation count;
- authority;
- downstream consumers;
- failure behavior.

Required invariants:

- confirmation validator result created exactly once;
- final ten-role registry after all ten results;
- regeneration derived from the final registry;
- no hard-coded role count as pass authority;
- explicit confirmations derived from retained evidence;
- no confirmation/validator cycle;
- no result validates itself;
- no placeholder under a final result path.

──────────────────────────────────────────────────────────────────────────────
16. PROCESS-CUSTODY CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-process-custody-v1.json

Freeze:

- top-level platform authority for parent creation;
- parent authority for child creation and ledger;
- one child recorder;
- prelaunch before spawn;
- contiguous ordinals;
- exact argv/cwd/environment/stdin/timeout;
- exact stdout/stderr retention;
- exit/signal;
- reaping;
- descriptor closure;
- fixed output attribution;
- dynamic root attribution;
- nonzero-exit attribution;
- timeout attribution;
- process-group posture;
- no shell;
- no PATH lookup for executables;
- no inherited environment beyond explicitly permitted platform mechanics;
- no supervisor loop;
- no administrative continuation.

Every child effect must be attributed before cleanup.

──────────────────────────────────────────────────────────────────────────────
17. FAILURE-EVIDENCE AND CLEANUP CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-failure-evidence-and-cleanup-v1.json

On failure require this order:

1. stop dependent work;
2. retain exact first blocker;
3. retain structured exception;
4. reap children;
5. close descriptors;
6. retain complete process ledger and streams;
7. retain complete partial-root inventory;
8. retain identities of all generated artifacts;
9. retain evidence inside the governing package before any fixture deletion;
10. derive cleanup registry from created roots;
11. revalidate root identity before removal;
12. remove exact roots;
13. observe ENOENT twice;
14. require exact set equality:
    created
    =
    inventoried
    =
    evidence-retained
    =
    cleanup rows
    =
    twice absent;
15. repeat supplied-root closing equality;
16. retain package authority false;
17. retain terminal seal false;
18. forbid same-root retry.

No path to a subsequently removed file counts as retained evidence.

──────────────────────────────────────────────────────────────────────────────
18. EXTERNAL-INTERFACE CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-external-interface-v1.json

Enumerate every acceptance-bearing external input required by a future
implementation.

For every interface bind:

- authority;
- exact path or authoritative path derivation;
- fixed identity when fixed;
- strict grammar;
- required top-level fields;
- exact pointers;
- exact types;
- row key;
- count derivation;
- uniqueness derivation;
- digest derivation;
- optional fields;
- corroborative summaries;
- consumers;
- failure reason.

Rules:

- no aliases;
- no pointer fallback;
- no generic recursive list selection;
- no first/longest/same-length selection;
- no filename/content/recency scoring;
- missing required field fails;
- wrong type fails;
- counts derive from rows;
- uniqueness derives from rows;
- digests independently recomputed;
- summaries corroborate only;
- absence never means false, zero, empty, or pass;
- historical results never become fresh results.

Explicitly freeze the actual 946-case registry vocabulary, including:

- actual case-list pointer;
- actual case-name field;
- `names_unique`;
- derived count:
  946;
- derived unique count:
  946;
- name-digest encoding.

`literal_names_unique` is not a recognized alias.

──────────────────────────────────────────────────────────────────────────────
19. TOTAL JSON-OBSERVATION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-total-json-observation-v1.json

Required statuses:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

When present retain:

- exact JSON type;
- canonical pointer;
- value;
- document identity.

Rules:

- no chained `.get()` over untrusted or mutated JSON;
- no object-only operation without exact object type;
- no array access without array type and bounds;
- deliberate type-changing mutation remains an opaque typed value;
- rejection reason derives from schema-validator output plus typed observation;
- independent validators implement separate observation logic.

──────────────────────────────────────────────────────────────────────────────
20. INTERNAL SPECIAL-CASE CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-internal-special-cases-v1.json

At minimum freeze:

- normative-construction-parent is the sole schema role without a generated
  family;
- exactly fourteen generated families;
- zero child count;
- zero cleanup-root count;
- empty but valid cleanup sets;
- raw false values;
- positive assertions over raw false values;
- nullable first blocker on success;
- empty error arrays;
- root row `"."`;
- self-exclusions;
- reserved premanifest directory;
- implementation absent;
- implementation authority false;
- independent acceptance false before audit.

For every special case bind:

- exact sentinel;
- semantic meaning;
- permitted contexts;
- forbidden contexts;
- required branch;
- output representation;
- whether generic truthiness is forbidden;
- whether direct dictionary indexing is forbidden.

No unregistered acceptance-bearing special case is permitted.

──────────────────────────────────────────────────────────────────────────────
21. GENERATION-2 SOURCE ARCHITECTURE
──────────────────────────────────────────────────────────────────────────────

Generate:

analysis/gen2-source-architecture-v1.json

Define, without implementing, at minimum:

Production components:

1. finite reconstruction parent;
2. child process recorder;
3. strict JSON reader;
4. total JSON observer;
5. supplied-root inventory/authenticator;
6. artifact-plan enforcer;
7. namespace materializer;
8. contract/schema copier;
9. schema-role registry generator;
10. generated-family authority generator;
11. schema/family mapper;
12. witness generator;
13. negative-matrix executor;
14. contradiction-regression executor;
15. field-map generator;
16. documentary-evidence lifecycle controller;
17. confirmation evidence generator;
18. current-role occupancy generator;
19. failure finalizer;
20. cleanup controller;
21. temporal-inventory generator;
22. terminal manifest generator A;
23. terminal manifest generator B;
24. terminal seal controller.

Qualification-only components:

25. qualification driver;
26. independent external-interface validator;
27. independent JSON-observation validator;
28. independent schema/family validator;
29. independent negative-matrix validator;
30. independent documentary-lifecycle validator;
31. independent process-custody validator;
32. independent namespace/closure validator;
33. independent rehearsal validator.

For every component bind:

- authority;
- nonauthority;
- inputs;
- outputs;
- mutable facts written;
- consumers;
- forbidden dependencies;
- failure behavior.

Independent validators may not import production modules or producer helpers.

──────────────────────────────────────────────────────────────────────────────
22. FUTURE IMPLEMENTATION QUALIFICATION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/gen2-implementation-qualification-v1.json

Require a future implementation package to pass, before source freeze:

A. Static/source gates

- compilation under pinned Python `-I -S -B`;
- AST/call-graph/dataflow;
- bytecode/exception-table/CFG;
- import boundary;
- writer-site crosswalk;
- namespace-creation-site crosswalk;
- no postseal operation.

B. Literal matrices

At minimum:

- 50 external-interface cases;
- 45 JSON-observation cases;
- 30 schema/family cases;
- 35 process-custody cases;
- 35 cleanup/failure-evidence cases;
- 40 writer/lifecycle cases;
- 40 namespace/temporal cases;
- 35 manifest/terminal cases;
- 40 negative-checker robustness cases.

Every matrix requires:

- unique names;
- exact name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

C. Complete rehearsals

Two physically distinct full subject reconstructions.

Each must independently complete:

- exact contract/schema copy;
- 15/14 registries;
- witnesses;
- 946 negative cases;
- 137 contradiction cases;
- 766/333 field map;
- ten validator results;
- evidence DAG;
- independent schema validator;
- confirmations;
- occupancy;
- status;
- supplied-root equality;
- cleanup;
- namespace finalization;
- temporal inventory;
- terminal manifests;
- final reprojection;
- terminal topology;
- no postseal activity.

D. Rehearsal determinism

Normalize only explicitly physical bindings.

Require zero unexplained semantic difference.

E. Independent rehearsal validation

Must not import production or producer helpers.

F. Evidence before cleanup

No rehearsal root removal until complete evidence has been retained elsewhere.

G. Source freeze

Freeze only exact bytes used by both passing rehearsals.

H. Frozen-source requalification

No source modification after freeze.

I. Fresh independent audit

A separately created independent audit must accept the implementation package
before one-shot current-subject construction is authorized.

──────────────────────────────────────────────────────────────────────────────
23. GENERATION-2 CONTRACT WITNESSES
──────────────────────────────────────────────────────────────────────────────

Produce minimal and complete contract witnesses for:

- success path;
- failure before child launch;
- child spawn failure;
- child nonzero exit with dynamic effects;
- external-interface mismatch;
- deliberately malformed JSON shape;
- zero-root cleanup success;
- nonempty cleanup success;
- failure-evidence retention before cleanup;
- fifteen-role/fourteen-family mapping;
- documentary evidence lifecycle;
- namespace finalization;
- temporal inventory;
- terminal manifest pair;
- no-write terminal seal.

Retain:

validation/gen2-contract-witness-matrix-v1.json

Every witness must satisfy the Generation-2 contracts and remain subordinate
to the normative construction-parent contract.

──────────────────────────────────────────────────────────────────────────────
24. GENERATION-2 MUTATION MATRICES
──────────────────────────────────────────────────────────────────────────────

A. State-machine matrix

Retain:

validation/gen2-state-machine-matrix-v1.json

Cover:

- skipped phase;
- reordered phase;
- continued work after failed prerequisite;
- duplicate phase output;
- missing cleanup phase;
- temporal projection before namespace finalization;
- terminal manifests before temporal verification;
- seal before final reprojection;
- operation after seal.

B. Namespace and temporal matrix

Retain:

validation/gen2-namespace-temporal-matrix-v1.json

At minimum cover:

1. Exact planned namespace.
2. `closeout/` absent at namespace finalization.
3. `manifest/` absent at namespace finalization.
4. New directory after namespace finalization.
5. New nonmanifest file after namespace finalization.
6. Temporal projection omits `closeout/`.
7. Temporal projection omits `manifest/`.
8. Temporal file creates `closeout/`.
9. Temporal file written into existing `closeout/`.
10. Root row absent.
11. Root row duplicated.
12. Temporal self inclusion.
13. Manifest A/B not excluded.
14. Unknown path.
15. Wrong mode.
16. Symlink.
17. Special object.
18. Multiple hard link.
19. Cache/bytecode.
20. Exact Candidate 2 defect.
21. Exact failed replay defect.
22. Correct baseline.

C. Writer/evidence-lifecycle matrix

Retain:

validation/gen2-writer-lifecycle-matrix-v1.json

At minimum cover:

- duplicate writer;
- same path staged and final;
- identical second write;
- different second write;
- confirmation validator written twice;
- final registry before all ten results;
- registry after all ten results;
- regeneration hard-coded;
- regeneration derived;
- confirmation cycle;
- result self-validation;
- exact corrected baseline.

D. Process/failure-custody matrix

Retain:

validation/gen2-process-failure-custody-matrix-v1.json

At minimum cover:

- spawn failure;
- zero exit;
- nonzero exit;
- timeout;
- lost stdout;
- lost stderr;
- lost process ledger;
- dynamic root on nonzero exit;
- cleanup before evidence retention;
- one ENOENT;
- survivor;
- zero-root cleanup;
- exact Candidate 2 qualification-custody loss;
- corrected baseline.

Require across every matrix:

- unique names;
- exact expected closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

──────────────────────────────────────────────────────────────────────────────
25. INDEPENDENT GENERATION-2 CONTRACT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement one fresh, source-external independent validator for this contract
package.

It may not import producer helpers or mutation generators.

It must independently verify:

- normative-contract preservation;
- schema authority;
- 15/14 semantics;
- authority/nonauthority;
- state-machine ordering;
- exact artifact plan;
- exact directory namespace;
- namespace-finalization boundary;
- temporal-inventory lifecycle;
- terminal-manifest lifecycle;
- writer registry;
- documentary-evidence lifecycle;
- process custody;
- failure evidence and cleanup;
- external interfaces;
- total JSON observation;
- special cases;
- source architecture;
- future qualification contract;
- every witness;
- every mutation matrix;
- no implementation source exists.

Retain:

validation/independent-gen2-contract-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
26. FOUR PARENT-OWNED PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain four separately generated analytical projections:

1. authority and state machine;
2. namespace, filesystem, and terminal closure;
3. process custody, failure evidence, and cleanup;
4. validation independence and acceptance evidence.

They are nonauthoritative projections.

Retain:

analysis/perspective-authority-state-machine-v1.json
analysis/perspective-namespace-closure-v1.json
analysis/perspective-process-custody-v1.json
analysis/perspective-validation-evidence-v1.json

Then retain:

analysis/parent-perspective-reconciliation-v1.json

Require:

- no unresolved disagreement;
- no open operating-model decision;
- no hidden implementation decision deferred to source code.

Any unresolved decision blocks readiness for implementation.

──────────────────────────────────────────────────────────────────────────────
27. CONTRACT-PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate a preterminal status record with:

- status:
  gen2-contract-frozen-pending-implementation;
- normative contract unchanged:
  true;
- current schemas unchanged:
  true;
- implementation source present:
  false;
- production source authority:
  false;
- current schema subject constructed:
  false;
- implementation qualification performed:
  false;
- independent implementation audit performed:
  false;
- product process-self-test executed:
  false;
- product construct mode executed:
  false;
- target audit executed:
  false;
- runtime validation rerun:
  false;
- ready for a fresh clean implementation tranche:
  true only after terminal contract-package closure.

No status record may claim implementation readiness or package acceptance.

──────────────────────────────────────────────────────────────────────────────
28. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- failed Candidate 2 replay;
- failed Candidate 2 repair root;
- blocked clean implementation root;
- terminal historical reconciliation;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any other historical root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every contract-package-owned fixture/cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
29. CONTRACT-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Apply the same namespace rules being frozen for the future implementation.

Before temporal projection:

- create every final directory, including `closeout/` and `manifest/`;
- finalize every nonclosure output;
- freeze the exact directory set;
- prohibit later directory creation.

Then:

1. generate temporal projection excluding itself and future A/B;
2. write it into the already existing `closeout/`;
3. independently reproject immediately;
4. require exact equality;
5. exclusively create zero-length A and B in the already existing
   `manifest/`;
6. retain both descriptors;
7. generate independent A/B bytes with both paths excluded;
8. require equality;
9. write/fsync/close;
10. fsync manifest directory;
11. reopen no-follow;
12. verify path/inode/type/mode/link/size/hash;
13. independently reproject the final root;
14. require root row exactly once;
15. require no empty descendant;
16. require no symlink, special object, or multiply linked file;
17. require all modes `0700/0600`;
18. require no cache/bytecode;
19. transition seal once;
20. emit only a guarded terminal marker;
21. exit nonreturningly;
22. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
30. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact first blocker;
- structured exception;
- parent/process records;
- complete partial inventory;
- indispensable evidence before cleanup;
- cleanup;
- supplied-root closing equality;
- contract-package authority false;
- terminal seal false;
- same-root retry forbidden.

Do not create success manifests for a failed contract package.

Failure to retain indispensable evidence, complete cleanup, or close supplied
roots equally is:

CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

only when:

- Candidate 2 retirement authenticates;
- normative contract and current schemas authenticate;
- exact future subject namespace closes;
- Generation-2 authority closes;
- complete state machine closes;
- namespace-finalization contract closes;
- temporal and terminal lifecycle contracts close;
- writer registry closes;
- documentary lifecycle closes;
- process custody closes;
- failure evidence and cleanup close;
- external interfaces close;
- total JSON observation closes;
- special cases close;
- source architecture closes;
- future qualification contract closes;
- all witnesses pass;
- all mutation matrices pass;
- independent validator passes;
- perspectives reconcile with no open decision;
- no implementation source exists;
- supplied roots close equal;
- contract package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_BLOCKED

when:

- a governing semantic or operating-model decision remains unresolved;
- the exact future namespace cannot be frozen;
- one-writer ownership remains ambiguous;
- documentary evidence lifecycle remains cyclic;
- a required interface cannot be frozen;
- a mutation matrix or independent validator fails;
- resolving the defect would require changing the normative contract or current
  schema semantics.

Return:

CONTRACT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- fixed identity mismatch;
- lost indispensable evidence;
- unregistered process or filesystem effect;
- cleanup inequality;
- supplied-root closing inequality;
- contract-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh contract-root identity
3. Candidate 2 terminal retirement authentication
4. Historical defect-catalogue result
5. Terminal historical decision authentication
6. Normative-contract identity and authority
7. Current schema identities and role registry
8. Validation-specification identity
9. Generation-2 authority and nonauthority
10. Complete Generation-2 state machine
11. Exact future subject namespace and artifact count
12. Exact future directory set
13. Namespace-finalization boundary
14. Temporal-inventory lifecycle
15. Terminal-manifest lifecycle
16. Phase/function/path writer registry
17. Documentary-evidence lifecycle
18. Process-custody contract
19. Failure-evidence and cleanup contract
20. External-interface contract
21. Total JSON-observation contract
22. Internal-special-case contract
23. Generation-2 source architecture
24. Future implementation-qualification contract
25. Contract-witness result
26. State-machine matrix
27. Namespace/temporal matrix
28. Writer/lifecycle matrix
29. Process/failure-custody matrix
30. Independent Generation-2 contract-validator result
31. Four parent-owned perspectives
32. Perspective reconciliation
33. Confirmation no implementation source exists
34. Contract-package status
35. Supplied-root closing equality
36. Fixture/cache cleanup
37. Failure-closeout capability and use
38. Temporal-inventory identity
39. Manifest A identity
40. Manifest B identity
41. Independent terminal reprojection
42. Terminal membership and modes
43. No-write-after-closure
44. Remaining uncertainty and nonclaims
45. Explicit confirmation registry

Required confirmations:

CANDIDATE_2_QUALIFICATION_LINEAGE_RETIRED
FURTHER_CANDIDATE_2_REPLAY_NOT_USED
FAILED_REPLAY_ROOT_MUTATION_NOT_PERFORMED
FAILED_CANDIDATE_2_REPAIR_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLEAN_IMPLEMENTATION_ROOT_MUTATION_NOT_PERFORMED
TERMINAL_HISTORICAL_DECISION_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
HISTORICAL_DEFECT_CATALOGUE_COMPLETE
CANDIDATE_2_TEMPORAL_NAMESPACE_DEFECT_RETAINED
FAILED_REPLAY_TEMPORAL_NAMESPACE_DEFECT_RETAINED
GEN2_AUTHORITY_SCOPE_CLOSED
GEN2_NONAUTHORITY_SCOPE_CLOSED
ONE_AUTHORITATIVE_WRITER_PER_MUTABLE_FACT
GEN2_STATE_MACHINE_COMPLETE
GEN2_PHASE_ORDER_EXACT
EXACT_FUTURE_SUBJECT_PATH_SET_FROZEN
EXACT_FUTURE_SUBJECT_DIRECTORY_SET_FROZEN
CLOSEOUT_DIRECTORY_EXISTS_BEFORE_TEMPORAL_PROJECTION
MANIFEST_DIRECTORY_EXISTS_BEFORE_TEMPORAL_PROJECTION
NO_DIRECTORY_CREATION_AFTER_NAMESPACE_FINALIZATION
NO_NONMANIFEST_OUTPUT_AFTER_NAMESPACE_FINALIZATION_EXCEPT_TEMPORAL_INVENTORY
TEMPORAL_INVENTORY_LIFECYCLE_FROZEN
TEMPORAL_PROJECTION_INCLUDES_CLOSEOUT_DIRECTORY
TEMPORAL_PROJECTION_INCLUDES_MANIFEST_DIRECTORY
TEMPORAL_INVENTORY_DOES_NOT_CREATE_CLOSEOUT_DIRECTORY
TERMINAL_MANIFEST_LIFECYCLE_FROZEN
BOTH_MANIFEST_PATHS_EXIST_BEFORE_MANIFEST_PROJECTION
NO_NAMESPACE_MUTATION_BETWEEN_MANIFEST_PROJECTIONS
PHASE_FUNCTION_PATH_WRITER_REGISTRY_COMPLETE
NO_FINAL_PATH_HAS_MULTIPLE_WRITERS
NO_FINAL_PATH_USED_AS_STAGING_PATH
DOCUMENTARY_EVIDENCE_LIFECYCLE_ACYCLIC
CONFIRMATION_VALIDATOR_RESULT_HAS_ONE_WRITER
FINAL_TEN_ROLE_REGISTRY_AFTER_ALL_RESULTS
DOCUMENTARY_REGENERATION_DERIVED_FROM_FINAL_REGISTRY
EXPLICIT_CONFIRMATIONS_DERIVED_FROM_EVIDENCE
PROCESS_CUSTODY_CONTRACT_COMPLETE
FAILURE_EVIDENCE_RETAINED_BEFORE_CLEANUP
CLEANUP_SET_EQUALITY_REQUIRED
ALL_ACCEPTANCE_BEARING_EXTERNAL_INTERFACES_FROZEN
NO_ACCEPTANCE_BEARING_POINTER_FALLBACK
TOTAL_JSON_OBSERVATION_MODEL_COMPLETE
NO_UNGUARDED_OBJECT_ACCESS_ON_UNTRUSTED_JSON
ALL_ACCEPTANCE_BEARING_SPECIAL_CASES_FROZEN
GEN2_SOURCE_ARCHITECTURE_COMPLETE
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
TWO_COMPLETE_REHEARSALS_REQUIRED_BEFORE_SOURCE_FREEZE
INDEPENDENT_IMPLEMENTATION_AUDIT_REQUIRED_BEFORE_ONE_SHOT_USE
GEN2_CONTRACT_WITNESS_MATRIX_PASSED
GEN2_STATE_MACHINE_MATRIX_PASSED
GEN2_NAMESPACE_TEMPORAL_MATRIX_PASSED
GEN2_WRITER_LIFECYCLE_MATRIX_PASSED
GEN2_PROCESS_FAILURE_CUSTODY_MATRIX_PASSED
INDEPENDENT_GEN2_CONTRACT_VALIDATOR_PASSED
PARENT_PERSPECTIVES_RECONCILED
NO_OPEN_OPERATING_MODEL_DECISION
NO_IMPLEMENTATION_SOURCE_CREATED
NO_CURRENT_SCHEMA_SUBJECT_CONSTRUCTED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
CONTRACT_PACKAGE_TEMPORAL_INVENTORY_CREATED
CONTRACT_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
CONTRACT_PACKAGE_MANIFEST_A_CREATED
CONTRACT_PACKAGE_MANIFEST_B_CREATED
CONTRACT_PACKAGE_MANIFESTS_BYTE_IDENTICAL
CONTRACT_PACKAGE_TERMINAL_REPROJECTION_PASSED
CONTRACT_PACKAGE_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CONTRACT_FROZEN_READY_FOR_IMPLEMENTATION

the next tranche may implement a new clean parent from this Generation-2
contract package.

That future implementation:

- may not use Candidate 2 or V1–V4 source;
- must pass two full rehearsals;
- must be frozen;
- must undergo a fresh independent implementation-package audit;
- may not construct the current subject until that audit accepts.

Construction-parent product implementation remains blocked until:

1. a fresh schema subject is reconstructed and terminally closed;
2. a freshly qualified P06/P18-corrected harness accepts it; and
3. no governing contract has reopened implementation authority.
```

**Source:** Codex’s `QUALIFICATION_REPLAY_PROVENANCE_MISMATCH` report in this turn.  
**Confidence:** 1.00 that Candidate 2 qualification is terminally retired; 0.99 that the next missing authority is a complete namespace/evidence-lifecycle implementation contract; 0.98 that implementing again before freezing this contract would repeat the same class of failure.
