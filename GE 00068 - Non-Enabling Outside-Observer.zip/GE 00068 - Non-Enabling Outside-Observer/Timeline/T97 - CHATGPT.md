A6R is ready for implementation. Its conclusion is appropriately narrow:

- The failed final control was semantically and operationally healthy; only peer read-policy verification failed.
- The root-size changes were fully explained by three expected direct-child insertions.
- Directory allocation size is not a reliable identity or content invariant for a deliberately mutable tree grant.
- Stable filesystem-object identity and security posture remain enforced.
- Exact file grants still retain byte-size and digest requirements.
- No whole-root self-attestation path was found.
- Splitting immutable and mutable roots remains a later least-privilege seam rather than necessary scope for this repair.

The next tranche should implement the **successor-only read-policy amendment**, seal it, and stop. The complete five-control A6 refresh must then restart in a new child; the current failed A6 child cannot be resumed or promoted. A bounded verifier causal does not replace that downstream run. 

## Codex prompt: implement the A6R read-policy correction

```text
Permission is workspace-write for one new source-external successor/evidence
child only.

Objective

Implement, validate, close out, and seal the Repair 10I-A6R mutable-tree
read-policy identity amendment frozen by the sealed A6R reconnaissance.

The defect is confined to successor validation semantics:

- a mutable `tree` grant currently treats directory allocation metadata,
  including `st_size`, as acceptance-bearing identity;
- the failed pristine-final control legitimately created three predeclared,
  runner-owned direct children beneath the retained control root:
  `validation-bin`, the corpus file, and `pty-07`;
- the root directory remained the same filesystem object with the same path,
  type, device, inode, ownership, permissions, role, scope, and governed
  security posture;
- the directory size progressed through 448, 480, 512, and 544 bytes;
- external qualification rejected the control solely because the recorded
  directory size differed;
- the repository source, terminal universe, semantic extraction, PTY policy,
  terminal reconciliation, and resource disposition were otherwise correct.

Implement the grant-kind-specific stable-identity model frozen by A6R.

For mutable tree grants:

- stable object identity and security posture remain acceptance-bearing;
- volatile allocation metadata becomes factual/report-only;
- literal regular-file and executable grants retain exact byte size and digest
  requirements;
- no global weakening of directory checks is authorized;
- no grant scope may widen;
- no repository or product contract changes.

This is a parent-only implementation turn.

Do not modify repository source.
Do not modify sealed A6O.
Do not modify sealed A6R.
Do not modify sealed A5C, A5T4, A6O reconnaissance, or any predecessor.
Do not resume, modify, overwrite, or seal the failed A6 child.
Do not start a new five-control A6 refresh in this turn.
Do not implement the historical directional-comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Candidate repository, read-only throughout

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Sealed A5T4 repository lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5C successor lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A6O reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-historical-overlay-recon-8de797304ea9

Sealed A6O overlay successor baseline

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Sealed A6R read-policy reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9

Failed and unsealed A6 refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Required new successor child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

## 1. Absolute repository-root lock

Before any substantive observation:

1. Component-walk and `lstat` CANDIDATE_R.
2. Require the exact physical path:
   `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
3. Require:
   - type: directory
   - device: 16777234
   - inode: 122118502
   - mode: 0755
   - UID/GID: 501/20
4. Require physical `pwd -P` to equal CANDIDATE_R exactly.
5. Require CANDIDATE_R and PRIMARY_R to remain physically distinct sibling
   directories:
   - PRIMARY_R device/inode: 16777234/47685738
   - no equality
   - no alias
   - no nesting
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode: 0644;
- size: 123;
- device/inode: 16777234/122118504;
- one link;
- SHA-256:
  79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419;
- exact target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Set for all Git observations:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured subprocess cwd equal to the physical CANDIDATE_R.

No command may use PRIMARY_R as:

- cwd;
- Git `-C` target;
- source root;
- inventory root.

For inline Python:

- use `PYTHONDONTWRITEBYTECODE=1`;
- verify `os.getcwd()` before repository-relative access;
- import no executable module from an evidence child;
- create no `__pycache__` or `.pyc`.

Stop on any physical-root or Git-binding mismatch:

REPAIR10I_A6R_IMPLEMENTATION_WORKTREE_MISMATCH

## 2. Mandatory opening gate

Using only candidate-rooted observations, require:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- inventory size:
  54314
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require every governed member to be a regular nonsymlink member under the
existing source-inventory contract.

Require the exact three-file A5T4 repository delta and every other repository
tuple to match sealed A5T4.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Require exact sealed A5C:

- manifest SHA-256:
  05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489
- manifest size:
  31421
- payloads:
  216
- directories:
  71
- source T:
  2c2d0b36f52d5949d023a36400f0e0748149875a
- inventory:
  810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9

Require exact sealed A6O reconnaissance:

- manifest SHA-256:
  20852734748924f75194239767a9d47c102e4767a529dadbbb5e3c4c48461138
- manifest size:
  4031
- payloads:
  28

Require exact sealed A6O successor:

- manifest SHA-256:
  ab54d9f980a810b87f318ecee10073c731044a111b7f5ba7e69b8893dedb388f
- manifest size:
  38321
- payloads:
  241
- directories:
  80
- source T:
  716d59b3e28ab4c77ae46af1ee44b28cd24ea77d
- source inventory:
  f47e798ce2429d20f73791a68ced180b2f5cc6b693d072037885e319bd1f30cc
- members:
  12

A6O binaries:

repair10-runner:
  f37d350c11692bb225a8a710779ba089468a6d9618dc5110b3a8f39a625aa9b2

repair10-compare:
  7b72930c44b9803a386328bd39ec96abba179eb6122c96000c6f96c016135301

repair10-semantic:
  5e70f1c874033124df7b7c0f7d4df355403ced8d6620081910f51f7006591181

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require exact sealed A6R:

- manifest SHA-256:
  12ec94fff28d4a861b92ec069abd90ddd1e39f9b026777799b585db755cfcb6c
- payloads:
  19
- directories:
  8

Reverify completely:

- closeout/final-report-v1.md
- findings/contract-freeze-v1.json
- schemas/stable-versus-volatile-fields-v1.md
- tests/future-causal-matrix-v1.json
- closeout/command-root-audit-v1.json
- root-lifecycle analysis;
- schema/dialect analysis;
- touched-file freeze;
- implementation and A6-restart sequence;
- future stop conditions.

Require the failed A6 child to remain:

- present;
- unsealed;
- without evidence manifest or detached digest;
- byte-exact from opening through closing.

Reverify:

- findings/fresh-validation-block-v1.json
- closeout/validation-blocked-closeout-v1.json
- exact pristine-final suite specification;
- effective read policies;
- command intents/results;
- terminal reconciliation;
- raw streams through EOF;
- semantic envelope;
- producer qualification;
- peer blocked qualification;
- resource ledger;
- cleanup and two absence epochs.

Bind:

- exact candidate source identity;
- tests:
  2,753 pass / 137 fail / 8 skip;
- packages:
  14 pass / 11 fail / 23 skip;
- semantic-integrity failures:
  0;
- unknown diagnostics:
  0;
- peer qualification:
  blocked-uncertain;
- sole false verification field:
  read_policy_verified;
- root-size observations:
  448, 480, 512, and 544 bytes;
- direct-child insertion sequence:
  `validation-bin`, corpus file, `pty-07`;
- all stable root fields:
  exact according to A6R;
- remaining controls/comparisons:
  not started.

Require the new successor child to be absent.

Stop on any mismatch:

REPAIR10I_A6R_IMPLEMENTATION_BASELINE_MISMATCH

## 3. Evidence-child creation

After the opening gate, create the successor child exclusively under umask 077.

Use exactly:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, nonsymlink, with intended mode 0600 or 0700.

No hardlinks.

Do not import executable modules from predecessor evidence children.

Copy all 12 A6O successor source members independently into:

tool/source/

Require:

- no hardlinks;
- opening bytes and logical modes equal A6O;
- complete source inventory and pure T;
- every unchanged member reverified at closeout.

## 4. Exact authorized successor scope

Modify exactly these four copied A6O source files:

1. tool/source/FORMAT.md
2. tool/source/envelope/runner.go
3. tool/source/envelope/semantic.go
4. tool/source/envelope/envelope_test.go

The other eight source members remain byte- and logical-mode-identical to A6O:

- tool/source/envelope/source.go
- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-fixture/main.go
- both golden files
- go.mod

No thirteenth source member.
No new dependency.
No golden edit.
No CLI edit.
No repository edit.

Stop if another source file is required:

REPAIR10I_A6R_SCOPE_EXPANSION_REQUIRED

## 5. Frozen correction

Implement Model B exactly as frozen by sealed A6R.

Use the normative field classifications from:

schemas/stable-versus-volatile-fields-v1.md

Do not reconstruct or simplify that table from this prompt.

### Mutable tree grants

For a mutable-directory tree grant:

Acceptance-bearing identity includes exactly the stable fields frozen by A6R,
including:

- declared grant kind;
- declared role and scope;
- lexical and physical path binding;
- no-follow component identity;
- directory type;
- stable filesystem-object identity;
- ownership;
- permissions;
- supported security posture.

Treat exactly the A6R-classified allocation metadata as factual/report-only,
including mutable directory size and other locally volatile allocation/time
observations identified in the frozen table.

Do not let a report-only change make `read_policy_verified=false`.

Continue recording opening and closing report-only observations.

Do not accept replacement, symlink substitution, type change, owner change,
mode widening, security-posture change, role change, or scope change.

### Literal regular-file grants

Retain all frozen exact requirements, including:

- path and identity;
- regular-file type;
- exact size;
- exact byte digest;
- mode/owner/security posture;
- no-follow and ancestor checks.

A byte or size change remains qualification-blocking.

### Executable grants

Retain the exact executable identity and digest requirements frozen by A6R.

### Other grant kinds

Implement exactly the frozen treatment for:

- immutable tree, if represented;
- metadata-only ancestor;
- device/socket literal;
- source, GOROOT, tool, and other typed roots.

Do not apply mutable-tree semantics to another grant kind by convenience.

### Prohibited weakening

Do not:

- ignore all directory metadata globally;
- accept path replacement because a size happens to match;
- accept any size-growth lattice;
- use command-specific numeric size exceptions;
- treat same size as descendant-content proof;
- turn a tree grant into an exact recursive output inventory;
- widen read scope;
- admit a new root;
- split roots in this tranche;
- change PTY, overlay, canonicalization, or comparison policy.

Model D root decomposition remains a separately reopened hardening seam.

## 6. Schema dialect

Implement exactly the future active dialect frozen in A6R.

Before editing, retain the exact current A6O 24-schema dialect.

After editing, retain the exact new 24-schema dialect.

The frozen transition includes:

- `effective-read-policy.v2`;
- the complete eight-record outer v5 chain;
- command records remaining v3;
- PTY records remaining v2;
- the exact remaining v1 records.

Do not infer the list or version numbers from this prompt where the A6R
contract provides the exact list.

Use the exact A6R producer/consumer map.

Require:

- every active producer emits the intended generation;
- every active consumer requires the intended generation;
- strict decoding;
- old read-policy/source-binding acceptance records are parse-only historical
  inputs;
- old schemas cannot qualify new semantics;
- new schemas cannot qualify through old verification logic;
- mixed old/new acceptance chains fail.

Do not reuse an active schema identifier with changed meaning.

## 7. External peer qualification

Implement the exact peer-verification contract frozen by A6R.

The peer must independently:

1. reopen or reobserve each declared path with no-follow semantics;
2. validate grant kind and role;
3. validate all acceptance-bearing stable fields for that grant kind;
4. validate regular-file/executable bytes, size, and digest where required;
5. retain volatile observations factually without making them acceptance
   fields;
6. reject path, type, device, inode, owner, mode, flags, ACL/xattr posture,
   digest, role, scope, or stable-ancestor mismatch;
7. reject mixed policy generations;
8. retain opening and closing observations;
9. preserve factual observations even when qualification fails.

Producer captions are never authority.

A producer-side `read_policy_verified=true` does not substitute for peer
recomputation.

## 8. Logical fingerprint

Update logical fingerprints exactly as frozen by A6R.

The fingerprint must bind:

- effective-read-policy schema generation;
- grant kind;
- role;
- scope;
- all behaviorally material stable-policy fields.

Volatile report-only observations must not make otherwise equivalent controls
logically different.

Do not fingerprint only the read-policy record digest without structural
validation.

Independently mutate every material policy field and require fingerprint
change or strict rejection.

## 9. Mandatory vulnerable-predecessor causal

Using exact A6O source, reproduce the frozen vulnerable condition:

- mutable tree root;
- same path/device/inode/type/owner/mode/role/scope;
- expected direct-child insertions;
- directory size changes;
- A6O peer verification rejects;
- only `read_policy_verified` fails.

Retain this as expected-negative evidence.

Do not modify or resume the failed A6 child.

## 10. Mandatory 32-case causal matrix

Implement every case in the sealed:

tests/future-causal-matrix-v1.json

No omission, merging, approximation, or substitute.

The matrix includes the exact frozen cases for:

- mutable-tree size-only changes;
- mutable-tree time/allocation observations;
- path replacement with new inode;
- replacement retaining the same reported size;
- symlink substitution;
- type change;
- owner change;
- permission widening;
- flags/ACL/xattr posture mutation where governed;
- descendant changes demonstrating that size is not content proof;
- literal-file byte/size/digest mutation;
- executable identity/digest mutation;
- metadata-only ancestor behavior;
- wrong grant kind;
- wrong role;
- old/new policy-schema rejection;
- mixed acceptance chains;
- producer-caption/peer-recomputation disagreement;
- late close/resource fault;
- exact failed-A6 causal under repaired semantics;
- A5C, A5P2, and historical-overlay nonregression;
- no read-scope widening;
- self-attestation timing/denial coverage frozen by A6R.

Use the exact test identities and expected outcomes frozen in A6R.

## 11. Private-filesystem causals

Use only exclusive private roots.

Require direct causals for:

- stable directory identity with changing size;
- path replacement caught by inode/device identity;
- matching directory size with changed descendants;
- mode widening;
- owner/security-posture changes where safely testable;
- literal regular-file byte and size changes;
- one-nibble digest mutation;
- exact executable mutation;
- metadata-only ancestor behavior.

Do not inspect unrelated user state.

Do not modify repository or predecessor evidence.

## 12. Failed-A6 bounded requalification causal

Run only the bounded causal permitted by the A6R contract.

Use the retained failed-A6 records and/or the exact private reconstruction
defined by sealed A6R.

Do not claim live requalification of a deleted control root unless the frozen
A6R contract explicitly establishes sufficient independent evidence.

Require the causal to prove:

- source and terminal universe remain the expected pristine-final values;
- semantic integrity remains pass;
- unknown count remains zero;
- all stable policy fields are exact;
- only mutable-tree allocation metadata differs;
- repaired verification accepts that difference as report-only;
- path replacement, role change, scope change, owner/mode/security change, or
  file-byte change still rejects.

Label this:

bounded successor-tool causal only

It does not become a fresh A6 source control and cannot replace the later
five-control A6 refresh.

## 13. Two disjoint successor controls

Use pinned Go 1.26.5 under umask 077.

Each side independently owns:

- source;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build root;
- command output;
- report root;
- private read-policy probe roots.

No writable state may be shared.

Require:

- no-hardlink source copies;
- disjoint source inode sets;
- disjoint caches/build roots;
- no undeclared Git alternate or shared mutable store.

On both sides run:

gofmt -d over all Go source members

Require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*ReadPolicy'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*ReadPolicy'

Also execute the exact focused selectors frozen in the A6R causal matrix.

Require:

- every frozen causal executes;
- zero required skips;
- zero test failures;
- zero race reports;
- zero malformed streams;
- zero missing/duplicate terminals;
- no survivor;
- no forced cleanup;
- complete resource and terminal disposition.

## 14. Deterministic builds

Build independently on both sides:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require every A/B pair:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- expected mode;
- built from exact amended source;
- no unexpected absolute build path.

## 15. A6O, A5C, A5P2, and overlay nonregression

Re-run or independently reverify:

- exact 24-schema overlay dialect transition into the new policy dialect;
- all 58 historical-overlay causals;
- valid bounded Repair 9 overlay qualification;
- historical HEAD no-overlay qualification;
- final/fresh/mutant overlay-free source binding;
- all seven A5C observability tests;
- observability duration position semantics;
- A5P2 `LOCAL_PEERPID`;
- acknowledged openpty/forkpty handoffs;
- parent-alias close ordering;
- EOF/hangup evidence;
- direct `/dev/ptmx` denial;
- unrelated-terminal denial;
- PTY late-fault rejection;
- byte-comparison behavior;
- logical source, suite, and command fingerprints.

No semantic grammar, source-overlay, PTY, comparison, or execution-policy
change is authorized beyond the read-policy identity correction.

## 16. Self-attestation and least privilege

Preserve A6R’s conclusion that acceptance-bearing records remain externally
held and unreadable to the controlled command at the relevant time.

Add or retain the exact timing/denial causals frozen by A6R.

Do not grant:

- repository root;
- Downloads;
- home directory;
- credential directories;
- sealed evidence;
- unrelated user state;
- future peer-qualification records.

Do not split the control root in this tranche unless the A6R stop conditions
are triggered. Root decomposition remains a later hardening seam.

## 17. Security and authority controls

Require:

- repository remains read-only and byte-exact;
- no product/public schema change;
- no product execution-authority change;
- no general filesystem-policy framework;
- no broad read grant;
- no generic metadata weakening;
- no generic `/dev/fd` or terminal grant;
- no `.out` traversal or write;
- no PackageFloor or fixed-runtime access;
- no credential, keychain, TLS, SPIFFE, Vault, endpoint, or unrelated-user
  exposure;
- no raw PTY payload retained;
- all generated records remain evidence/projection only.

## 18. Evidence requirements

Retain:

- complete physical-root and candidate capsule;
- command-root audit;
- A6O source copy/inventory;
- exact four-file source delta;
- old and new active schema dialects;
- exact stable/volatile normative table;
- vulnerable A6O reproduction;
- all 32 causals;
- private-filesystem probe records;
- failed-A6 bounded causal;
- A/B test, race, and build records;
- binary identities;
- A6O/A5C/A5P2/overlay nonregression;
- failed and superseded attempts;
- closing repository and predecessor verification;
- cleanup and two absence epochs;
- implementation report;
- exact path/mode/size/hash inventory.

Do not claim a fresh five-control A6 result.
Do not claim historical-policy readiness.
Do not retain sensitive contents.

## 19. Closeout and sealing

Require:

- exactly the four authorized successor files changed;
- the other eight A6O source members byte- and mode-identical;
- repository remains:
  - T `8de797304ea944b6a155924e0d1e9e8bbe79534e`
  - inventory
    `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
  - membership `389/375/14`
  - staged/deleted/renamed/unmerged `0/0/0/0`;
- branch/HEAD/parent/tree/upstream/index unchanged;
- candidate root and `.git` binding unchanged;
- A6O, A6R, A5C, A5T4, failed A6, and every predecessor unchanged;
- no predecessor cache or bytecode;
- no private source, cache, build, probe, process, descriptor, socket, report,
  or temporary root remains;
- two fresh absence epochs pass;
- command-root audit proves no command used PRIMARY_R as cwd or source root.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification of:

- membership;
- path set;
- file types;
- modes;
- sizes;
- hashes;
- links;
- directory modes;
- final source T/inventory;
- binary identities;
- repository/predecessor identities;
- absence state;
- command-root audit.

## 20. Mandatory stop conditions

Stop on:

- physical-root or repository mismatch;
- baseline or lineage mismatch;
- need for a fifth successor file;
- repository mutation;
- incomplete active-schema transition;
- old schema qualifies new semantics;
- mutable-tree treatment weakens type, path, inode, device, owner, mode,
  role, scope, flags, ACL, or xattr posture beyond the frozen contract;
- file-size or digest verification weakens;
- grant scope widens;
- whole-root self-attestation appears;
- any required causal survives;
- A/B test, race, or binary mismatch;
- A6O, A5C, A5P2, or overlay regression;
- survivor, forced cleanup, or seal failure.

## 21. Verdicts

Physical-root mismatch:

REPAIR10I_A6R_IMPLEMENTATION_WORKTREE_MISMATCH

Opening or lineage mismatch:

REPAIR10I_A6R_IMPLEMENTATION_BASELINE_MISMATCH

Scope expansion required:

REPAIR10I_A6R_SCOPE_EXPANSION_REQUIRED

Contract or schema transition incomplete:

REPAIR10I_A6R_CONTRACT_INCOMPLETE

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A6R_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6R_MUTABLE_TREE_READ_POLICY_PATCH_SEALED_READY_FOR_FRESH_A6_RESTART

The success report must include:

1. Repository opening/closing identity and physical-root lock.
2. A6O and amended successor T/inventory.
3. Exact four-file delta.
4. Exact old and new 24-schema dialects.
5. Effective-read-policy.v2 contract.
6. Complete eight-record outer v5 chain.
7. Stable-versus-volatile field treatment by grant kind.
8. Vulnerable A6O causal.
9. Repaired mutable-tree causal.
10. All 32 causal outcomes.
11. Literal-file/executable nonregression.
12. Failed-A6 bounded causal and explicit non-substitution label.
13. A6O/A5C/A5P2/overlay nonregression.
14. A/B test/race/build results and binary identities.
15. Self-attestation and least-privilege result.
16. Repository no-mutation and command-root audit.
17. Manifest SHA-256, size, and payload count.
18. Cleanup and two absence epochs.
19. Explicit statement that fresh A6 was not restarted, the historical
    comparator was not implemented, product A/B was not run, and no snapshot
    or audit occurred.

No fresh A6 restart.
No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After this successor amendment seals, create a **new** A6 evidence child and rerun all five controls from the beginning. Do not resume the current failed A6 child. Implementation and later independent audit remain separate engagements, and changed bytes require new validation and a fresh audit.  

The correction remains validation scaffolding, not ES product architecture or authority. The project’s MVP freeze explicitly says proof-harness behavior must not be promoted into architecture and generated evidence remains non-authoritative. 

### Sources

- Codex’s sealed `REPAIR10I_A6R_RECONNAISSANCE_READY` report supplied in this turn.
- Milestone 0 MVP claim freeze and proof-scaffolding boundary. 
- Governed Execution implementation, repair, and independent-audit lifecycle.  
- Provenance establishes exact bytes but not correctness or authority. 

**Confidence:** 0.998 that A6R is implementation-ready; 0.97 that Model B is the correct bounded correction; 0.96 that the four-file successor scope is sufficient; 0.99 that Model D should remain a later hardening seam; 0.999 that the complete five-control A6 refresh must restart only after this amendment seals.
