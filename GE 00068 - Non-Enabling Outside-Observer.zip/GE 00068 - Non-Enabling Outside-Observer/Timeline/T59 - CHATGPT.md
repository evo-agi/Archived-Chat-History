A5S is the correct bounded closure. It repaired exactly the representability problem that prevented the missing A5 evidence from being collected:

- one exact diagnostic changed from unknown to recognized;
- the A5 test remained passing;
- no generic or ranged line-number normalization was added;
- wrong-line and overbound cases stayed blocking;
- historical and existing final/fresh/mutant semantics remained unchanged;
- repository bytes were untouched.

It does **not** freeze the historical-comparison policy and does not qualify the failed evidence-refresh attempt. Because A5S changed the successor bytes, the policy-evidence refresh must restart in a new child with two newly materialized A5 controls. The prior refresh remains negative predecessor evidence only. This separation matches the established rule that a bounded successor causal does not replace fresh downstream source controls. 

The next gate should still exclude A6 implementation, product A/B, and capture. Its sole job is to establish stable A5 full-suite semantics, recover the exact historical transition matrices, and decide whether comparator-policy work is safe or the candidate still has current regressions.

Pass this to Codex:

```text
Objective

Restart the Repair 10I-A6 policy-evidence refresh from the beginning using:

- the exact sealed Repair 10I-A5 repository source; and
- the exact sealed Repair 10I-A5S successor.

Run two newly materialized, physically independent A5 full-suite controls,
externally requalify both, require final/fresh semantic equality, and then
derive the exact HEAD→A5 and Repair-9→A5 transition and hazard matrices.

Use those exact matrices to determine whether:

1. a durable structural historical no-regression policy can now be frozen; or
2. the current A5 source contains actual blocking transitions requiring a
   repository/test/validation repair before A6 comparator-policy work.

Do not implement A6 in this turn.

Do not modify repository source.
Do not modify A5S or any predecessor evidence.
Do not resume, overwrite, seal, or promote the failed earlier policy-evidence
refresh.
Do not start B6.
Do not run product A/B.
Do not create a ZIP, handoff, capture child, or snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, execute Linux binaries, or claim independent audit or acceptance.

No subagents. You are the sole operator and evidence writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 product repair

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5S successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Sealed A4 predecessor successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Failed prior policy-evidence refresh, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-e260e1bb5ac4

Retained B4 historical semantics

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800

Required new evidence child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- protected package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require exact A5:

- manifest SHA-256:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A5S:

- manifest SHA-256:
  57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f
- payloads:
  271
- successor T:
  983943e612dd4d48ca4f0fabbc48ad51909c2e11
- successor inventory:
  799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a
- members:
  12

A5S binaries:

repair10-runner:
  ce6a44a99d4f53eaa6c8feeadc407e063deb7e6303e68f154fbe1cf0d573e68b

repair10-compare:
  e31887e0d45026d6bad6a6f2e5a4a30dd1f0f7c5bd55847991a9120ef6351e06

repair10-semantic:
  2f28bf8996b4a42d318cb16604804ad90cdb41b17517d30b4c0db85d5fbd0c2e

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require exact A4 predecessor:

- T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

Require the exact A4→A5S three-file delta:

- FORMAT.md
- envelope/envelope_test.go
- envelope/semantic.go

The other nine members must remain byte- and mode-identical to A4.

Require the failed prior policy-evidence child to remain:

- present;
- unsealed;
- byte-exact from opening through closing;
- nonqualifying.

Require its exact failed a5-final record to remain bound to:

- exact A5 T and inventory;
- test:
  TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2;
- test terminal:
  pass;
- sole unknown:
  unknown-typed-candidate-v1;
- exact source line:
  1706.

Completely reverify the A5S bounded causal against that retained stream:

- A4 extraction:
  exactly one unknown at line 1706;
- A5S extraction:
  zero unknowns;
- A5S semantic SHA-256:
  7d009b6b6108ace17b39725e83478c7362b54fa4d45a46394631573080728efc;
- exactly one semantic record changed classification;
- lifecycle and terminal sets unchanged;
- every other diagnostic record unchanged.

Reverify A, A2, A3, A4, A5, Phase H, B/B2/B3/B4/B5, the B4 divergence
reconciliation, and the failed refresh sufficiently to prove unchanged
lineage.

Require the new evidence child to be absent.

Stop on any mismatch:

REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED

## 2. Authority and evidence posture

The active validation successor for this turn is sealed A5S.

A4 is predecessor/tool-causal evidence only.

The failed prior policy-evidence refresh is expected-negative predecessor
evidence only. No command, stream, semantics, or qualification from it may
qualify the new refresh.

A5 implementation validation remains sealed same-byte predecessor evidence.
It does not replace the two fresh full-suite controls required here.

No historical comparison policy is accepted at opening.

Do not invoke A4’s compiled-in historical exception logic as policy authority.

## 3. New evidence child

Create the new child exclusively under umask 077 with exactly:

opening/
tool/
commands/
controls/
analysis/
findings/
closeout/

All directories must be mode 0700.

All files must be regular, single-link, non-symlink members with the intended
0600 or 0700 mode.

No hardlinked evidence.

Retain failed and superseded attempts additively. Never overwrite or reuse an
attempt path.

The child remains unsealed until:

- both A5 controls qualify;
- final/fresh accepted equality succeeds;
- both historical transition matrices and hazard analyses are complete;
- policy adjudication or regression adjudication is complete;
- cleanup and two absence epochs pass.

If execution fails before those conditions, leave the child unsealed.

## 4. A5S tool hard gate

Before launching a repository command:

1. Verify all 12 A5S source members.
2. Verify the exact A4→A5S three-file delta.
3. Verify all four A5S binary identities.
4. Copy each binary independently into two private tool roots.
5. Require:
   - origin-to-copy byte equality;
   - side-A/side-B byte equality;
   - all binary inodes distinct;
   - link count one;
   - expected mode;
   - no shared writable tool state.
6. Reopen and verify A5S’s sealed causals:
   - exact line-1706 A5 record recognized;
   - lines 1364 and 1375 preserve historical behavior;
   - all seven wrong-line cases remain unknown;
   - all ten malformed/overbound cases remain blocking;
   - historical HEAD semantics remain byte-identical;
   - historical Repair-9 semantics remain byte-identical;
   - sealed final/fresh and mutant-direction tool causals remain unchanged.

These records establish only the A5S tool boundary. They do not establish the
new A5 source controls.

Stop on any A5S source, binary, causal, or copy mismatch:

REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED

## 5. Two fresh A5 full-suite controls

Create two complete, physically independent controls:

1. a5-final
2. a5-fresh

Both use source class:

pristine-final

Both must independently reconstruct:

- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389

No hardlinks.

Each control must independently own:

- source;
- Git worktree metadata and object store;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- runtime root and private slots;
- process session/group;
- sockets/listeners;
- command, output, and evidence roots.

No mutable state may be shared.

Run the controls sequentially, never concurrently.

Literal repository command:

go test -json -count=1 -p=1 -parallel=1 ./...

Expected process-exit membership:

{0,1}

Exit membership alone does not qualify a control.

Use opposite A5S tool sides for producer execution and external
requalification.

For each control retain:

- source inventory, membership, and T;
- complete suite specification;
- logical fingerprint;
- command intent;
- exact executable, argv, cwd, and environment;
- effective read policy and rendered profile;
- raw stdout and stderr through EOF;
- exit and exactly one Wait disposition;
- command result;
- terminal reconciliation;
- resource ledger and worker joins;
- process, descriptor, listener, and socket observations;
- two fresh post-cleanup observations;
- producer semantic envelope;
- opposite-side raw re-extraction;
- producer qualification;
- opposite-side qualification;
- complete source/tool/spec/result lineage.

Each control must independently achieve:

- containment enforced;
- resource disposition pass;
- complete terminal reconciliation;
- no forced cleanup;
- no survivor;
- complete raw EOF;
- well-formed JSONL;
- no duplicate or missing package/test terminal;
- semantic integrity pass;
- zero unknown diagnostics;
- peer re-extraction canonical bytes equal to producer canonical bytes;
- producer qualification `qualified`;
- peer qualification `qualified`.

Any failure stops without retry:

REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED

## 6. A5 final/fresh stability gate

Compare the two fresh A5 controls using A5S’s exact final/fresh policy.

Require:

- both independently qualified;
- physical disjointness passed;
- lifecycle equal;
- diagnostics equal;
- canonical comparable semantics equal;
- zero unknowns;
- AcceptedEqual=true;
- Outcome=`qualified-equal`;
- exit 0.

Raw streams may differ and must remain reported factually.

Explicitly require equal terminal outcomes, and require pass where applicable,
for:

- TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
  one_pipe_closes_first
- TestRepair10IDualSetpgidRaceReconciliationV1
- TestRepair10ISetpgidFailureRequiresExactGroupProofV1
- TestRepair10ISetpgidInverseMutantsV1
- TestRepair10IStructuralPrivacyProjectionCausalControlsV1
- TestRemoteAlphaExternalTLST2APRepair10Contract
- TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2

A repeat of the B4 lifecycle flip blocks this turn. Do not retry it.

If final/fresh is not accepted equal:

REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED

Do not derive a policy from only one side.

## 7. Retained historical inputs

Use the exact qualified retained B4 historical records after independently
reverifying their source, raw-stream, semantic, terminal, qualification, and
extractor bindings.

HEAD semantics:

- size:
  1,252,005 bytes
- SHA-256:
  661d179e97a7449c76b32c0f5322dfabb7f53a8793734677d91e056c8e96c2c4

Repair-9 semantics:

- size:
  1,305,141 bytes
- SHA-256:
  93713c4ac02d16de6b227b84ae2339b121509bb30db4214543bc529f46378613

Re-extract their bound raw streams with both A5S sides.

Require:

- side A and side B output equality;
- equality with the A5S sealed historical compatibility results;
- zero newly introduced unknowns;
- unchanged lifecycle and terminal sets;
- unchanged non-target diagnostics and hazard classifications.

Do not rerun historical repository suites in this turn.

Do not use A4’s historical policy result as authority.

## 8. Strict transition analyzer

Create one retained source-external analyzer inside the new child.

Its complete source and self-tests must be retained.

Run it with an empty/private environment and no bytecode generation.

It must:

- strictly decode the semantic schema;
- verify source/control bindings;
- reject duplicate identity keys;
- preserve Package, Test, and Occurrence exactly;
- distinguish package terminals by empty Test;
- distinguish test/subtest terminals by nonempty Test;
- preserve exact terminal actions;
- preserve all diagnostic and intrinsic-integrity fields;
- preserve package-failure-abort records;
- emit canonical LF-terminated JSON;
- report complete input and output hashes.

Do not call A4/A5S’s historical no-regression predicate from the analyzer.

For each direction independently derive the complete transition matrices.

### Test and subtest transitions

- absent→pass
- absent→fail
- absent→skip
- pass→pass
- pass→fail
- pass→skip
- pass→absent
- fail→pass
- fail→fail
- fail→skip
- fail→absent
- skip→pass
- skip→fail
- skip→skip
- skip→absent

### Package transitions

Derive the same matrix independently.

For every transition set retain:

- complete canonical identity array;
- count;
- canonical byte length;
- canonical SHA-256;
- top-level/subtest split where applicable;
- package distribution.

Identity records must retain:

- Package;
- Test;
- Occurrence.

Do not print hundreds of identities in the final report. Provide exact retained
array paths and hashes.

## 9. Exact hazard analysis

For HEAD→A5 and Repair-9→A5 independently derive:

- new and lost panic identities;
- new and lost race identities;
- new and lost warnings;
- new and lost fatal-runtime identities;
- malformed-stream changes;
- truncated-stream changes;
- duplicate/missing start changes;
- duplicate/missing run changes;
- duplicate/missing terminal changes;
- terminal-without-start changes;
- unknown-diagnostic changes;
- package-failure-abort changes;
- aggregate process exit;
- qualification state;
- custody, resource, and terminal-reconciliation state.

Do not retain A4’s hardcoded HEAD warning or Repair-9 transition exceptions as
policy.

Determine whether exact A5 still exhibits either condition and classify it
from current evidence.

## 10. Blocking-transition source grounding

For every current A5 identity in any potentially blocking transition or hazard
set, retain:

- exact identity;
- transition;
- canonical-array reference;
- raw event references;
- source declaration path/line where recoverable;
- whether source-absent from HEAD is proven;
- whether source-absent from Repair 9 is proven;
- whether an exact sealed A5 same-byte command separately executed and passed
  that identity;
- whether it is environment-gated;
- whether it is an exact package `[no test files]` result;
- whether the cause remains unresolved.

Potentially blocking transition sets include:

- absent→fail;
- absent→skip;
- pass→fail;
- pass→skip;
- pass→absent;
- fail→skip;
- fail→absent;
- skip→fail;
- skip→absent;
- package absent→fail;
- package absent→skip;
- every new warning, panic, race, fatal-runtime, malformed, unknown, abort,
  qualification, custody, resource, or terminal failure.

Do not infer source absence from terminal absence.

## 11. Skip and no-test adjudication

A test skip may be proposed as structurally admissible only when all are
proven:

- exact intentional skip;
- bounded source-visible validation gate;
- a sealed A5 command against identical source bytes executed the same test
  and passed;
- no package abort;
- no malformed, unknown, missing, or duplicate terminal;
- no qualification/custody/resource uncertainty;
- the future comparison can bind that independent positive receipt
  structurally rather than by test-name exception.

Otherwise the skip remains blocking.

A final-only package skip may be proposed as admissible only when:

- the package is absent historically;
- its final raw stream contains exactly one bound `[no test files]` event;
- it has zero test run and terminal identities;
- no failure, abort, malformed stream, unknown, or qualification uncertainty
  exists.

A final-only failure or baseline pass→fail remains blocking unless the
transition record itself is proven erroneous. Do not introduce an identity
exception.

## 12. Policy-model adjudication

Evaluate:

A. finite identity allowlist;
B. declarations generated from a previous execution;
C. structural directional terminal/hazard relation;
D. structural directional relation plus independently bound same-byte
   validation receipts for one narrowly typed intentional-skip class.

Reject A and B unless exact new evidence overturns the prior analysis.

Determine whether C is sufficient.

If A5 contains intentional environment-gated skips that separately passed in
sealed A5 validation, evaluate D.

No accepted policy may use:

- a test-name prefix;
- a package-wide exception;
- a generated passing-identity allowlist;
- a one-off warning identity exception;
- a one-off pass→fail exception;
- producer captions as proof;
- prior-run output as self-authorizing policy.

A policy must preserve independent blocking for:

- baseline disappearance;
- pass→fail and pass→skip;
- final-only failure;
- unqualified test skip;
- package fail/abort;
- panic;
- race;
- warning;
- fatal-runtime condition;
- malformed/truncated/incomplete stream;
- unknown diagnostic;
- qualification, custody, resource, or terminal failure.

Inherited failures remain explicitly reported failures.

## 13. Policy-freeze requirements

Return `REPAIR10I_A6_POLICY_FREEZE_READY` only if one structural policy can be
frozen with:

- no identity-specific exception;
- exact test/subtest transition lattice;
- exact package transition lattice;
- finite package-no-test rule;
- finite same-byte intentional-skip receipt rule, if needed;
- independent hazard rules;
- aggregate-exit treatment;
- exact v2 schema/result direction;
- exact result fields;
- closed reason-code set;
- exact successor touched-file set;
- exact causal test matrix;
- B6 restart contract.

A candidate design may use:

- `execution-substrate.repair10i.semantic-comparison-spec.v2`
- `execution-substrate.repair10i.semantic-comparison-result.v2`
- historical policy:
  `historical-directional-no-regression-v2`

but freeze these only if supported by the completed matrices.

The preferred direction remains:

- no passing-identity allowlist;
- final-only passing identities retained and reported exactly;
- V1 historical policy parseable but nonqualifying;
- final/fresh and mutant policies unchanged.

## 14. Regression-block verdict

Return `REPAIR10I_A6_BLOCKED_BY_A5_REGRESSIONS` when:

- both A5 controls qualify;
- final/fresh is accepted equal;
- exact matrices and hazards are complete;
- one or more current A5 transitions/hazards remain blocking.

For every blocker state:

- severity and classification;
- exact identity/class;
- source and raw evidence;
- whether it is product source, active test, validation construction, or
  unresolved current behavior;
- minimal likely repair surface;
- which same-byte A5 evidence remains usable after repair;
- which full controls must be rerun.

Do not implement that repair here.

## 15. Evidence-refresh-block verdict

Return `REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED` when:

- an A5 control fails qualification;
- any unknown diagnostic remains;
- final/fresh diverges;
- A5S peer extraction differs;
- historical input binding fails;
- analyzer integrity fails;
- required transition or hazard evidence cannot be derived;
- containment, cleanup, or evidence sealing fails.

Do not retry or repair inside this turn.

## 16. Evidence and closeout

If the result is either:

- `REPAIR10I_A6_POLICY_FREEZE_READY`; or
- `REPAIR10I_A6_BLOCKED_BY_A5_REGRESSIONS`;

seal the evidence child.

Retain:

- complete opening identities;
- A5S hard-gate verification;
- prior failed refresh identity;
- both fresh A5 suite specs and source inventories;
- all command intents, streams, terminal records, resource ledgers, semantics,
  and qualifications;
- final/fresh comparison;
- analyzer source and self-tests;
- complete transition arrays and matrix summaries;
- hazard arrays;
- source-grounding and skip/no-test adjudication;
- policy-model analysis;
- exact recommended policy or regression ledger;
- failed and superseded attempts;
- cleanup and two absence epochs;
- closing repository and lineage verification;
- final report.

Require repository, A5, A5S, historical evidence, B5, and the failed refresh
to remain unchanged.

Require no private source, Git store, cache, runtime, process, descriptor,
socket, listener, analyzer root, or temporary report to remain.

Install the detached digest before the evidence manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

If the result is `REPAIR10I_A6_EVIDENCE_REFRESH_BLOCKED`, leave the child
unsealed and retain the failure evidence.

## 17. Required final report

Include:

1. Opening and closing repository and lineage identities.
2. A5S source, manifest, binary, and hard-gate identities.
3. Both A5 raw-stream, semantics, and qualification identities.
4. Final/fresh equality outcome and exact reason codes.
5. Required named A5 test outcomes.
6. HEAD→A5 test/subtest matrix.
7. HEAD→A5 package matrix.
8. Repair-9→A5 test/subtest matrix.
9. Repair-9→A5 package matrix.
10. Canonical array paths, sizes, and hashes.
11. Hazard-class deltas.
12. Complete blocker/skip/no-test adjudication.
13. Policy A/B/C/D comparison.
14. Final verdict and rationale.
15. If ready, exact A6 v2 design, touched files, tests, and B6 restart plan.
16. If blocked by regressions, exact repair ledger.
17. Evidence manifest identity and payload count, when sealed.
18. Cleanup and two absence epochs.
19. Explicit nonclaims.

## 18. Nonclaims

No A6 implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

This refresh is the first gate that can authoritatively distinguish “the comparator needs a structural policy” from “the current candidate still has regressions that the comparator must continue to block.” A5S made the exact A5 output representable; it did not decide which transitions are acceptable.

Exact manifests establish that A5 and A5S are the intended bytes, but they do not establish that the historical policy is correct or that its validation is sufficient.  After any future A6 successor edit, the downstream source controls must again be freshly materialized; the sealed A2 closeout explicitly says its bounded tool causal could not replace the required fresh downstream control.  Any later byte-changing repair also requires new provenance, validation, and a fresh independent audit. 

### Sources

- Codex’s `REPAIR10I_A5S_SEMANTIC_LINE_COMPATIBILITY_PATCH_SEALED_READY_FOR_A6_EVIDENCE_REFRESH` report in the current turn.
- Governed Execution Provenance Guidance. 
- Sealed Repair 10I-A2 restart boundary. 
- Governed Execution repair and re-audit protocol. 

**Confidence:** 0.999 that A5S closes the exact representability blocker; 0.99 that the next gate is the fresh two-control policy-evidence refresh; 0.95 that exact A5 will still expose at least one transition requiring explicit structural adjudication; 0.995 that A6 implementation remains premature until this evidence is complete.
