Here is Codex's response:

AUDIT\_PROVENANCE\_MISMATCH

Primary cause category: **opening provenance mismatch**.

The retained evidence classifies the cause as supplied-input drift. It does not establish a package implementation defect.

## 1. Exact frozen-source invocation
```
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 -I -S -B /Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-postseal-repair-qrjez1td/provenance/parent-source.py
```

Exact Python argv:
```
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-postseal-repair-qrjez1td/provenance/parent-source.py
```

No parent-source arguments were added. The noninteractive shell carrier was replaced using terminal `exec`; TTY and login-shell modes were disabled.

The runtime record retained:

- PID: `5623`
- Python: `3.13.4`
- Source size: `170197`
- Source SHA-256: `cabb33610266806babdc57cba269aab888effc4e7b346cc1b659e73d27f9ab75`
- Effective flags: `isolated=1`, `no_site=1`, `dont_write_bytecode=1`
- Source drift: `false`
- Runtime self-check: passed
- stdin read: `false`

## 2. Submitted cwd
```
/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-postseal-repair-qrjez1td
```

## 3. Explicit environment
```
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

These were the explicit stable values. The platform transcript did not enumerate unrelated inherited variables.

## 4. Platform process result

- Exit code: `0`
- Signal: none
- Platform-observed elapsed time: `0.68816975` seconds
- Terminal-seal marker emitted: no
- Parent completed by emitting a failure capsule, not by crashing or being interrupted.

## 5. Raw stdout

The platform-exposed output exactly consists of:

1. The `AUDIT_ROOT=` locator line.
2. The `PRIMARY_VERDICT=` line.
3. The retained 3,744-byte final audit report.

Result:

- Size: `3889` bytes
- SHA-256: `14865c0ff272b7a23e6e2af5710715040dab3099555dfb19238cf55e3ee67c2d`

## 6. Raw stderr

- Size: `0` bytes
- SHA-256: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

No stderr content appeared in the platform transcript. The platform result exposed one output field rather than an independently labelled stderr artifact; the empty-stderr attribution follows from that output matching the reconstructed stdout byte-for-byte.

## 7. Audit-root locator emitted

Yes. It was emitted once at epoch start.

## 8. Exact audit-root path
```
/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-883oil09
```

Retained initial identity:

- Device/inode: `16777234 / 179822492`
- Mode: `0700`

No root was located by scanning, recency, prefix matching, or scoring.

## 9. First failing provenance gate

The first failed phase was:
```
P00 — opening and fixed identities
```

Evidence: `opening/opening-gate-result.json`, status `failed`.

The runtime source check passed before supplied-root inspection. The audit plan was frozen before the supplied roots were opened. No finer ordering among the three P00 provenance failures is retained, so none is invented.

## 10. Expected versus observed values

### Frozen source and invocation

| CheckExpectedObserved |                                                                    |                         |
| --------------------- | ------------------------------------------------------------------ | ----------------------- |
| Source size           | `170197`                                                           | `170197`                |
| Source SHA-256        | `cabb33610266806babdc57cba269aab888effc4e7b346cc1b659e73d27f9ab75` | Same                    |
| Isolated mode         | enabled                                                            | `isolated=1`            |
| No-site mode          | enabled                                                            | `no_site=1`             |
| Bytecode suppression  | enabled                                                            | `dont_write_bytecode=1` |
| Source drift          | none                                                               | `false`                 |

No frozen-source identity or runtime failure was retained.

### Successor temporal inventory

Expected:

- Temporal inventory path-set equality: `true`
- Terminal chronology with no nonmanifest write after manifest closure: `true`

Observed:

- Candidate entry count: `1205`
- Candidate size: `313198`
- Candidate SHA-256: `7e3f7103e057a251a674c18508c043b7b7257bf3cfe1d7f7c2e39fa5f4213f81`
- `path_set_equal=false`
- Maximum nonmanifest mtime: `1790137418618683079`
- Minimum manifest mtime: `1790137418618255370`
- Difference: the nonmanifest mtime was `427709 ns` later
- `zero_writes_after_manifest_closure=false`

The successor’s ordinary paired manifests were byte-identical and represented their 1,207-entry closure, but its terminal temporal inventory and chronology did not authenticate the physical root as sealed.

### Blocking-audit manifest closure

Expected:

- Represented physical closure: `1362` entries
- A chosen manifest list covering the same path set
- `path_set_equal=true`

Observed:

- Candidate list: `/entries`
- Candidate count: `1361`
- Chosen list/count: `null / null`
- Identity mismatches within listed entries: none
- `path_set_equal=false`
- Manifest A and B remained byte-identical:
  - Size: `243162` each
  - SHA-256: `8438d5d1571e8cfa462f53a6df0744749aab281fb9181e602bd02f82f9dc0063`

The failure was represented-closure coverage, not disagreement between the two manifest files.

### Other opening inputs

These authenticated successfully:

- Predecessor
- Qualified launcher
- Import reconciliation
- Pinned Python interpreter

## 11. Exact causal mechanism

The frozen parent started normally, retained its runtime self-check, froze phases P00–P18, and opened the five supplied roots.

P00 then found:

1. The successor temporal inventory’s path set did not equal the freshly observed successor root.
2. The successor contained a nonmanifest write timestamp after terminal-manifest closure.
3. The blocking-audit manifest represented 1,361 paths where the physical closure required 1,362.

Those conditions were recorded as fixed-input drift and manifest mismatch. They made opening provenance false. The parent continued its predetermined finite plan so it could retain failure evidence, cleanup evidence, closing equality, and a failure capsule. Preseal remained false; terminal success manifests were therefore not generated.

## 12. Whether the frozen parent began execution

Yes.

It retained:

- The fresh audit root.
- Parent PID and runtime identity.
- Passing parent-source runtime self-check.
- Frozen audit plan.
- Opening authentication records.
- P00–P18 terminal phase records.
- Complete child ledger.
- Cleanup and closing-equality records.
- Failure closeout.

## 13. Last successfully completed audit phase

The last phase with status `passed` was:
```
P16 — closing equality
```

Its completion timestamp was `1790219746376165000`.

Afterward:

- P17 preseal: `failed`
- P18: completed as `failure-capsule`

## 14. Last qualifying child ordinal
```
2
```

Child summary:

- Ordinal 1: intentional nonexistent-executable recorder causal; spawn error; `failed-or-superseded`.
- Ordinal 2: `/usr/bin/true`; exit `0`; `qualifying`.
- Ordinal 3: fresh audit-owned validator; exit `1`; `failed-or-superseded`.

## 15. Missing, incomplete, or contradictory process records

No child-ledger gap was retained:

- Child count: `3`
- Ordinals: `[1,2,3]`
- Complete and contiguous: `true`
- All launched children reaped: `true`
- Descriptor closure: `true`
- Each child has prelaunch, result, stdout, and stderr records.
- All child stdout/stderr files are zero bytes.

The capsule explicitly does not self-attest creation of the top-level parent; the Codex platform transcript is the authority for that launch. That is an authority boundary, not a missing child-ledger record.

The runtime observation that Python’s effective flags were enabled is not contradictory with the audit-level confirmation remaining false: the former records this parent launch, while the latter required package-audit qualification that P00 did not permit.

## 16. Whether supplied roots were opened

Yes. The parent opened and inventoried exactly these retained supplied roots:
```
successor:
  /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

predecessor:
  /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

blocking-audit:
  /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

qualified-launcher:
  /Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

import-reconciliation:
  /Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s
```

They were not opened before the source self-check and frozen-plan record.

Historical failed or surviving audit roots named by the capsule were not opened or reused.

## 17. Whether supplied roots were mutated

No.

P16 retained matching opening and closing digests and entry counts for all five supplied roots. The pinned interpreter also remained equal.

The records explicitly confirm no mutation of:

- Successor
- Predecessor
- Blocking audit
- Qualified launcher
- Import reconciliation
- Prior failed audit root

## 18. Whether package correctness work began

Some audit-owned package analysis began after P00 and retained records, including the audit-owned validator and security/export analysis.

It did not produce a qualified package conclusion because opening provenance had already failed. The audit-owned validator exited `1`; three J checks passed while A/C/H/I rows were false and `producer_case_count` was `null`. Those results cannot be promoted to a package implementation defect under the failed provenance gate.

## 19. Whether materialization or handoff ran

No.

All four records say `not_reached=true`:

- Canonical materialization 1: not reached; root `null`
- Canonical materialization 2: not reached; root `null`
- Carrier 0002 handoff 1: not reached
- Carrier 0002 handoff 2: not reached

## 20. Whether audit-owned roots remain

Yes. The failed audit capsule remains at the emitted audit-root path as immutable failure evidence.

No additional materialization or temporary roots were created:
```
created_roots=[]
cleanup_row_roots=[]
```

## 21. Cleanup and closing-equality status

Cleanup:

- P15 status: `passed`
- `cleanup_complete=true`
- `set_equality=true`
- Created roots: `0`
- Cleanup rows: `0`
- Twice-absent roots: `0`

Closing equality:

- P16 status: `passed`
- All five supplied roots: opening equals closing
- Pinned interpreter: unchanged
- Overall success: `true`

## 22. Terminal inventory and manifest status

Temporal failure inventory:

- Present: yes
- Path: `closeout/temporal-final-inventory.json`
- Size: `23988`
- SHA-256: `c877473618ffc76f18d62dc3d800947d1065320e3f146aecbcc81efedd9ca240`
- Retained entries: `84`

Terminal manifests:

- `manifest/canonical-manifest-a-v1.json`: absent
- `manifest/canonical-manifest-b-v1.json`: absent
- Terminal manifest directory: present but empty
- Byte-equality comparison: not applicable
- `AUDIT_TERMINAL_SEAL_COMPLETE`: not emitted

This is consistent with failed preseal and failure-capsule closeout.

## 23. Complete retained audit-created path inventory

The temporal record contains these 84 entries:
```
analysis
analysis/failed-and-superseded-attempt-adjudication.json
analysis/finding-a-source-field-map.json
analysis/finding-c-custody-model.json
analysis/finding-h-publication-state-machine.json
analysis/j-field-map-qualification-parsing.json
analysis/perspective-contract-authority.json
analysis/perspective-filesystem-security.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/producer-50-case-classification.json
analysis/producer-h-matrix-authentication.json
analysis/replay-evidence-closure.json
analysis/security-export-authority.json
analysis/severity-ranked-residual-findings.json
causals
causals/finding-i-real-case-28.json
cleanup
cleanup/cleanup-set-equality.json
closeout
closeout/explicit-confirmations.json
closeout/final-audit-report.md
closeout/parent-preseal-outcome.json
closeout/phase-terminal-results.json
closeout/primary-verdict.json
closing
closing/blocking-audit-closing-inventory.json
closing/import-reconciliation-closing-inventory.json
closing/predecessor-closing-inventory.json
closing/qualified-launcher-closing-inventory.json
closing/successor-closing-inventory.json
closing/supplied-root-closing-equality.json
manifest
opening
opening/blocking-audit-authentication.json
opening/blocking-audit-opening-inventory.json
opening/bootstrap-start.json
opening/fixed-semantic-and-evidence-identities.json
opening/frozen-audit-plan.json
opening/governing-blocking-audit-authentication.json
opening/import-reconciliation-authentication.json
opening/import-reconciliation-opening-inventory.json
opening/opening-gate-result.json
opening/package-producer-record-bindings.json
opening/parent-source-runtime-self-check.json
opening/pinned-python-authentication.json
opening/predecessor-authentication.json
opening/predecessor-opening-inventory.json
opening/qualified-launcher-authentication.json
opening/qualified-launcher-opening-inventory.json
opening/successor-authentication.json
opening/successor-identity-registry.json
opening/successor-opening-inventory.json
process
process/child-0001-prelaunch.json
process/child-0001-result.json
process/child-0001-stderr.bin
process/child-0001-stdout.bin
process/child-0002-prelaunch.json
process/child-0002-result.json
process/child-0002-stderr.bin
process/child-0002-stdout.bin
process/child-0003-prelaunch.json
process/child-0003-result.json
process/child-0003-stderr.bin
process/child-0003-stdout.bin
provenance
provenance/child-recorder-self-causals.json
provenance/complete-child-ledger.json
provenance/historical-failed-audit-disposition.json
provenance/parent-process-start.json
provenance/parent-source.py
validation
validation/canonical-materialization-1.json
validation/canonical-materialization-2.json
validation/carrier-0002-handoff-1.json
validation/carrier-0002-handoff-2.json
validation/finding-a-fresh-causal-matrix.json
validation/finding-c-fresh-causal-matrix.json
validation/fresh-audit-owned-validator-result.json
validation/fresh-audit-owned-validator.py
validation/fresh-publication-boundary-matrix.json
validation/independent-bootstrap-validator-result-v1.json
validation/renameatx-np-rename-excl-capability.json
```

The retained inventory intentionally excludes:
```
root
closeout/temporal-final-inventory.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json
```

Therefore, the complete presently retained audit-created path set is:

- The audit root itself
- The 84 entries above
- `closeout/temporal-final-inventory.json`

The two terminal manifest paths do not exist.

## 24. Exact recommended next action

Preserve this failed root unchanged as audit-process evidence.

The owners of the supplied provenance artifacts should create new immutable roots—not alter these roots—with:

1. A successor temporal inventory whose path set exactly equals the physical root under its declared exclusions.
2. No nonmanifest write after terminal-manifest closure.
3. A blocking-audit manifest covering all `1362` expected represented paths.
4. Two byte-identical terminal manifests generated only after closure.
5. A newly frozen and independently qualified parent capsule pinned to those new identities.

Only a separate explicit authorization should execute that new parent once. The existing parent must not be rerun against repaired, replaced, or drifted inputs.

## 25. Explicit nonclaims and category distinction

| ClassificationResult               |                                                                                                                                                             |
| ---------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Audit-process defect               | Not established. The parent source self-check passed, the ledger is complete, and failure closeout completed normally.                                      |
| Supplied-input drift               | Established; this is the primary cause.                                                                                                                     |
| Package implementation defect      | Not established and not claimed.                                                                                                                            |
| Audit-harness oracle/parser defect | Not adjudicated. The failed audit-owned validator retained suspicious/unqualified results, but opening provenance failed first.                             |
| Unavailable evidence               | Exact missing successor temporal-inventory path names were not retained in the summarized authentication record; no qualified package verdict is available. |

Further nonclaims:

- No ACCEPT, BLOCK, or REJECT package verdict.
- No candidate-repository inspection.
- No Strategic B inspection.
- No V1/V2/V3 target audit.
- No full target audit or A6 work.
- No product/runtime, deployment, readiness, or publication authority.
- No Git commit or external-publication authority.
- No crash-safety, power-loss, or eventual target-audit conclusion.
- No authorization to repair package code, supplied roots, audit records, or the frozen source.

Required confirmations:
```
FAILED_ATTEMPT_NOT_RESUMED
FAILED_ATTEMPT_NOT_REPAIRED
REPLACEMENT_PARENT_NOT_LAUNCHED
SUPPLIED_ROOTS_NOT_MUTATED
PACKAGE_REPAIR_NOT_AUTHORIZED
GIT_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
SUBAGENTS_CREATED: 0
```
