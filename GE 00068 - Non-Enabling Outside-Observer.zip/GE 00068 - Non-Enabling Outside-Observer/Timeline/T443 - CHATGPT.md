## Engineering assessment

The repaired Generation‑2 package is now a credible implementation authority. The previous blocker was not papered over: the successor contract changes the physically impossible launch sequence into an executable one and proves that sequence through an audit-owned filesystem model.

The decisive improvements are:

- **E00 is outside the package state machine.** Runtime and source authentication can occur before a subject root exists, without inventing package authority.
- **G00 can now physically write its required evidence.** It allocates the root, creates `opening/`, durably retains a nonauthoritative bootstrap record, and only then emits the locator.
- **G01 establishes the complete directory namespace**, including `closeout/` and `manifest/`, before any later phase relies on those directories.
- **G02–G04 establish authority monotonically:** execution provenance, fixed-input authentication, then external-interface closure.
- **G05–G29 remain semantically preserved.**
- The successor has an exact 73-path future namespace, one writer per path, explicit pre- and post-locator failure semantics, 15 complete traces, a 45-case boundary matrix, and a physical implementability proof.
- The package closed terminally, and its independent validator passed.

There is no remaining contract-level reason to delay source creation. Another documentary audit before implementation would add little; the two complete rehearsals and the later independent implementation-package audit are the correct places to discover implementation defects.

The next tranche should therefore create a **new clean implementation from the successor package only**. It must not reuse source from the blocked attempt or any earlier lineage. It must finish with frozen source pending a separate independent audit and must not construct the current schema subject.

```text
IMPLEMENT AND QUALIFY THE REPAIRED GENERATION-2
SCHEMA-SUBJECT RECONSTRUCTION PARENT

Objective

Create a new clean-room implementation of the schema-subject reconstruction
parent from the sealed successor Generation-2 contract package.

Implement the repaired E00 and G00–G04 bootstrap model and the preserved
G05–G29 semantics; complete producer qualification; run two full disposable
subject rehearsals; independently validate both rehearsals; freeze the exact
source bytes used by both; requalify those frozen bytes; and terminally close
the implementation package.

Do not construct the authoritative current schema subject in this task.

Do not claim independent acceptance of the implementation package. A separate,
fresh, source-external audit of the completed implementation package is
mandatory before the frozen parent may be used once to construct the current
schema subject.

This task is not:

- another Generation-2 contract repair;
- another historical reconciliation;
- a repair or continuation of the blocked implementation root;
- a reuse of Candidate 2 or V1–V4 source;
- the product construction-parent implementation;
- product process-self-test;
- product construct mode;
- a target audit;
- runtime validation;
- repository work;
- publication, deployment, or A6 work.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned implementation and qualification process in one
fresh private implementation-package root.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace material identities, causal findings, commands,
validation counts, process custody, or disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_BLOCKED

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. SOLE GOVERNING SUCCESSOR CONTRACT PACKAGE
──────────────────────────────────────────────────────────────────────────────

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected root identity:

- device:
  16777234
- inode:
  180871216
- mode:
  0700
- retained verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_BOOTSTRAP_ORDER_REPAIRED_READY_FOR_IMPLEMENTATION

Expected current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  180880724
- size:
  21069
- SHA-256:
  afbca81dd1812a38183c875890b88dc5631d28579962148d47deef140161b636

Expected manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Each:

- size:
  23268
- SHA-256:
  e83fcb2f7f27aef3af1306e9aa91f64fad6e24963937aff51b1e9eed42dbc3bf

Authenticate before implementation:

- root device/inode/mode;
- temporal-inventory identity;
- manifest A/B identity and byte equality;
- exact 89-entry represented manifest projection;
- 91-entry physical root;
- root row exactly once;
- terminal topology and modes;
- no empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- no cache or bytecode;
- no-write-after-seal posture;
- retained status;
- retained 84-confirmation registry;
- independent bootstrap-order validator result.

Use `contract/current-gen2-contract-role-registry-v2.json` as the sole selector
for current governing Generation-2 artifacts.

Do not select a governing artifact by:

- predecessor filename;
- basename;
- recursive discovery;
- first match;
- latest/newest;
- shortest or longest document;
- content scoring;
- historical report references;
- fallback.

Unknown, missing, duplicated, ambiguous, or identity-mismatched current roles
are terminal blockers.

Require complete opening/closing equality for GEN2_SUCCESSOR_ROOT.

──────────────────────────────────────────────────────────────────────────────
2. CURRENT GENERATION-2 GOVERNING ROLES
──────────────────────────────────────────────────────────────────────────────

Resolve every one of the 41 current roles in the current role registry.

At minimum, the current role set must bind the successor versions of:

Launch and bootstrap:

- launch-envelope;
- reconstruction state machine;
- bootstrap output registry;
- bootstrap failure and locator;
- early-state trace model;
- bootstrap-order mutation matrix;
- abstract implementability proof;
- independent bootstrap-order validator.

Namespace and output:

- future subject artifact plan;
- phase/function/path writer registry;
- namespace-finalization rules;
- temporal-inventory lifecycle;
- terminal-manifest lifecycle.

Authority and process:

- reconstruction-parent authority;
- process custody;
- failure evidence and cleanup;
- external interfaces;
- total JSON observation;
- internal special cases.

Source and qualification:

- source architecture;
- implementation qualification.

Preserved validation:

- contract witnesses;
- state-machine matrix;
- namespace/temporal matrix;
- writer/lifecycle matrix;
- process/failure-custody matrix;
- parent perspectives;
- perspective reconciliation.

Lineage, status, confirmation, and report roles:

- bootstrap-order repair lineage;
- current package status;
- explicit confirmations;
- terminal report data.

Retain:

opening/current-gen2-role-resolution-v1.json

For every role bind:

- role ID;
- exact current path;
- exact file identity;
- predecessor identity when retained;
- current status;
- semantic owner;
- authority classification;
- implementation consumer.

Require exactly 41 resolved current roles and no historical artifact silently
used as current.

──────────────────────────────────────────────────────────────────────────────
3. AUTHORITATIVE EXTERNAL INPUTS
──────────────────────────────────────────────────────────────────────────────

Resolve all exact supplied inputs through the current Generation-2 external
interface and role registries.

At minimum:

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use:

- the normative contract as the sole semantic writer;
- only the fifteen current v2 schemas;
- only root-independent case registries and validation specifications from the
  validation-specification source.

Do not copy historical:

- package status;
- result files as fresh results;
- temporal inventories;
- terminal manifests;
- root-bound confirmations;
- P06/P18 records;
- reports or verdicts;
- package authority.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
4. PROHIBITED SOURCE INPUTS
──────────────────────────────────────────────────────────────────────────────

Do not copy, import, transform, patch, execute, or use as an implementation
base any source from:

- the blocked Generation-2 implementation root;
- Candidate 2;
- the Candidate 2 replay;
- V1;
- V2;
- V3;
- V4;
- any earlier reconstruction parent;
- any earlier process recorder;
- any earlier validator;
- any earlier finalizer;
- any earlier manifest generator.

The repaired Generation-2 contract package contains the governing defect
catalogue and lineage. Historical source roots do not need to be opened for
implementation.

Retain:

opening/gen2-clean-room-source-authority-v1.json

Require:

- production source initially absent;
- qualification source initially absent;
- no historical source copy;
- no historical patch provenance;
- no historical module import;
- no historical AST fragment as source origin;
- implementation authority derives only from:
  - current Generation-2 contracts;
  - normative contract;
  - current schemas;
  - current validation specifications.

Textual similarity is report-only and is not an acceptance oracle.

──────────────────────────────────────────────────────────────────────────────
5. FRESH IMPLEMENTATION-PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-

Immediately emit:

IMPLEMENTATION_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh implementation-root identity;
- allocation method and umask;
- successor Generation-2 package identity;
- current role-registry identity;
- authoritative external-input identities;
- clean-room source authority;
- implementation authority;
- explicit nonauthority;
- source-attempt limit;
- current schema subject construction authorized:
  false;
- independent implementation audit performed:
  false;
- one-shot current-subject use authorized:
  false;
- product process-self-test authorized:
  false;
- product construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- publication/deployment/A6 authorized:
  false;
- same-root retry authorized:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. PRE-SOURCE IMPLEMENTABILITY AND OPERATING FREEZE
──────────────────────────────────────────────────────────────────────────────

Before writing production or qualification source, retain:

opening/gen2-implementation-operating-freeze-v1.json

It must bind every governing Generation-2 role and prove:

- E00 performs in-memory/platform-authenticated launch checks only;
- E00 writes no subject-package path;
- E00 allocates no subject root;
- G00 can physically allocate the root;
- G00 can create `opening/`;
- G00 can write and durably retain `opening/bootstrap-start.json`;
- locator emission occurs only after G00 durability;
- G01 can create and verify every remaining final directory;
- `closeout/` and `manifest/` exist at G01;
- no directory creation occurs after G01;
- G02 can durably create execution authority;
- G03 can durably create fixed-input authentication;
- G04 can durably create external-interface freeze;
- every G00–G04 output has one writer;
- G05 preconditions are physically satisfiable;
- G05–G29 semantics remain as frozen;
- all failure classes have physically executable retention or cleanup paths;
- no successful path requires a write before its containing directory exists;
- no success or failure path requires adoption, overwrite, or same-root retry.

Also retain:

validation/pre-source-gen2-implementability-preflight-v1.json

This is a source-external preflight, not implementation qualification.

It must independently replay the successor package’s abstract implementability
proof and all 15 early-state traces.

If this gate fails:

- create no production source;
- return the implementation-blocked verdict;
- do not create a source attempt.

──────────────────────────────────────────────────────────────────────────────
7. IMPLEMENTATION SOURCE LAYOUT
──────────────────────────────────────────────────────────────────────────────

Derive and retain:

contract/gen2-implementation-source-layout-v1.json

Map every current component role from the successor source architecture to:

- exact relative source path;
- production or qualification classification;
- component authority;
- component nonauthority;
- exact allowed imports;
- exact forbidden imports;
- inputs;
- outputs;
- mutable facts written;
- process-launch authority;
- filesystem-write authority;
- consumers.

The successor architecture must resolve all current component roles. Preserve
the exact role count and identities from the current source-architecture
record; do not use predecessor counts if the successor changed them.

Require:

- every role mapped exactly once;
- no unregistered source;
- no silent authority merge;
- production never imports qualification code;
- independent validators never import production code or producer helpers;
- one production parent;
- one production child recorder;
- two independently implemented terminal-manifest projectors;
- one terminal-seal controller;
- one failure-finalization owner;
- one cleanup owner;
- explicit E00 launch-envelope implementation;
- explicit G00–G04 phase implementations.

Retain planned registries:

contract/gen2-production-source-registry-v1.json
contract/gen2-qualification-source-registry-v1.json

Close them with exact identities after source creation.

──────────────────────────────────────────────────────────────────────────────
8. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most three complete source attempts are permitted.

A complete attempt begins when:

- its production source registry closes;
- its qualification source registry closes;
- compilation starts.

For every attempt retain:

- complete production-source identities;
- complete qualification-source identities;
- compilation;
- static checks;
- matrices reached;
- rehearsal result when reached;
- first blocker;
- supersession disposition.

Any source modification after compilation begins creates a new source attempt.

No failed or superseded attempt contributes:

- final source identity;
- passing case counts;
- rehearsal result;
- source freeze;
- readiness verdict.

If attempt 3 fails any required prefreeze gate:

- return the blocked verdict;
- do not create attempt 4.

──────────────────────────────────────────────────────────────────────────────
9. CLEAN PRODUCTION IMPLEMENTATION
──────────────────────────────────────────────────────────────────────────────

Implement a clean production parent from the successor Generation-2 contracts.

The production parent exposes exactly one mode:

--mode reconstruct-subject

No default mode.

Use the pinned interpreter and required `-I -S -B` invocation frozen by the
current process and launch-envelope contracts.

Implement the exact execution model:

E00 — platform launch and in-memory self-authentication

- authenticate interpreter;
- authenticate `-I -S -B`;
- authenticate exact source;
- authenticate argv, cwd, environment, and stdin posture;
- allocate no subject root;
- write no subject path;
- grant no package authority.

G00 — fresh root, opening directory, durable bootstrap, locator

- allocate exactly one fresh root;
- create `opening/` mode 0700;
- exclusively write `opening/bootstrap-start.json`;
- fsync file and directory;
- reopen no-follow and verify;
- emit exactly:
  SUBJECT_ROOT=<absolute-path>\n
- emit no extra stdout.

G01 — exact remaining directory namespace

- create every remaining final directory from the current v2 artifact plan;
- include `closeout/` and `manifest/`;
- set modes 0700;
- retain namespace-materialization evidence;
- verify exact directory-set equality;
- forbid all later directory creation.

G02 — durable execution-authority commit

- exclusively write current execution-authority record;
- bind E00, G00, and G01;
- fsync, close, fsync parent, reopen, verify;
- grant execution provenance only.

G03 — fixed-input authentication

- authenticate all supplied roots and fixed files;
- use exact current external-interface contract;
- no fallback;
- exclusively retain fixed-input authentication;
- grant fixed-input authority only.

G04 — external-interface freeze

- bind all current interfaces, exact pointers, types, counts, uniqueness, and
  digests;
- exclusively retain current interface-freeze record;
- grant interface authority only.

G05–G29

- implement every current successor phase exactly;
- preserve current phase order;
- preserve current authority boundaries;
- use current v2 artifact plan and writer registry;
- do not substitute predecessor phase semantics.

Production restrictions:

- no network;
- no Git;
- no shell;
- no PATH lookup for executables;
- no broad Downloads scan;
- no latest/newest/prefix/score selection;
- no existing-root adoption;
- no inherited environment beyond explicitly frozen mechanics;
- no stdin reads;
- finite control flow;
- every child through one recorder;
- fresh output root only;
- exclusive writes;
- no overwrite;
- no symlink following;
- no same-root retry;
- no administrative continuation;
- no repository/product/target operation.

──────────────────────────────────────────────────────────────────────────────
10. EXACT CURRENT FUTURE NAMESPACE
──────────────────────────────────────────────────────────────────────────────

Implement the exact current future-subject namespace from:

- the current role registry;
- current `future-schema-subject-artifact-plan-v2`;
- current writer registry.

The successor report establishes:

- 73 total paths;
- 61 files;
- 12 directories including the root.

Do not reconstruct the path set from prose.

Before source implementation, retain an exact path ledger derived from the
current artifact plan:

contract/gen2-current-future-subject-path-ledger-v1.json

For every path bind:

- artifact role;
- file or directory;
- phase;
- component;
- function;
- write operation;
- maximum successful writes;
- mode;
- lifecycle;
- consumers;
- root-bound status;
- terminal-exclusion status.

At successful G01:

- every final directory exists;
- exact directory-set equality passes;
- no later directory creation is possible.

At G25:

- verify the already-final directory set;
- freeze planned final paths;
- allow after G25 only:
  - temporal inventory file in preexisting `closeout/`;
  - manifest A/B in preexisting `manifest/`.

Unknown output is a blocker.

──────────────────────────────────────────────────────────────────────────────
11. WRITER AND DOCUMENTARY-EVIDENCE ENFORCEMENT
──────────────────────────────────────────────────────────────────────────────

Implement the current successor writer registry exactly.

For every final path:

- one phase;
- one component;
- one function;
- one creation event;
- exclusive creation;
- no overwrite;
- no adoption;
- no final path used as staging;
- no second successful write.

Implement the documentary-evidence order frozen by the current successor
package.

At minimum preserve:

1. prerequisite documentary-validator results;
2. confirmation evidence map;
3. confirmation-evidence-map validator;
4. final ten-role registry;
5. registry-derived regeneration;
6. independent schema validation;
7. evidence-derived confirmations;
8. occupancy/status/lineage/report;
9. temporal inventory;
10. terminal manifests.

The confirmation-validator result must be created exactly once.

The final registry must be written only after all required current results
exist and authenticate.

Regeneration must derive from the retained final registry.

No result validates itself.
No placeholder uses a final result path.
No hard-coded count substitutes for retained rows.

──────────────────────────────────────────────────────────────────────────────
12. EXTERNAL INTERFACES AND TOTAL JSON OBSERVATION
──────────────────────────────────────────────────────────────────────────────

Implement every exact current external interface resolved from the successor
contract package.

Rules:

- exact authority and path;
- strict JSON;
- duplicate-key rejection;
- nonfinite rejection;
- exact pointer;
- exact type;
- no alias;
- no fallback;
- no recursive arbitrary list selection;
- no first/longest/same-length selection;
- no basename/content/recency scoring;
- missing field fails;
- wrong type fails;
- count derives from rows;
- uniqueness derives from row keys;
- digest independently recomputed;
- summary fields corroborate only;
- absence never means false, zero, empty, or success.

For the 946-case registry use the exact current vocabulary frozen in the
successor package. Do not recognize `literal_names_unique` unless the current
successor contract explicitly does—which the governing report says it does
not.

Implement total observation statuses:

- present;
- absent;
- wrong-container-type;
- invalid-pointer-token;
- invalid-array-index;
- duplicate-key-source-invalid;
- wrong-top-level-type.

No chained object access on untrusted or mutated JSON.

No object-only operation without an exact object-type observation.

No array access without exact array type and bounds.

──────────────────────────────────────────────────────────────────────────────
13. CURRENT SPECIAL CASES
──────────────────────────────────────────────────────────────────────────────

Implement every current special case from the current successor role.

At minimum:

- `normative-construction-parent` is the sole schema role without a generated
  family;
- exactly fourteen generated families;
- zero children is valid;
- zero cleanup roots is valid;
- empty but equal cleanup sets are valid;
- raw false remains raw false;
- positive assertion over false uses an explicit predicate;
- null blocker only in the frozen success context;
- empty error arrays are valid;
- root row `"."` is explicit;
- terminal self-exclusions are explicit;
- reserved `manifest/` is lifecycle-bound;
- implementation present remains false in generated subject evidence;
- implementation authority remains false;
- independent acceptance remains false before audit.

Do not use generic truthiness for acceptance-bearing numeric, Boolean, null, or
collection posture.

──────────────────────────────────────────────────────────────────────────────
14. PROCESS CUSTODY AND LOCATOR
──────────────────────────────────────────────────────────────────────────────

Implement the current v2 process and bootstrap custody contracts.

Require:

- platform owns top-level parent creation;
- parent owns child creation and ledger;
- one recorder;
- prelaunch before spawn;
- contiguous ordinals;
- exact argv/cwd/environment/stdin/timeout;
- exact stdout/stderr bytes, sizes, and hashes;
- exit or signal;
- reaping;
- descriptor closure;
- fixed-output attribution;
- dynamic-root attribution;
- nonzero-exit attribution;
- timeout attribution;
- no shell;
- no PATH lookup;
- no persistent supervisor loop.

Locator:

- exactly `SUBJECT_ROOT=<absolute-path>\n`;
- once only;
- only after durable bootstrap-start;
- exact allowed parent and prefix from the current contract;
- absolute path;
- no extra stdout;
- parse on zero and nonzero completion;
- no scan, guess, fallback, latest, or score selection.

Every root effect must be attributed before cleanup.

──────────────────────────────────────────────────────────────────────────────
15. FAILURE FINALIZATION
──────────────────────────────────────────────────────────────────────────────

Implement every current v2 failure class.

At minimum:

E00 failure:

- no subject root;
- no locator;
- platform/process evidence only.

G00 pre-allocation failure:

- no root;
- no locator.

G00 after allocation but before opening:

- exact root identity known;
- inventory/cleanup or retention exactly as frozen;
- no locator;
- no package authority.

G00 after opening but before durable bootstrap:

- no locator;
- exact evidence and cleanup/retention policy.

G00 after durable bootstrap but before locator:

- failed root retained under bound platform custody;
- no locator;
- explicit nonauthority.

Post-locator failure:

- root retained immutably;
- complete failure evidence;
- no same-root retry.

G01–G04 failure:

- subject root retained;
- first blocker;
- complete partial inventory;
- process ledger and streams;
- subsidiary fixture cleanup only;
- exact authority boundary for completed phases.

Later failure:

- preserve current Generation-2 semantics.

Before removing any owned fixture root:

- retain root identity;
- retain complete inventory;
- retain process records and streams;
- retain indispensable evidence in the governing package;
- revalidate identity;
- remove exact root;
- observe ENOENT twice.

Require exact cleanup-set equality.

No path inside a removed root counts as retained evidence.

──────────────────────────────────────────────────────────────────────────────
16. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

For each source attempt:

1. Compile all sources under pinned Python using `-I -S -B`.
2. Require exit 0 and empty stderr.
3. Run AST/call-graph/dataflow analysis.
4. Run bytecode/exception-table/CFG analysis.
5. Crosswalk every:
   - process launch;
   - filesystem write;
   - directory creation;
   - cleanup;
   - terminal operation;
   - locator emission;
   - authority transition.

Require:

- exactly one production parent;
- exactly one production recorder;
- no unregistered process launch;
- no unregistered write;
- E00 writes no subject path;
- G00 allocates the only subject root;
- `opening/` exists before bootstrap-start;
- locator after bootstrap durability;
- all directories created at G01;
- no directory creation after G01;
- G02 authority only after namespace completion;
- G03 only after G02;
- G04 only after G03;
- no duplicate writer;
- no successful second write;
- no overwrite;
- no result adoption;
- no network;
- no Git;
- no shell;
- no stdin read;
- no persistent loop;
- no import-time execution;
- no repository/product/target operation;
- no production-reachable qualification hook;
- total JSON observation on untrusted data;
- explicit special-case branches;
- complete failure finalization;
- one terminal seal transition;
- no postseal filesystem operation.

A static aggregate is false if any required field is false.

──────────────────────────────────────────────────────────────────────────────
17. REQUIRED QUALIFICATION MATRICES
──────────────────────────────────────────────────────────────────────────────

Execute every matrix required by the current
`gen2-implementation-qualification-v2` role.

At minimum include:

A. E00/G00–G04 bootstrap-order matrix

Include all current 45 inherited bootstrap-order cases and additional
source-level implementation cases as required.

B. External-interface matrix.

C. Total JSON-observation matrix.

D. Schema-role/family matrix.

E. Process-custody and locator matrix.

F. Failure-evidence and cleanup matrix.

G. Writer/documentary-lifecycle matrix.

H. Namespace/temporal matrix.

I. Manifest/terminal matrix.

J. Negative-checker robustness matrix.

Every matrix requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Each matrix must include the exact relevant historical defect cases retained by
the successor defect catalogue.

──────────────────────────────────────────────────────────────────────────────
18. INDEPENDENT COMPONENT VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Implement every current qualification-only validator role.

Independent validators may not import:

- production modules;
- producer helpers;
- producer mutation builders;
- producer expected-result maps;
- production JSON observers;
- production manifest projectors.

Independently implement:

- strict parsing;
- total pointer observation;
- supplied-root inventory;
- launch/bootstrap trace adjudication;
- schema/family closure;
- negative-case adjudication;
- process custody;
- failure cleanup;
- writer/lifecycle adjudication;
- namespace and temporal adjudication;
- terminal manifest reprojection.

An independent-validator exception is a qualification failure.

──────────────────────────────────────────────────────────────────────────────
19. COMPLETE REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

After every component gate passes, invoke the exact production parent once.

Use the exact current Generation-2 invocation contract:

- pinned Python;
- `-I -S -B`;
- exact source;
- exact argv;
- exact cwd;
- exact environment;
- DEVNULL stdin;
- finite timeout;
- no shell.

Do not preallocate the subject root if the current G00 contract assigns root
allocation to the production parent.

Capture the exact `SUBJECT_ROOT` locator and bind the returned root.

The rehearsal must complete E00 and G00–G29 and produce the exact current
73-path, 61-file subject package.

Require fresh completion of:

- E00 runtime/source authentication;
- G00 durable bootstrap and locator;
- G01 directory namespace;
- G02 execution authority;
- G03 fixed-input authentication;
- G04 interface freeze;
- G05–G29;
- exact contract/schema copying;
- 15-role registry;
- 14-family authority and mapping;
- metaschema validation;
- family reconstruction;
- witnesses;
- complete 946 negative cases;
- complete 137 contradiction cases;
- 766/333 field map;
- documentary-validator results and lifecycle;
- independent schema validator;
- confirmation evidence;
- occupancy/status/lineage/report;
- fixture cleanup;
- supplied-root closing equality;
- namespace finalization;
- temporal inventory;
- manifest pair;
- final reprojection;
- terminal topology;
- no postseal activity.

Required rehearsal status:

rehearsal-passed-nonauthoritative

Do not claim independent acceptance.

Keep the rehearsal root until all evidence is safely retained.

──────────────────────────────────────────────────────────────────────────────
20. COMPLETE REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Run the same exact source bytes, argv shape, environment, and supplied inputs.

Require a physically distinct returned root.

Require the same complete E00/G00–G29 pipeline.

Retain:

validation/two-complete-gen2-successor-rehearsals-v1.json

Normalize only explicit physical bindings:

- root path;
- device/inode;
- root-bound generated identities;
- PIDs;
- nonacceptance-bearing timestamps;
- explicitly enumerated physical fields.

Require semantic equality for:

- normative contract;
- fifteen schema identities;
- fifteen-role rows;
- fourteen-family rows;
- mapping;
- witnesses;
- all 946 results;
- all 137 results;
- all 766/333 field-map rows;
- ten-role registry;
- all validator results;
- confirmation semantics;
- occupancy/status/lineage;
- temporal semantics;
- normalized terminal manifests.

Require zero unexplained difference.

──────────────────────────────────────────────────────────────────────────────
21. INDEPENDENT REHEARSAL VALIDATION
──────────────────────────────────────────────────────────────────────────────

Run the independent rehearsal validator against both retained roots.

It must independently verify:

- E00/G00–G04 trace;
- exact locator and root identities;
- planned membership;
- no unplanned output;
- exact 73-path namespace;
- exact directories;
- contract and schemas;
- 15/14 closure;
- witnesses;
- 946/137 closure;
- field-map closure;
- documentary lifecycle;
- ten-validator closure;
- process custody;
- failure-custody capability;
- supplied-root equality;
- cleanup;
- temporal inventory;
- manifests;
- final reprojection;
- terminal topology;
- normalized determinism.

Require zero errors and no exception.

──────────────────────────────────────────────────────────────────────────────
22. REHEARSAL EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing either rehearsal, retain in the implementation package:

- exact root identity;
- complete physical inventory;
- complete process ledger;
- all stdout/stderr;
- every validation result identity;
- temporal and manifest identities;
- normalized comparison;
- independent rehearsal-validator result;
- terminal posture;
- failure evidence, when any.

Require a passing evidence-retention record.

Then:

- re-lstat A and verify identity;
- remove A;
- observe ENOENT twice;
- re-lstat B and verify identity;
- remove B;
- observe ENOENT twice;
- require zero process survivor;
- require zero descriptor survivor;
- require zero cache/bytecode survivor.

Require exact equality:

created rehearsal roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

──────────────────────────────────────────────────────────────────────────────
23. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze source only after:

- every static gate passes;
- every required matrix passes;
- every independent component validator passes;
- rehearsal A passes;
- rehearsal B passes;
- normalized equality passes;
- independent rehearsal validation passes;
- rehearsal evidence retention passes;
- rehearsal cleanup passes.

Retain:

opening/gen2-implementation-source-freeze-v1.json

Bind:

- exact production source registry;
- exact qualification source registry;
- clean-room provenance;
- successor Generation-2 package identity;
- current governing-role resolution;
- matrices;
- rehearsal A/B;
- normalized comparison;
- independent rehearsal validation;
- cleanup;
- supplied inputs;
- later source modification permitted:
  false;
- current subject constructed:
  false;
- one-shot authoritative use permitted:
  false;
- fresh independent implementation audit required:
  true.

Reopen every source no-follow and verify exact identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
24. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen bytes, rerun:

- compilation;
- all static gates;
- import and source-boundary checks;
- every required literal matrix;
- independent component validators;
- source/rehearsal identity linkage;
- supplied-root equality.

Do not rerun the two complete rehearsals.

Require proof that both passing rehearsals used the exact bytes later frozen.

Retain:

validation/gen2-frozen-source-requalification-v1.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
25. IMPLEMENTATION-PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate a preterminal status record:

- status:
  gen2-bootstrap-repaired-reconstruction-parent-implemented-qualified-frozen-pending-independent-audit;
- authority:
  schema-subject reconstruction tooling only;
- current subject constructed:
  false;
- producer qualification:
  passed;
- independent implementation-package audit:
  not performed;
- one-shot current-subject use:
  not authorized;
- product implementation present:
  false;
- process-self-test:
  not executed;
- product construct mode:
  not executed;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- publication/deployment/A6:
  not authorized.

Do not claim implementation acceptance.

──────────────────────────────────────────────────────────────────────────────
26. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- successor Generation-2 package;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any additional supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every implementation-owned fixture/cache root:

- retain complete inventory;
- retain indispensable evidence;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
27. IMPLEMENTATION-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the repaired namespace discipline for the implementation package itself.

Before temporal projection:

- create every final implementation-package directory, including
  `closeout/` and `manifest/`;
- finalize every nonclosure output;
- freeze exact directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and future A/B;
2. write it into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. exclusively create zero-length A/B in preexisting `manifest/`;
6. retain both descriptors;
7. independently generate A/B bytes with both paths excluded;
8. require equality;
9. write/fsync/close;
10. fsync manifest directory;
11. reopen no-follow;
12. verify path/inode/type/mode/link/size/hash;
13. independently reproject final root;
14. require root row exactly once;
15. require no empty descendant;
16. require no symlink or special object;
17. require no multiply linked regular file;
18. require modes 0700/0600;
19. require no cache or bytecode;
20. transition seal exactly once;
21. emit only guarded terminal marker;
22. exit nonreturningly;
23. perform no filesystem read or write after seal.

Do not write terminal confirmation updates after seal. Terminal confirmations
may be resolved only through the guarded external marker and immutable
preterminal registry semantics frozen by the current contract.

──────────────────────────────────────────────────────────────────────────────
28. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- exact first blocker;
- structured exception;
- complete parent/child ledger;
- stdout/stderr;
- complete partial-root inventory;
- indispensable evidence before cleanup;
- fixture cleanup;
- supplied-root closing equality;
- implementation-package authority false;
- source-freeze posture;
- terminal-seal false;
- same-root retry false.

Do not create success manifests on failure.

Failure to retain indispensable evidence, complete cleanup, or close supplied
roots equally is:

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
29. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

only when:

- successor Generation-2 package authenticates;
- current role registry resolves exactly;
- clean-room provenance closes;
- pre-source implementability passes;
- implementation completes within three attempts;
- every current component role is implemented;
- E00 and G00–G04 are physically and semantically correct;
- G05–G29 semantics are preserved;
- all static gates pass;
- all required matrices pass;
- all independent component validators pass;
- rehearsal A passes;
- rehearsal B passes;
- normalized rehearsal equality passes;
- independent rehearsal validator passes;
- evidence retention precedes cleanup;
- cleanup closes;
- source freezes;
- frozen-source requalification passes;
- current subject remains unconstructed;
- supplied roots close equal;
- implementation package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTATION_BLOCKED

when:

- implementation cannot satisfy the current successor contract within three
  attempts;
- a required source boundary cannot be implemented;
- a static gate, matrix, validator, or rehearsal fails;
- normalized rehearsals diverge;
- implementation would require changing normative semantics, current schemas,
  validation semantics, or the successor operating model.

Return:

IMPLEMENTATION_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- governing identity mismatch;
- source drift after freeze;
- unregistered process or filesystem effect;
- indispensable evidence lost before cleanup;
- cleanup inequality;
- supplied-root closing inequality;
- implementation-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
30. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh implementation-root identity
3. Successor Generation-2 package authentication
4. Current governing-role resolution
5. External authoritative-input identities
6. Clean-room source-authority result
7. Pre-source implementability result
8. Implementation operating freeze
9. Source-layout registry
10. Source-attempt ledger
11. Final production-source registry
12. Final qualification-source registry
13. E00 implementation result
14. G00 implementation result
15. G01 implementation result
16. G02 implementation result
17. G03 implementation result
18. G04 implementation result
19. G05–G29 implementation crosswalk
20. Current 73-path namespace implementation
21. Writer-registry implementation
22. Documentary-lifecycle implementation
23. External-interface implementation
24. Total JSON-observation implementation
25. Special-case implementation
26. Process-custody and locator implementation
27. Failure-finalization implementation
28. Compilation and static results
29. Bootstrap-order matrix
30. External-interface matrix
31. JSON-observation matrix
32. Schema/family matrix
33. Process-custody/locator matrix
34. Cleanup/failure-evidence matrix
35. Writer/lifecycle matrix
36. Namespace/temporal matrix
37. Manifest/terminal matrix
38. Negative-checker robustness matrix
39. Independent component-validator results
40. Rehearsal A complete result
41. Rehearsal B complete result
42. Normalized rehearsal comparison
43. Independent rehearsal-validator result
44. Rehearsal evidence retention
45. Rehearsal cleanup
46. Source freeze
47. Frozen-source requalification
48. Confirmation current subject was not constructed
49. Implementation-package status
50. Supplied-root closing equality
51. Fixture/cache cleanup
52. Failure-closeout capability and usage
53. Temporal-inventory identity
54. Manifest A identity
55. Manifest B identity
56. Independent terminal reprojection
57. Terminal membership and modes
58. No-write-after-closure
59. Remaining uncertainty and nonclaims
60. Explicit confirmation registry

Required task-level confirmations:

SUCCESSOR_GEN2_CONTRACT_MUTATION_NOT_PERFORMED
SUCCESSOR_GEN2_CONTRACT_IDENTITY_MATCHED
SUCCESSOR_GEN2_TERMINAL_CLOSURE_AUTHENTICATED
CURRENT_GEN2_ROLE_REGISTRY_RESOLVED
ALL_CURRENT_GEN2_ROLES_AUTHENTICATED
NO_HISTORICAL_GEN2_ARTIFACT_USED_AS_CURRENT
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
CLEAN_ROOM_SOURCE_AUTHORITY_ESTABLISHED
NO_HISTORICAL_SOURCE_COPIED
NO_HISTORICAL_SOURCE_PATCHED
PRE_SOURCE_IMPLEMENTABILITY_PASSED
IMPLEMENTATION_OPERATING_FREEZE_COMPLETED_BEFORE_SOURCE
SOURCE_LAYOUT_REGISTRY_COMPLETE
SOURCE_ATTEMPT_LIMIT_RESPECTED
FINAL_PRODUCTION_SOURCE_REGISTRY_COMPLETE
FINAL_QUALIFICATION_SOURCE_REGISTRY_COMPLETE
ALL_CURRENT_PRODUCTION_COMPONENT_ROLES_IMPLEMENTED
ALL_CURRENT_QUALIFICATION_COMPONENT_ROLES_IMPLEMENTED
INDEPENDENT_VALIDATORS_IMPORT_NO_PRODUCTION_HELPERS
GEN2_AUTHORITY_SCOPE_PRESERVED
GEN2_NONAUTHORITY_SCOPE_PRESERVED
E00_IMPLEMENTED
E00_WRITES_NO_SUBJECT_PACKAGE_PATH
E00_ALLOCATES_NO_SUBJECT_ROOT
E00_RUNTIME_AND_SOURCE_AUTHENTICATION_PASSED
G00_IMPLEMENTED
G00_FRESH_ROOT_ALLOCATED
G00_OPENING_CREATED_BEFORE_BOOTSTRAP_START
G00_BOOTSTRAP_START_DURABLY_RETAINED
G00_LOCATOR_EMITTED_AFTER_DURABILITY
G01_IMPLEMENTED
G01_EXACT_DIRECTORY_NAMESPACE_MATERIALIZED
CLOSEOUT_EXISTS_AT_G01
MANIFEST_EXISTS_AT_G01
NO_DIRECTORY_CREATION_AFTER_G01
G02_EXECUTION_AUTHORITY_COMMITTED
NO_EXECUTION_AUTHORITY_BEFORE_G02
G03_FIXED_INPUT_AUTHENTICATION_COMMITTED
NO_FIXED_INPUT_AUTHORITY_BEFORE_G03
G04_EXTERNAL_INTERFACE_FREEZE_COMMITTED
NO_INTERFACE_AUTHORITY_BEFORE_G04
G05_G29_SEMANTICS_PRESERVED
THIRTY_PHASE_MODEL_IMPLEMENTED
EXACT_CURRENT_FUTURE_PATH_SET_IMPLEMENTED
EXACT_73_PATH_FUTURE_NAMESPACE_IMPLEMENTED
EXACT_61_FILE_FUTURE_NAMESPACE_IMPLEMENTED
PHASE_FUNCTION_PATH_WRITER_REGISTRY_ENFORCED
NO_FINAL_PATH_HAS_MULTIPLE_WRITERS
NO_SUCCESSFUL_SECOND_WRITE
NO_OVERWRITE_OR_FINAL_RESULT_ADOPTION
DOCUMENTARY_EVIDENCE_LIFECYCLE_ENFORCED
CONFIRMATION_VALIDATOR_RESULT_CREATED_EXACTLY_ONCE
FINAL_TEN_ROLE_REGISTRY_AFTER_ALL_RESULTS
DOCUMENTARY_REGENERATION_DERIVED_FROM_FINAL_REGISTRY
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
ALL_CURRENT_EXTERNAL_INTERFACES_IMPLEMENTED
NO_ACCEPTANCE_BEARING_POINTER_FALLBACK
TOTAL_JSON_OBSERVATION_IMPLEMENTED
NO_UNGUARDED_OBJECT_ACCESS_ON_UNTRUSTED_JSON
ALL_CURRENT_SPECIAL_CASES_IMPLEMENTED
NORMATIVE_CONSTRUCTION_PARENT_INTENTIONALLY_UNMAPPED
EXACTLY_FOURTEEN_GENERATED_FAMILIES
PROCESS_CUSTODY_CONTRACT_IMPLEMENTED
ROOT_LOCATOR_CONTRACT_IMPLEMENTED
ALL_CHILDREN_ROUTED_THROUGH_SINGLE_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
FAILURE_EVIDENCE_RETAINED_BEFORE_CLEANUP
CLEANUP_SET_EQUALITY_ENFORCED
PRODUCTION_SOURCES_COMPILED
QUALIFICATION_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
BOOTSTRAP_ORDER_MATRIX_PASSED
EXTERNAL_INTERFACE_MATRIX_PASSED
JSON_OBSERVATION_MATRIX_PASSED
SCHEMA_ROLE_FAMILY_MATRIX_PASSED
PROCESS_CUSTODY_LOCATOR_MATRIX_PASSED
CLEANUP_FAILURE_EVIDENCE_MATRIX_PASSED
WRITER_LIFECYCLE_MATRIX_PASSED
NAMESPACE_TEMPORAL_MATRIX_PASSED
MANIFEST_TERMINAL_MATRIX_PASSED
NEGATIVE_CHECKER_ROBUSTNESS_MATRIX_PASSED
INDEPENDENT_COMPONENT_VALIDATORS_PASSED
COMPLETE_REHEARSAL_A_PASSED
COMPLETE_REHEARSAL_B_PASSED
TWO_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_REHEARSAL_VALIDATOR_PASSED
REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP
REHEARSAL_ROOTS_CLEANED
FINAL_SOURCE_REGISTRIES_FROZEN
FINAL_SOURCES_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_PACKAGE_PENDING_INDEPENDENT_AUDIT
ONE_SHOT_CURRENT_SUBJECT_USE_NOT_AUTHORIZED
PROCESS_SELF_TEST_NOT_EXECUTED
PRODUCT_CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_CREATED
IMPLEMENTATION_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
IMPLEMENTATION_PACKAGE_MANIFEST_A_CREATED
IMPLEMENTATION_PACKAGE_MANIFEST_B_CREATED
IMPLEMENTATION_PACKAGE_MANIFESTS_BYTE_IDENTICAL
IMPLEMENTATION_PACKAGE_TERMINAL_REPROJECTION_PASSED
IMPLEMENTATION_PACKAGE_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

Also resolve every acceptance-bearing confirmation required by the current
`gen2-implementation-qualification-v2` role.

Do not mark a confirmation true merely because its phase executed. Every true
confirmation must bind exact retained evidence.

After:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_INDEPENDENT_AUDIT

the next tranche is a fresh source-external independent audit of the sealed
implementation package.

Do not execute the frozen parent to construct the current schema subject until
that independent audit accepts.
```

**Source:** Codex’s `SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_BOOTSTRAP_ORDER_REPAIRED_READY_FOR_IMPLEMENTATION` report in this turn.  
**Confidence:** 0.995 that implementation is now the correct next tranche; 0.99 that the successor’s current-role registry must be the sole governing selector; 0.98 that the independent implementation-package audit must remain the final gate before one-shot subject construction.
