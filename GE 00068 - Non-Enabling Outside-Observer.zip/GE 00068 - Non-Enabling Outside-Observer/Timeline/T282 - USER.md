Here is Codex's response:

# Validation-Custody V3 audit-repair implementation report

`REPORT_NORMATIVE: false`\
`REPORT_ROLE: nonnormative source-external repair evidence`

## 1. Primary verdict

`REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT`

## 2. Repair-root identity

The completed capsule is [ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b).

Terminal root identity:

- Device: `16777234`
- Inode: `178948757`
- Mode: `0700`
- Link count after removal of `private/`: `10`
- Allocation: `tempfile.mkdtemp`, required prefix, umask `0077`

The supersession record captured the same device/inode/mode before cleanup, when the directory link count was `11`. Directory link count is intentionally excluded from stable inventory authority.

## 3. Opening candidate and supplied-root identities

The opening gate passed before target-correctness work. Its retained record is `16,745` bytes, SHA-256 `9ad3ea3482f7f4704b8321419aa1414b0a8976afca208683dd7c3b5062391764`.

Candidate identity matched exactly:

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream: absent
- Governed/tracked/untracked: `389 / 375 / 14`
- Tracked modifications: `22`
- Staged/deleted/renamed/unmerged: `0 / 0 / 0 / 0`
- F source T: `f276536fea579d0842cda43b0290656b200b7f27`
- F inventory: `54,314` bytes, SHA-256 `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`

Complete lstat/no-follow opening inventories:

| RootDevice:inode, modeDirectories/filesEntry-set SHA-256Retained inventory |                              |           |                                                                    |                                                                              |
| -------------------------------------------------------------------------- | ---------------------------- | --------- | ------------------------------------------------------------------ | ---------------------------------------------------------------------------- |
| Candidate                                                                  | `16777234:122118502`, `0755` | `94/390`  | `17672875e454028ab23b83125757b3709be71742dfb7616704e7642f426193d2` | `79,057`, `2ee80c2f43f1037a6248ec0775542e65db7df571df12ee1ee309502a4923ac43` |
| Strategic B gate                                                           | `16777234:178865681`, `0700` | `10/46`   | `beb545c5a3c0d3aaa1308d89fb1160d8d1ca8d29a7c8c250701d94056ea8ba74` | `9,414`, `61708434279827cb4689a3e0ef5398b9a4c7f1a0463a00a4c3ff03432a3a6dc4`  |
| Strategic B                                                                | `16777234:178255587`, `0700` | `107/462` | `b628b57574992aef2c444672f33556de1d467fde0ab40bb0189b7be00eb2921a` | `96,325`, `ef456e2815d29dfd9e4f7bedc330c5e9d74b3d0e9f06ad5c53ca382aaccdb789` |
| Blocked V1                                                                 | `16777234:178515489`, `0700` | `11/62`   | `f9286c21e1ce5397c79417c0911a09b73505ae532d56affeccf20249c4a77a2f` | `12,577`, `df165e3fccbd1d921df46424e7cab24e47b0e8bdbccf3416a8c92b52d4a9b7d9` |
| Validation-Custody V2                                                      | `16777234:178558083`, `0700` | `12/90`   | `03dc276015d9c1dc51e0c1397e9b7838d1d0d4dbc7a926940bb4d949b19ad02e` | `17,843`, `b76491179f17301a468487a12934549f57109cdef4a7fa97df95843428f2968c` |
| V2 independent audit                                                       | `16777234:178646858`, `0700` | `21/197`  | `d724b872ca99a7339f05c9dcd94318fbce0d1e69e8b24b736dbc6f0aab1f33e3` | `38,677`, `e3ef059678881d003bb78aba0663c4f0fabf71fcc4b0abe0ec8cb8164de2a394` |
| V3 predecessor                                                             | `16777234:178799785`, `0700` | `12/88`   | `64b9b79117f9ac3c42c2140f166411d3705f143c6a3f048bd6ea984900ce576a` | `18,868`, `269a8fe0c17c04397c575973fdebd12766bb9db974bb3fbf37013e70d7be4192` |
| Blocking audit                                                             | `16777234:178926896`, `0700` | `8/273`   | `2becf22f625eae36a06f454bb8226f34ccde7ca3784029f5b20846cd9498f086` | `49,298`, `fbf1bf0ed4876ada95334fb93baacddecff2673f5fc630008febea8907be503e` |

All eight inventories reported zero symlinks and zero special objects.

Additional fixed identities passed:

- Strategic B gate record: `4,173` bytes, SHA-256 `555041298ee49db603a7c3ff64e022cdf8bf79cd7d7edc6007dcd32e35998212`
- Gate manifests: `10,066` bytes each, SHA-256 `d58de35fdf630829b1fb7efe80a04f0616a66c98039fdf27a2b49a622c49bd05`, byte-identical
- Strategic B canonical projection independently reproduced: `96,657` bytes, SHA-256 `4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360`
- B inventory: `54,314` bytes, SHA-256 `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- B source tree: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- V2 audit report: `92,491` bytes, SHA-256 `e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05`
- V2 audit inventory: `69,706` bytes, SHA-256 `9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf`
- Blocking-audit report: `12,458` bytes, SHA-256 `a2f0d346661808aaef9afc2048d29f172a5b5ce76ec18561ea1060251f1411ca`
- Blocking-audit inventory: `96,833` bytes, SHA-256 `448dd1916c183e4343fb4d1eee14b20314fc9bcef8c612495e09a8613f46afa3`

The blocking audit’s retained verdict was `AUDIT_PROVENANCE_MISMATCH`; it was treated as nonqualifying and never as acceptance or authority.

## 4. Audit findings reproduced

Both target findings were independently reproduced.

1. The predecessor contained exactly two top-level naked contract-shaped objects satisfying the V3 contract ID, sole-writer flag, and current/pending-effective status criteria:
   - `contract/strategic-b-validation-custody-v3.json`
   - `validation/failed-attempts/build-attempt-1/contract/strategic-b-validation-custody-v3.json`
   Nested mutation envelopes and textual source/report occurrences were separately classified as noncurrent fixtures or text, not overlooked as additional top-level writers.
2. Predecessor adoption rows 5 and 7 were not supported by raw-only citations:
   - Eight-command raw record: `/pass=false`, `/all_accepted=false`
   - Cleanup raw record: `/pass=false`

The authenticated correction record is:

`/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy/adjudication/replay-and-cleanup-corrections.json`

Identity: `2,128` bytes, SHA-256 `7bfd935591ba24e30d97ddbfc03827d617ed460086ed971c76ebd6874200ee75`.

The record has no `schema` member; that absence is recorded explicitly. Its relevant correction fields were independently verified as supporting the bounded corrected observations.

## 5. Exact effect boundary

This was classified under the repository governance model as a source-external evidence/provenance repair over an existing bounded slice rule.

Writes were confined to the new repair capsule. No repository code, documentation, index, supplied evidence, V3 executable or acceptance-bearing semantic, Plan V4 command semantic, V2 dynamic result, Strategic B authority, publication state, commit state, readiness state, or A6 state changed.

`PLANS.md` and the applicable `.docs/` architecture, artifact-hygiene, publication, capability-probing, lifecycle, custody, and Remote Alpha material were consulted. Because repository behavior and design intent were not changed, no repository documentation change was warranted.

## 6. Current normative contract identity

The sole current contract is [strategic-b-validation-custody-v3.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/contract/strategic-b-validation-custody-v3.json):

- Size: `4,878`
- SHA-256: `16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55`
- Mode/link count: `0600 / 1`
- Status: `proposed-effective-pending-independent-audit`

It is an exact copy of the predecessor current contract. The terminal authority check found exactly one current contract-shaped V3 normative object and one sole-writer claim. Strategic B remains source authority; the contract’s source-authority flag remains false.

## 7. Current Plan V4 identity

The sole current Plan V4 is [validation-plan-v4.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/contract/validation-plan-v4.json):

- Size: `26,001`
- SHA-256: `af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea`
- Mode/link count: `0600 / 1`
- Status: `proposed_effective_pending_fresh_independent_audit`
- Command count: `8`

It is an exact copy of the predecessor current Plan V4. The authority scan found exactly one current Plan V4 writer. No Plan command was executed.

## 8. Failed-attempt authority repair

[failed-and-superseded-attempt-index-v2.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/lineage/failed-and-superseded-attempt-index-v2.json) is `6,884` bytes, SHA-256 `f7e19e44047e764f80f72e4f59b7d9f055d8a52e905c3b6482a790bd4bfc9d83`.

It externally binds all nine predecessor failed-attempt artifacts:

1. `build_v3_capsule-attempt1.py` — `40,258`, `bd2dfa9c34c6c7bbddef2fdb0d6a2d2766a571cd7939d445d0f0590406a12ac4`
2. `contract/path-source-closure-v3.json` — `2,323`, `e62998b9a5d45ea7bbe86fed4222f83af9e2db9d6a3a556736b1301e675ed04e`
3. `contract/strategic-b-validation-custody-v3.json` — `4,878`, `16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55`
4. `contract/validation-plan-v4.json` — `26,001`, `af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea`
5. `opening/blocked-v1-binding.json` — `22,910`, `25dc309d8a19b1bea58f510fe7d3d7f3da03983c4e8a1c50b80a1b6b876fc98c`
6. `opening/candidate-identity.json` — `107,405`, `780989a9586880f1fe29278bc32f192fa290ece501a63be62be022b3e93695b1`
7. `opening/strategic-b-binding.json` — `167,796`, `1e0634cd92fda6517534331c284162b1c5bbc6273f0357b52379bba9f966e396`
8. `opening/v2-audit-binding.json` — `65,837`, `95ffcf0c2f118ffab2f71cca71c9a0a7d6defd27ae67d7fe59fada316477dd9b`
9. `opening/v2-capsule-binding.json` — `32,699`, `e93f52830f0057019ffa3fa2b538cf7feff79e0bca44a6ff9ff94b0292e25a55`

Each entry binds its predecessor root/path, identity, failed attempt, failure reason, and superseding current record. Every entry has `normative`, `effective`, `authoritative`, `current_contract_writer`, `current_plan_writer`, and `eligible_for_runtime_or_acceptance_use` set to false.

No failed-attempt contract, Plan, source-closure, or opening-binding object was copied as historical content. The current contract, Plan, and source closure necessarily share their unchanged content digests with predecessor copies, but occur only at the required current paths; there is no additional historical-copy path in the repair root.

The retained authority scan is `2,234` bytes, SHA-256 `f9c4190764a8a238e0205d9647a161e3ce1f322f347c62fa245b36e2b7c4aa3b`.

## 9. Authoritative supersession record

[authoritative-supersession-v1.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/lineage/authoritative-supersession-v1.json) is `4,816` bytes, SHA-256 `1db6abcf4c077d1b303772ad190981ad11de5af49e6d6430cebd8a836bbfdc4c`.

It binds:

- Predecessor root: device `16777234`, inode `178799785`, mode `0700`
- Predecessor complete-entry digest: `64b9b79117f9ac3c42c2140f166411d3705f143c6a3f048bd6ea984900ce576a`
- Predecessor current contract, Plan V4, source closure, and equivalence identities
- All nine failed-attempt identities
- The new repair-root identity
- The unchanged current contract and Plan identities
- Current writer counts: contract `1`, Plan `1`, failed-attempt writer `0`

Its bounded scope is authority location, historical custody, unchanged-current-location selection, and documentary adoption-lineage repair. It explicitly does not supersede or change V3 semantics, Plan V4 semantics, V2 dynamic evidence, Strategic B source authority, or runtime results.

## 10. Complete V2 adoption V2 field map

[v2-technical-evidence-adoption-v2.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/adoption/v2-technical-evidence-adoption-v2.json) is `56,563` bytes, SHA-256 `fdafef48a62bbe04e71c3cf5f805c93e25b71daa86aec1a7b521a781383674e9`.

All nine rows include observation ID, raw absolute/relative path, size, digest, schema presence/value, exact status fields, optional correction identity and fields, adopted fact, adoption basis, bounded authority, and all required nonauthority flags.

Every row has:

- `support_verified: true`
- `evidence_authority: bounded-technical-observation`
- `dynamic_replay: false`
- `v2_audit_verdict: BLOCK`
- `verdict_promoted: false`
- `product_authority: false`
- `runtime_authority: false`
- `readiness_authority: false`
- `a6_authority: false`

The row-specific field maps are:

1. `OBS-01-ALLOCATOR-CAUSALS` — raw `allocation/allocator-causals.json`, `960`, `6ecbd4ef58cfcc2bbdfb92625dcbaa372db1791618eba1a7197fac036143ba70`, schema absent. Status: aggregate pass and each named allocator causal true; non-EEXIST terminal was not retried. Basis: `raw-record`.
2. `OBS-02-PATH-BUDGET-86` — raw `path-budget/independent-proof.json`, `3,558`, `fc46134e4d7e95ff404a2f81dace6dfed7584e3e6094d510717ef7a7fc30ee7f`, schema absent. Status: `/pass`, derivation result, lexical/physical shared identity, decimal-format marker, and uint32-random marker true; observed random name was not used as the bound. Basis: `raw-record`.
3. `OBS-03-FOUR-CAUSAL-MATRIX` — raw `causals/four-causal-matrix.json`, `2,175,630`, `fd45ce5b818b465f878aa68d3894c0ee1bd8b94135b7294ae68e225bb520e035`, schema absent. Aggregate, shared-positive, long-shared-negative, sibling-historical-negative, and boundary-100/101 pass fields are true. Basis: `raw-record`.
4. `OBS-04-EXACT-B-MATERIALIZATION` — raw `materialization/exact-B.json`, `152,755`, `b698eab37368faac9d5bb084ed01e092c3e99aeca43e9cdf8820677ae827decc`, schema absent. `/pass=true`, private Git clean, governed count `389`, inventory hash `64b2…65c2`, source/private tree `8de797…34e`, inode-alias count `0`. Basis: `raw-record`.
5. `OBS-05-EIGHT-COMMAND-ACCEPTANCE` — raw `validation/eight-command-summary.json`, `100,416`, `ab110d950c4f38df378e8ca6fc68e2f50cbbc1f17c7214c923d8406fae720fe6`, schema absent. Raw `/pass=false`, `/all_accepted=false`, command count `8`, complete order true. Seven rows reported direct acceptance; `external-tls-all` reported exit `1`, one failure and four skips. Correction basis: `raw-plus-correction-record`, using `/all_eight_commands_corrected_acceptance=true`, `/external_tls_corrected_acceptance=true`, raw adjudication false, and exact failure/test identity fields true.
6. `OBS-06-CROSS-COMMAND-ISOLATION` — same raw summary identity. Raw aggregate remains false, while each `cross_command_isolation[0..7].pass` and `module_seed_intact` field is true. Basis: `raw-record`, limited to those eight isolation rows.
7. `OBS-07-SHORT-ROOT-CLEANUP` — raw `cleanup/short-root-cleanup.json`, `2,940`, `e0bd40d46758c9a852ef50a692e537c344bda3c29c1bfe3d54eea1514a04ffd7`, schema absent. Raw `/pass=false`; direct children exact, descriptor identity stable, and both absence observations true; descendant snapshots were `[94742]` and `[94748]`. Correction basis: `raw-plus-correction-record`, using `/cleanup_raw_pass=false`, `/cleanup_corrected_acceptance=true`, the bounded `/bin/ps` false-positive explanation, two fresh ENOENT observations, and an empty post-run PID query.
8. `OBS-08-CLOSING-EQUALITY` — raw `closing/closing-gate.json`, `106,759`, `29265b45e2560d26bb9202024817e8bce47ca0f3a45f93d6a0f6d1aa8dc5c44b`, schema absent. Aggregate, candidate, Go, blocked-V1, blocking-audit, Strategic-B, and V2 comparisons true. Basis: `raw-record`.
9. `OBS-09-V2-CAPSULE-CLOSURE` — raw `opening/manifest-closure.json`, `5,833`, `10e4342fe2c6fda7b0d0e95b85cca7cf354e0f897057310061698d0b260bf2b0`, schema absent. V2 pass, manifest byte equality, independent projections, no symlink/special object, all directories `0700`, and all files regular/single-link/`0600` are true. Basis: `raw-record`.

## 11. Exact raw and correction lineage for all adopted observations

[complete-observation-lineage-ledger-v1.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/adoption/complete-observation-lineage-ledger-v1.json) is `50,136` bytes, SHA-256 `d7afb786f724e620c49c74fac68b09aba4ac5fd0a1b96d67837a39979c04f396`.

The complete chains are:

- OBS-01: allocator raw record → bounded allocator-causal observation.
- OBS-02: independent path-budget raw record → exact bounded 86-byte observation.
- OBS-03: four-causal raw matrix → named four-causal observation.
- OBS-04: exact-B raw record → clean, physically separate fixed-B materialization observation.
- OBS-05: raw false eight-command aggregate → authenticated correction record → corrected identity-policy observation.
- OBS-06: raw false aggregate plus eight independently true isolation subrecords → bounded isolation-only observation.
- OBS-07: raw false cleanup record → authenticated correction plus two fresh ENOENT observations → corrected cleanup observation.
- OBS-08: raw closing gate → named candidate/supplied-root equality observation.
- OBS-09: raw manifest closure → bounded V2 capsule-closure observation.

Rows 5 and 7 alone use `raw-plus-correction-record`; the other seven use `raw-record`. Raw false values remain visible and were not rewritten. The correction record’s missing schema member remains explicitly recorded as absent.

## 12. Confirmation V2 verdict remains BLOCK

The fixed V2 audit report was authenticated at `92,491` bytes and SHA-256 `e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05`; its parsed primary verdict remains `BLOCK`.

The adoption record is bounded evidence composition, not verdict inheritance. All nine rows carry `verdict_promoted:false`; the correction record repairs only the two technical-observation lineages and does not promote V2 acceptance.

## 13. Independent V3 contract revalidation

The repair-owned V3 field map is `10,977` bytes, SHA-256 `4bdfc5a910261ebcdde9b4afefd59c2ea1c9daf0e682eecedc516ec2d91e72de`.

It established:

- Strict JSON parse passed.
- Independent duplicate-member rejection passed.
- All `115` contract leaves were recorded by JSON pointer.
- Contract size/hash matched exactly.
- All eight authority flags remain false: source, runtime, product, deployment, publication, commit, readiness, and A6.
- All six unsupported-environment flags remain false: shared/adversarial host, hostile/remotely administered host, symlink alias, bind-mount alias, mount alias, and pathname alias.
- Strategic B remains source authority.
- The contract cannot redefine, override, narrow, or widen the source.

The separate authority/nonauthority revalidation is `1,102` bytes, SHA-256 `20c87446a772b06706d8fe4c5f78bf83ce32d9a3119ff5c92664dac8ef7e9133`.

## 14. Independent Plan V3→V4 equivalence

The retained equivalence record is `3,937` bytes, SHA-256 `4855cbd41a4c16a4d0ff52aa2dec75bdd66b1f272d1e1323d7a3b8759efe2f5b`. The new repair-owned comparator record is `2,392` bytes, SHA-256 `26b309dbed6fefd83d72d0378cd6a37cceff2bf95fedb7e51cadf6781cd5850b`.

Plan V3 source identity:

- Size: `28,590`
- SHA-256: `fee24453d7c4c951f5ce27c55589f169737c97def516a7ad13df3cbe2eee1eee`

The independently normalized V3 and V4 projections were both `24,483` bytes with SHA-256 `bd9802aeb6eb316a30d8582e6911e7fb38233aca24c3519cf15217eed818959f`.

All eight command objects had equal argv, reason, expectations/identity policy, and canonical bytes:

1. `go-version` — `62ed8aa2ec3de137bcad1c044e15db33a1b56a479ad7734d6032135756f13a5c`
2. `complete-docs-105` — `8702e3ca4f998c706752a13a84651d57e59fdccd848193952dcebce4250fa7c0`
3. `testsupport-acceptance` — `183f9366f4441fcfbf72b317829e870e5fec94121e712a292c0d8f4734e18f9a`
4. `external-tls-all` — `a1c9eaf8399aca021595c6aed5a7c5bfca77e1398633a531f4f2893f4030ae74`
5. `repair10-current-affected-pass` — `05d44af6b9a3c456140ece47771f697e1eb61cfe441d837bee9532458505a03b`
6. `changed-nonroot-product-tests` — `6d93846881d1736b7198e54180e760dd1a1083dcd10abc47618cd521e6230098`
7. `bash-syntax` — `d62e68c4152c9ee5deabb5f66c8eb2a0f2bdb68d262d303bbf4e4b3b5dda47bf`
8. `private-git-diff-check` — `4a5a1e893ade08969ae62bc331fbc4db6c829213c090fde565217bd0c34f1a51`

Environment, exact source, pinned tools, expected identity counts, and all nonmetadata top-level fields matched. Runtime replay was false.

## 15. Independent exact-source and 86-byte derivation

The retained source closure is `2,323` bytes, SHA-256 `e62998b9a5d45ea7bbe86fed4222f83af9e2db9d6a3a556736b1301e675ed04e`. The repair-owned revalidation is `2,109` bytes, SHA-256 `e5db881ba95196a6ef4ed71f910e39d32f5099814ec5f0aa577fddc289ac5251`.

The five sources were reread and matched:

1. `internal/testsupport/controlroot.go` — `8,695`, `3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3`
2. `internal/testsupport/controlroot_test.go` — `1,359`, `de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f`
3. `es/runtimehelper/helper_test.go` — `5,017`, `715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0`
4. Pinned Go `src/os/tempfile.go` — `4,002`, `a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16`
5. Pinned Go `src/internal/strconv/itoa.go` — `6,171`, `cfda0d39152dc8ad8e2eb0407682c399ea0a321796211e015096fa57b17a35d5`

Static markers established the `MkdirTemp` prefix, policy limit `100`, both identity leaves, uint32 base-10 randomness, and decimal conversion implementation.

Independent derivation:

`59 + 1 + (2 + 10) + 1 + 13 = 86 <= 100`

The maximum generated component is `12` bytes; worst-case socket path is `86`; margin is `14`. No runtime replay occurred.

## 16. Mutation validators and exact case set

The two validators were separately implemented, explicitly nonnormative, and shared no code or parsing helper:

- Producer source: `22,097` bytes, `5702a316c7a2066f9ba25a4a62c4e31ee2847e6f02cb5d52678717dcc41efa5b`
- Independent source: `21,623` bytes, `480d04da1e57eda709171f570e0baa7d500e66945f8dbe110a57d59224e21922`
- Producer result: `17,890` bytes, `ce8d0ab299ed1fe7af1cd1b8d512622394c5d6d7786b82c9fcfbd2bee4fafb09`
- Independent result: `18,229` bytes, `1119953ad7d5108035d82853073822291cb02bb1fcb68c7c5c4e6d01fd032384`

Each source contains its own literal expected name/reason set. Each executed exactly `64` unique mutations, reconciled names and reasons both ways, produced `64` mechanism-specific rejections, and had zero false acceptances.

Exact set:
```
01 fresh-csprng-material-disabled → fresh_suffix_per_attempt_required
02 suffix-source-not-os-csprng → suffix_source_must_be_operating_system_csprng
03 descriptor-relative-exclusive-creation-weakened → exclusive_descriptor_relative_creation_required
04 component-no-follow-traversal-removed → component_no_follow_parent_traversal_required
05 retry-widened-beyond-eexist → retry_must_be_eexist_only
06 collision-material-reused → collision_material_reuse_forbidden
07 attempt-limit-changed → attempt_limit_must_equal_128
08 non-eexist-fallback-admitted → non_eexist_failure_must_be_terminal
09 latest-prefix-scan-admitted → prefix_and_latest_scan_forbidden
10 adoption-admitted → adopt_existing_forbidden
11 rename-into-eligibility-admitted → rename_into_eligibility_forbidden
12 pid-authority-admitted → pid_authority_forbidden
13 counter-authority-admitted → counter_authority_forbidden
14 timestamp-authority-admitted → timestamp_authority_forbidden
15 git-hash-authority-admitted → git_hash_authority_forbidden
16 shared-adversarial-host-support-true → shared_adversarial_host_support_must_be_false
17 hostile-remote-admin-support-true → hostile_remote_host_support_must_be_false
18 symlink-alias-support-true → symlink_alias_support_must_be_false
19 bind-mount-alias-support-true → bind_mount_alias_support_must_be_false
20 mount-alias-support-true → mount_alias_support_must_be_false
21 pathname-alias-support-true → pathname_alias_support_must_be_false
22 itoa-source-omitted → five_source_closure_requires_itoa
23 itoa-source-digest-changed → itoa_source_identity_mismatch
24 tempfile-source-digest-changed → tempfile_source_identity_mismatch
25 decimal-maximum-changed → uint32_decimal_max_must_equal_10
26 generated-component-maximum-changed → generated_component_max_must_equal_12
27 worst-case-path-changed → worst_case_socket_path_must_equal_86
28 socket-limit-changed → socket_path_limit_must_equal_100
29 validation-command-removed → exact_eight_command_set_required
30 validation-command-reordered → validation_command_order_mismatch
31 validation-command-argv-changed → validation_command_argv_mismatch
32 expected-identity-removed → expected_identity_policy_incomplete
33 expected-failure-reclassified → expected_failure_identity_changed
34 expected-skip-reclassified → expected_skip_identity_changed
35 b-source-tree-identity-changed → strategic_b_source_tree_mismatch
36 shared-r-custody-changed → shared_control_tmp_custody_required
37 v2-block-promoted-to-accept → v2_block_verdict_must_not_be_promoted
38 plan-v3-described-previously-effective → plan_v3_must_remain_non_effective
39 plan-v4-described-current-without-audit → plan_v4_requires_fresh_independent_audit
40 v3-contract-granted-source-authority → source_authority_must_be_false
41 v3-contract-granted-publication-commit-readiness-a6-authority → publication_commit_readiness_a6_authority_must_be_false
42 second-current-v3-normative-contract → exactly_one_current_v3_normative_writer_required
43 failed-attempt-contract-copied-into-current-root → failed_attempt_contract_bytes_must_not_be_copied_as_history
44 failed-attempt-index-historical-contract-normative → historical_contract_must_be_nonnormative
45 failed-attempt-index-historical-plan-effective → historical_plan_must_be_ineffective
46 authoritative-supersession-omits-predecessor-binding → predecessor_binding_required
47 authoritative-supersession-widens-semantic-scope → semantic_scope_widening_forbidden
48 raw-eight-command-false-treated-as-direct-pass → raw_eight_false_cannot_directly_support_pass
49 eight-command-correction-record-omitted → eight_command_correction_required
50 eight-command-correction-digest-changed → eight_command_correction_identity_mismatch
51 correction-field-does-not-support-adopted-fact → correction_field_must_support_adopted_fact
52 raw-cleanup-false-treated-as-direct-pass → raw_cleanup_false_cannot_directly_support_pass
53 cleanup-correction-record-omitted → cleanup_correction_required
54 v2-block-promoted → v2_block_verdict_preservation_required
55 adopted-observation-broadened → adopted_fact_must_remain_bounded
56 directory-symlink-omitted-by-inventory → directory_symlink_must_be_detected_and_rejected
57 special-object-omitted-by-inventory → special_object_must_be_detected_and_rejected
58 unexplained-empty-directory-admitted → empty_directory_must_be_rejected
59 final-inventory-has-unstable-directory-metadata → directory_size_and_link_count_forbidden
60 final-scan-omits-report-without-exclusion → final_report_must_be_scanned_or_explicitly_excluded
61 second-current-plan-v4-writer → exactly_one_current_plan_v4_writer_required
62 report-claims-normativity → report_must_be_nonnormative
63 validator-claims-normativity → validator_must_be_nonnormative
64 historical-bytes-runtime-eligible → historical_failed_bytes_runtime_use_forbidden
```

## 17. Complete membership and directory-symlink adjudication

Two independent lstat/no-follow generators were retained:

- Generator A: `5,273` bytes, SHA-256 `d3c2dae2f34343591ca15a63d6dd2058bc68e17e72a97b4be334143f8d074392`
- Generator B: `5,471` bytes, SHA-256 `cf54073cc9ac1c86cc17957ea826aba424b24701dbfa578628e09647a09f3105`

Both enumerate the root and every descendant, including directories; detect and reject directory symlinks; and reject every symlink, special object, multiply linked regular file, unsupported UTF-8 path, and empty retained directory.

Final represented membership:

- Directories including root: `9`
- Nonmanifest regular files: `59`
- Represented entries: `68`
- Physical final tree: `9` directories and `61` regular files, including the two manifests
- All directories: mode `0700`
- All files: regular, single-link, mode `0600`
- Symlinks/special objects/empty directories/unsupported paths: none

Directory entries contain only path, type, and mode. File entries additionally contain link count, size, and SHA-256. Directory size and directory link count are absent.

## 18. Final inventory temporal treatment

[final-evidence-inventory-v2.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/closeout/final-evidence-inventory-v2.json) is `12,106` bytes, SHA-256 `fb8b2c509121cde9bc80365ec25597b1aab1e3bfe9e7a5f274da8c2b9a4811e6`.

It was created after every other nonmanifest artifact was final. It contains `67` entries: `9` directories and `58` regular files. Its exact declared exclusions are:

1. `closeout/final-evidence-inventory-v2.json`
2. `manifest/canonical-manifest-a-v2.json`
3. `manifest/canonical-manifest-b-v2.json`

It does not claim coverage of its own bytes or future manifest bytes. Both final manifests subsequently cover the inventory.

## 19. Final sensitive-material scan

[final-sensitive-material-scan-v1.json](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/closeout/final-sensitive-material-scan-v1.json) is `18,332` bytes, SHA-256 `5f70142c1c0460920b3dcf419d436ec2009f754ec32aedb92f04cf0bc6455801`.

It scanned all `57` regular nonmanifest files existing at scan time, including the finalized implementation report, validators, adoption records, lineage records, revalidation records, and failed-attempt index.

Its exact content exclusions were:

1. Itself
2. Future manifest A
3. Future manifest B

The final inventory did not yet exist and is recorded as `not-yet-present-at-scan-time; not an exclusion`. The scan does not claim to cover its recursively changing own bytes. Matched payload content was not emitted.

Result: `plausible_live_secret_count: 0`. Both final manifests subsequently cover the scan record.

## 20. Failed/superseded attempts

Two historical failure contexts remain distinct:

- The predecessor’s nested build attempt failed with `TypeError: zip() takes no keyword arguments`. Its nine artifacts remain immutable at predecessor paths and are represented only through the external index.
- Audit-repair attempt 1 remains at `/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-4i5hddd3`, device `16777234`, inode `178947279`, mode `0700`. It stopped during the opening gate because it incorrectly compared separately authoritative Strategic B logical modes with physically sealed `0600` evidence-file modes. Failure: `AssertionError: source member identity mismatch: .examples/control_plane_normal_shell_runtime/entrypoint`.

Attempt 1 created no current contract or Plan and never began the target-correctness repair. Its explicitly nonnormative source, output set, exact failure, and complete inventory digest `1637998409dc36c50d2cf9f40d7b4b05891fe0d141d8c6f53a680064e18108e3` are bound by the successful attempt’s ledger. It was rechecked terminally unchanged.

The successful capsule is audit-repair attempt 2. No successful artifact was overwritten.

## 21. Closing supplied-root equality

The closing record is `5,400` bytes, SHA-256 `1ed0984e824685d51df19e52a0d56de24e4e47bfbeeeef037214c9dfc6d4b55a`.

Fresh closing inventories matched the opening inventories byte-for-byte for the candidate, Strategic B gate, Strategic B snapshot, blocked V1, V2, V2 audit, predecessor V3, and blocking audit. Root device/inode/mode identities and complete entry-set digests also matched.

Candidate branch, HEAD, tree, parent, upstream absence, status counts, modification classes, F source tree, and F inventory all requalified. Strategic B gate identities, canonical projection, B inventory, and B tree requalified.

The process audit found:

- All validator children reaped
- No persistent process survivors
- No persistent non-stdio descriptor survivors
- No network process
- No Plan V3/V4 process
- No repository-test or product process

## 22. Cleanup and exact-private-path ENOENT observations

The exact path

`/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/private`

was removed while empty. Before removal it was device `16777234`, inode `178948770`, mode `0700`.

Two distinct fresh `lstat` calls on that exact path both returned:

- `absent: true`
- `errno: 2`
- `errno_name: ENOENT`

The retained cleanup record is `841` bytes, SHA-256 `9732eaed3c75a867c5180e6670f5a8b6b7469b3c7ebb4491df313daf10204c65`.

## 23. Final manifest identities and capsule closure

- [Manifest A](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/manifest/canonical-manifest-a-v2.json): `12,587` bytes, SHA-256 `b7836cb66f5e23811914e69e140d544b7dbabb1e6437f819e7ff2da4a0849206`
- [Manifest B](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/manifest/canonical-manifest-b-v2.json): `12,587` bytes, SHA-256 `b7836cb66f5e23811914e69e140d544b7dbabb1e6437f819e7ff2da4a0849206`

The manifests are byte-identical, independently generated, and independently reprojected equal. Their only exclusions are themselves. They cover the final inventory, final scan, implementation report, and all other retained content.

The [final implementation report](/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b/closeout/final-implementation-report-v2.md) is `10,650` bytes, SHA-256 `b6efb70d366844ed41a386d30d912e2df01c8e499fc97544aab65473b34a51e5`. It was intentionally finalized before scan, inventory, and manifests, so it conditionally describes those future temporal steps rather than preclaiming their hashes. This inline report supplies their terminal identities.

A final read-only handoff check reproduced both manifest bytes, exact root membership, exact inventory/scan exclusions, mutation counts, adoption dispositions, and private-path absence. A postmanifest in-memory whole-root authority check also passed. No file was written after manifest closure.

## 24. Remaining uncertainty and nonclaims

The capsule establishes static documentary, identity, provenance, lineage, local-filesystem membership, and mutation-rejection facts only.

It does not claim:

- Fresh independent-audit acceptance
- Runtime validation success
- Product or live-service behavior
- Current-repository truth for Strategic B beyond the fixed supplied identities
- Shared/adversarial or hostile/remotely administered host support
- Symlink, bind-mount, mount, or pathname-alias support
- Publication, commit, deployment, readiness, or A6 authority
- Semantic-successor or orchestrator implementation
- Exhaustive absence of every theoretically possible secret encoding

A fresh independent audit remains the next authority-bearing step.

## 25. Explicit confirmations
```
CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED: true
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED: true
STRATEGIC_B_GATE_ROOT_MUTATION_NOT_PERFORMED: true
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED: true
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED: true
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED: true
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED: true
VALIDATION_CUSTODY_V3_PREDECESSOR_MUTATION_NOT_PERFORMED: true
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED: true
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED: true
V3_CONTRACT_SEMANTICS_NOT_CHANGED: true
PLAN_V4_SEMANTICS_NOT_CHANGED: true
FAILED_ATTEMPT_NORMATIVE_BYTES_NOT_COPIED_AS_CURRENT_AUTHORITY: true
EXACTLY_ONE_CURRENT_V3_NORMATIVE_WRITER: true
V2_RAW_FAILURES_PRESERVED: true
V2_CORRECTION_LINEAGE_EXPLICIT: true
V2_BLOCK_VERDICT_NOT_PROMOTED: true
RUNTIME_VALIDATION_NOT_RERUN: true
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED: true
NETWORK_CONTACT_NOT_PERFORMED: true
A6_NOT_STARTED: true
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED: true
ORCHESTRATOR_NOT_IMPLEMENTED: true
STAGING_NOT_PERFORMED_IN_CANDIDATE: true
COMMIT_NOT_PERFORMED_IN_CANDIDATE: true
INDEPENDENT_AUDIT_NOT_PERFORMED: true
SUBAGENTS_CREATED: 0
```
