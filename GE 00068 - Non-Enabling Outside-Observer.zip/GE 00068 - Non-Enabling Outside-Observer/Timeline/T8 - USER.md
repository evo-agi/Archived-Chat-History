Here is Codex's response:

# REPAIR10G\_VALIDATION\_BLOCKED\_FINAL\_FRESH\_DIVERGENCE

The sealed evidence does not prove fresh-pristine semantic restoration. Final and fresh used the same source, inventory, tools, and logical suite, and both were independently qualified; nevertheless, the selected comparator recorded six lifecycle differences and 200 unresolved diagnostic differences. The readiness verdict is therefore invalid.

The comparator did not misreport equality: under its frozen contract, any lifecycle or unknown difference blocks equality. The principal contradiction was introduced by validation construction: the selected suite explicitly expected exit `2`—qualified-different—for final↔fresh, then closeout treated that expected difference as success.

## Provenance gates

Opening and closing verification both passed:

| FieldVerified value             |                                                                                                           |
| ------------------------------- | --------------------------------------------------------------------------------------------------------- |
| Repository source T             | `c7c27cb21dbea12d36324f66e3e5feed4c0ddeea`                                                                |
| Inventory SHA-256               | `3b60a85f9eeccc12fd02405a2ba41c2e49f22931d33213ba5ad7fd4b2d42f80b`                                        |
| Membership                      | `389 total / 375 tracked / 14 nonignored untracked`                                                       |
| Branch                          | `codex/remote-alpha-external-tls-status-observation-v1`                                                   |
| HEAD                            | `567bceced5df95ecfe787cc66038d463a854e12c`                                                                |
| Parent                          | `05dde14d185b6e022dcc169ef1a658a97961850f`                                                                |
| HEAD tree                       | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                                                |
| Upstream                        | absent                                                                                                    |
| Index SHA-256                   | `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`                                        |
| Staged/deleted/renamed/unmerged | `0/0/0/0`                                                                                                 |
| Phase G manifest SHA-256        | `5dd8ac31bf841e3a371a42a92894cd526ae8e5d886f1b13afc940211a5017c49`                                        |
| Governed files                  | `52,683`                                                                                                  |
| Directories                     | `7,836`                                                                                                   |
| Filesystem policy               | Full path set matched; files regular, single-link, mode `0600` or `0700`; directories `0700`; no symlinks |
| Detached digest                 | Matched manifest SHA-256                                                                                  |
| Phase G atime fingerprint       | `d83661a103c316e4b8a8931efbe5c04f0abcf7bc86cc5875ae0ae58422c81407` throughout                             |

The Phase G atime fingerprint was identical before and after the opening gate, before the closing gate, and after the closing gate. No Phase G atime change was observed or restored.

Primary provenance: [manifest](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/evidence-manifest-v1.txt), [detached digest](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/evidence-manifest-v1.txt.sha256), and [closing inventory](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/final-source-inventory-closing-v1.txt).

## Contradiction recovered

The sealed records say all of the following:

- The [implementation report](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/implementation-report-v2.md) correctly states that all five comparisons were qualified-different and explicitly declines to claim final↔fresh equality.
- The [Phase G closeout adjudication](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/phase-g-closeout-adjudication-v2.json) nevertheless sets `all_checks_pass=true` and declares readiness.
- The [semantic adjudication](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/semantic-comparison-adjudication.json) treats “five expected qualified differences” as successful.
- The selected [comparison suite specification](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/commands/repair10g-final-semantic-comparisons-v3.json) assigns `expected_exit:[2]` to all five comparisons—including final↔fresh.
- The [failed/superseded index](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/failed-and-superseded-index-v2.json) selects v3 and supersedes v1/v2.

Thus, the report’s “qualified-different” statement is factual. The readiness conclusion is the erroneous part.

## Five selected comparisons

`BytesEqual` below is a secondary comparison of the left/right extracted-semantics SHA-256 values. The sealed comparison schema itself has no `BytesEqual`, `AcceptedEqual`, or `reason_codes` fields. `AcceptedEqual` is therefore reported as “absent”; operationally, the runner accepted exit `2`, while the frozen `equal` field was `false`.

`L/D/U` means exact lifecycle/diagnostic/unknown difference counts. In every row, `unknown_differences` exactly equals `diagnostic_differences`.

| ComparisonControls and intended policyActual equality and qualificationsExit, reasons, and exact identities/classesStatus                                                                                   |                                                                                           |                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                                                  |                                         |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------- |
| [final-fresh-result-v1](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/retained-results/final-fresh-result-v1.json)     | Left: pristine final. Right: fresh independent final. Intended: `qualified-equal`.        | `qualified-different`; `equal=false`; BytesEqual `false` (`60a4…` vs `01bc…`); AcceptedEqual absent, runner accepted difference. Embedded qualification `true/true`; external qualification `qualified/qualified`. | Exit `2`; reason codes absent. `L/D/U=6/200/200`. Lifecycle: remoteobserver package and `TestObserveV1WitnessCustodyClassificationAndContextV1`, `TestObserverClosingWitnessPrivacyV1` are final pass vs fresh fail. Diagnostics: `+99/-101`; exact-root `+6/-6`, raw `+93/-95`. | Selected v3; earlier suites superseded. |
| [final-mutant-result-v1](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/retained-results/final-mutant-result-v1.json)   | Left: pristine final. Right: final-only mutant. Intended: `qualified-different`.          | `qualified-different`; `equal=false`; BytesEqual `false` (`60a4…` vs `0fac…`); AcceptedEqual absent, runner accepted difference. Embedded `true/true`; external final `qualified`, mutant `blocked-uncertain`.     | Exit `2`; reason codes absent. `L/D/U=2/197/197`. Exact lifecycle identity: `TestRemoteAlphaExternalTLST2APRepair10Contract`, final pass vs mutant fail. Diagnostics `+98/-99`; exact-root `+6/-6`, raw `+92/-93`.                                                               | Selected v3.                            |
| [mutant-fresh-result-v1](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/retained-results/mutant-fresh-result-v1.json)   | Left: final-only mutant. Right: fresh independent final. Intended: `qualified-different`. | `qualified-different`; `equal=false`; BytesEqual `false` (`0fac…` vs `01bc…`); AcceptedEqual absent, runner accepted difference. Embedded `true/true`; external mutant `blocked-uncertain`, fresh `qualified`.     | Exit `2`; reason codes absent. `L/D/U=8/201/201`: mutant contract failure plus the remoteobserver package and two fresh failures above. Diagnostics `+100/-101`; exact-root `+6/-6`, raw `+94/-95`.                                                                              | Selected v3.                            |
| [head-final-result-v1](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/retained-results/head-final-result-v1.json)       | Left: fresh HEAD. Right: pristine final. Intended: `qualified-different`.                 | `qualified-different`; `equal=false`; BytesEqual `false` (`d0f2…` vs `60a4…`); AcceptedEqual absent, runner accepted difference. Embedded and external qualifications `qualified/qualified`.                       | Exit `2`; reason codes absent. `L/D/U=1636/964/964`; lifecycle `+498/-1138`; diagnostics `+587/-377`; exact-root `+13/-8`, raw `+574/-369`. Exact identities are preserved in the linked arrays.                                                                                 | Selected v3.                            |
| [repair9-final-result-v1](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/retained-results/repair9-final-result-v1.json) | Left: fresh Repair 9. Right: pristine final. Intended: `qualified-different`.             | `qualified-different`; `equal=false`; BytesEqual `false` (`0844…` vs `60a4…`); AcceptedEqual absent, runner accepted difference. Embedded and external qualifications `qualified/qualified`.                       | Exit `2`; reason codes absent. `L/D/U=322/411/411`; lifecycle `+67/-255`; diagnostics `+188/-223`; exact-root `+9/-8`, raw `+179/-215`. Exact identities are preserved in the linked arrays.                                                                                     | Selected v3.                            |

The mutant’s external peer record is [blocked-uncertain with \`materialization\_verified=false\`](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-final-only-mutant-v2/repair10g-final-only-mutant-v2/fresh-control-qualification-by-b-expected-rejection.json), while the comparison envelopes say the mutant is qualified. That is a separate successor qualification-binding gap; it does not cause the final↔fresh result.

External qualification records:

- [Pristine final](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-pristine-final-v2/repair10g-pristine-final-v2/fresh-control-qualification-by-b.json)
- [Fresh independent final](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/fresh-control-qualification-by-a.json)
- [Fresh HEAD](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-head-v4/repair10g-fresh-head-v4/fresh-control-qualification-by-b.json)
- [Fresh Repair 9](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-repair9-v4/repair10g-fresh-repair9-v4/fresh-control-qualification-by-b.json)
- [Comparison suite qualification](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/fresh-control-qualification-by-b.json)

### Comparator execution evidence

| PairIntentResult/resource ledgerTerminalRaw stdout/stderr |                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                             |                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| --------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| final↔fresh                                               | [intent](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/02-compare-final-fresh.command-intent.json)   | [result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/02-compare-final-fresh.command-result.json)   | [terminal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/02-compare-final-fresh.terminal-reconciliation.json)   | [stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/02-compare-final-fresh/stdout.raw), [stderr](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/02-compare-final-fresh/stderr.raw)     |
| final↔mutant                                              | [intent](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/03-compare-final-mutant.command-intent.json)  | [result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/03-compare-final-mutant.command-result.json)  | [terminal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/03-compare-final-mutant.terminal-reconciliation.json)  | [stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/03-compare-final-mutant/stdout.raw), [stderr](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/03-compare-final-mutant/stderr.raw)   |
| mutant↔fresh                                              | [intent](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/04-compare-mutant-fresh.command-intent.json)  | [result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/04-compare-mutant-fresh.command-result.json)  | [terminal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/04-compare-mutant-fresh.terminal-reconciliation.json)  | [stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/04-compare-mutant-fresh/stdout.raw), [stderr](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/04-compare-mutant-fresh/stderr.raw)   |
| HEAD↔final                                                | [intent](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/05-compare-head-final.command-intent.json)    | [result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/05-compare-head-final.command-result.json)    | [terminal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/05-compare-head-final.terminal-reconciliation.json)    | [stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/05-compare-head-final/stdout.raw), [stderr](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/05-compare-head-final/stderr.raw)       |
| Repair 9↔final                                            | [intent](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/06-compare-repair9-final.command-intent.json) | [result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/06-compare-repair9-final.command-result.json) | [terminal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/reconciliation/06-compare-repair9-final.terminal-reconciliation.json) | [stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/06-compare-repair9-final/stdout.raw), [stderr](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/repair10g-final-semantic-comparisons-v3/06-compare-repair9-final/stderr.raw) |

All five comparison executions had containment enforced, resource outcome `pass`, exit `2`, empty stderr, complete stdout through EOF, one terminal result, owner disposition complete, workers joined, endpoints released, two fresh-zero observations, and a `verified-empty` next-command barrier. [Live-result custody](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/comparisons/final-semantic-comparisons-v3/live-result-custody-v1.json) proves comparator stdout and retained-result bytes match through EOF. That custody equality is not left/right semantic equality.

## Final-versus-fresh adjudication

1. **Source T and inventory:** Equal. Both qualifications record T `c7c27…` and inventory `3b60a8…`.
2. **Suite specification and command membership:** The specifications are not byte-identical because control name, private parent, evidence path, peer-runner side, and final command name differ. They have the same three logical commands: denied-read causality, transitive-module seed, and full suite. All substantive full-suite parameters match. Evidence: [final spec](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/commands/repair10g-pristine-final-v2.json), [fresh spec](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/commands/repair10g-fresh-independent-final-v2.json).
3. **Tools and executables:** Equal by SHA-256:
   - Runner A/B: `58f864da6bbcafb19ccdbb2555f5038ddcbd2be4b47de043349660511fedd987`
   - Semantic extractor A/B: `beb91091cd8477ebf15e5b868161aff3fef988ff6739dee7c0c95d3b86400a48`
   - Comparator A/B: `d571c303a3fd3e2c6072d379fc6848e0d6971fcd8dd97afde7045258e31e0a2f`
   - Go: `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`
   - Python: `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`
   - Git: `10f9c1df894525ae4c7454258febab6d3d25071062b42cb48dbb1842cdffd2a9`
   - OpenSSL: `bf63843e6856e1994ca71092ff3b46834236eb2144dd9b6ceb85d511128b836e`
4. **Command execution contract:** Requested argv was identically `go test -json -count=1 -p=1 -parallel=1 ./...`; lane `no-tcp`; timeout `1,200,000 ms`; stdout cap `268,435,456`; stderr cap `16,777,216`. Physical cwd, sandbox profile path, and root-derived environment values necessarily used different private control roots; other environment values matched. Evidence: [final command result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-pristine-final-v2/repair10g-pristine-final-v2/reconciliation/03-full-suite-pristine-final.command-result.json), [fresh command result](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/reconciliation/03-full-suite-fresh-independent-final.command-result.json).
5. **Package/test terminal identities:** The identity universe and lifecycle length (`6,244`) match, as do the 161 package-failure-abort identities, but terminal outcomes do not. Final has pass and fresh has fail for:
   - `execution-substrate/es/externaltls/internal/statusobservation/remoteobserver`
   - `TestObserveV1WitnessCustodyClassificationAndContextV1`
   - `TestObserverClosingWitnessPrivacyV1`
   Final action counts include three more passes; fresh includes three more failures.
6. **Skips:** Equal: 31 exact skip identities—20 packages without tests and 11 test skips.
7. **Panic/race/fatal/warning/malformed state:** Both have the same five panic-causing test identities and the same substantive no-TCP `httptest` listen failure. Their panic stack diagnostics differ in goroutine numbers and addresses. Both have zero race and fatal records, the same single warning, and no malformed, truncated, duplicate-terminal, missing-terminal, or intrinsic-integrity defects.
8. **Canonical diagnostics:** Not equal. Final has 579; fresh has 581. The comparator reports 200 differences, all 200 unresolved/unknown.
9. **Diagnostic differences:** Exact sided counts are `+99/-101`.

   Of the 99 paired differences on each side:
   - 5 pairs: OS `mktemp` suffixes
   - 4 pairs: Go temporary-subdirectory numbers
   - 7 pairs: recovery-session temporary/staged names
   - 1 pair: bootstrap `logical_bytes` (`87,370,882` vs `87,371,343`)
   - 34 pairs: panic goroutine IDs and pointer/code addresses
   - 48 pairs: API timestamps, trace IDs, request IDs, and durations
   Fresh additionally contains two failure diagnostics:
   - [“private closing evidence escaped canonical output: \`7002\`” (line 10394)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/03-full-suite-fresh-independent-final/stdout.raw:10394)
   - [“private custody identity escaped canonical document: \`7002\`” (line 10719)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/03-full-suite-fresh-independent-final/stdout.raw:10719)
   The tests search canonical JSON for bare decimal sentinel substrings `7001`/`7002`; see [closing privacy assertion (line 2172)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statusobservation/remoteobserver/observe_test.go:2172>) and [custody assertion (line 3695)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/es/externaltls/internal/statusobservation/remoteobserver/observe_test.go:3695>). This is provably collision-prone. The canonical document containing the match was not retained, so the exact field that supplied `7002` cannot be established.
10. **Mappings/canonicalization:** Each semantic envelope registered exactly:
    - Control root → `<CONTROL_ROOT>`
    - Source root → `<SOURCE_ROOT>`
    - Leader PID → `<LEADER_PID>`
    Final used PID `16268`; fresh used `16266`. No port, correlation-ID, generated-fixture, temp-suffix, goroutine, address, trace-ID, request-ID, duration, or logical-byte mapping was registered. The only benign omissions were Go event `Time`, `Elapsed`, and redundant lifecycle renderings. Evidence: [final semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-pristine-final-v2/repair10g-pristine-final-v2/03-full-suite-pristine-final/semantics.json), [fresh semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/03-full-suite-fresh-independent-final/semantics.json), [comparator contract](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/tool/build-control-a-v6/source/FORMAT.md), and [comparison implementation](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/tool/build-control-a-v6/source/envelope/semantic.go).
11. **Containment and resources:** Both sides had containment `enforced`, resource outcome `pass`, semantic integrity `pass`, 53 resources in the command result and 54 in terminal reconciliation. Final attributed 1,564 processes; fresh attributed 1,563. Both established and waited for the leader, closed streams through EOF without overflow, performed two zero-observation cleanup epochs, and reached a verified-empty barrier. No residual descriptor, listener, socket, process, or mutable private root is recorded. Evidence: the command records above, their terminal records, and [global private-root cleanup](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/closeout/private-root-cleanup-v1.json).
12. **Difference classification:**
    - Material semantic difference: **yes**—the three final-pass/fresh-fail terminal identities.
    - Unknown/unclassified difference: **yes**—all 200 diagnostics.
    - Expected control-local values needing predeclared canonical mapping/classification: **yes**—the 198 paired diagnostic entries appear run-local, but remain unknown under the frozen rules.
    - Reporting-only error: **no**. Reporting is wrong, but underlying selected evidence also diverges.
    - Comparator defect for final↔fresh: **no**. Its conservative output follows the frozen rule requiring zero lifecycle and zero unknown differences.
13. **Frozen restoration requirement:** **Failed.** Both controls were qualified, but final↔fresh was neither semantically equal nor free of unknown differences.

Extracted input identities:

| ControlExtracted semantics |                                                                                                                                                                                                                                                                                                                                                   |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Final                      | `60a4a41fa796d4bcdaec05a0f8d1f002d726f9cedff1db52f8042996c8ab12c3`, 1,334,435 bytes; [raw stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-pristine-final-v2/repair10g-pristine-final-v2/03-full-suite-pristine-final/stdout.raw) 3,287,906 bytes                            |
| Fresh final                | `01bcd8452627b3310cd04d7f48ca95ef8b6f9f1205297bf0c9c17310ac0950d3`, 1,334,966 bytes; [raw stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-fresh-independent-final-v2/repair10g-fresh-independent-final-v2/03-full-suite-fresh-independent-final/stdout.raw) 3,288,528 bytes |
| Final-only mutant          | `0fac925ed7c4a7b2231b77ff10908f241bcbce18fb22e48b4305faf04c5f4b4c`, 1,334,636 bytes; [raw stdout](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256/validation/repair10g-final-only-mutant-v2/repair10g-final-only-mutant-v2/07-full-suite-mutant/stdout.raw) 3,288,059 bytes                              |
| Fresh HEAD                 | `d0f20633ce1412925fe7149d63cd6a20e66ffcfde1393181b8488caa8b0a424e`, 1,197,826 bytes                                                                                                                                                                                                                                                               |
| Fresh Repair 9             | `0844404c343a6f3b0fad0413419b4adf31e323134d8968fc7c59da3e071821e1`, 1,263,417 bytes                                                                                                                                                                                                                                                               |

## Required repair scope

No repair was performed in this turn. A subsequent authorized repair needs to address:

- **Product source/tests:** Replace collision-prone substring privacy assertions with structural field-level assertions. The sealed evidence proves a test defect; it does not prove which canonical field supplied the incidental `7002`, nor a production privacy leak.
- **Canonicalization/successor source:** Predeclare deterministic handling for the 198 run-local diagnostic differences, or construct comparison inputs that exclude them by contract. Also bind external peer qualification into comparison eligibility so the mutant cannot appear qualified when its peer record says otherwise.
- **Validation construction:** Final↔fresh must require qualified equality, not expected exit `2`.
- **Reporting:** Closeout must block readiness unless final↔fresh records `equal=true` with both sides qualified and no unresolved differences.
- **Schema clarity:** If required by the frozen reporting contract, add explicit `BytesEqual`, `AcceptedEqual`, and reason-code fields in a successor format. Their absence must not be concealed by invented values.

## Read-only parser disclosure

The parser was secondary to the sealed raw records. It consumed files read-only and was used twice.

Exact process argv for both executions:
```
["/usr/bin/python3", "-"]
```

Working directory:
```
/Users/ds/Repositories/Execution Substrate
```

Exact opening launch environment and command prefix:
```
PYTHONDONTWRITEBYTECODE=1 GIT_OPTIONAL_LOCKS=0 EXPECTED_ATIME= /usr/bin/python3 -
```

Exact closing launch environment and command prefix:
```
PYTHONDONTWRITEBYTECODE=1 GIT_OPTIONAL_LOCKS=0 EXPECTED_ATIME=d83661a103c316e4b8a8931efbe5c04f0abcf7bc86cc5875ae0ae58422c81407 /usr/bin/python3 -
```

Complete stdin source used unchanged for both:
```
import base64, hashlib, json, os, stat, subprocess
from pathlib import Path
G=Path('/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256')
R=Path('/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1')
M=G/'evidence-manifest-v1.txt'; D=G/'evidence-manifest-v1.txt.sha256'
TOP=['ab','baselines','builds','closeout','commands','comparisons','findings','opening','preparation','tool','validation']
def walk():
 out=[]
 for d,ds,fs in os.walk(G,topdown=True,followlinks=False):
  ds.sort();fs.sort(); out.extend(Path(d)/n for n in ds+fs)
 return out
def afp():
 h=hashlib.sha256()
 for p in [G]+walk():
  s=os.lstat(p); h.update(f'{p.relative_to(G)}\0{s.st_atime_ns}\n'.encode())
 return h.hexdigest()
def rf(p):
 a=os.lstat(p)
 if not stat.S_ISREG(a.st_mode) or a.st_nlink!=1: raise AssertionError(('file-policy',str(p)))
 h=hashlib.sha256(); n=0; fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
 try:
  b=os.fstat(fd)
  while True:
   x=os.read(fd,1048576)
   if not x: break
   h.update(x); n+=len(x)
  c=os.fstat(fd)
 finally: os.close(fd)
 z=os.lstat(p); ident=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if ident(a)!=ident(b) or ident(b)!=ident(c) or ident(c)!=ident(z) or n!=z.st_size: raise AssertionError(('unstable',str(p)))
 return h.hexdigest(),n,z
pre=afp(); expected=os.environ.get('EXPECTED_ATIME','')
if expected and pre!=expected: raise AssertionError(('atime-since-opening',expected,pre))
msha,msize,mst=rf(M); _,_,dst=rf(D); raw=M.read_bytes(); lines=raw.splitlines()
assert raw.endswith(b'\n') and b'\r' not in raw and lines[0]==b'ES-REPAIR10-EVIDENCE-MANIFEST-V1'
count=int(lines[1].split(b'\t')[1]); rows=[]
for line in lines[2:]:
 f=line.split(b'\t'); assert len(f)==5 and f[0]==b'F' and f[1] in (b'100600',b'100700') and f[2].isdigit() and len(f[3])==64
 enc=f[4]; assert b'=' not in enc
 rel=base64.urlsafe_b64decode(enc+b'='*((4-len(enc)%4)%4)).decode()
 assert base64.urlsafe_b64encode(rel.encode()).rstrip(b'=')==enc
 rows.append((rel,f[1].decode(),int(f[2]),f[3].decode()))
paths=[r[0] for r in rows]; assert count==len(rows)==52683 and paths==sorted(paths) and len(paths)==len(set(paths))
assert not {'evidence-manifest-v1.txt','evidence-manifest-v1.txt.sha256'}&set(paths)
for rel,mode,size,want in rows:
 got,n,s=rf(G/rel); observed='100700' if stat.S_IMODE(s.st_mode)==0o700 else '100600' if stat.S_IMODE(s.st_mode)==0o600 else ''
 assert (got,n,observed)==(want,size,mode)
actual=[]; dirs=0
for p in walk():
 s=os.lstat(p); rel=str(p.relative_to(G))
 assert not stat.S_ISLNK(s.st_mode)
 if stat.S_ISDIR(s.st_mode): dirs+=1; assert stat.S_IMODE(s.st_mode)==0o700
 else:
  assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and stat.S_IMODE(s.st_mode) in (0o600,0o700)
  if rel not in (M.name,D.name): actual.append(rel)
assert sorted(actual)==paths and dirs==7836 and sorted(p.name for p in G.iterdir() if p.is_dir())==TOP
assert msha==D.read_text().strip()=='5dd8ac31bf841e3a371a42a92894cd526ae8e5d886f1b13afc940211a5017c49'
assert msize==11293788 and stat.S_IMODE(mst.st_mode)==stat.S_IMODE(dst.st_mode)==0o600 and dst.st_ctime_ns<=mst.st_ctime_ns
invraw=(G/'closeout/final-source-inventory-closing-v1.txt').read_bytes(); il=invraw.splitlines(); assert hashlib.sha256(invraw).hexdigest()=='3b60a85f9eeccc12fd02405a2ba41c2e49f22931d33213ba5ad7fd4b2d42f80b'
inv=[]
for line in il[2:]:
 f=line.split(b'\t'); enc=f[4]; rel=base64.urlsafe_b64decode(enc+b'='*((4-len(enc)%4)%4)).decode(); inv.append((rel,f[1].decode(),int(f[2]),f[3].decode()))
assert len(inv)==389
def oid(k,b): return hashlib.sha1(f'{k} {len(b)}\0'.encode()+b).digest()
t={'f':{},'d':{}}
for rel,mode,size,want in inv:
 got,n,s=rf(R/rel); observed='100755' if stat.S_IMODE(s.st_mode)&0o111 else '100644'; assert (got,n,observed)==(want,size,mode)
 data=(R/rel).read_bytes(); q=t; parts=rel.split('/')
 for c in parts[:-1]: q=q['d'].setdefault(c,{'f':{},'d':{}})
 q['f'][parts[-1]]=(mode,oid('blob',data))
def tree(q):
 v=[(n,n,m,h) for n,(m,h) in q['f'].items()]
 v += [(n+'/',n,'40000',tree(x)) for n,x in q['d'].items()]; v.sort(key=lambda x:x[0].encode())
 return oid('tree',b''.join(m.encode()+b' '+n.encode()+b'\0'+h for _,n,m,h in v))
T=tree(t).hex(); assert T=='c7c27cb21dbea12d36324f66e3e5feed4c0ddeea'
def git(*a,ok=False):
 p=subprocess.run(['/usr/bin/git','--no-optional-locks',*a],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode and not ok: raise AssertionError(('git',a,p.stderr.decode()))
 return p
tracked=git('ls-files','-z').stdout.split(b'\0')[:-1]; untracked=git('ls-files','--others','--exclude-standard','-z').stdout.split(b'\0')[:-1]
assert len(tracked)==375 and len(untracked)==14 and sorted(x.decode() for x in tracked+untracked)==sorted(x[0] for x in inv)
sr=git('status','--porcelain=v2','-z','--untracked-files=all').stdout.split(b'\0')[:-1]
staged=deleted=renamed=unmerged=0
for x in sr:
 if x.startswith(b'1 '):
  xy=x.split(b' ',2)[1]; staged+=xy[:1]!=b'.'; deleted+=b'D' in xy
 elif x.startswith(b'2 '): renamed+=1; staged+=1
 elif x.startswith(b'u '): unmerged+=1
assert (staged,deleted,renamed,unmerged)==(0,0,0,0)
idx=Path('/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1/index')
assert rf(idx)[0]=='012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31'
assert git('branch','--show-current').stdout.strip()==b'codex/remote-alpha-external-tls-status-observation-v1'
assert git('rev-parse','HEAD').stdout.strip()==b'567bceced5df95ecfe787cc66038d463a854e12c'
assert git('rev-parse','HEAD^').stdout.strip()==b'05dde14d185b6e022dcc169ef1a658a97961850f'
assert git('rev-parse','HEAD^{tree}').stdout.strip()==b'b7cab23732572c2aaea9d5f2f1593338e2e75338'
assert git('rev-parse','--abbrev-ref','--symbolic-full-name','@{upstream}',ok=True).returncode!=0
post=afp()
print(json.dumps({'result':'pass','phase_g_manifest_sha256':msha,'phase_g_count':count,'repository_T':T,'inventory_sha256':hashlib.sha256(invraw).hexdigest(),'membership':[len(inv),len(tracked),len(untracked)],'git_posture':[staged,deleted,renamed,unmerged],'atime_before':pre,'atime_after':post,'atime_changed_during_verification':pre!=post},sort_keys=True))
```

Both executions returned `result:"pass"` with the expected repository and Phase G identities. No validation suite was rerun.

REPOSITORY\_SOURCE\_MUTATION\_NOT\_PERFORMED\
GIT\_ADMINISTRATION\_MUTATION\_NOT\_PERFORMED\
PHASE\_G\_MUTATION\_NOT\_PERFORMED\
SNAPSHOT\_NOT\_CREATED\
INDEPENDENT\_AUDIT\_NOT\_PERFORMED\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED
