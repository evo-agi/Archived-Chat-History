## Assessment

This reconnaissance is nonqualifying and should not be resumed.

It stopped before the required repository gate completed, before any explorer or probe ran, and before any launch model was assessed. Its only substantive statement—that post-load pathname checks cannot identify the object Python opened earlier—was copied from the supplied SEC-02 mechanism rather than independently investigated.

Two procedural defects require a fresh Codex conversation:

1. The prompt incorrectly made `/.../v5/closeout/report.md` mandatory even though the fifth-audit report existed only inline. The machine-readable SEC-02 causal and perspective records do exist and are sufficient when paired with an inline SEC-02 capsule.
2. Codex ran `git status --short` in the forbidden primary checkout before reading the instructions. The resulting Git-metadata effect is unbracketed. This run cannot later become qualifying.

No implementation or architecture decision was made. In particular, Models B–G remain entirely unassessed, and Model C must not be treated as selected merely because it was the anticipated leading candidate.

Start a **new read-only Codex conversation**. The corrected prompt below removes the nonexistent report-file dependency, embeds the complete SEC-02 decision capsule, requires the existing machine record as corroboration, and makes the first-command boundary explicit.

The project operating model supports exactly this reset: architecture reconnaissance is a read-only engagement, all required explorers must complete, disagreements must be preserved, and unresolved authority decisions block implementation.   The existing architecture decision still requires an externally supplied, independently audited verifier source and rejects self-verification or recursive amendment chains. 

## Corrected Codex prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete reconnaissance report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

You may create and link source-external evidence as supplemental material, but
the complete required report must also appear in the response body.

This requirement applies to every outcome:

- READY;
- PARTIAL;
- BLOCKED;
- BASELINE_MISMATCH;
- SUBAGENT_UNAVAILABLE;
- PROCESS_BOUNDARY_VIOLATION.

Do not silently truncate the inline report. Prioritize the complete inline
report over supplemental links.

IMPORTANT FRESH-CONVERSATION RULE

This must be a fresh read-only Codex conversation.

Do not reuse or resume the failed load-custody reconnaissance conversation.

The failed conversation:

- required a nonexistent fifth-audit report path;
- stopped before full baseline verification;
- ran no explorer or probe;
- selected no model;
- and executed one unrooted Git command in the primary checkout.

Its conclusions are nonqualifying except that its report truthfully records
those failures.

Before executing any shell, Python, filesystem, or Git command, read this
entire prompt.

The first Git command in this conversation must be the explicitly rooted
opening command defined below. Any earlier Git command, any implicit-cwd Git
command, or any Git command in the primary checkout is a process-boundary
violation and requires an immediate stop.

Objective

Perform a read-only architecture and feasibility reconnaissance for the
Evidence Verification v1 executable-source load-custody boundary exposed by
the fifth independent audit’s SEC-02 finding.

Do not implement or edit anything.

The fifth audit demonstrated that post-load source-path binding is
insufficient:

1. Python began loading script bytes through an external symlink whose target
   was verifier source physically beneath the evidence target.
2. The target-contained loaded source executed a synchronization prelude.
3. An external actor atomically replaced the external symlink with a direct
   regular external file containing the exact current verifier bytes.
4. `open_source_binding()` and all closing checks observed only the later
   replacement.
5. `__file__` and `sys.argv[0]` retained the same lexical external pathname.
6. The target-contained code that Python had already loaded returned canonical
   `pass`.

Freeze one finite, safe launch-custody design before authorizing source
mutation.

No repository mutation.
No documentation edit.
No formatting.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No writer subagents.
No nested subagents.

## 1. Exact inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected canonical patch manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json

Expected manifest object:

- regular;
- single-link;
- mode `0600`;
- size `3192`;
- device/inode `16777234/176911418`;
- SHA-256:
  `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`.

Expected tracked binary-diff SHA-256:

8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac

Expected verifier SHA-256:

1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f

Expected test SHA-256:

cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Repair-v3 report:

REPAIR_V3_REPORT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/closeout/implementation-report-v3.md

Fifth-audit root:

AUDIT_V5=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Do not require a local `closeout/report.md`. The fifth-audit report was supplied
inline rather than retained at that path.

Existing fifth-audit perspective reports:

AUDIT_V5_CONTRACT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/contract-authority/report.md

AUDIT_V5_CORRECTNESS=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/verifier-correctness/report.md

AUDIT_V5_TEST=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/test-validation/report.md

AUDIT_V5_SECURITY=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/security-artifact/report.md

Machine-readable SEC-02 causal:

SEC02_RECORD=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/security-artifact/source-load-race-result.json

Expected SEC-02 record SHA-256:

1eb9e9f18cdf00a264b82012d0856c7a78160adb2e7f2de5674fe201ef2b74e0

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- version `3.13.4`;
- regular single-link file;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Required initially absent reconnaissance root:

RECON_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Frozen SEC-02 capsule supplied inline

Use the following as the complete task-framing statement from the fifth audit.
Do not require another local summary report.

SEC-02

Type:
Executable-source load-to-binding race.

Severity:
high.

Classification:
Residual repairable source-boundary defect and undocumented external
launch-custody precondition.

Current contract:

- `.docs/system_overview/evidence_verification.md` and
  `.docs/system_overview/artifact_hygiene.md` categorically require a direct,
  physically external executable source;
- symlinked launch paths are nonqualifying;
- exact source-byte authentication remains external to the verifier;
- the verifier must not self-certify its source trust.

Current source surfaces:

- `tools/evidence_verify/verify_v1.py`, especially the source-binding setup,
  main entry, source-path checks, and final cleanup;
- `tools/evidence_verify/test_verify_v1.py` stationary source-boundary tests.

Causal evidence:

- an audit-owned target-contained verifier source executed a synchronization
  prelude;
- Python loaded it through an external symlink;
- after load, the symlink was atomically replaced by a direct regular external
  file containing exact current verifier bytes;
- later source binding and closing checks observed only the replacement;
- the target-contained loaded code emitted canonical `pass`, exit `0`, empty
  stderr;
- the machine-readable causal is SEC02_RECORD above.

Reachable mechanism:

- Python selects and begins executing the script object before verifier Python
  code can run `open_source_binding()`;
- `__file__` and `sys.argv[0]` preserve pathname spelling, not the original
  loader inode;
- a later no-follow open of that pathname identifies the current object, not
  necessarily the object already loaded.

Impact:

A verifier pass can coexist with target-contained code having executed when an
actor controls the external launch pathname during interpreter startup.

Required design result:

Define and enforce launch custody at or before the interpreter-load boundary,
or change the launch design so the exact object or exact source bytes Python
executes are externally bound before target-controlled code can run.

Containment:

- this causal requires control of the external launch path;
- it does not show that a continuously direct, stable repository launch was
  bypassed;
- it does not impugn the real A6D or amendment results;
- stationary SEC-01 symlink launch was repaired;
- the issue is a bounded verifier launch-contract problem, not a product,
  readiness, orchestration, or runtime-authority defect.

Uncertainty:

- a same-timing uninstrumented swap was not run;
- privileged kernel identity forgery was not tested;
- current docs do not explicitly state a trusted immutable-launch-path
  assumption.

Preserved minority view:

The exact direct regular, externally pinned launches used in the audit were
contained for those specific invocations. That narrow statement is preserved,
but it does not settle the categorical verifier contract.

## 3. Strict posture and first-command boundary

Use:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the parent may execute Git.

No explorer may execute Git.

Every Git command must be exactly:

git -C "$IMPL_R" ...

with cwd equal to IMPL_R and both Git environment bindings above.

Do not execute Git in:

- PRIMARY_R;
- A6D;
- A6D_AMEND;
- any implementation-evidence root;
- AUDIT_V5;
- RECON_ROOT.

No implicit-cwd Git command.

FIRST-COMMAND RULE

The first Git command of this conversation must be exactly:

git -C "$IMPL_R" rev-parse --show-toplevel

under the required Git environment.

No Git command may precede it.

If any Git command has already run in this conversation before that exact
command, or if any Git command runs in PRIMARY_R, return immediately:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_PROCESS_BOUNDARY_VIOLATION

Do not continue after such a violation.

Record every parent Git argv, cwd, and relevant environment.

## 4. Complete opening gate

Run revision checks as separate commands. Do not combine the optional upstream
query with required revision queries.

Require:

- physical root equals lexical IMPL_R;
- root is a direct real directory;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- parent count exactly one;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream query fails only because upstream is absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked and nine untracked;
- every path regular, single-link, working mode `0644`, logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

Require EXPECTED_MANIFEST:

- exact object identity and digest;
- exact recipe ID;
- exact branch, HEAD, and absent upstream;
- exact 13 rows;
- exact four/nine classification;
- live path, mode, size, and SHA-256 equality;
- tracked binary diff equality.

Require:

- verifier and test hashes exact;
- RECIPE source exact;
- SEC02_RECORD present, regular, single-link, stable, and exact SHA-256;
- all four perspective reports present and stable;
- REPAIR_V3_REPORT present and stable;
- A6D and A6D_AMEND present and stable.

Do not require a nonexistent fifth-audit summary file.

Stop on any mismatch:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_BASELINE_MISMATCH

## 5. Reconnaissance root

Only after the complete opening gate passes, require RECON_ROOT absent.

Create it under umask `077` with:

opening/
perspectives/
probes/
findings/
closeout/

All outputs remain beneath RECON_ROOT.

Probe temporary roots must remain beneath:

RECON_ROOT/probes/tmp/

Remove only probe-owned temporary roots.

Do not write to IMPL_R or supplied evidence.

## 6. Four required explorers

Spawn exactly four bounded read-only explorers in parallel.

Retry a failed explorer once.

No nested subagents.

No explorer Git command.

Each explorer receives a self-contained context capsule containing:

- repository and exact baseline;
- frozen SEC-02 capsule;
- current architecture decision;
- strategic objective;
- non-goals;
- mutation authority: none;
- exact required report envelope.

### Explorer 1 — Python load and invocation semantics

Under pinned Python 3.13.4, determine:

- ordinary direct-script load behavior;
- final-symlink script load behavior;
- `python -c`;
- `python -`;
- `/dev/fd/N`;
- inherited-FD and `pass_fds` behavior;
- what remains observable after module execution starts;
- exact `sys.argv`, `sys.orig_argv`, `__file__`, `__spec__`, `__loader__`,
  code-object state, and relevant file descriptors;
- whether `sys.orig_argv` retains the complete exact `-c` source string;
- embedded newline and terminal-LF preservation;
- canonical UTF-8 round trip;
- approximately 37.5 KiB current verifier source;
- host argv-size margin;
- whether `sys.orig_argv` mutability affects its evidentiary use;
- whether a supported API exposes the original script inode;
- whether module code-object comparison can bind exact source bytes;
- macOS `F_GETPATH` or other supported FD-path mechanisms and limitations.

Label evidence, inference, and uncertainty separately.

### Explorer 2 — Authority and contract analysis

Inspect:

- architecture-reset decision;
- current `PLANS.md`;
- evidence-verification documentation;
- artifact hygiene;
- capability probing;
- provenance guidance;
- subagent operating protocol;
- repair-v3 report;
- fifth-audit perspective reports;
- frozen SEC-02 capsule.

Determine:

- which owner establishes source-byte trust;
- which owner establishes launch custody;
- whether physical source location is a required invariant or merely the
  current mechanism;
- whether exact executed-byte identity can replace physical location without
  weakening the non-self-verification architecture;
- whether a trusted immutable launch-path premise is allowed or would be a new
  external assumption;
- whether launch changes require:
  - no version change;
  - launch protocol v2;
  - verifier tool v2;
  - output/schema changes;
- exact governing docs that must change under each viable model.

Do not silently relax the categorical source-external rule.

### Explorer 3 — Security and threat-model analysis

Analyze:

- target-only control;
- concurrent external launch-path control;
- same-UID rename/write capability;
- source symlink and hardlink creation;
- package-file substitution;
- registry/layout substitution;
- environment control;
- argv construction control;
- inherited-FD manipulation;
- privileged filesystem identity forgery;
- exact loaded bytes physically beneath target;
- different source bytes compiling to equivalent code objects;
- mutability of `sys.argv` and `sys.orig_argv`;
- process-list disclosure of `-c` source;
- bootstrap recursion and root of trust.

For every model, state:

- guarantees;
- required assumptions;
- residual risks;
- whether assumptions are current contracts or new strategic hardening.

### Explorer 4 — Migration, validation, and bounded implementation map

For every viable model:

- exact repository files to change;
- any new file;
- classification of every new file;
- producer and auditor invocation;
- unit-test migration;
- A6D invocation migration;
- amendment invocation migration;
- synthetic A6 migration;
- provenance inputs;
- fresh-audit inputs;
- registry/layout disposition;
- historical-fixture disposition;
- complete causal matrix;
- stop conditions;
- whether one finite implementation tranche suffices.

Preserve disagreements.

## 7. Candidate models

Adjudicate every model. Do not preselect Model C.

### Model A — stronger post-load pathname binding

Assess whether any post-load-only mechanism can prove the object Python
originally loaded.

Expected answer may be “no,” but establish it from evidence.

### Model B — externally trusted immutable launch path

Assess:

- exact proof mechanism;
- same-UID mutation;
- ownership/mode limits;
- whether the assumption is already contractual;
- whether it merely exports an unproved premise.

### Model C — source-by-value `python -c`

External producer/auditor:

1. no-follow opens exact committed `verify_v1.py`;
2. reads and hashes exact bytes;
3. matches external provenance;
4. decodes canonical UTF-8;
5. places the exact source string directly in the interpreter `-c` argv;
6. supplies an explicit physically bound package root;
7. launches pinned Python without a script pathname.

Verifier:

- requires an exact closed `-c` invocation shape;
- obtains the supplied code string from `sys.orig_argv`;
- distinguishes trust from consistency checking;
- byte-compares the re-encoded command source to the no-follow-opened package
  `verify_v1.py`;
- physically binds package, registry, and layouts;
- retains target/candidate disjointness;
- rejects script, symlink, stdin, `/dev/fd`, or ambiguous launch when this
  protocol is required;
- emits no source path or hash.

Determine whether this is exact and practical.

### Model D — FD-bound script launch

External caller:

- opens source no-follow;
- verifies bytes against provenance;
- passes the held FD;
- launches Python using `/dev/fd/N` or an equivalent descriptor path.

Determine:

- whether Python necessarily loads that exact open description;
- FD lifetime and duplication;
- whether the verifier can later bind the same object;
- platform portability;
- whether `/dev/fd` is itself an unacceptable compatibility dependency.

### Model E — fixed `-c` bootstrap executing held-FD source

A small exact `-c` bootstrap:

- receives inherited source/package FDs;
- verifies expected externally supplied identity;
- reads, compiles, and executes exact held source bytes;
- transfers a closed custody object to verifier code.

Determine:

- bootstrap byte ownership;
- whether it creates recursive trust;
- whether it is a second verifier;
- provenance and versioning;
- whether it is needed if C works.

### Model F — native or compiled launcher

Assess only as fallback:

- source and binary provenance;
- build dependencies;
- portability;
- added owner;
- proportionality.

### Model G — contract relaxation to executed-byte equivalence

Assess separately:

- exact-byte equivalence;
- code-object equivalence;
- comments, encoding, compile flags, and source locations;
- impact on source-external architecture;
- whether it is a strategic redesign rather than a bounded repair.

Do not select G silently.

## 8. Required parent probes

After all explorers complete, the parent may run bounded probes beneath
RECON_ROOT only.

Use pinned Python and no network.

At minimum run:

1. Exact current verifier under `python -c`.
2. `sys.orig_argv` exact source-string recovery.
3. Byte → UTF-8 string → argv → byte round trip.
4. Terminal-LF preservation.
5. Source size and host argv-size margin.
6. Direct script, final symlink, stdin, `-c`, and `/dev/fd/N` observable-state
   comparison.
7. Source-by-value execution while a target-contained source path exists but is
   never loaded.
8. Package-root binding and package-source comparison.
9. Package file replaced after `-c` argv construction.
10. Source/package FD survival and identity.
11. `/dev/fd/N` with inherited source FD.
12. Code-object versus separately compiled-source comparison.
13. Any claimed macOS FD-path operation.
14. Mutation of `sys.orig_argv` after startup and its implications.
15. Process-list visibility of the `-c` source, classified as non-secret source
    exposure rather than silently ignored.

Use only private byte-exact copies.

Retain exact probe source, argv, environment, stdout, stderr, exit, identities,
and cleanup.

## 9. Selection criteria

The selected design must:

1. Bind the exact object or exact bytes Python executes before target-controlled
   code can run.
2. Preserve external provenance as the trust source.
3. Avoid verifier self-certification.
4. Avoid recursive launcher or amendment trust.
5. Fail closed on unsupported capability or ambiguous launch.
6. Preserve verifier no-write and no-network behavior.
7. Keep canonical output free of source/package/target paths and readiness.
8. Support deterministic producer and auditor invocation.
9. Preserve independent A6D, amendment, and synthetic A6 use.
10. Fit one finite auditable tranche.
11. State exact threat model and residual assumptions.
12. Avoid a mere same-UID-writable pathname-stability assumption.

If none satisfies all criteria, return BLOCKED.

## 10. Parent synthesis

The parent must:

- wait for all four explorers;
- identify failures and retries;
- preserve disagreements;
- distinguish evidence, inference, uncertainty, and strategic choice;
- reconcile repository contracts with the selected target;
- select one primary model and at most one fallback;
- classify SEC-02 as implementation, invocation-contract, tool-version, or
  architecture-boundary work;
- freeze exact invocation;
- freeze exact external caller responsibilities;
- freeze exact verifier responsibilities;
- freeze exact touched files and any new file;
- freeze tests and audit sequence;
- freeze migration from current audit inputs;
- freeze stop conditions;
- close every explorer;
- reverify the baseline and supplied evidence unchanged.

Do not implement.

## 11. Verdicts

Return exactly one:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_READY

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_PARTIAL

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECONNAISSANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_RECON_PROCESS_BOUNDARY_VIOLATION

SUBAGENT_UNAVAILABLE

## 12. Complete inline final report

Include all sections inline:

1. Verdict.
2. Response-format confirmation.
3. Opening and closing repository/provenance identity.
4. Prior failed-recon disposition.
5. Frozen SEC-02 statement and machine-evidence identity.
6. Why post-load path binding is or is not sufficient.
7. Four explorer scopes and completion status.
8. Preserved disagreements.
9. Probe environment.
10. Exact probes run.
11. Probe results.
12. Model A adjudication.
13. Model B adjudication.
14. Model C adjudication.
15. Model D adjudication.
16. Model E adjudication.
17. Model F adjudication.
18. Model G adjudication.
19. Selected primary model.
20. Selected fallback, if any.
21. Rejected models and reasons.
22. Exact threat model.
23. Residual trust assumptions.
24. Exact future invocation contract.
25. Exact external producer/auditor responsibilities.
26. Exact verifier responsibilities.
27. Direct-script support disposition.
28. Tool and launch-protocol version disposition.
29. Output/schema disposition.
30. Registry/layout disposition.
31. Exact intended touched-file set.
32. Any new file and classification.
33. Complete causal and validation matrix.
34. A6D and amendment migration.
35. Synthetic A6 migration.
36. Provenance and fresh-audit sequence.
37. Mandatory stop conditions.
38. Inspection limits and unresolved uncertainty.
39. Recon-created artifacts and cleanup.
40. Git-process record.
41. Explicit confirmations:
    - repository mutation not performed;
    - documentation mutation not performed;
    - implementation not performed;
    - repository tests not run;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product paths/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not replace any section with a link.

Supplemental links may follow the complete inline report only.

No implementation.
No staging.
No commit.
No push.
No A6 restart.
```

## What to expect

A sound reconnaissance may still select `python -c`, but it must show that:

- the external caller, not the verifier, establishes trusted source bytes;
- the exact code string Python executes is fixed before any target-controlled code runs;
- any comparison inside the verifier is a consistency check, not self-attestation;
- package, registry, and layout substitution remain fail-closed;
- the invocation can be reproduced identically by producer and auditor;
- no recursive trusted launcher is introduced.

An FD-backed model may prove stronger or simpler on macOS; that is why Model D and the fixed-bootstrap Model E must be behaviorally tested rather than dismissed.

### Sources

- The failed reconnaissance supplied in this turn.
- Independent audit is a separate fresh read-only engagement, and reconnaissance must stop when the baseline or required authority input is unresolved.  
- The selected verifier architecture supplies exact source externally and explicitly avoids verifier self-verification. 
- Provenance binds work to the same bytes but does not establish correctness or authority. 
- Exact recipe/source bytes must remain available rather than only a digest. 
- Proof harness behavior and generated evidence must not become architecture or authority by drift. 

**Confidence**

- Failed-recon nonqualification: **0.999**
- Need for a fresh conversation because of the Git-boundary violation: **0.999**
- Sufficiency of inline SEC-02 capsule plus machine record for the corrected reconnaissance: **0.99**
- Likelihood that post-load-only pathname checks cannot close SEC-02: **0.995**
- Need to compare `-c`, FD-bound, and bootstrap models before implementation: **0.98**
