## Assessment

The package-evidence repair appears complete at the producer level:

- The normative contract and all fifteen schemas stayed byte-identical.
- The validator registry now owns exactly ten roles.
- `confirmation-evidence-map-validator` is explicitly current.
- Regeneration derives from the actual ten registry rows.
- The confirmation chain is acyclic and evidence-derived.
- The predecessor package, reconciliation roots, contract package, schema reconciliation, and failed audit all closed equal.
- The new package sealed with byte-identical manifests and no post-closure write.

The repaired package is still **not independently accepted**. The remaining critical path is exactly the audit-harness side of the earlier mixed finding.

That repair must address not only the false terminal-capsule calculations, but also the incorrect package-audit oracles already adjudicated:

- exclude the physical root from descendant-empty classification;
- calculate physical emptiness from the physical tree, not a self-excluding manifest projection;
- preserve each manifest grammar’s exact `root_identity` shape;
- defer all terminal-success authority until actual terminal reprojection;
- require the repaired ten-role validator registry;
- do not require replay of the root-bound independent validator;
- do not require the four overreaching preterminal-correction fields;
- verify current-role occupancy instead.

The next tranche should produce and freeze a corrected audit harness **without running the full schema-package audit**. The following tranche can then execute that exact frozen harness once against the repaired package.

## Prompt for Codex

```text
IMPLEMENT, QUALIFY, AND FREEZE THE CORRECTED
CONSTRUCTION-PARENT SCHEMA-PACKAGE INDEPENDENT-AUDIT HARNESS

This task repairs and qualifies the independent-audit harness that previously
produced a nonqualifying audit of the construction-parent schema package.

It creates a fresh audit-harness package and freezes its exact source and audit
plan.

It does not:

- run the full schema-package audit;
- accept or block the repaired schema package;
- modify the repaired schema package;
- modify the normative construction-parent contract;
- modify any generated-record schema;
- patch or execute construction-parent implementation source;
- execute process-self-test;
- execute construct mode;
- construct a target-audit harness package;
- run a target audit;
- rerun runtime validation;
- modify a repository.

Do not modify, resume, clean, finish, or reseal any supplied root.
Do not execute historical failed-audit tooling as current tooling.
Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Return the complete substantive report inline.

Return exactly one primary verdict:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIRED_READY_FOR_FRESH_AUDIT
CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIR_BLOCKED
HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FUTURE FULL-AUDIT SUBJECT
──────────────────────────────────────────────────────────────────────────────

REPAIRED_SCHEMA_EVIDENCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device:
  16777234
- inode:
  180576497
- mode:
  0700
- producer verdict:
  TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_EVIDENCE_PACKAGE_REPAIRED

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- size:
  19782
- SHA-256:
  a0b9cea7066be343416abb38e510e3f10f1cb0984d07ed193269ea3d81780b44

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  19875 each
- SHA-256:
  e3dd1d878e97b5f49c4cd6091f77d1606cccfb83a26b0a16e3404f0dcd2c076b
- byte-identical:
  required

Expected physical closure:

- total paths:
  85
- directories:
  10
- regular files:
  75
- empty descendant directories:
  0
- symlinks:
  0
- special objects:
  0
- multiply linked regular files:
  0
- directory/file modes:
  0700 / 0600

This root is the future audit subject.

In this task it may be opened read-only for:

- identity authentication;
- manifest-grammar extraction;
- closure replay;
- current-role and validator-registry fixture qualification.

Do not perform its full semantic independent audit.

Do not assign it package acceptance.

──────────────────────────────────────────────────────────────────────────────
2. PREDECESSOR SCHEMA PACKAGE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_SCHEMA_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

Expected manifests:

- size:
  15314 each
- SHA-256:
  71a95eafce77a9cf41c2839e7020c0dead925e0cd1732a99692bdd0137810968

Use this root read-only to qualify the future audit’s exact evidence-repair
scope and historical-lineage logic.

It remains historical and nonaccepted.

──────────────────────────────────────────────────────────────────────────────
3. FAILED INDEPENDENT AUDIT
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-independent-audit-_0v5svyw

Expected identity:

- device/inode:
  16777234 / 180525271
- mode:
  0700
- verdict:
  AUDIT_PROVENANCE_MISMATCH

Expected terminal manifests:

- size:
  16085 each
- SHA-256:
  22cce40cb2c543ab1b4295bdefdb8bb782c21a1b19e1eb9c40cb5feeeaa8deac

Expected physical closure:

- total paths:
  70
- directories:
  12
- regular files:
  58
- actual empty descendant directories:
  0

This root is immutable failed-audit evidence.

Do not:

- resume it;
- modify it;
- clean it;
- adopt its verdict;
- execute its sources as current audit tooling;
- copy its terminal result as a current result.

Historical source bytes may be copied into the fresh harness root only after
their exact source roles are authenticated through explicit retained bindings.

──────────────────────────────────────────────────────────────────────────────
4. GOVERNING FINDINGS RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

FINDINGS_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-audit-findings-reconciliation-58_k5uc1

Expected identity:

- device/inode:
  16777234 / 180555800
- mode:
  0700
- verdict:
  CONSTRUCTION_PARENT_SCHEMA_AUDIT_RECONCILED_MIXED_REPAIR_REQUIRED

Authenticate and inspect at minimum:

opening/failed-audit-source-registry-v1.json
analysis/empty-directory-audit-algorithm-v1.json
analysis/root-identity-canonicalization-defect-v1.json
analysis/audit-capsule-terminal-failure-v1.json
analysis/documentary-validator-role-registry-adjudication-v1.json
analysis/documentary-validator-write-behavior-v1.json
analysis/preterminal-correction-lineage-adjudication-v1.json
analysis/current-role-occupancy-v1.json
analysis/audit-and-package-finding-dependency-graph-v1.json
validation/schema-audit-findings-reconciliation-matrix-v1.json
closing/supplied-root-closing-equality-v1.json
closeout/final-inline-equivalent-report-v1.json
closeout/final-diagnostic-inventory-v1.json

The governing audit-harness findings are:

A. Physical-root empty-directory defect.

B. Manifest-projection empty-directory defect.

C. Manifest-grammar-insensitive root-identity canonicalization.

D. Premature or stale terminal-success projections.

E. Root-bound independent validator replay was incorrectly treated as required.

F. Four extra preterminal-correction fields were incorrectly treated as
   acceptance requirements.

The governing package finding was repaired in the new subject package:

- exactly ten current documentary-validator roles;
- `confirmation-evidence-map-validator` currently owned;
- evidence-derived regeneration and confirmations.

The corrected audit harness must verify that repair. It must not recreate the
old nine-role defect.

──────────────────────────────────────────────────────────────────────────────
5. SUPPORTING AUTHORITY ROOTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Open these only as needed to freeze:

- normative-contract authority;
- repaired-schema authority;
- historical contradiction sets;
- future audit acceptance requirements.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
6. FRESH AUDIT-HARNESS ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-schema-package-audit-harness-repair-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before substantive work:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- failed-audit identity;
- findings-reconciliation identity;
- future subject identity;
- predecessor subject identity;
- contract-package identity;
- schema-reconciliation identity;
- audit-harness-repair-only authority;
- full schema-package audit execution authorized:
  false;
- package repair authorized:
  false;
- contract or schema modification authorized:
  false;
- implementation creation authorized:
  false;
- process-self-test authorized:
  false;
- construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false.

Create directories lazily.
Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
7. EXACT FAILED-AUDIT SOURCE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Use only:

FINDINGS_RECONCILIATION_ROOT/opening/failed-audit-source-registry-v1.json

to identify the historical audit sources.

Authenticate all six bound source roles.

At minimum identify:

- opening inventory source;
- executed main audit source;
- manifest/reprojection source or functions;
- terminal closeout/seal source or functions.

The executed historical main source is expected to be:

tooling/main_audit_v4.py

with reported size:

102555

and its complete SHA-256 must be obtained from the authenticated source
registry and independently observed.

Do not rely on the abbreviated report hash.

The opening inventory source contains the adjudicated defect at its bound
source range corresponding to historical line 88.

Retain:

opening/historical-audit-source-authentication-v1.json

For every source bind:

- role;
- failed-root path;
- size;
- SHA-256;
- mode/link count;
- producer;
- consumer;
- executed status;
- permitted repair use.

No source may be selected by basename, recency, scoring, or fallback.

──────────────────────────────────────────────────────────────────────────────
8. CURRENT AUDIT-HARNESS SOURCE SET
──────────────────────────────────────────────────────────────────────────────

Create a fresh current source set beneath:

source/

The source set may contain:

- one finite parent audit source;
- one inventory/manifest grammar module;
- one process recorder module when required;
- bounded audit-owned fixture helpers.

Do not create:

- a persistent supervisor;
- an input loop;
- a command socket;
- direct-auditor or subagent entry points;
- a reusable orchestration service.

The finite parent must own all audit sequencing.

All child launches must pass through one retained child recorder.

Retain:

contract/current-audit-harness-source-registry-v1.json

with exactly one current source per source role.

Historical source identities remain lineage only.

──────────────────────────────────────────────────────────────────────────────
9. BOUNDED SOURCE-REPAIR AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Authorized source changes are exactly:

1. physical descendant-empty calculation;
2. top-level parent-path normalization;
3. manifest-directory lifecycle handling;
4. grammar-specific root-identity handling;
5. terminal reprojection and seal authority;
6. verdict/confirmation timing;
7. ten-role validator-registry audit logic;
8. root-bound validator replay disposition;
9. preterminal-correction audit logic;
10. fresh-root and current-input identities;
11. current subject/predecessor evidence-repair comparison.

Unauthorized changes include:

- normative-contract interpretation;
- schema semantics;
- witness or negative-case semantics;
- required validator-role semantics beyond the adjudicated ten-role set;
- package authority;
- implementation authority;
- construction-parent behavior;
- target-audit behavior;
- product or repository behavior.

Retain:

analysis/historical-to-current-audit-source-delta-v1.json

For every changed hunk bind:

- historical source and range;
- repaired source and range;
- governing reconciliation finding;
- behavior before;
- behavior after;
- subject-package semantic effect:
  none.

Require function-level AST equality for all unrelated functions.

If the repair cannot be isolated to these audit-owned concerns, return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIR_BLOCKED

──────────────────────────────────────────────────────────────────────────────
10. PHYSICAL EMPTY-DESCENDANT ALGORITHM
──────────────────────────────────────────────────────────────────────────────

Implement one authoritative physical empty-descendant algorithm.

Rules:

1. The physical root may be represented as `"."`, but it is not a descendant
   candidate for the terminal “empty descendant” invariant.

2. Normalize the parent of every top-level path to `"."`.

3. A nonroot directory is empty only when the physical no-follow traversal has
   no direct physical child for that directory.

4. Do not infer physical emptiness from a self-excluding manifest projection.

5. Before terminal manifests:
   - a reserved `manifest/` directory may be present and empty only when the
     lifecycle phase explicitly permits it.

6. After A and B physically exist:
   - `manifest/` is nonempty;
   - no other retained directory may be empty.

7. Manifest self-exclusions do not remove physical A/B from the emptiness
   calculation.

Retain:

contract/physical-empty-descendant-policy-v1.json

and:

analysis/physical-empty-descendant-field-map-v1.json

──────────────────────────────────────────────────────────────────────────────
11. EMPTY-DIRECTORY QUALIFICATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement at least these literal cases:

1. Root with direct regular-file child.
2. Root with direct directory child.
3. Root with top-level `analysis/`.
4. Empty nonroot directory.
5. Nonempty nonroot directory.
6. Root row represented as `"."`.
7. Root row omitted by manifest grammar.
8. Top-level `dirname("")` normalization.
9. Reserved empty premanifest `manifest/`.
10. Premanifest unrelated empty directory.
11. Terminal `manifest/` with A and B.
12. Terminal manifest projection excluding A and B.
13. Physical tree including A and B.
14. One manifest absent.
15. Both manifests absent in a claimed success capsule.
16. Empty descendant after terminal closure.
17. Symlink child.
18. Special child.
19. Multi-link regular child.
20. Root incorrectly included as empty candidate.

Require:

- unique names;
- exact expected classifications;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/physical-empty-descendant-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
12. MANIFEST-GRAMMAR REGISTRY
──────────────────────────────────────────────────────────────────────────────

Create:

contract/manifest-grammar-registry-v1.json

Derive each grammar from authenticated manifest bytes and governing schema or
retained grammar records.

At minimum support the exact grammars used by:

- repaired schema evidence package;
- predecessor schema package;
- authoritative contract package;
- schema reconciliation root;
- findings reconciliation root;
- historical failed audit capsule;
- future fresh audit capsule.

For every grammar freeze:

- manifest schema ID;
- top-level fields;
- entry array pointer;
- entry path field;
- root represented in entries:
  true/false;
- root identity location;
- exact root identity field set;
- exclusion location and semantics;
- type vocabulary;
- mode representation;
- identity fields;
- ordering;
- terminal metadata fields;
- empty-directory semantics:
  physical, never manifest-derived.

Unknown manifest grammar must fail closed.

Do not normalize one grammar into another by injecting fields.

──────────────────────────────────────────────────────────────────────────────
13. ROOT-IDENTITY PRESERVATION
──────────────────────────────────────────────────────────────────────────────

For every supported manifest grammar:

- parse the actual root identity exactly;
- preserve its field set;
- compare only fields owned by that grammar;
- reject missing, changed, or extra fields under that grammar;
- do not inject `path` when the grammar excludes it;
- do not remove `path` when the grammar requires it.

At minimum qualify:

1. Exact contract-package root identity.
2. Contract-package identity plus injected `path`.
3. Missing contract-package root field.
4. Changed contract-package device.
5. Changed contract-package inode.
6. Changed contract-package mode.
7. Subject grammar with legitimate `path`.
8. Subject grammar missing legitimate `path`.
9. Unknown field.
10. Unknown grammar.
11. Root path represented outside `root_identity`.
12. Descendant-only manifest with separately bound root.

Retain:

validation/root-identity-grammar-matrix-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
14. CURRENT PACKAGE-FINDING ORACLES
──────────────────────────────────────────────────────────────────────────────

Freeze corrected subject-package audit oracles.

A. Documentary-validator registry

Require:

- exactly ten current validator roles;
- exact current ownership of:
  confirmation-evidence-map-validator;
- no duplicate role;
- no duplicate current artifact;
- all ten current results present and passing;
- regeneration derived from the actual registry;
- evidence graph acyclic.

B. Root-bound validator replay

Do not require fresh execution of:

validation/independent_generated_record_schema_validator_v1.py

when:

- current source identity authenticates;
- current retained result identity authenticates;
- current registry owns the role;
- retained result passes;
- no package acceptance rule requires replay;
- direct replay would write into the supplied root.

Classify direct replay as prohibited in read-only independent audit mode.

C. Preterminal correction

Do not require:

- `exact_failed_operation`;
- `files_created_before_failure`;
- `files_superseded`;
- `superseding_result_identities`.

Instead require:

- correction record authenticates;
- failed attempt established no current authority;
- no failed artifact occupies a current role;
- no failed result contributes current pass counts, confirmations, verdict, or
  manifests;
- current-role occupancy is complete and unambiguous.

Retain:

contract/current-package-finding-oracles-v1.json

──────────────────────────────────────────────────────────────────────────────
15. PACKAGE-FINDING ORACLE MATRIX
──────────────────────────────────────────────────────────────────────────────

Cover at minimum:

Validator registry:

1. Exact repaired ten-role registry.
2. Historical nine-role registry.
3. Missing confirmation validator.
4. Duplicate role.
5. Result absent.
6. Result false.
7. Regeneration hard-coded pass.
8. Acyclic evidence graph.
9. Evidence-cycle case.
10. Historical result promoted.

Replay:

11. Root-bound validator retained and passing.
12. Root-bound validator direct replay requested in read-only mode.
13. Safe validator with explicit audit-owned `--result`.
14. Retained result identity mismatch.
15. Current registry does not own validator.

Preterminal correction:

16. Incomplete historical correction, no current artifact promoted.
17. Failed artifact at current role path.
18. Failed result included in current count.
19. Current-role occupancy complete.
20. Current-role ambiguity.
21. Four audit-only fields absent.
22. Four audit-only fields present but unauthenticated.

Require zero false outcomes.

Retain:

validation/current-package-finding-oracle-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
16. TERMINAL VERDICT AND CONFIRMATION MODEL
──────────────────────────────────────────────────────────────────────────────

The audit harness must distinguish:

- substantive audit verdict;
- preseal evidence completeness;
- terminal audit-capsule closure;
- final authoritative audit result.

Before terminal manifests, retain only nonauthoritative preseal records.

Required preseal fields include:

- substantive verdict candidate:
  ACCEPT, BLOCK, or AUDIT_PROVENANCE_MISMATCH as applicable;
- required phases terminal;
- substantive findings complete;
- supplied-root closing equality;
- cleanup complete;
- terminal closure:
  pending;
- authoritative:
  false.

Do not preassert:

- terminal reprojection passed;
- terminal manifests passed;
- no-write-after-closure passed;
- final authoritative verdict.

After every nonmanifest write is complete:

1. Generate and verify temporal inventory.
2. Generate A and B independently.
3. Write/fsync/read back A and B.
4. Independently reproject the physical audit root.
5. Run physical empty-descendant checks.
6. Run topology and mode checks.
7. Determine terminal closure success in memory.
8. Perform no later filesystem read or write after the seal point.
9. Emit the final verdict and terminal marker to stdout.
10. Exit nonreturningly.

The retained preseal substantive verdict becomes authoritative only through:

- exact A/B closure;
- successful reprojection;
- physical terminal posture;
- platform-observed terminal marker and exit.

If terminal closure fails:

- do not emit a terminal-success marker;
- do not reinterpret a provisional substantive verdict as authoritative;
- retain a truthful unsealed failure outcome before any successful seal;
- exit nonzero;
- do not create success-captioned manifests.

──────────────────────────────────────────────────────────────────────────────
17. STALE-VERDICT AND CONFIRMATION PREVENTION
──────────────────────────────────────────────────────────────────────────────

The harness must not leave:

- an earlier `PACKAGE_BLOCKED` value when the current substantive result differs;
- a terminal-success confirmation generated before reprojection;
- a retained success confirmation when the capsule fails terminal closure;
- a report claiming terminal completion before A/B verification.

Create:

contract/audit-verdict-and-confirmation-evidence-map-v1.json

Every retained preseal confirmation must bind an existing source record and
pointer.

Every terminal confirmation must be platform/transcript-authoritative or
manifest/closure-derived and must not require a postseal write.

No confirmation token may be assigned literal `true` without evidence
resolution.

──────────────────────────────────────────────────────────────────────────────
18. TERMINAL-LIFECYCLE MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Cover at minimum:

1. Successful substantive ACCEPT and successful terminal closure.
2. Successful substantive BLOCK and successful terminal closure.
3. Substantive provenance mismatch and successful failure-capsule closure.
4. Temporal inventory failure.
5. Manifest A write failure.
6. Manifest B write failure.
7. A/B byte mismatch.
8. A/B identity mismatch.
9. Reprojection mismatch.
10. Actual empty descendant.
11. Root falsely classified empty.
12. Manifest projection falsely making `manifest/` empty.
13. Unknown manifest grammar.
14. Wrong root-identity shape.
15. Preasserted terminal success.
16. Hard-coded final confirmation.
17. Stale prior verdict in report.
18. Terminal failure after provisional substantive verdict.
19. Attempted filesystem read after seal.
20. Attempted filesystem write after seal.
21. Stream-write failure after seal.
22. Failure handler attempting package write after seal.
23. Success marker with nonzero exit.
24. Exit zero without terminal marker.
25. Failure capsule with absent manifests where failure policy permits absence.

Require exact dispositions and zero false outcomes.

Retain:

validation/terminal-audit-lifecycle-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
19. FUTURE FULL-AUDIT INPUT REGISTRY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/future-full-schema-package-audit-inputs-v1.json

Bind exact future full-audit operands:

1. Current subject:
   repaired schema evidence package.

2. Predecessor:
   schema repair package.

3. Authoritative contract package.

4. Schema satisfiability reconciliation root.

5. Mixed findings reconciliation root.

6. Historical failed audit root:
   harness lineage only, not package authority.

For every input bind:

- role;
- exact path;
- device/inode/mode;
- expected temporal inventory identity when applicable;
- expected manifest identities;
- authority;
- permitted use;
- mutation:
  forbidden.

The full audit source must require these exact identities before substantive
work.

Do not execute that full audit in this task.

──────────────────────────────────────────────────────────────────────────────
20. FULL-AUDIT PHASE PLAN
──────────────────────────────────────────────────────────────────────────────

Retain a complete finite parent-owned phase plan for the future audit.

At minimum:

P00 source self-authentication and input authentication
P01 recorder causals
P02 complete subject/predecessor closure
P03 normative-contract preservation
P04 current schema-role and supersession audit
P05 metaschema validation
P06 fresh fourteen-family reconstruction
P07 fresh contract witnesses
P08 fresh schema witnesses
P09 historical contradiction regression
P10 generated-record negative audit
P11 field-map V2 audit
P12 current documentary-validator audit
P13 fresh independent schema validator
P14 prior blind-spot closure
P15 current-role occupancy and lineage
P16 security/artifact review
P17 supplied-root closing equality
P18 cleanup
P19 preseal substantive verdict
P20 terminal manifest closure and platform verdict

For every phase freeze:

- prerequisites;
- operands;
- outputs;
- pass rule;
- failure rule;
- continuation rule;
- cleanup obligation;
- authority contribution.

No phase may create a subagent or direct auditor.

──────────────────────────────────────────────────────────────────────────────
21. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Implement one finite parent process.

Top-level launch authority:

Codex platform transcript.

The audit root does not self-attest parent creation.

Every child process must use one recorder with:

- prelaunch record before spawn;
- exact argv;
- cwd;
- explicit environment;
- timeout;
- fixed outputs;
- dynamic output contract when applicable;
- stdout;
- stderr;
- exit/signal;
- reaping;
- descriptor closure;
- paths written;
- cleanup registrations;
- first blocker;
- disposition.

Require contiguous child ordinals.

No direct child bypass.

No administrative continuation.

No stdin loop.

No persistent supervisor.

──────────────────────────────────────────────────────────────────────────────
22. REPAIR QUALIFICATION — LIVE READ-ONLY REPLAYS
──────────────────────────────────────────────────────────────────────────────

Without performing the full package audit, run bounded read-only replay of:

A. Physical closure and empty-descendant checks against:

- current repaired schema evidence package;
- predecessor schema package;
- authoritative contract package;
- schema reconciliation root;
- mixed findings reconciliation root;
- historical failed audit root.

B. Manifest root-identity parsing against every grammar in the registry.

C. Current subject’s ten-role validator-registry audit.

D. Current subject’s current-role occupancy audit.

E. Current subject’s preterminal correction disposition.

Do not run:

- full schema semantic audit;
- all 946 negative cases;
- all 137 regression cases;
- full fresh independent schema validator.

This task qualifies the harness algorithms, not the subject package.

Retain:

validation/bounded-live-harness-replay-v1.json

Require all bounded lanes to pass.

──────────────────────────────────────────────────────────────────────────────
23. INDEPENDENT HARNESS VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a fresh validator that imports neither:

- repaired harness helpers;
- producer matrices;
- producer fixtures;
- producer expected-result maps.

It must independently inspect:

- source registry;
- bounded source delta;
- empty-descendant algorithm;
- manifest grammar registry;
- root-identity preservation;
- package-finding oracles;
- terminal lifecycle;
- process routing;
- phase plan;
- future input registry;
- bounded live replay;
- no full audit execution.

Run its own literal mutation registry.

Retain:

validation/independent-schema-audit-harness-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
24. STATIC SOURCE CHECKS
──────────────────────────────────────────────────────────────────────────────

Before executing repaired harness source:

A. Compile with pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B

B. AST/call-graph/dataflow analysis.

C. Bytecode/exception-table CFG analysis.

Require both analyses to prove:

- finite parent;
- no stdin reads;
- no persistent loop;
- no subagent/direct-auditor path;
- all child launches use the recorder;
- full audit mode not executed during qualification;
- no supplied-root write;
- no broad Downloads traversal;
- no latest/prefix/score selection;
- no manifest grammar field injection;
- root excluded from empty-descendant candidates;
- no physical emptiness derived from a manifest projection;
- no success authority before terminal closure;
- no filesystem read/write after seal;
- failure handler cannot write after seal.

Require agreement.

──────────────────────────────────────────────────────────────────────────────
25. QUALIFICATION EXECUTION MODE
──────────────────────────────────────────────────────────────────────────────

The repaired harness may expose exactly:

--mode qualify-harness
--mode run-full-audit

No default mode.

In this task execute only:

--mode qualify-harness

Qualification mode must:

- use audit-owned synthetic fixtures;
- perform bounded live read-only replay;
- run the required matrices;
- run the independent harness validator;
- never begin substantive full audit phases P03–P16 as a full audit;
- never produce a schema-package ACCEPT/BLOCK verdict.

`run-full-audit` must remain unexecuted.

Retain exact mode-separation proof.

──────────────────────────────────────────────────────────────────────────────
26. HARNESS SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

After qualification passes, freeze every current harness source.

Retain:

opening/schema-audit-harness-freeze-v1.json

Bind:

- source registry;
- exact source identities;
- governing findings reconciliation;
- future input registry;
- phase plan;
- process contracts;
- matrix identities;
- live replay identity;
- independent validator identity;
- static checks;
- qualification result;
- full audit mode executed:
  false;
- later source modification permitted:
  false.

Reopen every source no-follow and verify identity.

No source modification afterward.

──────────────────────────────────────────────────────────────────────────────
27. FROZEN HARNESS REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source:

- recompile;
- rerun both static analyses;
- rerun empty-descendant matrix;
- rerun root-identity matrix;
- rerun package-finding oracle matrix;
- rerun terminal-lifecycle matrix;
- rerun bounded live replay;
- rerun independent harness validator;
- verify future input registry;
- verify phase plan;
- verify full audit mode not executed;
- verify supplied roots unchanged.

Retain:

validation/frozen-schema-audit-harness-requalification-v1.json

Any mismatch requires:

HARNESS_PROVENANCE_MISMATCH

Do not edit frozen source.

──────────────────────────────────────────────────────────────────────────────
28. NO FULL AUDIT EXECUTION
──────────────────────────────────────────────────────────────────────────────

Do not invoke:

--mode run-full-audit

Do not produce:

- schema-package ACCEPT;
- schema-package BLOCK;
- a fresh full-audit verdict;
- a fresh complete schema audit;
- a current implementation-readiness conclusion.

This package may conclude only that the repaired harness is or is not ready
for one fresh full audit.

──────────────────────────────────────────────────────────────────────────────
29. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every harness-owned fixture/cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
30. HARNESS-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before closure finalize:

- source authentication;
- historical/current source registry;
- source delta;
- empty-descendant policy and matrix;
- manifest grammar registry;
- root-identity matrix;
- package-finding oracles and matrix;
- terminal lifecycle and matrix;
- future input registry;
- phase plan;
- process contracts;
- bounded live replay;
- independent harness validator;
- static checks;
- qualification result;
- source freeze;
- frozen requalification;
- supplied-root equality;
- cleanup;
- final report;
- explicit confirmations;
- temporal final inventory.

Then independently generate harness-package manifest A and B.

Require:

- root represented;
- all current directories and nonmanifest files represented;
- exactly two manifest self-exclusions;
- no empty descendant;
- no symlink;
- no special object;
- no multi-link regular file;
- modes 0700/0600;
- no cache or bytecode;
- A/B byte-identical;
- independent whole-root reprojection exact;
- no write after closure.

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIRED_READY_FOR_FRESH_AUDIT

only when:

- failed-audit and reconciliation inputs authenticate;
- source authority is explicit;
- source delta is bounded to audit-owned defects;
- physical empty-descendant algorithm passes;
- root-identity grammar preservation passes;
- current package-finding oracles pass;
- terminal lifecycle matrix passes;
- process custody closes;
- bounded live replay passes;
- static analyses agree;
- independent harness validator passes;
- sources freeze;
- frozen requalification passes;
- full audit mode remains unexecuted;
- supplied roots close equal;
- harness package seals terminally.

Return:

CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIR_BLOCKED

when:

- an audit semantic decision remains unresolved;
- an indispensable source cannot be authenticated;
- the repair requires changing package semantics;
- manifest grammars remain ambiguous;
- terminal authority cannot be frozen safely;
- package-finding oracles cannot be reconciled.

Return:

HARNESS_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- opening/closing inequality;
- historical source identity mismatch;
- unaccounted child or filesystem effect;
- cleanup-set inequality;
- frozen-source drift;
- harness-package closure failure;
- any write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh harness-root identity
3. Future subject identity and closure
4. Predecessor subject identity and closure
5. Failed-audit identity and closure
6. Findings-reconciliation identity and closure
7. Supporting-root identities
8. Historical source registry
9. Current source registry
10. Exact source identities
11. Bounded source delta
12. Physical empty-descendant implementation
13. Empty-descendant matrix
14. Manifest grammar registry
15. Root-identity preservation result
16. Root-identity matrix
17. Current package-finding oracles
18. Package-finding oracle matrix
19. Terminal verdict/confirmation model
20. Terminal-lifecycle matrix
21. Future full-audit input registry
22. Full-audit phase plan
23. Process-custody implementation
24. Qualification mode/result
25. Bounded live replay
26. Static analysis A
27. Static analysis B
28. Independent harness validator
29. Harness source freeze
30. Frozen harness requalification
31. Confirmation full audit mode did not execute
32. Supplied-root closing equality
33. Fixture/cache cleanup
34. Temporal inventory identity
35. Manifest A identity
36. Manifest B identity
37. Independent terminal reprojection
38. Terminal membership and modes
39. No-write-after-closure
40. Remaining uncertainty and nonclaims
41. Explicit confirmations

Required confirmations:

FUTURE_SUBJECT_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_SCHEMA_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_SCHEMA_AUDIT_ROOT_MUTATION_NOT_PERFORMED
FINDINGS_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
HISTORICAL_AUDIT_SOURCE_REGISTRY_AUTHENTICATED
CURRENT_AUDIT_SOURCE_REGISTRY_COMPLETE
AUDIT_SOURCE_REPAIR_BOUNDED_TO_RECONCILED_DEFECTS
ROOT_EXCLUDED_FROM_EMPTY_DESCENDANT_CANDIDATES
TOP_LEVEL_PARENT_NORMALIZED_TO_ROOT
PHYSICAL_EMPTINESS_NOT_DERIVED_FROM_MANIFEST_PROJECTION
RESERVED_MANIFEST_DIRECTORY_LIFECYCLE_HANDLED
EMPTY_DESCENDANT_MATRIX_PASSED
MANIFEST_GRAMMAR_REGISTRY_COMPLETE
ROOT_IDENTITY_FIELD_SETS_PRESERVED
NONEXISTENT_ROOT_IDENTITY_FIELDS_NOT_INJECTED
ROOT_IDENTITY_MATRIX_PASSED
TEN_ROLE_VALIDATOR_REGISTRY_REQUIRED
CONFIRMATION_EVIDENCE_MAP_VALIDATOR_REQUIRED
ROOT_BOUND_VALIDATOR_REPLAY_NOT_REQUIRED
PRETERMINAL_CORRECTION_AUDIT_OVERREACH_REMOVED
CURRENT_ROLE_OCCUPANCY_REQUIRED
PACKAGE_FINDING_ORACLE_MATRIX_PASSED
PRESEAL_VERDICTS_NONAUTHORITATIVE
TERMINAL_REPROJECTION_NOT_PREASSERTED
FINAL_VERDICT_AUTHORITY_REQUIRES_TERMINAL_SEAL
NO_STALE_PRIOR_VERDICT_RETAINED_AS_CURRENT
NO_HARDCODED_TERMINAL_CONFIRMATION
TERMINAL_LIFECYCLE_MATRIX_PASSED
FUTURE_FULL_AUDIT_INPUT_REGISTRY_FROZEN
FULL_AUDIT_PHASE_PLAN_COMPLETE
FINITE_PARENT_PROCESS_MODEL
PERSISTENT_SUPERVISOR_ABSENT
PARENT_STDIN_NOT_READ
ALL_CHILDREN_ROUTED_THROUGH_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
QUALIFY_HARNESS_MODE_EXECUTED
QUALIFY_HARNESS_MODE_PASSED
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
BOUNDED_LIVE_HARNESS_REPLAY_PASSED
STATIC_AUDIT_HARNESS_CHECK_A_PASSED
STATIC_AUDIT_HARNESS_CHECK_B_PASSED
INDEPENDENT_AUDIT_HARNESS_VALIDATOR_PASSED
FINAL_AUDIT_HARNESS_SOURCES_FROZEN
FINAL_AUDIT_HARNESS_SOURCES_NOT_MODIFIED_AFTER_FREEZE
FROZEN_AUDIT_HARNESS_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
HARNESS_PACKAGE_TEMPORAL_INVENTORY_CREATED
HARNESS_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
HARNESS_PACKAGE_MANIFEST_A_CREATED
HARNESS_PACKAGE_MANIFEST_B_CREATED
HARNESS_PACKAGE_MANIFESTS_BYTE_IDENTICAL
HARNESS_PACKAGE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
FULL_SCHEMA_PACKAGE_AUDIT_NOT_EXECUTED
NO_IMPLEMENTATION_CREATED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_HARNESS_PACKAGE_CONSTRUCTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After
`CONSTRUCTION_PARENT_SCHEMA_AUDIT_HARNESS_REPAIRED_READY_FOR_FRESH_AUDIT`,
invoke the exact frozen harness once in `run-full-audit` mode against the frozen
future input registry. Do not alter the subject package or harness between
qualification and that audit.
```

## Decision

The package-side evidence repair is complete at the producer level. Repair and freeze the audit harness next; do not rerun the full audit or restart implementation yet.

**Source:** Codex’s `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_SCHEMA_EVIDENCE_PACKAGE_REPAIRED` report and the governing mixed-repair reconciliation.  
**Confidence:** 0.99 that the package acceptance-evidence defect has been repaired; 1.00 that the old audit remains nonqualifying; 0.98 that audit-harness repair is the only remaining prerequisite to a fresh full schema-package audit.
