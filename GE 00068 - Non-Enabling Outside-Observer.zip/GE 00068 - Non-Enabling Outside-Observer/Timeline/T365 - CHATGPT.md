## Assessment

This reconciliation is decisive enough to authorize an **audit-parent repair, not a package repair**.

The package remains unaccepted because the only qualifying full audit returned `BLOCK`. But all acceptance-affecting primary failures from that audit were traced to eight audit-side defects:

1. A synthetic Finding A oracle hard-coded the script operand.
2. The H publication oracle mislabeled a precommit cleanup-fault case as authoritative success.
3. The qualification parser read the wrong contract key and rejected a valid nullable `first_blocker`.
4. The H-matrix parser expected obsolete arrays instead of the current count fields.
5. The handoff helper admitted booleans as integers and recursively converted metadata strings into output paths.
6. The security scan treated a qualification-only `Popen` sink as production-reachable.
7. It treated `failure_inject` substrings as an actual production hook without identifier or call-graph evidence.
8. It parsed an intentionally invalid syntax fixture as ordinary exported Python source.

`F-PIV` was purely derivative: the package independent validator was never launched because the two handoff summaries were falsely marked failed.

Therefore:

- **No package byte is authorized to change.**
- The current package is still **not accepted**.
- The next step is a narrowly bounded repair of the frozen parent-audit source, exact-byte freeze, then one fresh full audit.
- The fresh audit must actually run the package independent validator; the reconciliation cannot establish its result in advance.

Forward this prompt to Codex:

```text
BOUNDED QUALIFYING-BLOCK AUDIT-ORACLE REPAIR AND EXACT-BYTE PARENT-SOURCE FREEZE

This task repairs exactly the audit-side defects established by:

BLOCK_FINDINGS_RECONCILED_AUDIT_DEFECT_ONLY

It then qualifies and freezes the repaired finite parent-audit source.

It is not:

- a successor-package repair;
- a package implementation task;
- a package audit;
- an audit retry;
- a V3 target audit;
- a repository or product audit.

Do not modify any package, contract, schema, validation record, launcher,
reconciliation capsule, predecessor, blocking audit, or qualifying audit root.

Do not execute the complete parent audit.
Do not emit `AUDIT_EPOCH_START`.
Do not run Git.
Do not use the network.
Do not invoke a product or live service.
Do not stage, commit, publish, deploy, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_READY
PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT BASE PARENT-SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

BASE_PARENT_SOURCE_CAPSULE:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq

Expected identity:

- device/inode:
  16777234 / 179906468
- mode:
  0700
- producer verdict:
  PARENT_AUDIT_SOURCE_P00_REPAIR_READY

Expected temporal inventory:

closeout/temporal-final-inventory.json

- size:
  14265
- SHA-256:
  be98d7f5d176ed2ef217afee3f6da030c3530e036c0eeffbb2c66c7e8f8cc1f5

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  13502 each
- SHA-256:
  23586b791a5856199518bcaa1acf9fda20a91f557cdeb42319ea0622c164c4ab
- byte-identical:
  required

Expected freeze record:

opening/parent-source-freeze.json

- size:
  6398
- SHA-256:
  9170750be2ac907506de73326e13ac98b589d685052e833cc7c10e3d3e1feba8

BASE_PARENT_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-p00-repair-g3iqi8uq/provenance/parent-source.py

Expected source identity:

- device/inode:
  16777234 / 179932225
- size:
  190827
- SHA-256:
  85cb475093deb1cfd1496c6e1284a823bf0b217fd4a2dcdea61986986ef1b6e6
- mode/link count:
  0600 / 1

Authenticate and independently reproduce the complete base-capsule closure
before reading the source.

Open the source no-follow and require stable pre/post-read identity.

Do not modify, resume, clean, chmod, normalize, or execute this capsule.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING BLOCK-FINDINGS RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

BLOCK_FINDINGS_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-block-findings-reconciliation-ozq6_nrf

Expected identity:

- device/inode:
  16777234 / 180020352
- mode:
  0700
- primary verdict:
  BLOCK_FINDINGS_RECONCILED_AUDIT_DEFECT_ONLY

Expected final inventory:

- entries:
  15
- digest:
  a9f90d5a30bc8a9c84829f73bafa53808b2a027dba44ce6c718bee6e51b0ca1a

Authenticate the complete diagnostic closure and inspect at minimum:

closeout/final-reconciliation-report.md
findings/complete-failed-gate-registry.json
findings/finding-a-case-ledger.json
analysis/parser-source-crosswalks.json
analysis/dependency-graph.json
closing/supplied-root-equality.json
closeout/final-diagnostic-inventory.json

The governing classifications are:

F-A:
  AUDIT_ORACLE_DEFECT

F-H1:
  AUDIT_ORACLE_DEFECT

F-Q:
  AUDIT_PARSER_DEFECT

F-H2:
  AUDIT_PARSER_DEFECT

F-PID1 and F-PID2:
  one common AUDIT_EXECUTION_OR_BINDING_DEFECT

F-PIV:
  DERIVATIVE_FAILURE; no independent repair

F-S1:
  AUDIT_ORACLE_DEFECT

F-S2:
  AUDIT_ORACLE_DEFECT

F-S3:
  AUDIT_PARSER_DEFECT

No successor-package repair authority exists.

──────────────────────────────────────────────────────────────────────────────
3. QUALIFYING AUDIT EVIDENCE
──────────────────────────────────────────────────────────────────────────────

QUALIFYING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-mvpvi_kv

Expected identity:

- device/inode:
  16777234 / 180015111
- mode:
  0700
- primary verdict:
  BLOCK

Authenticate and inspect read-only:

closeout/primary-verdict.json
closeout/final-audit-report.md
closeout/parent-preseal-outcome.json
closeout/phase-terminal-results.json
closeout/explicit-confirmations.json
provenance/complete-child-ledger.json
opening/opening-gate-result.json
analysis/severity-ranked-residual-findings.json

and every exact finding, validation, handoff, parser, and security record
referenced by the reconciliation.

The qualifying `BLOCK` remains historical authority for the failed attempt. The
new parent repair must not rewrite that verdict or its records.

──────────────────────────────────────────────────────────────────────────────
4. READ-ONLY PACKAGE INPUTS
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected identity:

- device/inode:
  16777234 / 179405897
- mode:
  0700

Expected terminal manifests:

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

PREDECESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Open only the exact records and source files needed to repair and qualify the
audit logic.

Every opened root is subject to complete opening/closing equality.

Do not inspect candidate repositories, Strategic B, V1/V2/V3 targets, or
unrelated product source.

──────────────────────────────────────────────────────────────────────────────
5. FRESH REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-parent-audit-source-block-findings-repair-

Immediately emit:

SOURCE_REPAIR_ROOT=<absolute-path>

Before semantic work retain:

opening/bootstrap-start.json

including:

- fresh-root identity;
- allocation method;
- umask;
- base parent-source identity;
- reconciliation identity;
- qualifying-audit identity;
- exact read-only package inputs;
- audit epoch begun:
  false;
- full parent executed:
  false.

Create directories lazily. Do not retain empty directories.

──────────────────────────────────────────────────────────────────────────────
6. EXACT OPENING SOURCE COPY
──────────────────────────────────────────────────────────────────────────────

Copy the exact base source to:

opening/original-parent-source.py

Use:

- no-follow source open;
- exclusive destination creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Require:

- size:
  190827
- SHA-256:
  85cb475093deb1cfd1496c6e1284a823bf0b217fd4a2dcdea61986986ef1b6e6

Retain:

opening/original-source-identity.json

──────────────────────────────────────────────────────────────────────────────
7. CLOSED REPAIR SCOPE
──────────────────────────────────────────────────────────────────────────────

Create:

working/parent-source-block-findings-repaired.py

Only these eight audit-side scopes may change:

1. Finding A synthetic script-operand oracle.
2. Finding H1 postcommit-case classification.
3. Qualification-result contract/nullability parser.
4. Producer H-matrix parser and authentication.
5. Shared handoff PID/output-binding helper.
6. Security source-role and production-reachability analysis.
7. Security failure-hook identifier/call-graph analysis.
8. Expected-invalid syntax-fixture classification.

F-PIV is derivative and receives no independent implementation change except
that the repaired handoff gate must permit the already-defined validator phase
to run during the next full audit.

Preserve all other semantics, including:

- P00 schema-specific opening gate;
- P00 mutation matrix and independent validator;
- child recorder;
- dynamic root-locator handling;
- materialization commands;
- handoff commands;
- substantive package A/C/H/I/J audit logic;
- Finding C causal logic;
- publication-state reconstruction;
- package independent-validator command;
- cleanup-set equality;
- supplied-root closing equality;
- preseal gate;
- verdict rules;
- postseal terminal-seal control flow.

No package byte or package contract may change.

──────────────────────────────────────────────────────────────────────────────
8. FINDING A ORACLE REPAIR
──────────────────────────────────────────────────────────────────────────────

The defective audit-only synthetic case hard-coded `"script.py"` as the script
operand even when the tested argv’s first non-option was `"path/-I"`.

Repair the audit oracle so that it derives the script boundary exactly from the
tested invocation, using the same interpreter-option semantics required by the
package contract.

Required behavior:

- Pre-script literal token counts include only interpreter options before the
  actual script operand.
- Flag-like text inside the script pathname is not an interpreter option.
- Flag-like payload arguments after the script are not interpreter options.
- Duplicate required pre-script tokens reject.
- Missing `-I`, `-S`, or `-B` rejects.
- Environment cannot substitute for missing `-B`.
- Combined forms that do not produce the required literal-token registry
  reject.
- Reordered complete separate tokens may pass when allowed by the contract.

The exact case:

`P -I -S -B path/-I ...`

must not be rejected merely because the script path contains `-I`.

Retain the raw derived script operand, option segment, payload segment, and
token counts for every audit-owned A case.

Do not weaken the package’s own literal-token enforcement.

──────────────────────────────────────────────────────────────────────────────
9. FINDING H1 CASE-CLASSIFICATION REPAIR
──────────────────────────────────────────────────────────────────────────────

Remove positional slicing such as:

`H_CASE_NAMES[25:31]`

from authority.

Define postcommit cases through an explicit, contract-derived literal registry.

The case:

`precommit-fragment-cleanup-fault`

must be classified as precommit because exclusive final publication did not
succeed and no authoritative final commit existed.

Required expectation for that case:

- authoritative success:
  false;
- final commit:
  absent;
- staged/result/outcome fragments:
  nonauthoritative;
- cleanup fault:
  does not promote authority;
- reason:
  package-defined canonical precommit failure/cleanup disposition.

Case-array order must not affect semantics.

Mutation tests must reorder and extend the case list while preserving exact
classification by name.

Do not change the package publication model.

──────────────────────────────────────────────────────────────────────────────
10. QUALIFICATION-RESULT PARSER REPAIR
──────────────────────────────────────────────────────────────────────────────

Authenticate:

validation/qualification-result-v1.json

Expected:

- size:
  5338
- SHA-256:
  a2cfaaa9c326aab3628d1929ab6f8e0dfe8412a2d6a0c8dd0baff398e4c46811
- schema:
  execution-substrate.validation-custody-v3.audit-repair.qualification-result.v1

Authenticate:

contract/qualification-result-contract-v1.json

Expected:

- size:
  3753
- SHA-256:
  0a25d2b65b60fed54877bd7bdcf17ffa0005063c9c967dd8fcb00d15d2a9d803

Read the exact governing contract key:

`required_result_fields`

Do not recursively search for arbitrary keys named `required`.

Require exact set equality among:

- result top-level fields;
- contract `required_result_fields`;
- governing schema/field-map fields.

Require exactly the current 21-field registry.

Respect contract nullability:

- `first_blocker` may be null on success;
- nullability must be validated by the exact field rule;
- do not apply `all(value is not None)` to the result object.

Retain exact missing and extra field sets and the governing JSON pointers.

──────────────────────────────────────────────────────────────────────────────
11. PRODUCER H-MATRIX PARSER REPAIR
──────────────────────────────────────────────────────────────────────────────

Authenticate:

validation/a-c-h-i-repair/publication-boundary-matrix-final-v3.json

Expected:

- size:
  175293
- SHA-256:
  ba8f2b76f8ad97485f54f74e81a28aadece3563c8e566fa5f98926e551a770b9
- schema:
  execution-substrate.validation-custody-v3.repaired-publication-boundary-matrix.v1
- case count:
  30
- case-name digest:
  7e22e5e9f8362e1605f78fac137479b2c48745d1a38a1b88264ccfb6b0142bb4
- replay-complete count:
  30

Use the current contract-defined count fields:

- `false_acceptance_count`
- `false_rejection_count`
- `reason_mismatch_count`
- `skipped_count`
- `replay_complete_count`

Do not require legacy array fields.

Require:

- all error counts zero;
- replay-complete count equals case count;
- exact path, size, SHA-256, schema, case names, name digest;
- exact qualification-result binding;
- exact package-manifest binding;
- exact owning-contract binding, whether inline or through the qualification
  result as defined by the contract.

Absence of an obsolete legacy array must not fail authentication.

Mutation tests must cover:

- wrong count;
- missing count;
- wrong schema;
- wrong digest;
- wrong replay count;
- stale qualification binding;
- stale manifest binding;
- unexpected legacy-array substitution.

──────────────────────────────────────────────────────────────────────────────
12. HANDOFF PID-BINDING REPAIR
──────────────────────────────────────────────────────────────────────────────

Repair the shared audit helper used by both handoff phases.

PID handling:

- Use only an exact allowlist of authoritative PID pointers.
- Require:
  `type(value) is int`
- Explicitly reject booleans:
  `True` and `False` are not PID values.
- Do not recursively collect arbitrary integers.
- Retain every compared pointer and value.

At minimum bind:

- recorder-spawned child PID;
- constructed-launch `launcher_pid`;
- launcher pre-exec PID when retained;
- payload PID;
- self-check comparison result.

Account explicitly for terminal `os.execve` semantics.

Do not require an independently stored wrapper PID when the contract does not
promise one.

The audit passes the same-PID check only when the exact authoritative numeric
PID values agree and the package self-check assertion is true.

──────────────────────────────────────────────────────────────────────────────
13. HANDOFF OUTPUT-BINDING REPAIR
──────────────────────────────────────────────────────────────────────────────

Do not recursively interpret every string beneath a pointer containing
`"output"` as a filesystem path.

Use only the handoff request’s exact declared:

`expected_outputs`

list.

For every declared output require:

- exact path;
- expected root containment;
- regular type;
- mode 0600;
- single link;
- expected size/SHA-256 or schema as contractually applicable.

Metadata strings such as:

- `0600`
- `process-self-check-result`
- `regular`

must never be converted into paths.

Retain:

- declared expected outputs;
- observed exact outputs;
- missing outputs;
- extra outputs;
- metadata strings ignored as nonpaths.

The repaired helper must make the retained handoff-1 and handoff-2 records pass
without altering those records.

──────────────────────────────────────────────────────────────────────────────
14. SECURITY ROLE AND REACHABILITY REPAIR
──────────────────────────────────────────────────────────────────────────────

Replace file-presence and substring heuristics with role-aware, operation-aware
analysis.

For every Python file first classify its role through exact package contracts,
manifests, import graph, and consumers:

- production bootstrap;
- copied production process input;
- qualification harness;
- test driver;
- mutation fixture;
- expected-invalid fixture;
- report/evidence generator;
- unrelated evidence-only source.

A dynamic process sink in a qualification-only harness is not
production-reachable merely because the file is manifest-retained or available
to future consumers.

For:

`source/qualification_harness_v1.py:342`

retain:

- exact `Popen` call;
- owning function;
- argv source;
- environment source;
- callers;
- importers;
- production reachability;
- qualification-only reachability.

Require the production bootstrap import/call graph to determine export impact.

Do not declare the sink harmless solely from filename or directory placement;
bind the role through exact contracts and call graph.

──────────────────────────────────────────────────────────────────────────────
15. FAILURE-HOOK ANALYSIS REPAIR
──────────────────────────────────────────────────────────────────────────────

Do not classify arbitrary strings containing:

`failure_inject`

as executable hooks.

Analyze exact identifiers, definitions, references, calls, assignments,
imports, environment bindings, CLI bindings, and dataflow.

The reconciliation established there is no `failure_inject` definition or
identifier in the production package.

Distinguish these non-hook strings:

- `tests/failure_injection_driver_v1.py`
- `failure_injection_accepted`
- `self_check_failure_injection`

Reconstruct the actual qualification flow:

qualification harness
→ ProcessRecorder.run
→ separate driver child
→ load_source
→ install_failure
→ monkeypatch imported bootstrap functions
→ module.run

Determine whether ordinary production CLI, environment, copied artifact,
request, or launch-contract data can activate that flow.

Only a real production-reachable activating input is a production hook.

──────────────────────────────────────────────────────────────────────────────
16. EXPECTED-INVALID FIXTURE CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

Authenticate:

payloads/carrier-0003-syntax-error.py

Expected:

- size:
  50
- SHA-256:
  47fac8e58353a75dbf8b68f209b8f7c9de0f735d1ec6ae57319fb5f217ed1818
- expected syntax error:
  `expected ':'`
- line:
  1
- offset:
  21
- end offset:
  22

Classify it positively through the qualified-launcher package contract and
Carrier 0003 negative-fixture role.

Do not parse expected-invalid payload fixtures as ordinary production-export
source.

Require:

- identity matches;
- role is exact;
- expected parser failure matches;
- fixture is not imported or invoked by the production bootstrap;
- fixture remains part of qualification evidence only.

An unexpected syntax error in a production or unclassified source remains
fatal.

──────────────────────────────────────────────────────────────────────────────
17. DERIVATIVE PACKAGE-VALIDATOR GATE
──────────────────────────────────────────────────────────────────────────────

Do not run the full package independent validator in this repair task.

Repair only the gate so that, during the next fresh full audit:

- successful handoff summaries permit P13 to launch;
- failed handoff summaries block it;
- no Boolean-as-PID or metadata-as-path artifact can block it;
- its exact canonical command remains unchanged.

Retain one in-memory phase-routing test proving:

- the two retained successful handoff records make P13 eligible;
- a genuinely failed handoff makes P13 ineligible.

Do not preclaim that the package independent validator will pass.

──────────────────────────────────────────────────────────────────────────────
18. RETAINED-EVIDENCE REPLAY
──────────────────────────────────────────────────────────────────────────────

Run a read-only replay of the repaired audit logic against the exact qualifying
audit evidence and unchanged package records.

Require:

- F-A reconciles as pass;
- F-H1 reconciles as pass;
- F-Q reconciles as pass;
- F-H2 reconciles as pass;
- F-PID1 reconciles as pass;
- F-PID2 reconciles as pass;
- F-S1 reconciles as pass;
- F-S2 reconciles as pass;
- F-S3 reconciles as pass;
- F-PIV is classified `eligible-to-run`, not passed;
- no package record is changed;
- no package verdict is emitted.

Retain:

validation/retained-block-evidence-replay-v1.json

This is an audit-logic regression record, not package acceptance evidence.

──────────────────────────────────────────────────────────────────────────────
19. AUDIT-LOGIC MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a closed audit-owned mutation registry covering at minimum:

Finding A:

1. Real script path contains `-I`.
2. Real script path contains `-S`.
3. Real script path contains `-B`.
4. Payload text contains all three flags.
5. Duplicate pre-script `-I`.
6. Missing pre-script `-I`.
7. Missing pre-script `-S`.
8. Missing pre-script `-B`.
9. Combined token form.
10. Tokens only after script.
11. Wrong interpreter observation.
12. Stale observation.

H1:

13. Case order changed.
14. Unrelated case inserted before postcommit cases.
15. Precommit cleanup-fault mislabeled postcommit.
16. Actual postcommit fault.
17. Missing named case.
18. Duplicate named case.

Qualification parser:

19. Exact 21-field success with nullable first blocker.
20. Missing required field.
21. Extra field.
22. Wrong contract key.
23. Stale contract identity.
24. Nonnullable field null.
25. Success false with missing blocker when blocker is required.

H matrix parser:

26. Exact count-field baseline.
27. False-acceptance count nonzero.
28. False-rejection count nonzero.
29. Reason-mismatch count nonzero.
30. Skip count nonzero.
31. Replay count mismatch.
32. Wrong digest.
33. Wrong schema.
34. Stale qualification binding.
35. Stale manifest binding.
36. Obsolete arrays present instead of required counts.

PID binding:

37. Exact matching numeric PIDs.
38. Boolean true plus matching PID.
39. Boolean false plus matching PID.
40. Historical PID mixed with current PID.
41. Missing authoritative PID.
42. Mismatched launcher/payload PID.
43. Self-check false despite equal numeric values.

Output binding:

44. Exact declared output present.
45. Declared output missing.
46. Undeclared extra output.
47. Metadata strings below output-related fields.
48. Output outside materialization root.
49. Wrong output type/mode/link/hash.

Security:

50. Qualification-only Popen.
51. Production-reachable Popen.
52. Error string containing `failure_inject`.
53. Filename containing `failure_injection`.
54. Actual callable production failure hook.
55. Expected-invalid syntax fixture.
56. Unexpected invalid production source.
57. Unclassified invalid source.
58. Qualification-only monkeypatch driver.
59. Production import of qualification harness.

Routing:

60. Two valid handoffs make P13 eligible.
61. One invalid handoff blocks P13.
62. Not-reached handoff blocks P13.
63. Boolean-as-PID cannot make handoff valid.
64. Metadata-as-path cannot make handoff invalid.

Add all further cases required by the repaired source.

Require:

- exact literal case-name registry;
- unique names;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/audit-logic-mutation-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
20. INDEPENDENT AUDIT-LOGIC VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports neither the repaired parent source nor
the first matrix helper.

It must independently validate:

- script-boundary extraction;
- explicit H case classification;
- qualification field-set/nullability parsing;
- H count-field authentication;
- PID allowlist and strict integer typing;
- declared-output-only handling;
- production versus qualification reachability;
- exact identifier/call-graph hook analysis;
- expected-invalid fixture handling;
- P13 routing.

Use its own literal case registry and expected reasons.

Require the same zero-error conditions.

Retain:

validation/independent-audit-logic-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
21. EXACT SEMANTIC DELTA
──────────────────────────────────────────────────────────────────────────────

Retain a complete original-to-repaired source delta.

For every changed hunk record:

- original and repaired ranges;
- owning audit defect:
  F-A, F-H1, F-Q, F-H2, F-PID, F-S1, F-S2, or F-S3;
- behavior before;
- behavior after;
- governing reconciliation evidence;
- authority effect;
- unrelated semantics changed:
  false.

Expected ownership:

parent-audit-qualifying-block-oracle-parser-binding-repair

No package-audit acceptance predicate outside these eight scopes may change.

If another semantic source change is indispensable, stop with:

PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_BLOCKED

Do not widen the repair silently.

──────────────────────────────────────────────────────────────────────────────
22. COMPILATION AND FULL STATIC REGRESSION
──────────────────────────────────────────────────────────────────────────────

Compile the repaired source without executing it using pinned Python with:

-I -S -B

Require:

- exit 0;
- empty stdout;
- empty stderr;
- source unchanged.

Then rerun:

- complete static noninteractive gate;
- complete 25-item structural crosswalk;
- P00 mutation matrix;
- independent P00 validator;
- read-only P00 replay;
- postseal checker A;
- postseal checker B;
- postseal mutation matrix.

Require all previously qualified P00 and postseal guarantees to remain true.

No regression is permitted.

──────────────────────────────────────────────────────────────────────────────
23. FREEZE THE REPAIRED SOURCE
──────────────────────────────────────────────────────────────────────────────

Only after all repair and regression gates pass, install the exact repaired
bytes at:

provenance/parent-source.py

Use:

- exclusive creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Retain:

opening/parent-source-freeze.json

containing:

- base source identity;
- repaired source identity;
- exact semantic-delta identity;
- block-findings-reconciliation identity;
- compilation identity;
- retained-evidence replay identity;
- mutation-matrix identity;
- independent-validator identity;
- P00 regression identities;
- postseal regression identities;
- source frozen:
  true;
- later modification permitted:
  false;
- audit epoch begun:
  false.

──────────────────────────────────────────────────────────────────────────────
24. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against the exact frozen path:

1. Reopen no-follow and verify identity.
2. Compile again.
3. Rerun retained-evidence replay.
4. Rerun the audit-logic mutation matrix.
5. Rerun the independent validator.
6. Rerun the static gate.
7. Rerun the 25-item crosswalk.
8. Rerun P00 regressions.
9. Rerun both postseal checkers.
10. Rerun the postseal mutation matrix.
11. Compare all pre-freeze and post-freeze result identities under documented
    path-bound normalization.

Require complete equality.

Retain:

validation/frozen-source-requalification.json

Any mismatch requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit the frozen bytes.

──────────────────────────────────────────────────────────────────────────────
25. NO AUDIT EPOCH AND NO FULL AUDIT EXECUTION
──────────────────────────────────────────────────────────────────────────────

Do not emit:

AUDIT_EPOCH_START

Do not invoke the repaired parent’s `main`.

Do not execute:

- the complete package audit;
- package producer validation;
- package independent validation;
- canonical materializations;
- Carrier 0002 handoffs;
- substantive V3 target audit;
- product or repository code.

Only bounded read-only retained-evidence replay, audit-owned parser/oracle
fixtures, compilation, and static analysis are authorized.

──────────────────────────────────────────────────────────────────────────────
26. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality for:

- base parent-source capsule;
- block-findings reconciliation root;
- qualifying audit root;
- successor;
- predecessor;
- blocking audit;
- qualified launcher;
- import reconciliation;
- pinned Python.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
27. REPAIR-CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before terminal sealing:

- bootstrap start;
- supplied-root opening identities;
- original source;
- repaired source;
- exact semantic delta;
- Finding A repair evidence;
- H1 repair evidence;
- qualification-parser repair evidence;
- H-matrix parser repair evidence;
- PID/output-binding repair evidence;
- security-role/hook/fixture repair evidence;
- P13 routing evidence;
- retained-evidence replay;
- audit-logic mutation matrix;
- independent validator;
- compilation;
- static regression;
- P00 regressions;
- postseal regressions;
- frozen source;
- freeze record;
- frozen-source requalification;
- supplied-root closing equality;
- final report;
- temporal final inventory.

Then create two independently generated terminal manifests.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- manifests byte-identical;
- no write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
28. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_READY

only when:

- all supplied roots authenticate and close;
- exact base-source authority is established;
- source delta is bounded to the eight audit defects;
- retained evidence replays correctly;
- every former false finding reconciles as pass;
- P13 is correctly classified eligible-to-run but not preclaimed passed;
- audit-logic mutation matrix passes;
- independent validator passes;
- repaired source compiles;
- static and structural regressions pass;
- P00 and postseal regressions pass;
- exact repaired bytes are frozen;
- frozen requalification passes;
- supplied-root closing equality passes;
- repair capsule closes;
- audit epoch did not begin;
- full parent audit was not executed.

Return:

PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_BLOCKED

when:

- a package defect is discovered during bounded repair;
- the audit defects cannot be repaired without wider source changes;
- another audit defect is discovered outside the authorized scope;
- retained evidence cannot be replayed consistently;
- any P00 or postseal regression occurs.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation or closing inequality;
- source-authority mismatch;
- unauthorized source drift;
- frozen-source mismatch;
- repair-capsule closure failure.

──────────────────────────────────────────────────────────────────────────────
29. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-root identity
3. Base parent-source identity and closure
4. Block-findings reconciliation identity
5. Qualifying-audit identity and retained evidence
6. Successor/predecessor/blocking-audit identities
7. Original parent-source identity
8. Repaired parent-source identity
9. Exact semantic delta
10. Finding A oracle repair
11. H1 case-classification repair
12. Qualification-result parser repair
13. H-matrix parser repair
14. PID-binding repair
15. Output-binding repair
16. Security role/reachability repair
17. Failure-hook analysis repair
18. Expected-invalid fixture repair
19. P13 routing treatment
20. Retained-evidence replay
21. Audit-logic mutation matrix
22. Independent audit-logic validator
23. Repaired-source compilation
24. Static/structural regression
25. P00 regression
26. Postseal regression
27. Frozen parent-source identity
28. Freeze-record identity
29. Frozen-source requalification
30. Supplied-root closing equality
31. Repair-capsule inventory and manifests
32. Confirmation audit epoch did not begin
33. Confirmation full parent audit was not executed
34. Remaining uncertainty and nonclaims
35. Explicit confirmations

Required confirmations:

BASE_PARENT_SOURCE_CAPSULE_MUTATION_NOT_PERFORMED
BLOCK_FINDINGS_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
QUALIFYING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_PACKAGE_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
EXACT_BASE_SOURCE_AUTHORITY_VERIFIED
ORIGINAL_PARENT_SOURCE_BYTES_PRESERVED
REPAIR_BOUNDED_TO_EIGHT_AUDIT_DEFECTS
NO_PACKAGE_BYTE_MODIFIED
NO_PACKAGE_REPAIR_AUTHORITY_ASSUMED
FINDING_A_SCRIPT_BOUNDARY_FIXED
FINDING_H1_CASE_CLASSIFICATION_FIXED
QUALIFICATION_RESULT_REQUIRED_FIELD_PARSER_FIXED
QUALIFICATION_RESULT_NULLABILITY_FIXED
PRODUCER_H_COUNT_FIELD_PARSER_FIXED
HANDOFF_PID_BOOLEAN_EXCLUDED
HANDOFF_PID_POINTERS_ALLOWLISTED
HANDOFF_OUTPUTS_READ_FROM_DECLARED_LIST_ONLY
QUALIFICATION_HARNESS_REACHABILITY_CLASSIFIED
FAILURE_HOOK_IDENTIFIER_ANALYSIS_FIXED
EXPECTED_INVALID_FIXTURE_CLASSIFIED
PACKAGE_INDEPENDENT_VALIDATOR_GATE_ELIGIBLE
PACKAGE_INDEPENDENT_VALIDATOR_NOT_PRECLAIMED_PASSED
RETAINED_BLOCK_EVIDENCE_REPLAY_PASSED
AUDIT_LOGIC_MUTATION_MATRIX_PASSED
INDEPENDENT_AUDIT_LOGIC_VALIDATOR_PASSED
REPAIRED_PARENT_SOURCE_COMPILED_SUCCESSFULLY
ALL_25_STRUCTURAL_ITEMS_PASSED
STATIC_NONINTERACTIVE_GATE_PASSED
P00_REGRESSIONS_PASSED
POSTSEAL_CHECK_A_STILL_PASSED
POSTSEAL_CHECK_B_STILL_PASSED
POSTSEAL_MUTATION_MATRIX_STILL_PASSED
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_RECOMPILE_PASSED
FROZEN_SOURCE_REQUALIFICATION_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
AUDIT_EPOCH_NOT_STARTED
FULL_PARENT_AUDIT_NOT_EXECUTED
NO_V3_TARGET_AUDIT_STARTED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS_CREATED
```

After `PARENT_AUDIT_SOURCE_BLOCK_FINDINGS_REPAIR_READY`, execute the exact frozen
source once in a wholly fresh full package audit. Do not regenerate, edit, or
re-preflight it.
```

**Source:** Codex’s `BLOCK_FINDINGS_RECONCILED_AUDIT_DEFECT_ONLY` report in the current turn.

**Confidence:** 0.995 that no package repair is authorized; 0.99 that the qualifying `BLOCK` was caused entirely by the eight reconciled audit defects; 0.98 that the bounded parent-source repair above is the correct next authority-bearing step.
