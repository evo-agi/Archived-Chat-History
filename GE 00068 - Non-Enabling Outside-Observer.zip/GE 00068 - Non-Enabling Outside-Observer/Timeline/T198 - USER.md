# Independent Evidence Verification v1 audit

## 1. Verdict

**BLOCK.** The exact successor can return success and publish an accepted record into a directory that has been moved away from the declared `--record` pathname. A causal test reproduced the custody gap.

## 2. Pre-epoch disclosure and audit start

Before the audit epoch, I read the pasted request through its absolute attachment path while the command’s cwd was the unrelated primary checkout. I did not access content beneath that checkout. The audit epoch began before the first repository provenance command; every subsequent substantive command used the frozen implementation checkout or the audit-owned root as its explicit cwd. The known nonqualifying audit root was not inspected or reused.

## 3. Frozen identities

The implementation checkout was `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`. It remained on `codex/evidence-verification-v1` at HEAD `567bceced5df95ecfe787cc66038d463a854e12c`, tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`, sole parent `05dde14d185b6e022dcc169ef1a658a97961850f`, with no upstream.

The canonical repository manifest was SHA-256 `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`; the full-index tracked working-tree diff was `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`. The governed inventory contained exactly 477 objects. The unchanged verifier was 40,121 bytes, SHA-256 `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`.

The exact [successor source](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py) was 45,678 bytes, SHA-256 `3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631`. Its exact base copy was 33,758 bytes, SHA-256 `c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24`. The source delta was SHA-256 `a9f1f7d3ec09317126b575ade443fe89e7b9a7d31db7a0466d63c452e0bd3bd2`.

## 4. Selected audit root

Python `tempfile.mkdtemp` atomically selected:

`/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im`

It was a direct physical directory, owned by the effective user and mode 0700. It was not renamed to a fixed suffix. Its private `tmp/` was empty at close.

## 5. Opening and closing provenance

Opening and corrected closing checks matched the 183-file, 10-directory repair-root closure. Both canonical repair manifests were byte-identical at SHA-256 `58b1f0fe386be8fafd3d073a80b99bd9ae3191f0547f40ce8967ccf18669fc00`; their 181 SHA-bearing rows covered every nonmanifest file once, and only the two manifests were self-excluded. Files were regular, single-link, 0600; directories were 0700.

The base repair inventory and prior blocking-audit inventory remained exact. The base manifest was `70e2a46949f2bc0eb25a799e60af2c44e73112a408bd119fc8e297a6203eec15`. A6D and amendment manifest hashes remained `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9` and `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`. Pinned Python was version 3.13.4, 119,424 bytes, single-link, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Two read-only checker mistakes were retained and corrected: the first opening check counted `.git` and hashed `HEAD^..HEAD`; the first closing check prefixed root-relative inventory paths with `./`. Corrected comparisons matched the frozen inputs. The [closing provenance record](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/closing_provenance.json) reports all 30 Boolean checks passing.

## 6. Four auditors

Auditors 1–3 started concurrently. Auditor 4 started after auditor 1 completed. None delegated further, wrote files, ran Git, imported repository modules, or contacted the network. The parent retained their reports under `AUDIT_ROOT/auditors/`.

| Auditor | Exact principal operands | Cwd and status |
| --- | --- | --- |
| [Contract](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/auditors/contract.md) | Repair-root base, successor, source delta; implementation-root `PLANS.md` and `.docs/system_overview/evidence_verification.md` | Inherited cwd not observed; all substantive commands used the implementation root. Scoped pass. |
| [Filesystem](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/auditors/filesystem.md) | Successor, publication tests and causals, implementation report, audit-owned displacement and collision records, governing docs | Bare `pwd` with explicit workdir returned the implementation root; substantive commands used it. Confirmed blocker. |
| [Snapshot](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/auditors/snapshot.md) | Base, successor, depth/snapshot causals, compatibility results, prior blocking-audit snapshot report, governing docs | Bare `pwd` with explicit workdir returned the implementation root; substantive commands used it. Scoped pass. |
| [Security](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/auditors/security.md) | Successor, manifests, 22 copied records, compatibility results, audit-owned causals, frozen verifier/layout and sealed manifests | Inherited cwd not observed; substantive commands used the implementation root. Confirmed blocker. |

Each retained report states evidence, inference, uncertainty, uninspected scope, disagreements, and “mutation performed: no; nested subagents created: no.”

## 7. Exact source delta

Independent regeneration produced the supplied 21,432-byte unified diff byte-for-byte. The changes were confined to caller-evidence destination relationships, staged exclusive publication, its output state machine and capability probe, private deterministic test controls, and explanatory constants/comments. CLI names, order, required status and defaults remained unchanged. The snapshot/depth block was byte-identical to base: 7,831 bytes, SHA-256 `287302fb8e96d79898e1ae30f632f346a45a6aa76ea1bc030e26e7267b9fe7ff`. No unrelated semantic widening was found.

## 8. Corrected collision contract

A final pathname created by another writer is foreign evidence, even when its bytes say `"outcome":"accepted"`. Its presence alone is not this caller’s acceptance. The two fresh collision causals preserved the foreign object and returned nonaccepted with no accepted shared-output projection. The producer’s earlier literal-absence objection is resolved by the corrected contract; foreign pathname presence is not a defect.

## 9. Caller-evidence containment

The source compares descriptor-bound physical ancestry in both directions before child launch and again before publication. A fresh audit-owned exact-byte source copy rejected equal, source descendant, validation descendant, ancestor, symlink-mediated, and supported case-alias destinations. Each rejection created no record, sidecar, or stage; the copied caller-evidence inventory and A6D manifest remained unchanged. The observed classification was `RECORD_DESTINATION_CONTAINMENT`, or `DIRECTORY_SYMLINK_OR_TYPE` for the symlink. See the [containment causal](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/containment_causal.json).

## 10. Atomic-publication capability

The source uses Darwin `renameatx_np` with `RENAME_EXCL = 0x00000004`, with both names relative to the same held parent descriptor. Its behavioral probe runs before public output creation. A fresh [capability causal](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/capability_causal.json) found that an occupied target preserved both objects and returned `RECORD_DESTINATION_EXISTS`; an unoccupied target received the staged inode, removed the source name, and remained single-link 0600. The probe cleaned its names. No copy/delete, overwrite, or persistent hard-link fallback was observed.

## 11. Output state machine and commit point

The caller initially requires stdout sidecar, stderr sidecar, final JSON, and deterministic stage name to be absent. It creates sidecars and stage exclusively as 0600 files, writes and fsyncs them, closes them, and reobserves identity and bytes. Acceptance-bearing provenance, snapshots, relationships, parent binding, and outputs are checked before [exclusive stage-to-final rename](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py:539). That rename is the accepted-record commit point. Normal success has three final outputs, no stage, canonical accepted JSON, empty errors, matching sidecars, and caller return 0. Postcommit hook, parent-close, and shared-stdout errors do not downgrade a committed record.

The commit point is **not sufficient to bind the final record to the declared pathname**, as section 12 shows.

## 12. Destination-parent displacement causal

The parent ran an independent [causal script](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/displacement_causal.py) against exact successor bytes. Immediately after the final checks and before the real exclusive rename, it moved the held 0700 `records` directory to `records-moved`, created a distinct 0700 replacement at `records`, then allowed the real rename through the held descriptor.

The [result](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/displacement_causal.json) records held-directory inode `177420060`, replacement inode `177420067`, and staged/final inode `177420066`. The moved directory held canonical accepted JSON and sidecars; the replacement was empty and the declared final pathname was absent. Nevertheless `main()` returned 0, shared stdout reported accepted, errors were empty, and verifier exit was 0. Source and sealed manifest were unchanged. This reproduces an accepted-record custody gap and is the blocking defect.

## 13. Ordinary failure behavior

Fresh execution of an audit-owned adaptation of the 17-case publication matrix covered failures before stdout; partial stdout/stderr/stage writes; their fsyncs; intervals between outputs; staged reobservation; early parent rebind; unavailable capability; exclusive-publication failure; success; postcommit error; and shared-stdout failure. Ordinary precommit cases left no caller-created final JSON and emitted no accepted shared output. The staged-reobservation failure, which exercises the prior late-JSON mechanism, left final JSON absent. The [fresh matrix](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/causals/publication-failure-matrix-fresh.json) used exact successor bytes and wrote only audit-owned evidence. Its adapted test logic is distinguished from the independently authored displacement and collision causals.

## 14. Foreign-final collisions

For both arbitrary bytes and canonical schema-valid accepted-looking JSON, the foreign file was created after initial absence checking and before exclusive publication. Its device, inode, type, mode, link count, size, and bytes were unchanged after failure and retry. The staged inode did not become the final inode. The caller exited through `RECORD_DESTINATION_EXISTS`, produced no accepted shared output, retained sidecars/stage as failed-attempt evidence, and a same-basename retry rejected. See the [foreign-collision causal](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/foreign_collision_causal.json).

## 15. Partial artifacts and retry

Partial sidecars and stages stayed private 0600 and blocked reuse of the same occupied directory/name. A failure before creating any artifact left a fresh destination available. A normal successful record rejected a same-basename retry without changing its three outputs. When a parent is replaced, artifacts under its former inode do not occupy the new pathname; that path can appear fresh. The reproduced accepted displacement makes this distinction consequential and requires a custody repair.

## 16. Hook reachability

Both private hooks defaulted to null. Fresh [hook tests](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/hook_causal.json) set each non-null in turn and found that normal `main()` rejected it before output or child launch. No CLI, environment, target byte, or source-by-value verifier argument sets either hook. The displacement test used an audit-process in-memory wrapper to model the interleaving; it did not expose a normal-input hook route.

## 17. Depth and snapshot regression

The 7,831-byte block preserved limits of 12,000 files, 2,048 directories, depth 12, 1,024 relative-path bytes, 4,096 root-path bytes, 256 MiB per file, and 4 GiB total. Fresh audit-owned adaptations reran all [11 depth cases](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/causals/depth-boundaries-fresh.json) and [31 snapshot cases](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/causals/successor-snapshot-matrix-fresh.json). Root depth 0 and file/directory depth 12 passed; depth 13 rejected before overdepth stat/open. Stable repetition, symlink/special/hardlink, replacement, mutation, disappearance, type/mode/link, resource, listing-capability, and no-watched-root-write cases passed their expected classifications.

## 18. Protocol, schema, and fields

Launch protocol stayed `execution-substrate.evidence-closure-launch/v2`; record schema stayed `execution-substrate.evidence-closure-launch-record.v3`. Base and successor retained these exact 25 top-level fields and their roles:

`argv_shape`, `argv_shape_sha256`, `atomic_loaded_object_binding`, `candidate`, `environment`, `errors`, `exit`, `interpreter`, `interpreter_trust_model`, `launch_protocol`, `layout_expected_sha256`, `outcome`, `package_root`, `registry_expected_sha256`, `schema`, `shared_or_adversarial_host_supported`, `snapshots`, `source`, `stderr_sha256`, `stderr_size`, `stdout_sha256`, `stdout_size`, `target`, `transient_trusted_principal_replacement_covered`, `verifier_child_launched`.

The caller still launches verified verifier source by value with `-I -S -B -c`, checks interpreter/source/registry/layout/result identities, and adds no fourth public output.

## 19. Record disclosure and attribution

The 22 copied implementation records and fresh accepted runs were canonical v3 JSON with matching sidecar sizes and hashes. No inspected final JSON contained an absolute `/Users/ds/` path, stage name, verifier source text, or watched-root path. Fresh collision runs emitted no shared attribution of foreign objects. Accepted records retain the mandatory false values for atomic loaded-object binding, transient trusted-principal replacement coverage, and shared/adversarial-host support. The displacement case violates *location attribution*: its accepted record existed, but not at the caller’s declared pathname.

## 20. A6D

Two independent sealed exact-successor runs returned caller exit 0 and verifier exit 0, empty verifier stderr, and canonical verifier stdout SHA-256 `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`. Nonsnapshot fields matched. Target, package, TMPDIR, and caller-evidence snapshots were equal; each run left exactly three 0600 outputs and no stage. Same-name retry rejected. The 829-object A6D input inventory and its manifest stayed unchanged. See [fresh compatibility evidence](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/sealed_compatibility_causal.json).

## 21. Amendment

Two sealed exact-successor amendment runs likewise returned caller and verifier exit 0, empty verifier stderr, canonical stdout SHA-256 `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`, equal nonsnapshot fields and snapshots, three 0600 outputs, no stage, and rejected same-name retry. The 39-object amendment input inventory and manifest stayed unchanged. Results are in the same [compatibility record](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/sealed_compatibility_causal.json).

## 22. Synthetic A6

An audit-owned fixture passed two pre-seal runs, then received only `evidence-manifest-v1.txt` and its detached SHA-256 sidecar, then passed two sealed runs. Each run used exact successor bytes, returned verifier exit 0 with empty stderr, equal snapshots, canonical accepted records, three 0600 outputs, and no stage. Repetition was deterministic within each stage; initial payload files remained unchanged. The fixture was removed after its [causal record](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/synthetic_a6_causal.json) was retained.

## 23. SEC-02

The accepted synthetic runs used source-by-value launch. The target script marker remained absent. A direct-script predecessor-shaped invocation returned exit 2 with `INVOCATION`, so it did not qualify. This does not claim atomic custody of the loaded Python interpreter.

## 24. Caller negatives

Fresh audit-owned adaptations passed 12 caller negatives, including interpreter hash/size, source and result provenance, package/target separation, snapshot uncertainty/replacement/capability, depth 13, invalid destination, and parent replacement. A separate 21-case destination suite passed occupied final/sidecar/stage, symlink, mode/owner/name/relative-path, containment, and early parent-race negatives. The independently authored containment, collision, and final-interval displacement tests add cases absent from those adapted suites. See [caller negatives](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/validation/caller-negatives-fresh.json) and [destination negatives](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/causals/destination-negatives-fresh.json).

## 25. No-write and deterministic-output evidence

Accepted A6D and amendment runs had equal opening/closing target, package, private TMPDIR, and caller-evidence snapshots; their complete input inventories were unchanged. The containment fixture’s caller-evidence inventory was unchanged on every rejection. The synthetic payload changed only through its two expected seal files. Repeated sealed stdout hashes and nonsnapshot record fields matched by family. Snapshot instrumentation found read-only opens and no watched-root write.

## 26. Authority and security adjudication

`PLANS.md` and the governing `.docs/` classify the ES-owned verifier as a **Bounded slice rule**. Its output remains evidence/projection, without product, runtime, readiness, commit, publication, or cross-service authority. The source delta did not re-derive a reopened seam or widen those boundaries. The defect is repairable source-external record custody, rather than a fundamental authority redesign.

## 27. Severity-ranked residual findings

- **P1 — blocking:** After the last parent/path validation, the held output directory can move before exclusive rename. The caller then returns success with an accepted record outside the declared destination.
- No separate collision, containment, schema, snapshot, hook, or compatibility defect was reproduced.

## 28. Minority findings and parent resolution

The contract and snapshot auditors found no blocker within their scoped reviews. The filesystem and security auditors identified the final rebind-to-rename interval; the parent’s causal reproduced it, so the overall verdict is blocking. The implementation report’s foreign-final absence concern does not survive the corrected collision contract: both independently tested foreign files remained untouched and unattributed.

## 29. Remaining uncertainty and nonclaims

The audit does not claim crash-durable directory publication, proof against transient mutation between observations, atomic loaded-interpreter custody, privileged-host attestation, shared/adversarial-host support, product correctness, or A6 readiness. The displacement causal models a concurrent filesystem move with an audit-process wrapper around the real rename; it does not claim ordinary CLI input can install that wrapper. Other possible interleavings were not exhaustively explored.

## 30. Audit-created paths and cleanup

All fixtures and retained evidence were created beneath the selected audit root. Temporary fixtures were removed; `tmp/` was empty; a process check found no surviving successor or verifier Python process. The final root contained **94 regular files and 15 directories**, with private 0600 single-link files and 0700 directories. The [final inventory](/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im/final_inventory.json) is SHA-256 `267d6df463bc09e65babd312faab1441d2516227e10241b24b38f710d6778296`, with only itself explicitly self-excluded from SHA-bearing rows. The first flawed closing-check record was retained as `closing_provenance_attempt_1.json`; the corrected closing record passed.

## 31. Explicit confirmations

Repository mutation: not performed. Supplied-evidence mutation: not performed. Repair: not performed. Git staging: not performed. Commit: not performed. Push: not performed. A6 restart: not performed. Product or live services: not invoked. Network contact: not performed. Nested subagents: not created. Four required direct auditors were created and completed.
