## Assessment

This is a clean **Repair 10I-A2 success**. The amendment stayed successor-only, changed exactly `envelope/semantic.go` and `envelope/envelope_test.go`, and left the repository, sealed Phase I-A, Phase H, and the failed Phase I-B attempt unchanged. 

More importantly, Codex did not merely add seven strings and rerun unit tests. It established the causal chain needed for the downstream restart:

- The predecessor successor reproduced exactly seven unknown historical-HEAD diagnostics.
- The amended A/B extractors produced byte-identical semantics.
- Unknowns fell from seven to zero.
- Exactly seven records moved into `go-testing-tempdir-parent-v1`; the four previously recognized records and all unrelated diagnostics were unchanged.
- Lifecycle and package/test terminal sets remained exactly equal.
- Opposite-side external qualification returned `qualified`. 

The amendment also passed full and focused count-three tests, race tests, deterministic A/B builds, and the complete successor hard gate. The four binary pairs were byte-equal but inode-distinct.  The child was then sealed with 210 payloads, and the manifest was the final mutation. 

There is no reason to reopen repository implementation or Repair 10I-A. The exact continuation is a **fresh Repair 10I-B2 child**, not reuse of the failed Phase I-B directory and not an audit of A2 in isolation. The report explicitly preserves that boundary. 

The independent audit should remain after B2 validation, product A/B, evidence sealing, and integrated capture. Implementation validation and independent audit are separate engagements; changed or newly qualifying bytes are audited later in a fresh read-only conversation. 

Pass this to the same parent Codex implementation conversation:

```text
Continue the existing Repair 10I parent implementation conversation.

Permission is workspace-write because this turn must create new private
validation/evidence and, only after successful sealing, new public transport
artifacts. Repository source is read-only in this turn.

Do not create subagents. You are the sole writer.

Return exactly one:

REPAIR10I_B2_VALIDATION_CAPTURE_READY_FOR_FRESH_AUDIT
REPAIR10I_B2_BASELINE_MISMATCH
REPAIR10I_B2_SOURCE_OR_TOOL_REPAIR_REQUIRED
REPAIR10I_B2_VALIDATION_BLOCKED
REPAIR10I_B2_CLOSEOUT_BLOCKED
REPAIR10I_B2_CAPTURE_BLOCKED

## 1. Objective

Restart Repair 10I-B from a new absent child, using:

1. the sealed Repair 10I-A repository/tool-gate lineage;
2. the sealed Repair 10I-A2 successor amendment;
3. fresh, independently materialized HEAD, Repair 9, final, mutant, and fresh
   final controls;
4. fresh product A/B preparation and byte comparison;
5. a sealed Repair 10I-B2 validation/evidence child;
6. only after that seal succeeds, one new Option-B integrated source capture and
   handoff for a later fresh independent audit.

Do not modify repository source, successor source, sealed evidence, Phase H, the
failed Phase I-B child, or any predecessor artifact.

This turn is validation, evidence production, and transport capture. It is not
an independent audit and not a commit gate.

## 2. Mandatory opening repository gate

Repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Require exactly:

branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

upstream:
absent

index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

repository T:
4dd2112078004c3d82d24a5167f16a6f25fe33ed

repository inventory:
2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0

membership:
389 total
375 tracked
14 nonignored untracked
22 tracked-modified

staged/deleted/renamed/unmerged:
0/0/0/0

Protected production file:

es/externaltls/internal/statuspackage/package.go

SHA-256:
168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6

Require the exact nine-path Repair 10I-A repository delta and no additional
changed path.

Stop with REPAIR10I_B2_BASELINE_MISMATCH on any discrepancy.

## 3. Immutable lineage gates

### 3.1 Sealed Repair 10I-A

Path:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Manifest:

size:
55676 bytes

SHA-256:
dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7

payload count:
334

sidecar file SHA-256:
5c1beb551414e711dd5135be8642ee7a5a2b1a208dd3009bd74b4e3d111ea896

### 3.2 Sealed Repair 10I-A2 successor amendment

Path:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800

Manifest:

size:
32392 bytes

SHA-256:
f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7

payload count:
210

sidecar file SHA-256:
5904fd5b990b2a0c05ea196257c498b3c8aed5178beaa775745fa1c6105f5e6d

Current successor source:

T:
e1d896e39a5e0e174fde197374361fc2bc3cb952

inventory:
a5184737d6076459b3f5914b0c163a34de097eac9b56942036e767ac0911abac

members:
12

Retained A/B binary identities:

repair10-runner:
5587490 bytes
fe425e2d5c384660a39224ce7e36567b3e8648309fd506a31fe53db20e3321a6

repair10-compare:
4597186 bytes
c7d7be9e8972a9e0067fd0dea48fe378b8aeeedbb3a3d991b95ee705f0d353d9

repair10-semantic:
4128962 bytes
69bc5169182e150e4e373ce6fc8c3c0a9c81eeb1d00be493648bc6f054837694

repair10-fixture:
7709426 bytes
d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require exactly two A2 successor source differences relative to the sealed
Repair 10I-A successor:

envelope/semantic.go
envelope/envelope_test.go

### 3.3 Phase H

Path:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Manifest SHA-256:
fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Payload count:
6191

Sidecar file SHA-256:
238f72b2f71983f632d20c99de5848b83dd377735eeac3c09fcddb2e1bc6486c

Phase H is historical evidence only. It cannot qualify an active Repair 10I
record.

### 3.4 Failed Phase I-B attempt

Path:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

Require it to remain exact, unsealed, and non-authoritative.

Its historical failed HEAD input includes:

raw size:
2759234 bytes

raw SHA-256:
43c45dc0912fe9bcdd60df78ffa39b519805e376d7ec82926bd6bbf8a02a9a5c

old semantics SHA-256:
491adc1c6dda1aa6c58408464be60d7d7623797f3ae13e88427b48165660eb90

blocked peer-record SHA-256:
87d9001d06fdd3b9fd07f43961f8bd6bbbce78cd366221eec0d55d1e7f85768c

Do not add to, remove from, seal, rename, repair, or reuse this child.

## 4. New Repair 10I-B2 child

Require this path to be absent:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

Create it exclusively under umask 077.

Use exact top-level directories:

opening
tool
commands
validation
baselines
comparisons
preparation
builds
findings
closeout

No evidence member may be hardlinked to a predecessor or another evidence
member.

Bind the sealed A2 A/B successor source and binaries as immutable tool inputs.
Do not rebuild, edit, or reseal the successor in this turn. Reverify its hard
gate and binary/source identities read-only before first control execution.

Only the Repair 10I schema generation may qualify active records. F/G/H
schemas remain parse-only historical evidence.

## 5. Fresh source controls

Create five complete, mutually inode-disjoint, no-hardlink controls with
separate source, Git administration, objects, HOME, XDG, GOPATH, GOMODCACHE,
GOCACHE, GOTMPDIR, TMPDIR, runtime, socket, and result roots.

### 5.1 Historical HEAD

Source identity:

T:
b7cab23732572c2aaea9d5f2f1593338e2e75338

Commit:
567bceced5df95ecfe787cc66038d463a854e12c

Materialize from the exact Git commit into private state. Do not execute from the
live worktree.

### 5.2 Repair 9

Use the exact retained Repair 9 transport if present:

/Users/ds/Downloads/ES-T2AP-repair9-0ea3b661f09e.zip

Expected ZIP:

size:
2200315 bytes

SHA-256:
4363b63a758c02a43945ef8b4f092df951967c295e6b428d20c7d80a00cfab6b

Expected source:

T:
0ea3b661f09e73e1126bae0f6e993e22bbf21198

Repair 10I comparison inventory identity:
7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e

members:
382

Stop rather than silently substituting another Repair 9 serialization if the
expected control cannot be reproduced.

### 5.3 Pristine final Repair 10I

T:
4dd2112078004c3d82d24a5167f16a6f25fe33ed

inventory:
2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0

members:
389

Materialize from governed live source through an opening/closing identity
bracket; execute only in the private copy.

### 5.4 Intentional final-only mutant

Construct it before execution from a distinct final copy.

The sole source delta is:

path:
es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

insert at the already frozen Repair 10I test location:
t.Fatal("intentional Repair 10I mutant")

Expected sole same-mode file transition:

before size:
268924

before SHA-256:
cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec

after size:
268966

after SHA-256:
5c5c75ba1c7ee712f006a692a07171b38775bead2dc638fc713e0d24512d9898

Expected mutant:

T:
d57e0a07b3ac60359b0b61e85a5b083255e47f07

inventory:
bdca359eb18fccc236c2f0b7bfa9f17d83be5c69d4853eebc0a2bb8675d8ea34

Retain and seal the complete intentional-mutant provenance before launching its
suite. Bind every mutant suite, qualification, and comparison record to that
provenance.

Any second source path, second diagnostic, second undeclared terminal delta, or
post-construction mutation blocks.

### 5.5 Fresh independent final

Independently rematerialize final T/inventory in a fifth disjoint control. Do
not clone or hardlink from the pristine-final control.

## 6. Full-suite execution and semantic extraction

Each control executes literally:

go test -json -count=1 -p=1 -parallel=1 ./...

Use pinned Go 1.26.5, offline private caches, stdin `/dev/null`, bounded
stdout/stderr, explicit physical cwd, and the qualified successor runner.

Exit membership may be `{0,1}`. Exit code alone does not qualify a control.

For every command retain:

- exact suite specification;
- intent;
- actual executable/argv/environment/cwd;
- sandbox or containment profile;
- raw stdout/stderr through EOF;
- exit and Wait result;
- terminal reconciliation;
- resource ledger;
- two fresh post-clean observations;
- suite result;
- producer semantics;
- opposite-successor re-extraction and qualification.

Reject malformed or truncated JSONL, duplicate/missing terminals, unfinished
starts, unexpected survivors, forced cleanup, output overflow, unknown
diagnostics, unsupported schema, source mismatch, or late custody/resource
fault.

The newly materialized HEAD run must independently demonstrate zero unknown
diagnostics. Do not use the bounded A2 historical-stream causal as the B2 HEAD
control.

If HEAD or another control reveals an additional valid diagnostic grammar,
stop with REPAIR10I_B2_SOURCE_OR_TOOL_REPAIR_REQUIRED. Do not widen matching
rules during B2.

## 7. External requalification

Every control must be independently re-extracted from its retained raw stream
by the opposite sealed A2 successor side.

Require:

- raw-derived semantics byte equality;
- exact Repair 10I schemas;
- exact control/source identity;
- terminal and resource reconciliation;
- zero unknown diagnostics;
- stable raw and semantic custody through EOF;
- correct source class:
  - historical-head
  - historical-repair9
  - pristine-final
  - intentional-mutant
  - fresh-pristine-final

Producer captions are not proof.

All five controls must independently qualify before any semantic comparison is
accepted.

## 8. Required semantic comparison matrix

Use separately retained comparison specifications and opposite-side
qualification records.

### Final ↔ fresh final

Require:

- both independently qualified;
- identical logical fingerprints;
- lifecycle equal;
- diagnostics equal;
- canonical semantics equal;
- unknown count zero;
- accepted equality true;
- outcome `qualified-equal`;
- exit 0.

Raw JSONL bytes may differ only where the frozen canonicalization contract
permits. Any unknown or lifecycle difference blocks.

### Final ↔ mutant

Require:

- both independently qualified;
- exactly the declared intentional-mutant test/package delta;
- complete diagnostic tuple and lifecycle delta exactly match provenance;
- no additional semantic change;
- unknown count zero;
- outcome `qualified-different`;
- exit 2.

### Mutant ↔ fresh final

Require the exact inverse declared mutant delta, no additional difference,
unknown count zero, and exit 2.

### HEAD ↔ final

Require both independently qualified, unknown count zero, exit 2, and no
undeclared final-only:

- failure;
- skip;
- disappearance;
- package abort;
- panic;
- race;
- warning;
- malformed stream;
- unknown diagnostic.

A declared new passing identity is the only permissible new identity.

### Repair 9 ↔ final

Apply the same independent directional rule, without unioning HEAD and Repair 9
baseline negatives.

Any failure in one historical direction is independently blocking.

## 9. Fresh product A/B preparation

After the five-control matrix passes, construct two complete independently
qualified final-candidate controls, A and B.

They must have disjoint:

- source copies;
- Git worktree/common/object state;
- HOME/XDG;
- GOPATH/module/build/temp caches;
- runtime roots and fixed-slot substitutes;
- PackageFloor/generation/slot roots;
- process groups, sockets, and evidence roots.

Use a deterministic synthetic C over exact final T. Record the recipe and
verify both sides derive the same C.

Run the active exact-candidate compiler/source oracle and deterministic
preparation/reuse/collision validation frozen by Repair 10I-A. No required test
may skip.

Require exact A/B equality for:

C
T
D
E

While both origins remain live:

- open artifact A and B through held descriptors;
- compare through EOF;
- open build-evidence A and B through held descriptors;
- compare through EOF;
- independently parse each evidence document;
- independently verify C/T/D, source inventory, compiler inputs, module inputs,
  GOROOT, tool identities, and non-authority labels;
- create independent mode-0600, single-link retained copies;
- compare origin-to-copy through EOF;
- close every descriptor;
- clean A and B independently;
- prove two fresh absence epochs.

Any alias, hardlink, containment overlap, shared mutable cache/store, byte
difference, binding difference, close uncertainty, or cleanup uncertainty
blocks.

## 10. Repair 10I-B2 evidence closeout

Retain:

- all five control source inventories and pure trees;
- exact mutant provenance installed before mutant execution;
- every suite spec, intent, raw stream, command result, terminal reconciliation,
  resource ledger, semantics, external qualification, and suite result;
- all five comparison specs/results/custody records;
- both directional baseline adjudications;
- product A/B ownership and disjointness inventories;
- live and retained artifact/evidence byte-comparison transcripts;
- C/T/D/E records and independent evidence parses;
- all failed or superseded attempts;
- literal assertion mapping;
- provenance recipe and payload inventories;
- command index;
- cleanup/absence observations;
- implementation/validation report;
- Phase I-B2 closeout adjudication.

No failed or superseded record may contribute to readiness.

Create the detached digest first.

Install `evidence-manifest-v1.txt` as the final mutation of the B2 child.

Write nothing into B2 afterward.

Run complete read-only post-seal verification.

If validation succeeds but the child cannot be sealed exactly, return
REPAIR10I_B2_CLOSEOUT_BLOCKED.

## 11. New Option-B integrated capture

Begin capture only after B2 is sealed and post-seal verified.

Require these targets to be absent:

/Users/ds/Downloads/ES-T2AP-repair10i-integrated-4dd211207800.zip

/Users/ds/Downloads/ES-T2AP-repair10i-integrated-4dd211207800-audit-handoff.md

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-4dd211207800-repair10i

If any target exists, stop with REPAIR10I_B2_CAPTURE_BLOCKED. Do not overwrite,
rename aside, reuse, or silently version it.

Place the complete capture operation behind an outer recorder that retains the
original caller’s:

- argv;
- cwd;
- bounded environment;
- stdout/stderr through EOF;
- exit;
- Wait/reap state;
- publication state;
- resource cleanup.

Use the Repair 10I Option-B byte-transport identity contract.

Acceptance-bearing ZIP identity binds:

- complete ZIP bytes, size, and SHA-256;
- exact safe member set and sole expected prefix;
- regular-file types and logical modes;
- raw ZIP headers;
- CRCs;
- absence of comments, extra fields, encryption, descriptors, traversal,
  duplicates, links, special objects, `.git`, caches, private evidence, and
  sidecars;
- two independently extracted, inode-disjoint trees;
- exact source inventory and T;
- archive regular/non-symlink type, mode 0600, link count one, and captured
  effective owner;
- same-filesystem atomic no-clobber publication from absent target;
- completed write, sync, close, and publication record;
- forward and reverse handoff bindings;
- capture manifest and detached digest.

Treat these as report-only container observations:

- device and inode as transport metadata;
- ctime and birth time;
- host-managed xattr names/value digests;
- host flags.

Do not assert historical or cross-host equality for report-only fields. Do not
intentionally add, remove, or modify xattrs.

The handoff must bind:

- final repository T/inventory/membership;
- Repair 10I-A seal;
- Repair 10I-A2 seal;
- Repair 10I-B2 seal;
- ZIP size/SHA/member count;
- Option-B policy version;
- exact validation outcomes;
- A/B C/T/D/E and compared byte counts;
- nonclaims and next fresh-audit gate.

Seal the capture child after successful publication, verification, cleanup, and
handoff creation. Manifest must be its final mutation.

On any capture failure, retain the exact failed attempt and return
REPAIR10I_B2_CAPTURE_BLOCKED. Do not overwrite or repair a published target in
the same turn.

## 12. Mandatory no-mutation and nonclaims

Do not modify:

- repository source;
- repository index, refs, objects, configuration, or upstream;
- sealed Repair 10I-A;
- sealed Repair 10I-A2;
- Phase H;
- failed Phase I-B;
- any predecessor ZIP, handoff, or evidence child.

Do not stage, commit, push, create a PR, install, invoke a live status route,
contact a remote host, execute Linux outputs, or perform T2A-I/T2B work.

Do not claim independent audit or acceptance.

## 13. Stop conditions

Return REPAIR10I_B2_BASELINE_MISMATCH on any opening or immutable-input
identity mismatch.

Return REPAIR10I_B2_SOURCE_OR_TOOL_REPAIR_REQUIRED if:

- a fresh control exposes an additional legitimate unknown grammar;
- Repair 10I source or successor bytes require correction;
- an active Repair 10I schema is inadequate;
- exact mutant provenance cannot be reconstructed;
- a required source identity cannot be reproduced.

Return REPAIR10I_B2_VALIDATION_BLOCKED if:

- any control fails independent qualification;
- final/fresh is not accepted equal with zero unknowns and exit 0;
- the mutant delta is not exact;
- either historical direction has an undeclared regression;
- product A/B C/T/D/E or bytes differ;
- any required control skips;
- any survivor, forced cleanup, resource uncertainty, output truncation,
  malformed stream, or custody failure occurs.

Return REPAIR10I_B2_CLOSEOUT_BLOCKED if validation passes but evidence
membership, final-mutation discipline, cleanup, or sealing cannot be proved.

Return REPAIR10I_B2_CAPTURE_BLOCKED for any target, publication, ZIP, extraction,
handoff, outer-recorder, Option-B, cleanup, or capture-seal failure.

Do not weaken a rule, add a grammar, normalize unknown text, union historical
baselines, or reclassify a failed record in order to continue.

## 14. Success report

On complete success report:

1. Verdict.
2. Opening repository and immutable lineage identities.
3. Repair 10I-B2 child and manifest identity.
4. Five source T/inventory identities and physical-disjointness result.
5. Full-suite command identities and raw-stream hashes.
6. Five producer and five peer qualifications.
7. Exact final/fresh accepted-equality result.
8. Exact mutant provenance and two mutant comparison results.
9. HEAD→final and Repair-9→final independent regression adjudications.
10. Product A/B C/T/D/E and compared artifact/evidence byte counts.
11. B2 failed/superseded evidence and exclusion.
12. B2 manifest size/SHA-256/payload count and sidecar identity.
13. Option-B ZIP path, size, SHA-256, member count, modes, and extraction/T
    results.
14. Handoff path, size, SHA-256, and forward/reverse binding result.
15. Capture child path and manifest identity.
16. Repository and predecessor no-mutation proof.
17. Cleanup and two absence epochs.
18. Remaining limitations and exact fresh-audit continuation point.

Required footer:

REPAIR10I_B2_VALIDATION_AND_CAPTURE_READY_FOR_FRESH_AUDIT
REPOSITORY_SOURCE_MUTATION_NOT_PERFORMED
REPAIR10I_A_MUTATION_NOT_PERFORMED
REPAIR10I_A2_MUTATION_NOT_PERFORMED
PHASE_H_MUTATION_NOT_PERFORMED
FAILED_REPAIR10I_B_ATTEMPT_MUTATION_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

### Sources

- Repair 10I-A2 sealed implementation report: exact opening lineage, two-file successor delta, hard-gate validation, historical-HEAD causal re-extraction, seal, and restart boundary.    
- Codex operating protocol: independent audit remains separate from implementation validation, and repaired bytes require a new audit.  
- Provenance guidance: precise identity establishes common bytes, not correctness or authority. 

**Confidence:** 0.99 that A2 successfully closes the reported successor-only defect; 0.97 that Repair 10I-B2 is now the correct critical-path gate; 0.94 that validation, sealing, and Option-B capture can remain one hard-gated parent-only turn without reopening repository implementation.
