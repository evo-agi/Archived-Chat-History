## Assessment

Codex stopped correctly. The blocker is in the **prescribed external validation layout**, not in B, the strategic snapshot, or the repository.

The previous repair froze:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/t
```

Those paths are siblings. Exact B requires `TMPDIR` to be physically contained by the control root, so both mandatory positive tests rejected the layout before reaching socket creation.

The report also gives us the correct resolution:

- A 57-byte short root is sufficient.
- When the control root itself is 59 bytes, the maximum governed socket path is 86 bytes.
- The long-root causal set `TMPDIR` and `ES_REPAIR10_CONTROL_ROOT` to the **same directory** and reached the intended 100-byte path-limit failure rather than the containment failure. That proves equality satisfies B’s containment rule.
- Therefore the narrowest evidence-backed repair is:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/r
```

Not `r/t`, and not sibling `r` and `t`. Using the same private transient directory preserves the historical producer semantics while avoiding mutation of the supplied strategic-snapshot root.

This is another source-external custody correction. It requires:

1. no repository or B-source change;
2. a versioned validation-custody contract, because the blocked v1 contract must not be silently redefined;
3. a versioned validation plan superseding both the original plan and the unusable sibling-root proposal;
4. all eight validation commands rerun;
5. a fresh independent audit of the combined strategic snapshot and corrected custody capsule.

Do not proceed to the H→B commit gate yet.

## Prompt for Codex

```text
REPAIR 10I T2A-P STRATEGIC B VALIDATION-CUSTODY V2 IMPLEMENTATION

Implement the corrected source-external validation-custody contract for the
Repair 10I T2A-P strategic B snapshot.

Do not create subagents.

This task does not modify the candidate repository, the strategic B snapshot,
the blocking independent audit, the blocked v1 custody-repair capsule, or any
other supplied input. It does not stage, commit, publish, install, deploy, or
begin A6.

Return exactly one primary verdict:

REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_V2_READY_FOR_FRESH_AUDIT
REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_V2_BLOCKED
VALIDATION_CUSTODY_V2_PROVENANCE_MISMATCH

OBJECTIVE

Replace the blocked sibling-root custody design with a versioned,
independently replayable contract in which:

- `ES_REPAIR10_CONTROL_ROOT` and `TMPDIR` are the same exact short physical
  directory;
- every acceptance-bearing socket path is bounded to at most 100 bytes;
- no supplied evidence root is used for mutable or generated state;
- all eight original validation commands and all expected identity-level
  outcomes remain unchanged;
- exact B source, logical modes, source T, inventory, Git tree, synthetic
  commit, H→B classification, and source provenance remain unchanged.

This is a repair of validation custody and observed validation only. It is not
new B source authority.

──────────────────────────────────────────────────────────────────────────────
1. IMMUTABLE INPUTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed files:
  389
- tracked/untracked:
  375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- current F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- current F inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Required strategic B identities:

- source T / Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- inventory size:
  54314
- governed files:
  389
- H→B:
  22 modified, 14 added, 0 deleted, 0 renamed
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1
- synthetic parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- synthetic subject:
  implement Remote Alpha external TLS T2A-P source

Required snapshot closeout identities:

- closeout/final-evidence-inventory.json
  size:
  130182
  SHA-256:
  fb30338e1a0fc39359b3517d6f70303ea086689330074b9f1f35854a431a73bb

- closeout/final-report.md
  size:
  151150
  SHA-256:
  2a853c551635c223eec38eb229535285541a653dfa5f1ce59855fd5b2082b2fe

- manifest/canonical-manifest-a-v1.json
- manifest/canonical-manifest-b-v1.json
  size:
  139328 each
  SHA-256:
  df5933f201437dc9ac55f22f72aac4bdde8477a203b7ca22358ab11e77f5c9fc
  required:
  byte-identical

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-independent-audit-qtbsxpc9

Required records:

- retained/final-audit-report.md
  size:
  34460
  SHA-256:
  b7e959a5785af954c6be556da594b39fc3c2da37e8d1b09dd775ddcae623ea65

- retained/final-audit-root-inventory.json
  size:
  25624
  SHA-256:
  d514e99ce2833bdf6bb36dc5e3b9ced3b9eb52651425f9d6057c13e5fb4a8475

Required verdict:

BLOCK

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

Required identities:

- device/inode:
  16777234 / 178515489
- final inventory:
  closeout/final-evidence-inventory-v1.json
  size:
  16030
  SHA-256:
  42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0
- canonical manifests:
  manifest/canonical-manifest-a-v1.json
  manifest/canonical-manifest-b-v1.json
  size:
  17363 each
  SHA-256:
  73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498
  required:
  byte-identical
- verdict:
  REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_REPAIR_BLOCKED

Required consumed v1 defect:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/t
```

The sibling relationship violates exact B’s containment predicate and caused:

- `TestRepair10ControlRootPolicyV1`:
  `is outside control root`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`:
  `is outside control root`

The v1 repair root remains immutable historical evidence. Do not alter it or
present it as an effective supersession.

Use other provenance roots only through exact paths referenced by these inputs.
Do not broadly scan unrelated Downloads content or repository siblings.

──────────────────────────────────────────────────────────────────────────────
2. EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read CANDIDATE_R and named supplied roots;
- allocate one fresh retained v2 correction root beneath
  `/Users/ds/Downloads`;
- allocate one separate short transient execution root beneath
  `/Users/ds/Downloads`;
- create private exact-B materializations, Git state, caches, homes, temp
  directories, fixtures, validation records, and reports;
- execute the complete recovered eight-command validation plan offline;
- remove only task-owned transient state.

Forbidden:

- candidate repository edits or index mutation;
- mutation of STRATEGIC_B_ROOT, BLOCKING_AUDIT_ROOT, or
  BLOCKED_V1_REPAIR_ROOT;
- mutation of any other supplied root;
- staging or committing in the candidate;
- restore, reset, amend, rebase, stash, merge, checkout, or clean in the
  candidate;
- changing B source bytes, tests, logical modes, source T, inventory, Git tree,
  synthetic commit, or H→B classification;
- weakening the containment or 100-byte policies;
- omitting or reclassifying a validation command or expected test identity;
- symlink, bind-mount, mount, alias, or rename workaround;
- using a supplied root as generated-state custody;
- product/live-service invocation;
- installation or deployment;
- network contact;
- A6 work;
- subagents.

Every candidate Git read must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd exactly equal to CANDIDATE_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

──────────────────────────────────────────────────────────────────────────────
3. FRESH RETAINED V2 CORRECTION ROOT
──────────────────────────────────────────────────────────────────────────────

Under umask 077, allocate one unpredictable retained root beneath
`/Users/ds/Downloads` using `tempfile.mkdtemp` with prefix:

ES-repair10i-t2ap-strategic-b-validation-custody-v2-

Retained directories:

- direct physical directories;
- mode 0700.

Retained files:

- regular;
- single-link;
- mode 0600.

Recommended retained structure:

opening/
contract/
causals/
validation/
provenance/
manifest/
closeout/

Do not retain unexplained empty directories.

All supplied roots remain immutable.

──────────────────────────────────────────────────────────────────────────────
4. VALIDATION-CUSTODY V2 CONTRACT
──────────────────────────────────────────────────────────────────────────────

Contract ID:

execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v2

Physical short-root parent:

/Users/ds/Downloads

Short-root basename:

r10b-<32-lowercase-hex>

Suffix:

- exactly 16 operating-system CSPRNG bytes;
- lowercase hexadecimal encoding;
- fresh material for every attempt.

Allocation:

1. Set umask 0077.
2. Open `/Users/ds/Downloads` component by component without following links.
3. Hold the physical parent descriptor and identity.
4. Generate 16 CSPRNG bytes and encode exactly 32 lowercase hexadecimal
   characters.
5. Create the child descriptor-relatively and exclusively at mode 0700.
6. Retry only on EEXIST.
7. Use fresh CSPRNG material for every retry.
8. Permit at most 128 attempts.
9. Treat every non-EEXIST error as terminal with no fallback.
10. Open and hold the created child descriptor.
11. Require:
    - direct parentage;
    - invoking-UID ownership;
    - expected parent GID;
    - mode 0700;
    - stable device/inode;
    - no symlink component;
    - no alias or containment with candidate or supplied roots.
12. Require the absolute UTF-8 short-root path to be exactly 57 bytes on this
    frozen supported-local parent and naming contract.
13. Do not scan for latest, adopt an existing entry, rename a path into
    eligibility, or use PID, counter, timestamp, or Git hash authority.

Create these physical directories:

- `${SHORT_ROOT}/s` — exact B validation source and private Git state
- `${SHORT_ROOT}/h` — HOME
- `${SHORT_ROOT}/u` — GOTMPDIR
- `${SHORT_ROOT}/c` — GOCACHE
- `${SHORT_ROOT}/m` — GOMODCACHE
- `${SHORT_ROOT}/r` — shared control-root and TMPDIR custody

All are direct children of SHORT_ROOT, mode 0700.

Do not create `${SHORT_ROOT}/t`.

Exact environment bindings:

```text
ES_REPAIR10_SOURCE_ROOT=${SHORT_ROOT}/s
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/r
HOME=${SHORT_ROOT}/h
GOTMPDIR=${SHORT_ROOT}/u
GOCACHE=${SHORT_ROOT}/c
GOMODCACHE=${SHORT_ROOT}/m
```

Required relationship:

```text
TMPDIR lexical path == ES_REPAIR10_CONTROL_ROOT lexical path
TMPDIR device/inode == ES_REPAIR10_CONTROL_ROOT device/inode
```

The shared directory is private transient validation state. It is not B source,
retained evidence, or current repository authority.

──────────────────────────────────────────────────────────────────────────────
5. SOURCE-DERIVED PATH-BUDGET PROOF
──────────────────────────────────────────────────────────────────────────────

Inspect the exact B sources governing:

- `TestRepair10ControlRootPolicyV1`;
- `AllocateControlDir`;
- `AllocateShortDir`;
- `PhysicalTMPDir`;
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`;
- every helper constructing the relevant generated directory or socket leaf;
- pinned Go `os/tempfile.go`.

Produce a canonical path-budget record containing:

- policy limit:
  100 bytes;
- short root:
  exactly 57 bytes;
- shared control/TMP root:
  exactly 59 bytes;
- generated component grammar and exact maximum:
  12 bytes;
- socket leaf:
  `identity.sock`, 13 bytes;
- separators:
  2 bytes;
- maximum complete path:
  `59 + 1 + 12 + 1 + 13 = 86 bytes`;
- proof:
  `86 <= 100`;
- exact lexical-equality and physical-identity relationship for control/TMP;
- proof that equality satisfies exact B’s containment predicate.

Do not treat one observed random generated component as the maximum proof.

──────────────────────────────────────────────────────────────────────────────
6. REQUIRED CAUSAL MATRIX
──────────────────────────────────────────────────────────────────────────────

All causals use private exact-B materializations and task-owned roots only.

A. Long shared-root negative

Set:

```text
ES_REPAIR10_CONTROL_ROOT=<LONG_PRIVATE_ROOT>
TMPDIR=<LONG_PRIVATE_ROOT>
```

Choose a direct physical audit-owned root whose exact source-derived maximum
socket path exceeds 100 bytes.

Require reproduction of:

- `TestRepair10ControlRootPolicyV1` failing for the 100-byte limit;
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` failing at or before
  Unix-socket bind for the overlong path;
- no outside-control-root error.

B. Blocked v1 sibling-layout negative

Set:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/t
```

Require reproduction of:

- both mandatory identities failing because TMPDIR is outside the control root;
- no path-length failure;
- exact classification as the blocked v1 mechanism.

C. Corrected v2 shared-root positive

Set:

```text
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
TMPDIR=${SHORT_ROOT}/r
```

Require:

- `TestRepair10ControlRootPolicyV1` passes;
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` passes;
- no skip;
- no socket path above 100 bytes;
- no B source/tree mutation;
- no supplied-root write;
- clean generated-state disposition.

D. Boundary causal

Using a separate audit-owned private B copy and the narrowest audit-only
same-package test harness necessary:

- exercise the exact length predicate at 100 bytes;
- exercise it at 101 bytes;
- require 100 to be admitted if exact source uses `<= 100`;
- require 101 to reject before unsafe socket launch or bind;
- retain the audit-only harness source and identity;
- do not modify the primary B validation source;
- do not count the harness as product or B validation.

If exact source uses a stricter boundary, preserve and report the exact source
behavior rather than forcing an assumed result.

Stop if the corrected shared-root positive does not pass.

──────────────────────────────────────────────────────────────────────────────
7. VALIDATION PLAN V3
──────────────────────────────────────────────────────────────────────────────

Create:

contract/validation-plan-v3.json

It must bind:

- the original strategic snapshot validation plan;
- blocked v1 custody repair and blocked proposed v2 plan;
- exact B source/tree/synthetic-commit identities;
- validation-custody contract v2.

It must preserve unchanged:

- all eight command IDs;
- command order;
- argv except environment-resolved private paths;
- pinned tools;
- expected exits;
- exact pass/fail/skip identity policies;
- governing rationale;
- B source tree;
- synthetic commit/tree identities.

It must replace only generated-state custody with the v2 shared-root bindings.

It must contain placeholders or typed parameters for a future independently
allocated conforming `r10b-<32hex>` root. It must not pin the producer’s random
root as future authority.

Create a supersession record with this exact lineage:

```text
base strategic-snapshot validation plan:
  historical source plan

blocked custody v1 / proposed plan v2:
  historical, non-effective, unusable because TMPDIR and control root are siblings

validation-custody v2 / validation plan v3:
  proposed effective correction pending fresh independent audit
```

The supersession record must explicitly state that B source, B origin,
inventory, logical modes, Git tree, synthetic commit, H→B classification, and
authority/non-authority claims are unchanged.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE EIGHT-COMMAND REVALIDATION
──────────────────────────────────────────────────────────────────────────────

Construct a fresh exact-B validation tree beneath `${SHORT_ROOT}/s`.

Require before running:

- 389 governed files;
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e;
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2;
- Git tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e;
- synthetic commit:
  e42aac659299e023df07a842df17e9fc84a135c1;
- clean private Git state;
- no alias with candidate or supplied roots.

Pinned Go:

/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go

Expected identity:

- version:
  go version go1.26.5 darwin/arm64
- SHA-256:
  3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19

Common environment:

```text
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
HOME=${SHORT_ROOT}/h
TMPDIR=${SHORT_ROOT}/r
GOTMPDIR=${SHORT_ROOT}/u
GOCACHE=${SHORT_ROOT}/c
GOMODCACHE=${SHORT_ROOT}/m
ES_REPAIR10_SOURCE_ROOT=${SHORT_ROOT}/s
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
GOROOT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64
GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

All commands use cwd `${SHORT_ROOT}/s`.

Seed only already-present pinned module-cache objects. Do not use network or
install anything.

Execute the complete original eight-command plan:

1. `go-version`
2. `complete-docs-105`
3. `testsupport-acceptance`
4. `external-tls-all`
5. `repair10-current-affected-pass`
6. `changed-nonroot-product-tests`
7. `bash-syntax`
8. `private-git-diff-check`

Use the exact argv retained by the base strategic-snapshot validation plan,
except for the parameterized physical root substitutions required by v2.

Required identity-level outcomes:

A. `complete-docs-105`

- exactly 105 identities;
- 105 pass;
- zero skip, fail, error, or panic.

B. `testsupport-acceptance`

- PASS `TestRepair10ControlRootPolicyV1`
- PASS `TestRepair10OwnedProcessLifecycleV1`
- PASS `TestRepair10SignalBirthMismatchNeverSignalsV1`
- raw exit 0.

C. `external-tls-all`

Exactly one allowed failure:

- `execution-substrate/es/externaltls/internal/statuspackage::TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2`

Required failure mechanism:

- `lifetime_lock_identity_invalid`

Exactly four allowed skips:

- `TestPrivateExactCandidateCompilerInputOracleAndOmissionsV2`
- `TestPrivateExactCandidateDeterministicPreparationAndReuseV2`
- `TestRepair10ECombinedErrorExactCloseCardinalityV2`
- `TestRepair10PublishedStageCombinedErrorRealPreparationV2`

Require zero additional fail, skip, error, panic, or malformed event.

D. `repair10-current-affected-pass`

- exact retained 20 identities;
- 20 pass;
- no fail or skip.

E. `changed-nonroot-product-tests`

Required passes:

- `TestExecutionWorkspaceTempDirUsesControlRoot`
- `TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir`
- `TestNomadHarnessProcessCustodianWithoutServiceV1`
- `TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention`
- `TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess`
- `TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath`
- `TestValidateExecutionRuntimeInputsRejectsNonRegularBinary`
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`

Required governed skip:

- `TestNomadHarnessProcessCustodianFixtureV1`
  exact reason:
  `private custodian fixture only`

Require eight passes, one governed skip, zero failure/error/panic.

F. `bash-syntax`

- exit 0;
- empty stdout and stderr.

G. `private-git-diff-check`

- exit 0;
- empty stdout and stderr.

For every command retain:

- exact argv;
- cwd;
- explicit environment;
- allocation and path-budget references;
- exit/signal;
- complete stdout/stderr;
- sizes and SHA-256 values;
- exact pass/fail/skip/error identities;
- before/after B source T, inventory, and Git tree;
- generated-state inventory.

Require exact B identities and clean private Git state after each owning command.

Retain failed or superseded producer attempts separately and exclude them from
qualification.

──────────────────────────────────────────────────────────────────────────────
9. V2 CORRECTION CAPSULE CONTENT
──────────────────────────────────────────────────────────────────────────────

Retain at minimum:

opening/
  candidate-and-supplied-root-identities.json
  strategic-snapshot-binding.json
  blocking-audit-binding.json
  blocked-v1-repair-binding.json

contract/
  strategic-b-validation-custody-v2.json
  validation-plan-v3.json
  validation-plan-supersession-v2.json
  path-budget-v2.json

causals/
  long-shared-root-expected-negative.json
  blocked-v1-sibling-root-negative.json
  corrected-v2-shared-root-positive.json
  path-budget-boundary.json

validation/
  exact eight command records
  complete raw stdout/stderr captures
  identity-level-result-summary-v3.json
  validation-summary-v3.json
  failed-and-superseded-attempt-index-v1.json

provenance/
  allocator source
  path-budget checker source
  boundary harness source
  exact-B materializer source
  validation runner source
  cleanup source
  source inventories and hashes

closeout/
  cleanup-v1.json
  absence-observation-1-v1.json
  absence-observation-2-v1.json
  closing-equality-v1.json
  final-implementation-report-v1.md
  final-evidence-inventory-v1.json

manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json

Do not copy all 389 B files into the retained v2 capsule as a competing source
authority. The transient B materialization is removed at closeout. The v2
capsule binds STRATEGIC_B_ROOT and supersedes only validation custody, plan, and
results.

──────────────────────────────────────────────────────────────────────────────
10. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

The v2 capsule may claim only:

- short-root allocation semantics;
- exact control/TMP shared-directory relationship;
- source-derived socket path budget;
- validation-plan v3 environment/custody;
- fresh observed validation results;
- narrow supersession of the blocked custody plans and producer validation
  results.

It may not claim:

- new B source, mode, origin, inventory, or tree authority;
- publication or commit authority;
- current repository truth for B;
- product/runtime/deployment readiness;
- A6 readiness;
- semantic-successor implementation;
- orchestrator implementation;
- hostile/shared-host support;
- symlink or mount authority.

STRATEGIC_B_ROOT remains the sole B source/provenance package.

──────────────────────────────────────────────────────────────────────────────
11. CLEANUP AND CLOSING GATE
──────────────────────────────────────────────────────────────────────────────

After validation:

1. Stop and reap every task-owned process.
2. Verify no socket, process, or descriptor survivor.
3. Remove only the task-owned short root and all descendants.
4. Do not chmod any supplied or retained object to enable removal.
5. Make two fresh `lstat` observations returning ENOENT.
6. Verify no task-owned `r10b-*` sibling remains.
7. Recompute candidate opening/closing equality.
8. Recompute STRATEGIC_B_ROOT, BLOCKING_AUDIT_ROOT, and
   BLOCKED_V1_REPAIR_ROOT equality.
9. Recompute every other supplied-root identity actually used.
10. Verify no supplied-root mutation.
11. Verify v2 correction-root closure.
12. Generate two canonical manifests independently.
13. Require:
    - byte-identical manifests;
    - every retained directory represented;
    - every retained nonmanifest file represented once;
    - only the two manifests self-excluded;
    - no empty, unexplained, symlink, special, or multiply linked object;
    - every directory mode 0700;
    - every file regular, single-link, mode 0600.
14. Retain a complete final report and evidence inventory.

Return VALIDATION_CUSTODY_V2_PROVENANCE_MISMATCH on opening/closing drift.

──────────────────────────────────────────────────────────────────────────────
12. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Stop immediately on:

- candidate or supplied-root drift;
- B source/tree/inventory mismatch;
- mutation of any supplied root;
- inability to prove the shared-root relationship from exact B source;
- worst-case socket path above 100 bytes;
- corrected shared-root positive causal failure;
- changed command IDs, order, argv semantics, or expected identities;
- any unexpected fail, skip, error, panic, or malformed event;
- incomplete streams;
- B source/tree mutation;
- network or installation attempt;
- short-root cleanup failure;
- surviving process, descriptor, or socket;
- incomplete capsule closure;
- authority widening.

Do not repair B source or tests.

──────────────────────────────────────────────────────────────────────────────
13. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the complete report inline. Do not rely on a linked report for required
content.

Include:

1. Primary verdict
2. Opening candidate and supplied-root identities
3. V2 correction-root identity
4. Blocking v1 findings consumed
5. Exact v2 validation-custody contract
6. Short-root allocation and identities
7. Shared control/TMP identity proof
8. Source-derived 86-byte worst-case proof
9. Long shared-root negative
10. Blocked v1 sibling-root negative
11. Corrected v2 shared-root positive
12. 100/101 boundary causal
13. Validation-plan v1/v2/v3 lineage
14. Proof B source/tree identities remained unchanged
15. Exact eight commands, environments, and outcomes
16. Exact pass/fail/skip adjudication
17. Failed/superseded attempts
18. V2 capsule authority and nonauthority
19. Artifact and sensitive-material findings
20. Cleanup and two ENOENT observations
21. Candidate and supplied-root closing equality
22. Complete retained membership and manifest identities
23. Remaining uncertainty
24. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
CONTROL_ROOT_AND_TMPDIR_SHARED_EXACT_PHYSICAL_DIRECTORY
SHORT_TRANSIENT_ROOT_ALLOCATED
SHORT_TRANSIENT_ROOT_REMOVED
TWO_ABSENCE_OBSERVATIONS_COMPLETED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
SUBAGENTS_CREATED: 0
```

After a successful producer pass, run a fresh independent audit of the combined
target:

- immutable strategic B snapshot; and
- validation-custody v2 correction capsule.

Only an `ACCEPT` should unlock the real H→B commit gate.

### Source

:chatgpt-content-reference{index="0"}

**Confidence:** 0.998 that the sibling-root layout was the sole immediate defect; 0.99 that sharing `${SHORT_ROOT}/r` between `TMPDIR` and `ES_REPAIR10_CONTROL_ROOT` is the narrowest evidence-backed repair; 0.98 that no repository or strategic-snapshot source change is required.
