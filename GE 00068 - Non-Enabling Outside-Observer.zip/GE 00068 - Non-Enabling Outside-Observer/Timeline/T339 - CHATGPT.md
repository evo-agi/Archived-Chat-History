## Assessment

This attempt says nothing about package quality. It failed solely because the audit controller used a **persistent interactive input loop**, remained idle, and received an uncaught `KeyboardInterrupt`.

The opening work is nonqualifying, and none of the A/C/H/I repair was examined. The failed root must remain immutable:

`/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-dyumfk2_`

This does **not** justify:

- another implementation tranche;
- another findings reconciliation;
- changing the successor package;
- weakening the independent-audit criteria;
- reusing any partial opening observations.

The next audit should preserve the single-parent authority model while replacing the interactive supervisor with a **finite, noninteractive, one-shot parent**. The full audit plan must be frozen before inspection and executed sequentially without reading stdin or waiting for further Codex instructions. Long-running children should be polled with periodic report-only heartbeats so the carrier is never idle.

## Prompt for Codex

```text
FRESH ONE-SHOT PARENT-OWNED INDEPENDENT AUDIT RETRY —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP A/C/H/I REPAIR SUCCESSOR

Repeat the immediately preceding complete independent-audit brief from the
beginning.

The exact audit target, predecessor, blocking-audit root, optional roots,
fixed identities, substantive A/C/H/I requirements, Finding J regression,
causal matrices, materializations, handoffs, security checks, verdict rules,
required inline report, and confirmation registry remain unchanged except
where this prompt explicitly replaces the parent-process execution model.

This is the audit. Do not create or qualify another process package, wrapper
package, supervisor package, importer package, or capability probe.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected root identity:

- device/inode:
  16777234 / 179405897
- mode:
  0700
- producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_A_C_H_I_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected temporal final inventory:

closeout/temporal-final-inventory-a-c-h-i-v1.json

- size:
  313198
- SHA-256:
  7e3f7103e057a251a674c18508c043b7b7257bf3cfe1d7f7c2e39fa5f4213f81

Expected manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

Expected closure:

- 1207 represented entries;
- 334 directories including root;
- 873 represented nonmanifest regular files;
- 875 physical regular files including manifests;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- zero writes after final manifest closure.

──────────────────────────────────────────────────────────────────────────────
2. IMMUTABLE FAILED ATTEMPT
──────────────────────────────────────────────────────────────────────────────

FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-dyumfk2_

Treat this root as immutable, nonqualifying process-failure evidence.

The sole adopted fact is:

- the previous parent waited at an interactive input loop;
- it received an uncaught `KeyboardInterrupt`;
- substantive package inspection did not begin.

Do not:

- resume it;
- repair it;
- clean it;
- copy partial opening results from it;
- use its attempted identities as qualification evidence;
- inspect it as a supplied target unless needed only to bind the historical
  process-failure disposition.

Do not classify the interruption as a package defect.

──────────────────────────────────────────────────────────────────────────────
3. AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Read the complete prompt before invoking a tool.

Then emit exactly:

AUDIT_EPOCH_START

Use:

top_level_launch_authority = "codex-platform-tool-transcript"

and:

audit_root_does_not_self_attest_parent_process_creation = true

──────────────────────────────────────────────────────────────────────────────
4. REPLACEMENT PROCESS MODEL — FINITE ONE-SHOT PARENT
──────────────────────────────────────────────────────────────────────────────

Use exactly one finite, noninteractive parent audit process.

The parent must execute the complete audit from bootstrap through terminal
sealing in one invocation.

Forbidden:

- `input()`;
- `sys.stdin.readline()`;
- reading from stdin after launch;
- an interactive command loop;
- a persistent supervisor awaiting later commands;
- a shell session awaiting input;
- a socket-based command channel;
- externally injected phase commands;
- a later administrative continuation;
- a replacement parent after failure;
- a resume operation against a failed audit root.

The parent must not become intentionally idle while awaiting instructions.

The complete phase plan must be frozen before supplied-root inspection and
retained as:

opening/frozen-audit-plan.json

The plan must contain the complete ordered phase set, including:

1. bootstrap;
2. child-recorder causals;
3. opening provenance;
4. package delta and repair authority;
5. Finding A analysis and causals;
6. Finding C analysis and causals;
7. Finding H publication analysis and causals;
8. Finding I case and full producer classification;
9. Finding J regression;
10. contract/schema/source/record analysis;
11. fresh independent validator;
12. two materializations;
13. two Carrier 0002 handoffs;
14. production export/security analysis;
15. four parent-owned perspectives;
16. closing equality;
17. cleanup;
18. final report;
19. temporal inventory;
20. terminal manifests;
21. terminal exit.

The parent may not add, remove, reorder, or redefine substantive phases after
supplied-root inspection begins.

──────────────────────────────────────────────────────────────────────────────
5. NO-IDLE EXECUTION
──────────────────────────────────────────────────────────────────────────────

The top-level audit process must remain observably active.

While an external child is running, the parent must poll rather than block
indefinitely.

At least once every 10 seconds while waiting for a child, emit one report-only
stdout line in this exact general form:

AUDIT_HEARTBEAT phase=<phase-id> child=<ordinal-or-none> elapsed_ms=<integer>

Heartbeat output:

- is not acceptance evidence;
- is not retained as a target artifact;
- must not expose sensitive content;
- must not affect child stdout/stderr capture;
- must not be parsed as a package result.

Every child must have a bounded timeout derived from the frozen audit plan.

On timeout:

- terminate through the recorder’s bounded policy;
- retain complete timeout evidence;
- classify the relevant causal or validation result;
- continue only when the substantive audit contract permits continuing after
  that failed case.

Do not wait indefinitely.

Launch the one-shot parent with the maximum available noninteractive platform
timeout. Do not issue a tool-side cancellation while it is making progress.

──────────────────────────────────────────────────────────────────────────────
6. TOP-LEVEL EXCEPTION HANDLING
──────────────────────────────────────────────────────────────────────────────

The parent must wrap the complete audit body in one top-level handler covering:

- `KeyboardInterrupt`;
- `SystemExit`;
- ordinary `Exception`;
- other catchable `BaseException` subclasses.

Before supplied-root inspection, retain:

opening/bootstrap-start.json
provenance/parent-source.py
provenance/parent-process-start.json
opening/frozen-audit-plan.json

For a catchable failure before terminal sealing, retain and fsync:

closeout/parent-process-failure.json
closeout/parent-process-outcome.json
closeout/failure-report.md

The failure records must include:

- phase;
- operation;
- exception type;
- exception message;
- complete traceback path, size, and SHA-256;
- current phase ordinal;
- current child ordinal, when any;
- supplied roots opened;
- supplied roots mutated;
- artifacts created;
- package findings completed;
- cleanup completed;
- next-action authorization;
- process exit disposition.

A caught `KeyboardInterrupt` is still an audit-process failure and requires
`AUDIT_PROVENANCE_MISMATCH`, but it must not escape unrecorded.

Do not continue package adjudication after a parent interruption.

No administrative continuation may finalize the root.

──────────────────────────────────────────────────────────────────────────────
7. SUCCESSFUL PARENT COMPLETION
──────────────────────────────────────────────────────────────────────────────

On the successful path, the parent must not write a post-seal filesystem
outcome record.

Use this authority split:

- audit-root records are authoritative for all work through final sealing;
- the Codex platform transcript is authoritative for the final top-level
  process exit after sealing.

Before terminal manifests, retain:

closeout/parent-process-preseal-outcome.json

It must state:

- every substantive phase completed;
- all child records complete;
- closing equality complete;
- cleanup complete;
- final report finalized;
- temporal inventory ready;
- terminal sealing is the only remaining operation;
- intended terminal exit:
  0.

Then:

1. create terminal manifest A;
2. create terminal manifest B;
3. independently reproduce both manifests in memory;
4. require byte equality and exact closure;
5. perform no later filesystem write;
6. emit one terminal stdout line:
   `AUDIT_TERMINAL_SEAL_COMPLETE`;
7. exit 0.

The transcript-authoritative final exit is sufficient. Do not create a
postmanifest outcome file.

──────────────────────────────────────────────────────────────────────────────
8. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-

Retain and emit the exact root path before supplied-root inspection.

Do not reuse or scan for a prior root.

Do not adopt an existing prefix match.

──────────────────────────────────────────────────────────────────────────────
9. CHILD-PROCESS RECORDER
──────────────────────────────────────────────────────────────────────────────

Every external child launched by the one-shot parent must use one
contemporaneous recorder.

For each child retain:

- contiguous ordinal;
- start record durably written before spawn;
- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- timeout posture;
- reaping;
- descriptor closure;
- paths written;
- purpose;
- qualifying or failed/superseded disposition.

Run the recorder self-causals before opening supplied roots:

1. missing executable:
   `FileNotFoundError` / `ENOENT`;
2. `/usr/bin/true`:
   exit 0;
3. empty streams;
4. complete quartet;
5. reaping;
6. descriptor closure.

A child-record gap requires:

AUDIT_PROVENANCE_MISMATCH

Pure in-process parsing, hashing, and lstat/no-follow inspection do not require
fictional child records.

──────────────────────────────────────────────────────────────────────────────
10. NO DIRECT AUDITORS OR SUBAGENTS
──────────────────────────────────────────────────────────────────────────────

Do not create direct auditors.
Do not create subagents.

Retain four parent-generated analytical perspectives:

analysis/perspective-contract-authority.json
analysis/perspective-runtime-causals.json
analysis/perspective-validation-lineage.json
analysis/perspective-filesystem-security.json

Each must contain:

- exact operands;
- findings;
- limits;
- uncertainty;
- uninspected scope.

These are analytical projections, not independent authorities.

──────────────────────────────────────────────────────────────────────────────
11. SUBSTANTIVE AUDIT SCOPE
──────────────────────────────────────────────────────────────────────────────

After the opening gate passes, execute every substantive section of the
immediately preceding complete independent-audit brief without omission or
semantic change.

This includes:

- exact predecessor-to-successor delta;
- exact six-path semantic scope;
- unchanged Finding J-owned schemas;
- repair-authority adjudication;
- Finding A static and dynamic audit;
- Finding C static and dynamic custody audit;
- Finding H publication state machine;
- Darwin `renameatx_np(..., RENAME_EXCL)` binding;
- final success-commit field map;
- fresh independent publication matrix;
- precommit/postcommit/retry semantics;
- replay-evidence closure;
- fault-hook reachability;
- Finding I real wrapper case;
- complete producer 50-case mechanism classification;
- Finding J 928-case regression;
- complete contract/schema/source/record consistency;
- fresh independent validator;
- two fresh materializations;
- two fresh Carrier 0002 handoffs;
- export/security/authority review;
- failed/superseded-attempt adjudication;
- four parent perspectives;
- supplied-root closing equality;
- fixture cleanup and double-ENOENT observations;
- final audit capsule.

Do not narrow the causal sets or acceptance rules.

Do not inherit the producer’s matrices as the audit oracle.

──────────────────────────────────────────────────────────────────────────────
12. FIXED SUPPLIED ROOTS
──────────────────────────────────────────────────────────────────────────────

The fixed roots and identities remain exactly those in the immediately
preceding complete audit brief:

SUCCESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

PREDECESSOR_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

Optional roots when required:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Use all expected sizes, SHA-256 values, manifest identities, closure counts,
semantic identities, and verdict bindings from the immediately preceding
complete audit brief unchanged.

──────────────────────────────────────────────────────────────────────────────
13. FAILED ROOT NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Do not use the incomplete `dyumfk2_` root for:

- successor identities;
- opening identities;
- package delta;
- package findings;
- causals;
- validation;
- closing equality;
- acceptance.

Its partial records do not qualify any fact about the successor.

Retain one historical disposition record in the fresh audit root:

opening/prior-failed-audit-disposition.json

The record must state:

- prior root path;
- prior primary verdict:
  AUDIT_PROVENANCE_MISMATCH;
- sole adopted cause:
  uncaught `KeyboardInterrupt` while idle at an input loop;
- target findings reached:
  false;
- reusable target evidence:
  none;
- prior root opened during this audit:
  false.

Do not otherwise inspect it.

──────────────────────────────────────────────────────────────────────────────
14. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Use the exact verdict rules from the immediately preceding complete audit
brief.

Return ACCEPT only if every provenance, A, C, H, I, J, materialization,
handoff, export, security, equality, cleanup, and capsule gate passes with no
acceptance-affecting residual finding.

Return BLOCK for any repairable implementation, contract/schema,
validation/evidence, causal, replay, retry, publication, copy-custody,
interpreter, producer-lineage, or authority defect.

Return REJECT only for fundamental unsoundness outside a bounded repair.

Return AUDIT_PROVENANCE_MISMATCH for:

- supplied-root drift or mutation;
- missing fixed input;
- child-process record gap;
- uncaught or caught parent interruption before completion;
- closing inequality;
- terminal capsule failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
15. FINALIZATION
──────────────────────────────────────────────────────────────────────────────

Create directories lazily.

Do not create `manifest/` until every other retained artifact is final.

The no-empty-directory rule applies to terminal retained state.

Finalize in this order:

1. opening records;
2. frozen audit plan;
3. package identities and delta;
4. A evidence;
5. C evidence;
6. H evidence;
7. I evidence;
8. J evidence;
9. contract/schema/source/record maps;
10. independent validator;
11. materializations;
12. handoffs;
13. attempt adjudication;
14. four parent perspectives;
15. export/security analysis;
16. child-process ledger;
17. closing equality;
18. cleanup and ENOENT records;
19. final report;
20. parent preseal outcome;
21. temporal final inventory;
22. create `manifest/`;
23. manifest A;
24. manifest B;
25. in-memory independent reproduction;
26. terminal stdout line;
27. process exit.

No filesystem write after step 24.

──────────────────────────────────────────────────────────────────────────────
16. ADDITIONAL REQUIRED INLINE REPORT SECTIONS
──────────────────────────────────────────────────────────────────────────────

Return every section required by the immediately preceding complete audit
brief.

Additionally report:

1. Prior failed-root disposition.
2. Confirmation that the new parent was finite and noninteractive.
3. Frozen audit-plan identity.
4. Confirmation that stdin was never read after launch.
5. Confirmation that no input loop existed.
6. Parent heartbeat count and maximum heartbeat interval.
7. Parent process duration.
8. Whether any `KeyboardInterrupt` occurred.
9. Whether any administrative continuation occurred.
10. Parent preseal outcome identity.
11. Platform-authoritative terminal exit.
12. Confirmation that no file was written after terminal manifests.

Additional required confirmations:

PRIOR_FAILED_AUDIT_ROOT_NOT_RESUMED
PRIOR_FAILED_AUDIT_ROOT_NOT_MUTATED
PRIOR_FAILED_AUDIT_EVIDENCE_NOT_REUSED
FINITE_ONE_SHOT_PARENT_USED
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
FROZEN_AUDIT_PLAN_RETAINED
AUDIT_PHASE_ORDER_FIXED_BEFORE_INSPECTION
HEARTBEATS_EMITTED_DURING_LONG_CHILDREN
NO_TOOL_SIDE_CANCELLATION
KEYBOARD_INTERRUPT_NOT_OBSERVED
ONE_PARENT_PROCESS_COMPLETED
ADMINISTRATIVE_CONTINUATION_NOT_USED
PARENT_PRESEAL_OUTCOME_RETAINED
PLATFORM_TERMINAL_EXIT_AUTHORITATIVE
NO_POSTMANIFEST_FILESYSTEM_WRITE

Retain every confirmation from the immediately preceding complete audit brief.

Do not begin another implementation or findings-reconciliation tranche unless
this fresh audit reaches a concrete substantive package defect.
```

**Source:** Codex’s latest `AUDIT_PROVENANCE_MISMATCH` report and the immediately preceding complete independent-audit brief.

**Confidence:** 0.999 that the latest result is audit-process-only; 0.99 that replacing the interactive input loop with a finite one-shot parent addresses the exact failure; 0.97 that the package remains ready for the same substantive independent audit.
