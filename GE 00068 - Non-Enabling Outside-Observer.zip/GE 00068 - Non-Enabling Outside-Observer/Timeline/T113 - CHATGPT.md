## Assessment

This resolves the architecture blocker. The selected design is now explicit and non-recursive: an ES-owned, committed external verifier with committed layout specifications; exact uncommitted source is supplied directly to a fresh audit before the first commit; neither the verifier nor an evidence child is asked to certify the verifier itself. 

The authority split is also sound. The verifier decides byte and filesystem closure only; layout specifications define bounded structure; readiness remains a separate adjudication recomputed by a later audit. The tool is narrowly owned by ES under `tools/evidence_verify/`, without creating a premature cross-repository framework.  

One implementation choice should be made explicit: **use a new clean Git worktree at the same committed HEAD and do not copy the current Repair 10I candidate’s uncommitted overlay into it.** The candidate presently has 22 tracked modifications and 14 untracked paths, while this implementation has a frozen 13-path scope. Copying the candidate overlay would entangle unrelated Repair 10I bytes in the later commit, especially in `PLANS.md` and the system-overview documents.  

The critical sequence is therefore:

1. Implement the verifier in a new clean worktree from `567bce…`.
2. Produce exact validation and patch provenance.
3. Run a fresh independent audit of the verifier source and layout semantics only.
4. Commit exactly the audited 13-path patch.
5. Restart A6 from a new evidence child using the audited committed verifier.

That preserves the required separation between implementation and independent audit.  

## Codex implementation prompt

```text
Permission is workspace-write for one bounded Execution Substrate
implementation tranche.

Implement the exact architecture frozen in the preceding read-only report:

EVIDENCE_VERIFICATION_ARCHITECTURE_RESET_READY

This turn implements the verifier, registry, three initial layout
specifications, governing documentation, fixtures, and tests. It performs
implementation validation and exact patch provenance only.

Do not perform an independent audit.
Do not stage, commit, push, create a PR, merge, install, deploy, invoke a live
route, contact a network, run a product workload, restart Repair 10I-A6, or
modify any existing Repair 10I evidence child.

No subagents. You are the sole repository writer.

## 1. Repository and worktree model

Current Repair 10I candidate, read-only throughout:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Primary checkout, read-only and not an implementation cwd:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Required new implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Required new branch:

codex/evidence-verification-v1

Required implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

The current candidate contains unrelated uncommitted Repair 10I work. Do not
copy or transplant its dirty working-tree bytes into IMPL_R.

Create IMPL_R as a clean worktree directly from the exact committed baseline:

567bceced5df95ecfe787cc66038d463a854e12c

The implementation patch must therefore contain only this verifier tranche,
not the candidate’s pre-existing Repair 10I modifications.

## 2. Mandatory candidate and common-Git gate

Before creating IMPL_R, verify CANDIDATE_R read-only:

- physical root:
  `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
- device/inode:
  `16777234/122118502`
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- upstream:
  absent
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- current candidate source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- current candidate inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- membership:
  `389 / 375 / 14`
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Verify the candidate `.git` pointer:

- regular file, not symlink;
- mode `0644`;
- size `123`;
- device/inode `16777234/122118504`;
- SHA-256:
  `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419`;
- target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Require:

- IMPL_R absent;
- branch `codex/evidence-verification-v1` absent;
- EVIDENCE absent.

Do not inspect or enumerate the primary checkout’s modified or untracked path
names.

Stop on any mismatch:

EVIDENCE_VERIFICATION_V1_BASELINE_MISMATCH

## 3. Create the clean implementation worktree

Using the verified candidate worktree as the explicitly rooted Git entrypoint,
create exactly one new worktree and branch:

git -C "$CANDIDATE_R" worktree add \
  -b codex/evidence-verification-v1 \
  "$IMPL_R" \
  567bceced5df95ecfe787cc66038d463a854e12c

This worktree/branch creation is the only authorized opening Git-
administration mutation.

Immediately require IMPL_R:

- physical path equals lexical path;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- tracked membership equals the committed HEAD;
- zero modified, staged, deleted, renamed, unmerged, or untracked paths;
- no Git operation marker or lock.

Set every repository subprocess cwd explicitly to IMPL_R.

Set for Git observations:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Do not use PRIMARY_R or CANDIDATE_R as the implementation cwd or source root.

Stop if the clean baseline cannot be established:

EVIDENCE_VERIFICATION_V1_WORKTREE_CONSTRUCTION_BLOCKED

## 4. Exact touched-file scope

Modify or add exactly these 13 paths in IMPL_R:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Expected classifications:

- four modified existing files:
  - `PLANS.md`
  - `boundaries.md`
  - `artifact_hygiene.md`
  - `capability_probing.md`
- nine added regular files;
- zero deletion;
- zero rename;
- zero executable-mode addition;
- zero modification outside this set.

All repository files in this tranche remain logical mode `100644`.

Do not add:

- `AGENTS.md` changes;
- Go source;
- product or public schema;
- module or dependency files;
- a package initializer;
- a runtime route;
- a second verifier;
- an evidence-child-local verifier;
- a generated manifest inside the repository.

Any additional repository path requires an immediate stop:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

## 5. Governing classification

Document and preserve these classifications:

- The verifier and layout specifications are an ES-owned `Bounded slice rule`
  for source-external evidence closure.
- The verifier is not:
  - ES runtime authority;
  - execution admission authority;
  - orchestration authority;
  - readiness authority;
  - durable program truth;
  - product result truth.
- Verifier output is evidence/projection only.
- Layout specifications define structure only.
- Closeout adjudication and later independent audit own validation/readiness
  judgment.
- Historical target-specific verifiers are `Temporary compatibility edges`
  and regression fixtures only.
- This tranche exercises no `Reopened redesign seam`.
- T1 and all public product/runtime contracts remain unchanged.

## 6. Documentation-first order

Implement in this order:

1. `PLANS.md`
2. the four system-overview documents
3. verifier tests and historical fixtures
4. layout specifications and registry
5. `verify_v1.py`
6. validation
7. provenance and closeout.

### `PLANS.md`

Record:

- authority split;
- ES-local placement;
- bootstrap model B before first commit;
- committed model A after audit;
- no self-verification;
- no amendment chains;
- no caller-supplied layouts;
- implementation → fresh audit → exact-byte commit → fresh A6 sequence;
- stop conditions.

### `boundaries.md`

State that:

- verifier closure is evidence only;
- verifier output cannot become ES runtime/admission truth;
- readiness and product correctness are outside its authority;
- a future cross-repository verifier owner requires a separate decision.

### `artifact_hygiene.md`

Define:

- byte/path/type/mode/size/hash/link closure;
- manifest and sidecar posture;
- manifest-last observable ordering;
- source-external pre-seal manifest candidate;
- no writes;
- no target-contained verifier;
- no evidence child self-verification;
- historical target-specific verifier classification.

### `capability_probing.md`

Define:

- descriptor/no-follow capabilities must be behaviorally proven;
- missing capability is a verification-boundary failure;
- no OS-name branch or permissive fallback;
- no broad path or metadata fallback;
- I/O or race uncertainty returns a blocking result.

### `evidence_verification.md`

Own the complete normative verifier, registry, layout-spec, output, invocation,
error, authority, bootstrap, audit, and migration contract.

## 7. Tool identity and placement

Tool ID:

`execution-substrate.evidence-closure-verifier/v1`

Sole executable implementation:

`tools/evidence_verify/verify_v1.py`

Requirements:

- Python standard library only;
- no third-party dependency;
- no repository package import;
- no import from target evidence;
- no child process;
- no network;
- no environment-derived target registration;
- no runtime `--layout-file`;
- no runtime registry extension;
- no arbitrary caller-provided schema;
- no write to target;
- no write to tool package;
- no cwd write;
- no cache or bytecode;
- no temporary file;
- deterministic canonical stdout.

Run with the exact resolved Python 3.13 interpreter and retain:

- physical interpreter path;
- size;
- SHA-256;
- version;
- argv;
- environment.

Required invocation grammar:

```text
python3.13 -I -B verify_v1.py \
  --root ABSOLUTE_PHYSICAL_TARGET \
  --layout-id ID \
  --stage pre-seal \
  --manifest ABSOLUTE_EXTERNAL_CANDIDATE
```

or:

```text
python3.13 -I -B verify_v1.py \
  --root ABSOLUTE_PHYSICAL_TARGET \
  --layout-id ID \
  --stage sealed
```

Rules:

- `--manifest` is mandatory at `pre-seal`;
- `--manifest` is forbidden at `sealed`;
- the pre-seal manifest is outside both target and verifier package;
- target must not equal, contain, or be contained by the verifier package;
- unknown option or positional argument rejects;
- relative target or manifest rejects;
- target identity is descriptor-bracketed;
- target code is never imported.

## 8. Registry contract

File:

`tools/evidence_verify/registry_v1.json`

Canonical form:

- UTF-8;
- ASCII-only JSON content;
- sorted object keys;
- compact separators;
- exactly one final LF;
- no duplicate key;
- no float;
- no unknown top-level key.

It maps exact layout IDs to:

- repository-package-relative spec filename;
- exact complete spec SHA-256.

No path outside `tools/evidence_verify/layouts/` is admissible.

Initial IDs:

1. `execution-substrate.repair10i.a6d-successor-layout/v1`
2. `execution-substrate.repair10i.a6d-amendment-layout/v1`
3. `execution-substrate.repair10i.a6-policy-layout/v1`

Unknown ID rejects.

A registry ID/spec filename/spec hash mismatch rejects.

Adding a schema-compatible target later changes:

- one new committed spec;
- one audited registry entry;

and does not require `verify_v1.py` modification.

## 9. Closed layout-spec schema

Canonical JSON permits only:

- `schema`
- `id`
- `manifest_magic`
- `required_root_directories`
- `required_directories`
- `required_files`
- `optional_subtrees`
- `file_modes`
- `directory_mode`
- `stages`
- `limits`

Reject:

- duplicate keys;
- unknown keys;
- floats;
- noncanonical encoding;
- mismatched embedded ID;
- unsupported manifest magic;
- unbounded optional subtree;
- arbitrary regular expression;
- caller-supplied path.

Portable path segments:

- nonempty ASCII;
- first character alphanumeric;
- remaining characters limited to alphanumeric, `.`, `_`, and `-`;
- segment must not equal `.` or `..`;
- no slash, NUL, control character, backslash, or absolute path.

Shared limits:

- maximum files: `8192`
- maximum directories: `2048`
- maximum single-file bytes: `268435456`
- maximum total payload bytes: `4294967296`
- maximum path segments: `12`
- maximum encoded relative-path bytes: `1024`.

All directories:

- mode `0700`.

Regular payload modes:

- `0600` or `0700`.

Fixed required records:

- mode `0600`.

No symlink.
No hardlink.
No FIFO, socket, device, or other special file.

## 10. Initial layout specifications

### A6D successor layout

ID:

`execution-substrate.repair10i.a6d-successor-layout/v1`

Recover the exact seven historical top-level directories and fixed required
records from the original sealed A6D child and its manifest.

Do not invent or broaden them.

This layout uses manifest magic:

`ES-REPAIR10-EVIDENCE-MANIFEST-V1`

### A6D amendment layout

ID:

`execution-substrate.repair10i.a6d-amendment-layout/v1`

Recover the exact six historical top-level directories and fixed required
records from the sealed A6D verifier amendment.

Do not invent or broaden them.

This layout uses manifest magic:

`ES-REPAIR10-EVIDENCE-MANIFEST-V1`

### A6 policy layout

ID:

`execution-substrate.repair10i.a6-policy-layout/v1`

Require exactly these top-level directories:

- `opening`
- `tool`
- `sources`
- `commands`
- `controls`
- `validation`
- `comparisons`
- `analysis`
- `findings`
- `closeout`

Require fixed files:

- `opening/opening-capsule-v1.json`
- `closeout/closing-gate-v1.json`
- `closeout/cleanup-v1.json`
- `closeout/command-root-audit-v1.json`
- `closeout/final-report-v1.md`

This layout uses manifest magic:

`GE-EVIDENCE-MANIFEST-V1`

No spec interprets any record’s JSON or Markdown contents.

## 11. Manifest contract

Legacy and GE manifests differ only by exact header.

Supported headers:

- `ES-REPAIR10-EVIDENCE-MANIFEST-V1`
- `GE-EVIDENCE-MANIFEST-V1`

Use the exact closed row grammar recovered from the sealed legacy manifests:

- canonical payload count;
- byte-sorted unique relative paths;
- exact regular-file logical mode;
- canonical unsigned decimal size;
- lowercase 64-hex SHA-256;
- unpadded canonical URL-safe base64 path encoding;
- no CR;
- one final LF;
- no duplicate path;
- no noncanonical numeric or base64 spelling.

The manifest excludes:

- `evidence-manifest-v1.txt`
- `evidence-manifest-v1.txt.sha256`

At sealed stage:

- both files must exist at target root;
- both are regular, single-link, mode `0600`;
- sidecar bytes are exactly:
  `<lowercase-manifest-sha256>\n`;
- all other governed files exactly equal manifest rows;
- no unexpected file exists;
- every directory satisfies the layout and mode;
- observable manifest-last metadata ordering passes;
- stable repeated traversal passes.

At pre-seal:

- both root seal files are absent;
- the external manifest candidate is verified against the target;
- the verifier does not install either file.

Do not claim resistance to privileged timestamp forgery or historical
transport mutation. Report only the observable same-child sealed posture.

## 12. Closure algorithm

The verifier’s sole decision is structural and byte closure.

It checks:

- exact registered layout identity;
- target boundary;
- stage posture;
- canonical manifest syntax;
- sidecar identity at sealed stage;
- complete path set;
- required layout entries;
- bounded optional-subtree entries;
- file type;
- directory type;
- modes;
- file sizes;
- complete SHA-256;
- link count one;
- directory mode;
- no symlink or special object;
- total counts and byte limits;
- before/read/after file identity stability;
- repeated traversal stability;
- manifest-last observable ordering.

It does not inspect:

- test result meaning;
- comparison acceptance;
- repair correctness;
- closeout readiness;
- historical-policy safety;
- product authority;
- runtime authority;
- orchestration authority.

A structurally valid child containing failing tests must receive the same
closure result as the same structurally valid child containing passing tests.

## 13. Canonical output and exits

Stdout is exactly one compact, sorted-key JSON line plus LF.

Fields:

- `schema`
- `tool_id`
- `outcome`
- `stage`
- `layout_id`
- `registry_sha256`
- `layout_sha256`
- `manifest_sha256`
- `payload_count`
- `directory_count`
- `error_class`

Unavailable values are JSON `null`.

Never include:

- absolute target path;
- payload path;
- payload content;
- timestamps;
- hostnames;
- usernames;
- readiness captions;
- traceback.

Outcomes:

- `pass`
- `reject`
- `indeterminate`

Exit codes:

- `0`: closure pass
- `2`: invocation or target-boundary failure
- `3`: registry/spec identity or schema failure
- `4`: stage/layout failure
- `5`: manifest/sidecar failure
- `6`: path/type/mode/link/size/hash/post-seal closure failure
- `7`: I/O, capability, or race uncertainty.

Closed error classes:

- `INVOCATION`
- `TARGET_BOUNDARY`
- `UNKNOWN_LAYOUT`
- `SPEC_IDENTITY`
- `SPEC_SCHEMA`
- `STAGE`
- `LAYOUT`
- `MANIFEST_CANONICAL`
- `SIDECAR`
- `PATH_SET`
- `TYPE_MODE_LINK`
- `SIZE_HASH`
- `POST_SEAL`
- `IO_OR_RACE`

All nonzero exits block evidence closure.

## 14. Historical defect fixtures

Copy exact original bytes, without normalization, into:

- `fixtures/historical_a6d_verify_postseal_v1.py.txt`
- `fixtures/historical_a6d_verify_closing_v1.py.txt`

Recover them from the original sealed A6D evidence and bind their exact source
paths and SHA-256 values in tests.

These are inert `.txt` fixtures.

Never import or execute them as repository code.

The tests must reproduce the original valid-sealed-layout rejection and show
that `verify_v1.py` accepts the corresponding valid fixture under the audited
layout spec.

## 15. Required 30-case validation matrix

Implement and run every case:

1. Valid generic pre-seal closure passes.
2. Valid generic sealed closure passes.
3. Missing manifest at sealed stage rejects.
4. Missing sidecar rejects.
5. Wrong sidecar digest rejects.
6. Missing manifested payload rejects.
7. Unexpected payload rejects.
8. Wrong file mode rejects.
9. Wrong size rejects.
10. Wrong hash rejects.
11. Wrong link count rejects.
12. Directory-mode mismatch rejects.
13. Symlink rejects at every depth.
14. Special file rejects at every depth.
15. Observable post-manifest mutation, including a same-byte rewrite, rejects.
16. Unknown layout ID rejects.
17. Wrong registered layout hash rejects.
18. Missing required layout entry rejects.
19. Unexpected layout entry rejects.
20. Pre-seal/sealed posture confusion rejects.
21. Caller-supplied arbitrary layout is impossible and rejected at CLI.
22. Readiness content changes without structural change produce the same
    closure result.
23. Complete target and tool-package snapshots before/after invocation are
    identical.
24. Repeated invocation under the pinned environment produces byte-identical
    canonical stdout.
25. Verifier source inside or dependent on the target rejects or fails source
    audit.
26. Target equal to the verifier package or its container rejects.
27. Producer and independently materialized auditor fixtures reproduce the
    same result.
28. Exact original A6D target-specific verifier defect is reproduced; the new
    verifier closes the valid fixture.
29. A fourth test layout is added through only a temporary registry/spec copy;
    `verify_v1.py` bytes remain identical.
30. Exact verifier source, branch/HEAD, registry hash, layout ID/hash, manifest
    identity, and invocation are retained in closeout evidence.

Use `unittest` or an equivalently standard-library-only test harness.

All fixture roots must be private, short, test-owned, and removed.

No test may write into the repository except its already authorized source
files during implementation.

## 16. Real sealed-child compatibility checks

Read-only inputs:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Require the new verifier to pass sealed verification twice against each child
using the corresponding registered legacy layout.

For each child require:

- both exits `0`;
- repeated stdout byte-identical;
- expected manifest identity;
- expected payload and directory counts;
- no target mutation;
- before/after complete safe identity snapshots equal.

Do not interpret validation or readiness records inside either child.

## 17. Validation commands

Resolve and bind the exact Python 3.13 interpreter first.

Run under:

- `PYTHONDONTWRITEBYTECODE=1`
- isolated mode `-I`
- no bytecode `-B`
- `LC_ALL=C`
- `LANG=C`
- private `TMPDIR`
- no network.

Required validation:

1. Parse every Python source with `ast.parse`; create no bytecode.
2. Parse registry and all specs with the implementation’s strict canonical
   parser.
3. Run `test_verify_v1.py` completely.
4. Run the complete test command twice and require equivalent outcomes.
5. Run the real A6D sealed check twice.
6. Run the real amendment sealed check twice.
7. Run a synthetic A6 pre-seal check twice.
8. Run the same synthetic A6 fixture after sealing twice.
9. Require byte-identical verifier output for repeated identical invocations.
10. Snapshot target and verifier package before and after every no-write
    control.
11. Run `git diff --check`.

Do not run the repository Go suite. This tranche changes no Go or product
behavior.

Retain exact argv, cwd, safe environment, exit, stdout, and stderr in EVIDENCE.

## 18. Implementation evidence and provenance

Create EVIDENCE under umask `077` with:

- `opening/`
- `inputs/`
- `validation/`
- `provenance/`
- `closeout/`

This evidence root is an audit input. It is not verified by the new verifier
and is not represented as authoritative.

Retain:

- architecture-decision identity;
- candidate read-only opening/closing capsule;
- implementation-worktree opening/closing capsule;
- worktree/branch creation record;
- original fixture source identities;
- exact validation records;
- real-child compatibility records;
- target/tool before/after snapshots;
- exact final diff;
- implementation report.

Create one source-external deterministic provenance recipe and retain its exact
source bytes.

The provenance recipe must record:

- implementation repository physical root;
- branch;
- HEAD;
- upstream;
- complete changed-path set;
- addition/modification/deletion/untracked classification;
- file type;
- logical mode;
- byte size;
- SHA-256;
- deterministic tracked binary-diff SHA-256;
- recipe ID;
- exact canonical JSON.

Requirements:

- sort paths bytewise;
- use fixed canonical JSON;
- include untracked files;
- reject unsupported file types;
- contain no timestamp or random value;
- write only under EVIDENCE;
- run twice after validation;
- require byte-identical canonical output;
- retain recipe SHA-256 and complete source for the auditor.

Because IMPL_R opened clean, require the final repository path set to be
exactly the 13 authorized paths.

Do not use the new evidence-closure verifier to certify this implementation
patch or its own package.

## 19. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`
- HEAD still:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- upstream:
  absent
- exactly 13 changed/untracked paths;
- exactly four modified tracked files;
- exactly nine untracked added files;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- `git diff --check` clean;
- no `__pycache__`, `.pyc`, `.pytest_cache`, database, lock, generated
  manifest, test fixture, or temporary output in the repository.

Require CANDIDATE_R closing identity exactly equals its opening identity.

Require PRIMARY_R was never an implementation cwd or source root.

Remove only implementation-created temporary fixture/cache roots.

Do not remove IMPL_R or EVIDENCE; they are required for the fresh audit.

## 20. Mandatory stop conditions

Stop on:

- candidate baseline drift;
- worktree path or branch already exists;
- clean implementation baseline cannot be established;
- need for a 14th repository path;
- need to copy the candidate dirty overlay;
- inability to recover exact historical fixture bytes;
- real A6D or amendment child fails the new verifier;
- verifier writes to target, tool package, cwd, cache, or temporary path;
- output includes an absolute target path or readiness claim;
- registry permits runtime layout injection;
- spec accepts an unbounded subtree;
- arbitrary extra file can pass;
- unsupported no-follow/descriptor behavior falls back permissively;
- same input produces different canonical output;
- third-party dependency or network is required;
- provenance output is unstable;
- candidate or predecessor evidence changes.

## 21. Verdicts

Opening or worktree mismatch:

EVIDENCE_VERIFICATION_V1_BASELINE_MISMATCH

Clean worktree construction failure:

EVIDENCE_VERIFICATION_V1_WORKTREE_CONSTRUCTION_BLOCKED

Scope expansion:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

Contract or validation failure:

EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED

Provenance failure:

EVIDENCE_VERIFICATION_V1_PROVENANCE_BLOCKED

Complete implementation success:

EVIDENCE_VERIFICATION_V1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

## 22. Required implementation report

Include:

1. Candidate opening/closing identity.
2. New worktree path, branch, HEAD, and upstream.
3. Exact 13-path delta and classifications.
4. Authority and non-authority treatment.
5. Verifier tool ID and exact source SHA-256.
6. Python interpreter identity.
7. Registry SHA-256.
8. All three layout IDs, paths, and SHA-256 values.
9. Exact historical fixture source paths and hashes.
10. All 30 causal outcomes.
11. Real A6D and amendment verification results.
12. No-write and deterministic-output evidence.
13. Exact validation commands and results.
14. Generated/artifact hygiene.
15. Security or authority widening:
    explicitly none, or exact finding.
16. Provenance recipe ID and source SHA-256.
17. Tracked binary-diff SHA-256.
18. Canonical patch-manifest SHA-256.
19. Complete changed-file manifest.
20. Remaining uncertainty and uninspected areas.
21. Confirmation:
    - independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - no product test or live service invoked.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## What follows

A successful implementation result should go directly to a **fresh read-only audit of the 13-path patch**, not to commit or A6. The operating protocol requires the implementation parent to remain the sole writer and the later audit to run in a separate read-only conversation. 

The audit must receive the exact provenance recipe source, reproduce its canonical output twice, and stop before correctness inspection on any mismatch. 

### Sources

- Attached `EVIDENCE_VERIFICATION_ARCHITECTURE_RESET_READY` decision. 
- Selected bootstrap, ownership, and placement. 
- Frozen verifier, registry, spec, output, and migration contracts. 
- Exact future touched-file set. 
- Required causal matrix and sequencing. 
- MVP proof scaffolding remains non-authoritative. 
- Implementation/audit separation. 
- Exact provenance lifecycle. 

**Confidence**

- Architecture-freeze interpretation: **0.995**
- Correctness of the clean-worktree sequencing decision: **0.98**
- Implementation-readiness: **0.98**
- Confidence that no Repair 10I successor rebuild is needed for this tranche: **0.97**
- Confidence that a fresh independent audit must precede the first commit and A6 restart: **0.999**
