Codex stopped at the right boundary. This is not a regression in Evidence Verification v1 and it does not reopen the accepted commit.

## Assessment

The work has now separated cleanly into three layers:

1. **Structural closure is implemented and committed.**  
   The generic verifier, registry, A6 policy layout, source-by-value caller, bundle publication, and committed Git identities are settled.

2. **The retained A6 execution intent is largely recoverable.**  
   Codex identified the five controls, seven-command suite shape, five comparison pairs, expected exits, child layout, sealing order, and authority split.

3. **The current semantic execution contract does not yet exist.**  
   Four gaps are acceptance-bearing:
   - no five-control **v6 / effective-read-policy-v3** suite-spec set;
   - no implemented historical directional comparator;
   - no v6/v3-compatible transition analyzer;
   - no authoritative fresh-child allocation rule.

There is also a fifth integration gap: no current orchestration contract binds those components into one executable A6 plan.

The correct next move is **not** to run A6, reinterpret the v5/v2 records, change the committed verifier, or create another evidence child. The architecture reset deliberately keeps structural closure separate from readiness adjudication and requires a fresh child rather than resuming a failed one. 

My provisional target architecture is:

- **Committed EV package:** structural closure only; unchanged.
- **A6D plus amendment:** immutable lineage and current dialect inputs; unchanged.
- **New source-external A6 semantic package:** current suite specifications, comparison, qualification, and analysis mechanics.
- **Fresh A6 child:** run evidence only; it must not invent or contain the first authoritative copy of its own acceptance machinery.
- **Governing ES docs:** own the fresh-child allocation and execution-contract decision.

This should probably become **two implementation tranches**, after one read-only design pass:

1. current v6/v3 semantic toolchain and exact five specs;
2. allocation/orchestration/closeout contract that consumes the audited toolchain.

The reconnaissance should decide whether those two can safely share one source package and audit chain. Exploration and mutation should remain separate turns, with no subagents active during repository mutation. 

## Prompt for Codex

```text
MANDATORY RESPONSE FORMAT

Embed the complete report inline in Markdown. Links may be supplemental, but
must not replace any requested section.

Return exactly one:

REPAIR10I_A6_CURRENT_CONTRACT_RECONNAISSANCE_READY
REPAIR10I_A6_CURRENT_CONTRACT_RECONNAISSANCE_PARTIAL
REPAIR10I_A6_CURRENT_CONTRACT_RECONNAISSANCE_BLOCKED
SUBAGENT_UNAVAILABLE

This is a read-only architecture, contract, source, and validation
reconnaissance. Do not implement anything.

Do not create, edit, delete, chmod, normalize, clean, stage, commit, reset,
amend, revert, merge, push, create an upstream, create a PR, install a
dependency, invoke a live service, contact a network, create or resume an A6
child, execute a Repair 10I control, run a comparison, run the transition
analyzer, invoke the Evidence Verification verifier or caller, seal evidence,
or mutate any supplied evidence root.

Do not create a reconnaissance evidence root. The inline response is the only
new report from this turn.

## 1. Objective

Freeze an implementation-ready current A6 execution contract that resolves the
acceptance-bearing gaps identified by the immediately preceding phase-entry
reconciliation:

1. five exact current suite specifications using outer schema v6 and
   effective-read-policy v3;
2. an implemented historical directional comparator contract;
3. a transition analyzer compatible with v6 qualification and v3 policy
   evidence;
4. an authoritative fresh-child prefix or deterministic allocation rule;
5. one orchestration and closeout contract binding those components into the
   five-control A6 execution plan.

The result must identify exact ownership, source placement, schema versions,
touched files, source-external artifacts, validation, audit, provenance,
sequencing, and stop conditions.

Do not silently relabel v5/v2 inputs as v6/v3.
Do not treat historical parse compatibility as current qualification.
Do not reduce the five-control plan.
Do not remove either historical comparison.
Do not invent readiness semantics inside Evidence Verification v1.
Do not mutate or amend sealed A6D or the sealed amendment.
Do not reuse or resume any existing A6 child.

## 2. Current adjudicated state

Treat the following as current inputs, subject to fresh read-only identity
verification.

### 2.1 Committed Evidence Verification package

EV_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected:

- branch:
  codex/evidence-verification-v1
- HEAD:
  05dcedb75b674660215504dcf5b5fab9dbb8aa2f
- tree:
  1705df78364003806e2463bb54588c09dc69c60d
- sole parent:
  567bceced5df95ecfe787cc66038d463a854e12c
- subject:
  add evidence verification v1
- upstream:
  absent
- worktree/index:
  clean

Frozen committed identities:

- verifier:
  tools/evidence_verify/verify_v1.py
  SHA-256
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

- registry:
  tools/evidence_verify/registry_v1.json
  SHA-256
  e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880

- A6 policy layout:
  tools/evidence_verify/layouts/a6_policy_v1.json
  layout ID
  execution-substrate.repair10i.a6-policy-layout/v1
  SHA-256
  b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8

The committed verifier is accepted for structural closure. It is not the owner
of control success, comparison acceptance, historical policy, transition
analysis, Repair 10I correctness, or A6 readiness.

Do not propose changing this commit as part of the present tranche unless
inspection finds a direct, unavoidable contract inconsistency. Such a finding
must return RECONNAISSANCE_BLOCKED rather than widening scope.

### 2.2 Source-external caller

FINAL_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py

Expected:

- size:
  49,047 bytes
- SHA-256:
  643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5
- launch protocol:
  execution-substrate.evidence-closure-launch/v2
- record schema:
  execution-substrate.evidence-closure-launch-record/v4

The caller is frozen structural-verification transport and evidence
publication. Do not add A6 readiness or semantic comparison authority to it.

### 2.3 Candidate repository

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0

Treat candidate product bytes as protected read-only inputs.

### 2.4 Evidence roots

EVIDENCE_ROOT=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1

A6D_ROOT=$EVIDENCE_ROOT/phase-i-a6d-device-security-successor-closure-8de797304ea9

AMENDMENT_ROOT=$EVIDENCE_ROOT/phase-i-a6d-seal-verifier-amendment-8de797304ea9

A6V_ROOT=$EVIDENCE_ROOT/phase-i-a6v-evidence-target-recon-8de797304ea9

Expected immutable identities include:

- A6D manifest:
  dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9
- A6D source T:
  8c237318e3a72172e5cbbdf41f5e68244ae15895
- A6D source inventory:
  7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852
- amendment manifest:
  a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e
- joint qualification SHA-256:
  e9af0475fb0855404616630c3dfc5749be6d5b7f7ec9107a8de0eee2e7eb92c9

A6D establishes outer schema v6 and effective-read-policy v3. Retained v5/v2
suite specifications and qualifications are historical parse-only inputs.

The joint qualification explicitly records that the historical comparator is
not implemented. Do not reinterpret that field.

Inspect A6V and every existing `phase-i-a6-policy-evidence-*` child. None may
be resumed or selected as the future fresh target.

## 3. Process posture

After receiving this prompt:

- every repository Git command must use `git -C <exact root>`;
- its cwd must equal that exact root;
- explicitly supply:

  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  GIT_OPTIONAL_LOCKS=0
  GIT_CONFIG_NOSYSTEM=1
  LC_ALL=C
  LANG=C
  PYTHONDONTWRITEBYTECODE=1

Do not run Git in the primary checkout.

The parent alone may run Git.
Subagents must not run Git.

Python inspection, when required, must use pinned Python with `-I -B` or
`-I -S -B`, bytecode disabled, and source supplied through stdin or `-c`.
Do not import repository or retained tool modules.
Do not execute retained Repair 10I binaries.

Read only the exact repositories and evidence roots stated above, plus exact
paths discovered beneath them. Do not broadly traverse unrelated Downloads or
repository siblings.

## 4. Subagent workflow

After the parent verifies the opening identities, start exactly four distinct
read-only explorers.

Start explorers 1–3 concurrently. Start explorer 4 after any one of the first
three closes. Make at most one retry if a required explorer fails to start.
Do not silently replace missing explorer work with parent inference.

No nested subagents.

Give every explorer the same current-state capsule above and require path and
line references for every material claim.

### Explorer 1 — Current dialect and five suite specifications

Inspect:

- A6D source, FORMAT or schema documentation, retained source copies, binaries,
  tests, hard gates, and qualification records;
- all five retained v5 suite specifications;
- v6 suite-result and control-qualification records;
- effective-read-policy v2 and v3 records;
- current command, terminal, PTY, resource, custody, materialization, and source
  lineage structures;
- historical compatibility parsing behavior.

Return:

1. the exact current suite-spec schema ID and canonical field map required for
   v6/v3;
2. whether an existing v6 suite-spec implementation is present but merely not
   instantiated, or whether schema/source implementation is missing;
3. a field-by-field v5→current migration table;
4. the exact five current specifications:
   - pristine final;
   - fresh independent final;
   - intentional mutant;
   - historical HEAD;
   - historical Repair 9;
5. exact command lists, order, expected exits, PTY requirements, source class,
   base/effective T and inventory bindings, mutation/overlay lineage, terminal
   reconciliation, qualification, peer qualification, and cleanup fields;
6. exact source and test files that must change or be added;
7. compatibility treatment for v5/v2 records;
8. validation and audit causals;
9. unresolved ambiguities.

Do not produce merely a version-renamed copy of the v5 records.

### Explorer 2 — Historical comparator and transition analyzer

Inspect:

- current `repair10-compare`, `repair10-semantic`, and related source and tests;
- retained comparison specs/results/custody records;
- the joint qualification’s historical-comparator nonimplementation statement;
- retained transition analyzer source and tests;
- the five frozen comparison pairs and historical direction requirements;
- v6 qualification, v3 effective-read policy, lineage, peer qualification,
  late-fault, resource, terminal, custody, and unknown-difference semantics.

Return separately for the comparator and analyzer:

1. current implemented behavior;
2. missing behavior;
3. exact intended schema IDs and complete field maps;
4. exact CLI and input/output contracts;
5. reason-code sets;
6. expected exits;
7. historical direction rules;
8. overlay treatment;
9. unknown-difference policy;
10. late-fault policy;
11. independent qualification recomputation;
12. source, test, documentation, fixtures, and build surfaces;
13. whether one binary can correctly own both concerns or two tools are required;
14. exact A/B build, self-test, causal, peer, and independent-audit matrix;
15. compatibility behavior for v5/v2 inputs.

A factual comparison result and an acceptance result must remain distinct.
Do not let aggregate suite exit substitute for transition analysis.
Do not let later qualification failure erase factual equality or difference.

### Explorer 3 — Fresh-child allocation and orchestration contract

Inspect:

- candidate `PLANS.md`, governing `.docs/`, A6V, all failed A6 children,
  A6D/amendment closeouts, command indexes, cleanup records, opening capsules,
  sealing conventions, and evidence-root naming conventions;
- Evidence Verification A6 policy layout;
- caller bundle placement and containment rules;
- current zero-observation, cleanup, final-report, manifest, and detached-digest
  requirements.

Return:

1. the recommended authoritative fresh-child naming contract;
2. whether it is:
   - one deterministic absent path; or
   - one fixed authoritative prefix plus exclusive random allocation;
3. the exact prefix or deterministic rule;
4. why it cannot alias or resume an existing child;
5. allocation API/algorithm, umask, ownership, type, and mode requirements;
6. the exact opening capsule and orchestration-record schemas;
7. one authoritative writer for:
   - child allocation;
   - command progression;
   - control completion;
   - peer qualification;
   - comparison completion;
   - analysis completion;
   - closeout adjudication;
   - cleanup;
   - sealing;
8. exact top-level paths and bounded optional paths;
9. external placement for verifier/caller outputs and private roots;
10. serial and parallel execution rules;
11. crash/interruption/retry disposition;
12. final mutation and sealing rules;
13. exact touched governing docs, scripts, schemas, and tests;
14. validation and independent-audit requirements.

Prefer a fixed prefix plus exclusive allocation when that is sufficient to
prevent stale-path reuse; preserve a deterministic exact path only if an
owning contract requires it. State the evidence either way.

### Explorer 4 — Authority, ownership, security, provenance, and tranche split

Inspect all governing and proposed surfaces from the first three roles.

Return:

1. current authority owners;
2. proposed owner for each new schema, source file, generated spec, binary,
   orchestration record, and mutable state;
3. one-authoritative-writer analysis;
4. which artifacts belong in:
   - the ES repository;
   - a source-external audited tool package;
   - the future A6 child;
   - external caller/verifier bundles;
5. whether any proposal would turn proof harness behavior into product,
   runtime, readiness, or repository authority;
6. security and sensitive-material boundaries;
7. exact provenance lifecycle;
8. implementation/audit/commit dependencies;
9. whether the work must be split into two or more implementation tranches;
10. the minimum safe tranche ordering;
11. stop conditions;
12. any disagreement with another role’s proposed ownership or scope.

Treat the committed verifier and caller as frozen inputs, not convenient homes
for missing semantic logic.

## 5. Parent adjudication requirements

After all four explorers close, the parent must reconcile their reports and
produce an implementation-ready decision.

### 5.1 Current contract ledger

For each item below, classify it as:

- current implemented contract;
- current retained historical compatibility;
- missing implementation;
- missing governing decision;
- report-only uncertainty;
- superseded or nonresumable evidence.

Items:

- suite specification schema;
- each of the five suite specs;
- suite result;
- control qualification;
- peer qualification;
- effective read policy;
- semantic extraction;
- factual comparison;
- historical directional comparator;
- transition analyzer;
- closeout adjudicator;
- orchestration state/progression;
- fresh-child allocator;
- Evidence Verification closure;
- caller bundle publication.

### 5.2 Exact target version map

Freeze the exact current IDs for:

- suite specification;
- suite result;
- control qualification;
- peer qualification if separate;
- effective-read-policy;
- semantic envelope;
- comparison specification;
- comparison result;
- comparison custody;
- comparison adjudication;
- historical directional analysis;
- closeout adjudication;
- orchestration/opening capsule;
- child allocation record;
- cleanup record;
- failed/superseded-attempt index;
- command index.

Do not invent “v6” merely because the outer result schema is v6. Recover the
actual owner and field-level version relationship.

### 5.3 Five complete specification capsules

For every control, include:

- control ID;
- source class;
- base and effective source identity;
- exact materialization procedure;
- mutation or overlay contract;
- command sequence;
- expected per-command exit;
- allowed aggregate exit;
- PTY/read-policy contract;
- terminal reconciliation;
- resource disposition;
- cleanup;
- qualification;
- peer qualification;
- exact binary/source bindings;
- outputs and schemas;
- historical treatment;
- stop conditions.

Zero acceptance-bearing field may remain “TBD”.

### 5.4 Comparator and analyzer freeze

Provide exact contracts, source locations, touched paths, tests, build outputs,
A/B requirements, reason codes, expected exits, and compatibility behavior.

The final report must answer:

- Is the historical comparator absent source, absent wiring, absent schema, or
  all three?
- Is the analyzer’s v5/v2 dependency local and replaceable, or does its core
  model need redesign?
- Can the current `repair10-compare` and `repair10-semantic` source lineage be
  evolved, or is a new versioned successor package required?
- What exact independent evidence qualifies the new bytes before A6?

### 5.5 Fresh-child freeze

Provide one exact allocation rule. It must be concrete enough for a subsequent
implementation and A6 prompt to execute without inventing a suffix or choosing
between alternatives.

It must guarantee:

- absent target;
- exclusive allocation;
- no existing-child reuse;
- no child rename into eligibility;
- direct physical root;
- mode 0700;
- separation from package, candidate, caller output, TMPDIR, control roots,
  caches, runtimes, Git stores, sockets, and source roots;
- recorded path identity and lineage;
- deterministic consumer discovery without making the pathname authority.

### 5.6 Implementation tranche decomposition

Recommend the minimum safe implementation sequence.

The expected shape is provisionally:

A. current v6/v3 semantic toolchain and five exact specifications;
B. fresh-child allocator plus orchestration/closeout contract;
C. fresh A6 execution;
D. independent A6 audit.

Do not force that split if source inspection proves another decomposition is
safer. State why.

For every pre-A6 implementation tranche, provide:

- objective;
- owner;
- repository or source-external root;
- exact touched-file set;
- new files;
- governing docs;
- tests;
- builds;
- validation;
- provenance;
- independent audit;
- commit or sealed-package requirement;
- inputs and outputs;
- stop conditions;
- dependency on earlier tranches.

No implementation tranche may mutate both the candidate product source and an
unrelated repository.

### 5.7 Acceptance gate

The reconnaissance can return READY only when:

- all current schema IDs are exact;
- all five specs are exact;
- comparator and analyzer ownership and source surfaces are exact;
- fresh-child allocation is exact;
- orchestration ownership is exact;
- touched paths are exact;
- validation and audit are exact;
- no acceptance-bearing semantic choice is deferred to the future A6 run.

## 6. Required final report sections

1. Verdict.
2. Opening identities and inspected roots.
3. Explorer identities, scopes, scheduling, failures/retries, and completion.
4. Evidence/inference/uncertainty ledger.
5. Current contract ledger.
6. Current-versus-historical dialect map.
7. Exact version/schema map.
8. Five complete current suite-specification capsules.
9. Historical comparator contract.
10. Transition analyzer contract.
11. Comparator/analyzer source and build ownership.
12. Fresh-child allocation contract.
13. Orchestration and closeout ownership model.
14. Structural Evidence Verification and caller integration.
15. Exact implementation tranche decomposition.
16. Exact touched repository paths.
17. Exact source-external files and proposed root structure.
18. Validation and causal matrix.
19. Provenance and independent-audit plan.
20. Compatibility and migration treatment.
21. Security, authority, and sensitive-material boundaries.
22. Preserved explorer disagreements and parent resolution.
23. Stop conditions.
24. Remaining ambiguity.
25. Uninspected scope.
26. Explicit confirmations:
    - no file created;
    - no file modified;
    - no file deleted;
    - no test, build, control, comparator, analyzer, verifier, or caller run;
    - no A6 child created or resumed;
    - no evidence root allocated;
    - no staging, commit, reset, amend, revert, push, PR, merge, or upstream;
    - no product/live-service invocation;
    - no network contact;
    - no nested subagents.

## 7. Mandatory stop conditions

Return REPAIR10I_A6_CURRENT_CONTRACT_RECONNAISSANCE_BLOCKED if:

- any opening identity drifts;
- A6D or amendment is not immutable;
- the five-control plan is ambiguous;
- an existing failed child must be reused;
- current suite-spec schema cannot be recovered or explicitly designed;
- comparator or analyzer ownership remains unclear;
- comparator/analyzer implementation would require readiness logic in the
  structural verifier;
- a v5/v2 record must be silently promoted;
- product source mutation is required merely to construct proof tooling;
- a fresh-child allocation rule remains optional or unresolved;
- a mutable fact has multiple authoritative writers;
- exact touched-file scope cannot be bounded;
- a required explorer remains unavailable after one retry;
- sensitive material would need to be exposed;
- the read-only baseline changes.
```

## Expected continuation

A `READY` result should lead to a **parent-only implementation turn**, not directly to A6. The implementation bytes would then need their own exact validation, provenance, and fresh independent audit before the fresh child is allocated. The project protocol explicitly treats read-only design, parent-only implementation, independent audit, and commit/publication as separate engagement types. 

The previous closeout capsule should remain an input record, not be promoted into a correctness verdict; it explicitly described itself as read-only audit input rather than independent correctness assessment. 

### Sources

- Evidence Verification architecture reset: structural closure is separate from readiness, failed children are not resumed, and a fresh A6 follows accepted verifier source and commit. 
- Codex operating protocol: separate read-only reconnaissance from parent-only mutation and later independent audit. 
- Provenance guidance: provenance binds bytes but does not establish correctness or authority. 

**Confidence**

- Codex’s `RECONCILIATION_BLOCKED` verdict: **0.995**
- Diagnosis that the verifier track is complete and should remain frozen: **0.99**
- Need for a separate semantic-contract implementation before A6: **0.995**
- Provisional two-tranche decomposition: **0.88**
- Readiness to execute fresh A6 now: **0.02**
