## Assessment

A6R is a clean successor implementation result. It closes the read-policy blocker without weakening the material security boundary:

- Mutable-tree allocation metadata is now report-only.
- Path, physical identity, type, device/inode, ownership, permissions, role, scope, ACL/xattr posture, and per-grant custody remain acceptance-bearing.
- Regular-file and executable size, bytes, and digest remain exact.
- Replacement with the same reported directory size still fails.
- No read grant, PTY authority, overlay authority, canonicalization, comparison policy, or repository behavior widened.
- The failed A6 record remains a bounded tool causal rather than being promoted into a successful source control.
- Repository bytes and all prior sealed evidence remained unchanged.

The next step is the **complete fresh A6 policy-evidence refresh**, using a new evidence child and all five newly materialized controls. No more reconnaissance is needed before that run.

The failed A6 child must remain unsealed negative evidence; bounded successor causals cannot replace the fresh downstream controls.  The read-policy machinery also remains proof scaffolding rather than product architecture or authority. 

## Codex prompt: fresh Repair 10I-A6 policy refresh

```text
Permission is workspace-write for one new source-external evidence child only.

Objective

Execute, analyze, close out, and seal the complete fresh Repair 10I-A6
policy-evidence refresh using the sealed Repair 10I-A6R mutable-tree
read-policy successor.

Freshly materialize and independently qualify:

1. pristine final;
2. independent pristine final;
3. intentional mutant;
4. historical HEAD;
5. historical Repair 9 under its exact validation-harness overlay.

Run all five required semantic comparisons:

1. final ↔ fresh;
2. final ↔ intentional mutant;
3. mutant ↔ fresh;
4. HEAD ↔ final;
5. Repair 9 ↔ final.

Then derive the complete historical transition and hazard matrices for:

- HEAD → final;
- Repair 9 → final.

Use those fresh, independently qualified records to decide whether the
structural historical-directional no-regression policy can be frozen for a
later successor implementation.

This turn performs validation, evidence generation, deterministic analysis,
and policy freezing only.

Do not modify repository source.
Do not modify the sealed A6R successor.
Do not modify any predecessor evidence.
Do not resume, overwrite, or seal the failed A6 child.
Do not implement the historical comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole evidence writer.

Candidate repository

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as repository cwd or source root

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Sealed A5T4 repository-validation lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5C canonicalization successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A6O reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-historical-overlay-recon-8de797304ea9

Sealed A6O overlay successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Sealed A6R read-policy reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9

Sealed A6R mutable-tree successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-successor-closure-8de797304ea9

Failed and unsealed earlier A6 refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Required new A6 evidence child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9

## 1. Absolute physical-root lock

Before any substantive observation:

1. Component-walk and `lstat` CANDIDATE_R.
2. Require the exact physical path:
   `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
3. Require:
   - type: directory;
   - device: `16777234`;
   - inode: `122118502`;
   - mode: `0755`;
   - UID/GID: `501/20`.
4. Enter the candidate through an explicitly configured cwd.
5. Require physical `pwd -P` to equal CANDIDATE_R exactly.
6. Require CANDIDATE_R and PRIMARY_R to remain physically distinct siblings:
   - PRIMARY_R device/inode: `16777234/47685738`;
   - no equality;
   - no alias;
   - no nesting;
   - no same inode.

Inspect CANDIDATE_R/.git and require:

- regular pointer file;
- no final symlink;
- mode `0644`;
- size `123`;
- device/inode `16777234/122118504`;
- one link;
- SHA-256:
  `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419`;
- exact target:
  `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---external-tls-status-observation-v1`;
- common Git directory:
  `/Users/ds/Repositories/Execution Substrate/.git`.

Set for all Git observations:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Every Git command must use:

git -C "$CANDIDATE_R" ...

or an explicitly configured subprocess cwd equal to physical CANDIDATE_R.

No command may use PRIMARY_R as:

- cwd;
- Git `-C` target;
- source root;
- inventory root.

For inline Python:

- use `PYTHONDONTWRITEBYTECODE=1`;
- verify `os.getcwd()` before repository-relative access;
- import no executable module from an evidence child;
- create no `__pycache__` or `.pyc`.

Stop on any physical-root or Git-binding mismatch:

REPAIR10I_A6_WORKTREE_MISMATCH

## 2. Mandatory opening gate

Using candidate-rooted observations only, require:

- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- upstream:
  absent
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- repository inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- inventory size:
  `54314`
- membership:
  `389 total / 375 tracked / 14 nonignored untracked`
- tracked modifications:
  `22`
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require every governed source member to be a regular nonsymlink member under
the existing inventory contract.

Require the repository delta from sealed A5 to remain exactly the three
existing A5T4 test files recorded in the sealed A5T4 source inventory.

Require exact sealed A5T4:

- manifest SHA-256:
  `7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888`
- manifest size:
  `202930`
- payloads:
  `1000`
- directories:
  `188`
- repository T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`.

Bind the qualified A5T4 full-suite facts:

Tests:

- `2753 pass`
- `137 fail`
- `8 skip`

Packages:

- `14 pass`
- `11 fail`
- `23 skip`

Raw SHA-256:

`0a97bd3a3ca7e162feac63795da125dd05bae7d13987faa61e3712479df83d25`

A5P2 semantic SHA-256:

`f692595d3611e13ef90babafbdb8726407190155b02c0ae60d3c9a15152f57f8`

Producer and peer qualifications:

`qualified`

Unknown diagnostics:

`0`

Require exact sealed A5C:

- manifest SHA-256:
  `05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489`
- manifest size:
  `31421`
- payloads:
  `216`
- directories:
  `71`
- source T:
  `2c2d0b36f52d5949d023a36400f0e0748149875a`
- inventory:
  `810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9`.

Require exact sealed A6O reconnaissance:

- manifest SHA-256:
  `20852734748924f75194239767a9d47c102e4767a529dadbbb5e3c4c48461138`
- manifest size:
  `4031`
- payloads:
  `28`.

Require exact sealed A6O successor:

- manifest SHA-256:
  `ab54d9f980a810b87f318ecee10073c731044a111b7f5ba7e69b8893dedb388f`
- manifest size:
  `38321`
- payloads:
  `241`
- directories:
  `80`
- source T:
  `716d59b3e28ab4c77ae46af1ee44b28cd24ea77d`
- inventory:
  `f47e798ce2429d20f73791a68ced180b2f5cc6b693d072037885e319bd1f30cc`.

Require exact sealed A6R reconnaissance:

- manifest SHA-256:
  `12ec94fff28d4a861b92ec069abd90ddd1e39f9b026777799b585db755cfcb6c`
- payloads:
  `19`
- directories:
  `8`.

Require exact sealed A6R successor:

- manifest SHA-256:
  `fe8954e4401005e85059fc0d44684b89bce38c7019d239ebcd5dfa000030f983`
- manifest size:
  `26785`
- payloads:
  `193`
- directories:
  `28`
- source T:
  `50f08cc78fe8634488063853e43904a633261f51`
- source inventory:
  `56f20b54e4992c860598c6603563b4eea589421dff886c5d4002adcc9846c84f`
- source members:
  `12`.

A6R binaries:

repair10-runner:
`84afddf2657480661215557059de3eecbf74db8e9ec5f43f19ad883b7ddc1199`

repair10-compare:
`c9af21bd8841a55979c7a907a77195a03345eac6c83001651f11a09a0e7d2781`

repair10-semantic:
`fb438eaf872bc86310fd79b1820a2163aa8a2c9fc2fd5515cc22ad0f5fee2d9a`

repair10-fixture:
`d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4`

Recover and require their exact sizes from the sealed A6R report and manifest.

Require:

- A/B byte equality;
- inode-distinct copies;
- complete post-seal verification;
- all 32 read-policy causals;
- all 58 overlay causals;
- all seven A5C tests;
- A5P2 PTY/policy nonregression;
- bounded failed-A6 causal explicitly classified as non-substituting;
- cleanup and two absence epochs.

Require the exact A6R active 24-schema dialect:

Outer v5:

- `execution-substrate.repair10i.suite-spec.v5`
- `execution-substrate.repair10i.ab-suite-spec.v5`
- `execution-substrate.repair10i.suite-result.v5`
- `execution-substrate.repair10i.binding-recomputation.v5`
- `execution-substrate.repair10i.control-qualification.v5`
- `execution-substrate.repair10i.semantic-comparison-spec.v5`
- `execution-substrate.repair10i.semantic-comparison-result.v5`
- `execution-substrate.repair10i.semantic-comparison-custody.v5`

Command v3:

- `execution-substrate.repair10i.command-intent.v3`
- `execution-substrate.repair10i.command-result.v3`
- `execution-substrate.repair10i.terminal-reconciliation.v3`

Private PTY v2:

- `execution-substrate.repair10i.private-pty-command.v2`
- `execution-substrate.repair10i.private-pty-broker-journal.v2`
- `execution-substrate.repair10i.private-pty-allocation.v2`
- `execution-substrate.repair10i.private-pty-reconciliation.v2`

Read policy v2:

- `execution-substrate.repair10i.effective-read-policy.v2`

Unchanged v1:

- `execution-substrate.repair10i.control-observation.v1`
- `execution-substrate.repair10i.mutable-inventory.v1`
- `execution-substrate.repair10i.intentional-mutant-provenance.v1`
- `execution-substrate.repair10i.validation-harness-overlay-provenance.v1`
- `execution-substrate.repair10i.go-test-semantics.v1`
- `execution-substrate.repair10i.byte-capture.v1`
- `execution-substrate.repair10i.byte-comparison-spec.v1`
- `execution-substrate.repair10i.byte-comparison-result.v1`

Require strict rejection of mixed prior and current acceptance chains.

Require the failed earlier A6 child to remain:

- present;
- unsealed;
- without evidence manifest or detached digest;
- byte-exact from opening through closing.

Reverify:

- `findings/fresh-validation-block-v1.json`
- `closeout/validation-blocked-closeout-v1.json`
- pristine-final suite specification;
- effective-read policies;
- command intents/results;
- terminal reconciliation;
- raw streams through EOF;
- semantic envelope;
- producer qualification;
- peer blocked qualification;
- resource ledger;
- cleanup and two absence epochs.

Require the new A6 target to be absent.

Stop on any mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

## 3. Evidence-child creation

After the opening gate, create the new A6 child exclusively under umask 077.

Use exactly:

opening/
tool/
sources/
commands/
controls/
validation/
comparisons/
analysis/
findings/
closeout/

All directories mode `0700`.

All files regular, single-link, nonsymlink, mode `0600` or `0700` as intended.

No hardlinks.

Do not import executable modules from predecessor evidence children.

Copy the sealed A6R A and B binaries independently into private tool roots.

Require:

- origin-to-copy byte equality;
- A/B byte equality;
- every copied binary inode distinct;
- one link;
- expected mode;
- no shared writable tool state.

No repository or successor source file may be edited.

## 4. A6R successor hard gate

Before creating any source control:

1. Verify all 12 A6R source members.
2. Verify the exact four-file A6O→A6R delta.
3. Verify all four A6R binary identities.
4. Reopen and verify:
   - active 24-schema dialect;
   - `effective-read-policy.v2`;
   - complete outer v5 chain;
   - mutable-tree stable/volatile field contract;
   - all 32 read-policy causals;
   - failed-A6 bounded causal;
   - all 58 overlay causals;
   - bounded Repair 9 overlay qualification;
   - historical HEAD no-overlay qualification;
   - final/fresh/mutant overlay-free source-binding causals;
   - A5C observability-v2 causals;
   - A5P2 PTY and execution-policy causals;
   - cleanup and absence records.
5. Require:
   - old read-policy and outer source-binding records cannot qualify current
     semantics;
   - producer captions remain non-authoritative;
   - mutable-tree allocation metadata is report-only;
   - stable identity/security fields remain acceptance-bearing;
   - regular-file/executable size and digest remain exact;
   - no repository, read-scope, PTY, overlay, semantic, or comparison-policy
     widening.

Stop on mismatch:

REPAIR10I_A6_SUCCESSOR_INPUT_MISMATCH

## 5. One-attempt execution rule

Each acceptance-bearing source control receives exactly one full-suite
execution.

Do not retry or replace a launched full-suite control.

Do not choose among multiple successful or failed outputs.

Prelaunch construction failure stops before execution.

A full-suite failure, qualification failure, unexpected unknown, or comparison
failure triggers the applicable mandatory-stop verdict.

Retain every prelaunch, failed, and superseded attempt separately.

## 6. Exact five source controls

### 6.1 Final

- source class:
  `pristine-final`
- validation overlay:
  absent
- intentional-mutant provenance:
  absent
- base == effective
- T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- members:
  `389`.

### 6.2 Fresh independent final

- source class:
  `pristine-final`
- overlay:
  absent
- mutant provenance:
  absent
- same T, inventory, and membership as final;
- physically independent source, Git, caches, runtime, command, evidence,
  PTY, listener, socket, process, and control state.

Do not introduce a separate fresh-final source class.

### 6.3 Intentional mutant

- source class:
  `intentional-mutant`
- validation overlay:
  absent
- base:
  exact final source.

Recover the complete exact active mutant contract from sealed A6R source,
tests, and bounded mutant causals.

Expected owning path:

`es/externaltls/internal/statusobservation/remoteobserver/observe_test.go`

Expected owning test:

`TestRepair10IStructuralPrivacyProjectionCausalControlsV1`

Do not reconstruct the mutation from memory or this abbreviated description.

Require:

- exact mutation provenance frozen before execution;
- exactly one existing changed path;
- same logical mode;
- no addition, deletion, rename, or second path;
- exact base/effective T and inventory;
- exact declared diagnostic tuple;
- exact declared test and package terminal delta;
- source frozen before execution.

Stop if the active mutant contract is ambiguous.

### 6.4 Historical HEAD

- source class:
  `historical-head`
- validation overlay:
  absent
- mutant provenance:
  absent
- base == effective
- T:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- inventory:
  `291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a`
- members:
  `375`.

### 6.5 Historical Repair 9

- source class:
  `historical-repair9`
- intentional-mutant provenance:
  absent.

Base:

- T:
  `0ea3b661f09e73e1126bae0f6e993e22bbf21198`
- inventory:
  `7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e`
- members:
  `382`.

Overlay:

- ID:
  `repair10i-historical-repair9-a5t4-validation-harness-overlay-v1`
- schema:
  `execution-substrate.repair10i.validation-harness-overlay-provenance.v1`
- recipe SHA-256:
  `811c420adc61f33a4117ae553863d194d021ede9f0a8d0ae5dfee9c3fe0e64e5`
- exact one-file transformation and all recipe facts must match sealed A6O.

Effective:

- T:
  `4bd05d4f949e6239ff7aaeb68ac229143ddeff6e`
- inventory:
  `e17a7732e260a8af7305d5e130bbbc2cc9608175390c2d763f8c655471ea6583`
- members:
  `382`.

Classification:

`historical source under validation-harness overlay`

Explicit nonclaims:

- effective bytes are not historical product source;
- overlay is not a product improvement;
- overlay is not historical runtime behavior;
- overlay is not an intentional mutant.

## 7. Physical control isolation

Materialize all five controls in physically disjoint, short, exclusive private
roots.

Each independently owns:

- base source where applicable;
- effective source;
- Git administration and object store where required;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- runtime root;
- command and evidence roots;
- PTY/broker state;
- listener/socket state;
- process tree.

No writable state may be shared.

Require:

- no hardlinks;
- no cross-control inode collision;
- no path equality or containment across mutable control roots;
- no shared Git alternate or mutable object store;
- no cache alias;
- no runtime, PackageFloor, evidence, socket, listener, PTY, or process alias.

For Repair 9, base and effective source roots must be physically distinct and
nonaliasing.

## 8. Source-specific path, read, and PTY policies

Before launching each control:

1. Enumerate its active tests.
2. Inspect its exact source-specific PTY helper call graph.
3. Declare finite PTY roles and counts.
4. Compute every prospective Unix-socket and broker path.
5. Require every path at most 100 bytes.
6. Construct `effective-read-policy.v2`.
7. Classify every grant by exact grant kind and role.
8. Retain stable and report-only observations separately.
9. Omit PTY capability from commands that do not require it.
10. Retain the source evidence supporting every request and grant.

Do not reuse the final-source PTY or read-policy inventory blindly for
historical controls.

Reject every undeclared PTY request.

Keep generic `/dev/fd/*` denied.

Do not admit any new path outside the sealed A6R policy model.

## 9. Exact suite execution and qualification

Use the exact A6R v5 suite-spec contract and all mandatory preflight commands.

The acceptance-bearing full-suite command for each control is literal:

go test -json -count=1 -p=1 -parallel=1 ./...

Use pinned Go 1.26.5 and the established clean offline environment.

Expected process exit membership:

{0,1}

Exit membership alone never qualifies a control.

Distribute controls across both A6R tool sides.

Require every control to receive opposite-side external raw re-extraction and
qualification.

For every control require:

- source class valid;
- exact base identity;
- exact overlay or mutant provenance where applicable;
- exact effective identity;
- source frozen before execution;
- complete raw stdout/stderr through EOF;
- exactly one Wait;
- complete terminal reconciliation;
- complete resource disposition;
- no forced cleanup;
- no survivor;
- no malformed or truncated JSONL;
- no duplicate or missing lifecycle record;
- semantic integrity pass;
- zero unknown diagnostics;
- producer and peer semantic bytes equal;
- producer and peer qualifications both `qualified`;
- suite and logical fingerprints bound;
- read-policy v2 structurally recomputed by the peer;
- overlay or mutant provenance independently recomputed;
- PTY-policy fingerprint bound;
- every declared PTY request consumed exactly;
- no undeclared PTY request;
- direct `/dev/ptmx` denied;
- arbitrary `/dev/fd/*` denied;
- unrelated terminal inaccessible;
- actual PTY EOF/EIO reconciled;
- every socket path at most 100 bytes;
- two cleanup epochs;
- verified-empty next-command barrier.

Mutable-tree report-only differences may not make the control unqualified.

Stable identity or file-byte differences must make the control unqualified.

## 10. Final/fresh acceptance gate

Execute final and fresh first.

Before continuing to mutant or historical controls, require:

- lifecycle equal;
- diagnostics equal;
- canonical semantics equal;
- logical suite fingerprints equal;
- read-policy semantics equal;
- both independently qualified;
- zero unknowns;
- accepted equality true;
- outcome:
  `qualified-equal`;
- comparator exit:
  `0`.

Require exact terminal identity-set equality.

Expected counts:

Tests:

- `2753 pass`
- `137 fail`
- `8 skip`

Packages:

- `14 pass`
- `11 fail`
- `23 skip`

Counts alone are insufficient.

Raw output bytes may differ.

Any lifecycle, terminal, canonical diagnostic, unknown, qualification,
read-policy, custody, or resource difference stops A6:

REPAIR10I_A6_VALIDATION_BLOCKED

## 11. Intentional-mutant gates

After final/fresh succeeds, execute the mutant.

Require final ↔ mutant:

- both controls qualified;
- zero unknowns;
- exact declared diagnostic tuple;
- exact declared test and package terminal delta;
- no additional lifecycle or diagnostic difference;
- accepted equality false;
- outcome:
  `qualified-different`;
- comparator exit:
  `2`.

Require mutant ↔ fresh:

- both controls qualified;
- zero unknowns;
- exact inverse declared delta;
- no additional difference;
- outcome:
  `qualified-different`;
- comparator exit:
  `2`.

Require exact mutant provenance to be frozen before execution and independently
recomputed by the peer.

Any mismatch stops A6:

REPAIR10I_A6_VALIDATION_BLOCKED

## 12. Historical-control qualification

Only after final/fresh and both mutant comparisons pass, execute historical
HEAD and Repair 9.

Require each historical control to have:

- exact source class;
- exact base identity;
- exact effective identity;
- exact overlay absence or presence;
- exact provenance;
- zero unknowns;
- producer qualification:
  `qualified`;
- peer qualification:
  `qualified`;
- complete raw/semantic custody;
- complete terminal/resource reconciliation;
- no survivor or forced cleanup.

Repair 9 qualification must independently reconstruct:

- exact base source;
- exact overlay recipe;
- exact effective source;
- frozen-before-execution posture.

An effective-source caption without independently proven base and recipe is
insufficient.

## 13. Existing historical comparator execution

Run the sealed A6R comparator for:

- HEAD ↔ final;
- Repair 9 ↔ final.

Retain:

- comparison spec;
- custody;
- result;
- process exit;
- reason codes;
- lifecycle differences;
- diagnostic differences;
- qualification references;
- read-policy references;
- Repair 9 overlay projection.

The current historical acceptance policy is not A6 readiness authority.

A current historical comparator exit of `1` may still permit structural
analysis only when:

- both controls are independently qualified;
- unknown count is zero;
- raw and semantic custody are complete;
- terminal/resource reconciliation passes;
- the rejection is exclusively the current historical-policy mismatch.

Any source, overlay, read-policy, qualification, unknown, integrity, custody,
resource, or late-fault failure stops A6:

REPAIR10I_A6_VALIDATION_BLOCKED

## 14. Deterministic transition analyzer

Create one versioned, source-external analyzer inside the A6 evidence child.

It is evidence tooling only and is not successor authority.

Retain:

- exact source;
- source SHA-256;
- tests;
- argv;
- cwd;
- environment;
- complete outputs.

Run it twice over the same sealed inputs and require byte-identical canonical
output.

### 14.1 Identity model

Test/subtest identity:

- package;
- test/subtest;
- occurrence.

Package identity:

- package;
- empty test;
- occurrence.

Sort by raw UTF-8 bytes.

Canonical arrays must include:

- count;
- canonical byte length;
- SHA-256;
- complete embedded identity list.

### 14.2 Complete test transition matrix

For HEAD→final and Repair-9→final independently compute:

- absent→pass
- absent→fail
- absent→skip
- pass→pass
- pass→fail
- pass→skip
- pass→absent
- fail→pass
- fail→fail
- fail→skip
- fail→absent
- skip→pass
- skip→fail
- skip→skip
- skip→absent.

### 14.3 Complete package transition matrix

Compute the same matrix for package terminals.

Separately classify:

- exact package `[no test files]` skip;
- package fail with failing test terminals;
- package failure abort;
- setup/build failure where raw evidence supports it;
- unclassified package failure.

### 14.4 Integrity and hazard arrays

Compute exact baseline/final deltas for:

- panic;
- race;
- warning;
- fatal runtime;
- unknown diagnostics;
- malformed stream;
- truncated stream;
- duplicate start/run/terminal;
- missing start/run/terminal;
- terminal without start;
- impossible association;
- mapping errors;
- package failure aborts;
- final-exit inconsistency.

### 14.5 Final-only passing identities

For every absent→pass test or package:

- retain exact identity;
- prove final terminal pass;
- bind recognized diagnostics;
- require zero unknown diagnostics;
- require no hazardous diagnostic class.

Do not use a finite name allowlist.

Exact observed arrays are evidence, not policy authority.

### 14.6 Repair 9 overlay accounting

Retain both:

- historical base identity;
- effective overlay identity.

Do not count the overlay as:

- a product improvement;
- a test addition;
- historical product source;
- final-side behavior.

Require the overlay to preserve the test-declaration universe.

## 15. Candidate structural historical policy

Adjudicate HEAD→final and Repair-9→final independently.

### Test/subtest transitions admitted

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

### Test/subtest transitions blocked

- absent→fail
- absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent

### Package transitions admitted

- absent→pass
- pass→pass
- fail→fail
- fail→pass
- skip→skip
- skip→pass

Admit absent→skip only when all are true:

- package absent in baseline;
- final has exactly one package skip;
- exact raw `[no test files]` evidence exists;
- zero test run/terminal identities exist for the package;
- zero unknown diagnostics;
- zero package abort;
- qualification, terminal reconciliation, custody, read policy, and resources
  are clean.

### Package transitions blocked

- absent→fail
- unclassified absent→skip
- pass→fail
- pass→skip
- pass→absent
- fail→skip
- fail→absent
- skip→fail
- skip→absent
- any package abort or setup/build uncertainty.

### Independent hazard blockers

Block on any:

- new panic;
- new race;
- new warning;
- new fatal runtime;
- new unknown diagnostic;
- malformed or truncated stream;
- missing, duplicate, or impossible lifecycle state;
- new package abort;
- terminal disappearance;
- unexplained final-exit inconsistency.

Aggregate exit equality is not required.

A baseline exit `1` may become final exit `0` through clean admitted
improvements.

No finite final-only identity allowlist.

No policy generated from one run’s observed pass set.

Any number of new passes cannot mask one blocked transition or hazard.

## 16. Policy decision

If both historical directions have:

- independently qualified controls;
- zero unknowns;
- zero blocked transitions;
- zero hazards;
- zero unexplained disappearance;
- deterministic complete matrices;

freeze the future historical-comparator contract.

Do not implement it.

### Schema-version rule

A6R already uses active v5 source-binding and semantic-comparison schemas.

Do not reuse an active v5 schema identifier with changed historical-policy
meaning.

Inspect the exact active producer/consumer graph and freeze the next unused
generation only for records whose acceptance meaning changes.

The next semantic-comparison generation is likely v6, but derive it rather
than assuming it.

Determine separately whether changes are required to:

- semantic-comparison spec;
- semantic-comparison result;
- semantic-comparison custody;
- runner schema registry;
- CLI dispatch;
- suite result;
- qualification;
- binding recomputation;
- other records.

Freeze:

- exact future schema IDs;
- complete fields;
- producer/consumer map;
- strict-decoding behavior;
- current historical-policy parse-only/nonqualifying behavior;
- exact future touched-file set;
- exact reason codes;
- exact exit policy;
- complete causal matrix.

If either historical direction contains a real blocked transition or hazard,
seal the complete evidence and return policy blocked without inventing an
exception.

## 17. Required future historical result

Freeze a future embedded historical analysis containing:

- baseline exit code;
- final exit code;
- accepted historical-no-regression boolean;
- test transition sets;
- package transition sets;
- final-only passing tests;
- final-only passing packages;
- admitted package-no-test records;
- blocked transitions;
- improvements;
- inherited failures;
- missing baseline identities;
- package-failure-abort deltas;
- hazardous diagnostic-class deltas;
- unknown and lifecycle-integrity deltas;
- historical base identity;
- overlay ID and effective identity where applicable;
- read-policy qualification references.

Every transition set contains:

- from action;
- to action;
- count;
- complete identities;
- canonical byte length;
- canonical SHA-256.

External references cannot be the sole acceptance record.

## 18. Required reason and exit freeze

Recover all current A6R reason codes.

Add only source-grounded historical reason codes.

At minimum distinguish:

- `historical-no-regression-satisfied`
- `historical-no-regression-not-satisfied`
- `final-only-pass-observed`
- `final-only-package-pass-observed`
- `package-no-tests-admitted`
- `inherited-failure-observed`
- `baseline-fail-became-pass`
- `baseline-skip-became-pass`
- `final-only-fail`
- `final-only-test-skip`
- `final-only-package-fail`
- `final-only-package-skip-unclassified`
- `final-only-package-abort`
- `baseline-pass-regressed`
- `baseline-terminal-disappeared`
- `baseline-fail-became-skip`
- `baseline-skip-became-fail`
- `new-panic`
- `new-race`
- `new-warning`
- `new-fatal-runtime`
- `malformed-stream`
- `truncated-stream`
- `unknown-diagnostic`
- `lifecycle-integrity-failed`
- `overlay-qualified`
- `overlay-qualification-failed`
- `read-policy-qualification-failed`.

Exit policy to freeze:

- `0`:
  only `qualified-equal` with accepted equality true;
- `2`:
  both controls qualified, zero unknowns, and either:
  - exact intentional-mutant difference; or
  - accepted historical-directional no-regression;
- `1`:
  every qualification, overlay, read-policy, custody, integrity, unknown,
  policy, or late fault.

Do not derive exit `2` from `errors.Is` over a joined mismatch error.

## 19. Future causal matrix to freeze

Freeze future tests for at least:

1. Hundreds of arbitrary absent→pass tests admitted without a name allowlist.
2. Arbitrary final-only passing subtests admitted.
3. Final-only test fail blocks.
4. Final-only test skip blocks.
5. Final-only package fail blocks.
6. Final-only package abort blocks.
7. Pass→fail blocks.
8. Pass→skip blocks.
9. Pass→absent blocks.
10. Fail→pass admitted and reported.
11. Skip→pass admitted and reported.
12. Fail→skip blocks.
13. Skip→fail blocks.
14. Fail→absent blocks.
15. Skip→absent blocks.
16. Exact package no-test skip admitted only with bound raw proof.
17. No-test marker/package/test-count/diagnostic mutation blocks.
18. New passes cannot mask one blocked transition.
19. New panic, race, warning, fatal runtime, unknown, malformed, truncated,
    missing, duplicate, impossible, or package-abort state blocks.
20. HEAD and Repair 9 evaluated independently.
21. Reversed historical direction rejected.
22. Repair 9 overlay qualification required before historical policy.
23. Overlay bytes receive no product-improvement credit.
24. Current historical-policy schemas become parse-only/nonqualifying.
25. Final/fresh and intentional-mutant policies remain unchanged.
26. Transition arrays, lengths, and hashes deterministic.
27. Clean fail→pass may improve aggregate exit.
28. Test rename is pass→absent plus absent→pass and blocks.
29. Deleting a failing baseline test is fail→absent and blocks.
30. Old/new schema mixtures reject.
31. Read-policy v2 failure blocks historical acceptance.
32. Mutable-tree report-only changes do not alter transition evidence once
    qualification succeeds.

## 20. Security and authority controls

Require:

- repository and successor remain read-only and byte-exact;
- no generic `/dev/fd` grant;
- no broad device or terminal grant;
- no product/public schema change;
- no product execution-authority change;
- no `.out` traversal or write;
- no live PackageFloor or fixed-runtime slot access;
- no credential, keychain, TLS, SPIFFE, Vault, endpoint, or unrelated-user
  exposure;
- no raw PTY payload retained;
- overlay remains validation scaffolding only;
- transition analyzer remains evidence tooling only;
- generated evidence remains non-authoritative.

## 21. Evidence requirements

Retain:

- complete physical-root and candidate capsule;
- command-root audit;
- A6R source and binary hard gate;
- exact five base/effective source identities;
- Repair 9 overlay provenance;
- intentional-mutant provenance frozen before execution;
- source-specific read, PTY, and path policies;
- suite specs;
- command intents, argv, cwd, environment;
- rendered profiles and effective policies;
- raw stdout/stderr through EOF;
- command, terminal, read-policy, and resource records;
- PTY journals;
- producer and peer semantics;
- producer and peer qualifications;
- all five comparator records;
- deterministic analyzer source and tests;
- complete transition and hazard arrays;
- policy adjudication;
- frozen future contract if supported;
- failed and superseded attempts;
- cleanup and two absence epochs;
- final report;
- exact path/mode/size/hash inventory.

No raw PTY payload.
No sensitive environment dump.

## 22. Closeout and sealing

Require:

- repository T/inventory/membership unchanged;
- exact three-file repository delta unchanged;
- candidate root and `.git` binding unchanged;
- branch/HEAD/parent/tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged zero;
- A5T4, A5C, A6O reconnaissance, A6O successor, A6R reconnaissance, A6R
  successor, failed prior A6, and all predecessors unchanged;
- no predecessor bytecode or cache;
- no private source, base/effective tree, Git store, cache, runtime, PTY,
  process/group, worker, socket, listener, descriptor, build, analyzer, or
  report root remains;
- two fresh absence epochs pass;
- command-root audit proves no command used PRIMARY_R as cwd or source root.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 23. Mandatory stop conditions

Stop on:

- physical-root mismatch;
- baseline or lineage mismatch;
- A6R input mismatch;
- missing or ambiguous source identity;
- overlay reconstruction mismatch;
- intentional-mutant ambiguity;
- final/fresh difference;
- final/fresh terminal universe differs from A5T4;
- mutant delta differs;
- any control unqualified;
- read-policy verification failure;
- unknown diagnostic;
- malformed or incomplete lifecycle;
- undeclared PTY request;
- socket path above 100 bytes;
- direct PTY allocation succeeds;
- unrelated terminal accessible;
- historical qualification or custody failure;
- analyzer nondeterminism;
- unresolved historical transition;
- survivor, forced cleanup, or sealing failure.

## 24. Verdicts

Physical-root mismatch:

REPAIR10I_A6_WORKTREE_MISMATCH

Opening or lineage mismatch:

REPAIR10I_A6_BASELINE_MISMATCH

A6R successor input mismatch:

REPAIR10I_A6_SUCCESSOR_INPUT_MISMATCH

Fresh validation, comparison, or qualification failure:

REPAIR10I_A6_VALIDATION_BLOCKED

Controls qualify, but a real historical transition or hazard blocks the
candidate structural policy:

REPAIR10I_A6_POLICY_BLOCKED

Complete refresh and supported future policy freeze:

REPAIR10I_A6_POLICY_REFRESH_SEALED_READY_FOR_HISTORICAL_COMPARATOR_IMPLEMENTATION

A validation-blocked child remains unsealed.

A policy-blocked result may be sealed only when:

- all five controls independently qualified;
- final/fresh and both mutant comparisons passed;
- both historical controls independently qualified;
- the blocker is a completely observed source-grounded transition or hazard;
- analyzer, cleanup, and evidence closeout are complete.

## 25. Required success report

Include:

1. Repository and physical-root opening/closing identities.
2. A6R successor source and A/B binary identities.
3. Exact active 24-schema dialect.
4. Exact five base/effective source identities.
5. Repair 9 overlay provenance and qualification.
6. Intentional-mutant provenance.
7. Final/fresh raw and semantic identities.
8. Final/fresh accepted equality and exit `0`.
9. Both mutant comparison results and exit `2`.
10. Historical control qualifications.
11. Current comparator factual historical outputs.
12. Complete test/package transition matrices for both directions.
13. Complete hazard and integrity arrays.
14. Canonical array lengths and hashes.
15. Package no-test evidence.
16. Structural-policy adjudication independently for HEAD and Repair 9.
17. Explicit recognition that v5 is already active.
18. Frozen next schema generations, fields, reason codes, exits, touched files,
    and causal matrix when supported.
19. Manifest SHA-256, size, and payload count.
20. Cleanup and two absence epochs.
21. Command-root audit.
22. Explicit statement that no historical-comparator implementation occurred,
    B6 was not started, product A/B was not run, and no snapshot or audit
    occurred.

No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After A6

If A6 returns:

```text
REPAIR10I_A6_POLICY_REFRESH_SEALED_READY_FOR_HISTORICAL_COMPARATOR_IMPLEMENTATION
```

the next tranche is a bounded successor implementation of the frozen historical policy. That implementation will change successor bytes again, so it must receive new validation and later a fresh independent audit. Implementation validation and independent audit remain separate engagements. 

If A6 returns `POLICY_BLOCKED`, the observed transition or hazard—not the proof harness—must determine the next repair or policy decision.

### Sources

- Codex’s `REPAIR10I_A6R_MUTABLE_TREE_READ_POLICY_PATCH_SEALED_READY_FOR_FRESH_A6_RESTART` report supplied in the current turn.
- Milestone 0 proof-harness and evidence-authority boundary. 
- Sealed A2 bounded-causal/downstream-control distinction. 
- Governed Execution implementation, repair, and independent-audit lifecycle. 
- Provenance establishes exact bytes, not correctness or authority. 

**Confidence**

- Provenance interpretation of the A6R report: **0.998**
- Validation-readiness confidence: **0.985**
- Confidence that the fresh five-control A6 restart is now the correct next gate: **0.999**
- Confidence in the structural historical policy before fresh evidence: **0.86**
- Confidence that current v5 schemas must not be repurposed for later historical-policy semantics: **0.995**
