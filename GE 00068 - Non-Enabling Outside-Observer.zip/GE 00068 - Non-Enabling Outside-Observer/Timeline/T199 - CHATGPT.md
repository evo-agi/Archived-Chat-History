## Assessment

This is the first clean audit in the recent sequence that establishes a **real source defect**, not a process or provenance failure.

Opening and closing provenance matched; the audit root was atomically allocated; all four auditors completed; the source delta matched; containment, foreign-final collision handling, snapshot/depth behavior, hooks, schema, A6D, amendment, synthetic A6, and SEC-02 all passed.  

The blocker is specific:

> After the caller’s final path checks, the output directory was renamed and replaced. The exclusive rename still committed through the held descriptor into the **moved directory**, while the declared record pathname remained empty. The caller nevertheless returned `0` and reported acceptance. 

That makes the current successor **BLOCKED**. Commit and A6 restart remain prohibited.

### Why another small rebind patch is the wrong response

An extra pathname check before rename would merely move the race window. A post-rename check can detect displacement, but by then a canonical JSON record saying `accepted` has already been published elsewhere. Removing it afterward would create a transient accepted record and make the supposed commit point provisional again.

The underlying conflict is between:

- publishing files through a held directory object; and
- promising that those files are committed to a mutable absolute pathname.

A same-privilege process can rename an ancestor between any user-space check and a descriptor-relative commit. No finite sequence of pre/post `stat` checks makes that absolute pathname immutable.

The repair therefore needs a **publication-contract decision**, not another audit prompt and not a one-line path check. The audit itself classifies the defect as repairable source-external record custody rather than an authority redesign. 

## Recommended path

Run one bounded, read-only reconnaissance before authorizing mutation.

The provisional primary should be **atomic bundle-directory publication**:

- `--record` still names the final JSON file.
- Its immediate parent becomes the invocation’s output bundle and must initially be absent.
- The caller builds all three outputs inside a private staging directory.
- The caller commits the complete directory in one exclusive root-relative rename to the declared bundle-parent path.
- The source and destination of that rename are resolved from a stable root descriptor, not the already-opened output-directory descriptor.
- The record JSON, stdout sidecar, and stderr sidecar therefore become visible together.
- The absolute-path guarantee is explicitly a **commit-time guarantee**. Later mutation by a trusted principal remains outside the supported-local proof.

This is a semantic destination-contract change. It may require a caller-record or publication-protocol version bump even if the verifier protocol and the 25 payload fields remain unchanged. That decision should be frozen before implementation.

A held-directory/inode-custody interpretation is a possible fallback, but it would make `--record` only an opening locator and would weaken the practical meaning of the record path. I do not recommend silently taking that route.

## Codex prompt — record-custody reconnaissance

```text
MANDATORY RESPONSE FORMAT

Embed the complete reconnaissance report inline in Markdown. Local evidence
links may be supplemental, but must not replace any report section.

Return exactly one:

RECORD_CUSTODY_RECONNAISSANCE_READY
RECORD_CUSTODY_RECONNAISSANCE_BLOCKED
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH READ-ONLY RECONNAISSANCE

This is design reconnaissance after a qualifying independent audit returned
BLOCK for a destination-parent displacement defect.

Do not implement, edit, format, clean supplied roots, stage, commit, push,
create a PR, merge, install, deploy, restart A6, invoke product or live-service
paths, or contact the network.

Do not resume the blocked audit or any implementation attempt.

No nested subagents.

## 1. Objective

Freeze the smallest technically sound publication and custody contract for the
Evidence Verification v1 source-external caller after the audit proved that the
current caller can:

1. complete its final pathname checks;
2. have the held output directory moved and replaced;
3. publish through the held directory descriptor into the moved directory;
4. return success and report acceptance while the declared `--record` pathname
   remains absent.

Do not patch around the race. Determine which publication model can honestly
support a persistent record contract under the supported-local threat model.

## 2. Exact frozen inputs

Repository:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected repository identity:

- branch:
  codex/evidence-verification-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- canonical manifest SHA-256:
  4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537
- tracked binary-diff SHA-256:
  b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb
- governed inventory:
  477 exact objects

Current producer repair:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-repair-c24d79991539-v1

CURRENT_SUCCESSOR=$REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12_atomic_publish.py

Expected current successor:

- size:
  45678
- SHA-256:
  3c06a1c8dae17ba1a8f21fa50fde8b9dea9b4a5c274c740b761774c60bedc631

Current base:

CURRENT_BASE=$REPAIR_ROOT/source/base_caller_exact.py

Expected current base:

- size:
  33758
- SHA-256:
  c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24

Current source delta:

CURRENT_DELTA=$REPAIR_ROOT/provenance/source-delta.diff

Expected delta SHA-256:

a9f1f7d3ec09317126b575ade443fe89e7b9a7d31db7a0466d63c452e0bd3bd2

Qualifying blocking audit:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-evidence-atomic-publication-independent-audit-58b1f0fe386b-mib0s7im

Inspect at minimum:

- displacement_causal.py
- displacement_causal.json
- foreign_collision_causal.json
- containment_causal.json
- capability_causal.json
- hook_causal.json
- causals/publication-failure-matrix-fresh.json
- causals/depth-boundaries-fresh.json
- causals/successor-snapshot-matrix-fresh.json
- sealed_compatibility_causal.json
- synthetic_a6_causal.json
- validation/caller-negatives-fresh.json
- causals/destination-negatives-fresh.json
- auditors/contract.md
- auditors/filesystem.md
- auditors/snapshot.md
- auditors/security.md
- closing_provenance.json
- final_inventory.json

The audit verdict and causal are frozen facts:

- verdict: BLOCK;
- held-directory inode:
  177420060;
- replacement-directory inode:
  177420067;
- staged/final record inode:
  177420066;
- accepted JSON and sidecars landed in the moved original directory;
- the replacement directory was empty;
- the declared final pathname was absent;
- caller `main()` returned 0;
- shared stdout reported acceptance;
- verifier exit was 0.

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier:

- size:
  40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected Python:

- version 3.13.4;
- size 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Create a fresh, atomically allocated reconnaissance root under
`/Users/ds/Downloads` only after opening provenance passes.

## 3. Posture and process boundary

This turn is read-only with respect to every supplied root.

Audit-owned probe sources, fixtures, outputs, and temporary directories are
allowed only under the fresh reconnaissance root.

Repository Git commands must use:

git -C "$IMPL_R" ...

with cwd IMPL_R and explicit:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

An inherited cwd or a bare `pwd` is administrative only. It is not a process
blocker. Substantive relative filesystem operands are prohibited until cwd is
explicitly changed to IMPL_R or the reconnaissance root.

## 4. Four read-only perspectives

Start three distinct auditors concurrently:

1. Filesystem and Darwin VFS/rename semantics.
2. Caller contract, schema, compatibility, and versioning.
3. Security/threat model and custody guarantees.

After one completes, start a fourth:

4. Migration, validation matrix, provenance, and evidence compatibility.

No nested delegation. Auditors run no Git, supplied-root writes, tests against
supplied roots, network calls, or repository-module imports.

Preserve disagreements.

## 5. Models to adjudicate

Evaluate every model below. Do not silently combine models.

### Model A — More checks around the existing file-level commit

Examples:

- one more path rebind immediately before rename;
- post-rename path rebind;
- rollback or unlink after a failed post-rename check;
- repeated check loops.

Determine whether any variant prevents a transient or persistent accepted record
outside the declared pathname. Reject it if it merely moves the race window or
makes the current commit point provisional.

### Model B — Root-relative final-file rename

Stage the JSON under private custody, then use a root descriptor and the full
declared destination path for the destination side of one exclusive rename.

Adjudicate:

- whether stdout/stderr sidecars can remain consistently co-located;
- whether parent displacement can split the three outputs;
- whether the result can have one irrevocable commit point;
- whether it preserves the existing `--record` contract.

### Model C — Atomic bundle-parent publication

Provisional primary.

Interpret the immediate parent of `--record` as an invocation bundle directory.

Candidate contract:

- the bundle directory must be absent initially;
- its grandparent must be an admitted existing directory;
- build JSON, stdout, and stderr inside a private sibling staging directory;
- validate the complete staged bundle;
- commit the whole directory with one exclusive `renameatx_np(RENAME_EXCL)`;
- resolve source and destination from a root descriptor and full root-relative
  paths at commit, not through a previously held bundle-parent descriptor;
- all three public files appear together;
- the JSON path after commit is the original `--record` path;
- no acceptance-bearing operation occurs after the directory rename;
- later mutation by a trusted principal is outside the bounded guarantee.

Probe and adjudicate:

- grandparent moved and replaced before commit;
- grandparent moved during commit;
- foreign final bundle already present;
- schema-valid foreign bundle;
- stage and final inode identity;
- directory and file modes;
- retry after success and every failure;
- cleanup and failed-attempt evidence;
- whether the three existing outputs and redaction posture can be preserved.

### Model D — Directory-object/inode custody

Treat `--record` as an opening locator only. Acceptance is bound to the opened
directory object, not continuing lexical pathname resolution.

Determine:

- what persistent reference a consumer receives;
- how the record can be located after the directory moves;
- whether existing shared stdout and v3 fields can express custody honestly;
- whether this weakens the existing record-path contract.

Do not select this model merely because the current caller already behaves this
way.

### Model E — Trusted stable destination ancestry

Place the record parent, all mutable ancestors, and every principal able to
rename them inside the supported-local trusted boundary.

Determine:

- whether this is consistent with the existing trusted-host contract;
- whether it makes the record destination useful as audit evidence;
- whether it contradicts the project’s existing fail-closed race tests;
- the exact unsupported-host boundary and required documentation;
- whether source changes remain necessary.

### Model F — Dedicated writer, privileged helper, or native launcher

Evaluate only as a proportionality fallback.

Determine:

- new owner and authority;
- source/binary/build provenance;
- host and privilege requirements;
- why Models C or E are insufficient.

Do not select it without demonstrated necessity.

## 6. Required parent probes

Run bounded, audit-owned probes using the pinned host and standard library or
small ctypes sources. Do not mutate supplied roots.

At minimum probe:

1. `renameatx_np(RENAME_EXCL)` with source and destination relative to a held
   directory descriptor after that directory is moved.
2. Source under a held descriptor and destination resolved root-relatively.
3. Source and destination both resolved root-relatively.
4. Atomic rename of a complete directory containing three regular files.
5. Grandparent rename and replacement immediately before directory commit.
6. Grandparent rename synchronized during directory commit.
7. Occupied final bundle containing arbitrary bytes.
8. Occupied final bundle containing accepted-looking JSON.
9. Same-basename retry after success.
10. Partial staged bundle and retry.
11. Whether an accepted bundle can be located at the declared JSON path at the
    exact commit observation.
12. Whether any proposed postcommit check can fail after accepted bytes become
    externally visible.

Retain exact probe source, argv, environment, results, filesystem identities,
and cleanup.

## 7. Threat-model freeze

State exactly which actors may:

- mutate the target;
- mutate the record bundle;
- rename the bundle or its ancestors;
- race publication;
- modify the interpreter or caller;
- control the kernel or process.

Distinguish:

- precommit hostile or accidental concurrency the design must detect;
- postcommit mutation by trusted principals that is explicitly outside the
  guarantee;
- privileged/kernel compromise that remains out of scope.

Do not promise permanent lexical-path stability if the threat model admits a
writer that can rename the path after commit.

## 8. Versioning and compatibility decision

For the selected model, freeze:

- exact meaning of `--record`;
- whether its immediate parent exists or is absent initially;
- output file names and count;
- shared-stdout contract;
- launch protocol version;
- caller-record schema version;
- exact top-level fields;
- whether any field meaning changes;
- migration treatment for existing v3 caller records;
- whether A6D and amendment historical records remain compatibility evidence;
- whether old callers become Temporary compatibility edges;
- whether the verifier remains byte-identical.

Do not preserve v2/v3 identifiers by inertia if their semantics materially
change.

## 9. Selected design requirements

Select one primary model and no automatic fallback.

The selected design must provide one clear answer to each:

1. What exact kernel operation is the accepted-record commit point?
2. What object and pathname are guaranteed at that instant?
3. What becomes externally visible atomically?
4. Which checks occur before the commit?
5. Which operations remain after commit, and why can none contradict
   acceptance?
6. How is a foreign collision distinguished from this caller’s publication?
7. How does a consumer locate and authenticate the accepted record?
8. What later path mutation is outside the guarantee?
9. What exact caller record or protocol version identifies these semantics?
10. What source and evidence owner is authoritative for the contract?

## 10. Future implementation freeze

Do not implement, but freeze:

- exact successor source file(s);
- any documentation or private contract files;
- exact touched-file set;
- new or changed schema/protocol IDs;
- exact source-external evidence root structure;
- old/new source provenance;
- causal test sources;
- compatibility test sources;
- manifest and sealing treatment;
- failed/superseded attempt handling.

No repository file should be added unless the selected contract requires a
repository documentation or test change. State the reason for every intended
path.

## 11. Future causal and validation matrix

Include at least:

- valid commit;
- target, package, candidate, TMPDIR, caller-evidence, interpreter, and output
  containment;
- every displaced-parent and displaced-ancestor timing;
- arbitrary and accepted-looking foreign collisions;
- output count and co-location;
- partial writes and fsync faults;
- partial bundle construction;
- capability failure;
- same-name retry after every failure and after success;
- hooks unreachable in normal execution;
- depth and snapshot regression;
- schema and redaction;
- A6D twice;
- amendment twice;
- synthetic A6 twice pre-seal and twice sealed;
- SEC-02;
- unchanged supplied roots;
- no process or descriptor survivor;
- fresh independent audit.

For each case name the required outcome and acceptance evidence.

## 12. Mandatory stop conditions

Return RECORD_CUSTODY_RECONNAISSANCE_BLOCKED if:

- no model can honestly meet the desired pathname guarantee;
- the selected model depends on an unproved kernel behavior;
- source and destination cannot be committed as one custody unit;
- a postcommit failure can contradict accepted evidence;
- the model silently weakens the threat model;
- a schema or protocol change is required but left unversioned;
- a product/runtime/public authority change becomes necessary;
- placement or ownership remains unresolved.

## 13. Required inline report

Include:

1. Verdict.
2. Pre-epoch disclosure.
3. Opening and closing identities.
4. Fresh reconnaissance-root identity.
5. Four auditor identities, schedules, operands, and status.
6. Frozen audit finding.
7. Why finite file-level rechecks are or are not sufficient.
8. Model A adjudication.
9. Model B adjudication.
10. Model C adjudication.
11. Model D adjudication.
12. Model E adjudication.
13. Model F adjudication.
14. Exact probes and results.
15. Threat model.
16. Selected primary model.
17. Explicit absence of automatic fallback.
18. Exact commit point.
19. Exact pathname/object guarantee.
20. Version and schema decision.
21. Compatibility and migration treatment.
22. Exact future touched-file set.
23. Complete future causal matrix.
24. Future implementation and audit sequence.
25. Mandatory stop conditions.
26. Inspection limits and uncertainty.
27. Reconnaissance-created paths and cleanup.
28. Explicit confirmations:
    - repository mutation not performed;
    - supplied-evidence mutation not performed;
    - implementation not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.
```

## Current disposition

- **Current successor:** independently blocked.
- **Blocker:** accepted-record custody under destination-parent displacement.
- **Other audited mechanisms:** passed on the exact bytes.
- **Next activity:** record-custody reconnaissance, not implementation and not another audit.
- **Commit/A6 restart:** still blocked.

### Sources

The audit reproduced success and accepted output after the record directory moved away from the declared destination, leaving the declared final path absent. 

Opening and closing provenance, source-delta scope, all four auditor perspectives, and the other major security and compatibility gates passed.  

The project protocol requires a fresh repair and re-audit after a blocking source finding; a prior audit cannot bind changed bytes.  Provenance must bind later work to the same bytes without being mistaken for correctness or authority. 

**Confidence**

- The audit establishes a genuine source defect: **0.999**
- Another finite pre/post pathname check is insufficient: **0.98**
- A publication-contract reconnaissance is required before mutation: **0.97**
- Atomic bundle-directory publication is the strongest provisional model: **0.90**
- Commit and A6 restart must remain blocked: **0.999**
