Here is Codex's response:

The Repair 10I-A5P2 contract can be safely frozen. The amended design separates immutable custody-record lifetime from live descriptor lifetime and uses a role-specific, peer-bound acknowledgment before closing runner aliases.

## 1. Opening and closing identities

The read-only opening and closing gates were identical and passed.

| IdentityOpening = closing       |                                                                                   |
| ------------------------------- | --------------------------------------------------------------------------------- |
| Repository                      | `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1` |
| Branch                          | `codex/remote-alpha-external-tls-status-observation-v1`                           |
| HEAD                            | `567bceced5df95ecfe787cc66038d463a854e12c`                                        |
| Sole parent                     | `05dde14d185b6e022dcc169ef1a658a97961850f`                                        |
| HEAD tree                       | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                        |
| Upstream                        | absent                                                                            |
| Index SHA-256                   | `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`                |
| Repository T                    | `ab646e5a0e66a30c00ca405ab43fbf6903224043`                                        |
| Inventory SHA-256               | `c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3`                |
| Inventory size                  | `54314`                                                                           |
| Membership                      | `389 / 375 / 14` total/tracked/untracked                                          |
| Staged/deleted/renamed/unmerged | `0 / 0 / 0 / 0`                                                                   |

The delta from sealed A5 remains exactly:

- `remote_alpha_operator_test.go`: mode `100644`, size `333580`, SHA-256 `f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578`
- `es/runtimehelper/supervisor_test.go`: mode `100644`, size `5293`, SHA-256 `842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226`

There are zero additions, deletions, renames, or mode changes.

Sealed A5S reverified payload-by-payload:

- Manifest `57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f`
- `271` payloads, `81` directories including root
- T `983943e612dd4d48ca4f0fabbc48ad51909c2e11`
- Inventory `799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a`
- `12` source members

Sealed A5P reconnaissance reverified payload-by-payload:

- Manifest `1a1d3362886deb9b5b8e7358bf711af191f358faa164c0a3c58d7f7539042550`
- `148` payloads, `7` directories including root
- Required report, contract, direct-denial, broker-positive, unrelated-terminal-denial, cleanup, and absence members all verified.

Failed A5P remains present, unsealed, and byte-exact:

- Snapshot `ac1807404ca78c800714e34223e42b7ddd8ba31ca1c814b8de5b97922c754283`
- `305` entries: `248` files, `57` directories
- T `c9831fd4c3365b8e47e5174ea6177ba4d8894d57`
- Inventory `b4d5b80e1719a80a6fb2b164ccffb99bec279c04cc3166369b9e97d74ecbcce3`
- A/B hard gate outcome `qualified`; authoritative hard-gate record SHA-256 `34c04eb05dc16701da6d2ac25e877ac6df399ead32f7c3b94b504aac6a0baa82`
- Bounded failure SHA-256 `bd1ef0418509418d25da6a027b19de5cdd43036217c3a34ef780e5c6e2bc9e61`
- Conflict report SHA-256 `6bb1303a22abad1be202758a18aff19570202d21824990c5aadbe63352ff21bf`
- Kernel causal SHA-256 `85dcb4d2ef27b102ab6fc592e887e42283c623b98878162c202813a12c41ce30`
- Manifest and detached digest remain absent.

Failed A5T remains unsealed at snapshot `652526402c404201592958a6cdd616d25ab1db44744c174223fd7bdc47e29361` (`227/187/40`). Failed A6 remains unsealed at `501b04e31157d2437d73aafae053a49f3fb4140880247fdc3256ac6433b924ae` (`180/134/46`).

All seven sealed and eight unsealed predecessor roots reverified; predecessor bytecode remains absent. No A5P2 path exists.

## 2. Exact erroneous sealed clause

The exact defect is:

> Runner retains the original pair until whole-process-group completion and both zero-observation epochs, preventing slave-node reuse while the literal rule exists.

It appears in the sealed [successor capability contract (line 25)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66/findings/successor-capability-contract-v1.json:25). The reconnaissance report repeats that originals remain held until all attributed processes are gone at [line 105 (line 105)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66/findings/reconnaissance-report-v1.md:105). The failed implementation documents the same rule in [FORMAT.md (line 693)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/FORMAT.md:693).

That rule conflates evidence lifetime with descriptor-open lifetime and creates a circular dependency: retained slave → no master EOF → helper cannot finish → process completion unavailable → retained slave cannot be closed.

## 3. Exact failed implementation mechanism

The failed implementation:

1. Preallocates each master/slave pair and stores the same original `*os.File` objects in custody and broker structures at [runner.go (line 2343)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2343).
2. Creates descriptor-less logical “transfer” records rather than records for actual recipient descriptor generations at [runner.go (line 2304)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2304).
3. Sends the originals through `SCM_RIGHTS` at [runner.go (line 2658)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2658).
4. Accepts a self-reported transfer acknowledgment without binding it to the AF\_UNIX peer PID or a process birth identity at [runner.go (line 2667)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2667).
5. Starts the sole `Wait` before any original PTY close at [runner.go (line 3434)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:3434).
6. Calls final broker disposition only after `Wait`, output drains, and the process barrier at [runner.go (line 3580)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:3580).
7. Finally closes the original slave and master in `stopV1` at [runner.go (line 2849)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2849).

The bounded A5T attempt reached its first pair transfer, acknowledgment, all four denial probes, and the caller-slave close receipt, then stopped making progress exactly at this cycle. Cleanup after deliberate termination produced two absence epochs.

A separate defect exists in partial allocation: the allocator’s error defer closes acquired descriptors outside custody at [runner.go (line 2200)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/tool/source/envelope/runner.go:2200). A5P2 must register each acquired generation before any later failure can close it.

## 4. Repository-helper EOF mechanism

The principal helper:

- calls `pty.openpty()`;
- passes the slave to the nested process’s fd `0/1/2`;
- closes its own slave;
- blocks reading the master until zero-length read or `OSError`;
- closes the master;
- only then calls `proc.wait()`.

That sequence is exact at [remote\_alpha\_operator\_test.go (line 126)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_operator_test.go:126>).

The forkpty helper calls `pty.fork()`, retains the parent master, services prompts, observes/reaps the fork child, and closes the master at [remote\_alpha\_vault\_workload\_auth\_bootstrap\_test.go (line 50)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_vault_workload_auth_bootstrap_test.go:50>).

Neither helper can be changed for A5P2.

## 5. Kernel-causal result

The independent [kernel causal](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66/findings/pty-eof-retained-slave-causal-v1.json) established:

- Child wrote one byte, closed its slave, exited, and was reaped.
- No EOF/EIO appeared during a `0.25 s` observation while the parent slave remained open.
- EOF appeared immediately after releasing that slave.
- All descriptors closed.
- No raw PTY payload was retained.

This is direct behavioral evidence for the deadlock, not an inference from source structure.

## 6. Complete descriptor and alias graph

| LayerAlias or generationStatus |                                                                                        |                                                                                                |
| ------------------------------ | -------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| Allocator                      | Local `master` and `slave` `*os.File` values                                           | Original runner-owned generations                                                              |
| Allocation fallback            | Error defer closes those locals                                                        | Live close path, currently outside custody and therefore defective                             |
| Preparation                    | `ownedMaster`/`ownedSlave` variables                                                   | Aliases of the same original generations                                                       |
| Custody                        | Close closures captured by `masterResource`/`slaveResource`                            | Sole intended runner close owners                                                              |
| Journal                        | `Master`/`Slave` identity structures                                                   | Metadata only; no descriptor ownership                                                         |
| Broker pair                    | `privatePTYPairV1.master/slave`                                                        | Pointer aliases of the runner originals                                                        |
| Broker worker                  | Numeric descriptors borrowed by `UnixRights`                                           | Non-owning SCM send borrow; no duplicate exists on the sender                                  |
| Transfer resources             | `Descriptor: -1` logical records                                                       | Metadata only; not actual recipient descriptors                                                |
| `exec.Cmd`                     | Only launch-sync fd in `ExtraFiles`                                                    | No PTY descriptor; stdout/stderr are unrelated pipes                                           |
| SCM receiver                   | Two numeric descriptors returned by `recvmsg`                                          | Independent process-scoped descriptor generations sharing endpoint identity with the originals |
| Reexec                         | Environment integers → `_PRELOADED` tuple → `_TRACKED`                                 | Aliases of the SCM receiver generations across same-PID `execve`                               |
| `openpty` helper               | Returned master/slave; `Popen` installs slave on nested fd `0/1/2`                     | Master remains with Python helper; intended slave copies remain in nested process              |
| `forkpty` helper               | `fork()` duplicates receiver table                                                     | Separate parent and fork-child owner generations                                               |
| Fork child setup               | Child master close; `login_tty(slave)` duplicates slave to `0/1/2` and closes setup fd | Controlling-terminal generation                                                                |
| Fork parent                    | Parent slave close; parent master retained                                             | Parent owns master read/select lifecycle                                                       |
| Output workers                 | Runner drains only outer stdout/stderr pipes                                           | No PTY alias or PTY close authority                                                            |
| Event connections              | Short-lived AF\_UNIX descriptors                                                       | Separate from PTY endpoints                                                                    |
| Deferred/final cleanup         | Broker and custody reuse original resource indexes                                     | No new PTY descriptor generation                                                               |

The `SCM_RIGHTS`, fork, and `dup2` generations share PTY device/inode/rdev identity; endpoint equality does not mean ownership-record equality.

## 7. Selected handoff boundary and rejected alternatives

| CandidateDecision                         |                                                                                                                                       |
| ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| A. `exec.Cmd.Start`                       | Rejected: only establishes the outer leader; no nested Python receiver or PTY descriptor exists yet.                                  |
| B. Launch-sync release                    | Rejected: establishes containment and permits execution but precedes SCM transfer and terminal setup.                                 |
| C. Child inheritance/setup acknowledgment | Selected, with acceptance-bearing strengthening.                                                                                      |
| D. Repository-helper close receipt        | Rejected as the authorization boundary: it is later than safe transfer, role-dependent, and proves only that one helper alias closed. |
| SCM send success                          | Rejected: proves sender-side transfer, not receiver installation or setup.                                                            |
| Existing terminal event                   | Selected as the fork-role completion of C, after strengthening.                                                                       |
| Process-group completion                  | Rejected: this is the deadlocking boundary.                                                                                           |

The exact selected boundary is role-specific:

- `openpty-no-ctty`: the post-reexec transfer acknowledgment.
- `forkpty-ctty`: the later post-`login_tty` terminal acknowledgment. Its initial transfer acknowledgment is provisional and does not authorize parent closure.

Before launch-sync release, the broker must be bound to the already-established process tracker. Each acknowledgment connection must then prove:

- kernel-observed AF\_UNIX peer PID;
- matching receiver-reported PID;
- matching live `ProcessIdentity` including PID, PPID, PGID, SID, birth identity, and attributed ancestry;
- exactly two received rights, no ancillary truncation or unexpected flags;
- distinct numeric master/slave fds;
- exact character-device endpoint identity and link count;
- inheritable state required for the completed reexec;
- exact denial probes.

For `openpty-no-ctty`, terminal setup is exactly `not-required`.

For `forkpty-ctty`, the final event must additionally prove:

- event peer is the attributed fork child;
- `PID == SID == PGRP == foreground PGRP`;
- fd `0/1/2` are terminals and each matches the transferred slave identity;
- child master is closed;
- the setup slave fd is closed after `login_tty`;
- no terminal-setup error remains pending.

The broker then transitions to `child-inherited-and-acknowledged`, closes the runner slave once, closes the runner master once, verifies both original generations’ dispositions, and only then replies `{"accepted":true}`. Any close uncertainty produces a false response and permanent nonqualification.

The local SDK defines `SOL_LOCAL` and `LOCAL_PEERPID` at [sys/un.h (line 85)](/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk/usr/include/sys/un.h:85), and the Go standard library exposes `GetsockoptInt` at [syscall\_unix.go (line 312)](/usr/local/go/src/syscall/syscall_unix.go:312). This is static feasibility evidence only. A5P2 must behaviorally validate the option and fail closed without OS/version branching or fallback, consistent with [capability\_probing.md (line 11)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md:11>).

## 8. Corrected ownership state machine

Required distinct records are:

1. Runner original master.
2. Runner original slave.
3. Child/receiver master.
4. Child/receiver slave.
5. Non-owning broker-worker SCM send borrow.
6. Openpty nested fd `0/1/2` or fork parent/child/setup/ctty generations.
7. Child process/session/group birth epoch.
8. Exact literal slave-device ioctl grant.
9. Ungranted sentinel master/slave.
10. Every malformed, surplus, duplicate, or temporary received descriptor.

Success transitions are exactly:
```
allocated
→ identity-attached
→ transfer-prepared
→ child-inherited-and-acknowledged
→ parent-alias-disposing
→ parent-alias-closed
→ child-active
→ child-released/process-complete
→ final-accounting-complete
```

No state may be skipped.

Terminal failure states are:
```
failed-allocation
failed-partial-allocation
failed-identity
failed-transfer
failed-acknowledgment
failed-terminal-setup
failed-parent-alias-disposition
failed-child-release
failed-eof
failed-process
failed-worker
failed-final-accounting
```

Cleanup can continue from a terminal failure, but the allocation cannot transition back to a success state.

A kernel-duplicated child descriptor has no globally unique inode distinct from its parent alias. Its strongest honest identity is:
```
(handoff_id, role, ordinal, endpoint identity,
 kernel-bound ProcessIdentity, process_fd)
```

That identity is supported by send success, exact ancillary count, peer-bound acknowledgment, strict fstat identity, and later release evidence. It is not represented as a new inode.

## 9. Corrected lifetime rule

The frozen replacement clause is:

> Retain each immutable PTY custody and disposition record through process completion, cleanup, terminal reconciliation, and external qualification. Close the runner-owned original slave—and the runner-owned original master, which has no post-transfer operational role—exactly once after the role-specific inherited-descriptor and terminal-setup acknowledgment, before waiting for master EOF or process completion. A runner alias retained beyond that boundary is a qualification-blocking leak.

Exceptions:

- A declared but not-yet-requested pair remains open until its handoff or terminal cleanup.
- The ungranted sentinel remains open until all required denial acknowledgments finish, then closes during broker cleanup.
- Neither exception permits waiting for process completion once its operational role has ended.

Role ownership:

- `openpty-no-ctty`: repository Python helper owns the master read; its SCM slave is closed after `Popen`; nested fd `0/1/2` close on nested-process exit.
- `forkpty-ctty`: fork parent owns master/select/read; parent slave closes; `login_tty` replaces the child setup slave with fd `0/1/2`; those close on fork-child exit.
- Runner output workers own only outer stdout/stderr pipes. The runner never reads or consumes PTY bytes.
- A generated observational `os.read` wrapper may report only zero-length EOF or exact `EIO` hangup, without retaining or modifying payload bytes.

Required success order:
```
handoff acknowledgment
→ runner slave close
→ runner master close
→ acknowledgment success response
→ child active
→ intended child slave release
→ actual master EOF/EIO observation
→ helper master close
→ process Wait/reap
→ outer stdout/stderr EOF and worker joins
→ broker listener close and worker join
→ sentinel/unrequested cleanup
→ ledger reconciliation
→ two process/socket/device absence epochs
→ final terminal accounting
```

## 10. Failure and cleanup semantics

Global rules:

- Every actual cause is appended in stable observation order; later cleanup errors never overwrite the initiating cause.
- A valid locally owned descriptor generation receives exactly one close syscall. No retry is permitted, including after `EINTR`.
- A not-acquired generation receives zero close calls.
- A child-owned logical generation receives zero runner close calls; it requires one release observation plus process/EOF evidence.
- Every delivered malformed or surplus ancillary fd is closed once by the receiver before rejection. `MSG_CTRUNC` is itself terminal failure; process termination/reap closes any descriptor the receiver could not enumerate.
- Once failure is latched, qualification remains false even if cleanup later establishes absence.

| FailureTermination and continued cleanupDisposition and qualification |                                                                                                                                                                        |                                                                       |
| --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| Pair allocation failure                                               | No group signal before launch. Register and dispose every actually acquired component, then listener/sentinel/worker cleanup.                                          | One close per acquired generation; no retry; false.                   |
| Partial allocation                                                    | Same, including master-only or slave-only results.                                                                                                                     | Unacquired side gets zero closes; acquired side gets one; false.      |
| Child start failure                                                   | If no process identity exists, no group signal. If a live birth-bound PID exists, positive-PID cleanup only. Join prelaunch workers and dispose all pairs.             | Once-only closes; false.                                              |
| Acknowledgment failure                                                | Reject response, terminate all attributed birth-matched descendants, reap, then complete remaining cleanup.                                                            | Parent aliases each close once; false.                                |
| Wrong fd, identity, inode, type, role, count, or ancillary flags      | Same as acknowledgment failure.                                                                                                                                        | Receiver closes every delivered fd once; originals close once; false. |
| Controlling-terminal setup failure                                    | Terminate attributed parent and fork child, including the new-session child by birth identity.                                                                         | No successful handoff; once-only cleanup; false.                      |
| Process-group/session setup failure                                   | If group proof is absent, never use a negative-PID signal; use birth-bound positive PID cleanup.                                                                       | False.                                                                |
| Parent slave/master close error                                       | Continue closing the other parent alias and all later resources; send rejection and terminate child group.                                                             | One close call only; false even if post-close fstat reports `EBADF`.  |
| Parent close `EINTR`                                                  | Do not retry because descriptor disposition is unspecified. Record immediate post-close observation, terminate/reap, and continue external cleanup.                    | Permanently false.                                                    |
| Pre-close stale/reused fd                                             | Do not close the foreign generation; record one disposition attempt and zero close syscalls for the lost original. Clean the foreign descriptor through its own owner. | False.                                                                |
| Post-close reuse                                                      | Original receives one close; record the new identity but do not close it through the original owner.                                                                   | False.                                                                |
| Child exits before acknowledgment                                     | No positive acknowledgment; close originals once, reap or terminate remaining descendants.                                                                             | False.                                                                |
| Child closes receiver slave before acknowledgment                     | Initial fstat/ack fails. The fork child’s expected post-`login_tty` setup-fd close is allowed only when fd `0/1/2` terminal identity is simultaneously proven.         | Otherwise false.                                                      |
| Child never closes final slave                                        | Existing command timeout fires; terminate/reap, then cleanup.                                                                                                          | False even if process teardown later releases it.                     |
| Master EOF too early                                                  | EOF before `parent-alias-closed` or before valid role setup is a protocol failure; terminate and clean.                                                                | False.                                                                |
| Master EOF never arrives                                              | Existing outer timeout bounds it; terminate/reap and clean.                                                                                                            | False.                                                                |
| Output worker failure                                                 | Terminate live descendants, force-close pipe readers once, join both workers, continue broker cleanup.                                                                 | False.                                                                |
| Process timeout                                                       | Birth-matched TERM then KILL, sole Wait join, stream/broker cleanup.                                                                                                   | False.                                                                |
| Signal failure                                                        | Preserve signal error, continue bounded escalation and absence checks.                                                                                                 | False regardless of later absence.                                    |
| Wait uncertainty                                                      | Terminate/reap attempts, close all remaining resources, run absence checks.                                                                                            | False.                                                                |
| Repeated internal cleanup                                             | Idempotent latch returns the original disposition without another close. Duplicate external close/event records are protocol failures.                                 | Internal idempotence may preserve success; duplicate evidence cannot. |
| Late ledger or terminal-record failure                                | No process signal is needed if all processes are already absent; external recomputation rejects the record.                                                            | False and cannot be repaired by a caption or later cleanup.           |

## 11. EOF and deadlock invariants

1. Master EOF is not expected while any intended slave owner remains live.
2. The runner creates no unintended slave owner.
3. After the final intended slave closes, the actual master reader must observe zero-length EOF or exact `EIO` hangup before the command’s existing `timeout_ms` deadline.
4. Deterministic causals use the retained-slave `250 ms` negative window and a repaired positive deadline no greater than `2 s`.
5. A retained parent slave mutant must block EOF, remain visible in the ledger, and be nonqualifying.
6. An early-close mutant must fail state ordering even if a kernel transfer happened to succeed.
7. Duplicate inherited slave aliases or ancillary counts other than two are rejected and disposed.
8. Process completion is never a prerequisite for runner-slave closure.
9. Parent-alias closure cannot invalidate kernel-installed child descriptors.
10. EOF evidence must come from the helper’s actual read result, never synthesized by the runner.
11. EOF must be ordered after `parent-alias-closed` and before helper master close.
12. No broker record may contain raw terminal payload.

## 12. Complete A5P2 schema dialect

A5P2 accepts only this mixed active dialect.

Eleven acceptance-bearing outer schemas become v3:
```
execution-substrate.repair10i.suite-spec.v3
execution-substrate.repair10i.ab-suite-spec.v3
execution-substrate.repair10i.command-intent.v3
execution-substrate.repair10i.command-result.v3
execution-substrate.repair10i.terminal-reconciliation.v3
execution-substrate.repair10i.suite-result.v3
execution-substrate.repair10i.binding-recomputation.v3
execution-substrate.repair10i.control-qualification.v3
execution-substrate.repair10i.semantic-comparison-spec.v3
execution-substrate.repair10i.semantic-comparison-result.v3
execution-substrate.repair10i.semantic-comparison-custody.v3
```

All four private schemas become v2:
```
execution-substrate.repair10i.private-pty-command.v2
execution-substrate.repair10i.private-pty-broker-journal.v2
execution-substrate.repair10i.private-pty-allocation.v2
execution-substrate.repair10i.private-pty-reconciliation.v2
```

Eight unchanged records remain v1:
```
execution-substrate.repair10i.control-observation.v1
execution-substrate.repair10i.mutable-inventory.v1
execution-substrate.repair10i.effective-read-policy.v1
execution-substrate.repair10i.intentional-mutant-provenance.v1
execution-substrate.repair10i.go-test-semantics.v1
execution-substrate.repair10i.byte-capture.v1
execution-substrate.repair10i.byte-comparison-spec.v1
execution-substrate.repair10i.byte-comparison-result.v1
```

The exact command constants are:
```
capability = repair10i-private-pty-broker-v2
lane       = validation-private-pty-v1
protocol   = scm-rights-acknowledged-handoff-v2
mapping    = scm-rights-distinct-owner-handoff-v2
stream     = test-harness-owned-pty-v1
```

`private-pty-command.v2` remains the closed caller-controlled shape:
```
schema, capability, lane, protocol,
expected_requests[{role,count}], max_total_pairs
```

Its entire normalized value plus the derived role-specific handoff, mapping, stream, and lifetime semantics enter the logical fingerprint.

`private-pty-allocation.v2` is the closed acceptance record containing:
```
schema, handoff_id, ordinal, role, controlling_terminal,
descriptor_mapping, stream_attachment_mode,
runner_derived_slave_path, runner_derived_slave_path_sha256,
profile_rule, owner_generations, state_transitions, handoff_ack,
negative_checks, child_release_receipts, master_eof,
process_release, outcome, errors
```

Each `owner_generations[]` entry contains:
```
owner_id, generation_id, parent_owner_id, endpoint,
owner_kind, owner_role, process_identity, process_fd,
device, inode, rdev, links, descriptor_type,
required_until, state, acquired_sequence, disposition_sequence,
disposition_attempts, kernel_close_calls,
close_result, close_cause, kernel_disposition
```

Inapplicable values are explicit null/zero values, not omitted aliases.

`handoff_ack` contains peer PID/process identity, reported PID, ancillary count/flags, numeric fds, exact identities, inheritable state, terminal requirement/state, fd `0/1/2` identities when required, setup error, verification sequence, both parent dispositions, authorization, and final acceptance.

`master_eof` records reader owner, exact `read-zero` or `EIO-after-release`, errno, ordering flags, observation sequence, applicable deadline, and `payload_retained_bytes=0`.

`private-pty-broker-journal.v2` binds the policy, socket/token/sitecustomize identities, peer-PID capability result, sentinel, all allocations/requests, owner transitions, handoffs, parent dispositions, child releases, EOF ordering, process and worker disposition, two socket/device epochs, zero broker payload, final outcome, and ordered errors.

`private-pty-reconciliation.v2` independently recomputes:
```
policy_verified
fingerprint_bound
profile_rules_exact
owner_generations_exact
handoffs_exact
parent_alias_disposition_exact
child_release_exact
eof_ordering_exact
process_and_terminal_exact
cleanup_epochs_verified
default_denial_verified
outcome
```

`control-qualification.v3.private_pty_verified` remains the outer aggregate, but now means the conjunction of all v2 reconciliation facts. Old fields cannot substitute because their enclosing schema is rejected.

Producers/consumers requiring changes:

- `envelope/runner.go`: all private records, outer suite/intent/result/reconciliation/qualification records, broker, generated hook, ledger, runtime requalification.
- `envelope/semantic.go`: v3 semantic comparison spec/result/custody and v3 qualification/suite-result consumption.
- `envelope/source.go`: v3 qualification consumption for byte/product paths.
- `envelope/envelope_test.go`: strict fixtures, dialect inventory, causals, mutants, and historical rejection.
- `FORMAT.md`: authoritative format description.

A5S v1 and failed-A5P outer v2/private v1 remain parseable only through purpose-built historical reporting and are always nonqualifying on A5P2 paths.

## 13. Exact successor touched-file set

The sealed reconnaissance named five tool files and eight future repository files.

Its repository array was:
```
PLANS.md
.docs/system_overview/capability_probing.md
.docs/system_overview/boundaries.md
.docs/system_overview/artifact_hygiene.md
docs_contract_test.go
repair10_private_pty_test.go
remote_alpha_operator_test.go
remote_alpha_vault_workload_auth_bootstrap_test.go
```

None are touched by A5P2.

The failed A5P’s actual delta from A5S was exactly:

| FileA5S size/hashFailed A5P size/hash |                            |                            |
| ------------------------------------- | -------------------------- | -------------------------- |
| `FORMAT.md`                           | `37324` / `c0014417…8ec3`  | `40802` / `a75c47ab…9a6c`  |
| `envelope/envelope_test.go`           | `215860` / `092756bb…43ba` | `244040` / `ee748e24…7e3e` |
| `envelope/runner.go`                  | `170520` / `e0141a9d…2da8` | `248948` / `f083fa37…ba87` |
| `envelope/semantic.go`                | `86963` / `0ebf04c0…5933`  | `86963` / `a62fcd6e…847b`  |
| `envelope/source.go`                  | `62947` / `0d54aecf…cd76`  | `62976` / `f83f252f…f07b`  |

The minimal A5P2 successor touched-file set is exactly the same five paths, implemented freshly from sealed A5S:
```
tool/source/FORMAT.md
tool/source/envelope/runner.go
tool/source/envelope/semantic.go
tool/source/envelope/source.go
tool/source/envelope/envelope_test.go
```

Explicit adjudication:

- Repository source: unchanged.
- A5T test source: unchanged.
- Fixture main: unchanged.
- Runner main: unchanged.
- Semantic main: unchanged.
- Comparator main: unchanged.
- Envelope runner: changed.
- Envelope source: changed because byte/product qualification must require the v3 aggregate.
- Envelope semantic logic: changed.
- Envelope tests: changed.
- `FORMAT.md`: changed.
- Golden files: unchanged.
- `go.mod`: unchanged.
- New dependency: none.
- Thirteenth successor member: none.

## 14. Exact causal-test matrix

The frozen test names are:

1. `TestRepair10IA5P2VulnerableRetainedParentSlaveBlocksEOFV1`
2. `TestRepair10IA5P2AcknowledgedHandoffClosesParentAliasesAndCompletesV1`
   - `openpty-no-ctty`
   - `forkpty-ctty`
3. `TestRepair10IA5P2EarlyParentCloseIsNonqualifyingV1`
4. `TestRepair10IA5P2RetainedParentAliasIsNonqualifyingV1`
5. `TestRepair10IA5P2DuplicateInheritedSlaveIsRejectedAndDisposedV1`
6. `TestRepair10IA5P2CloseFaultMatrixV1`
7. `TestRepair10IA5P2PrivatePTYDialectAndHistoricalRejectionV1`
8. `TestRepair10IA5P2PeerBoundAcknowledgmentFaultsV1`
9. `TestRepair10IA5P2SecurityNonRegressionV1`
10. `TestRepair10IA5P2AllocationAndPartialCleanupV1`
11. `TestRepair10IA5P2ExternalRequalificationRejectsLateFaultsV1`

The close-fault matrix has exact subtests:
```
parent-slave-close-error
parent-slave-close-eintr
preclose-stale-fd
postclose-fd-reuse
repeated-disposal
child-slave-close-uncertain
master-eof-missing
output-worker-failure
process-timeout
signal-failure
wait-uncertainty
late-ledger-failure
late-terminal-failure
```

The peer-bound matrix covers wrong peer PID, wrong reported PID, unattributed process birth, wrong numeric fds, endpoint/type mismatch, wrong role/order/count, duplicate rights, ancillary truncation, early exit, wrong ctty/session/group/foreground state, and fd `0/1/2` mismatch.

The security test proves `/dev/ptmx` denial, unrelated terminal denial, absence of broad `/dev` and `/dev/ttys*` rules, exact literal ioctl grant, denial of another allocation, zero capability for omitted/null policy, and no broker payload retention.

Bounded A5T integration must freshly execute these four exact tests:

- `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadUsesBoundedRemoteCommand`
- `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesTraversalAmbiguityWithSudoVisibleInspection`
- `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareSpireBundleReadClassifiesAccessibleBundleShowFailure`
- `TestRemoteAlphaOperatorRecoverySessionVaultWorkloadAuthBootstrapPrepareRunsBeforeHelperExecution`

Required runs:

- Explicit capability: count `3` plus race count `1`; all named passes and all five intended assertions reached.
- No capability: count `1`, expected exit `1`, all four fail at the PTY denial after listener setup.
- Every actual socket path is at most `100` bytes.
- All external qualifications recompute.
- No required skip, survivor, socket, device, control root, or descriptor residue.

The failed A5P causal remains expected-negative evidence and cannot substitute for either fresh A5P2 control.

## 15. Implementation, validation, and restart sequence

1. Create a new A5P2 implementation child from sealed A5S, never from failed A5P.
2. Reimplement the broker under this amended contract.
3. Preserve failed A5P byte-exact as expected-negative evidence.
4. Run two inode-disjoint A/B source materializations, complete tests, races, security mutants, and deterministic builds.
5. Run the vulnerable retained-slave causal and repaired EOF causal.
6. Run bounded current-A5T capability and no-capability integration.
7. Seal A5P2 only after complete cleanup and two zero-observation epochs.
8. Create a new A5T validation/closure child; do not resume the existing failed A5T child.
9. Run the complete A5T gate from the beginning.
10. Only after A5T seals, implement and seal A5C.
11. Restart the complete two-control A6 policy-evidence refresh from fresh materializations.

No bounded or failed causal substitutes for a required fresh downstream control.

## 16. Inspection limits and uncertainty

Directly established:

- Exact source ordering and helper behavior.
- Exact failed broker ownership and cleanup paths.
- The retained-slave deadlock in bounded integration.
- The independent kernel EOF causal.
- Static availability of the AF\_UNIX peer-PID option and Go socket-option API.

Not established during this turn:

- No live runtime `LOCAL_PEERPID` probe was executed. A5P2 must behaviorally validate it and fail closed if unavailable or inconsistent.
- No live process descriptor table was attached or inspected.
- `Popen`, `fork`, `SCM_RIGHTS`, and `login_tty` copy relationships beyond retained records are derived from their source-visible operations and kernel/API semantics.
- A kernel duplicate cannot receive an independently unique inode. Process identity, process fd, handoff ID, endpoint identity, exact count, and acknowledgment provide the strongest honest identity.
- Arbitrary later child `dup` operations cannot be enumerated directly. The generated fixed hook, exact role/count protocol, close receipts, EOF/hangup, process tracking, reap, and two absence epochs bound that uncertainty.
- No remote host, Linux binary, live route, or operator terminal was inspected.

These limits do not block the contract because each unproven runtime capability is an explicit fail-closed validation condition.

## 17. No-mutation confirmation

This turn performed read-only source and evidence inspection only.

- No repository, A5S, reconnaissance, failed A5P, failed A5T, failed A6, or lineage byte changed.
- No source, evidence, cache, bytecode, scratch, test, build, snapshot artifact, ZIP, handoff, capture, product A/B, or successor child was created.
- No A5P2 path exists.
- No tests or builds ran.
- No subagent was created or used.
- No staging, commit, push, installation, live route, remote contact, network action, or Linux execution occurred.
- A5T was not sealed; A5C, A6, and B6 were not started.

REPAIR10I\_A5P2\_RECONNAISSANCE\_READY
