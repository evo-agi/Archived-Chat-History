## Assessment

This is a **prompt-input failure, not a caller-repair failure**.

The stopped audit behaved correctly: provenance guidance requires an auditor to halt before correctness inspection when an exact input differs.  The mismatch, however, came from the audit prompt specifying the wrong retained predecessor-copy filename:

- **Incorrect path in the prompt:**  
  `source/launch_v3_trusted_host_descriptor_snapshot.py`
- **Actual manifest-covered path:**  
  `source/predecessor_caller_exact.py`

Codex found the actual file at the second path with the expected predecessor SHA-256. It also independently verified that:

- the repository, successor, source delta, and repair-manifest identities matched;
- the repair root still contained exactly 108 regular files and 10 directories;
- the two manifests were canonical, byte-identical, and covered every retained nonmanifest file exactly once;
- only the two manifests were self-excluded;
- opening and closing inventories were unchanged.

The implementation report promised an exact inert predecessor copy and complete closure, but did not assign it the filename that the audit prompt assumed.  The repair’s canonical manifests cover all 106 nonmanifest files and identify only themselves as exclusions. 

The prompt also contained a malformed first copy of the expected tree hash before later giving the correct value. That did not cause this stop, but it should be eliminated.

**Do not run another implementation or reconciliation tranche.** Nothing needs repair. Leave the stopped `…-v1` audit immutable and nonqualifying, then launch a completely fresh audit at `…-v2` with:

- the correct predecessor-copy path;
- one unambiguous, correct tree hash;
- an explicit statement that the previously assumed filename is not expected.

The successor implementation remains producer-validated but expressly requires a fresh independent audit. 

## Corrected Codex prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Embed the complete audit report inline in Markdown. Local evidence links may be
supplemental, but must not replace any section of the inline report.

Return exactly one:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH
PROCESS_BOUNDARY_BLOCK
SUBAGENT_UNAVAILABLE

FRESH READ-ONLY CONVERSATION

This must be a completely fresh Codex conversation.

Do not resume:

- the caller reusability/depth implementation conversation;
- the stopped provenance-mismatch audit at the v1 audit root;
- the preceding caller-snapshot audit;
- any repository implementation or repository audit conversation;
- the artifact-restoration conversation.

The stopped v1 audit is permanently nonqualifying. Its mismatch resulted from
an incorrect predecessor-copy filename in its prompt. Do not resume or amend
that audit.

Objective

Independently audit the exact source-external Evidence Verification v1 caller
successor that repairs:

1. fixed record-destination non-reusability; and
2. nonuniform depth enforcement for regular-file entries.

The Evidence Verification repository is frozen, read-only context. Do not
repair or modify the caller, repository, or supplied evidence.

No formatting, cleanup of supplied roots, staging, commit, push, PR, merge,
installation, deployment, A6 restart, product execution, live-service
invocation, network contact, or Linux binary execution.

No nested subagents.

## 1. Exact frozen inputs

Repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree — this is the only authoritative tree value in this prompt:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected repository manifest:

REPO_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f/provenance/manifest-run-1.json

Expected repository-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Expected restored repository inventory:

RESTORED_INVENTORY=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632/restoration/full-object-after.json

Expected governed repository objects:

477

Frozen predecessor caller-repair root:

PREDECESSOR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-repair-4a3a42441632-v1

Original predecessor caller:

PREDECESSOR_CALLER=$PREDECESSOR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Expected predecessor-caller identity:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

New successor-repair root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-repair-c030f2baf200-v1

Exact successor caller:

SUCCESSOR=$REPAIR_ROOT/source/launch_v3_trusted_host_reusable_depth12.py

Expected successor identity:

- size: 33758
- SHA-256:
  c24d79991539a1aa638480c45e7b3af86d8ea5f04134b7222da76f0e1bb91d24

Actual retained predecessor copy inside the successor-repair root:

PREDECESSOR_COPY=$REPAIR_ROOT/source/predecessor_caller_exact.py

Expected retained predecessor-copy identity:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

IMPORTANT INPUT CORRECTION

The following path is NOT expected to exist inside REPAIR_ROOT:

$REPAIR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Its absence is not a provenance mismatch.

The required retained predecessor copy is exactly:

$REPAIR_ROOT/source/predecessor_caller_exact.py

Require PREDECESSOR_COPY to be byte-identical to PREDECESSOR_CALLER.

Expected source delta:

SOURCE_DELTA=$REPAIR_ROOT/provenance/source-delta.diff

Expected source-delta identity:

- size: 9993
- SHA-256:
  06dd40b2e07aab14d436e8dd8d4f115b59cde1830cadd37431be395a096caeaa

Repair manifests:

REPAIR_MANIFEST_1=$REPAIR_ROOT/provenance/repair-manifest-run-1.json
REPAIR_MANIFEST_2=$REPAIR_ROOT/provenance/repair-manifest-run-2.json

Expected SHA-256 for each:

70e2a46949f2bc0eb25a799e60af2c44e73112a408bd119fc8e297a6203eec15

Expected repair-root closure:

- 108 regular files;
- 10 directories including the root;
- every retained regular file mode 0600 and single-link;
- every retained directory mode 0700;
- private tmp directory empty;
- the two repair manifests byte-identical;
- 106 SHA-bearing file rows covering every retained regular file except the
  exact two manifest paths;
- exactly those two manifest paths declared as self-exclusions;
- all 10 directory paths and modes covered;
- the manifest-covered predecessor copy is
  source/predecessor_caller_exact.py.

Expected implementation report:

IMPLEMENTATION_REPORT=$REPAIR_ROOT/closeout/implementation-report.md

Expected attempt index:

ATTEMPT_INDEX=$REPAIR_ROOT/provenance/attempt-index-final.json

Stopped prior audit, historical and nonqualifying:

STOPPED_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-independent-audit-70e2a46949f2-v1

You may inspect its provenance records only to confirm the prompt-input failure.
Do not use it as correctness evidence, resume it, or write into it.

Original vulnerable caller:

ORIGINAL_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected original-caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular, single-link;
- size: 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Fresh audit root, required absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-independent-audit-70e2a46949f2-v2

## 2. Authority and audit scope

Current authority split:

- The repository verifier is an ES-owned Bounded slice rule.
- Its output has structural-evidence authority only.
- The caller and its records are validation/provenance evidence only.
- Neither verifier nor caller owns product, runtime, admission, orchestration,
  readiness, durable-state, commit, publication, or deployment authority.
- Supported-local trusted-host assumptions and all existing nonclaims remain.
- Atomic interpreter custody is not claimed.

Audit scope:

- exact successor caller source;
- exact predecessor-to-successor delta;
- record-destination reusability and custody;
- uniform depth semantics;
- descriptor snapshot and output implementation;
- internal test-hook containment;
- record schema/protocol preservation;
- repair-root provenance and closure;
- exact-successor compatibility and negative causals.

Out of scope beyond provenance verification:

- repository authority-family design;
- test 89 and the repository’s 89-test suite;
- MK-01;
- product behavior;
- fresh A6 construction;
- commit or publication.

Do not reopen those topics unless the caller successor actually changes their
contract.

## 3. Audit-evidence posture

Before substantive inspection:

1. Require AUDIT_ROOT absent.
2. Set umask 077.
3. Create audit directories directly at mode 0700.
4. Create every retained audit file exclusively at mode 0600.
5. Do not truncate, overwrite, chmod-correct, or rewrite a retained record.
6. Capture subprocess output in memory before exclusively retaining it.
7. The parent writes all retained auditor reports.
8. Keep private audit TMPDIR empty at closeout.

If retained evidence posture fails, return:

PROCESS_BOUNDARY_BLOCK

Do not repair the same audit attempt.

Do not inspect primary-working-tree content. Repository Git reads must use only:

git -C "$IMPL_R" ...

with cwd exactly IMPL_R and explicit:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Auditors must run no Git.

Do not import repository modules. Any import-based causal must use an
audit-owned exact source copy with bytecode disabled.

## 4. Opening provenance

Before correctness inspection:

### Repository

Independently require:

- exact branch, HEAD, tree, parent, and absent upstream;
- exact canonical manifest and tracked diff;
- exact 477-object restored inventory by relative path;
- no cache, bytecode, test cache, generated artifact, or ignored extra path;
- zero staged, deleted, renamed, or unmerged paths.

### Repair root

Independently inventory REPAIR_ROOT by relative path.

Require:

- exactly 108 regular files and 10 directories;
- no symlink or special file;
- exact file and directory modes and link counts;
- exact successor, PREDECESSOR_COPY, source delta, reports, tests, and causals;
- PREDECESSOR_COPY byte-identical to PREDECESSOR_CALLER;
- empty tmp directory;
- both repair manifests canonical and byte-identical;
- exactly 106 SHA-bearing file rows;
- all nonmanifest retained files covered exactly once;
- exactly the two manifest paths self-excluded;
- all directories covered exactly once;
- no unexplained exclusion or later mutation.

The manifest’s retained predecessor-copy path must be:

source/predecessor_caller_exact.py

Do not substitute or require another filename.

Producer manifests are evidence, not authority. Create a separate audit-owned
complete inventory.

On any actual byte, path-set, mode, type, link, manifest, or repository
identity mismatch:

AUDIT_PROVENANCE_MISMATCH

Stop before source correctness inspection.

## 5. Four distinct auditors

After provenance matches, start three distinct read-only auditors concurrently:

1. Contract, CLI, protocol, record-schema, and source-delta auditor.
2. Record-destination and descriptor-output filesystem auditor.
3. Snapshot, depth, resource-limit, test, and provenance auditor.

After one completes and closes, start a fourth distinct auditor:

4. Security, hook reachability, record disclosure, compatibility, and artifact
   auditor.

Retry a failed start once.

If a required distinct auditor cannot start:

SUBAGENT_UNAVAILABLE

No nested delegation. No auditor mutation, Git, network, supplied-root write,
repository import, or test execution that can create repository artifacts.

Each auditor must report:

- exact operands inspected;
- actual cwd;
- source/evidence claims;
- inference;
- uncertainty;
- uninspected scope;
- disagreements;
- mutation performed: no;
- nested subagents: no.

## 6. Exact source-delta review

Independently compare PREDECESSOR_CALLER, PREDECESSOR_COPY, and SUCCESSOR.

Require:

- PREDECESSOR_CALLER and PREDECESSOR_COPY are byte-identical;
- SOURCE_DELTA exactly describes PREDECESSOR_COPY to SUCCESSOR;
- no unexplained source difference exists.

Require the semantic delta to be limited to:

1. removal of the fixed record directory;
2. generic caller-supplied record-parent validation and descriptor-relative
   output creation;
3. caller-evidence root derivation needed by the reusable successor;
4. uniform depth checking before observation of every entry type;
5. source-private deterministic test hooks and normal-main guards.

Confirm unchanged:

- CLI option names, order, required/optional status, and defaults;
- launch protocol:
  execution-substrate.evidence-closure-launch/v2;
- record schema:
  execution-substrate.evidence-closure-launch-record.v3;
- all 25 top-level record fields and their meanings;
- source-by-value verifier launch;
- interpreter posture;
- source, registry, and layout authentication;
- returned verifier-result validation;
- trusted-host nonclaims;
- every nonsnapshot and nondestination acceptance gate;
- error classes except destination/depth behavior required by the repair;
- no product/runtime/readiness/publication authority;
- no pathname payload-read fallback.

Return BLOCK for any unexplained semantic widening.

## 7. Record destination and caller-evidence semantics

Independently inspect the exact successor.

Verify:

- `--record` is the pre-existing argument, not a new protocol field;
- absolute-path and basename grammar enforcement;
- no-follow parent traversal;
- parent ownership and exact 0700 mode;
- held parent-directory descriptor;
- pre-existence checks for JSON/stdout/stderr outputs;
- ancestry checks against target, verifier package, candidate, TMPDIR, and
  interpreter installation;
- exclusive descriptor-relative 0600 creation;
- complete write, fsync, close, reobservation, and parent rebinding;
- preserved output order: stdout, stderr, JSON;
- no accepted result after destination uncertainty or partial output;
- no overwrite or record reuse;
- shared stdout discloses only the record basename;
- no absolute record destination enters the v3 record.

### Caller-evidence containment

The implementation report says `caller_evidence` follows the successor source
container.

Independently determine and causally test record destinations:

1. equal to the caller-evidence/source container;
2. beneath that container;
3. an ancestor containing that container.

None may produce an accepted invocation or mutate the frozen caller source
container without detection.

If current ancestry checks permit such a destination, or output can be created
there after the caller-evidence closing snapshot, return BLOCK.

Adjudicate whether `caller_evidence` retains its predecessor field meaning.

### Partial-output and failure atomicity

Deterministically inject failures:

- after stdout creation but before stderr creation;
- after both sidecars but before JSON creation;
- during a sidecar write;
- during fsync;
- during closing reobservation.

Require:

- no accepted JSON record;
- no overwrite;
- partial files are unambiguously nonaccepted evidence, or are handled by an
  already documented exact cleanup contract;
- retry of the same basename cannot silently reuse a partial attempt;
- no error is erased by verifier success.

A newly required schema field or protocol change is a BLOCK finding, not an
audit repair.

## 8. Reusability causals

Using exact SUCCESSOR bytes, not edited copies, independently test:

- two distinct external record directories accepted;
- a third later-A6-style record directory accepted without caller-byte change;
- neither PREDECESSOR_ROOT nor REPAIR_ROOT receives new output;
- existing JSON rejects;
- existing stdout rejects;
- existing stderr rejects;
- final symlink rejects;
- parent symlink rejects;
- wrong parent mode rejects;
- wrong owner rejects when safely injectable;
- unsafe basename rejects;
- relative path rejects;
- target equality and nesting reject;
- verifier-package equality and nesting reject;
- candidate equality and nesting reject;
- TMPDIR equality and nesting reject;
- interpreter-installation relationship rejects;
- caller-evidence/source-container relationships reject;
- parent replacement before output rejects;
- parent replacement during output rejects;
- repeated record basename does not overwrite or duplicate accepted evidence.

Use deterministic coordination.

## 9. Uniform depth and snapshot review

Verify:

- root depth is 0;
- entry depth is relative component count;
- maximum admitted depth is 12;
- the check applies to files and directories;
- entry depth greater than 12 rejects before stat, open, read, or descent;
- depth and path-byte failures remain distinct.

Independently run:

- root-only;
- file depth 1;
- directory depth 12;
- file depth 12;
- directory depth 13;
- file depth 13;
- child beneath depth-12 directory;
- exact predecessor-audit depth-13-leaf shape against predecessor and
  successor;
- instrumentation proving no over-depth stat/open/read/descent.

Rerun or independently reconstruct all previously passing snapshot causals:

- stable and canonical repeat;
- empty and nested trees;
- root/ancestor/internal symlink;
- special file;
- hardlink;
- replacement before and after open;
- in-place mutation;
- root and directory replacement;
- disappearance;
- type/mode/link changes;
- all file/directory/path/byte limits;
- capability denial and runtime descriptor-listing failure;
- zero watched-root writes.

Verify resource limits are enforced before unbounded allocation or read work.

## 10. Internal-hook reachability

Prove:

- all hooks default to null;
- normal `main()` rejects any non-null hook before destination preparation or
  child launch;
- no CLI option, environment variable, target, package, verifier result,
  registry/layout value, record field, or record path can set a hook;
- hooks are unavailable in ordinary source-by-value execution;
- no exception path retains a hook;
- tests import only audit-owned exact source copies;
- hooks cannot suppress or reorder destination, snapshot, provenance, or
  closing checks in normal execution.

Any normal-execution route to a hook is BLOCK.

## 11. Record schema and disclosure

Inspect producer and audit-owned records.

Require:

- exact v3 schema and v2 launch protocol;
- exact 25 top-level fields;
- unchanged field meanings;
- no watched-root or record absolute paths;
- no source text, payload, credential, or private endpoint;
- mandatory trusted-host nonclaims;
- `outcome="accepted"` only when destination, snapshot, verifier,
  provenance, and result gates all pass;
- no late error erased by accepted output;
- `caller_evidence` remains coherent and usable for future A6 evidence.

## 12. Fresh exact-successor compatibility

Every acceptance-bearing launch must use exact SUCCESSOR source bytes. Do not
edit, patch, copy-and-change, replace constants, or reconstruct its logic.

Use fresh external record directories satisfying the destination contract.

### A6D

Run sealed twice.

Require:

- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical stdout SHA-256:
  3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606;
- deterministic non-snapshot fields;
- equal target/package/TMPDIR/caller-evidence snapshots;
- safe exclusive 0600 outputs;
- unchanged A6D manifest;
- mandatory nonclaims.

### Amendment

Run sealed twice.

Require canonical stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same conditions.

### Synthetic A6

Create only an audit-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice.

Require exact successor bytes, accepted results, deterministic outputs per
stage, empty verifier stderr, and only the expected writer-owned seal
transition.

### SEC-02

Run a target-marker causal using exact successor source.

Require target script never loaded, marker absent, and direct-script
predecessor shape nonqualifying.

Do not claim atomic interpreter custody.

### Caller negatives

Freshly exercise:

- wrong interpreter hash and size;
- source mismatch;
- registry/layout result mismatch;
- package/target containment;
- snapshot uncertainty/replacement/capability failure;
- invalid destination;
- parent replacement;
- file depth 13;
- partial-output failures.

Require exact or stricter compatible nonaccepting classifications.

## 13. Closing provenance and artifacts

Remove only audit-owned temporary fixtures.

At closeout require:

- unchanged repository manifest and tracked diff;
- exact 477-object repository inventory;
- unchanged PREDECESSOR_ROOT;
- unchanged PREDECESSOR_AUDIT if inspected;
- unchanged REPAIR_ROOT;
- exact 108-file/10-directory repair-root inventory;
- unchanged producer manifests;
- unchanged A6D and amendment manifests;
- no child, process, or descriptor survivor;
- empty audit tmp;
- every retained audit file regular, single-link 0600;
- every retained audit directory 0700.

## 14. Verdict rules

ACCEPT only if:

- provenance matches;
- source delta is bounded and explained;
- record destination is reusable and safely external;
- caller-evidence semantics remain coherent;
- partial-output behavior cannot create ambiguous accepted evidence;
- depth 12 is uniformly enforced;
- hooks are unreachable in normal execution;
- independent causals pass;
- exact-successor compatibility passes;
- protocol, schema, nonclaims, and authority remain unchanged;
- no process or artifact blocker remains.

BLOCK for a repairable caller, test, evidence, provenance-format, redaction,
resource, failure-atomicity, or validation defect.

REJECT only for a fundamental architecture or authority defect.

AUDIT_PROVENANCE_MISMATCH only for an actual input, repository, repair-root,
manifest, inventory, or closing identity mismatch—not for the corrected
filename that this prompt explicitly identifies.

PROCESS_BOUNDARY_BLOCK for an audit-process violation or retained-evidence
posture failure.

SUBAGENT_UNAVAILABLE if a required auditor cannot start after one retry.

## 15. Required inline report

Include:

1. Verdict.
2. Exact repository and repair-root identities.
3. Audit-evidence posture.
4. Opening and closing provenance.
5. Corrected predecessor-copy-path reconciliation.
6. Repair-manifest self-exclusion adjudication.
7. Four auditor identities, roles, scheduling, operands, and status.
8. Exact source delta.
9. CLI, protocol, and schema preservation.
10. Record-destination contract and reusability.
11. Caller-evidence containment and field-meaning adjudication.
12. Partial-output and failure-atomicity adjudication.
13. Descriptor-output algorithm.
14. Uniform depth and resource-limit adjudication.
15. Internal-hook reachability.
16. Vulnerable predecessor causals.
17. Independent successor causal matrix.
18. Record schema and disclosure.
19. A6D results.
20. Amendment results.
21. Synthetic A6 results.
22. SEC-02 result.
23. Caller-negative results.
24. No-write and deterministic-output evidence.
25. Authority and security adjudication.
26. Severity-ranked residual findings.
27. Minority findings and parent resolution.
28. Remaining uncertainty and nonclaims.
29. Audit-created paths and cleanup.
30. Explicit confirmations:
    - repository mutation not performed;
    - supplied evidence mutation not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

Do not stage, commit, push, or restart A6.
```

## Sources

The successor implementation reports that it is complete but still requires fresh independent audit.  Its repository, predecessor, verifier, and interpreter identities were frozen at implementation opening.  Its repair manifests cover all other retained files and exclude only their own two paths. 

The audit’s stop-before-correctness behavior was correct under the project provenance protocol: provenance must be reproduced before inspection, and any mismatch stops the audit.  Provenance is an evidence mechanism, not proof of correctness or authority. 

**Confidence**

- The mismatch was caused by the audit prompt’s wrong filename: **0.999**
- The repair root itself showed no provenance drift: **0.99**
- No implementation or reconciliation tranche is warranted: **0.995**
- A fresh `v2` audit with the corrected path is the right next action: **0.999**
