## Engineering assessment

This report supports moving directly to **one fresh independent audit**.

The repair is materially complete, not another partial preflight result. Codex reports that the harness now produces terminal phase records, phase-specific evidence, an explicit child ledger, all 20 required evidence domains, complete mode-aware runtime reports and confirmations, effect-derived subject status, findings and preseal evidence, cleanup and fixed-input equality, temporal inventory, byte-identical manifests, final reprojection, and a true no-operation-after-seal transition. :chatgpt-content-reference{index="0"}

Qualification also covered the exact historical failure surfaces:

- phase terminalization: `45/45`;
- phase evidence: `35/35`;
- evidence-domain completeness: `60/60`;
- child custody: `35/35`;
- runtime report and confirmation: `50/50` each;
- subject-effect attribution: `35/35`;
- cleanup/equality: `40/40`;
- temporal/manifest/reprojection: `60/60`;
- seal ordering: `40/40`;
- unchanged governed suites: `15/595`, `151`, `171`, instance-state, constructor, and packaged-resolver suites. :chatgpt-content-reference{index="1"}

The three packaged rehearsals then traversed the actual repaired path:

- ACCEPT produced a complete accepted capsule with `subject_constructed=false`;
- BLOCK retained a direct package blocker and complete sealed evidence;
- provenance failure retained one audit-provenance blocker without promoting a package verdict;
- all three were independently validated with zero errors. :chatgpt-content-reference{index="2"}

The final package chain also closed:

- 43 source files froze and remained unchanged;
- PYZ v4 Build A/B were byte-identical;
- the final PYZ contains 154 members;
- authority-v5 Build A/B were byte-identical;
- post-package qualification passed;
- launch-certificate-v3 Build A/B were byte-identical;
- independent certificate-input validation passed;
- frozen-PYZ v4 requalification exited zero with empty stderr. :chatgpt-content-reference{index="3"}

### Final authority-bearing artifacts

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.pyz
```

- device/inode: `16777234 / 182454073`
- mode/link count: `0400 / 1`
- size: `2,868,243`
- SHA-256: `541063469c8c7a31c790b4ed2899d4bc3df7798f22bc0f0e5a19c73d06e64767`

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.authority-v5.json
```

- device/inode: `16777234 / 182454077`
- mode/link count: `0400 / 1`
- size: `9,630`
- SHA-256: `72bb569b9c6ae00cd2057235e043bb07be2edff6bcb815a2adfb6ee792ca1097`

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.launch-certificate-v3.json
```

- device/inode: `16777234 / 182454084`
- mode/link count: `0400 / 1`
- size: `8,260`
- SHA-256: `a511cea82cff8edbfb234d77e0ff875bdccdfd0e96e0d8a2e39460c8dffaec61` :chatgpt-content-reference{index="4"}

### One caveat that must not become another false blocker

The first finalization pass used a predecessor-only validator that requested:

```text
pyz-member-registry-v2.json
```

The current PYZ v4 instead binds:

```text
package/pyz-member-registry-v3.json
```

Codex retained that failed finalization closeout, then completed a source-external v4-aware recomputation without changing frozen source or final bytes. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

The audit wrapper must therefore use the **current certificate, authority-v5, and `pyz-member-registry-v3.json`**. It must not resurrect a `v2` registry requirement.

### Progression decision

Execute exactly **one** fresh audit.

No additional source repair, documentary contract, qualification, replay, authority, or certificate tranche is justified beforehand. The certificate authorizes one future audit, while no real audit or implementation verdict has yet occurred. :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"}

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE FRESH INDEPENDENT AUDIT OF THE SEALED
GENERATION-2 RECONSTRUCTION-PARENT IMPLEMENTATION EVIDENCE

USING FINAL HARNESS PYZ V4, RUNTIME AUTHORITY V5, AND
EXTERNAL LAUNCH CERTIFICATE V3

Objective

Execute exactly one fresh independent audit using these five exact current
authority files:

1. final clean harness PYZ v4;
2. final runtime harness authority v5;
3. final external launch certificate v3;
4. current-authority content snapshot ZIP;
5. current content-snapshot authority JSON.

The external wrapper must authenticate launch certificate v3 before process
creation.

The harness must receive authority v5 through `--harness-authority`.

The launch certificate is external wrapper authority. Do not pass it to the
harness unless the exact current CLI contract expressly requires it.

Capture top-level process creation and completion exactly.

After the process completes:

- retain raw streams before parsing;
- parse only under the exact stream/framing contract bound by certificate v3
  and the final PYZ;
- authenticate the one exact supplied audit root;
- inspect the capsule read-only;
- independently authenticate all governed evidence and terminal closure;
- report the exact harness disposition;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute `qualify-harness`.

Do not launch a replacement, recovery, continuation, or second audit parent.

Do not run a direct implementation auditor outside the frozen harness.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run a target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

The wrapper primary verdict must preserve the exact current harness
disposition. Expected governed dispositions are:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

GEN2_IMPLEMENTATION_PACKAGE_BLOCK

AUDIT_PROVENANCE_MISMATCH

Do not normalize a specific harness disposition to generic ACCEPT or BLOCK.

If a prelaunch gate or platform preflight fails before process creation, return:

AUDIT_PROVENANCE_MISMATCH

and explicitly state:

FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED
FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. EXACT FIVE-FILE AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

FINAL_HARNESS_PYZ_V4:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.pyz

Expected identity:

- device:
  16777234
- inode:
  182454073
- mode:
  0400
- link count:
  1
- size:
  2868243
- SHA-256:
  541063469c8c7a31c790b4ed2899d4bc3df7798f22bc0f0e5a19c73d06e64767

FINAL_RUNTIME_AUTHORITY_V5:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.authority-v5.json

Expected identity:

- device:
  16777234
- inode:
  182454077
- mode:
  0400
- link count:
  1
- size:
  9630
- SHA-256:
  72bb569b9c6ae00cd2057235e043bb07be2edff6bcb815a2adfb6ee792ca1097

FINAL_EXTERNAL_LAUNCH_CERTIFICATE_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-v4-output-75mwkz4f/gen2-clean-source-external-independent-audit-harness-v4.launch-certificate-v3.json

Expected identity:

- device:
  16777234
- inode:
  182454084
- mode:
  0400
- link count:
  1
- size:
  8260
- SHA-256:
  a511cea82cff8edbfb234d77e0ff875bdccdfd0e96e0d8a2e39460c8dffaec61

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

All containing directories are nonauthoritative.

Do not inspect or depend on unrelated directory members.

Do not open predecessor harness packages, predecessor authorities, consumed
certificates, failed audit roots, repair roots, rehearsal roots, draft roots, or
documentary tooling roots.

──────────────────────────────────────────────────────────────────────────────
2. STABLE PRELAUNCH FILE AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO CURRENT FILES
────────────────────────────────────────────────

Before allocating an audit root or launching any process, authenticate all five
files.

For every file:

1. open no-follow;
2. require a regular file;
3. require mode `0400`;
4. require link count one;
5. retain device, inode, size, and SHA-256;
6. perform two stable reads;
7. require byte and metadata equality.

Strict-parse:

- authority v5;
- launch certificate v3;
- content authority JSON;

using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any predicate fails:

- do not allocate an audit root;
- do not run platform preflight;
- do not create the audit parent;
- return `AUDIT_PROVENANCE_MISMATCH`;
- retain the exact first blocker;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
3. LAUNCH-CERTIFICATE V3 AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO ACTUAL SCHEMA
────────────────────────────────────────────────

Strictly validate certificate v3 under its exact current schema.

Require it to bind:

- exact PYZ-v4 identity;
- exact authority-v5 identity;
- exact content-bundle identity;
- exact content-authority identity;
- exact source-freeze identity;
- production source registry;
- qualification source registry;
- independent source registry;
- deterministic PYZ Build-A/Build-B equality;
- exact PYZ member count:
  154;
- exact current member registry:
  `package/pyz-member-registry-v3.json`;
- all three governing documentary-package identities;
- exact five-domain governance:
  5 documentary domains,
  66 report IDs,
  81 confirmation names,
  15 matrices,
  595 cases;
- exact interpreter-tuple governance;
- exact 113-dependency and 108/5 record-class governance;
- capsule-authority repair qualification;
- phase-terminalization qualification;
- phase-evidence qualification;
- child-custody qualification;
- evidence-domain qualification;
- mode-aware report and confirmation qualification;
- subject-effect attribution qualification;
- cleanup/equality qualification;
- temporal/manifest/reprojection qualification;
- seal-ordering qualification;
- packaged ACCEPT rehearsal;
- packaged BLOCK rehearsal;
- packaged provenance rehearsal;
- independent capsule validation;
- post-package qualification;
- certificate-input validation;
- frozen-PYZ-v4 requalification;
- exact future `run-full-audit` invocation;
- wrapper launch authorized:
  true;
- authorized future audit count:
  1;
- real audit already executed:
  false;
- implementation verdict:
  not issued;
- current schema subject constructed:
  false.

Do not require:

- `package/pyz-member-registry-v2.json`;
- a predecessor-only finalization role;
- an evidence path superseded by current v4 roles;
- certificate self-validation;
- an unbound fixed cwd.

Certificate v3 is the external launch authority.

Authority v5 is the runtime authority supplied to the harness.

Any actual inconsistency:

- do not allocate the audit root;
- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`;
- leave authorization unconsumed.

──────────────────────────────────────────────────────────────────────────────
4. PYZ V4 MEMBER AND GOVERNANCE CLOSURE
──────────────────────────────────────────────── LIMITED TO CURRENT PACKAGE
────────────────────────────────────────────────

Parse the PYZ directly.

Require exact correspondence with certificate v3, authority v5, and:

package/pyz-member-registry-v3.json

Require:

- exactly 154 members;
- raw UTF-8 byte-sorted member names;
- ZIP_STORED only;
- frozen timestamp;
- `create_system=3`;
- member mode `0600`;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no archive or member comment;
- no uncontrolled extra field;
- no cache or bytecode;
- no stale compatibility alias.

Resolve embedded current artifacts only through exact role registries.

Independently recompute:

- documentary domains:
  5;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrices:
  15;
- runtime matrix cases:
  595;
- stale 645 accepted:
  false;
- interpreter roles:
  3;
- terminal-runtime-image role:
  absent;
- governed dependencies:
  113;
- schema-discriminated dependencies:
  108;
- schema-version-discriminated dependencies:
  5;
- capsule paths:
  66;
- capsule writer bindings:
  66;
- phases:
  25;
- required audit-evidence domains:
  20;
- content roles:
  8;
- content members:
  479.

Authenticate current embedded roles for:

- entrypoint;
- source freeze;
- source registries;
- current member registry v3;
- governing documentary records;
- dependency/member-role/record-class registries;
- report and confirmation registries;
- runtime matrix registry;
- phase plan;
- capsule authority contract;
- capsule path registry;
- writer registry;
- child custody contract;
- cleanup/equality contracts;
- temporal/manifest lifecycle;
- package status;
- qualification and rehearsal evidence bound by certificate v3.

Do not invent a stronger launch predicate.

Do not weaken a governed predicate.

Any discrepancy:

- do not allocate the audit root;
- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
5. WRAPPER AND AUDIT-ROOT ALLOCATION
──────────────────────────────────────────────── LIMITED TO PRIVATE PATHS
────────────────────────────────────────────────

After Sections 2–4 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Using:

- tempfile.mkdtemp;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-fresh-independent-audit-v4-wrapper-`;
- umask:
  `077`.

Use it only for wrapper-owned:

- file-authentication evidence;
- certificate/PYZ closure;
- platform-preflight custody;
- audit-parent custody;
- raw stream copies;
- read-only capsule-adjudication records;
- final wrapper report.

B. FRESH_PRIVATE_AUDIT_ROOT

Using:

- tempfile.mkdtemp;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-fresh-independent-audit-v4-`;
- umask:
  `077`.

Immediately retain:

- absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty opening inventory.

Require:

- directory;
- no symlink;
- mode `0700`;
- empty before preflight;
- empty immediately before audit-parent creation.

Use the same exact path as:

- the `--audit-root` operand;
- submitted cwd.

Cwd is external-wrapper launch custody.

If the certificate is silent about a fixed cwd, do not treat that silence as a
mismatch.

The capsule must later prove runtime cwd equals the submitted cwd.

If a prelaunch failure occurs:

- retain evidence;
- remove only the wrapper-owned empty audit root after identity revalidation;
- observe ENOENT twice;
- audit authorization remains unconsumed.

After audit-parent creation:

- authorization is consumed;
- preserve the audit root unchanged regardless of outcome.

──────────────────────────────────────────────────────────────────────────────
6. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────── LIMITED TO WRAPPER CUSTODY
────────────────────────────────────────────────

Run exactly one harmless synchronous preflight.

This does not consume the audit authorization.

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

Use a program equivalent to:

import os
os.write(1, b"PLATFORM_CAPTURE_STDOUT_V1\n")
os.write(2, b"PLATFORM_CAPTURE_STDERR_V1\n")
os._exit(23)

Submitted cwd:

the exact FRESH_PRIVATE_AUDIT_ROOT

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Retain:

- argv;
- cwd;
- environment;
- PID;
- start/completion;
- duration;
- raw streams;
- sizes and SHA-256;
- exit/signal;
- reaping;
- descriptor closure.

Expected stdout:

- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

Expected exit:

23

Expected signal:

null

After preflight require the audit root remains empty.

If preflight or root emptiness fails:

- do not create the audit parent;
- remove the wrapper-owned empty audit root after evidence retention;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
7. EXACT REAL-AUDIT INVOCATION
──────────────────────────────────────────────── LIMITED TO ONE PROCESS
────────────────────────────────────────────────

Derive the exact invocation from certificate v3 and authority v5.

Require it to use the current paths and semantic operands:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_HARNESS_PYZ_V4>
--mode
run-full-audit
--harness-authority
<FINAL_RUNTIME_AUTHORITY_V5>
--content-bundle
<CURRENT_CONTENT_BUNDLE>
--content-authority
<CURRENT_CONTENT_AUTHORITY>
--audit-root
<FRESH_PRIVATE_AUDIT_ROOT>

If the exact current CLI uses different option spellings, use only the spellings
strictly derived from certificate v3 and the final embedded CLI contract.
Do not infer them from an older generation.

Do not pass launch certificate v3 to the harness unless the exact current CLI
contract requires it. The reported architecture classifies it as wrapper
authority.

Do not pass:

- predecessor authority;
- consumed certificate;
- documentary roots;
- implementation root;
- historical root;
- continuation or recovery option;
- any extra operand.

Submitted cwd:

the exact FRESH_PRIVATE_AUDIT_ROOT

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Immediately before process creation:

- reauthenticate all five fixed files;
- reauthenticate audit-root identity;
- require the audit root remains empty.

Launch synchronously.

Launch count:

exactly one.

The authorization is consumed only when process creation succeeds.

After creation it remains consumed regardless of disposition or custody
failure.

Do not launch:

- `qualify-harness`;
- replacement or recovery parent;
- continuation;
- direct implementation auditor;
- post-failure validator;
- second audit.

──────────────────────────────────────────────────────────────────────────────
8. TOP-LEVEL PROCESS CUSTODY
──────────────────────────────────────────────── LIMITED TO EXTERNAL PLATFORM
────────────────────────────────────────────────

Retain the complete process result before parsing:

- custody ID;
- creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- exact cwd;
- submitted environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and hashes;
- exit code;
- signal;
- process error;
- reaping;
- descriptor closure;
- identities of all five fixed files at launch;
- audit-root identity at launch.

The wrapper is authoritative for top-level process creation and completion.

The capsule crosswalks runtime-observed evidence to that custody; it does not
replace external custody.

If completion capture is missing after creation:

- do not scan for another root;
- do not guess;
- do not retry;
- preserve the exact audit root;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
9. STREAM AND TERMINAL-FRAME CONTRACT
──────────────────────────────────────────────── LIMITED TO CURRENT CONTRACT
────────────────────────────────────────────────

Retain raw streams before parsing.

Parse only under the exact stream/framing contract bound by certificate v3 and
the final PYZ.

Do not assume a separate locator line unless the current contract explicitly
requires it.

The audit root is already supplied through `--audit-root`.

Require:

- exact handled-terminal stdout posture;
- exact handled-terminal stderr posture;
- no duplicate frame;
- no trailing bytes;
- strict UTF-8 JSON;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact frame schema;
- exact disposition;
- exact preseal, terminal, temporal, and manifest identities;
- exact seal and no-postseal fields.

Require equality:

terminal-frame audit root
=
submitted audit root
=
submitted cwd
=
capsule root identity.

If the process exits under a current frozen unhandled-failure posture:

- return `AUDIT_PROVENANCE_MISMATCH`;
- do not scan for alternatives;
- preserve the supplied audit root;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
10. READ-ONLY CAPSULE INSPECTION
──────────────────────────────────────────────── LIMITED TO SUPPLIED ROOT
────────────────────────────────────────────────

Authenticate and inspect only the exact supplied audit root.

Do not:

- scan for another root;
- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute implementation source;
- run another validator process;
- regenerate or add evidence;
- replace a record or manifest.

Resolve authoritative records only through:

- terminal frame;
- capsule path registry;
- capsule indexes;
- manifests.

For every record retain:

- relative path;
- schema;
- mode;
- link count;
- size;
- SHA-256;
- authority role.

──────────────────────────────────────────────────────────────────────────────
11. PARENT SELF-AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO GOVERNED CROSSWALK
────────────────────────────────────────────────

Authenticate:

opening/parent-runtime-self-authentication.json

Crosswalk with external platform custody.

Require:

- declared Framework launcher;
- launcher-valued `sys.executable`;
- launcher-valued `_base_executable`;
- governed Python.app `sys.orig_argv[0]`;
- exact argv tail;
- exact application argv;
- exact runtime cwd equal submitted audit root;
- exact runtime PID equal platform PID;
- required Python flags;
- exact PYZ identity;
- exact authority-v5 identity;
- exact content inputs;
- exact source freeze;
- no terminal-runtime-image role;
- no kernel-image claim;
- no role substitution or path fallback.

Environment must preserve the exact five submitted rows.

Permit only the governed optional:

__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0

when its UID relation and zero components pass.

Reject every unknown extra.

Require:

top_level_process_authority = external_platform_wrapper

Failure is audit provenance, not a package finding.

──────────────────────────────────────────────────────────────────────────────
12. CAPSULE PATH, WRITER, PHASE, AND CUSTODY CLOSURE
──────────────────────────────────────────────── LIMITED TO GOVERNED ROLES
────────────────────────────────────────────────

Authenticate the exact 66-role capsule path registry and the exact 66
single-writer bindings.

Require:

- every mandatory role present once;
- no unknown path;
- no duplicate role;
- no overwrite or adoption;
- no staging misuse;
- exact schemas.

Authenticate all P00–P24 records.

Require:

- 25 unique records;
- every phase terminal;
- explicit status;
- phase-specific evidence;
- evidence pointers resolve;
- first blocker or null;
- continuation decision;
- cleanup obligations;
- authority contribution;
- completion timestamp.

Generic phase evidence as the sole evidence is forbidden.

Authenticate:

provenance/complete-child-ledger.json
provenance/child-process-custody-result.json

A zero-child audit is valid only when explicitly retained.

Require all created children reaped and all descriptors closed.

──────────────────────────────────────────────────────────────────────────────
13. REQUIRED EVIDENCE DOMAINS
──────────────────────────────────────────────── LIMITED TO COMPLETE CAPSULE
────────────────────────────────────────────────

Require all 20 governed evidence domains, including:

- implementation lineage;
- production registry;
- qualification registry;
- source freeze;
- frozen requalification;
- production security;
- E00/G00–G29 crosswalk;
- documentary lifecycle/writers;
- 15/595 matrices;
- 946 result;
- 137 result;
- 766/333 field map;
- producer rehearsal;
- Attempt-2 evidence;
- implementation confirmations;
- constructed-subject evidence;
- behavioral causals;
- fresh source-external validation;
- security/authority closure;
- dependency access.

Every record must contain current audit adjudication and declare its authority
posture.

A generic shared summary does not satisfy multiple roles.

──────────────────────────────────────────────── LIMITED TO CURRENT AUDIT
────────────────────────────────────────────────

14. RUNTIME REPORT AND CONFIRMATIONS

Runtime report:

- exactly R01–R66;
- exactly 66 rows;
- mode `run-full-audit`;
- explicit applicability, status, value, evidence, and authority;
- no placeholder values;
- no blanket N/A;
- evidence pointers resolve.

Runtime confirmations:

- exact 81 names;
- exactly 81 rows;
- mode `run-full-audit`;
- applicability;
- observed;
- expected;
- pass;
- evidence;
- authority role.

Require `pass` to derive from observed versus expected.

Require correct false observations where governed.

Require subject-related confirmations to match the effect-attribution result.

Any contradiction fails audit provenance.

────────────────────────────────────────────────

15. SUBJECT-EFFECT ATTRIBUTION

Authenticate:

analysis/current-subject-effect-attribution.json

Require derivation from:

- created-root registry;
- filesystem-effect ledger;
- child-effect ledger;
- capsule output classification;
- content read set;
- product/live-service invocation ledger.

The audit harness is not authorized to construct the current subject.

Require:

subject_constructed = false

with affirmative effect-ledger proof.

If true:

- classify AUDIT_AUTHORITY_VIOLATION;
- wrapper verdict AUDIT_PROVENANCE_MISMATCH;
- do not treat it as package evidence.

────────────────────────────────────────────────

16. EMBEDDED DEPENDENCY ACCESS

Require:

- exactly 113 dependency roles;
- access set equals current registry;
- every role resolved semantically;
- exact member identity;
- correct record-class parser;
- correct discriminator;
- no stale path;
- no direct acceptance-bearing member path;
- no alias or fallback;
- bootstrap uses `schema_version`;
- governed matrix uses current role;
- no `embedded-record-unavailable`;
- no instance-state failure.

Failure is audit provenance unless independently proven to be a current package
defect.

────────────────────────────────────────────────

17. IMPLEMENTATION AUDIT EVIDENCE

Authenticate and report:

- content closure;
- attempt lineage;
- source registries;
- source freeze and requalification;
- production authority/static security;
- E00/G00–G29;
- documentary lifecycle/writers;
- 15/595;
- 946;
- 137;
- 766/333;
- producer rehearsals;
- Attempt-2 bounded failure evidence;
- implementation confirmations;
- constructed-subject domain;
- fresh causals;
- fresh source-external validation;
- security/authority closure.

Do not execute implementation source.

Separate findings:

- direct package;
- audit;
- derivative;
- mixed;
- unresolved.

Direct package blockers require direct current evidence.

────────────────────────────────────────────────

18. FINDINGS AND PRESEAL RESULT

Authenticate:

analysis/findings-and-dependency-graph.json
closeout/preseal-substantive-result.json

Require:

- complete finding ownership;
- severity;
- direct evidence;
- dependency edges;
- affected phases;
- disposition effects;
- first blocker;
- phase distribution;
- cleanup posture;
- fixed-input-equality posture;
- subject-effect posture;
- `authoritative=false`;
- `terminal_closure_required=true`.

An empty producer findings list is not independently sufficient.

────────────────────────────────────────────────

19. CLEANUP AND FIXED-INPUT EQUALITY

Authenticate:

cleanup/cleanup-result.json
closing/fixed-input-closing-equality.json

Cleanup requires canonical rows and exact set equality.

Equal empty sets pass.

Require zero process, descriptor, cache, and bytecode survivors.

Capsule input equality covers:

- PYZ v4;
- authority v5;
- content bundle;
- content authority.

The launch certificate is wrapper-owned and is covered through wrapper-level
five-file equality.

────────────────────────────────────────────────

20. TEMPORAL, MANIFEST, REPROJECTION, AND SEAL

Authenticate:

closeout/temporal-final-inventory.json
manifest/canonical-manifest-a.json
manifest/canonical-manifest-b.json
terminal/terminal-result.json
terminal frame

Require:

- immediate temporal reprojection;
- root row once;
- A/B existence;
- A/B byte equality;
- exact manifest identities;
- final independent reprojection;
- no empty descendant;
- no symlink/special object;
- no multiply linked file;
- directory/file modes 0700/0600;
- no cache/bytecode;
- one seal transition;
- terminal frame emitted after closure;
- no filesystem/process/inventory/validation operation after seal.

A clean external directory inventory does not substitute for manifest-backed
closure.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

────────────────────────────────────────────────

21. WRAPPER FIVE-FILE CLOSING EQUALITY

After process completion, repeat stable no-follow identity checks for all five
fixed files.

Require exact equality with opening.

Do not mutate any fixed file.

Failure forces:

AUDIT_PROVENANCE_MISMATCH

────────────────────────────────────────────────

22. FINAL VERDICT RULES

Report:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

only when:

- all five files authenticate;
- certificate authorizes launch;
- process custody completes;
- parent self-authentication passes;
- path/writer/phase/custody closure passes;
- all evidence domains exist;
- report/confirmations close;
- subject was not constructed;
- dependency closure passes;
- no direct package blocker remains;
- preseal disposition is ACCEPT;
- terminal disposition is GEN2_IMPLEMENTATION_PACKAGE_ACCEPT;
- cleanup/equality/manifest closure pass.

Report:

GEN2_IMPLEMENTATION_PACKAGE_BLOCK

only when:

- all provenance gates pass;
- at least one direct current package blocker exists;
- findings/dependencies are complete;
- preseal disposition is BLOCK;
- terminal disposition is GEN2_IMPLEMENTATION_PACKAGE_BLOCK;
- cleanup/equality/manifest closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for any failure of:

- fixed inputs or certificate;
- custody/framing/root authentication;
- self-authentication;
- path/writer/phase/evidence closure;
- child custody;
- reports/confirmations/matrices;
- subject-effect attribution;
- dependency access;
- finding ownership;
- cleanup/equality;
- temporal/manifests/reprojection/seal;
- wrapper closing equality.

Do not retry.

────────────────────────────────────────────────

23. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all five files;
- preserve audit root unchanged;
- do not clean the capsule;
- do not construct current subject;
- do not run product modes;
- do not run target audit or runtime validation;
- do not modify a repository;
- do not commit or push;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

24. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Five fixed-file identities
3. Stable authentication
4. Certificate authentication
5. PYZ/member closure
6. Wrapper evidence-root identity
7. Audit-root identity
8. Platform preflight
9. Exact argv/cwd/environment
10. Top-level custody
11. Raw streams
12. Exit/signal
13. Terminal frame
14. Root post-run authentication
15. Parent self-authentication
16. Interpreter/environment crosswalk
17. Path/writer closure
18. P00–P24
19. Child custody
20. Twenty evidence domains
21. R01–R66
22. 81 confirmations
23. Subject effects
24. Dependency closure
25. Content/implementation source closure
26. Production security
27. E00/G00–G29
28. Documentary lifecycle/writers
29. 15/595
30. 946
31. 137
32. 766/333
33. Producer rehearsals
34. Attempt-2 evidence
35. Implementation confirmations
36. Constructed-subject domain
37. Fresh causals
38. Fresh source-external validation
39. Security/authority closure
40. Findings/ownership/dependency graph
41. Preseal disposition
42. Cleanup
43. Capsule input equality
44. Wrapper five-file equality
45. Temporal identity
46. Manifest identities
47. Reprojection
48. Topology/modes
49. Seal/no-postseal
50. Confirmation current subject not constructed
51. Confirmation no product/runtime/target/A6 activity
52. Remaining uncertainty/nonclaims
53. Explicit wrapper confirmations

Required confirmations:

FINAL_PYZ_V4_IDENTITY_MATCHED
FINAL_AUTHORITY_V5_IDENTITY_MATCHED
FINAL_LAUNCH_CERTIFICATE_V3_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
LAUNCH_CERTIFICATE_CURRENT_AND_COHERENT
LAUNCH_CERTIFICATE_AUTHORIZED_ONE_AUDIT
PYZ_MEMBER_SET_154_CLOSED
CURRENT_MEMBER_REGISTRY_V3_USED
PREDECESSOR_MEMBER_REGISTRY_V2_NOT_REQUIRED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
LAUNCH_CERTIFICATE_NOT_PASSED_TO_HARNESS
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_SUPPLIED_ROOT
PARENT_RUNTIME_SELF_AUTHENTICATION_RETAINED
INTERPRETER_OBSERVATION_TUPLE_PASSED
RUNTIME_ENVIRONMENT_POLICY_PASSED
RUNTIME_CWD_EQUALS_WRAPPER_SUBMITTED_CWD
CAPSULE_PATH_SET_66_COMPLETE
CAPSULE_WRITER_SET_66_COMPLETE
EVERY_REQUIRED_PHASE_TERMINAL
PHASE_SPECIFIC_EVIDENCE_COMPLETE
CHILD_LEDGER_RETAINED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
ALL_20_EVIDENCE_DOMAINS_RETAINED
RUNTIME_REPORT_66_COMPLETE
RUNTIME_CONFIRMATIONS_81_COMPLETE
CURRENT_SUBJECT_STATUS_EFFECT_DERIVED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
DEPENDENCY_ACCESS_SET_113_COMPLETE
DEPENDENCY_ACCESS_EQUAL_CURRENT_REGISTRY
NO_EMBEDDED_RECORD_UNAVAILABLE
NO_INSTANCE_STATE_FAILURE
FINDING_OWNERSHIP_COMPLETE
PRESEAL_RESULT_RETAINED
CLEANUP_RESULT_RETAINED
CAPSULE_FIXED_INPUT_CLOSING_EQUALITY_RETAINED
WRAPPER_FIVE_FILE_CLOSING_EQUALITY_PASSED
TEMPORAL_INVENTORY_RETAINED
MANIFEST_A_RETAINED
MANIFEST_B_RETAINED
MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_PASSED
ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_SEAL
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Source and confidence

This assessment is based on the attached Codex report, not an independent read of the private roots. The report nevertheless contains internally coherent identities, qualification results, rehearsals, source-freeze evidence, final package identities, and an explicit account of the one superseded finalization pass. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

**Provenance confidence:** 0.96  
**Validation confidence:** 0.99  
**Implementation-readiness confidence:** 0.98  
**Next-step confidence:** 0.995

Some older project uploads have expired. Re-upload an older artifact only if the next review needs its original bytes rather than the retained identities and reports.
