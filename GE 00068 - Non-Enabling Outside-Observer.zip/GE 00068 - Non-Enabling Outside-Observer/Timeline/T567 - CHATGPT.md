## Engineering assessment

The real audit did not execute, and the successor authorization remains unconsumed. The wrapper stopped at the correct prelaunch boundary: no wrapper root, workspace, platform-preflight process, audit parent, streams, capsule, or subject verdict was created. :chatgpt-content-reference{index="0"}

The sole defect is now sharply bounded. **Launch profile v3 contains four stale root-inventory digests**, while all three other views agree:

1. launch certificate v4;
2. runtime authority v2;
3. two stable, no-follow live filesystem projections.

The agreed current digests are:

| Bound root | Current canonical inventory digest |
|---|---|
| Replacement subject | `eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3` |
| Construction wrapper | `9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e` |
| Accepted implementation audit | `3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d` |
| Accepted implementation wrapper | `6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108` |

:chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

Profile v3 does not declare an alternate inventory algorithm, so this is not an algorithm-selection dispute. It is stale metadata in one external launch-authority artifact. :chatgpt-content-reference{index="3"}

### Classification

```text
STALE_EXTERNAL_LAUNCH_PROFILE_ROOT_INVENTORY_BINDINGS
```

The repair owner is the successor launch-profile producer and its dependent certificate chain. The defect is not in:

- the replacement subject;
- the construction wrapper;
- the accepted implementation package;
- the audit PYZ;
- runtime authority v2;
- the semantic audit logic;
- the split-root lifecycle;
- the current content snapshot.

The report explicitly reaches the same ownership conclusion. :chatgpt-content-reference{index="4"}

### Required correction

Create immutable successors:

```text
gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json
gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json
```

Preserve byte-for-byte:

- successor audit PYZ v2;
- runtime authority v2;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle and authority.

Profile v4 should differ from profile v3 only where required to:

- bind the four canonical current inventory digests;
- identify profile v3 as superseded;
- identify profile v4 as current;
- update profile identity/version fields;
- preserve every execution-control and split-root field unchanged.

Certificate v5 should:

- bind profile v4;
- preserve the already-correct root digests and all unchanged artifact bindings;
- supersede certificate v4;
- transfer—not duplicate—the unconsumed authorization;
- leave exactly one current, active, unconsumed real-audit authorization.

### Progression decision

Perform one bounded external launch-authority correction. Do not rebuild or modify the audit harness, runtime authority, or subject.

After profile v4 and certificate v5 qualify, the following task is exactly one real audit.

---

## Complete replacement Codex prompt

```text
CORRECT THE FOUR STALE ROOT-INVENTORY BINDINGS IN THE CURRENT
EXTERNAL AUDIT LAUNCH PROFILE

PRESERVE THE SUCCESSOR AUDIT PYZ AND RUNTIME AUTHORITY BYTE-FOR-BYTE;
CREATE LAUNCH PROFILE V4 AND LAUNCH CERTIFICATE V5

Objective

Correct the sole provenance defect that prevented the real replacement-subject
audit from launching.

The current launch profile v3 contains four stale directory-inventory digests.

The following three independent views agree on the current values:

1. launch certificate v4;
2. runtime authority v2;
3. two stable no-follow live filesystem projections.

The real audit was not executed.

No wrapper root, workspace, capsule path, platform-preflight process, or audit
parent was created.

The certificate-v4 authorization remains unconsumed.

Create one bounded immutable successor launch-authority generation:

- launch profile v4;
- launch certificate v5.

Do not modify, rebuild, or replace:

- successor audit PYZ v2;
- runtime authority v2;
- audit source;
- source freeze;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Do not execute the real subject audit in this task.

Do not execute audit, rehearsal, or synthetic mode.

Platform preflight may be executed only to qualify the unchanged external
process controls. It does not consume the audit authorization.

Do not mutate the replacement subject.

Do not promote or rebind current schema authority.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite source-external launch-authority correction parent in one fresh
private build root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_CORRECTED_READY_FOR_ONE_REAL_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_CORRECTION_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. UNCHANGED SUCCESSOR AUDIT PYZ V2
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_AUDIT_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit-v2.pyz

Expected identity:

- inode:
  182785051;
- mode:
  0400;
- link count:
  1;
- size:
  4216423;
- SHA-256:
  d771e987ce6571634d87058f804e34976e2c3368b357053501adf62de260cb19.

Observe and retain device.

Require a device predicate only when governed by current authority.

Authenticate with two stable no-follow reads.

Do not mutate or rebuild the PYZ.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. UNCHANGED RUNTIME AUTHORITY V2
──────────────────────────────────────────────────────────────────────────────

SUCCESSOR_RUNTIME_AUTHORITY_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.authority-v2.json

Expected identity:

- inode:
  182785057;
- mode:
  0400;
- link count:
  1;
- size:
  47750;
- SHA-256:
  64e789738129b460eec10c85c4524159ae41118da90ba4c48190b6de627262ec.

Observe and retain device.

Strict-parse using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

Authenticate:

- PYZ binding;
- source freeze;
- source registries;
- subject-input dependency registry;
- semantic resolver qualification;
- split-root invocation relationship;
- current root identities and inventory digests;
- real audit already executed:
  false;
- subject verdict:
  not issued.

Do not mutate the authority.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING PREDECESSOR PROFILE
────────────────────────────────────────────────

3. CURRENT LAUNCH PROFILE V3

CURRENT_LAUNCH_PROFILE_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.launch-profile-v3.json

Expected identity:

- inode:
  182785068;
- mode:
  0400;
- link count:
  1;
- size:
  11778;
- SHA-256:
  c5707b91fbf8e05f5bb926f01c93d65791386e9dc1ba08924d11659cf66298fa.

Observe and retain device.

Strict-parse under its exact current schema.

Retain every field and its canonical serialization.

Extract and retain the complete four stale inventory-binding rows, including
their full predecessor digest values.

Classify after successor closure:

HISTORICAL_SUPERSEDED_STALE_ROOT_INVENTORY_BINDING_PROFILE

Required facts:

- profile identity valid:
  true;
- profile schema valid:
  true;
- execution controls valid:
  true;
- split-root controls valid:
  true;
- current before profile-v4 closure:
  true;
- current after profile-v4 closure:
  false;
- real-audit authorization consumed:
  false;
- mutation:
  forbidden;
- deletion:
  forbidden;
- supersession cause:
  four stale canonical root-inventory digests.

Do not mutate profile v3.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO PREDECESSOR CERTIFICATE
────────────────────────────────────────────────

4. CURRENT LAUNCH CERTIFICATE V4

CURRENT_LAUNCH_CERTIFICATE_V4:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-input-role-repair-output-v2aqmvn8/gen2-replacement-schema-subject-independent-audit.launch-certificate-v4.json

Expected identity:

- inode:
  182785073;
- mode:
  0400;
- link count:
  1;
- size:
  31870;
- SHA-256:
  b98a9f32d89ba69c14050e1fd6194a8a981c4007ad063eb54e2aae43a21f79b5.

Observe and retain device.

Strict-parse under its exact current schema.

Authenticate:

- successor PYZ-v2 binding;
- authority-v2 binding;
- profile-v3 binding;
- replacement-subject binding;
- construction-wrapper binding;
- accepted implementation-root bindings;
- content bindings;
- split-root execution controls;
- stream/framing contract;
- current correct canonical root inventories;
- active authorization count:
  one;
- authorization consumed:
  false;
- real audit:
  false;
- subject verdict:
  not issued.

Classify after certificate-v5 closure:

HISTORICAL_SUPERSEDED_CERTIFICATE_BINDING_STALE_PROFILE

Required facts:

- certificate identity valid:
  true;
- certificate schema valid:
  true;
- its four root-inventory values agree with authority v2 and live projections:
  true;
- its bound profile contains stale values:
  true;
- current before certificate-v5 closure:
  true;
- current after certificate-v5 closure:
  false;
- active authorization after certificate-v5 closure:
  zero;
- mutation:
  forbidden;
- deletion:
  forbidden.

The unconsumed authorization is transferred to certificate v5.

It is not duplicated.

Do not mutate certificate v4.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING ROOT BINDINGS
────────────────────────────────────────────────

5. REPLACEMENT SUBJECT ROOT

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234;
- inode:
  182649818;
- mode:
  0700;
- UID/GID:
  501/20.

Expected canonical current inventory digest:

eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

Expected closure:

- 73 entries;
- 12 directories;
- 61 regular files.

Authenticate using two complete stable no-follow inventory projections.

Require both projections identical.

Require identity and current digest to agree with:

- certificate v4;
- runtime authority v2;
- live projection.

Do not use the stale profile-v3 digest.

Do not mutate or clean the subject.

Require opening/closing equality.

────────────────────────────────────────────────

6. REPLACEMENT CONSTRUCTION WRAPPER ROOT

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234;
- inode:
  182648782;
- mode:
  0700;
- UID/GID:
  501/0.

Expected canonical current inventory digest:

9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e

Expected closure:

- 49 entries;
- 12 directories;
- 37 regular files.

Authenticate using two complete stable no-follow inventory projections.

Require identity and current digest to agree with:

- certificate v4;
- runtime authority v2;
- live projection.

Do not use the stale profile-v3 digest.

Do not mutate or clean the wrapper root.

Require opening/closing equality.

────────────────────────────────────────────────

7. ACCEPTED IMPLEMENTATION AUDIT ROOT

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234;
- inode:
  182593190;
- mode:
  0700.

Expected canonical current inventory digest:

3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d

Authenticate using two complete stable no-follow inventory projections.

Require identity and current digest to agree with:

- certificate v4;
- runtime authority v2;
- live projection.

Do not use the stale profile-v3 digest.

Do not mutate or clean the root.

Require opening/closing equality.

────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION WRAPPER ROOT

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234;
- inode:
  182593189;
- mode:
  0700.

Expected canonical current inventory digest:

6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108

Authenticate using two complete stable no-follow inventory projections.

Require identity and current digest to agree with:

- certificate v4;
- runtime authority v2;
- live projection.

Do not use the stale profile-v3 digest.

Do not mutate or clean the root.

Require opening/closing equality.

────────────────────────────────────────────────

9. CONTENT INPUTS
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- inode:
  181651092;
- mode:
  0400;
- link count:
  1;
- size:
  13598758;
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671.

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- inode:
  181651098;
- mode:
  0400;
- link count:
  1;
- size:
  19737;
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563.

Authenticate authority before ZIP interpretation.

Require:

- 479 members;
- eight current roles;
- deterministic member closure;
- no `.DS_Store`.

Do not mutate either file.

Require opening/closing equality.

────────────────────────────────────────────────

10. CANONICAL ROOT-INVENTORY ALGORITHM
────────────────────────────────────────────────

Before building successor artifacts, retain:

contract/canonical-launch-root-inventory-binding-v1.json
analysis/profile-v3-root-inventory-drift-crosswalk-v1.json

Derive the canonical root-inventory algorithm from the exact common authority
used by:

- certificate v4;
- runtime authority v2;
- the successful prelaunch wrapper projections.

Do not invent a new algorithm.

Do not accept a profile-local alternate algorithm.

Retain:

- algorithm schema/name/version;
- no-follow behavior;
- path ordering;
- root-row treatment;
- object-kind vocabulary;
- metadata fields;
- byte hashing fields;
- mode treatment;
- symlink/special handling;
- serialization;
- final digest procedure.

For each of the four roots retain:

- root role;
- path;
- device/inode/mode where governed;
- stale profile-v3 digest;
- certificate-v4 digest;
- authority-v2 digest;
- live projection A digest;
- live projection B digest;
- agreement result;
- selected current digest;
- direct evidence.

Require:

certificate-v4 digest
=
authority-v2 digest
=
live projection A
=
live projection B

for all four roots.

If any disagreement remains:

- do not create profile v4;
- return provenance mismatch.

────────────────────────────────────────────────

11. FRESH BUILD AND OUTPUT ROOTS

Allocate one fresh private build root beneath `/private/tmp`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-audit-launch-profile-binding-correction-`.

Immediately emit:

LAUNCH_PROFILE_CORRECTION_BUILD_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-audit-launch-profile-binding-correction-output-`.

Immediately emit:

LAUNCH_PROFILE_CORRECTION_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/launch-profile-correction-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-profile-certificate-disposition-v1.json
opening/process-execution-policy-v1.json

────────────────────────────────────────────────

12. SUCCESSOR PROFILE SCHEMA TREATMENT

Resolve the exact schema used by profile v3.

If that schema supports immutable successor versioning, current-status changes,
supersession, and corrected inventory bindings:

- use the existing schema exactly.

If it cannot represent the successor without mutation or semantic ambiguity:

- create one additive profile-v4 schema;
- preserve every execution-control field and semantic constraint;
- add only the minimum lineage/current-version structure required;
- reject unknown fields;
- permit no optional acceptance-bearing field.

Do not change:

- interpreter;
- isolation flags;
- argv template;
- split-root workspace policy;
- capsule-child policy;
- cwd;
- environment;
- stdin;
- shell;
- TTY;
- detachment;
- foreground/synchronous posture;
- platform-preflight contract;
- authorization-consumption rule;
- framing contract.

Retain:

contract/profile-v3-to-v4-schema-adjudication-v1.json

────────────────────────────────────────────────

13. PROFILE V3 → V4 DELTA CONTRACT

Retain:

contract/launch-profile-v3-v4-delta-contract-v1.json
analysis/launch-profile-v3-v4-delta-v1.json

Authorized semantic changes are limited to:

1. profile identity/version;
2. predecessor/supersession reference;
3. current-status transition;
4. four canonical root-inventory digest corrections;
5. fields whose bytes necessarily change because of items 1–4.

Every other semantic field must compare equal.

Require an exact field-by-field crosswalk.

Require:

- changed-field registry;
- unchanged-field registry;
- unknown field count zero;
- omitted field count zero;
- additional execution-control count zero;
- removed execution-control count zero.

The four corrected bindings must be exactly:

replacement subject:

eb46c6784c361962fa007c2c8638676ca8e5a810cfb91512437e008cd64beea3

construction wrapper:

9c6736d69b81fc0f0d06bbee8dde0a930bab284064f40c01b9ec65cf9ea5b60e

accepted implementation audit:

3e88e9c4df565bf29e181eb6f9ba10f64faf07342cf0e642a7154d15f6be222d

accepted implementation wrapper:

6d1d2176d356634176ee8717a5dce46cfb2718ba42237872b32e9d44de5ac108

────────────────────────────────────────────────

14. SUCCESSOR CERTIFICATE SCHEMA TREATMENT

Resolve the exact schema used by certificate v4.

If it supports immutable successor binding and lineage:

- use it exactly.

Otherwise create one additive certificate-v5 schema limited to:

- profile-v4 identity;
- certificate-v4 predecessor identity;
- predecessor/current posture;
- transferred authorization;
- unchanged artifact and qualification bindings.

Do not change:

- PYZ binding;
- runtime-authority binding;
- subject binding;
- construction-wrapper binding;
- accepted implementation bindings;
- content bindings;
- source-freeze binding;
- member-registry binding;
- qualification and rehearsal bindings;
- split-root policy;
- stream/framing contract;
- authorized audit count:
  one;
- real audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Reject unknown fields.

Retain:

contract/certificate-v4-to-v5-schema-adjudication-v1.json

────────────────────────────────────────────────

15. BUILDER SOURCE AUTHORITY

Create fresh standard-library-only builder and validator source.

The builder may read only:

- Sections 1–9 fixed inputs;
- current profile/certificate schemas;
- current authority/member registries;
- canonical inventory contract;
- this task’s delta contracts.

It must not:

- modify any fixed input;
- execute audit mode;
- execute qualification/rehearsal/synthetic mode unless expressly allowed in
  Section 18;
- execute subject or construction source;
- import audit source;
- use Git/VCS;
- use network;
- broad-scan directories;
- select by basename, suffix, recency, score, or first match.

Retain:

opening/profile-correction-source-authority-v1.json
opening/profile-correction-source-registry-v1.json

Compile under pinned Python using `-I -S -B`.

Run static:

- AST;
- call graph;
- dataflow;
- source/input boundary;
- filesystem effects;
- process effects;
- deterministic serialization;
- exact delta enforcement;
- authorization-transfer logic;
- no-Git/no-network;
- terminal operations.

────────────────────────────────────────────────

16. ROOT-INVENTORY BINDING MATRIX

Run at least 50 uniquely named cases.

Include:

A. Exact baseline

- all four current canonical digests;
- profile/certificate/authority/live agreement.

B. Stale profile values

- stale subject digest;
- stale construction-wrapper digest;
- stale implementation-audit digest;
- stale implementation-wrapper digest;
- all four stale.

C. Authority disagreements

- certificate differs from authority;
- authority differs from live projection;
- projection A differs from B;
- root identity differs while digest matches;
- alternate inventory algorithm asserted;
- algorithm omitted;
- serialization mismatch.

D. Profile delta

- exact authorized delta;
- execution argv changed;
- cwd changed;
- environment changed;
- root lifecycle changed;
- preflight changed;
- framing changed;
- extra field;
- missing field;
- wrong predecessor.

E. Authorization lineage

- profile v3 and v4 both current;
- certificate v4 and v5 both current;
- zero active authorization;
- two active authorizations;
- predecessor authorization marked consumed;
- successor authorization pre-consumed;
- real audit marked executed;
- subject verdict preissued.

F. Determinism

- Build-A/Build-B equality;
- differing key order;
- differing whitespace;
- differing newline;
- differing mode.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/root-inventory-binding-correction-matrix-v1.json

────────────────────────────────────────────────

17. INDEPENDENT SUCCESSOR AUTHORITY VALIDATOR

Create one independently authored standard-library-only validator that imports
neither:

- builder;
- matrix generator;
- expected-result map;
- inventory projector;
- profile producer;
- certificate producer;
- serialization helper.

It must independently:

1. authenticate every fixed input;
2. derive the canonical inventory algorithm;
3. inventory all four roots twice;
4. compare certificate, authority, profile-v3, and live values;
5. validate the profile-v3 → v4 field delta;
6. validate profile-v4 schema;
7. validate certificate-v4 → v5 bindings;
8. validate certificate-v5 schema;
9. reconstruct exact execution controls;
10. prove execution controls unchanged;
11. prove exactly one active authorization;
12. run independent negative cases;
13. require zero errors.

Retain:

validation/independent-launch-profile-binding-validator-v1.json

──────────────────────────────────────────────── LIMITING DYNAMIC QUALIFICATION
────────────────────────────────────────────────

18. PLATFORM-PREFLIGHT QUALIFICATION

After a provisional profile v4 is generated, qualify only its unchanged external
execution controls.

Allocate one disposable wrapper workspace under the exact profile-v4 policy.

Derive the absent capsule child.

Run the exact platform preflight.

Retain complete custody.

Require:

- exact interpreter and isolation flags;
- exact cwd;
- exact five-row environment;
- exact process posture;
- exact stdout;
- exact stderr;
- exact exit/signal;
- workspace remains empty;
- capsule child remains absent;
- no file/child effects.

This does not consume the audit authorization.

Retain evidence, then revalidate and remove the disposable workspace with double
ENOENT.

Do not execute audit, qualification, rehearsal, or synthetic harness mode.

────────────────────────────────────────────────

19. DETERMINISTIC LAUNCH PROFILE V4

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-profile-v4.json

Use canonical deterministic JSON.

Require Build A/B byte equality.

Set final mode:

0400.

Bind:

- unchanged PYZ identity;
- unchanged runtime-authority identity;
- unchanged subject identity;
- unchanged construction-wrapper identity;
- unchanged accepted implementation roots;
- unchanged content inputs;
- unchanged execution controls;
- corrected canonical root-inventory bindings;
- profile-v3 predecessor identity;
- profile-v3 historical posture;
- profile-v4 current posture;
- one unconsumed future audit authorization context.

Retain exact final identity.

────────────────────────────────────────────────

20. DETERMINISTIC LAUNCH CERTIFICATE V5

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v5.json

Use canonical deterministic JSON.

Require Build A/B byte equality.

Set final mode:

0400.

Bind:

- final profile-v4 identity;
- profile-v3 predecessor identity and supersession;
- certificate-v4 predecessor identity and supersession;
- unchanged PYZ;
- unchanged runtime authority;
- unchanged subject;
- unchanged construction wrapper;
- unchanged accepted implementation roots;
- unchanged content inputs;
- unchanged source freeze and package member registry;
- unchanged qualification/rehearsal results;
- unchanged split-root policy;
- unchanged framing contract;
- four canonical root inventories;
- exactly one active, unconsumed successor authorization;
- certificate-v4 active authorization:
  zero;
- real audit:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Retain exact final identity.

────────────────────────────────────────────────

21. CERTIFICATE-INPUT VALIDATION

Run a separate validator over final profile-v4 and certificate-v5 bytes.

Require:

- exact profile binding;
- exact predecessor/successor lineage;
- exact four canonical inventory bindings;
- exact fixed artifact identities;
- unchanged execution controls;
- unchanged preflight;
- unchanged split-root lifecycle;
- unchanged framing;
- exactly one active authorization;
- no duplicated predecessor authorization;
- real audit false;
- subject verdict not issued;
- authority promotion false;
- no unknown field;
- zero errors.

Retain:

validation/certificate-v5-input-validation-v1.json

────────────────────────────────────────────────

22. CURRENT LAUNCH-AUTHORITY ROLE REGISTRY

Retain:

contract/current-external-launch-authority-role-registry-v3.json

Current roles:

- external-audit-launch-profile-v4;
- external-audit-launch-certificate-v5.

Historical roles:

- profile v3;
- certificate v4;
- every earlier profile/certificate.

Require:

- exactly one current profile;
- exactly one current certificate;
- no duplicate current role;
- no ambiguous path;
- exact identities;
- profile v3 current false;
- certificate v4 current false;
- all earlier profiles/certificates current false;
- exactly one active current authorization;
- authorization consumed:
  false.

────────────────────────────────────────────────

23. INPUT CLOSING EQUALITY AND CLEANUP

Repeat opening/closing authentication for:

- audit PYZ v2;
- runtime authority v2;
- profile v3;
- certificate v4;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Do not mutate supplied inputs.

Before removing disposable roots, retain:

- identities;
- inventories;
- process custody;
- matrix and validation results.

Require exact cleanup-set equality and double ENOENT.

Do not remove successful final outputs.

────────────────────────────────────────────────

24. FAILURE CLOSEOUT

On failure retain:

- exact first blocker;
- canonical inventory crosswalk;
- source identities;
- compilation/static results;
- matrix result;
- independent-validator result;
- preflight result;
- partial output inventory;
- cleanup;
- input closing equality;
- profile/certificate lineage;
- authorization posture;
- real audit not executed;
- subject verdict not issued.

Do not create current profile-v4 or certificate-v5 authority on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

25. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_CORRECTED_READY_FOR_ONE_REAL_AUDIT

only when:

- every fixed input authenticates;
- canonical inventory algorithm is established;
- all four certificate/authority/live projections agree;
- profile-v3 stale values are fully crosswalked;
- profile-v4 delta is limited to authorized fields;
- certificate-v5 bindings are coherent;
- builder source qualifies;
- correction matrix passes;
- independent validator passes;
- platform preflight passes;
- profile-v4 Build A/B match;
- certificate-v5 Build A/B match;
- certificate-input validation passes;
- current role registry closes;
- exactly one active, unconsumed audit authorization exists;
- input equality and cleanup pass;
- final outputs are mode 0400;
- no real audit executed;
- no subject verdict issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_CORRECTION_BLOCKED

when:

- canonical root-inventory authority remains ambiguous;
- certificate/authority/live projections do not agree;
- immutable successor representation requires changing execution semantics;
- correction cannot remain limited to external launch metadata.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- supplied-root drift;
- evidence loss;
- builder-source provenance failure;
- custody failure;
- cleanup inequality;
- deterministic-output mismatch;
- final-output identity failure;
- Git/VCS or network activity.

────────────────────────────────────────────────

26. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve audit PYZ and runtime authority unchanged;
- preserve profile v3 and certificate v4;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve successful profile-v4 and certificate-v5 outputs;
- do not execute the real subject audit;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

27. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Audit-PYZ identity
5. Runtime-authority identity
6. Profile-v3 identity and disposition
7. Certificate-v4 identity and disposition
8. Replacement-subject identity
9. Construction-wrapper identity
10. Accepted implementation-root identities
11. Content identities
12. Canonical inventory algorithm
13. Profile-v3 stale binding rows
14. Certificate-v4 binding rows
15. Authority-v2 binding rows
16. Live projection-A rows
17. Live projection-B rows
18. Four-way inventory agreement
19. Profile schema adjudication
20. Profile-v3 → v4 delta contract
21. Exact profile field delta
22. Certificate schema adjudication
23. Builder-source registry
24. Builder compilation/static qualification
25. Root-inventory correction matrix
26. Independent successor-authority validator
27. Platform-preflight qualification
28. Profile-v4 Build A
29. Profile-v4 Build B
30. Profile-v4 equality and identity
31. Certificate-v5 Build A
32. Certificate-v5 Build B
33. Certificate-v5 equality and identity
34. Certificate-input validation
35. Current launch-authority role registry
36. Exactly-one-current-authorization result
37. Input closing equality
38. Cleanup
39. Confirmation real audit not executed
40. Confirmation no subject verdict
41. Final profile-v4 path and identity
42. Final certificate-v5 path and identity
43. Remaining uncertainty and nonclaims
44. Explicit confirmations

Required confirmations:

SUCCESSOR_AUDIT_PYZ_V2_IDENTITY_MATCHED
SUCCESSOR_RUNTIME_AUTHORITY_V2_IDENTITY_MATCHED
PROFILE_V3_IDENTITY_MATCHED
CERTIFICATE_V4_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_ROOT_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
STALE_PROFILE_V3_INVENTORY_BINDINGS_REPRODUCED
CANONICAL_ROOT_INVENTORY_ALGORITHM_AUTHENTICATED
REPLACEMENT_SUBJECT_INVENTORY_AGREES_CERTIFICATE_AUTHORITY_AND_LIVE
CONSTRUCTION_WRAPPER_INVENTORY_AGREES_CERTIFICATE_AUTHORITY_AND_LIVE
IMPLEMENTATION_AUDIT_INVENTORY_AGREES_CERTIFICATE_AUTHORITY_AND_LIVE
IMPLEMENTATION_WRAPPER_INVENTORY_AGREES_CERTIFICATE_AUTHORITY_AND_LIVE
PROFILE_V3_CLASSIFIED_HISTORICAL_SUPERSEDED
CERTIFICATE_V4_CLASSIFIED_HISTORICAL_SUPERSEDED
PROFILE_V4_SCHEMA_COMPLETE
CERTIFICATE_V5_SCHEMA_COMPLETE
PROFILE_V3_V4_DELTA_BOUNDED_TO_AUTHORIZED_FIELDS
EXECUTION_CONTROLS_UNCHANGED
SPLIT_ROOT_LIFECYCLE_UNCHANGED
STREAM_FRAMING_CONTRACT_UNCHANGED
PROFILE_CORRECTION_BUILDER_SOURCE_EXTERNAL
PROFILE_CORRECTION_BUILDER_COMPILED
PROFILE_CORRECTION_STATIC_QUALIFICATION_PASSED
ROOT_INVENTORY_BINDING_CORRECTION_MATRIX_PASSED
INDEPENDENT_SUCCESSOR_AUTHORITY_VALIDATOR_PASSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PREFLIGHT_EXECUTION_CONTROLS_MATCH_PROFILE_V4
PROFILE_V4_BUILD_A_B_BYTES_IDENTICAL
PROFILE_V4_MODE_0400
PROFILE_V4_IDENTITY_VERIFIED
CERTIFICATE_V5_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_V5_MODE_0400
CERTIFICATE_V5_IDENTITY_VERIFIED
CERTIFICATE_V5_INPUT_VALIDATION_PASSED
CURRENT_LAUNCH_AUTHORITY_ROLE_REGISTRY_COMPLETE
EXACTLY_ONE_CURRENT_LAUNCH_PROFILE
EXACTLY_ONE_CURRENT_LAUNCH_CERTIFICATE
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
CERTIFICATE_V4_AUTHORIZATION_NOT_DUPLICATED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
AUDIT_PYZ_MUTATION_NOT_PERFORMED
RUNTIME_AUTHORITY_MUTATION_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_LAUNCH_PROFILE_BINDINGS_CORRECTED_READY_FOR_ONE_REAL_AUDIT

the next task is exactly one real audit using:

1. unchanged successor audit PYZ v2;
2. unchanged runtime authority v2;
3. launch profile v4;
4. launch certificate v5;
5. unchanged replacement subject;
6. construction wrapper;
7. current content inputs;
8. accepted implementation authority chain.

Do not combine profile correction with the real audit.
```

## Source and confidence

The attached report establishes that all fixed artifacts and live roots authenticated, and that the only failed gate was the four stale inventory bindings in profile v3. :chatgpt-content-reference{index="5"}

It also establishes that no launch-related process or root was created and that the successor authorization remains unconsumed. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

**Provenance confidence:** 0.999  
**Stale-profile-binding diagnosis confidence:** 0.999  
**Subject/PYZ/runtime-authority preservation confidence:** 0.999  
**Next-step confidence:** 0.995

The latest attachment was fully readable. Some earlier project uploads have expired; re-upload an older artifact when its original bytes—not merely the retained report and identities—are required.
