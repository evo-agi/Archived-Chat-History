## Engineering assessment

The bundle attempt failed because its recovery contract was still too close to **live filesystem closure**. The needed artifact is instead a **manifest-authenticated content snapshot**.

The reconciliation package’s regular-file evidence is recoverable:

- Manifest A and B remain byte-identical.
- The temporal record retains its expected identity.
- Every manifest-represented regular file is present with the exact expected bytes.
- No represented path is missing.
- The only unregistered live path is the already classified root-level `.DS_Store`.

The four mismatches are directory metadata, not content:

- root `link_count`: `12 → 13`;
- `manifest/` link count: `2 → 4`;
- `manifest/` size: `64 → 128`;
- `manifest/` modification time changed.

The `manifest/` differences are the known consequence of creating Manifest A and B after the manifest projection was generated. The root link-count difference is volatile directory metadata in a contaminated live namespace. Neither affects a copied regular-file byte.

The previous prompt permitted volatile contamination fields only on the root and omitted `link_count`; it also required the reconciliation manifest’s historical `manifest/` directory metadata to equal the final live directory. That made the recovery rule impossible even though the actual content evidence remained intact.

The correct authority boundary is therefore:

- **Original manifests and temporal records:** preserved byte-for-byte as historical evidence.
- **Manifest-covered regular files:** authenticated by exact size and SHA-256, then copied byte-for-byte.
- **Directories:** represented through the original manifest rows and a separate live divergence ledger, but not copied as ZIP entries and not required to retain volatile live metadata.
- **`.DS_Store`:** recorded as contamination and excluded.
- **Final authority:** the deterministic archive file plus its external authority JSON—not any live source directory.

This does **not** restore or reinterpret the source roots as currently sealed. It creates a new, narrowly classified authority artifact: a content-addressed snapshot of the manifest-authenticated bytes.

The Attempt-2 bounded evidence subset is already valid. No bundle source was created, no compilation began, and the full two-attempt builder budget remains available.

## Replacement Codex prompt

```text
CREATE A DETERMINISTIC MANIFEST-AUTHENTICATED CONTENT SNAPSHOT
OF THE CURRENT GENERATION-2 AUTHORITIES

Objective

Create one deterministic, content-addressed, single-file archive containing
the exact manifest-authenticated regular-file bytes required by the future
clean source-external independent-audit harness.

The source roots are no longer currently sealed directory capsules. They have
root-level `.DS_Store` contamination, and one historical package records
directory metadata from a pre-manifest-write lifecycle cut.

Do not require historical directory metadata to equal current volatile
directory metadata.

Do not weaken, rewrite, reseal, or reinterpret the original package manifests.

Instead:

- preserve every original temporal inventory and terminal manifest byte;
- authenticate every manifest-covered regular file by exact size and SHA-256;
- preserve original directory rows as historical evidence;
- retain live directory observations separately;
- permit only explicitly governed volatile-directory divergences;
- copy regular-file bytes only;
- exclude `.DS_Store`;
- create a new deterministic archive whose own byte identity becomes the
  future authority boundary.

Do not repair, delete from, rename within, chmod within, or otherwise mutate a
supplied root.

Do not claim any live source directory is currently sealed.

Do not implement the current-authority closure verifier.

Do not implement the independent-audit harness.

Do not adjudicate the Generation-2 reconstruction-parent implementation.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not issue an implementation or package verdict.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned build and qualification process in one fresh
private working root.

At most two complete builder-source attempts are permitted.

The preceding bundle attempt created no source registry, began no compilation,
and consumed zero builder-source attempts. The complete 0/2 attempt budget
remains available.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

GEN2_CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_BUILD_BLOCKED

CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PRIOR FAILED BUNDLE ATTEMPT
──────────────────────────────────────────────────────────────────────────────

PRIOR_FAILED_BUNDLE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-snapshot-bundle-build-f64j3f73

Expected identity:

- device:
  16777234
- inode:
  181630758
- mode:
  0700
- verdict:
  CURRENT_AUTHORITY_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH
- builder-source attempts:
  0 / 2
- archive created:
  false
- authority JSON created:
  false
- same-root retry:
  false

Authenticate only these named records when present:

analysis/current-root-contamination-ledger-v1.json
analysis/attempt-2-failure-evidence-extraction-v1.json
analysis/roles/terminal-findings-reconciliation-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/gen2-implementation-package-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/gen2-successor-contract-package-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/normative-contract-package-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/current-schema-package-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/schema-reconciliation-capsule-manifest-scoped-snapshot-authentication-v1.json
analysis/roles/current-validation-specification-package-manifest-scoped-snapshot-authentication-v1.json
analysis/builder-source-attempt-ledger-v1.json
validation/supplied-root-closing-equality-v1.json

Authenticate the prior failure facts:

- all eight fixed root identities matched;
- every root had exactly one root-level `.DS_Store`;
- `.DS_Store` bytes were not copied;
- six manifest-backed roles were recoverable under the prior rule;
- the reconciliation role failed only on these directory fields:
  - root `link_count`;
  - `manifest/` `link_count`;
  - `manifest/` `size`;
  - `manifest/` modification time;
- its A/B bytes, temporal identity, represented regular files, and regular-file
  bytes otherwise authenticated;
- Attempt-2 qualified as `BOUNDED_FAILURE_EVIDENCE_SUBSET`;
- no archive or source was created;
- zero builder-source attempts were consumed;
- supplied roots closed equal during that task.

Classify this root as:

historical_pre_source_content_snapshot_policy_failure

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- not a source base;
- not cleanable in this task.

Its source plan may not be copied, patched, imported, executed, translated, or
used as an AST or bytecode origin.

Require complete opening/closing equality if this root is opened.

──────────────────────────────────────────────────────────────────────────────
2. CURRENT INPUT ROLES
──────────────────────────────────────────────────────────────────────────────

Open exactly the eight roles below.

Seven roles use:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

One role uses:

BOUNDED_FAILURE_EVIDENCE_SUBSET

A. TERMINAL FINDINGS RECONCILIATION

Role ID:
terminal-findings-reconciliation

Root:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-audit-block-findings-reconciliation-1cinwqpj

Expected root identity:

- device/inode:
  16777234 / 181119472
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact temporal path:

closeout/temporal-final-inventory-v1.json

Exact manifest paths:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

B. SEALED IMPLEMENTATION PACKAGE

Role ID:
gen2-implementation-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected root identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

C. CURRENT GENERATION-2 SUCCESSOR

Role ID:
gen2-successor-contract-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected root identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

Current role registry:

contract/current-gen2-contract-role-registry-v2.json

- inode:
  180880498
- size:
  37791
- SHA-256:
  6fb98f6558b18c22c161b9869ca3cf4752c0867307fa17b5e255d9dc21e2963f

D. AUTHORITATIVE NORMATIVE-CONTRACT PACKAGE

Role ID:
normative-contract-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected root identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v2.json
manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

Expected temporal identity:

- size:
  17739
- SHA-256:
  e65b511f4c6fb69be9a14a4702ee32d2e1b670db04f4058b398fcf36d662f0f1

Expected manifest identity:

- size:
  17596
- SHA-256:
  a5886bb9f465accaa034398fa51c9720090c9826aa7a464e2ca6f8717f0ec7a2

Normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

E. CURRENT SCHEMA PACKAGE

Role ID:
current-schema-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected root identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

F. SCHEMA RECONCILIATION CAPSULE

Role ID:
schema-reconciliation-capsule

Root:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected root identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

G. CURRENT VALIDATION-SPECIFICATION PACKAGE

Role ID:
current-validation-specification-package

Root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected root identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Role class:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Exact closure paths:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

H. CURRENT ATTEMPT-2 FAILURE EVIDENCE

Role ID:
attempt-2-failure-evidence

Root:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected root identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700

Role class:

BOUNDED_FAILURE_EVIDENCE_SUBSET

Expected failure outcome:

- inode:
  180892410
- size:
  3352
- SHA-256:
  2168ff6dcba31613d7071cdd2d86ee7895e4331dd1c9ab4d4d94ea6e779eecf0

Resolve the exact failure-outcome path and every other permitted evidence path
only through the sealed implementation package’s current Attempt-2 binding.

No basename, recursive path, inode, size, hash, first-match, latest, or scoring
selection is permitted.

──────────────────────────────────────────────────────────────────────────────
3. EXCLUDED ROOTS
──────────────────────────────────────────────────────────────────────────────

Do not open any retired or failed audit-harness or verifier root other than the
single prior bundle root in Section 1.

Retain:

opening/excluded-root-registry-v2.json

For each excluded path retain:

- fixed_input:
  false;
- opened:
  false;
- inventoried:
  false;
- source_read:
  false;
- authority:
  none.

No historical harness, verifier, or bundle-builder source may be copied,
patched, imported, executed, translated, or used as an AST/bytecode origin.

──────────────────────────────────────────────────────────────────────────────
4. FRESH WORKING AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate the private build working root under `/private/tmp` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-current-authority-content-snapshot-build-

Immediately emit:

BUNDLE_BUILD_ROOT=<absolute-path>

Allocate a separate fresh private final-output directory under
`/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-current-authority-content-snapshot-output-

Immediately emit:

BUNDLE_OUTPUT_ROOT=<absolute-path>

The build root is temporary and must be removed after evidence retention.

The output directory is not authority-bearing and does not require a closed
member set.

The only final authority-bearing outputs are the two exact files defined in
Section 12.

Before supplied-root inspection retain:

opening/bootstrap-start.json
opening/content-snapshot-authority-v1.json
opening/fixed-input-registry-v2.json
opening/excluded-root-registry-v2.json
opening/process-execution-policy-v2.json

Authority is limited to:

- supplied-root read-only authentication;
- manifest-scoped regular-file extraction;
- bounded Attempt-2 evidence extraction;
- contamination adjudication;
- deterministic archive construction;
- archive qualification;
- supplied-root semantic closing equality;
- build-root cleanup;
- failure closeout.

Nonauthority includes:

- declaring a source directory currently sealed;
- repairing or cleaning supplied roots;
- deleting `.DS_Store`;
- implementation adjudication;
- verifier or audit-harness implementation;
- implementation production execution;
- current-subject construction;
- product/runtime/target/repository work;
- publication, deployment, or A6.

──────────────────────────────────────────────────────────────────────────────
5. CONTENT-SNAPSHOT AUTHORITY MODEL
──────────────────────────────────────────────────────────────────────────────

Before builder source creation retain:

contract/manifest-authenticated-content-snapshot-model-v1.json

Define exactly two role classes.

A. MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT

Authority derives from:

- exact root identity;
- exact temporal-record identity and bytes;
- exact manifest A identity and bytes;
- exact manifest B identity and bytes;
- manifest A/B byte equality;
- strict root-owned manifest grammar;
- exact represented path set;
- exact represented regular-file bytes;
- exact represented regular-file modes and stable identity fields;
- exact represented directory path, kind, device, inode, mode, UID, and GID
  when owned;
- explicit live divergence ledger for volatile directory fields;
- explicit contamination ledger;
- archive-member authentication.

This role class does not claim:

- the live root is currently sealed;
- volatile live directory metadata equals historical manifest metadata;
- the archive reproduces original directory metadata as filesystem objects.

Successful claim:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT_RECOVERED

B. BOUNDED_FAILURE_EVIDENCE_SUBSET

Authority derives from:

- exact implementation-package Attempt-2 binding;
- exact failure-root identity;
- exact failure-outcome path, identity, and bytes;
- any additional explicitly bound evidence;
- no unbound path selection;
- no complete-root claim unless an authenticated complete inventory exists.

Successful claim:

BOUNDED_FAILURE_EVIDENCE_SUBSET_RECOVERED

Unknown role class fails closed.

──────────────────────────────────────────────────────────────────────────────
6. DIRECTORY-METADATA AUTHORITY AND DIVERGENCES
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/content-snapshot-directory-metadata-policy-v1.json

Directory rows remain historical evidence and must be included in role
authority records, but directory entries are not copied into the ZIP.

For every represented directory require exact live equality for owned stable
fields:

- path;
- type or kind;
- device;
- inode;
- mode;
- UID;
- GID.

Volatile fields may differ only under these rules.

A. Root-level contamination divergence

For exact path `.` only, when the only unregistered live path is root-level
`.DS_Store`, permit divergence in owned volatile directory fields:

- link count;
- size;
- mtime or mtime_ns;
- ctime or ctime_ns.

Every historical and live value must be retained separately.

B. Reconciliation `manifest/` lifecycle divergence

For role `terminal-findings-reconciliation`, exact path `manifest` only, permit
divergence in:

- link_count;
- size;
- mtime_ns;
- ctime_ns when owned.

The live root must contain exactly the two terminal manifest files at the
declared paths, and their exact identities must match.

The difference must be classified:

POST_MANIFEST_PROJECTION_A_B_NAMESPACE_EFFECT

C. All other directories

No directory metadata divergence is permitted unless independently established
by that role’s authenticated closure lifecycle and explicitly added to a
root-specific policy row before builder source creation.

No blanket “all directory metadata is volatile” exception is permitted.

Any differing path, kind, device, inode, mode, UID, GID, regular-file field, or
unregistered directory is a blocker.

For reconciliation require the prior four observed divergence classes to be
covered:

- root `link_count`;
- `manifest` `link_count`;
- `manifest` `size`;
- `manifest` `mtime_ns`.

The values themselves must be freshly observed and retained, not copied from
prompt prose.

──────────────────────────────────────────────────────────────────────────────
7. CONTAMINATION CLASSIFICATION
──────────────────────────────────────────────────────────────────────────────

For each current root perform one complete no-follow traversal.

The only permitted unregistered path is:

.DS_Store

at the root’s top level.

When present require:

- exactly one path;
- relative path exactly `.DS_Store`;
- regular file;
- no symlink;
- link count one;
- mode `0644`;
- not referenced by any manifest, temporal inventory, current registry,
  binding, confirmation, or evidence record.

Retain:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256;
- mtime_ns;
- ctime_ns.

Classification:

FORBIDDEN_INCIDENTAL_OS_METADATA_CONTAMINATION

Disposition:

- record;
- do not copy;
- do not delete;
- do not mutate;
- do not treat as package content;
- do not weaken original package closure rules.

Acceptable unregistered live path sets:

- empty;
- `{".DS_Store"}`.

Any other unregistered path is:

CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

Retain:

analysis/current-root-contamination-ledger-v2.json

──────────────────────────────────────────────────────────────────────────────
8. MANIFEST-AUTHENTICATED REGULAR-FILE EXTRACTION
──────────────────────────────────────────────────────────────────────────────

For every `MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT` role:

1. Authenticate root identity.
2. Authenticate temporal record identity and bytes.
3. Authenticate manifest A identity and bytes.
4. Authenticate manifest B identity and bytes.
5. Require A/B byte equality.
6. Strict-parse with duplicate-key rejection.
7. Recover the exact root-owned manifest grammar.
8. Recover the exact represented member set.
9. Perform complete live no-follow traversal.
10. Require every represented path present.
11. For every represented regular file require:
    - regular file;
    - no symlink;
    - exact link count when owned;
    - exact mode;
    - exact size;
    - exact SHA-256;
    - exact other stable fields owned by the grammar.
12. For every represented directory apply Section 6.
13. Require no missing represented path.
14. Require no duplicate represented path.
15. Require live paths to equal:
    - represented paths;
    - plus manifest A;
    - plus manifest B;
    - plus optional root-level `.DS_Store`;
    accounting for whether the root itself is represented in the grammar.
16. Copy only regular-file bytes.
17. Copy the original temporal and A/B files as original evidence.
18. Do not create ZIP directory members.
19. Retain original directory rows in the role authority JSON.
20. Retain live directory observations and divergence classification
    separately.

Required classification:

MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT_RECOVERED

Retain one record per role:

analysis/roles/<role-id>-content-snapshot-authentication-v1.json

──────────────────────────────────────────────────────────────────────────────
9. ATTEMPT-2 FAILURE-EVIDENCE EXTRACTION
──────────────────────────────────────────────────────────────────────────────

For `attempt-2-failure-evidence`:

1. Authenticate the current implementation-package Attempt-2 binding.
2. Resolve only exact bound paths.
3. Authenticate the failure root identity.
4. Authenticate the exact failure outcome.
5. Permit only root-level `.DS_Store` as an unregistered live path.
6. Do not require success temporal or manifest closure.
7. Do not copy any unbound path.
8. Do not claim a complete failure-root snapshot without an authenticated
   complete inventory.

If a current authenticated complete inventory is bound:

- authenticate and include its listed regular files.

Otherwise include only:

- the exact binding records;
- the exact failure outcome;
- exact evidence paths explicitly named by the binding.

Required classification:

BOUNDED_FAILURE_EVIDENCE_SUBSET_RECOVERED

Retain:

analysis/attempt-2-failure-evidence-extraction-v2.json

──────────────────────────────────────────────────────────────────────────────
10. ARCHIVE MEMBER NAMESPACE
──────────────────────────────────────────────────────────────────────────────

Use these member prefixes:

bundle/index.json
bundle/build-provenance.json
bundle/contamination-ledger.json
bundle/directory-divergence-ledger.json
bundle/role-registry.json
roles/<role-id>/root-authority.json
roles/<role-id>/original-temporal/<basename>
roles/<role-id>/original-manifests/<basename>
roles/<role-id>/files/<original-relative-path>
roles/attempt-2-failure-evidence/bindings/<relative-path>
roles/attempt-2-failure-evidence/evidence/<relative-path>
validation/<validation-records>
report/operative-report.json

Rules:

- no absolute member path;
- no leading slash;
- no `..`;
- no empty segment;
- no duplicate member;
- UTF-8 names only;
- regular files only;
- no ZIP directory members;
- no symlink;
- no hard-link representation;
- no device/special member;
- no `.DS_Store`;
- original absolute paths only as JSON string data;
- every payload member owned by one role.

──────────────────────────────────────────────────────────────────────────────
11. BUNDLE INDEX AND ROLE AUTHORITY RECORDS
──────────────────────────────────────────────────────────────────────────────

Generate:

bundle/index.json
bundle/role-registry.json
bundle/contamination-ledger.json
bundle/directory-divergence-ledger.json

The role registry must contain:

- seven `MANIFEST_AUTHENTICATED_CONTENT_SNAPSHOT` rows;
- one `BOUNDED_FAILURE_EVIDENCE_SUBSET` row;
- exactly eight unique role IDs.

For every role authority record retain:

- original root path and identity;
- role class;
- original temporal identity;
- original manifest identities;
- original manifest grammar;
- original represented path set;
- regular-file member registry;
- original directory rows;
- current live directory observations;
- permitted divergence rows;
- contamination row;
- claim limits;
- source root mutated:
  false;
- live root currently sealed:
  false;
- package verdict:
  not issued;
- implementation verdict:
  not issued.

The bundle index must contain for every member:

- archive member path;
- role;
- source root;
- original relative path;
- authority record and pointer;
- kind:
  regular_file;
- original mode;
- source size;
- source SHA-256;
- archive storage method.

Do not store the archive’s own final hash inside the archive.

──────────────────────────────────────────────────────────────────────────────
12. DETERMINISTIC ARCHIVE FORMAT AND FINAL OUTPUTS
──────────────────────────────────────────────────────────────────────────────

Create an uncompressed deterministic ZIP using Python standard library only.

Required ZIP format:

- `ZIP_STORED`;
- member names sorted by raw UTF-8 bytes;
- fixed timestamp:
  1980-01-01T00:00:00;
- `create_system = 3`;
- no archive comment;
- no member comments;
- no uncontrolled extra fields;
- fixed regular-file permissions:
  `0600`;
- no directory members;
- no symlink/special attributes;
- UTF-8 names;
- no duplicate names.

Build independently twice:

- Build A;
- Build B.

Require byte equality.

Final output filenames:

gen2-current-authority-manifest-content-snapshot-v1.zip
gen2-current-authority-manifest-content-snapshot-v1.authority.json

Create them inside the fresh output directory from Section 4.

After final verification, set both files to mode `0400`.

The containing directory is nonauthoritative.

The authority JSON must bind:

- archive absolute path;
- archive device;
- inode;
- mode;
- link count;
- size;
- SHA-256;
- ZIP format;
- member count;
- index member identity;
- role count:
  8;
- content-snapshot role count:
  7;
- failure-evidence role count:
  1;
- contamination-role count;
- `.DS_Store` member count:
  0;
- directory-divergence row count;
- Build-A identity;
- Build-B identity;
- A/B equality;
- independent validation result;
- supplied-root semantic closing equality;
- implementation verdict:
  not issued;
- package verdict:
  not issued;
- audit harness implemented:
  false;
- full audit executed:
  false.

Future authority is:

exact archive bytes
+
exact authority-JSON bytes

not the output-directory closure.

──────────────────────────────────────────────────────────────────────────────
13. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete builder-source attempts.

An attempt begins only when:

- final builder-source registry closes;
- final independent-validator registry closes;
- compilation begins.

Any source modification after compilation begins creates a new attempt.

If Attempt 2 fails, stop.

Do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
14. STATIC SOURCE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every builder and validator source using pinned Python `-I -S -B`.

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- process-launch crosswalk;
- supplied-root operation crosswalk;
- manifest-member extraction crosswalk;
- directory-divergence policy crosswalk;
- archive-member writer crosswalk;
- final-output operation crosswalk.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- all children through one recorder;
- no shell or PATH lookup;
- no Git/VCS;
- no network;
- no broad Downloads scan;
- no excluded-root access;
- supplied roots read-only;
- no source-root deletion or chmod;
- no `.DS_Store` copying;
- no path-traversal archive member;
- no duplicate member;
- no ZIP directory member;
- no archive overwrite after finalization;
- no mutation after final authority verification.

──────────────────────────────────────────────────────────────────────────────
15. CONTENT-SNAPSHOT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 130 uniquely named cases.

A. Manifest-covered regular files

- exact baseline;
- missing file;
- extra file;
- wrong bytes;
- same-size mutation;
- wrong size;
- wrong mode;
- wrong link count;
- symlink substitution;
- special-object substitution;
- stale hash;
- duplicate represented path.

B. Directory stable fields

- exact baseline;
- path mismatch;
- kind mismatch;
- device mismatch;
- inode mismatch;
- mode mismatch;
- UID mismatch;
- GID mismatch.

C. Root contamination divergence

- exact `.DS_Store` baseline;
- no contamination;
- root link-count divergence;
- root size divergence;
- root mtime divergence;
- root ctime divergence;
- non-root divergence attributed to contamination;
- regular-file divergence attributed to contamination;
- extra contamination path;
- nested `.DS_Store`;
- wrong contamination mode;
- symlink contamination;
- hard-linked contamination.

D. Reconciliation manifest-directory lifecycle

- exact `manifest` divergence baseline;
- link-count change;
- size change;
- mtime change;
- ctime change when owned;
- wrong directory;
- wrong field;
- regular-file change;
- missing A;
- missing B;
- wrong A/B identity;
- additional manifest-directory path.

E. Attempt-2 evidence

- exact bounded subset;
- missing binding;
- stale outcome;
- unbound evidence path;
- false complete-root claim;
- unknown extra path.

F. Archive member namespace

- safe path;
- absolute path;
- path traversal;
- duplicate name;
- empty segment;
- invalid UTF-8;
- directory entry;
- symlink entry;
- special entry;
- `.DS_Store` member;
- missing member;
- extra member;
- wrong role owner.

G. Determinism

- source iteration reordered;
- timestamp changed;
- compression enabled;
- archive comment;
- member comment;
- extra field;
- host system changed;
- mode changed;
- A/B byte mismatch.

H. Authority

- wrong archive hash;
- wrong archive size;
- wrong index hash;
- wrong member count;
- wrong role count;
- live root falsely called sealed;
- package verdict emitted;
- implementation verdict emitted;
- containing directory treated as authority.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/current-authority-content-snapshot-bundle-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
16. INDEPENDENT ARCHIVE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement an independent validator importing neither:

- builder modules;
- builder helpers;
- builder member registry;
- builder divergence classifier;
- mutation generator;
- expected-result map.

It must independently:

1. strict-parse authority JSON;
2. authenticate archive file identity;
3. parse ZIP central directory;
4. reject duplicate/unsafe names;
5. reject nonregular entries;
6. reject compression/comments/uncontrolled extras;
7. authenticate `bundle/index.json`;
8. authenticate role registry;
9. authenticate contamination ledger;
10. authenticate directory-divergence ledger;
11. authenticate every member size/hash;
12. require exact index/member equality;
13. require eight exact roles;
14. require seven content-snapshot roles;
15. require one bounded failure-evidence role;
16. require no `.DS_Store` member;
17. require no ZIP directory member;
18. independently compare each copied source member with the current source
    root and its manifest or binding;
19. verify every permitted directory divergence;
20. verify no forbidden divergence;
21. verify Build-A/B evidence;
22. verify supplied-root semantic closing equality;
23. verify no package or implementation verdict.

Require zero errors.

Retain:

validation/independent-current-authority-content-snapshot-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
17. TWO COMPLETE BUNDLE REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete bundle builds using independent working
roots and identical builder source bytes.

Each rehearsal must:

- authenticate all eight roles;
- classify contamination;
- apply exact directory-divergence policy;
- generate complete index and role records;
- build deterministic A and B;
- require internal A/B equality;
- pass independent archive validation;
- retain complete process custody;
- retain cleanup evidence.

Compare the final rehearsal archives.

The archive bytes must be exactly equal without normalization.

Only external output paths, inodes, process IDs, and evidence timestamps outside
the archive may be normalized.

Retain both archives until:

- independent validation;
- rehearsal comparison;
- evidence retention.

Then remove rehearsal archives and roots and observe ENOENT twice.

──────────────────────────────────────────────────────────────────────────────
18. PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Exercise:

- nonexistent executable;
- zero/empty streams;
- nonzero/both streams;
- timeout/kill/reap;
- one child;
- multiple children;
- empty ledger;
- lost stdout;
- lost stderr;
- unregistered build-root effect;
- zero/one/multiple-root cleanup.

Require:

- prelaunch record;
- exact argv/cwd/environment;
- complete stdout/stderr;
- exit/signal;
- reaping;
- descriptor closure;
- effect attribution;
- evidence before cleanup;
- exact cleanup equality;
- double ENOENT;
- zero process, descriptor, cache, or bytecode survivor.

──────────────────────────────────────────────────────────────────────────────
19. SOURCE FREEZE AND REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Freeze only after:

- all eight roles authenticate;
- all seven content snapshots recover;
- Attempt-2 bounded extraction closes;
- contamination ledger closes;
- directory-divergence ledger closes;
- compilation/static gates pass;
- mutation matrix passes;
- deterministic A/B passes;
- independent validation passes;
- both rehearsals pass;
- rehearsal archive equality passes;
- process custody passes;
- evidence retention/cleanup passes;
- supplied-root semantic closing equality passes.

Retain:

opening/current-authority-content-snapshot-builder-source-freeze-v1.json

Reopen every source no-follow.

Do not modify source afterward.

Against frozen bytes rerun:

- compilation;
- static gates;
- mutation matrix;
- one disposable deterministic build;
- independent validation;
- source/result linkage;
- supplied-root semantic closing equality.

Do not rerun both complete rehearsals.

Prove both rehearsals used the bytes later frozen.

Retain:

validation/frozen-current-authority-content-snapshot-builder-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
20. SUPPLIED-ROOT SEMANTIC CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

For each current supplied root retain opening and closing:

A. Authoritative-member inventory

- every manifest-covered path;
- temporal file;
- manifest A;
- manifest B;
- current registry/binding files used;
- exact mode, type, size, and SHA-256 for regular files;
- stable directory fields.

B. Incidental contamination observation

- `.DS_Store` presence or absence;
- identity and metadata when present.

Require exact opening/closing equality for all authoritative members.

For `.DS_Store`:

- permit metadata or byte changes caused outside the task;
- record opening and closing observations;
- require no task process opened it for write;
- require no path other than root-level `.DS_Store` appears or disappears.

Do not claim whole-root physical equality when incidental contamination changes.

Require:

SUPPLIED_ROOT_AUTHORITATIVE_MEMBER_CLOSING_EQUALITY_PASSED

Any authoritative-member difference is:

CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
21. FINAL OUTPUTS
──────────────────────────────────────────────────────────────────────────────

Final files:

gen2-current-authority-manifest-content-snapshot-v1.zip

gen2-current-authority-manifest-content-snapshot-v1.authority.json

Set both to mode `0400` after final validation.

Retain and report exact:

- absolute path;
- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

The containing output directory is nonauthoritative.

Do not remove final files on success.

──────────────────────────────────────────────────────────────────────────────
22. BUILD-ROOT AND REHEARSAL CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any owned build/rehearsal root retain:

- root identity;
- complete inventory;
- process records/streams;
- all validation results;
- failure outcome where applicable.

Then:

- revalidate identity;
- remove exact root;
- observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Do not remove the final output directory or final output files on success.

──────────────────────────────────────────────────────────────────────────────
23. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- source attempt or pre-attempt posture;
- first blocker;
- structured exception;
- process ledger/streams;
- complete partial build inventory;
- contamination ledger;
- directory-divergence ledger;
- indispensable evidence;
- build/rehearsal cleanup;
- authoritative-member closing equality;
- source-freeze posture;
- same-root retry false.

Do not create authoritative final output files on failure.

If provisional files exist:

- record identity;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- supplied-root identity mismatch;
- manifest-covered regular-file mismatch;
- forbidden directory stable-field mismatch;
- unknown live extra path;
- supplied-root authoritative-member mutation;
- excluded-root access;
- historical source use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- source drift;
- final archive/authority mismatch.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

only when:

- all fixed identities match;
- all seven manifest documents authenticate;
- every manifest-covered regular file authenticates;
- every represented path is present;
- only root-level `.DS_Store` is unregistered;
- directory stable fields match;
- all directory divergences are explicitly permitted and retained;
- seven content snapshots recover;
- Attempt-2 bounded evidence recovers;
- index and member registries close;
- no `.DS_Store` or directory entry enters the archive;
- deterministic Build A/B match;
- mutation matrix passes;
- independent validator passes;
- both rehearsals pass;
- rehearsal archive bytes match;
- process custody passes;
- source freezes;
- frozen requalification passes;
- authoritative supplied-root members close equal;
- final archive and authority JSON validate and are mode `0400`;
- no package or implementation verdict is issued.

Return:

GEN2_CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_BUILD_BLOCKED

when:

- manifest-authenticated content cannot be recovered without inventing regular
  file bytes or path membership;
- Attempt-2 bounded evidence cannot be resolved;
- source cannot qualify within two attempts;
- a matrix, rehearsal, or validator fails without provenance failure.

Return:

CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_PROVENANCE_MISMATCH

for the provenance failures defined in Section 23.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh working-root identity
3. Fresh output-root identity
4. Prior failed bundle identity/disposition
5. Fixed-input registry
6. Excluded-root registry
7. Confirmation excluded roots unopened
8. Content-snapshot authority model
9. Directory-metadata policy
10. Contamination ledger
11. Reconciliation content-snapshot authentication
12. Implementation content-snapshot authentication
13. Successor content-snapshot authentication
14. Normative-contract content-snapshot authentication
15. Schema content-snapshot authentication
16. Schema-reconciliation content-snapshot authentication
17. Validation content-snapshot authentication
18. Attempt-2 bounded evidence extraction
19. Complete role registry
20. Complete archive-member registry
21. Bundle index identity
22. Builder-source attempt ledger
23. Final builder-source registry
24. Final independent-validator registry
25. Compilation/static gates
26. Content-snapshot mutation matrix
27. Deterministic Build A
28. Deterministic Build B
29. Build-A/B equality
30. Independent archive validation
31. Bundle rehearsal A
32. Bundle rehearsal B
33. Rehearsal archive equality
34. Process custody
35. Evidence retention
36. Build/rehearsal cleanup
37. Source freeze
38. Frozen-source requalification
39. Confirmation no implementation verdict
40. Confirmation no package verdict
41. Confirmation verifier/audit harness not implemented
42. Supplied-root authoritative-member closing equality
43. Final archive path and identity
44. Final authority-JSON path and identity
45. Final archive member count
46. Final role count
47. Confirmation archive contains no `.DS_Store`
48. Confirmation archive contains no directory members
49. Remaining uncertainty and nonclaims
50. Explicit confirmation registry

Required confirmations:

PRIOR_FAILED_BUNDLE_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_BUNDLE_ROOT_NOT_RESUMED
PRIOR_FAILED_BUNDLE_CONSUMED_ZERO_SOURCE_ATTEMPTS
FULL_TWO_ATTEMPT_BUILDER_BUDGET_PRESERVED
FIXED_CURRENT_ROOT_REGISTRY_COMPLETE
EXCLUDED_ROOT_REGISTRY_COMPLETE
NO_EXCLUDED_ROOT_OPENED
SUPPLIED_ROOTS_NOT_MUTATED_BY_TASK
LIVE_ROOTS_NOT_CLAIMED_CURRENTLY_SEALED
CONTENT_SNAPSHOT_AUTHORITY_MODEL_FROZEN
SEVEN_MANIFEST_DOCUMENT_PAIRS_AUTHENTICATED
SEVEN_TEMPORAL_RECORDS_AUTHENTICATED
ALL_MANIFEST_COVERED_REGULAR_FILE_BYTES_AUTHENTICATED
ALL_MANIFEST_COVERED_PATHS_PRESENT
DIRECTORY_STABLE_FIELDS_AUTHENTICATED
DIRECTORY_DIVERGENCE_LEDGER_COMPLETE
ROOT_CONTAMINATION_DIVERGENCES_BOUNDED
RECONCILIATION_MANIFEST_DIRECTORY_DIVERGENCES_BOUNDED
NO_BLANKET_DIRECTORY_METADATA_EXCEPTION
CONTAMINATION_LEDGER_COMPLETE
ONLY_PERMITTED_EXTRA_PATHS_OBSERVED
DS_STORE_CLASSIFIED_AS_INCIDENTAL_OS_METADATA
DS_STORE_BYTES_NOT_COPIED
ORIGINAL_CLOSURE_RECORDS_PRESERVED_BYTE_EXACT
ORIGINAL_CLOSURE_RULES_NOT_REWRITTEN
SEVEN_CONTENT_SNAPSHOTS_RECOVERED
ATTEMPT_2_BINDING_AUTHENTICATED
ATTEMPT_2_FAILURE_OUTCOME_AUTHENTICATED
ATTEMPT_2_EVIDENCE_SCOPE_EXPLICIT
BOUNDED_FAILURE_EVIDENCE_SUBSET_RECOVERED
BUNDLE_ROLE_REGISTRY_COMPLETE
BUNDLE_MEMBER_REGISTRY_COMPLETE
NO_ABSOLUTE_ARCHIVE_MEMBER
NO_ARCHIVE_PATH_TRAVERSAL
NO_DUPLICATE_ARCHIVE_MEMBER
NO_DIRECTORY_ARCHIVE_MEMBER
NO_SYMLINK_OR_SPECIAL_ARCHIVE_MEMBER
NO_DS_STORE_ARCHIVE_MEMBER
DETERMINISTIC_ZIP_FORMAT_FROZEN
BUILD_A_CREATED
BUILD_B_CREATED
BUILD_A_B_BYTES_IDENTICAL
INDEPENDENT_ARCHIVE_VALIDATOR_PASSED
CONTENT_SNAPSHOT_MUTATION_MATRIX_PASSED
COMPLETE_BUNDLE_REHEARSAL_A_PASSED
COMPLETE_BUNDLE_REHEARSAL_B_PASSED
REHEARSAL_ARCHIVE_BYTES_IDENTICAL
PROCESS_CUSTODY_QUALIFICATION_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
BUILD_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
BUILDER_SOURCE_FROZEN
BUILDER_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_BUILDER_REQUALIFICATION_PASSED
SUPPLIED_ROOT_AUTHORITATIVE_MEMBER_CLOSING_EQUALITY_PASSED
FINAL_ARCHIVE_CREATED
FINAL_ARCHIVE_MODE_0400
FINAL_ARCHIVE_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_BINDS_ARCHIVE
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CLOSURE_VERIFIER_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_HARNESS_NOT_IMPLEMENTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CURRENT_AUTHORITY_CONTENT_SNAPSHOT_BUNDLE_CREATED_VERIFIED_READY

the next tranche is implementation and qualification of the clean
source-external independent-audit harness using only:

- the exact final archive;
- the exact authority JSON;
- their pinned file identities.

Do not reopen the contaminated current directory roots in that later tranche.

Do not combine snapshot construction with verifier or harness implementation.
```

### Sources

The Codex report in your message establishes that the reconciliation failure was confined to four directory metadata fields while its A/B bytes, temporal identity, represented paths, and regular-file bytes otherwise authenticated. It also establishes that the other six manifest-backed packages were recoverable and that Attempt 2 qualified as a bounded evidence subset.

It further confirms that no source or archive was created, zero builder-source attempts were consumed, all eight supplied roots remained unchanged during the task, and no implementation or package verdict was issued.

**Confidence:** 0.999 that no regular-file content defect or implementation-package defect was established; 0.99 that the failed rule was still overbinding live directory metadata; 0.98 that a manifest-authenticated regular-file content bundle is the correct authority boundary; 0.97 that this removes the need for further live-root closure reinterpretation.
