Here is Codex's response:

AUDIT\_PROVENANCE\_MISMATCH

# Independent audit report

## 1. Verdict

The implementation-evidence root fails the mandatory opening provenance gate. It contains an unexplained empty `commands/` directory that is neither authenticated by the canonical manifest nor covered by either declared exclusion. Adding or removing that directory leaves the manifest unchanged.

The directory was initially enumerated but incorrectly treated as harmless because the manifest authenticates files only. Auditor 4 identified the conflict after correctness inspection had begun. Under the prompt’s stop rule, all subsequent correctness results below are preserved as non-dispositive observations; they cannot cure the opening mismatch.

Even if directory membership were excluded from the provenance requirement, the allocation and orchestration field maps contain independently blocking omissions.

## 2. Audit target and exact identities

- Candidate: `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`
- Physical device/inode: `16777234 / 122118502`
- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream: absent
- Contract ID: `execution-substrate.repair10i-a6.successor-governance.v1`
- Documentary test: `TestRepair10IA6SuccessorGovernanceContract`
- Raw 12,919-byte authority-block SHA-256: `ec6191e0ffdd1647215f37ee5ca033f47816dd44c63a7f99d8c87c4b886e8a94`
- Audit root: [ES-repair10i-a6-governance-audit-1gmqlvjg](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg), mode `0700`

## 3. Opening provenance

The repository side of the opening gate matched:

- Retained opening inventory: 389 objects, 54,314 bytes, SHA-256 `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- Independently reconstructed opening source T: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Live final inventory: 389 objects, 54,314 bytes, SHA-256 `29251ed38218cadb5528db1e6b04a60078abf7aea3d9ebfa2b29437fc6c923a7`
- Live final source T: `e01538a45d8b11a332ee6b6fc78239bfd6509303`
- Provenance recipe: 28,602 bytes, SHA-256 `50e767ba6551a309bc9390cb1baddb389659e5a6b715fd0868af2d4dd8d29276`
- Two audit-owned executions reproduced the expected identities, stdout, delta, and 15 canonical outputs.
- Two independent deltas matched each other and the supplied 51,594-byte delta at `f78a14dc8c78f692001a2b6818c3aae6b42f7067c7db1b1ccb18b7c702d1ac9c`.

The evidence-root side did not pass:

- 60 regular files
- 14 directories including the root
- 55 manifest-covered files
- Five declared excluded files
- One unexplained empty directory: `commands/`

That discrepancy is detailed in §§21 and 24.

## 4. Dirty baseline and exact seven-path delta

The live posture remained:

- 375 tracked paths
- 14 nonignored untracked paths
- 389 governed objects
- 22 tracked modifications
- Zero staged, deleted, renamed, or unmerged paths

Exactly seven paths differ from the retained opening inventory; all other 382 match in path, type, mode, size, and SHA-256.

| PathBytesFinal SHA-256                                                    |         |                                                                    |
| ------------------------------------------------------------------------- | ------- | ------------------------------------------------------------------ |
| `PLANS.md`                                                                | 288,739 | `f9ba77d11df271e951d29cdf4aa0f21fdc2faa13b698343d2c20e0bbaa19fe8f` |
| `.docs/system_overview/configuration.md`                                  | 129,589 | `f83f9469014cd89fdbea8fdf5c38eb5a580c25c4937b066e27d665d073fe14b3` |
| `.docs/system_overview/boundaries.md`                                     | 96,086  | `0bac404d0f4c56cfcc9e7f5f91594c1017a471ed1e9b5be2d4c2347eba03a7dd` |
| `.docs/system_overview/artifact_hygiene.md`                               | 38,322  | `2f262b42385d6963c2c6ab4677204361e7f8ecc217192f915b3f056bf9f69910` |
| `.docs/system_overview/capability_probing.md`                             | 42,667  | `4730644365b4ad65f56f57573cb39e592ff3eeb88a0a5e10f6df444dcc75a65b` |
| `.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md` | 97,555  | `010d2d6ed46e325ec82eaeeb8f843493f6cd7d52feef53ed140db12e1cc042e6` |
| `docs_contract_test.go`                                                   | 778,632 | `b1f61eed7960d208541c25ac145af0768ab178248c020333841fc619543432d3` |

No product Go source, module file, public schema, operational command, Evidence Verification source, or caller source changed.

## 5. Four independent auditors

All four were direct auditors; none created a nested agent. They received the same candidate and authenticated opening/final identities. They ran no Git, tests, repository imports, writes, network operations, or product binaries.

| AuditorSchedule and scopeResult and limits |                                                                                                                                                                                                                       |                                                                                                                                                                                                                               |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/root/auditor_1_contract_authority`       | Initial concurrent wave; first to close. Read `AGENTS.md`, complete `PLANS.md`, all six governing documents, relevant referenced documents, authority/reference blocks, and bounded A6D/amendment/A6V/A6R evidence.   | No blocker. Confirmed current/target separation, historical-only v5/v2, v1 runner versus v2 extractor/FORMAT mismatch, sole writer, and no authority widening. Reported one low wording ambiguity in `capability_probing.md`. |
| `/root/auditor_2_structured_test`          | Initial concurrent wave; 2026-09-19 02:41:38Z–02:48:03Z. Read the full focused test and helper call graph, contract, references, mutation evidence, and relevant provenance records.                                  | No blocker. Found an independent runtime oracle and effective canonical/duplicate-key rejection. Reported two low hardening issues and one provenance observation.                                                            |
| `/root/auditor_3_provenance_validation`    | Initial concurrent wave. Read complete inventories, deltas, recipes, all validation and failed-attempt records, tool identities, reader discovery, corrections, and manifest evidence.                                | No repository blocker. Reported two low validation-record defects and a low producer temp-confinement overstatement. Its file-focused exclusion conclusion did not treat the empty directory as a mismatch.                   |
| `/root/auditor_4_security_artifact`        | Started only after Auditor 1 closed. Read allocation/orchestration authority, artifact/capability documents, manifest recipe and rows, all evidence filesystem objects, validation environments, and excluded report. | Found the dispositive unexplained directory and independently blocking allocation, orchestration, and producer-temp findings. Did not inspect product/runtime correctness or historical roots outside its assignment.         |

## 6. Sole authority and complete-document review

The sole writer is [remote\_alpha\_external\_tls\_status\_deployment\_v1.md (line 1350)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md:1350>). It classifies the contract as `private-planning-and-assurance` and expressly denies authority over commit, execution, product, publication, public API, readiness, and runtime.

Five documents are reference-only consumers:

- `PLANS.md`: `sequence-and-status`
- `configuration.md`: `private-proof-tool-and-path-configuration`
- `boundaries.md`: `authority-and-nonauthority`
- `artifact_hygiene.md`: `artifact-classification-and-custody`
- `capability_probing.md`: `behavioral-capability-validation`

Complete-document review found no claim that v7, the semantic package, the allocator, the orchestrator, the five bound instances, or a fresh A6 already exists. No product/public/runtime authority was widened.

The contract nevertheless claims its structured block is the only normative field map. That makes the allocation and orchestration omissions material: stronger prose in reference-only consumers cannot fill gaps in the sole normative map.

## 7. Independent parsed contract field map

The independent parser, built without repository helper logic, parsed 367 typed map entries. It enforced duplicate-key rejection, nonfinite rejection, exact canonical one-line encoding, terminal newline placement, complete keys/types/values, marker topology, and the authority digest.

The six top-level keys are:

- `authority`
  - classification, sole writer, five consumer roles, seven explicit nonauthorities
- `contract_id`
- `current_facts`
  - `a6d`, `amendment_immutable`, caller authority, Evidence Verification authority, existing children, fresh A6, missing successor instances, v5/v2 treatment
- `selected_target`
  - allocation, authority split, canonicalization, dialect, five controls, historical policy, implementation status, nonauthority, orchestration, outputs, Repair 9 overlay
- `status`
  - `selected-successor-governance-not-implemented`
- `tranche_order`
  - governance freeze → semantic successor → orchestration successor → independent qualification → fresh A6 → independent A6 audit

The five selected logical control templates are:

- `repair10i-pristine-final-v1`
- `repair10i-fresh-independent-final-v1`
- `repair10i-intentional-mutant-v1`
- `repair10i-historical-head-v1`
- `repair10i-historical-repair9-v1`

Their instances remain uncreated. The complete typed-map record is [independent-contract-complete-field-map-v1.json](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/independent-contract-complete-field-map-v1.json).

## 8. Consumer-reference adjudication

Each consumer contains exactly one five-field reference with:

- The exact contract ID
- The exact sole-writer path
- Its literal consumer role
- `selected-not-implemented`
- `reference-only-does-not-redefine-override-narrow-or-widen`

No consumer contains an authority block. The capability consumer contains stronger allocation prose, but its nonoverride declaration prevents that prose from supplying missing normative writer fields.

## 9. Marker scope and repository-wide observation

The actual authority claim is scoped to the closed six-document set formed by the sole writer plus five enumerated consumers. Within that scope there is exactly one authority block and five references.

A repository-wide literal observation found:

- One actual V1 authority block
- Five actual V1 reference blocks
- Literal marker/contract constants in `docs_contract_test.go`
- No alternate live authority family

The constants in the test are an oracle, not a second authority block. The independent parser also rejected alternate-family, mismatched, unmatched, nested, duplicate-writer, and consumer-embedded blocks.

## 10. Independent mutation matrices

All 14 independently reconstructed producer cases rejected for the intended mechanism:
```
v7-claimed-implemented                         → target.status
v6-silently-redefined                         → current.a6d-family
v5-v2-promoted                                → current.v5-v2-history
observability-rule-reverted-v1                → canonicalization.observability-v2
independent-runner-extractor-registries       → canonicalization.one-registry
absent-to-pass-rejected                       → admitted-transition length/value
new-passes-offset-regressions                 → historical.no-offset
aggregate-exit-equality-authoritative         → historical.per-control-exit
factual-result-adjudication-merged            → outputs.distinct
scan-latest-timestamp-pid-allocation          → forbidden allocation sources
existing-child-resumed                        → allocation.no-resume-adopt-rename
second-orchestration-writer                   → orchestration.sole-writer
ev-readiness-authority                        → authority.ev-nonreadiness
source-external-evidence-product-authority    → authority.child-nonproduct
```

All 25 audit-only mutations also rejected:
```
missing-mandatory-key                         → schema.missing:$.status
unknown-key                                   → schema.unknown:$.unexpected
boolean-replaced-by-string                    → selected_target.nonauthority.product type
string-replaced-by-boolean                    → current_facts.fresh_a6 type
wrong-sole-writer                             → authority.sole-writer
selected-target-status-current                → target.implementation-status
generated-schema-normative-authority          → canonical authority mismatch
caller-execution-authority                    → authority.caller-bounded
verifier-publication-authority                → authority.ev-nonreadiness
interruption-resumable                        → orchestration.no-resume
duplicate-json-key                            → duplicate-key:status
noncanonical-json                             → authority.fenced-shape
duplicate-authority-block                     → authority.writer-count:2
alternate-authority-family-id                 → alternate-family marker
mismatched-begin-end                          → mismatched marker IDs
unmatched-begin                               → unmatched BEGIN
unmatched-end                                 → unmatched END
nested-overlapping-blocks                     → nested marker
duplicate-consumer-reference                  → PLANS.md reference-count:2
consumer-override-local-narrowing-widening    → consumer.nonoverride
authority-block-in-consumer:PLANS.md          → block-in-consumer
authority-block-in-consumer:configuration     → block-in-consumer
authority-block-in-consumer:boundaries        → block-in-consumer
authority-block-in-consumer:artifact_hygiene  → block-in-consumer
authority-block-in-consumer:capability        → block-in-consumer
```

Reasons and fixtures are recorded in [independent-contract-parser-and-matrix-v1.json](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/independent-contract-parser-and-matrix-v1.json).

## 11. Test-oracle independence

The repository test is an independent regression oracle:

- The exact authority digest is compiled into the test.
- Critical semantic values, consumer paths, and roles are literals.
- Expected values are not loaded from the document or producer evidence.
- Whole-map canonical bytes lock all fields, including those without dedicated semantic checks.
- `SetEscapeHTML(false)` correctly preserves `<32-lowercase-hex>`.
- Duplicate keys collapse during Go unmarshalling and then fail raw canonical-byte equality.
- Nonfinite constants fail JSON validity.
- The focused static call graph has no subprocess, environment-derived semantic input, write, or external evidence read.

The current 14 mutation names were stable in source and verbose validation. The test itself does not separately assert `len == 14` or a fixed name inventory, which is a nonblocking hardening issue.

## 12. Current-versus-target treatment

The complete documents consistently distinguish:

- Current invariant: sealed A6D/amendment facts, immutable/nonresumable existing children, bounded caller/EV authority.
- Temporary compatibility edge: retained v5/v2 parsing and reporting only; it is not current qualification.
- Reopened redesign seam: the selected v7 semantic, allocation, and orchestration design.
- Selected target: explicitly `selected-not-implemented`.

The patch does not redefine v6, promote v5/v2, claim a fresh A6, or imply that the future packages or five control instances exist. One low wording ambiguity remains where capability prose calls v2 the “current observability rule” inside a selected-future context.

## 13. Exact version and canonicalization map

Advance to v7:

- `suite-spec.v7`
- `ab-suite-spec.v7`
- `suite-result.v7`
- `binding-recomputation.v7`
- `control-qualification.v7`
- `semantic-comparison-spec.v7`
- `semantic-comparison-result.v7`
- `semantic-comparison-custody.v7`

Retain:

- Command intent/result/terminal reconciliation v3
- Effective read policy v3
- Private PTY command, broker-journal, allocation, and reconciliation v2
- Control observation, mutable inventory, intentional-mutant provenance, validation-harness-overlay provenance, Go-test semantics, byte capture, byte-comparison spec, and byte-comparison result v1

Adopt for A6:

- Historical transition analysis v2
- Historical comparison adjudication v1
- Child allocation, opening capsule, orchestration record, closeout adjudication, cleanup, command index, failed/superseded index, closing gate, and command-root audit v1

Canonicalization:

- Policy: `execution-substrate.repair10i.semantic-canonicalization.v2`
- Active observability rule: `observability-inbound-request-complete-v2`
- v1 rule: historical only
- One ordered registry owned by the future semantic package
- Ordered rules: source root, control root, Go temp parent, Vault reset run ID, Darwin mktemp failed candidate, observability v2, Go panic runtime identities, and fresh-bootstrap logical-byte binding
- Independent runner/extractor registries: forbidden
- Shared wrong final/fresh fingerprint: nonqualifying
- Bound fields: policy ID, ordered-rules digest, logical suite fingerprint

## 14. Historical direction, transition, and exit policy

Directions:

- Historical HEAD → pristine final
- Historical Repair 9 effective → pristine final

Admitted:

- `pass→pass`
- `fail→fail`
- `skip→skip`
- `absent→pass`
- `fail→pass`
- `skip→pass`

Rejected:

- `pass→fail`
- `pass→skip`
- `pass→absent`
- `fail→skip`
- `fail→absent`
- `skip→fail`
- `skip→absent`
- `absent→fail`
- `absent→skip`

`absent→absent` is outside the union transition set. Improvements cannot offset regressions. Aggregate exit equality is not required. Each control must independently have an admitted exit, terminal/semantic consistency, qualification, EOF completeness, and custody completeness.

## 15. Fact, analysis, and adjudication separation

Three distinct outputs are selected:

- Factual comparison: `semantic-comparison-result.v7`
  - Exit 0: qualified equal
  - Exit 1: unqualified, uncertain, invalid, or custody failure
  - Exit 2: qualified different with both sides qualified and no unknown
- Directional transition analysis: `historical-transition-analysis.v2`
  - Exit 0: valid complete analysis
  - Exit 1: invalid input, qualification, recomputation, direction, custody, or production failure
- Historical adjudication: `historical-comparison-adjudication.v1`
  - Exit 0: accepted no-regression direction
  - Exit 1: rejected, unqualified, or uncertain

The field map keeps the records and exit meanings distinct.

## 16. Allocation contract

The normative map does freeze:

- Exact parent and prefix
- 16 operating-system CSPRNG bytes encoded as 32 lowercase hex characters
- Mode `0700`, umask `0077`, expected effective user/group
- Descriptor-relative exclusive mkdir
- No symlink follow
- Stable device/inode requirement
- Limit 128
- Direct allocation record/digest discovery
- No adoption, rename into eligibility, or resume
- No counter, Git hash, latest scan, PID, prefix scan, or timestamp authority

It does not explicitly freeze:

- Component-by-component no-follow traversal
- Holding the parent descriptor and its identity across creation
- Fresh CSPRNG material for every `EEXIST`
- Collision-only retry semantics

Those requirements appear only in reference-only capability prose and the excluded implementation report. A later allocator could satisfy every normative field while still choosing underspecified traversal or collision behavior. This is independently blocking for the requested “exact” governance freeze.

## 17. Orchestration and interruption contract

The normative map freezes:

- Exactly one future progression writer
- Immutable event records
- No second mutable current-state authority
- Fourteen owned progression stages
- Permanent failed/superseded, inspection-only disposition after interruption
- No resume

It does not explicitly freeze:

- Immutable result records
- Exactly one final orchestration record
- The full no-repair/no-seal interruption rule

Thus a future implementation could produce mutable results or multiple final records without violating the literal field map. This is independently blocking.

## 18. Critical current-fact verification

Bounded reads of the named A6D, amendment, A6V, and A6R roots confirmed:

1. The A6D runner uses `observability-inbound-request-complete-v1`.
2. A6D semantic extraction and FORMAT require v2.
3. A6D and its amendment are immutable retained evidence.
4. Joint qualification states that fresh A6 was not restarted and the historical comparator was not implemented.
5. Retained v5/v2 records and analyzer behavior are historical, parse/report-only compatibility.
6. A6V naming was a design candidate, not allocation authority.
7. Existing A6 policy children are immutable and nonresumable.

No historical binary, comparator, analyzer, service, or control was executed.

## 19. Fresh validation and exact test identities

Pinned tools matched:

- Go: `go version go1.26.5 darwin/arm64`
- Go SHA-256: `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`
- gofmt SHA-256: `3b87c876b1255feb8ecc539afff2eadd9dcc76e0e34657bdab6d32fd03329f81`

All runs used `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, `GOENV=off`, `GOWORK=off`, `GOFLAGS=-mod=readonly`, and audit-owned `GOCACHE`, `GOMODCACHE`, `GOTMPDIR`, `TMPDIR`, and `HOME`.

Results:

- Focused governance test, verbose and uncached: exit 0; all 14 subtests observed; no failure, error, or skip.
- Corrected conservative pre-existing reader set: 85 identities; exit 0.
- All 106 identities under umask `077`: exit 0.
- All 106 identities under umask `022`: exit 0.
- `gofmt -d docs_contract_test.go`: empty.
- `git diff --check`: empty.
- Before and after every group: all seven hashes and the full 389-object inventory were unchanged.

The exact 106 identities were:
```
TestRepair10IA6SuccessorGovernanceContract
TestGo1265ToolchainBaselineDocsAndBuildContract
TestSubmitIdempotencyCorrelationAndRecoveryDocsContract
TestReliableSubmitPureModelDocsAndSourceContract
TestReliableSubmitPublicOptInAndVersioningDocsContract
TestReliableSubmitContractAdapterFoundationDocsAndSourceContract
TestReliableSubmitPersistenceAndConcurrencyADRDocsContract
TestSystemOverviewAuthorityHeadersFollowRepoHierarchy
TestHybridIntegrationArchitectureADRDocsContract
TestHybridIntegrationBridgeCodexRowPinsEvidenceBoundary
TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries
TestPrimaryMilestoneRealignmentPreservesESOwnership
TestWorkstreamASharedKernelDecisionIsDocumented
TestWorkstreamBArtifactPublicationStorageDecisionIsDocumented
TestWorkstreamB1ArtifactBoundaryGuardrailPostureIsDocumented
TestWorkstreamBArtifactCompatibilityEdgesStayConsistent
TestWorkstreamB0ArtifactBoundaryGateIsDocumented
TestWorkstreamCESExecutionAdmissionModelDecisionIsDocumented
TestWorkstreamC7CheckpointDocsContract
TestWorkstreamCProducerContractPrepareBoundaryTestsAreDocumented
TestWorkstreamC0ExecutionOwnershipGateIsDocumented
TestWorkstreamC0BoundarySurfaceAssertionsAreDocumented
TestWorkstreamC1PrepareAdmissionGuardrailPostureIsDocumented
TestWorkstreamC2SubmitLifecycleProjectionGuardrailPostureIsDocumented
TestWorkstreamC3RetainedResultAuthorityHandoffGuardrailPostureIsDocumented
TestWorkstreamC4RuntimeIdentityVaultHandoffGuardrailPostureIsDocumented
TestWorkstreamC5StatusLogsResultCancelCompatibilityGuardrailPostureIsDocumented
TestWorkstreamCLifecycleProjectionAuthorityLabelsAreDocumented
TestWorkstreamC6AdmissionPolicyLayerV0ContractIsDocumented
TestWorkstreamC6ConfigurableAdmissionPolicyInputsAreDocumented
TestWorkstreamC6AdmissionPolicyNonClaimsAreDocumented
TestWorkstreamC0ExternalAuthorityAndEvidenceNonOwnershipIsDocumented
TestWorkstreamDPolicyAuthorizationBoundaryClarificationIsDocumented
TestWorkstreamDVersioningGuardrailBeforeSemanticExpansionIsDocumented
TestWorkstreamD1bCGSV2AuthorizeContractDesignIsDocumented
TestWorkstreamD1cEGSVersionedRuntimeTrustWrapperDesignIsDocumented
TestWorkstreamD1dIDConfCompatibilityDowngradeIsDocumented
TestWorkstreamERuntimeConfigOwnershipDecisionIsDocumented
TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal
TestWorkstreamFRuntimeIdentityHandoffOwnershipDecisionIsDocumented
TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal
TestWorkstreamCResultSurfaceClassificationStaysConsistent
TestWorkstreamCRetainedResultBundleClarificationIsDocumented
TestWorkstreamCRuntimeProfileBoundaryStaysNarrow
TestWorkstreamCRuntimeProfileCompatibilityMatrixIsDocumented
TestGoldenProducerProofPathIsDocumented
TestProducerFailurePathDistinctionsAreDocumented
TestMilestone1LeastPrivilegeBoundaryCloseoutIsDocumented
TestMilestone1BoundaryPostureMatrixIsDocumented
TestRemoteSupportedHostAlphaRuntimeSecurityBoundaryCheckerIsDocumented
TestRemoteSupportedHostAlphaDirectBoundaryIsDocumented
TestDocsRemoteAlphaOperatorFacadeBoundaries
TestRemoteAlphaOperatorDocsInvolvementAndP0dEvidenceBoundaries
TestRemoteAlphaOperatorP0dDocsFirstDelegationBoundary
TestRemoteAlphaOperatorP0fDocsReadinessSessionBoundary
TestRemoteAlphaOperatorP0gDocsRecoverySessionBoundary
TestRemoteAlphaOperatorP0hDocsSchemaAwareRecoveryEvidenceBoundary
TestRemoteAlphaOperatorP0iDocsHostLocalUnsealBoundary
TestRemoteAlphaOperatorP0jDocsMacSideUnsealBoundary
TestRemoteAlphaOperatorP0kDocsMacSideResetDryRunBoundary
TestRemoteAlphaOperatorP0lDocsMacSideResetExecuteContractPrep
TestRemoteAlphaOperatorP0mDocsMacSideResetExecuteImplementationBoundary
TestRemoteAlphaOperatorP0nDocsMacSideWorkloadAuthCheckBoundary
TestRemoteAlphaOperatorP0oDocsVaultWorkloadAuthBootstrapPlanningBoundary
TestRemoteAlphaOperatorP0pDocsVaultWorkloadAuthBootstrapExecutionContractPrep
TestRemoteAlphaOperatorP0qDocsVaultWorkloadAuthBootstrapExecutionRoute
TestRemoteAlphaOperatorP0rDocsRuntimeIdentitySummaryRoute
TestRemoteAlphaOperatorP0sDocsESServiceTLSRenewRoute
TestRemoteAlphaOperatorP0tDocsESGovernanceTLSRenewRoute
TestRemoteAlphaOperatorP0uDocsOperatorHealthcheckTLSRenewRoute
TestRemoteAlphaOperatorP0vDocsOperatorHealthcheckTLSNoninteractiveStatusDesign
TestRemoteAlphaOperatorP0vCompanionDocsCurrentStatusAlignment
TestRemoteAlphaOperatorHealthcheckTLSCompanionDocsCurrentAndTargetSeparation
TestRemoteAlphaExternalTLSLifecyclePlanningAndBoundaryAlignment
TestRemoteAlphaExternalTLSLifecycleCurrentAndTargetContract
TestRemoteAlphaExternalTLSPolicyCoreDocumentationContract
TestRemoteAlphaExternalTLSLifecycleSecurityAndOwnership
TestRemoteAlphaExternalTLSLifecycleRejectsTargetWidening
TestRemoteAlphaExternalTLSIncidentCompatibilityAndMigration
TestRemoteAlphaExternalTLSLifecycleHasExactPolicyCoreConsumer
TestRemoteAlphaExternalTLSRestorationAndChat00054Boundary
TestRemoteAlphaMaintenanceMonitorBoundaryAndRouteMatrix
TestDocsRemoteAlphaOperatorP0cFirstDelegationBoundary
TestRemoteSupportedHostAlphaDoctorVocabularyIsDocumented
TestRemoteSupportedHostAlphaSupportBundleSummarySectionsAreDocumented
TestRemoteSupportedHostAlphaVaultWorkloadAuthSummarySchemaIsDocumented
TestRemoteSupportedHostAlphaVaultServiceUserMigrationSurfaceIsDocumented
TestRemoteSupportedHostAlphaNormalShellRuntimeImageSummarySchemaIsDocumented
TestRemoteSupportedHostAlphaAGSServiceHardeningSliceIsDocumented
TestRemoteSupportedHostAlphaARSServiceHardeningSliceIsDocumented
TestRemoteSupportedHostAlphaEGSServiceHardeningSliceIsDocumented
TestRemoteSupportedHostAlphaESConfigTLSPrepSliceIsDocumented
TestRemoteSupportedHostAlphaESConfigTLSPrepOperatorStagingFlowIsDocumented
TestRemoteSupportedHostAlphaESWritableStateReadinessOperatorFlowIsDocumented
TestRemoteSupportedHostAlphaESServiceUserMigrationOperatorFlowIsDocumented
TestRemoteSupportedHostAlphaESServiceUserRollbackRehearsalIsDocumented
TestRemoteSupportedHostAlphaESBinaryDeploymentOperatorFlowIsDocumented
TestRemoteSupportedHostAlphaESWritableStateOwnershipOperatorFlowIsDocumented
TestRemoteAlphaExternalTLSStatusObservationV1Contract
TestRemoteAlphaExternalTLSStatusT2APackageAndFacadeContract
TestRemoteAlphaExternalTLST2APRepair7Contract
TestRemoteAlphaExternalTLST2APRepair8Contract
TestRemoteAlphaExternalTLST2APRepair9Contract
TestRemoteAlphaExternalTLST2APRepair10Contract
TestRemoteAlphaExternalTLST2APRepair5LifecycleOrderV1
TestRemoteAlphaExternalTLST2APCurrentTargetMatrixV1
```

The exact 85-reader group is the set above minus these 21 identities:
```
TestRepair10IA6SuccessorGovernanceContract
TestGo1265ToolchainBaselineDocsAndBuildContract
TestReliableSubmitContractAdapterFoundationDocsAndSourceContract
TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries
TestWorkstreamC6AdmissionPolicyNonClaimsAreDocumented
TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal
TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal
TestWorkstreamCRuntimeProfileCompatibilityMatrixIsDocumented
TestProducerFailurePathDistinctionsAreDocumented
TestRemoteSupportedHostAlphaDirectBoundaryIsDocumented
TestRemoteAlphaOperatorP0vCompanionDocsCurrentStatusAlignment
TestRemoteAlphaOperatorHealthcheckTLSCompanionDocsCurrentAndTargetSeparation
TestRemoteAlphaExternalTLSLifecycleCurrentAndTargetContract
TestRemoteAlphaExternalTLSPolicyCoreDocumentationContract
TestRemoteAlphaExternalTLSLifecycleSecurityAndOwnership
TestRemoteAlphaExternalTLSLifecycleRejectsTargetWidening
TestRemoteAlphaExternalTLSLifecycleHasExactPolicyCoreConsumer
TestRemoteAlphaExternalTLSRestorationAndChat00054Boundary
TestRemoteSupportedHostAlphaDoctorVocabularyIsDocumented
TestRemoteSupportedHostAlphaSupportBundleSummarySectionsAreDocumented
TestRemoteSupportedHostAlphaESWritableStateReadinessOperatorFlowIsDocumented
```

Raw validation is recorded in [fresh-validation-v1.json](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/fresh-validation-v1.json).

## 20. Failed and superseded attempts

All producer attempts were inspected:

- Local Go 1.26.1: excluded
- Missing `ES_REPAIR10_SOURCE_ROOT`: excluded
- JSON HTML escaping: excluded
- Four compatibility-statement failures: excluded
- Three provenance failures: excluded

Final lineage: 10 failed, 7 passed, zero skipped, all failures explicitly superseded. No failed output supplied a final hash, qualifying count, or acceptance claim.

The four final compatibility corrections do not widen the contract:

- `PLANS.md:4055`: no retroactive Repair 10H repair/promotion
- `boundaries.md:1397`: Repair 10F/G/H remain parse/report-only
- `configuration.md:2120-2121`: configuration cannot promote future instances
- `configuration.md:2123`: logical-fingerprint policy entries remain nonconfigurable

## 21. Implementation evidence and manifest exclusions

The supplied evidence root has:

- 60 files
- 14 directories including the root
- Root mode `0700`
- All retained files regular, single-link, mode `0600`
- All directories mode `0700`
- No symlink or special object
- Canonical manifest: 55 rows, 8,396 bytes, SHA-256 `ba4d570e12f9746646a747cf4728e3328b11b8525ece7a7e652beb87404c1ca0`
- Manifest-recipe SHA-256: `9c980ce38223485bcc58483fee9218db4efcb1841eb862dc199fbf61f6f7e737`

The five file exclusions are exactly:

- `manifest/candidate-a-v1.txt`
- `manifest/candidate-b-v1.txt`
- `manifest/canonical-manifest-v1.txt`
- `manifest/manifest-reproducibility-v1.json`
- `closeout/final-implementation-report-v1.md`

The empty [commands/](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/commands) directory is outside both exclusion classes and unexplained. The manifest recipe validates directory modes while traversing, but emits rows only for files. Its bytes therefore do not authenticate empty-directory membership.

## 22. Artifact and sensitive-material findings

- No bounded sensitive-pattern hit, credential, secret, raw evidence payload, or unexpected special object was found.
- Absolute private paths were limited to expected evidence/provenance operands and the fixed allocation parent.
- Generated schemas, reports, manifests, comparisons, and closeout records remain nonproduct projections/evidence.
- The producer report’s claim that all temporary files were confined to its private root is unsupported: its test environments omitted `TMPDIR` and `HOME`, while `docs_contract_test.go:903-904` invokes `t.TempDir()`.
- The fresh audit corrected that process issue by placing `TMPDIR`, `HOME`, Go caches, and generated state under the audit root, then removing the caches.

## 23. Authority and nonauthority adjudication

The tranche is a private governance/documentary-test slice. It does not:

- Alter product Go source or a public/product schema
- Alter runtime, lifecycle, admission, credentials, deployment, or routing
- Implement v7
- Implement the semantic package
- Implement allocator or orchestrator behavior
- Create or resume an A6 child
- Grant Evidence Verification semantic/readiness authority
- Grant caller v4 semantic/readiness authority
- Turn evidence or generated projections into run truth
- Create a cross-repository framework owner

## 24. Severity-ranked findings

### A4-PROV-001 — Unexplained unauthenticated directory

- **Type:** Evidence-manifest membership omission
- **Severity:** high
- **Classification:** provenance / artifact
- **Path and line:** [commands/](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/commands); [build\_manifest\_v1.py (line 36)](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/provenance/build_manifest_v1.py:36); [final report (line 167)](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/closeout/final-implementation-report-v1.md:167)
- **Evidence:** `commands/` is empty, mode `0700`, outside the two exclusions, absent from manifest rows, and unexplained.
- **Reachable mechanism:** Empty directories may be added or removed without affecting manifest bytes or regeneration.
- **Impact:** Exact evidence-root membership is unauthenticated.
- **Required correction:** Produce a new immutable evidence root whose manifest binds directory membership, or explicitly authenticates narrowly defined directory exclusions.
- **Containment/nonclaims:** All 55 file rows verified; no file hash, mode, link, or type discrepancy was found.
- **Uncertainty:** Low; the format calls itself a file manifest, but the audit prompt expressly requires every directory and unexplained object.
- **Origin:** Implementation-evidence/provenance defect
- **Blocking:** yes

### A4-CONTRACT-002 — Allocation mechanics absent from the sole normative map

- **Type:** Incomplete allocation authority
- **Severity:** high
- **Classification:** selected target / authority
- **Path and line:** [writer (line 1350)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md:1350>), [capability consumer (line 706)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md:706>), [test (line 368)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:368>)
- **Evidence:** No normative field requires component traversal, a held parent descriptor/identity, fresh collision material, or collision-only retry.
- **Reachable mechanism:** An allocator can satisfy all current fields while using underspecified traversal or collision semantics.
- **Impact:** The exact requested security boundary is not frozen.
- **Required correction:** Add explicit normative fields and independent mutations for those mechanics; update the canonical digest.
- **Containment/nonclaims:** Existing fields prohibit scan/latest/timestamp/PID/counter/Git-hash authority, adoption, rename, and resume. No allocator exists.
- **Uncertainty:** Medium because `no_symlink_follow` and `descriptor-relative-exclusive` imply some intent, but implication is insufficient for an exact sole map.
- **Origin:** Seven-path patch defect
- **Blocking:** yes

### A4-CONTRACT-003 — Result immutability and final-record cardinality absent

- **Type:** Incomplete orchestration authority
- **Severity:** high
- **Classification:** selected target / authority
- **Path and line:** [writer (line 1358)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md:1358>), [test (line 375)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:375>), [artifact consumer (line 614)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md:614>)
- **Evidence:** The map freezes immutable events and one writer but not immutable results, exactly one final record, or the complete no-repair/no-seal rule.
- **Reachable mechanism:** Mutable results or multiple final records can satisfy the current map.
- **Impact:** The append-only one-final-record model is not fully frozen.
- **Required correction:** Add result-immutability, final-cardinality, and forbidden interruption-action fields and mutations.
- **Containment/nonclaims:** A second writer, mutable current-state authority, and resumption are already prohibited. No orchestrator exists.
- **Uncertainty:** Low for result/cardinality; medium for whether “inspection-only” implicitly forbids sealing.
- **Origin:** Seven-path patch defect
- **Blocking:** yes

### A4-ART-004 — Producer temporary-file confinement overclaimed

- **Type:** Unsupported artifact-hygiene claim
- **Severity:** medium
- **Classification:** process / artifact
- **Path and line:** [producer report (line 140)](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/closeout/final-implementation-report-v1.md:140), [test (line 903)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:903>)
- **Evidence:** Retained environments set `GOCACHE` and `GOTMPDIR`, not `TMPDIR` or `HOME`; a test invokes `t.TempDir()`.
- **Reachable mechanism:** Test temporary directories can be created outside the claimed private root.
- **Impact:** The excluded report overstates confinement and cleanup coverage.
- **Required correction:** Re-run with all five locations private or narrow the claim and account for external locations.
- **Containment/nonclaims:** No residue or supplied-root mutation was observed; fresh audit validation used confined paths.
- **Uncertainty:** Low for `TMPDIR`; HOME use is unproved rather than established.
- **Origin:** Implementation-evidence/process defect
- **Blocking:** yes if considered independently of the provenance mismatch

### A0-PROC-001 — Opening directory discrepancy initially misclassified

- **Type:** Audit sequencing defect
- **Severity:** medium
- **Classification:** process / provenance
- **Path:** [initial evidence inventory](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/implementation-evidence-inventory-v1.json)
- **Evidence:** The record said `outcome:"pass"` while also recording `empty_directories:["commands"]`.
- **Reachable mechanism:** File-only manifest reasoning was applied despite the prompt’s explicit directory requirement.
- **Impact:** Correctness inspection occurred after a gate that should have stopped it.
- **Required correction:** Treat directory membership and explanations as first-class opening-gate checks.
- **Containment/nonclaims:** The audit remained read-only; this report makes the gate failure dispositive and labels subsequent results non-dispositive.
- **Uncertainty:** None
- **Origin:** Audit-process issue
- **Blocking:** no additional effect beyond A4-PROV-001

### A3-F01 — Producer reader set omitted two direct readers

- **Type:** Validation selection defect
- **Severity:** low
- **Classification:** test adequacy / process
- **Path and line:** [docs\_contract\_test.go (line 3531)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:3531>) and [same file (line 13362)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:13362>)
- **Evidence:** Producer set 010 omitted `TestSystemOverviewAuthorityHeadersFollowRepoHierarchy` and `TestRemoteAlphaExternalTLST2APRepair5LifecycleOrderV1`.
- **Reachable mechanism:** Treating its 83 identities as exhaustive misses dynamic/table readers.
- **Impact:** Contained by producer 011 and fresh 85/106 runs.
- **Required correction:** Describe 010 as nonexhaustive and use the corrected 85 set.
- **Containment/nonclaims:** Both omitted tests passed on final bytes.
- **Uncertainty:** None
- **Origin:** Producer evidence-process issue
- **Blocking:** no

### A3-F02 — Historical pass 004 was not bound to every final document byte

- **Type:** Final-byte binding defect
- **Severity:** low
- **Classification:** provenance / test adequacy
- **Path:** `validation/004-focused-governance-contract-canonical-fix.json`
- **Evidence:** It predates later PLANS, boundaries, and configuration corrections; several producer records omit all six document hashes.
- **Reachable mechanism:** The intermediate pass could be misdescribed as final-byte proof.
- **Impact:** Contained by producer 014/011 and fresh exact-byte validation.
- **Required correction:** Treat 004 as historical and bind future owning groups to all seven hashes or the complete inventory.
- **Containment/nonclaims:** No final test failure was found.
- **Uncertainty:** Historical input bytes are not fully recoverable from that record alone.
- **Origin:** Producer evidence-process issue
- **Blocking:** no

### A2-01 — Mutation count and names are not self-pinned

- **Type:** Test hardening
- **Severity:** low
- **Classification:** test adequacy
- **Path and line:** [docs\_contract\_test.go (line 516)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:516>)
- **Evidence:** Current source and validation contain 14 exact cases, but the test lacks an independent fixed count/name assertion.
- **Reachable mechanism:** A future case could be deleted or renamed while remaining subtests pass.
- **Impact:** Future demonstration coverage could shrink.
- **Required correction:** Optionally assert the expected count and name set.
- **Containment/nonclaims:** Current source contains all 14 and all passed.
- **Uncertainty:** None after fresh execution
- **Origin:** Patch hardening limitation
- **Blocking:** no

### A2-02 — Repository test marker-family checks are narrow

- **Type:** Authority-marker hardening
- **Severity:** low
- **Classification:** test adequacy / authority
- **Path and line:** [docs\_contract\_test.go (line 247)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/docs_contract_test.go:247>)
- **Evidence:** The repository test counts exact V1 tokens in the six-document set but does not itself reject arbitrary alternate-family markers.
- **Reachable mechanism:** A differently suffixed future marker could evade the exact-token count.
- **Impact:** Potential future ambiguity.
- **Required correction:** Add bounded family-prefix and orphan/mismatch checks if family exclusivity is intended.
- **Containment/nonclaims:** Current repository-wide observation is clean; the independent parser rejected all such mutations.
- **Uncertainty:** The contract lacks a separate marker-scope field.
- **Origin:** Patch hardening limitation
- **Blocking:** no

### A1-OBS-01 — “Current observability rule” wording is locally ambiguous

- **Type:** Wording ambiguity
- **Severity:** low
- **Classification:** compatibility / selected target
- **Path and line:** [capability\_probing.md (line 706)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md:706>)
- **Evidence:** v2 is called the current observability rule within future-capability prose.
- **Reachable mechanism:** A reader could detach that phrase from the surrounding selected-not-implemented qualifier.
- **Impact:** Interpretive ambiguity only; the structured contract and surrounding reference block remain explicit.
- **Required correction:** Optionally say “selected future active rule.”
- **Containment/nonclaims:** Complete-document review found no actual claim that v2 successor execution exists.
- **Uncertainty:** Low
- **Origin:** Patch wording issue
- **Blocking:** no

### A2-03 — Apply recipe is not a complete seven-path reproducer

- **Type:** Producer-record observation
- **Severity:** observation
- **Classification:** process / provenance
- **Path and line:** [apply\_governance\_freeze\_v1.py (line 218)](/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2/provenance/apply_governance_freeze_v1.py:218)
- **Evidence:** It writes the six documents but not `docs_contract_test.go`.
- **Reachable mechanism:** Running it alone cannot recreate the final tranche.
- **Impact:** Only if misrepresented as the final reproducer.
- **Required correction:** Preserve its classification as a historical edit recipe.
- **Containment/nonclaims:** The designated closeout recipe and exact seven-path delta reproduce the final state.
- **Uncertainty:** None
- **Origin:** Evidence/process observation
- **Blocking:** no

## 25. Minority findings and parent resolution

- Auditors 1 and 2 found no blocker in their assigned contract/test scopes.
- Auditor 3 found the repository and file-manifest lineage reproducible and treated the evidence exclusions as complete.
- Auditor 4 identified that the prompt extends the gate beyond files to every retained directory. The parent agrees: `commands/` is an unexplained object whose membership is not manifest-bound.
- Auditor 4 alone raised the allocation and orchestration gaps. The parent agrees because the sole writer expressly claims the only normative structured field map; stronger consumer prose and an excluded report cannot complete it.
- Auditor 3 rated the producer temp-confinement problem low; Auditor 4 rated it medium and conditionally blocking. The parent uses medium because the excluded report makes an affirmative universal confinement claim, while recognizing that no residue or repository mutation was found.

## 26. Remaining uncertainty and explicit nonclaims

Remaining uncertainty is limited to whether a self-described file manifest was intentionally never meant to authenticate empty directories. The prompt removes that ambiguity by expressly requiring every retained file and directory and requiring all omissions/extras to be explained.

This audit does not claim:

- Semantic successor correctness
- Allocator or orchestrator implementation
- A6 qualification or readiness
- Product/runtime/deployment behavior
- Historical comparator execution
- Evidence Verification or caller behavior
- Authorization to stage, commit, push, publish, or start A6

## 27. Audit-created paths and cleanup

All created state remained beneath [the audit root](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg).

Retained supporting records include:

- [provenance gate](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/provenance-gate-independent-v1.json)
- [parser and mutation matrix](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/independent-contract-parser-and-matrix-v1.json)
- [test discovery](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/independent-test-identity-and-reader-discovery-v1.json)
- [fresh validation](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/fresh-validation-v1.json)
- [closing provenance](/Users/ds/Downloads/ES-repair10i-a6-governance-audit-1gmqlvjg/records/closing-provenance-v1.json)

The closing record is 42,872 bytes with SHA-256 `4c4cda808e9169ff9d521318f0bd3675d38fbbe9bf8985def82fce0590fd4763`.

Audit-owned Go caches, module copies, temp directories, homes, and fixtures were removed. One initial cache cleanup encountered read-only copied module files; only those exact audit-owned files were made removable and deleted. An initial audit-only closing delta attempt encoded Git inventory modes (`100644`) instead of delta modes (`0644`); its assertion failed, the audit-only output was overwritten with the corrected byte-identical delta, and no continuation or supplied object was touched.

No cache directory or `__pycache__` remains. All retained audit directories are mode `0700`; retained files are mode `0600`.

## 28. Closing provenance

After cleanup:

- Repository physical identity, branch, HEAD, tree, parent, absent upstream, status, and diff posture remained unchanged.
- Final inventory remained 54,314 bytes at `29251ed38218cadb5528db1e6b04a60078abf7aea3d9ebfa2b29437fc6c923a7`.
- Final source T remained `e01538a45d8b11a332ee6b6fc78239bfd6509303`.
- All seven final identities remained exact.
- The other 382 opening-baseline objects remained exact.
- Two new recipe continuations reproduced identical summaries and all 15 canonical outputs.
- Two new independent deltas matched the supplied delta at `f78a14dc8c78f692001a2b6818c3aae6b42f7067c7db1b1ccb18b7c702d1ac9c`.
- The complete implementation-evidence inventory, including modes, link counts, sizes, and hashes, was unchanged.
- The unexplained `commands/` directory remained present, so the opening discrepancy also persisted at closing.

## 29. Explicit confirmations
```
REPOSITORY_MUTATION_NOT_PERFORMED
SUPPLIED_EVIDENCE_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
FORMATTING_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
EVIDENCE_VERIFICATION_NOT_INVOKED
CALLER_NOT_INVOKED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
NESTED_SUBAGENTS_CREATED: 0
```
