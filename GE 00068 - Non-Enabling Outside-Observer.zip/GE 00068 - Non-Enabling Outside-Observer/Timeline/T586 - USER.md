Here is Codex's response:

### 1. Exact primary verdict

`ES_ACTIVE_CANDIDATE_TEST_HARNESS_REPAIRS_COMPLETED_NATIVE_LINUX_PENDING`

### 2. Opening repository identity

- Root: `/Users/ds/Repositories/Execution Substrate`
- Branch: `trunk_dev`
- HEAD: `b92bd9884106154d25342e1573dcc4c312311436`
- Tree: `cdd4e44bac15c1952d70997143040644361f0bb1`
- Parent: `4f797fb63d3c5b95275b1455af36ebc9b695f773`
- Upstream: `origin/trunk_dev`
- Divergence: behind 0, ahead 1
- Status: staged 0, modified tracked 64, untracked 11, conflicts 0
- Status digest: `adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93`
- Ignored: 2,849 entries, digest `7b065aa851b4c0876529248f9faafb7343d8f2b0504fd38092c7129efbaa4e4f`
- Locks/active operations/submodules: none

Opening worktrees:

- Main: `trunk_dev` at expected HEAD
- Evidence verification: `05dcedb75b674660215504dcf5b5fab9dbb8aa2f`
- External TLS lifecycle reset: `fbc0e7252c2779add456cc64a77ba3e25cc731ce`
- External TLS policy core: `05dde14d185b6e022dcc169ef1a658a97961850f`
- External TLS policy status: `fbc0e7252c2779add456cc64a77ba3e25cc731ce`
- External TLS status observation: `567bceced5df95ecfe787cc66038d463a854e12c`

### 3. Protected candidate status

All 64 modified tracked files and 11 untracked files were treated as protected current reality. Nothing was restored from HEAD, removed, staged, stashed, reset, switched, rebased, merged, or cleaned.

The opening and closing path/status digest is identical. The 75-path candidate set and all six worktrees remain unchanged.

### 4. Applicable guidance

Consulted `AGENTS.md`, `PLANS.md`, applicable execution-lifecycle documents, capability probing, supported-Linux qualification, Remote Alpha host guidance, relevant runbooks, current helpers/tests, and the operator script read-only.

Classification:

- Production no-follow custody and privacy-first filtering: `Current invariant`
- Current finite test inventories: `Bounded slice rule`
- Retired operator compatibility routes: `Temporary compatibility edge`
- No `Reopened redesign seam` was exercised
- Repair type: bounded test-only refinement; no documentation change was warranted because documented behavior did not change

### 5. Exact M1/M2/M3 reproduction

M1 was reproduced before repair with:

```bash
go test ./es/admission \
  -run '^(TestDarwinStagingCustodyCapabilityProbeExercisesActualSyscalls|TestStagingCustodyCreatesNoMarkerAndCloseRetainsRoot|TestRuntimeMountArchiveValidatesThenMaterializesWithinLimits)$' \
  -count=1
```

Under the governed offline Go environment, all three failed with `too many levels of symbolic links`.

M2 synthetic reproduction showed:

- A comment containing `newExecutionLocator()` produced a raw count of 1 while semantic calls remained 0.
- A dead string containing `s.nomadClient.submitJob` satisfied the lexical spelling while semantic calls remained 0.

M3 synthetic reproduction showed:

- Changing `retired_es_existing_host_route() {` to `retired_es_existing_host_route () {` remained valid under `bash -n` but broke the old exact-layout marker.
- An inert comment changed the raw symbol count from 3 to 4 without changing behavior.

This section is the retained equivalent of the requested external reproduction report; no repository report file was created.

### 6. Exact task-touched files

Exactly these 12 existing authorized test files changed:

- `es/admission/executionpackage_test.go`
- `es/admission/lifecycle_test.go`
- `es/admission/mounts_test.go`
- `es/admission/resolved_execution_plan_test.go`
- `es/admission/resource_limits_test.go`
- `es/admission/results_test.go`
- `es/admission/service_direct_test.go`
- `es/admission/staging_custody_darwin_test.go`
- `es/admission/staging_custody_test.go`
- `es/admission/workstream_c_guardrails_test.go`
- `es/admission/writablestate_readiness_test.go`
- `remote_alpha_operator_test.go`

The thirteenth authorized file, `es/admission/submit_test.go`, remained byte-identical at SHA-256 `33b525aa935d591ad3f8db71bacec439ca35c35c787685ecc8657a8e61d2bb1b`.

### 7. Preexisting versus task delta

Each row records opening file hash, closing file hash, opening candidate-delta hash, closing candidate-delta hash, and byte change:

```text
executionpackage_test.go
  4daa067640248558b39b918ab2d8559ddfcf64115520d5df37a501b5ec6706f9
  -> 69b253790f8f29e7c564b6e7493fb0fcf2eb1f72b6e290520152b1af3c16f858
  opening-delta 7a7efe9b45be4d6147012961e32aa86992f307dceea8ce65b72cf690476ffaaa
  closing-delta d4df234c4d18d998c9e35edad04ed80826a11a14f330a64c2fe5f9905b46fb0d  +22 bytes

lifecycle_test.go
  fc547af58810fa494c099f7347e4a1beadf461cc1e15fe0dfc9e9f876ae61a8a
  -> c5cd093019b4c202c334bdf9672d2e3d2bdf807cd17b90d9c80e9bcaf2cefba7
  opening-delta 35f1394a655a46c01e072b4a1aed19ff9a05c804b8dbb713dd1dbd190105d63b
  closing-delta 0befd2bd2fa6e7ccfe3df4540dda1224c90d825ec5c3ac04d1285c9d0b8a3e26  +22 bytes

mounts_test.go
  85639779d814d68360876cf2ef5c9566c952b1e094be923f9ea800fc599027c3
  -> d871b26d4d365805b408c8acfb3d314fd7e312b0b7356db0787344ec5c915519
  opening-delta c40c1e2ab1027c733b47ba8991c13ea87ff8207097021296297b334344fefb8c
  closing-delta 7d9e627496fe32db051529a4636b3287475582339950fae338018b403167225a  +22 bytes

resolved_execution_plan_test.go
  e7dfc917c567b45eafe1151cca3a7100d495d90f9543bb48de98a80693782d41
  -> 82d29ee395f4199a4f90334b4d6832a641c4c442505d828cb48310b4426ede1c
  opening-delta e7dfc917c567b45eafe1151cca3a7100d495d90f9543bb48de98a80693782d41
  closing-delta 82d29ee395f4199a4f90334b4d6832a641c4c442505d828cb48310b4426ede1c  +88 bytes

resource_limits_test.go
  54eff4aeca660acca01c4e1cf6a8c714ed0178ac7c0a5053692d354f719ae9ee
  -> 5f08020f7fc37adfe4d5ada5c75f17731b880b08391c9ac7ae076ee5b1aa3cd7
  opening-delta 54eff4aeca660acca01c4e1cf6a8c714ed0178ac7c0a5053692d354f719ae9ee
  closing-delta 5f08020f7fc37adfe4d5ada5c75f17731b880b08391c9ac7ae076ee5b1aa3cd7  +33 bytes

results_test.go
  4f9d161e1e3d2aaa8837425202aed2d817768e3ba55bc6aa582a544b0b9d48e9
  -> 6845eb633af053abdeabea890e1bbad9c96d3d7194fdf972af5b05a7e97d1d96
  opening-delta 4bdd46c5bdeb7ab8053247faf90f20784a5a3ad0ce124242d83db0a8d10e12a6
  closing-delta 4864ac792a9003a6809b55dfd91b5708aba54fa06f9fda73eeadb8094cb83b71  +66 bytes

service_direct_test.go
  f3d078953d22cc9e5f83e9b8c1b385f4a189806bdf2df9438b06161ea1a4356d
  -> ff8cba1ed9ef76d8f3e1cacb221d9deb716c4934417672016ee98e4af3929f9d
  opening-delta bf9a89b9530d2f0723bc1dd8fea06ec40717474b78f1685915fe2f8e7376ac28
  closing-delta 864453b70e8a1d107be55a17591730283b89ad6f19cc9294ebaf30cbb50a1422  +33 bytes

staging_custody_darwin_test.go
  993ef55b8c44b43c9caf88a1d36499388d63ae8254f0f34747e89f5d1bffba18
  -> 229c1514213a78dd58717c7e0b4eb87e7e0530fc6452c1e365c4b1b7807683f5
  opening-delta 993ef55b8c44b43c9caf88a1d36499388d63ae8254f0f34747e89f5d1bffba18
  closing-delta 229c1514213a78dd58717c7e0b4eb87e7e0530fc6452c1e365c4b1b7807683f5  +33 bytes

staging_custody_test.go
  c42ca16b0be98b1fc8d8db89e6883fcfb75c8304a9c172ab8b4e3ca93974b56f
  -> 7dc4b6eeeb1eacc53e2647899857187509f3e6d75204d33bc7b588bb8047f537
  opening-delta c42ca16b0be98b1fc8d8db89e6883fcfb75c8304a9c172ab8b4e3ca93974b56f
  closing-delta 7dc4b6eeeb1eacc53e2647899857187509f3e6d75204d33bc7b588bb8047f537  +3196 bytes

workstream_c_guardrails_test.go
  30b4d6bb035228dacbc2f38535f6e15acd60df3fd4a960a5182e7e3bd04b0007
  -> e77463365f503425f6bb0349349f322d50398fdfa87efcabe583d24f0a2e1a46
  opening-delta 09b0550297fc9854bdcdce42ef9082889d0eb8abd15e8b107a75745ed7f0be01
  closing-delta 9743224e5329138dcdb39c65d028a37c75fcf11ddfa6589f09ce26cb574cdf6a  +11226 bytes

writablestate_readiness_test.go
  c8fcc386ea2afa30d4f1cea8d45fef781386e78f5858a3eed28d7186248f84c6
  -> dd70e1e92e0b00e4d6279f7638fa284168d465823cf1fc2037721314df2ac6bf
  opening-delta 65442ed07d929eb0c156c2acebcf64b600c52152320e9b8fe367645ce13baf84
  closing-delta 08df1d75381c4ccfb50325a65935ff4b9d8150f06d2f7160e10b3f4a3183054e  +44 bytes

remote_alpha_operator_test.go
  b5466022ac34bc94c26885f3c890b0940a3cfc76837d5f525a2f3c78cc843348
  -> 3b248b290ab51b3edfae5a72e59699c7b206b1bd4ccbe3b75f0d44ac576a3d24
  opening-delta 0bcfe12891b88b52da3816b027dd05e9cba196f4471efb41506945146ffc4448
  closing-delta 224277fbae4d97101a78d0448c53ddcd397b5d6501627a606e8219a9fc25b69d  +11850 bytes
```

The additional delta is limited to physical test-root substitution/helper tests, typed Go semantic inventories/mutations, and structure-aware shell inventories/mutations.

### 8. Physical temporary-root helper design

The helper is at [staging_custody_test.go](</Users/ds/Repositories/Execution Substrate/es/admission/staging_custody_test.go:13>).

It:

- Starts with `t.TempDir()`
- Resolves the allocation using `filepath.EvalSymlinks`
- Requires an absolute existing directory
- Uses `os.SameFile` to prove the resolved path is the same allocation
- Re-resolves the result and requires exact path equality
- Leaves cleanup ownership with `testing.T`

Direct tests prove same-object identity, already-physical spelling, subtest cleanup, and continued refusal of an intentionally symlinked staging ancestor.

### 9. Repaired custody-sensitive call-site inventory

All 48 substitutions changed only `t.TempDir()` to `physicalTestTempDir(t)`, or the corresponding `filepath.Join(t.TempDir(), ...)` form.

| File | Calls | Owners | Custody reason |
|---|---:|---|---|
| `executionpackage_test.go` | 2 | Trust-materialization cause; workload trust capture | Direct custody/captured-file paths |
| `lifecycle_test.go` | 2 | Successful stage retention; descriptor-close retention | Claimed staging roots |
| `mounts_test.go` | 2 | Archive validation/materialization tests | Mount materialization under staging custody |
| `resolved_execution_plan_test.go` | 8 | Owned material; pre-freeze failure; runtime-support identity; B2 operational causes | Captured material and staging/results host context |
| `resource_limits_test.go` | 3 | Local limits; exact-limit/no-follow; ancestor replacement | Stable no-follow capture roots |
| `results_test.go` | 6 | Governed retention, retained-publication fixture, configured-root replacement, result-service fixture | Retained-result/staging custody |
| `service_direct_test.go` | 3 | Runtime input valid/nonregular/nonabsolute tests | Runtime-support validation roots |
| `staging_custody_darwin_test.go` | 3 | Darwin primitives, capability probe, replacement refusal | Direct Darwin custody syscalls |
| `staging_custody_test.go` | 13 | All general custody creation, expected-tree, materialization, revalidation and probe fixtures | Direct no-follow custody |
| `workstream_c_guardrails_test.go` | 2 | `newWorkstreamCTestService`, used by five Workstream C prepare/submit tests | Shared staging/results fixture |
| `writablestate_readiness_test.go` | 4 | Stage/mount tests and synthetic normalized-run fixture | Staging/results custody |

Remaining `t.TempDir()` calls were independently inventoried:

- Four lifecycle calls are non-custody results/layout or debug-retention fixtures.
- Two resolved-plan calls are pure projection/copy inputs.
- One result path-traversal call performs lexical path calculation only.
- One result test uses `t.Chdir` for the runtime-unconfigured path.
- Three writable-state calls construct marker-authority fixtures, not staging custody.
- The helper’s own `t.TempDir()` is mandatory.
- The direct helper test’s allocation is intentionally compared with the resolved object.

### 10. Preserved symlink/unsafe-object negative-test inventory

Preserved and passing coverage includes:

- Intentional symlinked staging ancestor refusal
- Every preexisting-object refusal
- Existing-leaf materialization refusal
- Root replacement detection
- Hard-link and symlink replacement detection
- Unexpected-child and missing-child refusal
- Darwin root replacement refusal
- Stable-capture single-link, no-follow, and ancestor-replacement tests
- Retained-results configured-root replacement refusal
- Cleanup limited to exact capability-probe objects

No production no-follow code changed.

### 11. Go semantic-oracle design

The new analyzer begins at [workstream_c_guardrails_test.go](</Users/ds/Repositories/Execution Substrate/es/admission/workstream_c_guardrails_test.go:4017>).

It uses parsed AST plus `go/types.Object` identity, the existing cross-target typed package loader, exact caller inventories, function-literal classification, defer classification, and AST statement order.

It no longer treats selector spelling, comments, strings, whitespace, or incidental line placement as semantic evidence.

### 12. Go semantic inventory and mutation coverage

The guarded inventories now include:

- Exact `Service.Submit` freeze/projection/custody/materialization/handoff/Nomad sequence
- Exact resolver sequence through semantic-plan, byte-material, and host-context freeze
- Exact mount-parser sequence
- Sole resolver, locator, run projection, and Nomad submission references
- Exact plan/material/host constructors
- Mount target normalization
- Typed gzip/tar call-site inventories
- Custody claim, materialization, and pre-handoff revalidation
- Existing typed finite `ReadDir`, synchronization-owner/reader/writer, and rejected-A3 topology checks

Mutation tests prove:

- Comments and strings are inert
- Formatting and local-variable renaming pass
- Dead helpers do not satisfy live flow
- Hidden helpers and closures are detected
- Wrong order fails
- Alternate consumers fail
- Missing required calls fail
- Duplicate/unexpected calls fail

### 13. Shell semantic-oracle design

The shell analyzer begins at [remote_alpha_operator_test.go](</Users/ds/Repositories/Execution Substrate/remote_alpha_operator_test.go:5173>).

It is:

- Heredoc-aware
- Comment- and quoted-string-aware
- Independent of indentation, blank lines, and function-name spacing
- Based on function definitions, semantic commands, case patterns, dispatch handlers, exact caller ownership, terminal status, and printed literal lines
- Backed primarily by real behavioral invocation tests

The operator script itself was not changed.

### 14. Retired-route/flag behavioral inventory

Preserved behavioral coverage includes:

- Top-level retired evidence aliases
- Nested retired workload-auth and runtime-identity aliases
- Explicit absence of nested `recovery-session vault-service-user-check`
- All six retired flags in split and equals forms
- Historical `--readiness-summary` and `--staging-record` forms
- Existing-host tombstones `es-writable-state-readiness-check` and `readiness-session`
- Exit status 2
- Empty stdout and exact fixed stderr
- No helper execution, staging, filesystem artifact, or other side effect
- Secret-like arguments filtered before retirement classification
- Unrelated live recovery, TLS, and EGS routes retained

### 15. Shell structure-insensitive regression coverage

Passing regression mutations prove:

- Whitespace-only function formatting is accepted
- A retired-route comment is ignored
- An inert retired-flag string is ignored
- Duplicate active dispatch fails
- Missing route/flag fails
- Wrong handler fails
- Privacy-order reversal fails
- Fixed refusal-text drift fails
- Removal of an unrelated live recovery route fails

### 16. Formatting and diff checks

- `gofmt -w` ran only on the 12 task-changed Go tests.
- `gofmt -l` checked all 44 currently modified/untracked Go paths: no output.
- `git diff --check`: exit 0, no output.
- `bash -n scripts/remote_alpha_operator.sh`: exit 0.
- Closing static recheck produced the same clean results.

### 17. Focused test commands and results

All used cached Go 1.26.5 with preserved original `PATH`, `GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`, and `GOFLAGS=-mod=readonly`.

M1:

```bash
go test ./es/admission \
  -run '^(TestPhysicalTestTempDir.*|TestStagingCustody.*|TestDarwinStagingCustody.*|TestRuntimeMountArchive.*|TestStableLocalCapture.*|TestTrancheALocalMaterialBoundariesUseSelectedLimits|TestTrancheB2TrustMaterializationCauseUsesFixedPublicError|TestWorkloadTrustMaterialCaptureWritesVaultAndCombinedBundles|TestResolvedExecutionMaterialOwnsBytesBeforeHostMaterialization|TestSubmitStopsBeforeFreezeWithoutRunOrFilesystemEffects|TestRuntimeSupportMaterialIdentityMatchesCapturedBytes|TestTrancheB2PreSubmissionOperationalCausesUseFixedPublicMessages|TestValidateExecutionRuntimeInputs.*|TestStageExecutionInputsSucceedsWithOwnerOnlyStagingRoot|TestRuntimeMountExtractionSucceedsWithOwnerOnlyMountStageRoot|TestRetain.*|TestRetained.*|TestResult.*|TestStatus.*|TestDescriptorCloseRetainsSuccessfulRunRoot|TestWorkstreamC(Prepare|Submit|3).*|TestReadRetainedResultBundle.*)$' \
  -count=1
```

Result: pass, `ok execution-substrate/es/admission 1.240s`.

M2:

```bash
go test ./es/admission \
  -run '^(TestResolvedExecutionPlanPostFreezeConsumerGuardrails|TestSemanticCallSequenceRejectsLexicalAndControlFlowMutants|TestTrancheAResourceAndFilesystemCustodySourceGuardrails)$' \
  -count=1
```

Result: pass, `1.105s`.

M3:

```bash
go test . \
  -run '^(TestRemoteAlphaOperatorHelpAndInventoryExposeRetirementAndPreserveUnrelatedRoutes|TestRemoteAlphaOperatorClassifiesRefusalsBeforeHelperPathInitialization|TestRemoteAlphaOperatorBlockedSubcommandsRefuseWithoutRouting|TestRemoteAlphaOperatorExistingHostESRoutesAreFixedEffectFreeTombstones|TestRemoteAlphaOperatorRetiredRoutesApplyExactPrivacyPrefilterFirst|TestRemoteAlphaOperatorRecoverySessionRetiresHistoricalDisplayAndPreservesCurrentRoutes|TestRemoteAlphaOperatorEvidenceCompatibilitySurfacesAreFixedEffectFreeRetirements|TestRemoteAlphaOperatorEvidenceRetirementKeepsPrivacyPrefilterFirst|TestRemoteAlphaOperatorRecoverySessionRejectsForbiddenFlagsAndUnsafeArgs|TestRemoteAlphaOperatorSourceCutsOffEvidenceCompatibilityAndPreservesUnrelatedRoutes|TestRemoteAlphaOperatorRetiredRouteSourceInventoryIsExact|TestRemoteAlphaOperatorEvidenceRetirementSourceInventoryIsExact|TestRemoteAlphaOperatorSemanticInventoryRejectsLayoutAndOwnershipMutations)$' \
  -count=1
```

Result: pass, `ok execution-substrate 1.121s`.

### 18. Default-host admission result

Without a `TMPDIR` override:

```bash
go test ./es/admission -count=1
```

Passed: `ok execution-substrate/es/admission 5.562s`.

### 19. Default-host full-suite result

Without a `TMPDIR` override:

```bash
go test ./... -count=1
```

Passed across every package. Notable durations: root `86.548s`, admission `7.285s`, app `110.485s`.

### 20. Physical-root validation results

With `TMPDIR=/private/tmp`:

- `go test ./es/admission -count=1` — pass, `5.508s`
- `go test ./es/app -count=1` — pass, `60.615s`
- `go test . -count=1` — pass, `76.098s`
- `go test ./... -count=1` — pass; root `85.135s`, app `110.087s`, all packages green

### 21. Race-validation result

```bash
TMPDIR=/private/tmp go test -race ./es/admission ./es/app -count=1
```

Passed:

- Admission: `18.454s`
- App: `263.703s`
- No race report

### 22. Offline Linux cross-compile result

Commands used `CGO_ENABLED=0`, the governed offline environment, and `go test -c ./es/admission`.

- linux/amd64:
  - SHA-256 `2a481f4d52e60dcde8f1bbff5510ada84125992cc92e7f0500c740b9f9de27b4`
  - Size `23004091`
  - ELF x86-64, statically linked
- linux/arm64:
  - SHA-256 `36fa42046afa29c0256b6a6d9bdc3d3927eb94c2d65212ade28d55c9bd8b537b`
  - Size `21612183`
  - ELF aarch64, statically linked

Both binaries were created only under `/private/tmp/es-crosscompile.4GkzVD`, then unlinked. The directory was removed and absence verified.

This is compile evidence only, not native runtime validation.

### 23. Authority/security review

The task delta is test-only. It introduces no:

- Production behavior or source change
- Documentation, contract, runbook, configuration, or script change
- Authority widening or hidden mutable truth
- No-follow policy weakening
- Process/descriptor custody change
- Cleanup/failure-path change
- Privacy-order or fixed-public-error change
- Platform-scope change
- External schema integration
- Reliable keyed-submit wiring
- Secret-bearing artifact

### 24. Native-Linux validation handoff

Module/toolchain identity:

- Module: `execution-substrate`
- `go.mod`: `af622e2528c074e8d8d46ab5b18e8f57ebb7fad39a1f4349fe94d3c83783a1e3`
- `go.sum`: `5c2e536bc93d89ce2a874a5203207b2bee6a859a90471c7abfbe4850fb00970e`
- Required Go: `go1.26.5`
- Required environment: `GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off GOFLAGS=-mod=readonly`
- Native systems: governed Ubuntu 24.04 linux/amd64 and linux/arm64

Exact native commands:

```bash
go test ./es/admission -count=1
```

Run once on each architecture after authenticating the exact candidate bytes below.

```text
M|0644|93564|c422ac326215c3d983038fe02de88a4019a18e759a37b60dd619ee7a921018e1|.docs/execution_lifecycle/contracts.md
M|0644|45804|f0e8543c7c7e3e56f7ccec76c810ce719762058d6edd2df3132d5ecc9a2738ad|.docs/execution_lifecycle/design.md
M|0644|67959|7b9383d3dceb6c3a4c9c35408af599984c077ff920aaf92e72e5eaa426b245ea|.docs/execution_lifecycle/es_execution_admission_model.md
M|0644|73961|20a16ffc000cbb9351ff09e5744abfaf1217fe8ef1ffd435f24d36885dbea2f8|.docs/execution_lifecycle/implementation.md
M|0644|62228|9d99a01de5c9363b5faf25907d32ddfe0142dd661f257e9c222fd51ebfa377bb|.docs/execution_lifecycle/reliable_submit_persistence_and_concurrency.md
M|0644|62970|8efb52819c640425a32e2fd09c5ec1c435707a7fed1f1ec23034b1eb25dd6114|.docs/execution_lifecycle/submit_idempotency_correlation_and_recovery.md
M|0644|18371|84b93a1453c4ed97beee6af5ec371295447660de1737df45e0088165add32ee8|.docs/system_overview/artifact_publication_storage.md
M|0644|68229|43c95f0e2b4778764a1450d872af2be422fc844de83d991ee22ebd608d9ab406|.docs/system_overview/boundaries.md
M|0644|8524|6474236759cf4f6923d971a8d5d7814bb47fa6941feb6314a777295ebdd0bce8|.docs/system_overview/capability_probing.md
M|0644|100680|3413b85b7730da6cdc526379a1c883a363395980a51c075ab167350dc94bd4ed|.docs/system_overview/configuration.md
M|0644|78144|5dd563b163c5d863cefca04252b52b0e85bef06a5208a9e080f01f5f6f5f49d2|.docs/system_overview/contracts.md
M|0644|9364|cebc09a3d47f9ae9da8fb702d06a354d3340566e1365b5c326eaa624e40a9394|.docs/system_overview/remote_alpha_beta_es_privilege_boundary_assessment.md
M|0644|8932|889041966368869534fa1c9ccaed62834c3aeaae93baa433d4862eb08a039289|.docs/system_overview/remote_alpha_beta_es_privileged_operation_matrix.md
M|0644|10286|2de76470e8dd9f96db7104bfba220d87c502ff06dbcd954e20ee30d9e041048a|.docs/system_overview/remote_alpha_beta_es_runtime_ownership_normalization.md
M|0644|2547|77c8c4464a9fcff0cb7436c67a9e4d6dfedf384342e11dd7862dd9c1acf91489|.docs/system_overview/remote_alpha_beta_es_writable_state_ownership.md
M|0644|299497|b4369112059e92116d21d2108acf396c534a920f331dff548513b7bdd2a7e00f|.docs/system_overview/remote_supported_host_alpha.md
M|0644|11555|7d4761de88d6723dba49e84b965c50903f03718fa9dd973b8e703a4eae513994|.docs/system_overview/runtime_config_ownership.md
M|0644|18428|98350b4dcc90c55388d8d996ceda9275970e0245ef958ad93679427fe468fa8c|.docs/system_overview/supported_linux_host_qualification.md
M|0644|9831|682351c6c4be041090907d8aab8b285503d7268b0929cda36c8b311d6fa98f0a|.runbooks/execution/v1_submit_runtime_identity_reference.md
M|0644|9234|1eec5bae5bf05f74bc1480582080e29ac3d7ee613c4f4f95ec4ca8432a460e1e|.runbooks/execution/v1_submit_static_script.md
M|0644|31422|7e041d159e0b6b775741034bab4aa1ddc4140e11486a213a895871178717145e|.runbooks/system/v1_bringup.md
M|0644|208856|a2c3f428b3fe2606d1ad6cf1797d69e66bdedf760e0f58927742cafdea2d3b4b|PLANS.md
M|0644|7033|86cf4c40a0773889f9f4f6cbe7b2e73beacfcb551e48ac37374acdd5f73f162f|README.md
M|0644|684635|d1d4569494b1e5905d40fda5e93e1e15bd1cc603278cb22935fbc4883ba12a96|docs_contract_test.go
M|0644|10219|a4e40cf6cf003286115c7ce628947dbb7b855a06b466f4a1b36db698365b4bcc|es/admission/authorityhandoff.go
M|0644|5852|d9d955b9ab8b3a47012438c40a823887662204c59312f595d2f8b15079109ee6|es/admission/authorityhandoff_test.go
M|0644|11605|d5fb8b4441d85566e26a53fcd4398ef00bd558321da85037b56e2e438e80f9a1|es/admission/executionpackage.go
M|0644|11621|69b253790f8f29e7c564b6e7493fb0fcf2eb1f72b6e290520152b1af3c16f858|es/admission/executionpackage_test.go
M|0644|13480|42107368d530b49fb1ea6f4afab9475095da0c2752fba45d606297324af5728c|es/admission/lifecycle.go
M|0644|26525|06655f4712be0caf1b08baf94b7ffffe5636ef4586faf408e10432fcb635444d|es/admission/lifecycle_nomad_test.go
M|0644|7930|c5cd093019b4c202c334bdf9672d2e3d2bdf807cd17b90d9c80e9bcaf2cefba7|es/admission/lifecycle_test.go
M|0644|16973|bf443378ccaf2cdc0deb530d9677a731c91f080359e4d55e9cab5730619c22b9|es/admission/mounts.go
M|0644|14923|d871b26d4d365805b408c8acfb3d314fd7e312b0b7356db0787344ec5c915519|es/admission/mounts_test.go
M|0644|2704|97e9900720789081bac411f70d8cde681046f93d81ddf9965e4ce8239b31da0f|es/admission/ownership.go
M|0644|5210|9232966e014a71ee37c1e0a29d8075a69df25f51f871bdfa48ee60101b1e66cf|es/admission/policy_payload.go
M|0644|18728|9819047b95c8ab939a9a2142a3c98b4dd408a4154b4661f14d68d854df89ca62|es/admission/reliable_submit_guardrails_test.go
M|0644|33075|1065b74505af33841060478407b20f70cd2a22181b6c69f214724d280bbab7b8|es/admission/results.go
M|0644|31612|6845eb633af053abdeabea890e1bbad9c96d3d7194fdf972af5b05a7e97d1d96|es/admission/results_test.go
M|0644|34043|1f30d484c88902c3973c0a32327e84528845be2ddbfc1c3bba5ea8857fd454db|es/admission/service.go
M|0644|13314|ff8cba1ed9ef76d8f3e1cacb221d9deb716c4934417672016ee98e4af3929f9d|es/admission/service_direct_test.go
M|0644|8824|6cc366b970e6bee1ad916838db0b6c7d0139eb6f3469a03f026438a9daa616ea|es/admission/submit.go
M|0644|22601|33b525aa935d591ad3f8db71bacec439ca35c35c787685ecc8657a8e61d2bb1b|es/admission/submit_test.go
M|0644|239149|e77463365f503425f6bb0349349f322d50398fdfa87efcabe583d24f0a2e1a46|es/admission/workstream_c_guardrails_test.go
M|0644|4638|992863dba0b04c8bd0870b147239dbbe15f5dec46aa46de14c8b43139cbcfbeb|es/admission/writablestate_preflight.go
M|0644|31121|dd70e1e92e0b00e4d6279f7638fa284168d465823cf1fc2037721314df2ac6bf|es/admission/writablestate_readiness_test.go
M|0644|5041|8752824d4fea8aa8fe49d792b1a51d64a504a0408789b0049956a502192457ab|es/app/result_integration_test.go
M|0644|8864|23da6147541ed69a472171bb71f0f6426a4dd684ed4a9a45f9331989a829f261|es/app/staging_cleanup_integration_test.go
M|0644|9273|d1202ab7b0b9e528c116a696cf6c6f1343e0776447754068a4fe5ff0fc48b078|remote_alpha_check_es_writable_state_readiness_test.go
M|0644|239|63a0fdad37d48f46479d5f271dc665baca1f8be4f3462fea1ffa180fbf6b9d63|remote_alpha_es_service_user_rollback_rehearsal_test.go
M|0644|237|0ec9f33cf5059cc92e35b13437247146b30d640ec17b745c4b34cd5242de465d|remote_alpha_migrate_es_service_user_test.go
M|0644|234098|3b248b290ab51b3edfae5a72e59699c7b206b1bd4ccbe3b75f0d44ac576a3d24|remote_alpha_operator_test.go
M|0644|222|0fca226f7cc058eaf99a9356623136601695b1561c3135078b54d9f66e4bc08a|remote_alpha_plan_old_root_cleanup_test.go
M|0644|244|6bf2ed9fe8bd4a659554df48192b4e2937c2751fa1c757bb5d2a300b0b1933f1|remote_alpha_prepare_es_writable_state_ownership_test.go
M|0644|42102|8b4f7991b6a0067fcf266cde8185d0543ec8fcb46acd51ab7ffa97022bef23ea|remote_alpha_runtime_security_boundary_check_test.go
M|0644|245|7d72e4c67711bc3b929b33024708462ee523e104565fbb3610f43f649657bb2f|remote_alpha_stage_es_service_user_migration_test.go
M|0644|260|2b8e2290c54b0f26ff0dc513a7c7377a13bef38a157f65f33f36910acf138e25|remote_alpha_stage_es_writable_state_readiness_check_test.go
M|0644|14440|4d65b66bb90a5f3ff55b1e5e9aa65422de490ff2ecfc6c96f1534286dd2fb482|scripts/internal/operator_failures.sh
M|0644|555|5f15e132e40f3efd1369780c87fccaf961716f7ee9efb8f230789190929e0cad|scripts/internal/remote_alpha_check_es_writable_state_readiness.sh
M|0755|557|82296f862c7af00274d749492e5d26a8ca871c9d1153686a475aa281c532b390|scripts/internal/remote_alpha_es_service_user_rollback_rehearsal.sh
M|0644|535|cc2c48595970622811d891b3746d42b6cb13a066bba6a56a6a7e81ebf0d984f2|scripts/internal/remote_alpha_migrate_es_service_user.sh
M|0644|531|936cf8624cfdaf89754225023ee0eff588fd699b228a87d2802d59517e0893ac|scripts/internal/remote_alpha_plan_old_root_cleanup.sh
M|0644|559|e8f6c50c5d1582dbec94f58b90887d75eb22e27a49da65f64803a7c18f5d21ab|scripts/internal/remote_alpha_prepare_es_writable_state_ownership.sh
M|0755|567|33b79cc0ff4ae86df8c59ea7da3e8399e0f12f4b7fd8151070de30d334d7b06d|scripts/internal/remote_alpha_stage_es_writable_state_readiness_check.sh
M|0755|186929|bb58b56b7e13bb848234e2411f357d3489631c9d8a65a6e5da372353a150426c|scripts/remote_alpha_operator.sh
??|0644|28074|5b8b95116996b4c2fbcd563586915c30a9e5bdd5da0159c47093432586ea446e|es/admission/resolved_execution_plan.go
??|0644|114768|82d29ee395f4199a4f90334b4d6832a641c4c442505d828cb48310b4426ede1c|es/admission/resolved_execution_plan_test.go
??|0644|3207|4971e38a41a925109089a2437550516dc51b5fb65edc42a64ad253ecb31378ba|es/admission/resource_limits.go
??|0644|14526|5f08020f7fc37adfe4d5ada5c75f17731b880b08391c9ac7ae076ee5b1aa3cd7|es/admission/resource_limits_test.go
??|0644|40592|b1230b63a7ab76e756606c4444b76580a3cae57e5f64edf8c33169c461f46638|es/admission/staging_custody.go
??|0644|855|5927d8b7c2a41f659c39f68cc6d2c6e61ab3eee9e601b30f43ad1bda9b7271d4|es/admission/staging_custody_darwin.go
??|0644|3781|229c1514213a78dd58717c7e0b4eb87e7e0530fc6452c1e365c4b1b7807683f5|es/admission/staging_custody_darwin_test.go
??|0644|1058|13d703288b8f63700e6f5744508144f39a0417c3beaf2bd70702429bdab66080|es/admission/staging_custody_linux.go
??|0644|2272|85805dd6f053d2afa53fed9443c1165bebf8302d1d7651058dfa0e04571ac40c|es/admission/staging_custody_linux_test.go
??|0644|24809|7dc4b6eeeb1eacc53e2647899857187509f3e6d75204d33bc7b588bb8047f537|es/admission/staging_custody_test.go
??|0644|29402|8a28d5830ac45e7e01ff063d1a940b9c7a01c4a98345bd28c7d272b2ffc685c6|es/admission/tranche_b2_privacy_guardrails_test.go
```

Native reports must record architecture, Ubuntu/kernel identity, toolchain and environment, candidate manifest verification, command/output/exit status, and explicit evidence for:

- `openat2`
- `RESOLVE_BENEATH`, no magic links, no symlinks
- required `RESOLVE_NO_XDEV`
- `renameat2(RENAME_NOREPLACE)` collision behavior
- stable identity/device checks
- exclusive run-root custody
- actual mount-crossing refusal

Cross-compilation does not satisfy this gate.

### 25. Remaining commit blockers

The sole known pre-commit gate is successful native execution of `go test ./es/admission -count=1` against these exact bytes on:

- Governed Ubuntu 24.04 linux/amd64
- Governed Ubuntu 24.04 linux/arm64

### 26. Closing repository identity and status

Closing identity exactly matches opening:

- Branch `trunk_dev`
- HEAD `b92bd9884106154d25342e1573dcc4c312311436`
- Tree `cdd4e44bac15c1952d70997143040644361f0bb1`
- Parent `4f797fb63d3c5b95275b1455af36ebc9b695f773`
- Upstream `origin/trunk_dev`; behind 0, ahead 1
- Staged 0; modified tracked 64; untracked 11; conflicts 0
- Status digest `adcc18919d1f7c93247f9cf2807a4a0f2eab519c5d3cbcdebf52a4c177807f93`
- Ignored count/digest unchanged
- Worktree set and every worktree HEAD/branch unchanged
- No locks, active operations, or submodules

### 27. Exact modified/untracked path set

The status-prefixed 75-row manifest in §24 is the exact set: first 64 rows are modified tracked paths and final 11 rows are untracked paths. No path was added, deleted, staged, or removed from that set.

### 28. Native-Linux gate posture

Native Linux execution was deliberately not performed. Both architecture gates remain mandatory and pending; Darwin tests and cross-compilation were not substituted for runtime syscall evidence.

### 29. Stage/commit posture

No staging, commit, push, merge, rebase, reset, restore, clean, stash, checkout, switch, or new worktree operation occurred. The preexisting ahead-by-one state remains unchanged.

### 30. Explicit confirmations

```text
ES_REPOSITORY_ROOT_AUTHENTICATED
CURRENT_WORKTREE_CANDIDATE_PRESERVED
PREEXISTING_MODIFICATIONS_PRESERVED
PREEXISTING_UNTRACKED_SOURCE_PRESERVED
CURRENT_AGENTS_MD_READ
CURRENT_PLANS_MD_READ
M1_MACOS_TEMP_ROOT_DEFECT_REPRODUCED
M1_TEST_OWNED_PHYSICAL_ROOT_IMPLEMENTED
PRODUCTION_NOFOLLOW_POLICY_UNCHANGED
CUSTODY_SENSITIVE_TEMP_ROOT_CALLS_EXACTLY_INVENTORIED
INTENTIONAL_SYMLINK_NEGATIVE_TESTS_PRESERVED
M2_GO_TEXT_ORACLE_DEFECT_REPRODUCED
GO_SEMANTIC_GUARDRAILS_USE_AST_TYPES_OR_BEHAVIOR
COMMENTS_AND_DEAD_STRINGS_DO_NOT_SATISFY_GO_SEMANTIC_INVENTORIES
HIDDEN_GO_SEMANTIC_ALTERNATIVES_ARE_DETECTED
M3_SHELL_LAYOUT_ORACLE_DEFECT_REPRODUCED
SHELL_SEMANTIC_GUARDRAILS_ARE_STRUCTURE_INSENSITIVE_OR_BEHAVIORAL
COMMENTS_AND_INERT_STRINGS_DO_NOT_SATISFY_SHELL_INVENTORIES
RETIRED_ROUTE_PRIVACY_ORDER_BEHAVIOR_PRESERVED
FIXED_PUBLIC_REFUSAL_TEXT_PRESERVED
NO_PRODUCTION_SOURCE_CHANGED
NO_DOCUMENTATION_CHANGED
NO_SCRIPT_CHANGED
NO_AUTHORITY_WIDENING
NO_SECURITY_BOUNDARY_WIDENING
NO_PLATFORM_SCOPE_WIDENING
NO_EXTERNAL_SCHEMA_PACKAGE_INTEGRATION
TASK_CHANGED_GO_TESTS_FORMATTED
ALL_CURRENT_GO_CANDIDATE_PATHS_FORMATTED
GIT_DIFF_CHECK_PASSED
BASH_SYNTAX_CHECK_PASSED
FOCUSED_TESTS_PASSED
DEFAULT_HOST_ADMISSION_TESTS_PASSED
DEFAULT_HOST_FULL_SUITE_PASSED
PHYSICAL_ROOT_ADMISSION_TESTS_PASSED
PHYSICAL_ROOT_APP_TESTS_PASSED
PHYSICAL_ROOT_ROOT_TESTS_PASSED
PHYSICAL_ROOT_FULL_SUITE_PASSED
RACE_SUITE_PASSED
LINUX_AMD64_CROSS_COMPILE_PASSED
LINUX_ARM64_CROSS_COMPILE_PASSED
CROSS_COMPILE_NOT_REPORTED_AS_NATIVE_RUNTIME
NATIVE_LINUX_VALIDATION_HANDOFF_COMPLETE
NATIVE_LINUX_AMD64_RUNTIME_PENDING
NATIVE_LINUX_ARM64_RUNTIME_PENDING
REPOSITORY_MUTATION_BOUNDED_TO_AUTHORIZED_TEST_FILES
NO_NEW_REPOSITORY_FILE
NO_STAGING
NO_COMMIT
NO_PUSH
CLOSING_BRANCH_HEAD_AND_TREE_MATCHED
CLOSING_WORKTREE_SET_MATCHED
PROTECTED_PATH_SET_PRESERVED
NO_TASK_REPOSITORY_ARTIFACT_RETAINED
NO_DEPENDENCY_INSTALLATION
NO_NETWORK_CONTACT
NO_SUBAGENTS_CREATED
```
