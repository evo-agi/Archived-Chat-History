Here is Codex's response:

### 1. Primary verdict

`SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_CLEAN_AUDIT_HARNESS_INTERFACE_REPAIR_BLOCKED`

Actual source Attempt 2 failed the independent-interface validation gate. The two-attempt budget is exhausted.

### 2. Fresh process-clean repair-root identity

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b`

- Device/inode: `16777234 / 181400197`
- Mode: `0700`
- Allocated privately with the required prefix and umask `077`
- Harness authority: false
- Source freeze: false
- Terminal seal: false

### 3. Blocked clean-harness identity and closure

Historical root:

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-source-external-independent-audit-harness-5cmvznq8`

- Device/inode/mode: `16777234 / 181151302 / 0700`
- Entries: `423`
- Opening/closing projection: `a3659edc8aff7ff3980a662be072b15ac67b1c44ba3ccb44a4b03f792a9a5ee0`
- Failure closeout: inode `181185194`, size `6142`, SHA-256 `73d52a8857ccc850f3e8c652bb6daf94e8c28a7f6dba9f27471aeebc8376d7a8`
- Historical, immutable, noncurrent, nonauthoritative, and not resumed or cleaned.

### 4. Prior Git-disqualified root identity and disposition

Historical root:

`/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-4xuh1lon`

- Device/inode/mode: `16777234 / 181212642 / 0700`
- Entries: `71`
- Opening/closing projection: `c4b414046df830dcf1eee1ecf8adff3dca388776c925da2f909f20c3ec3aabf7`
- Failure closeout: inode `181221630`, size `3147`, SHA-256 `ad7b9085796e7e29c0c4b42f356c6be566f75d77a76a6022527dff903be5da37`
- Classified as a historical process-policy violation before any source attempt.
- It was not resumed, mutated, copied, imported, or used as a source origin.

### 5. Confirmation prior repair consumed zero source attempts

Authenticated source-attempt ledger:

- Source attempts consumed: `0`
- Source registries closed: no
- Compilation begun: no
- Candidate children created: no
- Full two-attempt budget available when this retry began: yes

### 6. Task process-execution policy

[Policy artifact](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/contract/task-process-execution-policy-v1.json):

- Inode/mode/size: `181400203 / 0600 / 1159`
- SHA-256: `5285e0f3b9e97fac4e60cd13fc7b52e2f5bf72b99e007308192ed9c74b616e0b`
- Exact pinned Python, explicit environment, no shell, no PATH lookup
- Prelaunch and outcome custody required
- Forbidden-executable denial tested before spawn

### 7. Confirmation no Git/VCS executable or library was used

No Git or other VCS operation occurred in this retry:

- No Git executable or subcommand
- No VCS library
- No `.git` metadata access
- No repository discovery or VCS diagnostic
- No shell-mediated VCS action
- No network contact

The process-ledger correction establishes that the sole non-Python argv was an intentionally denied pre-spawn policy causal; it was never launched.

### 8. Exact Attempt-3 source authority

The source base was the exact 21-file Attempt-3 set:

- Production registry: inode `181183049`, size `3275`, SHA-256 `99577b16994ebc42ace893610863c1ffa7c38d54b831d32bb37153d3617fc30d`
- Qualification registry: inode `181183050`, size `1825`, SHA-256 `207ea576fa5e3aec1cdf3e5e0314bca34d3da00e39608df1592cc94e5e339232`
- Independent registry: inode `181183051`, size `1074`, SHA-256 `e76bd6eb21ea47bd4a6d6884faae1c523e9ddb1e51fac3dfcb441b01bd6e9cb3`
- Production/qualification/independent counts: `12 / 6 / 3`
- Source-set SHA-256: `d5a03fbefd9717724bc426d300303a090418d1452479d7f511af4a5db1f59fbd`

No Attempt-1, Attempt-2, incremental-lineage, or prior partial-staged source supplied final bytes.

### 9. Governing-root identities and closing equality

All roots had device `16777234`, mode `0700`, and exact opening/closing equality:

| Root | Inode | Entries | Projection |
|---|---:|---:|---|
| Blocked clean harness | `181151302` | 423 | `a3659edc…a9a5ee0` |
| Prior disqualified repair | `181212642` | 71 | `c4b41404…c3aabf7` |
| Final reconciliation | `181119472` | 56 | `36859bd0…1a681b2` |
| Implementation | `180884963` | 112 | `0fb62bb9…bede8b3` |
| Generation-2 successor | `180871216` | 91 | `2647cef7…f5b8f7e` |
| Contract | `180472094` | 77 | `ae7c9cd2…a101a1` |
| Schema source | `180513083` | 67 | `ca28343f…26006d` |
| Schema reconciliation | `180480821` | 37 | `3a90e818…f2ee47` |
| Validation specification | `180576497` | 85 | `7bffc22e…fd4d79` |
| Attempt-2 failed root | `180892391` | 20 | `72531759…a5f1e` |

The normative contract remained size `32038`, SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`.

### 10. Cleanup blocker reproduction

The blocker reproduced before source copying:

- `run_two_rehearsals` returned a field named `cleanup_rows`.
- In the historical provider object, that field held the two A/B root strings; structured `{root,double_enoent,pass}` evidence was retained separately.
- `qualification_parent.combine_cleanup` accessed `group["cleanup_roots"]`.
- The exact exception was `KeyError("cleanup_roots")`.
- Rehearsals A and B and normalized comparison had already passed.
- Classification: `CLEAN_HARNESS_CROSS_MODULE_CLEANUP_INTERFACE_DEFECT`.

### 11. Cleanup-result authority adjudication

[Authority adjudication](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/analysis/cleanup-result-authority-adjudication-v2.json):

- Inode `181401377`
- Size `1644`
- SHA-256 `02b39ce59e9374113b783907f8146f8b2a3a20598bfa070bb0d42f0747c656c1`
- Cleanup authority was unambiguous and crosswalked against custody, evidence retention, set equality, providers, consumers, fixtures, and independent validation.

### 12. Canonical cleanup-result schema

Schema: `clean-harness-cleanup-result.v2`.

Exact result fields:

`schema`, `created_roots`, `inventoried_roots`, `evidence_retained_roots`, `cleanup_rows`, `twice_absent_roots`, `process_survivor_count`, `descriptor_survivor_count`, `cache_or_bytecode_survivor_count`, `set_equality`, `pass`, `first_blocker`.

Each cleanup row is exactly:

`root`, `double_enoent`, `pass`.

Success requires absolute roots, exact set equality, zero survivor counts, `double_enoent=[true,true]`, and a null blocker.

### 13. Confirmation no conflicting cleanup alias exists

The canonical contract permits no `cleanup_roots` alias, fallback, recursive discovery, missing-as-empty behavior, or generic truthiness. The 57-case matrix verified those prohibitions.

### 14. Complete derived interface set

The complete derived set was:

```text
I01  model.AuditError -> production typed failure paths
I02  json_total.strict_file -> audit_engine.bounded_compatibility_replay
I03  json_total.require_present -> adapters typed adapters
I04  io_nofollow.stable_bytes -> audit_engine manifest/source authentication
I05  io_nofollow.inventory -> capsule.terminal_close
I06  io_nofollow.remove_exact_root -> rehearsal_driver.run_two_rehearsals
I07  adapters.adapt_attempt_status -> audit_engine.bounded_compatibility_replay
I08  adapters.validate_freeze_binding -> audit_engine.bounded_compatibility_replay
I09  adapters.join_roles_to_sources -> audit_engine.bounded_compatibility_replay
I10  static_path.analyze_g01_reachability -> audit_engine.bounded_compatibility_replay
I11  adapters.adjudicate_confirmations -> subject.validate_constructed_subject
I12  adapters.adapt_lane -> audit_engine.bounded_compatibility_replay
I13  adapters.adjudicate_field_map -> audit_engine.bounded_compatibility_replay
I14  subject.validate_constructed_subject -> entrypoint.run_synthetic_rehearsal
I15  normalize.compare_normalized_rows -> rehearsal_driver.run_two_rehearsals
I16  causal.project_causal_report -> audit_engine.audit_synthetic_package
I17  process_custody.ChildRecorder.run -> qualification-parent process callers
I18  audit_engine.bounded_compatibility_replay -> qualification_parent.main
I19  audit_engine.audit_synthetic_package -> qualification_parent synthetic fixtures
I20  case_factory.build_cases -> direct_suite.run_direct_suite
I21  direct_suite.run_direct_suite -> static_gate.run_static_gates
I22  static_gate.run_static_gates -> qualification_parent.main
I23  synthetic_fixture.allocate_rehearsal -> rehearsal_driver.run_two_rehearsals
I24  rehearsal_driver.run_two_rehearsals -> qualification_parent.main
I25  entrypoint.run_synthetic_rehearsal -> rehearsal_driver.run_two_rehearsals
I26  capsule.terminal_close -> entrypoint.run_synthetic_rehearsal
I27  component_validator.main -> qualification_parent.run_independent
I28  rehearsal_validator.main -> rehearsal_driver.run_two_rehearsals
I29  package_validator.main -> qualification_parent.run_independent
I30  qualification_parent.main -> capsule.terminal_close
I31  model cleanup constructors/validator/combiner -> qualification cleanup callers
```

### 15. Complete registered interface set

Registered set: exactly `I01–I31`.

[Registry](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/contract/clean-harness-cross-module-interface-registry-attempt-2-v3.json):

- Inode `181411723`
- Size `41840`
- SHA-256 `04c1d9c7b33c70b42f41b8c6925ef085ea702ffbaa37b935db8163e9191cbb43`

### 16. Directly tested interface set

Direct set: exactly `I01–I31`. All 31 were exercised by the 372-case direct interface matrix.

### 17. Independently tested interface set

Independent coverage set: exactly `I01–I31`. The independent validator inspected every row; coverage was complete, but `I08` failed its shape-policy predicate.

### 18. Interface-set equality

Derived, registered, direct-test, and independent-test ID sets were equal:

- Interface count: `31`
- Unknown interfaces: `0`
- Dynamic unresolved acceptance edges: `0`
- Untested interface IDs: none

Set equality did not override the later semantic failure on `I08`.

### 19. Repair authority and touched source surface

The bounded repair changed seven of 21 source files:

- `source/production/model.py`
- `source/production/process_custody.py`
- `source/qualification/direct_suite.py`
- `source/qualification/static_gate.py`
- `source/qualification/rehearsal_driver.py`
- `source/qualification/qualification_parent.py`
- `source/independent/component_validator.py`

The work remained limited to cleanup-result closure, cross-module interface qualification, process custody, and the Attempt-1 stage-vocabulary correction. No implementation-package source changed.

### 20. Source-attempt ledger

- Two tooling-only preflight stops occurred before compilation and consumed no source attempt.
- Attempt 1 compiled source set `3631506d7926bdad883b7c66841536271d393ea290fafd6cf1de993bf443a969`; it failed because the parent emitted an unsupported package-validator stage.
- Attempt 2 compiled source set `0b25e78496abdfb18ae9a09cb8d34453ae1fa7e13987cb7f7483685537f433ad`; it failed at the independent interface validator.
- Attempts consumed/limit: `2 / 2`
- Attempts remaining: `0`

[Final attempt ledger](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/source-attempt-ledger-v2.json): inode `181415014`, size `695`, SHA-256 `89bc657e7a6ddfc120bcb05fa032e35a608d171ea6046f3ace60af5aa4de1445`.

### 21. Final production-source registry

Attempt-2 closed production registry:

- Inode/mode/size: `181411725 / 0600 / 5998`
- SHA-256: `1b6861d9107debe981551160d143060169dc9f6fc87916797e4212a181cc07c0`
- Sources: `12`

It closed before compilation but never became part of a formal source freeze.

### 22. Final qualification-source registry

Attempt-2 closed qualification registry:

- Inode/mode/size: `181411726 / 0600 / 3357`
- SHA-256: `86c6248187b3ef5ef8b47cd49bb4b5086a21f3a8c07f4328d80bedaca014400d`
- Sources: `6`

### 23. Final independent-source registry

Attempt-2 closed independent registry:

- Inode/mode/size: `181411727 / 0600 / 1892`
- SHA-256: `43c3b04f3589a919ca3ad6edb2cde79692d4a77a8b5786c3f107726605bde20b`
- Sources: `3`

All 21 source identities still matched these registries after failure.

### 24. Exact source delta

[Exact delta](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/analysis/exact-source-delta-attempt-2-v2.json):

- Inode `181411720`
- Size `111859`
- SHA-256 `02b39c51504e17d3e5b4fb016279e539aadceb6fa1567de1e006d16cf1c2abb6`
- Predecessor source set: `d5a03f…f59fbd`
- Candidate source set: `0b25e7…f433ad`
- Changed sources: seven
- Unchanged sources: fourteen

### 25. Protected-function equality

- Protected functions/classes: `132`
- AST mismatches: `0`
- Exact AST equality: true

Artifact: inode `181411721`, size `154`, SHA-256 `dde0bc937280b876c5ca35b56eb9557583fa2aa4f9e9dc2d51f486454d65adf1`.

### 26. Precompilation interface conformance

Attempt 2 passed all 19 precompilation checks:

- 21 AST parses
- 34 architecture roles
- 31 interfaces
- Exact set equality
- Provider/consumer and serialized-record analysis
- No cleanup alias or fallback dependency
- No unresolved acceptance edge
- No VCS import or `.git` access
- Protected AST equality

Artifact SHA-256: `ed05ca82838e42a10a22b3dd55dea136c97acd02bb4c85220c212da67add9ad3`.

### 27. Cleanup-result matrix

- Cases: `57`
- False acceptances/rejections: `0 / 0`
- Reason mismatches: `0`
- Skips: `0`
- Unexpected exceptions: `0`
- Result: passed

Artifact SHA-256: `157cc335a800bae5d0eb16b0f00f2770354fec460bf1adb89c7be19fb7807119`.

### 28. Cross-module interface matrix

- Interfaces: `31`
- Cases per interface: `12`
- Total cases: `372`
- False acceptances/rejections: `0 / 0`
- Skips or unexpected exceptions: `0`
- Direct matrix result: passed

The later independent `I08` policy failure remains controlling.

### 29. D01–D10 regression

All `390` cases passed:

- D01 `30`
- D02 `25`
- D03 `30`
- D04 `30`
- D05 `35`
- D06 `100`
- D07 `30`
- D08 `40`
- D09 `40`
- D10 `30`

All false-acceptance, false-rejection, reason-mismatch, skip, and unexpected-exception counts were zero.

### 30. Process-custody regression

- Cases: `17`
- Result: passed
- Process records retained: `35`
- Qualification records: `34`
- Actual qualification children launched: `33`
- Pre-spawn policy denials: `1`
- Pre-source reproduction child: `1`
- All launched children reaped; all descriptors closed; no survivors.

The original closeout aggregate incorrectly counted the denied-before-spawn causal as a launched executable. [The immutable adjudication](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/process-ledger-adjudication-v2.json) corrects the effective policy result to passed.

### 31. Synthetic accepted-package regression

Passed. The accepted synthetic package produced no package or audit finding and the expected accepted causal result.

### 32. Synthetic BLOCK-package regression

Passed. The synthetic direct package defect remained a package-primary finding and produced the expected blocked causal result.

### 33. Synthetic provenance-failure regression

Passed. Provenance failure remained separate from package adjudication and emitted no inferred causal report.

### 34. Synthetic subject-pair regression

Passed. The constructed-subject confirmation and manifest relationships remained exact for the paired synthetic subjects.

### 35. Bounded compatibility replay

- Checks: `17`
- Result: passed
- Package verdict emitted: none

No package acceptance or verdict rule was changed.

### 36. Cleanup integration causals

- Causals: `10`
- Result: passed
- Canonical provider, consumer, and combined cleanup results agreed.
- Evidence-before-cleanup and exact cleanup-set equality were retained.

### 37. Rehearsal A

Complete rehearsal A passed against source set `0b25e7…f433ad`, including its independent validator and synthetic capsule closure. Its owned root was removed only after evidence retention and then observed absent twice.

### 38. Rehearsal B

Complete rehearsal B passed against the same source bytes. Its retained root identity before cleanup included device `16777234`, inode `181412553`, mode `0700`; it too was removed and observed absent twice.

### 39. Normalized rehearsal comparison

- Left semantic SHA-256: `1614816126afadc1744b5c5f62dd26a3aeae371f859b621058249861b4d3bd63`
- Right semantic SHA-256: identical
- Unexplained differences: `0`
- Result: passed

### 40. Independent interface validator

This was the controlling failure:

- Checks passed: `15 / 16`
- Interface rows passed: `30 / 31`
- Sole failed interface: `I08`
- Provider and consumer candidates: present
- Call sites: valid
- Registry alias: `absolute/relative path rendering only`
- Validator predicate: required every row’s alias to equal `forbidden`
- Failed check: `interface-source-shapes`
- Exit code: `1`
- Parent exception: `RuntimeError("independent-validator-process:independent-interface-validator-initial")`

[Failure evidence](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/independent-interface-validator-failure-v1.json): inode `181415009`, size `2909`, SHA-256 `9173e28a2e2c08e1318c47fff8811161922d261ed3e6b82a2c16eb3101a1e56c`.

### 41. Compilation and static qualification

- All 21 sources compiled under pinned Python `-I -S -B`.
- Compilation passed with empty stderr.
- Static AST/call/dataflow/bytecode/CFG/effect gates passed.
- Process-policy and forbidden-library gates passed.
- Initial component and package validators passed on Attempt 2.
- Independent interface validation subsequently failed as described above.

### 42. Source freeze

Formal source freeze was not established because the independent validator did not pass.

The Attempt-2 registries were closed, and all 21 source identities remained exact after failure, but registry closure is not being misrepresented as the required post-validation source freeze.

### 43. Frozen-source requalification

Not run. It was correctly gated behind source freeze.

### 44. Confirmation implementation production source was not executed

Confirmed. The sealed implementation package remained read-only, unmodified, and unexecuted.

### 45. Confirmation full independent audit was not executed

Confirmed. No full target audit or authoritative current-subject construction occurred.

### 46. Harness-package status

- Status: blocked after final source attempt
- Harness qualification: failed at independent interface validation
- Harness authority: false
- Source frozen: false
- Terminal seal: false
- Same-root retry: false
- Implementation adjudicated: false

### 47. Supplied-root closing equality

All ten opened supplied roots closed exactly equal. The retained equality artifact is inode `181415011`, size `4537`, SHA-256 `d8cf1dad3d4c5f18114db1d6873c3357c4a5dd3d69f437c3181183005640e3fa`.

No supplied root was modified or cleaned.

### 48. Evidence retention and fixture cleanup

- Cleanup roots observed absent twice: `11`
- Process survivors: `0`
- Descriptor survivors: `0`
- Cache/bytecode survivors: `0`
- Evidence retained before removal: yes
- Cleanup-set equality: passed

[Cleanup evidence](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/fixture-cleanup-v1.json): inode `181415010`, size `1358`, SHA-256 `8bf9c5c499d13faf70622cf34cb72e0f1c982d3136257c7d7d472fa4877e7a03`.

### 49. Failure-closeout capability and use

Failure closeout was used:

- Complete partial inventory: inode `181415008`, size `97536`, SHA-256 `2f129b7f235b718fb493134e32f72b0af59d0cca1b28a98b1392c47292059300`
- Process ledger: inode `181415012`, size `74583`, SHA-256 `5f1031606edd5e7ff208dcf1c6eeea49f5f0ddfd06f9b321fa83894e0d9454e0`
- Attempt-2 closure: inode `181415013`, size `11672`, SHA-256 `c641d317a409466e5928aaedce6fe708fec164986446abc9ca35af1176890a42`
- [Failure closeout](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/failure-closeout-v1.json): inode `181415015`, size `14843`, SHA-256 `704ea0c472a0f926c37777048f5383a8957b7c46e1eec1d44edebae85f1322e3`
- [Closeout adjudication](/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-audit-harness-interface-repair-clean-shv_7p0b/failure/failure-closeout-adjudication-v2.json): inode `181415954`, size `989`, SHA-256 `641a1717541357f1901be59ab4b829e2864975e8ab328c5f6a5eb5b8cb592b48`

No success manifests were created.

### 50. Temporal-inventory identity

No successor-package temporal inventory was created. The run stopped before source freeze and terminal closure.

### 51. Manifest A identity

No successor-package Manifest A was created.

### 52. Manifest B identity

No successor-package Manifest B was created.

### 53. Independent terminal reprojection

Not reached. The sealed synthetic rehearsal capsules do not constitute successor-package terminal closure.

### 54. Terminal membership and modes

Not reached. No claim is made about successful terminal membership, root-row closure, empty-descendant closure, or terminal topology.

### 55. No-write-after-closure

No successor terminal seal occurred, so this success-only confirmation is not established. There was therefore no post-seal operation to assess.

### 56. Candidate terminality disposition

- `repair_candidate_retired=true`
- `further_localized_repair_authorized=false`
- `new_clean_implementation_generation_required=true`
- Attempts remaining: `0`
- Same-root retry: prohibited

The next work must be a new clean implementation generation, not a third localized repair and not a fresh target audit.

### 57. Remaining uncertainty and nonclaims

No claim is made that the implementation is accepted or rejected. No harness authority was established.

Two additional report-contract inconsistencies remain for the new generation to resolve:

- Registry `I30` describes a “59-section” terminal report, while this task requires 58 sections.
- The candidate confirmation file contains 96 entries because it appends a success-verdict token to the 95 requested confirmation names. That extra token is not reproduced here, preserving the exactly-one-primary-verdict rule.

Neither issue displaces `I08` as the first observed Attempt-2 blocker.

### 58. Explicit confirmation registry

The 95 confirmation names explicitly requested by the task resolve as follows:

```text
PASS — BLOCKED_CLEAN_HARNESS_ROOT_MUTATION_NOT_PERFORMED
PASS — BLOCKED_CLEAN_HARNESS_ROOT_NOT_RESUMED
PASS — PRIOR_GIT_DISQUALIFIED_ROOT_MUTATION_NOT_PERFORMED
PASS — PRIOR_GIT_DISQUALIFIED_ROOT_NOT_RESUMED
PASS — PRIOR_GIT_DISQUALIFIED_REPAIR_CONSUMED_ZERO_SOURCE_ATTEMPTS
PASS — FULL_TWO_ATTEMPT_REPAIR_BUDGET_PRESERVED
PASS — NO_GIT_EXECUTABLE_INVOKED
PASS — NO_GIT_LIBRARY_USED
PASS — NO_DOT_GIT_PATH_ACCESSED
PASS — NO_VCS_DIAGNOSTIC_EXECUTED
PASS — TASK_PROCESS_EXECUTION_POLICY_FROZEN
PASS — ALL_EXTERNAL_CHILDREN_ROUTED_THROUGH_RECORDER
PASS — EXACT_ATTEMPT_3_SOURCE_AUTHORITY_ESTABLISHED
PASS — ATTEMPT_1_SOURCE_NOT_USED
PASS — ATTEMPT_2_SOURCE_NOT_USED
PASS — PARTIAL_STAGED_SOURCE_NOT_USED_AS_REPAIR_BASE
PASS — FINAL_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
PASS — IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
PASS — IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
PASS — SUCCESSOR_GEN2_ROOT_MUTATION_NOT_PERFORMED
PASS — AUTHORITATIVE_CONTRACT_ROOT_MUTATION_NOT_PERFORMED
PASS — SCHEMA_SOURCE_ROOT_MUTATION_NOT_PERFORMED
PASS — SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
PASS — VALIDATION_SPEC_ROOT_MUTATION_NOT_PERFORMED
PASS — ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
PASS — CLEANUP_INTERFACE_MISMATCH_REPRODUCED
PASS — CLEANUP_RESULT_AUTHORITY_ADJUDICATED
PASS — CANONICAL_CLEANUP_RESULT_SCHEMA_FROZEN
PASS — NO_CONFLICTING_CLEANUP_ALIAS
PASS — NO_CLEANUP_FIELD_FALLBACK
PASS — EQUAL_EMPTY_CLEANUP_SETS_ACCEPTED
PASS — CLEANUP_INTEGER_ZERO_COUNTS_ACCEPTED
PASS — CLEANUP_SET_EQUALITY_ENFORCED
PASS — COMPLETE_CROSS_MODULE_INTERFACE_SET_DERIVED
PASS — COMPLETE_CROSS_MODULE_INTERFACE_REGISTRY_PRODUCED
PASS — DERIVED_REGISTERED_INTERFACE_SET_EQUAL
PASS — EVERY_REGISTERED_INTERFACE_DIRECTLY_TESTED
PASS — EVERY_REGISTERED_INTERFACE_INDEPENDENTLY_TESTED
PASS — NO_UNREGISTERED_ACCEPTANCE_BEARING_INTERFACE
PASS — REPAIR_BOUNDED_TO_CLEANUP_AND_INTERFACE_CLOSURE
PASS — PACKAGE_ACCEPTANCE_RULES_UNCHANGED
PASS — PACKAGE_VERDICT_RULES_UNCHANGED
PASS — UNRELATED_FUNCTIONS_AST_IDENTICAL
PASS — SOURCE_ATTEMPT_LIMIT_RESPECTED
PASS — PRECOMPILATION_INTERFACE_CONFORMANCE_PASSED
PASS — CLEANUP_RESULT_MATRIX_PASSED
PASS — CROSS_MODULE_INTERFACE_MATRIX_PASSED
PASS — D01_D10_REGRESSION_PASSED
PASS — PROCESS_CUSTODY_REGRESSION_PASSED
PASS — SYNTHETIC_ACCEPTED_PACKAGE_REGRESSION_PASSED
PASS — SYNTHETIC_BLOCK_PACKAGE_REGRESSION_PASSED
PASS — SYNTHETIC_PROVENANCE_FAILURE_REGRESSION_PASSED
PASS — SYNTHETIC_SUBJECT_PAIR_REGRESSION_PASSED
PASS — BOUNDED_COMPATIBILITY_REPLAY_PASSED
PASS — BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
PASS — CLEANUP_INTEGRATION_CAUSALS_PASSED
PASS — COMPLETE_REHEARSAL_A_PASSED
PASS — COMPLETE_REHEARSAL_B_PASSED
PASS — TWO_REHEARSALS_NORMALIZED_EQUAL
FAIL — INDEPENDENT_INTERFACE_VALIDATOR_PASSED
PASS — ALL_SOURCES_COMPILED
PASS — STATIC_SOURCE_GATES_PASSED
NOT_REACHED — FINAL_SOURCE_REGISTRIES_FROZEN
NOT_REACHED — FINAL_SOURCES_NOT_MODIFIED_AFTER_FREEZE
NOT_REACHED — FROZEN_SOURCE_REQUALIFICATION_PASSED
PASS — IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
PASS — FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
PASS — SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
PASS — EVIDENCE_RETAINED_BEFORE_CLEANUP
PASS — AUDIT_OWNED_CLEANUP_SET_EQUALITY_PASSED
PASS — ALL_CREATED_CHILDREN_REAPED
PASS — ALL_CHILD_DESCRIPTORS_CLOSED
PASS — NO_PROCESS_SURVIVOR
PASS — NO_DESCRIPTOR_SURVIVOR
PASS — NO_CACHE_OR_BYTECODE_RETAINED
NOT_REACHED — SUCCESSOR_TEMPORAL_INVENTORY_CREATED
NOT_REACHED — SUCCESSOR_TEMPORAL_INVENTORY_VERIFIED
NOT_REACHED — SUCCESSOR_MANIFEST_A_CREATED
NOT_REACHED — SUCCESSOR_MANIFEST_B_CREATED
NOT_REACHED — SUCCESSOR_MANIFESTS_BYTE_IDENTICAL
NOT_REACHED — SUCCESSOR_TERMINAL_REPROJECTION_PASSED
NOT_REACHED — SUCCESSOR_ROOT_ROW_PRESENT_EXACTLY_ONCE
NOT_REACHED — NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NOT_REACHED — NO_SYMLINK_OR_SPECIAL_OBJECT
NOT_REACHED — NO_MULTIPLY_LINKED_FILE
NOT_REACHED — ALL_DIRECTORY_MODES_0700
NOT_REACHED — ALL_FILE_MODES_0600
NOT_REACHED — NO_WRITE_AFTER_TERMINAL_CLOSURE
PASS — NO_NETWORK_CONTACT
PASS — NO_GIT_INVOCATION
PASS — NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
PASS — NO_TARGET_AUDIT_EXECUTED
PASS — NO_RUNTIME_VALIDATION_RERUN
PASS — NO_A6_ACTIVITY
PASS — NO_SUBAGENTS_CREATED
```
