Here is Codex's response:

# Repair 10I-A6 reconnaissance

`REPAIR10I_A6_RECONNAISSANCE_BLOCKED`

The sealed material is insufficient to freeze a safe A6 policy:

- No exact full-suite semantic envelope exists for A5 source `e260e1bb…`; A5 retained only focused and external-TLS partial streams, and B5 launched no controls.
- The last exact full-suite final is pre-A5 source `4dd211207800…`. It contains transitions that the provisional policy would block: HEAD has four final-only test failures, five final-only test skips, one final-only package failure, and one new warning; Repair 9 has three final-only test skips and one pass→fail regression.
- Therefore neither requested HEAD→A5 nor Repair-9→A5 matrix—or A5’s complete hazard set—can be reconstructed without inference.

## 1. Opening and closing identities

Opening and closing were identical:

| FieldOpening and closing        |                                                                    |
| ------------------------------- | ------------------------------------------------------------------ |
| Branch                          | `codex/remote-alpha-external-tls-status-observation-v1`            |
| HEAD                            | `567bceced5df95ecfe787cc66038d463a854e12c`                         |
| Sole parent                     | `05dde14d185b6e022dcc169ef1a658a97961850f`                         |
| HEAD tree                       | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                         |
| Upstream                        | absent                                                             |
| Index SHA-256                   | `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31` |
| Repository T                    | `e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c`                         |
| Inventory SHA-256               | `9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b` |
| Membership                      | `389 / 375 / 14`                                                   |
| Tracked modified                | `22`                                                               |
| Staged/deleted/renamed/unmerged | `0 / 0 / 0 / 0`                                                    |

Sealed lineage reverified payload-by-payload:

| ChildManifest SHA-256PayloadsDirectories |                                                                    |       |       |
| ---------------------------------------- | ------------------------------------------------------------------ | ----- | ----- |
| A                                        | `dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7` | 334   | 69    |
| A2                                       | `f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7` | 210   | 55    |
| A3                                       | `a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b` | 292   | 78    |
| A4                                       | `772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf` | 540   | 175   |
| A5                                       | `29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc` | 341   | 84    |
| Phase H                                  | `fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb` | 6,191 | 1,102 |

A4 source remained exact: T `fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac`, inventory `7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06`, 12 members.

Unsealed lineage fingerprints also remained exact:

| ChildSnapshot SHA-256Entries/files/directories |                                                                    |             |
| ---------------------------------------------- | ------------------------------------------------------------------ | ----------- |
| B                                              | `281840cd018212e2b58caaf7d6bcda67e5ef8ae3d8ad4a989ffbe1efdb35cb50` | 199/155/44  |
| B2                                             | `32877e54f504bbf8fd4d3c8677b63ec2e70586fa2152a25ff3b529e6ca4117b5` | 227/183/44  |
| B3                                             | `876c55a7cda894f794f268e1080dbcba0f5ebf7d7a7e1565212693cbe607cc04` | 475/383/92  |
| B4                                             | `017e41afda824d7e0288c23a3445e49d26eae045c9b15c9beb35be0694cd38ca` | 425/341/84  |
| B4 divergence reconciliation                   | `7270187fc188174ddeb38807db181f665a0bdb1c384aa5b79edb1dbee96dadb0` | 655/519/136 |
| B5                                             | `c520a08ddce7d6e04f795792fd23b7fe5460b477b3fbbc9470545f94c9e8c3bf` | 36/23/13    |

B5 remains unsealed. A6 remains absent.

## 2. Exact current A4 mechanism

The relevant source is:

- `semantic.go`: schemas [17 (line 17)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:17), lifecycle/diagnostic identity [49 (line 49)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:49), V1 spec [139 (line 139)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:139), V1 result [151 (line 151)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:151), strict loading [1125 (line 1125)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1125), binding [1165 (line 1165)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1165), qualified comparison [1271 (line 1271)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1271), historical dispatch [1356 (line 1356)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1356), predicate [1729 (line 1729)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1729), declaration [1783 (line 1783)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1783), exceptions [1787 (line 1787)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1787), terminal key [1813 (line 1813)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1813), exit mapping [1829 (line 1829)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/semantic.go:1829).
- Historical causal tests begin at [envelope\_test.go (line 2704)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/envelope_test.go:2704).
- CLI dispatch is fixed to V1 at [main.go (line 22)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/cmd/repair10-compare/main.go:22).
- The documented factual/acceptance distinction is at [FORMAT.md (line 468)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/FORMAT.md:468), with the active historical contract at [FORMAT.md (line 584)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/FORMAT.md:584).

`SemanticComparisonSpecV1` contains no declaration or transition-policy field. The strict decoder rejects unknown fields, and the only accepted policy names are `qualified-equal`, `exact-intentional-mutant-delta`, and `baseline-expected-difference`.

Package, test, and subtest terminals are flattened into the same key:

`package + NUL + test + NUL + occurrence`

A package uses an empty test string. A subtest has no separate type; its slash-containing Go test name is the `test` value.

`noFinalOnlyRegressionV1` currently:

- Blocks every baseline terminal disappearance.
- Allows a final-only terminal only when it passes and exactly matches the one compiled privacy-test identity.
- Rejects every changed terminal except the exact Repair-9 pass→fail pin exception.
- Therefore rejects fail→pass and skip→pass improvements too.
- Requires exact aggregate exit-code equality.
- Rejects new diagnostics only when their text contains `panic:`, `warning:`, `data race`, or `malformed`, except for one exact HEAD warning.
- Has no explicit fatal-runtime classification.
- Rejects unknown diagnostics and final intrinsic malformed/incomplete state.
- Rejects newly introduced `PackageFailureAborts`; that field is not itself part of `intrinsicSemanticFailures`.
- Has no separate package no-test policy.

There is one production caller, at `semantic.go:1357`. All other callers are direct tests at `envelope_test.go` lines 2716, 2719, 2725, 2737, 2741, 2745, 2748, 2751, 2754, 2757, 2761 (twice), 2764, 2767, and 2782.

The factual fields are `LifecycleEqual`, `DiagnosticsEqual`, `RawBytesEqual`, `CanonicalSemanticsEqual`, both qualification states, difference arrays, qualification references, unknown count, fingerprints, qualification recomputation, and physical disjointness. `AcceptedEqual`, `Outcome`, `ReasonCodes`, and the process exit encode the policy decision. Raw equality is reported but is not a historical-policy gate.

Exit behavior is:

- `0`: `qualified-equal` and `AcceptedEqual=true`.
- `2`: policy-satisfied `qualified-different`, both sides qualified, zero unknowns.
- `1`: every rejection, uncertainty, binding failure, or policy mismatch.

The compiled declaration cannot represent the retained history because it authorizes exactly one occurrence of one top-level privacy test. It cannot express hundreds of test/subtest identities, package additions, or A5’s 26 newly observed focused identities. Strict decoding prevents adding a declaration to the spec. Additionally, A4’s Repair-9 exception hard-codes source line 3287; after A5, the relevant `t.Fatal` is at [remote\_alpha\_prepare\_external\_tls\_status\_test.go (line 3618)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go:3618>).

## 3. Historical transition matrices

Exact HEAD→A5 and Repair-9→A5 matrices are unavailable.

The nearest exact records are:

- [HEAD semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800/validation/repair10i-historical-head-v1/03-full-suite-semantic-restoration/semantics.json): 1,252,005 bytes, SHA-256 `661d179e97a7449c76b32c0f5322dfabb7f53a8793734677d91e056c8e96c2c4`, source T `b7cab237…`, inventory `291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a`.
- [Repair-9 semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800/validation/repair10i-historical-repair9-v1/03-full-suite-semantic-restoration/semantics.json): 1,305,141 bytes, SHA-256 `93713c4ac02d16de6b227b84ae2339b121509bb30db4214543bc529f46378613`, source T `0ea3b661…`, inventory `7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e`.
- [Pre-A5 final semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800/validation/repair10i-pristine-final-v1/03-full-suite-semantic-restoration/semantics.json): 1,383,394 bytes, SHA-256 `5a427e8ddc57eb503dd015e408f880db108f00010d77cbdd1e1221edf7287c8f`, source T `4dd211207800…`, inventory `2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0`.

All three records are qualified and identity-bound. Recomputed nearest-predecessor matrices follow.

### HEAD→pre-A5 final: test/subtest terminals

| Baseline \ finalpassfailskipabsent |       |     |   |   |
| ---------------------------------- | ----- | --- | - | - |
| absent                             | 638   | 4   | 5 | — |
| pass                               | 1,582 | 0   | 0 | 0 |
| fail                               | 498   | 154 | 0 | 0 |
| skip                               | 0     | 0   | 3 | 0 |

### HEAD→pre-A5 final: package terminals

| Baseline \ finalpassfailskipabsent |    |    |    |   |
| ---------------------------------- | -- | -- | -- | - |
| absent                             | 1  | 1  | 1  | — |
| pass                               | 13 | 0  | 0  | 0 |
| fail                               | 0  | 10 | 0  | 0 |
| skip                               | 0  | 0  | 22 | 0 |

### Repair-9→pre-A5 final: test/subtest terminals

| Baseline \ finalpassfailskipabsent |       |     |   |   |
| ---------------------------------- | ----- | --- | - | - |
| absent                             | 194   | 0   | 3 | — |
| pass                               | 2,460 | 1   | 0 | 0 |
| fail                               | 64    | 157 | 0 | 0 |
| skip                               | 0     | 0   | 5 | 0 |

### Repair-9→pre-A5 final: package terminals

| Baseline \ finalpassfailskipabsent |    |    |    |   |
| ---------------------------------- | -- | -- | -- | - |
| absent                             | 1  | 0  | 0  | — |
| pass                               | 13 | 0  | 0  | 0 |
| fail                               | 0  | 11 | 0  | 0 |
| skip                               | 0  | 0  | 23 | 0 |

The HEAD final-only nonpasses are four fails and five skips. Repair 9 has three final-only skips and the pass→fail `TestRemoteAlphaT2APExactReachablePinsAndMutantsV3`.

## 4. Canonical final-only identity sets

Reconnaissance canonicalization was: sort by raw UTF-8 `(package,test,occurrence)`, encode a compact JSON array with lexicographically sorted keys and one final LF. Every identity includes `occurrence`, `package`, and `test`; a package uses `test:""`.

| Exact pre-A5 setCountTop/subBytesSHA-256     |     |         |        |                                                                    |
| -------------------------------------------- | --- | ------- | ------ | ------------------------------------------------------------------ |
| HEAD final-only passing tests                | 638 | 137/501 | 98,092 | `1b56e885f511d4f7ce8412def111828585943c582538214200e8f02e29510e92` |
| Repair-9 final-only passing tests            | 194 | 40/154  | 29,800 | `5ac20428341ac995498a80b1be5a6d176940ce76f6957b55bdadf490c4981f57` |
| Final-only passing package, either direction | 1   | —       | 82     | `d84ece8e64d6057ea473eb702aec2a0081030c99386840f0194b1ab895b250f8` |

Package distribution:

- HEAD: root 228; `remoteobserver` 10; `statuspackage` 387; `internal/testsupport` 13.
- Repair 9: root 67; `remoteobserver` 10; `statuspackage` 104; `internal/testsupport` 13.
- The sole final-only passing package is `execution-substrate/internal/testsupport`.

A5’s [focused semantics](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800/compatibility/focused-semantics-a.json) proves 26 A5-added identities passed in that focused stream: 3 top-level tests and 23 subtests, all in the root package. Canonical size is 3,307 bytes; SHA-256 `195cef21d421e81c441b0647049b258ca8e01ae6994cbbad59c384dde81d7856`.

Combining that focused set arithmetically with the pre-A5 sets would produce 664/220 identities and hashes `3de6c8d7…`/`3daef134…`, but those are not full-suite A5 observations and must not be used as A5 matrix values.

## 5. Package-terminal policy

The exact pre-A5 HEAD-only packages are:

- `internal/testsupport`: absent→pass.
- `statuspackage`: absent→fail, accompanied by a failing test.
- `cmd/es-external-tls-status-package`: absent→skip with the exact bound raw `[no test files]` event at [stdout.raw (line 7171)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800/validation/repair10i-pristine-final-v1/03-full-suite-semantic-restoration/stdout.raw:7171).

Every retained package skip—22 in HEAD and 23 in Repair 9/pre-A5 final—has a raw `[no test files]` marker; none is unmarked.

The durable candidate package relation is:

- absent→pass: admit and report.
- absent→skip: admit only with exact causal proof of a new package, one exact raw no-test event, zero test run/terminal identities, and clean diagnostics, aborts, reconciliation, custody, and qualification.
- absent→fail or abort: block.
- pass→pass: admit; pass→fail/skip/abort/absent: block.
- fail→fail: admit as inherited failure and report; fail→pass: admit as improvement; fail→skip/absent: block.
- skip→skip: admit only if the no-test classification remains exact; skip→pass: admit as improvement; skip→fail/absent: block.
- Generic package skip is never an exception.

A4 does not separately type “setup/build abort.” It records package fail terminals and `PackageFailureAborts`; the latter means active tests lost terminals after a failing package, not necessarily a setup/build failure. Any finer causal category would require a bound-raw classifier or a semantic-schema extension.

## 6. Hazard analysis

| DirectionPanic identitiesRaceWarningFatal runtimeIntrinsic malformed/incomplete/unknownPackage failure aborts |              |       |              |       |           |                       |
| ------------------------------------------------------------------------------------------------------------- | ------------ | ----- | ------------ | ----- | --------- | --------------------- |
| HEAD→pre-A5                                                                                                   | `5→5`, new 0 | `0→0` | `0→1`, new 1 | `0→0` | all `0→0` | `161→161`, new/lost 0 |
| Repair-9→pre-A5                                                                                               | `5→5`, new 0 | `0→0` | `1→1`, new 0 | `0→0` | all `0→0` | `161→161`, new/lost 0 |

No baseline hazardous identity disappeared or changed class. The HEAD-only warning is the exact vault-reset warning that A4 hard-codes as an exception. The provisional A6 rule would block it.

“Fatal runtime” was checked using exact case-folded `fatal error:` and `runtime: fatal` markers; A4 has no native fatal-runtime field or predicate.

A5 partial evidence cannot replace this matrix:

- Focused: 34 passing test terminals, one passing package, no diagnostics or intrinsic failures.
- External-TLS regression: 1,378 passing test terminals, five passing and three no-test packages, eight nonhazard diagnostics, no intrinsic failures or aborts.
- That regression was only `./es/externaltls/...` and explicitly skipped `TestProductionLifetimeLockFD9CLOEXECPreventsChildInheritanceV2`.
- No retained A5 command ran `go test ... ./...`.

## 7. Why identities are final-only

Source-grounding safely reaches this far:

- HEAD: all 146 unique top-level parents covering its 647 final-only test terminals were absent from HEAD source. The three new packages are likewise absent from its inventory.
- Repair 9: 13 passing `internal/testsupport` identities and its one skipped test are definitely source-absent. The 10 privacy-test identities are also source-absent because the relevant source file is byte-identical to HEAD, which lacks that test.
- The 26 A5-focused passing identities are source-absent from both historical sources. Their top-level declarations begin at [lines 900 (line 900)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go:900>), [941 (line 941)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go:941>), and [1018 (line 1018)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go:1018>).
- For Repair 9, the remaining 171 pre-A5 final-only passes and two statuspackage skips cannot be distinguished between source absence and “present but never started after package failure,” because the source materialization was cleaned and only inventory hashes remain.
- No final-only identity overlaps an explicit baseline `PackageFailureAborts` entry. Consequently, none can be positively classified as “started but lost its terminal.”
- Two final-only subtests have a parent terminal in Repair 9, but retained evidence cannot distinguish a newly added subtest from a conditionally unexecuted branch.

Phase H has an older source identity and cannot bridge this gap.

## 8. Models A/B/C and recommendation

| ModelAdjudication                  |                                                                                                                                                |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| A: finite allowlist                | Rejected. It is non-durable, name-coupled, fails for generated subtests/packages, and recreates A4’s current defect.                           |
| B: generated from a prior run      | Rejected. It makes the comparison self-authorizing and can bless flakes, missing coverage, or hazards from the generating run.                 |
| C: structural directional relation | Recommended design direction. It scales independently of identity count and keeps exact observed identities as evidence rather than authority. |

C cannot yet be frozen as a passing A6 contract. The last exact full-suite records supply direct counterexamples, and the exact A5 records needed to decide whether those counterexamples remain are absent.

The recommended test lattice remains:

- Admit: absent→pass, pass→pass, fail→fail/pass, skip→skip/pass.
- Block every other transition.
- Report inherited failures and all improvements exactly.
- Never let new passes mask any blocking transition or hazard.

Aggregate exit code should remain factual, not be required to stay equal: a clean fail→pass improvement may legitimately change baseline exit 1 to final exit 0.

## 9. Contingent v2 schema/result direction

This is the exact candidate direction, not a frozen contract:

- Spec schema: `execution-substrate.repair10i.semantic-comparison-spec.v2`
- Result schema: `execution-substrate.repair10i.semantic-comparison-result.v2`
- Historical policy: `historical-directional-no-regression-v2`
- No `declared_final_only_passes`.
- Historical direction is strictly left=`historical-head` or `historical-repair9`, right=`pristine-final`.
- V1 `baseline-expected-difference` remains strictly parseable but always returns nonqualifying, `blocked-uncertain`, reason `historical-policy-v1-nonqualifying`, exit 1.
- Existing final/fresh `qualified-equal` and mutant `exact-intentional-mutant-delta` behavior remains unchanged.

Retain all V1 result fields and add:
```
BaselineExitCode
FinalExitCode
AcceptedHistoricalNoRegression
HistoricalAnalysis
  TestTerminalTransitionSets
  PackageTerminalTransitionSets
  FinalOnlyPassingTests
  FinalOnlyPassingPackages
  FinalOnlyNonpassingIdentities
  AdmittedPackageNoTests
  BaselineRegressions
  BaselineImprovements
  MissingBaselineIdentities
  PackageFailureAbortDeltas
  HazardousDiagnosticClassDeltas
```

Each transition set should contain:
```
FromAction
ToAction
Count
Identities
CanonicalByteLength
CanonicalSHA256
```

Each identity must contain exact `Package`, `Test`, and `Occurrence`; `Test` is empty for packages. Arrays are embedded rather than referenced externally, preventing a second custody problem.

Recommended historical reason-code additions, using A4’s existing lowercase-hyphen style, are:
```
historical-policy-v1-nonqualifying
final-only-pass-observed
final-only-package-pass-observed
final-only-fail
final-only-test-skip
final-only-package-fail
final-only-package-skip-unclassified
final-only-package-abort
baseline-pass-regressed
baseline-terminal-disappeared
baseline-fail-became-skip
baseline-skip-became-fail
inherited-failure-observed
baseline-fail-became-pass
baseline-skip-became-pass
package-no-tests-admitted
new-package-abort
new-panic
new-race
new-warning
new-fatal-runtime
malformed-stream
truncated-stream
unknown-diagnostic
duplicate-start
missing-start
duplicate-run
missing-run
duplicate-terminal
missing-terminal
terminal-without-start
impossible-association
mapping-error
final-exit-inconsistent
historical-no-regression-satisfied
historical-no-regression-not-satisfied
```

These names do not conflict with current A4 spellings, but cannot be declared frozen under this verdict.

## 10. Minimal touched-file recommendation

A v2 successor requires five files, not the expected three:

1. `tool/source/FORMAT.md` — normative schemas, transition relation, canonical encoding, result fields, reasons, and exits.
2. `tool/source/envelope/semantic.go` — v2 types, strict loader, transition engine, bound-raw no-test classification, hazard deltas, V1 historical disabling, and exits.
3. `tool/source/envelope/envelope_test.go` — causal matrix and active-schema tests.
4. `tool/source/envelope/runner.go` — its deliberately closed active schema registry currently lists only V1 at [runner.go (line 41)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800/tool/source/envelope/runner.go:41).
5. `tool/source/cmd/repair10-compare/main.go` — currently always invokes the V1 loader/comparator/exit path; it needs strict schema-aware dispatch.

The suite runner’s execution behavior, fixture generator, byte comparator, and `go.mod` need no change.

## 11. Mandatory causal tests

1. Hundreds of absent→pass tests accepted without an allowlist.
2. Exact identity arrays, byte lengths, and hashes retained deterministically.
3. Final-only test fail blocks.
4. Final-only test skip blocks.
5. Final-only package abort blocks.
6. Pass→fail blocks.
7. Pass→skip blocks.
8. Pass→absent blocks.
9. Fail→pass is admitted and reported.
10. Skip→pass is admitted and reported.
11. Fail→skip blocks.
12. Skip→fail blocks.
13. New panic, race, warning, fatal-runtime, malformed, truncated, unknown, duplicate, missing, and terminal-without-start states each block independently.
14. HEAD and Repair 9 are evaluated independently; reversing either direction fails validation.
15. Exact no-test package evidence admits only the narrow package skip; marker, package, test count, diagnostic, or terminal mutations block.
16. V1 historical specs parse but return nonqualifying exit 1.
17. Final/fresh still returns accepted equality/exit 0, and exact mutant behavior remains qualified-different/exit 2.
18. No active policy references the compiled privacy-test constant or predicate.

Required controls:

- Rename: old pass→absent blocks even if a same-body new test passes.
- Deletion: fail→absent blocks rather than being labeled improvement.
- Masking: any number of new passes cannot hide one hazardous transition.
- Subtests: an arbitrary-name final-only passing subtest is admitted structurally.
- Package lattice: exercise every admitted and blocked package transition.
- CLI: verify exact v1/v2 result schemas, reason codes, and 0/1/2 exits.

## 12. B6 restart implications

B6 must not start from B4’s pre-A5 final record.

Before A6 can be frozen, a separately authorized evidence-refresh turn must produce a complete, identity-bound A5 full-suite raw stream and semantic envelope for exact T `e260e1bb…` and inventory `9fb9765a…`. The two historical matrices and hazard deltas must then be recomputed.

If the exact A5 run still contains any provisional blocker, B6 must stop with exit 1. A6 must not regain success through identity exceptions or a generated declaration.

Only after the policy is supported and A6 is sealed should B6 restart from the beginning with fresh HEAD, Repair 9, final, mutant, and independent-final controls.

## 13. Inspection limits

The unresolved evidence gaps are:

- No exact A5 `./...` raw stream, semantic envelope, suite result, qualification, or custody chain.
- B5 explicitly launched no repository control or semantic comparison.
- A5 focused/regression streams are compatibility evidence, not a full historical control.
- Exact Repair-9 source bytes were cleaned, limiting source-grounding.
- A4 lacks typed no-test and fatal-runtime semantic fields.
- Consequently, the exact A5 matrices, exact A5 set hashes, complete hazard deltas, and final reason-code closure remain unknowable from sealed material.

## 14. Read-only confirmation

No repository or evidence file was changed. No A6/B6 child, source copy, report, cache, bytecode, scratch artifact, manifest, ZIP, handoff, or snapshot artifact was created. No test suite ran. No staging, commit, push, installation, live route, remote host, or network operation occurred. Inline parsing used `PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -`, imported no sealed-child module, and emitted stdout only. No subagent was created or used.

REPAIR10I\_A6\_RECONNAISSANCE\_BLOCKED
