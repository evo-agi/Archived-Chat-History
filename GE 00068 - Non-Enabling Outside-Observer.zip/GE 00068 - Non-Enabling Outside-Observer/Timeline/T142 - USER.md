Here is Codex's response:

## 1. Verdict

**EVIDENCE\_VERIFICATION\_V1\_LOAD\_CUSTODY\_RECONNAISSANCE\_READY**

A finite design is ready for implementation review: **Model C, externally authenticated source by value through&#x20;****`python -c`**. This is a design verdict. No implementation or repository test was performed.

## 2. Response-format confirmation

This is the complete reconnaissance report inline. The links after section 41 are supplemental evidence.

## 3. Opening and closing repository/provenance identity

The opening and closing checks matched:

| ItemVerified identity       |                                                                                                                                       |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Physical worktree root      | `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`; direct real directory                                        |
| Branch                      | `codex/evidence-verification-v1`                                                                                                      |
| HEAD                        | `567bceced5df95ecfe787cc66038d463a854e12c`                                                                                            |
| HEAD tree                   | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                                                                            |
| Sole parent                 | `05dde14d185b6e022dcc169ef1a658a97961850f`                                                                                            |
| Upstream                    | Absent; the separate query failed only with “no upstream configured”                                                                  |
| Worktree                    | Exactly 13 paths: four modified tracked, nine untracked; zero staged, deleted, renamed, or unmerged paths; no extra path              |
| Paths                       | All 13 matched the manifest’s classification, size, SHA-256, regular single-link type, working mode `0644`, and logical mode `100644` |
| Tracked binary diff         | `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`, using the provenance recipe’s exact diff flags                    |
| Git operation markers/locks | None                                                                                                                                  |

The four modified paths were `PLANS.md` and `.docs/system_overview/{artifact_hygiene,boundaries,capability_probing}.md`. The nine untracked paths were `.docs/system_overview/evidence_verification.md`, the verifier and test, the registry, three layouts, and two inert historical `.py.txt` fixtures.

The manifest was a regular single-link `0600` file of 3,192 bytes at device/inode `16777234/176911418`, SHA-256 `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`. Its exact recipe ID, branch, HEAD, absent upstream, 13 rows, and diff digest matched. The retained recipe SHA-256 was `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`. Verifier and test SHA-256 values remained `1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f` and `cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132`.

The SEC-02 record remained a stable regular single-link file with SHA-256 `1eb9e9f18cdf00a264b82012d0856c7a78160adb2e7f2de5674fe201ef2b74e0`. The repair-v3 report and all four fifth-audit perspective reports were present, stable, and unchanged by hash. The A6D and amendment roots remained direct directories at device/inode `16777234/176287133` and `16777234/176653980`. The pinned interpreter remained Python 3.13.4, a regular single-link 119,424-byte file with SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

## 4. Prior failed-recon disposition

The earlier failed conversation is **nonqualifying**. Its missing fifth-audit summary-path requirement, incomplete baseline gate, absence of explorers and probes, and unrooted Git command in the primary checkout provide no design conclusion for this reconnaissance. This conversation used the supplied inline SEC-02 capsule and did not require a fifth-audit `closeout/report.md`.

## 5. Frozen SEC-02 statement and machine-evidence identity

SEC-02 is a **high-severity executable-source load-to-binding race** and a residual repairable source-boundary defect. Python loaded target-contained source through an external symlink. That source ran a synchronization prelude. An external actor then atomically replaced the symlink with a direct external file containing the exact current verifier bytes. Later source checks saw the replacement, while `__file__` and `sys.argv[0]` retained the lexical external pathname. The target-loaded marker appeared, yet the recorded result was canonical `pass`, exit `0`, and empty stderr.

The machine record has the SHA-256 stated in section 3. It establishes this instrumented causal. It does not establish a same-timing uninstrumented swap or invalidate the specific continuously direct, externally pinned A6D and amendment invocations.

## 6. Why post-load path binding is insufficient

Python selects and begins executing a script before the verifier reaches `open_source_binding()`. The current verifier calls that function from `main()` after load (`verify_v1.py:333-357,790-810`), then rechecks the object it opened later (`:365-383,828-831`). Path spelling, loader filename, `__file__`, and `sys.argv[0]` do not identify the earlier loader inode. SEC-02 demonstrates that the later path object can differ from the object whose code already ran.

A later no-follow open, stronger closing stat, `F_GETPATH`, or code-object comparison cannot retroactively establish the original script object or undo executed target code.

## 7. Four explorer scopes and completion status

| ExplorerScopeStatus |                                                         |          |
| ------------------- | ------------------------------------------------------- | -------- |
| 1                   | Python 3.13.4 load, argv, FD, and code-object semantics | Complete |
| 2                   | Repository authority, contracts, and versioning         | Complete |
| 3                   | Security models and threat boundaries                   | Complete |
| 4                   | Migration, validation, and finite implementation map    | Complete |

All four were read-only, ran no Git command, and created no nested subagent. The first three started together. The fourth start and its required immediate retry hit the environment’s four-slot limit, which includes the parent; it started when a slot opened and overlapped the remaining explorer work. Thus **four explorers completed, but all four could not run simultaneously**. All were closed before the parent probes.

## 8. Preserved disagreements

The fifth-audit correctness perspective’s narrow finding remains valid: the particular continuously direct, externally pinned launches it examined were contained. The security perspective’s broader finding also remains valid: that does not prove the categorical launch contract when an actor controls the external pathname during Python startup.

The explorers agreed that `sys.orig_argv` can check consistency but cannot authenticate source trust. Explorer 1 found `/dev/fd/N` useful for a held descriptor on this host; the security and migration reviews emphasized its mutable-file and portability gaps. There was no disagreement requiring a second selected design.

## 9. Probe environment

The parent ran isolated probes with the pinned Python 3.13.4 interpreter, a private `0700` root beneath `RECON_ROOT/probes/tmp/`, `PYTHONDONTWRITEBYTECODE=1`, `LC_ALL=C`, `LANG=C`, and a private `TMPDIR`. The source inputs were private byte-exact copies or small retained diagnostic sources. Most semantic probes used `-I -S -B`; the exact current-verifier `-c` probe used its existing `-I -B` contract. No network, product path, live service, or repository test was invoked.

## 10. Exact probes run

The retained probe record contains each argv vector, environment, source bytes or retained source file, stdin, passed FDs, input identities, stdout, stderr, exit status, and cleanup. The parent ran:

1. Exact current verifier bytes through `python -I -B -c SOURCE`.
2. `sys.orig_argv` recovery of a complete `-c` source argument.
3. Byte → canonical UTF-8 string → argv → byte round trip.
4. Embedded and terminal LF preservation.
5. A 37,488-byte source argument and host argv-capacity observation.
6. Observable-state comparison for direct script, final symlink to a target-contained source, stdin, `-c`, and inherited `/dev/fd/N`.
7. `-c` execution while a target-contained source and external link existed but were never loaded.
8. A prototype no-follow package-source byte comparison.
9. Package file replacement after the `-c` string was constructed.
10. Source and package FD survival and identity under `pass_fds`.
11. `/dev/fd/N` script loading through an inherited source FD.
12. Separate compilation of byte-distinct, code-equivalent sources.
13. macOS `F_GETPATH` before and after renaming the held file.
14. Mutation of `sys.orig_argv` and `sys.argv` after startup.
15. Process-list visibility of a `-c` source marker.

## 11. Probe results

| ProbeObserved result              |                                                                                                                                                                                                                                                             |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Exact current verifier under `-c` | Canonical `IO_OR_RACE`/exit `7`, empty stderr. The unchanged source expects `__file__`; implementation work is required.                                                                                                                                    |
| Round trip and LF                 | The 37,488-byte UTF-8 command was recovered with identical SHA-256, embedded newlines, and terminal LF; exit `0`.                                                                                                                                           |
| Argv capacity                     | `ARG_MAX` was 1,048,576 bytes. The measured argv and environment occupied 37,567 and 191 bytes, leaving an approximate 1,010,818-byte aggregate margin before kernel overhead. The actual spawn succeeded. This is host evidence, not a portable guarantee. |
| Direct and final-symlink script   | Both exposed the lexical script pathname in `sys.argv[0]`, `__file__`, and code filename. The symlink case did not expose its target inode through those values.                                                                                            |
| Stdin and `-c`                    | Stdin used `-`/`<stdin>`; `-c` used `-c`/`<string>` and had no `__file__`. `sys.orig_argv` retained the complete command string.                                                                                                                            |
| Target source present during `-c` | Only the argv source ran, printing `argv-source-only`; the target source was not loaded.                                                                                                                                                                    |
| Package comparison                | Matching `-c` and package bytes returned `same: true`, exit `0`. Replacement after argv construction returned `same: false`, exit `2` in the prototype.                                                                                                     |
| FD probes                         | Held source and package FDs survived Python startup with the parent’s device/inode identities. `/dev/fd/3` loaded and retained lexical `/dev/fd/3` metadata; this does not freeze the file’s bytes.                                                         |
| Code objects                      | Two byte-distinct sources differing by a trailing comment produced equal bytecode, constants, line tables, and marshalled code objects.                                                                                                                     |
| `F_GETPATH`                       | It reported `fdpath-before`, then `fdpath-after` for the same held inode after rename. It is a current FD path observation, not loader history.                                                                                                             |
| Mutable argv                      | Both `sys.orig_argv` and `sys.argv` changed when Python code assigned to them.                                                                                                                                                                              |
| Process list                      | `ps` displayed the `visible-source-marker` from the `-c` argument. The probe process was terminated and reaped.                                                                                                                                             |

These observations establish feasibility of the byte transport on this host. They are not a test of the future full verifier implementation.

## 12. Model A — stronger post-load pathname binding

**Rejected.** It can bind the object found when verifier code begins, but SEC-02 disproves the assumption that this is necessarily Python’s earlier loader object. No supported Python-level direct-script API identified the original loader inode. More later path checks would preserve the gap.

## 13. Model B — externally trusted immutable launch path

**Rejected for this tranche.** It could work only with an externally proved immutability boundary covering the source and every ancestor throughout startup. A `0644` file, one link, no-follow checks after load, or an operator assertion does not prevent a same-UID owner from changing a writable path. That premise is absent from the current contract and would export an unproved condition rather than close SEC-02.

## 14. Model C — source by value through `python -c`

**Selected, subject to the future validation gates in section 33.** A trusted external producer or auditor opens a direct, physically external package source without following links, authenticates its exact bytes against independent provenance, converts those bytes to a canonical UTF-8 string, and places that string directly in one `-c` argv element before Python starts. Path substitution after construction cannot change those argv bytes.

The verifier’s later comparison of `sys.orig_argv` to no-follow-opened package source is a **consistency and package-boundary check**, not source self-certification. The externally authenticated package source remains physically outside the target; the documentation must explicitly define this by-value execution model before code changes.

## 15. Model D — FD-bound script launch

**Not selected.** On this macOS host, `/dev/fd/N` and `pass_fds` worked with a held source descriptor. The pseudo-path remains a platform dependency, the current direct-file rule and `__file__`-derived package logic do not fit it, and a held regular FD does not prevent in-place byte changes between external hashing and Python’s read. A portable same-object, immutable-byte protocol was not established.

## 16. Model E — fixed `-c` bootstrap executing held-FD source

**Not selected.** It can be made meaningful only if an external owner authenticates both the bootstrap bytes and the bytes read from the held FD before compilation. That creates a second executable provenance object and an FD custody contract. A file-backed bootstrap reintroduces the load problem; Model C avoids this extra trust surface.

## 17. Model F — native or compiled launcher

**Not selected.** It would add launcher source, binary and build provenance, platform qualification, and an owner for the launcher. Those additions are disproportionate while Model C is feasible within the existing verifier tranche.

## 18. Model G — contract relaxation to executed-byte equivalence

**Rejected as a silent repair.** Exact-byte equality helps only when the executed bytes are externally authenticated and bound before load. Code-object equality is insufficient: the probe produced identical marshalled code objects from different source bytes. Allowing target-contained executable source merely because bytes match would change the current categorical physical-source rule and require a separate strategic `PLANS.md` and normative-doc decision.

## 19. Selected primary model

**Model C** is the sole primary design. It is an explicit **Bounded slice rule refinement and incompatible invocation-contract change**, with verifier implementation work. It does not exercise a `Reopened redesign seam`, alter T1 or a public product contract, or confer readiness authority.

## 20. Selected fallback

**None.** If Model C fails a mandatory implementation or audit gate, stop and reopen design review. Model D is not an automatically authorized fallback.

## 21. Rejected models and reasons

A cannot recover pre-load identity. B depends on an unproved immutable path. D leaves mutable FD bytes and a platform-specific pseudo-path contract. E adds a second executable trust object. F adds a build and binary trust chain. G conflicts with the physical-source contract or weakens byte identity. None meets the selected criteria more directly than C on the observed host.

## 22. Exact threat model

The design addresses target-controlled files and a concurrent actor capable of replacing or writing the external launch pathname, including same-UID rename/write and transient symlink substitution. It assumes the **external producer or independent auditor**, its provenance input, the pinned interpreter, and argv construction are trusted. The target cannot choose the source string, package root, interpreter, options, environment, inherited FDs, or acceptance of the returned record.

Source symlink/hardlink and target/package containment remain disallowed. Registry and layout substitution is checked through the exact hashes of bytes parsed and mandatory external comparison with independently pinned hashes. Hostile argv or environment construction, forged transcripts, a compromised caller/interpreter/stdlib, privileged filesystem identity forgery, debugger or process-memory tampering, and SHA-256 collision are outside the bounded guarantee. A verifier `pass` remains structural evidence only.

## 23. Residual trust assumptions

The trusted caller must truly read and authenticate the exact source bytes *before* exec and pass those bytes as one argv element without shell transformation. Python/OS argv delivery and the pinned interpreter must behave as probed; `-I -S -B` limits startup inputs. `sys.orig_argv` remains mutable, so it cannot replace caller provenance. The canonical source is nonsecret and may appear in process listings. Unsupported capability or insufficient argv capacity must stop the launch; no script, stdin, or FD fallback is permitted.

## 24. Exact future invocation contract

Freeze **launch protocol v2** with an argv-list API, no shell, no command substitution, no trimming, and no extra options. `SOURCE_TEXT` is the exact canonical UTF-8 decoding of externally authenticated `verify_v1.py` bytes, including its terminal LF.
```
PYTHON -I -S -B -c SOURCE_TEXT
  --package-root ABSOLUTE_PHYSICAL_EXTERNAL_PACKAGE
  --root ABSOLUTE_PHYSICAL_TARGET
  --layout-id ID
  --stage sealed
```

For pre-seal, append exactly `--manifest ABSOLUTE_PHYSICAL_EXTERNAL_CANDIDATE` after `--stage pre-seal`. The caller uses the pinned interpreter, private external `TMPDIR`, `PYTHONDONTWRITEBYTECODE=1`, `LC_ALL=C`, and `LANG=C`, and closes unrelated FDs. The verifier checks the fixed option order and count, `sys.argv[0] == "-c"`, and the expected `sys.orig_argv` option/string sequence. Its check must account for this macOS framework interpreter reporting a `Python.app` executable spelling in `sys.orig_argv[0]`; the caller, not that field, pins interpreter identity.

## 25. Exact external producer/auditor responsibilities

The external caller must:

1. Pin the interpreter’s physical identity, version, size, and SHA-256.
2. No-follow traverse the physically external package, open direct regular single-link `verify_v1.py`, establish package/target/candidate separation, and authenticate the exact read bytes against the current external patch provenance or later exact-byte commit provenance.
3. Reject invalid/noncanonical UTF-8, NUL, missing terminal LF, byte round-trip failure, identity uncertainty, or insufficient argv capacity before exec.
4. Construct and retain the exact argv vector, safe environment, source-byte identity, and pre/post source/package observations. It must not use a shell or substitute a script pathname.
5. Independently pin registry and selected layout bytes. After execution, accept a result only after checking exit, empty stderr, canonical single-line output, schema, tool ID, stage, layout ID, and the returned registry/layout hashes against that provenance.
6. Retain no-write snapshots of target, package, candidate when applicable, and private temporary directory. Treat `pass` as structural evidence, never readiness or source trust.

Producer and auditor perform these duties independently; neither asks the verifier to certify its own code or evidence container.

## 26. Exact verifier responsibilities

The future verifier must require the closed v2 `-c` shape; recover its command string from `sys.orig_argv`; re-encode and byte-compare it with a no-follow-opened, direct regular single-link package `verify_v1.py`; and retain source/package identity checks through closing. It must physically bind the explicit package root, registry, selected layout, target, and pre-seal candidate, preserving their existing disjointness and capability rules. A source mismatch or uncertain identity blocks canonically. Definite forbidden source/package containment rejects canonically. Invalid invocation rejects canonically.

It must preserve the existing read-only, no-network, standard-library-only closure work. It must neither claim its comparison authenticates itself nor emit source path, source hash, package path, target path, or readiness.

## 27. Direct-script support disposition

Direct-script, final-symlink script, stdin, `/dev/fd/N`, and ambiguous `-c` forms are **nonqualifying under launch protocol v2**. The trusted new verifier source should return canonical `INVOCATION`/exit `2` for an unsupported invocation shape. A hostile replacement program could forge output in any launch model; the external caller’s pre-execution source authentication and recorded invocation remain mandatory. Historical direct-launch results remain historical observations, not v2 qualification.

## 28. Tool and launch-protocol version disposition

Name the incompatible invocation **launch protocol v2**. Retain `verify_v1.py`, tool ID `execution-substrate.evidence-closure-verifier/v1`, and result schema v1 for this precommit bounded repair because closure meaning and output fields stay unchanged. This is a strategic version choice, not a claim that the old direct-script invocation still qualifies. Any closure or output-schema change requires a separate version decision and fresh provenance.

## 29. Output/schema disposition

Keep the existing canonical one-line JSON fields and exit/failure taxonomy. Registry, layout, and manifest hashes already in the output remain structural provenance fields; add no source hash, source/package/target path, launch-attestation claim, product result, or readiness field. A bare canonical `pass` is insufficient for caller acceptance without external source and registry/layout provenance checks.

## 30. Registry/layout disposition

`registry_v1.json`, the three layout JSON files, and their schemas remain unchanged. The verifier hashes the exact registry and selected layout bytes it parses. The trusted caller must compare those returned hashes with independently pinned values, so a substituted package JSON file cannot qualify merely by being restored later. The historical `.py.txt` fixtures remain inert **Temporary compatibility edges**.

## 31. Exact intended touched-file set

The one finite implementation tranche touches exactly six existing repository paths, in doc-first order:

| FileIntended change                              |                                                                                                |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------- |
| `PLANS.md`                                       | Record launch-custody refinement, sequencing, and stop conditions                              |
| `.docs/system_overview/evidence_verification.md` | Define v2 invocation, caller/verifier ownership, physical source meaning, and failure behavior |
| `.docs/system_overview/artifact_hygiene.md`      | Align categorical source-external wording with externally authenticated by-value execution     |
| `.docs/system_overview/capability_probing.md`    | Define behavioral source/package capability checks and fail-closed boundary                    |
| `tools/evidence_verify/test_verify_v1.py`        | Migrate invocation harness and add launch-custody causals                                      |
| `tools/evidence_verify/verify_v1.py`             | Implement the closed `-c` and explicit-package consistency/binding behavior                    |

`.docs/system_overview/boundaries.md` retains the same ownership and non-authority split; no change is intended. No product, lifecycle, registry, layout, or historical-fixture file is in scope.

## 32. Any new file and classification

**No new repository file.** The patch remains 13 paths; the current `PLANS.md` stop on a required fourteenth path remains operative. A future producer or auditor runner retained outside the repository would be **source-external validation/provenance evidence**, independently reviewed and pinned, with no verifier, product, or readiness authority. This reconnaissance created only the isolated evidence files described in section 39.

## 33. Complete causal and validation matrix

These are **future implementation gates**, not tests claimed to have passed in this reconnaissance.

| CausalRequired result                                                       |                                                                       |
| --------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| Exact authenticated by-value source, pre-seal and sealed                    | Canonical pass on valid private fixtures                              |
| Exact source string, embedded/terminal LF, canonical UTF-8, size limit      | Byte-identical recovery or pre-exec stop                              |
| Direct script, stdin, `/dev/fd`, extra/reordered/ambiguous launch options   | Canonical nonqualification; no fallback                               |
| SEC-02 timed external symlink swap                                          | Target-contained prelude never executes; no qualifying forged pass    |
| Target-contained source and external symlink present but unused             | Only authenticated argv source executes                               |
| Source symlink, hardlink, symlinked parent, or source/package inside target | Definite boundary reject                                              |
| Same source bytes in a distinct target inode                                | Does not by itself establish aliasing; existing physical rules govern |
| Package source replaced or rewritten after argv construction                | Byte/identity mismatch blocks before pass                             |
| Package replaced during verifier checks                                     | Rebinding or closing uncertainty blocks                               |
| Registry or selected layout substituted                                     | Returned digest differs from pinned provenance; caller rejects        |
| Package/target equality, nesting, and case alias                            | Boundary reject                                                       |
| Pre-seal candidate inside package or target, or substituted                 | Existing candidate boundary/race reject                               |
| Missing no-follow, parent traversal, FD, or repeated-read capability        | Canonical `IO_OR_RACE`; no path fallback                              |
| Invalid source UTF-8, NUL, missing LF, argv over limit                      | Caller stops before exec                                              |
| Mutable `sys.orig_argv` or equivalent code object                           | Never accepted as source authentication                               |
| Existing closure causals and deterministic/no-write checks                  | Retain and pass under new harness                                     |
| Sealed A6D, sealed amendment, synthetic A6                                  | Repeated canonical results and unchanged snapshots                    |
| Output schema and authority                                                 | No source attestation, paths, or readiness claim                      |

The current 75-test suite must be migrated, including tests 60–75’s direct-script assumptions, then independently rerun. No repository test was run here.

## 34. A6D and amendment migration

Future validation should invoke the unchanged sealed A6D and sealed amendment **twice each** through the new authenticated `-c` caller, using their existing layout IDs. Compare canonical stdout byte for byte and snapshot target, package, and private `TMPDIR` before and after. Preserve the sealed children and the historical verifier fixtures unchanged. These future read-only checks do not restart A6 or convert old results into new qualification automatically.

## 35. Synthetic A6 migration

Reuse the existing test-owned private synthetic A6 writer. Under v2, run pre-seal twice against its external candidate, let that writer install its seal, then run sealed verification twice. Compare deterministic output and target/package/candidate/temporary snapshots. The verifier itself must install nothing.

## 36. Provenance and fresh-audit sequence

Before code: revise `PLANS.md` and the three authoritative `.docs/` pages, then tests, then verifier code. After code: run the full migrated suite and causal matrix, the read-only real-child checks, and synthetic A6 checks. Recapture the same 13-path manifest twice with the retained exact provenance recipe if the path set stays unchanged; the old manifest will no longer authenticate changed bytes. Record exact `-c` source, argv, interpreter, environment, registry, layout, and external runner identities.

A **fresh independent** audit must inspect and exercise the new source, launch procedure, registry/layout custody, and SEC-02 causal before any exact-byte commit. Any later fresh Repair 10I-A6 child and its evidence audit remain separate subsequent work. No such work was performed now.

## 37. Mandatory stop conditions

Stop if exact source bytes cannot be externally authenticated before exec; UTF-8, LF, argv delivery, or host capacity fails; the trusted caller uses shell transformation; source/package physical ancestry or no-follow behavior is uncertain; an unsupported launch qualifies; package source or registry/layout provenance differs; a capability failure gains a fallback; output becomes source self-certification or readiness authority; no-write/no-network behavior changes; a real or synthetic compatibility gate fails; a fourteenth repository path or second verifier is needed; or the work crosses product, public, runtime, shared-kernel, or reopened-seam boundaries without a new governance decision.

## 38. Inspection limits and unresolved uncertainty

The parent probed Python transport and prototype comparisons, not a future full implementation. The exact current verifier under `-c` correctly failed before modification. A same-timing uninstrumented SEC-02 swap, privileged kernel identity forgery, cross-host argv limits, and adversarial concurrent real-child mutation were not tested. `F_GETPATH` and `/dev/fd` observations are macOS-host-specific. The architecture-reset decision was found in `PLANS.md` and the normative verifier docs; no separate authoritative reset file was identified. The four-explorer simultaneous-start constraint could not be met because the parent occupied one of four slots; all four independent reports nevertheless completed before parent probes.

## 39. Recon-created artifacts and cleanup

The required previously absent `RECON_ROOT` was created with `opening/`, `perspectives/`, `probes/`, `findings/`, and `closeout/` at mode `0700`. Retained files are mode `0600`: opening identity and Git process records, explorer status, probe source and exact results, source copies, model selection, and closing identity. All are beneath `RECON_ROOT`. The one probe-owned temporary run root beneath `probes/tmp/` was removed; that directory is empty. No supplied evidence or repository path was written.

## 40. Git-process record

The **first Git command** was exactly `git -C "$IMPL_R" rev-parse --show-toplevel`, with cwd `IMPL_R` and `GIT_OPTIONAL_LOCKS=0`, `GIT_CONFIG_NOSYSTEM=1`, `LC_ALL=C`, `LANG=C`, and `PYTHONDONTWRITEBYTECODE=1`. Every later parent Git command used the same rooted `git -C "$IMPL_R"` form, cwd, and environment. No explorer ran Git, and no Git command ran in the primary checkout or an evidence root.

The ordered opening Git argv suffixes were: `rev-parse --show-toplevel`; `branch --show-current`; `rev-parse HEAD`; `rev-parse HEAD^{tree}`; `rev-list --parents -n 1 HEAD`; the separate upstream query; `status --porcelain=v1 -uall`; `diff --cached --name-status`; `diff --binary`; a diagnostic `diff --binary` hash; the exact recipe-flagged binary diff hash; `ls-files --stage`; and `status --porcelain=v1 --untracked-files=all`. The diagnostic non-recipe diff hash was `5855e4f…`; the exact recipe-flagged hash matched `8aea2e7…`. The separate upstream query exited `128` solely because no upstream exists; all other opening Git commands exited `0`.

Closing repeated rooted root, branch, HEAD, tree, parent, separate upstream, status, staged diff, and exact recipe-flagged diff-hash commands, with the same results. The retained process record gives every full argv, cwd, relevant environment, exit, and hash observation.

## 41. Explicit confirmations

Repository mutation **not performed**. Documentation mutation **not performed**. Implementation **not performed**. Repository tests **not run**. Staging **not performed**. Commit **not performed**. Push **not performed**. A6 **not restarted**. Product paths and live services **not invoked**. Network contact **not performed**. Nested subagents **not created**.

Supplemental retained evidence: [exact probe results](/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f/probes/probe-results.json), [probe source](/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f/probes/probe.py), [opening Git-process record](/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f/opening/git-process.json), [closing identity](/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f/closeout/closing-identity.json), and [selection record](/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f/findings/selection.json).
