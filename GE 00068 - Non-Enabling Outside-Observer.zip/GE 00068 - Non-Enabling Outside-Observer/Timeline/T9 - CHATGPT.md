This confirms the **Phase G readiness verdict was invalid**. The correct disposition is not “reporting error”; it is a real validation failure.

The important distinction is that the sealed evidence does **not yet establish a product implementation defect**. It establishes three different problems:

1. **Product-test defect:** two `remoteobserver` tests use collision-prone bare-decimal substring checks. Fresh happened to contain `7002` somewhere in canonical output and failed, while final passed. That does not prove private custody data leaked.
2. **Successor/comparison defect:** the comparator does not safely canonicalize known run-local diagnostics, and it accepted an embedded mutant qualification inconsistent with the external qualification record.
3. **Validation-construction defect:** final↔fresh was deliberately configured with expected exit `2`, so the selected validation was incapable of proving fresh-pristine restoration. Closeout then treated this expected difference as success.

Phase G must remain sealed and nonqualifying. Provenance and sealing establish exact bytes, not correctness or acceptance.   Generated evidence also remains non-authoritative. 

## The most important unresolved item

Do **not** broadly classify all 200 diagnostic differences as harmless nondeterminism.

Most categories look run-local:

- temporary suffixes and directories;
- recovery-session names;
- panic goroutine numbers and instruction addresses;
- timestamps, trace IDs, request IDs, and durations.

But the `logical_bytes` difference—`87,370,882` versus `87,371,343`—must remain material until its producer and input universe are traced. It may be benign transient-state accounting, but normalizing it before proving that would weaken the comparator.

The next gate should therefore be **read-only Repair 10H reconnaissance**, not implementation, snapshotting, auditing, or committing. The project protocol requires changed bytes to return through implementation and a fresh independent audit, rather than repairing inside an audit or treating prior evidence as binding.  

Use this prompt:

```text
REPAIR 10H — FINAL/FRESH SEMANTIC-RESTORATION RECONNAISSANCE

Objective

Freeze the smallest coherent Repair 10H that makes pristine final versus newly
materialized fresh pristine final prove qualified semantic equality, while
preserving strict detection of the deliberate mutant, baseline differences,
material diagnostic changes, unqualified controls, and unknown output.

This turn is read-only reconnaissance. Do not implement, edit, create, delete,
format, stage, commit, push, build, run tests, create evidence, create scratch
files, modify Git administration, or alter sealed Phase G.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected repository baseline

Branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

Parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

Candidate T:
c7c27cb21dbea12d36324f66e3e5feed4c0ddeea

Inventory SHA-256:
3b60a85f9eeccc12fd02405a2ba41c2e49f22931d33213ba5ad7fd4b2d42f80b

Membership:
389 total
375 tracked
14 nonignored untracked

Expected staged/deleted/renamed/unmerged:
0/0/0/0

Sealed Phase G

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256

Manifest SHA-256:
5dd8ac31bf841e3a371a42a92894cd526ae8e5d886f1b13afc940211a5017c49

Current disposition

REPAIR10G_VALIDATION_BLOCKED_FINAL_FRESH_DIVERGENCE

Phase G is exact, sealed, immutable, and nonqualifying.

The sealed evidence established:

- final and fresh use the same candidate T, inventory, tools and logical full
  suite;
- both final and fresh controls were independently qualified;
- final versus fresh was configured with expected exit 2;
- the comparator produced qualified-different;
- lifecycle differences were:
  - package execution-substrate/es/externaltls/internal/statusobservation/remoteobserver
  - TestObserveV1WitnessCustodyClassificationAndContextV1
  - TestObserverClosingWitnessPrivacyV1
- those two tests use collision-prone bare-decimal substring assertions for
  7001/7002;
- 200 diagnostic differences remained unresolved;
- the differences include temporary names, goroutine/address values, API
  timestamps/IDs/durations and one logical_bytes difference;
- the comparison envelope treated the mutant as qualified even though the
  external peer qualification was blocked-uncertain with
  materialization_verified=false;
- Phase G closeout treated five expected qualified differences as success.

Authority posture

- T1 remains a Current invariant.
- Repair 10G/10H remains an unaccepted Bounded slice rule.
- Legacy operator behavior remains a Temporary compatibility edge.
- T2A-I and T2B remain absent.
- Do not reopen the operating model.
- Do not change public product schemas, result authority, installation,
  deployment, binding, witness, restoration, or remote behavior.
- Do not assume production source must change merely because tests diverged.

Opening gate

Before substantive inspection:

1. Verify the repository baseline above without modifying repository or Git
   administration.
2. Reverify the sealed Phase G manifest, detached digest, full path set, modes,
   sizes, hashes, and link policy.
3. Stop on any mismatch with:

REPAIR10H_RECONNAISSANCE_BASELINE_MISMATCH

Subagent workflow

After the opening gate, create exactly four bounded read-only explorers. No
nested delegation. Give each the same baseline and exact Phase G identity.

Do not permit any explorer to create a file, run a test, launch a build, write a
cache, or use an external scratch path.

Role 1 — product-test semantics

Inspect at minimum:

- es/externaltls/internal/statusobservation/remoteobserver/observe_test.go
- the production canonical document types and serializers exercised by:
  - TestObserveV1WitnessCustodyClassificationAndContextV1
  - TestObserverClosingWitnessPrivacyV1
- related tests defining the intended privacy/non-disclosure contract
- any schema or contract governing the canonical document

Determine:

1. The precise intended private-data exclusion rule.
2. Why searching raw JSON for bare decimal 7001/7002 is unsound.
3. The narrow structural field/path/value assertion that should replace it.
4. Whether product production code contains an actual disclosure defect.
5. Whether a production source change is required or whether this is test-only.
6. The exact repository files that would need to change.
7. Causal mutants proving the replacement catches:
   - prohibited private field/key;
   - prohibited private structured value;
   - prohibited private nested context;
   - control-local unrelated decimal collision;
   - legitimate timestamp/request/counter values containing the same digits.

Do not authorize a production-code change merely to stabilize the test.

Role 2 — semantic extraction and canonicalization

Inspect at minimum the selected Phase G successor source, FORMAT contract,
semantic extractor, comparison implementation and tests that produced:

- final semantics:
  60a4a41fa796d4bcdaec05a0f8d1f002d726f9cedff1db52f8042996c8ab12c3
- fresh semantics:
  01bcd8452627b3310cd04d7f48ca95ef8b6f9f1205297bf0c9c17310ac0950d3

Recover all 200 final/fresh diagnostic differences from sealed records and
classify every one into exactly one category:

- materially different;
- recognized control-local identity;
- structurally typed nondeterministic value;
- safely canonicalizable panic-runtime value;
- unknown/unclassified;
- evidence-generation/reporting defect.

For every proposed canonicalization rule specify:

- producer and output grammar;
- exact field/template identity;
- token/component boundaries;
- allowed capture type;
- preserved surrounding bytes;
- mapping source and mapping ID;
- ambiguity handling;
- unknown-value behavior;
- causal positive and negative mutants.

Rules must be structural and allowlisted. Reject generic replacement of decimal
numbers, hexadecimal values, UUID-like strings, paths, timestamps or arbitrary
diagnostic text.

Panic handling, if retained, must preserve at least:

- package and test identity;
- panic message and type;
- function names;
- source file and source line;
- stack frame order;
- multiplicity and correlation order.

Only goroutine identifiers and runtime instruction/address values may be
considered for typed normalization, and only if their exact syntax is proven.

Trace/request/timestamp/duration normalization must parse a recognized
structured field or known output template. Do not regex-normalize arbitrary
text.

The logical_bytes difference:

87,370,882 versus 87,371,343

is a mandatory stop item. Trace its exact producer, input universe, and contract.

Return one of:

- deterministic bug to repair at source;
- safely typed control-local value;
- material semantic difference;
- unresolved.

Do not propose normalizing logical_bytes unless source evidence proves that it
is intentionally outside semantic equality and identifies its exact typed
producer.

Role 3 — qualification and comparator contract

Inspect at minimum:

- successor comparison schemas and FORMAT.md
- comparator CLI
- semantic.go/source.go or their Repair 10G equivalents
- final/fresh comparison envelope
- mutant external peer qualification
- embedded comparison qualifications
- command/suite qualification records
- selected comparison v3 suite specification
- predecessor v1/v2 specifications and their supersession reasons

Determine:

1. Why the comparison envelope represented the mutant as qualified while the
   external peer record was blocked-uncertain.
2. Whether the mutant was genuinely unqualified or was validated against the
   wrong expected materialization.
3. How intentional-mutant qualification must differ from pristine-source
   qualification.
4. The exact source of truth for left/right qualification.
5. Whether comparison must independently derive qualification, cryptographically
   bind an external qualification record, or both.
6. The exact private schema changes needed.

Freeze factual and acceptance fields separately. At minimum adjudicate whether
the next private schema requires:

- LifecycleEqual
- DiagnosticsEqual
- RawBytesEqual
- CanonicalSemanticsEqual
- LeftQualified
- RightQualified
- AcceptedEqual
- Outcome
- ReasonCodes
- QualificationRecordRefs
- UnknownDifferenceCount

AcceptedEqual must never be true unless:

- both controls are independently qualified;
- lifecycle identities and outcomes satisfy the comparison policy;
- canonical diagnostics satisfy the comparison policy;
- unknown differences equal zero;
- resource/custody/terminal checks are clean;
- all late faults are absent.

A factual equality field may remain true after a late qualification failure, but
accepted equality must be false.

Historical Repair 10G schemas remain parseable only as nonqualifying historical
evidence if their meaning is insufficient. Do not modify Phase G.

Role 4 — validation construction, closeout and scope

Inspect at minimum:

- commands/repair10g-final-semantic-comparisons-v3.json
- semantic-comparison-adjudication.json
- phase-g-closeout-adjudication-v2.json
- implementation-report-v2.md
- failed-and-superseded-index-v2.json
- command-index.json
- literal assertion mapping
- provenance recipe inventory
- every orchestration script or retained source that generated or adjudicated
  the five selected comparisons

Freeze the correct policy matrix:

- final versus fresh:
  required qualified-equal, expected exit 0
- final versus deliberate mutant:
  required qualified-different, expected exit 2, with the mutant itself
  independently containment/resource qualified against its declared mutant
  source
- mutant versus fresh:
  required qualified-different, expected exit 2
- HEAD versus final:
  required qualified-different, expected exit 2
- Repair 9 versus final:
  required qualified-different, expected exit 2

Closeout readiness must explicitly require final-versus-fresh AcceptedEqual=true
and UnknownDifferenceCount=0. “All expected outcomes occurred” is insufficient.

Identify:

- exact Phase H successor source members needing modification;
- exact Phase H orchestration/spec/report sources needing modification;
- exact repository paths needing modification;
- governing docs or contract tests that need amendment;
- files that must remain byte-identical;
- private schema IDs requiring versioning;
- validation and evidence records required for a future implementation;
- independent-audit requirements.

Parent synthesis

After all four explorers finish:

1. Preserve every disagreement.
2. Separate product defect, product-test defect, successor defect,
   validation-construction defect and report defect.
3. State whether product production bytes need to change.
4. Produce a complete difference taxonomy for all 200 diagnostic differences.
5. Explicitly adjudicate logical_bytes.
6. Freeze the exact intended repository touched-file set.
7. Freeze the exact successor source touched-file set.
8. Freeze any new private schema identifiers.
9. Freeze the exact implementation order:
   docs/contracts → tests → successor/product changes → validation construction
   → fresh controls → reporting → seal.
10. Define the exact future comparison matrix and expected exit policy.
11. Define causal mutants that prove:
    - decimal collisions no longer fail privacy tests;
    - genuine private fields still fail;
    - recognized control-local values canonicalize;
    - one-nibble OID/digest mutation remains visible;
    - EPERM/EACCES distinction remains visible;
    - pass/fail/skip remains visible;
    - unknown text remains blocking;
    - logical_bytes material change remains visible unless its typed contract
      explicitly excludes it;
    - unqualified mutant cannot be embedded as qualified;
    - final/fresh difference cannot satisfy readiness;
    - closeout cannot set readiness when AcceptedEqual is false.
12. Define provenance, evidence-lineage and sealing requirements.
13. Define stop conditions.
14. Verify repository and Phase G remain unchanged.
15. Close all explorers and stop without editing.

Mandatory stop conditions

Return REPAIR10H_RECONNAISSANCE_BLOCKED if:

- Phase G or repository baseline differs;
- the source of logical_bytes cannot be recovered;
- safe typed canonicalization cannot be distinguished from broad suppression;
- an unknown diagnostic would need to be silently ignored;
- production privacy semantics are unclear;
- fixing the test would weaken the actual privacy contract;
- mutant qualification cannot be independently established;
- comparison acceptance cannot be separated from factual difference;
- a public/product schema change is required;
- T1 behavior rather than test assurance must change;
- implementation requires editing sealed Phase G;
- touched scope cannot be frozen exactly.

Final verdict

Return exactly one:

REPAIR10H_RECONNAISSANCE_READY
REPAIR10H_RECONNAISSANCE_PARTIAL
REPAIR10H_RECONNAISSANCE_BLOCKED

Required report

Include:

- opening and closing provenance;
- explorer completion and nesting status;
- exact inspected paths;
- 200-difference taxonomy;
- logical_bytes adjudication;
- product/test/successor/validation/report defect ledger;
- exact touched-file sets;
- private schema decisions;
- implementation order;
- validation matrix;
- evidence lineage;
- stop conditions;
- inspection limits and confidence.

End with:

REPOSITORY_SOURCE_MUTATION_NOT_PERFORMED
GIT_ADMINISTRATION_MUTATION_NOT_PERFORMED
PHASE_G_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
BUILDS_NOT_RUN
SNAPSHOT_NOT_CREATED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
```

## Strategic assessment

This should be a smaller tranche than Repair 10G, but it is not merely report repair. It crosses the product-test surface and the source-external validation successor. The likely architecture is:

- **No product production change**, unless structural inspection finds an actual privacy leak.
- Replace the two numeric-substring tests with structural privacy assertions.
- Extend the successor with narrow, typed diagnostic canonicalization.
- Make unknown diagnostics blocking.
- Bind comparison eligibility to independently derived control qualification.
- Require final↔fresh accepted equality and exit `0`.
- Prevent closeout readiness when that equality is absent.
- Seal a new Phase H lineage and rerun the affected matrix before creating another integrated snapshot.

**Sources:** Codex’s sealed Phase G reconciliation report supplied above; implementation/audit separation and mandatory re-audit after changed bytes are established by the project operating protocol.   Provenance remains evidence rather than correctness or authority. 

**Confidence:** 0.995 that Phase G is nonqualifying; 0.97 that read-only Repair 10H reconnaissance is the correct next gate; 0.82 that no production runtime change will be required; 0.65 that `logical_bytes` will prove benign rather than uncover another material nondeterminism.
