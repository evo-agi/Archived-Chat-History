Here is Codex's response:

1. **Exact primary verdict:** `AUDIT_PROVENANCE_MISMATCH`

`REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED`  
`FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED`

The governed launch records omit mandatory exact execution controls. Inventing those values was expressly forbidden, so no wrapper root, audit root, platform preflight, or audit parent was created.

## Operative report

1. **Primary verdict:** As stated above.

2. **Final audit-artifact identities:**

   - PYZ: device `16777234`, inode `182699827`, mode `0400`, nlink `1`, UID/GID `501/20`, size `4589679`, SHA-256 `00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0`.
   - Runtime authority: device `16777234`, inode `182699838`, mode `0400`, nlink `1`, UID/GID `501/20`, size `56463`, SHA-256 `9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0`.
   - Launch certificate: device `16777234`, inode `182699841`, mode `0400`, nlink `1`, UID/GID `501/20`, size `3572`, SHA-256 `525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c`.
   - Every file passed two stable no-follow reads.

3. **Replacement subject identity:** device `16777234`, inode `182649818`, mode `0700`, UID/GID `501/20`, nlink `13`, size `416`. Stable inventory: 73 entries, 12 directories, 61 regular files.

4. **Construction-wrapper authentication:** device `16777234`, inode `182648782`, mode `0700`, UID/GID `501/0`, 49 stable entries. Forward treatment, semantic source-freeze resolution, one-shot consumption, production-parent custody, exact locator, closing equality, terminal seal, and “pending fresh independent audit” posture all authenticated.

5. **Accepted implementation chain:**

   - Audit root: device `16777234`, inode `182593190`, mode `0700`, 78 entries.
   - Wrapper root: device `16777234`, inode `182593189`, mode `0700`, 12 entries.
   - External wrapper disposition was `GEN2_IMPLEMENTATION_PACKAGE_ACCEPT`.
   - Source freeze, source registries, lineage, unsuperseded candidate, and opening/closing equality authenticated without re-auditing the implementation.

6. **Content identities:**

   - Bundle: device `16777234`, inode `181651092`, mode `0400`, nlink `1`, size `13598758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`.
   - Authority: device `16777234`, inode `181651098`, mode `0400`, nlink `1`, size `19737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`.
   - Authority was authenticated before ZIP interpretation.
   - ZIP: 479 members, eight roles, seven content roles, one bounded failure-evidence role, no `.DS_Store`; byte-identical in-memory deterministic rebuild; independent-validation record passed.

7. **Stable prelaunch authentication:** All nine fixed roles passed identity, stable-read/inventory, strict JSON where applicable, and final read-only equality checks.

8. **Launch-certificate authentication:** Its bytes, schema, artifact bindings, one-audit count, unused posture, external-wrapper posture, runtime-authority binding, qualification booleans, and stream fields authenticated. It is not launch-complete under the present mandate because no governed record specifies:

   - exact `cwd`;
   - explicit environment;
   - TTY posture;
   - detachment posture;
   - root-allocation ownership/model;
   - exact preflight stdout marker;
   - exact preflight stderr marker;
   - exact preflight exit code.

   The embedded process policy supplies interpreter, isolation flags, `shell=false`, and DEVNULL stdin, but not those missing values.

9. **PYZ/member closure:** 89 members and 88 non-self registry rows; exact registry equality and hashes; UTF-8 byte-sorted names; ZIP_STORED; uniform frozen timestamp `2020-01-01 00:00:00`; `create_system=3`; member mode `0600`; no duplicate, unsafe, directory, symlink, special, comment, cache, bytecode, or historical-audit-source member. Independent in-memory rebuild was byte-identical.

10. **Wrapper/audit-root identities:** Not allocated because Sections 7, 10, and 11 could not close. No empty root required cleanup.

11. **Platform preflight:** Not executed. Its exact marker and exit contract is absent, so execution would have invented authority.

12. **Audit argv/cwd/environment:** The governed argv template was authenticated as:

```text
/usr/local/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz
--mode audit
--runtime-authority /Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json
--subject-root /Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
--construction-wrapper /private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a
--content-bundle /Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority /Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--accepted-implementation-audit /private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04
--accepted-implementation-wrapper /private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg
--output-root <fresh-private-audit-root>
```

   No argv was submitted. Exact `cwd` and environment remain unresolved.

13. **Top-level process custody:** No creation result, custody ID, PID, timing, or completion event exists because parent creation was prohibited.

14. **Raw streams and exit/signal:** No audit-parent streams, exit, signal, or process error existed.

15. **Terminal frame:** None emitted or parsed.

16. **Audit-root authentication:** Not reached; no audit root exists.

17. **Parent self-authentication:** Not reached.

18. **Audit source/freeze/no-Git posture:** Embedded clean source freeze authenticated: ten frozen source files, 32 mapped roles, no later modification permitted. No Git or other VCS was invoked. Real-audit runtime posture was not exercised.

19. **Subject terminal closure:** Prelaunch subject closure identities authenticated: one root row, no empty descendant, symlink, special object, multiply linked file, or cache/bytecode; directory/file modes `0700/0600`. No fresh independent-audit closure was produced.

20. **Normative contract:** Subject file device `16777234`, inode `182649836`, mode `0600`, nlink `1`, size `32038`, SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`. Opening/closing bytes were unchanged.

21. **Fifteen schema roles:** Frozen model contains exactly 15; no real-audit adjudication occurred.

22. **Fourteen families:** Frozen model contains exactly 14; no real-audit adjudication occurred.

23. **Role/family mapping:** Prelaunch package closure passed:

```text
child-process-record → child-process
cleanup-result → cleanup-result
current-export-registry → current-export-registry
executable-origin-registry → executable-origin-registry
failure-outcome → failure-outcome
metadata-coherence → metadata-coherence
normative-construction-parent → intentionally unmapped
package-freeze → package-freeze
package-root-rebinding → package-root-rebinding
phase-record → phase-record
plan-identity-consumer-registry → plan-identity-consumer-registry
pointer-resolution-result → pointer-resolution-result
qualification-result → qualification-result
temporal-inventory → temporal-inventory
terminal-manifest-metadata → terminal-manifest-metadata
```

24. **Draft 2020-12:** Packaged qualification evidence passed; no real-subject metaschema run occurred.

25. **Contract witness rows:** Not executed.

26. **Schema witness rows:** Not executed.

27. **Witness aggregate:** Not produced.

28. **Complete 946 aggregate:** Frozen vocabulary has 946 rows; real audit did not evaluate them.

29. **Failed 946 rows:** None produced; this is not evidence that all rows pass.

30. **Complete 137 aggregate:** Frozen vocabulary has 137 rows; real audit did not evaluate them.

31. **Failed 137 rows:** None produced; this is not evidence that all rows pass.

32. **Dual-oracle crosswalk:** Frozen contract and qualification passed; no real-subject oracle run occurred.

33. **766/333 field map:** Not independently adjudicated in this run.

34. **Documentary-validator closure:** Frozen ten-role vocabulary authenticated; real results were not produced.

35. **Confirmation derivation:** Frozen derivation contract authenticated; real evidence map was not evaluated.

36. **Derivative-confirmation ledger:** Not produced.

37. **Current-role occupancy:** Frozen exact-set vocabulary authenticated; real subject occupancy was not adjudicated.

38. **Lineage/supersession:** Accepted implementation chain authenticated; real audit lineage result absent.

39. **Producer status:** Subject remained in constructed-and-closed, pending-independent-audit posture. No acceptance was preclaimed.

40. **Findings:**

   - `PF-001`: mandatory exact launch controls are absent from the launch certificate, runtime authority, and embedded future-audit contract.
   - `PF-002`: no exact platform-preflight marker/exit contract exists.
   - These are audit-provenance defects, not subject blockers.

41. **Repair owners:** Primary owner is the clean audit-harness launch-authority/package surface. Subject bytes need not change; subject reconstruction is not required. A future unchanged-subject audit is permitted only under a newly coherent, unconsumed launch authority.

42. **Dependency graph:** launch authority → exact preflight/process contract → audit-parent creation → raw streams/frame → capsule authentication. Closure stopped at the first edge.

43. **A00–A15:** No real-audit phase records created.

44. **Child custody:** No governed preflight or audit child created; no child ledger exists.

45. **Audit cleanup:** Not reached; no audit capsule or wrapper-owned temporary root existed.

46. **Capsule supplied-root equality:** Not reached.

47. **Wrapper fixed-input equality:** Read-only opening and closing observations for all nine fixed roles were identical.

48. **Audit temporal identity:** Not created.

49. **Audit manifest identities:** Not created.

50. **A/B equality:** Subject’s pre-existing manifests A/B were byte-identical at size `16620`, SHA-256 `5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758`; no audit-capsule manifests exist.

51. **Final reprojection:** No audit-capsule reprojection occurred.

52. **Physical topology/modes:** Subject prelaunch topology passed; audit-capsule topology not reached.

53. **A15/closure equality:** Not reached.

54. **Seal/no-postseal:** No audit seal transition occurred.

55. **Subject unchanged:** Confirmed by stable opening/closing inventory equality. No mutation or cleanup was performed.

56. **Authority promotion:** None; no rebinding occurred.

57. **Product/runtime/target/A6:** No network, product/live-service mode, target audit, runtime-validation rerun, publication, deployment, or A6 activity occurred.

58. **Remaining uncertainty/nonclaims:** No subject verdict exists. No claim is made about witness, 946, 137, documentary, oracle, confirmation, occupancy, A00–A15, cleanup, or capsule closure results. The one future authorization remains unconsumed.

59. **Explicit wrapper confirmations:**

```text
FINAL_AUDIT_PYZ_IDENTITY_MATCHED=TRUE
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED=TRUE
FINAL_LAUNCH_CERTIFICATE_IDENTITY_MATCHED=TRUE
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED=TRUE
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED=TRUE
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED=TRUE
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED=TRUE
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED=TRUE
LAUNCH_CERTIFICATE_CURRENT_AND_COHERENT=FALSE
LAUNCH_CERTIFICATE_AUTHORIZED_ONE_REAL_AUDIT=TRUE
AUDIT_PYZ_MEMBER_SET_89_CLOSED=TRUE
PLATFORM_CAPTURE_PREFLIGHT_PASSED=FALSE
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE=FALSE
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_CONSUMED=FALSE
QUALIFICATION_MODE_NOT_EXECUTED=TRUE
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED=TRUE
ADMINISTRATIVE_CONTINUATION_NOT_USED=TRUE
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS=TRUE
RAW_STDOUT_RETAINED=NOT_REACHED
RAW_STDERR_RETAINED=NOT_REACHED
PLATFORM_EXIT_AND_SIGNAL_RETAINED=NOT_REACHED
AUDIT_ROOT_SCAN_NOT_PERFORMED=TRUE
TERMINAL_FRAME_STRICTLY_PARSED=NOT_REACHED
CLEAN_AUDIT_SOURCE_FREEZE_AUTHENTICATED=TRUE
NO_GIT_OR_VCS_INVOCATION=TRUE
SUBJECT_TERMINAL_REPROJECTION_PASSED=NOT_REACHED
NORMATIVE_CONTRACT_BYTES_UNCHANGED=TRUE
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES=TRUE_PRELAUNCH_ONLY
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES=TRUE_PRELAUNCH_ONLY
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY=TRUE_PRELAUNCH_ONLY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE=TRUE_PRELAUNCH_ONLY
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID=NOT_REACHED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID=NOT_REACHED
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID=NOT_REACHED
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE=NOT_REACHED
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED=NOT_REACHED
EVERY_NONPASSING_946_ROW_RETAINED=NOT_REACHED
CONTRADICTION_REGRESSION_137_COMPLETED=NOT_REACHED
EVERY_NONPASSING_137_ROW_RETAINED=NOT_REACHED
DUAL_ORACLE_RESULTS_AGREE=NOT_REACHED
NO_ORACLE_EXCEPTION=NOT_REACHED
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED=NOT_REACHED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED=NOT_REACHED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET=TRUE_PRELAUNCH_ONLY
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT=NOT_REACHED
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED=NOT_REACHED
CONFIRMATION_EVIDENCE_MAP_COMPLETED=NOT_REACHED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS=TRUE_PRELAUNCH_ONLY
NO_HARDCODED_CONFIRMATION_SUCCESS=TRUE_PRELAUNCH_ONLY
CURRENT_ROLE_OCCUPANCY_COMPLETE=NOT_REACHED
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED=TRUE_PRELAUNCH_ONLY
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT=NOT_REACHED
NO_FAILED_ARTIFACT_CURRENT=NOT_REACHED
IMPLEMENTATION_PRESENT_FALSE=TRUE_PRELAUNCH_ONLY
IMPLEMENTATION_AUTHORITY_FALSE=TRUE_PRELAUNCH_ONLY
PRODUCER_PACKAGE_NOT_SELF_PROMOTED=TRUE_PRELAUNCH_ONLY
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED=TRUE
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE=NOT_REACHED
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER=NOT_REACHED
FINDING_OWNERSHIP_COMPLETE=NOT_REACHED
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL=NOT_REACHED
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS=NOT_REACHED
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS=NOT_REACHED
ALL_CREATED_CHILDREN_REAPED=NOT_REACHED
ALL_CHILD_DESCRIPTORS_CLOSED=NOT_REACHED
AUDIT_CLEANUP_SET_EQUALITY_PASSED=NOT_REACHED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED=NOT_REACHED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED=TRUE
AUDIT_TEMPORAL_INVENTORY_CREATED=NOT_REACHED
AUDIT_TEMPORAL_INVENTORY_VERIFIED=NOT_REACHED
AUDIT_MANIFEST_A_CREATED=NOT_REACHED
AUDIT_MANIFEST_B_CREATED=NOT_REACHED
AUDIT_MANIFESTS_BYTE_IDENTICAL=NOT_REACHED
AUDIT_TERMINAL_REPROJECTION_PASSED=NOT_REACHED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE=NOT_REACHED
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE=NOT_REACHED
NO_SYMLINK_OR_SPECIAL_OBJECT=NOT_REACHED
NO_MULTIPLY_LINKED_FILE=NOT_REACHED
ALL_AUDIT_DIRECTORY_MODES_0700=NOT_REACHED
ALL_AUDIT_FILE_MODES_0600=NOT_REACHED
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED=NOT_REACHED
SINGLE_AUDIT_SEAL_TRANSITION=NOT_REACHED
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL=NOT_REACHED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED=TRUE
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED=TRUE
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED=TRUE
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED=TRUE
NO_NETWORK_CONTACT=TRUE
NO_GIT_INVOCATION=TRUE
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION=TRUE
NO_TARGET_AUDIT_EXECUTED=TRUE
NO_RUNTIME_VALIDATION_RERUN=TRUE
NO_A6_ACTIVITY=TRUE
NO_SUBAGENTS_CREATED=TRUE
```
