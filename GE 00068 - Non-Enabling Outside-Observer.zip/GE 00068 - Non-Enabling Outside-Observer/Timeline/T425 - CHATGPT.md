## Engineering assessment

The fresh reconstruction failed for a **narrow reconstruction-tool defect**, not for a contract or schema defect.

The decisive sequence is clear:

- The normative contract copied exactly and passed its authority checks.
- All fifteen current schemas copied exactly and passed Draft 2020-12 metaschema validation.
- The fifteen-role registry closed.
- The fourteen generated-record families were reconstructed with explicit normative pointers.
- The fourteen-to-fifteen mapping closed correctly, with `normative-construction-parent` as the sole schema role without a generated-record family.
- Both witness directions passed with zero jointly unsatisfiable or under-enforced baseline families.
- The fourth negative case deliberately replaced `child-process:/outcome` with a list.
- The schema correctly rejected that mutation.
- The documentary checker then incorrectly assumed the deliberately invalid `outcome` remained an object and called `.get()` on the list.

That is a **negative-matrix checker exception on a successful rejection case**. It supplies no repair authority over the normative contract, schemas, case registry, or expected validation semantics.

The proper next step is one bounded repair to the fresh reconstruction parent, followed by one entirely fresh reconstruction attempt. The failed reconstruction root must remain immutable failure evidence. No result file from it should become current, although its exact parent source may be used as the authenticated repair base.

The next attempt also needs stronger failure closeout. The prior failed root did not reach supplied-root closing equality or formal cleanup evidence. The repaired parent must execute read-only supplied-root equality and reconstruction-owned cleanup from a `finally` path on either success or failure. That is process-custody hardening, not package-semantic widening.

No further historical reconciliation is warranted. Construction-parent implementation remains paused until:

1. the fresh subject reconstructs and seals;
2. a fresh P06/P18-corrected harness is qualified against its identity; and
3. one fresh independent audit accepts it.

```text
FRESH BOUNDED REPAIR OF THE SCHEMA-SUBJECT RECONSTRUCTION PARENT
AND ONE-SHOT RECONSTRUCTION RETRY

This task repairs one fresh reconstruction-tool defect and then performs one
wholly fresh schema-subject reconstruction attempt.

The exact defect is:

- negative-matrix case ordinal 4:
  required-mistype:child-process:/outcome;
- the mutated `/outcome` value was deliberately a list;
- the child-process schema correctly rejected the list;
- the documentary checker then called `.get()` on that deliberately invalid
  list and terminated the reconstruction;
- no schema false acceptance was observed.

This task is not another historical provenance reconciliation.

It does not:

- repair the normative construction-parent contract;
- repair any of the fifteen current schemas;
- change the 946-case negative-case registry or its expected semantics;
- change the 137-case contradiction-regression specification;
- patch or reuse the historical blocked construction-parent implementation;
- execute process-self-test;
- execute construct mode;
- build a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- qualify the product;
- authorize A6.

Do not modify, resume, clean, finish, or retry the failed reconstruction root.
Do not promote any result from that root as a current package result.
Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned reconstruction process in one fresh root.
No same-root retry is permitted.

Return the complete operative report inline. Private artifact paths may
supplement but may not replace causal findings, material values, validation
results, or the disposition.

Return exactly one primary verdict:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

PACKAGE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FAILED RECONSTRUCTION ROOT — HISTORICAL FAILURE EVIDENCE
──────────────────────────────────────────────────────────────────────────────

FAILED_RECONSTRUCTION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-86y_r9l9

Expected identity:

- device:
  16777234
- inode:
  180657503
- mode:
  0700
- retained verdict:
  CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Expected reconstruction-parent source identity:

- expected path:
  provenance/fresh_subject_reconstruction_parent_v1.py
- inode:
  180659051
- mode:
  0600
- size:
  167068
- SHA-256:
  5ddc657cccb6e19c810b9a535cbd2d05e62ead31a6990c8ed753904e5fd956a8

Resolve the exact source path through the failed root’s retained bootstrap,
process, source-identity, and failure records. The expected path above is not a
fallback authority.

Expected failure record:

closing/reconstruction-failure-v1.json

- inode:
  180660636
- mode:
  0600
- size:
  1653
- SHA-256:
  99bafbe58e5330caa173b8005e808605e66d021f26440d9084848226acb908f6

Authenticate at minimum:

- bootstrap start;
- reconstruction-parent source identity;
- platform/process custody;
- artifact plan;
- normative-contract preservation result;
- schema copy and role-registry results;
- generated-family authority;
- schema/family mapping;
- metaschema result;
- fourteen-family reconstruction;
- both witness results;
- exact negative-matrix case registry;
- exact blocker;
- failure record.

Classify the root as:

historical_failed_fresh_reconstruction

It is:

- noncurrent;
- nonauthoritative;
- not resumable;
- not cleanable in this task;
- not eligible to supply current package outputs.

Do not execute any source from this root before copying and repairing it into
the new root.

Require complete opening/closing equality when this root is opened.

──────────────────────────────────────────────────────────────────────────────
2. TERMINAL HISTORICAL DECISION
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-final-subject-p06-p18-reconciliation-v4j7a04y

Expected identity:

- device/inode:
  16777234 / 180632969
- mode:
  0700
- verdict:
  FINAL_SUBJECT_SCHEMA_P06_P18_RECONCILIATION_STOP_AND_RECONSTRUCT
- mandatory progression:
  FRESH_SUBJECT_RECONSTRUCTION_AND_FRESH_HARNESS_EVALUATION
- historical reconciliation terminal:
  true
- further historical reconciliation authorized:
  false

Expected final diagnostic inventory:

closeout/final-diagnostic-inventory-v1.json

- inode:
  180633002
- mode:
  0600
- size:
  14272
- SHA-256:
  a80260149b05ca1f173426165ae41559696029b2a972149bdcc2c373644fe304

Authenticate this decision.

Do not reopen historical reconciliation.

──────────────────────────────────────────────────────────────────────────────
3. AUTHORITATIVE CONTRACT AND SCHEMA INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

Use these roots as the authorities for:

- normative-contract bytes;
- exact fifteen current schemas;
- schema role identities;
- schema-repair authority;
- historical contradiction definitions.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. OTHER HISTORICAL LINEAGE INPUTS
──────────────────────────────────────────────────────────────────────────────

HISTORICAL_SUBJECT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

HISTORICAL_FULL_AUDIT:

/Users/ds/Downloads/ES-repair10i-v3-fresh-schema-package-independent-audit-2o4jt9xo

FAILED_P06_P18_RECONCILIATION:

/Users/ds/Downloads/ES-repair10i-v3-schema-audit-block-reconciliation-ppg2rkd9

These roots are lineage and validation-specification inputs only.

Do not copy as current:

- temporal inventories;
- terminal manifests;
- package-status records;
- reports;
- root-bound confirmations;
- P06/P18 results;
- closing-equality results;
- historical package verdicts.

Require opening/closing equality for every historical root opened.

──────────────────────────────────────────────────────────────────────────────
5. FRESH PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-schema-fresh-subject-retry-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- failed reconstruction identity;
- exact failed-parent source identity;
- exact blocker;
- terminal historical decision;
- authoritative contract identity;
- schema-authority identities;
- reconstruction-parent-repair-only authority;
- contract change authorized:
  false;
- schema change authorized:
  false;
- negative-case semantic change authorized:
  false;
- implementation creation authorized:
  false;
- process-self-test authorized:
  false;
- construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false;
- same-root retry authorized:
  false.

Create directories lazily.
Do not retain an empty directory except the lifecycle-permitted reserved
`manifest/` directory.

──────────────────────────────────────────────────────────────────────────────
6. EXACT BLOCKER REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before repairing source, reproduce the blocker read-only from authenticated
failed-root evidence.

Retain:

analysis/negative-matrix-checker-failure-reproduction-v1.json

Bind:

- case ordinal:
  4;
- case name:
  required-mistype:child-process:/outcome;
- target schema role:
  child-process-record;
- mutated instance pointer:
  /outcome;
- mutated value type:
  list;
- expected acceptance:
  false;
- observed schema acceptance:
  false;
- observed schema result:
  correctly rejected;
- expected rejection keyword:
  type, or the exact contractually accepted mechanism;
- expected instance path:
  /outcome;
- checker operation:
  exact `.get()` call and source range;
- exception type;
- exception message;
- traceback identity;
- first blocker;
- package semantic effect:
  none;
- schema semantic effect:
  none;
- negative-case semantic effect:
  none;
- repair owner:
  fresh reconstruction documentary checker.

If the exact failure cannot be reproduced from authenticated source and case
bytes, return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Do not alter the schema or mutation to make the checker pass.

──────────────────────────────────────────────────────────────────────────────
7. BOUNDED RECONSTRUCTION-PARENT SOURCE REPAIR
──────────────────────────────────────────────────────────────────────────────

Copy the authenticated failed reconstruction-parent source to:

provenance/fresh_subject_reconstruction_parent_v2.py

using:

- no-follow stable read;
- exclusive mode-0600 write;
- fsync;
- close;
- no-follow reopen;
- byte comparison before the authorized edits.

Repair ownership:

fresh-subject-negative-matrix-documentary-checker-and-failure-closeout

Authorized semantic changes are exactly:

A. Negative-matrix documentary checker

- never assume a deliberately mutated value retains its baseline object type;
- never call `.get()`, `.items()`, or object-only helpers without an exact
  type guard;
- evaluate acceptance from the schema validator outcome;
- evaluate rejection mechanism from retained validation errors;
- compare instance paths and schema keywords without dereferencing the invalid
  value as an object;
- preserve the invalid value’s actual type in the result;
- preserve every case’s expected acceptance and expected mechanism;
- treat checker exceptions as explicit harness failures, never as case passes;
- continue through all cases only when the checker remains structurally sound.

B. Safe JSON-pointer observation

Implement or repair a total pointer-observation helper that returns a tagged
result:

- present;
- absent;
- wrong-container-type;
- invalid-token;
- value and exact JSON type.

It must not throw merely because a mutation replaced an object with:

- list;
- string;
- number;
- Boolean;
- null.

C. Failure closeout

On any preterminal failure, execute a bounded `finally` path that:

- retains the exact first blocker;
- retains source and process identities;
- retains partial-artifact inventory;
- closes every child/process descriptor;
- reaps every child;
- inventories and cleans every reconstruction-owned fixture/cache root;
- observes ENOENT twice;
- repeats supplied-root closing equality for every opened supplied root;
- records package authority false;
- records terminal closure false;
- forbids same-root retry;
- does not generate success manifests;
- does not claim reconstruction readiness.

D. Fresh-root identities and output bindings

Regenerate only fresh-root-bound identities and paths.

Unauthorized changes:

- normative-contract bytes or interpretation;
- any schema byte;
- the fifteen-role schema set;
- the fourteen-family set;
- family-to-contract pointers;
- witness semantics;
- 946 case names;
- 946 expected acceptance values;
- 946 expected mechanisms;
- 137 contradiction-regression semantics;
- field-map rules;
- ten-role validator semantics;
- package manifest grammar;
- terminal package status semantics;
- implementation authority.

Retain:

analysis/reconstruction-parent-v1-v2-source-delta.json

For every changed hunk bind:

- old source range;
- new source range;
- exact defect;
- behavior before;
- behavior after;
- contract effect:
  none;
- schema effect:
  none;
- case-registry effect:
  none.

Require all unrelated functions AST-identical.

──────────────────────────────────────────────────────────────────────────────
8. NEGATIVE-CHECKER REPAIR REGRESSION
──────────────────────────────────────────────────────────────────────────────

Before executing the reconstruction parent, run a dedicated audit-owned
regression over the repaired checker.

It must not import reconstruction output state or historical result fixtures
as its oracle.

Retain:

validation/negative-matrix-checker-repair-regression-v1.json

Cover at minimum:

1. Baseline valid child-process record.
2. `/outcome` replaced by list.
3. `/outcome` replaced by null.
4. `/outcome` replaced by string.
5. `/outcome` replaced by Boolean.
6. `/prelaunch` replaced by list.
7. `/prelaunch` replaced by scalar.
8. Required object field absent.
9. Required scalar mistyped as object.
10. Required array mistyped as object.
11. Nested pointer traverses a list unexpectedly.
12. Nested pointer traverses null unexpectedly.
13. Unknown field added.
14. Schema validator returns multiple errors.
15. Expected-rejection keyword is first error.
16. Expected-rejection keyword is not first error but is present.
17. Expected mechanism absent.
18. Malformed JSON pointer token.
19. Pointer targets root.
20. Exact historical case:
    required-mistype:child-process:/outcome.

Require:

- twenty unique literal names;
- exact expected-name closure;
- no checker exception;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

The exact historical case must report:

- observed acceptance:
  false;
- expected acceptance:
  false;
- passed:
  true;
- mutated value type:
  array/list;
- rejection mechanism:
  exact accepted type-rejection mechanism.

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT CHECKER VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement an independently written validator that imports neither:

- the repaired checker;
- reconstruction-parent helpers;
- producer expected-result maps;
- producer fixture builders.

It must independently inspect:

- repaired source AST;
- type guards;
- pointer-observation totality;
- historical-case handling;
- the twenty-case regression result;
- preservation of the 946-case registry identity and expected semantics.

Retain:

validation/independent-negative-matrix-checker-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
10. REPAIRED SOURCE PREFLIGHT AND FREEZE
──────────────────────────────────────────────────────────────────────────────

Before executing the repaired parent:

1. Compile with pinned Python:

   /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
   -I
   -S
   -B

2. Require empty stdout/stderr and exit `0`.

3. Run AST/call-graph/dataflow review.

4. Require:

   - finite parent;
   - no stdin read;
   - no persistent loop;
   - no network;
   - no Git;
   - no shell;
   - no repository/product/target operation;
   - every child launch through one recorder;
   - checker type guards complete;
   - no mutation-case semantic drift;
   - failure closeout reachable for every preterminal exception;
   - success terminal protocol unchanged.

Retain:

opening/fresh-subject-reconstruction-parent-freeze-v1.json

Bind:

- repaired source identity;
- source delta;
- blocker reproduction;
- checker regression;
- independent checker validator;
- contract/schema input identities;
- later source modification permitted:
  false.

Reopen source no-follow and verify identity.

Do not modify it afterward.

──────────────────────────────────────────────────────────────────────────────
11. ONE-SHOT FRESH RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Execute the exact frozen repaired parent once.

Use pinned Python with:

-I
-S
-B

Use exact direct argv, cwd, environment, and DEVNULL stdin retained by the
reconstruction process contract.

Do not:

- retry;
- replace the parent;
- continue administratively;
- edit source after failure;
- resume the root;
- run a validator outside the parent after a failed run.

The parent must execute the entire reconstruction pipeline from the beginning.

No result from the failed reconstruction root may be copied as a current
result.

Root-independent specifications and case registries may be reused only after
exact identity authentication.

──────────────────────────────────────────────────────────────────────────────
12. REQUIRED RECONSTRUCTION PIPELINE
──────────────────────────────────────────────────────────────────────────────

The fresh parent must repeat all stages, including stages that passed in the
failed attempt:

1. Authenticate terminal historical decision.
2. Authenticate authoritative contract package.
3. Authenticate schema source and schema reconciliation.
4. Authenticate historical lineage inputs.
5. Retain complete artifact plan.
6. Copy normative contract exactly.
7. Copy all fifteen schemas exactly.
8. Generate exact fifteen-role schema registry.
9. Generate exact fourteen-family authority.
10. Generate schema-role/family mapping.
11. Validate all fifteen schemas against Draft 2020-12.
12. Freshly reconstruct all fourteen families.
13. Generate fresh contract-derived witnesses.
14. Generate fresh schema-derived witnesses.
15. Execute the complete 946-case negative matrix.
16. Execute the complete 137-case contradiction regression.
17. Generate the 766-leaf/333-row field map.
18. Generate all ten documentary-validator results.
19. Generate the exact ten-role documentary-validator registry.
20. Generate and validate the evidence DAG.
21. Run the fresh independent schema validator.
22. Generate confirmation evidence and its validator result.
23. Generate evidence-derived explicit confirmations.
24. Generate current-role occupancy.
25. Generate package status and authority.
26. Generate historical lineage.
27. Perform supplied-root closing equality.
28. Perform fixture/cache cleanup.
29. Finalize all nonmanifest outputs.
30. Generate and verify temporal inventory.
31. Generate and verify terminal manifests.
32. Independently reproject the final package.
33. Seal exactly once.
34. Perform no filesystem activity after seal.

No passing result from the failed reconstruction may substitute for a fresh
result.

──────────────────────────────────────────────────────────────────────────────
13. COMPLETE 946-CASE NEGATIVE MATRIX
──────────────────────────────────────────────────────────────────────────────

The fresh result must retain:

- exact registry identity;
- case count:
  946;
- unique case count:
  946;
- complete expected-name closure;
- every observed acceptance;
- every expected acceptance;
- every observed rejection mechanism;
- every expected mechanism;
- instance path;
- schema path;
- mutated value type;
- per-case pass;
- checker exception:
  absent.

Require:

- false acceptance count:
  0;
- false rejection count:
  0;
- reason mismatch count:
  0;
- skip count:
  0;
- checker exception count:
  0;
- pass:
  true.

The historical blocking case must pass as a correctly rejected mutation.

──────────────────────────────────────────────────────────────────────────────
14. COMPLETE FAILURE FINALIZATION
──────────────────────────────────────────────────────────────────────────────

Whether the fresh attempt succeeds or fails, the finite parent must retain:

- parent/source identity;
- complete child ledger;
- first blocker when any;
- partial-artifact inventory when any;
- fixture/cache cleanup;
- process/descriptor survivor results;
- supplied-root opening/closing equality;
- source-root equality;
- same-root retry forbidden;
- package authority false on failure.

On failure:

- do not create terminal success manifests;
- do not claim package readiness;
- exit nonzero;
- retain the failed root unchanged afterward.

A failure to execute closing equality or cleanup is:

PACKAGE_PROVENANCE_MISMATCH

rather than an ordinary blocked reconstruction.

──────────────────────────────────────────────────────────────────────────────
15. PACKAGE SEMANTIC REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

The fresh package must retain:

- exact normative contract bytes;
- exact fifteen current schema bytes;
- exactly fifteen current schema roles;
- exactly fourteen generated-record families;
- `normative-construction-parent` as the sole schema role without a generated
  record family;
- fourteen one-to-one family mappings;
- all fifteen schemas metaschema-valid;
- fourteen contract witnesses schema-valid;
- fourteen schema witnesses contract-valid;
- zero jointly unsatisfiable families;
- zero under-enforced baseline families;
- 946-case matrix pass;
- 137-case regression pass;
- 766/333 field-map closure;
- exactly ten documentary-validator roles;
- all ten current results fresh and passing;
- confirmation-evidence-map validator current and passing;
- current-role occupancy complete;
- implementation present false;
- implementation authority false;
- independent acceptance false before a later fresh audit.

No reconstruction result may claim independent package acceptance.

──────────────────────────────────────────────────────────────────────────────
16. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened,
including:

- failed reconstruction root;
- terminal historical reconciliation;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- any historical lineage root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every reconstruction-owned fixture or cache root:

- retain complete pre-removal inventory;
- remove the exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
17. PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the fresh-subject manifest grammar already selected by the terminal
historical decision:

- root row `"."` present exactly once;
- stable directory fields:
  device, gid, inode, kind, mode, path, uid;
- regular-file fields additionally:
  nlink, size, sha256;
- exact A/B self-exclusions;
- no mtime, ctime, directory size, or directory link count.

Use two independently authored reprojectors.

Use the final-namespace protocol:

1. Finalize every nonmanifest artifact.
2. Generate and verify temporal inventory.
3. Ensure reserved manifest directory exists.
4. Exclusively create zero-length A and B before either projection.
5. Retain both descriptors.
6. Fsync both empty files and manifest directory.
7. Generate A and B independently with both paths excluded.
8. Require generated bytes identical.
9. Write through retained descriptors.
10. Fsync and close both.
11. Fsync manifest directory.
12. Reopen no-follow.
13. Reverify path/inode/type/mode/link/size/hash.
14. Require A equals B.
15. Independently reproject final root.
16. Require root row present once.
17. Require no empty descendant.
18. Require no symlink, special object, or multi-link file.
19. Require modes `0700/0600`.
20. Require no cache or bytecode.
21. Seal exactly once.
22. After seal, allow only guarded terminal stream output and immediate
    nonreturning exit.

No write or read after seal.

──────────────────────────────────────────────────────────────────────────────
18. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

only when:

- repaired checker regression passes;
- independent checker validator passes;
- repaired source compiles, freezes, and remains unchanged;
- parent runs once;
- complete reconstruction pipeline passes;
- 946-case matrix passes;
- 137-case regression passes;
- field map closes;
- ten-role validation closes;
- independent schema validator passes;
- confirmation evidence closes;
- current-role occupancy closes;
- implementation remains absent;
- supplied roots close equal;
- cleanup closes;
- temporal inventory verifies;
- manifests verify;
- final reprojection passes;
- no write follows closure.

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

when:

- the bounded checker repair does not fix the exact blocker;
- another semantic validation lane fails;
- a normative family cannot be established;
- documentary authority remains ambiguous;
- package closure cannot complete without changing the contract or schemas.

Return:

PACKAGE_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source identity mismatch;
- source drift after freeze;
- opening/closing inequality;
- unaccounted child or filesystem effect;
- failure closeout omission;
- cleanup inequality;
- terminal package closure failure;
- write or read after seal.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh package-root identity
3. Failed reconstruction identity and disposition
4. Terminal historical decision authentication
5. Authoritative contract and schema input identities
6. Exact failed-parent source identity
7. Exact blocker reproduction
8. Exact checker exception and source range
9. Repaired-parent source identity
10. Exact bounded source delta
11. Negative-checker repair regression
12. Independent checker validator
13. Source compilation and static preflight
14. Parent source freeze
15. One-shot parent invocation and custody
16. Complete child-process ledger
17. Artifact-plan result
18. Normative contract preservation
19. Exact fifteen schemas
20. Exact fifteen-role registry
21. Exact fourteen generated families
22. Governing contract pointers for every family
23. Schema/family mapping
24. Fifteen-schema metaschema result
25. Fresh fourteen-family reconstruction
26. Contract-witness result
27. Schema-witness result
28. Complete 946-case matrix result
29. Historical blocker case result
30. Complete 137-case regression
31. Contract/schema field-map result
32. Exact ten-role documentary-validator registry
33. All ten fresh validator results
34. Documentary-validator evidence DAG
35. Fresh independent schema-validator result
36. Confirmation evidence and validator
37. Explicit confirmations
38. Current-role occupancy
39. Package status and authority
40. Historical lineage
41. Supplied-root closing equality
42. Fixture/cache cleanup
43. Failure-finalization result, whether used or not
44. Temporal-inventory identity
45. Manifest A identity
46. Manifest B identity
47. Independent terminal reprojection
48. Terminal membership and modes
49. Root-row presence
50. No-write-after-closure
51. Remaining uncertainty and nonclaims
52. Explicit confirmation registry

Required confirmations:

FAILED_RECONSTRUCTION_ROOT_MUTATION_NOT_PERFORMED
FAILED_RECONSTRUCTION_ROOT_NOT_RESUMED
FAILED_RECONSTRUCTION_ROOT_NOT_CLEANED
TERMINAL_HISTORICAL_DECISION_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
EXACT_FAILED_PARENT_SOURCE_AUTHENTICATED
EXACT_NEGATIVE_MATRIX_BLOCKER_REPRODUCED
SCHEMA_CORRECTLY_REJECTED_HISTORICAL_MUTATION
NEGATIVE_CHECKER_EXCEPTION_CAUSAL_IDENTIFIED
REPAIR_BOUNDED_TO_NEGATIVE_CHECKER_AND_FAILURE_CLOSEOUT
CONTRACT_SEMANTICS_UNCHANGED
ALL_FIFTEEN_SCHEMA_BYTES_UNCHANGED
NEGATIVE_CASE_REGISTRY_UNCHANGED
NEGATIVE_CASE_EXPECTATIONS_UNCHANGED
NEGATIVE_CHECKER_REPAIR_REGRESSION_PASSED
INDEPENDENT_NEGATIVE_CHECKER_VALIDATOR_PASSED
REPAIRED_PARENT_SOURCE_COMPILED
REPAIRED_PARENT_STATIC_PREFLIGHT_PASSED
REPAIRED_PARENT_SOURCE_FROZEN
REPAIRED_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
REPAIRED_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
PARENT_STDIN_NOT_READ
ALL_CHILDREN_ROUTED_THROUGH_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
EVERY_GENERATED_FAMILY_HAS_NORMATIVE_AUTHORITY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FRESH_FOURTEEN_FAMILY_RECONSTRUCTION_PASSED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_PASSED
HISTORICAL_BLOCKING_CASE_PASSED_AS_REJECTED_MUTATION
CONTRADICTION_REGRESSION_137_PASSED
CONTRACT_SCHEMA_FIELD_MAP_CLOSED
EXACTLY_TEN_CURRENT_DOCUMENTARY_VALIDATOR_ROLES
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_FRESH
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
DOCUMENTARY_VALIDATOR_EVIDENCE_GRAPH_ACYCLIC
INDEPENDENT_SCHEMA_VALIDATOR_PASSED
CONFIRMATION_EVIDENCE_MAP_PASSED
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
FAILURE_CLOSEOUT_CAPABLE
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FRESH_SUBJECT_TEMPORAL_INVENTORY_CREATED
FRESH_SUBJECT_TEMPORAL_INVENTORY_VERIFIED
FRESH_SUBJECT_MANIFEST_A_CREATED
FRESH_SUBJECT_MANIFEST_B_CREATED
FRESH_SUBJECT_MANIFESTS_BYTE_IDENTICAL
FRESH_SUBJECT_TERMINAL_REPROJECTION_PASSED
FRESH_SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

the next tranche is to construct and qualify a fresh independent-audit harness
bound to the new subject identity, with:

- explicit fifteen-schema-role and fourteen-family P06 predicates;
- an explicit P18 zero-root cleanup predicate using set equality and
  `count == 0`;
- one fresh full acceptance audit.

Do not begin construction-parent implementation before that fresh audit
accepts the reconstructed subject.
```

**Source:** Codex’s `CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED` report in this turn and the terminal reconstruction mandate established by the prior reconciliation.  
**Confidence:** 0.995 that the blocker is confined to the reconstruction checker; 0.99 that no contract or schema repair is justified; 0.98 that one fresh bounded source repair and reconstruction retry is the correct progression.
