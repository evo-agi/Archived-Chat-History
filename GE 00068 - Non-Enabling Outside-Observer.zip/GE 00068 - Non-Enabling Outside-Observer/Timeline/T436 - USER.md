Here is Codex's response:

1. **Primary verdict** — `QUALIFICATION_REPLAY_PROVENANCE_MISMATCH`.
2. **Mandatory next treatment** — `RETIRE_CANDIDATE_QUALIFICATION_LINEAGE`.

The replay retained the previously missing evidence and independently confirmed a Candidate 2 production defect. However, the replay capsule itself failed temporal-inventory verification before manifest creation. Capsule-closure failure mandates the primary verdict and treatment above; no further Candidate 2 replay is authorized.

3. **Fresh replay-root identity** — [replay capsule](/Users/ds/Downloads/ES-repair10i-v3-clean-parent-exact-qualification-replay-b6pbc620), device/inode `16777234/180821288`, mode `0700`. Bootstrap SHA-256: `3557be64b029c2324df1116174a4331fcfb43e6b9cdfe0717c3d2af6d5183586`.
4. **Failed repair-root identity and closure** — `/Users/ds/Downloads/ES-repair10i-v3-schema-subject-clean-parent-evidence-ownership-repair-no81sk4_`, device/inode `16777234/180805755`, mode `0700`. It remained immutable. Opening and closing inventories were identical: 121 rows, projection `a1fbb6c832883887308892d4752f0c224088a9d4669caceb50960cc8f740e838`. Its retained final report authenticated at SHA-256 `4dc3f1098b5796c2a3707c49dfb39192294142fdcb1dee21ccc7b2b10e71bb61`.
5. **Exact production-source registry** — All files were authenticated and copied byte-for-byte, mode `0600`, link count 1.

| PathBytesSHA-256                       |        |                                                                    |
| -------------------------------------- | ------ | ------------------------------------------------------------------ |
| `source/reconstruction_parent_v1.py`   | 28,564 | `75efcbb46ef7230e717880710ffad6f134a3b194f675d93c7871120b256f611b` |
| `source/process_recorder_v1.py`        | 2,814  | `791567d839755e0cd8eac2773cdd5e2b5734a9782600171978b1a7c30ebc3dd7` |
| `source/strict_json_v1.py`             | 5,628  | `b99a2e30100ea1d6af54c7d9a796a4cabf36faefd77e6674eb96741967d246aa` |
| `source/json_observation_v1.py`        | 3,454  | `3e4127193ff92e2dbad82a35dfc5f74019478d5993eba80538e0824df043ff2d` |
| `source/supplied_root_inventory_v1.py` | 2,915  | `bfb29efb83b0b093cedbab6c607f6e45f10ed16d211ee6758a31e2316e643067` |
| `source/manifest_projection_a_v1.py`   | 3,588  | `72673406941b036b0063bc8d616b500bc957c9085f431b4448ec9f20a4fa1071` |
| `source/manifest_projection_b_v1.py`   | 3,853  | `0cb66ced7e8181d0157a41c775399319e099097b110a3f094e6918c026a9ea6e` |
| `source/schema_engine_v1.py`           | 17,784 | `a921404efd8b789566c081e083b18795aaa66a5ed6691ce7bea9424693963aff` |
| `source/subject_model_v1.py`           | 21,985 | `3711dd7f13bbe9986cb88938b820e5f2a2fe9a1000769f99c2a3e6cc31e2b4be` |

6. **Exact qualification-source registry** — All seven files authenticated and copied byte-for-byte.

| PathBytesSHA-256                                            |         |                                                                    |
| ----------------------------------------------------------- | ------- | ------------------------------------------------------------------ |
| `validation/qualification_harness_v1.py`                    | 157,586 | `a4f206e41432ceefd445dd0e1c70925af4e70e84022b94c807c0242fcb57c626` |
| `validation/independent_external_interface_validator_v1.py` | 5,123   | `1c0a44777233fc22876b045c29be786881eefbf5df51b80b394822f5944bc35b` |
| `validation/independent_negative_matrix_validator_v1.py`    | 8,773   | `8e24d764878add303d4b2531b4fd9cc60f28a6dadf1d5ec68bc71b80adac3828` |
| `validation/independent_schema_subject_validator_v1.py`     | 13,453  | `9087c0109db5bc77366e312b610622f7f948ba4be72e91eface5c5ac67d47606` |
| `validation/independent_process_custody_validator_v1.py`    | 3,129   | `b7a351b0517f54a8a76e26c16fe82768e8529c01ffebf536d968b409d7e3e99f` |
| `validation/independent_rehearsal_validator_v1.py`          | 23,445  | `b810003b879ce3f2c26d25565509a86762d6ed0626eaec18aedda3e1bf567677` |
| `validation/terminal_manifest_reprojector_v1.py`            | 4,185   | `8a0ae1f57ba987df816827e583b99d57bc5ecca31cdb7a50e440ab10958d0c2f` |

7. **Authoritative supplied-input identities** — Contract root `16777234/180472094`; schema source `16777234/180513083`; schema reconciliation `16777234/180480821`; validation source `16777234/180576497`; all mode `0700`. The normative contract remained 32,038 bytes with SHA-256 `874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19`.
8. **Exact source-copy result** — Passed: 16 sources, zero missing, zero extra, zero mismatch, zero transformation, normalization, edit, or generated Candidate source. Evidence: [exact-candidate-source-copy-v1.json](/Users/ds/Downloads/ES-repair10i-v3-clean-parent-exact-qualification-replay-b6pbc620/opening/exact-candidate-source-copy-v1.json), SHA-256 `7df678142bbecf0ba88a61de540340e1ea570964ade65e51e780855b224e6672`.
9. **Replay-supervisor source identity** — `tooling/source_external_replay_supervisor_v1.py`, inode `180823797`, mode `0600`, 108,425 bytes, SHA-256 `b29afbf167774501946eaf91bfed2707d3f96012e64283a88bd03cffcd37f9bd`. Static import inspection found no Candidate production, qualification, recorder, projection, or expected-result helper imports.
10. **Supervisor custody preflight** — Passed all eight causals: nonexistent executable; zero/empty streams; nonzero with both streams; successful and unsuccessful dynamic roots; missing result; timeout/kill/reap; and evidence-before-cleanup with double ENOENT. Child ordinals `0–6` were contiguous. Evidence SHA-256: `087fda29700da28fdaf6f072c566b9533dbb2b91a5a6ab879666b3104d2f5f3e`.
11. **Exact rehearsal invocation contract** — Frozen before execution. Both parents used pinned Python with `-I -S -B`, the copied `source/reconstruction_parent_v1.py`, mode `reconstruct-subject`, an externally allocated subject root, its exact authority record, cwd equal to that root, explicit fixed environment, DEVNULL stdin, and 600-second timeout. The qualification harness was not used as parent. Contract SHA-256: `201196624950f2338546ed02919068991101653cdfe4c05b88396204e5a16e7f`.
12. **Rehearsal A identity** — `/Users/ds/Downloads/ES-repair10i-v3-clean-parent-replay-rehearsal-a-p7j62bp7`, device/inode `16777234/180826070`, mode `0700`.
13. **Rehearsal A parent process custody** — Ordinal 7, PID `35882`, exit `0`, no signal or timeout, reaped, descriptors closed. Stdout: 154 bytes, SHA-256 `a5c8c6f6f0a77954dc18ea7344ce992b6c2679f26f1ac79519d2a204bffdfa75`; stderr: empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Terminal output reported `rehearsal-passed-nonauthoritative`.
14. **Rehearsal A complete inventory and terminal result** — 70 inventory rows, projection `59e4aef01a69cabb6b2d3429a6d8e1000a34cf696a11f1549019627911472da0`. All 946 negative and 137 contradiction cases passed; 15 roles, 14 families, ten documentary validators, manifest A/B byte equality, terminal topology, modes, links, and postseal stability passed. Its temporal inventory failed independent reprojection because it omitted the later-created `closeout/` directory. Temporal SHA-256 `42e136dffdc22cd1613610d80add91b4756893941c049d598586ff2d96f51ce1`; manifest pair SHA-256 `75e18e5d81a7376b4f40b59a51f5c3558993795a7898e6104c3da48acd1c0265`.
15. **Rehearsal B identity** — `/Users/ds/Downloads/ES-repair10i-v3-clean-parent-replay-rehearsal-b-lx3isrf5`, device/inode `16777234/180826071`, mode `0700`.
16. **Rehearsal B parent process custody** — Ordinal 8, PID `35884`, exit `0`, no signal or timeout, reaped, descriptors closed. Stdout: 154 bytes, SHA-256 `0c7234c32fc44026b1228efba1d35c707b8defb949ec96d8cb4dd61ba2068f3d`; stderr empty. Terminal output reported `rehearsal-passed-nonauthoritative`.
17. **Rehearsal B complete inventory and terminal result** — 70 rows, projection `9fd4df0f24ccad9551e7ab903716356af03916415f5ae8812f109646e2b02c0d`. All substantive result lanes and terminal topology passed, but the same temporal-reprojection defect occurred. Temporal SHA-256 `8e9bfdc4e20391f4cab9d3e93be56a7cfcee0482ff09a373454c18a325236ac0`; manifest pair SHA-256 `0943122c0c369fce1712b19ae158214cea2dad97ff17d3ae958929c3df15a964`.
18. **Raw rehearsal-result adjudication** — Both parents exited successfully and generated all 58 planned files. Both source-external audits independently found exactly one error: `temporal-reprojection`. In each root, the retained temporal inventory contained 66 entries while the final projection, excluding the temporal file, required 67. The sole missing row was directory `closeout`. Evidence SHA-256: `a1103dc588852f1c2a1d307bf4f85f212a87e6669e510a14b89c8f94999fb5b8`.
19. **Independent-validator invocation contract** — The exact copied validator ran once under pinned Python with `-I -S -B`; operands were the replay capsule, rehearsal A, and rehearsal B; cwd was the capsule; timeout 900 seconds; roots were read-only to the validator. Its captured-result path was absent before launch and exclusively created. Contract SHA-256: `9a5de57f48250e62a531b043e006487ac42e378ea3650998dd2e46ee83c9e5f8`.
20. **Independent-validator process custody** — Ordinal 9, PID `35886`, exit `1`, no signal, no timeout, reaped, descriptors closed. Its complete process record authenticated at SHA-256 `e4a35474609974a6a4d03031c279d61b920112db74346690c17e4b0d6f23cad9`.
21. **Validator stdout identity and complete structured contents** — 1,555 bytes, SHA-256 `465c935ab4792e0556a40b928684ce4cab2086d53e120ba032c5cc29f93b683c`. It reported:
```
{
  "schema": "execution-substrate.schema-subject-clean-reconstruction-parent.independent-rehearsal-validator.v1",
  "implementation": "independently-authored-standard-library-only",
  "imports_production_modules": false,
  "imports_producer_qualification_helpers": false,
  "rehearsal_a": {
    "planned_artifact_count": 58,
    "observed_artifact_count": 58,
    "schema_role_count": 15,
    "generated_family_count": 14,
    "negative_case_count": 946,
    "contradiction_case_count": 137,
    "documentary_validator_count": 10,
    "errors": ["temporal-reprojection"],
    "error_count": 1,
    "pass": false
  },
  "rehearsal_b": {
    "planned_artifact_count": 58,
    "observed_artifact_count": 58,
    "schema_role_count": 15,
    "generated_family_count": 14,
    "negative_case_count": 946,
    "contradiction_case_count": 137,
    "documentary_validator_count": 10,
    "errors": ["temporal-reprojection"],
    "error_count": 1,
    "pass": false
  },
  "normalized_comparison": {
    "compared_artifact_count": 58,
    "normalized_difference_count": 0,
    "normalized_differences": [],
    "errors": [],
    "error_count": 0,
    "pass": true
  },
  "error_count": 2,
  "pass": false
}
```

22. **Validator stderr identity and complete contents** — Zero bytes; SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Complete text: empty.
23. **Validator result identity and complete findings** — Exact stdout bytes were retained as [independent-rehearsal-validator-result-v1.json](/Users/ds/Downloads/ES-repair10i-v3-clean-parent-exact-qualification-replay-b6pbc620/validation/independent-rehearsal-validator-result-v1.json), also 1,555 bytes and SHA-256 `465c935ab4792e0556a40b928684ce4cab2086d53e120ba032c5cc29f93b683c`. No finding was lost.
24. **Complete validator-error adjudication** — Two errors were retained and independently reproduced:
    - `rehearsal_a:0`, validator source line 305: `temporal-reprojection`; independently confirmed production-output defect.
    - `rehearsal_b:0`, validator source line 305: `temporal-reprojection`; independently confirmed production-output defect.

&#x20;  Causal mechanism: the parent projected the temporal inventory before `closeout/` existed, then created that directory while writing `closeout/temporal-final-inventory-v1.json`. Thus the retained temporal projection omitted a final directory row. No validator parser, invocation, or oracle defect was established. The retained adjudication’s generic `validator_used_correct_grammar:false` field conflicts with the agreement between validator and fresh audit; that record inconsistency is disclosed but does not change the independently observed production defect.

25. **Normalized rehearsal comparison** — Passed independently. All 58 artifacts compared with zero unexplained difference after only permitted physical normalization. The Candidate validator’s comparison and the source-external comparison agreed. Evidence SHA-256: `ae3d65074498521498efd6740a2c69cfd89d932e9ebdc08a6fab9fabe413cee0`.
26. **Candidate 2 terminal classification** — The retained preclosure classifier recorded `PRODUCTION_CANDIDATE_DEFECT_CONFIRMED`. Both exact executions reproduce the same temporal-inventory construction defect; the independent validator is not the cause.
27. **Mandatory next-treatment rationale** — Although the production defect is independently established, the replay capsule then repeated an analogous ordering error in its own temporal closure: it projected before creating its `closeout/` directory. Because capsule closure failed, the requested rules require retiring the entire Candidate 2 qualification lineage rather than relying on the preclosure classification or authorizing another replay.
28. **Evidence-retention result** — Passed before cleanup. Complete 58-file copies of both roots were retained inside the capsule; A copy registry digest `a8f59018ebe438b322eb6facb4d4dd36efdba90017eb367e6603555d2527f6ed`, B `9b96c6836d8570d3ba45b0054d668764cb5381ff311cf84f0fad527c7e52f857`. Parent processes, streams, inventories, validator inputs/result/streams, raw and error adjudications, normalized comparison, classification, and treatment were all retained. Evidence-record SHA-256: `5c6436738f2baa51d2c3c6e9d527a664fe34b09d4069b12a8db2a088ef41a854`.
29. **Rehearsal cleanup and double-ENOENT result** — Passed. Both exact original identities were revalidated; A and B were removed only after evidence retention; each produced `ENOENT` twice. Created, inventoried, retained-evidence, cleanup, and twice-absent root sets were equal. SHA-256: `7d2bb0d28fad48c39f7864f97832af382c348f4bd3f7e7d9aa47734ccb28d681`.
30. **Complete child-process ledger** — Ten contiguous ordinals; every created child reaped and all descriptors closed.

| OrdinalChildExitTimeout |                                  |                        |     |
| ----------------------- | -------------------------------- | ---------------------- | --- |
| 0                       | nonexistent-executable preflight | spawn failure retained | no  |
| 1                       | zero/empty-stream preflight      | 0                      | no  |
| 2                       | nonzero/both-stream preflight    | 7                      | no  |
| 3                       | dynamic-root success preflight   | 0                      | no  |
| 4                       | dynamic-root nonzero preflight   | 9                      | no  |
| 5                       | missing-result preflight         | 0                      | no  |
| 6                       | timeout preflight                | signal 9               | yes |
| 7                       | rehearsal A parent               | 0                      | no  |
| 8                       | rehearsal B parent               | 0                      | no  |
| 9                       | independent validator            | 1                      | no  |

Ledger SHA-256: `23e4a0b5bbead077088b129df20b8562df4214d1150fb078e5360e68f62530a7`.

31. **Supplied-root closing equality** — Passed for all five opened roots.

| RootRowsOpening/closing projection |     |                                                                    |
| ---------------------------------- | --- | ------------------------------------------------------------------ |
| Failed repair root                 | 121 | `a1fbb6c832883887308892d4752f0c224088a9d4669caceb50960cc8f740e838` |
| Contract package                   | 77  | `daa4d205f44aac24a0689c5a03e97fb2a93875d7785ababf7ce25a42fe086f38` |
| Schema source                      | 67  | `2d32fa214d08b0dd98032d8ad2232e01197d8225b9179cef6d11039a96de9d8c` |
| Schema reconciliation              | 37  | `f850f1b79b2d535b7759716e57fe2e6150ef505081a378fb24651c33a09510a6` |
| Validation source                  | 85  | `6184b1764acc92e30579bfbd63d483fa6154f36a6516b4664c0ac58110fc38d4` |

32. **Replay temporal-inventory identity** — A file was created at `closeout/temporal-final-inventory-v1.json`: 59,444 bytes, SHA-256 `505c62c43c6dc017b31180476dd02f3de56beeb8e4dddc8ee066375be4832f09`, 245 projected entries. Its internal `verified:true` assertion did not survive immediate independent reprojection because its projection omitted the newly created `closeout/` directory. It is failure evidence, not a verified terminal inventory.
33. **Replay manifest A identity** — Not created.
34. **Replay manifest B identity** — Not created.
35. **Independent replay-capsule reprojection** — Not reached. Temporal reprojection failed before manifest placeholders were created.
36. **Terminal membership and modes** — No terminal closure occurred. Terminal empty-directory, object-kind, link, and mode claims are therefore not established, even though preclosure evidence used modes `0700/0600` and retained no cache or bytecode.
37. **No-write-after-closure** — Not established because no terminal seal occurred. The supervisor wrote the explicit failure outcome after temporal verification failed; no success seal or manifest was produced.
38. **Remaining uncertainty and nonclaims** — There is no remaining ambiguity about the reproduced Candidate defect: both roots and the independent validator agree on the missing `closeout` temporal row. The replay nevertheless cannot be promoted as a qualifying terminal result because its own closure failed. The preclosure report is superseded by [replay-failure-outcome-v1.json](/Users/ds/Downloads/ES-repair10i-v3-clean-parent-exact-qualification-replay-b6pbc620/closing/replay-failure-outcome-v1.json), SHA-256 `c1249f41672d41dea05ca66d86763ca68940ee7219d2cfc645168593e3a20f8c`. No current subject, product process, target audit, runtime validation, deployment, A6 activity, or further replay occurred.
39. **Explicit confirmation registry**
    - **Confirmed true:** `FAILED_REPAIR_ROOT_MUTATION_NOT_PERFORMED`, `EXACT_CANDIDATE_2_PRODUCTION_SOURCE_REGISTRY_AUTHENTICATED`, `EXACT_CANDIDATE_2_QUALIFICATION_SOURCE_REGISTRY_AUTHENTICATED`, `CANDIDATE_2_SOURCE_BYTES_NOT_MODIFIED`, `CANDIDATE_2_SOURCE_REPAIR_NOT_PERFORMED`, `AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED`, `SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED`, `SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED`, `VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED`, `SOURCE_EXTERNAL_SUPERVISOR_USED`, `SUPERVISOR_IMPORTS_NO_CANDIDATE_HELPERS`, `SUPERVISOR_CUSTODY_PREFLIGHT_PASSED`, `EXACT_REHEARSAL_INVOCATION_FROZEN`, `REHEARSAL_A_EXECUTED_EXACTLY_ONCE`, `REHEARSAL_B_EXECUTED_EXACTLY_ONCE`, `REHEARSAL_ROOTS_PHYSICALLY_DISTINCT`, `REHEARSAL_A_PROCESS_CUSTODY_COMPLETE`, `REHEARSAL_B_PROCESS_CUSTODY_COMPLETE`, `REHEARSAL_A_COMPLETE_INVENTORY_RETAINED`, `REHEARSAL_B_COMPLETE_INVENTORY_RETAINED`, `REHEARSAL_A_STREAMS_RETAINED`, `REHEARSAL_B_STREAMS_RETAINED`, `REHEARSAL_A_TERMINAL_POSTURE_ADJUDICATED`, `REHEARSAL_B_TERMINAL_POSTURE_ADJUDICATED`, `INDEPENDENT_VALIDATOR_EXECUTED_EXACTLY_ONCE`, `INDEPENDENT_VALIDATOR_PROCESS_CUSTODY_COMPLETE`, `INDEPENDENT_VALIDATOR_STDOUT_RETAINED`, `INDEPENDENT_VALIDATOR_STDERR_RETAINED`, `INDEPENDENT_VALIDATOR_RESULT_RETAINED`, `EVERY_VALIDATOR_ERROR_RETAINED`, `EVERY_VALIDATOR_ERROR_INDEPENDENTLY_ADJUDICATED`, `TWO_REHEARSALS_NORMALIZED_COMPARISON_COMPLETED`, `CANDIDATE_2_TERMINAL_CLASSIFICATION_COMPLETE`, `MANDATORY_NEXT_TREATMENT_SELECTED`, `REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP`, `REHEARSAL_A_DOUBLE_ENOENT_RETAINED`, `REHEARSAL_B_DOUBLE_ENOENT_RETAINED`, `REHEARSAL_CLEANUP_SET_EQUALITY_PASSED`, `CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS`, `ALL_CREATED_CHILDREN_REAPED`, `ALL_CHILD_DESCRIPTORS_CLOSED`, `NO_PROCESS_SURVIVOR`, `NO_DESCRIPTOR_SURVIVOR`, `NO_CACHE_OR_BYTECODE_RETAINED`, `SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED`, `CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED`, `PROCESS_SELF_TEST_NOT_EXECUTED`, `CONSTRUCT_MODE_NOT_EXECUTED`, `NO_TARGET_AUDIT_EXECUTED`, `NO_RUNTIME_VALIDATION_RERUN`, `REPLAY_CAPSULE_TEMPORAL_INVENTORY_CREATED`, `NO_NETWORK_CONTACT`, `NO_GIT_INVOCATION`, `NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION`, `NO_A6_ACTIVITY`, `NO_SUBAGENTS_CREATED`.
    - **False or not established:** `REPLAY_CAPSULE_MANIFEST_A_CREATED`, `REPLAY_CAPSULE_MANIFEST_B_CREATED`, `REPLAY_CAPSULE_MANIFESTS_BYTE_IDENTICAL`, `REPLAY_CAPSULE_TERMINAL_REPROJECTION_PASSED`, `NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE`, `NO_SYMLINK_OR_SPECIAL_OBJECT`, `NO_MULTIPLY_LINKED_FILE`, `ALL_DIRECTORY_MODES_0700`, `ALL_FILE_MODES_0600`, `NO_WRITE_AFTER_TERMINAL_CLOSURE`.
