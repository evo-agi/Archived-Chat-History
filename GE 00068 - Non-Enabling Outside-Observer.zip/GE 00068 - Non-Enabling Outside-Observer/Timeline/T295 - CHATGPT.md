## Assessment

The reconciliation is decisive: **the launcher and launch contracts satisfied every Carrier 0002 requirement.** The only failure was the payload oracle at line 48:

```python
env == launch["fixed_environment"]
```

That assertion incorrectly required the entire post-`execve` environment to contain exactly six keys. The launcher supplied the exact six-key mapping, but the executed Python process also observed the platform-added:

```text
__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0
```

Every contract-owned key and value was correct. Same-PID execution passed, the complete wrapper CLI passed, `--expected-wrapper-sha256` appeared exactly once, fixed `PATH` passed, and validator A passed all 30 cases.

The correct predicate is:

```python
constructed["fixed_environment"] == launch["fixed_environment"] and all(
    env.get(key) == value
    for key, value in launch["fixed_environment"].items()
)
```

Additional post-exec keys should be retained as diagnostics, not used to fail qualification. That preserves the real authority boundary:

- the **launcher** owns the exact environment supplied to `execve`;
- the **payload** verifies every contract-owned value survived;
- platform/runtime additions after `execve` do not retroactively change the launcher’s supplied mapping.

One adjustment is needed to Codex’s recommendation: the launcher, CLI contract, and request contract can likely remain byte-identical, but the launch-contract instance embeds physical-root paths. A fresh qualification root therefore requires an **explicitly recorded root rebinding**, not a false claim that every contract byte was preserved. All normalized non-root semantics must remain identical.

The next tranche is a fresh, complete launcher qualification with only the payload oracle corrected. The full V3 audit should remain blocked until that package returns `WRAPPED_CARRIER_LAUNCHER_READY`.

## Codex prompt

```text
FRESH WRAPPED-CARRIER LAUNCHER QUALIFICATION —
PAYLOAD-ORACLE CORRECTION ONLY

Create and fully qualify a new immutable wrapped-carrier launcher package.

This is a bounded source-external launcher-qualification repair.

Do not modify any supplied root.
Do not resume or repair the failed qualification root.
Do not modify the accepted generic wrapper.
Do not inspect any candidate repository, Strategic B root, V1/V2/V3 capsule,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not use the network.
Do not create subagents.
Do not begin the full V3 audit.

Return exactly one primary verdict:

WRAPPED_CARRIER_LAUNCHER_READY
WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE
LAUNCHER_QUALIFICATION_PROVENANCE_MISMATCH

OBJECTIVE

Produce a fresh launcher-qualification package that:

1. preserves the already validated launcher algorithm;
2. preserves the exact wrapper CLI and request-contract semantics;
3. explicitly rebinds only physical qualification-root paths;
4. corrects only the Carrier 0002 post-exec environment oracle;
5. runs the complete qualification sequence:
   - valid Carrier 0002;
   - intentional SyntaxError Carrier 0003;
   - successful recovery Carrier 0004;
   - complete closeout Carrier 0005;
6. executes both independent static launch-conformance validators;
7. proves process, environment, PID, phase-record, cleanup, and capsule
   continuity;
8. produces one immutable accepted launcher package for the later full V3
   audit.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

ACCEPTED_GENERIC_WRAPPER_ROOT:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Accepted wrapper:

provenance/phase_runner.py

Required identity:

- size:
  15300 bytes
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- regular:
  true
- links:
  1
- physical mode:
  0600

FAILED_QUALIFICATION_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualification-kb6zyh_o

Treat this root as immutable, incomplete, and nonqualifying.

Use it only as bounded source input for:

- launcher source;
- phase-runner CLI contract;
- carrier-request contract;
- launch-contract semantics;
- Carrier 0002 request and constructed-launch records;
- validator A and B sources;
- Carrier 0003, 0004, and 0005 payload sources when retained;
- the exact defective Carrier 0002 payload source;
- phase and result evidence needed to bind the repair.

Do not resume, clean, repair, or write into it.

ROOT_CAUSE_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-failure-reconciliation-c4uoh34p

Consume and independently verify at minimum:

analysis/root-cause-record.json
analysis/artifact-ledger.json
analysis/wrapper-cli-adjudication.json
analysis/payload-assertion-ledger.json
analysis/same-pid-adjudication.json
analysis/fixed-environment-adjudication.json
analysis/static-matrix-adjudication.json
analysis/requirement-traceability.json
analysis/exact-recommended-next-tranche.json
closeout/final-report.md
closeout/final-inventory.json

Do not treat its verdict as a substitute for fresh qualification.

PINNED PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Interpreter permission bits, uid/gid, device/inode, timestamps, xattrs, flags,
and ancestor posture are report-only.

Do not reject mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
2. PREDECESSOR DEFECT TO REPRODUCE
──────────────────────────────────────────────────────────────────────────────

Independently reproduce that the predecessor Carrier 0002 reached payload
execution and failed only because:

payloads/carrier-0002-valid.py

used the predicate:

env == launch["fixed_environment"]

The predecessor observed:

- every contract-owned key with the exact required value;
- one additional post-exec key:
  `__CF_USER_TEXT_ENCODING`;
- same launcher and payload PID;
- complete wrapper CLI;
- expected-wrapper SHA exactly once;
- successful validator A;
- successful launcher-side conformance.

Confirm that no other independent Carrier 0002 predicate failed.

Stop with `LAUNCHER_QUALIFICATION_PROVENANCE_MISMATCH` if that causal cannot be
reproduced from immutable retained bytes.

──────────────────────────────────────────────────────────────────────────────
3. FRESH QUALIFICATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-wrapped-carrier-launcher-qualified-

Retain and emit the exact root path before later checks.

Recommended structure:

opening/
source/
contract/
payloads/
validation/
provenance/
closeout/
manifest/
private/

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No retained empty directory, symlink, special object, or multiply linked file
is permitted.

──────────────────────────────────────────────────────────────────────────────
4. EXACT SOURCE AND CONTRACT PRESERVATION
──────────────────────────────────────────────────────────────────────────────

A. Launcher source

Copy the predecessor launcher source byte-for-byte.

Require exact predecessor size and SHA-256 from the immutable failed
qualification root and reconciliation ledger.

No launcher source change is authorized.

B. Wrapper CLI contract

Copy the phase-runner CLI contract byte-for-byte when it contains no
root-specific value.

If it contains a physical qualification-root value, rebind only that exact
value and retain a normalized semantic-equivalence record.

C. Carrier-request contract

Copy byte-for-byte unless an exact physical-root binding requires rebinding.
Any rebinding must be separately identified by JSON pointer and normalized
equivalence.

D. Launch-contract instance

A fresh root necessarily changes physical values such as:

- wrapper absolute path;
- qualification-root absolute path;
- private HOME;
- private TMPDIR;
- any launcher or audit-root absolute path.

Create a fresh launch-contract instance by changing only the closed set of
root-bound fields.

Retain:

contract/launch-contract-root-rebinding-v1.json

For every changed field record:

- JSON pointer;
- predecessor value;
- successor value;
- classification:
  `physical-root-rebinding-only`;
- semantic effect:
  none.

Create normalized predecessor and successor projections by replacing the two
physical roots with `${QUALIFICATION_ROOT}`.

Require those normalized projections to be byte-identical.

Any non-root-bound launch-contract difference blocks qualification.

E. Wrapper source

Copy the exact accepted wrapper bytes and preserve mode 0600.

Do not modify the wrapper.

──────────────────────────────────────────────────────────────────────────────
5. PAYLOAD-ORACLE CORRECTION
──────────────────────────────────────────────────────────────────────────────

Create a corrected Carrier 0002 payload from the exact predecessor source.

Outside unavoidable physical-root rebinding, the only authorized semantic
source change is replacement of the defective whole-map environment predicate.

Replace:

```python
env == launch["fixed_environment"]
```

with the equivalent of:

```python
constructed["fixed_environment"] == launch["fixed_environment"] and all(
    env.get(key) == value
    for key, value in launch["fixed_environment"].items()
)
```

Required semantics:

1. The environment mapping constructed for `execve` must equal the launch
   contract’s fixed environment exactly.
2. Every contract-owned key must be observed with the exact required value in
   the payload.
3. Additional post-exec keys are diagnostics only.
4. Additional keys do not redefine the launcher input.
5. Additional keys do not fail qualification.
6. Missing or changed contract-owned keys fail qualification.
7. A constructed environment that differs from the launch contract fails.
8. No exact additional-key name is required for success.

Retain additional post-exec keys in sorted diagnostic form. Do not emit secret
values. The observed `__CF_USER_TEXT_ENCODING` key may be reported but must not
be hardcoded as required.

Retain:

- exact predecessor payload identity;
- exact corrected payload identity;
- unified source delta;
- normalized root-independent semantic delta;
- proof that the environment predicate is the only semantic change.

Stop with `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` if another payload semantic
change is required.

──────────────────────────────────────────────────────────────────────────────
6. ENVIRONMENT-ORACLE CAUSALS
──────────────────────────────────────────────────────────────────────────────

Before Carrier 0002, run one audit-owned in-memory validator over the corrected
environment predicate.

Require:

1. Exact constructed mapping and exact observed mapping:
   accepted.
2. Exact constructed mapping and observed mapping with one additional key:
   accepted with diagnostic.
3. Missing required observed key:
   rejected.
4. Changed required observed value:
   rejected.
5. Constructed mapping missing required key:
   rejected.
6. Constructed mapping with changed required value:
   rejected.
7. Constructed mapping with an additional key not in the launch contract:
   rejected.
8. Multiple additional post-exec observed keys:
   accepted with sorted diagnostics.

Retain validator source and complete mechanism-specific result.

This validator must not execute the launcher or wrapper and must inspect no
target content.

──────────────────────────────────────────────────────────────────────────────
7. PRESERVE THE TWO STATIC LAUNCH VALIDATORS
──────────────────────────────────────────────────────────────────────────────

Copy validator A and validator B source byte-for-byte from the failed
qualification root.

If physical-root rebinding is unavoidable, permit only a closed path rebinding
with normalized semantic equality.

Do not weaken, remove, or reinterpret any existing case.

Require:

- validator A runs during Carrier 0002;
- validator B runs during Carrier 0004;
- both have the expected complete case set;
- both pass;
- both agree on every shared case;
- zero false acceptance.

Retain exact source and result identities.

──────────────────────────────────────────────────────────────────────────────
8. QUALIFICATION PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

Use:

pinned Python
→ qualified launcher
→ same-PID execve
→ pinned Python
→ mode-0600 phase runner
→ retained payload

Do not invoke the wrapper directly.
Do not invoke a payload directly.
Do not use a shell fallback.
Do not use PATH lookup for interpreter or wrapper.
Do not chmod any Python source.

Fixed environment must come only from the launch contract:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<QUALIFICATION_ROOT>/private/home
TMPDIR=<QUALIFICATION_ROOT>/private/tmp

Per-carrier requests must not repeat or override invariant launch fields.

The constructed wrapper argv must include every required CLI option, including
exactly one:

--expected-wrapper-sha256
6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

──────────────────────────────────────────────────────────────────────────────
9. CARRIER 0001 — BOOTSTRAP
──────────────────────────────────────────────────────────────────────────────

Carrier 0001 is the sole bootstrap exception.

It must:

- retain and emit the fresh root;
- verify all immutable inputs;
- copy the wrapper and launcher;
- create contracts and root-rebinding evidence;
- create payload and validator sources;
- create exact source-identity records;
- create the initial carrier requests;
- inspect no unrelated target.

Retain bootstrap-start and bootstrap-outcome records.

──────────────────────────────────────────────────────────────────────────────
10. CARRIER 0002 — CORRECTED VALID QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Carrier 0002 must run the corrected valid payload.

Require:

- complete constructed-launch record;
- complete phase-start and phase-outcome;
- parser admission;
- payload read, compile, and execution;
- expected-wrapper SHA exactly once and exact;
- no required or unknown wrapper option error;
- same launcher and payload PID;
- exact constructed environment;
- exact contract-owned observed values;
- additional observed environment keys diagnostic only;
- validator A pass;
- no child process;
- no target inspection;
- payload result mode 0600;
- payload returns success;
- wrapper exits success.

Any Carrier 0002 failure makes the qualification nonqualifying. Do not retry
inside the same root.

──────────────────────────────────────────────────────────────────────────────
11. CARRIER 0003 — INTENTIONAL SYNTAX ERROR
──────────────────────────────────────────────────────────────────────────────

Use the exact retained predecessor SyntaxError payload when present and
authenticated.

Require:

- same launcher and contracts;
- complete constructed-launch record;
- complete phase-start and phase-outcome;
- payload identity exact;
- compilation begins;
- deterministic SyntaxError identity retained;
- payload execution does not begin;
- expected result is absent;
- wrapper records the failure completely;
- no process-record gap.

The expected SyntaxError is a qualifying causal, not a package failure.

──────────────────────────────────────────────────────────────────────────────
12. CARRIER 0004 — RECOVERY SUCCESS
──────────────────────────────────────────────────────────────────────────────

Use the exact retained predecessor recovery payload when authenticated.

Require:

- same launcher and contracts;
- successful execution after Carrier 0003;
- same-PID proof;
- fixed-environment proof using the corrected observation semantics;
- validator B pass;
- validator A/B result agreement;
- expected result created at mode 0600;
- complete phase records;
- no target inspection.

──────────────────────────────────────────────────────────────────────────────
13. CARRIER 0005 — CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

Carrier 0005 must:

- verify Carriers 0001–0004;
- verify the environment-oracle causal matrix;
- verify validator A and B;
- verify source and contract identities;
- verify root-rebinding closure;
- verify every request lacks invariant overrides;
- verify every constructed wrapper argv;
- verify same launcher, interpreter, wrapper, flags, and fixed environment;
- verify complete phase continuity;
- verify no process or descriptor survivor;
- remove only `private/`;
- perform two fresh `lstat` calls on the exact removed path;
- require ENOENT twice;
- create the carrier index, process audit, cleanup record, and closeout report.

Its own phase records must complete through the wrapper.

──────────────────────────────────────────────────────────────────────────────
14. CARRIER AND CONSTRUCTED-LAUNCH RECORDS
──────────────────────────────────────────────────────────────────────────────

For every wrapped carrier retain:

- carrier request;
- constructed-launch record;
- launcher identity;
- launch-contract identity;
- request-contract identity;
- request identity;
- interpreter identity;
- interpreter flags;
- wrapper identity and mode;
- complete argv;
- complete fixed environment;
- submitted cwd;
- launcher PID;
- payload PID when reached;
- same-PID adjudication;
- required-option set;
- generated-option set;
- missing/unknown/duplicate options;
- expected-wrapper-SHA occurrence count and value;
- phase-start;
- phase-outcome;
- artifacts;
- discrepancy status.

Require zero missing required options, unknown options, or duplicate
single-value options on valid carriers.

──────────────────────────────────────────────────────────────────────────────
15. FAILED ROOTS AND ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Treat the prior failed qualification root as immutable historical evidence.

Do not copy its primary verdict as current truth.

Retain every new failed or superseded qualification attempt separately.

No failed attempt may contribute:

- current source identity;
- final pass count;
- final carrier result;
- final manifest identity;
- acceptance.

Do not overwrite a failed artifact.

──────────────────────────────────────────────────────────────────────────────
16. CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Create a complete immutable qualification capsule.

Use two independently implemented lstat/no-follow manifest generators.

Require:

- root and every retained directory represented;
- every nonmanifest file represented;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- independent manifests byte-identical.

Finalize:

- wrapper CLI contract;
- launch contract;
- request contract;
- root-rebinding record;
- environment-observation policy;
- corrected payload and source delta;
- environment-oracle validator and result;
- accepted wrapper copy;
- launcher source;
- both launch validators and results;
- all requests;
- all constructed-launch records;
- all phase records;
- all payloads and results;
- carrier index;
- process audit;
- cleanup record;
- final report;
- final inventory;
- manifest pair.

──────────────────────────────────────────────────────────────────────────────
17. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return `WRAPPED_CARRIER_LAUNCHER_READY` only if:

- predecessor failure is reproduced exactly;
- launcher source remains semantically unchanged;
- CLI/request semantics remain unchanged;
- launch-contract changes are root-binding only;
- the corrected payload has only the authorized semantic change;
- environment-oracle causals pass;
- Carrier 0002 passes;
- Carrier 0003 records the expected SyntaxError completely;
- Carrier 0004 succeeds;
- validators A and B pass;
- same-PID behavior passes;
- fixed-environment behavior passes under corrected semantics;
- every carrier uses the same launcher and contracts;
- phase and carrier records are complete;
- cleanup passes;
- capsule closure passes;
- no acceptance-affecting residual finding remains.

Return `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` for a substantive launcher,
wrapper-interface, contract, or payload limitation that cannot be repaired
within this exact bounded tranche.

Return `LAUNCHER_QUALIFICATION_PROVENANCE_MISMATCH` for input drift,
supplied-root mutation, missing indispensable input, process-record gaps,
carrier ambiguity, or closing inequality.

Do not begin the full V3 audit.

──────────────────────────────────────────────────────────────────────────────
18. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh qualification-root identity
3. Immutable input identities
4. Predecessor defect reproduction
5. Exact authorized source delta
6. Root-binding changes and normalized equivalence
7. Corrected environment-observation policy
8. Environment-oracle causal matrix
9. Launcher and contract identities
10. Carrier 0002 result
11. Carrier 0003 SyntaxError result
12. Carrier 0004 recovery result
13. Validator A/B results
14. Same-PID adjudication
15. Fixed-environment adjudication
16. Constructed-argv adjudication
17. Carrier and phase continuity
18. Failed/superseded attempts
19. Cleanup and two exact-path ENOENT observations
20. Capsule closure and manifest identities
21. Severity-ranked residual findings
22. Remaining uncertainty and nonclaims
23. Explicit confirmations

Required confirmations:

GENERIC_WRAPPER_INPUT_NOT_MUTATED
FAILED_QUALIFICATION_ROOT_NOT_MUTATED
ROOT_CAUSE_RECONCILIATION_ROOT_NOT_MUTATED
LAUNCHER_SOURCE_SEMANTICS_NOT_CHANGED
CLI_CONTRACT_SEMANTICS_NOT_CHANGED
REQUEST_CONTRACT_SEMANTICS_NOT_CHANGED
LAUNCH_CONTRACT_ONLY_ROOT_REBOUND
PAYLOAD_ORACLE_ONLY_SEMANTIC_CHANGE
CONSTRUCTED_ENVIRONMENT_EQUALS_LAUNCH_CONTRACT
ALL_CONTRACT_OWNED_ENVIRONMENT_VALUES_OBSERVED
ADDITIONAL_POST_EXEC_ENVIRONMENT_KEYS_DIAGNOSTIC_ONLY
ENVIRONMENT_ORACLE_CAUSALS_PASSED
EXPECTED_WRAPPER_SHA_ARGUMENT_PRESENT_EXACTLY_ONCE
VALID_CARRIER_0002_PASSED
SYNTAX_ERROR_CARRIER_0003_COMPLETELY_RECORDED
RECOVERY_CARRIER_0004_PASSED
VALIDATOR_A_PASSED
VALIDATOR_B_PASSED
LAUNCHER_USED_SAME_PID_EXEC_TO_WRAPPER
WRAPPER_RETAINED_MODE_0600
WRAPPER_NOT_EXECUTED_DIRECTLY
ALL_WRAPPED_CARRIERS_USED_SAME_LAUNCH_CONTRACT
TOP_LEVEL_PHASE_RECORDS_COMPLETE_AND_CONTIGUOUS
PRIVATE_SUBTREE_REMOVED
TWO_EXACT_PRIVATE_PATH_ABSENCE_OBSERVATIONS_COMPLETED
TARGET_CONTENT_NOT_INSPECTED
CANDIDATE_GIT_NOT_INVOKED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
FULL_V3_AUDIT_NOT_STARTED
SUBAGENTS_CREATED: 0
```

After—and only after—`WRAPPED_CARRIER_LAUNCHER_READY`, issue a fresh full V3 independent-audit prompt that consumes the qualified launcher package as an immutable input. Do not reconstruct the launcher or qualification oracle inside that audit.

**Source:** Codex’s read-only Carrier 0002 failure reconciliation above.

**Confidence:** 0.999 that the sole causal defect was the whole-environment equality oracle; 0.995 that the launcher and contracts require no semantic change; 0.98 that one fresh complete qualification with the corrected payload is sufficient before returning to the V3 audit.
