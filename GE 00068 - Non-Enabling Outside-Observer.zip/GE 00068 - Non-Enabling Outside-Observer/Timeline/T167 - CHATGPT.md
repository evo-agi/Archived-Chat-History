## Assessment

The validator repair itself appears substantively successful. The audit independently confirmed generic authority-family scanning, all 38 contradiction cases, four clean 89-test suites, unchanged governing/runtime inputs, fresh A6D and amendment compatibility, synthetic A6, and the SEC-02 regression. **No patch defect was found.**

The audit is nevertheless nonqualifying for two independent reasons:

1. Its own Python import created ignored repository artifacts:
   - `tools/evidence_verify/__pycache__/`
   - `tools/evidence_verify/__pycache__/test_verify_v1.cpython-313.pyc`
2. Two auditors performed prohibited reads relative to the primary checkout.

The second issue cannot be cured inside that audit. The first must be removed before another audit. Therefore:

- **Do not repeat or modify the one-file repair.**
- **Do not change the canonical manifest.**
- **Do not relabel the failed audit as accepted after cleanup.**
- Perform one exact artifact-restoration turn.
- Then conduct a completely fresh independent audit against the same `4a3a4244…18537` manifest, with stricter bytecode and cwd controls.

The implementation closeout had already established a 477-object repository snapshot with no bytecode or cache and bound the repaired patch to canonical manifest `4a3a4244…18537`.  The audit protocol permits removing only audit-created artifacts and otherwise requires a stop when cleanup would mutate repository state; that is why a separately authorized cleanup turn is now required.  Project provenance guidance explicitly classifies `__pycache__` and `.pyc` files as artifacts to remove when created by the current activity, while forbidding deletion of unrelated pre-existing artifacts. 

## Codex prompt: exact audit-artifact restoration

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete restoration report inline in
Markdown.

Do not return only:

- a verdict;
- a summary;
- a link to a report;
- or “full report available at …”.

Supplemental evidence links may follow the complete inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh, parent-only workspace-write Codex conversation.

Do not resume:

- the failed independent audit;
- the alternate-authority implementation task;
- any earlier Evidence Verification conversation.

Do not spawn subagents. You are the sole actor.

Objective

Restore the Evidence Verification v1 implementation worktree to its exact
pre-audit repository-object state by removing only the two artifacts created by
the failed audit:

1. `tools/evidence_verify/__pycache__/test_verify_v1.cpython-313.pyc`
2. `tools/evidence_verify/__pycache__/`

Do not modify any patch file.

Do not repair or rerun implementation.
Do not change the validator.
Do not change documentation.
Do not run the repository test suite.
Do not stage, commit, push, create a PR, merge, install, deploy, restart A6,
invoke product or live-service paths, contact a network, or execute Linux
binaries.

This is exact audit-artifact restoration, not implementation.

## 1. Exact repository and target

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected canonical manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Implementation evidence root, read-only:

IMPLEMENTATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f

Failed audit root, read-only:

FAILED_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1

Failed-audit repository diff record:

$FAILED_AUDIT/closeout/repository-snapshot-diff.json

Failed-audit adjudication:

$FAILED_AUDIT/closeout/adjudication.json

New restoration evidence root:

RESTORE_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632

Require RESTORE_ROOT absent before creation.

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Exact artifact identities

Expected added directory:

tools/evidence_verify/__pycache__

Required opening properties:

- directory;
- no symlink;
- mode `0755`;
- exact child set:
  `test_verify_v1.cpython-313.pyc`;
- no second file, hidden file, symlink, or subdirectory.

Expected added file:

tools/evidence_verify/__pycache__/test_verify_v1.cpython-313.pyc

Required opening properties:

- regular file;
- no symlink;
- link count 1;
- mode `0644`;
- size `150793`;
- SHA-256:
  `1e57088f5455ea8bdeb59a95c208d665a70acf2248a7c313c64fb78c16ca4b42`.

The failed audit reports:

- implementation baseline inventory: 477 objects;
- current closing inventory: 479 objects;
- exact set difference: only the directory and file above;
- no baseline object removed or changed.

Recompute that claim against:

- the live worktree;
- `repository-snapshot-diff.json`;
- the implementation evidence’s final repository snapshot or inventory records.

Do not delete anything unless the set difference is exactly those two objects.

## 3. Strict Git and process boundary

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - `PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin`
  - `GIT_OPTIONAL_LOCKS=0`
  - `GIT_CONFIG_NOSYSTEM=1`
  - `LC_ALL=C`
  - `LANG=C`
  - `PYTHONDONTWRITEBYTECODE=1`
- be retained with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in PRIMARY_R, FAILED_AUDIT, IMPLEMENTATION_EVIDENCE,
RESTORE_ROOT, or another evidence root.

Every Python command must use the pinned interpreter with:

- `-I`
- `-B`
- `PYTHONDONTWRITEBYTECODE=1`

Do not import a repository module.

Use absolute paths or cwd exactly equal to IMPL_R for every repository read.

A nonconforming Git command or PRIMARY_R-relative repository access is an
immediate process-boundary block.

## 4. Opening gate

Before creating RESTORE_ROOT or removing anything, require:

- exact repository root;
- exact branch, HEAD, tree, parent, and absent upstream;
- exactly four modified tracked and nine untracked patch paths;
- zero staged, deleted, renamed, or unmerged paths;
- every canonical patch row matches EXPECTED_MANIFEST;
- canonical-manifest hash matches;
- tracked binary diff matches;
- no Git operation marker or lock;
- every canonical patch file remains regular, single-link, mode `0644`,
  logical mode `100644`;
- the live full-object inventory differs from the recorded clean implementation
  baseline by exactly the two specified audit artifacts;
- the artifact directory contains exactly the specified pyc file;
- both artifact identities match section 2;
- FAILED_AUDIT and IMPLEMENTATION_EVIDENCE are unchanged.

Stop without mutation on any mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORATION_BASELINE_MISMATCH

## 5. Restoration evidence root

After the opening gate passes, create RESTORE_ROOT under umask `077`:

opening/
restoration/
provenance/
closeout/
tmp/

Directories must be mode `0700`.
Retained files must be regular, single-link, mode `0600`.

Retain:

- opening repository identity;
- opening 13-path manifest reconciliation;
- full-object before inventory;
- exact artifact identities;
- failed-audit snapshot-diff reconciliation;
- exact removal operations;
- full-object after inventory;
- provenance replays;
- closing gate;
- Git command ledger.

## 6. Exact restoration operation

Do not use recursive deletion.

Perform exactly:

1. No-follow recheck of the pyc file.
2. Unlink only:
   `tools/evidence_verify/__pycache__/test_verify_v1.cpython-313.pyc`
3. Recheck that the directory is empty.
4. Remove only the now-empty directory:
   `tools/evidence_verify/__pycache__`

Do not remove another `__pycache__`, `.pyc`, ignored path, cache, or artifact.

Do not change file modes, timestamps, or bytes of any baseline object as part of
cleanup.

If the directory is not empty immediately after removing the exact pyc, stop:

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORATION_SCOPE_MISMATCH

## 7. Post-restoration verification

Require:

- both exact artifact paths absent;
- no `__pycache__`, `.pyc`, `.pyo`, or `.pytest_cache` under
  `tools/evidence_verify`;
- full repository-object inventory restored from 479 to 477;
- post-restoration inventory equals the recorded implementation baseline;
- no baseline object missing, added, or changed;
- exact 13-path Git status unchanged;
- all 13 manifest rows unchanged;
- canonical manifest still:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked binary diff still:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- `git diff --check` passes;
- zero staged/deleted/renamed/unmerged paths;
- no Git operation marker or lock.

Do not run the test suite.

## 8. Provenance replay

Run the exact unchanged RECIPE twice against IMPL_R into fresh absent outputs
beneath RESTORE_ROOT/provenance.

Use pinned Python with `-I -B` and bytecode disabled.

Require:

- both exits `0`;
- empty stderr;
- byte-identical output files;
- stdout equals each output file;
- both outputs equal EXPECTED_MANIFEST;
- canonical manifest remains `4a3a4244…18537`;
- tracked diff remains `b2487310…7aceb`;
- no new repository artifact.

## 9. Closing gate

Require:

- branch, HEAD, tree, parent, and upstream unchanged;
- exact 13-path scope unchanged;
- all patch bytes unchanged;
- full inventory equals the clean 477-object baseline;
- no repository cache or bytecode;
- implementation evidence unchanged;
- failed audit evidence unchanged;
- no surviving child process or descriptor;
- RESTORE_ROOT/tmp empty;
- no product, network, or live operation occurred.

Do not stage or commit.

## 10. Verdicts

Use exactly one:

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORATION_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORATION_SCOPE_MISMATCH

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORATION_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_AUDIT_ARTIFACT_RESTORED_READY_FOR_FRESH_AUDIT

## 11. Complete inline final report

Include:

1. Verdict.
2. Response-format confirmation.
3. Opening repository identity.
4. Canonical patch provenance.
5. Failed-audit artifact finding consumed.
6. Exact opening artifact identities.
7. Exact full-inventory difference.
8. Exact removal operations.
9. Confirmation that no recursive cleanup was used.
10. Post-restoration full inventory.
11. Confirmation that all 477 baseline objects match.
12. Confirmation that every patch byte remained unchanged.
13. Canonical manifest and tracked diff after restoration.
14. Two provenance replay results.
15. Artifact scan.
16. Evidence inventory and cleanup.
17. Complete Git-process record.
18. Explicit confirmations:
    - implementation not performed;
    - repository patch bytes not modified;
    - formatting not performed;
    - tests not run;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created.

No implementation.
No independent audit.
No staging.
No commit.
No push.
No A6 restart.
```

## After restoration

The next audit must be a **new audit root and new conversation**. The failed audit remains permanently nonqualifying even though its substantive findings are useful evidence.

The replacement audit should add these hard controls:

- Every Python process uses `-B` and `PYTHONDONTWRITEBYTECODE=1`.
- No repository module is imported without bytecode suppression.
- The clean 477-object inventory is checked before and after every audit phase.
- Every subagent command uses cwd exactly `IMPL_R` or absolute paths.
- Each subagent’s first command, cwd, and operands are retained.
- Any primary-checkout-relative access immediately stops the audit.
- Four distinct auditors are still required.
- The same exact `4a3a4244…18537` patch remains the audit target.

### Sources

- The implementation report binds the one-file repair to manifest `4a3a4244…18537`, reports a clean 477-object repository snapshot, and requires a fresh audit. 
- Independent audit must reproduce provenance before correctness inspection and may remove only audit-created artifacts when that can be done within its authorized posture. 
- Project artifact guidance identifies `__pycache__`, `.pyc`, and `.pyo` as removable current-activity artifacts, while prohibiting deletion of unrelated pre-existing objects. 
- Provenance is evidence that audit and implementation address the same bytes; it does not convert the failed audit into an accepted correctness judgment. 

**Confidence**

- The one-file validator repair has no demonstrated substantive defect: **0.99**
- The current audit is permanently nonqualifying: **1.00**
- The two repository artifacts are safely removable under exact authorization: **0.995**
- The canonical patch target should remain `4a3a4244…18537`: **0.999**
- Required next sequence is exact cleanup followed by a fresh audit: **1.00**
