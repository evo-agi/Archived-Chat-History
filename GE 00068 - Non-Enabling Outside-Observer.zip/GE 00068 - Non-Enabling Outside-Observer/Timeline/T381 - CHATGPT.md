## Assessment

Codex stopped correctly. This is **not a package defect** and does not authorize any semantic, target, bootstrap, or harness change.

The blocker is a transcription error in my preceding prompt. I supplied a malformed 62-character value:

```text
f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e
```

The retained file’s Codex-observed SHA-256 is the valid 64-character value:

```text
f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e
```

The missing characters are `9e` immediately after `...1309bf`.

Because the malformed digest was presented as a fixed governing identity, Codex was right not to infer or repair it. The failed root must remain immutable. The prior metadata-repair task should now be rerun from a wholly fresh root with only this one corrected expected identity. No additional reconciliation tranche is needed.

## Correction prompt for Codex

```text
FRESH RETRY OF THE PRECEDING TARGET-AUDIT HARNESS METADATA-REPAIR TASK —
ONE EXPLICITLY CORRECTED GOVERNING IDENTITY

The immediately preceding task stopped correctly with:

PREFLIGHT_PROVENANCE_MISMATCH

because one supplied expected SHA-256 was malformed.

This prompt explicitly corrects that one identity and authorizes a wholly fresh
retry of the preceding task.

All other objectives, authority boundaries, fixed inputs, constraints,
algorithms, validation requirements, closure requirements, stop conditions,
verdict rules, and required confirmations from the immediately preceding
“BOUNDED TRANSITIVE-IDENTITY METADATA REPAIR, PHYSICAL-ROOT REBINDING,
FRESH QUALIFICATION, AND TERMINAL CLOSURE” prompt remain unchanged and fully
in force.

Do not weaken, reinterpret, omit, or replace them.

──────────────────────────────────────────────────────────────────────────────
1. EXACT IDENTITY CORRECTION
──────────────────────────────────────────────────────────────────────────────

Subject file:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn/validation/two-root-rebinding-determinism-v1.json

Expected size:

8350 bytes

INVALID HISTORICAL VALUE FROM THE PRIOR PROMPT:

f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e

- length:
  62 characters
- valid SHA-256:
  false
- authority:
  none
- use in the fresh task:
  forbidden

CORRECT EXPECTED SHA-256:

f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e

- length:
  64 characters
- lowercase hexadecimal:
  required

This correction replaces only the malformed expected identity for this exact
file.

No other supplied identity, path, source byte, contract, scope, or task rule is
changed.

──────────────────────────────────────────────────────────────────────────────
2. CORRECTION AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Before adopting the corrected identity:

1. Authenticate the sealed predecessor root:

   /Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn

2. Authenticate its terminal manifest pair:

   manifest/canonical-manifest-a-v2.json
   manifest/canonical-manifest-b-v2.json

   Expected identities:

   - size:
     16431 each
   - SHA-256:
     240259f8e850293f1d8b8bec8c349eb8d21bc931ea191ff34373cfa963a9eee7
   - byte-identical:
     required

3. Locate the exact manifest row for:

   validation/two-root-rebinding-determinism-v1.json

4. Require the row to bind:

   - regular type;
   - mode 0600;
   - link count 1;
   - size 8350;
   - SHA-256:
     f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e

5. Independently reopen the exact file no-follow and recompute its size and
   SHA-256.

6. Require:

   - manifest A row;
   - manifest B row;
   - independently observed file identity;

   to agree exactly.

If any of those checks fails, return:

PREFLIGHT_PROVENANCE_MISMATCH

Do not continue.

Do not infer the corrected value merely by inserting characters into the
malformed value. Authority comes from the retained file and authenticated
predecessor manifests.

──────────────────────────────────────────────────────────────────────────────
3. RETAIN THE CORRECTION PROVENANCE
──────────────────────────────────────────────────────────────────────────────

In the fresh package root, before semantic construction, retain:

opening/supplied-identity-correction-v1.json

It must record:

- subject absolute path;
- subject package-relative path;
- expected size;
- malformed historical value;
- malformed-value character count:
  62;
- malformed-value validity:
  false;
- corrected value;
- corrected-value character count:
  64;
- exact predecessor-manifest identities;
- manifest A row;
- manifest B row;
- independent no-follow observation;
- all-three equality:
  true;
- correction scope:
  one-fixed-preflight-identity-only;
- semantic effect:
  none;
- source/export effect:
  none;
- target-audit acceptance-rule effect:
  none;
- historical malformed value current authority:
  false.

This is audit-owned correction provenance, not a consumer-facing semantic
export.

──────────────────────────────────────────────────────────────────────────────
4. FAILED ATTEMPT DISPOSITION
──────────────────────────────────────────────────────────────────────────────

The prior failed retry root is:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-h5f09wc4

Treat it as immutable, nonauthoritative preflight-failure evidence.

Do not:

- resume it;
- modify it;
- clean it;
- adopt it;
- copy current authority from it;
- use its incomplete package state.

It may be opened read-only only to bind its identity and failure reason in
historical lineage.

Require complete opening/closing equality if it is opened.

──────────────────────────────────────────────────────────────────────────────
5. FRESH ROOT AND COMPLETE TASK RESTART
──────────────────────────────────────────────────────────────────────────────

Allocate a wholly fresh final package root using the same allocation contract,
parent, umask, and prefix required by the preceding task:

ES-repair10i-v3-target-audit-harness-package-metadata-repair-

Do not reuse the prior failed root.

Restart the preceding task from its beginning.

Perform every required step from the preceding prompt, including:

- exact sealed-predecessor authentication;
- exact seven-export authentication;
- fresh physical-root binding in the plan;
- six byte-identical semantic exports;
- clean versioned metadata;
- exact four-consumer registry;
- real RFC 6901 pointer resolution;
- complete dependency graph;
- root-rebinding contract V2;
- current export registry V2;
- fresh qualification result V2;
- metadata-pointer mutation matrix;
- independent metadata validator;
- root-rebinding matrix V2;
- two-root metadata determinism;
- fresh support-binding qualification;
- fresh finalizer qualification;
- synthetic Carrier 0003 materializations;
- synthetic finalizer causals;
- freeze record V3;
- post-freeze four-pointer resolution;
- package metadata coherence;
- frozen-package requalification V3;
- historical lineage;
- package immobility;
- cache and bytecode discipline;
- supplied-root closing equality;
- temporal final inventory;
- terminal manifest A and B;
- independent terminal reprojection;
- no-write-after-closure.

Do not skip or adopt a prior result merely because the preceding run reached
it.

──────────────────────────────────────────────────────────────────────────────
6. FIXED-IDENTITY FORMAT PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before package construction, validate every explicitly supplied SHA-256 literal
used by the fresh task.

Require each to be:

- exactly 64 characters;
- lowercase hexadecimal.

If any other malformed fixed identity exists:

- do not stop after reporting only the first one;
- retain the complete malformed-identity ledger;
- return `PREFLIGHT_PROVENANCE_MISMATCH`;
- do not begin package construction.

The corrected subject identity above must not be reported as malformed.

──────────────────────────────────────────────────────────────────────────────
7. UNCHANGED VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return exactly one verdict from the preceding task:

TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_READY
TARGET_AUDIT_HARNESS_PACKAGE_METADATA_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

The readiness verdict still requires every construction, qualification,
metadata-coherence, freeze, requalification, supplied-root equality, temporal
inventory, manifest, terminal reprojection, mode/type, cache, and
no-write-after-closure gate from the preceding prompt.

The identity correction alone is not a readiness result.

──────────────────────────────────────────────────────────────────────────────
8. INLINE REPORT ADDITION
──────────────────────────────────────────────────────────────────────────────

Return the full inline report required by the preceding task.

Add, near the opening provenance section:

- malformed historical identity;
- corrected identity;
- predecessor manifest-row identities;
- independent file observation;
- correction-record identity;
- confirmation that only one fixed preflight identity changed;
- confirmation that no semantic export or acceptance rule changed because of
  the correction.

Links to retained artifacts are supplemental. Do not put the substantive
report only in a file.

Additional required confirmations:

MALFORMED_HISTORICAL_DIGEST_REJECTED
CORRECTED_DIGEST_EXACTLY_64_LOWERCASE_HEX
CORRECTED_DIGEST_AUTHENTICATED_BY_MANIFEST_A
CORRECTED_DIGEST_AUTHENTICATED_BY_MANIFEST_B
CORRECTED_DIGEST_INDEPENDENTLY_RECOMPUTED
CORRECTION_SCOPE_ONE_FIXED_IDENTITY_ONLY
PRIOR_FAILED_RETRY_ROOT_MUTATION_NOT_PERFORMED
PRIOR_FAILED_RETRY_ROOT_NOT_RESUMED
NO_SEMANTIC_CHANGE_FROM_IDENTITY_CORRECTION
```

The correct response to the latest attempt is therefore a fresh retry, not another package or target repair.

**Source:** Codex’s latest `PREFLIGHT_PROVENANCE_MISMATCH` report and the malformed digest in my preceding prompt.  
**Confidence:** 1.00 that Codex stopped correctly; 1.00 that the supplied 62-character value was invalid; 0.995 that the corrected 64-character digest should be authenticated from the predecessor manifests and retained file before the task continues.
