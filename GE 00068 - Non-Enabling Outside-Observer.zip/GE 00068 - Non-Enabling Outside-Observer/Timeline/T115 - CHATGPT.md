## Assessment

The stop was correct, and the defect is narrowly bounded.

This is **not** a failure of the external-verifier architecture, the generic closure algorithm, or the historical amendment child. It is an implementation mistake in the amendment layout specification:

- The sealed amendment manifest truthfully records the two corrected Python helpers as mode `0700`.
- The new layout specification incorrectly classified them with fixed evidence records requiring `0600`.
- The architecture freeze already allows regular payloads to be either `0600` or `0700`, while fixed records remain `0600`; it also defines required files with explicit modes. 
- These two files are **required executable helper source**, not evidence records.

The bounded correction is:

1. Require mode `0700` for exactly:
   - `tool/corrected/verify-closing-v1.py`
   - `tool/corrected/verify-postseal-v1.py`
2. Keep fixed JSON, Markdown, manifests, indexes, and other evidence records at `0600`.
3. Add no wildcard allowing arbitrary executable payloads.
4. Update the amendment spec hash in the registry.
5. Clarify the governing documentation and add exact mode-regression tests.
6. Rerun the entire validation program and only then generate final provenance.

There is no reason to create another worktree or restart the implementation. This is a patch-caused validation failure within the authorized 13-path scope, so it belongs in the same parent-only implementation tranche. Independent audit still begins only after final validation and provenance. 

Because this implementation has not been audited or committed, the correction does not require a layout-ID or verifier-version bump. The final initial implementation bytes are what the later fresh audit will receive.

## Codex continuation prompt

```text
Permission remains workspace-write.

Continue in the same foreground Codex implementation conversation and the same
clean implementation worktree.

Objective

Repair the exact historical-amendment layout-mode defect that produced:

EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED

Then rerun the complete implementation validation program, generate exact
provenance, and return the original success verdict only if every gate passes:

EVIDENCE_VERIFICATION_V1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

This is a bounded continuation of the existing implementation tranche, not a
new architecture decision.

Do not create another worktree.
Do not reset or discard the current patch.
Do not overwrite or delete the retained blocked-attempt evidence.
Do not modify the Repair 10I candidate.
Do not modify either sealed evidence child.
Do not stage, commit, push, create a PR, install, deploy, invoke a live route,
contact a network, restart A6, or perform an independent audit.

No subagents. You remain the sole writer.

## 1. Paths

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Implementation branch:

codex/evidence-verification-v1

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as implementation cwd/source:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

## 2. Mandatory continuation baseline

Before editing, require IMPL_R:

- physical root equals lexical root;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- exactly the previously authorized 13 changed/untracked paths;
- exactly four modified tracked documentation paths;
- exactly nine untracked added regular files;
- all repository paths mode `100644`;
- nothing staged, deleted, renamed, or unmerged;
- no changed path outside the authorized set.

Require the current incomplete verifier source to match the blocked report:

- `tools/evidence_verify/verify_v1.py`
- SHA-256:
  `63b79cc7781db7e7ba78b8d1321e33785f896156813105733c7e01cd23dd1f27`

Reverify the complete current 13-path byte set against the retained blocked
closeout record:

EVIDENCE/closeout/validation-blocked-v1.json

Require the prior raw validation outputs and failure record to remain present
and unchanged.

Require CANDIDATE_R to remain exact:

- physical device/inode:
  `16777234/122118502`;
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`;
- source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
- membership:
  `389 / 375 / 14`;
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Use explicitly rooted Git commands only.

Require A6D unchanged:

- manifest:
  `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`.

Require A6D_AMEND unchanged:

- manifest:
  `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`.

Require the exact historical amendment facts:

- `tool/corrected/verify-closing-v1.py`
  is regular, single-link, mode `0700`, and manifest-bound;
- `tool/corrected/verify-postseal-v1.py`
  is regular, single-link, mode `0700`, and manifest-bound.

Stop on any unexpected drift:

EVIDENCE_VERIFICATION_V1_CONTINUATION_BASELINE_MISMATCH

## 3. Defect classification

Record the defect exactly as:

- type:
  layout-spec implementation defect;
- affected target:
  `execution-substrate.repair10i.a6d-amendment-layout/v1`;
- mechanism:
  two required executable helper-source files were misclassified as fixed
  evidence records and assigned mode `0600`;
- observed historical truth:
  both are exact manifest-bound mode-`0700` regular files;
- authority impact:
  none;
- verifier architecture impact:
  none;
- product/runtime impact:
  none.

Do not call this:

- an A6D evidence defect;
- a source-child defect;
- a verifier-architecture defect;
- a readiness defect;
- a product defect.

## 4. Frozen mode distinction

Refine the contract as follows.

### Fixed evidence records

Fixed JSON, Markdown, text, manifest-adjacent, index, report, and closeout
records remain exact mode `0600`.

### Required executable helper source

A layout specification may require an exact regular helper-source path at mode
`0700` only when all are true:

- the path is explicitly enumerated in that audited layout specification;
- the required mode is exactly `0700`;
- the file remains regular and single-link;
- its bytes, size, and SHA-256 are manifest-bound;
- no wildcard or optional subtree grants executable mode by implication.

For the historical A6D amendment layout, the only required executable helper
paths are:

- `tool/corrected/verify-closing-v1.py`
- `tool/corrected/verify-postseal-v1.py`

Both must be exactly mode `0700`.

No other path gains mode `0700` because of this repair.

The following remain unchanged:

- all directory modes;
- ordinary fixed-record modes;
- permitted general payload mode set;
- manifest grammar;
- sidecar grammar;
- closure semantics;
- authority split;
- no-write behavior;
- target-boundary behavior.

## 5. Exact repair surfaces

Remain within the already authorized 13 repository paths.

At minimum inspect and, where needed, update:

- `.docs/system_overview/evidence_verification.md`
- `.docs/system_overview/artifact_hygiene.md`
- `tools/evidence_verify/layouts/a6d_amendment_v1.json`
- `tools/evidence_verify/registry_v1.json`
- `tools/evidence_verify/test_verify_v1.py`

Do not change another path outside the existing 13-path implementation set.

Inspect whether `verify_v1.py` already supports an exact per-required-file
mode.

### If exact per-required-file mode is already supported

- keep `verify_v1.py` byte-identical;
- correct only the spec, registry hash, documentation, and tests required by
  the distinction.

### If exact per-required-file mode is not yet supported

A minimal implementation inside the already authorized `verify_v1.py` is
authorized only to implement the architecture-reset contract that
`required_files` carry exact modes.

It must not add:

- mode alternatives;
- wildcard executable rules;
- caller-selected modes;
- executable-subtree defaults;
- another spec field;
- another target kind;
- another source path.

If the distinction cannot be expressed within the existing closed spec schema
and authorized 13-path set, stop:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

Do not version-bump the verifier, registry schema, or layout ID. These initial
implementation bytes have not yet been independently audited or committed.

## 6. Registry update

After changing `a6d_amendment_v1.json`:

- canonicalize it under the existing strict spec encoding;
- recompute its complete SHA-256;
- update only the corresponding registry entry;
- preserve the other two layout IDs, filenames, and hashes unless their bytes
  genuinely changed for this repair;
- require registry canonical encoding;
- require embedded ID, filename, and digest consistency.

No runtime registry injection.
No caller-supplied spec.
No new layout.

## 7. Mandatory mode-regression tests

Add exact tests within the existing test file.

At minimum require:

1. The exact historical amendment fixture passes when:
   - both corrected helper sources are mode `0700`;
   - every fixed evidence record remains `0600`.

2. Changing `verify-closing-v1.py` from `0700` to `0600` rejects.

3. Changing `verify-postseal-v1.py` from `0700` to `0600` rejects.

4. Changing either helper to `0644`, `0755`, or another mode rejects.

5. An unrelated fixed JSON/Markdown/report record changed from `0600` to
   `0700` rejects.

6. An unenumerated executable-mode file rejects as an unexpected path or
   layout violation.

7. A mode-`0700` file under an optional subtree does not gain special
   authority beyond the existing manifest and layout rules.

8. The A6D successor layout remains unchanged and still passes.

9. The A6 policy layout remains unchanged.

10. Registry/spec hash mismatch rejects.

Do not weaken an existing test to obtain a pass.

Preserve the original blocked real-child run as a retained expected-negative
attempt. Do not overwrite its stdout, stderr, or result records.

## 8. Complete validation restart

After the repair, rerun the full implementation validation program from the
beginning. Do not rely on the prior partial success.

Use the exact Python 3.13 interpreter identity and pinned environment from the
current implementation evidence.

Required gates:

1. Parse all Python source with `ast.parse`; create no bytecode.
2. Strictly parse the registry and all three specs.
3. Run the complete `test_verify_v1.py` test command.
4. Run the complete test command a second time.
5. Require equivalent test outcomes across both runs.
6. Run the exact sealed A6D compatibility check twice.
7. Require:
   - exit `0` twice;
   - byte-identical canonical stdout;
   - target and verifier-package before/after snapshots unchanged.
8. Run the exact sealed A6D amendment compatibility check twice.
9. Require:
   - exit `0` twice;
   - byte-identical canonical stdout;
   - the exact two helper paths accepted at mode `0700`;
   - target and verifier-package before/after snapshots unchanged.
10. Run a synthetic A6 pre-seal check twice.
11. Seal the synthetic fixture using the test-owned writer.
12. Run the synthetic A6 sealed check twice.
13. Require byte-identical outputs for repeated identical invocations.
14. Re-run all 30 frozen causal cases, including the new exact-mode
    regressions.
15. Verify historical defect fixtures retain their exact original bytes and
    hashes.
16. Run `git diff --check`.

Every fixture root must be removed after its owning check.

No repository Go test is required.

No network.
No child process from the verifier.
No write to a real sealed input.
No bytecode or cache.

## 9. Real-child compatibility interpretation

The expected real-child outcomes are:

### A6D successor child

- passes under:
  `execution-substrate.repair10i.a6d-successor-layout/v1`.

### A6D amendment child

- passes under:
  `execution-substrate.repair10i.a6d-amendment-layout/v1`;
- exact helper modes:
  `0700`;
- all fixed evidence records:
  exact declared `0600`;
- no readiness content interpreted.

If either real child fails after the repair, stop:

EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED

Do not change the sealed child to fit the spec.

## 10. Implementation evidence continuation

Preserve all existing records in EVIDENCE.

Add fresh continuation records under new versioned names or a new bounded
subdirectory. Do not overwrite:

- `closeout/validation-blocked-v1.json`;
- prior raw stdout/stderr;
- prior test records;
- the real amendment rejection.

Retain:

- exact defect adjudication;
- pre-repair and post-repair spec bytes/hashes;
- pre-repair and post-repair registry bytes/hashes;
- exact changed implementation bytes;
- complete fresh validation;
- both real-child compatibility checks;
- all no-write snapshots;
- failed and superseded attempt index;
- final implementation report.

## 11. Provenance

Only after every validation gate passes:

1. Create the source-external deterministic provenance recipe required by the
   original implementation prompt.
2. Retain its complete source bytes.
3. Compute and report its SHA-256.
4. Run it twice against IMPL_R.
5. Require byte-identical canonical output.
6. Require the final path set to be exactly the authorized 13 paths.
7. Require:
   - four modified tracked files;
   - nine untracked additions;
   - zero deletion;
   - zero rename;
   - zero unsupported type;
   - zero staged path.
8. Record:
   - recipe ID;
   - branch;
   - HEAD;
   - upstream;
   - path classification;
   - file type;
   - logical mode;
   - size;
   - SHA-256;
   - tracked binary-diff SHA-256;
   - canonical patch-manifest SHA-256.
9. Write recipe and outputs only beneath EVIDENCE.
10. Remove no pre-existing artifact.

The exact recipe must be available to the future auditor; a hash alone is not
sufficient.

## 12. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- upstream:
  absent;
- exactly 13 changed/untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- `git diff --check` clean;
- no cache, bytecode, test fixture, generated manifest, database, lock, or
  temporary output in the repository.

Require CANDIDATE_R closing identity to equal opening identity exactly.

Require A6D and A6D_AMEND to remain byte-exact.

Require PRIMARY_R never used as implementation cwd or source root.

Do not remove IMPL_R or EVIDENCE; both are required for the fresh audit.

## 13. Verdicts

Continuation baseline mismatch:

EVIDENCE_VERIFICATION_V1_CONTINUATION_BASELINE_MISMATCH

Scope expansion:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

Validation failure:

EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED

Provenance failure:

EVIDENCE_VERIFICATION_V1_PROVENANCE_BLOCKED

Complete success:

EVIDENCE_VERIFICATION_V1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

## 14. Required final report

Include:

1. Candidate opening/closing identity.
2. Implementation worktree identity.
3. Initial blocked real-child finding.
4. Exact mode-contract correction.
5. Exact files changed during the correction.
6. Whether `verify_v1.py` changed and why.
7. Final verifier source SHA-256.
8. Final registry SHA-256.
9. All layout IDs and final layout SHA-256 values.
10. Exact two mode-`0700` historical amendment helper paths.
11. Confirmation fixed records remain mode `0600`.
12. Complete fresh test results, including repeated full test command.
13. All 30 causal outcomes and new mode regressions.
14. Real A6D checks, both runs.
15. Real amendment checks, both runs.
16. No-write/determinism evidence.
17. Exact Python interpreter identity.
18. Final 13-path delta and classifications.
19. Provenance recipe ID and source SHA-256.
20. Tracked binary-diff SHA-256.
21. Canonical patch-manifest SHA-256.
22. Complete changed-file manifest.
23. Generated/artifact hygiene.
24. Authority/security widening:
    explicitly none, or exact contrary finding.
25. Remaining uncertainty.
26. Confirmation:
    - independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests and live services not invoked.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

A successful continuation should move directly to a fresh read-only audit of the exact 13-path patch and its provenance. The provenance recipe must be run twice and supplied in full to the auditor, not merely by hash. 

### Sources

- Codex’s `EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED` report supplied in this turn.
- Frozen layout schema and payload-mode contract. 
- Frozen 13-path implementation scope. 
- Implementation validation may repair patch-caused failures; independent audit remains separate. 
- Exact implementation closeout and audit provenance lifecycle. 
- Proof scaffolding must remain non-authoritative. 

**Confidence**

- Stop correctness: **0.999**
- Classification as a layout-spec mode defect: **0.995**
- Confidence that exact `0700` declarations for the two historical helpers are the correct repair: **0.99**
- Confidence that no architecture or verifier version change is needed: **0.98**
- Confidence that the same implementation worktree should be repaired and fully revalidated: **0.997**
