Here is Codex's response:

# AUDIT\_PROVENANCE\_MISMATCH

The first post-epoch bootstrap process terminated without returning a bootstrap identity, audit-root path, recorder-gate result, or persistent recorder session. Although it exited with status 0, it emitted no output, so recorder construction and both mandatory causals are unprovable.

Starting another process would bypass the required in-process parent recorder. The audit therefore stopped immediately, before any candidate or supplied-root inspection.

No V3 repair, Git operation, runtime validation, test, product invocation, or supplied-input mutation was performed. Any root potentially created by this failed bootstrap must be treated as immutable historical process-failure evidence.

The following required confirmations cannot be made:

- `PROCESS_RUNNER_SOURCE_RETAINED_AND_HASH_BOUND`
- `PROCESS_0001_START_RECORDED_BEFORE_SPAWN`
- `MISSING_EXECUTABLE_CAUSAL_RECORDED`
- `PROCESS_0002_SUCCESS_RECORDED`
- `PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS`
- `NO_PARENT_CHILD_LAUNCH_BYPASSED_RECORDER`
