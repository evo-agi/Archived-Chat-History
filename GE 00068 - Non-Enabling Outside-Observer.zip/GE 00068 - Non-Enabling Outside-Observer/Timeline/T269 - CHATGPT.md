## Assessment

This result is decisive: **the Codex tool interface cannot support the persistent-supervisor audit model**.

The probe established two separate facts:

1. The recorder logic itself works within one carrier. It successfully recorded:
   - a pre-spawn start record and `FileNotFoundError` for process 0001;
   - a normal exit-0 process 0002;
   - complete, contiguous quartets and matching stream hashes.

2. The carrier cannot remain addressable across interactions. After `READY`, it exited with no persistent-session identifier, so `ping`, later `self_check`, and `close` could not be sent to the same PID.

This is **not a V3 finding** and does not justify changing the V3 capsule. It is a hard interface constraint on the audit method.

We should now stop trying to make an audit artifact prove the launch of its own top-level carrier. That has produced repeated process-only failures and is not proportional. The correct authority split is:

- **Codex’s tool transcript** owns top-level carrier invocation facts: command, cwd, tool-call ordering, returned status, and auditor scheduling.
- **The audit root** owns target provenance, phase results, child-process evidence, validation artifacts, and closing equality.
- Every child process launched inside a carrier still receives a pre-spawn record.
- The audit report explicitly depends on the platform transcript for parent-carrier provenance; it does not pretend that the audit root is self-contained for that fact.

This follows the project’s one-authoritative-writer principle and removes the impossible circular requirement.

The supervisor probe root should remain immutable historical capability evidence:

`/Users/ds/Downloads/ES-repair10i-audit-supervisor-capability-probe-w8h8q0jr`

No further capability probe is needed.

## Next Codex prompt

Start a **fresh Codex chat**. Paste the last complete V3 independent-audit prompt, then append this override. It replaces the persistent-supervisor and parent-process-recording requirements; every target identity, four-auditor requirement, independent reconstruction, 50-case mutation matrix, no-runtime-replay rule, closing gate, and verdict rule remains in force.

```text
TOOL-TRANSCRIPT-AUTHORITATIVE AUDIT PROCESS OVERRIDE

This override replaces every requirement in the governing V3 independent-audit
prompt for:

- a persistent audit supervisor;
- a process remaining alive across Codex tool interactions;
- an in-root pre-spawn record for the top-level Codex carrier process;
- cross-interaction stdin communication with one carrier PID;
- a self-contained audit-root proof of top-level carrier launch provenance.

All target, provenance, correctness, four-auditor, no-runtime-replay, mutation,
authority, artifact, closing, and verdict requirements remain unchanged.

The persistent-supervisor capability has been tested and is unavailable.

Historical capability evidence:

/Users/ds/Downloads/ES-repair10i-audit-supervisor-capability-probe-w8h8q0jr

Do not use that root as qualification evidence for V3. Leave it immutable.

The probe established only:

- one carrier can pre-record and execute child processes correctly;
- missing-executable and exit-0 child causals passed inside that carrier;
- the Codex interface did not return a persistent-session identifier;
- later stdin interactions with the same carrier PID were unavailable.

Do not perform another persistent-supervisor or persistent-session probe.

──────────────────────────────────────────────────────────────────────────────
1. PROCESS-AUTHORITY SPLIT
──────────────────────────────────────────────────────────────────────────────

Use this exact authority split.

A. Codex platform tool transcript is the sole authority for:

- top-level Codex tool-call ordering;
- the exact top-level command submitted;
- the top-level cwd supplied to the tool;
- the tool-call result and any reported exit;
- direct-auditor creation, scheduling, identity, and completion;
- whether another top-level tool call occurred.

B. The audit root is the sole authority for:

- bootstrap identity;
- supplied-input and target identities;
- audit-phase inputs and outcomes;
- child processes launched by audit-owned scripts;
- stdout/stderr retained by audit-owned scripts;
- contract, plan, source-closure, lineage, mutation, and authority findings;
- audit artifacts;
- opening and closing filesystem equality;
- process and descriptor cleanup inside the audited phases.

C. No audit-root record may claim to prove that it existed before its own
top-level Codex carrier was launched.

D. No final report may call the audit root self-contained for parent-carrier
launch provenance.

E. Dependence on the visible Codex tool transcript must be explicit and is not
a defect under this audit-process model.

──────────────────────────────────────────────────────────────────────────────
2. ADMINISTRATIVE INTAKE AND AUDIT EPOCH
──────────────────────────────────────────────────────────────────────────────

Read the complete governing audit prompt and this override before invoking a
tool.

Administrative prompt intake is excluded from evidence.

Do not inspect the candidate or supplied evidence during administrative intake.

Then state exactly:

AUDIT_EPOCH_START

The first post-epoch tool call must:

- use the candidate repository as its declared cwd;
- carry the explicit environment required by the governing prompt;
- set umask 077 inside the invoked audit-owned program;
- allocate a fresh audit root with the required prefix;
- create the bootstrap record before target-content inspection;
- create the audit phase and child-process recording infrastructure;
- return the exact audit-root path and bootstrap result.

If that tool call fails before a bootstrap record is created, return
AUDIT_PROVENANCE_MISMATCH based on the platform transcript. Do not attempt to
repair or continue the same audit.

──────────────────────────────────────────────────────────────────────────────
3. TOP-LEVEL CARRIER REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

A top-level carrier is one Codex tool call that invokes one audit-owned phase
program.

No persistent carrier is required or permitted.

Each carrier must be a separate, explicit tool call.

Where the tool interface permits separate cwd and environment fields, use them
directly. Otherwise invoke the phase with an explicit closed environment whose
complete values appear in the submitted command.

Prefer the pinned Python interpreter and an argv-list launch. Do not depend on
an interactive shell, background job, detached process, daemon, or terminal
session.

Do not use optional discovery binaries such as:

- rg
- fd

Use Python standard-library traversal and matching instead.

Each top-level carrier must perform one bounded audit phase or one coherent
validation group. Do not combine unrelated exploratory operations in one
carrier.

Before each carrier is launched, the parent must state in its reasoning or
tool-call context:

- carrier ordinal;
- phase name;
- exact script;
- exact cwd;
- exact explicit environment;
- authorized operands;
- expected output records.

The platform transcript is authoritative for that declaration and launch.

──────────────────────────────────────────────────────────────────────────────
4. PHASE RECORDS
──────────────────────────────────────────────────────────────────────────────

Each carrier, immediately after process start and before inspecting target
content for its phase, must exclusively create:

provenance/carrier-NNNN.phase-start.json

It must record:

- carrier ordinal;
- phase name;
- exact argv as observed by the phase program;
- cwd;
- complete effective environment used by the phase;
- effective umask;
- process PID;
- authorized operands;
- expected output records;
- start timestamp;
- phase-program path, size, and SHA-256;
- statement:
  `top_level_launch_authority = "codex-platform-tool-transcript"`.

At successful or failed phase completion, it must exclusively create:

provenance/carrier-NNNN.phase-outcome.json

It must record:

- outcome;
- exit or exception disposition;
- created artifact list;
- child-process ordinal range;
- retained stdout/stderr identities where applicable;
- end timestamp;
- cleanup state;
- whether the phase reached its intended completion point.

A phase start record is evidence observed after launch. It is not described as
pre-spawn proof of the carrier.

Do not overwrite phase records.

Carrier ordinals must be contiguous across the audit.

──────────────────────────────────────────────────────────────────────────────
5. CHILD-PROCESS RECORDING
──────────────────────────────────────────────────────────────────────────────

Every external child process launched from inside an audit phase must use one
audit-owned recorder.

For each child ordinal N, retain exactly:

provenance/child-NNNN.start.json
provenance/child-NNNN.stdout
provenance/child-NNNN.stderr
provenance/child-NNNN.outcome.json

The complete start record and stdout/stderr files must be exclusively created
and fsynced before attempting child creation.

The recorder must catch:

- FileNotFoundError;
- PermissionError;
- all other OSError subclasses;
- invalid cwd;
- malformed argv.

The outcome must record:

- process-created Boolean;
- PID when created;
- exit or signal;
- creation exception type, errno, and message when applicable;
- stdout/stderr size and SHA-256;
- reaped status;
- descriptor-close status;
- complete/incomplete disposition.

A child-creation failure with a complete quartet is a recorded process result,
not automatically an audit-provenance mismatch.

A missing quartet, overwritten record, ordinal gap, unknown child launch, or
unreaped child is AUDIT_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
6. DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

The four direct auditors are Codex platform interactions, not local OS child
processes.

Their creation, scheduling, and completion authority comes from the Codex tool
transcript.

Preserve the governing schedule:

- start exactly three distinct direct auditors concurrently after opening
  provenance passes;
- after the first completes, start a fourth distinct auditor;
- no nested auditors.

The parent must retain under the audit root:

- each exact auditor prompt;
- exact authorized operand list;
- reported auditor identity;
- start and completion order;
- complete returned report;
- uncertainty and uninspected scope;
- any disclosed process or scope deviation.

Writing those retained copies requires an audit-owned carrier phase, recorded
under §§3–4.

Do not claim that the retained copy proves the platform-side auditor start. The
platform transcript owns that fact.

──────────────────────────────────────────────────────────────────────────────
7. PLATFORM-CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

At closeout, create:

closeout/platform-carrier-index.json

For every top-level carrier, list:

- contiguous carrier ordinal;
- phase;
- exact submitted command;
- exact submitted cwd;
- exact explicit environment;
- platform-reported result;
- corresponding phase-start record;
- corresponding phase-outcome record;
- child-process ordinal range;
- artifact references;
- discrepancy status.

This index is a projection derived from the visible Codex tool transcript and
the in-root phase records.

It must state:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not invent platform invocation IDs or stream hashes that the transcript did
not expose. Mark unavailable transcript fields as unavailable rather than
reconstructing them.

Return AUDIT_PROVENANCE_MISMATCH if:

- a known top-level carrier has no corresponding phase record;
- a phase record has no corresponding visible tool call;
- carrier ordering is ambiguous;
- submitted cwd or command conflicts with its phase record;
- an unrecorded target-facing tool call occurred.

──────────────────────────────────────────────────────────────────────────────
8. OPENING AND CORRECTNESS AUDIT
──────────────────────────────────────────────────────────────────────────────

After the first carrier creates the bootstrap and opening provenance passes,
perform the governing V3 audit exactly as previously specified:

- complete candidate and supplied-root identity checks;
- complete V3 capsule closure;
- four direct auditors;
- independent V3 contract reconstruction;
- independent Plan V3→V4 field-level equivalence;
- independent exact-source and path-budget derivation including `itoa.go`;
- independent V2 technical-evidence adoption review;
- failed-attempt and sole-writer adjudication;
- independent 50-case-or-greater mutation matrix;
- no runtime validation replay;
- authority and nonauthority adjudication;
- bounded sensitive-material and artifact review.

Do not weaken or omit any target-level requirement because the parent-process
model changed.

──────────────────────────────────────────────────────────────────────────────
9. CLOSING PROCESS AUDIT
──────────────────────────────────────────────────────────────────────────────

At closeout, independently verify:

- carrier ordinals are contiguous;
- every known carrier has a start and outcome record;
- the platform-carrier index agrees with the visible transcript;
- child ordinals are contiguous;
- every child has one complete quartet;
- every child stream matches its retained size and SHA-256;
- every created child was reaped;
- every child descriptor was closed;
- no child launch bypassed the audit recorder;
- no target-facing carrier bypassed phase recording;
- all four auditor interactions are represented;
- no process or descriptor survivor remains.

Retain:

closeout/complete-process-and-carrier-audit.json

The report must distinguish:

- platform-authoritative parent-carrier facts;
- audit-root-authoritative child and target facts.

──────────────────────────────────────────────────────────────────────────────
10. FAILED CAPABILITY ROOT
──────────────────────────────────────────────────────────────────────────────

Leave this capability-probe root immutable:

/Users/ds/Downloads/ES-repair10i-audit-supervisor-capability-probe-w8h8q0jr

Do not use it to qualify V3.

It may be cited only for this process-capability fact:

- one carrier successfully recorded child spawn-failure and success causals;
- the Codex interface did not expose a persistent interactive session after
  READY.

Also leave all previous failed V3 audit roots immutable and nonqualifying.

──────────────────────────────────────────────────────────────────────────────
11. VERDICT TREATMENT
──────────────────────────────────────────────────────────────────────────────

Do not return AUDIT_PROVENANCE_MISMATCH merely because:

- no persistent supervisor exists;
- a parent carrier cannot pre-record its own launch in the audit root;
- parent-carrier provenance depends on the Codex tool transcript.

Those are now explicit properties of the supported audit-process contract.

Return AUDIT_PROVENANCE_MISMATCH for:

- missing or conflicting platform carrier evidence;
- an unrecorded target-facing carrier;
- missing phase record;
- missing child quartet;
- supplied-root drift;
- failed opening/closing equality;
- unknown mutation or process activity.

All target-level ACCEPT/BLOCK/REJECT rules from the governing prompt remain
unchanged.

──────────────────────────────────────────────────────────────────────────────
12. ADDITIONAL REQUIRED REPORT CONTENT
──────────────────────────────────────────────────────────────────────────────

In addition to every section required by the governing V3 audit prompt,
include:

1. Process-authority split
2. Complete carrier list
3. Platform-carrier-index result
4. Phase-record continuity
5. Child-process-record continuity
6. Four-auditor transcript/retained-report reconciliation
7. Explicit statement that no persistent supervisor was used
8. Explicit statement that the audit root does not self-attest its carrier
   launch

Additional required confirmations:

PERSISTENT_SUPERVISOR_NOT_USED
PLATFORM_TRANSCRIPT_IS_CARRIER_LAUNCH_AUTHORITY
AUDIT_ROOT_DOES_NOT_SELF_ATTEST_CARRIER_CREATION
TOP_LEVEL_CARRIERS_COMPLETELY_INDEXED
TOP_LEVEL_PHASE_RECORDS_COMPLETE_AND_CONTIGUOUS
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_TARGET_FACING_TOOL_CALL_BYPASSED_PHASE_RECORDING
NO_CHILD_PROCESS_BYPASSED_CHILD_RECORDER
FOUR_AUDITOR_INTERACTIONS_RECONCILED
```

Use this override with a **fresh audit root** and otherwise execute the previous
complete V3 independent-audit prompt unchanged.

## Why this is the right correction

Another persistent-session attempt would contradict the capability evidence. A chained self-recording workaround would add a new, unqualified transport. The transcript-authoritative split instead assigns each fact to the system that can actually observe it:

- Codex platform: parent carrier starts and auditor scheduling.
- Audit code: child processes, bytes, validation, artifacts, and closing state.

That is the narrowest correction and avoids another layer of audit-harness development.

### Source

Codex persistent-supervisor capability report in your message.

**Confidence:** 0.999 that V3 remains unaffected; 0.995 that the persistent-supervisor requirement must be retired; 0.96 that the transcript-authoritative carrier model is the most proportionate supported replacement.
