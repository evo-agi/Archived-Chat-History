Codex stopped exactly where it should. More importantly, the stop exposes a flaw in **my previous A5 plan**: I over-constrained the repair by requiring the child to become the sole process-group establisher while assuming an existing launch-acknowledgement channel.

The absence of that channel is real, but adding one is probably unnecessary. POSIX’s job-control rationale explicitly describes calling `setpgid()` in **both the child and parent** as useful for resolving the two launch races: the child must enter the group before `exec`, and the parent must establish the group before signaling it.  The defect is therefore not inherently the dual invocation. It is that:

- the child interprets `undef` numerically and can falsely treat failure as success;
- the parent ignores its result;
- neither side applies an explicit, closed final-state reconciliation rule.

The reproduced child `undef/EPERM` plus successful parent call and `PGID == PID` is potentially a **benign race outcome that must be explicitly verified**, not necessarily converted into exit 120. Forcing child-only establishment would replace a small return-handling defect with a new launch protocol and significantly widen the supervisor.

The correct next tranche remains **repository-only Repair 10I-A5**, but with a corrected dual-`setpgid` contract. A4 remains unchanged. After A5 changes repository bytes, B5 must start over; prior downstream controls cannot qualify the new source. That restart principle is already explicit in the sealed A2 lineage. 

Pass this to Codex:

```text
Objective

Implement Repair 10I-A5 as a bounded correction to the existing dual-setpgid
process-group establishment protocol in the shell bounded Git supervisor.

This prompt supersedes the prior child-sole A5 plan.

Do not introduce a new launch-ready pipe, acknowledgement protocol, sideband
channel, or public/test configuration surface.

The intended pattern retains one child setpgid attempt and one parent setpgid
attempt, but makes both attempts explicit, checked, causally reconciled, and
fail-closed.

This is a repository-only implementation and validation turn.

No subagents. You are the sole writer.

Do not start Repair 10I-B5.
Do not create a ZIP, handoff, capture child, or strategic snapshot.
Do not edit successor source.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, execute Linux binaries, or claim independent acceptance.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

New evidence child, required absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- source T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- source inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require the A5 evidence child to be absent.

Completely reverify:

Repair 10I-A:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a
- manifest:
  dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7
- payloads:
  334

Repair 10I-A2:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800
- manifest:
  f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7
- payloads:
  210

Repair 10I-A3:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800
- manifest:
  a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b
- payloads:
  292

Repair 10I-A4:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800
- successor T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

Phase H:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d
- manifest:
  fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb
- payloads:
  6,191

Require B, B2, B3, and B4 to remain byte-exact and unsealed.

Require the divergence-reconciliation child to remain byte-exact:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-divergence-recon-4dd211207800

Stop before editing on any mismatch:

REPAIR10I_A5_BASELINE_MISMATCH

## 2. Corrected finding and contract

Adopt:

ID:
REPAIR10I-A5-PROCESS-GROUP-001

Type:
bounded supervisor process-group establishment and error-reconciliation defect

Severity:
HIGH

Classification:
T2A-P Bounded slice rule defect

The confirmed vulnerable state is:

- child setpgid(0,0) returned undef with EPERM;
- parent setpgid(pid,pid) succeeded;
- the resulting child PGID already equalled the child PID;
- the child evaluated undef numerically;
- Perl emitted an uninitialized-value warning;
- the numeric comparison incorrectly selected the success branch.

The repair must distinguish:

1. syscall-call success;
2. race-permitted syscall failure;
3. independently observed final process-group state;
4. irreconcilable or uncertain failure.

The two setpgid attempts are retained to close opposite launch races.

Neither invocation may ignore its result.

A failed invocation may be reconciled only when:

- its errno is in a closed, documented, platform-proved race set;
- a fresh process-group observation proves the intended child is in the group
  whose PGID equals the child PID;
- the process identity is still the intended child;
- no session mismatch, child disappearance, PID reuse, or observation
  uncertainty remains.

The exact accepted errno set must be derived from the private causal matrix.
Do not broadly accept every EPERM, EACCES, or ESRCH.

ESRCH, identity uncertainty, wrong PGID, session uncertainty, observation
failure, or an unclassified errno is not successful establishment.

## 3. Authorized repository scope

Exactly these seven existing files may change:

1. PLANS.md
2. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
3. .docs/system_overview/boundaries.md
4. .docs/system_overview/capability_probing.md
5. docs_contract_test.go
6. remote_alpha_prepare_external_tls_status_test.go
7. scripts/remote_alpha_prepare_external_tls_status.sh

No repository file may be added, removed, renamed, or mode-changed.

Every other repository file is protected, including package.go,
package_test.go, schema.go, operator production, production main packages,
go.mod, go.sum, policy-core production, and status-observation production.

Do not modify A4 or any other successor/evidence lineage.

## 4. Pre-edit platform and capability gate

Before modifying repository bytes, use an isolated private harness to establish:

- the exact return representation of successful and failed Perl setpgid;
- errno capture immediately after failure;
- availability and exact behavior of the process-group observation primitive
  used by the script;
- child-first behavior;
- parent-first behavior;
- observed child undef/EPERM after parent success;
- parent failure after child establishment, if reproducible;
- both-attempt failure or wrong-final-group behavior;
- child disappearance behavior;
- process identity stability across each observation.

The harness must prove that a final-state reconciliation is implementable
without a new sideband protocol.

The minimum causal matrix is:

A. Child succeeds; parent succeeds or observes the already-correct group.
   Result: established.

B. Parent succeeds first; child returns undef/EPERM; child observes its own
   process group equal to its PID.
   Result: established, no warning, child may continue.

C. Child succeeds first; parent invocation returns a documented race error;
   parent observes the exact child in PGID=PID.
   Result: established.

D. Child invocation fails and child observes PGID != PID.
   Result: child exits bootstrap code 120 before chdir/redirection/exec.

E. Parent invocation fails and parent cannot prove exact child PGID=PID.
   Result: bootstrap failure; no group signaling on an unproved PGID; reap and
   cleanup remain bounded.

F. Child has exited or identity is uncertain.
   Result: never reinterpret as successful group establishment.

Retain exact argv, source, outputs, errno values, process identities, and
cleanup evidence.

If a robust final-state reconciliation cannot be implemented with the
available primitives, stop without editing:

REPAIR10I_A5_REQUIRES_NEW_PROTOCOL_REFREEZE

Do not add a sideband protocol in this turn.

## 5. Docs-first contract

Update the governing plan and bounded contracts to state:

- the bounded supervisor deliberately performs one child and one parent
  setpgid attempt to close opposite fork/exec/signaling races;
- both results are inspected;
- undefined Perl return values are never numerically interpreted;
- each side captures errno before another syscall can overwrite it;
- a call-level failure is accepted only through the closed, documented
  race-reconciliation rule and exact final-state observation;
- observed PGID=PID does not excuse an arbitrary or unclassified error;
- the parent may not signal the group until it has established or reconciled
  the exact child PGID;
- the child may not chdir, rebind descriptors, or exec until it has established
  or reconciled its own PGID;
- an irreconcilable child-side bootstrap failure exits 120;
- an irreconcilable parent-side setup failure blocks launch and performs
  bounded cleanup/reaping;
- one Wait, deadline, output-cap, pipe-EOF, TERM→KILL, and final group-absence
  behavior remains unchanged.

Reject in docs_contract_test.go:

- numeric comparison of an untested possibly-undef return;
- ignored parent return;
- acceptance of EPERM/EACCES/another errno without final-state proof;
- final-state proof without process-identity proof;
- parent group signaling before establishment;
- child exec before establishment;
- generic acceptance of ESRCH;
- introducing a public process-group override or test mode;
- claiming the parent or child is the sole establisher.

This is a bounded Repair 10I-A5 refinement. It does not alter public CLI,
JSON schema, blockers, paths, installation, T2A-I, T2B, or authority.

## 6. Production implementation

Child branch:

1. Call setpgid(0,0) exactly once.
2. Store the return value.
3. Check definedness before any numeric comparison.
4. On defined zero, mark call success.
5. On undef:
   - capture errno immediately;
   - allow reconciliation only for the exact documented race error;
   - freshly observe the calling process’s PGID;
   - require PGID == PID;
   - otherwise _exit(120).
6. A defined nonzero return is failure unless the platform capability gate
   proves that representation has a governed meaning.
7. Do not emit an uninitialized-value warning.
8. Do not chdir, rebind stdout/stderr, notify downstream execution state, or
   exec before establishment/reconciliation succeeds.

Parent branch:

1. Call setpgid(pid,pid) exactly once.
2. Store and inspect its result and errno.
3. On success, mark the exact child group established.
4. On failure:
   - permit only the closed documented race cases;
   - revalidate child identity;
   - observe the child’s PGID;
   - require PGID == PID;
   - otherwise treat setup as failed.
5. Never ignore ESRCH or another failure.
6. Never send a group signal before establishment is proven.
7. On unproved establishment:
   - avoid killpg against an unproved group;
   - use only the bounded, identity-safe cleanup available for the exact child;
   - inspect one Wait;
   - close and drain resources;
   - block the operation.

Preserve all other supervisor contracts.

Do not add a third setpgid call, a polling loop without a strict bound, a
launch pipe, an environment override, or an exported test hook.

## 7. Deterministic causal tests

Retain the vulnerable pre-repair causal before editing.

After repair, causally prove:

1. Parent-first benign race:
   - parent call succeeds;
   - child returns undef/EPERM;
   - child observes PGID=PID;
   - no warning;
   - child continues;
   - command executes normally.

2. Child-first benign race:
   - child succeeds;
   - parent receives its documented race outcome;
   - parent observes exact child PGID=PID;
   - normal execution completes.

3. Child failure, wrong group:
   - child returns undef;
   - PGID != PID;
   - child exits 120 before chdir/redirection/exec.

4. Parent failure, wrong or unknown group:
   - parent does not signal the unproved group;
   - launch is blocked;
   - exact child is reaped;
   - no descendant or resource survives.

5. Child disappearance or PID/identity uncertainty:
   - never accepted as establishment.

6. Both-success control.

7. Existing one-pipe-closes-first, both-pipes, timeout, cap, child-exit, TERM,
   KILL, group-release, and result controls remain correct.

Required inverse mutants:

- restore `undef == 0`;
- ignore the parent return;
- accept EPERM without PGID verification;
- accept wrong PGID;
- accept ESRCH;
- signal group before parent establishment;
- exec before child establishment;
- call setpgid more than once on either side.

Every mutant must be killed by a production-path causal test.

Mutation/injection remains private to tests. No production hook or public
surface.

## 8. Stability validation

Run:

/bin/bash -n scripts/remote_alpha_prepare_external_tls_status.sh

gofmt -d \
  docs_contract_test.go \
  remote_alpha_prepare_external_tls_status_test.go

git diff --check

Focused count-one:

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaExternalTLST2APRepair10Contract|TestRepair10IDualSetpgidRaceReconciliationV1|TestRepair10ISetpgidFailureRequiresExactGroupProofV1|TestRepair10ISetpgidInverseMutantsV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

Focused count-three:

go test -json -count=3 -p=1 -parallel=1 . \
  -run '^(TestRepair10IDualSetpgidRaceReconciliationV1|TestRepair10ISetpgidFailureRequiresExactGroupProofV1|TestRepair10ISetpgidInverseMutantsV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

Targeted race:

go test -race -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRepair10IDualSetpgidRaceReconciliationV1|TestRepair10ISetpgidFailureRequiresExactGroupProofV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

Run three physically disjoint controls, each:

go test -json -count=30 -p=1 -parallel=1 . \
  -run '^TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/one_pipe_closes_first$'

Also run deterministic parent-first and child-first controls repeatedly, so the
repair is not accepted merely because the natural scheduler race did not occur.

Every control uses private source, HOME, XDG, GOPATH, GOMODCACHE, GOCACHE,
GOTMPDIR, TMPDIR, process group, streams, and evidence roots.

No required skip is permitted.

Any warning, panic, race, hang, timeout, malformed stream, duplicate/missing
terminal, survivor, forced cleanup, unclosed pipe, or unproved group blocks A5.

## 9. Broader repository validation

Run the governed external-TLS regression using the exact private
repository/commit/tree construction accepted in Repair 10I-A.

All formerly environment-gated required tests must run and pass.

Then run:

go mod verify

go vet ./...

Do not represent inherited repository-wide failures as passes.

A private deterministic build smoke is permitted but is not artifact
acceptance and is not required to establish this shell-only repair.

## 10. A4 compatibility

A4 remains byte-immutable.

Use sealed A4 tooling in a bounded nonqualifying compatibility preflight over
the final A5 focused and regression streams.

Require:

- well-formed extraction;
- zero new unknowns caused by A5 diagnostics or source-line shifts;
- unchanged successor bytes;
- no attempt to reuse B4 as B5 qualification.

If exact A5 bytes expose an A4 grammar incompatibility, stop:

REPAIR10I_A5_SUCCESSOR_COMPATIBILITY_BLOCKED

Do not patch A4 in this turn.

## 11. Evidence and closeout

Create the A5 evidence child only after the opening gate and capability gate.

Retain:

- opening baseline and immutable-lineage verification;
- corrected architectural adjudication that dual setpgid is intentional;
- the superseded child-sole plan and A5 plan-conflict report;
- B4 raw direction: final pass, fresh fail;
- pre-repair vulnerable causal;
- platform/capability matrix;
- exact seven-path delta;
- docs and contract mapping;
- every command intent, argv, cwd, environment, streams through EOF, exit,
  Wait, terminal reconciliation, and resource disposition;
- every causal and inverse-mutant result;
- focused/count-three/race/disjoint count-thirty evidence;
- external-TLS regression, module verification, and vet;
- A4 compatibility preflight;
- failed and superseded attempts;
- cleanup and two absence epochs;
- implementation report;
- final inventory, T, and exact path tuples.

Closeout requires:

- exactly the seven authorized paths changed;
- zero additions, removals, renames, or mode changes;
- all other repository members byte-identical;
- branch/HEAD/parent/HEAD tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged = 0/0/0/0;
- A/A2/A3/A4/H/B/B2/B3/B4 and divergence-recon unchanged;
- no Git operation marker or lock;
- no private source, cache, process, group, descriptor, stream, socket,
  listener, runtime root, PackageFloor, generation, build, or report residue;
- two fresh absence epochs.

Install detached digest before the evidence manifest.

Install evidence-manifest-v1.txt as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 12. Stop conditions and verdicts

Opening mismatch:

REPAIR10I_A5_BASELINE_MISMATCH

Final-state reconciliation unavailable without a new protocol:

REPAIR10I_A5_REQUIRES_NEW_PROTOCOL_REFREEZE

Source or scope problem:

REPAIR10I_A5_SOURCE_REPAIR_BLOCKED

Successor compatibility problem:

REPAIR10I_A5_SUCCESSOR_COMPATIBILITY_BLOCKED

Validation, cleanup, or sealing failure:

REPAIR10I_A5_VALIDATION_BLOCKED

Complete success:

REPAIR10I_A5_DUAL_SETPGID_REPAIR_SEALED_READY_FOR_B5_RESTART

The success report must include:

- opening/final T, inventory, and membership;
- exact seven-path delta;
- platform return/errno/final-state matrix;
- vulnerable branch reproduction;
- parent-first and child-first repaired results;
- wrong-group, disappearance, and inverse-mutant results;
- proof that neither return is ignored;
- focused/count-three/race/count-thirty totals;
- external-TLS regression and skip count;
- A4 compatibility;
- module/vet;
- evidence manifest and payload count;
- cleanup and two absence epochs;
- explicit statement that B5 was not started.

No B5.
No snapshot.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A5, the downstream lifecycle is unchanged: new implementation bytes require a completely fresh B5 and, after capture, a fresh independent audit. The project protocol requires repair bytes to receive new validation and a new audit; prior audit or validation does not remain binding after any byte change. 

### Sources

- Codex’s `REPAIR10I_A5_PLAN_CONFLICT` report in the current turn.
- POSIX `setpgid()` specification and job-control rationale. 
- Repair 10I-A2 restart boundary. 
- Governed Execution repair and re-audit protocol. 
- Governed Execution provenance limitations. 

**Confidence:** 0.99 that Codex’s stop was correct against the frozen child-sole plan; 0.96 that retaining dual `setpgid` attempts with strict return and final-state reconciliation is the smallest sound repair; 0.85 that no new sideband protocol is needed, pending the private Perl/Darwin capability matrix; 0.995 that any A5 byte change requires a completely fresh B5 and later independent audit.
