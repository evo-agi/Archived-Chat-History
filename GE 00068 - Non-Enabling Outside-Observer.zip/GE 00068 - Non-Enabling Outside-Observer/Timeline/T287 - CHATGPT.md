## Assessment

`AUDIT_PROVENANCE_MISMATCH` is correct. This attempt failed entirely inside the bootstrap and produced **no information about the V3 audit-repair capsule**.

The bootstrap invented an acceptance condition that the retry brief did not authorize:

- Required interpreter facts: exact path, Python 3.13.4, regular file, one link, 119,424 bytes, pinned SHA-256.
- Observed: all required facts matched.
- Unauthorized rejection: permission bits were `0775`.

The permission bits must not be added to the interpreter identity contract now. `0775` is also not inherently inconsistent with an installed executable. The exact byte identity and successful execution through the pinned path are the relevant controls for this audit.

The next attempt should repeat the full audit unchanged, with four narrow bootstrap corrections:

1. Interpreter acceptance uses an **explicit closed field set**. Permission bits, owner, group, and ancestor posture are report-only.
2. The fresh audit-root path is emitted and retained immediately after allocation, before interpreter or wrapper checks.
3. The unlocated root from this failed attempt is not searched for, adopted, reused, or cleaned.
4. The mode-`0600` wrapper is still invoked through pinned Python with `-I -S -B`.

No V3 repair, wrapper repair, runtime replay, or additional capability probe is justified.

## Send this continuation to Codex

```text
FRESH RETRY — CLOSED INTERPRETER-IDENTITY CONTRACT AND
BOOTSTRAP-ROOT RETENTION FOR THE VALIDATION-CUSTODY V3
AUDIT-REPAIR INDEPENDENT AUDIT

Repeat the immediately preceding full independent-audit brief from the
beginning with a wholly fresh audit root.

The complete target scope, supplied inputs, fixed identities, static audit
requirements, four-auditor schedule, mutation matrix, manifest causals,
closing gates, verdict rules, and required report remain unchanged.

The only authorized changes are the bootstrap and interpreter-admission rules
below.

Do not modify or repair the V3 audit-repair capsule.
Do not modify the generic wrapper.
Do not change Plan V4.
Do not rerun runtime validation.
Do not inspect or attempt to discover the unreported audit root from the
immediately preceding failed attempt.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. PRECEDING FAILURE DISPOSITION
──────────────────────────────────────────────────────────────────────────────

The preceding attempt failed because its bootstrap introduced an unauthorized
interpreter permission-mode predicate.

The pinned interpreter matched every field required by the prior brief:

- path:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
- version:
  Python 3.13.4
- regular file:
  true
- link count:
  1
- size:
  119424 bytes
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Its observed physical permission bits were 0775.

The prior brief did not constrain those permission bits. Rejecting 0775 was an
audit-process defect.

The failed bootstrap allocated a fresh root but did not emit its exact path.

Required treatment:

- Do not scan `/Users/ds/Downloads` for that root.
- Do not select by prefix, newest entry, timestamps, or process history.
- Do not adopt, resume, rename, clean, or mutate an inferred root.
- Do not make that unknown root an input to this fresh audit.
- Do not claim global cleanup of all prior failed audit roots.
- Treat it as an unlocated, immutable, nonqualifying process-failure artifact.

This disposition is not a supplied-input mismatch and is not a V3 target
finding.

──────────────────────────────────────────────────────────────────────────────
2. CLOSED INTERPRETER ACCEPTANCE FIELD SET
──────────────────────────────────────────────────────────────────────────────

The interpreter acceptance field set is closed and contains exactly:

1. exact absolute path;
2. version string;
3. regular-file type;
4. link count equal to 1;
5. byte size;
6. SHA-256.

Required accepted identity:

- path:
  /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
- version:
  Python 3.13.4
- regular:
  true
- links:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

No other interpreter property is acceptance-bearing in this audit.

The following may be observed and recorded, but are report-only and must not
change the pass/fail result:

- physical permission bits;
- uid;
- gid;
- owner name;
- group name;
- device;
- inode;
- timestamps;
- flags;
- xattrs;
- ancestor permissions;
- ancestor ownership;
- group writability;
- `os.access` results beyond actual process launch.

Specifically:

- mode 0775 must not be rejected;
- mode 0775 must not be added to the frozen cross-audit identity;
- do not chmod or normalize the interpreter;
- do not infer a new trusted-installation contract;
- do not inspect or enforce an unstated owner/group policy.

File-type bits may be used only to establish that the object is a regular
file. Permission bits are report-only.

The successful creation of a child process through the exact pinned
interpreter path is the behavioral execution-capability observation.

If any bootstrap implementation applies an acceptance predicate outside this
closed list, stop with AUDIT_PROVENANCE_MISMATCH and identify the unauthorized
predicate.

──────────────────────────────────────────────────────────────────────────────
3. BOOTSTRAP ROOT MUST BE RETAINED BEFORE OTHER CHECKS
──────────────────────────────────────────────────────────────────────────────

The bootstrap remains the sole permitted unwrapped local-process carrier.

Its first operations must be:

1. Set umask 077.
2. Allocate one fresh root beneath `/Users/ds/Downloads` using
   `tempfile.mkdtemp` with the exact prefix from the preceding full-audit
   brief.
3. Create the required opening directory.
4. Exclusively create and fsync:

   opening/bootstrap-start.json

5. Emit exactly one line to captured stdout:

   AUDIT_ROOT=<exact-absolute-path>

Only after the root path has been retained and emitted may the bootstrap:

- create the remaining audit directories;
- inspect the accepted wrapper source;
- copy the wrapper;
- inspect the pinned interpreter;
- apply the closed identity checks in §2.

The bootstrap-start record must include:

- exact audit-root path;
- root device and inode;
- root mode;
- bootstrap cwd;
- explicit environment;
- umask;
- prefix;
- allocation method;
- status:
  `bootstrap-started`;
- target-inspection-performed:
  false.

Before bootstrap return, always exclusively create and fsync:

opening/bootstrap-outcome.json

On success, record:

- status:
  `bootstrap-qualified`;
- wrapper identity;
- wrapper destination;
- wrapper mode;
- interpreter closed-field identity;
- interpreter report-only observations;
- authorized next carrier ordinal.

On any bootstrap failure, record:

- status:
  `bootstrap-failed`;
- failed operation;
- exception type and canonical message;
- every completed retained artifact;
- exact audit-root path;
- confirmation that target inspection did not begin.

A bootstrap failure must never again leave the fresh root locator unknown.

──────────────────────────────────────────────────────────────────────────────
4. WRAPPER IDENTITY AND MODE
──────────────────────────────────────────────────────────────────────────────

Accepted wrapper source:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns/provenance/phase_runner.py

Expected:

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- regular:
  true
- links:
  1
- physical mode:
  0600

Copy its exact bytes to:

$AUDIT_ROOT/provenance/phase_runner.py

Preserve mode 0600.

The wrapper is private Python source and must not be treated as an executable.

Forbidden:

- direct execution;
- using it as argv[0];
- chmodding it;
- copying it to mode 0700 or 0755;
- relying on a shebang;
- shell sourcing;
- import-based execution;
- changing its bytes.

──────────────────────────────────────────────────────────────────────────────
5. EXACT WRAPPER INVOCATION
──────────────────────────────────────────────────────────────────────────────

Every wrapped carrier must invoke:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  "$AUDIT_ROOT/provenance/phase_runner.py" \
  <exact wrapper arguments>

Use the exact CLI field map defined by the accepted wrapper and demonstrated by
the successful generic phase-wrapper probe.

Do not invent alternate argument names or ordering.

Required explicit environment includes:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Use audit-owned private values for any required HOME and TMPDIR.

Do not use:

PYTHONPATH
user site packages
system site packages
repository Python modules
an executable wrapper copy
an import loader in place of the script operand

The wrapper must remain the script operand to the pinned interpreter.

──────────────────────────────────────────────────────────────────────────────
6. FIRST WRAPPED CARRIER SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Before target or supplied-root inspection, use Carrier 0002 for one
audit-owned wrapper-launch self-check.

The retained payload must:

- be regular, single-link mode 0600;
- use only the Python standard library;
- read no target or supplied root;
- create no child process;
- write one expected private result beneath the fresh audit root;
- return success.

Require:

- phase-start record created and fsynced before payload read or compilation;
- phase-outcome record created and fsynced after execution;
- copied wrapper identity exact;
- wrapper mode 0600;
- pinned interpreter closed-field identity exact;
- interpreter flags exactly `-I -S -B`;
- payload identity exact;
- payload compiled and executed;
- expected result created at mode 0600;
- no direct wrapper execution;
- no permission error;
- no bytecode;
- no target inspection.

Stop with AUDIT_PROVENANCE_MISMATCH if this self-check fails.

Do not try an alternative launch shape within the same audit.

──────────────────────────────────────────────────────────────────────────────
7. CHILD-RECORDER CAUSALS AND FULL AUDIT
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 qualifies, perform the child-recorder self-causals from the
preceding full-audit brief:

- absent executable / ENOENT;
- `/usr/bin/true` / exit 0.

Only after both qualify may the opening provenance gate inspect targets.

Then execute the complete preceding full independent-audit brief unchanged:

- complete opening provenance;
- four direct auditors;
- normative-authority audit;
- V2 adoption and correction audit;
- V3 and Plan static semantic audit;
- independent mutation matrix;
- manifest-generator source review and dynamic causals;
- real capsule closure;
- final inventory temporal adjudication;
- terminal sensitive-material scan;
- closing equality;
- process reconciliation;
- exact-private-path cleanup;
- final audit inventory.

No target requirement is removed or weakened.

──────────────────────────────────────────────────────────────────────────────
8. CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

For bootstrap, bind:

- bootstrap-start record;
- bootstrap-outcome record;
- exact emitted audit-root locator;
- platform result.

For every wrapped carrier, retain the stable fields from the previous brief
plus:

- interpreter path;
- interpreter version;
- interpreter size;
- interpreter SHA-256;
- interpreter flags:
  `["-I", "-S", "-B"]`;
- observed interpreter permission bits:
  report-only;
- interpreter permission predicate applied:
  false;
- wrapper mode:
  `0600`;
- invocation type:
  `interpreter-mediated-python-source`;
- direct wrapper execution:
  false.

The Codex platform transcript remains top-level carrier launch and ordering
authority.

Do not require unavailable opaque tool-internal command serialization.

──────────────────────────────────────────────────────────────────────────────
9. STOP RULES
──────────────────────────────────────────────────────────────────────────────

Return AUDIT_PROVENANCE_MISMATCH for:

- failure to retain or emit the fresh root before later bootstrap checks;
- interpreter mismatch in any of the six closed acceptance fields;
- use of an unauthorized interpreter acceptance predicate;
- wrapper mismatch;
- direct wrapper execution;
- wrapper chmod or executable copy;
- failed wrapper self-check;
- missing carrier record;
- missing child quartet;
- actual supplied-input mismatch or drift;
- unrecorded local process.

Do not return a target-level BLOCK for those audit-process failures.

After wrapper and process gates pass, use the original target-level verdict
rules from the preceding full-audit brief.

──────────────────────────────────────────────────────────────────────────────
10. REQUIRED REPORT ADDITIONS
──────────────────────────────────────────────────────────────────────────────

In addition to every item required by the preceding full-audit brief, report:

1. Exact audit-root locator emitted by bootstrap.
2. Bootstrap-start identity.
3. Bootstrap-outcome identity.
4. Pinned interpreter closed-field identity.
5. Observed interpreter permission bits as report-only.
6. Confirmation that no permission-mode predicate was applied.
7. Wrapper mode and identity.
8. Exact interpreter-mediated launch shape.
9. Carrier 0002 self-check result.
10. Confirmation every later wrapped carrier used the same contract.
11. Disposition of the unknown-root preceding attempt:
    unlocated, immutable, nonqualifying, not searched, not adopted, not
    cleaned.

Add these required confirmations:

AUDIT_ROOT_RETAINED_BEFORE_INTERPRETER_CHECK
AUDIT_ROOT_EMITTED_BEFORE_INTERPRETER_CHECK
BOOTSTRAP_START_RETAINED
BOOTSTRAP_OUTCOME_RETAINED
INTERPRETER_ACCEPTANCE_FIELD_SET_CLOSED
INTERPRETER_PERMISSION_BITS_REPORT_ONLY
NO_UNAUTHORIZED_INTERPRETER_PREDICATE_APPLIED
PINNED_PYTHON_IDENTITY_VERIFIED
WRAPPER_RETAINED_MODE_0600
WRAPPER_NOT_EXECUTED_DIRECTLY
WRAPPER_NOT_CHMODDED
WRAPPER_NOT_COPIED_AS_EXECUTABLE
WRAPPER_INVOKED_THROUGH_PINNED_PYTHON
WRAPPER_INVOKED_WITH_ISOLATION_FLAGS
WRAPPER_LAUNCH_SELF_CHECK_PASSED
ALL_WRAPPED_CARRIERS_USED_SAME_INTERPRETER_CONTRACT
UNKNOWN_FAILED_ROOT_NOT_SEARCHED
UNKNOWN_FAILED_ROOT_NOT_ADOPTED
UNKNOWN_FAILED_ROOT_NOT_MUTATED

Retain all confirmations and requirements from the preceding full-audit brief.
Do not otherwise narrow, simplify, or change it.
```

This should return directly to the complete independent audit. Another generic probe would add no useful information.

**Source:** Codex’s bootstrap `AUDIT_PROVENANCE_MISMATCH` report immediately above.

**Confidence:** 0.999 that the rejection came solely from an unauthorized interpreter-mode predicate; 0.998 that the pinned interpreter satisfies every specified identity condition; 0.99 that retaining and emitting the root before all discretionary bootstrap checks prevents recurrence of the unlocated-root failure.
