## Engineering assessment

The replacement construction remains available. The production parent was never created, so the replacement one-shot authorization is still unconsumed.

The preceding wrapper stopped for two wrapper-owned reasons:

1. It made the **partial, unsealed, explicitly nonqualifying failed-reconciliation root** an acceptance-bearing construction input.
2. Its closing-equality aggregation failed without identifying any supplied root that actually drifted.

Neither result establishes a defect in the accepted production parent, the fixed construction inputs, or the historical subject.

### The provenance gate was overconstrained

The failed reconciliation root was already classified as:

- partial;
- unsealed;
- nonqualifying;
- missing substantive A06/A07/A08/A11 adjudication;
- not eligible to authorize repair ownership;
- not eligible for same-root retry.

Requiring that root to contain a complete failure report, closeout, terminal records, and partial inventory before allowing terminal stop-and-reconstruct made a known nonauthority root authoritative over the forward treatment. That contradicts the purpose of `TERMINAL_STOP_AND_RECONSTRUCT`.

The forward treatment is authorized by the explicit terminal decision in this conversation:

- the historical subject remains blocked and noncurrent;
- the historical BLOCK remains unchanged;
- no further findings reconciliation is authorized;
- fresh replacement construction is the selected forward path;
- the replacement must later undergo a fresh independent audit.

The failed reconciliation root should therefore be **excluded from construction fixed inputs**. It may remain preserved as historical nonqualifying evidence, but the next wrapper must neither open it nor require it to be complete.

### The closing-equality failure is not evidence of input drift

The report identifies no opening/closing mismatch for any acceptance-bearing supplied root. The historical subject, historical audit, accepted implementation audit, accepted source, source freeze, contract, content bundle, and content authority all authenticated successfully.

The wrapper nevertheless emitted:

```text
WRAPPER_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED=false
```

without retaining an exact mismatched role or opening/closing pair. That is a wrapper closeout/equality-aggregation defect or unresolved wrapper-reporting defect—not proof of supplied-root mutation.

The next wrapper should independently qualify its equality logic before construction:

- only roots actually opened as fixed inputs participate;
- each role gets an explicit opening/closing row;
- not-reached construction confirmations do not affect equality;
- equal empty cleanup sets pass;
- excluded historical evidence roots do not participate;
- aggregate pass is derived only from the per-role comparisons.

## Progression decision

Run replacement construction again in a **new wrapper root**, with the following correction:

- treat this prompt’s explicit forward-treatment directive as the construction authority;
- do not open the failed final-reconciliation root;
- do not make the previous failed replacement wrapper acceptance-bearing;
- qualify and freeze the new wrapper’s provenance and equality logic before platform preflight;
- if those gates pass, execute the already accepted production parent exactly once.

No new reconciliation, documentary package, production-source repair, implementation audit, or subject audit is warranted before that launch.

---

## Complete replacement Codex prompt

```text
EXECUTE ONE FRESH REPLACEMENT CURRENT-SCHEMA-SUBJECT CONSTRUCTION

CORRECT THE EXTERNAL WRAPPER’S FORWARD-AUTHORITY AND CLOSING-EQUALITY
GATES WITHOUT REOPENING THE FAILED FINAL RECONCILIATION

Objective

Execute exactly one fresh replacement current-schema-subject construction using
the independently accepted Generation-2 reconstruction-parent implementation.

The immediately preceding replacement-construction wrapper did not launch the
production parent.

Its replacement authorization remains unconsumed.

Its two blockers were wrapper-owned:

1. it required complete retained records from an explicitly partial, unsealed,
   nonqualifying failed-reconciliation root;

2. its closing-equality aggregate failed without retaining any exact supplied
   role whose opening and closing identities differed.

Correct those wrapper gates in a fresh wrapper root.

Do not rerun or repair the failed final reconciliation.

Do not open the failed final-reconciliation root.

Do not make that root an acceptance-bearing fixed input.

Do not perform another A06/A07/A08/A11 reconciliation.

Do not reinterpret, reverse, replace, or supersede the historical sealed BLOCK.

The forward treatment is explicitly authorized by this task:

- historical subject remains blocked and noncurrent;
- historical subject audit remains sealed and historical;
- final findings reconciliation remains nonqualifying and terminal;
- further findings reconciliation is forbidden;
- fresh replacement-subject construction is required;
- the replacement subject must later receive one fresh independent audit;
- no authority promotion occurs in this task.

Do not modify the historical subject.

Do not modify the historical subject-audit capsule.

Do not modify the accepted implementation package or production source.

Do not repair production source.

Do not execute qualification source or audit-harness source.

Do not independently audit the replacement subject in this task.

Do not promote or rebind current schema authority.

Do not execute product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite, source-external construction wrapper in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTED_AND_TERMINALLY_CLOSED_PENDING_FRESH_INDEPENDENT_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXPLICIT FORWARD-TREATMENT AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before opening any historical or construction input, retain:

opening/forward-treatment-directive-v1.json

Its authority classification is:

EXTERNAL_COGNITIVE_ENGINEERING_DIRECTIVE

Retain these exact decisions:

- historical subject verdict:
  GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK;

- historical subject current:
  false;

- historical BLOCK reversed:
  false;

- further A06/A07/A08/A11 reconciliation authorized:
  false;

- failed final reconciliation qualifying:
  false;

- failed final reconciliation required as a construction fixed input:
  false;

- failed final reconciliation may be opened:
  false;

- failed final reconciliation may authorize repair ownership:
  false;

- mandatory forward treatment:
  FRESH_REPLACEMENT_SUBJECT_CONSTRUCTION;

- replacement construction count authorized:
  1;

- replacement authorization consumed:
  false before process creation;

- replacement subject requires later fresh independent audit:
  true;

- construction and independent audit combined:
  false;

- current-authority promotion:
  false;

- product/runtime/target/publication/deployment/A6 authority:
  false.

This directive changes only forward execution authority.

It does not change historical facts.

Retain:

opening/forward-treatment-authority-boundary-v1.json

Require that no file in the failed final-reconciliation root is used as:

- fixed input;
- construction authority;
- repair-owner authority;
- equality operand;
- source authority;
- invocation authority;
- subject-content input.

──────────────────────────────────────────────────────────────────────────────
2. HISTORICAL SUBJECT
──────────────────────────────────────────────── LIMITED TO PRESERVATION
────────────────────────────────────────────────

HISTORICAL_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-25kljb3m

Expected root identity:

- device:
  16777234
- inode:
  182600670
- mode:
  0700
- UID:
  501
- GID:
  20

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  c3f5e291a35b2bfc0a4d00e93216c298bcc985e7964acaab700bb41c1a80c5bd

Expected manifest A:

manifest/canonical-manifest-a-v1.json

- size:
  16620
- SHA-256:
  43e5e3f726c62d144ca616412252af7fd2073abed71df3279e71581f97049ec8

Expected manifest B:

manifest/canonical-manifest-b-v1.json

- size:
  16620
- SHA-256:
  43e5e3f726c62d144ca616412252af7fd2073abed71df3279e71581f97049ec8

Authenticate read-only:

- root identity;
- temporal identity;
- A/B identity and equality;
- terminal physical closure;
- historical subject-audit linkage;
- blocked/noncurrent posture.

Classify:

HISTORICAL_BLOCKED_SUBJECT_NONCURRENT

Require:

- mutation:
  forbidden;
- cleanup:
  forbidden;
- same-root reuse:
  forbidden;
- repair in place:
  forbidden;
- replacement output path:
  forbidden;
- current-authority contribution:
  none.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. HISTORICAL SEALED SUBJECT AUDIT
──────────────────────────────────────────────── LIMITED TO HISTORICAL BOUNDARY
────────────────────────────────────────────────

HISTORICAL_SUBJECT_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-current-schema-subject-independent-audit-u3nnutm4

Expected root identity:

- device:
  16777234
- inode:
  182616808
- mode:
  0700
- UID:
  501
- GID:
  0

Expected historical verdict:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK

Expected audit temporal inventory:

- size:
  14818
- SHA-256:
  9430d301ecba2ab7d5ee1b9e6596221c82e7caaf01d0b2c3d38908f2729be84b

Expected audit manifest pair:

- size:
  15350 each;
- SHA-256:
  cd323c84fa1904ae13e1d2b57beb14c06f48d19cc50876d199e4c4f7131fed06.

Authenticate read-only:

- root identity;
- temporal and manifest identities;
- A/B equality;
- final reprojection;
- one seal transition;
- no postseal operation;
- historical BLOCK;
- zero historical provenance errors.

Do not adjudicate the four historical findings.

Do not use the historical audit source as a current source.

Classify:

HISTORICAL_TERMINAL_BLOCK_AUDIT_NONCURRENT

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. FAILED FINAL RECONCILIATION EXCLUSION
────────────────────────────────────────────────

Known historical path:

/private/tmp/ES-repair10i-v3-current-schema-subject-block-final-reconciliation-jethgbgl

Do not open this path.

Do not `stat`, `lstat`, inventory, traverse, read, hash, execute, clean, or
compare it.

Do not scan for another reconciliation root.

Retain:

opening/failed-final-reconciliation-exclusion-v1.json

Required facts:

- classification:
  HISTORICAL_NONQUALIFYING_PARTIAL_UNSEALED_RECONCILIATION;

- substantive A06/A07/A08/A11 adjudication:
  not reached;

- historical BLOCK effect:
  unchanged;

- forward construction authority:
  none;

- fixed-input status:
  excluded;

- opening/closing equality operand:
  false;

- source/input/authority use:
  forbidden;

- further reconciliation:
  forbidden.

The existence, absence, completeness, or incompleteness of this path is not a
precondition for replacement construction.

──────────────────────────────────────────────────────────────────────────────
5. PREVIOUS FAILED REPLACEMENT WRAPPER
──────────────────────────────────────────────── LIMITED TO HISTORICAL WRAPPER DEFECT
────────────────────────────────────────────────

PREVIOUS_FAILED_REPLACEMENT_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-1jp957ag

Open only this exact root if present.

Do not scan for it.

Use it only to authenticate these historical wrapper facts:

- primary verdict:
  GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_PROVENANCE_MISMATCH;

- production-parent process created:
  false;

- replacement authorization consumed:
  false;

- platform preflight executed:
  false;

- replacement subject allocated:
  false;

- first provenance blocker:
  incomplete failed-reconciliation evidence;

- wrapper closing equality:
  failed without retained per-role drift adjudication;

- same-root retry:
  forbidden.

Classify:

HISTORICAL_NONCURRENT_PRELAUNCH_WRAPPER_GATE_DEFECT

It is not:

- construction authority;
- source authority;
- fixed construction input;
- supplied-root equality operand for the new wrapper.

If absent:

- do not search;
- retain the user-supplied operative report as historical wrapper evidence.

Do not modify or clean it.

──────────────────────────────────────────────────────────────────────────────
6. ACCEPTED IMPLEMENTATION AUTHORITY
──────────────────────────────────────────────── LIMITED TO ACCEPTED PARENT
────────────────────────────────────────────────

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected accepted wrapper report:

final-wrapper-report.json

- mode:
  0600
- size:
  38653
- SHA-256:
  a5faa8fc6a4a0617c605c04951ac2b0cce8877629a4663a9f66984f96afa595c

Expected accepted disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the chain required to establish:

- accepted implementation package;
- accepted production source;
- accepted source freeze;
- production source registry;
- qualification source registry;
- independent schema validator;
- construction-parent authority and nonauthority;
- exact invocation;
- fixed inputs;
- cleanup/failure contract;
- terminal-lifecycle contract;
- accepted implementation remains current and unsuperseded.

Do not re-audit the implementation package.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
7. CURRENT CONTENT AUTHORITY
──────────────────────────────────────────────── LIMITED TO ACCEPTED MATERIAL
────────────────────────────────────────────────

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before ZIP.

Resolve current construction inputs through:

accepted implementation audit
→ exact content role
→ bundle index
→ exact member path and identity.

Do not use the containing directory as authority.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
8. FRESH REPLACEMENT-CONSTRUCTION WRAPPER ROOT
──────────────────────────────────────────────── LIMITED TO EXTERNAL CUSTODY
────────────────────────────────────────────────

Allocate one fresh private root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v2-

Immediately emit:

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT=<absolute-path>

Before wrapper qualification retain:

opening/bootstrap-start.json
opening/forward-treatment-directive-v1.json
opening/replacement-construction-wrapper-authority-v1.json
opening/fixed-input-registry-v1.json
opening/excluded-historical-inputs-v1.json
opening/process-execution-policy-v1.json

The wrapper root may write only:

- wrapper source and qualification;
- fixed-input authentication;
- forward-treatment and replacement authorization;
- platform-preflight custody;
- production-parent custody;
- raw streams;
- locator adjudication;
- read-only replacement-subject validation;
- per-role opening/closing equality;
- final wrapper report.

The wrapper root is not subject-content authority.

──────────────────────────────────────────────────────────────────────────────
9. WRAPPER GATE AND EQUALITY CONTRACT
────────────────────────────────────────────────

Before writing wrapper source, retain:

contract/replacement-wrapper-provenance-gates-v1.json
contract/replacement-wrapper-closing-equality-v1.json

A. ACCEPTANCE-BEARING FIXED INPUTS

Enumerate exact roles before opening them.

Required fixed-input roles include only:

- historical blocked subject;
- historical sealed subject audit;
- accepted implementation audit root;
- accepted implementation wrapper root;
- current content bundle;
- current content authority;
- accepted implementation root;
- accepted successor root;
- normative contract root;
- current schema root;
- schema-reconciliation root;
- validation-specification root;
- accepted production source;
- source freeze;
- production registry;
- qualification registry;
- independent schema validator;
- exact construction contract.

Excluded from fixed inputs:

- failed final reconciliation root;
- previous failed replacement wrapper;
- report-only chat/history artifacts;
- absent or nonqualifying historical capsules.

B. PER-ROLE EQUALITY

Every opened fixed input receives one row containing:

- role;
- path;
- object type;
- opening identity;
- closing identity;
- comparison fields;
- pass;
- exact mismatch reason or null.

For files compare governed:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

For roots compare:

- root identity;
- complete stable no-follow inventory;
- path set;
- bytes;
- governed metadata.

C. AGGREGATION

Aggregate equality pass is:

- exact fixed-role set closed;
- every row present once;
- every row pass true;
- no missing role;
- no extra role.

Do not aggregate:

- not-reached construction confirmations;
- downstream semantic qualification;
- absence of replacement output;
- excluded historical inputs;
- empty cleanup-set counts as false.

Equal empty cleanup sets pass.

No Boolean/integer conflation.

D. FAILURE CLOSEOUT

On a prelaunch failure:

1. compute all opened-input closing rows before terminal output;
2. retain the exact failed gate;
3. retain authorization-consumption false;
4. retain no construction launched;
5. prepare the terminal frame fully;
6. emit it;
7. perform no later inspection or write.

──────────────────────────────────────────────────────────────────────────────
10. WRAPPER SELF-QUALIFICATION
────────────────────────────────────────────────

Create a finite source-external wrapper.

It must import no implementation production or qualification module.

It may launch the production parent only after self-qualification and fixed-input
authentication pass.

Compile under pinned Python with `-I -S -B`.

Run static:

- AST;
- call graph;
- dataflow;
- process-effect analysis;
- filesystem-effect analysis;
- excluded-input access analysis;
- equality-row ownership analysis;
- terminal-operation analysis.

Require:

- failed reconciliation path never opened;
- previous failed wrapper not acceptance-bearing;
- exact fixed-role registry;
- one equality row per opened role;
- no equality aggregation from unrelated confirmations;
- empty cleanup sets valid;
- authorization consumed only on process creation;
- success/failure closeout reachable;
- no network;
- no Git;
- no shell;
- no broad scan;
- no post-terminal operation.

Retain:

validation/wrapper-static-qualification-v1.json

──────────────────────────────────────────────────────────────────────────────
11. WRAPPER GATE/EQUALITY MATRIX
────────────────────────────────────────────────

Run at least 35 uniquely named cases.

Include:

- exact baseline;
- failed reconciliation physically present but excluded;
- failed reconciliation absent and excluded;
- excluded root accidentally opened;
- previous wrapper accidentally made fixed;
- one actual file SHA mismatch;
- one root inventory mismatch;
- missing fixed-role row;
- duplicate fixed-role row;
- extra role;
- not-reached confirmation false;
- no replacement root;
- zero cleanup roots;
- integer zero cleanup count;
- empty equality set where roles are required;
- equal empty cleanup sets;
- downstream semantic false;
- prelaunch failure with all fixed inputs equal;
- authorization unconsumed before process creation;
- authorization consumed after process creation;
- terminal frame before equality;
- inspection after terminal frame.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/wrapper-gate-and-equality-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT WRAPPER VALIDATOR
────────────────────────────────────────────────

Create a standard-library-only independent validator that imports neither:

- wrapper source;
- matrix generator;
- expected-result map;
- equality producer;
- fixed-role producer.

It must independently:

1. validate forward-treatment authority;
2. validate excluded-input policy;
3. inspect wrapper source for forbidden failed-reconciliation access;
4. reconstruct the fixed-role set;
5. reconstruct equality rows;
6. validate empty-set semantics;
7. validate authorization consumption;
8. validate terminal ordering;
9. run independent negative cases;
10. require zero errors.

Retain:

validation/independent-replacement-wrapper-validator-v1.json

Freeze wrapper source after:

- compilation;
- static qualification;
- gate/equality matrix;
- independent wrapper validation.

Do not modify it afterward.

──────────────────────────────────────────────────────────────────────────────
13. REPLACEMENT ONE-SHOT CONSTRUCTION AUTHORIZATION
────────────────────────────────────────────────

Retain:

opening/replacement-subject-construction-authorization-v2.json

Derive from:

- forward-treatment directive;
- historical blocked subject;
- historical sealed audit;
- accepted implementation audit;
- accepted production source and freeze;
- prior construction authorization consumed;
- previous replacement wrapper launched no production process;
- no replacement subject exists.

Required fields:

- schema;
- purpose:
  terminal-stop-and-reconstruct;
- historical subject identity;
- historical BLOCK identity;
- accepted implementation identity;
- production-source identity;
- source-freeze identity;
- construction-contract identity;
- prior original-construction authorization consumed:
  true;
- previous replacement authorization consumed:
  false;
- replacement subject exists:
  false;
- replacement authorization:
  true;
- authorization count:
  1;
- consumed:
  false before process creation;
- fresh root required:
  true;
- historical-root adoption:
  forbidden;
- same-root retry:
  forbidden;
- replacement parent:
  forbidden;
- continuation:
  forbidden;
- independent subject audit:
  not included;
- authority promotion:
  false;
- product/runtime/target/A6 authority:
  false.

Authorization is consumed only on successful production-parent process creation.

──────────────────────────────────────────────── LIMITED TO CURRENT ACCEPTED PARENT
────────────────────────────────────────────────

14. ACCEPTED PRODUCTION-PARENT RESOLUTION

Resolve and authenticate:

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

CONTRACT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

SCHEMA_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

VALIDATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

PRODUCTION_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/production/reconstruct_parent.py

Expected production-source identity:

- device:
  16777234
- inode:
  180888833
- mode:
  0600
- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

SOURCE_FREEZE:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/opening/gen2-source-freeze-v1.json

Expected source-freeze identity:

- device:
  16777234
- inode:
  180896001
- mode:
  0600
- size:
  4057
- SHA-256:
  678f4fb76c4bab0d686e106911e28eb34328e0abdc280cee38cca6a8265e135b

CONSTRUCTION_CONTRACT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n/contract/package-construction-parent-v1.json

Expected construction-contract identity:

- device:
  16777234
- inode:
  180472112
- mode:
  0600
- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

PRODUCTION_REGISTRY:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-production-source-registry-final-v1.json

QUALIFICATION_REGISTRY:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-qualification-source-registry-final-v1.json

INDEPENDENT_SCHEMA_VALIDATOR:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/qualification/validate_schema_family.py

Authenticate all exact identities through the accepted audit and source
registries.

Do not substitute another root or file.

──────────────────────────────────────────────── LIMITED TO EXACT ACCEPTED INVOCATION
────────────────────────────────────────────────

15. EXACT PRODUCTION-PARENT ARGV

After all prelaunch gates pass, require exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/production/reconstruct_parent.py
--mode
reconstruct-subject
--implementation-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634
--successor-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve
--contract-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n
--schema-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf
--reconciliation-root
/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t
--validation-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs
--production-registry
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-production-source-registry-final-v1.json
--qualification-registry
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-qualification-source-registry-final-v1.json
--independent-schema-validator
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/qualification/validate_schema_family.py
--cwd
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Submitted cwd:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Submitted environment exactly:

PYTHONDONTWRITEBYTECODE=1

Do not inherit another environment variable.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Root allocation is parent-owned.

Do not preallocate a subject root.

Governed locator grammar:

SUBJECT_ROOT=<absolute-path>\n

Do not scan for a root.

──────────────────────────────────────────────── LIMITED TO CUSTODY
────────────────────────────────────────────────

16. PLATFORM-CAPTURE PREFLIGHT

Run one harmless synchronous capture preflight using:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

Submitted cwd:

the implementation root.

Submitted environment:

PYTHONDONTWRITEBYTECODE=1

stdin:
DEVNULL

shell/TTY/detachment:
false.

The program:

- emits exact stdout and stderr markers;
- exits with one fixed nonzero test code;
- reads no stdin;
- creates no file or child.

Retain complete custody.

If preflight fails:

- do not launch construction;
- authorization remains unconsumed;
- compute wrapper closing equality;
- return provenance mismatch;
- do not retry.

──────────────────────────────────────────────── LIMITED TO ONE EXECUTION
────────────────────────────────────────────────

17. PRODUCTION-PARENT EXECUTION

Immediately before process creation:

- reauthenticate every fixed input;
- reauthenticate production source;
- reauthenticate source freeze;
- require no cache or bytecode effect.

Launch the exact argv from Section 15 exactly once.

Run synchronously and in the foreground.

Authorization is consumed only when process creation succeeds.

Do not launch:

- qualification mode;
- self-test mode;
- replacement parent;
- recovery parent;
- continuation;
- helper outside the governed parent;
- second construction.

──────────────────────────────────────────────── LIMITED TO PLATFORM
────────────────────────────────────────────────

18. TOP-LEVEL PROCESS CUSTODY

Retain before parsing:

- custody ID;
- creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- exact cwd;
- explicit environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and hashes;
- exit code;
- signal;
- process error;
- reaping;
- descriptor closure;
- fixed-input identities at launch.

If completion custody is lost after process creation:

- authorization remains consumed;
- do not scan;
- do not retry;
- return provenance mismatch.

──────────────────────────────────────────────── LIMITED TO GOVERNED LOCATOR
────────────────────────────────────────────────

19. LOCATOR AND SUBJECT-ROOT AUTHENTICATION

Retain raw streams before parsing.

Require exact stdout grammar:

SUBJECT_ROOT=<absolute-path>\n

Require:

- exactly one line;
- exact prefix;
- absolute path;
- no chatter;
- no duplicate;
- no trailing bytes.

Require stderr posture and exit code according to the accepted production
contract.

Use only the parsed path.

Do not scan.

Authenticate:

- fresh allocation;
- path unequal to historical subject;
- device/inode unequal to historical subject;
- directory;
- no symlink;
- mode 0700;
- governed parent directory and prefix;
- allocation evidence;
- no preexisting-root adoption;
- no historical-root mutation.

If authentication fails:

- inspect no alternative;
- preserve emitted value as report-only evidence;
- return provenance mismatch.

After process creation, never remove or clean the subject root in this task.

──────────────────────────────────────────────── LIMITED TO PRODUCER RESULT
────────────────────────────────────────────────

20. READ-ONLY REPLACEMENT-SUBJECT VALIDATION

Inspect only the authenticated fresh subject root.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute subject source;
- run an independent subject audit;
- regenerate evidence;
- add or replace a record or manifest.

Resolve authoritative records through:

- package status;
- role registry;
- artifact plan;
- temporal inventory;
- manifests;
- terminal result.

Authenticate:

- normative contract preservation;
- 15 current schema roles;
- 14 generated families;
- intentional normative-parent nonmapping;
- exact role/family mapping;
- 15/15 Draft 2020-12 result;
- 14 contract witnesses;
- 14 schema witnesses;
- zero joint unsatisfiability;
- zero under-enforced baseline family;
- 946-case negative matrix;
- 137-case contradiction matrix;
- 766/333 field map;
- exact documentary-validator roles;
- all validator results;
- confirmation map and validator;
- explicit confirmations;
- role occupancy;
- package status;
- lineage and supersession;
- no historical closure output current;
- no failed artifact current;
- implementation-present false;
- implementation-authority false;
- pending-independent-audit posture.

This is producer-result validation only.

Do not retrospectively adjudicate historical A06/A07/A08/A11 findings.

──────────────────────────────────────────────── LIMITING CLOSURE
────────────────────────────────────────────────

21. INTERNAL CUSTODY, CLEANUP, EQUALITY, AND TERMINAL CLOSURE

Authenticate:

- child ledger;
- contiguous ordinals;
- prelaunch records;
- child streams and outcomes;
- reaping;
- descriptor closure;
- effect attribution;
- cleanup rows;
- cleanup-set equality;
- supplied-input closing equality;
- temporal inventory;
- manifest A;
- manifest B;
- A/B equality;
- independent final reprojection;
- root row once;
- topology and modes;
- one seal transition;
- terminal marker;
- no parent postseal filesystem/process/tool activity.

Require no process, descriptor, cache, or bytecode survivor.

A success disposition without terminal closure is nonauthoritative.

──────────────────────────────────────────────── LIMITED TO SEPARATION
────────────────────────────────────────────────

22. HISTORICAL/REPLACEMENT SEPARATION

Retain:

analysis/historical-and-replacement-subject-separation-v1.json

Require:

- historical subject unchanged;
- historical subject audit unchanged;
- accepted implementation roots unchanged;
- new path distinct;
- new identity distinct;
- no historical subject root reused;
- no historical closure output current;
- no failed audit result promoted;
- new subject remains pending independent audit.

────────────────────────────────────────────────

23. WRAPPER CLOSING EQUALITY

Before final wrapper output, create explicit opening/closing rows for every
fixed input opened by this wrapper.

Do not include:

- failed final reconciliation root;
- previous failed replacement wrapper;
- downstream not-reached confirmations;
- absent replacement output;
- cleanup counts.

Require:

- exact role-set closure;
- every row present once;
- every row pass true;
- no extra row;
- no missing row.

Retain:

closing/wrapper-supplied-input-closing-equality-v1.json

On any wrapper failure, compute this record before emitting the terminal frame.

No post-frame inspection or write is permitted.

────────────────────────────────────────────────

24. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTED_AND_TERMINALLY_CLOSED_PENDING_FRESH_INDEPENDENT_AUDIT

only when:

- forward-treatment directive closes;
- historical subject/audit authenticate;
- accepted implementation authority closes;
- wrapper self-qualification passes;
- replacement authorization closes;
- all fixed inputs authenticate;
- platform preflight passes;
- parent launches once;
- custody completes;
- locator/root authentication passes;
- producer semantic qualification passes;
- internal custody and cleanup pass;
- parent supplied-input equality passes;
- temporal/manifests/reprojection pass;
- terminal topology/modes pass;
- one seal/no-postseal rule passes;
- wrapper closing equality passes.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_BLOCKED

when:

- the accepted production parent reports a substantive construction blocker;
- provenance remains valid;
- complete failure evidence exists;
- no false success closure is claimed.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_PROVENANCE_MISMATCH

for:

- historical-input mismatch;
- accepted-authority mismatch;
- wrapper self-qualification failure;
- source/freeze mismatch;
- custody loss;
- malformed locator;
- historical-root reuse;
- supplied-input mutation;
- evidence loss;
- cleanup inequality;
- terminal-closure failure;
- postseal parent activity;
- wrapper equality failure.

Do not retry in this task.

────────────────────────────────────────────────

25. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all historical roots;
- preserve accepted implementation roots;
- preserve the new constructed or failed subject root;
- preserve the wrapper root;
- do not independently audit the new subject;
- do not construct another subject;
- do not promote/rebind current authority;
- do not execute product modes;
- do not run target audit or runtime validation;
- do not modify a repository;
- do not commit or push;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

26. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh wrapper-root identity
3. Forward-treatment directive
4. Historical subject authentication
5. Historical subject-audit authentication
6. Failed-reconciliation exclusion
7. Previous failed-wrapper disposition
8. Accepted implementation authority
9. Current content identities
10. Wrapper fixed-role registry
11. Wrapper equality contract
12. Wrapper static qualification
13. Wrapper gate/equality matrix
14. Independent wrapper validation
15. Replacement construction authorization
16. Authorization consumption state
17. Production-source identity
18. Source-freeze identity
19. Construction-contract identity
20. Exact fixed construction inputs
21. Platform preflight
22. Exact production-parent argv
23. Exact cwd/environment
24. Top-level custody
25. Raw stdout/stderr
26. Exit/signal
27. Locator parsing
28. Replacement subject-root identity
29. Fresh allocation/nonadoption proof
30. Historical/replacement separation
31. Normative-contract preservation
32. Fifteen schema roles
33. Fourteen generated families
34. Role/family mapping
35. Draft 2020-12 result
36. Witness results
37. 946-case result
38. 137-case result
39. 766/333 field map
40. Documentary-validator registry/results
41. Confirmation-evidence result
42. Explicit confirmations
43. Role occupancy
44. Package status
45. Lineage/supersession
46. Child custody
47. Effect attribution
48. Cleanup
49. Parent input equality
50. Wrapper input equality
51. Temporal identity
52. Manifest identities
53. A/B equality
54. Final reprojection
55. Terminal topology/modes
56. Seal/marker
57. No-postseal result
58. Confirmation no retry/replacement/continuation
59. Confirmation fresh independent audit not executed
60. Confirmation no product/runtime/target/A6 activity
61. Remaining uncertainty/nonclaims
62. Explicit wrapper confirmations

Required confirmations:

FORWARD_TREATMENT_DIRECTIVE_RETAINED
HISTORICAL_SUBJECT_ROOT_AUTHENTICATED
HISTORICAL_SUBJECT_MUTATION_NOT_PERFORMED
HISTORICAL_SUBJECT_AUDIT_AUTHENTICATED
HISTORICAL_BLOCK_PRESERVED
FAILED_FINAL_RECONCILIATION_EXCLUDED_FROM_FIXED_INPUTS
FAILED_FINAL_RECONCILIATION_NOT_OPENED
FURTHER_FINDINGS_RECONCILIATION_NOT_USED
PREVIOUS_FAILED_REPLACEMENT_WRAPPER_NONCURRENT
PREVIOUS_REPLACEMENT_AUTHORIZATION_UNCONSUMED
PRIOR_ORIGINAL_CONSTRUCTION_AUTHORIZATION_CONSUMED
PRIOR_SUBJECT_NOT_REUSED_AS_CURRENT
ACCEPTED_IMPLEMENTATION_AUDIT_AUTHENTICATED
GEN2_IMPLEMENTATION_PACKAGE_ACCEPT_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
WRAPPER_FIXED_ROLE_REGISTRY_COMPLETE
WRAPPER_CLOSING_EQUALITY_CONTRACT_COMPLETE
WRAPPER_STATIC_QUALIFICATION_PASSED
WRAPPER_GATE_EQUALITY_MATRIX_PASSED
INDEPENDENT_WRAPPER_VALIDATOR_PASSED
REPLACEMENT_ONE_SHOT_AUTHORIZATION_ESTABLISHED
ACCEPTED_PRODUCTION_SOURCE_IDENTITY_MATCHED
ACCEPTED_SOURCE_FREEZE_IDENTITY_MATCHED
ACCEPTED_CONSTRUCTION_CONTRACT_AUTHENTICATED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PRODUCTION_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_CONSTRUCTION_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_HELPER_EXECUTED_OUTSIDE_PARENT
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
REPLACEMENT_SUBJECT_ROOT_FROM_EXACT_GOVERNED_LOCATOR
SUBJECT_ROOT_SCAN_NOT_PERFORMED
REPLACEMENT_SUBJECT_ROOT_FRESHLY_ALLOCATED
REPLACEMENT_SUBJECT_ROOT_DISTINCT_FROM_HISTORICAL
PREEXISTING_SUBJECT_ROOT_NOT_ADOPTED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_PASSED
CONTRADICTION_REGRESSION_137_PASSED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_PASSED
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_SET_EQUALITY_PASSED
PARENT_SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
WRAPPER_SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
REPLACEMENT_SUBJECT_TEMPORAL_INVENTORY_CREATED
REPLACEMENT_SUBJECT_TEMPORAL_INVENTORY_VERIFIED
REPLACEMENT_SUBJECT_MANIFEST_A_CREATED
REPLACEMENT_SUBJECT_MANIFEST_B_CREATED
REPLACEMENT_SUBJECT_MANIFESTS_BYTE_IDENTICAL
REPLACEMENT_SUBJECT_TERMINAL_REPROJECTION_PASSED
REPLACEMENT_SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_CLOSURE_BY_PARENT
SECOND_REPLACEMENT_CONSTRUCTION_NOT_ATTEMPTED
REPLACEMENT_SUBJECT_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Source and confidence

This assessment is grounded solely in the Codex operative report in your message.

**Confidence:** 0.999 that replacement authorization remains unconsumed; 0.999 that no replacement subject exists; 0.995 that the failed-reconciliation completeness gate was an external wrapper overconstraint; 0.96 that a freshly qualified wrapper with the failed reconciliation excluded from fixed inputs is the correct immediate path.
