## Engineering assessment

The split-root launch authority is now complete and qualified. The frozen runtime was shown to support an existing workspace as `cwd` and a distinct, absent child as `--output-root`:

```text
workspace:
  /private/tmp/ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-...

cwd:
  <workspace>

output root:
  <workspace>/audit-capsule
```

The runtime forwards the explicit output path unchanged, creates it exactly once with `exist_ok=False`, and reports that child—not the workspace—as `capsule_root`. No frozen source or runtime-authority rule requires `cwd == output_root`. :chatgpt-content-reference{index="0"}

The correction was qualified dynamically as well as statically:

- 81 root-lifecycle authority cases passed;
- an independently authored validator passed;
- the platform preflight left the workspace empty and capsule child absent;
- the filesystem lifecycle probe created the child once and rejected a second creation;
- a packaged synthetic execution created the child through the actual frozen harness and returned a terminal frame binding it. :chatgpt-content-reference{index="1"}

The successor launch artifacts are deterministic, sealed, and current:

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json
```

- inode: `182745731`
- mode/link count: `0400 / 1`
- size: `10,412`
- SHA-256: `2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c`

```text
/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json
```

- inode: `182745737`
- mode/link count: `0400 / 1`
- size: `19,323`
- SHA-256: `e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d` :chatgpt-content-reference{index="2"}

Profile v1, certificate v2, and certificate v1 are now historical and contribute zero active authorization. Certificate v3 holds the sole active authorization, which remains unconsumed. No real subject audit or subject verdict exists yet. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

## Progression decision

Execute exactly **one** real audit now.

No additional launch-authority, root-lifecycle, audit-source, packaging, qualification, construction, or reconciliation tranche is justified beforehand.

The wrapper must use:

- the unchanged audit PYZ;
- the unchanged runtime authority;
- launch profile v2;
- launch certificate v3;
- a newly allocated workspace as `cwd`;
- its absent `audit-capsule` child as `--output-root`.

It must not reuse profile v1 or certificates v1/v2 as current authority, and it must not pass the profile or certificate to the harness.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE REAL INDEPENDENT AUDIT OF THE UNCHANGED
REPLACEMENT GENERATION-2 SCHEMA SUBJECT

USING CURRENT LAUNCH PROFILE V2 AND LAUNCH CERTIFICATE V3
WITH THE QUALIFIED SPLIT-ROOT LIFECYCLE

Objective

Execute exactly one real independent audit of:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Use these exact current artifacts:

1. unchanged final independent-audit PYZ;
2. unchanged runtime authority;
3. current external launch profile v2;
4. current external launch certificate v3;
5. unchanged replacement subject;
6. replacement construction wrapper;
7. current content bundle;
8. current content authority;
9. accepted implementation authority chain.

Use the qualified split-root lifecycle:

- allocate one existing wrapper-owned workspace;
- submit that workspace as cwd;
- derive the exact absent child:
  <workspace>/audit-capsule;
- pass that absent child through `--output-root`;
- do not create the child in the wrapper;
- require the frozen audit runtime to create it;
- require the terminal frame to bind that child as `capsule_root`.

The one active real-audit authorization remains unconsumed.

Consume it only if the real audit-parent process is successfully created.

Capture top-level process creation and completion exactly.

After completion:

- retain raw streams before parsing;
- parse only under the current frozen framing contract;
- authenticate the exact capsule child;
- inspect the capsule read-only;
- independently verify its substantive result and terminal closure;
- preserve the exact harness disposition;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute qualification or synthetic mode.

Do not launch a replacement, recovery, continuation, or second audit parent.

Do not run another direct subject auditor outside the frozen harness.

Do not execute subject source.

Do not rerun subject construction.

Do not promote or rebind current schema authority.

Do not combine audit and authority promotion.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

AUDIT_PROVENANCE_MISMATCH

If any prelaunch gate fails before process creation, return:

AUDIT_PROVENANCE_MISMATCH

and explicitly state:

REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. FINAL AUDIT PYZ
──────────────────────────────────────────────────────────────────────────────

FINAL_AUDIT_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz

Expected identity:

- device:
  16777234
- inode:
  182699827
- mode:
  0400
- link count:
  1
- size:
  4589679
- SHA-256:
  00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0

──────────────────────────────────────────────────────────────────────────────
2. RUNTIME AUTHORITY
──────────────────────────────────────────────────────────────────────────────

FINAL_RUNTIME_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json

Expected identity:

- device:
  16777234
- inode:
  182699838
- mode:
  0400
- link count:
  1
- size:
  56463
- SHA-256:
  9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0

──────────────────────────────────────────────────────────────────────────────
3. CURRENT LAUNCH PROFILE V2
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_PROFILE_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json

Expected identity:

- device:
  16777234
- inode:
  182745731
- mode:
  0400
- link count:
  1
- size:
  10412
- SHA-256:
  2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c

──────────────────────────────────────────────────────────────────────────────
4. CURRENT LAUNCH CERTIFICATE V3
──────────────────────────────────────────────────────────────────────────────

CURRENT_LAUNCH_CERTIFICATE_V3:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json

Expected identity:

- device:
  16777234
- inode:
  182745737
- mode:
  0400
- link count:
  1
- size:
  19323
- SHA-256:
  e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d

──────────────────────────────────────────────── LIMITED TO LINEAGE
────────────────────────────────────────────────

5. HISTORICAL LAUNCH ARTIFACTS

Historical profile v1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json

Expected:

- inode:
  182723650
- mode:
  0400
- size:
  9131
- SHA-256:
  14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568

Historical certificate v2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json

Expected:

- inode:
  182723661
- mode:
  0400
- size:
  12987
- SHA-256:
  f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f

Historical certificate v1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

Expected:

- inode:
  182699841
- mode:
  0400
- size:
  3572
- SHA-256:
  525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c

Use them only when required to authenticate current certificate-v3 lineage.

Require:

- profile v1 current:
  false;
- certificate v2 current:
  false;
- certificate v1 current:
  false;
- their active authorization counts:
  zero;
- their mutation:
  forbidden.

Do not use their launch controls.

If certificate v3 already closes lineage without external opening, do not add
the historical files as unnecessary launch fixed inputs.

──────────────────────────────────────────────────────────────────────────────
6. REPLACEMENT SUBJECT
──────────────────────────────────────────────── LIMITED TO AUDIT TARGET
────────────────────────────────────────────────

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234
- inode:
  182649818
- mode:
  0700
- UID/GID:
  501/20

Expected physical closure:

- 73 entries including root;
- 12 directories;
- 61 regular files;
- root row exactly once;
- no empty descendant;
- no symlink;
- no special object;
- no multiply linked regular file;
- directory/file modes:
  0700/0600;
- no cache or bytecode.

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  905a21d0ec24be5caf8b29ac0e29419833dc19b7b309f60afdb2ad215a1866b4

Expected manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16620 each
- SHA-256:
  5f22e7e1405afd0378ff2e054f7b436d4b00172a300a97a5676880a9d7196758

Open only this exact root.

Do not scan for another subject.

──────────────────────────────────────────────── LIMITING CONSTRUCTION PROVENANCE
────────────────────────────────────────────────

7. REPLACEMENT CONSTRUCTION WRAPPER

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234
- inode:
  182648782
- mode:
  0700
- UID/GID:
  501/0

Authenticate only the current chain needed to establish:

- accepted source-freeze resolution;
- accepted implementation authority;
- one-shot construction authorization and consumption;
- exact production-parent custody;
- exact subject locator;
- fresh allocation and nonadoption;
- terminal subject closure;
- pending-independent-audit posture;
- no second construction.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO ACCEPTED IMPLEMENTATION
────────────────────────────────────────────────

8. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only:

- accepted reconstruction-parent implementation;
- accepted production source;
- accepted source freeze;
- construction contract;
- unsuperseded implementation package;
- replacement construction used the accepted parent.

Do not re-audit the implementation package.

Require opening/closing equality.

────────────────────────────────────────────────

9. CURRENT CONTENT INPUTS

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate the content authority before interpreting the ZIP.

Require:

- 479 members;
- eight roles;
- seven content roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive-validation evidence;
- no `.DS_Store`.

──────────────────────────────────────────────── LIMITING CURRENT AUTHORITY
────────────────────────────────────────────────

10. STABLE PRELAUNCH AUTHENTICATION

Before allocating any fresh root, authenticate:

- final audit PYZ;
- runtime authority;
- current profile v2;
- current certificate v3;
- replacement subject;
- construction wrapper;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority.

Open historical profile/certificates only if required by the current
certificate’s external lineage-validation contract.

For every file:

- open no-follow;
- require regular file;
- require governed mode/link count;
- retain device/inode/size/SHA-256;
- perform two stable byte and metadata reads.

For every root:

- require exact identity;
- retain a stable opening inventory when required by the current launch
  authority.

Strict-parse:

- runtime authority;
- profile v2;
- certificate v3;
- content authority;

using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any predicate fails:

- do not allocate wrapper or workspace roots;
- do not execute platform preflight;
- do not create the audit parent;
- return:
  AUDIT_PROVENANCE_MISMATCH;
- state:
  REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED;
- state:
  FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED.

────────────────────────────────────────────────

11. CURRENT LAUNCH-AUTHORITY CLOSURE

Validate profile v2 and certificate v3 under their exact schemas.

Require exact correspondence among:

- profile v2;
- certificate v3;
- PYZ;
- runtime authority;
- replacement subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- source freeze;
- 89-member registry;
- qualification evidence;
- split-root policy;
- framing contract.

Require:

- profile v2 current:
  true;
- certificate v3 current:
  true;
- every predecessor profile/certificate current:
  false;
- all predecessor active authorization counts:
  zero;
- certificate-v3 authorization count:
  one;
- total active current authorization count:
  one;
- real audit already executed:
  false;
- subject verdict:
  not issued;
- authority promotion:
  false.

Any discrepancy:

- do not launch;
- return provenance mismatch;
- authorization remains unconsumed.

────────────────────────────────────────────────

12. PYZ MEMBER AND GOVERNANCE CLOSURE

Parse the PYZ directly.

Require exact correspondence with:

- runtime authority;
- profile v2;
- certificate v3;
- embedded member registry.

Require:

- exactly 89 members;
- 88 non-self member rows;
- raw UTF-8 sorted names;
- ZIP_STORED;
- frozen timestamp;
- `create_system=3`;
- member mode 0600;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink/special member;
- no comments or uncontrolled extras;
- no cache or bytecode;
- no historical audit source.

Authenticate embedded current roles for:

- executable entrypoint;
- source freeze;
- source registries;
- 15/14 model;
- complete 946 vocabulary;
- complete 137 vocabulary;
- total-checking contract;
- dual-oracle contract;
- occupancy vocabulary;
- confirmation contract;
- physical-closure/A15 contract;
- no-VCS contract;
- qualification matrices;
- synthetic rehearsal results;
- independent qualification;
- post-package qualification;
- frozen-package requalification;
- future invocation contract.

Any discrepancy:

- do not launch;
- return provenance mismatch.

────────────────────────────────────────────────

13. WRAPPER EVIDENCE ROOT AND WORKSPACE

After Sections 10–12 pass, allocate:

A. WRAPPER_EVIDENCE_ROOT

Using:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-schema-subject-real-audit-wrapper-v2-`;
- umask:
  `077`.

Use it only for:

- prelaunch authentication;
- profile/certificate validation;
- preflight custody;
- audit-parent custody;
- raw streams;
- read-only capsule adjudication;
- fixed-input closing equality;
- final wrapper report.

B. FRESH_PRIVATE_AUDIT_WORKSPACE

Using the exact profile-v2 policy:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-`;
- umask:
  `077`.

Immediately retain:

- absolute path;
- device;
- inode;
- mode;
- UID/GID;
- empty opening inventory.

Require:

- absolute path;
- directory;
- no symlink;
- mode 0700;
- empty at allocation.

Derive:

ABSENT_AUDIT_CAPSULE_ROOT =
<FRESH_PRIVATE_AUDIT_WORKSPACE>/audit-capsule

Require before preflight and launch:

- absolute child path;
- direct child of workspace;
- basename exactly `audit-capsule`;
- does not exist;
- wrapper has not created it;
- no sibling or fallback candidate;
- no scan.

Use:

- workspace as submitted cwd;
- absent child as `--output-root`.

On prelaunch failure:

- retain evidence;
- remove only wrapper-owned empty workspace after identity revalidation;
- observe ENOENT twice;
- authorization remains unconsumed.

After process creation:

- authorization is consumed;
- preserve workspace and capsule child regardless of disposition.

────────────────────────────────────────────────

14. PLATFORM-CAPTURE PREFLIGHT

Run exactly once using profile v2:

```text
/usr/local/bin/python3.13
-I
-S
-B
-c
import os;os.write(1,b"PLATFORM_CAPTURE_STDOUT_V1\n");os.write(2,b"PLATFORM_CAPTURE_STDERR_V1\n");os._exit(23)
```

Submitted cwd:

FRESH_PRIVATE_AUDIT_WORKSPACE

Submitted environment exactly, with no inheritance:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

Process posture:

- stdin:
  DEVNULL;
- shell:
  false;
- TTY:
  false;
- detachment:
  false;
- foreground:
  true;
- synchronous:
  true.

Retain complete external custody.

Require:

- stdout exact:
  `PLATFORM_CAPTURE_STDOUT_V1\n`;
- stdout size:
  27;
- stdout SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2;
- stderr exact:
  `PLATFORM_CAPTURE_STDERR_V1\n`;
- stderr size:
  27;
- stderr SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5;
- exit:
  23;
- signal:
  null;
- workspace still empty;
- capsule child still absent;
- no file or child effect.

If preflight fails:

- do not create the audit parent;
- authorization remains unconsumed;
- clean only wrapper-owned empty workspace after evidence retention;
- return provenance mismatch;
- do not retry.

────────────────────────────────────────────────

15. EXACT REAL-AUDIT INVOCATION

After preflight passes, require exactly:

```text
/usr/local/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz
--mode
audit
--runtime-authority
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json
--subject-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
--construction-wrapper
/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a
--content-bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--accepted-implementation-audit
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04
--accepted-implementation-wrapper
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg
--output-root
<ABSENT_AUDIT_CAPSULE_ROOT>
```

Do not pass profile v2 or certificate v3 to the harness.

Do not add or omit any operand.

Submitted cwd:

FRESH_PRIVATE_AUDIT_WORKSPACE

Submitted environment exactly:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

No inherited environment.

Process posture:

- stdin:
  DEVNULL;
- shell:
  false;
- TTY:
  false;
- detachment:
  false;
- foreground:
  true;
- synchronous:
  true.

Immediately before process creation:

- reauthenticate all fixed inputs;
- reauthenticate workspace identity;
- require workspace empty;
- require capsule child absent.

Launch exactly once.

The authorization is consumed only when process creation succeeds.

After successful creation, consumption is final regardless of outcome.

Do not launch:

- qualification mode;
- synthetic mode;
- replacement parent;
- recovery parent;
- continuation;
- direct auditor;
- post-failure validator;
- second audit.

────────────────────────────────────────────────

16. TOP-LEVEL PROCESS CUSTODY

Retain before parsing:

- custody ID;
- creation result;
- PID;
- start/completion;
- duration;
- exact argv;
- cwd;
- environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and hashes;
- exit;
- signal;
- process error;
- reaping;
- descriptor closure;
- fixed-input identities at launch;
- workspace identity at launch;
- capsule-child absence at launch.

The wrapper is authoritative for process creation and completion.

If completion custody is lost after process creation:

- authorization remains consumed;
- do not scan for another capsule;
- do not retry;
- preserve the workspace and any created child;
- return provenance mismatch.

────────────────────────────────────────────────

17. STREAM AND TERMINAL-FRAME PARSING

Retain raw streams before parsing.

Parse only under the exact profile-v2/certificate-v3/runtime-authority framing
contract.

Do not assume a frame schema or field omitted from current authority.

Require all current handled-terminal predicates, including:

- exact stdout posture;
- exact stderr posture;
- one frame;
- no trailing bytes;
- strict UTF-8 JSON;
- duplicate-key rejection;
- nonfinite-number rejection;
- exact current frame schema;
- governed disposition;
- governed scenario;
- closure result;
- capsule-root binding.

Require:

terminal-frame capsule root
=
ABSENT_AUDIT_CAPSULE_ROOT

and not the workspace.

If the process exits under an unhandled-failure posture:

- return provenance mismatch;
- do not scan for another capsule;
- preserve workspace and capsule child;
- do not retry.

────────────────────────────────────────────────

18. CAPSULE-ROOT AUTHENTICATION

Authenticate only:

ABSENT_AUDIT_CAPSULE_ROOT

Require:

- it was absent before process creation;
- it now exists only if created by the audit process;
- absolute path;
- direct child of the workspace;
- basename `audit-capsule`;
- directory;
- no symlink;
- mode 0700;
- terminal-frame equality;
- capsule records bind the same root;
- workspace is not treated as the capsule root.

Do not scan `/private/tmp`.

Do not select an alternative path.

Failure forces provenance mismatch.

────────────────────────────────────────────────

19. READ-ONLY CAPSULE INSPECTION

Inspect only the authenticated capsule child.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute subject source;
- launch another validator;
- regenerate evidence;
- add or replace records.

Resolve authoritative records only through:

- terminal frame;
- capsule path/role registry;
- capsule indexes;
- manifests;
- exact evidence pointers.

Authenticate:

- source identities and freeze;
- no-Git/VCS posture;
- exact 15/14 model;
- complete 946 and 137 outcome vocabularies;
- total documentary checking;
- dual-oracle results;
- subject terminal closure;
- normative contract;
- schema roles and families;
- Draft 2020-12 results;
- witness rows;
- complete 946 rows;
- complete 137 rows;
- dual-oracle crosswalk;
- 766/333 field map;
- documentary validators;
- confirmation derivation;
- occupancy, lineage, and producer status;
- findings and repair owners;
- A00–A15;
- child custody;
- cleanup;
- supplied-root equality;
- temporal inventory;
- manifests;
- final reprojection;
- physical topology;
- A15/closure agreement;
- one seal transition;
- no postseal operation.

────────────────────────────────────────────────

20. DIRECT SUBJECT-BLOCKER EVIDENCE STANDARD

A terminal:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

is authoritative only when every direct blocker contains:

- exact failed witness or case row;
- non-null direct evidence;
- governing contract/schema/specification pointer;
- primary repair owner;
- exact repair surface;
- whether subject bytes must change;
- whether reconstruction is required;
- whether unchanged-subject re-audit is allowed.

For a 946- or 137-suite blocker, require exact failed per-case rows.

An aggregate count without those rows is invalid.

Derivative confirmations are not independent blockers.

Any:

- evaluator exception;
- dual-oracle disagreement;
- invalid outcome projection;
- incomplete direct evidence;
- hard-coded confirmation;
- occupancy-role defect;
- audit cleanup failure;
- capsule closure failure;

forces:

AUDIT_PROVENANCE_MISMATCH

rather than subject BLOCK.

────────────────────────────────────────────────

21. CAPSULE TERMINAL CLOSURE

Authenticate:

- temporal inventory;
- manifest A;
- manifest B;
- A/B byte equality;
- independent final reprojection;
- root row exactly once;
- no physical empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- directory/file modes 0700/0600;
- no cache or bytecode;
- A15 status equals final closure pass;
- one seal transition;
- no filesystem/process/validation operation after seal.

The physical namespace includes all reserved terminal files.

A terminal frame does not substitute for capsule closure.

Failure forces provenance mismatch and prevents promotion of an embedded ACCEPT
or BLOCK.

────────────────────────────────────────────────

22. WRAPPER FIXED-INPUT CLOSING EQUALITY

After process completion, repeat opening/closing authentication for every fixed
input actually opened by the wrapper:

- final audit PYZ;
- runtime authority;
- profile v2;
- certificate v3;
- any historical profile/certificate opened for lineage;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Require:

- exact role set;
- one row per role;
- no missing or extra row;
- every row passes.

Do not mutate any fixed input.

Failure forces provenance mismatch.

────────────────────────────────────────────────

23. FINAL VERDICT RULES

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_ACCEPT

only when:

- all fixed inputs authenticate;
- current launch authority closes;
- platform preflight passes;
- audit process custody completes;
- terminal framing passes;
- capsule-root authentication passes;
- capsule provenance passes;
- subject terminal closure passes;
- exact 15/14 model passes;
- all schemas pass Draft 2020-12;
- all witness rows pass;
- all 946 rows pass;
- all 137 rows pass;
- dual oracles agree;
- 766/333 closes;
- documentary-validator authority closes;
- confirmation evidence closes;
- occupancy/lineage/status close;
- no direct subject blocker remains;
- cleanup and supplied-root equality pass;
- capsule terminal closure passes;
- wrapper closing equality passes.

Scope:

- accepts this exact replacement subject;
- does not promote or rebind current authority;
- does not establish product/runtime readiness;
- does not authorize target audit, publication, deployment, or A6.

Report:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_BLOCK

only when:

- audit provenance passes;
- at least one direct subject blocker exists;
- every blocker satisfies Section 20;
- findings and dependencies are complete;
- cleanup, equality, and terminal closure pass.

Report:

AUDIT_PROVENANCE_MISMATCH

for:

- fixed-input or launch-authority mismatch;
- preflight failure;
- process-custody loss;
- framing or root failure;
- subject drift;
- source/toolchain/freeze failure;
- oracle exception or disagreement;
- invalid outcome projection;
- incomplete direct evidence;
- hard-coded confirmation;
- occupancy-role defect;
- cleanup inequality;
- supplied-root inequality;
- capsule terminal-closure failure;
- A15/closure contradiction;
- postseal activity;
- wrapper closing-equality failure.

Do not retry.

────────────────────────────────────────────────

24. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve all launch artifacts;
- preserve workspace and capsule;
- preserve replacement subject unchanged;
- preserve construction wrapper;
- preserve accepted implementation roots;
- preserve content inputs;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product or live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

25. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Final PYZ identity
3. Runtime-authority identity
4. Current profile-v2 identity
5. Current certificate-v3 identity
6. Historical profile/certificate lineage
7. Replacement-subject identity
8. Construction-wrapper authentication
9. Accepted implementation-chain authentication
10. Content identities
11. Stable prelaunch authentication
12. Current launch-authority closure
13. PYZ/member closure
14. Wrapper-evidence-root identity
15. Workspace identity
16. Absent capsule-child prelaunch proof
17. Platform preflight
18. Exact audit argv
19. Cwd/environment/process posture
20. Top-level process custody
21. Raw stdout/stderr
22. Exit/signal
23. Terminal frame
24. Capsule-root authentication
25. Source/freeze/no-Git posture
26. Subject terminal closure
27. Normative contract
28. Fifteen schema roles
29. Fourteen generated families
30. Role/family mapping
31. Draft 2020-12 result
32. Contract-witness rows
33. Schema-witness rows
34. Witness aggregate
35. Complete 946 result
36. Exact failed 946 rows if any
37. Complete 137 result
38. Exact failed 137 rows if any
39. Dual-oracle crosswalk
40. 766/333 field map
41. Documentary-validator closure
42. Confirmation derivation
43. Derivative-confirmation ledger
44. Occupancy, lineage, and producer status
45. Findings
46. Repair-owner registry
47. Dependency graph
48. A00–A15
49. Child custody
50. Audit cleanup
51. Capsule supplied-root equality
52. Wrapper fixed-input equality
53. Audit temporal identity
54. Audit manifest identities
55. A/B equality
56. Final reprojection
57. Physical topology/modes
58. A15/closure agreement
59. Seal/no-postseal result
60. Confirmation subject unchanged
61. Confirmation no authority promotion
62. Confirmation no product/runtime/target/A6 activity
63. Remaining uncertainty/nonclaims
64. Explicit wrapper confirmations

Required confirmations:

FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
CURRENT_PROFILE_V2_IDENTITY_MATCHED
CURRENT_CERTIFICATE_V3_IDENTITY_MATCHED
PROFILE_V1_NOT_CURRENT
CERTIFICATE_V2_NOT_CURRENT
CERTIFICATE_V1_NOT_CURRENT
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
CURRENT_SPLIT_ROOT_LAUNCH_AUTHORITY_COHERENT
AUDIT_PYZ_MEMBER_SET_89_CLOSED
WRAPPER_WORKSPACE_ALLOCATED
WRAPPER_WORKSPACE_EMPTY_BEFORE_LAUNCH
CAPSULE_CHILD_ABSENT_BEFORE_LAUNCH
WRAPPER_DID_NOT_PRECREATE_CAPSULE_ROOT
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PREFLIGHT_WORKSPACE_REMAINED_EMPTY
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
SYNTHETIC_MODE_NOT_EXECUTED
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_CAPSULE_CHILD
CAPSULE_ROOT_DISTINCT_FROM_WORKSPACE
CLEAN_AUDIT_SOURCE_FREEZE_AUTHENTICATED
NO_GIT_OR_VCS_INVOCATION
SUBJECT_TERMINAL_REPROJECTION_PASSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

## Source and confidence

The latest Codex report establishes exact frozen-runtime split-root compatibility, successful static and dynamic qualification, deterministic profile/certificate creation, predecessor supersession, and one active unconsumed authorization. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"}

**Provenance confidence:** 0.999  
**Split-root launch-readiness confidence:** 0.999  
**Single-authorization confidence:** 0.999  
**Replacement-subject acceptance confidence before audit:** 0.00

This pass used the latest attachment in full. Some older uploads in the project have expired; re-upload one only if a future review needs its original bytes rather than the retained reports and identities.
