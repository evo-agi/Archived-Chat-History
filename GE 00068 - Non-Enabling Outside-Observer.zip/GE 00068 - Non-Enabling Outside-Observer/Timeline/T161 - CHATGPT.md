## Assessment

This repair is ready for a fresh independent audit.

It appears to close the exact repository blocker without reopening the settled threat model:

- `evidence_verification.md` is now the sole authoritative writer for a closed, typed trusted-host contract.
- The other three governing documents contain bounded, expressly non-overriding references.
- Test 89 retains its identity but now validates the whole contract, its references, canonical encoding, exact types and values, duplicate and unknown fields, and 31 contradictory mutations.
- `verify_v1.py`, the source-external caller, `boundaries.md`, registry, layouts, and historical fixtures remained byte-identical.
- Four complete 89-test runs passed across umasks `077` and `022`.
- The new exact audit target is canonical manifest `0d7180be…85dd0` with tracked binary diff `b2487310…7aceb`.

That is the proportional closure to CT-01. The prior audit expressly found the current prose coherent and identified only the phrase-based test’s inability to reject later contradictory text. 

AP-06 must now be handled through audit orchestration, not source changes. The fresh audit needs four **distinct** auditor instances: three concurrently, followed by a fourth distinct security auditor after a slot becomes available. The earlier audit delivered four subject perspectives but used only three distinct instances.  This sequencing is consistent with the project protocol’s separate audit roles and its rule that a missing required perspective cannot be silently replaced by parent inference. 

The main audit risk is now **oracle independence**: the auditor must not merely rerun test 89’s own parser and declare the contract sound. It should build an independent parser and contradiction matrix, inspect the complete governing documents for contradictory prose outside the bounded blocks, and verify that the structured contract is genuinely the sole authority.

No further implementation or producer replay is indicated. Changed bytes require a fresh read-only audit with independently reproduced provenance. 

## Codex prompt: fresh independent audit of CT-01 repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete audit report inline in Markdown.

Do not respond with only:

- a verdict;
- a summary;
- a link to a report;
- “full report available at …”;
- or an attachment reference.

Supplemental evidence links may follow the complete inline report.

This requirement applies to every outcome:

- ACCEPT;
- BLOCK;
- REJECT;
- AUDIT_PROVENANCE_MISMATCH;
- SUBAGENT_UNAVAILABLE;
- PROCESS_BOUNDARY_BLOCK.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh, read-only Codex conversation.

Do not resume:

- the CT-01 implementation conversation;
- the prior trusted-host-boundary audit;
- any earlier evidence-verification implementation or audit conversation.

Objective

Independently audit the exact Evidence Verification v1 CT-01 repair.

Do not repair or modify the patch.

The prior independent audit found:

1. the current trusted-host contract was coherent;
2. the verifier and source-external caller had no demonstrated blocker;
3. CT-01 was the sole repository-patch blocker:
   `InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`
   used isolated phrase checks and could pass while contradictory contract text
   existed;
4. AP-06 was a separate audit-process issue because four subject perspectives
   were delivered through only three distinct subagent instances.

The repair now claims:

- one authoritative structured trusted-host contract in
  `.docs/system_overview/evidence_verification.md`;
- bounded non-overriding references in `PLANS.md`,
  `artifact_hygiene.md`, and `capability_probing.md`;
- strict full-contract validation in test 89;
- 31 mechanism-specific contradictory mutation cases;
- no verifier, caller, registry, layout, boundary, or fixture change.

Audit whether those claims are true, contradiction-resistant, non-authoritative,
and proportionate.

No repository mutation.
No formatting.
No repair.
No repository cleanup that changes bytes or metadata.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No nested subagents.

## 1. Exact audit target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Implementation evidence root:

IMPLEMENTATION_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/trusted-host-contract-test-repair-2aedcf930bfa

Expected canonical-manifest SHA-256:

0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Expected final-run manifest path convention:

EXPECTED_MANIFEST_CANDIDATE=$IMPLEMENTATION_EVIDENCE/provenance/run-1/provenance/manifest-run-1.json

Evidence inventory:

EVIDENCE_INVENTORY=$IMPLEMENTATION_EVIDENCE/closeout/evidence-inventory.json

Implementation closing gate:

IMPLEMENTATION_CLOSING=$IMPLEMENTATION_EVIDENCE/closeout/closing-gate.json

Validation summary:

VALIDATION_SUMMARY=$IMPLEMENTATION_EVIDENCE/validation/summary.json

Contradiction ledger:

CONTRADICTION_LEDGER=$IMPLEMENTATION_EVIDENCE/validation/contradiction-matrix.json

Use EVIDENCE_INVENTORY and IMPLEMENTATION_CLOSING to confirm the uniquely
indexed final run-1 manifest path.

If the indexed manifest is not uniquely identifiable, is absent, or differs
from EXPECTED_MANIFEST_CANDIDATE without an explicit machine-readable index,
return:

AUDIT_PROVENANCE_MISMATCH

Do not infer or approximately reconstruct the path.

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe:

- recipe ID:
  `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`
- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`

Expected verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

- size:
  `40121`
- SHA-256:
  `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`

Expected tests:

TESTS=$IMPL_R/tools/evidence_verify/test_verify_v1.py

- size:
  `83542`
- SHA-256:
  `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea`

Expected source-external caller, unchanged:

CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Prior blocking audit root, read-only:

PRIOR_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-2aedcf930bfa-v1

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular single-link file;
- size:
  `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Required fresh audit root, absent at opening:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-0d7180be1a6f-v1

Forbidden primary checkout for Git or repository-relative reads:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

## 2. Expected final 13-path patch

Require exactly four modified tracked paths and nine untracked paths.

Expected final identities:

`PLANS.md`
- size: `221718`
- SHA-256:
  `fb3b2590103af1db07f17eac8fbe9c9e65420fd9d2c7fc6a8ccf9e7510e72750`

`.docs/system_overview/boundaries.md`
- size: `65156`
- SHA-256:
  `643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e`

`.docs/system_overview/artifact_hygiene.md`
- size: `13721`
- SHA-256:
  `1a3e570167ab7b2238a75d43f678e7121e226950d6202b9e17259317bf5ce1c5`

`.docs/system_overview/capability_probing.md`
- size: `10039`
- SHA-256:
  `3333ea9b3c618ae95110273041396a2d7482891fac01b9d29e6b1609a2124d63`

`.docs/system_overview/evidence_verification.md`
- size: `18599`
- SHA-256:
  `fc7d485728b8ba2815ae7a9f3e21b0859f0e35ba28083ba355a64047857f5875`

`tools/evidence_verify/verify_v1.py`
- size: `40121`
- SHA-256:
  `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`

`tools/evidence_verify/test_verify_v1.py`
- size: `83542`
- SHA-256:
  `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea`

`tools/evidence_verify/registry_v1.json`
- size: `585`
- SHA-256:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`

`tools/evidence_verify/layouts/a6d_successor_v1.json`
- size: `892`
- SHA-256:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`

`tools/evidence_verify/layouts/a6d_amendment_v1.json`
- size: `856`
- SHA-256:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`

`tools/evidence_verify/layouts/a6_policy_v1.json`
- size: `1015`
- SHA-256:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`

`tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
- size: `3338`
- SHA-256:
  `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98`

`tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`
- size: `14418`
- SHA-256:
  `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f`

All paths must be regular, single-link, working mode `0644`, logical mode
`100644`.

Require:

- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

## 3. Process and Git boundary

Use:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Only the audit parent may execute Git.

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry every environment value above;
- be recorded with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

No auditor may execute Git.

No Git command may run in:

- PRIMARY_R;
- CANDIDATE_R;
- A6D;
- A6D_AMEND;
- IMPLEMENTATION_EVIDENCE;
- PRIOR_AUDIT;
- AUDIT_ROOT;
- another evidence or audit root.

Non-Git absolute-path reads before the first Git command are allowed.

Before a repository-relative read, use cwd IMPL_R or an absolute IMPL_R path.

Any nonconforming Git invocation or PRIMARY_R-relative repository access is a
current audit-process blocker.

## 4. Opening provenance gate

Require:

- physical repository root equals lexical IMPL_R;
- expected branch, HEAD, tree, sole parent, and absent upstream;
- exact 13-path scope and classifications;
- exact modes, sizes, and hashes;
- exact canonical manifest;
- exact tracked binary diff;
- exact recipe source and recipe ID;
- implementation evidence records present and stable;
- prior audit present and stable;
- caller present and exact;
- A6D and amendment manifests exact.

Stop before correctness inspection on any mismatch:

AUDIT_PROVENANCE_MISMATCH

## 5. Opening provenance reproduction

After the complete gate passes, require AUDIT_ROOT absent.

Create it under umask `077` with:

opening/
provenance/
perspectives/
validation/
findings/
closeout/
tmp/

Run the exact unchanged RECIPE twice into fresh opening continuations.

Require:

- both exits `0`;
- empty stderr;
- both output files byte-identical;
- both stdout streams byte-identical;
- stdout equals its output file;
- all outputs equal the indexed canonical manifest;
- manifest SHA-256:
  `0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0`;
- tracked binary diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- no repository or supplied-evidence mutation.

Stop on mismatch:

AUDIT_PROVENANCE_MISMATCH

## 6. Four distinct audit instances

AP-06 must be closed through orchestration, not repository mutation.

Create four distinct auditor instances.

### Initial concurrent wave

Start exactly three distinct auditors concurrently:

1. Contract, authority, and complete-document auditor.
2. Structured-contract/parser correctness auditor.
3. Test and validation-adequacy auditor.

Give each:

- the same reproduced canonical manifest;
- the exact expected field map below;
- CT-01 and AP-06 history;
- current authority boundaries;
- explicit non-goals;
- read-only posture;
- no Git authority;
- standard audit finding format.

Wait until at least one initial auditor completes and close that auditor.

### Fourth distinct auditor

After a slot becomes available, start a fourth, distinct:

4. Security, filesystem, process, evidence, and artifact auditor.

It must be a new auditor instance, not reuse of any first-wave auditor.

If any required auditor fails to start:

- retry that role once;
- record both attempts.

If the fourth distinct auditor cannot start after one retry, return:

SUBAGENT_UNAVAILABLE

Do not have another auditor perform two roles.
Do not replace missing coverage with parent inference.
Do not proceed to ACCEPT without reports from four distinct instances.
No nested delegation.

## 7. Authoritative contract audit

Independently locate the authoritative contract block in:

`.docs/system_overview/evidence_verification.md`

Expected contract ID:

`execution-substrate.evidence-verification.trusted-host-contract.v1`

Require exactly one authoritative block across all four governing documents.

Build an audit-owned parser. Do not import or reuse test 89’s parser or helper
as the sole oracle.

Require strict JSON with:

- duplicate-key rejection;
- unknown-key rejection;
- missing-key rejection;
- exact type checks;
- exact values;
- canonical sorted-key compact JSON encoding;
- exact marker and Markdown-fence structure;
- no second authoritative block.

Expected complete field map:

```json
{
  "all_interpreter_installation_writers_trusted": true,
  "atomic_loaded_object_binding_claimed": false,
  "foreground_validation_process_trusted": true,
  "interpreter_observation_authority": "corroboration-only",
  "interpreter_trust_model": "trusted-host-stable-path-v1",
  "kernel_and_process_execution_substrate_trusted": true,
  "operator_controlled_host_required": true,
  "out_of_contract_argv_and_environment_untrusted": true,
  "pinned_interpreter_installation_and_ancestors_trusted": true,
  "preseal_candidate_untrusted": true,
  "production_host_attestation": false,
  "remotely_administered_hostile_host_supported": false,
  "schema": "execution-substrate.evidence-verification.trusted-host-contract.v1",
  "scope": "supported-local",
  "shared_or_adversarial_host_supported": false,
  "supplied_repository_and_provenance_inputs_trusted": true,
  "target_content_untrusted": true,
  "target_controlled_script_paths_untrusted": true,
  "transient_trusted_principal_replacement_covered": false,
  "undocumented_launcher_fallback_authorized": false,
  "unproven_package_registry_layout_inputs_untrusted": true,
  "verifier_result_authority": "structural-evidence-only"
}
```

Confirm that this structured object is:

- private documentation/assurance material;
- not a product schema;
- not a runtime protocol;
- not a public API;
- not readiness, execution, commit, or publication authority.

## 8. Consumer-reference audit

Independently locate the bounded reference sections in:

- `PLANS.md`;
- `.docs/system_overview/artifact_hygiene.md`;
- `.docs/system_overview/capability_probing.md`.

Require in each:

- exactly one bounded reference section;
- exact contract ID;
- exact sole-writer declaration naming
  `.docs/system_overview/evidence_verification.md`;
- explicit statement that the consumer does not redefine, override, narrow, or
  widen the contract;
- no second authoritative contract block;
- no local override;
- no independent duplicate full contract.

Inspect the complete governing documents, not only marked blocks.

Confirm there is no contradictory prose elsewhere that:

- claims atomic interpreter custody;
- supports shared or hostile hosts;
- claims production host attestation;
- treats interpreter observations as proof;
- authorizes an undocumented launcher fallback;
- gives verifier output readiness, execution, commit, or runtime authority;
- excludes an interpreter-installation writer from the trusted boundary.

If explanatory prose outside the bounded sections exists, determine whether it
is clearly subordinate to the authoritative block. Preserve any ambiguity as a
finding.

## 9. Test 89 source audit

Inspect:

`InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`

Require:

- identity preserved;
- exactly one complete-contract validator;
- no reliance on independent `assertIn` phrase presence as the acceptance
  mechanism;
- duplicate-key rejection;
- unknown/missing/type/value validation;
- canonical encoding validation;
- exact bounded-section parsing;
- reference-section validation;
- unauthorized authoritative-block rejection;
- exact verifier SHA-256 pin;
- mechanism-specific rejection reasons.

Inspect whether the test’s expected-field constants are independent enough to
detect document drift rather than mechanically deriving their values from the
document under test.

Identify any shared-oracle weakness between:

- contract generation;
- test expected map;
- mutation matrix;
- separate producer validator.

## 10. Independent contradiction matrix

Using only audit-owned copies in AUDIT_ROOT, independently reproduce all 31
reported mutations.

Do not call the test helper as the only validator.

Require exact intended rejection classes for:

1. atomic loaded-object binding true;
2. transient trusted-principal replacement covered true;
3. shared/adversarial host support true;
4. remotely hostile administration support true;
5. production attestation true;
6. interpreter observations upgraded to proof;
7. installation writers untrusted;
8. fallback authorized;
9. readiness authority;
10. execution authority;
11. commit authority;
12. widened scope;
13. wrong contract ID;
14. boolean replaced by string;
15. string replaced by boolean;
16. missing mandatory key;
17. unknown key;
18. duplicate key;
19. duplicate authoritative block;
20. authoritative block in a consumer;
21. wrong consumer contract ID;
22. missing consumer reference;
23. local override;
24. contradiction inside authoritative section;
25. contradiction inside reference section;
26. malformed marker;
27. malformed JSON fence;
28. noncanonical JSON;
29. duplicate consumer reference;
30. wrong sole-writer declaration;
31. consumer-declared overriding semantics.

For every mutation:

- keep all unrelated syntax valid when possible;
- require failure for the intended mechanism;
- record observed reason;
- compare with implementation CONTRADICTION_LEDGER.

Also independently inspect the unchanged complete current documents for
contradictions outside the marked sections.

Do not require test 89 to reject arbitrary prose outside the authoritative and
reference sections when the contract clearly makes that prose subordinate.
Do require the current documents themselves to be coherent.

## 11. Test execution

Use pinned Python 3.13.4.

Freshly run:

### Static gates

- `ast.parse` on verifier and test source;
- parse both historical `.py.txt` fixtures without executing them;
- strict canonical JSON parsing of registry and all three layouts;
- registry-to-layout hash validation;
- historical fixture hash validation;
- audit-owned authoritative-contract parser;
- audit-owned 31-case contradiction matrix;
- rooted parent-only `git diff --check`.

### Test 89 targeted runs

Run test 89 alone three times.

Require every owning command:

- exit `0`;
- exactly one test;
- zero failure;
- zero error;
- zero skip;
- all 31 contradiction cases execute;
- repository snapshot unchanged.

### Complete suites

Independently discover the complete test set.

Expected:

- exactly 89 identities;
- tests 01 through 88;
- `InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`.

Run:

- twice under umask `077`;
- twice under umask `022`.

Require every owning command:

- exit `0`;
- 89 tests;
- zero failure;
- zero error;
- zero skip;
- identical identity set;
- no repository artifact.

Do not accept an inner successful unittest result when its owning wrapper exits
nonzero.

## 12. Unchanged verifier and caller audit

Require verifier SHA-256 remains:

bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Require source-external caller SHA-256 remains:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Reinspect enough source to confirm the documentary/test repair did not alter or
misstate:

- source-by-value launch protocol v2;
- direct-script/stdin/FD nonqualification;
- package/source exact-byte consistency;
- trusted-host boundary;
- mandatory caller nonclaims;
- structural-evidence-only authority;
- no-write/no-network behavior;
- absence of fallback launchers.

## 13. Fresh compatibility checks

The implementation intentionally did not rerun acceptance-bearing
compatibility. This audit must do so.

Build an audit-owned minimal caller or independently inspect and reconstruct the
documented caller behavior. Do not treat the producer caller as an oracle.

Run:

### Sealed A6D

Twice.

Require:

- exit `0`;
- empty verifier stderr;
- byte-identical canonical stdout;
- expected stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- mandatory nonclaim fields;
- target/package/TMPDIR unchanged;
- A6D manifest unchanged.

### Sealed amendment

Twice.

Require:

- exit `0`;
- empty verifier stderr;
- byte-identical canonical stdout;
- expected stdout SHA-256:
  `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`;
- mandatory nonclaim fields;
- target/package/TMPDIR unchanged;
- amendment manifest unchanged.

### Synthetic A6

Create an audit-owned fixture using independently inspected writer logic.

Run:

1. pre-seal twice;
2. seal only the audit-owned fixture;
3. sealed twice.

Require:

- all exits `0`;
- empty stderr;
- deterministic output within each stage;
- target/package/candidate/TMPDIR unchanged by verifier invocation;
- verifier installs nothing;
- fixture removed at cleanup.

### Source-by-value SEC-02 regression

Run a fresh audit-owned target-marker causal.

Require:

- target-controlled source exists;
- valid source-by-value launch never loads it;
- marker never appears;
- direct-script predecessor shape remains nonqualifying;
- no claim against in-boundary malicious interpreter replacement.

## 14. Implementation-evidence audit

Inspect the complete IMPLEMENTATION_EVIDENCE tree.

Require:

- opening and final provenance bind the reported bytes;
- evidence inventory matches every retained file;
- closing gate matches live repository identity;
- validation summary selects final qualifying attempts;
- failed and superseded attempts remain separate;
- three test-89 runs are final and passing;
- four full-suite runs are final and passing;
- mutation ledger contains all 31 cases and specific reasons;
- verifier and caller are reported unchanged;
- no compatibility result is falsely claimed as rerun by implementation;
- AP-06 is correctly classified as audit process, not patch behavior;
- no prior audit is portrayed as qualifying changed bytes;
- no readiness or product-authority widening appears.

## 15. Authority and artifact audit

Audit the whole 13-path patch.

Require:

- verifier remains an ES-owned bounded slice rule;
- structured contract remains private documentation/assurance;
- proof output and caller records remain evidence/projection;
- no run truth, readiness, product, runtime, orchestration, admission, durable
  state, commit, or publication authority;
- no public or runtime schema;
- no new cross-repository framework owner;
- no proof harness promoted into product architecture.

Scan IMPL_R for:

- `__pycache__`;
- `.pyc` and `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixtures;
- databases;
- journals;
- locks;
- build outputs;
- unexpected executable modes;
- unsupported file types.

Historical fixtures must remain inert.

## 16. Prior-finding closure

Reconcile at least:

- CT-01;
- AP-06;
- SEC-01;
- SEC-02;
- VC-01 / SEC-A1;
- EV-01 through EV-09;
- F-01 through F-04;
- PP-01;
- PE-02;
- TA-03;
- AP-04;
- AP-05;
- CA-01.

CT-01 closes only if:

- one authoritative structured contract exists;
- consumer references cannot override it;
- current complete documents are coherent;
- test 89 validates the complete contract;
- all 31 independent contradictions fail for intended reasons;
- no shared-oracle defect makes test and document drift together undetectably.

AP-06 closes only if four distinct auditor instances complete.

Do not represent the trusted-host premise as atomic interpreter custody.

## 17. Closing provenance

Remove only audit-owned temporary fixtures.

Run the exact unchanged RECIPE twice into a fresh closing continuation.

Require:

- both exits `0`;
- empty stderr;
- both outputs byte-identical;
- stdout equals output file;
- outputs equal the indexed canonical manifest;
- manifest SHA-256:
  `0d7180be1a6fff58a78ea845de63e80b77cbb53e56537de27838aed1b3885dd0`;
- tracked binary diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- exact opening/closing repository identity;
- zero staged/deleted/renamed/unmerged;
- no repository or supplied-evidence mutation;
- implementation evidence, prior audit, caller, A6D, amendment, and candidate
  unchanged.

On mismatch:

AUDIT_PROVENANCE_MISMATCH

## 18. Finding format

AUDIT FINDING

ID:
Type:
Severity: critical | high | medium | low | observation
Classification:
Current contract or strategic target:
Path and line:
Evidence:
Reachable mechanism:
Impact:
Required correction:
Containment/nonclaim:
Uncertainty:
Patch defect, contract defect, pre-existing issue, producer-process issue, or
audit-process issue:
Blocking: yes | no

## 19. Verdict rules

### AUDIT_PROVENANCE_MISMATCH

Use for any repository, recipe, manifest, path, classification, type, mode,
size, hash, diff, evidence-index, or closing-provenance mismatch.

Stop before correctness inspection on opening mismatch.

### SUBAGENT_UNAVAILABLE

Use when a required distinct auditor cannot be started after one retry.

Do not substitute another auditor or parent inference.

### REJECT

Use only for a fundamental authority or architectural defect that cannot be
repaired within the bounded documentation/test tranche.

### BLOCK

Use when a repairable defect remains in:

- single-authority contract structure;
- contract or reference coherence;
- contradiction resistance;
- test independence;
- validation;
- implementation evidence;
- authority boundaries;
- artifacts;
- current audit process.

### ACCEPT

Use only when:

- opening and closing provenance match;
- four distinct auditors completed;
- one authoritative structured contract exists;
- all consumer references are exact and non-overriding;
- current complete documents are coherent;
- audit-owned strict parsing succeeds;
- all 31 independent contradiction cases reject correctly;
- test 89 is complete and independent enough;
- all targeted and full-suite runs pass;
- verifier and caller remain unchanged;
- fresh A6D, amendment, synthetic, and SEC-02 checks pass;
- authority remains bounded;
- no artifact or audit-process blocker remains.

## 20. Complete inline final report

Your final response must include the complete audit report inline.

Do not replace a section with a link.

Supplemental links may follow the complete report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact audit target and input identities.
4. Opening and closing provenance.
5. Repository identity and 13-path scope.
6. Four distinct auditor instance IDs, roles, scheduling, retries, and status.
7. CT-01 repair summary.
8. Authoritative contract block review.
9. Exact parsed field map.
10. Canonical JSON and marker/fence review.
11. Consumer-reference review.
12. Complete-document contradiction review.
13. Test 89 source and oracle-independence review.
14. Independent 31-case contradiction matrix.
15. Three targeted test-89 results.
16. Exact 89-test identity set.
17. Both umask-077 results.
18. Both umask-022 results.
19. Verifier and caller unchanged-byte review.
20. A6D results.
21. Amendment results.
22. Synthetic A6 results.
23. Source-by-value SEC-02 result.
24. No-write and deterministic-output evidence.
25. Implementation-evidence review.
26. Authority and non-authority adjudication.
27. Artifact findings.
28. Prior-finding closure table.
29. Severity-ranked residual findings.
30. Minority findings and parent resolution.
31. Remaining uncertainty and explicit nonclaims.
32. Audit-created path inventory and cleanup.
33. Complete Git-process record.
34. Explicit confirmations:
    - repository mutation not performed;
    - formatting not performed;
    - repair not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network contact not performed;
    - nested subagents not created.

No repair.
No staging.
No commit.
No push.
No A6 restart.
```

## After the audit

An `ACCEPT` result should move directly to the exact-byte commit gate. No further implementation, threat-model redesign, or producer replay should occur between audit acceptance and staging. The commit gate must regenerate `0d7180be…85dd0`, stage only the accepted 13 paths, compare staged and committed blobs to the accepted manifest, and stop on any drift. The project protocol permits commit only after audit acceptance and forbids implementation repair during the commit gate. 

### Sources

- The prior audit identified CT-01 as its only repository-patch blocker and separately recorded AP-06 as an audit-process limitation. 
- Independent audit must be a fresh read-only conversation, reproduce exact provenance first, and must not repair the patch. 
- The protocol calls for distinct contract, correctness, validation, and security audit roles, with at most one retry and no silent substitution for missing coverage. 
- Proof and generated evidence must remain non-authoritative rather than becoming architecture by drift. 
- Provenance binds audit to the exact implementation bytes but does not establish correctness or authority. 

**Confidence**

- CT-01 repair is ready for audit: **0.995**
- Verifier and caller should remain unchanged: **0.999**
- Four-distinct-auditor scheduling closes AP-06 without code changes: **0.99**
- Main audit risk is independent-oracle adequacy, not runtime behavior: **0.96**
- Correct next step is fresh audit, then exact-byte commit on `ACCEPT`: **0.999**
