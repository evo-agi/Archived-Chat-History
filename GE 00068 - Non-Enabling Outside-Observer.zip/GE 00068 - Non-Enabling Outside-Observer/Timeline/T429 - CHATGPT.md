## Engineering assessment

The latest failure is a **new internal semantic regression in the reconstruction parent**, not a contract, schema, package, or external-interface defect.

V3 correctly repaired and qualified the external-input layer:

- all 78 interfaces and 639 required pointers passed live preflight;
- the 946-case registry was authenticated at 946 rows with 946 unique names;
- `names_unique:true` matched independently derived uniqueness;
- the 32-case interface matrix passed;
- the independent interface validator passed;
- the earlier negative-checker repair remained qualified.

The failure arose later, inside the parent’s own schema-role/family mapping:

```python
CONTRACT_POINTERS[family]
```

received `family=None` for `normative-construction-parent`. That role is intentionally the fifteenth schema role without a generated-record family. V2 had tolerated that state through a default lookup; V3 removed the default while hardening external interfaces, unintentionally changing a valid internal semantic special case.

A direct one-line restoration is not enough. Three successive one-shot attempts have exposed three different unexercised branches. The next source must therefore pass a **complete end-to-end reconstruction rehearsal before freeze**, not just static analysis, interface preflight, and focused matrices.

The next tranche should:

1. authenticate and reproduce `KeyError(None)`;
2. freeze an explicit internal policy for the intentionally unmapped normative schema role;
3. repair V3 without restoring a generic fallback;
4. audit every changed function for unauthorized semantic drift;
5. execute two complete prefreeze reconstruction rehearsals in distinct disposable roots;
6. independently compare their normalized semantic outputs and terminal closure;
7. only then freeze V4 and execute it once to create the current package.

This should be the **last incremental repair** of the V1→V2→V3 parent lineage. If V4 cannot complete two full prefreeze rehearsals, do not produce V5 by another localized patch. The next engineering treatment would be a clean parent implementation from the already frozen contract, interface contract, artifact plan, and validation specifications.

Construction-parent implementation remains paused until a reconstructed subject is terminally closed and subsequently accepted by a freshly qualified P06/P18-corrected independent-audit harness.

```text
FINAL INCREMENTAL REPAIR OF THE FRESH-SUBJECT RECONSTRUCTION PARENT,
COMPLETE PREFREEZE REHEARSAL, SOURCE FREEZE, AND ONE-SHOT RECONSTRUCTION

This task repairs one internal semantic regression in the V3 fresh-subject
reconstruction parent, qualifies the complete parent through two full
prefreeze reconstruction rehearsals, freezes the exact source, and then
executes it once to produce one fresh schema subject package.

The exact V3 failure is:

- schema role:
  normative-construction-parent;
- generated family:
  null / None, intentionally;
- historical V2 lookup:
  CONTRACT_POINTERS.get(family, ["/"]);
- V3 lookup:
  CONTRACT_POINTERS[family];
- V3 result:
  KeyError(None);
- failing source:
  fresh_subject_reconstruction_parent_v3.py;
- failing line:
  2192;
- supplied-root closing equality:
  passed;
- cleanup:
  passed;
- source drift:
  absent;
- same-root retry:
  forbidden.

The failure is an internal reconstruction-parent semantic regression.

It is not:

- an external-interface fallback failure;
- a normative-contract defect;
- a generated-schema defect;
- a missing generated-record family;
- a package defect;
- authority to amend the fifteen-role or fourteen-family model.

This task must not merely replace `[]` indexing with a generic `.get()`
fallback.

It must explicitly encode and qualify the intentionally unmapped normative
schema role.

This is the final incremental repair permitted for the V1→V2→V3 parent
lineage.

If the repaired candidate cannot complete two full, terminally sealed
prefreeze reconstruction rehearsals, return the blocked verdict and state that
the next treatment is a clean construction-parent rewrite from the frozen
contracts and specifications. Do not propose V5 as another localized patch.

This task does not:

- alter the normative construction-parent contract;
- alter any of the fifteen current schemas;
- change the fifteen schema-role set;
- change the fourteen generated-record-family set;
- add a fifteenth generated-record family;
- change the 946 negative cases or their expectations;
- change the 137 contradiction-regression cases or their expectations;
- reuse or patch the historical blocked construction-parent implementation;
- execute process-self-test;
- execute construct mode;
- construct a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- qualify the product;
- authorize A6.

Do not modify, resume, clean, finish, or retry any supplied failed root.

Do not promote any result from a failed root as a current package result.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one fresh repair/package root and separate disposable rehearsal roots.

Before source freeze:

- bounded source corrections are permitted;
- multiple superseded source attempts may be retained;
- two complete disposable rehearsals are mandatory.

After source freeze:

- source modification is forbidden;
- exactly one final reconstruction-parent execution is permitted;
- no replacement parent is permitted;
- no administrative continuation is permitted;
- no same-root retry is permitted.

Return the complete operative report inline.

Return exactly one primary verdict:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

PACKAGE_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. LATEST FAILED V3 RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

FAILED_V3_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-v3-ajbsz5z0

Expected identity:

- device:
  16777234
- inode:
  180716308
- mode:
  0700
- retained verdict:
  CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Expected V3 parent path:

provenance/fresh_subject_reconstruction_parent_v3.py

Reported identity:

- inode:
  180718354
- mode:
  0600
- size:
  229125
- SHA-256:
  obtain the complete value from the authenticated V3 freeze record and live
  no-follow observation; do not use the abbreviated prose hash.

Expected V3 freeze path:

opening/fresh-subject-reconstruction-parent-v3-freeze-v1.json

Expected V3 failure path:

closing/reconstruction-failure-v1.json

Authenticate through the retained package membership and records:

- bootstrap start;
- V3 source identity;
- source freeze;
- V2→V3 delta;
- external-input crosswalk;
- external-interface contract;
- live interface preflight;
- interface mutation matrix;
- independent interface validator;
- negative-checker regression;
- independent negative-checker validator;
- invocation/process custody;
- artifact plan;
- first blocker;
- partial inventory;
- supplied-root equality;
- cleanup;
- failure outcome.

Classify this root as:

historical_failed_fresh_reconstruction_v3

It is:

- immutable;
- noncurrent;
- nonauthoritative;
- nonresumable;
- not cleanable in this task;
- ineligible to supply current package results.

Require complete opening/closing equality when opened.

──────────────────────────────────────────────────────────────────────────────
2. EARLIER FAILED RECONSTRUCTION LINEAGE
──────────────────────────────────────────────────────────────────────────────

FAILED_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-retry-9w9u27us

Expected identity:

- device/inode:
  16777234 / 180679599
- mode:
  0700

Expected V2 parent:

provenance/fresh_subject_reconstruction_parent_v2.py

- inode:
  180680467
- size:
  202053
- SHA-256:
  3f48bc75330b1c5718b964428c760e62bfab15e00d0f640b5f259b9c52b7da47

FAILED_V1_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-86y_r9l9

Expected identity:

- device/inode:
  16777234 / 180657503
- mode:
  0700

Expected V1 parent:

provenance/fresh_subject_reconstruction_parent_v1.py

- inode:
  180659051
- size:
  167068
- SHA-256:
  5ddc657cccb6e19c810b9a535cbd2d05e62ead31a6990c8ed753904e5fd956a8

Use V1 and V2 only for:

- exact source lineage;
- original negative-checker defect;
- qualified V2 negative-checker repair;
- V2’s historical intentionally-unmapped-role behavior;
- V2→V3 semantic regression comparison.

Do not promote any V1/V2 output as current package evidence.

Require complete opening/closing equality for each root opened.

──────────────────────────────────────────────────────────────────────────────
3. TERMINAL HISTORICAL DECISION
──────────────────────────────────────────────────────────────────────────────

FINAL_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-final-subject-p06-p18-reconciliation-v4j7a04y

Expected identity:

- device/inode:
  16777234 / 180632969
- mode:
  0700
- verdict:
  FINAL_SUBJECT_SCHEMA_P06_P18_RECONCILIATION_STOP_AND_RECONSTRUCT
- mandatory progression:
  FRESH_SUBJECT_RECONSTRUCTION_AND_FRESH_HARNESS_EVALUATION
- historical reconciliation terminal:
  true
- further historical reconciliation authorized:
  false

Expected final diagnostic inventory:

closeout/final-diagnostic-inventory-v1.json

- inode:
  180633002
- size:
  14272
- SHA-256:
  a80260149b05ca1f173426165ae41559696029b2a972149bdcc2c373644fe304

Authenticate this decision.

Do not initiate any new historical provenance reconciliation.

──────────────────────────────────────────────────────────────────────────────
4. AUTHORITATIVE CONTRACT, SCHEMA, AND VALIDATION INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use these roots as authority for:

- normative-contract bytes;
- exact fifteen schema bytes;
- schema-role identities;
- schema-repair authority;
- generated-record-family semantics;
- root-independent validation specifications;
- 946-case registry;
- 137-case registry;
- witness semantics;
- field-map semantics;
- documentary-validator semantics.

Do not copy historical package authority, temporal inventories, manifests,
reports, package status, confirmations, closing equality, or P06/P18 results as
current evidence.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
5. FRESH V4 REPAIR AND PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-schema-fresh-subject-v4-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- V1, V2, and V3 failed-root identities;
- exact V3 source identity;
- exact KeyError(None) blocker;
- terminal historical decision;
- authoritative contract identity;
- schema authority identities;
- validation-specification source identity;
- final-incremental-repair authority;
- contract change authorized:
  false;
- schema change authorized:
  false;
- schema-role-set change authorized:
  false;
- generated-family-set change authorized:
  false;
- case-registry change authorized:
  false;
- validator semantic change authorized:
  false;
- implementation creation authorized:
  false;
- process-self-test authorized:
  false;
- construct mode authorized:
  false;
- target audit authorized:
  false;
- runtime validation rerun:
  false;
- same-root retry authorized:
  false;
- further incremental parent patch after this task:
  false.

Create directories lazily.

Do not retain an empty directory except the reserved premanifest `manifest/`
directory during terminal closure.

──────────────────────────────────────────────────────────────────────────────
6. EXACT KEYERROR(NONE) REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before editing source, reproduce the exact V3 failure from authenticated bytes.

Retain:

analysis/normative-role-unmapped-keyerror-reproduction-v1.json

Bind:

- schema role:
  normative-construction-parent;
- schema-role row;
- family:
  null / None;
- reason family is null:
  intentionally no generated-record family;
- V2 source expression:
  CONTRACT_POINTERS.get(family, ["/"]);
- V3 source expression:
  CONTRACT_POINTERS[family];
- V3 source function;
- exact V3 source range;
- exact preceding assignments;
- exact `CONTRACT_POINTERS` keys;
- exception:
  KeyError;
- exception argument:
  null / None;
- failure record first-blocker string:
  "None";
- traceback identity;
- package semantic effect:
  none;
- contract effect:
  none;
- schema effect:
  none;
- family-set effect:
  none;
- repair owner:
  reconstruction-parent internal schema/family mapping.

Independently confirm:

- there are exactly fifteen current schema roles;
- there are exactly fourteen generated-record families;
- `normative-construction-parent` is the sole intentionally unmapped schema
  role;
- every other schema role requiring a family has exactly one non-null family.

If any of those facts fails, return the blocked verdict.

Do not restore a generic fallback merely to avoid the exception.

──────────────────────────────────────────────────────────────────────────────
7. INTENTIONALLY UNMAPPED ROLE POLICY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/intentionally-unmapped-schema-role-policy-v1.json

Freeze exactly one intentionally unmapped role:

normative-construction-parent

Required policy:

- exact schema role:
  normative-construction-parent;
- generated family:
  null;
- intentionally unmapped:
  true;
- current schema identity:
  exact;
- normative contract remains sole semantic writer:
  true;
- generated-family authority required:
  false;
- may create a fifteenth family:
  false;
- may be silently treated as unknown:
  false;
- may use a generic dictionary default:
  false.

For every other current schema role:

- `family is None`:
  reject;
- missing mapping:
  reject;
- unknown family:
  reject;
- multiple mappings:
  reject.

Determine the exact output-row representation for the intentionally unmapped
role from:

- the frozen artifact plan;
- V2 source semantics;
- normative contract;
- schema-role/family mapping record shape;
- validation specifications.

If that representation includes a contract-pointer field:

- freeze its exact meaning explicitly;
- do not derive it through generic `.get(..., default)`;
- do not use `"/"` as an RFC 6901 root pointer unless the governing record
  explicitly defines that convention;
- distinguish documentary root-scope notation from an RFC 6901 pointer.

If the exact representation cannot be established without inventing package
semantics, return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

Do not issue another historical reconciliation.

──────────────────────────────────────────────────────────────────────────────
8. INTERNAL SEMANTIC SPECIAL-CASE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Statically enumerate every internal sentinel or intentional special case used
inside the V3 reconstruction parent, not merely external input interfaces.

Generate:

contract/reconstruction-parent-internal-special-cases-v1.json

At minimum cover:

- schema role with no generated family;
- optional documentary fields;
- empty but valid cleanup sets;
- zero child count;
- zero fixture count;
- root row `"."`;
- reserved premanifest directory;
- manifest self-exclusions;
- implementation absent;
- implementation authority false;
- independent acceptance false before audit;
- null first blocker on success, when allowed;
- empty error arrays;
- empty optional result collections.

For every special case bind:

- owning function;
- source range;
- exact sentinel value;
- semantic meaning;
- permitted contexts;
- forbidden contexts;
- required branch;
- output representation;
- matrix cases;
- whether generic truthiness is forbidden;
- whether direct dictionary indexing is forbidden;
- whether a default is permitted.

Require zero unregistered acceptance-bearing sentinel behavior.

──────────────────────────────────────────────────────────────────────────────
9. V3 → V4 SOURCE REPAIR
──────────────────────────────────────────────────────────────────────────────

Copy the authenticated V3 source to:

provenance/fresh_subject_reconstruction_parent_v4.py

Use:

- no-follow stable read;
- exclusive mode-0600 write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison before authorized edits.

Repair ownership:

fresh-subject-intentionally-unmapped-role-and-internal-semantic-preservation

Authorized changes are exactly:

A. Explicit normative-role branch

Implement an explicit branch equivalent to:

- when schema role is exactly `normative-construction-parent`:
  - require family is null;
  - require intentionally-unmapped policy match;
  - do not index `CONTRACT_POINTERS` with null;
  - emit the exact frozen intentionally-unmapped row shape.

- for every other schema role:
  - require family is non-null;
  - require family exists in `CONTRACT_POINTERS`;
  - use direct lookup;
  - reject unknown or missing mapping.

B. Internal special-case enforcement

Use the frozen internal-special-case registry for acceptance-bearing sentinel
handling.

C. Changed-function semantic preservation

Within every changed V3 function:

- retain exact AST equality outside authorized subranges;
- enumerate every changed expression;
- classify it as authorized or unauthorized;
- reject any unauthorized semantic delta.

D. Failure record precision

When the exception is `KeyError`, retain:

- exception type;
- `repr(exception)`;
- exception arguments;
- exact missing key as canonical JSON;
- source line;
- operation;
- traceback identity.

Do not replace the complete blocker with `str(exception)` alone.

E. Preserve all V3-qualified repairs

Preserve unchanged:

- complete external-interface contract;
- exact `names_unique` registry binding;
- row-derived case count and uniqueness;
- no acceptance-bearing fallback;
- V2 negative-checker type safety;
- complete failure closeout;
- terminal package protocol.

Unauthorized changes:

- normative-contract semantics;
- any schema byte;
- fifteen-role set;
- fourteen-family set;
- family normative pointers;
- external-interface semantics;
- 946 case registry or expectations;
- 137 case registry or expectations;
- witness semantics;
- field-map rules;
- documentary-validator semantics;
- package manifest grammar;
- terminal authority semantics;
- implementation authority.

Retain:

analysis/reconstruction-parent-v3-v4-source-delta.json

Require all unrelated functions AST-identical.

──────────────────────────────────────────────────────────────────────────────
10. SCHEMA/FAMILY MAPPING MATRIX
──────────────────────────────────────────────────────────────────────────────

Generate:

validation/schema-role-family-mapping-matrix-v1.json

Cover at minimum:

1. Exact fifteen roles and fourteen families.
2. `normative-construction-parent` with family null.
3. `normative-construction-parent` with non-null family.
4. Non-normative role with null family.
5. Non-normative role with correct family.
6. Non-normative role with unknown family.
7. Duplicate family mapping.
8. Duplicate schema-role mapping.
9. Missing schema role.
10. Extra schema role.
11. Missing generated family.
12. Extra fifteenth family.
13. Direct lookup with null.
14. Generic `.get(..., default)` fallback attempted.
15. Explicit intentionally-unmapped branch.
16. Contract pointer missing for mapped family.
17. Contract pointer present for mapped family.
18. Unmapped row representation exact.
19. Unmapped row representation contains invented authority.
20. Exact V3 failure baseline.
21. Exact repaired V4 baseline.

Require:

- twenty-one unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- no unexpected exception.

──────────────────────────────────────────────────────────────────────────────
11. CHANGED-FUNCTION DIFFERENTIAL VALIDATION
──────────────────────────────────────────────────────────────────────────────

For every function changed from V3 to V4:

- construct a bounded input registry;
- execute V3 and V4 in isolated in-memory or audit-owned contexts;
- compare outputs and failure reasons.

Require semantic equality except for:

- the explicit intentionally-unmapped-role repair;
- structured KeyError evidence improvement;
- fresh-root-bound values.

Retain:

validation/v3-v4-changed-function-differential-v1.json

At minimum include:

- all fifteen schema-role rows;
- all fourteen family mappings;
- exact normative role;
- missing family;
- unknown family;
- duplicate mapping;
- successful baseline mapping;
- failure baseline mapping;
- external registry preflight paths;
- negative-checker historical case;
- empty cleanup;
- nonempty cleanup;
- package-status generation.

Require zero unauthorized output differences.

──────────────────────────────────────────────────────────────────────────────
12. REGRESSION PRESERVATION
──────────────────────────────────────────────────────────────────────────────

Rerun unchanged against V4:

A. External-interface qualification

- 78-interface live preflight;
- 32-case external-interface matrix;
- independent external-interface validator.

B. Negative-checker qualification

- 20-case negative-checker regression;
- independent negative-checker validator.

C. Internal-special-case qualification

- internal-special-case matrix covering every registered sentinel.

D. Source security/static qualification

- compile with pinned Python `-I -S -B`;
- AST/call-graph/dataflow analysis;
- bytecode/exception-table analysis.

Require:

- no external-interface regression;
- no negative-checker regression;
- no network;
- no Git;
- no shell;
- no repository/product/target operation;
- all child launches through one recorder;
- no stdin reads;
- no persistent loop;
- failure closeout reachable;
- terminal protocol unchanged;
- no unregistered acceptance-bearing sentinel;
- explicit normative-role branch present;
- no direct `CONTRACT_POINTERS[family]` path where family may be null.

──────────────────────────────────────────────────────────────────────────────
13. COMPLETE PREFREEZE REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

Before source freeze, execute V4 through its complete intended reconstruction
pipeline against one disposable, audit-owned rehearsal root.

Prefix:

ES-repair10i-v3-fresh-subject-v4-rehearsal-a-

Use exact production inputs and exact production semantics.

This is a qualification rehearsal, not a current package.

It must complete:

1. input authentication;
2. artifact planning;
3. contract copy;
4. fifteen-schema copy;
5. fifteen-role registry;
6. fourteen-family authority;
7. schema/family mapping;
8. metaschema validation;
9. fresh family reconstruction;
10. contract witnesses;
11. schema witnesses;
12. complete 946-case negative matrix;
13. complete 137-case contradiction regression;
14. 766/333 field map;
15. ten documentary-validator results;
16. ten-role validator registry;
17. evidence DAG;
18. independent schema validator;
19. confirmation evidence;
20. explicit confirmations;
21. current-role occupancy;
22. package status;
23. lineage;
24. supplied-root equality;
25. cleanup;
26. temporal inventory;
27. manifest A/B;
28. independent terminal reprojection;
29. terminal topology and modes;
30. no-write-after-seal.

Require rehearsal verdict:

rehearsal-passed-nonauthoritative

Retain complete rehearsal identities and result under the V4 repair root.

Do not promote rehearsal artifacts as current package artifacts.

──────────────────────────────────────────────────────────────────────────────
14. COMPLETE PREFREEZE REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Execute an independently allocated second rehearsal root:

ES-repair10i-v3-fresh-subject-v4-rehearsal-b-

Use identical source bytes, inputs, argv shape, environment, and semantics.

Require the same complete pipeline and terminal closure.

Retain:

validation/two-complete-v4-rehearsals-v1.json

Compare rehearsals A and B after explicit normalization of only:

- physical rehearsal-root path;
- root device/inode;
- root-bound generated identities;
- timestamps when documentary and nonacceptance-bearing;
- child PIDs;
- other explicitly enumerated physical bindings.

Require semantic equality for:

- normative contract;
- fifteen schema identities;
- fifteen-role registry;
- fourteen-family registry;
- mapping;
- witness semantics;
- all 946 case names/results;
- all 137 case names/results;
- field-map rows;
- ten validator-role set;
- all validator pass results;
- confirmation semantics;
- occupancy;
- package status;
- manifest grammar;
- normalized terminal manifests.

Require:

- both rehearsals pass;
- zero unexplained normalized differences;
- zero unregistered outputs;
- zero process or descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
15. INDEPENDENT REHEARSAL AUDIT
──────────────────────────────────────────────────────────────────────────────

Implement an independent validator that imports neither:

- V4 parent helpers;
- rehearsal driver helpers;
- producer expected-result maps;
- producer fixture builders.

It must independently inspect:

- both rehearsal roots;
- complete pipeline result presence;
- exact 946/137 closure;
- fifteen/ fourteen role closure;
- field-map closure;
- ten-validator closure;
- terminal inventories;
- manifests;
- terminal reprojections;
- cleanup;
- normalized determinism.

Retain:

validation/independent-v4-rehearsal-validator-v1.json

Require zero errors.

If either rehearsal or the independent rehearsal validator fails:

- do not freeze V4;
- do not execute the final reconstruction;
- return:
  CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED;
- state that incremental V1→V4 repair is exhausted;
- select as the next treatment:
  clean reconstruction-parent implementation from the frozen contract,
  interface contract, artifact plan, and validation specifications;
- do not propose V5.

──────────────────────────────────────────────────────────────────────────────
16. REHEARSAL CLEANUP
──────────────────────────────────────────────────────────────────────────────

After both rehearsals and independent validation:

- retain complete inventories of rehearsal A and B;
- retain all terminal identities and normalized comparison records;
- remove each exact rehearsal root;
- observe ENOENT twice for each;
- require zero process survivors;
- require zero descriptor survivors;
- require zero cache/bytecode survivors.

No rehearsal root may remain current.

──────────────────────────────────────────────────────────────────────────────
17. V4 SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze V4 only after all previous qualification gates pass.

Retain:

opening/fresh-subject-reconstruction-parent-v4-freeze-v1.json

Bind:

- exact V4 source identity;
- V1/V2/V3 source lineage;
- KeyError reproduction;
- intentionally-unmapped-role policy;
- internal-special-case registry;
- V3→V4 delta;
- schema/family mapping matrix;
- changed-function differential;
- external-interface regressions;
- negative-checker regressions;
- both complete rehearsal results;
- independent rehearsal validator;
- rehearsal cleanup;
- authoritative supplied input identities;
- later source modification permitted:
  false;
- same-root retry permitted:
  false.

Reopen V4 no-follow and verify exact identity.

Do not modify V4 afterward.

──────────────────────────────────────────────────────────────────────────────
18. FROZEN V4 REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen V4 source, rerun read-only or disposable-fixture
qualification:

- compilation;
- static analyses;
- schema/family mapping matrix;
- changed-function differential;
- external-interface matrix;
- independent external-interface validator;
- negative-checker regression;
- independent negative-checker validator;
- internal-special-case matrix;
- source identity and freeze checks.

Do not rerun the two complete rehearsals after freeze unless the freeze record
explicitly requires a source-byte-only replay mode. The passing complete
rehearsals must bind the exact bytes later frozen.

Retain:

validation/frozen-v4-requalification-v1.json

Require complete identity linkage between rehearsed source bytes and frozen
source bytes.

──────────────────────────────────────────────────────────────────────────────
19. ONE-SHOT FINAL RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Execute exact frozen V4 once to produce the current package in the fresh
package root.

Use:

- pinned Python;
- exact `-I -S -B`;
- direct argv;
- explicit environment;
- DEVNULL stdin;
- one finite parent;
- no shell;
- no replacement parent;
- no administrative continuation;
- no retry.

The parent must execute the complete reconstruction pipeline from the
beginning.

No rehearsal output and no failed-root output may substitute for a fresh
current result.

──────────────────────────────────────────────────────────────────────────────
20. FINAL RECONSTRUCTION REQUIREMENTS
──────────────────────────────────────────────────────────────────────────────

The current package must freshly establish:

- exact normative contract;
- exact fifteen schemas;
- exact fifteen current schema roles;
- exact fourteen generated-record families;
- normative-construction-parent as the sole intentionally unmapped schema role;
- fourteen one-to-one mappings;
- all fifteen schemas metaschema-valid;
- fresh fourteen-family reconstruction;
- fourteen contract witnesses schema-valid;
- fourteen schema witnesses contract-valid;
- zero jointly unsatisfiable families;
- zero under-enforced baseline families;
- complete 946-case negative matrix pass;
- historical ordinal-4 mutation correctly rejected;
- complete 137-case contradiction-regression pass;
- 766/333 field-map closure;
- exactly ten documentary-validator roles;
- all ten fresh results passing;
- acyclic evidence DAG;
- independent schema-validator pass;
- confirmation-evidence pass;
- evidence-derived confirmations;
- current-role occupancy;
- package status:
  fresh-reconstructed-pending-independent-audit;
- implementation present false;
- implementation authority false;
- independent acceptance false;
- supplied-root equality;
- cleanup;
- temporal inventory;
- terminal manifests;
- final reprojection;
- terminal topology/modes;
- no postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
21. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On success or failure retain:

- parent/source identity;
- complete child ledger;
- first blocker;
- structured exception details;
- partial-artifact inventory;
- fixture/cache cleanup;
- process/descriptor survivors;
- complete supplied-root closing equality;
- same-root retry forbidden.

On failure:

- package authority false;
- terminal closure false;
- no success manifests;
- nonzero exit;
- failed root retained immutable;
- no external post-failure validator.

Failure to complete cleanup or supplied-root closing equality is:

PACKAGE_PROVENANCE_MISMATCH

rather than an ordinary reconstruction blocker.

──────────────────────────────────────────────────────────────────────────────
22. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened,
including:

- V3 failed root;
- V2 failed root;
- V1 failed root;
- terminal historical reconciliation;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any additional historical root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every V4-owned fixture/cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
23. TERMINAL PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Use the frozen fresh-subject manifest grammar:

- root row `"."` present exactly once;
- directory fields:
  device, gid, inode, kind, mode, path, uid;
- regular fields additionally:
  nlink, size, sha256;
- exact A/B self-exclusions;
- no mtime, ctime, directory size, or directory link count.

Use two independently authored reprojectors.

Use the stabilized final-namespace protocol:

1. Finalize every nonmanifest artifact.
2. Generate and verify temporal inventory.
3. Ensure reserved manifest directory exists.
4. Exclusively create zero-length A and B before either projection.
5. Retain both descriptors.
6. Fsync both empty files and manifest directory.
7. Generate A and B independently with both paths excluded.
8. Require generated bytes identical.
9. Write through retained descriptors.
10. Fsync and close both.
11. Fsync manifest directory.
12. Reopen no-follow.
13. Reverify path/inode/type/mode/link/size/hash.
14. Require A equals B.
15. Independently reproject final root.
16. Require root row present exactly once.
17. Require no empty descendant.
18. Require no symlink, special object, or multi-link regular file.
19. Require modes `0700/0600`.
20. Require no cache or bytecode.
21. Seal exactly once.
22. After seal, permit only guarded terminal stream output and immediate
    nonreturning exit.
23. Perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

only when:

- KeyError causal is authenticated;
- intentionally-unmapped-role policy closes;
- V4 source repair is bounded;
- mapping matrix passes;
- changed-function differential passes;
- all prior regressions pass;
- two complete rehearsals pass;
- independent rehearsal validator passes;
- rehearsal cleanup passes;
- V4 source freezes and remains unchanged;
- frozen V4 requalification passes;
- final V4 parent executes exactly once;
- complete reconstruction pipeline passes;
- package terminally closes;
- no write follows seal.

Return:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED

when:

- intentionally-unmapped representation remains ambiguous;
- source repair cannot be isolated;
- any prefreeze full rehearsal fails;
- rehearsals diverge semantically;
- independent rehearsal validation fails;
- a fresh semantic validation lane fails;
- package authority remains ambiguous;
- package cannot close without changing contract or schema semantics.

If this verdict results from a failed prefreeze rehearsal, explicitly state:

incremental_repair_lineage_exhausted = true

and select:

clean_parent_implementation_required = true

Do not recommend V5.

Return:

PACKAGE_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source drift after freeze;
- fixed input identity mismatch;
- unaccounted process or filesystem effect;
- missing failure closeout;
- cleanup inequality;
- supplied-root closing inequality;
- terminal package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh package-root identity
3. V3 failed-root identity and disposition
4. V2/V1 lineage identities and dispositions
5. Terminal historical decision authentication
6. Contract/schema/validation input identities
7. Exact V3 parent identity
8. Exact KeyError(None) reproduction
9. Intentionally-unmapped-role policy
10. Internal semantic special-case registry
11. V4 parent identity
12. Exact V3→V4 source delta
13. Schema/family mapping matrix
14. Changed-function differential result
15. External-interface regression result
16. Negative-checker regression result
17. Independent negative-checker result
18. Internal-special-case matrix
19. Compilation/static analyses
20. Rehearsal A identity and complete result
21. Rehearsal B identity and complete result
22. Rehearsal normalized comparison
23. Independent rehearsal validator
24. Rehearsal cleanup
25. V4 source freeze
26. Frozen V4 requalification
27. Final one-shot parent invocation and custody
28. Complete final child ledger
29. Artifact-plan result
30. Normative contract preservation
31. Exact fifteen schemas
32. Exact fifteen-role registry
33. Exact fourteen families
34. Governing normative pointers
35. Schema/family mapping
36. Metaschema result
37. Fresh family reconstruction
38. Contract-witness result
39. Schema-witness result
40. Complete 946-case result
41. Historical ordinal-4 result
42. Complete 137-case regression
43. Field-map result
44. Exact ten-role documentary-validator registry
45. All ten fresh validator results
46. Evidence DAG
47. Fresh independent schema-validator result
48. Confirmation evidence and validator
49. Evidence-derived explicit confirmations
50. Current-role occupancy
51. Package status and authority
52. Historical lineage
53. Supplied-root closing equality
54. Fixture/cache cleanup
55. Failure closeout capability and usage
56. Temporal-inventory identity
57. Manifest A identity
58. Manifest B identity
59. Independent terminal reprojection
60. Terminal membership and modes
61. Root-row presence
62. No-write-after-closure
63. Remaining uncertainty and nonclaims
64. Explicit confirmation registry

Required confirmations:

V3_FAILED_ROOT_MUTATION_NOT_PERFORMED
V3_FAILED_ROOT_NOT_RESUMED
V3_FAILED_ROOT_NOT_CLEANED
V2_FAILED_ROOT_MUTATION_NOT_PERFORMED
V1_FAILED_ROOT_MUTATION_NOT_PERFORMED
TERMINAL_HISTORICAL_DECISION_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
EXACT_V3_PARENT_SOURCE_AUTHENTICATED
KEYERROR_NONE_CAUSAL_REPRODUCED
NORMATIVE_CONSTRUCTION_PARENT_INTENTIONALLY_UNMAPPED
NO_FIFTEENTH_GENERATED_FAMILY_CREATED
EVERY_OTHER_SCHEMA_ROLE_HAS_EXACTLY_ONE_FAMILY
INTENTIONALLY_UNMAPPED_ROLE_POLICY_FROZEN
INTERNAL_SPECIAL_CASE_REGISTRY_COMPLETE
V4_REPAIR_BOUNDED_TO_INTERNAL_SEMANTIC_REGRESSION
EXTERNAL_INTERFACE_REPAIRS_PRESERVED
NEGATIVE_CHECKER_REPAIRS_PRESERVED
CONTRACT_SEMANTICS_UNCHANGED
ALL_FIFTEEN_SCHEMA_BYTES_UNCHANGED
NEGATIVE_CASE_REGISTRY_UNCHANGED
NEGATIVE_CASE_EXPECTATIONS_UNCHANGED
SCHEMA_ROLE_FAMILY_MAPPING_MATRIX_PASSED
V3_V4_CHANGED_FUNCTION_DIFFERENTIAL_PASSED
EXTERNAL_INTERFACE_REGRESSION_PASSED
NEGATIVE_CHECKER_REGRESSION_PASSED
INDEPENDENT_NEGATIVE_CHECKER_VALIDATOR_PASSED
INTERNAL_SPECIAL_CASE_MATRIX_PASSED
V4_PARENT_COMPILED
V4_PARENT_STATIC_ANALYSES_PASSED
COMPLETE_REHEARSAL_A_PASSED
COMPLETE_REHEARSAL_B_PASSED
TWO_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_REHEARSAL_VALIDATOR_PASSED
REHEARSAL_ROOTS_CLEANED
V4_PARENT_SOURCE_FROZEN
V4_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_V4_REQUALIFICATION_PASSED
V4_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
PARENT_STDIN_NOT_READ
ALL_CHILDREN_ROUTED_THROUGH_RECORDER
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
EVERY_GENERATED_FAMILY_HAS_NORMATIVE_AUTHORITY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FRESH_FOURTEEN_FAMILY_RECONSTRUCTION_PASSED
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_PASSED
HISTORICAL_BLOCKING_CASE_PASSED_AS_REJECTED_MUTATION
CONTRADICTION_REGRESSION_137_PASSED
CONTRACT_SCHEMA_FIELD_MAP_CLOSED
EXACTLY_TEN_CURRENT_DOCUMENTARY_VALIDATOR_ROLES
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_FRESH
ALL_TEN_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
DOCUMENTARY_VALIDATOR_EVIDENCE_GRAPH_ACYCLIC
INDEPENDENT_SCHEMA_VALIDATOR_PASSED
CONFIRMATION_EVIDENCE_MAP_PASSED
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
FAILURE_CLOSEOUT_CAPABLE
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FRESH_SUBJECT_TEMPORAL_INVENTORY_CREATED
FRESH_SUBJECT_TEMPORAL_INVENTORY_VERIFIED
FRESH_SUBJECT_MANIFEST_A_CREATED
FRESH_SUBJECT_MANIFEST_B_CREATED
FRESH_SUBJECT_MANIFESTS_BYTE_IDENTICAL
FRESH_SUBJECT_TERMINAL_REPROJECTION_PASSED
FRESH_SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After:

CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTED_READY_FOR_FRESH_HARNESS

the next tranche is:

1. construct and qualify a fresh independent-audit harness bound to the new
   subject identity;
2. implement explicit fifteen-schema-role and fourteen-family P06 predicates;
3. implement P18 zero-root cleanup using explicit set equality and
   `count == 0`;
4. run one fresh full acceptance audit.

Do not begin construction-parent implementation before that fresh audit accepts
the reconstructed subject.
```

**Source:** Codex’s latest `CONSTRUCTION_PARENT_SCHEMA_FRESH_SUBJECT_RECONSTRUCTION_BLOCKED` report.  
**Confidence:** 0.998 that the immediate failure is an internal V3 semantic regression; 0.99 that complete prefreeze rehearsals are now mandatory; 0.97 that one final V4 incremental repair remains proportionate, provided failure before freeze ends this lineage rather than triggering V5.
