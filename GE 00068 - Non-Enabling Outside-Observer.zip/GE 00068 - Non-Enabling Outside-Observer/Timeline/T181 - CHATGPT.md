## Assessment

This is a substantive **BLOCK** with two narrowly repairable defects in the source-external caller:

1. **The exact caller is not reusable.** Its record directory is hardcoded into the now-frozen repair evidence root. The audit-owned reconstruction proved the underlying caller logic can still run when only that destination is changed, but reconstructed bytes cannot substitute for the exact audited caller identity.

2. **The advertised depth bound is off by one for files.** The implementation checks directory descent but not every entry’s relative depth. A regular file at depth 13 therefore passed despite the declared maximum of 12.

Neither finding requires another repository edit. The repository remains frozen at manifest `4a3a4244…18537`, the restored 477-object baseline remains intact, and the existing caller-repair root must remain immutable. The repository implementation itself still changes only `test_verify_v1.py`; its other twelve paths remain byte-identical.  The restoration independently established the exact 477-object baseline and reproduced the canonical manifest twice. 

### Frozen decisions for the repair

The two findings should be repaired in **one new source-external caller successor**:

- Keep verifier launch protocol `execution-substrate.evidence-closure-launch/v2`.
- Keep caller record schema `execution-substrate.evidence-closure-launch-record.v3`.
- Keep all 25 record fields and their meanings.
- Keep the existing caller CLI shape. The audit shows that a caller-provided record destination already exists; generalize its validation rather than adding or renaming arguments.
- Make the existing record destination genuinely external and reusable, using a held directory descriptor and exclusive descriptor-relative output creation.
- Define depth uniformly for every entry: root depth `0`; an entry’s depth is the number of relative path components; every file and directory with depth greater than `12` rejects before opening or reading it.
- Preserve the old caller, the first snapshot-repair root, and the blocking audit unchanged.
- Do not use an audit-owned modified reconstruction for compatibility qualification. All acceptance-bearing compatibility runs must use the exact final successor source.

The project workflow requires a separate writer repair after an audit `BLOCK`, fresh validation and provenance for the changed bytes, and then a new read-only audit. 

## Codex prompt — caller reusability and depth repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Embed the complete implementation report inline in Markdown.

Evidence links may be supplemental, but must not replace the inline report.

Return exactly one:

EVIDENCE_VERIFICATION_V1_CALLER_REUSABILITY_AND_DEPTH_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
EVIDENCE_VERIFICATION_V1_CALLER_REUSABILITY_AND_DEPTH_REPAIR_BLOCKED
EVIDENCE_VERIFICATION_V1_CALLER_REUSABILITY_AND_DEPTH_REPAIR_BASELINE_MISMATCH
EVIDENCE_VERIFICATION_V1_CALLER_REUSABILITY_AND_DEPTH_REPAIR_SCOPE_EXPANSION_REQUIRED

FRESH SOLE-WRITER TASK

This must be a fresh Codex conversation.

Do not resume:

- the caller-snapshot implementation conversation;
- the independent caller-snapshot audit;
- any repository implementation or audit conversation;
- the artifact-restoration conversation.

Do not create subagents. This is a localized source-external repair.

Objective

Repair the two findings from the independent caller-snapshot audit:

1. The exact repaired caller hardcodes its record directory inside the frozen
   snapshot-repair evidence root and therefore cannot write later A6 evidence
   without changing its bytes or mutating that frozen root.
2. The configured snapshot depth limit of 12 is applied to child directories
   but not uniformly to regular-file entries; a regular file at relative entry
   depth 13 is accepted.

Produce one exact successor caller that:

- retains the existing CLI shape;
- accepts a fresh caller-supplied record destination satisfying a closed,
  descriptor-bound destination contract;
- is reusable without modification for later A6 evidence;
- enforces depth 12 uniformly for all entries;
- preserves launch protocol v2, record schema v3, all record fields and
  meanings, verifier behavior, registry/layout behavior, trusted-host
  nonclaims, and all unrelated caller semantics.

Do not modify the Evidence Verification repository or any existing evidence.

No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, live-service invocation, network contact, or Linux binary
execution.

No independent audit in this task.

## 1. Exact frozen inputs

Repository, read-only:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Expected repository manifest:

REPO_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/alternate-authority-id-repair-0d7180be1a6f/provenance/manifest-run-1.json

Expected repository-manifest SHA-256:

4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537

Expected tracked binary-diff SHA-256:

b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb

Expected restored repository inventory:

RESTORED_INVENTORY=/Users/ds/Downloads/ES-evidence-verification-v1-audit-artifact-restoration-4a3a42441632/restoration/full-object-after.json

Expected governed repository objects:

477

Frozen predecessor snapshot-repair root:

PREDECESSOR_REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-repair-4a3a42441632-v1

Predecessor repaired caller:

PREDECESSOR_CALLER=$PREDECESSOR_REPAIR_ROOT/source/launch_v3_trusted_host_descriptor_snapshot.py

Expected predecessor caller:

- size: 28540
- SHA-256:
  c030f2baf20065b34460720dbd7fde3eaa77e372771cc789e8a805a0378e38c1

Predecessor repair manifests:

PREDECESSOR_MANIFEST_1=$PREDECESSOR_REPAIR_ROOT/provenance/repair-manifest-run-3.json
PREDECESSOR_MANIFEST_2=$PREDECESSOR_REPAIR_ROOT/provenance/repair-manifest-run-4.json

Expected SHA-256 for each:

dfee24304dfe57c9e45c1df997bc78ca1a3c61c4f878d3b928e094e199ebb36d

Blocking independent audit, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-snapshot-independent-audit-dfee24304dfe-v1

Exact relevant audit records:

$BLOCKING_AUDIT/records/exact-caller-destination-rejection.json
$BLOCKING_AUDIT/causals/depth12-leaf.json
$BLOCKING_AUDIT/causals/independent-matrix-v2.json
$BLOCKING_AUDIT/closeout/closing-checks.json

Original vulnerable caller, read-only:

ORIGINAL_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/commands/launch_v3_trusted_host.py

Expected original-caller SHA-256:

002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104

Unchanged verifier:

VERIFY=$IMPL_R/tools/evidence_verify/verify_v1.py

Expected verifier identity:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Original sealed A6D:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned Python:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4
- regular, single-link
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

New repair root, required absent before creation:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-caller-reusability-depth-repair-c030f2baf200-v1

## 2. Classification and authority

This is a source-external validation-evidence successor repair.

Current boundaries remain:

- The repository verifier is an ES-owned Bounded slice rule.
- Verifier output has structural-evidence authority only.
- The caller and caller records are validation/provenance evidence only.
- Neither caller nor verifier owns product, runtime, admission, orchestration,
  readiness, durable-state, commit, publication, or deployment authority.
- Supported-local trusted-host assumptions and all existing nonclaims remain.
- Atomic interpreter custody is not claimed.

This repair changes:

- source-external caller bytes;
- source-external caller tests and evidence;
- caller output-destination enforcement;
- snapshot depth enforcement.

This repair does not change:

- repository bytes;
- verifier bytes or behavior;
- registry or layouts;
- launch protocol v2;
- caller record schema v3;
- record field names or meanings;
- caller CLI names, ordering, or defaults;
- source-by-value launch;
- trusted-host contract;
- product/public/runtime contracts;
- authority allocation.

If either repair requires changing the caller CLI, launch protocol, record
schema, verifier, registry, layouts, repository docs/tests, or a record-field
meaning, stop with:

EVIDENCE_VERIFICATION_V1_CALLER_REUSABILITY_AND_DEPTH_REPAIR_SCOPE_EXPANSION_REQUIRED

Do not silently widen scope.

## 3. Permitted writes

Write only beneath REPAIR_ROOT, except for private transient fixtures and
record-output roots created solely for validation and removed before closeout.

Do not modify:

- IMPL_R;
- PREDECESSOR_REPAIR_ROOT;
- BLOCKING_AUDIT;
- ORIGINAL_CALLER;
- A6D;
- A6D_AMEND;
- any prior implementation, repair, audit, or restoration root.

Create REPAIR_ROOT directories at mode 0700 and retained files as regular,
single-link mode 0600 using exclusive creation.

Suggested retained structure:

REPAIR_ROOT/
  opening/
  source/
  tests/
  causals/
  validation/
  validation/records/
  provenance/
  closeout/
  tmp/

The final `tmp/` must be empty.

Retain an exact immutable copy of PREDECESSOR_CALLER and derive the successor
from its exact bytes.

## 4. Repair A — reusable bounded record destination

Use the caller’s existing record-path CLI argument exactly as it currently
exists. Do not rename, add, remove, or reorder caller arguments.

Remove the requirement that a record path’s parent equal the predecessor
repair root’s fixed records directory.

Replace it with one generic closed destination contract.

### 4.1 Destination path

Require:

1. The supplied record path is absolute.
2. Its basename satisfies the caller’s existing safe-name grammar; if the
   existing source has no explicit grammar, freeze a narrow portable ASCII
   basename grammar and report it.
3. The parent already exists.
4. Every parent-path component is opened from `/` without following symlinks.
5. The parent is a direct physical directory, owned by the effective caller
   UID, mode exactly 0700, and neither group- nor world-accessible.
6. The held parent-directory identity remains stable through all output
   creation and closeout.
7. The record path and all currently derived sidecar paths are absent before
   creation.
8. No output path is a symlink, hardlink alias, directory, or special file.
9. The destination is disjoint in both ancestry directions from:
   - target;
   - verifier package;
   - pre-seal candidate when present;
   - private TMPDIR;
   - pinned interpreter installation.
10. Existing source/package/target/candidate boundary checks remain unchanged.

Do not require the destination to be beneath this repair root.

The exact final caller must be capable of writing records into a fresh,
audit-owned directory selected by a later A6 producer or auditor.

### 4.2 Output creation

Hold the parent directory descriptor.

Create the existing JSON/stdout/stderr outputs descriptor-relatively using:

- `O_CREAT | O_EXCL | O_WRONLY | O_NOFOLLOW | O_CLOEXEC`;
- creation mode 0600;
- immediate `fchmod(0600)`;
- complete writes;
- `fsync`;
- close;
- descriptor-relative no-follow reobservation.

Preserve the existing output naming, write ordering, content, schema, and
field meanings unless the source proves a change is unavoidable. Report the
exact preserved ordering.

Do not overwrite or reuse an existing output.

On uncertain parent identity, replacement, unsupported descriptor operation,
partial write, close uncertainty, existing output, unsafe basename, unsafe
mode/owner, or boundary conflict, reject before an accepted result can be
reported.

Do not add the absolute output path to shared stdout or to fields that
previously carried only a basename.

### 4.3 Reusability causals

At minimum prove:

- the predecessor exact caller rejects a fresh external record destination for
  the retained fixed-parent reason;
- the successor exact caller accepts two distinct fresh external destination
  directories without changing its own bytes;
- the successor writes no record into PREDECESSOR_REPAIR_ROOT or REPAIR_ROOT
  during the external-destination causals;
- an existing JSON path rejects;
- an existing stdout sidecar rejects;
- an existing stderr sidecar rejects;
- a final-path symlink rejects;
- a parent symlink rejects;
- a parent with mode other than 0700 rejects;
- an unsafe basename rejects;
- a relative path rejects;
- a destination within target rejects;
- a destination within package rejects;
- a destination within candidate rejects;
- a destination within TMPDIR rejects;
- a deterministic parent replacement before output creation rejects;
- a deterministic parent replacement during output creation rejects;
- retrying the same record path does not overwrite or duplicate evidence.

All deterministic race hooks must be inaccessible through normal CLI,
environment, target, verifier, registry, layout, or record input. Normal
`main()` must reject a non-null internal hook.

Preserve the existing meaning of every caller-record field. Do not repurpose a
caller-evidence, package, target, candidate, or TMPDIR field to mean the record
destination.

## 5. Repair B — uniform depth enforcement

Freeze the depth contract as follows:

- watched root depth: 0;
- an entry’s depth: the number of components in its path relative to the
  watched root;
- maximum admitted entry depth: 12;
- the depth check applies uniformly to every directory and regular file;
- any entry at depth greater than 12 rejects before it is opened, descended
  into, or read.

Preserve `MAX_DEPTH = 12`; do not relabel the bound.

Require explicit boundary causals:

- root-only tree accepted;
- file at depth 1 accepted;
- directory at depth 12 accepted when it has no child;
- regular file at depth 12 accepted;
- directory at depth 13 rejected;
- regular file at depth 13 rejected;
- child of an admitted depth-12 directory rejected at depth 13;
- the blocking audit’s exact depth-13-leaf shape is reproduced as accepted by
  PREDECESSOR_CALLER and rejected by the successor;
- path-byte and depth failures remain distinct;
- the depth check occurs before file open/read and before directory descent.

Preserve the existing snapshot error taxonomy. The regular-file depth failure
must use the same limit classification as the existing over-depth-directory
failure. If that cannot be done without changing record-field meaning or error
taxonomy, stop for scope expansion.

## 6. Unchanged descriptor-snapshot requirements

Retain and regress all predecessor snapshot guarantees:

- absolute physical root;
- no-follow root-component traversal;
- held root descriptor;
- descriptor-relative entry listing;
- deterministic encoded-byte name ordering;
- descriptor-relative no-follow observations and opens;
- bytes hashed only from held descriptors;
- pre-open, descriptor, post-read, and pathname reobservation binding;
- actual byte-count verification;
- entry rechecks;
- directory relisting and identity rechecks;
- closing root rebind;
- symlink, special-file, hardlink, replacement, disappearance, metadata,
  capability, and race rejection;
- no pathname payload-read fallback;
- no watched-root write;
- no payload retention or path disclosure.

Retain the existing limits except for correcting the uniform application of
depth 12:

- 12000 files;
- 2048 directories including root;
- depth 12;
- 1024 encoded relative-path bytes;
- 4096 absolute-root bytes;
- 268435456 bytes per file;
- 4294967296 aggregate bytes.

## 7. Validation matrix

### 7.1 Predecessor expected negatives

Using exact immutable PREDECESSOR_CALLER bytes, reproduce:

1. Fixed-parent record-destination rejection.
2. Depth-13 regular-file acceptance.
3. The already retained pathname metadata/bytes split, or bind and reverify the
   exact retained predecessor causal if rerunning it adds no value.

State the precise limit of each causal.

### 7.2 Successor snapshot causals

Rerun every case from the predecessor repaired matrix, plus the new depth
boundaries. Require no regression in the previously passing 31 independent
cases.

### 7.3 Destination causals

Run all destination cases in §4.3 using the exact successor source.

### 7.4 Record/schema checks

Require:

- schema remains `execution-substrate.evidence-closure-launch-record.v3`;
- launch protocol remains
  `execution-substrate.evidence-closure-launch/v2`;
- exactly the predecessor 25 top-level fields;
- unchanged meanings;
- no absolute watched-root or record path;
- no payload or source text;
- mandatory trusted-host nonclaims unchanged;
- snapshot and destination errors cannot be erased by later verifier success;
- `outcome="accepted"` requires all snapshot, destination, verifier-result, and
  provenance gates.

## 8. Exact-successor compatibility validation

Acceptance-bearing compatibility must execute the exact successor source
without patching, copying-and-editing, replacing constants, or reconstructing
its logic.

Use fresh external record directories satisfying the new destination contract.

### A6D

Run sealed twice.

Require:

- exact successor source;
- caller accepted;
- verifier exit 0;
- empty verifier stderr;
- canonical verifier stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- deterministic non-snapshot fields within the pair;
- descriptor-bound target/package/TMPDIR/caller-evidence snapshots equal;
- destination files created exclusively at 0600;
- A6D manifest unchanged;
- mandatory nonclaims present.

### Amendment

Run sealed twice.

Require canonical verifier stdout SHA-256:

be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Require the same caller, record, snapshot, manifest, and nonclaim conditions.

### Synthetic A6

Create only an audit-owned fixture.

Run pre-seal twice, seal only that fixture, then run sealed twice with exact
successor bytes and fresh external record directories.

Require deterministic output per stage and only the expected writer-owned seal
transition.

### SEC-02

Run a target-marker causal using exact successor source.

Require source-by-value execution never loads the target script, the marker
remains absent, and direct-script predecessor shape remains nonqualifying.

Do not claim atomic interpreter custody.

### Caller negatives

Freshly exercise:

- wrong interpreter hash;
- wrong interpreter size;
- source mismatch;
- registry-result mismatch;
- layout-result mismatch;
- package/target containment;
- snapshot uncertainty;
- snapshot replacement;
- unsupported snapshot capability;
- invalid record destination;
- record-parent replacement;
- regular-file depth 13.

Require exact existing error classes, plus the existing destination/depth
classes discovered from source. Do not add an error class unless strictly
necessary; stop for scope expansion if a record-schema meaning would change.

## 9. Repository and supplied-input invariance

At opening and closing require:

- repository manifest:
  `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`;
- tracked diff:
  `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`;
- exact restored 477-object inventory;
- no repository cache, bytecode, test cache, generated artifact, or ignored
  path;
- zero staged, deleted, renamed, or unmerged paths;
- PREDECESSOR_REPAIR_ROOT unchanged;
- BLOCKING_AUDIT unchanged;
- A6D and amendment manifests unchanged;
- ORIGINAL_CALLER unchanged.

Do not run or modify the repository’s 89-test suite. Repository bytes are not
part of this repair.

## 10. New source-external repair provenance

Retain beneath REPAIR_ROOT:

- exact predecessor caller identity and inert copy;
- exact successor caller source;
- exact test sources;
- fixed-parent predecessor causal;
- predecessor depth-13 causal;
- successor destination matrix;
- successor snapshot/depth matrix;
- schema comparison;
- all exact-successor compatibility records and sidecars;
- caller-negative results;
- opening and closing repository inventories/manifests;
- opening and closing supplied-root inventories;
- failed and superseded attempt index;
- cleanup and survivor record;
- implementation report.

Generate a canonical repair manifest twice and require byte-identical output.

The manifest must cover every retained regular file except its exact,
explicitly named self-excluded output files. Independently verify:

- exact path set;
- regular type;
- mode;
- link count;
- size;
- SHA-256;
- directory path and mode set;
- no unexplained exclusion;
- empty `tmp/`.

Report:

- successor caller path, size, and SHA-256;
- predecessor caller SHA-256;
- test-source paths, sizes, and SHA-256 values;
- canonical repair-manifest SHA-256;
- regular-file count;
- directory count;
- exact excluded manifest paths;
- launch-protocol and record-schema disposition;
- exact record-destination contract;
- exact depth semantics;
- compatibility outcomes;
- remaining nonclaims.

## 11. Stop conditions

Stop without widening if:

- any frozen repository or supplied evidence identity differs;
- REPAIR_ROOT already exists;
- the existing CLI shape cannot support a reusable external destination;
- a new CLI argument is required;
- record schema or field meaning must change;
- launch protocol must change;
- verifier, registry, layout, repository docs, or repository tests must change;
- destination safety requires a pathname payload-write fallback;
- record output cannot be descriptor-relative and exclusive;
- depth semantics cannot be fixed without changing the bound or taxonomy;
- exact successor compatibility requires source patching or constant
  replacement;
- an authority, product, runtime, readiness, or publication claim widens;
- retained evidence cannot close at 0600/0700 with empty tmp and no survivors.

## 12. Required inline report

Include:

1. Verdict.
2. Exact opening repository and predecessor identities.
3. Repair classification and non-goals.
4. Exact successor caller identity.
5. Exact source delta from predecessor.
6. Existing CLI-shape confirmation.
7. Record-destination contract.
8. Descriptor-relative output algorithm.
9. Record-destination causals.
10. Uniform depth semantics.
11. Depth-boundary causals.
12. Complete snapshot-regression matrix.
13. Test-hook reachability adjudication.
14. Launch-protocol and record-schema disposition.
15. A6D results.
16. Amendment results.
17. Synthetic A6 results.
18. SEC-02 result.
19. Caller-negative results.
20. Repository and supplied-input invariance.
21. Evidence inventory and cleanup.
22. Canonical repair-manifest identity and exclusions.
23. Authority/security/protocol widening: none, or exact stop.
24. Remaining uncertainty and nonclaims.
25. Explicit confirmations:
    - repository mutation not performed;
    - existing evidence mutation not performed;
    - repair confined to REPAIR_ROOT;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 restart not performed;
    - product/live services not invoked;
    - network contact not performed;
    - independent audit not performed;
    - subagents created: 0.

Do not perform the independent audit in this task.
Do not stage, commit, push, or restart A6.
```

After Codex returns `…READY_FOR_FRESH_AUDIT`, the next audit should be confined to the new exact caller, its destination/depth behavior, and source-external evidence closure. It should verify repository provenance but should not reopen the repository’s authority-family repair.

### Sources

- Codex’s audit response above: fixed destination and file-entry depth are the two blocking caller defects.
- The repository is restored to the exact 477-object baseline, with the canonical manifest and tracked diff unchanged. 
- The repository repair changed only `test_verify_v1.py`; all other patch paths remained byte-identical. 
- Audit findings require a separate writer repair, new provenance, and a fresh audit; prior audit acceptance does not survive byte changes. 
- Provenance binds exact bytes but remains evidence rather than correctness or authority. 

**Confidence**

- Fixed record destination is a real reusability defect: **0.995**
- Regular-file depth 13 is a direct contract violation: **0.999**
- Both defects are confined to source-external caller bytes: **0.99**
- Launch protocol v2 and record schema v3 can remain unchanged: **0.93**
- The prompt above is the narrowest safe next tranche: **0.98**
