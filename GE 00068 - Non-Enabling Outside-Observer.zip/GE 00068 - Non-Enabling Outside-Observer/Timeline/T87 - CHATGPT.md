Codex’s A6O result is coherent and **implementation-ready**. The critical model is now correct:

```text
historical source identity
        +
closed validation-harness overlay
        =
effective validation source identity
```

The overlay does not replace `source_class`, masquerade as an intentional mutant, or become historical/product truth. That preserves the project’s explicit boundary that proof-harness behavior and generated evidence remain bounded scaffolding rather than architecture or authority. 

No further design turn is needed. The next tranche is a **successor-only, parent-written amendment from sealed A5C**, followed by an entirely new A6 refresh. The existing failed A6 child remains immutable negative evidence and must not be resumed.

## Codex prompt: implement the historical-overlay successor amendment

```text
Permission is workspace-write for one new source-external successor/evidence
child only.

Objective

Implement, validate, close out, and seal the Repair 10I-A6O historical
validation-overlay successor amendment frozen by the sealed A6O
reconnaissance.

The amendment must let one exact historical source class retain its
authoritative base identity while independently binding one exact,
validation-only source overlay and one separate effective execution identity.

The only admitted overlay is:

overlay_id =
  repair10i-historical-repair9-a5t4-validation-harness-overlay-v1

allowed source_class =
  historical-repair9

base:
  T =
    0ea3b661f09e73e1126bae0f6e993e22bbf21198
  inventory =
    7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
  members =
    382

effective:
  T =
    4bd05d4f949e6239ff7aaeb68ac229143ddeff6e
  inventory =
    e17a7732e260a8af7305d5e130bbbc2cc9608175390c2d763f8c655471ea6583
  members =
    382

The overlay is validation scaffolding only. It is not:

- Repair 9 product source;
- historical product behavior;
- an intentional mutant;
- a product or public schema;
- a migration mechanism;
- a general source-transformation framework;
- acceptance authority;
- evidence of a product improvement.

This is a parent-only implementation turn.

Do not modify repository source.
Do not modify sealed A5C.
Do not modify sealed A5T4.
Do not modify sealed A6O reconnaissance.
Do not resume, modify, overwrite, or seal the failed A6 child.
Do not restart the five-control A6 evidence refresh in this turn.
Do not implement the historical directional-comparator policy.
Do not start B6.
Do not run product A/B preparation.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Repository, read-only throughout

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5C successor baseline

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A5T4 repository lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5FD harness analysis

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5fd-devfd-recon-ab646e5a0e66

Sealed A6O reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-historical-overlay-recon-8de797304ea9

Failed and unsealed A6 attempt

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5c-8de797304ea9

Required new successor child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the exact three-file A5T4 repository delta recorded by sealed A5T4,
with every other repository tuple byte- and mode-identical.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Require exact sealed A5C:

- manifest SHA-256:
  05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489
- manifest size:
  31421
- payloads:
  216
- directories:
  71
- source T:
  2c2d0b36f52d5949d023a36400f0e0748149875a
- source inventory:
  810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9
- source members:
  12

Recover and verify every A5C A/B binary size and SHA-256 from the sealed A5C
report and manifest.

Require:

- A/B byte equality;
- inode-distinct copies;
- complete post-seal verification;
- all seven A5C tests;
- A5P2 PTY and policy nonregression;
- active observability rule:
  observability-inbound-request-complete-v2;
- current complete A5C v3/v2/v1 active schema dialect.

Require exact sealed A6O:

- manifest SHA-256:
  20852734748924f75194239767a9d47c102e4767a529dadbbb5e3c4c48461138
- manifest size:
  4031
- payloads:
  28
- payload directories:
  6 plus root

Reverify completely:

- closeout/final-report-v1.md
- source/repair9-a5t4-validation-harness-overlay-recipe-v1.json
- schemas/validation-harness-overlay-provenance-schema-v1.json
- schemas/validation-harness-overlay-provenance-exemplar-v1.json
- schemas/successor-active-schema-dialect-v1.json
- source/a5c-producer-consumer-map-v1.json
- tests/mandatory-causal-test-matrix-v1.json
- tests/future-validation-and-a6-restart-plan-v1.json
- tests/future-implementation-stop-conditions-v1.json

Require exact Repair 9 overlay facts:

Base file:

remote_alpha_prepare_external_tls_status_test.go

- logical mode:
  100644
- size:
  178894
- SHA-256:
  29f5c2ef23d1f26424d94cea0737401874a2c19f354e35b4acbc28279518e066

Effective file:

- logical mode:
  100644
- size:
  181912
- SHA-256:
  39c24dfe9d1238981edf0e650fcf04b04bec94b5b7f412366769b4b79ee8d362

Require the complete exact overlay recipe from sealed A6O, including:

- source cardinalities:
  2,1,1,1,1,1
- base offsets:
  19790,20717,21577,52232,89680,107000,177318
- one LF;
- exact 2762-byte helper;
- embedded derivative match count:
  1
- embedded derivative match offset:
  337
- preserved line count:
  1069
- exact loop-body equality;
- exact nonmatched-byte equality;
- reversibility;
- shell-equivalence lineage;
- production-wrapper equality;
- test-declaration-universe equality.

Do not reconstruct the recipe approximately.

Require the failed A6 child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- exact snapshot:
  9dd87f6830f20491929e74dfa0e65820de209868a9be775e33679ebfd8ae226f

Reverify:

- closeout/final-report-v1.md
- findings/historical-control-construction-required-v1.json
- sources/historical-repair9-validation-harness-overlay-provenance-v1.json
- both independent A5C rejection probes;
- cleanup and two absence epochs.

Require the new successor child to be absent.

Stop on any mismatch:

REPAIR10I_A6O_IMPLEMENTATION_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create the new successor child exclusively under
umask 077.

Use exactly:

opening/
tool/
controls/
commands/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, with intended mode 0600 or 0700.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy all 12 A5C successor source members independently into:

tool/source/

Require:

- no hardlinks;
- opening bytes and logical modes equal A5C;
- complete source inventory and pure T;
- every unchanged source member reverified at closeout.

Do not copy source from any failed or unsealed successor child.

## 3. Exact authorized successor scope

Modify exactly these four copied A5C source files:

1.
tool/source/FORMAT.md

2.
tool/source/envelope/runner.go

3.
tool/source/envelope/semantic.go

4.
tool/source/envelope/envelope_test.go

The other eight source members must remain byte- and mode-identical to A5C:

- tool/source/envelope/source.go
- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-fixture/main.go
- tool/source/envelope/testdata/evidence-manifest-v1.golden
- tool/source/envelope/testdata/source-inventory-v1.golden
- tool/source/go.mod

No thirteenth member.
No new dependency.
No golden-file edit.
No CLI edit.
No repository edit.

If a fifth source file is required, stop:

REPAIR10I_A6O_SCOPE_EXPANSION_REQUIRED

## 4. Frozen source model

Implement Model D exactly.

Source class and validation overlay are independent dimensions.

A valid overlaid control retains:

```text
source_class = historical-repair9

base:
  T
  inventory
  membership

validation_harness_overlay:
  exact closed provenance record

effective:
  T
  inventory
  membership
```

Historical HEAD remains:

```text
source_class = historical-head
validation_harness_overlay = absent
base == effective
```

Final and fresh final remain:

```text
source_class = pristine-final
validation_harness_overlay = absent
base == effective
```

Intentional mutant remains:

```text
source_class = intentional-mutant
intentional_mutant_provenance = present
validation_harness_overlay = absent
base != effective
```

Reject:

- `source_class=validation-harness-overlay`;
- overlay encoded as intentional-mutant provenance;
- silent source patching;
- overlay plus intentional-mutant provenance;
- overlay on any source class except historical-repair9;
- effective-only source evidence without independently proven base identity.

## 5. Overlay authority and closed admission

The only admitted overlay is:

overlay_id =
  repair10i-historical-repair9-a5t4-validation-harness-overlay-v1

The overlay is admitted only when every one of the following matches exactly:

- source class:
  historical-repair9
- base T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- base inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
- base membership:
  382
- changed-path count:
  1
- exact path:
  remote_alpha_prepare_external_tls_status_test.go
- logical mode:
  100644 before and after
- exact before size/hash;
- exact after size/hash;
- exact sealed recipe ID;
- exact recipe-source SHA-256;
- exact source cardinalities and offsets;
- exact helper bytes;
- exact embedded derivative;
- exact match count and offset;
- exact line/loop/nonmatched behavior;
- exact reversibility and shell-equivalence evidence;
- unchanged test-declaration universe;
- unchanged production paths and bytes;
- exact effective T:
  4bd05d4f949e6239ff7aaeb68ac229143ddeff6e
- exact effective inventory:
  e17a7732e260a8af7305d5e130bbbc2cc9608175390c2d763f8c655471ea6583
- effective membership:
  382.

Reject any:

- alternate source class;
- alternate base identity;
- alternate path;
- alternate recipe;
- caller-supplied recipe;
- additional changed path;
- addition, deletion, rename, or mode change;
- different effective identity.

Do not implement a general transformation engine.

## 6. Overlay provenance schema

Implement exactly:

execution-substrate.repair10i.validation-harness-overlay-provenance.v1

Use the exact closed schema from sealed A6O.

It must bind at least:

- schema;
- overlay ID;
- classification;
- purpose;
- allowed source class;
- base T/inventory/membership;
- effective T/inventory/membership;
- changed-path count;
- exact path;
- logical modes;
- sizes and hashes;
- recipe ID;
- recipe-source SHA-256;
- recoverable recipe-source lineage reference;
- match count and byte offset;
- before/after block hashes;
- line counts;
- loop-body hashes;
- nonmatched-byte equality;
- reversibility;
- shell-equivalence evidence reference and digest;
- test-declaration-universe equality;
- production-byte equality;
- creation sequence;
- frozen-before-execution;
- outcome;
- ordered errors.

Do not omit inapplicable fields. Use explicit closed null/zero semantics from
the sealed A6O schema.

Do not retain arbitrary full source bytes in the record when the sealed
recipe and bounded hashes are sufficient.

## 7. Active schema dialect

Implement exactly the 24-schema active dialect sealed in:

schemas/successor-active-schema-dialect-v1.json

Do not infer or rename schemas from this prompt.

The frozen shape is:

- eight source-binding acceptance records move to v4;
- command intent, command result, and terminal reconciliation remain v3;
- four PTY records remain v2;
- eight existing v1 records remain unchanged;
- the private validation-overlay provenance schema is added.

Before editing:

- reproduce the exact list of all 24 schema IDs;
- reproduce the exact producer/consumer map;
- retain them in opening evidence.

At closeout:

- reproduce the same list;
- require every active producer and consumer to use the exact intended schema;
- reject mixed old/new source-binding records;
- reject old acceptance semantics with a new overlay record;
- reject new source-binding records without complete overlay semantics when an
  overlay is present.

A5C historical schemas remain parseable only through explicit historical
reporting and are always nonqualifying for the new overlay semantics.

Stop if the dialect cannot be implemented completely in the four files:

REPAIR10I_A6O_CONTRACT_INCOMPLETE

## 8. Materialization sequence

For a valid historical Repair 9 control:

1. Create physically distinct, nonaliasing:
   - base-src
   - effective src
2. Materialize exact Repair 9 base bytes in base-src.
3. Verify:
   - source class;
   - path set;
   - modes;
   - membership;
   - inventory;
   - T;
   - no symlinks;
   - no hardlinks;
   - no inode aliases.
4. Create and freeze the exact overlay-provenance record before execution.
5. Independently materialize effective src from base-src.
6. Apply only the compiled fixed overlay recipe.
7. Require exactly one complete match.
8. Recompute effective path set, modes, membership, inventory, and T.
9. Require the exact frozen effective identity.
10. Freeze effective src before command execution.
11. Permit no later source mutation.
12. Retain both roots and all opening identities through qualification.
13. Close and remove them only after all required comparison and qualification
    evidence has been retained.

Do not mutate base-src.

Do not derive effective src through hardlinks or reflinks that alias writable
source state.

## 9. Independent external qualification

Opposite-side qualification must independently prove:

- exact source class;
- exact base identity;
- base path set and modes;
- exact overlay ID;
- overlay record identity and immutability;
- recipe identity and recoverable source;
- exact transformation facts;
- expected effective identity reconstructed from base plus recipe;
- actual executed effective source identity;
- frozen-before-execution posture;
- suite and command binding;
- raw-stream identity and EOF;
- extracted semantic identity;
- terminal reconciliation;
- resource and cleanup disposition;
- no later source mutation.

An effective T/inventory caption is not proof.

A source-tree hash without the base bytes and overlay provenance is
insufficient.

Qualification fails if:

- base source cannot be established;
- recipe cannot be recovered;
- overlay was created after execution;
- provenance was mutable;
- actual effective source differs;
- only producer-authored captions match.

## 10. Comparison and reporting semantics

Comparisons use qualified effective execution output as their factual semantic
input.

Every result involving an overlaid historical control must also retain:

- source class;
- base T/inventory/membership;
- overlay ID;
- overlay-provenance reference and SHA-256;
- overlay qualification outcome;
- effective T/inventory/membership;
- explicit classification:
  historical source under validation-harness overlay;
- explicit nonclaims:
  - effective bytes are not historical product source;
  - overlay is not a product improvement;
  - overlay is not historical runtime behavior.

The overlay may not:

- create or remove test declarations;
- receive credit as a final product improvement;
- authorize a transition blocked by historical policy;
- mask unknown diagnostics;
- alter the future directional transition lattice.

## 11. Mandatory vulnerable-predecessor causal

Before implementing the acceptance path, reproduce with exact A5C source:

- source class:
  historical-repair9;
- exact base identity;
- honest unequal base/effective identity;
- exact overlay provenance supplied through current available fields;
- current A5C rejects before control creation;
- outcome includes the source-grounded reason:
  non-mutant source has inconsistent base/effective identity;
- explicit overlay fields are rejected as unknown.

Retain this as expected-negative evidence.

Do not modify or execute the failed A6 child.

## 12. Mandatory active tests

Implement every one of the 58 cases in the sealed:

tests/mandatory-causal-test-matrix-v1.json

No omission, merging, or approximate substitute.

At minimum, the active tests must cover:

### Valid exact Repair 9 overlay

- exact base accepted;
- exact overlay accepted;
- exact effective identity accepted;
- source class remains historical-repair9;
- overlay classification retained;
- external qualification independently recomputes the complete chain.

### Overlay absence

- historical HEAD accepted with no overlay and base==effective;
- pristine final accepted with no overlay;
- independent pristine final accepted with no overlay;
- intentional mutant accepted only through intentional-mutant provenance.

### Wrong source class

Reject overlay on:

- historical HEAD;
- pristine final;
- independent pristine final;
- intentional mutant;
- test fixture;
- unknown source class.

### Wrong base identity

Reject:

- one-nibble base T mutation;
- one-nibble inventory mutation;
- wrong membership;
- wrong path set;
- wrong logical mode;
- source alias or hardlink.

### Wrong overlay

Reject:

- unknown overlay ID;
- wrong path;
- additional path;
- path removal;
- path addition;
- rename;
- mode change;
- zero matches;
- multiple matches;
- changed helper;
- changed loop body;
- changed nonmatched bytes;
- changed line count;
- changed source cardinality;
- changed offset;
- nonreversible transformation;
- recipe ID mismatch;
- recipe-source mismatch;
- missing recoverable recipe source;
- shell-equivalence evidence mismatch;
- test declaration added or removed;
- production byte changed;
- unexpected effective T;
- unexpected effective inventory.

### Provenance custody

Reject:

- absent provenance;
- provenance created after suite execution;
- mutable provenance;
- producer-caption-only provenance;
- provenance path alias;
- source/provenance inode alias;
- missing recipe lineage;
- late descriptor/close/resource fault.

### Semantic containment

Reject when overlay:

- changes a terminal outside the exact validation correction;
- adds or removes unrelated diagnostics;
- changes test universe;
- masks unknown text;
- changes product-source claims.

### Mixed classes and dialects

Reject:

- intentional-mutant provenance plus overlay;
- old schema with overlay;
- new schema with old source-binding meaning;
- partial v4/v3/v2/v1 mixture;
- v4 record without required overlay fields;
- overlay record used as source class.

## 13. Logical fingerprint and immutable policy

Every behaviorally material overlay field must enter the logical
suite/control fingerprint, including:

- overlay presence;
- overlay ID;
- base identity;
- effective identity;
- recipe ID;
- changed path;
- classification.

Non-overlaid controls must have a distinct explicit absent-overlay
fingerprint posture.

Independently mutate each material field and require fingerprint change or
strict rejection.

Do not key a fingerprint solely by provenance-record SHA-256 without also
structurally validating the record.

## 14. Two disjoint successor controls

Use pinned Go 1.26.5 under umask 077.

Each side independently owns:

- source;
- HOME;
- XDG_CONFIG_HOME;
- XDG_CACHE_HOME;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- build root;
- command output;
- report root;
- overlay materialization roots.

No writable state may be shared.

Verify:

- source copies are no-hardlink;
- source inode sets are disjoint;
- cache and build roots are disjoint;
- overlay base/effective roots do not alias;
- no undeclared Git alternate or shared store exists.

Run on both sides:

gofmt -d over all Go source members

Require empty output.

go test -json -count=3 -p=1 -parallel=1 ./...

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -json -count=3 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*Overlay'

go test -race -json -count=1 -p=1 -parallel=1 ./...

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I'

go test -race -json -count=1 -p=1 -parallel=1 ./envelope \
  -run '^TestRepair10I.*Overlay'

Require:

- zero required skips;
- zero race reports;
- zero malformed streams;
- zero missing or duplicate terminals;
- no survivor;
- no forced cleanup;
- complete resource and terminal disposition.

## 15. Deterministic builds

Build on both sides:

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-runner ./cmd/repair10-runner

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-compare ./cmd/repair10-compare

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-semantic ./cmd/repair10-semantic

CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 \
go build -trimpath -buildvcs=false -ldflags=-buildid= \
  -o <SIDE>/bin/repair10-fixture ./cmd/repair10-fixture

Require every A/B binary pair:

- byte-identical through EOF;
- inode-distinct;
- single-link;
- expected mode;
- built from exact amended source;
- no unexpected absolute build path.

## 16. Bounded overlay integration causals

After both successor hard gates pass, run bounded source-binding causals only.

Do not run a historical repository full suite.

### Repair 9 overlay causal

Independently materialize exact Repair 9 base source.

Require:

- exact base source class/T/inventory/membership;
- exact one-file overlay provenance frozen before the bounded command;
- exact effective identity;
- source immutable during execution;
- opposite-side qualification independently recomputes the chain;
- classification retained:
  historical source under validation-harness overlay;
- no claim that effective bytes are historical product source.

Use the smallest bounded command that proves source materialization, suite
binding, semantic extraction, terminal reconciliation, and cleanup.

Do not substitute a caption-only fixture when an actual bounded source command
can be used safely.

### Historical HEAD no-overlay causal

Independently materialize exact HEAD source.

Require:

- source class historical-head;
- overlay absent;
- base==effective;
- opposite-side qualification passes.

### Final/fresh/mutant nonregression

Use bounded retained or freshly generated source-binding causals to prove:

- pristine final remains overlay-free;
- second pristine final remains overlay-free;
- intentional mutant remains governed exclusively by intentional-mutant
  provenance;
- overlay and intentional-mutant provenance cannot coexist;
- A5C canonicalization behavior is unchanged.

These causals do not replace the future fresh A6 source controls.

## 17. A5C and A5P2 nonregression

Re-run or independently reverify:

- all seven A5C tests;
- observability v2 duration positioning;
- retained-A5 ten socket differences remain material;
- A5T4 raw re-extraction compatibility;
- A5P2 `LOCAL_PEERPID` binding;
- acknowledged openpty and forkpty handoffs;
- parent alias close ordering;
- EOF/hangup evidence;
- direct `/dev/ptmx` denial;
- unrelated-terminal denial;
- late-fault rejection;
- logical command/suite fingerprinting;
- byte-comparison behavior.

No semantic grammar, PTY policy, filesystem capability, or comparison policy
change is authorized beyond the overlay/source-binding contract.

## 18. Security and authority controls

Require:

- repository remains read-only and byte-exact;
- no public/product schema change;
- no product execution-authority change;
- no general overlay framework;
- no caller-provided recipe;
- no generic `/dev/fd` or device grant;
- no `.out` traversal or write;
- no live PackageFloor or fixed-runtime slot access;
- no credential, keychain, TLS, SPIFFE, Vault, endpoint, or unrelated-user
  exposure;
- no raw PTY payload retained;
- overlay remains explicitly non-authoritative validation scaffolding.

## 19. Evidence requirements

Retain:

- complete opening and lineage verification;
- exact A5C source copy and inventory;
- exact four-file source delta;
- complete active-schema dialect;
- producer/consumer map;
- vulnerable A5C rejection;
- exact Repair 9 base/effective/overlay provenance;
- every one of the 58 causals;
- fingerprint mutants;
- A/B test, race, and build evidence;
- bounded Repair 9 overlay qualification;
- HEAD no-overlay qualification;
- final/fresh/mutant nonregression;
- A5C/A5P2 compatibility evidence;
- all failed and superseded attempts;
- closing repository and predecessor verification;
- cleanup and two absence epochs;
- implementation report;
- exact path/mode/size/hash inventory.

Do not retain sensitive raw source content beyond the already sealed bounded
recipe/excerpts.

Do not claim fresh A6 final/fresh equality or historical-policy success.

## 20. Closeout and sealing

Require:

- exactly the four authorized successor source files changed;
- the other eight A5C source members byte- and mode-identical;
- repository remains:
  - T `8de797304ea944b6a155924e0d1e9e8bbe79534e`
  - inventory
    `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
  - membership `389/375/14`
  - staged/deleted/renamed/unmerged `0/0/0/0`;
- branch/HEAD/parent/tree/upstream/index unchanged;
- A5C, A5T4, A5FD, A6O, failed A6, and every predecessor unchanged;
- no predecessor bytecode or cache;
- no private source, base/effective tree, cache, build, process, descriptor,
  socket, report, or temporary root remains;
- two fresh absence epochs pass.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification of:

- membership;
- path set;
- file types;
- modes;
- sizes;
- hashes;
- links;
- directory modes;
- final source T/inventory;
- binary identities;
- repository and predecessor identities;
- absence state.

## 21. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- need for a fifth successor file;
- repository mutation;
- general overlay framework required;
- arbitrary caller recipe required;
- exact Repair 9 recipe unavailable or ambiguous;
- effective identity cannot be reproduced exactly;
- test declaration or production byte changes;
- old schema can qualify new overlay semantics;
- overlay and intentional-mutant semantics cannot remain separate;
- external qualification cannot independently reconstruct base plus recipe;
- any required causal survives;
- A/B test, race, or binary mismatch;
- A5C or A5P2 regression;
- survivor, forced cleanup, or seal failure.

## 22. Verdicts

Opening mismatch:

REPAIR10I_A6O_IMPLEMENTATION_BASELINE_MISMATCH

Contract or dialect incomplete:

REPAIR10I_A6O_CONTRACT_INCOMPLETE

Scope expansion required:

REPAIR10I_A6O_SCOPE_EXPANSION_REQUIRED

Implementation, validation, cleanup, or sealing failure:

REPAIR10I_A6O_SOURCE_OR_TOOL_REPAIR_REQUIRED

Complete success:

REPAIR10I_A6O_HISTORICAL_OVERLAY_SUCCESSOR_PATCH_SEALED_READY_FOR_FRESH_A6_RESTART

The success report must include:

1. A5C and amended successor T/inventory.
2. Exact four-file delta.
3. Exact 24-schema active dialect.
4. Overlay schema and overlay ID.
5. Repair 9 base and effective identities.
6. Exact one-file overlay recipe identity.
7. Confirmation historical HEAD remains overlay-free.
8. Confirmation final/fresh remain overlay-free.
9. Confirmation intentional mutant remains overlay-free and independently
   governed.
10. Vulnerable A5C rejection result.
11. Valid overlay materialization and external qualification result.
12. All 58 causal outcomes.
13. A/B test/race/build results and binary identities.
14. A5C/A5P2 nonregression.
15. Repository no-mutation evidence.
16. Manifest SHA-256, size, and payload count.
17. Cleanup and two absence epochs.
18. Explicit statement that A6 was not restarted, the historical comparator
    was not implemented, product A/B was not run, and no snapshot or audit
    occurred.

No A6 restart.
No historical-comparator implementation.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After the overlay amendment seals

Start an entirely new A6 evidence-refresh child and rerun all five source controls from the beginning. The old failed A6 child cannot be resumed or promoted. The project’s workflow explicitly separates implementation from independent audit and requires new validation and provenance after changed bytes.  

The eventual A6 refresh must still decide the historical directional policy from fresh qualified evidence; the overlay amendment must not pre-decide that policy.

### Sources

- Codex’s sealed `REPAIR10I_A6O_RECONNAISSANCE_READY` report supplied in this turn.
- Milestone 0 proof-harness and evidence-authority boundary. 
- Governed Execution parent-only implementation and fresh-audit separation. 
- Governed Execution repair and re-audit protocol. 
- Provenance establishes byte identity, not correctness or authority. 

**Confidence:** 0.995 that the A6O contract is ready for implementation; 0.98 that the source-class/overlay separation is the correct durable model; 0.96 that the four-file successor scope is sufficient; 0.99 that the old A6 child must remain unsealed negative evidence; 0.995 that the complete A6 refresh must restart after this successor amendment seals.
