## Engineering assessment

The operating model is finally closed at the right abstraction level. The new additive package is terminally sealed and ready to govern a **new clean harness implementation generation**.

The key result is not merely that the stale matrix path was documented. The package now freezes a complete, typed authority model for every acceptance-bearing embedded dependency:

```text
semantic role
→ typed descriptor
→ current member role
→ exact member path and identity
→ record-class parser
→ record-specific validator
→ authorized consumers
```

It derives **113 required embedded JSON dependencies** and closes the same 113-item set across the source-derived dependency set, descriptor registry, member-role registry, actual required PYZ members, direct documentary tests, and independent documentary tests. :chatgpt-content-reference{index="0"}

### What is now decided

The successor freezes exactly two record classes:

- `SCHEMA_DISCRIMINATED_JSON`: 108 records;
- `SCHEMA_VERSION_DISCRIMINATED_JSON`: 5 records.

The bootstrap record is correctly classified by `/schema_version = 1`; it is no longer subjected to an invented `schema` requirement. The governed runtime-matrix record remains `SCHEMA_DISCRIMINATED_JSON` with `/schema = governed-runtime-matrix-suite-v2`. :chatgpt-content-reference{index="1"}

The historical stale path is definitively noncurrent:

```text
qualification/runtime-matrix-suite-v2.json
```

The current matrix-evidence member remains:

```text
qualification/runtime-matrix-v2.json
```

Future consumers must request semantic roles. Direct path literals are retained only as historical evidence, and no compatibility alias or lookup fallback is permitted. :chatgpt-content-reference{index="2"}

The contract’s validation strength is sufficient to proceed:

- 171 uniquely named descriptor cases passed with no classification error;
- an independently authored validator covered all 113 dependencies plus 30 negative cases with zero errors;
- six perspectives reconciled with no disagreement or hidden implementation decision;
- the additive successor registry closed at 18 unique roles. :chatgpt-content-reference{index="3"}

The package also terminally closed: supplied inputs remained equal, the manifests are byte-identical, final reprojection passed, the root appears once, topology and modes are clean, and no filesystem or tool operation followed the sole seal transition. :chatgpt-content-reference{index="4"}

### Progression decision

Proceed directly to a **new clean harness implementation generation**.

This is not Attempt 4 of the retired generation. It receives a fresh three-attempt source budget.

The new generation must be governed by:

1. the five-domain documentary package;
2. the interpreter-observation-tuple package;
3. the embedded-dependency-descriptor package;
4. the current content snapshot;
5. the current content authority.

It must not copy or patch retired harness source.

One additional implementation safeguard is important: the new package will regenerate generation-specific evidence such as source freeze, qualification, rehearsals, and package status. Therefore, before source creation, Codex must classify all 113 predecessor dependency roles by disposition:

- `COPY_EXACT_GOVERNING_ARTIFACT`;
- `REGENERATE_CURRENT_GENERATION_EVIDENCE`;
- `HISTORICAL_REGRESSION_ONLY`.

The semantic role, exact path contract, and record class remain governed. A regenerated current record gets a new identity and must supersede—not impersonate—the predecessor evidence. Unknown or conflicting disposition must block before source creation.

---

## Complete replacement Codex prompt

```text
IMPLEMENT, QUALIFY, FREEZE, AND PACKAGE A NEW CLEAN
GENERATION-2 SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS

GOVERNED BY THE FIVE-DOMAIN, INTERPRETER-TUPLE, AND
EMBEDDED-DEPENDENCY-DESCRIPTOR DOCUMENTARY PACKAGES

Objective

Implement a new clean-room source-external independent-audit harness using only
these current governing authorities:

1. the sealed five-domain documentary package;
2. the sealed interpreter-observation-tuple additive package;
3. the sealed embedded-dependency-descriptor additive package;
4. the current-authority content snapshot ZIP;
5. the current content-snapshot authority JSON.

The new harness must:

- implement the exact five-domain runtime governance;
- implement the exact three-role interpreter-observation tuple;
- implement the exact typed embedded-dependency authority model;
- resolve every acceptance-bearing embedded record by semantic role;
- parse and validate records under their exact record class;
- implement a complete authoritative run-full-audit capsule;
- qualify every current runtime and repair surface;
- execute physically distinct packaged-path ACCEPT, BLOCK, and
  AUDIT_PROVENANCE_MISMATCH rehearsals;
- source-freeze;
- build a deterministic executable PYZ;
- create a runtime authority JSON;
- create a source-external launch certificate;
- authorize exactly one later real audit.

Do not execute the real implementation audit in this task.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any governing input.

Do not reopen original contaminated package directories.

Do not copy, patch, import, translate, execute, disassemble into source, or use
as an AST, bytecode, or source origin:

- the retired harness PYZ;
- any retired harness source;
- the retired embedded-record repair source;
- documentary-package tooling source;
- implementation-package source.

Historical evidence may be used only as test and regression input.

Do not perform another historical package-findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned clean implementation and qualification process in
one fresh private root.

This is a new clean implementation generation.

Source-attempt budget:

- maximum complete attempts:
  3;
- consumed:
  0;
- remaining:
  3;
- Attempt 4:
  forbidden.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. GOVERNING INPUT A — FIVE-DOMAIN DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

FIVE_DOMAIN_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifests:

manifest/documentary-manifest-a-v2.json
manifest/documentary-manifest-b-v2.json

Expected manifest identities:

- inodes:
  181887816
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478 each
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Authenticate:

- root identity;
- temporal identity;
- A/B identities and equality;
- terminal-manifest reprojection;
- root row exactly once;
- physical closure;
- topology and modes;
- one seal transition;
- no postseal activity.

Resolve current roles only through:

contract/current-governing-documentary-role-registry-v2.json

Required semantics:

- five documentary domains;
- exact R01–R66 runtime report registry;
- exact 81-name runtime confirmation registry;
- exact B00 and D01–D14 matrix registry;
- exact 15 matrices;
- exact 595 matrix cases;
- stale 645 rejected;
- aggregate owner classifications;
- aggregate owner/consumer rules;
- runtime/task-domain separation;
- package acceptance semantics.

Documentary tooling is not future source.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING INPUT B — INTERPRETER-TUPLE PACKAGE
──────────────────────────────────────────────────────────────────────────────

INTERPRETER_TUPLE_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-f5ys2h7f

Expected root identity:

- device:
  16777234
- inode:
  182148007
- mode:
  0700

Expected temporal record:

manifest/interpreter-observation-temporal-inventory-v1.json

- device:
  16777234
- inode:
  182159647
- mode:
  0600
- link count:
  1
- size:
  11608
- SHA-256:
  181015fc4ef80841995af4005e068b0a348a3d0e8cbb2ef9fac6ef6424af0031

Expected manifests:

manifest/interpreter-observation-manifest-a-v1.json
manifest/interpreter-observation-manifest-b-v1.json

Expected identities:

- inodes:
  182159648
  182159649
- mode:
  0600
- link count:
  1
- size:
  11968 each
- SHA-256:
  cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66

Authenticate terminal closure.

Resolve additive roles only through:

contract/current-launch-runtime-successor-role-registry-v1.json

Required semantics:

- exact three-role interpreter taxonomy;
- exact observation tuple;
- three-view process authority;
- argv/cwd/PID/flag/source crosswalks;
- exact runtime environment policy;
- optional bounded `__CF_USER_TEXT_ENCODING`;
- future parent self-authentication schema;
- no terminal-runtime-image role;
- no kernel executable-image claim.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. GOVERNING INPUT C — EMBEDDED-DEPENDENCY PACKAGE
──────────────────────────────────────────────── LIMITED TO NEW AUTHORITY
────────────────────────────────────────────────

EMBEDDED_DEPENDENCY_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-embedded-dependency-descriptor-contract-aasznw_h

Expected root identity:

- device:
  16777234
- inode:
  182361207
- mode:
  0700

Expected terminal disposition:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

Resolve exact closure paths through the package’s current successor role
registry and terminal manifests.

Expected closure identities:

Temporal inventory:

- size:
  8885;
- SHA-256:
  7e3453d0f8f807bb42452234f5503b68b4eeccb21ba80c57355710b67dfa1b6c.

Manifest A:

- size:
  9156;
- SHA-256:
  1b0fc86532f0b430b77ae256bf617ae0a37963d633fe7467304877775b92c982.

Manifest B:

- size:
  9156;
- SHA-256:
  1b0fc86532f0b430b77ae256bf617ae0a37963d633fe7467304877775b92c982.

Expected terminal reprojection:

- size:
  9909;
- SHA-256:
  0cc6d3f4ea1e70141aada843b1ea76c6a51e550df32aff05c4b6bdb79aff4427.

Authenticate:

- root identity;
- current additive role registry;
- 113-dependency authority model;
- two-record-class taxonomy;
- 113 member-role rows;
- 113 descriptor rows;
- exact set equality;
- 171-case matrix;
- independent validator;
- six-perspective reconciliation;
- package status;
- terminal manifests;
- one root row;
- clean topology and modes;
- one seal transition;
- no postseal operation.

Required semantics:

- `SCHEMA_DISCRIMINATED_JSON`;
- `SCHEMA_VERSION_DISCRIMINATED_JSON`;
- exactly 108 schema-discriminated records;
- exactly 5 schema-version-discriminated records;
- bootstrap-start validated by `schema_version`;
- governed runtime matrix validated by `schema`;
- semantic role owns authority;
- member path is an exact projection of that role;
- no direct acceptance-bearing path literal;
- no compatibility alias;
- no path/basename/suffix/prefix/version/score/recursive/content fallback;
- stale matrix-suite path noncurrent;
- `qualification/runtime-matrix-v2.json` current.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. GOVERNING INPUT D — CURRENT CONTENT SNAPSHOT
──────────────────────────────────────────────── LIMITED TO IMPLEMENTATION EVIDENCE
────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate content authority first.

Require:

- archive identity;
- 479 members;
- eight current roles;
- seven content-snapshot roles;
- one bounded failure-evidence role;
- no `.DS_Store`;
- deterministic archive equality;
- independent validation passed;
- no implementation/package verdict.

The containing directory is nonauthoritative.

──────────────────────────────────────────────────────────────────────────────
5. HISTORICAL DEFECT CATALOGUE
──────────────────────────────────────────────── LIMITED TO REGRESSION INPUT
────────────────────────────────────────────────

Before source creation retain:

analysis/historical-harness-defect-catalogue-v1.json

Include at minimum:

- incomplete audit-capsule lifecycle;
- stale qualification-mode confirmations in audit mode;
- generic phase evidence;
- missing custody, cleanup, equality, temporal, and manifests;
- launch/runtime flattened self-authentication;
- Framework launcher / Python.app orig-argv distinction;
- optional macOS environment injection;
- stale runtime-matrix member path;
- direct acceptance-bearing embedded path literal;
- overuniform blanket `schema` requirement;
- record with `schema_version` and no `schema`;
- incomplete runtime dependency closure.

Historical evidence is regression input only.

It is not source authority.

──────────────────────────────────────────────────────────────────────────────
6. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────── LIMITED TO NEW GENERATION
────────────────────────────────────────────────

Allocate one private build root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v3-new-generation-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate one private output directory beneath `/Users/ds/Downloads` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-independent-audit-harness-v3-new-generation-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-clean-source-external-independent-audit-harness-v3.pyz

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/new-clean-generation-authority-v1.json
opening/fixed-input-registry-v1.json
opening/governing-package-resolution-v1.json
opening/clean-room-source-authority-v1.json
opening/process-execution-policy-v1.json
opening/implementation-operating-freeze-v1.json

Bind:

- generation:
  new clean implementation generation;
- source-attempt maximum:
  3;
- source attempts consumed:
  0;
- source attempts remaining:
  3;
- Attempt 4:
  forbidden;
- retired source use:
  forbidden;
- implementation-package adjudication:
  forbidden in this task;
- real audit:
  forbidden in this task;
- implementation-source execution:
  forbidden;
- current-subject construction:
  forbidden;
- product/runtime/target/repository/publication/deployment/A6:
  forbidden.

──────────────────────────────────────────────────────────────────────────────
7. PRE-SOURCE DEPENDENCY-DISPOSITION LEDGER
──────────────────────────────────────────────── LIMITED TO 113 ROLES
────────────────────────────────────────────────

Before source creation retain:

analysis/current-generation-dependency-disposition-ledger-v1.json

Classify every one of the 113 predecessor dependency roles exactly once as:

A. COPY_EXACT_GOVERNING_ARTIFACT

Use only when:

- bytes are immutable governing inputs;
- owning documentary authority requires exact preservation;
- no generation-specific identity is embedded.

B. REGENERATE_CURRENT_GENERATION_EVIDENCE

Use when the semantic role is current but its content binds:

- source identities;
- source freeze;
- qualification results;
- rehearsals;
- package status;
- member registry;
- package identities;
- current-generation process custody;
- current-generation cleanup;
- current-generation authority.

The new record:

- preserves the governed semantic role;
- preserves or explicitly supersedes the governed path contract;
- preserves the governed record class;
- receives new bytes and identity;
- binds exact predecessor role and disposition;
- cannot silently adopt predecessor evidence.

C. HISTORICAL_REGRESSION_ONLY

Use when:

- the record exists solely to retain a failed or superseded attempt;
- it contributes no current acceptance authority;
- its use is limited to negative/regression qualification.

Every row must include:

- dependency ID;
- semantic role;
- predecessor member role/path/identity;
- record class;
- owning authority;
- disposition;
- current-generation path;
- regeneration owner when applicable;
- supersession semantics;
- current/historical authority effect;
- source consumers;
- qualification consumers;
- independent-validator consumers.

Unknown, duplicate, conflicting, or unclassified role blocks before source.

Require exact row count:

113.

Require independent validation of the disposition ledger before source
creation.

──────────────────────────────────────────────────────────────────────────────
8. CURRENT-GENERATION DEPENDENCY AUTHORITY
──────────────────────────────────────────────── LIMITED TO IMPLEMENTATION CONTRACT
────────────────────────────────────────────────

Before source creation derive and retain:

contract/current-generation-embedded-dependency-registry-v1.json
contract/current-generation-member-role-registry-v1.json
contract/current-generation-record-class-registry-v1.json

For every current run-full-audit dependency bind:

- semantic role;
- current member role;
- current exact path;
- disposition;
- record class;
- discriminator contract;
- parser contract;
- validation contract;
- producing component;
- consuming components;
- phase/report/confirmation consumers;
- required/optional posture;
- predecessor lineage;
- current identity timing:
  fixed before source,
  regenerated before freeze,
  generated during qualification,
  generated during final packaging.

The new current registry must not copy generation-specific predecessor
identities as current.

Future source requests semantic roles only.

No acceptance-bearing direct member-path literal is permitted.

──────────────────────────────────────────────────────────────────────────────
9. CLEAN-ROOM SOURCE AUTHORITY
──────────────────────────────────────────────── LIMITED TO AUTHORIZED INPUTS
────────────────────────────────────────────────

Permitted implementation inputs:

- the three authenticated documentary packages;
- normative contract/current schemas/current validation specifications inside
  the content bundle;
- exact current-generation dependency registries created before source;
- historical defect catalogue as test requirements;
- this task’s frozen pre-source contracts.

Forbidden source inputs:

- retired harness source;
- retired repair source;
- documentary tooling source;
- implementation source as harness source;
- transcript-reconstructed source;
- decompiled/disassembled source;
- generated source derived from predecessor source;
- source-similarity recovery.

Implementation-package source may be authenticated and parsed read-only in the
future audit and bounded compatibility replay.

It may not be imported or executed.

Retain:

opening/clean-room-source-authority-v1.json

──────────────────────────────────────────────────────────────────────────────
10. SOURCE ARCHITECTURE
──────────────────────────────────────────────── LIMITED TO MODULAR ROLES
────────────────────────────────────────────────

Define clean modular roles for:

- executable PYZ entrypoint;
- finite audit parent;
- child recorder;
- strict JSON;
- record-class dispatcher;
- schema-discriminated parser;
- schema-version-discriminated parser;
- semantic-role dependency resolver;
- PYZ member authority reader;
- content-bundle authority reader;
- documentary-governance reader;
- interpreter-tuple validator;
- environment validator;
- source/freeze validator;
- phase runner;
- path-sensitive implementation analyzer;
- runtime matrix adapter;
- mode-aware report projector;
- mode-aware confirmation projector;
- finding/dependency builder;
- security/authority analyzer;
- cleanup owner;
- fixed-input equality owner;
- audit-capsule lifecycle;
- terminal frame;
- failure closeout;
- qualification fixture drivers;
- independent validators;
- deterministic PYZ builder;
- runtime authority builder;
- external launch-certificate builder.

Every role maps exactly once to a clean source path.

Independent validators import no production/qualification helpers, fixture
generators, expected maps, observers, normalizers, or projectors.

Retain exact planned and final production, qualification, and independent source
registries.

──────────────────────────────────────────────────────────────────────────────
11. SOURCE-ATTEMPT LIMIT
──────────────────────────────────────────────── LIMITED TO NEW GENERATION
────────────────────────────────────────────────

At most three complete source attempts.

An attempt begins only when:

- final source registries close;
- compilation begins.

Any source modification after compilation begins consumes the next attempt.

For every attempt retain:

- exact source identities;
- clean-room provenance;
- compilation;
- static gates;
- matrices reached;
- rehearsals reached;
- first blocker;
- supersession.

If Attempt 3 fails, stop.

No Attempt 4.

──────────────────────────────────────────────────────────────────────────────
12. EMBEDDED DEPENDENCY IMPLEMENTATION
──────────────────────────────────────────────── LIMITED TO SEMANTIC ROLE LOOKUP
────────────────────────────────────────────────

Implement:

semantic role
→ current dependency descriptor
→ current member role
→ exact member path
→ member identity
→ record-class parser
→ discriminator validation
→ typed result

Required record classes:

- SCHEMA_DISCRIMINATED_JSON;
- SCHEMA_VERSION_DISCRIMINATED_JSON.

Additional record classes are permitted only when explicitly present and
governed by the documentary package.

Do not implement:

- direct acceptance-bearing member paths at consumers;
- fallback path lists;
- compatibility aliases;
- basename/suffix/prefix lookup;
- recursive archive search;
- first-existing path;
- version or score selection;
- same-byte lookup;
- generic discriminator fallback;
- blanket `schema` requirement.

The bootstrap-start record must validate through its exact schema-version
contract.

The governed runtime matrix evidence must resolve through its current semantic
role and exact current member.

──────────────────────────────────────────────────────────────────────────────
13. FIVE-DOMAIN AND INTERPRETER GOVERNANCE
────────────────────────────────────────────────

Implement unchanged:

- five documentary domains;
- exact R01–R66 report registry;
- exact 81-name confirmation registry;
- exact B00/D01–D14 registry;
- exact 15 / 595 authority;
- aggregate ownership;
- mode-aware report/confirmation semantics;
- three-role interpreter tuple;
- three-view process authority;
- argv/cwd/PID/flag/source crosswalks;
- bounded runtime environment policy;
- no terminal-runtime-image role;
- no kernel executable-image claim.

Stale 645 fails.

Unknown environment extras fail.

──────────────────────────────────────────────────────────────────────────────
14. CAPSULE, PHASE, CUSTODY, AND TERMINAL LIFECYCLE
────────────────────────────────────────────────

Implement a closed run-full-audit namespace and one-writer registry.

Require:

- schema-bearing canonical capsule JSON;
- explicit P00–P24 terminal records;
- phase-specific evidence;
- complete child ledger including zero-child case;
- internal child custody;
- external top-level process-authority boundary;
- canonical cleanup rows;
- exact fixed-input closing equality;
- fresh audit-owned behavioral causals;
- complete finding ownership and dependency graph;
- nonauthoritative preseal result;
- namespace-stable temporal inventory;
- independently generated byte-identical manifests;
- root row once;
- clean topology and modes;
- one seal transition;
- terminal frame only after closure;
- no postseal operation.

All final dispositions must terminally close when filesystem integrity permits.

──────────────────────────────────────────────────────────────────────────────
15. PRECOMPILATION CLOSURE
────────────────────────────────────────────────

Before final source registries close require:

- all three governing packages authenticate;
- content bundle/authority authenticate;
- dependency disposition ledger passes;
- current-generation dependency registries close;
- exact record-class registry closes;
- all source roles occupied;
- cross-module interface registry closes;
- source lookups derive exclusively from semantic-role APIs;
- no unregistered direct member path;
- report/confirmation/matrix owners resolved;
- no historical source origin;
- no Git/VCS mechanism.

Failure before compilation consumes zero attempts.

──────────────────────────────────────────────────────────────────────────────
16. COMPILATION AND STATIC GATES
────────────────────────────────────────────────

Compile all sources with pinned Python:

-I -S -B

Require exit zero and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception tables;
- CFG;
- source-to-dependency crosswalk;
- member-role/source-consumer join;
- record-class dispatch analysis;
- package-assembly crosswalk;
- interface analysis;
- path-sensitive phase analysis;
- report/confirmation/matrix ownership;
- process/filesystem operation crosswalk;
- terminal-operation analysis;
- forbidden source/path/executable analysis.

Require:

- finite flow;
- no stdin;
- no persistent supervisor;
- one child recorder;
- no network;
- no Git;
- no shell/PATH lookup;
- no broad filesystem scan;
- no retired-source origin;
- no direct acceptance-bearing member path literal;
- no fallback resolution;
- exact dependency closure;
- no postseal operation;
- reachable failure/success closeout.

──────────────────────────────────────────────────────────────────────────────
17. QUALIFICATION MATRICES
────────────────────────────────────────────────

A. Exact governed runtime suite

- B00;
- D01–D14;
- 15 matrices;
- 595 cases;
- exact names/outcomes.

B. Exact 151-case interpreter-tuple suite.

C. Exact 171-case dependency-descriptor suite.

D. Current-generation dependency-disposition matrix:
at least 80 cases.

E. Semantic-role/member-resolution matrix:
at least 80 cases.

F. Record-class dispatch matrix:
at least 60 cases.

G. Capsule-evidence matrix:
at least 60 cases.

H. Mode-aware confirmation matrix:
at least 40 cases.

I. Mode-aware report matrix:
at least 40 cases.

J. Terminal-lifecycle matrix:
at least 40 cases.

K. Process-custody matrix:
at least 40 cases.

L. Fresh behavioral-causal matrix:
at least 20 cases.

Every suite requires:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

New suites do not alter 15 / 595.

──────────────────────────────────────────────────────────────────────────────
18. SYNTHETIC AND BOUNDED REAL-BUNDLE LANES
────────────────────────────────────────────────

Run synthetic source-independent lanes for:

- ACCEPT;
- BLOCK;
- AUDIT_PROVENANCE_MISMATCH;
- semantically equal constructed subjects;
- stale member path;
- missing role;
- wrong record class;
- bootstrap blanket-schema regression;
- unknown environment injection;
- incomplete custody;
- terminal mutations.

Run bounded current-bundle compatibility replay:

- authenticate all 479 members and eight roles;
- resolve all current implementation evidence through semantic roles;
- parse all 113 governed embedded dependencies under their record classes;
- resolve the governed runtime matrix evidence;
- issue no package verdict;
- execute no implementation source.

──────────────────────────────────────────────────────────────────────────────
19. POST-PACKAGE REAL-PATH REHEARSALS
────────────────────────────────────────────────

Mandatory gate.

Build one complete provisional candidate PYZ v3 and provisional runtime
authority v4.

Run the exact packaged candidate PYZ through `run-full-audit`.

A. ACCEPT rehearsal

B. BLOCK rehearsal

C. AUDIT_PROVENANCE_MISMATCH rehearsal

Each rehearsal must:

- use the exact packaged PYZ;
- use provisional authority v4;
- use the exact future CLI;
- pass platform capture;
- pass parent self-authentication;
- access all required embedded dependencies by semantic role;
- retain a dependency-access ledger;
- produce exact mode-aware R01–R66 and 81-name projections;
- produce complete P00–P24 phase records;
- retain custody/cleanup/equality;
- terminally seal.

Require:

- no `embedded-record-unavailable`;
- no stale path;
- no alias or fallback;
- dependency-access set equals the current dependency registry;
- record-class selections equal descriptors;
- complete independent capsule validation.

Retain all evidence before cleanup.

Remove disposable roots with double ENOENT.

──────────────────────────────────────────────────────────────────────────────
20. INDEPENDENT VALIDATION
────────────────────────────────────────────────

Independent validators verify:

- clean-room provenance;
- three governing packages;
- content inputs;
- dependency disposition;
- current dependency registries;
- source/dependency/member/test equality;
- record-class dispatch;
- semantic role resolution;
- five-domain and interpreter governance;
- matrices;
- process custody;
- synthetic lanes;
- compatibility replay;
- all real-path rehearsals;
- capsule terminal closure;
- evidence retention and cleanup.

Independent validators import no candidate production or qualification helpers.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
21. SOURCE FREEZE
────────────────────────────────────────────────

Freeze only after every qualification gate passes.

Retain:

opening/clean-independent-audit-harness-v3-source-freeze-v1.json

Bind:

- all governing-package identities;
- content input identities;
- source registries;
- exact source identities;
- current dependency registries;
- record-class registry;
- all matrix results;
- synthetic lanes;
- compatibility replay;
- rehearsal identities;
- independent results;
- cleanup;
- future invocation;
- real audit not executed;
- later modification forbidden.

Reopen all sources no-follow.

Do not modify afterward.

──────────────────────────────────────────────────────────────────────────────
22. DETERMINISTIC PYZ V3
────────────────────────────────────────────────

Build independently twice:

gen2-clean-source-external-independent-audit-harness-v3.pyz

Require byte equality.

ZIP requirements:

- ZIP_STORED;
- raw UTF-8 sorted names;
- fixed timestamp;
- create_system 3;
- member mode 0600;
- no duplicate/unsafe/directory/symlink/special member;
- no comments/extras;
- no cache/bytecode.

Include exact governing artifacts, but not their tooling source.

Include current-generation dependency and member-role registries.

Include each current governed embedded record exactly once.

Do not include stale compatibility aliases.

Retain exact member registry and count.

──────────────────────────────────────────────────────────────────────────────
23. RUNTIME AUTHORITY V4
────────────────────────────────────────────────

Create deterministically twice:

gen2-clean-source-external-independent-audit-harness-v3.authority-v4.json

Bind:

- exact PYZ v3;
- member registry;
- source freeze;
- source registries;
- all governing packages;
- current dependency registry;
- current member-role registry;
- exact record-class registry;
- qualification evidence;
- post-package rehearsals;
- future run-full-audit invocation;
- current content inputs;
- full real audit:
  false;
- implementation verdict:
  not issued;
- current subject:
  false.

Authority v4 is passed to the harness.

Require Build-A/Build-B equality.

──────────────────────────────────────────────────────────────────────────────
24. POST-PACKAGE QUALIFICATION
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode once with exact authority v4
and required operands.

Retain platform custody and raw streams.

Require:

- PYZ/member self-authentication;
- source freeze;
- three governing packages;
- dependency and record-class closure;
- no stale path;
- all governed and new matrices;
- process custody;
- synthetic lanes;
- bounded replay;
- packaged ACCEPT/BLOCK/provenance rehearsals;
- independent validators;
- deterministic package closure;
- no real audit;
- no implementation verdict.

──────────────────────────────────────────────────────────────────────────────
25. EXTERNAL LAUNCH CERTIFICATE V2
────────────────────────────────────────────────

Create deterministically twice:

gen2-clean-source-external-independent-audit-harness-v3.launch-certificate-v2.json

Bind:

- exact PYZ v3;
- authority v4;
- content inputs;
- deterministic PYZ replay;
- fresh qualification custody/result;
- dependency/record-class closure;
- governing counts and identities;
- packaged rehearsal results;
- exact stream contracts;
- exact future run-full-audit invocation;
- wrapper launch authorized:
  true;
- future audit count:
  1;
- full real audit:
  false;
- implementation verdict:
  not issued.

The certificate is wrapper authority and is not passed to the harness.

Require Build-A/Build-B equality.

Run an independent certificate-input validator.

The future wrapper validates final certificate bytes.

──────────────────────────────────────────────────────────────────────────────
26. FROZEN-PYZ V3 REQUALIFICATION
────────────────────────────────────────────────

Run exact final PYZ v3 in `qualify-harness` mode with final authority v4.

Require:

- exit zero;
- empty stderr;
- exact result;
- package/source self-authentication;
- dependency closure;
- exact record-class dispatch;
- exact matrix-evidence resolution;
- all old/new matrices;
- real-path rehearsal linkage;
- authority-v4 coherence;
- no run-full-audit execution;
- no implementation verdict.

Independently recompute all aggregates.

Retain:

validation/frozen-pyz-v3-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
27. INPUT CLOSING EQUALITY AND CLEANUP
────────────────────────────────────────────────

Repeat exact no-follow checks/inventories for all supplied inputs.

Require opening/closing equality.

Do not mutate supplied inputs.

Before removing any disposable root retain:

- identity;
- complete inventory;
- streams;
- results;
- failure evidence.

Then revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

──────────────────────────────────────────────────────────────────────────────
28. FAILURE CLOSEOUT
────────────────────────────────────────────────

On failure retain:

- source-attempt posture;
- first blocker;
- structured exception;
- process records/streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- input equality;
- freeze/package/authority/certificate posture;
- same-root retry false.

If Attempt 3 fails:

- generation retired:
  true;
- further localized repair:
  false.

Remove provisional outputs only after evidence retention and double ENOENT.

──────────────────────────────────────────────────────────────────────────────
29. VERDICT RULES
────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- all governing inputs authenticate;
- dependency dispositions close;
- clean-room provenance passes;
- source qualifies within three attempts;
- exact 15/595 suite passes;
- exact 151 tuple cases pass;
- exact 171 descriptor cases pass;
- all new dependency/record-class/capsule/projection/custody matrices pass;
- synthetic lanes pass;
- bounded replay passes without verdict;
- packaged ACCEPT/BLOCK/provenance rehearsals pass;
- independent validators pass;
- source freezes;
- deterministic PYZ v3 builds match;
- authority-v4 builds match;
- fresh post-package qualification passes;
- launch-certificate-v2 builds match;
- certificate-input validation passes;
- frozen-PYZ v3 requalification passes;
- input equality and cleanup pass;
- final files are mode 0400;
- no real implementation audit ran;
- no implementation verdict was issued.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTATION_BLOCKED

for substantive qualification failure without provenance failure.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_PROVENANCE_MISMATCH

for fixed-input, source-authority, evidence-loss, custody, cleanup, source-drift,
or final-output identity failures.

──────────────────────────────────────────────────────────────────────────────
30. REQUIRED INLINE OPERATIVE REPORT
────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. Three governing-package identities
5. Content-bundle/content-authority identities
6. Fixed-input authentication
7. Governing-role resolution
8. Dependency disposition ledger
9. Clean-room source authority
10. Harness authority/nonauthority
11. Source architecture
12. Source-attempt ledger
13. Production-source registry
14. Qualification-source registry
15. Independent-source registry
16. Current dependency registry
17. Current member-role registry
18. Record-class registry
19. Cross-module interface registry
20. Compilation/static gates
21. B00/D01–D14
22. 151-case interpreter matrix
23. 171-case descriptor matrix
24. Dependency-disposition matrix
25. Semantic-role resolution matrix
26. Record-class dispatch matrix
27. Capsule-evidence matrix
28. Mode-aware confirmation matrix
29. Mode-aware report matrix
30. Terminal-lifecycle matrix
31. Process-custody matrix
32. Fresh causal matrix
33. Synthetic ACCEPT
34. Synthetic BLOCK
35. Synthetic provenance failure
36. Bounded compatibility replay
37. Packaged ACCEPT rehearsal
38. Packaged BLOCK rehearsal
39. Packaged provenance rehearsal
40. Rehearsal dependency-access closure
41. Independent validators
42. Evidence retention
43. Cleanup
44. Source freeze
45. PYZ v3 Build A
46. PYZ v3 Build B
47. PYZ equality/member closure
48. Authority-v4 Build A/B
49. Post-package qualification
50. Launch-certificate-v2 Build A/B
51. Certificate-input validation
52. Frozen-PYZ v3 requalification
53. Confirmation no real audit
54. Confirmation no implementation verdict
55. Input closing equality
56. Failure-closeout capability/use
57. Final PYZ v3 path/identity
58. Final authority-v4 path/identity
59. Final launch-certificate-v2 path/identity
60. Remaining uncertainty/nonclaims
61. Explicit confirmations

Required confirmations include:

FIVE_DOMAIN_DOCUMENTARY_PACKAGE_AUTHENTICATED
INTERPRETER_TUPLE_DOCUMENTARY_PACKAGE_AUTHENTICATED
EMBEDDED_DEPENDENCY_DOCUMENTARY_PACKAGE_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_AUTHENTICATED
CURRENT_CONTENT_AUTHORITY_AUTHENTICATED
NEW_CLEAN_IMPLEMENTATION_GENERATION_ESTABLISHED
NO_RETIRED_SOURCE_USED
SOURCE_ATTEMPT_LIMIT_RESPECTED
DEPENDENCY_DISPOSITION_LEDGER_COMPLETE
ALL_113_DEPENDENCY_ROLES_CLASSIFIED
NO_PREDECESSOR_GENERATION_EVIDENCE_SILENTLY_PROMOTED
CURRENT_DEPENDENCY_REGISTRY_COMPLETE
CURRENT_MEMBER_ROLE_REGISTRY_COMPLETE
CURRENT_RECORD_CLASS_REGISTRY_COMPLETE
SEMANTIC_ROLE_LOOKUP_IMPLEMENTED
NO_ACCEPTANCE_BEARING_DIRECT_MEMBER_PATH_LITERAL
SCHEMA_DISCRIMINATED_JSON_IMPLEMENTED
SCHEMA_VERSION_DISCRIMINATED_JSON_IMPLEMENTED
BOOTSTRAP_START_VALIDATED_BY_SCHEMA_VERSION
GOVERNED_MATRIX_EVIDENCE_RESOLVED_BY_ROLE
STALE_MATRIX_SUITE_PATH_ABSENT
NO_COMPATIBILITY_ALIAS
NO_PATH_FALLBACK
FIVE_DOCUMENTARY_DOMAINS_IMPLEMENTED
RUNTIME_REPORT_REGISTRY_66_IMPLEMENTED
RUNTIME_CONFIRMATION_REGISTRY_81_IMPLEMENTED
RUNTIME_MATRIX_REGISTRY_15_595_IMPLEMENTED
INTERPRETER_TUPLE_IMPLEMENTED
RUNTIME_ENVIRONMENT_POLICY_IMPLEMENTED
PARENT_SELF_AUTHENTICATION_IMPLEMENTED
PHASE_TERMINALITY_IMPLEMENTED
PHASE_SPECIFIC_EVIDENCE_IMPLEMENTED
PROCESS_CUSTODY_IMPLEMENTED
CANONICAL_CLEANUP_IMPLEMENTED
FIXED_INPUT_CLOSING_EQUALITY_IMPLEMENTED
CAPSULE_TERMINAL_LIFECYCLE_IMPLEMENTED
ALL_SOURCES_COMPILED
STATIC_GATES_PASSED
PRIOR_GOVERNED_MATRICES_PASSED
INTERPRETER_TUPLE_MATRIX_PASSED
DEPENDENCY_DESCRIPTOR_MATRIX_PASSED
NEW_DEPENDENCY_AND_RECORD_CLASS_MATRICES_PASSED
CAPSULE_PROJECTION_CUSTODY_MATRICES_PASSED
SYNTHETIC_LANES_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
PACKAGED_ACCEPT_REHEARSAL_PASSED
PACKAGED_BLOCK_REHEARSAL_PASSED
PACKAGED_PROVENANCE_REHEARSAL_PASSED
REHEARSAL_DEPENDENCY_ACCESS_EQUAL_REGISTRY
NO_EMBEDDED_RECORD_UNAVAILABLE
INDEPENDENT_VALIDATORS_PASSED
SOURCE_FROZEN
SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_V3_BUILD_A_B_BYTES_IDENTICAL
PYZ_V3_MEMBER_CLOSURE_PASSED
AUTHORITY_V4_BUILD_A_B_BYTES_IDENTICAL
POST_PACKAGE_QUALIFICATION_PASSED
LAUNCH_CERTIFICATE_V2_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_INPUT_VALIDATION_PASSED
FROZEN_PYZ_V3_REQUALIFICATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_PYZ_V3_CREATED
FINAL_PYZ_V3_MODE_0400
FINAL_PYZ_V3_IDENTITY_VERIFIED
FINAL_AUTHORITY_V4_CREATED
FINAL_AUTHORITY_V4_MODE_0400
FINAL_AUTHORITY_V4_IDENTITY_VERIFIED
FINAL_LAUNCH_CERTIFICATE_V2_CREATED
FINAL_LAUNCH_CERTIFICATE_V2_MODE_0400
FINAL_LAUNCH_CERTIFICATE_V2_IDENTITY_VERIFIED
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_V3_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next task is exactly one fresh audit using:

1. final PYZ v3;
2. final authority v4;
3. final launch certificate v2;
4. current content bundle;
5. current content authority.

Do not combine implementation and audit.

Do not construct the current schema subject until the later audit accepts the
Generation-2 implementation package.
```

### Sources

The new contract freezes all 113 embedded dependencies and both record classes, with exact set closure across source derivation, descriptors, member roles, package members, and tests. :chatgpt-content-reference{index="5"}

It expressly makes the stale matrix-suite path noncurrent and forbids compatibility aliases and every lookup fallback. :chatgpt-content-reference{index="6"}

The package terminally closed and reports no remaining operating-model uncertainty. :chatgpt-content-reference{index="7"}

**Confidence:** 0.999 that the embedded-dependency operating model is now frozen; 0.999 that no localized repair of the retired generation is authorized; 0.99 that a fresh clean implementation generation is the correct next tranche; 0.96 that the dependency-disposition ledger is necessary to prevent predecessor qualification evidence from being silently promoted as current.

The current attachment was fully readable. Some earlier uploaded files have expired; byte-level review of those older files would require re-uploading them.
