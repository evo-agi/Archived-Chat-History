Here is Codex's response:

PREFLIGHT\_PROVENANCE\_MISMATCH

The sealed predecessor is mechanically self-consistent, but one supplied governing identity is invalid and does not match the retained file:

- Record: [two-root-rebinding-determinism-v1.json](/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn/validation/two-root-rebinding-determinism-v1.json)
- Supplied digest: `f1e0882854891c2bb8f851309bf8d6f5eb97c13e482809009b75e7aeb31d3e` — 62 characters
- Observed SHA-256: `f1e0882854891c2bb8f851309bf9e8d6f5eb97c13e482809009b75e7aeb31d3e` — 64 characters
- Observed size: `8350`

A 62-character value cannot be an exact SHA-256 identity. I did not infer or silently repair the missing characters.

### Required inline report

1. **Primary verdict:** The verdict above.
2. **Allocated package root:** `/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-metadata-repair-h5f09wc4`; device/inode `16777234/180325856`, mode `0700`. It is unsealed and nonauthoritative.
3. **Sealed predecessor:** Device/inode/mode matched `16777234/180248929/0700`. Closure had 74 entries, 14 directories, and 60 regular files.
4. **Historical roots:** No historical lineage root other than the predecessor was opened.
5. **Predecessor exports:** No export was adopted. The per-export authority gate was not promoted after the governing mismatch.
6. **Successor exports:** Not created.
7. **Direct plan-root delta:** Not performed.
8. **Generated metadata:** Not generated.
9. **Four-consumer registry:** Not generated.
10. **Four-pointer resolution:** Not run.
11. **Dependency graph V2:** Not generated.
12. **Root-rebinding contract V2:** Not generated.
13. **Export registry V2:** Not generated.
14. **Qualification result V2:** Not generated.
15. **Metadata-pointer matrix:** Not run.
16. **Independent metadata validator:** Not run.
17. **Root-rebinding matrix V2:** Not run.
18. **Two-root metadata determinism:** Not run.
19. **Support-binding qualification:** Not run.
20. **Finalizer qualification:** Not run.
21. **Carrier materializations:** Not run.
22. **Finalizer causals:** Not run.
23. **Freeze record V3:** Not generated.
24. **Metadata coherence:** Not evaluated.
25. **Frozen-package requalification:** Not run.
26. **Lineage record:** Not generated.
27. **Package immobility:** No successor authority was established.
28. **Cache posture:** No package-local bytecode or cache was created. External diagnostic caches were removed.
29. **Supplied-root closing equality:** Passed for the sole opened supplied root. Two complete inventories were identical: 74 entries, inventory digest `20b6085c18ba88151020942928549d767bf7948e2b2a80f45fba348a65636749`.
30. **Successor temporal inventory:** Not generated.
31. **Successor manifest A:** Not generated.
32. **Successor manifest B:** Not generated.
33. **Terminal reprojection:** The predecessor independently reprojected successfully; no successor reprojection was attempted.
34. **Terminal membership/modes:** No successor terminal closure exists.
35. **No-write-after-closure:** Not applicable because closure did not begin.
36. **Real target audit:** Not executed.
37. **Remaining uncertainty:** The intended authoritative digest cannot be inferred from the malformed supplied value, even though the retained record has a valid 64-character digest.
38. **Explicit confirmations:** See below.

Confirmed:
```
SEALED_PREDECESSOR_ROOT_MUTATION_NOT_PERFORMED
FAILED_UNSEALED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLOSURE_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
EXECUTABLE_SOURCE_CONTROL_FLOW_UNCHANGED
TARGET_AUDIT_ACCEPTANCE_RULES_UNCHANGED
HISTORICAL_PACKAGES_NONCURRENT
NO_RUNTIME_ROOT_DISCOVERY
NO_ROOT_FALLBACK
NO_LATEST_OR_SCORE_SELECTION
NO_BYTECODE_CACHE_RETAINED
NO_PYC_RETAINED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
REAL_TARGET_AUDIT_NOT_EXECUTED
RUNTIME_VALIDATION_NOT_RERUN
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

All construction-, qualification-, metadata-, freeze-, and successor-closure confirmations were not reached and are not claimed.
