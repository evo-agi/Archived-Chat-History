## Assessment

The reconnaissance is sufficient to authorize implementation. **Model C is the right bounded design.**

It closes SEC-02 at the correct boundary: the exact verifier source becomes part of the interpreter’s immutable process argv before Python begins executing it. Later package-file checks then establish consistency and package custody; they are no longer being asked to reconstruct which pathname object Python loaded earlier.

Three conditions must remain explicit during implementation:

1. **The producer or auditor constructing argv is part of the trusted external boundary.** Its authentication of the source bytes is the trust decision. The verifier’s comparison against `sys.orig_argv` and the package file is only a consistency check.
2. **No repository launcher should be introduced silently.** A file-backed launcher would create another executable-source custody problem. Implementation validation may retain a source-external launch capsule as evidence, but the fresh auditor must independently construct or verify its own caller.
3. **Direct-script execution becomes intentionally nonqualifying.** The migration must cover all unit, real-A6D, amendment, and synthetic-A6 invocations. A successful old-style invocation would be a blocker.

Keeping the verifier tool ID and output schema at v1 while naming the incompatible invocation **launch protocol v2** is defensible because closure semantics and output meaning stay unchanged. The change must nevertheless be unmistakable in `PLANS.md`, the normative documentation, tests, implementation evidence, and later audit inputs.

This remains a bounded proof-tool refinement, not a transfer of authority. The project freeze explicitly prohibits proof harnesses or generated evidence from becoming architecture or authority by inertia.  The selected architecture likewise keeps exact verifier-source trust outside the verifier itself. 

## Codex implementation prompt

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete implementation report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

A source-external report file may be created and linked as supplemental
evidence, but the complete report required below must also appear in the
response body.

This applies to every outcome, including:

- success;
- baseline mismatch;
- scope expansion;
- implementation block;
- validation block;
- provenance block.

Do not silently truncate the inline report. Prioritize the complete inline
report over supplemental links.

Permission is now workspace-write.

Objective

Implement the reconciled Model C launch-custody design from the preceding
read-only reconnaissance:

EXTERNALLY AUTHENTICATED SOURCE BY VALUE THROUGH PYTHON `-c`

The parent is the sole repository writer.

Do not spawn subagents. All reconnaissance agents are closed.

Do not redesign the external-verifier architecture.
Do not add self-verification authority.
Do not introduce a repository launcher.
Do not create another worktree.
Do not reset, clean, restore, rebase, or discard the current patch.
Do not modify the Repair 10I candidate.
Do not modify sealed A6D or amendment children.
Do not modify any completed audit or reconnaissance evidence.
Do not stage, commit, push, create a PR, merge, install, deploy, restart A6,
invoke product paths or live services, contact a network, or execute Linux
binaries.

## 1. Paths and baseline

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Current canonical patch manifest:

OPENING_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json

Expected opening-manifest SHA-256:

f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8

Expected opening tracked binary-diff SHA-256:

8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac

Expected opening verifier SHA-256:

1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f

Expected opening test SHA-256:

cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132

Exact retained provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Load-custody reconnaissance root, read-only:

RECON=/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f

Required new implementation-evidence root:

REPAIR_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4

Require REPAIR_EVIDENCE absent before creation.

Fifth-audit root, read-only:

AUDIT_V5=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular single-link file;
- size 119424;
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b.

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout for implementation commands:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. Strict Git and command boundary

Set:

GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Every Git invocation must use:

git -C "$IMPL_R" ...

with cwd equal to IMPL_R and both Git environment bindings above.

Do not run Git in PRIMARY_R, CANDIDATE_R, A6D, A6D_AMEND, RECON, AUDIT_V5,
REPAIR_EVIDENCE, or another evidence root.

Do not use an implicit-cwd Git invocation.

Record every Git argv, cwd, environment, exit, stdout hash, and stderr hash.

## 3. Mandatory opening gate

Before editing, require IMPL_R:

- physical root equals lexical path;
- direct real directory;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- parent count exactly one;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked and nine untracked;
- every path regular, single-link, working mode `0644`, logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

Expected 13 paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Open and verify OPENING_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact opening manifest SHA-256;
- exact recipe SHA-256;
- manifest/live equality for every path, classification, mode, size, and hash;
- exact tracked binary-diff;
- exact current verifier and test hashes;
- registry and three layout hashes unchanged;
- RECON and AUDIT_V5 opening snapshots stable;
- A6D and A6D_AMEND manifests exact;
- CANDIDATE_R identity unchanged from its recorded baseline.

Run the exact provenance recipe twice before editing, into fresh absent outputs
beneath:

REPAIR_EVIDENCE/opening/provenance/

Require byte-identical outputs equal to OPENING_MANIFEST.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_BASELINE_MISMATCH

## 4. Implementation-evidence root

After the opening gate, create REPAIR_EVIDENCE under umask `077` with:

opening/
design/
commands/
validation/
provenance/
closeout/

All directories mode `0700`.
All retained files regular, single-link, mode `0600` unless an executable
validation artifact is explicitly and safely classified.

Do not overwrite previous implementation, audit, or reconnaissance evidence.

Retain a design-adoption record binding:

- reconnaissance verdict;
- selected Model C;
- rejected alternatives;
- current baseline;
- exact six-file repository scope;
- launch protocol v2;
- external caller/verifier responsibility split;
- non-authority and non-self-verification rules;
- mandatory stop conditions.

## 5. Exact repository touched-file scope

This implementation may modify exactly these six existing repository paths:

1. `PLANS.md`
2. `.docs/system_overview/evidence_verification.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `tools/evidence_verify/test_verify_v1.py`
6. `tools/evidence_verify/verify_v1.py`

Modify only files genuinely required.

Keep byte-identical:

- `.docs/system_overview/boundaries.md`
- `tools/evidence_verify/registry_v1.json`
- all three layout JSON files
- both historical `.py.txt` fixtures.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No product or public schema.
No Go source.
No runtime route.
No shared package.

If a seventh repository file or a fourteenth patch path is needed, stop:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_SCOPE_EXPANSION_REQUIRED

## 6. Frozen authority and launch model

Implement exactly this split.

### External producer or auditor owns trust

The external caller:

- pins the physical interpreter identity;
- physically and no-follow opens the external verifier package;
- reads exact `verify_v1.py` bytes;
- authenticates those bytes against external patch or commit provenance;
- validates canonical UTF-8, no NUL, terminal LF, round-trip identity, and
  admitted source/argv size;
- constructs a fixed argv list without shell expansion or command
  substitution;
- places the exact source string in one `-c` argv element;
- supplies an explicit physical package root;
- launches the pinned interpreter under a private safe environment;
- independently pins registry and selected layout bytes;
- records exact argv and source/interpreter/package identities;
- accepts verifier output only after comparing returned registry/layout hashes
  against external provenance.

This external authentication is the trust decision.

### The verifier owns consistency and closure only

The verifier:

- requires launch protocol v2;
- requires exact source-by-value `-c` invocation;
- captures the initial interpreter argv state before application logic;
- recovers the complete source string from that captured state;
- re-encodes it canonically;
- compares it byte-for-byte with the physically opened package
  `verify_v1.py`;
- binds package, registry, selected layout, target, and optional candidate;
- performs the existing structural closure checks;
- rechecks package source and identities at close;
- emits structural evidence only.

The verifier’s source comparison is not source authentication and must not be
described as such.

## 7. Launch protocol v2

Define a stable internal constant and documentation name:

`execution-substrate.evidence-closure-launch/v2`

The verifier tool ID remains:

`execution-substrate.evidence-closure-verifier/v1`

The existing output schema remains unchanged.

The trusted caller invokes the verifier with an argv-list API, never a shell:

```text
PYTHON -I -S -B -c SOURCE_TEXT
  --package-root ABSOLUTE_PHYSICAL_EXTERNAL_PACKAGE
  --root ABSOLUTE_PHYSICAL_TARGET
  --layout-id ID
  --stage sealed
```

Pre-seal adds exactly:

```text
--manifest ABSOLUTE_PHYSICAL_EXTERNAL_CANDIDATE
```

after:

```text
--stage pre-seal
```

The final implementation may freeze a different exact argument order only when
required by current parser structure, but it must:

- use one exact documented order;
- reject reordered, duplicated, omitted, or extra arguments;
- use no shell;
- support no script-path fallback;
- support no stdin fallback;
- support no `/dev/fd` fallback;
- support no ambiguous `-c` form.

## 8. Early launch-state capture

Capture immutable launch state as early as Python source permits:

1. `from __future__ import annotations`
2. import `sys`
3. copy `sys.orig_argv` to an immutable tuple
4. copy `sys.argv` to an immutable tuple
5. record whether `__file__` is present
6. only then continue ordinary imports and application initialization

Do not retain the source string in diagnostic output.

The verifier must require, at minimum:

- `sys.argv[0] == "-c"`;
- `__file__` absent;
- isolated mode active;
- environment ignored;
- user-site disabled;
- site import disabled;
- bytecode writing disabled;
- captured original argv contains exactly:
  - interpreter spelling at element zero, treated as informational only;
  - `-I`;
  - `-S`;
  - `-B`;
  - `-c`;
  - the complete source string;
  - exactly the documented verifier CLI arguments;
- captured post-`-c` arguments equal captured `sys.argv[1:]`;
- no extra interpreter flag or application argument.

Do not treat `sys.orig_argv[0]` as interpreter authentication. The external
caller owns interpreter identity.

Mutation of live `sys.argv` or `sys.orig_argv` after capture must not alter the
captured launch decision.

## 9. Package-root and source consistency

Replace `__file__`-derived package authority with explicit `--package-root`.

Require the package root to be:

- absolute;
- physically equal to its lexical spelling;
- a direct real directory;
- no symlink component;
- outside and disjoint from target and pre-seal candidate;
- stable through closing checks.

Within the package root, open `verify_v1.py` through no-follow,
descriptor-relative custody.

Require:

- direct regular file;
- link count one;
- stable opening/path/descriptor identity;
- canonical UTF-8;
- no NUL;
- terminal LF;
- source-size limit;
- byte-for-byte equality with the captured `-c` source string.

The source string and package file must be compared as exact bytes, not code
objects or normalized text.

A package-source mismatch is a definite nonqualification.

Recommended mapping:

- unsupported invocation shape:
  `INVOCATION`, exit `2`;
- definite source/package inconsistency, package/source symlink, hardlink,
  forbidden containment, invalid canonical source, or source-byte mismatch:
  `TARGET_BOUNDARY`, exit `2`;
- unstable identity, disappearance, capability uncertainty, or closing race:
  `IO_OR_RACE`, exit `7`.

Preserve the existing canonical one-line stdout and empty-stderr behavior.

No output field may expose:

- source text;
- source path;
- source hash;
- package path;
- target path;
- interpreter path;
- readiness.

## 10. Registry, layout, target, and candidate behavior

Continue to load registry and selected layout relative to the physically bound
explicit package root.

Preserve:

- exact registry/spec canonical parsing;
- exact registry-to-layout hash binding;
- package/target equality and containment rejection;
- package/candidate and target/candidate disjointness;
- descriptor-relative no-follow traversal;
- existing file, directory, mode, link, path, manifest, sidecar, and resource
  limits;
- repeated scan and closing checks;
- no write;
- no target-code import;
- no child process from the verifier;
- no network;
- no readiness interpretation.

The trusted caller independently compares returned registry and layout hashes
with its pinned external values. The verifier must not claim that doing so
authenticates its own package.

## 11. Source-external caller evidence

Do not add a repository launcher.

For implementation validation, create a source-external launch-capsule source
beneath:

REPAIR_EVIDENCE/commands/

Classify it as:

source-external validation/provenance evidence

not:

- product source;
- verifier source;
- runtime source;
- repository authority;
- readiness authority;
- a durable cross-repository framework.

The capsule may be a Python standard-library helper, but its exact source must
be retained and reported. It must:

- implement the caller responsibilities in section 6;
- use an argv-list subprocess API;
- use no shell;
- avoid printing source text;
- retain only safe source size/hash and invocation identities;
- capture child stdout, stderr, and exit;
- produce a closed launch record containing:
  - schema ID;
  - launch protocol ID;
  - interpreter identity;
  - source package identity;
  - source size and SHA-256;
  - package-root identity;
  - target/candidate identities;
  - argv-shape digest without source text;
  - safe environment inventory;
  - registry/layout expected hashes;
  - child stdout/stderr size and SHA-256;
  - exit;
  - before/after snapshot results;
  - outcome and ordered errors.

Suggested private evidence schema:

`execution-substrate.evidence-closure-launch-record.v2`

The implementation and later auditor must not treat this producer capsule as
an independent correctness oracle. A fresh auditor must inspect it and
independently construct or reproduce the launch.

If retaining this capsule necessarily introduces a repository file or another
authority owner, stop.

## 12. Documentation-first implementation

Update documents before implementation code.

### PLANS.md

Record:

- SEC-02 root cause;
- launch protocol v2;
- source-by-value design;
- external caller versus verifier ownership;
- direct-script nonqualification;
- unchanged closure/output semantics;
- unchanged non-authority posture;
- migration and audit sequence;
- stop conditions.

Classify this as a bounded slice refinement, not a reopened product seam.

### evidence_verification.md

Define normatively:

- exact launch protocol;
- exact caller responsibilities;
- exact verifier responsibilities;
- explicit package root;
- exact source consistency check;
- trust versus consistency distinction;
- direct-script/stdin/FD nonqualification;
- process-list visibility of nonsecret source;
- unsupported capability and argv-capacity failure;
- unchanged output and readiness boundary.

### artifact_hygiene.md

State:

- the canonical source package remains physically external;
- the executed source is transported by value from externally authenticated
  package bytes;
- package and target/candidate remain physically disjoint;
- source text is nonsecret but should not be logged or retained unnecessarily;
- process-list visibility is a documented local validation characteristic;
- generated launch records remain evidence/projection.

### capability_probing.md

Define behavioral, fail-closed probes for:

- interpreter identity;
- isolated/no-site/no-bytecode flags;
- canonical UTF-8 round trip;
- NUL rejection;
- terminal LF;
- argv capacity;
- source/package no-follow identity;
- repeated source read;
- package-root traversal;
- unsupported-operation classification;
- no script/stdin/FD fallback.

Do not change boundaries.md unless a genuine ownership conflict is discovered;
if so, stop for scope expansion.

## 13. Test migration requirements

Preserve all existing 75 test identities or document a one-to-one migration
where a name must change. Do not silently remove or weaken any prior causal.

Migrate every qualifying verifier invocation to launch protocol v2.

Old direct-script invocations must become explicit expected-negative tests.

Add at least the following new causal coverage:

1. Exact v2 pre-seal pass.
2. Exact v2 sealed pass.
3. Direct-script invocation returns `INVOCATION`/2.
4. Final-symlink script invocation returns `INVOCATION`/2.
5. Parent-symlink script invocation returns `INVOCATION`/2.
6. Stdin invocation returns `INVOCATION`/2.
7. `/dev/fd/N` invocation returns `INVOCATION`/2.
8. Missing `--package-root` rejects.
9. Reordered application arguments reject.
10. Extra interpreter option rejects.
11. Combined or reordered `-I -S -B` flags reject if outside the one frozen
    shape.
12. `__file__` present rejects.
13. `sys.flags` isolation/no-site/no-bytecode mismatch rejects.
14. Captured argv remains decisive after live `sys.argv`/`sys.orig_argv`
    mutation.
15. Source/package byte equality passes.
16. One-byte source/package mismatch rejects.
17. Package source replaced after argv construction rejects without executing
    replacement bytes.
18. Package source replaced during verifier checks blocks.
19. Invalid UTF-8 is rejected by the external caller before exec.
20. NUL is rejected by the external caller before exec.
21. Missing terminal LF is rejected before exec.
22. Source byte/string/argv/byte round trip is exact.
23. Source over the frozen local maximum is rejected before exec.
24. Injected insufficient `ARG_MAX` capacity rejects before exec.
25. SEC-02 timed symlink swap:
    - target-contained marker source never executes;
    - no forged qualifying pass.
26. Target-contained source and external symlink may exist but are never loaded
    by a valid v2 launch.
27. Package source swap after argv construction cannot make target code execute.
28. Registry substitution yields a returned hash mismatch and caller rejection.
29. Layout substitution yields a returned hash mismatch and caller rejection.
30. Source text, path, hash, package path, interpreter path, and target path do
    not appear in canonical verifier output.
31. Source string visibility in the process list is classified as nonsecret
    exposure and never used as an identity oracle.
32. Real A6D verification under v2.
33. Real amendment verification under v2.
34. Synthetic A6 pre-seal and sealed verification under v2.

For every expected verifier failure assert:

- exact outcome;
- exact error class;
- exact exit;
- exactly one canonical stdout line;
- empty stderr;
- no traceback;
- no absolute path or source-content leak.

For caller-side pre-exec rejection assert:

- child not launched;
- zero verifier stdout/stderr;
- exact launch-record reason;
- no target/package/candidate mutation.

## 14. Validation sequence

Use:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Require the pinned identity above.

Use isolated private roots and no network.

Run, in order:

1. Parse current Python source with `ast.parse`.
2. Parse both historical `.py.txt` fixtures without executing them.
3. Strictly parse registry and three layouts.
4. Require registry/layout/historical-fixture bytes unchanged.
5. Verify documentation contract assertions.
6. Discover and retain the complete migrated test set.
7. Run all targeted launch-protocol-v2 causals.
8. Run the complete suite twice under umask `077`.
9. Run the complete suite twice under umask `022`.
10. Require identical discovered test sets.
11. Require zero failure, error, or required skip.
12. Run the SEC-02 timed negative independently outside the unit-suite wrapper.
13. Run sealed A6D twice through the source-external v2 caller.
14. Run sealed amendment twice through the v2 caller.
15. Run synthetic A6 pre-seal twice through the v2 caller.
16. Seal only the audit/implementation-owned synthetic fixture through the
    existing test writer.
17. Run synthetic A6 sealed twice.
18. Require repeated canonical verifier stdout byte equality.
19. Require source-external launch-record consistency.
20. Snapshot target, package, candidate when applicable, caller evidence root,
    and TMPDIR before and after.
21. Require no verifier mutation.
22. Require no caller mutation outside its own evidence outputs.
23. Run:
    `git -C "$IMPL_R" diff --check`
    under the fixed Git environment.
24. Scan IMPL_R for cache, bytecode, generated manifests, databases, journals,
    locks, fixture roots, temporary output, unexpected executable modes, and
    unsupported objects.
25. Remove only artifacts created by this implementation activity.

No Go suite.
No product path.
No live service.
No network.
No A6 restart.

## 15. Real-child migration requirements

### A6D

Run the unchanged sealed A6D child twice using:

- exact authenticated final verifier source by value;
- explicit implementation package root;
- existing A6D layout ID;
- sealed stage;
- pinned interpreter and registry/layout hashes.

Require:

- both exits 0;
- empty stderr;
- byte-identical canonical stdout;
- target and package unchanged;
- launch records internally consistent;
- A6D manifest remains:
  `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`.

### Amendment

Apply the same requirements using the amendment layout ID.

Require amendment manifest remains:

`a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`.

These are structural compatibility results only.

## 16. Provenance

After all validation passes, remove only implementation-created temporary
artifacts.

Use the exact existing RECIPE source without modification.

Run it twice against IMPL_R into fresh absent paths beneath:

REPAIR_EVIDENCE/provenance/

Require:

- both exits 0;
- empty stderr;
- byte-identical canonical output;
- exact same 13-path scope;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deletion;
- zero rename;
- zero unsupported type;
- no extra path.

Retain:

- exact recipe source;
- both canonical manifests;
- new canonical-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities;
- exact final verifier and test hashes;
- exact launch-capsule source and hash;
- complete validation command/result index.

Every previous audit becomes predecessor evidence only and does not qualify the
changed bytes.

## 17. Closing gate

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD unchanged;
- upstream absent;
- exactly 13 changed or untracked paths;
- four modified tracked;
- nine untracked;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero extra path;
- all patch paths regular logical mode `100644`;
- `git diff --check` clean;
- no repository cache, bytecode, generated manifest, fixture, database, lock,
  journal, or temporary output.

Require:

- CANDIDATE_R unchanged;
- A6D and A6D_AMEND unchanged;
- RECON and AUDIT_V5 unchanged;
- old implementation evidence unchanged;
- PRIMARY_R never used as implementation cwd or Git root.

Do not remove IMPL_R or previous evidence.

## 18. Mandatory stops

Stop immediately if:

- opening identity or provenance differs;
- a seventh repository file is needed;
- a fourteenth patch path is needed;
- registry or layout bytes must change;
- output schema or tool ID must change;
- source-by-value does not round-trip exactly;
- source size or argv capacity is insufficient;
- a shell or command substitution becomes necessary;
- direct script, stdin, or `/dev/fd` invocation still qualifies;
- source/package mismatch can still pass;
- SEC-02 target marker can execute under a valid v2 launch;
- source/package/target/candidate disjointness weakens;
- source comparison is represented as self-authentication;
- canonical output exposes source/path material;
- caller-side evidence becomes readiness or runtime authority;
- real A6D or amendment compatibility fails;
- existing EV/F causals regress;
- tests differ by umask;
- validation mutates repository or supplied evidence;
- final provenance is unstable.

Verdicts:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_SCOPE_EXPANSION_REQUIRED

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_BLOCKED

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTED_READY_FOR_FRESH_AUDIT

## 19. Required complete inline final report

Your final response must contain the complete implementation report inline.

Do not replace any section with a link. Supplemental links may follow the
complete inline report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Opening repository and provenance identity.
4. Reconnaissance adopted and rejected findings.
5. Preserved disagreements.
6. Exact six-file implementation scope.
7. Current-contract and strategic-target treatment.
8. Launch protocol v2 definition.
9. External caller trust and responsibility boundary.
10. Verifier consistency and closure boundary.
11. Early captured launch state.
12. Exact accepted argv shape.
13. Exact unsupported invocation behavior.
14. Package-root and source-byte binding implementation.
15. Registry/layout/target/candidate custody.
16. Error-class and exit mapping.
17. Documentation changes.
18. Source-external launch-capsule source, classification, and SHA-256.
19. Complete final test count and identity list.
20. Every new launch-custody causal and result.
21. SEC-02 independent negative result.
22. Both umask-077 suite results.
23. Both umask-022 suite results.
24. Prior EV/F regression results.
25. Real A6D v2 results.
26. Real amendment v2 results.
27. Synthetic pre-seal and sealed v2 results.
28. No-write and deterministic-output evidence.
29. Final verifier SHA-256.
30. Final test SHA-256.
31. Registry/layout/historical-fixture hashes, confirming unchanged bytes.
32. Exact final 13-path manifest.
33. Exact provenance recipe identity and source SHA-256.
34. New tracked binary-diff SHA-256.
35. New canonical patch-manifest SHA-256.
36. Source-external validation-evidence inventory.
37. Artifact hygiene and cleanup.
38. Authority/security/protocol widening:
    exact bounded launch-protocol change and explicit non-widenings.
39. Remaining uncertainty and uninspected areas.
40. Explicit statements:
    - all previous audits no longer qualify changed bytes;
    - fresh independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked;
    - network contact not performed;
    - no subagents were created.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## Next gate

On successful implementation, the changed 13-path patch **and the exact source-external launch capsule** require a fresh independent audit. The auditor should independently reconstruct source-by-value launch rather than treating the producer capsule as an oracle, and it should rerun SEC-02 before reviewing the rest of the patch.

Implementation and audit must remain separate conversations; changed bytes require new validation and provenance before a fresh audit.  Exact provenance must bind implementation and audit to the same bytes, while remaining evidence rather than correctness or authority. 

### Sources

- Codex’s complete inline load-custody reconnaissance supplied in this turn.
- Selected external-verifier architecture and non-self-verifying bootstrap. 
- Read-only reconnaissance followed by parent-only implementation, with no subagents during mutation. 
- Independent audit remains a fresh read-only conversation. 
- Exact recipe source and canonical provenance remain mandatory. 
- Proof harness and generated evidence remain non-authoritative. 

**Confidence**

- Reconnaissance readiness: **0.995**
- Model C as the best bounded design: **0.96**
- Need to treat the external caller as part of the trusted security boundary: **0.999**
- Feasibility within the six-file repository scope: **0.94**
- Correct next gate after implementation: fresh independent audit, **0.999**
