## Engineering assessment

The clean-room strategy remains sound. The blocked result identifies one bounded **evidence-lifecycle ownership defect**, not a defect in the normative contract, the fifteen schemas, the 15/14 role model, or the validation semantics.

The key failure is precise:

- `validation/confirmation-evidence-map-validator-v1.json` had already been created as one of the ten documentary-validator results.
- A later confirmation stage attempted a second exclusive creation of the same path.
- The artifact plan nominally assigned one “parent” writer, but did not close ownership at the necessary granularity: **phase, function, and creation event**.
- The rehearsal correctly failed rather than overwriting or adopting the existing file.

The repair must therefore address more than the duplicate write statement. It needs to freeze the documentary-evidence lifecycle so that:

1. the nine prerequisite documentary-validator results are generated;
2. the confirmation evidence map is generated;
3. the confirmation-evidence-map validator writes its result **exactly once**;
4. the final ten-role registry is generated only after all ten results exist;
5. the documentary-validator regeneration result is derived from that final registry;
6. explicit confirmations and reports are downstream of the closed registry;
7. no stage prewrites, reserves, overwrites, or later regenerates the validator result.

The implementation package also exposed a secondary custody gap: the failed rehearsal’s partial inventory was created in the rehearsal root but was removed before a copy was retained in the implementation package. The next repair should require partial-inventory retention before rehearsal-root deletion.

This does **not** require another clean-room rewrite. Candidate 003 is a legitimate clean-room implementation base: it was not derived from V1–V4, its static gates and component matrices passed, and the defect is isolated to current evidence ownership and closeout ordering. A fresh root should perform a bounded source-external repair of Candidate 003, then complete two full rehearsals, freeze the exact source, and requalify it.

Given the repeated qualification failures, the repaired implementation package should undergo a **fresh independent audit before it is ever used for the authoritative one-shot subject reconstruction**.

```text
BOUNDED REPAIR, COMPLETE QUALIFICATION, AND FREEZE OF THE
CLEAN SCHEMA-SUBJECT RECONSTRUCTION PARENT —
DOCUMENTARY-EVIDENCE SINGLE-WRITER AND FAILURE-CUSTODY REPAIR

This task repairs the clean-room schema-subject reconstruction parent after
its third source candidate failed complete rehearsal A.

The exact failure is:

- path:
  validation/confirmation-evidence-map-validator-v1.json;
- first creation:
  documentary-validator regeneration stage;
- later attempted creation:
  confirmation-evidence stage;
- write posture:
  exclusive create;
- result:
  collision and rehearsal failure;
- overwrite:
  not performed;
- adoption:
  not performed;
- contract effect:
  none;
- schema effect:
  none;
- validator-semantic effect:
  none.

The artifact plan assigned the parent as writer but did not establish one
authoritative phase/function/create event for this mutable fact.

A secondary evidence-custody defect also exists:

- rehearsal A’s parent created a partial inventory;
- the qualification harness removed the failed rehearsal root before retaining
  a copy of that inventory in the implementation package;
- the loss was disclosed and not promoted.

This task performs a bounded repair of the clean Candidate 003 implementation.
It does not return to the exhausted V1–V4 incremental lineage and does not
rewrite the implementation from historical source.

It does not:

- modify the normative construction-parent contract;
- modify any of the fifteen current schemas;
- change the fifteen-schema-role model;
- change the fourteen-generated-record-family model;
- change any of the 946 negative cases or their expectations;
- change any of the 137 contradiction-regression cases or their expectations;
- change documentary-validator semantics;
- create a current schema subject;
- execute product process-self-test;
- execute product construct mode;
- construct a target-audit harness;
- run a target audit;
- rerun runtime validation;
- modify a repository;
- qualify the product;
- authorize A6.

Do not modify, resume, clean, finish, or retry the failed implementation root.
Do not modify or resume either removed rehearsal.
Do not promote a failed or rehearsal artifact as current package evidence.
Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one fresh repair-package root.

At most two repaired source attempts are permitted before source freeze.

After source freeze:

- source modification is forbidden;
- complete rehearsals may not be rerun with different source bytes;
- no current schema subject may be constructed in this task.

Return the complete operative report inline.

Return exactly one primary verdict:

SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_EVIDENCE_OWNERSHIP_REPAIRED_QUALIFIED_FROZEN

SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_EVIDENCE_OWNERSHIP_REPAIR_BLOCKED

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. BLOCKED CLEAN IMPLEMENTATION PACKAGE
──────────────────────────────────────────────────────────────────────────────

BLOCKED_IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-clean-reconstruction-parent-2e9xutl_

Expected identity:

- device:
  16777234
- inode:
  180758397
- mode:
  0700
- verdict:
  SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED

Authenticate through its retained opening, source-attempt, validation,
rehearsal, closing, and report records.

Expected Candidate 003 production parent:

source/reconstruction_parent_v1.py

- inode:
  180774529
- mode:
  0600
- size:
  26544
- SHA-256:
  3e8e44979631fd93480ad03439b34bae6d04f0b0e342b0f322b428f1fa54d466

Expected Candidate 003 qualification harness:

validation/qualification_harness_v1.py

- inode:
  180778346
- mode:
  0600
- size:
  100523
- SHA-256:
  a687ba650953184bbf82d37a6deae57a079a16fef3fe58499f258c41c2689c2f

Authenticate the complete Candidate 003 source registries rather than relying
only on these two identities.

Expected production files:

- reconstruction_parent_v1.py
- process_recorder_v1.py
- strict_json_v1.py
- json_observation_v1.py
- supplied_root_inventory_v1.py
- manifest_projection_a_v1.py
- manifest_projection_b_v1.py
- schema_engine_v1.py
- subject_model_v1.py

Expected qualification files:

- qualification_harness_v1.py
- independent_external_interface_validator_v1.py
- independent_negative_matrix_validator_v1.py
- independent_schema_subject_validator_v1.py
- independent_process_custody_validator_v1.py
- independent_rehearsal_validator_v1.py
- terminal_manifest_reprojector_v1.py

Authenticate:

- clean-room source authority;
- operating model;
- source architecture;
- external-interface contract;
- special-case contract;
- total JSON-observation contract;
- artifact plan;
- all six component matrices;
- Candidate 003 static result;
- rehearsal A process/child records;
- exact collision;
- rehearsal A failure closeout;
- rehearsal cleanup;
- supplied-root closing equality;
- implementation-package status;
- explicit confirmations.

Classify Candidate 003 as:

clean_room_candidate_003_blocked_repair_base

It is:

- clean-room rather than V1–V4-derived;
- noncurrent;
- nonauthoritative;
- not frozen;
- eligible only as the exact bounded repair base defined here.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. HISTORICAL LINEAGE AND STOP AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Authenticate, read-only:

V4 failed root:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-fresh-subject-v4-p8f620pt

Expected identity:

- device/inode:
  16777234 / 180737457
- mode:
  0700
- incremental_repair_lineage_exhausted:
  true
- clean_parent_implementation_required:
  true

Terminal historical reconciliation:

/Users/ds/Downloads/ES-repair10i-v3-final-subject-p06-p18-reconciliation-v4j7a04y

Expected identity:

- device/inode:
  16777234 / 180632969
- mode:
  0700
- verdict:
  FINAL_SUBJECT_SCHEMA_P06_P18_RECONCILIATION_STOP_AND_RECONSTRUCT
- further historical reconciliation authorized:
  false

V1–V3 roots need be opened only if required to authenticate the lineage already
bound by the blocked clean implementation package.

Do not inspect them to derive implementation source.

Require complete opening/closing equality for every historical root opened.

──────────────────────────────────────────────────────────────────────────────
3. AUTHORITATIVE CONTRACT, SCHEMA, AND VALIDATION INPUTS
──────────────────────────────────────────────────────────────────────────────

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected identity:

- device/inode:
  16777234 / 180472094
- mode:
  0700

Authoritative normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected identity:

- device/inode:
  16777234 / 180513083
- mode:
  0700

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected identity:

- device/inode:
  16777234 / 180480821
- mode:
  0700

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected identity:

- device/inode:
  16777234 / 180576497
- mode:
  0700

Use these roots as authority for:

- normative-contract bytes;
- exact fifteen schema bytes;
- exact 15/14 role semantics;
- validation case registries;
- documentary-validator role semantics;
- confirmation-evidence semantics;
- accepted evidence lifecycle and DAG specification.

Do not copy historical result files as fresh results.

Require complete opening/closing equality for every supplied root opened.

──────────────────────────────────────────────────────────────────────────────
4. FRESH REPAIR-PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-schema-subject-clean-parent-evidence-ownership-repair-

Immediately emit:

REPAIR_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- blocked implementation-package identity;
- Candidate 003 source registries;
- exact collision path;
- exact rehearsal failure;
- exact partial-inventory retention gap;
- V4 stop authority;
- terminal historical decision;
- contract/schema/validation authorities;
- bounded clean-candidate repair authority;
- V1–V4 production-source reuse authority:
  false;
- contract change authority:
  false;
- schema change authority:
  false;
- validator semantic change authority:
  false;
- current subject construction authority:
  false;
- target audit authority:
  false;
- runtime validation authority:
  false;
- same-root retry:
  false.

Create directories lazily.
Do not retain empty directories except a lifecycle-permitted reserved
`manifest/` directory during terminal closure.

──────────────────────────────────────────────────────────────────────────────
5. EXACT COLLISION REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before editing source, reproduce the exact Candidate 003 collision from
authenticated source and rehearsal evidence.

Retain:

analysis/confirmation-validator-double-writer-reproduction-v1.json

Bind:

- exact path:
  validation/confirmation-evidence-map-validator-v1.json;
- artifact-plan row;
- declared owner;
- first writing stage;
- first writing function;
- first write operation;
- first written identity;
- second writing stage;
- second writing function;
- second write operation;
- exclusive-create flags;
- exception type;
- exception message;
- exact source ranges;
- exact process/child context;
- first blocker;
- downstream stages not reached.

Answer explicitly:

1. Did the first writer create a semantically final validator result?
2. Did it create a placeholder, staged result, or premature final result?
3. Did the second writer intend to regenerate identical bytes or different
   bytes?
4. Which stage is the contractually correct sole writer?
5. Which stage should only declare, schedule, reference, or consume the result?
6. Did the artifact plan distinguish parent ownership from phase/function
   ownership?
7. Did any accepted validation specification require two writes?
8. Does correcting the collision change validator semantics?

Classification must be one of:

IMPLEMENTATION_STAGE_OWNERSHIP_DEFECT
IMPLEMENTATION_EVIDENCE_LIFECYCLE_DEFECT
ARTIFACT_PLAN_WRITER_GRANULARITY_DEFECT
MIXED_IMPLEMENTATION_OWNERSHIP_DEFECT
EVIDENCE_INSUFFICIENT

If indispensable evidence is unavailable, return the blocked verdict.

Do not infer the correct lifecycle merely from path names.

──────────────────────────────────────────────────────────────────────────────
6. EXACT DOCUMENTARY-EVIDENCE LIFECYCLE
──────────────────────────────────────────────────────────────────────────────

Derive the lifecycle from the normative contract, validation specifications,
the accepted ten-role model, and the authenticated evidence DAG.

Retain:

contract/documentary-evidence-lifecycle-v1.json

Freeze every lifecycle stage in exact order.

At minimum distinguish:

1. stable validator source/mechanism identities;
2. the nine prerequisite documentary-validator results, excluding the
   confirmation-evidence-map validator;
3. any path-based confirmation map inputs;
4. any explicitly nonauthoritative staging state, when the accepted
   specification requires one;
5. confirmation evidence map;
6. confirmation-evidence-map validator result;
7. final ten-role documentary-validator registry;
8. documentary-validator regeneration result;
9. confirmation derivation;
10. independent validation;
11. explicit confirmations;
12. report and package status;
13. temporal inventory and terminal manifests.

For every stage bind:

- prerequisites;
- produced paths;
- consumed paths;
- authoritative writer component;
- authoritative writer function;
- write count;
- create semantics;
- authority before and after the stage;
- failure behavior;
- retry behavior;
- downstream consumers.

Required invariant:

validation/confirmation-evidence-map-validator-v1.json

has:

- exactly one writer component;
- exactly one writer function;
- exactly one exclusive-create event;
- no placeholder write;
- no reservation write;
- no overwrite;
- no regeneration;
- no adoption of a preexisting file.

The final ten-role registry may be written only after all ten current results
exist and authenticate.

The regeneration result must be derived from the final ten-role registry, not
from an expected constant.

Explicit confirmations must be derived downstream from retained evidence.

If the accepted specifications create an actual dependency cycle, return the
blocked verdict. Do not break a cycle by inventing authority.

──────────────────────────────────────────────────────────────────────────────
7. PHASE/FUNCTION/PATH WRITER REGISTRY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/phase-function-path-writer-registry-v1.json

For every mutable implementation-package and rehearsal-subject path bind:

- path or bounded path template;
- artifact role;
- phase;
- component;
- function;
- write operation;
- maximum successful write count;
- creation posture;
- whether content is staged or final;
- prerequisites;
- consumers.

Require:

- exactly one successful writer tuple per final path;
- no two phases own the same final path;
- no two functions own the same final path;
- no final path is both staged and final under one pathname;
- no successful overwrite;
- no implicit parent-wide writer ownership;
- dynamic paths have one bounded owner template;
- terminal manifests are owned by their exact manifest writers only;
- temporal inventory has one owner;
- failure outcome has one owner;
- partial inventory has one owner.

Crosswalk every source-level write site to this registry.

Unknown write site or unregistered output is a blocker.

──────────────────────────────────────────────────────────────────────────────
8. ONE-WRITER MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/phase-function-path-writer-matrix-v1.json

Cover at minimum:

1. Exact confirmation-validator lifecycle.
2. Documentary stage writes validator result prematurely.
3. Confirmation stage writes validator result exactly once.
4. Two phases write the same final path.
5. Two functions in one phase write the same final path.
6. Same function writes final path twice.
7. Placeholder then final under same path.
8. Staged file under distinct staging path.
9. Preexisting final path.
10. Final path adopted rather than created.
11. Second write with identical bytes.
12. Second write with different bytes.
13. Missing writer.
14. Unregistered writer.
15. Dynamic result path owned by two templates.
16. Final ten-role registry written before all results exist.
17. Final ten-role registry written after all results exist.
18. Regeneration record hard-codes role count.
19. Regeneration record derives role count from registry.
20. Confirmation result omitted from final registry.
21. Duplicate validator role.
22. Duplicate validator result path.
23. Confirmation-map validator self-validates its own result.
24. Confirmation cycle.
25. Exact Candidate 003 failure baseline.
26. Corrected baseline.

Require:

- twenty-six unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

──────────────────────────────────────────────────────────────────────────────
9. FAILURE PARTIAL-INVENTORY CUSTODY
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/failed-rehearsal-evidence-custody-v1.json

On rehearsal failure, require this order:

1. stop dependent work;
2. reap every child;
3. close every descriptor;
4. retain the exact first blocker;
5. generate complete no-follow partial-root inventory;
6. retain the inventory inside the rehearsal root;
7. copy or regenerate a byte-authenticated inventory record inside the
   implementation package;
8. bind rehearsal root identity, inventory identity, and failure record;
9. retain complete process ledger and stream identities;
10. retain cleanup eligibility and ownership;
11. only after all indispensable evidence is safely retained, remove the exact
    rehearsal root;
12. observe ENOENT twice;
13. retain the removal/absence record.

The implementation package must retain enough evidence to independently
authenticate the removed rehearsal’s partial state without the rehearsal root.

Do not treat a path to a subsequently removed inventory as retained evidence.

──────────────────────────────────────────────────────────────────────────────
10. FAILURE-CUSTODY MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/failed-rehearsal-evidence-custody-matrix-v1.json

Cover at minimum:

1. Failure before any rehearsal artifact.
2. Failure after one artifact.
3. Failure after documentary results.
4. Failure after partial inventory.
5. Inventory created but not copied before root removal.
6. Inventory copied and authenticated before removal.
7. Root removed before process ledger retention.
8. Child survivor.
9. Descriptor survivor.
10. Cleanup failure.
11. One ENOENT only.
12. Root identity changes before removal.
13. Failure record omits first blocker.
14. Stream identity missing.
15. Exact Candidate 003 evidence gap.
16. Corrected failure closeout baseline.

Require zero false outcomes and zero skips.

──────────────────────────────────────────────────────────────────────────────
11. BOUNDED SOURCE REPAIR
──────────────────────────────────────────────────────────────────────────────

Copy the authenticated Candidate 003 source registries into the fresh repair
root as the bounded repair base.

Use:

- no-follow stable reads;
- exclusive mode-0600 writes;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison before edits.

Retain original copies separately from working repaired candidates.

Permitted touched source files are only those proven by the collision and
failure-custody crosswalk.

Expected candidate surfaces may include:

- source/reconstruction_parent_v1.py;
- validation/qualification_harness_v1.py;
- any dedicated documentary-evidence writer module, if one owns the collision;
- any dedicated failure-finalization module, if one owns the inventory gap.

Do not authorize changes merely because a source file is convenient.

Repair ownership:

clean-reconstruction-parent-documentary-evidence-single-writer-and-failure-custody

Authorized changes:

A. Documentary evidence lifecycle

- remove the premature or duplicate write;
- assign one exact writer for the confirmation-validator result;
- enforce lifecycle prerequisites;
- generate final registry only after ten results exist;
- derive regeneration from final registry;
- preserve validator semantics and role set.

B. Writer enforcement

- source-level writes must resolve through the writer registry;
- reject second successful writes;
- reject unregistered writes;
- preserve exclusive-create posture.

C. Failure evidence custody

- retain partial inventory and failure evidence before root deletion;
- copy/authenticate indispensable evidence into the implementation package;
- preserve double-ENOENT cleanup after retention.

D. Fresh-root bindings

- regenerate only fresh-root-bound paths and identities.

Unauthorized changes:

- normative-contract bytes or meaning;
- any schema byte;
- fifteen-role set;
- fourteen-family set;
- 946 registry or expectations;
- 137 registry or expectations;
- witness semantics;
- field-map semantics;
- documentary-validator semantic roles;
- confirmation semantics;
- manifest grammar;
- terminal authority;
- product implementation authority.

Retain:

analysis/candidate-003-to-repaired-source-delta-v1.json

For every changed hunk bind:

- source file;
- old range;
- new range;
- exact defect;
- behavior before;
- behavior after;
- contract effect:
  none;
- schema effect:
  none;
- validation semantic effect:
  none.

Require every unrelated function AST-identical.

──────────────────────────────────────────────────────────────────────────────
12. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete repaired source attempts are permitted.

For every attempt retain:

- complete production source registry;
- complete qualification source registry;
- compilation;
- static checks;
- focused matrices;
- complete rehearsal result when reached;
- first blocker;
- supersession disposition.

A source attempt becomes complete when the source registry closes and
compilation begins.

If attempt 2 does not pass every prefreeze gate:

- return the blocked verdict;
- do not create attempt 3;
- do not recommend another localized repair in the inline report.

──────────────────────────────────────────────────────────────────────────────
13. STATIC AND OWNERSHIP GATES
──────────────────────────────────────────────────────────────────────────────

For each repaired attempt:

1. Compile all source with pinned Python `-I -S -B`.

2. Require exit `0` and empty stderr.

3. Run AST/call-graph/dataflow review.

4. Run bytecode/exception-table/CFG review.

5. Crosswalk every filesystem write site to the writer registry.

6. Crosswalk every documentary evidence stage to the lifecycle.

Require:

- no unregistered write;
- no path with multiple writer tuples;
- no successful second write;
- no overwrite;
- no preexisting-result adoption;
- exact ten validator roles;
- confirmation-validator result has one writer;
- final registry written after all ten results exist;
- regeneration derived from registry;
- explicit confirmations evidence-derived;
- failed-rehearsal evidence retained before cleanup;
- finite parent;
- no stdin read;
- no persistent loop;
- all child launches through one recorder;
- no network;
- no Git;
- no shell;
- no repository/product/target operation;
- no import-time behavior;
- no production-reachable qualification hook;
- no filesystem operation after terminal seal.

A static aggregate cannot pass while any required field is false.

──────────────────────────────────────────────────────────────────────────────
14. REGRESSION PRESERVATION
──────────────────────────────────────────────────────────────────────────────

Rerun unchanged:

- external-interface matrix;
- JSON-observation matrix;
- schema/family matrix;
- cleanup/process matrix;
- negative-checker robustness matrix;
- manifest/terminal matrix.

Require exact semantic closure against Candidate 003’s passing case registries.

Rerun independent validators for those lanes.

No regression result may bind a superseded source identity.

──────────────────────────────────────────────────────────────────────────────
15. DOCUMENTARY-LIFECYCLE INTEGRATION TEST
──────────────────────────────────────────────────────────────────────────────

Before full rehearsal, execute an isolated complete documentary-evidence
lifecycle in a disposable fixture root.

Require production-order execution of:

1. nine prerequisite documentary-validator results;
2. confirmation evidence map;
3. confirmation-evidence-map validator result;
4. final ten-role registry;
5. regeneration result;
6. confirmation derivation;
7. independent validation;
8. explicit confirmations.

Retain:

validation/documentary-evidence-lifecycle-integration-v1.json

Require:

- exact ten roles;
- ten distinct result paths;
- each result created once;
- confirmation-validator result created once;
- zero collisions;
- zero overwrite;
- final registry after all results;
- regeneration derived from registry;
- evidence DAG acyclic;
- explicit confirmations evidence-derived;
- no missing or extra output.

Independently validate this fixture without importing production helpers.

Remove the fixture and observe ENOENT twice after evidence retention.

──────────────────────────────────────────────────────────────────────────────
16. COMPLETE REHEARSAL A
──────────────────────────────────────────────────────────────────────────────

Allocate:

ES-repair10i-v3-clean-reconstruction-repair-rehearsal-a-

Run the exact repaired production parent through the full intended schema
subject reconstruction pipeline.

Require completion of:

- fixed-input authentication;
- artifact-plan enforcement;
- contract copy;
- fifteen-schema copy;
- fifteen-role registry;
- fourteen-family authority;
- schema/family mapping;
- metaschema validation;
- fresh family reconstruction;
- contract witnesses;
- schema witnesses;
- all 946 negative cases;
- all 137 contradiction-regression cases;
- 766/333 field map;
- ten documentary-validator results;
- final ten-role registry;
- evidence DAG;
- independent schema validator;
- confirmation evidence;
- explicit confirmations;
- current-role occupancy;
- package status;
- historical lineage;
- supplied-root equality;
- cleanup;
- temporal inventory;
- manifests;
- independent final reprojection;
- terminal physical posture;
- no write after seal.

Required status:

rehearsal-passed-nonauthoritative

──────────────────────────────────────────────────────────────────────────────
17. COMPLETE REHEARSAL B
──────────────────────────────────────────────────────────────────────────────

Allocate:

ES-repair10i-v3-clean-reconstruction-repair-rehearsal-b-

Run the same exact repaired source bytes, argv shape, environment, and inputs.

Require the same complete pipeline.

Retain:

validation/two-complete-repaired-rehearsals-v1.json

Normalize only explicitly physical values:

- rehearsal-root path;
- root device/inode;
- root-bound identities;
- PIDs;
- nonacceptance-bearing timestamps;
- other explicitly listed physical bindings.

Require semantic equality for:

- contract;
- schemas;
- 15/14 registries;
- mapping;
- witnesses;
- all 946 results;
- all 137 results;
- field-map rows;
- ten-role registry;
- all validator results;
- confirmation semantics;
- occupancy;
- status;
- normalized terminal manifests.

Require zero unexplained normalized difference.

──────────────────────────────────────────────────────────────────────────────
18. INDEPENDENT REHEARSAL VALIDATION
──────────────────────────────────────────────────────────────────────────────

Run an independently written validator against both rehearsal roots.

It must not import production modules or producer helpers.

Require independent validation of:

- planned membership;
- no unplanned output;
- exact contract and schemas;
- 15/14 closure;
- 946/137 closure;
- field-map closure;
- ten-validator closure;
- one-writer posture;
- confirmation result single creation;
- confirmation evidence;
- occupancy;
- supplied-root equality;
- cleanup;
- temporal inventories;
- manifests;
- final reprojections;
- normalized determinism.

Require zero errors.

If this validator throws while inspecting invalid fixture data, the source
attempt fails.

──────────────────────────────────────────────────────────────────────────────
19. REHEARSAL EVIDENCE RETENTION AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing either rehearsal:

- retain complete physical inventories;
- retain terminal identities;
- retain normalized comparison;
- retain independent validation;
- retain complete child/process ledgers;
- retain failure evidence when any.

Copy or regenerate indispensable evidence into the repair package and verify it
before removal.

Then:

- remove exact rehearsal A;
- observe ENOENT twice;
- remove exact rehearsal B;
- observe ENOENT twice;
- require zero process survivors;
- require zero descriptor survivors;
- require zero cache/bytecode survivors.

No rehearsal output becomes current implementation-package authority except
its retained qualification evidence.

──────────────────────────────────────────────────────────────────────────────
20. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze production and qualification source registries only after:

- collision reproduction;
- evidence lifecycle contract;
- writer registry;
- one-writer matrix;
- failure-custody contract and matrix;
- source repair;
- static/ownership gates;
- regression preservation;
- lifecycle integration fixture;
- rehearsal A;
- rehearsal B;
- normalized equality;
- independent rehearsal validation;
- rehearsal cleanup.

Retain:

opening/repaired-clean-reconstruction-parent-source-freeze-v1.json

Bind:

- exact final production source registry;
- exact final qualification source registry;
- Candidate 003 lineage;
- exact source delta;
- evidence lifecycle;
- writer registry;
- all matrices;
- both rehearsals;
- independent rehearsal result;
- cleanup;
- supplied-input identities;
- later modification permitted:
  false;
- current subject construction performed:
  false.

Reopen every source no-follow and verify identity.

No source modification afterward.

──────────────────────────────────────────────────────────────────────────────
21. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source bytes, rerun:

- compilation;
- static and ownership gates;
- writer matrix;
- failure-custody matrix;
- regression matrices;
- documentary-lifecycle integration in a disposable fixture;
- source/rehearsal identity linkage;
- supplied-root equality.

Do not rerun the two complete rehearsals.

Require proof that the exact bytes frozen are the bytes used in both passing
rehearsals.

Retain:

validation/frozen-repaired-clean-parent-requalification-v1.json

──────────────────────────────────────────────────────────────────────────────
22. IMPLEMENTATION-PACKAGE STATUS
──────────────────────────────────────────────────────────────────────────────

Generate a preterminal status record with:

- status:
  clean-reconstruction-parent-repaired-qualified-pending-independent-audit;
- implementation authority:
  schema-subject reconstruction tooling only;
- current subject constructed:
  false;
- independent audit of this implementation package completed:
  false;
- one-shot schema-subject reconstruction authorized:
  false;
- product implementation present:
  false;
- process-self-test executed:
  false;
- construct mode executed:
  false;
- target audit executed:
  false;
- runtime validation rerun:
  false.

Do not claim readiness for authoritative one-shot use until a later independent
audit accepts this repaired implementation package.

──────────────────────────────────────────────────────────────────────────────
23. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened:

- blocked clean implementation package;
- V4 stop-authority root;
- terminal historical reconciliation;
- authoritative contract package;
- schema source package;
- schema reconciliation root;
- validation-specification source;
- any additional historical root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every repair-owned fixture/cache root:

- retain complete pre-removal inventory;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
24. REPAIR-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

After all nonmanifest artifacts are final:

1. Generate and verify temporal inventory.
2. Ensure reserved `manifest/` exists.
3. Exclusively create zero-length manifest A and B before either projection.
4. Retain both descriptors.
5. Fsync both and the manifest directory.
6. Generate A and B independently with both paths excluded.
7. Require generated bytes identical.
8. Write through retained descriptors.
9. Fsync and close both.
10. Fsync manifest directory.
11. Reopen no-follow.
12. Verify path/inode/type/mode/link/size/hash.
13. Require A equals B.
14. Independently reproject the final root.
15. Require root row present exactly once.
16. Require no empty descendant.
17. Require no symlink, special object, or multiply linked file.
18. Require all modes `0700/0600`.
19. Require no cache/bytecode.
20. Transition terminal seal once.
21. After seal, permit only guarded terminal output and immediate nonreturning
    exit.
22. Perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
25. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On any failure retain:

- source attempt;
- exact first blocker;
- structured exception;
- process/child ledger;
- complete partial inventory;
- copy of indispensable failed-root evidence inside the repair package before
  root deletion;
- fixture/cache cleanup;
- process/descriptor survivors;
- supplied-root equality;
- implementation-package authority false;
- same-root retry false.

Do not create success manifests on failure.

Failure to complete cleanup or supplied-root equality is:

IMPLEMENTATION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
26. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_EVIDENCE_OWNERSHIP_REPAIRED_QUALIFIED_FROZEN

only when:

- collision is causally reproduced;
- lifecycle and writer registry close;
- one-writer matrix passes;
- failure-custody matrix passes;
- source repair is bounded;
- all regression lanes pass;
- documentary-lifecycle integration passes;
- both complete rehearsals pass;
- normalized rehearsal equality passes;
- independent rehearsal validation passes;
- rehearsal evidence is retained before cleanup;
- rehearsal cleanup passes;
- source freeze passes;
- frozen-source requalification passes;
- current subject remains unconstructed;
- supplied roots close equal;
- repair package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_EVIDENCE_OWNERSHIP_REPAIR_BLOCKED

when:

- correct sole writer cannot be established;
- evidence lifecycle is cyclic or ambiguous;
- repair cannot be bounded within two attempts;
- either complete rehearsal fails;
- independent rehearsal validation fails;
- normalized results diverge;
- repair requires changing contract, schema, or validation semantics.

Return:

IMPLEMENTATION_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- source drift after freeze;
- unregistered process or filesystem effect;
- indispensable failure evidence lost before cleanup;
- cleanup inequality;
- supplied-root closing inequality;
- repair-package closure failure;
- postseal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
27. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-root identity
3. Blocked clean implementation identity and closure
4. Candidate 003 production/qualification source identities
5. V4 and terminal historical authorities
6. Contract/schema/validation input identities
7. Exact collision reproduction
8. First and second writer crosswalk
9. Correct sole-writer adjudication
10. Documentary-evidence lifecycle
11. Phase/function/path writer registry
12. One-writer matrix
13. Failure partial-inventory custody adjudication
14. Failure-custody matrix
15. Source-attempt ledger
16. Final repaired production-source registry
17. Final repaired qualification-source registry
18. Exact bounded source delta
19. Compilation/static/ownership gates
20. Regression preservation
21. Documentary-lifecycle integration result
22. Rehearsal A complete result
23. Rehearsal B complete result
24. Normalized rehearsal comparison
25. Independent rehearsal-validator result
26. Rehearsal evidence retention
27. Rehearsal cleanup
28. Source freeze
29. Frozen-source requalification
30. Confirmation current subject was not constructed
31. Implementation-package status
32. Supplied-root closing equality
33. Fixture/cache cleanup
34. Failure-closeout capability and usage
35. Temporal-inventory identity
36. Manifest A identity
37. Manifest B identity
38. Independent terminal reprojection
39. Terminal membership and modes
40. No-write-after-closure
41. Remaining uncertainty and nonclaims
42. Explicit confirmation registry

Required confirmations:

BLOCKED_CLEAN_IMPLEMENTATION_ROOT_MUTATION_NOT_PERFORMED
BLOCKED_CLEAN_IMPLEMENTATION_ROOT_NOT_RESUMED
CANDIDATE_003_SOURCE_REGISTRIES_AUTHENTICATED
V4_STOP_AUTHORITY_AUTHENTICATED
TERMINAL_HISTORICAL_DECISION_AUTHENTICATED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
CONFIRMATION_VALIDATOR_DOUBLE_WRITER_CAUSAL_REPRODUCED
CORRECT_SOLE_WRITER_IDENTIFIED
DOCUMENTARY_EVIDENCE_LIFECYCLE_FROZEN
CONFIRMATION_VALIDATOR_RESULT_CREATED_EXACTLY_ONCE
FINAL_TEN_ROLE_REGISTRY_CREATED_AFTER_ALL_RESULTS
DOCUMENTARY_REGENERATION_DERIVED_FROM_FINAL_REGISTRY
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
PHASE_FUNCTION_PATH_WRITER_REGISTRY_COMPLETE
ONE_AUTHORITATIVE_WRITER_PER_MUTABLE_FACT
NO_UNREGISTERED_WRITE_SITE
NO_SUCCESSFUL_SECOND_WRITE
NO_OVERWRITE_OR_RESULT_ADOPTION
ONE_WRITER_MATRIX_PASSED
FAILED_REHEARSAL_PARTIAL_INVENTORY_RETAINED_BEFORE_REMOVAL
FAILED_REHEARSAL_PROCESS_LEDGER_RETAINED_BEFORE_REMOVAL
FAILED_REHEARSAL_EVIDENCE_CUSTODY_MATRIX_PASSED
SOURCE_ATTEMPT_LIMIT_RESPECTED
REPAIR_BOUNDED_TO_EVIDENCE_OWNERSHIP_AND_FAILURE_CUSTODY
NORMATIVE_CONTRACT_BYTES_UNCHANGED
ALL_FIFTEEN_SCHEMA_BYTES_UNCHANGED
FIFTEEN_SCHEMA_ROLE_SET_UNCHANGED
FOURTEEN_GENERATED_FAMILY_SET_UNCHANGED
NEGATIVE_CASE_REGISTRY_UNCHANGED
NEGATIVE_CASE_EXPECTATIONS_UNCHANGED
CONTRADICTION_REGISTRY_UNCHANGED
DOCUMENTARY_VALIDATOR_ROLE_SET_UNCHANGED
VALIDATOR_SEMANTICS_UNCHANGED
ALL_UNRELATED_FUNCTIONS_AST_IDENTICAL
PRODUCTION_SOURCES_COMPILED
QUALIFICATION_SOURCES_COMPILED
STATIC_AND_OWNERSHIP_GATES_PASSED
EXTERNAL_INTERFACE_MATRIX_STILL_PASSED
JSON_OBSERVATION_MATRIX_STILL_PASSED
SCHEMA_ROLE_FAMILY_MATRIX_STILL_PASSED
CLEANUP_PROCESS_MATRIX_STILL_PASSED
NEGATIVE_CHECKER_ROBUSTNESS_MATRIX_STILL_PASSED
MANIFEST_TERMINAL_MATRIX_STILL_PASSED
DOCUMENTARY_LIFECYCLE_INTEGRATION_PASSED
COMPLETE_REHEARSAL_A_PASSED
COMPLETE_REHEARSAL_B_PASSED
TWO_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_REHEARSAL_VALIDATOR_PASSED
REHEARSAL_EVIDENCE_RETAINED_BEFORE_CLEANUP
REHEARSAL_ROOTS_CLEANED
FINAL_SOURCE_REGISTRIES_FROZEN
FINAL_SOURCES_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_REQUALIFICATION_PASSED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_PACKAGE_PENDING_INDEPENDENT_AUDIT
ONE_SHOT_SCHEMA_SUBJECT_RECONSTRUCTION_NOT_YET_AUTHORIZED
PROCESS_SELF_TEST_NOT_EXECUTED
CONSTRUCT_MODE_NOT_EXECUTED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
REPAIR_PACKAGE_TEMPORAL_INVENTORY_CREATED
REPAIR_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
REPAIR_PACKAGE_MANIFEST_A_CREATED
REPAIR_PACKAGE_MANIFEST_B_CREATED
REPAIR_PACKAGE_MANIFESTS_BYTE_IDENTICAL
REPAIR_PACKAGE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After:

SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_EVIDENCE_OWNERSHIP_REPAIRED_QUALIFIED_FROZEN

the next tranche must be a fresh independent audit of the repaired
implementation package.

Only after that audit accepts may a separate one-shot task execute the frozen
parent to construct the current schema subject.

Construction-parent product implementation remains blocked until:

1. the current schema subject is constructed and terminally closed;
2. a freshly qualified P06/P18-corrected audit harness accepts it; and
3. no governing contract has reopened implementation authority.
```

**Source:** Codex’s `SCHEMA_SUBJECT_CLEAN_RECONSTRUCTION_PARENT_IMPLEMENTATION_BLOCKED` report in this turn.  
**Confidence:** 0.997 that the immediate defect is a bounded evidence-ownership/lifecycle bug; 0.99 that Candidate 003 is an appropriate clean repair base; 0.98 that an independent audit must precede authoritative one-shot use.
