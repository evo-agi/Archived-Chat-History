Here is Codex's response:

# Independent audit report

## 1. Verdict

**AUDIT\_PROVENANCE\_MISMATCH**

The one-file repair passed the substantive validator and compatibility checks. This audit run cannot qualify it: an audit-owned Python import created a bytecode file and directory inside the implementation worktree, changing its full object inventory from 477 to 479. Two auditors also made prohibited read-only accesses relative to the primary checkout. I left the repository artifact untouched because the request forbids repository cleanup.

## 2. Response format

This is the complete audit report inline. The links at the end provide supplemental records.

## 3. Exact target and identities

The target was `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1` on `codex/evidence-verification-v1`.

| IdentityObserved and expected value |                                                                                                                               |
| ----------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| HEAD                                | `567bceced5df95ecfe787cc66038d463a854e12c`                                                                                    |
| HEAD tree                           | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                                                                    |
| Sole parent                         | `05dde14d185b6e022dcc169ef1a658a97961850f`                                                                                    |
| Upstream                            | Absent                                                                                                                        |
| Canonical manifest SHA-256          | `4a3a42441632725c12dedbb13d6ab619f2b42677dde12a80c6efcc3025518537`                                                            |
| Tracked binary-diff SHA-256         | `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb`                                                            |
| Recipe SHA-256                      | `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`                                                            |
| Pinned interpreter                  | Python 3.13.4; regular, single-link, 119424 bytes; SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b` |

The current 13-path manifest differs from the prior audit’s manifest in exactly one row: [test\_verify\_v1.py](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/test_verify_v1.py>) changed from 83542 bytes, SHA-256 `f1fd7795343cfb3fd447280071d87cdf42e5f53d9bee0210e437e8d86cc4b4ea`, to 88127 bytes, SHA-256 `a106fe923440e4f2b24a7a425f994aa935eaaa9ffb7a68925987c8444df9b568`. The tracked diff is unchanged from that prior manifest.

## 4. Opening and closing provenance

The required audit root was absent at opening. Opening checks matched the repository identity, 13 manifest rows, recipe and caller bytes, implementation evidence inventory, prior TV-01 causal, and sealed A6D and amendment manifests. Both opening executions of the exact recipe exited 0 with empty stderr; their stdout and manifest files were byte-identical to the expected manifest.

Both closing recipe executions also exited 0 with empty stderr and reproduced that same manifest and tracked diff. Git still reported exactly 13 patch paths because the new bytecode is ignored. A separate complete repository-object comparison found the disqualifying closing mismatch:

| Full worktree inventoryResult       |                                                                                                                                                                                                                                                                                   |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Implementation baseline             | 477 objects                                                                                                                                                                                                                                                                       |
| Closing audit                       | 479 objects                                                                                                                                                                                                                                                                       |
| Added directory                     | `tools/evidence_verify/__pycache__`, mode 0755                                                                                                                                                                                                                                    |
| Added file                          | [test\_verify\_v1.cpython-313.pyc](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/__pycache__/test_verify_v1.cpython-313.pyc>), mode 0644, 150793 bytes, SHA-256 `1e57088f5455ea8bdeb59a95c208d665a70acf2248a7c313c64fb78c16ca4b42` |
| Removed or changed baseline objects | None                                                                                                                                                                                                                                                                              |

The file’s timestamp coincides with my audit-owned import of the test module without bytecode suppression. That was a repository mutation. The exact 13 manifest files and all supplied evidence bytes remained unchanged, but the required full repository and artifact state did not.

## 5. Repository scope

At opening and closing, Git showed four modified tracked paths and nine untracked paths, with no staged, deleted, renamed, or unmerged path. Every listed path was a regular, single-link file with working mode 0644 and logical mode `100644`.

| Path relative to targetBytesSHA-256                                       |        |                                                                    |
| ------------------------------------------------------------------------- | ------ | ------------------------------------------------------------------ |
| `PLANS.md`                                                                | 221718 | `fb3b2590103af1db07f17eac8fbe9c9e65420fd9d2c7fc6a8ccf9e7510e72750` |
| `.docs/system_overview/boundaries.md`                                     | 65156  | `643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e` |
| `.docs/system_overview/artifact_hygiene.md`                               | 13721  | `1a3e570167ab7b2238a75d43f678e7121e226950d6202b9e17259317bf5ce1c5` |
| `.docs/system_overview/capability_probing.md`                             | 10039  | `3333ea9b3c618ae95110273041396a2d7482891fac01b9d29e6b1609a2124d63` |
| `.docs/system_overview/evidence_verification.md`                          | 18599  | `fc7d485728b8ba2815ae7a9f3e21b0859f0e35ba28083ba355a64047857f5875` |
| `tools/evidence_verify/verify_v1.py`                                      | 40121  | `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c` |
| `tools/evidence_verify/test_verify_v1.py`                                 | 88127  | `a106fe923440e4f2b24a7a425f994aa935eaaa9ffb7a68925987c8444df9b568` |
| `tools/evidence_verify/registry_v1.json`                                  | 585    | `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880` |
| `tools/evidence_verify/layouts/a6d_successor_v1.json`                     | 892    | `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc` |
| `tools/evidence_verify/layouts/a6d_amendment_v1.json`                     | 856    | `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4` |
| `tools/evidence_verify/layouts/a6_policy_v1.json`                         | 1015   | `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8` |
| `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt` | 3338   | `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98` |
| `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`  | 14418  | `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f` |

The ignored `__pycache__` objects are outside that manifest but inside the repository, so the 13-path Git result does not resolve the provenance mismatch.

## 6. Four distinct auditors

The first three started concurrently. The fourth started after the contract auditor completed. No start needed a retry; all four completed. None ran Git or created a nested subagent.

| Auditor IDRoleStatus       |                                          |                                                                        |
| -------------------------- | ---------------------------------------- | ---------------------------------------------------------------------- |
| `/root/contract_authority` | Contract and authority                   | Complete; disclosed a prohibited primary-checkout-relative read        |
| `/root/marker_validator`   | Marker family and validator              | Complete; 16 independent causals                                       |
| `/root/test_adequacy`      | Tests and implementation evidence        | Complete; disclosed a second prohibited primary-checkout-relative read |
| `/root/security_artifacts` | Security, filesystem, process, artifacts | Complete; found the new bytecode objects                               |

The two read-only primary-checkout accesses ran no Git and changed no files. Section 3 of the request nevertheless makes *any* such access a current audit-process blocker. Four-instance completion closes the AP-06 scheduling requirement; it does not cure those accesses.

## 7. TV-01 repair

The prior TV-01 helper accepted a balanced `trusted-host-contract.v2` authority block in either the authority document or `PLANS.md`, including a claim of atomic binding. The current helper discovers markers across the entire `execution-substrate.evidence-verification.trusted-host-contract.` family before validating the exact v1 block. An audit-owned parser confirmed rejection of v2, v27, and the unlisted `future-review-17` identifier. TV-01 is substantively closed on the reviewed source bytes; this audit run cannot qualify the patch because of the provenance and process failures.

## 8. Family prefix and marker grammar

The helper matches literal HTML comments of the form `<!-- BEGIN ID -->` and `<!-- END ID -->`. `ID` must start with the full family prefix and continue with one or more characters excluding whitespace and angle brackets. It scans [evidence\_verification.md](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md>), `PLANS.md`, `artifact_hygiene.md`, and `capability_probing.md`. Prose containing the family string is not a marker. The scan is generic; it contains no finite list of alternate versions.

## 9. Validator invariants

The validator requires exactly those four input documents and exactly one complete family block globally. That block must be in `evidence_verification.md`, use the exact `.v1` ID, have matching BEGIN and END IDs, and be balanced without nesting or overlap. Any family block in a consumer rejects. It then checks the exact v1 fenced JSON: canonical one-line ASCII JSON plus LF, the 22 exact fields, field types and values, no duplicate, missing, or unknown keys, and one exact non-overriding reference in each consumer. No product or runtime authority is derived from the test helper.

## 10. Independent alternate-ID and location causals

An audit-owned parser, separate from test 89’s helper, and the subject validator agreed on all 16 cases. Balanced alternate blocks used complete contract-shaped canonical JSON, so identity and location caused their rejection.

| CaseObserved reason                      |                                                                                                                                                                          |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Live four-document set                   | Pass                                                                                                                                                                     |
| Balanced v2 in authority                 | `unauthorized_authoritative_contract_id:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v2`               |
| Balanced v27 in authority                | `unauthorized_authoritative_contract_id:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v27`              |
| Balanced v2 in `PLANS.md`                | `unauthorized_authoritative_block:PLANS.md:execution-substrate.evidence-verification.trusted-host-contract.v2`                                                           |
| Balanced v2 in `artifact_hygiene.md`     | `unauthorized_authoritative_block:.docs/system_overview/artifact_hygiene.md:execution-substrate.evidence-verification.trusted-host-contract.v2`                          |
| Balanced v2 in `capability_probing.md`   | `unauthorized_authoritative_block:.docs/system_overview/capability_probing.md:execution-substrate.evidence-verification.trusted-host-contract.v2`                        |
| Unlisted `future-review-17` in authority | `unauthorized_authoritative_contract_id:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.future-review-17` |

## 11. Mismatch, unbalanced, nesting, and overlap causals

| CaseObserved reason                     |                                                                                                                                                                                                                      |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| v2 BEGIN, v3 END                        | `authoritative_marker_mismatch:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v2:execution-substrate.evidence-verification.trusted-host-contract.v3` |
| Unmatched v2 BEGIN                      | `authoritative_marker_unbalanced:.docs/system_overview/evidence_verification.md`                                                                                                                                     |
| Unmatched v2 END                        | `authoritative_marker_unbalanced:.docs/system_overview/evidence_verification.md`                                                                                                                                     |
| Nested v2 block                         | `authoritative_marker_overlap:.docs/system_overview/evidence_verification.md`                                                                                                                                        |
| Overlapping v2 blocks                   | `authoritative_marker_overlap:.docs/system_overview/evidence_verification.md`                                                                                                                                        |
| Duplicate exact-v1 block                | `authoritative_section_count`                                                                                                                                                                                        |
| Unmarked family-prefix prose            | Pass                                                                                                                                                                                                                 |
| Unrelated HTML marker                   | Pass                                                                                                                                                                                                                 |
| Lookalike prefix lacking the family dot | Pass                                                                                                                                                                                                                 |

## 12. Original 31-case preservation

An audit-owned generator reconstructed the original 31 documentary contradictions without calling the producer mutation generator. All 31 rejected for their intended specific reasons. None degraded to an unrelated parse error.

## 13. Seven new producer cases

The seven added cases are `alternate_authoritative_contract_id`, `alternate_authoritative_block_in_consumer`, `alternate_authoritative_marker_mismatch`, `unmatched_alternate_authoritative_begin`, `unmatched_alternate_authoritative_end`, `nested_alternate_authoritative_block`, and `another_alternate_authoritative_contract_id`. All seven executed in test 89 and rejected for their intended reasons.

## 14. Audit-owned complete contradiction matrix

The live documents passed. All 38 independently constructed mutations rejected; each observed reason matched both the audit expectation and the implementation ledger.
```
01 atomic_loaded_object_binding_claimed=true => contract_value:atomic_loaded_object_binding_claimed
02 transient_trusted_principal_replacement_covered=true => contract_value:transient_trusted_principal_replacement_covered
03 shared_or_adversarial_host_supported=true => contract_value:shared_or_adversarial_host_supported
04 remotely_administered_hostile_host_supported=true => contract_value:remotely_administered_hostile_host_supported
05 production_host_attestation=true => contract_value:production_host_attestation
06 observation_authority=proof => contract_value:interpreter_observation_authority
07 installation_writers_untrusted => contract_value:all_interpreter_installation_writers_trusted
08 launcher_fallback_authorized => contract_value:undocumented_launcher_fallback_authorized
09 verifier_authority=readiness => contract_value:verifier_result_authority
10 verifier_authority=execution-authority => contract_value:verifier_result_authority
11 verifier_authority=commit-authority => contract_value:verifier_result_authority
12 scope_widened => contract_value:scope
13 wrong_contract_id => contract_value:schema
14 wrong_boolean_type => contract_type:operator_controlled_host_required
15 wrong_string_type => contract_type:scope
16 missing_field => contract_missing_key:scope
17 unknown_field => contract_unknown_key:undocumented_extra
18 duplicate_json_key => contract_duplicate_key:scope
19 duplicate_authoritative_block => authoritative_section_count
20 authoritative_block_in_consumer => unauthorized_authoritative_block:PLANS.md
21 wrong_consumer_contract_id => reference_contract_id:PLANS.md
22 missing_consumer_reference => reference:.docs/system_overview/artifact_hygiene.md_section_count
23 consumer_local_override => reference_local_override:.docs/system_overview/capability_probing.md
24 contradictory_authoritative_section_text => authoritative_section_content
25 contradictory_reference_section_text => reference_unexpected_content:PLANS.md
26 malformed_authoritative_marker => authoritative_section_count
27 malformed_contract_fence => contract_fence_structure
28 noncanonical_json => contract_noncanonical_json
29 duplicate_consumer_reference => reference:PLANS.md_section_count
30 wrong_consumer_writer => reference_writer:PLANS.md
31 consumer_overriding_declaration => reference_nonoverriding:PLANS.md
32 alternate_authoritative_contract_id => unauthorized_authoritative_contract_id:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v2
33 alternate_authoritative_block_in_consumer => unauthorized_authoritative_block:PLANS.md:execution-substrate.evidence-verification.trusted-host-contract.v2
34 alternate_authoritative_marker_mismatch => authoritative_marker_mismatch:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v2:execution-substrate.evidence-verification.trusted-host-contract.v3
35 unmatched_alternate_authoritative_begin => authoritative_marker_unbalanced:.docs/system_overview/evidence_verification.md
36 unmatched_alternate_authoritative_end => authoritative_marker_unbalanced:.docs/system_overview/evidence_verification.md
37 nested_alternate_authoritative_block => authoritative_marker_overlap:.docs/system_overview/evidence_verification.md
38 another_alternate_authoritative_contract_id => unauthorized_authoritative_contract_id:.docs/system_overview/evidence_verification.md:execution-substrate.evidence-verification.trusted-host-contract.v27
```

## 15. Three targeted test-89 runs

Each owning command exited 0, ran one test, had zero failure/error/skip, made 39 validator calls—one live set plus 38 mutations—and left its before/after repository snapshot unchanged. All three had stdout SHA-256 `9bbc04d8340f2c46b1da6708f46566436d00eb14bf3b4fa664e4c7cbff6e16a1` and stderr SHA-256 `b788ac40f9f3150e607168e1affc943f3ad43bf7fe50d44b3f1aa1195d388674`.

## 16. Exact 89-test set and four suites

The exact discovered set is the following 88 names prefixed by `test_verify_v1.ClosureCausals.`, plus `test_verify_v1.InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim`:
```
test_01_valid_preseal
test_02_valid_sealed
test_03_missing_manifest
test_04_missing_sidecar
test_05_wrong_sidecar
test_06_missing_payload
test_07_unexpected_payload
test_08_wrong_mode
test_09_wrong_size
test_10_wrong_hash
test_11_wrong_link_count
test_12_directory_mode
test_13_symlink_every_depth
test_14_special_every_depth
test_15_post_manifest_same_bytes
test_16_unknown_layout
test_17_wrong_registered_hash
test_18_missing_required_layout_entry
test_19_unexpected_layout_entry
test_20_stage_confusion
test_21_arbitrary_layout_option
test_22_readiness_not_interpreted
test_23_zero_writes
test_24_repeated_canonical_output
test_25_source_inside_target
test_26_own_container
test_27_independent_materialization
test_28_historical_defect
test_29_fourth_layout_without_verifier_edit
test_30_exact_closeout_identities
test_31_historical_amendment_exact_modes
test_32_closing_helper_0600_rejects
test_33_postseal_helper_0600_rejects
test_34_helper_other_modes_reject
test_35_unrelated_fixed_json_executable_rejects
test_36_unrelated_fixed_markdown_executable_rejects
test_37_unenumerated_executable_rejects
test_38_optional_executable_has_no_required_authority
test_39_other_layout_spec_bytes_unchanged
test_40_amendment_registry_hash_mismatch_rejects
test_41_physical_target_ancestry_and_aliases
test_42_physical_candidate_ancestry_and_aliases
test_43_literal_lf_preseal_rejections
test_44_literal_lf_sealed_rejections
test_45_json_depth_escapes_and_cli_failure
test_46_manifest_declared_budgets
test_47_scan_budgets_before_read
test_48_isolated_missing_root
test_49_expected_path_symlink_and_special
test_50_bounded_decimal_parser
test_51_capability_operation_failures_are_canonical
test_52_json_source_size_and_spec_failure
test_53_manifest_stat_caps_precede_body_read
test_54_manifest_stream_early_row_path_and_count_rejection
test_55_exact_maximum_count_and_path
test_56_seal_and_candidate_structural_budgets
test_57_sidecar_pre_read_size_and_exact_malformed_content
test_58_decimal_complete_lexical_classification
test_59_invalid_spec_paths_never_open_target
test_60_source_by_value_external_source_both_stages
test_61_direct_source_inside_target_both_stages
test_62_final_source_symlink_to_target_both_stages
test_63_parent_symlink_to_target_source_both_stages
test_64_hardlinked_source_to_target_both_stages
test_65_source_package_beneath_target
test_66_target_beneath_source_package
test_67_source_package_equals_target
test_68_case_alias_of_prohibited_source_relationship
test_69_source_identity_changes_before_close
test_70_source_disappears_before_close
test_71_unsupported_source_nofollow_or_parent_traversal
test_72_same_source_bytes_distinct_inode_admitted
test_73_external_source_with_symlinked_parent_rejects
test_74_relative_direct_script_invocation_rejects
test_75_final_symlink_to_external_source_rejects
test_76_direct_and_symlinked_script_launches_are_invocation_errors
test_77_stdin_and_dev_fd_launches_are_invocation_errors
test_78_missing_reordered_or_extra_application_arguments
test_79_extra_combined_or_reordered_interpreter_options
test_80_source_package_one_byte_mismatch_rejects
test_81_invalid_package_source_and_size_reject
test_82_captured_argv_survives_live_argv_mutation
test_83_package_source_replaced_after_argv_construction
test_84_unicode_source_round_trip_and_no_output_leak
test_85_no_package_source_authority_from_file_presence
test_86_closing_source_validation_failure_is_race
test_87_file_present_launch_state_rejects
test_88_missing_isolation_site_or_bytecode_flag_rejects
```

All four qualified owning commands used pinned Python with `-I -S -B`, ran 89 tests, had zero failure/error/skip, matched this identity set, and reported unchanged before/after repository snapshots:

| Umask and runExitStderr SHA-256 |   |                                                                    |
| ------------------------------- | - | ------------------------------------------------------------------ |
| 077, 1                          | 0 | `5dc7cac42f4e4a9edac94772b50b96a8a00571cc64d1e6ab4907f8ebe999d69d` |
| 077, 2                          | 0 | `df1360f1e42280491368fcfa9ced8a47e9c5395ee71e245ef03ac9da16987b68` |
| 022, 1                          | 0 | `61797c992440f7c9a8b733acbabeff118860fba5593321cacd0e64bff26f9fe2` |
| 022, 2                          | 0 | `58934f270d2fbb22629a21e72a006f6c83f346d4471686004f31a9a0543c1391` |

Each qualified stdout was empty, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. An earlier audit attempt omitted the required interpreter flags; its owning command exited 1 with 17 invocation-related failures. It is retained as failed and was not counted as qualified.

## 17. Unchanged governing, verifier, caller, and data inputs

The four governing documents, `boundaries.md`, [verify\_v1.py](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/verify_v1.py>), registry, three layouts, and two historical fixtures match the supplied exact bytes and the prior manifest. The source-external caller also remains at SHA-256 `002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104`.

Source review found no substantive trusted-host, launch-protocol, closure, or authority change in those inputs. Static gates parsed verifier, test, and both inert historical fixtures with `ast.parse`; parsed the registry and layouts as strict canonical JSON with their expected hashes; and found `git diff --check` clean.

## 18. Sealed A6D

Two audit-owned source-by-value launches exited 0 with empty stderr, canonical deterministic stdout SHA-256 `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`, and unchanged watched target, package, and TMPDIR snapshots. The sealed manifest stayed at SHA-256 `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`.

## 19. Sealed amendment

Two equivalent launches exited 0 with empty stderr and canonical deterministic stdout SHA-256 `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`. Watched snapshots and the sealed manifest, SHA-256 `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`, were unchanged.

## 20. Synthetic A6

The audit-owned fixture passed pre-seal twice with identical canonical stdout SHA-256 `2244434762225b0e380ff8ac68fea36a31347094a11b838684ff7eb28654870d`, then sealed twice with identical canonical stdout SHA-256 `a5527d15a34ccf4514245613a085a9f89731ca39a460f892ab009997e9291a2e`. All four exits were 0 with empty stderr and unchanged watched snapshots. The fixture was removed from the audit root. An initial fixture attempt sealed its files in the wrong order and received `POST_SEAL`; it is retained as a failed audit attempt and is not a verifier defect.

## 21. SEC-02

An audit-owned target-controlled script contained a marker-writing action. The source-by-value launch never executed that script or created its marker; the incomplete target rejected as `LAYOUT`, exit 4. A direct-script predecessor-shaped invocation of a trusted verifier copy rejected as `INVOCATION`, exit 2. Both outputs were canonical, stderr was empty, the target-controlled source stayed unchanged, and the fixture was removed. This does **not** claim atomic interpreter custody.

## 22. No-write and deterministic-output evidence

Each qualified targeted test, complete suite, and compatibility invocation had unchanged watched before/after snapshots. A6D, amendment, and synthetic A6 paired outputs were deterministic. The broader no-repository-write condition failed because my separate audit import created the ignored bytecode objects after those local checks. Supplied implementation evidence and sealed target manifests remained unchanged.

## 23. Implementation-evidence findings

The implementation inventory matches all 55 retained files excluding the inventory itself: exact size, SHA-256, mode 0600, and single-link status; evidence directories are mode 0700. Its vulnerable predecessor records show both copied-input v2 cases accepted. The repaired records use those same input copies and reject specifically by unauthorized ID or consumer location. The original 31 reasons and seven additions are complete. The implementation’s independent marker validator imports no test helper. Three final targeted and four qualified full runs are selected with successful owning commands; failed and superseded attempts remain separate. The implementation neither presents the prior audit as qualifying new test bytes nor falsely claims it reran compatibility.

## 24. Authority and artifact adjudication

The verifier remains an ES-owned `Bounded slice rule`. The trusted-host contract is private assurance material with one normative writer; its test validator and evidence records are non-authoritative. No reviewed input grants run truth, readiness, product, runtime, admission, orchestration, durable-state, commit, or publication authority, and no public product schema or cross-repository framework owner was introduced.

The artifact scan found no unsupported object or unexpected executable mode in the 13 patch paths. Baseline `.out` and example `dist` files were present in the implementation snapshot. The new `__pycache__` directory and `.pyc` file were not; they are the blocking current artifact drift.

## 25. Prior-finding closure

| FindingCurrent reconciliation          |                                                                                                                             |
| -------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| TV-01                                  | Generic family scan and independent v2, v27, and unlisted-ID causals close the source-level defect.                         |
| CT-01                                  | Governing contract and references remain coherent; current audit run is nonqualifying.                                      |
| AP-06                                  | Four distinct auditors completed in the required schedule.                                                                  |
| SEC-01, SEC-02                         | No regression in unchanged source; fresh SEC-02 causal passed.                                                              |
| VC-01 / SEC-A1                         | Supported-local trusted-host precondition and interpreter-observation limits remain explicit.                               |
| EV-01 through EV-08; F-01 through F-04 | No regression found in unchanged verifier, data, fixtures, or fresh compatibility checks.                                   |
| EV-09                                  | Historical audit-process issue is not treated as a new product defect; this run has its own disclosed process failures.     |
| PP-01                                  | Historical producer Git-process issue remains historical; current auditors ran no Git, and parent Git commands were rooted. |
| PE-02                                  | Evidence inventory and failed/qualified attempt selection matched.                                                          |
| TA-03                                  | The 38-case test and independent matrix retained specific rejection reasons.                                                |
| AP-04                                  | Failed owning attempts remain separate; four fresh qualified 89-test suites passed.                                         |
| AP-05                                  | Pathname snapshot observations remain a documented assurance limit.                                                         |
| CA-01                                  | Historical fixture portability edge is unchanged and outside this one-file repair.                                          |

## 26. Severity-ranked residual findings

1. **Blocking provenance and artifact mismatch:** the audit-created ignored bytecode directory and file make the full closing repository inventory 479 objects instead of 477. The request’s no-repository-mutation gate fails even though Git’s 13-path manifest replay passes.
2. **Blocking audit-process boundary:** `/root/contract_authority` and `/root/test_adequacy` each disclosed an initial read-only command relative to the forbidden primary checkout. Neither ran Git or changed files; the request explicitly blocks this access.
3. **Nonblocking assurance limits:** unmarked explanatory prose still requires document review, and interpreter pathname observations remain corroboration rather than atomic loaded-object custody.

No substantive defect was found in the exact one-file validator repair. The first full-suite invocation and first synthetic seal were audit-owned failed attempts and were superseded by the qualified runs reported above.

## 27. Minority findings and parent resolution

The marker auditor found the source repair sufficient to close TV-01. The contract and test auditors likewise found no substantive repair defect while explicitly reporting process violations. The security auditor found the new repository artifact. As parent auditor, I adopt the favorable source-level findings but cannot turn them into a qualifying audit: the closing full-inventory mismatch determines the stated verdict, and the primary-checkout accesses independently block a clean result.

## 28. Remaining uncertainty and nonclaims

This report does not claim atomic interpreter custody, hostile-host support, production attestation, product correctness, readiness, execution, commit fitness, or publication authority. Recipe-internal Git stdout and stderr hashes in the process ledger were inferred from the reviewed immutable recipe and matching parent-run mirror commands; the recipe subprocess did not expose each child stream separately. That limitation is disclosed rather than presented as direct per-child capture.

## 29. Audit-created paths and cleanup

The audit root is `/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1`, with `opening/`, `provenance/`, `perspectives/`, `validation/`, `findings/`, `closeout/`, and `tmp/`. It contains 59 audit files. Its `tmp/` is empty; the synthetic A6 and SEC-02 fixtures were removed. No supplied evidence was cleaned or altered. The two repository bytecode objects remain in place.

## 30. Complete Git-process record

Only the audit parent and its exact recipe subprocesses invoked Git. Every command used argv prefix `git -C "/Users/ds/Repositories/Execution Substrate - evidence-verification-v1"`, cwd equal to that same implementation worktree, and these explicitly supplied environment values:
```
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

The table maps **every one of the 66 ledger IDs** to exact remaining argv, exit, stdout SHA-256, and stderr SHA-256. `EMPTY` means the full SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

| Ledger IDsRemaining argvExitStdout SHA-256Stderr SHA-256 |                                                                             |     |                                                                    |                                                                    |
| -------------------------------------------------------- | --------------------------------------------------------------------------- | --- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| 1, 36                                                    | `rev-parse --show-toplevel`                                                 | 0   | `1f804a58891bbf9c02cb9327b9e04cdfae012f7c33e8da514358746fd73be1de` | EMPTY                                                              |
| 2, 11, 17, 23, 29, 37, 45, 50, 55, 60                    | `branch --show-current`                                                     | 0   | `ea96655087a20eebab1426d7c0d142a4b9ffd1e84bb91454161887efb15cb3af` | EMPTY                                                              |
| 3, 12, 18, 24, 30, 38, 46, 51, 56, 61                    | `rev-parse HEAD`                                                            | 0   | `35a27ba96b6a5737a238ef7b1d2aec9b6ba0817da8a0b0caef6e56e4b08197c7` | EMPTY                                                              |
| 4, 13, 19, 25, 31, 39, 47, 52, 57, 62                    | `rev-parse HEAD^{tree}`                                                     | 0   | `90aedb18ba194cdb9aeb6c160585f05f3094ecad77b7d4eadd0c339bd11d342e` | EMPTY                                                              |
| 5, 40                                                    | `rev-list --parents -n 1 HEAD`                                              | 0   | `a164dc591945b493ffb184e7b740b7adeadad166b923ae80711f7ba779c107cd` | EMPTY                                                              |
| 6, 14, 20, 26, 32, 41, 48, 53, 58, 63                    | `rev-parse --verify @{upstream}`                                            | 128 | EMPTY                                                              | `159386b3dbc19a37b4f8f5f1f02e1fe4ba6aef96364cc2ece40983d4075981d2` |
| 7, 15, 21, 27, 33, 42, 49, 54, 59, 64                    | `status --porcelain=v1 --untracked-files=all -z`                            | 0   | `7cbc827d5a678529209783f6bb9422fc43768a6221a181ceecf4b1316927d862` | EMPTY                                                              |
| 8, 43                                                    | `diff --cached --name-only -z`                                              | 0   | EMPTY                                                              | EMPTY                                                              |
| 9, 16, 22, 28, 34, 44, 65, 66                            | `diff --binary --no-ext-diff --no-textconv --no-color --full-index HEAD --` | 0   | `b248731059d2fb8dcba6292fc3a33e809ed3d845ffdc965e97f64e8b6197aceb` | EMPTY                                                              |
| 10                                                       | `rev-parse --git-dir`                                                       | 0   | `2c196990e35a00efda3c22702188467a3b622f633228d47fd9bedf1c7920d7f6` | EMPTY                                                              |
| 35                                                       | `diff --check`                                                              | 0   | EMPTY                                                              | EMPTY                                                              |

IDs 1–10 are opening parent commands; 11–16 and 23–28 are opening recipe mirrors; 17–22 and 29–34 denote their recipe-internal calls. ID 35 is the static gate. IDs 36–44 are closing parent commands; 45–49 and 55–59 are closing mirrors; 50–54, 60–64, 65, and 66 denote closing recipe-internal calls. The two recipe-internal diff entries were appended to the ledger after their runs, so ledger ID order is not execution chronology for those entries. No Git command ran in the primary checkout, candidate checkout, sealed targets, or evidence roots.

## 31. Explicit action confirmations

| ActionActual result                          |                                                                                                                                                          |
| -------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Repository mutation                          | **Occurred inadvertently:** the audit-created `__pycache__` directory and `.pyc` file described above. A confirmation of “not performed” would be false. |
| Formatting or repair of the patch            | Not performed                                                                                                                                            |
| Staging, commit, push, PR, or merge          | Not performed                                                                                                                                            |
| A6 restart                                   | Not performed                                                                                                                                            |
| Product execution or live-service invocation | Not performed                                                                                                                                            |
| Network contact                              | Not performed                                                                                                                                            |
| Linux binary execution                       | Not performed                                                                                                                                            |
| Nested subagents                             | Not created                                                                                                                                              |
| Supplied-evidence mutation                   | Not performed                                                                                                                                            |

Supplemental records: [closing adjudication](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/closeout/adjudication.json), [repository-object diff](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/closeout/repository-snapshot-diff.json), [independent 38-case matrix](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/validation/independent-38-results.json), [16 marker causals](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/perspectives/marker-validator-causals.json), [compatibility results](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/validation/compatibility-results.json), and [full Git ledger](/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-4a3a42441632-v1/closeout/git-commands.json).
