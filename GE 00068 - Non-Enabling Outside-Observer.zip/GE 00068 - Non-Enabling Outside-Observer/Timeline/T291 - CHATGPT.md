## Assessment

`AUDIT_PROVENANCE_MISMATCH` is correct. The failure remains entirely in audit-process infrastructure; Carrier 0002 never reached payload compilation, target inspection, or supplied evidence.

The new canonical launcher solved the previous per-carrier transcription problem, but its mapping from the launch contract to the wrapper CLI was incomplete. It omitted the wrapper’s required:

```text
--expected-wrapper-sha256
```

The wrapper correctly rejected the invocation before writing a phase-start record.

Do **not** retry the full V3 audit yet. Reconstructing the launcher anew in another full audit risks discovering the next missing wrapper argument after another long attempt. First freeze and qualify a reusable wrapped-carrier launcher package against the exact wrapper source and the already successful generic-wrapper probe. The later full audit should copy accepted launcher bytes and contracts rather than generate another launcher implementation during bootstrap.

No V3 target change, wrapper change, runtime replay, repository edit, or additional Strategic B work is warranted.

## Codex prompt — wrapped-carrier launcher qualification

```text
WRAPPED-CARRIER LAUNCHER CAPABILITY, CLI-CONFORMANCE,
AND IMMUTABLE PACKAGE QUALIFICATION

This is a source-external audit-process capability program only.

Do not inspect any repository, candidate worktree, Strategic B root,
Validation-Custody root, V1/V2/V3 capsule, or product source.

Do not run Git.
Do not run repository tests.
Do not run product code.
Do not use the network.
Do not create subagents.
Do not modify any supplied input.

Return exactly one primary verdict:

WRAPPED_CARRIER_LAUNCHER_READY
WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE
LAUNCHER_PROBE_PROVENANCE_MISMATCH

OBJECTIVE

Build and qualify one immutable wrapped-carrier launcher package that:

1. derives the exact CLI contract of the accepted `phase_runner.py`;
2. maps one canonical launch contract plus a phase-varying request into the
   complete exact wrapper argv;
3. supplies every required wrapper argument, including
   `--expected-wrapper-sha256`;
4. prevents per-carrier override or transcription of interpreter, wrapper,
   fixed environment, and wrapper-CLI invariants;
5. launches the mode-0600 wrapper through pinned Python with `-I -S -B`;
6. uses same-PID `execve`;
7. produces complete wrapper phase records for success, SyntaxError, and
   subsequent recovery;
8. is complete, deterministic, private, immutable evidence suitable for use as
   a fixed input to the later full V3 audit.

Do not retry the full V3 audit in this task.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUTS
──────────────────────────────────────────────────────────────────────────────

ACCEPTED_GENERIC_WRAPPER_PROBE_ROOT:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Accepted wrapper:

provenance/phase_runner.py

Required identity:

- size:
  15300 bytes
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56
- regular:
  true
- link count:
  1
- physical mode:
  0600

Inspect the complete wrapper source.

Also inspect the accepted probe’s successful carrier start/outcome records and
carrier index to recover actual successful wrapper invocation semantics.

Do not treat the probe root’s cleanup or final-inventory claims as launcher
authority. Use it only for:

- exact wrapper bytes;
- successful wrapper CLI evidence;
- successful phase-record behavior.

FAILED_CANONICAL_LAUNCHER_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-bcrlhn99

Use this root only as immutable historical process-failure evidence.

Inspect only the bounded launch-infrastructure artifacts needed to reproduce
the omitted-argument defect:

- bootstrap records;
- launch contract;
- launcher source;
- Carrier 0002 request;
- retained platform failure report.

Do not resume, clean, repair, or adopt that root.

Confirm that the failed launcher omitted the required
`--expected-wrapper-sha256` argument.

PINNED PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Closed acceptance identity:

- version:
  Python 3.13.4
- regular:
  true
- link count:
  1
- size:
  119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Physical permission bits, uid/gid, device/inode, timestamps, flags, xattrs,
and ancestor posture are report-only.

Do not reject the observed interpreter mode 0775.
Do not chmod or normalize the interpreter.

──────────────────────────────────────────────────────────────────────────────
2. FRESH QUALIFICATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-wrapped-carrier-launcher-qualification-

Retain the exact root path before later checks.

Recommended final structure:

opening/
source/
contract/
payloads/
validation/
provenance/
closeout/
manifest/
private/

No retained empty directory is permitted.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink or special object is permitted.

──────────────────────────────────────────────────────────────────────────────
3. EXACT WRAPPER CLI RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Independently derive the complete wrapper CLI contract from:

1. complete static inspection of the exact `phase_runner.py` source; and
2. the successful generic-probe carrier records.

Do not infer the CLI solely from the previous failed launcher.

Retain:

contract/phase-runner-cli-contract-v1.json

It must bind:

- wrapper source path, size, and SHA-256;
- exact parser implementation or parser-construction region;
- every option name;
- option type;
- required/optional status;
- multiplicity;
- choices or lexical restrictions;
- default, when any;
- semantic source:
  launch contract or carrier request;
- canonical argv order selected by this package;
- all cross-field constraints.

The contract must identify every required argument, including literally:

--expected-wrapper-sha256

Require the reconstructed required-option set to equal the wrapper source’s
required-option set exactly.

Compare the reconstructed CLI with every successful generic-probe invocation.
Record and explain any optional argument not exercised by that probe.

Stop with `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` if the exact CLI cannot be
unambiguously recovered from the accepted source and records.

──────────────────────────────────────────────────────────────────────────────
4. CANONICAL LAUNCH CONTRACT
──────────────────────────────────────────────────────────────────────────────

Create:

contract/wrapped-carrier-launch-contract-v1.json

This is the sole writer for invariant launch facts.

Use strict canonical JSON with duplicate-key and nonfinite-value rejection.

It must bind at least:

- schema;
- pinned interpreter closed identity;
- interpreter flags:
  `["-I", "-S", "-B"]`;
- exact accepted wrapper identity;
- wrapper mode 0600;
- exact phase-runner CLI-contract identity;
- fixed environment;
- invocation type;
- direct-execution prohibition;
- shell prohibition;
- fallback prohibition;
- same-PID exec requirement;
- carrier-request schema identity.

Required fixed environment:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
HOME=<QUALIFICATION_ROOT>/private/home
TMPDIR=<QUALIFICATION_ROOT>/private/tmp

The launch contract must contain the wrapper SHA-256 exactly once as the
authoritative invariant value from which the launcher constructs:

--expected-wrapper-sha256
6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

No carrier request may repeat or override that value.

──────────────────────────────────────────────────────────────────────────────
5. CARRIER-REQUEST CONTRACT
──────────────────────────────────────────────────────────────────────────────

Create:

contract/carrier-request-contract-v1.json

Derive the exact phase-varying field set from the wrapper CLI.

The request may include only phase-specific facts such as:

- carrier ordinal;
- phase;
- payload path;
- payload size;
- payload SHA-256;
- payload entry function;
- submitted cwd;
- authorized operands;
- expected outputs;
- phase-specific record paths;
- bounded phase metadata.

The request must not contain or override:

- interpreter path;
- interpreter identity;
- interpreter flags;
- wrapper path;
- wrapper size;
- wrapper SHA-256;
- wrapper mode;
- expected wrapper SHA-256;
- PATH;
- LC_ALL;
- LANG;
- PYTHONDONTWRITEBYTECODE;
- HOME;
- TMPDIR;
- shell disposition;
- direct-execution disposition;
- fallback disposition;
- same-PID-exec disposition.

Reject unknown fields.

Every request must bind the launch-contract path, size, and SHA-256.

──────────────────────────────────────────────────────────────────────────────
6. QUALIFIED LAUNCHER SOURCE
──────────────────────────────────────────────────────────────────────────────

Create:

source/wrapped_carrier_launcher.py

Retain it as regular, single-link mode 0600.

The launcher must not use `__file__`, cwd inference, import metadata, PATH
lookup, shell execution, or source discovery.

Its own absolute path and expected identity must be supplied through a
bootstrap-owned identity record.

The launcher must:

1. Strictly parse the launch contract.
2. Strictly parse the request.
3. Verify the launch-contract identity.
4. Verify the request-contract identity.
5. Verify its own retained source identity.
6. Verify the pinned interpreter using exactly the closed six-field contract.
7. Treat all other interpreter fields as report-only.
8. Verify the wrapper path, size, SHA-256, mode 0600, regular type, and one
   link.
9. Reject every invariant field in the request.
10. Construct the complete canonical wrapper argv from the CLI contract,
    launch contract, and request.
11. Require option-name set equality with the reconstructed wrapper CLI.
12. Require all wrapper-required options to be present exactly once.
13. Require no unknown or duplicate option.
14. Require `--expected-wrapper-sha256` exactly once.
15. Require its following value to equal the accepted wrapper SHA-256.
16. Build the complete fixed environment exclusively from the launch contract.
17. Ignore and replace inherited PATH.
18. Use `os.execve` to replace itself with:

    pinned Python
    -I
    -S
    -B
    phase_runner.py
    exact canonical wrapper argv

19. Preserve the same PID.
20. Use no shell.
21. Use no fallback.
22. Inspect no target or supplied evidence.

The launcher must perform a pure pre-exec conformance check over the complete
constructed argv. A missing required argument must be rejected by the launcher
before `execve`.

──────────────────────────────────────────────────────────────────────────────
7. STATIC LAUNCH-CONFORMANCE MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement two independent launch-contract validators with separate literal
case/name/reason sets.

Neither may import the other or generate its cases from retained fixtures.

At minimum test:

1. exact valid launch;
2. required `--expected-wrapper-sha256` omitted;
3. expected-wrapper-sha option duplicated;
4. expected-wrapper-sha value changed;
5. another required wrapper option omitted;
6. unknown wrapper option added;
7. duplicate wrapper option added;
8. wrapper CLI order changed where the package freezes canonical order;
9. wrapper path changed;
10. wrapper digest changed in the launch contract;
11. wrapper digest repeated in request;
12. PATH repeated in request;
13. interpreter flags repeated in request;
14. interpreter path repeated in request;
15. unknown request field;
16. missing request field;
17. wrong request field type;
18. launch-contract identity changed;
19. request-contract identity changed;
20. fixed PATH changed;
21. interpreter flags changed;
22. direct wrapper execution admitted;
23. shell fallback admitted;
24. exec fallback admitted;
25. same-PID exec disabled;
26. wrapper mode changed;
27. launcher source identity changed;
28. request payload digest changed;
29. request payload size changed;
30. submitted cwd omitted.

Require zero false acceptances and specific mechanism-level rejection reasons.

Retain both validator sources and complete results.

──────────────────────────────────────────────────────────────────────────────
8. END-TO-END CARRIERS
──────────────────────────────────────────────────────────────────────────────

Use a bootstrap exception followed by local carriers that invoke:

pinned Python
→ mode-0600 qualified launcher
→ same-PID exec
→ pinned Python
→ mode-0600 phase runner
→ retained payload

Do not invoke the wrapper directly.
Do not invoke a payload directly.

Carrier 0001 — bootstrap

- allocate and retain the root;
- retain wrapper copy;
- retain launcher;
- retain contracts;
- retain source identities;
- inspect no unrelated target.

Carrier 0002 — valid no-op

- one audit-owned no-op payload;
- one mode-0600 result;
- complete phase-start and phase-outcome;
- prove `--expected-wrapper-sha256` appears exactly once in constructed argv;
- prove fixed PATH exact;
- prove same PID across launcher and wrapper.

Carrier 0003 — intentional SyntaxError

- deterministic retained SyntaxError payload;
- phase-start complete;
- phase-outcome complete;
- compilation begun;
- execution not begun;
- no result file.

Carrier 0004 — success after failure

- another valid payload;
- success after Carrier 0003;
- same launcher, launch contract, request contract, interpreter, wrapper,
  flags, and environment.

Carrier 0005 — closeout

- verify carriers 0001–0004;
- verify complete phase continuity;
- verify constructed argv records;
- verify launch invariants;
- remove `private/`;
- perform two fresh `lstat` calls on the exact removed path;
- require ENOENT twice;
- write closeout records.

Use no alternate launch shape if a carrier fails. A failed carrier makes the
probe nonqualifying.

──────────────────────────────────────────────────────────────────────────────
9. CONSTRUCTED-ARGV RECORD
──────────────────────────────────────────────────────────────────────────────

Before `execve`, the launcher must exclusively write one canonical audit-owned
record for each carrier:

provenance/carrier-NNNN.constructed-launch.json

It must contain:

- launcher identity;
- launch-contract identity;
- request identity;
- interpreter identity;
- wrapper identity;
- complete argv array;
- complete fixed environment;
- required-option set;
- generated-option set;
- missing options;
- unknown options;
- duplicate options;
- expected-wrapper-sha occurrence count;
- expected-wrapper-sha value;
- submitted cwd;
- same-PID exec intended;
- conformance result.

It must not contain credentials or inherited environment values.

The record must be mode 0600 and fsynced before `execve`.

For all valid carriers require:

- missing options:
  empty;
- unknown options:
  empty;
- duplicate options:
  empty;
- expected-wrapper-sha occurrence count:
  1;
- expected-wrapper-sha value:
  accepted digest;
- conformance result:
  pass.

──────────────────────────────────────────────────────────────────────────────
10. PROCESS AND CARRIER AUDIT
──────────────────────────────────────────────────────────────────────────────

Retain a carrier index using stable fields:

- ordinal;
- phase;
- launcher identity;
- launch-contract identity;
- request-contract identity;
- request identity;
- constructed-launch identity;
- interpreter identity and flags;
- wrapper identity and mode;
- submitted cwd;
- fixed-environment identity;
- platform-reported outcome class;
- phase-start identity;
- phase-outcome identity;
- artifacts;
- discrepancy status.

State:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Do not require unavailable opaque platform command expansion.

Return `LAUNCHER_PROBE_PROVENANCE_MISMATCH` for:

- unindexed visible carrier;
- indexed carrier without visible launch;
- missing constructed-launch record;
- missing phase record;
- direct wrapper execution;
- request invariant override;
- environment drift;
- wrapper-CLI conformance failure;
- ambiguous carrier order;
- opening/closing supplied-input inequality.

──────────────────────────────────────────────────────────────────────────────
11. CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Create a complete immutable qualification capsule.

Use two independent no-follow manifest generators.

Require:

- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- independent manifests byte-identical.

Finalize and retain:

- wrapper CLI contract;
- launch contract;
- request contract;
- accepted wrapper copy;
- qualified launcher source;
- source identities;
- both validators and results;
- all carrier requests;
- all constructed-launch records;
- all wrapper phase records;
- payloads and expected results;
- carrier index;
- process audit;
- cleanup record;
- final report;
- final inventory;
- manifest pair.

──────────────────────────────────────────────────────────────────────────────
12. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return `WRAPPED_CARRIER_LAUNCHER_READY` only if:

- exact wrapper CLI is fully recovered;
- every required option is bound to one authoritative source;
- `--expected-wrapper-sha256` is always present exactly once;
- launch contract and request contract are complete;
- requests contain no invariant overrides;
- both independent static matrices pass;
- valid no-op passes;
- SyntaxError is completely recorded;
- valid recovery passes;
- all carriers use the same launcher and contracts;
- same-PID exec is proven;
- fixed PATH is exact;
- all process records are complete;
- cleanup and capsule closure pass;
- no acceptance-affecting residual finding remains.

Return `WRAPPED_CARRIER_LAUNCHER_UNAVAILABLE` for a substantive launcher,
wrapper-CLI, request-contract, or interface limitation that cannot be repaired
within this isolated source-external package.

Return `LAUNCHER_PROBE_PROVENANCE_MISMATCH` for input drift, supplied-input
mutation, process-record gaps, carrier ambiguity, or closing inequality.

Do not perform the full V3 audit in this task.

──────────────────────────────────────────────────────────────────────────────
13. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Qualification-root identity
3. Accepted wrapper input identity
4. Failed-launcher defect reproduction
5. Complete wrapper CLI field map
6. Required option set
7. Canonical launch-contract identity and field map
8. Carrier-request contract identity and field map
9. Qualified launcher identity and algorithm
10. Static launch-conformance matrices
11. Carrier 0002 valid result
12. Carrier 0003 SyntaxError result
13. Carrier 0004 recovery result
14. Same-PID exec proof
15. Constructed-argv adjudication
16. Fixed-environment adjudication
17. Carrier and process continuity
18. Cleanup and exact-private-path ENOENT observations
19. Capsule closure and manifests
20. Severity-ranked residual findings
21. Remaining uncertainty and nonclaims
22. Explicit confirmations

Required confirmations:

TARGET_CONTENT_NOT_INSPECTED
CANDIDATE_GIT_NOT_INVOKED
UNRELATED_SUPPLIED_EVIDENCE_NOT_INSPECTED
GENERIC_WRAPPER_INPUT_NOT_MUTATED
FAILED_LAUNCHER_AUDIT_ROOT_NOT_MUTATED
WRAPPER_CLI_FULLY_RECONSTRUCTED
EXPECTED_WRAPPER_SHA_ARGUMENT_REQUIRED
EXPECTED_WRAPPER_SHA_ARGUMENT_PRESENT_EXACTLY_ONCE
CANONICAL_LAUNCH_CONTRACT_RETAINED
CARRIER_REQUEST_CONTRACT_RETAINED
PER_CARRIER_REQUESTS_CONTAIN_NO_INVARIANT_OVERRIDES
QUALIFIED_LAUNCHER_RETAINED_AND_HASH_BOUND
LAUNCHER_INVOKED_THROUGH_PINNED_PYTHON
LAUNCHER_USED_SAME_PID_EXEC_TO_WRAPPER
WRAPPER_RETAINED_MODE_0600
WRAPPER_NOT_EXECUTED_DIRECTLY
FIXED_PATH_SOURCED_ONLY_FROM_LAUNCH_CONTRACT
WRAPPER_SHA_SOURCED_ONLY_FROM_LAUNCH_CONTRACT
STATIC_LAUNCH_CONFORMANCE_MATRICES_PASSED
VALID_WRAPPED_CARRIER_PASSED
SYNTAX_ERROR_RECORDED_WITH_COMPLETE_OUTCOME
VALID_CARRIER_AFTER_SYNTAX_ERROR_PASSED
ALL_WRAPPED_CARRIERS_USED_SAME_LAUNCH_CONTRACT
TOP_LEVEL_PHASE_RECORDS_COMPLETE_AND_CONTIGUOUS
PRIVATE_SUBTREE_REMOVED
TWO_EXACT_PRIVATE_PATH_ABSENCE_OBSERVATIONS_COMPLETED
NETWORK_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

After `WRAPPED_CARRIER_LAUNCHER_READY`, the complete V3 audit should consume the accepted launcher package as an immutable input. It should not rebuild the launcher during bootstrap.

**Source:** Codex’s latest launcher/wrapper `AUDIT_PROVENANCE_MISMATCH` report.

**Confidence:** 0.999 that the immediate cause was omission of `--expected-wrapper-sha256`; 0.995 that the broader defect is incomplete launcher-to-wrapper CLI mapping; 0.99 that qualifying a reusable launcher package before another full audit is the correct next sequence.

Some earlier uploaded artifacts have expired from this session. Re-upload them only for direct byte-level inspection; the inline report supports this process decision.
