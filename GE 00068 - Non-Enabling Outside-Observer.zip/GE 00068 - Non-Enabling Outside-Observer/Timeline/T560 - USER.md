Here is Codex's response:

## Operative report

1. **Primary verdict:** `GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT`

2. **Fresh build root:** `/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0`; dev `16777234`, inode `182740567`, mode `0700`, UID/GID `501/0`, final nlink `11`, size `352`.

3. **Fresh output root:** `/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu`; dev `16777234`, inode `182740568`, mode `0700`, UID/GID `501/20`. The directory itself is nonauthoritative.

4. **PYZ:** dev `16777234`, inode `182699827`, mode `0400`, nlink `1`, size `4589679`, SHA-256 `00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0`. Two stable no-follow reads matched.

5. **Runtime authority:** dev `16777234`, inode `182699838`, mode `0400`, nlink `1`, size `56463`, SHA-256 `9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0`. Strict JSON and opening/closing equality passed.

6. **Profile v1:** dev `16777234`, inode `182723650`, mode `0400`, size `9131`, SHA-256 `14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568`. Schema valid; current before closure, now `HISTORICAL_SUPERSEDED_SELF_CONTRADICTORY_ROOT_LIFECYCLE_PROFILE`; consumed count `0`; unchanged and retained.

7. **Certificate v2:** dev `16777234`, inode `182723661`, mode `0400`, size `12987`, SHA-256 `f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f`. Schema and PYZ/runtime bindings valid; authorization unconsumed; now historical with active count `0`; unchanged and retained.

8. **Certificate v1:** dev `16777234`, inode `182699841`, mode `0400`, size `3572`, SHA-256 `525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c`. Historical lineage retained; current false; active authorization count `0`.

9. **Replacement subject:** dev `16777234`, inode `182649818`, mode `0700`, UID/GID `501/20`, nlink `13`, size `416`; bound inventory count `73`, inventory SHA-256 `336539da37567b09e785ded4520eda882f91358d72102aeb55e75c48e20d920e`. Identity and terminal/construction posture were authenticated through the unchanged authority chain; semantics were not re-audited.

10. **Construction wrapper:** dev `16777234`, inode `182648782`, mode `0700`, UID/GID `501/0`, nlink `13`, size `416`; bound inventory count `49`, inventory SHA-256 `444847c41972ae7bc73a57ddcb0075bf1177dbf788493a7507b0157dbe0f16b7`. One-shot custody and no-second-construction posture remained intact.

11. **Accepted implementation chain:** audit root inode `182593190`, mode `0700`, entries `78`, inventory SHA-256 `8545cfdbaa84c46cef1de43c684d737d7d923de18068d5f8a398ea81a62d7c89`; wrapper root inode `182593189`, mode `0700`, entries `12`, inventory SHA-256 `dff89a86ee9a1883789680b1e374faa7e27b4ffcc36f7dfab47b2e0d7079875b`. Disposition remained `GEN2_IMPLEMENTATION_PACKAGE_ACCEPT`; no re-audit occurred.

12. **Content inputs:** bundle inode `181651092`, mode `0400`, size `13598758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`; authority inode `181651098`, mode `0400`, size `19737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`. Authority was authenticated first; bundle interpretation was unnecessary.

13. **Frozen root-flow adjudication:** passed. Exact chain: `__main__.main:arguments.output_root` → `audit_parent.audit_subject:output_root` → `core.create_synthetic_capsule:root` → `os.makedirs(root, mode=0o700, exist_ok=False)` → terminal `capsule_root=root`. [Evidence](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/analysis/frozen-runtime-root-flow-adjudication-v1.json)

14. **CLI semantics:** `__main__.py` size `2326`, SHA-256 `09798990…da3`, accepts an explicit `--output-root`. The external profile requires that operand to be absolute and nonexistent.

15. **Audit-parent forwarding:** `__main__.py:39` passes `arguments.output_root`; `audit_parent.py:170` passes `output_root` unchanged to `core.create_synthetic_capsule`.

16. **Capsule creation:** registry-resolved `core.py`, size `13033`, SHA-256 `0832b54d…541e`; `core.py:207` creates the supplied root exactly once with `exist_ok=False`.

17. **Cwd/self-authentication:** no frozen source, runtime-authority key, or self-authentication branch requires `cwd == output_root`; no code derives audit-mode output root from cwd.

18. **Terminal frame:** `core.py:290` reports the explicit root parameter as `capsule_root`. Cleanup and terminal logic operate on that root, not the workspace cwd.

19. **Repair decision:** `SPLIT_ROOT_LAUNCH_AUTHORITY`; harness change not required. The v1 contradiction was proven from `mkdtemp` plus same-token cwd/output and `exist_ok=False`. [Decision](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/analysis/root-lifecycle-repair-decision-v1.json)

20. **Split-root policy:** existing wrapper-owned workspace as cwd; absent `audit-capsule` child as output; frozen runtime owns child creation; terminal frame binds that child. [Policy](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/opening/split-root-external-launch-policy-v1.json)

21. **Workspace contract:** `tempfile.mkdtemp`, parent `/private/tmp`, prefix `ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-`, umask `077`, mode `0700`, absolute, empty, nonsymlink, no scan/adoption/fallback.

22. **Capsule-root contract:** exact direct child `<FRESH_PRIVATE_AUDIT_WORKSPACE>/audit-capsule`; placeholder `<ABSENT_AUDIT_CAPSULE_ROOT>`; absent before preflight and launch; wrapper must not create it.

23. **Exact launch context:** argv remains the frozen 23-element audit argv, with only the final operand changed to `--output-root <ABSENT_AUDIT_CAPSULE_ROOT>`. Cwd is `<FRESH_PRIVATE_AUDIT_WORKSPACE>`. Environment is exactly `PATH=/usr/bin:/bin`, `LANG=C`, `LC_ALL=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`, with no inheritance. Stdin `DEVNULL`; shell/TTY/detachment false; foreground/synchronous true.

24. **Preflight contract:** pinned Python with the existing marker program; expected stdout/stderr markers, exit `23`, signal null, workspace still empty, child still absent.

25. **Authorization consumption:** only successful real audit-parent process creation consumes it. Preflight and prelaunch failures do not; consumption is final after creation.

26. **Profile-v2 schema:** recursively closed, all fields required, unknown fields rejected; size `25446`, SHA-256 `d03b7d56c0f74f0293b91db0bc5ff2196f89dc949099ec7106745291ba49d7a3`.

27. **Certificate-v3 schema:** recursively closed, all fields required, unknown fields rejected; size `42337`, SHA-256 `bb8fbae0dc6fe48a34ff93c6c351bb3d7c247666303e52e22838be38dcf80b5b`.

28. **Builder-source registry:** three frozen standard-library-only sources. Registry SHA-256 `da349a1e…76bc`; source-authority SHA-256 `860fbe51…b83a`. Builder SHA-256 `ea9c6e65…9d11`; independent validator `3057cfb3…a3a`; certificate validator `ca83e0a3…126a`.

29. **Compilation/static qualification:** all three sources compiled under `/usr/local/bin/python3.13 -I -S -B`; 17 static gates passed, zero errors. No network import, shell execution, Git/VCS access, or forbidden launcher.

30. **Authority matrix:** `81` uniquely named cases; exact-name closure true; zero false acceptances, false rejections, reason mismatches, skips, or unexpected exceptions. [Matrix](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/validation/root-lifecycle-authority-matrix-v1.json)

31. **Independent validator:** all 16 required checks and 16 independently authored negative cases passed; zero errors; it imported none of the builder, analyzer, matrix, expected map, or producers. [Result](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/validation/independent-root-lifecycle-authority-validator-v1.json)

32. **Platform qualification:** workspace inode `182745688`; exact markers and exit `23`; workspace identity unchanged and empty; child remained absent; cleanup produced double `ENOENT`.

33. **Filesystem probe:** workspace `/private/tmp/…-2vcpbdnj`; child inode `182745691`, mode `0700`; cwd stayed the workspace; first creation succeeded, second failed with `EEXIST`/errno `17`; child and workspace received double-`ENOENT` cleanup.

34. **Packaged crosswalk:** applicable and passed exactly once in `synthetic` mode. The frozen harness created `/private/tmp/…-um6usuo2/audit-capsule`, returned one terminal frame binding that child, used no real subject, and was cleaned with double `ENOENT`.

35. **Profile Build A:** size `10412`, SHA-256 `2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c`.

36. **Profile Build B:** size `10412`, same SHA-256.

37. **Profile equality/final identity:** A/B bytes identical. Final dev `16777234`, inode `182745731`, mode `0400`, nlink `1`, size `10412`, same SHA-256.

38. **Certificate Build A:** size `19323`, SHA-256 `e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d`.

39. **Certificate Build B:** size `19323`, same SHA-256.

40. **Certificate equality/final identity:** A/B bytes identical. Final dev `16777234`, inode `182745737`, mode `0400`, nlink `1`, size `19323`, same SHA-256.

41. **Certificate-input validation:** all 17 checks and all nine evidence references passed; unknown-field count `0`, error count `0`. [Validation](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/validation/successor-certificate-v3-input-validation-v1.json)

42. **Role registry:** exactly one current profile and certificate; historical v1 profile, v2 certificate, and v1 certificate; no duplicate role or ambiguous path. [Registry](/private/tmp/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-shia63t0/contract/current-external-launch-authority-role-registry-v2.json)

43. **Authorization count:** exactly one active current real-audit authorization, held by certificate v3; still unconsumed.

44. **Input closing equality:** every supplied input matched its opening identity and content hash; pass true.

45. **Cleanup:** expected and observed sets matched across five disposable paths; all double-absence evidence passed; zero process, descriptor, cache, or bytecode survivors.

46. **Real audit:** no audit-mode process or real replacement-subject audit executed.

47. **Subject verdict:** not issued.

48. **Final profile:** [launch-profile-v2.json](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json) — SHA-256 `2c5afe3168090089de1896e3d35855996a658fc0a6a58836d48fe389f0d0b44c`.

49. **Final certificate:** [launch-certificate-v3.json](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-r8mjxopu/gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json) — SHA-256 `e30bc190320eb743eb982dee5e34022da2f3886fc6348463264afd91cbdce30d`.

50. **Remaining uncertainty/nonclaims:** the replacement subject’s semantic audit outcome remains unknown. This work proves launch-root compatibility and establishes one launch authority; it does not accept or reject the subject, promote/rebind schema authority, modify the harness, or validate product/runtime behavior.

51. **Required confirmations:**

```text
FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
PROFILE_V1_IDENTITY_MATCHED
CERTIFICATE_V2_IDENTITY_MATCHED
CERTIFICATE_V1_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
SELF_CONTRADICTORY_ROOT_LIFECYCLE_PROVEN
FROZEN_RUNTIME_ROOT_FLOW_ADJUDICATED
CWD_OUTPUT_ROOT_EQUALITY_REQUIREMENT_ADJUDICATED
SPLIT_ROOT_COMPATIBILITY_ADJUDICATED
ROOT_LIFECYCLE_REPAIR_DECISION_SELECTED
PROFILE_V1_CLASSIFIED_HISTORICAL_SUPERSEDED
CERTIFICATE_V2_CLASSIFIED_HISTORICAL_SUPERSEDED
PREDECESSOR_AUTHORIZATIONS_UNCONSUMED
ADDITIVE_SPLIT_ROOT_POLICY_FROZEN
WRAPPER_WORKSPACE_ALLOCATION_FROZEN
ABSENT_CAPSULE_CHILD_CONTRACT_FROZEN
WRAPPER_DOES_NOT_PRECREATE_CAPSULE_ROOT
CWD_EQUALS_WORKSPACE
OUTPUT_ROOT_EQUALS_ABSENT_CHILD
TERMINAL_FRAME_BINDS_CAPSULE_CHILD
EXACT_AUDIT_ARGV_FROZEN
EXACT_SUBMITTED_ENVIRONMENT_FROZEN
STDIN_DEVNULL_FROZEN
SHELL_FALSE_FROZEN
TTY_FALSE_FROZEN
DETACHMENT_FALSE_FROZEN
AUTHORIZATION_CONSUMPTION_RULE_FROZEN
PROFILE_V2_SCHEMA_COMPLETE
CERTIFICATE_V3_SCHEMA_COMPLETE
ROOT_LIFECYCLE_BUILDER_SOURCE_EXTERNAL
ROOT_LIFECYCLE_BUILDER_COMPILED
ROOT_LIFECYCLE_STATIC_QUALIFICATION_PASSED
ROOT_LIFECYCLE_AUTHORITY_MATRIX_PASSED
INDEPENDENT_ROOT_LIFECYCLE_VALIDATOR_PASSED
SPLIT_ROOT_PLATFORM_PREFLIGHT_PASSED
PREFLIGHT_WORKSPACE_REMAINED_EMPTY
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT
FILESYSTEM_SPLIT_ROOT_LIFECYCLE_PROBE_PASSED
OPTIONAL_PACKAGED_ROOT_PATH_CROSSWALK_PASSED_OR_NOT_APPLICABLE
PROFILE_V2_BUILD_A_B_BYTES_IDENTICAL
PROFILE_V2_MODE_0400
PROFILE_V2_IDENTITY_VERIFIED
CERTIFICATE_V3_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_V3_MODE_0400
CERTIFICATE_V3_IDENTITY_VERIFIED
CERTIFICATE_V3_INPUT_VALIDATION_PASSED
CURRENT_LAUNCH_AUTHORITY_ROLE_REGISTRY_COMPLETE
EXACTLY_ONE_CURRENT_LAUNCH_PROFILE
EXACTLY_ONE_CURRENT_LAUNCH_CERTIFICATE
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
CURRENT_AUDIT_PYZ_MUTATION_NOT_PERFORMED
CURRENT_RUNTIME_AUTHORITY_MUTATION_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```
