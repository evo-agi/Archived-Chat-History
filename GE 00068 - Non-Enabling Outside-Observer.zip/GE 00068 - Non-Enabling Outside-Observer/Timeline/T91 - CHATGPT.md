The stop is correct. The executed final control itself looks healthy:

- Exact expected terminal universe: `2,753 pass / 137 fail / 8 skip`.
- Zero unknown diagnostics and zero semantic-integrity failures.
- Only `read_policy_verified` was false.
- Grant path, type, mode, device, inode, and regular-file digests remained exact.
- The mismatch was solely directory `st_size` on a retained root that legitimately gained runtime entries.

That strongly points to a **successor read-policy identity-model defect**, not a repository, A5T4, A5C, historical-overlay, or test defect.

However, the correct repair is not yet frozen. There are two plausible models:

1. **Construction-order correction:** create every direct child before the policy identity is captured, then preserve root topology.
2. **Grant-semantics correction:** for an intentionally mutable `tree` grant, bind stable security identity—resolved path, type, device, inode, owner, mode, flags/ACL posture—and treat directory allocation size as report-only.

The second model is likely correct. Darwin directory size is an allocation observation, not a stable security identity for a mutable tree root. But it must be applied **only to the correct grant kind and role**. Globally ignoring directory metadata would be unsafe, and silently changing `effective-read-policy.v1` acceptance semantics without versioning would repeat the schema-drift problems already encountered.

Do not retry A6 yet. Preserve the current A6 child as unsealed negative evidence and run one bounded read-only reconnaissance to freeze:

- whether root mutation was expected and bounded;
- which entries caused each size transition;
- whether precreation is feasible and semantically cleaner;
- exact stable versus volatile identity fields by grant type;
- schema-version impact;
- exact successor touched files and causal matrix.

Proof harness behavior remains bounded scaffolding rather than product architecture or authority. 

## Codex prompt: Repair 10I-A6R read-policy identity reconnaissance

```text
Objective

Perform a parent-only, source-read-only Repair 10I-A6R reconnaissance of the
fresh A6 validation blocker.

Determine the exact contract correction required for external qualification of
a mutable `tree` read-policy grant.

The failed final control executed completely and produced the exact expected
terminal universe:

- tests: 2,753 pass / 137 fail / 8 skip
- packages: 14 pass / 11 fail / 23 skip
- semantic-integrity failures: 0
- unknown diagnostics: 0

The sealed A6O external qualifier returned `blocked-uncertain` only because
`read_policy_verified=false`.

Exact reported cause:

- each command read policy captured the retained control root as a `tree`
  grant;
- opening recorded directory size was 448, 480, or 512 bytes;
- later admitted runtime entries increased the retained root to 544 bytes;
- path, resolved identity, type, mode, device, inode, and regular-file digests
  remained exact;
- external qualification treated the root directory-size change as an
  identity mismatch at `envelope/runner.go:6012`.

Freeze whether the required correction is:

1. control-root construction ordering;
2. grant-type-specific identity semantics;
3. root decomposition into immutable and mutable subroots;
4. a combination of those;
5. unresolved and blocking.

Do not implement any correction in this turn.

Do not modify repository source.
Do not modify sealed A6O.
Do not modify sealed A5C, A5T4, or A6O reconnaissance.
Do not modify, resume, overwrite, or seal the failed A6 child.
Do not launch any remaining A6 source control.
Do not run any repository full suite.
Do not implement the historical comparator.
Do not start B6.
Do not run product A/B.
Do not create a snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. You are the sole operator.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5T4 repository lineage

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

Sealed A5C successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5c-successor-closure-8de797304ea9

Sealed A6O reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-historical-overlay-recon-8de797304ea9

Sealed A6O overlay successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6o-overlay-successor-closure-8de797304ea9

Failed and unsealed A6 refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6o-8de797304ea9

Required new reconnaissance child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6r-read-policy-recon-8de797304ea9

## 1. Mandatory opening and closing gates

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- repository inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the exact three-file A5T4 repository delta and every other repository
tuple to match sealed A5T4.

Require exact sealed A5T4:

- manifest SHA-256:
  7cc55f3399d8c5eac48470a4eb82e8087753ddbb17e8d0eb6de7d03ad7937888
- manifest size:
  202930
- payloads:
  1000
- directories:
  188
- repository T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

Require exact sealed A5C:

- manifest SHA-256:
  05ff0c0f63babccf1f6f11be262202c5792a1ce93f497b0231eb49e532e38489
- manifest size:
  31421
- payloads:
  216
- directories:
  71
- source T:
  2c2d0b36f52d5949d023a36400f0e0748149875a
- source inventory:
  810f9d2934d56fba840f3c44938ee7a7784face2c8fa2458873fc5df8722f6f9

Require exact sealed A6O reconnaissance:

- manifest SHA-256:
  20852734748924f75194239767a9d47c102e4767a529dadbbb5e3c4c48461138
- manifest size:
  4031
- payloads:
  28

Require exact sealed A6O overlay successor:

- manifest SHA-256:
  ab54d9f980a810b87f318ecee10073c731044a111b7f5ba7e69b8893dedb388f
- manifest size:
  38321
- payloads:
  241
- directories:
  80
- source T:
  716d59b3e28ab4c77ae46af1ee44b28cd24ea77d
- source inventory:
  f47e798ce2429d20f73791a68ced180b2f5cc6b693d072037885e319bd1f30cc

A6O binaries:

repair10-runner:
  f37d350c11692bb225a8a710779ba089468a6d9618dc5110b3a8f39a625aa9b2

repair10-compare:
  7b72930c44b9803a386328bd39ec96abba179eb6122c96000c6f96c016135301

repair10-semantic:
  5e70f1c874033124df7b7c0f7d4df355403ced8d6620081910f51f7006591181

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require the complete A6O post-seal verification, active 24-schema dialect, all
58 overlay causals, A5C nonregression, and A5P2 PTY/policy nonregression.

Require the failed A6 child to remain:

- present;
- unsealed;
- without manifest or detached digest;
- byte-exact from opening through closing.

At opening, retain a complete safe snapshot of its:

- path set;
- file types;
- modes;
- sizes;
- SHA-256 values;
- link counts;
- directory modes.

Reverify:

- findings/fresh-validation-block-v1.json
- closeout/validation-blocked-closeout-v1.json
- pristine-final suite specification;
- effective read policy;
- rendered sandbox profile;
- command intent/result;
- terminal reconciliation;
- raw streams through EOF;
- semantic envelope;
- producer qualification;
- peer blocked qualification;
- resource ledger;
- cleanup and two absence epochs.

Bind these exact facts:

- only control executed:
  pristine-final;
- terminal universe:
  2,753 pass / 137 fail / 8 skip;
- package universe:
  14 pass / 11 fail / 23 skip;
- semantic-integrity failure count:
  0;
- unknown diagnostics:
  0;
- external qualification:
  blocked-uncertain;
- sole false verification field:
  read_policy_verified;
- opening tree-root sizes:
  448, 480, or 512 bytes by command;
- later retained-root size:
  544 bytes;
- grant path, type, mode, device, inode, and file-digest checks:
  exact;
- remaining four controls and all comparisons:
  not started;
- cleanup:
  complete with two absence epochs.

Require the A6R target to be absent.

Repeat every repository, successor, predecessor, failed-A6, and lineage check
at closeout.

Stop on any mismatch:

REPAIR10I_A6R_RECONNAISSANCE_BASELINE_MISMATCH

## 2. Reconnaissance evidence child

After the opening gate, create A6R exclusively under umask 077 with exactly:

opening/
source/
analysis/
schemas/
tests/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, mode 0600 or 0700 as intended.

No hardlinks.

Do not import executable modules from predecessor evidence children.

The child may contain only:

- safe source excerpts and inventories;
- read-policy producer/consumer mapping;
- root-lifecycle and metadata analysis;
- bounded private filesystem probes;
- frozen implementation contract;
- causal and validation plans;
- closeout evidence.

No repository or full-suite tests are authorized.

## 3. Recover the exact read-policy model

Inspect exact sealed A6O source:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/source.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- CLI dispatch only where schema behavior is implemented.

Recover every active read-policy or admitted-input structure and field.

For every grant kind, report:

- schema;
- grant kind;
- purpose;
- requested path;
- physical path;
- ancestor policy;
- type;
- mode;
- UID/GID;
- device/inode;
- link count;
- size;
- mtime/ctime if recorded;
- flags;
- ACL/xattr posture;
- regular-file digest;
- recursive or literal semantics;
- opening and closing observations;
- fields used by producer validation;
- fields used by external qualification;
- fields entering logical fingerprints.

Enumerate every grant kind, including at least:

- literal regular file;
- exact executable;
- tree/subpath directory;
- metadata-only ancestor;
- any PTY/device-specific literal;
- any source/GOROOT/tool root.

State where inspection stops.

## 4. Recover the exact failing root lifecycle

For each command in the pristine-final control:

1. Recover the exact retained control-root path and inode identity.
2. Recover its metadata when the read policy was captured.
3. Recover every direct child entry present at that moment.
4. Recover every direct child created later.
5. Recover creation sequence, owner, and purpose for each later child.
6. Recover final direct-child set.
7. Recover root size at each retained observation when available.
8. Determine which direct-child creation changed:
   - 448 → 544;
   - 480 → 544;
   - 512 → 544.
9. Determine whether size changed through:
   - expected direct-child insertion;
   - removal and replacement;
   - filesystem allocation behavior;
   - another mechanism.
10. Require path, type, device, inode, owner, mode, flags, ACL/xattr posture,
    and link count to remain exact where retained evidence supports them.

Do not copy sensitive file contents.

Safe child-entry names and role classifications may be retained when they are
already non-sensitive evidence names.

Determine whether all later root mutations were:

- predeclared by suite construction;
- runner-owned;
- evidence-owned;
- command-owned;
- unexpected.

## 5. Read-policy authority analysis

Determine exactly what a `tree` grant asserts.

Distinguish:

### Access authority

What the sandboxed command is allowed to read.

### Identity binding

Which filesystem object owns that authority.

### Content or topology assertion

Whether the grant claims any exact descendant inventory or content identity.

### Report-only observations

Metadata retained for diagnosis but not authority or qualification.

Answer:

1. Does `tree` mean “this exact directory object and every descendant beneath
   it,” or “this exact immutable directory inventory”?
2. Does any contract say direct-child topology must remain fixed?
3. Is root `st_size` used as a security identity, a content proxy, or merely
   copied by a generic metadata structure?
4. Can directory size change while path/device/inode/mode/owner remain stable
   and the authorized tree object remains the same?
5. Can directory size remain unchanged while unauthorized content changes?
6. Does size contribute any independent security guarantee for a tree grant?
7. Does omitting size verification permit path replacement, symlink
   substitution, owner/mode widening, or scope widening?
8. Is descendant inventory independently fenced by another contract?
9. Can the controlled command read suite intent, results, qualification
   records, or other self-attesting evidence because the entire control root
   is granted?
10. Should the granted tree be narrowed to one or more typed subroots?

## 6. Evaluate candidate correction models

Evaluate all models below.

### Model A — precreate all direct children before policy capture

Freeze feasibility and consequences:

- exact children that would need precreation;
- whether later direct-child creation can be eliminated;
- whether command/result/terminal files require paths not yet known;
- whether empty precreated children alter fingerprints or execution;
- whether root size can still change despite stable direct-child names;
- whether this creates false confidence from filesystem allocation metadata.

### Model B — tree-root stable identity excluding volatile allocation metadata

For `tree` grants only:

Acceptance-bearing fields would include, when supported:

- lexical and physical path;
- directory type;
- device/inode;
- UID/GID;
- permission mode;
- link count where meaningful;
- flags;
- ACL/xattr posture;
- no-follow component identity;
- declared grant role and scope.

Report-only fields would include:

- directory size;
- mtime;
- ctime;
- birth time;
- allocation blocks.

Regular-file literal grants would retain exact size and digest requirements.

Evaluate whether this is sufficient and least-privilege.

### Model C — exact recursive tree inventory

Evaluate:

- when inventory is captured;
- whether command-created descendants make it circular;
- boundedness;
- race behavior;
- self-attestation risk;
- whether it changes a read grant into an output-content contract.

### Model D — split immutable and mutable roots

Evaluate whether the control root should contain separately declared:

- immutable input/tool/source root;
- mutable runtime root;
- mutable output/evidence root;
- qualification-only external root.

Determine whether this is required now or a later hardening seam.

### Model E — ignore all directory metadata globally

Reject unless source evidence unexpectedly proves it safe.

The expected disposition is rejection because directory object identity,
permissions, ownership, and no-follow posture remain security-relevant.

### Model F — accept size growth only

Evaluate and likely reject rules such as:

- final size >= opening size;
- known set of allowed numeric sizes;
- command-specific size deltas.

Directory allocation size is filesystem-specific and is not a reliable
content or identity lattice.

## 7. Controlled private filesystem probes

Use one exclusive private probe root only.

No repository tests.

No access to live credentials, operator state, or unrelated directories.

Required probes:

1. Create a private directory; capture full metadata.
2. Add one direct child; recapture.
3. Add descendants under an existing direct child; recapture root and child.
4. Remove a child; recapture.
5. Replace a directory at the same pathname; prove inode/device identity
   catches replacement.
6. Change mode; prove mode check catches it.
7. Where permitted, alter harmless xattr or flags in the private probe and
   determine whether the intended posture detects it.
8. Create a regular-file literal grant:
   - same path/inode and changed bytes/size;
   - require size/digest mismatch.
9. Create a tree root whose size changes while stable identity remains.
10. Demonstrate that equal directory size does not imply equal descendants.

Record only safe generated names and metadata.

Do not infer universal filesystem behavior from one probe; use probes to
confirm the local causal mechanism and combine them with source/API semantics.

## 8. Schema and versioning analysis

Inspect the exact active 24-schema A6O dialect.

Identify every acceptance-bearing record whose meaning changes under the
selected model.

At minimum inspect:

- effective-read-policy;
- suite spec;
- suite result;
- binding recomputation;
- control qualification;
- semantic comparison spec/result/custody;
- command intent/result;
- terminal reconciliation;
- mutable inventory;
- control observation.

Determine:

- whether `effective-read-policy.v1` currently declares size as
  acceptance-bearing for tree grants;
- whether changing that interpretation requires
  `effective-read-policy.v2`;
- which outer records bind the policy schema or `read_policy_verified`
  meaning;
- whether any active v4 source-binding record also requires a new version;
- whether command records remain unchanged;
- whether strict decoding can reject old/new mixtures.

Do not reuse an active schema identifier when its acceptance meaning changes.

Freeze the exact future active dialect and historical parse-only dialects.

## 9. Stable versus volatile field table

Produce one normative table by grant kind.

For every field classify:

- required and acceptance-bearing;
- conditionally acceptance-bearing;
- report-only;
- forbidden or meaningless.

At minimum cover:

- path;
- physical path;
- role;
- grant kind;
- type;
- device;
- inode;
- UID/GID;
- mode;
- link count;
- size;
- digest;
- mtime;
- ctime;
- birth time;
- flags;
- ACLs;
- xattrs;
- descendant inventory;
- ancestor identity.

The table must distinguish at least:

- literal regular file;
- exact executable;
- mutable tree root;
- immutable tree root, if such a type exists;
- metadata-only ancestor;
- device or socket literal where applicable.

## 10. External qualification contract

Freeze how the peer qualifier independently recomputes read-policy validity.

A valid design must not trust producer captions.

For every grant it must:

1. reopen or reobserve the declared path with no-follow semantics;
2. validate grant kind and role;
3. validate all acceptance-bearing stable fields;
4. validate file bytes/digest where applicable;
5. classify volatile fields as observations without turning them into
   acceptance;
6. reject type, path, inode, device, owner, mode, flags, ACL/xattr, digest, or
   scope mismatch;
7. reject mixed policy schema generations;
8. retain opening and closing observations;
9. preserve factual observations even when qualification fails.

Determine whether the peer must also reconstruct the expected direct-child
role set from suite records.

## 11. Self-attestation and least-privilege review

Inspect what resides beneath the granted control root and when it becomes
readable to the command.

Classify:

- immutable inputs;
- executable/tool copies;
- source;
- profiles;
- command intents;
- raw outputs;
- command results;
- terminal records;
- suite results;
- peer qualifications;
- comparison outputs;
- credentials or private state, if any;
- control-only sentinels.

Determine whether granting the whole root permits the child to read records
that later claim to qualify it.

If so, decide whether:

- those records are created only after child exit and therefore inaccessible;
- they are cryptographically or custody-bound independently;
- root decomposition is required immediately;
- this is a separately reopened hardening seam.

Do not silently expand this tranche beyond the observed blocker unless the
current design permits actual self-attestation.

## 12. Exact touched-file freeze

Recover the exact A6O source paths implementing:

- policy schema;
- policy rendering;
- policy capture;
- logical fingerprinting;
- external verification;
- qualification result;
- tests;
- CLI dispatch if applicable.

Inspect explicitly:

- `FORMAT.md`
- `envelope/runner.go`
- `envelope/source.go`
- `envelope/semantic.go`
- `envelope/envelope_test.go`
- command mains
- golden files
- `go.mod`.

Freeze the smallest complete successor touched-file set.

No repository file may change.
No new dependency.
No thirteenth member.
No general filesystem-policy framework.

## 13. Mandatory future causal matrix

Freeze tests for at least:

1. Mutable tree root:
   size changes through expected child creation; stable identity exact;
   qualification passes.
2. Mutable tree root:
   path replaced with new inode; qualification fails.
3. Mutable tree root:
   symlink substitution; fails.
4. Mutable tree root:
   type change; fails.
5. Mutable tree root:
   owner change; fails.
6. Mutable tree root:
   mode widening; fails.
7. Mutable tree root:
   flags/ACL/xattr posture change where governed; fails.
8. Mutable tree root:
   size changes only; report retained, no failure.
9. Mutable tree root:
   mtime/ctime changes only; report retained, no failure.
10. Mutable tree root:
    same size but changed descendants; size is not represented as proof.
11. Literal regular file:
    byte or size change; fails.
12. Literal regular file:
    one-nibble digest mutation; fails.
13. Exact executable:
    identity or digest change; fails.
14. Metadata-only ancestor:
    accepted fields exact; descendant content is not overclaimed.
15. Wrong grant kind; fails.
16. Wrong role; fails.
17. Old policy schema on new path; nonqualifying.
18. New policy schema with old verification semantics; nonqualifying.
19. Mixed old/new suite/qualification records; fails.
20. Producer says pass but peer recomputation fails; control unqualified.
21. Late close/resource fault still clears qualification.
22. Current failed A6 control requalification:
    all stable fields exact;
    only directory size differs;
    repaired model qualifies.
23. Root replacement causal with matching reported size still fails.
24. A5C, A5P2, and overlay causals remain unchanged.
25. No grant widening to repository, Downloads, home, credentials, or unrelated
    user state.
26. Any whole-root self-attestation risk identified by reconnaissance is
    covered by a dedicated denial or timing causal.

## 14. Future implementation and A6 restart sequence

Freeze:

1. Create one new successor implementation child from sealed A6O.
2. Implement only the read-policy identity correction.
3. Run two disjoint source/test/race/build controls.
4. Reproduce the current A6 failure as expected-negative evidence.
5. Requalify the exact retained pristine-final control under the repaired
   verifier where source records permit safe read-only recomputation.
6. This bounded requalification remains a tool causal only.
7. Seal the successor amendment.
8. Create a new A6 evidence-refresh child.
9. Restart all five controls from the beginning.
10. Do not resume the current failed A6 child.
11. Run all five comparisons and structural policy analysis.
12. Proceed to historical-comparator implementation only after a successful
    fresh A6 policy freeze.

## 15. Mandatory future stop conditions

Freeze stop conditions including:

- baseline or lineage mismatch;
- root mutation source cannot be recovered exactly;
- expected and unexpected root mutations cannot be distinguished;
- size is the only available path-replacement protection;
- selected stable field set permits symlink, inode, owner, type, or mode
  substitution;
- whole-root grant permits acceptance-bearing self-attestation;
- schema-version impact cannot be closed;
- source scope cannot be frozen;
- repository change required;
- generic metadata weakening required;
- old policy schema can qualify new semantics;
- peer cannot independently recompute the policy;
- new dependency or thirteenth member required.

## 16. Required verdict

Return exactly one:

### Contract ready

REPAIR10I_A6R_RECONNAISSANCE_READY

Use only when:

- root mutation is fully explained;
- stable versus volatile metadata is frozen by grant kind;
- authority and self-attestation implications are resolved;
- schema dialect is complete;
- touched-file scope is complete;
- causal and restart matrices are complete;
- no repository change or general framework is required.

### Contract blocked

REPAIR10I_A6R_RECONNAISSANCE_BLOCKED

Use when:

- direct-child mutation remains ambiguous;
- safe stable identity cannot be distinguished from volatile metadata;
- root grant is overbroad in a way requiring redesign;
- schema/version impact is unresolved;
- source scope is incomplete;
- peer recomputation cannot be made independent.

## 17. Required final report

Include:

1. Opening and closing identities.
2. Exact failed-control identity and terminal universe.
3. Exact read-policy and qualifier mechanism.
4. Complete grant-kind inventory.
5. Exact root lifecycle and size-transition explanation.
6. Stable versus volatile field table.
7. Candidate-model adjudication.
8. Self-attestation and least-privilege assessment.
9. Selected correction and rejected alternatives.
10. Complete schema-version and active-dialect freeze.
11. Exact successor touched-file set.
12. External qualification contract.
13. Complete causal matrix.
14. Future implementation and fresh-A6 restart sequence.
15. Stop conditions.
16. Inspection limits and uncertainty.
17. Manifest SHA-256 and payload count if the reconnaissance child is sealed.
18. Confirmation no repository, successor, predecessor, failed-A6, cache,
    bytecode, test, or build artifact was modified.

No implementation.
No successor amendment.
No additional A6 control.
No comparison.
No historical analysis.
No B6.
No product A/B.
No snapshot.
No ZIP or handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The failed pristine-final run remains strong evidence: it shows that the source, PTY policy, terminal universe, and semantic extraction were sound while one verifier field was structurally overconstrained. It cannot be promoted to qualification or substitute for the fresh five-control A6 run after repair. A bounded tool causal and a freshly materialized downstream control are distinct gates. 

Any successor repair changes the tested bytes and therefore requires new validation, provenance, and later a fresh independent audit.   Provenance will bind the exact repaired policy and control bytes, but it will not prove that the chosen stable-field lattice is secure or complete. 

### Sources

- Codex’s `REPAIR10I_A6_VALIDATION_BLOCKED` report supplied in the current turn.
- Milestone 0 proof-scaffolding and evidence-authority boundary. 
- Sealed A2 bounded-causal/downstream-control distinction. 
- Governed Execution repair and re-audit lifecycle.  
- Provenance limitations. 

**Confidence:** 0.999 that A6 correctly stopped; 0.97 that the blocker is a successor read-policy identity-model defect rather than a repository or semantic defect; 0.88 that grant-kind-specific exclusion of directory size from mutable-tree identity is the right correction; 0.98 that a read-only contract freeze should precede implementation; 0.995 that the complete five-control A6 refresh must restart after the repaired successor seals.
