This is a **correct stop**, and it materially narrows the remaining problem.

A4 did not fail. It did exactly what it was supposed to do: all five controls qualified with zero unknowns, and the comparator refused to call final↔fresh equal because one required test had different terminal outcomes. The divergence is therefore not something to normalize away or dismiss as harmless raw-output noise.

The remaining uncertainty is now local:

- a real timing or process-custody defect in the shell bounded Git runner;
- a nondeterministic assertion or fixture in `one_pipe_closes_first`;
- or a validation-environment assumption that was not actually equivalent between the two controls.

The evidence provided does **not** yet distinguish those. A retry of B4 would be the wrong move: it might pass by chance and destroy the opportunity to establish why the first final control failed. Preserve B4 unsealed and unchanged.

The next turn should be a narrow, read-only causal investigation. Only after that investigation should we freeze either a repository repair or, less likely, another successor amendment. Any changed bytes will require a fresh downstream execution rather than promotion of B4’s partial results; this is consistent with the established amendment/restart rule used earlier in the chain. 

Pass this to Codex:

```text
Objective

Diagnose the exact cause of the Repair 10I-B4 final↔fresh divergence:

TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
one_pipe_closes_first

This is a parent-only, read-only causal-reconciliation turn.

Do not repair repository source.
Do not repair successor source.
Do not retry or resume Repair 10I-B4.
Do not seal, rewrite, clean, rename, or delete B4.
Do not create a new B5 validation child.
Do not create a ZIP, handoff, capture child, or snapshot.

Determine whether the divergence is:

1. a production shell bounded-runner defect;
2. a test/fixture nondeterminism defect;
3. a validation-construction or environment-equivalence defect;
4. a successor extraction/comparison defect;
5. or presently unresolved.

Return one frozen, executable repair plan with an exact touched-file scope and
fresh-validation restart requirements.

No subagents.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Immutable sealed successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Immutable failed validation child

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800

Optional new diagnostic child, required absent before creation

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-divergence-recon-4dd211207800

The diagnostic child is evidence only. It must not become validation authority.

## 1. Opening baseline

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- repository inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require exact A4 identity:

- T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

A4 binaries:

repair10-runner:
  9df605f44e2a5fa10cd8bbc9360a7709a739f209fa4bf386353c8a790ef45961

repair10-compare:
  e53c6878acddb2e601376486ee8994d73bf30f176606ca7f42dea8434ddc6f0f

repair10-semantic:
  ef378cfe85c26f1e45eb6f4a0895d58c53647c1b74a685d1636bccbb81a52a66

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Completely reverify A4 and B4 path sets, modes, sizes, hashes, links, and
available detached digests. B4 remains unsealed and nonqualifying.

Stop before further work on any mismatch:

REPAIR10I_B4_DIVERGENCE_BASELINE_MISMATCH

## 2. Bind the exact observed divergence

Read and identity-bracket at minimum:

- B4 final suite specification;
- B4 fresh-final suite specification;
- final and fresh source inventories/T records;
- final and fresh complete environments;
- final and fresh effective read policies;
- command intents and results;
- raw stdout/stderr through EOF;
- terminal reconciliations;
- resource ledgers;
- producer semantic envelopes;
- peer re-extractions and qualifications;
- final↔fresh comparison specification;
- final↔fresh comparison result;
- validation-blocked finding;
- closeout adjudication.

The report names:

comparisons/final-fresh-result-v1.json

findings/validation-blocked-final-fresh-v1.json

closeout/closeout-adjudication-v1.json

Recover the exact package, test, subtest, action transition, failure text,
timestamps or durations, exit state, and surrounding raw JSONL records for:

TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
one_pipe_closes_first

Prove whether:

- final recorded fail and fresh recorded pass;
- this was the only lifecycle difference;
- diagnostic differences are solely consequences of that terminal difference;
- both source trees and test bytes were exact;
- both controls used the same logical command and intended environment contract;
- neither control had a custody, EOF, process, listener, resource, terminal, or
  qualification fault.

Do not infer the failure mechanism from the test name alone.

## 3. Inspect the exact source and call path

Inspect, with exact line references:

- the complete test:
  TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7
- its subtest:
  one_pipe_closes_first
- every helper used by that subtest;
- the bounded shell Git-runner implementation exercised by it;
- the Perl or shell supervisor, pipe creation, select/poll loop, deadline,
  process-group termination, wait, EOF, and output-cap handling;
- any fixture process or helper that intentionally closes one pipe before the
  other;
- timeout constants, sleep intervals, polling cadence, scheduling assumptions,
  and expected event ordering;
- cleanup and process-custody paths;
- assertions that distinguish a production invariant from a timing expectation.

Principal likely source surfaces include, but are not limited to:

- remote_alpha_prepare_external_tls_status_test.go
- scripts/remote_alpha_prepare_external_tls_status.sh
- docs or contract tests governing bounded Git execution

Do not presume both files require changes.

Produce a precise control-flow account from fixture launch through terminal
assertion.

## 4. Reconstruct control equivalence

Compare final and fresh controls field by field.

Classify every difference as:

- required physical disjointness;
- governed root-derived difference;
- semantically irrelevant and predeclared;
- execution-affecting;
- unexplained.

Pay particular attention to:

- physical source-root length;
- TMPDIR/GOTMPDIR length;
- executable and helper paths;
- shell and Perl identities;
- PATH;
- locale;
- process IDs and process-group IDs;
- pipe FD numbering;
- resource limits;
- command timeout;
- per-command and suite deadlines;
- scheduling or concurrency settings;
- inherited open descriptors;
- sandbox profile bytes;
- filesystem and parent-directory modes;
- stdout/stderr caps;
- process-start and readiness ordering.

Determine whether the two controls were logically equivalent for this test, not
merely qualified under the general successor contract.

## 5. Focused causal reproduction

Use fresh, complete, no-hardlink private copies of exact repository T
4dd2112078004c3d82d24a5167f16a6f25fe33ed.

Do not execute in the live repository.

Use at least three physically disjoint controls under umask 077 with private
HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR and no shared mutable state.

First run the exact focused command in each control:

go test -json -count=30 -p=1 -parallel=1 . \
  -run '^TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/one_pipe_closes_first$'

If package placement requires an adjusted package argument, record the exact
reason and use the package that actually owns the test. Do not broaden the test
selection.

Then run thirty independent process-level invocations per control:

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/one_pipe_closes_first$'

Each invocation must have:

- its own command intent;
- exact argv/cwd/environment;
- bounded streams through EOF;
- exit and Wait result;
- terminal reconciliation;
- process/resource cleanup;
- no survivor or forced cleanup;
- raw JSONL retained until analysis finishes.

Stop the repetition once a failure is reproduced, but preserve completed
controls and report the exact denominator. Do not retry a failed occurrence.

If the exact B4 failure cannot be reproduced, run only bounded differentiating
controls justified by source inspection, such as:

- the same fixture with parent-root path lengths matched to B4 final and fresh;
- an existing causal control with one pipe closing first and the other remaining
  open;
- an existing causal control where both pipes close before child exit;
- an existing deadline or child-exit variant.

Do not patch or dynamically rewrite repository source.

Do not invent a new acceptance condition.

## 6. Required classification

Return a claim ledger distinguishing:

### Production defect

Use only if the governed shell supervisor can violate its bounded execution,
EOF, deadline, process-group, Wait, output, or cleanup contract under the valid
fixture.

Identify:

- exact source mechanism;
- exact externally observable consequence;
- whether the failure is safety, correctness, boundedness, availability, or
  diagnostic;
- minimal production/docs/tests scope.

### Test or fixture defect

Use only if production behavior satisfies the written contract and the failure
comes from an unstable timing, scheduling, FD-number, ordering, sleep, or
assertion assumption.

Identify:

- the exact unstable assumption;
- why it is not a product guarantee;
- the causal replacement test;
- how the replacement still kills the intended product mutant.

Do not weaken the test merely to make it pass.

### Validation-construction defect

Use only if final and fresh controls were not logically equivalent for this
test despite general qualification.

Identify:

- the execution-affecting field;
- why qualification failed to detect it;
- whether repository source, successor source, or only B4 orchestration must
  change.

### Successor defect

Use only if both raw test executions had the same actual terminal outcome and
A4 extraction/comparison produced a false lifecycle difference.

This currently appears unlikely, but must be ruled out from raw JSONL rather
than assumed.

### Inconclusive

Use when no mechanism is established.

State exactly what remains unknowable and what bounded experiment is required.
Do not recommend a speculative patch.

## 7. Frozen repair-plan requirements

If a mechanism is established, freeze:

- finding ID;
- type and severity;
- current contract;
- exact paths and lines;
- exact evidence;
- production versus test versus validation/tool classification;
- smallest coherent touched-file set;
- governing docs that must change with code, if any;
- failing causal test that must precede implementation;
- positive and negative validation;
- race or repeated-run requirements;
- exact provenance and evidence requirements;
- stop conditions.

State explicitly whether the next write turn is:

- a repository-only Repair 10I-A5;
- a successor-only Repair 10I-A5;
- a combined but still bounded Repair 10I-A5;
- or no repair yet.

Do not freeze B5 execution details beyond this rule:

Any repository or successor byte change requires a completely fresh B5,
rerunning all five source controls, all five comparisons, and product A/B from
the beginning. No B4 source-control result may become B5 qualification.

## 8. Evidence and cleanup

The optional diagnostic child may contain:

- opening identities;
- copied B4 evidence needed for diagnosis, with origin bindings;
- source inspection report;
- focused command records and raw streams;
- causal observations;
- classification and frozen repair plan;
- failed and superseded diagnostic attempts;
- cleanup record.

Do not present it as a sealed implementation or validation tranche.

Remove every private source, cache, Git store, process, descriptor, socket,
listener, runtime root, and temporary helper created by this investigation.

Require two absence epochs.

Do not mutate B4 or A4.

## 9. Closing gate

Reverify:

- repository source T/inventory/membership;
- branch/HEAD/parent/HEAD tree/upstream/index;
- staged/deleted/renamed/unmerged posture;
- protected repository source hashes;
- Repair 10I-A/A2/A3/A4;
- Phase H;
- B, B2, B3, and B4 path sets and bytes;
- public ZIP/handoff/capture targets remain absent;
- no Git operation marker or lock;
- no diagnostic-owned survivor or residue.

## 10. Verdicts

Exact, repair-ready root cause:

REPAIR10I_B4_DIVERGENCE_RECONNAISSANCE_READY

Report the classification and frozen Repair 10I-A5 scope.

Exact successor/extractor false-difference defect:

REPAIR10I_B4_SUCCESSOR_DEFECT_CONFIRMED

Exact production supervisor defect:

REPAIR10I_B4_PRODUCT_DEFECT_CONFIRMED

Exact test/fixture defect:

REPAIR10I_B4_TEST_FIXTURE_DEFECT_CONFIRMED

Exact validation-construction defect:

REPAIR10I_B4_VALIDATION_CONSTRUCTION_DEFECT_CONFIRMED

Insufficient evidence:

REPAIR10I_B4_DIVERGENCE_INCONCLUSIVE

Opening mismatch:

REPAIR10I_B4_DIVERGENCE_BASELINE_MISMATCH

No source mutation.
No successor mutation.
No sealing of B4.
No B5.
No snapshot or capture.
No staging, commit, push, installation, live route, remote contact, or
independent-audit claim.
```

The critical point is that final↔fresh equality is a substantive acceptance condition, not a cosmetic comparator result. A required test that passes on one independent final control and fails on the other means the current bytes have not demonstrated deterministic restoration. Provenance can prove that both controls used the intended bytes; it cannot turn that inconsistent behavior into correctness. 

### Sources

- Codex’s Repair 10I-B4 report in the current turn.
- Sealed A2 precedent: successor causal evidence does not replace a freshly materialized downstream source control. 
- Governed Execution protocol: implementation validation and independent audit are separate, and repair bytes require a new audit cycle.  
- Provenance guidance: exact-byte identity does not establish correctness or test sufficiency. 

**Confidence:** 0.995 that B4 stopped correctly; 0.97 that the divergence is in the product/test/validation execution layer rather than A4’s comparator; 0.72 on whether the underlying cause is the production shell supervisor or its causal fixture until the retained failure and focused repetitions are inspected.
