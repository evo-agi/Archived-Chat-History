Here is Codex's response:

# AUDIT\_PROVENANCE\_MISMATCH

1. **Primary verdict**\
   `AUDIT_PROVENANCE_MISMATCH`. Direct Auditor 3 created and deleted four `/tmp` files despite the absolute read-only auditor boundary. This is process execution outside declared authority, so no package-level primary verdict is authorized.
2. **Fresh audit-root identity**\
   `/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv`\
   Device/inode `16777234 / 179156020`, mode `0700`.
3. **Package identity and closure**\
   Package root matched `16777234 / 179120828`, mode `0700`. Its manifests were byte-identical, 33,552 bytes, SHA-256 `cec56d4c9ac08c79ae7da58107fd56cd3389ba879ed566e327b4582ae27e259b`. Live closure was 177 represented entries: 12 directories and 165 nonmanifest files; 167 physical files including manifests.
4. **Immutable-input identities**\
   All expected root identities and named file identities matched at opening. Pinned Python was regular, single-link, 119,424 bytes, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`; mode `0775` was accepted as report-only. All supplied roots were byte/metadata equal at close.
5. **Process authority and child ledger**\
   `top_level_launch_authority = "codex-platform-tool-transcript"` and `audit_root_does_not_self_attest_parent_process_creation = true`. Six child attempts were recorded contiguously: ENOENT causal, `/usr/bin/true`, two materializations, and two handoffs. Every record includes argv, cwd, explicit environment, streams, outcome, reaping, and descriptor closure. See [child ledger](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/provenance/complete-child-process-ledger.json).
6. **Direct auditors and schedule**\
   Auditors 1–3 started concurrently; completion order was 1, 3, 2. Auditor 4 was not started after the mandatory stop. Auditor 1 and 2 remained read-only. Auditor 3 disclosed the four unauthorized transient writes. Reports: [Auditor 1](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/auditors/auditor-1-report.md), [Auditor 2](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/auditors/auditor-2-report.md), [Auditor 3](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/auditors/auditor-3-report.md).
7. **Exact source identities**\
   `full_audit_bootstrap_v1.py`: 81,613 bytes, `01fb237ef588241e7147abf92baa59009d0b159dd5bc5543e70f7f83d82b01f5`.\
   `process_self_check_payload_v1.py`: 18,433 bytes, `a6e83b46b4696b92a2a6cd66b9e7709d51f1ce376703138cf808f10e7582642e`.\
   `qualification_harness_v1.py`: 66,641 bytes, `47d12bc390fd41a255f8b0adfa8e02826b8f25419195a3ac8f8fa596a0666fe8`.\
   Implementation report: 3,062 bytes, `7f4f8841130917fa672a24b5c3ad85cdfe1ce29b9aa09e0241dfe58a10363a29`.
8. **Production export boundary**\
   Static inspection found `full_audit_bootstrap_v1.py` is the future-audit executable, `process_self_check_payload_v1.py` is the runtime template, and `qualification_harness_v1.py` is qualification-only. Production did not depend on tests, producer validation, lineage, closeout reports, or the qualification harness.
9. **Authority and nonauthority**\
   Current source constants and the main contract describe process-only authority and the complete nonauthority set. However, bootstrap start/outcome/result and self-check results inherit rather than repeat that complete boundary, creating an unresolved explicit-agreement issue.
10. **CLI and root allocation**\
    Exact four-option CLI, no target-root option, literal roots, `tempfile.mkdtemp`, umask `077`, and exact locator behavior were observed. High-severity defect: production verifies the interpreter identity but does not verify actual `-I -S -B` flags, while recording those flags unconditionally.
11. **Literal process-input selection**\
    Static inspection found fixed literal paths with no scoring, fallback, glob selection, latest/newest selection, PATH lookup, or existing-root adoption.
12. **Qualified-package verifier**\
    The qualified manifest pair matched: 12,404 bytes and SHA-256 `a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb`. Full independent verifier mutation work stopped after the process mismatch.
13. **Reconciliation verifier**\
    Exact `closeout/verdict.json` identity and `/verdict` value matched. Production does not enforce the reconciliation root’s expected device/inode, only its literal path and content closure.
14. **Five-artifact copy boundary**\
    Both materializations copied exactly the five expected byte identities. Defect: the separately contracted post-copy re-verification step compares cached identity dictionaries instead of reopening the copied files.
15. **Fixed-environment record**\
    Both fresh records had exactly `authority`, `environment`, and `schema`, with the required six-key environment and fresh-root HOME/TMPDIR values.
16. **Launcher identity and root-bound contract**\
    Both materializations generated fresh launcher identities and root-bound contracts. The observed current outputs matched their expected copied launcher and auxiliary identities.
17. **Twelve-pointer proof**\
    Both outputs used the exact schema, twelve ordered pointers, physical-root-only classification, semantic effect `none`, normalized equality, and non-root difference count zero.
18. **Carrier 0002 assertion map**\
    Both handoffs produced all 30 named positive assertions as `true`. Raw false posture was separate from the positive assertion map.
19. **Target-inspection polarity**\
    The repaired polarity is correct: `target_content_inspected_is_false` is positive when true. Full independent absence-of-inspection proof was not completed.
20. **Payload identity treatment**\
    The vacuous self-comparison assertion is absent and the result states wrapper-authoritative verification. Auditor 3 found that retained producer evidence does not independently replay that claim.
21. **Same-PID evidence**\
    Both generated results reported equal launcher/payload PIDs. This was not accepted as fully verified because the comparison was not anchored to the recorder-observed spawned PID.
22. **Environment evidence**\
    Both handoffs reported exact constructed environments, exact contract-owned observed values, and diagnostic-only additional key names without additional values.
23. **CLI and wrapper SHA**\
    Both results reported CLI conformance and wrapper SHA value/cardinality success. Auditor 3 found incomplete binding of all option values and SHA-to-option association.
24. **Fresh independent mutation matrix**\
    Not completed after the mandatory provenance stop.
25. **Two materializations**\
    Both distinct roots materialized successfully. Payload bytes, normalized launch contracts, fixed-environment records, and requests—after explicit root-bound contract-digest normalization—agreed.
26. **Two Carrier 0002 handoffs**\
    Both individual handoffs exited zero with successful result records. The full requirement did not pass: root/PID-only normalization left differences at `/environment_evidence/constructed_map_sha256` and `/environment_evidence/launch_contract_map_sha256`.
27. **Failure-atomicity causals**\
    Not independently completed. Auditor 2 found the producer cases omit important verifier and final-success-publication boundaries.
28. **Root-layout adjudication**\
    Not completed because Auditor 4 was never started. No affirmative no-placeholder conclusion is issued.
29. **Security and sensitive-material findings**\
    Completed static work found no production network, Git, shell, candidate path, target path, or automatic target-audit progression. The full sensitive-material review was not completed.
30. **Producer/independent validation**\
    Auditor 3 found several claimed negative cases were hard-coded or synthetic rather than exercised through the claimed rejection boundary.
31. **Failed and superseded attempts**\
    Historical failed-audit polarity, extra `policy` field, and malformed rebinding proof were corroborated. Broader attempt adjudication stopped early.
32. **Manifest and inventory chronology**\
    Package opening and closing inventories were equal. Full package chronology adjudication was incomplete. The fresh capsule itself was sealed correctly after its final temporal inventory.
33. **Supplied-root closing equality**\
    All five supplied roots and pinned Python matched their opening states. See [closing equality](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/closeout/supplied-root-closing-equality.json).
34. **Fixture cleanup**\
    Only the two audit-owned materialization roots and preparatory driver were removed. Each removal produced two ENOENT observations. The four disclosed `/tmp` paths also produced two ENOENT observations each. Cleanup is recorded in [cleanup-completion.json](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/fixtures/cleanup-completion.json).
35. **Audit-capsule closure**\
    Final temporal inventory: 12,836 bytes, SHA-256 `0748849bc4d0a662e7ce6a5bb2b745eedc0b4757454b2856b74524c0d3e53513`. Terminal manifests are byte-identical, 12,860 bytes, SHA-256 `6935ae04a130a5f1f27fd8c2f0cd9b829ba50213c909652292ab4da2f006d12b`; 11 directories, 67 represented nonmanifest files, and 69 physical files including manifests. See [final report](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/closeout/final-audit-report.md).
36. **Severity-ranked findings**\
    Fatal audit-process finding: unauthorized direct-auditor writes. Partial package findings include unverified interpreter flags, fail-open contract/schema alignment, fictitious post-copy reverification, non-atomic final success publication, deleted replay evidence, synthetic negative cases, and unanchored same-PID evidence. Full list: [severity-ranked findings](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-independent-audit-n0qou3qv/analysis/severity-ranked-findings.json).
37. **Minority findings and resolution**\
    Auditor 1 treated authority inheritance as potentially acceptance-affecting but left it for parent resolution. The parent did not resolve that package question because provenance failure superseded package adjudication.
38. **Remaining uncertainty and nonclaims**\
    No conclusion is granted over the candidate repository, Strategic B, V1/V2/V3 targets, product/runtime behavior, publication, commit, deployment, readiness, eventual V3 verdict, or A6. A fresh audit is required.
39. **Explicit confirmations**
```
FULL_AUDIT_BOOTSTRAP_PACKAGE_MUTATION_NOT_PERFORMED=true
FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED=true
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED=true
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED=true
REPAIRED_IMPORTER_REFERENCE_MUTATION_NOT_PERFORMED=true
PACKAGE_SOURCE_IDENTITIES_INDEPENDENTLY_BOUND=true
PRODUCTION_EXPORT_BOUNDARY_CLOSED=true
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY=true
CANDIDATE_REPOSITORY_NOT_INSPECTED=true
STRATEGIC_B_NOT_INSPECTED=true
V1_V2_V3_TARGETS_NOT_INSPECTED=true
LITERAL_EXACT_PATH_SELECTION_VERIFIED=true
EXACT_FIVE_PROCESS_ARTIFACTS_COPIED=true
FIXED_ENVIRONMENT_RECORD_EXACT_THREE_FIELD_SHAPE=true
REBINDING_PROOF_EXACT_SCHEMA=true
REBINDING_PROOF_EXACT_TWELVE_POINTERS=true
NORMALIZED_LAUNCH_CONTRACTS_EQUAL=true
NON_ROOT_DIFFERENCE_COUNT_ZERO=true
TARGET_INSPECTION_POLARITY_CORRECT=true
RAW_FALSE_TARGET_STATE_NOT_USED_AS_POSITIVE_ASSERTION=true
VACUOUS_PAYLOAD_IDENTITY_ASSERTION_ABSENT=true
SAME_PID_DYNAMIC_EVIDENCE_VERIFIED=false
CONSTRUCTED_ENVIRONMENT_VERIFIED=true
OBSERVED_OWNED_ENVIRONMENT_VERIFIED=true
ADDITIONAL_ENVIRONMENT_KEYS_DIAGNOSTIC_ONLY=true
WRAPPER_SHA_VALUE_AND_CARDINALITY_VERIFIED=true
CLI_CONFORMANCE_VERIFIED=false
NO_CHILD_PROCESS_VERIFIED=false
NO_TARGET_INSPECTION_VERIFIED=false
FRESH_INDEPENDENT_MUTATION_MATRIX_PASSED=false
TWO_FRESH_MATERIALIZATIONS_PASSED=true
TWO_CARRIER_0002_HANDOFFS_PASSED=false
FAILURE_ATOMICITY_CAUSALS_PASSED=false
NO_PLACEHOLDER_ONLY_ARTIFACT_ADMITTED=false
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS=true
FOUR_AUDITOR_INTERACTIONS_RECONCILED=false
NO_NETWORK_CONTACT=true
NO_GIT_INVOCATION=true
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION=true
FULL_V3_AUDIT_NOT_STARTED=true
A6_NOT_STARTED=true
NO_NESTED_SUBAGENTS=true
```
