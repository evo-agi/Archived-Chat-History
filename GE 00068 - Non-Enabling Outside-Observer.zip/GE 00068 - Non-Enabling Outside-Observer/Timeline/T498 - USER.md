Here is Codex's response:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_CREATED_READY_FOR_FRESH_AUDIT

The sealed authority is [gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json](/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-authority-v2-output-b1a0mfnn/gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json).

## Operative report

1. **Primary verdict:** successful authority-v2 creation and qualification.

2. **Fresh authority-build root:** `/private/tmp/ES-repair10i-v3-clean-harness-external-authority-v2-build-etyn0ad3`; device `16777234`, inode `182023515`, mode `0700`. It has been removed.

3. **Fresh authority-output root:** `/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-authority-v2-output-b1a0mfnn`; device `16777234`, inode `182023516`, mode `0700`. It contains only the final authority file.

4. **Unchanged PYZ:** device `16777234`, inode `181950905`, mode `0400`, links `1`, size `1442390`, SHA-256 `19496183b8eb3e7545f9ebda8f966a41839ad67251239d5be2ba801d84cb0174`.

5. **Predecessor authority v1:** device `16777234`, inode `181950910`, mode `0400`, links `1`, size `14748`, SHA-256 `6c39b301198727e7a152e27c5d3db0e3bf53b3b45b4ae6deabd955c74cc067ae`.

6. **Content bundle:** device `16777234`, inode `181651092`, mode `0400`, links `1`, size `13598758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`.

7. **Content authority:** device `16777234`, inode `181651098`, mode `0400`, links `1`, size `19737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`.

8. **Stable input authentication:** all four inputs passed two no-follow stable reads, regular-file/link/mode checks, byte equality, and expected identity checks. Both authority JSON documents passed strict UTF-8 parsing with duplicate-key and nonfinite rejection.

9. **Predecessor disposition:** `historical_predecessor_launch_authority_incomplete`; immutable and historically valid, but noncurrent after authority-v2 success. Its limitation remains incomplete final-PYZ qualification/reconciliation binding—not corruption.

10. **PYZ closure:** exactly `93` sorted ZIP_STORED regular-file members; fixed timestamp, create-system `3`, mode `0600`, no duplicates, unsafe paths, directories, symlinks, special members, comments, extras, caches, or bytecode. Member-list digest: `9bc065d21a534509f8c8a7174afb2a315dd160aaf2bce89054417c81d50e0f3b`. Member-registry SHA-256: `89c244cab0caedccf094947bbbaf6c7aa10d548e4752b099614a2737dec8a0be`.

11. **Invocation derivation:** derived solely from `__main__.py`, embedded fixed-input/package/future-invocation contracts, and predecessor authority. The only additional operand was the already-bound documentary root: device `16777234`, inode `181874306`, mode `0700`.

12. **Platform preflight:** executed once. PID `38869`; duration `15,228,250 ns`; exit `23`; signal `null`; reaped and descriptors closed. Stdout/stderr were the exact required 27-byte strings and hashes.

13. **Exact qualification argv:**

```text
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-attempt2-qw4sqw4r/gen2-clean-source-external-independent-audit-harness-v1.pyz
--mode
qualify-harness
--bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--bundle-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--documentary-contract-root
/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u
```

14. **Cwd/environment:** cwd was the unchanged PYZ directory, with wrapper-custody effect only. Environment was exactly `PATH=/usr/bin:/bin`, `LANG=C`, `LC_ALL=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`; stdin `DEVNULL`; shell/TTY/detachment false.

15. **Qualification custody:** PID `38870`; start `2026-10-01T01:48:04.534164Z`; completion `2026-10-01T01:48:04.633909Z`; duration `99,759,084 ns`. Python executable identity: device `16777234`, inode `2301718`, mode `0775`, size `119424`, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`. Process reaped; descriptors closed.

16. **Raw stdout:** size `6493`, SHA-256 `f2085502ab0c1f5f93f27afe8ed87a1f83687269cd0b890c6ed8db400c1e2fd7`. Exactly one canonical UTF-8 JSON frame plus one LF; no chatter, duplicate record, or trailing bytes.

17. **Raw stderr:** size `0`, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; handled-result posture satisfied.

18. **Qualification completion:** exit code `0`; signal `null`; process error `null`.

19. **Fresh result identity:** canonical size `6493`, SHA-256 `f2085502ab0c1f5f93f27afe8ed87a1f83687269cd0b890c6ed8db400c1e2fd7`.

20. **Fresh result contents:** schema `frozen-pyz-qualification-record-v1`; guarded result `HARNESS_QUALIFICATION_PASSED`; PYZ self-authentication, bundle authentication, embedded documentary authentication, documentary terminal closure, packaged evidence, and fresh qualification all passed. Derived values were `5/66/81/15/595`; documentary inventory had `50` entries and `20` roles. No full audit, implementation verdict, or current subject occurred.

21. **Exact final-PYZ binding:** argv position, launch-time no-follow identity, predecessor binding, fresh self-authentication, raw-stream custody, and current closing identity all resolve to the same fixed PYZ.

22. **Source freeze:** member size `15709`, SHA-256 `66baa80b61868477acc5b6107faec48c1431f851fcb023e265cfb7e28b0fb409`; `22` sources; zero drift; source unchanged after freeze.

23. **Source registries:** production `14`, SHA-256 `c8771fae5bc0dde04e054125fffca5890bbde087f27a08b60810ca326c4a0490`; qualification `4`, SHA-256 `c72cc5158821fe04bff33252d60ebcd8a1672c6ff21208b9fb57c7ff97d3fc08`; independent `4`, SHA-256 `98f0300b5f212a7eedb5d9ba31fb4eb1cf2d75ff7a92d8ba2149a5c64d662229`.

24. **Runtime governance:** five-domain contract `d4f3a8…bc4c11`; report registry `9db3f1…304c1` (`66`); confirmation registry `547ae9…3367e` (`81`); matrix registry `1a9c75…083eb` (`15/595`); aggregate-owner registry `51c8a4…07618`; stale `645` disposition `cf7e48…7d06a`.

25. **Matrix results:** all passed with exact case totals and identities: B00 `70/62dacc…aa69`; D01 `30/6e5997…5c39`; D02 `25/428d1c…f6b0`; D03 `30/20e7d2…3d97`; D04 `30/395a2a…f2e4`; D05 `35/a12d7f…4e93`; D06 `100/fd1dbe…ce4a`; D07 `30/d7776f…deae`; D08 `40/a6817c…a0d`; D09 `40/3dd0a1…b9fa`; D10 `30/c0b41b…6a3a`; D11 `50/1cc23c…8d81`; D12 `35/f12435…924b`; D13 `25/2fc2ca…257b`; D14 `25/528533…6bae`.

26. **Process-custody qualification binding:** size `6706`, SHA-256 `c9789507b4660c2fdb5b35ffb5676ffc651dcaa08d5b0706ca848c4411a258f9`; all fifteen custody checks passed.

27. **Synthetic lanes:** ACCEPT, BLOCK, and provenance-mismatch lanes matched their expected outcomes. Constructed-subject pair was physically distinct, semantically equal, and passed. Evidence SHA-256 `60f5002b35e3eb65600d30eda6b29be3a91b40ecaefd3d3da7a856cd4c27c301`.

28. **Compatibility replay:** passed without package verdict, implementation verdict, implementation-source execution, or current-subject construction. SHA-256 `532ad7eb429c8c95ed24568133848ef815c5acca0543f2f5941d3df38d8b6b5a`.

29. **Rehearsals:** A and B each passed all `12` components. Their provisional PYZs were byte-identical at size `248837`, SHA-256 `ce9a50443c37ea7079b5a14a6432af45989b01d091532d18037cccf2598e77dd`; normalized semantic equality passed with zero unexplained differences.

30. **Independent-validator bindings:** embedded source and evidence validators passed; the embedded aggregate remains labeled `prepackage` with its historical package-validator state `pending-final-package`. The new source-external authority-v2 validator separately authenticated the final PYZ and authority and closed with zero errors.

31. **Deterministic-package binding:** current PYZ bytes, self-authentication, and 93-member closure were directly recomputed. Historical Build-A/B equality remains transitive through package-build record SHA-256 `98d3dd12a3d4e36c5345f81274e35fe75edd1a30ff727cdbe1c97254abd5e3a6` plus the specific embedded Build-A, Build-B, byte-equality, member-closure, and frozen-requalification confirmations.

32. **Package status:** size `677`, SHA-256 `644929e34e558de76927083cb01c0b4e333e44e1be7e65e5f3d50725e804ecfe`; source frozen, qualification passed, ready for one fresh audit, full audit false, implementation verdict not issued.

33. **Frozen-PYZ crosswalk:** all `38` required facts passed with direct/transitive authority labels, exact evidence pointers, and independent recomputation where applicable.

34. **Final reconciliation v2:** all `24` components agreed; disagreement count `0`; conclusion `UNCHANGED_FINAL_PYZ_FRESHLY_REQUALIFIED_AND_EXTERNALLY_RECONCILED`.

35. **Authority-v2 contents:** schema `clean-source-external-independent-audit-harness-authority-v2`, version `2`, current authority true. It self-contains fixed identities, member/source/runtime bindings, both raw process streams, parsed qualification result, 38-fact crosswalk, reconciliation, package evidence, future invocation, nonexecution flags, confirmations, next treatment, and nonclaims. It contains no build-root dependency or mutable evidence pointer. The linked 81,008-byte file is the complete canonical object.

36. **Authority Build A:** size `81008`, SHA-256 `782dd6a5d26508bd9bcd7942336d1cab4f1600fde37fabff314d0b8f4291691e`.

37. **Authority Build B:** size `81008`, SHA-256 `782dd6a5d26508bd9bcd7942336d1cab4f1600fde37fabff314d0b8f4291691e`.

38. **A/B equality:** identical bytes, size, digest, parsed object, key order, canonical serialization, and single trailing LF. No authority-bearing PID, uncontrolled generation timestamp, build-root path, or mutable pointer was present.

39. **Independent authority-v2 validation:** passed with zero errors. It independently reauthenticated the four inputs, 93-member PYZ, 479-member/8-role bundle, fresh streams, 5/66/81/15/595 counts, source freeze, matrices, custody, synthetic lanes, replay, rehearsals, package status, future invocation, A/B equality, self-containment, and launch justification.

40. **Source repair:** not performed.

41. **PYZ mutation/rebuild:** neither occurred; opening, launch-time, prepublication, postpublication, and final identities match.

42. **Real audit:** `run-full-audit` launch count was zero; no target audit was executed.

43. **Implementation posture:** no implementation production source was executed, no implementation verdict was issued, and no current schema subject was constructed.

44. **Input closing equality:** all four files closed equal on device, inode, mode, link count, size, and SHA-256.

45. **Cleanup:** the sole build root was completely inventoried, evidence was retained before cleanup, its identity was revalidated, and two ENOENT observations followed removal. No qualification root was emitted. No process, descriptor, cache, or bytecode survived.

46. **Failure closeout:** implemented but unused; same-root retry remained false. A provisional authority would have been classified nonauthoritative and removed on failure.

47. **Final authority identity:** device `16777234`, inode `182023548`, mode `0400`, links `1`, size `81008`, SHA-256 `782dd6a5d26508bd9bcd7942336d1cab4f1600fde37fabff314d0b8f4291691e`.

48. **Mandatory next treatment:** exactly one fresh independent audit using the unchanged PYZ, this authority-v2 JSON, the current bundle, and the current bundle authority. Authority v1 must not be supplied as current launch authority. Authority creation and audit execution remain separate.

49. **Remaining uncertainty/nonclaims:** no implementation-package judgment was made; historical package Build-A/B evidence was not reopened; no current subject was constructed; no audit ran. Consistent with repository governance, this external launch authority is not repository architecture authority. No repository files or documentation were changed.

50. **Explicit confirmations:**

```text
UNCHANGED_HARNESS_PYZ_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V1_IDENTITY_MATCHED
CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V1_DISPOSITION_RETAINED
PYZ_MEMBER_SET_CLOSED
EXACT_QUALIFY_HARNESS_INVOCATION_DERIVED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
QUALIFY_HARNESS_EXECUTED_EXACTLY_ONCE
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
QUALIFY_HARNESS_PROCESS_CUSTODY_COMPLETE
QUALIFY_HARNESS_RAW_STDOUT_RETAINED
QUALIFY_HARNESS_RAW_STDERR_RETAINED
QUALIFY_HARNESS_EXIT_AND_SIGNAL_RETAINED
FRESH_QUALIFICATION_RESULT_STRICTLY_PARSED
FRESH_QUALIFICATION_PASSED
FRESH_RESULT_BOUND_TO_EXACT_FINAL_PYZ
SOURCE_FREEZE_IDENTITY_BOUND
SOURCE_NOT_MODIFIED_AFTER_FREEZE
FINAL_SOURCE_REGISTRIES_BOUND
FIVE_DOCUMENTARY_DOMAINS_RECOMPUTED
RUNTIME_REPORT_ROW_COUNT_66_RECOMPUTED
RUNTIME_CONFIRMATION_NAME_COUNT_81_RECOMPUTED
RUNTIME_MATRIX_COUNT_15_RECOMPUTED
RUNTIME_MATRIX_CASE_TOTAL_595_RECOMPUTED
STALE_MATRIX_TOTAL_645_REJECTED
PROCESS_CUSTODY_QUALIFICATION_BOUND
SYNTHETIC_LANES_BOUND
BOUNDED_COMPATIBILITY_REPLAY_BOUND
COMPLETE_REHEARSAL_A_BOUND
COMPLETE_REHEARSAL_B_BOUND
REHEARSAL_PYZS_BYTE_IDENTICAL_BOUND
REHEARSAL_NORMALIZED_DIFFERENCE_ZERO_BOUND
INDEPENDENT_VALIDATORS_BOUND
DETERMINISTIC_FINAL_PYZ_BUILD_BOUND
FINAL_PYZ_MEMBER_CLOSURE_BOUND
FINAL_AUTHORITY_V1_RECONCILED_AS_PREDECESSOR
FINAL_EXTERNAL_RECONCILIATION_V2_PASSED
AUTHORITY_V2_SELF_CONTAINED
AUTHORITY_V2_BUILD_A_CREATED
AUTHORITY_V2_BUILD_B_CREATED
AUTHORITY_V2_BUILD_A_B_BYTES_IDENTICAL
INDEPENDENT_AUTHORITY_V2_VALIDATOR_PASSED
HARNESS_SOURCE_REPAIR_NOT_PERFORMED
HARNESS_PYZ_MODIFICATION_NOT_PERFORMED
HARNESS_PYZ_REBUILD_NOT_PERFORMED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_PYZ_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_V1_CLOSING_EQUALITY_PASSED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_CONTENT_AUTHORITY_CLOSING_EQUALITY_PASSED
AUTHORITY_OWNED_CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_AUTHORITY_V2_CREATED
FINAL_AUTHORITY_V2_MODE_0400
FINAL_AUTHORITY_V2_IDENTITY_VERIFIED
FINAL_AUTHORITY_V2_BINDS_UNCHANGED_PYZ
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```
