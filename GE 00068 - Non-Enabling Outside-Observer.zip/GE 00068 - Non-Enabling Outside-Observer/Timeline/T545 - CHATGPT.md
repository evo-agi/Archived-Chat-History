## Engineering assessment

The replacement construction remains available. The production parent was never created, so the replacement authorization is still unconsumed and no replacement subject exists. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The wrapper corrections from the preceding tranche worked:

- the terminal forward-treatment directive was retained;
- the failed final reconciliation was neither opened nor used;
- the previous failed wrapper remained report-only;
- the accepted implementation audit and content authority authenticated;
- the wrapper’s 18-role registry, equality contract, static qualification, 47-case matrix, and independent validation all passed. :chatgpt-content-reference{index="2"}

The sole blocker was this hard-coded path:

```text
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/opening/gen2-source-freeze-v1.json
```

It does not exist. Codex correctly refused to substitute some differently named file. Seventeen of eighteen fixed roles authenticated; only `accepted-source-freeze` failed. :chatgpt-content-reference{index="3"}

That proves only that the wrapper’s guessed **path** is wrong. It does not prove that the accepted source-freeze authority is absent. The implementation audit was accepted, the production source identity matched, and the accepted authority chain authenticated. The freeze role must now be resolved from its owning authority records rather than from an invented filename. :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

### Exact classification

```text
ACCEPTED_SOURCE_FREEZE_FIXED_PATH_RESOLUTION_DEFECT
```

This is another external wrapper defect, not:

- a production-source defect;
- an implementation-package defect;
- a construction-contract defect;
- a historical subject defect;
- a consumed construction attempt.

The wrapper-level equality failure is wholly derivative from that same unresolved role. It now identifies the exact failed row rather than reporting an unexplained aggregate mismatch. :chatgpt-content-reference{index="6"}

## Progression decision

Run replacement construction again in a fresh wrapper root, but resolve `accepted-source-freeze` semantically:

```text
accepted implementation audit evidence
→ accepted source-freeze role
→ accepted package/current content role registry
→ exact current relative path and identity
→ exact external package file or authenticated bundle member
```

Do not guess another filename.

Do not select by basename, recency, hash alone, similarity, or first match.

If the current authorities yield exactly one path, freeze that resolution and continue to the already resolved production invocation.

If they yield zero or multiple current candidates, stop with `CONSTRUCTION_BLOCKED`; do not launch and do not consume the authorization.

No new documentary package, findings reconciliation, implementation audit, production-source repair, or subject audit is warranted before this launch.

---

## Complete replacement Codex prompt

```text
EXECUTE ONE FRESH REPLACEMENT CURRENT-SCHEMA-SUBJECT CONSTRUCTION

RESOLVE THE ACCEPTED SOURCE-FREEZE ROLE THROUGH CURRENT AUTHORITY
INSTEAD OF A HARDCODED FILESYSTEM PATH

Objective

Execute exactly one fresh replacement current-schema-subject construction using
the independently accepted Generation-2 reconstruction-parent implementation.

The immediately preceding wrapper correctly closed every forward-authority,
historical-exclusion, equality, static-qualification, and independent-validator
gate except one.

It required the hard-coded path:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/opening/gen2-source-freeze-v1.json

That path is absent.

The accepted-source-freeze semantic role was therefore not resolved.

The production parent was not created.

The replacement authorization remains unconsumed.

Correct only this external-wrapper role-resolution defect.

Do not blindly substitute a differently named file.

Resolve the accepted source-freeze role through exact current authority:

accepted implementation audit
→ current accepted source-freeze evidence role
→ accepted implementation/content role registry
→ exact current member role
→ exact relative path and identity
→ exact external file representation when governed.

If no unique current source-freeze role/path can be established, stop before
launch with:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_BLOCKED

Do not treat an unresolved semantic role as an authorization to guess.

Do not rerun or repair the failed final reconciliation.

Do not perform another A06/A07/A08/A11 reconciliation.

Do not reinterpret, reverse, replace, or supersede the historical BLOCK.

Do not open the failed final-reconciliation root.

Do not make the preceding failed wrapper an acceptance-bearing fixed input.

Do not modify the historical subject or historical subject-audit capsule.

Do not modify the accepted implementation package or production source.

Do not execute qualification source or audit-harness source.

Do not independently audit the replacement subject in this task.

Do not promote or rebind current schema authority.

Do not execute product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite, source-external construction wrapper in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTED_AND_TERMINALLY_CLOSED_PENDING_FRESH_INDEPENDENT_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_BLOCKED

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FORWARD-TREATMENT AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Before opening any construction input, retain:

opening/forward-treatment-directive-v2.json

Required decisions:

- historical subject verdict:
  GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK;

- historical subject current:
  false;

- historical BLOCK reversed:
  false;

- further A06/A07/A08/A11 reconciliation:
  forbidden;

- failed final reconciliation qualifying:
  false;

- failed final reconciliation may be opened:
  false;

- mandatory treatment:
  FRESH_REPLACEMENT_SUBJECT_CONSTRUCTION;

- replacement authorization count:
  1;

- replacement authorization consumed:
  false before process creation;

- replacement requires a later fresh independent audit:
  true;

- current-authority promotion:
  false;

- product/runtime/target/publication/deployment/A6 authority:
  false.

Classification:

EXTERNAL_COGNITIVE_ENGINEERING_DIRECTIVE

This directive changes only forward treatment.

It does not change historical facts.

──────────────────────────────────────────────────────────────────────────────
2. HISTORICAL SUBJECT
──────────────────────────────────────────────── LIMITED TO PRESERVATION
────────────────────────────────────────────────

HISTORICAL_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-25kljb3m

Expected root identity:

- device:
  16777234
- inode:
  182600670
- mode:
  0700
- UID:
  501
- GID:
  20

Expected temporal record:

closeout/temporal-final-inventory-v1.json

- size:
  16051
- SHA-256:
  c3f5e291a35b2bfc0a4d00e93216c298bcc985e7964acaab700bb41c1a80c5bd

Expected manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16620 each
- SHA-256:
  43e5e3f726c62d144ca616412252af7fd2073abed71df3279e71581f97049ec8

Authenticate read-only:

- root identity;
- temporal identity;
- A/B equality;
- physical terminal closure;
- historical BLOCK linkage;
- noncurrent posture.

Classify:

HISTORICAL_BLOCKED_SUBJECT_NONCURRENT

Require:

- mutation:
  forbidden;
- cleanup:
  forbidden;
- same-root reuse:
  forbidden;
- repair in place:
  forbidden;
- replacement output:
  forbidden;
- current-authority contribution:
  none.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. HISTORICAL SEALED SUBJECT AUDIT
──────────────────────────────────────────────── LIMITED TO HISTORICAL BOUNDARY
────────────────────────────────────────────────

HISTORICAL_SUBJECT_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-current-schema-subject-independent-audit-u3nnutm4

Expected root identity:

- device:
  16777234
- inode:
  182616808
- mode:
  0700
- UID:
  501
- GID:
  0

Expected verdict:

GEN2_CURRENT_SCHEMA_SUBJECT_BLOCK

Expected audit temporal inventory:

- size:
  14818
- SHA-256:
  9430d301ecba2ab7d5ee1b9e6596221c82e7caaf01d0b2c3d38908f2729be84b

Expected audit manifest pair:

- size:
  15350 each
- SHA-256:
  cd323c84fa1904ae13e1d2b57beb14c06f48d19cc50876d199e4c4f7131fed06

Authenticate read-only:

- root identity;
- temporal and manifest identities;
- final reprojection;
- one seal transition;
- no postseal operation;
- historical BLOCK;
- zero historical audit-provenance errors.

Do not adjudicate the historical findings.

Classify:

HISTORICAL_TERMINAL_BLOCK_AUDIT_NONCURRENT

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. EXCLUDED HISTORICAL INPUTS
────────────────────────────────────────────────

Do not open:

/private/tmp/ES-repair10i-v3-current-schema-subject-block-final-reconciliation-jethgbgl

Do not open the preceding failed wrapper as an acceptance-bearing input:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v2-vosm4ehd

The preceding wrapper may be opened only through its exact final report when
needed to authenticate:

- production process count:
  0;
- replacement authorization consumed:
  false;
- replacement subject:
  absent;
- sole blocker:
  accepted-source-freeze fixed-path resolution;
- same-root retry:
  forbidden.

Classify:

HISTORICAL_NONCURRENT_SOURCE_FREEZE_PATH_RESOLUTION_FAILURE

Neither excluded root participates in:

- construction authority;
- source authority;
- fixed-input equality;
- invocation authority;
- subject content.

──────────────────────────────────────────────── LIMITED TO ACCEPTED CHAIN
────────────────────────────────────────────────

5. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234
- inode:
  182593190
- mode:
  0700

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234
- inode:
  182593189
- mode:
  0700

Expected accepted wrapper report:

final-wrapper-report.json

- mode:
  0600
- size:
  38653
- SHA-256:
  a5faa8fc6a4a0617c605c04951ac2b0cce8877629a4663a9f66984f96afa595c

Expected disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only the chain needed to establish:

- accepted implementation package;
- accepted production source;
- accepted source freeze as a semantic evidence role;
- production source registry;
- qualification source registry;
- exact construction contract;
- exact production invocation;
- fixed inputs;
- failure and cleanup contract;
- terminal-lifecycle contract;
- no superseding implementation package.

Resolve authoritative audit records only through:

- terminal manifests;
- capsule path registry;
- current audit indexes;
- exact evidence pointers.

At minimum resolve:

provenance/implementation-source-freeze.json
provenance/implementation-source-registries.json
provenance/implementation-lineage.json
provenance/implementation-frozen-requalification.json
analysis/source-external-evidence.json
analysis/production-authority-and-security.json
analysis/e00-g29-crosswalk.json
validation/implementation-confirmation-result.json
closeout/preseal-substantive-result.json
terminal/terminal-result.json

Do not re-audit the implementation package.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITED TO CURRENT CONTENT
────────────────────────────────────────────────

6. CURRENT CONTENT AUTHORITY

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate authority before ZIP.

Require:

- archive identity;
- 479 members;
- eight current roles;
- seven content-snapshot roles;
- one bounded failure-evidence role;
- deterministic archive equality;
- independent archive validation;
- no `.DS_Store`.

Resolve accepted construction inputs through:

accepted implementation audit
→ exact content semantic role
→ bundle role/index
→ exact member path and identity.

Do not use the containing directory as authority.

Require opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
7. FRESH WRAPPER ROOT
──────────────────────────────────────────────── LIMITED TO EXTERNAL CUSTODY
────────────────────────────────────────────────

Allocate one fresh private root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-

Immediately emit:

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT=<absolute-path>

Before substantive resolution retain:

opening/bootstrap-start.json
opening/forward-treatment-directive-v2.json
opening/replacement-wrapper-authority-v2.json
opening/fixed-input-role-registry-v2.json
opening/excluded-historical-inputs-v2.json
opening/process-execution-policy-v2.json

The wrapper may write only:

- wrapper source and qualification;
- fixed-input authentication;
- semantic-role resolution evidence;
- replacement authorization;
- platform preflight;
- production-parent custody;
- raw streams;
- locator adjudication;
- read-only replacement-subject validation;
- per-role opening/closing equality;
- final report.

The wrapper is not subject-content authority.

──────────────────────────────────────────────────────────────────────────────
8. SOURCE-FREEZE SEMANTIC ROLE RESOLUTION
────────────────────────────────────────────────

Before opening any guessed source-freeze path, retain:

contract/accepted-source-freeze-role-resolution-v1.json
analysis/accepted-source-freeze-role-crosswalk-v1.json

The authoritative input is the semantic role:

ACCEPTED_IMPLEMENTATION_SOURCE_FREEZE

Resolve it in this exact order:

1. accepted audit capsule current role/path registry;
2. accepted audit record:
   provenance/implementation-source-freeze.json;
3. accepted implementation-source registries;
4. current content authority role registry;
5. current content bundle index/member registry;
6. accepted implementation package role registry and terminal manifest when a
   current external package file is required.

The resolution must retain:

- semantic role;
- owning authority;
- accepted audit evidence path;
- accepted audit evidence identity;
- bound implementation-package role;
- current bundle/content role;
- exact member path;
- exact member size;
- exact member SHA-256;
- record schema;
- source identities bound by the freeze;
- external representation kind:
  - external_regular_file,
  - authenticated_bundle_member,
  - package_manifest_member;
- exact external relative path when governed;
- exact external absolute path only when uniquely derived from the accepted
  implementation root plus the authoritative relative path;
- uniqueness proof;
- current/nonhistorical posture;
- consumers;
- opening/closing comparison contract.

Forbidden resolution methods:

- hard-coded filename from this prompt;
- basename match;
- suffix match;
- prefix match;
- recency;
- first existing file;
- broad recursive scan;
- hash-only search;
- inode-only search;
- similarity score;
- fallback candidate list;
- silent differently named substitution.

If the accepted role registry directly supplies one exact current path, use it.

If it supplies identity and role but not a path, an exact identity join is
permitted only within the already authenticated, closed package manifest or
bundle member registry and only when exactly one current member matches the
full governed tuple.

Full tuple includes every available governed field:

- role;
- schema;
- size;
- SHA-256;
- mode;
- source-set identity;
- package identity.

Zero matches:

- return CONSTRUCTION_BLOCKED;
- authorization remains unconsumed.

More than one match:

- return CONSTRUCTION_BLOCKED;
- authorization remains unconsumed.

One exact match:

- freeze the result;
- do not substitute another representation later.

Do not require the obsolete guessed path:

opening/gen2-source-freeze-v1.json

unless the authoritative semantic resolution independently yields that exact
path.

──────────────────────────────────────────────────────────────────────────────
9. SOURCE-FREEZE RESOLUTION MATRIX
────────────────────────────────────────────────

Run at least 30 uniquely named cases.

Include:

- exact baseline role resolution;
- exact external-file representation;
- exact bundle-member representation;
- exact package-manifest-member representation;
- absent guessed legacy path but valid current role;
- zero current role rows;
- duplicate current role rows;
- one role with two paths;
- two roles with one path;
- stale historical freeze;
- failed-attempt freeze;
- wrong source set;
- wrong schema;
- wrong size;
- wrong SHA-256;
- wrong mode;
- current role absent but same basename exists;
- same hash under two roles;
- hash-only candidate;
- inode-only candidate;
- basename candidate;
- suffix candidate;
- first-existing candidate;
- recursive scan candidate;
- ambiguous identity join;
- exact unique identity join;
- external path outside accepted implementation root;
- bundle member missing;
- package-manifest row missing;
- opening/closing identity mismatch.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/accepted-source-freeze-role-resolution-matrix-v1.json

──────────────────────────────────────────────── LIMITED TO INDEPENDENCE
────────────────────────────────────────────────

10. INDEPENDENT SOURCE-FREEZE RESOLUTION VALIDATOR

Create a standard-library-only validator that imports neither:

- wrapper role resolver;
- matrix generator;
- expected-result map;
- content-role producer;
- identity-join helper.

It must independently:

1. authenticate accepted audit evidence;
2. parse the accepted source-freeze record;
3. parse implementation source registries;
4. parse content roles and bundle index;
5. parse accepted package role/manifest records;
6. reconstruct the semantic role resolution;
7. prove the selected member is current and unique;
8. reject the guessed absent path as an authority;
9. reject aliases and fallback;
10. validate the opening/closing comparison contract;
11. run independent negative cases;
12. require zero errors.

Retain:

validation/independent-source-freeze-role-validator-v1.json

No platform preflight or construction may begin until the resolution matrix and
independent validator pass.

──────────────────────────────────────────────── LIMITING FIXED INPUTS
────────────────────────────────────────────────

11. WRAPPER FIXED-ROLE REGISTRY AND EQUALITY

Retain:

contract/replacement-wrapper-fixed-role-registry-v2.json
contract/replacement-wrapper-closing-equality-v2.json

Fixed roles include:

- historical subject;
- historical sealed subject audit;
- accepted implementation audit root;
- accepted implementation wrapper root;
- content bundle;
- content authority;
- accepted implementation root;
- accepted successor root;
- normative contract root;
- current schema root;
- schema-reconciliation root;
- validation-specification root;
- accepted production source;
- accepted source-freeze semantic role;
- production registry;
- qualification registry;
- independent schema validator;
- exact construction contract.

For `accepted-source-freeze`, store:

- semantic role;
- representation kind;
- exact resolved path or bundle/member locator;
- exact identity;
- owning enclosing root or archive;
- opening comparison;
- closing comparison.

Per-role closing equality:

- one row per fixed role;
- role set closes exactly;
- no missing or extra row;
- every row independently passed.

For external files compare:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

For bundle members compare:

- enclosing bundle identity;
- member path;
- member size;
- member SHA-256;
- member metadata.

For roots compare:

- root identity;
- complete no-follow inventory;
- path set;
- bytes;
- governed metadata.

Do not include:

- failed final reconciliation;
- preceding failed wrappers;
- downstream not-reached confirmations;
- absent replacement outputs;
- cleanup counts.

Equal empty cleanup sets pass.

No Boolean/integer conflation.

──────────────────────────────────────────────── LIMITED TO WRAPPER SOURCE
────────────────────────────────────────────────

12. WRAPPER SELF-QUALIFICATION

Create a finite source-external wrapper.

It imports no implementation production or qualification module.

Compile under pinned Python with `-I -S -B`.

Run:

- AST;
- call graph;
- dataflow;
- process effects;
- filesystem effects;
- excluded-input access;
- semantic-role resolution ownership;
- equality-row ownership;
- terminal-order analysis.

Require:

- no hard-coded source-freeze filename;
- source-freeze opened only after semantic resolution;
- failed reconciliation never opened;
- previous wrappers nonauthoritative;
- exact fixed-role registry;
- one equality row per role;
- empty cleanup sets valid;
- authorization consumed only on process creation;
- success/failure closeout reachable;
- no network;
- no Git;
- no shell;
- no broad scan;
- no post-terminal operation.

Retain:

validation/wrapper-static-qualification-v2.json

────────────────────────────────────────────────

13. WRAPPER INTEGRATION MATRIX

Run at least 45 uniquely named cases covering:

- exact full baseline;
- semantic source-freeze resolution;
- guessed path absent but role resolves;
- unique bundle-member source freeze;
- ambiguous source freeze;
- stale source freeze;
- failed-attempt source freeze;
- all prior equality cases;
- fixed input drift;
- empty cleanup;
- prelaunch failure;
- post-creation authorization consumption;
- terminal ordering.

Require zero false outcomes, mismatches, skips, or exceptions.

Retain:

validation/wrapper-integration-matrix-v2.json

Run an independently authored wrapper validator.

Require zero errors.

Freeze wrapper source afterward.

──────────────────────────────────────────────── LIMITING AUTHORIZATION
────────────────────────────────────────────────

14. REPLACEMENT CONSTRUCTION AUTHORIZATION

Retain:

opening/replacement-subject-construction-authorization-v3.json

Required facts:

- forward treatment:
  terminal-stop-and-reconstruct;
- historical subject blocked/noncurrent;
- historical audit sealed;
- failed reconciliation excluded;
- previous replacement attempts created no production process;
- all previous replacement authorizations unconsumed;
- accepted implementation audit:
  GEN2_IMPLEMENTATION_PACKAGE_ACCEPT;
- accepted production source authenticated;
- accepted source-freeze semantic role authenticated;
- construction contract authenticated;
- replacement authorization:
  true;
- count:
  1;
- consumed:
  false before process creation;
- fresh root required:
  true;
- historical adoption:
  forbidden;
- same-root retry:
  forbidden;
- replacement parent:
  forbidden;
- administrative continuation:
  forbidden;
- independent subject audit:
  not included;
- authority promotion:
  false;
- product/runtime/target/A6 authority:
  false.

Authorization is consumed only when process creation succeeds.

──────────────────────────────────────────────── LIMITING ACCEPTED PARENT
────────────────────────────────────────────────

15. ACCEPTED PRODUCTION INPUTS

Resolve and authenticate:

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

CONTRACT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

SCHEMA_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

VALIDATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

PRODUCTION_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/production/reconstruct_parent.py

Expected production-source identity:

- device:
  16777234
- inode:
  180888833
- mode:
  0600
- size:
  65305
- SHA-256:
  8edb8790e140560de891830919571e616852df8b7878d9d4e403fb0dde70bc6e

PRODUCTION_REGISTRY:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-production-source-registry-final-v1.json

QUALIFICATION_REGISTRY:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-qualification-source-registry-final-v1.json

INDEPENDENT_SCHEMA_VALIDATOR:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/qualification/validate_schema_family.py

CONSTRUCTION_CONTRACT:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n/contract/package-construction-parent-v1.json

Expected contract identity:

- device:
  16777234
- inode:
  180472112
- mode:
  0600
- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19

The accepted source-freeze role is supplied exclusively by Section 8.

Do not separately require a guessed source-freeze path.

──────────────────────────────────────────────── LIMITING CUSTODY
────────────────────────────────────────────────

16. PLATFORM-CAPTURE PREFLIGHT

After all gates pass, run one harmless synchronous capture preflight using:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

Submitted cwd:

the implementation root.

Submitted environment exactly:

PYTHONDONTWRITEBYTECODE=1

stdin:
DEVNULL

shell/TTY/detachment:
false.

Retain complete platform custody.

If preflight fails:

- do not launch construction;
- authorization remains unconsumed;
- compute wrapper closing equality;
- return provenance mismatch;
- do not retry.

──────────────────────────────────────────────── LIMITING ONE EXECUTION
────────────────────────────────────────────────

17. EXACT PRODUCTION-PARENT INVOCATION

Require exactly:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/production/reconstruct_parent.py
--mode
reconstruct-subject
--implementation-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634
--successor-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve
--contract-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n
--schema-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf
--reconciliation-root
/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t
--validation-root
/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs
--production-registry
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-production-source-registry-final-v1.json
--qualification-registry
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/contract/gen2-qualification-source-registry-final-v1.json
--independent-schema-validator
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634/source/qualification/validate_schema_family.py
--cwd
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Submitted cwd:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Submitted environment exactly:

PYTHONDONTWRITEBYTECODE=1

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Root allocation:

parent-owned.

Locator grammar:

SUBJECT_ROOT=<absolute-path>\n

Immediately before process creation:

- reauthenticate every fixed role;
- reauthenticate production source;
- reauthenticate the semantically resolved source-freeze role;
- require no cache or bytecode effect.

Launch exactly once, synchronously.

Authorization is consumed on successful process creation.

Do not launch qualification, self-test, recovery, continuation, helper, or a
second construction.

──────────────────────────────────────────────── LIMITED TO PLATFORM
────────────────────────────────────────────────

18. TOP-LEVEL PROCESS CUSTODY

Retain before parsing:

- custody ID;
- creation result;
- PID;
- start/completion;
- duration;
- argv;
- cwd;
- environment;
- stdin/shell/TTY/detachment;
- raw stdout/stderr;
- stream sizes/hashes;
- exit/signal;
- process error;
- reaping;
- descriptor closure;
- fixed-input identities at launch.

If custody is lost after process creation:

- authorization remains consumed;
- do not scan;
- do not retry;
- return provenance mismatch.

──────────────────────────────────────────────── LIMITED TO LOCATOR
────────────────────────────────────────────────

19. LOCATOR AND REPLACEMENT ROOT

Require stdout exactly:

SUBJECT_ROOT=<absolute-path>\n

Require:

- one line;
- exact prefix;
- absolute path;
- no chatter;
- no duplicate;
- no trailing bytes.

Use only that path.

Do not scan.

Authenticate:

- fresh allocation;
- path and identity distinct from historical subject;
- directory;
- no symlink;
- mode 0700;
- governed parent/prefix;
- allocation evidence;
- no preexisting adoption;
- no historical-root mutation.

After process creation, preserve the root unchanged.

──────────────────────────────────────────────── LIMITING PRODUCER RESULT
────────────────────────────────────────────────

20. READ-ONLY REPLACEMENT-SUBJECT VALIDATION

Inspect only the authenticated new root.

Do not mutate, clean, resume, execute source, run an independent audit, or
regenerate evidence.

Authenticate:

- normative contract preservation;
- 15 current schema roles;
- 14 generated families;
- intentional normative-parent nonmapping;
- role/family mapping;
- 15/15 Draft 2020-12 result;
- 14 contract witnesses;
- 14 schema witnesses;
- zero joint unsatisfiability;
- zero baseline under-enforcement;
- 946-case matrix;
- 137-case regression;
- 766/333 field map;
- documentary-validator roles/results;
- confirmation evidence;
- explicit confirmations;
- role occupancy;
- status and lineage;
- no historical closure output current;
- no failed artifact current;
- implementation-present false;
- implementation-authority false;
- pending-independent-audit posture.

Do not adjudicate historical A06/A07/A08/A11 findings.

──────────────────────────────────────────────── LIMITING TERMINAL CLOSURE
────────────────────────────────────────────────

21. INTERNAL CUSTODY, CLEANUP, EQUALITY, AND SEAL

Authenticate:

- child ledger;
- ordinals;
- child streams/outcomes;
- reaping and descriptor closure;
- effect attribution;
- cleanup rows and set equality;
- supplied-input closing equality;
- temporal inventory;
- manifest A/B;
- A/B equality;
- independent final reprojection;
- root row once;
- topology/modes;
- one seal transition;
- terminal marker;
- no parent postseal operation.

Require no process, descriptor, cache, or bytecode survivor.

A success disposition without terminal closure is nonauthoritative.

──────────────────────────────────────────────── LIMITING SEPARATION
────────────────────────────────────────────────

22. HISTORICAL/REPLACEMENT SEPARATION

Require:

- historical subject unchanged;
- historical audit unchanged;
- accepted implementation roots unchanged;
- new path and identity distinct;
- no historical subject reuse;
- no historical closure output current;
- no historical audit promoted;
- fresh subject pending independent audit.

Retain:

analysis/historical-and-replacement-subject-separation-v2.json

────────────────────────────────────────────────

23. WRAPPER CLOSING EQUALITY

Before terminal wrapper output, produce one explicit opening/closing row for
every fixed role from Section 11.

The source-freeze row uses the representation kind and comparison contract
frozen in Section 8.

Do not include excluded historical roots or downstream confirmations.

Require exact role-set closure and every row pass true.

Retain:

closing/wrapper-supplied-input-closing-equality-v2.json

On failure, compute this record before the terminal frame.

No post-frame read or write.

────────────────────────────────────────────────

24. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTED_AND_TERMINALLY_CLOSED_PENDING_FRESH_INDEPENDENT_AUDIT

only when:

- forward authority closes;
- historical roots authenticate;
- accepted implementation authority closes;
- source-freeze role resolves uniquely;
- wrapper qualification passes;
- replacement authorization closes;
- fixed inputs authenticate;
- preflight passes;
- parent launches once;
- custody completes;
- locator/root authentication passes;
- producer qualification passes;
- internal custody/cleanup pass;
- parent equality passes;
- temporal/manifests/reprojection pass;
- topology/modes pass;
- seal/no-postseal pass;
- wrapper equality passes.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_BLOCKED

when:

- the source-freeze semantic role cannot be uniquely resolved;
- an accepted current fixed role remains ambiguous;
- the production parent reports a substantive construction blocker;
- provenance otherwise remains valid.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_CONSTRUCTION_PROVENANCE_MISMATCH

for:

- historical-input mismatch;
- accepted-authority mismatch;
- role identity mismatch after unique resolution;
- wrapper qualification failure;
- source/freeze drift;
- custody loss;
- malformed locator;
- historical-root reuse;
- supplied-input mutation;
- evidence loss;
- cleanup inequality;
- terminal-closure failure;
- postseal parent activity;
- wrapper equality failure.

Do not retry in this task.

────────────────────────────────────────────────

25. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve historical roots;
- preserve accepted implementation roots;
- preserve the new constructed or failed subject root;
- preserve wrapper evidence;
- do not independently audit the new subject;
- do not construct another subject;
- do not promote or rebind authority;
- do not execute product modes;
- do not run target audit or runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

26. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh wrapper-root identity
3. Forward-treatment directive
4. Historical subject authentication
5. Historical audit authentication
6. Excluded-history posture
7. Previous failed-wrapper disposition
8. Accepted implementation authority
9. Current content identities
10. Source-freeze semantic role
11. Accepted audit source-freeze evidence
12. Implementation/content role crosswalk
13. Exact resolved source-freeze representation
14. Source-freeze uniqueness proof
15. Source-freeze resolution matrix
16. Independent source-freeze validator
17. Wrapper fixed-role registry
18. Wrapper equality contract
19. Wrapper static qualification
20. Wrapper integration matrix
21. Independent wrapper validation
22. Replacement authorization
23. Authorization consumption
24. Production-source identity
25. Construction-contract identity
26. Exact fixed construction inputs
27. Platform preflight
28. Exact production-parent argv
29. Cwd/environment
30. Top-level custody
31. Raw streams
32. Exit/signal
33. Locator parsing
34. Replacement root identity
35. Fresh allocation/nonadoption
36. Historical/replacement separation
37. Normative-contract preservation
38. Fifteen schema roles
39. Fourteen generated families
40. Role/family mapping
41. Draft 2020-12 result
42. Witness results
43. 946 result
44. 137 result
45. 766/333 result
46. Documentary-validator closure
47. Confirmation-evidence closure
48. Explicit confirmations
49. Role occupancy
50. Status and lineage
51. Child custody
52. Effect attribution
53. Cleanup
54. Parent equality
55. Wrapper equality
56. Temporal identity
57. Manifest identities
58. A/B equality
59. Reprojection
60. Topology/modes
61. Seal/marker
62. No-postseal result
63. Confirmation no retry/continuation
64. Confirmation fresh independent audit not executed
65. Confirmation no product/runtime/target/A6 activity
66. Remaining uncertainty/nonclaims
67. Explicit wrapper confirmations

Required confirmations:

FORWARD_TREATMENT_DIRECTIVE_RETAINED
HISTORICAL_SUBJECT_ROOT_AUTHENTICATED
HISTORICAL_SUBJECT_MUTATION_NOT_PERFORMED
HISTORICAL_SUBJECT_AUDIT_AUTHENTICATED
HISTORICAL_BLOCK_PRESERVED
FAILED_FINAL_RECONCILIATION_NOT_OPENED
FURTHER_FINDINGS_RECONCILIATION_NOT_USED
PREVIOUS_FAILED_REPLACEMENT_WRAPPER_NONCURRENT
ALL_PREVIOUS_REPLACEMENT_AUTHORIZATIONS_UNCONSUMED
PRIOR_ORIGINAL_CONSTRUCTION_AUTHORIZATION_CONSUMED
PRIOR_SUBJECT_NOT_REUSED_AS_CURRENT
ACCEPTED_IMPLEMENTATION_AUDIT_AUTHENTICATED
GEN2_IMPLEMENTATION_PACKAGE_ACCEPT_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
ACCEPTED_SOURCE_FREEZE_SEMANTIC_ROLE_RESOLVED
ACCEPTED_SOURCE_FREEZE_CURRENT_MEMBER_IDENTIFIED
ACCEPTED_SOURCE_FREEZE_UNIQUELY_RESOLVED
GUESSED_LEGACY_SOURCE_FREEZE_PATH_NOT_USED_AS_AUTHORITY
NO_BASENAME_SUFFIX_PREFIX_RECENCY_OR_SCORE_SELECTION
NO_HASH_ONLY_OR_INODE_ONLY_SELECTION
SOURCE_FREEZE_RESOLUTION_MATRIX_PASSED
INDEPENDENT_SOURCE_FREEZE_VALIDATOR_PASSED
WRAPPER_FIXED_ROLE_REGISTRY_COMPLETE
WRAPPER_CLOSING_EQUALITY_CONTRACT_COMPLETE
WRAPPER_STATIC_QUALIFICATION_PASSED
WRAPPER_INTEGRATION_MATRIX_PASSED
INDEPENDENT_WRAPPER_VALIDATOR_PASSED
REPLACEMENT_ONE_SHOT_AUTHORIZATION_ESTABLISHED
ACCEPTED_PRODUCTION_SOURCE_IDENTITY_MATCHED
ACCEPTED_SOURCE_FREEZE_IDENTITY_MATCHED
ACCEPTED_CONSTRUCTION_CONTRACT_AUTHENTICATED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
PRODUCTION_PARENT_EXECUTED_EXACTLY_ONCE
REPLACEMENT_CONSTRUCTION_AUTHORIZATION_CONSUMED
QUALIFICATION_MODE_NOT_EXECUTED
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_HELPER_EXECUTED_OUTSIDE_PARENT
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
REPLACEMENT_SUBJECT_ROOT_FROM_EXACT_GOVERNED_LOCATOR
SUBJECT_ROOT_SCAN_NOT_PERFORMED
REPLACEMENT_SUBJECT_ROOT_FRESHLY_ALLOCATED
REPLACEMENT_SUBJECT_ROOT_DISTINCT_FROM_HISTORICAL
PREEXISTING_SUBJECT_ROOT_NOT_ADOPTED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
ZERO_JOINTLY_UNSATISFIABLE_RECORD_FAMILY
ZERO_UNDER_ENFORCED_BASELINE_RECORD_FAMILY
GENERATED_RECORD_NEGATIVE_MATRIX_946_PASSED
CONTRADICTION_REGRESSION_137_PASSED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_PASSED
EXPLICIT_CONFIRMATIONS_EVIDENCE_DERIVED
CURRENT_ROLE_OCCUPANCY_COMPLETE
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_SET_EQUALITY_PASSED
PARENT_SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
WRAPPER_SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
REPLACEMENT_SUBJECT_TEMPORAL_INVENTORY_CREATED
REPLACEMENT_SUBJECT_TEMPORAL_INVENTORY_VERIFIED
REPLACEMENT_SUBJECT_MANIFEST_A_CREATED
REPLACEMENT_SUBJECT_MANIFEST_B_CREATED
REPLACEMENT_SUBJECT_MANIFESTS_BYTE_IDENTICAL
REPLACEMENT_SUBJECT_TERMINAL_REPROJECTION_PASSED
REPLACEMENT_SUBJECT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_CLOSURE_BY_PARENT
SECOND_REPLACEMENT_CONSTRUCTION_NOT_ATTEMPTED
REPLACEMENT_SUBJECT_INDEPENDENT_AUDIT_NOT_EXECUTED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Sources and confidence

The attached report establishes that the wrapper corrections, forward authority,
historical exclusions, accepted implementation authority, role registry,
equality contract, static qualification, matrix, and independent validation all
passed. :chatgpt-content-reference{index="7"}

It identifies the exact sole blocker as the absent hard-coded source-freeze
path, with seventeen of eighteen roles otherwise authenticated and no process
launch or replacement root. :chatgpt-content-reference{index="8"}

The wrapper’s equality failure was the same exact `accepted-source-freeze` row,
not unexplained drift elsewhere. :chatgpt-content-reference{index="9"}

**Provenance confidence:** 0.995  
**Authorization-unconsumed confidence:** 0.999  
**Wrapper-defect classification confidence:** 0.995  
**Next-step confidence:** 0.98

The latest attachment was fully readable. Some earlier uploads have expired. Re-upload an older artifact only if a later review needs its original bytes rather than the retained identities and reports.
