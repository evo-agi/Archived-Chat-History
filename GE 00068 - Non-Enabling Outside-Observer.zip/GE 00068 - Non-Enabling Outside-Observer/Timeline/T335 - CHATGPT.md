## Assessment

This is the first decisive audit of the repaired bootstrap package. **`BLOCK` is correct**, and another reconciliation tranche is unnecessary.

The report’s use of “remains unresolved” for A, C, and I understates its own evidence:

- **A is a confirmed implementation/evidence defect.** Invocations missing `-I`, `-S`, `-B`, or all three exited successfully and emitted records claiming that the required flags were established.
- **C is a confirmed implementation defect.** The post-copy “reverification” reused a cached identity; a same-size in-place mutation passed while a fresh read found changed bytes.
- **H is a confirmed implementation and qualification defect.** Four required commit boundaries falsely accepted incomplete publication, and the current commit point and postcommit disposition are ambiguous.
- **I is a confirmed validation-lineage defect.** Producer case 28 claims wrapper execution but performs only local dictionary comparison. The wrapper itself behaves correctly when genuinely exercised.
- **J passed the fresh 928-case matrix.** Preserve the J closure; do not redesign it.

The critical repair is H. The final success record must not be visible at its authoritative path until all acceptance-bearing preparation is complete. The clean design is:

1. Construct and fully verify a **nonauthoritative staged commit file**.
2. Complete its write, fsync, close, directory synchronization, and descriptor-based reopening before publication.
3. Publish it to the absent authoritative path with a **single exclusive atomic no-replace operation**.
4. Treat that publication as the one linearization point.
5. Treat later directory-sync, observation, or cleanup failures as explicitly **postcommit and non-downgrading**; do not attempt to write a contradictory authoritative failure outcome.
6. Never adopt or attribute a preexisting final commit to the current invocation.

Proceed directly to one bounded A/C/H/I successor implementation, followed by a fresh parent-owned audit.

```text
IMPLEMENT THE BOUNDED A/C/H/I REPAIR —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP PACKAGE

This is a source-external bounded package repair.

Do not modify the current package.
Do not modify the independent-audit capsule.
Do not modify the predecessor package or any other supplied evidence root.
Do not inspect the candidate repository, Strategic B, blocked V1,
Validation-Custody V2, the V2 audit, V3 targets, product source, or unrelated
evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke a product or live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create subagents.

Return exactly one primary implementation verdict:

VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_A_C_H_I_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_A_C_H_I_REPAIR_IMPLEMENTATION_BLOCKED

IMPLEMENTATION_PROVENANCE_MISMATCH

OBJECTIVE

Create one fresh immutable successor package that repairs exactly the four
defects confirmed by the fresh independent audit:

A. Interpreter isolation was claimed but not actually verified.

C. Post-copy reverification reused cached identity rather than reopening the
   copied destination.

H. Success-commit publication and qualification were unsound at required
   publication boundaries.

I. Producer case 28 claimed wrapper-boundary execution without executing the
   wrapper.

Preserve the already accepted Finding J schema closure.

Do not redesign unrelated bootstrap semantics.
Do not add product, repository, runtime, deployment, publication, external
commit, readiness, V3-target, V3-verdict, source, or A6 authority.

──────────────────────────────────────────────────────────────────────────────
1. EXACT CURRENT PACKAGE
──────────────────────────────────────────────────────────────────────────────

CURRENT_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-audit-repair-uht2nbgf

Expected root identity:

- device/inode:
  16777234 / 179272855
- mode:
  0700
- producer verdict:
  VALIDATION_CUSTODY_V3_FULL_AUDIT_BOOTSTRAP_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected temporal final inventory:

- size:
  237721
- SHA-256:
  1284fb7ed2bc19fe67b017404dfa4f749cf228dda4d010d1ed2a690ea0f766e9

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  237800 each
- SHA-256:
  adf2a6f8314327b07883153f95eae567ecd802413d2b0acdeebfc2bf56d47f8e
- byte-identical:
  required

Expected closure:

- 1140 represented entries;
- 333 directories including root;
- 807 represented nonmanifest files;
- 809 physical files including both manifests;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- regular files mode 0600 and link count 1.

Current semantic identities:

source/full_audit_bootstrap_v1.py

- size:
  92561
- SHA-256:
  2764bc8b7972c199df4bfc80f04ede124931247f74e52325e47dd74071228f79

contract/full-audit-bootstrap-contract-v1.json

- size:
  14481
- SHA-256:
  9fc27aa61dcff5e19a57936c1002de97d567e62d873cb787c562477002b7a652

contract/qualification-result-contract-v1.json

- size:
  2275
- SHA-256:
  d3b0cba5926a86a1a40db9034034120b7f9f2f691af4a11dbc37a6b275041dda

schemas/full-audit-bootstrap-contract-v1.schema.json

- size:
  9785
- SHA-256:
  08714f519f88bdc636c11c353b2eeadc32c5951689799629834637934c0a599e

schemas/process-self-check-result-v1.schema.json

- size:
  6554
- SHA-256:
  8a73bd13ee61b1a31d072d2a93c4e635cae14f0ad9f399dbef63954bd053abbf

schemas/root-rebinding-proof-v1.schema.json

- size:
  4662
- SHA-256:
  010a2d604980a914f8460b615dbfa62f125cb8f8d3a9584caf22499b9a7964cd

tests/failure_injection_driver_v1.py

- size:
  10506
- SHA-256:
  393f6b927bd245a1dd8901fa08f06fe5ca4a68d8d1389f4a5a8d25bec3f1c527

tests/test_full_audit_bootstrap_v1.py

- size:
  40478
- SHA-256:
  72845b61360f5390b9f8890589e8d36fef565bb75a4537161923b3b40e8eb7aa

Independently reproduce the current package closure before creating the
successor.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING INDEPENDENT AUDIT
──────────────────────────────────────────────────────────────────────────────

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-audit-repair-independent-audit-g4trkw97

Expected primary verdict:

BLOCK

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  243162 each
- SHA-256:
  8438d5d1571e8cfa462f53a6df0744749aab281fb9181e602bd02f82f9dc0063
- byte-identical:
  required

Authenticate through those manifests and inspect completely:

closeout/primary-verdict.json
closeout/final-audit-report.md
analysis/severity-ranked-residual-findings.json
causals/finding-a-interpreter-flags.json
causals/finding-c-post-copy.json
causals/predecessor-h-causal.json
validation/fresh-publication-boundary-matrix.json
analysis/commit-point-semantics.json
analysis/producer-case-level-adjudication.json
causals/finding-i-wrong-payload-mutation.json
validation/fresh-predecessor-j-reproduction-v2.json
validation/fresh-independent-j-matrix-v3.json
analysis/qualification-result-closure.json
analysis/replay-evidence-closure.json
analysis/failure-hook-reachability.json
closeout/explicit-confirmations.json
closeout/supplied-root-closing-equality.json

Derive and report exact sizes, SHA-256 identities, schemas, and authority roles
from the authenticated capsule.

The audit report and these records govern this repair.

──────────────────────────────────────────────────────────────────────────────
3. FRESH SUCCESSOR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh package root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-

Copy the complete current package into the new root with exact path
preservation.

Do not use:

- symlinks;
- hardlinks;
- clonefile/reflink aliasing;
- existing-root adoption;
- rename of the current package;
- in-place mutation.

Require every copied regular file to be physically distinct, single-link, mode
0600, and initially byte-identical.

Retain a complete current-to-successor opening comparison before editing.

──────────────────────────────────────────────────────────────────────────────
4. SEMANTIC TOUCHED-PATH FREEZE
──────────────────────────────────────────────────────────────────────────────

Before editing, reconstruct the complete owner map for A, C, H, and I.

The expected maximum semantic scope is:

source/full_audit_bootstrap_v1.py
contract/full-audit-bootstrap-contract-v1.json
contract/qualification-result-contract-v1.json
schemas/full-audit-bootstrap-contract-v1.schema.json
schemas/process-self-check-result-v1.schema.json
schemas/root-rebinding-proof-v1.schema.json
tests/failure_injection_driver_v1.py
tests/test_full_audit_bootstrap_v1.py

Only this set may change semantically unless an existing contract/schema
directly governing one of the four confirmed defects lies outside it.

If another semantic path is indispensable:

- do not edit it;
- stop;
- return the implementation-blocked verdict;
- report the exact path, owning contract, required change, and why the eight
  expected paths are insufficient.

New evidence, fixture, validation, provenance, lineage, and closeout files are
permitted under nonsemantic namespaces.

For every semantic hunk retain:

- path;
- old/new line ranges;
- finding owner:
  A, C, H, or I;
- exact audit evidence;
- behavior change;
- contract change;
- authority effect;
- validation-only status.

Any unrelated semantic change is a stop condition.

──────────────────────────────────────────────────────────────────────────────
5. PRESERVED SEMANTICS
──────────────────────────────────────────────────────────────────────────────

Preserve unless this prompt explicitly changes them:

- four-option bootstrap CLI;
- no target-root option;
- pinned Python path and binary identity;
- literal qualified-launcher and reconciliation paths;
- qualified-package manifest grammar;
- exact reconciliation-verdict lookup;
- five-artifact copy boundary;
- copied wrapper and launcher bytes;
- exact three-field fixed-environment record;
- fixed six-key environment;
- exact twelve-pointer root rebinding;
- target-inspection polarity;
- wrapper-authoritative payload verification;
- same-PID launcher/payload behavior;
- environment additional-key-name diagnostics;
- CLI and wrapper-SHA semantics;
- no child process;
- no target inspection;
- Carrier 0002 request semantics;
- fresh-root-only operation;
- no retry in a failed root;
- process-only authority;
- Finding J closure, except where record additions for A/C/H/I require
  consistent extensions.

Do not change schema or contract IDs unless the current IDs cannot truthfully
represent the repair. If a version transition is necessary, stop rather than
silently redefining V1.

──────────────────────────────────────────────────────────────────────────────
6. FINDING A REPAIR — VERIFY ACTUAL INTERPRETER INVOCATION
──────────────────────────────────────────────────────────────────────────────

The independent audit established:

- the contract requires `-I -S -B`;
- the source verifies interpreter path, version, and bytes;
- invocations missing `-I`, `-S`, `-B`, or all three still exited zero and
  emitted records claiming that all flags were established.

Repair this before any acceptance-bearing success record is written.

Require both:

A. Effective interpreter state

- `sys.flags.isolated == 1`
- `sys.flags.no_site == 1`
- `sys.flags.dont_write_bytecode == 1`

B. Actual submitted interpreter-option evidence

Use `sys.orig_argv` or an equivalently direct interpreter-owned observation.

Require the interpreter-option segment before the script operand to contain:

- literal `-I`;
- literal `-S`;
- literal `-B`;

under the exact CLI grammar selected by the contract.

Do not allow environment variables alone to satisfy a missing literal flag.

In particular, an invocation lacking `-B` must fail even if
`PYTHONDONTWRITEBYTECODE=1` makes `sys.flags.dont_write_bytecode` true.

Retain an interpreter-invocation observation containing:

- pinned interpreter identity;
- effective flag values;
- sanitized option tokens or their exact closed representation;
- `sys.orig_argv` binding or digest;
- owning contract identity;
- pass/fail;
- first blocker;
- authority and nonauthority.

Missing or contradictory flags must:

- fail before authoritative success;
- produce a canonical failure;
- leave no success commit;
- inspect no target;
- create no child process.

Required fresh causals:

1. exact `-I -S -B` passes;
2. missing `-I` rejects;
3. missing `-S` rejects;
4. missing `-B` rejects;
5. missing all three rejects;
6. missing `-B` plus `PYTHONDONTWRITEBYTECODE=1` rejects;
7. effective flag false despite token presence rejects, when safely
   constructible;
8. stale or forged flag record rejects;
9. absent invocation observation rejects;
10. contradictory observation rejects.

Update contracts, schemas, producers, qualification evidence, and field maps
consistently.

Do not merely narrow the wording of an existing false success record.

──────────────────────────────────────────────────────────────────────────────
7. FINDING C REPAIR — TRUE POST-COPY REVERIFICATION
──────────────────────────────────────────────────────────────────────────────

The independent audit established that the current post-copy reverification
reuses cached identity and accepts a same-size in-place mutation.

Implement one fresh no-follow destination observation after copy completion.

For every copied process artifact:

1. Initial copy must complete.
2. Destination file must be fsynced and closed.
3. Reopen the exact destination through a no-follow descriptor.
4. Require:
   - regular file;
   - mode 0600;
   - link count 1;
   - expected size;
   - expected SHA-256;
   - exact expected bytes;
   - expected path;
   - stable device/inode identity when the contract binds it.
5. Perform `fstat` before and after reading.
6. Reject held-file mutation, replacement, disappearance, type change, mode
   change, link-count change, size change, and content change.
7. Close the descriptor.
8. Retain a fresh post-copy observation distinct from the initial copy
   observation.

The reverification implementation must not accept:

- cached initial identity;
- cached source identity as destination truth;
- stale dictionary equality;
- pathname-only existence;
- lstat without reading destination bytes.

Bind the fresh observation into the root-bound launch contract or bootstrap
result wherever current semantics claim reverified copied artifacts.

Required audit-owned causals:

1. unchanged copy passes;
2. same-size in-place byte mutation rejects;
3. replacement with same-size different inode rejects;
4. symlink replacement rejects;
5. mode change rejects;
6. hardlink/link-count change rejects;
7. truncate rejects;
8. append rejects;
9. disappearance rejects;
10. mutation during held read rejects;
11. cached observation substituted for fresh observation rejects.

Do not modify supplied roots while running these causals.

──────────────────────────────────────────────────────────────────────────────
8. FINDING H REPAIR — FREEZE THE SUCCESS PUBLICATION MODEL
──────────────────────────────────────────────────────────────────────────────

The independent audit established:

- the predecessor defect was genuine;
- the current repair falsely accepts failures at:
  - final commit fsync;
  - final commit close;
  - final commit directory synchronization;
  - final commit identity reopening;
- a byte-valid final commit left by those failures is adopted as
  `valid_success_commit`;
- postcommit disposition is not closed.

Replace the current success-publication model with this closed protocol.

A. Nonauthoritative stage

Construct the complete success-commit bytes at an invocation-private stage path
that is never the authoritative final path.

The stage must bind:

- owning contract identity;
- invocation/fresh-root identity;
- result identity;
- outcome identity;
- completed step;
- success status;
- authority classification;
- nonauthority;
- publication protocol;
- source identity.

The stage file is nonauthoritative.

B. Complete prepublication qualification

Before final publication:

1. create stage exclusively;
2. write complete bytes;
3. fsync stage file;
4. close;
5. synchronize the stage-containing directory as required by the supported
   local contract;
6. reopen stage no-follow;
7. verify:
   - type;
   - mode;
   - link count;
   - size;
   - SHA-256;
   - bytes;
   - stable identity;
   - result/outcome references;
   - invocation binding;
8. close the reverified stage descriptor.

Any failure here is precommit.

The authoritative final path must remain absent.

C. One exclusive atomic publication

Publish the qualified stage to:

`opening/bootstrap-success-commit.json`

using one capability-gated, atomic, no-replace operation.

On the supported macOS host, the expected mechanism is an exact
`renameatx_np(..., RENAME_EXCL)`-class primitive or an equivalently strong
operation.

Requirements:

- destination must be absent;
- no overwrite;
- no copy/delete fallback;
- no ordinary replace-capable rename fallback;
- no adoption of an existing final file;
- no path scan or latest selection;
- stage and destination on the required same filesystem;
- capability failure is terminal.

The successful exclusive publication is the single authoritative commit point.

D. Postcommit semantics

After successful exclusive publication:

- success is authoritative;
- later failures must not downgrade it;
- do not attempt to write a contradictory authoritative failure outcome;
- retain any later error only as a postcommit observation/evidence record;
- explicitly classify:
  - containing-directory synchronization;
  - final-path observation;
  - cleanup;
  - stdout/reporting;
  - descriptor close;
  as acceptance-bearing precommit work or non-downgrading postcommit work.

Move all acceptance-bearing fsync, close, directory-sync, and identity
verification possible to the stage before publication.

If final-parent synchronization after publication is retained, classify it
explicitly as non-downgrading and make no crash/power-loss durability claim.

E. Existing final commit

A preexisting final commit, even byte-valid, must never be attributed to the
current invocation.

It must cause a collision/foreign-existing-final classification.

Do not report success through adoption.

F. Failure cleanup

For every precommit failure:

- final commit absent;
- stage removed when safely owned;
- result/outcome fragments explicitly nonauthoritative;
- failure record canonical;
- no same-root retry;
- no contradictory success/failure authority.

G. Retry posture

- A new fresh-root invocation after a precommit failure may proceed.
- The failed root remains failed and nonresumable.
- A second invocation against a committed root must not republish, overwrite,
  or adopt.
- A committed invocation remains committed despite explicitly
  non-downgrading postcommit cleanup/observation faults.

──────────────────────────────────────────────────────────────────────────────
9. FINDING H — REQUIRED FRESH PUBLICATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Replace the stale ten-case qualification matrix with a closed matrix derived
from the repaired source.

At minimum cover:

1. before result creation;
2. result write;
3. result fsync;
4. result close;
5. before outcome creation;
6. outcome write;
7. outcome fsync;
8. outcome close;
9. stage-commit creation;
10. stage-commit write;
11. stage-commit fsync;
12. stage-commit close;
13. stage-directory synchronization;
14. stage no-follow reopen;
15. stage identity/byte verification;
16. before atomic publication;
17. atomic publication failure;
18. successful atomic publication;
19. existing-final collision;
20. foreign byte-valid final collision;
21. postpublication directory-sync fault;
22. postpublication final-observation fault;
23. postpublication cleanup fault;
24. postpublication stdout/report fault, if applicable;
25. precommit fragment cleanup fault;
26. retry in fresh root after precommit failure;
27. same-root retry after precommit failure rejects;
28. second invocation after committed success rejects adoption;
29. stage/destination cross-filesystem or capability failure;
30. unsupported exclusive-publication capability.

For each retain complete replay evidence:

- stable case ID;
- exact source and driver identity;
- exact hook;
- reachability;
- argv;
- cwd;
- explicit environment;
- streams;
- exit/signal;
- result/outcome/stage/final-commit posture;
- partial inventory;
- expected and actual classification;
- retry posture;
- cleanup;
- replay recipe;
- fixture identity.

Require:

- exact closed name set;
- exact count;
- zero false acceptance;
- zero false rejection;
- zero skipped case;
- every dynamic case independently replayable from retained package bytes.

Do not count an unsupported boundary as a dynamic pass.

──────────────────────────────────────────────────────────────────────────────
10. FINDING H — COMMIT-POINT CONTRACT
──────────────────────────────────────────────────────────────────────────────

Update the owning contract and qualification result so the following is
literal:

- stage commit:
  nonauthoritative;
- final absent destination:
  required;
- successful exclusive atomic publication:
  authoritative commit point;
- all prior failures:
  precommit and nonauthoritative;
- all explicitly enumerated later failures:
  postcommit and non-downgrading;
- no crash/power-loss durability claim;
- no hostile/shared-host claim;
- no Git commit authority;
- no publication authority outside the evidence instance;
- no existing-final adoption;
- no overwrite;
- no fallback.

The final commit record must be independently consumable by reopening and
validating:

- exact schema;
- owning contract identity;
- invocation/root identity;
- result and outcome identities;
- source identity;
- authority/non-authority fields;
- success status;
- publication protocol and commit-point classification.

Update schema and validators consistently while preserving the accepted
Finding J closure.

──────────────────────────────────────────────────────────────────────────────
11. FINDING I REPAIR — REAL WRAPPER-BOUNDARY CASE
──────────────────────────────────────────────────────────────────────────────

The independent audit established:

- producer case 28 is named:
  `wrong_payload_identity_fails_through_wrapper`;
- its implementation only compares local dictionaries;
- a separate real wrapper invocation correctly rejects a mutated payload at
  `payload_identity:sha256`.

Repair the producer evidence.

Preferred repair:

- keep the existing case name only if the case now truly invokes the copied
  wrapper through the pinned interpreter and exact wrapper CLI;
- mutate the payload after the request binds its expected size/hash;
- invoke the wrapper;
- require rejection at `payload_identity:sha256`;
- require payload compilation did not begin;
- require payload execution did not begin;
- require expected payload outputs absent;
- require phase outcome complete;
- require process exit and streams retained;
- require no target inspection;
- require no child process.

If preserving the 50-case registry is impossible without misleading semantics:

- split the old static/local check under an accurately named static case;
- add the real integration causal under the wrapper-boundary name;
- update the closed case registry, count, digest, contract, schemas, producer
  result, qualification result, and independent validator consistently.

Do not silently keep a hard-coded or local-only case described as wrapper
execution.

Independently classify every producer case by actual mechanism:

- source/static check;
- schema mutation;
- local data mutation;
- production-input mutation;
- wrapper integration causal;
- bootstrap integration causal;
- hard-coded fixture;
- synthetic result check.

If another materially inaccurate integration claim is found, stop with the
implementation-blocked verdict rather than widening this repair silently.

──────────────────────────────────────────────────────────────────────────────
12. PRESERVE FINDING J
──────────────────────────────────────────────────────────────────────────────

The independent audit passed a fresh 928-case J matrix.

Do not weaken the accepted J closure.

Re-run the complete J regression after A/C/H/I changes.

Require continued rejection of:

- missing acceptance fields;
- unknown acceptance fields;
- mistyped fields;
- wrong enums;
- contradictory success/failure data;
- stale contract identities;
- empty assertion maps;
- missing/renamed/unknown assertions;
- non-Boolean assertions;
- aggregate inconsistency;
- empty rebinding proofs;
- missing/extra/duplicate pointers;
- wrong pointer count;
- false normalized equality;
- nonzero non-root differences;
- empty H matrices;
- missing replay evidence;
- mixed-generation contract/schema/result chains.

Any J regression is a stop condition.

──────────────────────────────────────────────────────────────────────────────
13. CONTRACT–SCHEMA–SOURCE–RECORD CONSISTENCY
──────────────────────────────────────────────────────────────────────────────

Reconstruct complete field maps for every changed or extended family:

- main bootstrap contract;
- interpreter-invocation observation;
- copied-artifact initial observation;
- copied-artifact fresh reverification;
- bootstrap result;
- bootstrap outcome;
- bootstrap failure;
- staged success commit;
- final success commit;
- postcommit observation;
- process-self-check result;
- qualification result;
- publication matrix;
- producer case registry.

For each field bind:

- JSON pointer;
- owner;
- required/optional;
- type;
- enum/const;
- cardinality;
- unknown-field rule;
- success/failure/precommit/postcommit applicability;
- cross-field rule;
- contract identity;
- authority role;
- producer;
- consumer.

Require exact agreement among:

- contract;
- JSON Schema;
- source producer;
- actual record;
- runtime validator, if any;
- package tests;
- independent validator.

──────────────────────────────────────────────────────────────────────────────
14. REQUIRED PRODUCER CAUSALS
──────────────────────────────────────────────────────────────────────────────

At minimum run:

A. Interpreter causals

- exact flags pass;
- missing `-I`;
- missing `-S`;
- missing `-B`;
- missing all;
- missing `-B` plus bytecode environment;
- stale record;
- missing record;
- contradictory record.

B. Copy reverification causals

- unchanged pass;
- same-size in-place mutation;
- same-size replacement;
- symlink replacement;
- mode change;
- hardlink change;
- truncate;
- append;
- disappearance;
- held-read mutation;
- cached-observation substitution.

C. Publication causals

- the complete matrix in §9.

D. Producer-lineage causals

- repaired real wrapper payload mismatch case;
- no local-only substitute;
- exact case-registry closure;
- exact mechanism-classification ledger.

E. J regression

- complete accepted J matrix.

All dynamic causals must retain replayable source and fixture evidence.

──────────────────────────────────────────────────────────────────────────────
15. FRESH INDEPENDENT VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement one fresh validator that imports neither producer helpers nor
producer mutation fixtures.

It must independently test:

- interpreter flag evidence;
- copy-reverification freshness;
- success-stage/final-publication semantics;
- no existing-final adoption;
- precommit/postcommit classifications;
- replay closure;
- producer case 28’s actual wrapper invocation;
- complete producer mechanism classification;
- qualification-result consistency;
- full J closure.

Pin an independent literal case-name and expected-reason set.

Require:

- exact count;
- uniqueness;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skipped case.

──────────────────────────────────────────────────────────────────────────────
16. TWO FRESH MATERIALIZATIONS AND HANDOFFS
──────────────────────────────────────────────────────────────────────────────

Run the repaired bootstrap twice into physically distinct implementation-owned
roots.

Before Carrier 0002 require:

- distinct roots;
- exact copied bytes;
- fresh post-copy reverification for every copied artifact;
- normalized auxiliary records equal;
- normalized launch contracts equal;
- payload bytes equal;
- normalized requests equal;
- no child;
- no target inspection;
- no success commit yet unless the protocol explicitly commits bootstrap
  materialization before handoff and the contract says so.

Then run Carrier 0002 in both roots.

Require:

- request admission;
- constructed launch;
- wrapper admission;
- compilation and execution;
- same PID;
- exact constructed environment;
- exact observed owned values;
- diagnostic-only extra names;
- wrapper SHA exact and once;
- CLI conformance;
- no child;
- no target inspection;
- all expected outputs;
- payload success;
- wrapper exit 0;
- correct staged and final success-publication behavior;
- authoritative final commit exact and independently reopenable.

Normalize root paths, PIDs, root-derived values, and derived hashes according
to the closed semantic normalization rule.

Require normalized semantic equality.

──────────────────────────────────────────────────────────────────────────────
17. REGRESSION SUITE
──────────────────────────────────────────────────────────────────────────────

Re-run:

- current producer suite;
- current independent validator;
- accepted J 928-case regression;
- repaired A/C/H/I suite;
- deterministic materialization checks;
- two handoffs;
- manifest and temporal-inventory checks;
- static-security checks;
- authority/non-authority checks;
- literal-path and five-artifact copy checks;
- exact fixed-environment checks;
- exact twelve-pointer proof checks.

Report exact test identities, counts, skips, failures, and outputs.

No failed or superseded attempt may contribute a final pass identity or count.

──────────────────────────────────────────────────────────────────────────────
18. STATIC SECURITY AND AUTHORITY REVIEW
──────────────────────────────────────────────────────────────────────────────

Inspect all changed source, contracts, schemas, tests, and new executable
fixtures for:

- network;
- Git;
- shell;
- candidate/target path access;
- broad Downloads scan;
- latest/prefix discovery;
- existing-root adoption;
- unsafe symlink following;
- overwrite;
- hidden production test hooks;
- production-reachable injection;
- secret-bearing output;
- authority widening.

Require:

- every injection mechanism qualification-only;
- no ordinary CLI, environment, request, copied artifact, or target input can
  activate it;
- no evidence-only source is part of the future consumer export boundary;
- internal success commit explicitly does not mean Git commit or external
  publication;
- package remains process-only.

Do not emit sensitive matched content.

──────────────────────────────────────────────────────────────────────────────
19. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Retain every failed implementation or validation attempt separately.

For each bind:

- ordinal;
- exact source identity;
- operation;
- expected result;
- actual result;
- first blocker;
- artifacts created;
- mutation posture;
- superseding attempt;
- contribution to final verdict:
  none.

Do not overwrite failed evidence.

No failed attempt contributes:

- final source identity;
- passing count;
- causal count;
- manifest identity;
- readiness verdict.

──────────────────────────────────────────────────────────────────────────────
20. OPENING AND CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Capture complete lstat/no-follow opening inventories for:

- current package;
- blocking audit;
- predecessor package, if opened;
- findings reconciliation, if opened;
- qualified launcher, if opened;
- import reconciliation, if opened;
- pinned Python.

Repeat complete closing inventories.

Require exact equality.

Do not mutate or clean supplied roots.

Retain complete inventories of implementation-owned fixtures before removing
them.

For every removed root:

- two fresh `lstat` observations;
- ENOENT twice;
- zero process survivor;
- zero descriptor survivor.

──────────────────────────────────────────────────────────────────────────────
21. SUCCESSOR PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize all source, contracts, schemas, tests, validation, lineage,
provenance, and closeout files before sealing.

Create a temporal final inventory excluding:

- itself;
- future manifest A;
- future manifest B.

Create `manifest/` only when terminal manifests are ready.

Use two independently implemented lstat/no-follow generators.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no missing/duplicate path;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests.

No filesystem write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
22. STOP CONDITIONS
──────────────────────────────────────────────────────────────────────────────

Return the implementation-blocked verdict when:

- repair requires an unauthorized semantic path;
- exact interpreter flag verification cannot be implemented without changing
  the closed CLI contract;
- post-copy reverification cannot reopen and hash destination bytes;
- an exclusive atomic no-replace publication primitive is unavailable;
- a fallback would be required;
- a preexisting final commit would need adoption;
- postcommit disposition cannot be made explicit;
- any required publication causal remains a false acceptance;
- case 28 cannot become a true wrapper integration causal;
- another materially inaccurate producer integration claim is discovered;
- Finding J regresses;
- ordinary production can reach an injection hook;
- supplied-root drift occurs.

Return `IMPLEMENTATION_PROVENANCE_MISMATCH` for supplied-root mutation,
opening/closing inequality, incomplete child-process evidence, or capsule
closure failure.

Do not repair supplied roots.

──────────────────────────────────────────────────────────────────────────────
23. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor-root identity
3. Current-package identity and closure
4. Blocking-audit identity and adopted findings
5. Exact repair authority
6. Semantic touched-path freeze
7. Before/after identities for every changed semantic path
8. Unchanged semantic-path confirmation
9. Finding A implementation
10. Interpreter-invocation field map
11. Finding A causal results
12. Finding C implementation
13. Post-copy reverification field map
14. Finding C causal results
15. Finding H publication model
16. Staged commit protocol
17. Exclusive final publication mechanism
18. Exact authoritative commit point
19. Precommit/postcommit classification
20. Existing-final and retry treatment
21. Complete publication matrix
22. Replay-evidence closure
23. Injection-hook reachability
24. Finding I repaired producer case
25. Complete producer case-classification ledger
26. Finding J regression
27. Contract/schema/source/record consistency
28. Fresh independent validator
29. Two materializations
30. Two Carrier 0002 handoffs
31. Regression-suite results
32. Static security and authority findings
33. Failed/superseded attempts
34. Supplied-root closing equality
35. Fixture cleanup and ENOENT observations
36. Successor inventory and manifests
37. Severity-ranked residual findings
38. Remaining uncertainty and nonclaims
39. Explicit confirmations

Required confirmations:

CURRENT_PACKAGE_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
PREDECESSOR_PACKAGE_MUTATION_NOT_PERFORMED
FINDINGS_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_NOT_INSPECTED
STRATEGIC_B_NOT_INSPECTED
V1_V2_V3_TARGETS_NOT_INSPECTED
ONLY_BOUNDED_A_C_H_I_REPAIR_IMPLEMENTED
FINDING_J_CLOSURE_PRESERVED
INTERPRETER_FLAGS_EFFECTIVELY_VERIFIED
INTERPRETER_FLAG_TOKENS_VERIFIED
MISSING_I_REJECTED
MISSING_S_REJECTED
MISSING_B_REJECTED
ENVIRONMENT_CANNOT_SUBSTITUTE_FOR_MISSING_B
POST_COPY_DESTINATION_FRESHLY_REOPENED
POST_COPY_DESTINATION_BYTES_FRESHLY_HASHED
CACHED_IDENTITY_NOT_USED_AS_REVERIFICATION
SAME_SIZE_IN_PLACE_MUTATION_REJECTED
REPLACEMENT_INODE_REJECTED
STAGED_SUCCESS_COMMIT_NONAUTHORITATIVE
ATOMIC_EXCLUSIVE_FINAL_PUBLICATION_USED
NO_PUBLICATION_FALLBACK
AUTHORITATIVE_COMMIT_POINT_UNAMBIGUOUS
PRECOMMIT_FAILURES_NONAUTHORITATIVE
POSTCOMMIT_FAILURES_EXPLICITLY_NON_DOWNGRADING
PREEXISTING_FINAL_NOT_ADOPTED
SAME_ROOT_RETRY_FORBIDDEN
FRESH_ROOT_RETRY_AFTER_PRECOMMIT_FAILURE_VERIFIED
PUBLICATION_BOUNDARY_MATRIX_COMPLETE
PUBLICATION_BOUNDARY_MATRIX_PASSED
PUBLICATION_REPLAY_EVIDENCE_COMPLETE
NO_DELETED_REPLAY_FIXTURE_REQUIRED
NO_PRODUCTION_REACHABLE_FAILURE_HOOK
PRODUCER_CASE_28_EXECUTES_WRAPPER
WRONG_PAYLOAD_REJECTED_BY_WRAPPER
PRODUCER_CASES_ACCURATELY_CLASSIFIED
FINDING_J_928_CASE_REGRESSION_PASSED
ACCEPTANCE_SCHEMA_CLOSURE_PRESERVED
CONTRACT_SCHEMA_SOURCE_RECORD_CONSISTENCY_VERIFIED
FRESH_INDEPENDENT_VALIDATOR_PASSED
TWO_FRESH_MATERIALIZATIONS_PASSED
TWO_FRESH_CARRIER_0002_HANDOFFS_PASSED
PACKAGE_AUTHORITY_REMAINS_PROCESS_ONLY
INTERNAL_COMMIT_NOT_GIT_OR_PUBLICATION_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
A6_NOT_STARTED
INDEPENDENT_AUDIT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

After this implementation reaches the ready-for-audit verdict, run one fresh
parent-owned independent audit. Do not add another findings-reconciliation
tranche unless that audit produces a new concrete discrepancy.

**Source:** Codex’s fresh independent audit report above.

**Confidence:** 0.995 that A, C, H, and I are now the exact repair scope; 0.98 that H should be repaired through staged verification plus exclusive atomic publication; 0.99 that J should remain untouched except for consistency extensions required by the four confirmed repairs.
