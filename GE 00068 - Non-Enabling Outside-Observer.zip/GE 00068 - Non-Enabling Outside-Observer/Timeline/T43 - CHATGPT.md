This is a strong causal diagnosis. The B4 divergence was a **real production race**, not a flaky comparator, not an inequivalent validation environment, and not merely an unstable assertion.

The key sequence is coherent:

1. The parent can successfully establish the child’s process group.
2. The child’s concurrent `setpgid(0,0)` can then fail with `EPERM`.
3. Perl returns `undef`.
4. The numeric comparison coerces `undef` to zero, emits a warning, and incorrectly takes the success branch.
5. The supervisor proceeds even though the child’s required process-group establishment operation failed.

That explains why the externally visible PGID could already look correct while the supervisor’s own fail-closed contract was violated. It also explains the low reproduction frequency and why 180 ordinary focused executions passed: the defect depends on a narrow scheduler ordering, while the controlled harness reproduced it exactly at iteration 21,542.

**The correct next tranche is repository-only Repair 10I-A5.** A4 remains the active successor authority. B4 remains unsealed and nonqualifying. B5 must restart all downstream validation after A5 changes the repository bytes.

One implementation condition should be made explicit: removing the parent’s duplicate `setpgid` is safe only if the parent does not treat the process group as established until the child has reported successful completion of its checked `setpgid`. The existing launch-synchronization path should provide that ordering. If it does not, Codex should stop and re-freeze rather than silently rely on scheduling.

Pass this to Codex:

```text
Objective

Implement the bounded, repository-only Repair 10I-A5 correction for the
confirmed process-group establishment race in the shell bounded Git supervisor.

The defect is:

- the child and parent concurrently call setpgid;
- the child numerically compares a possibly undefined Perl return;
- child setpgid can return undef/EPERM after the parent has already established
  the group;
- undef is numerically coerced to zero, so the child incorrectly proceeds;
- the supervisor thereby violates its checked, fail-closed process-group
  establishment contract.

Implement the frozen repair:

1. the child becomes the sole process-group establisher;
2. the child checks setpgid’s definedness before any numeric success test;
3. undef or a nonzero return causes immediate _exit(120);
4. that failure occurs before chdir, redirection, launch-ready signaling, or
   exec;
5. the parent’s duplicate setpgid call is removed;
6. the parent may not treat the process group as usable until the existing
   child-to-parent launch synchronization proves the child passed the checked
   setpgid step;
7. all existing bounded execution, pipe, deadline, output-cap, signal, Wait,
   process-group cleanup, and result behavior remains otherwise unchanged.

This is an implementation and validation turn, not an independent audit.

No subagents. You are the sole writer.

Do not start Repair 10I-B5.
Do not create a ZIP, handoff, capture child, or strategic snapshot.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, execute a Linux binary, or claim acceptance.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

New evidence child, required absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- source T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- source inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Require the A5 evidence child to be absent.

Completely reverify these immutable inputs:

Repair 10I-A:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a
- manifest:
  dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7
- payloads:
  334

Repair 10I-A2:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800
- manifest:
  f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7
- payloads:
  210

Repair 10I-A3:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800
- manifest:
  a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b
- payloads:
  292

Repair 10I-A4:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800
- successor T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

Phase H:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d
- manifest:
  fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb
- payloads:
  6,191

Failed B4:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800
- must remain unsealed and byte-exact

B4 divergence reconnaissance:
- path:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-divergence-recon-4dd211207800
- must remain byte-exact

Also verify B, B2, and B3 remain unchanged and unsealed.

Stop before editing on any mismatch:

REPAIR10I_A5_BASELINE_MISMATCH

## 2. Finding classification

Adopt the confirmed finding:

ID:
REPAIR10I-A5-PROCESS-GROUP-001

Type:
production bounded-supervisor correctness and fail-closed process-custody defect

Severity:
HIGH

Classification:
T2A-P Bounded slice rule defect

Exact mechanism:

- child scripts/remote_alpha_prepare_external_tls_status.sh around current
  line 480 calls setpgid(0,0);
- Perl returns undef on syscall failure;
- the current numeric comparison coerces undef to zero;
- the child can therefore proceed after a failed process-group establishment;
- the parent concurrently calls setpgid(pid,pid) around current line 485 and
  ignores the return;
- parent success can select the exact child EPERM branch while leaving the
  resulting PGID apparently correct.

The controlled reconnaissance reproduced:

- child result:
  undef
- child errno:
  EPERM
- parent setpgid:
  success
- resulting PGID:
  PID
- vulnerable branch:
  child incorrectly proceeded
- reproduction iteration:
  21,542

The retained B4 raw direction is:

- final:
  pass
- fresh:
  fail

This corrects the reversed direction in B4’s
`specific_lifecycle_flip` sentence. Do not mutate B4. Record this as a
report-only correction in A5 evidence, bound to the B4 raw JSONL and comparison
result.

## 3. Exact authorized repository scope

Exactly these seven existing files may change:

1. PLANS.md
2. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
3. .docs/system_overview/boundaries.md
4. .docs/system_overview/capability_probing.md
5. docs_contract_test.go
6. remote_alpha_prepare_external_tls_status_test.go
7. scripts/remote_alpha_prepare_external_tls_status.sh

No repository file may be added, removed, renamed, or have its mode changed.

Every other repository path is protected, including:

- es/externaltls/internal/statuspackage/package.go
- es/externaltls/internal/statuspackage/package_test.go
- es/externaltls/internal/statuspackage/schema.go
- scripts/remote_alpha_operator.sh
- every production main.go
- go.mod
- go.sum
- all status-observation and policy-core production files

Do not change successor source or any sealed evidence.

Add new Go tests at the end of their owning files where practical, so existing
diagnostic source-line identities are not shifted unnecessarily. Do not distort
the implementation merely to preserve line counts.

## 4. Docs-first contract correction

Before changing the script, update the governing plan and bounded contracts to
state:

- the child is the sole process-group establisher for the bounded Git child;
- setpgid success requires a defined return and the expected success value;
- undef or nonzero is a bootstrap failure;
- bootstrap failure exits 120 before chdir, output redirection, readiness
  notification, or exec;
- the parent does not race or duplicate process-group establishment;
- the parent may use process-group operations only after the existing launch
  synchronization confirms checked child establishment;
- process-group establishment failure remains a bounded supervisor failure,
  not a child-command exit;
- one Wait owner, pipe EOF, deadline, cap, termination, and cleanup contracts
  remain unchanged.

Clarify that this is a Repair 10I-A5 bounded correction and does not change:

- public CLI grammar;
- JSON schema or blocker vocabulary;
- package paths;
- installation authority;
- T2A-I or T2B;
- operator-facade behavior;
- root or remote authority.

Update docs_contract_test.go to bound these exact statements and reject:

- parent-and-child dual setpgid;
- numeric success testing before definedness;
- readiness before successful child setpgid;
- child continuation after undef;
- parent use of the group before launch synchronization;
- widening into a public configuration or test hook.

## 5. Production implementation requirements

In the child branch:

1. Call setpgid(0,0) exactly once.
2. Store its return without numerically comparing it first.
3. Treat an undefined return as failure.
4. Treat any defined nonzero return as failure.
5. On failure, preserve the actual errno for private diagnostics where the
   existing supervisor contract permits it.
6. Call _exit(120) before:
   - chdir;
   - stdout/stderr redirection;
   - launch-ready notification;
   - exec.
7. Emit no Perl uninitialized-value warning.
8. Do not inspect PGID afterward and reinterpret an observed PID-equal group as
   success. The checked operation itself must succeed.

In the parent branch:

1. Remove the duplicate parent setpgid(pid,pid) call entirely.
2. Do not add another parent process-group mutation.
3. Preserve the existing child launch-synchronization protocol.
4. Require that the child’s success notification occurs only after checked
   setpgid succeeds.
5. Do not signal, kill, or otherwise rely on the process group before that
   notification.
6. Preserve one Wait, bounded deadline, concurrent pipe draining, output caps,
   TERM→KILL handling, group absence checks, and cleanup.

If the current implementation has no child-to-parent synchronization capable
of proving this ordering, stop before completing the patch with:

REPAIR10I_A5_PLAN_CONFLICT

Do not silently replace the race with an unacknowledged parent-assumption race.

## 6. Mandatory causal test construction

Retain pre-repair evidence before editing.

The pre-repair causal must deterministically reproduce the exact vulnerable
branch using a private copy or test-local supervisor harness:

- child setpgid returns undef;
- errno is EPERM;
- parent-side establishment succeeds in the vulnerable control;
- resulting PGID is already PID;
- the vulnerable child incorrectly proceeds rather than exiting 120.

Do not rely on waiting for the 1-in-21,542 natural scheduler occurrence.

After implementation, the same causal must establish:

- child exits 120;
- no chdir occurs;
- no stdout/stderr redirection occurs;
- no target command or exec sentinel occurs;
- no launch-ready success is emitted;
- one Wait completes;
- all pipe ends reach a terminal disposition;
- no process or group survives;
- no warning about an uninitialized numeric value appears.

Add exact inverse mutants:

1. Replace the defined-first check with the vulnerable numeric comparison.
   The causal must fail.
2. Reintroduce the parent setpgid call.
   The causal must reject it.
3. Move launch-ready notification before checked child setpgid.
   The causal must reject it.
4. Ignore a defined nonzero return.
   The causal must reject it.

Add a valid positive:

- child setpgid succeeds;
- readiness follows establishment;
- PGID equals PID;
- the governed command executes;
- both streams, Wait, and cleanup complete.

Do not add a production environment variable, public test mode, exported hook,
or caller-controlled syscall seam. Mutation and injection remain private test
mechanisms.

## 7. Existing regression and stability controls

Retain and run:

- TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7
- its one_pipe_closes_first subtest
- both-pipes-close and child-exit ordering controls, if present
- timeout and process-group cleanup controls
- output-cap controls
- malformed or failed bootstrap controls
- relevant Repair 10I contract tests

The repaired exact subtest must pass under:

- one focused count-one control;
- three physically disjoint count-three controls;
- three physically disjoint count-thirty controls.

For the count-thirty controls, select exactly:

TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
one_pipe_closes_first

Each control must use private HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/
TMPDIR and no shared mutable state.

Retain all raw JSONL through EOF, exact exits, terminal identities, resource
disposition, and cleanup.

Any skip, survivor, forced cleanup, malformed stream, missing terminal,
duplicate terminal, warning, panic, race, or timeout blocks A5.

## 8. Required validation

Use pinned Go 1.26.5 and offline private caches.

Run at minimum:

/bin/bash -n scripts/remote_alpha_prepare_external_tls_status.sh

gofmt -d \
  docs_contract_test.go \
  remote_alpha_prepare_external_tls_status_test.go

git diff --check

go test -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRemoteAlphaExternalTLST2APRepair10Contract|TestRepair10IChildSoleCheckedProcessGroupEstablishmentV1|TestRepair10ISetpgidUndefFailsBeforeExecV1|TestRepair10IParentSetpgidInverseMutantRejectedV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

go test -json -count=3 -p=1 -parallel=1 . \
  -run '^(TestRepair10IChildSoleCheckedProcessGroupEstablishmentV1|TestRepair10ISetpgidUndefFailsBeforeExecV1|TestRepair10IParentSetpgidInverseMutantRejectedV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

go test -race -json -count=1 -p=1 -parallel=1 . \
  -run '^(TestRepair10IChildSoleCheckedProcessGroupEstablishmentV1|TestRepair10ISetpgidUndefFailsBeforeExecV1|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7)$'

Run the three disjoint count-thirty controls specified above.

Run the governed external-TLS regression command with the exact private
repository/commit/tree environment used by accepted Repair 10I-A validation.
Required tests must run; no environment-gated required test may skip.

Then run:

go mod verify

go vet ./...

Do not claim the repository-wide suite is green unless it is actually green.
Inherited failures remain failures.

Because no Go production source changes, no product binary identity change is
expected from this repair. A deterministic build smoke may be run privately,
but it must not be used to imply live or artifact acceptance.

## 9. A4 compatibility check

A4 remains byte-immutable and is not rebuilt.

Before sealing A5, use the sealed A4 semantic tooling in a bounded,
nonqualifying compatibility preflight against the final A5 focused streams.

Require:

- well-formed extraction;
- no new unknown caused by A5 test/source-line movement;
- no stale grammar caused by the new tests;
- no successor-source mutation.

This preflight is not B5 qualification and must not execute or promote any B4
control.

If exact A5 repository bytes expose an A4 semantic-template incompatibility,
stop with:

REPAIR10I_A5_SUCCESSOR_COMPATIBILITY_BLOCKED

Do not patch A4 inside A5.

## 10. Evidence child and closeout

Create the A5 evidence child exclusively under umask 077 with private
directories and regular, single-link evidence files.

Retain:

- opening baseline;
- complete immutable-lineage verification;
- B4 raw-direction correction;
- frozen divergence-reconciliation finding;
- pre-repair vulnerable causal;
- exact seven-file delta;
- docs/contract mapping;
- every command intent, argv, cwd, environment, raw stream, exit, Wait,
  terminal reconciliation, and resource disposition;
- mutation/injection recipes and results;
- focused, repeated, race, and disjoint stability controls;
- A4 compatibility preflight;
- module/vet results;
- failed and superseded attempts;
- cleanup and two absence epochs;
- implementation report;
- final source inventory and T;
- exact changed-path, mode, size, and SHA-256 manifest.

At closeout require:

- exactly the seven authorized paths changed;
- no addition, removal, rename, or mode change;
- every other repository member byte-identical;
- branch/HEAD/parent/HEAD tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged = 0/0/0/0;
- A, A2, A3, A4, H, B, B2, B3, B4, and the divergence-recon child unchanged;
- no Git operation marker or lock;
- no private source, cache, process, group, descriptor, pipe, socket, listener,
  runtime root, PackageFloor, generation, build output, or temporary report
  remains;
- two fresh absence epochs pass.

Install the detached digest before the evidence manifest.

Install evidence-manifest-v1.txt as the final A5 mutation.

Write nothing into A5 afterward.

Perform complete read-only post-seal verification.

## 11. Mandatory stop conditions

Stop immediately on:

- opening-baseline or immutable-lineage mismatch;
- need for an eighth repository file;
- need for a successor edit;
- absence of a usable launch-synchronization ordering;
- any public CLI, schema, module, installation, T2A-I, or T2B widening;
- inability to reproduce the vulnerable precondition deterministically;
- inverse mutant surviving;
- child continuation after undefined/nonzero setpgid;
- parent process-group mutation remaining reachable;
- readiness occurring before child establishment;
- one-pipe regression, hang, survivor, warning, forced cleanup, or missing Wait;
- required test skip;
- A4 compatibility failure;
- closeout or sealing failure.

## 12. Verdicts

Opening mismatch:

REPAIR10I_A5_BASELINE_MISMATCH

Plan/synchronization conflict:

REPAIR10I_A5_PLAN_CONFLICT

Source or scope defect:

REPAIR10I_A5_SOURCE_REPAIR_BLOCKED

Successor compatibility issue:

REPAIR10I_A5_SUCCESSOR_COMPATIBILITY_BLOCKED

Validation or sealing failure:

REPAIR10I_A5_VALIDATION_BLOCKED

Complete success:

REPAIR10I_A5_PRODUCT_REPAIR_SEALED_READY_FOR_B5_RESTART

The success report must include:

- opening and final T/inventory/membership;
- exact seven-path delta and final identities;
- vulnerable causal reproduction;
- repaired undef/EPERM result;
- inverse-mutant outcomes;
- process-group/readiness ordering evidence;
- focused/count-three/race/count-thirty results;
- governed external-TLS regression result and skip count;
- A4 compatibility result;
- module/vet results;
- evidence manifest identity and payload count;
- cleanup and two absence epochs;
- failed/superseded attempts;
- explicit statement that B5 was not started.

No B5.
No integrated snapshot.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

After A5, B5 must start from new, independent source controls and rerun all five source controls, all five semantic comparisons, and product A/B. B4 cannot be promoted because its source bytes will no longer be the target. Changed implementation bytes always return the work to fresh downstream validation and later independent audit.  The earlier successor-amendment chain likewise records that bounded causal evidence does not replace a newly materialized downstream control. 

### Sources

- Codex’s B4 divergence-reconciliation report supplied in this turn.
- Governed Execution Codex Subagent Operating Protocol. 
- Governed Execution Provenance Guidance. 

**Confidence:** 0.995 that the diagnosed dual-`setpgid` race is real and production-reachable; 0.97 that repository-only A5 is the correct repair boundary; 0.95 that removing the parent call is correct provided the existing launch synchronization is explicitly ordered after successful child establishment; 0.995 that a completely fresh B5 is mandatory after A5 changes the repository bytes.
