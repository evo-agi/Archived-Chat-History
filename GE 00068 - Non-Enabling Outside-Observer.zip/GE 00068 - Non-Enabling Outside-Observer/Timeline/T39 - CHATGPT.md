A4 is the clean result we needed. It closes the **comparison-policy defect only**, within the frozen three-file successor scope, and it preserves the stronger controls rather than relaxing them:

- Physical mappings and disjointness remain mandatory qualification inputs.
- Final↔mutant now accepts only the exact declared semantic delta.
- Final↔fresh still requires and reaches accepted equality.
- Mutant↔fresh reaches the inverse exact delta.
- Repository source remains unchanged.
- B4 does not yet exist.

There is no basis for A5 or a repository repair before B4. The next move is a completely fresh B4 execution. The retained B3 inputs proved the A4 causal fix, but none of B3’s source-control executions should be promoted into B4. This follows the established amendment rule: successor repair closes its own causal defect, while downstream validation restarts in a new child. 

Pass this to Codex:

```text
Objective

Execute Repair 10I-B4 from the beginning using the sealed Repair 10I-A4
successor.

Freshly:

1. execute and independently qualify all five source controls;
2. run the five governed semantic comparisons;
3. run two physically independent product A/B preparations and direct byte
   comparisons;
4. seal the complete Repair 10I-B4 evidence child;
5. only after B4 sealing, create and verify a new Option-B integrated source
   ZIP, audit handoff, and capture child.

Do not repair repository or successor source in this turn.

If any source, successor, validation, comparison, product-preparation, cleanup,
sealing, or capture defect is discovered, stop with the applicable blocking
verdict. Do not patch it inside B4.

No subagents. You are the sole operator.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Required new B4 child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b4-closure-4dd211207800

Required new public targets, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-integrated-4dd211207800-i10b4.zip

/Users/ds/Downloads/ES-T2AP-repair10-integrated-4dd211207800-i10b4-audit-handoff.md

Required new capture child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-4dd211207800-i10b4

## 1. Immutable lineage

Repair 10I-A:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Expected manifest:
dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7

Expected payloads:
334

Repair 10I-A2:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800

Expected manifest:
f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7

Expected payloads:
210

Repair 10I-A3:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800

Expected manifest:
a13558be3a3cae274a9654496633041cb5b47a83af3d94b73655d7fccbda252b

Expected payloads:
292

Repair 10I-A4:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Expected successor:
- T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- members:
  12

Expected manifest:
772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf

Expected payloads:
540

Expected binaries:

repair10-runner
- SHA-256:
  9df605f44e2a5fa10cd8bbc9360a7709a739f209fa4bf386353c8a790ef45961

repair10-compare
- SHA-256:
  e53c6878acddb2e601376486ee8994d73bf30f176606ca7f42dea8434ddc6f0f

repair10-semantic
- SHA-256:
  ef378cfe85c26f1e45eb6f4a0895d58c53647c1b74a685d1636bccbb81a52a66

repair10-fixture
- SHA-256:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Phase H:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Expected manifest:
fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Expected payloads:
6,191

Historical failed children are immutable and nonqualifying:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b3-closure-4dd211207800

Do not resume, seal, rename, remove, or modify any of those failed children.

## 2. Mandatory opening gate

Before creating B4, require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- source T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- source inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6
- package_test.go SHA-256:
  046db5a2e55f81fb754303606780eb352bc5732b49fc999f91db6ce54d010f3f

Completely reverify every immutable manifest, path set, mode, size, hash,
single-link condition, and detached digest. Do not rely only on aggregate
digests.

Require all B4 and capture targets to be absent.

Stop before creating B4 on any mismatch:

REPAIR10I_B4_BASELINE_MISMATCH

## 3. Authority and posture

Repair 10I-A4 is the sole active successor authority.

A, A2, A3, H, B, B2, and B3 are predecessor or historical evidence only.

A4’s comparisons against retained B3 inputs are bounded successor causal
evidence. They do not replace fresh B4 source controls.

Authorized:

- create the exclusive B4 child;
- copy exact A4 binaries into private roots without hardlinks;
- materialize private source and Git controls;
- run tests and product preparation;
- produce and seal B4 evidence;
- after B4 sealing, create one Option-B capture from absent targets.

Not authorized:

- repository edits;
- successor edits;
- mutation of immutable lineage;
- staging, commit, push, PR, merge;
- installation or live route execution;
- remote contact;
- Linux binary execution;
- T2A-I or T2B effects;
- independent-audit claims.

## 4. B4 evidence child

Create B4 exclusively under umask 077 with exactly:

opening/
tool/
commands/
validation/
baselines/
comparisons/
preparation/
builds/
findings/
closeout/

All directories must be mode 0700.

All files must be regular, single-link, non-symlink entries with intended
evidence mode 0600 or 0700.

No hardlinked evidence.

Retain failed and superseded attempts additively. Never overwrite an attempt.

## 5. A4 successor hard gate

Before any source control executes:

1. Reverify all 12 A4 source members.
2. Reverify the exact three-path A3→A4 delta.
3. Reverify all retained A4 A/B binaries.
4. Require A/B binary byte equality, inode distinction, single-link status,
   expected modes, and exact hashes.
5. Reverify A4 causal results:
   - vulnerable A3 final↔mutant:
     blocked-uncertain / mutant-delta-policy-mismatch;
   - repaired final↔mutant:
     qualified-different, exact provenance, AcceptedEqual=false,
     zero unknowns, exit 2;
   - final↔fresh:
     qualified-equal, AcceptedEqual=true, zero unknowns, exit 0;
   - mutant↔fresh:
     qualified-different, exact inverse delta, zero unknowns, exit 2.
6. Copy exact A4 binaries into private B4 tool roots.
7. Require copy-to-origin byte equality and distinct inodes.

Do not rebuild or amend A4 in B4.

A mismatch or tool defect stops with:

REPAIR10I_B4_SOURCE_OR_TOOL_REPAIR_REQUIRED

## 6. Five fresh source controls

Materialize five completely independent, no-hardlink controls:

1. historical HEAD
2. exact Repair 9
3. pristine final Repair 10I
4. intentional final-only mutant
5. fresh independent pristine final Repair 10I

Each control gets physically distinct:

- source;
- Git administration and object store;
- HOME;
- XDG roots;
- GOPATH;
- GOMODCACHE;
- GOCACHE;
- GOTMPDIR;
- TMPDIR;
- runtime root;
- PackageFloor;
- evidence root;
- process session/group;
- socket and listener state.

No mutable state may be shared across controls.

Source identities:

Historical HEAD:
- commit:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338

Repair 9:
- T:
  0ea3b661f09e73e1126bae0f6e993e22bbf21198
- inventory:
  7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e
- members:
  382

Final:
- T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- members:
  389

Fresh final:
- same logical T, inventory, and membership as final;
- independently materialized physical source, Git, cache, runtime, process,
  socket, and evidence state.

Use source_class `pristine-final` for both final and fresh-final controls.
Physical control identity and provenance distinguish them.

Each control executes literally:

go test -json -count=1 -p=1 -parallel=1 ./...

Process exit membership is {0,1}; semantic qualification, not exit alone,
determines acceptance.

For each control retain:

- source inventory and pure T;
- source class and control ID;
- suite specification;
- command intent;
- argv, cwd, and bounded environment;
- effective read policy;
- raw stdout and stderr through EOF;
- exit and Wait disposition;
- command result;
- terminal reconciliation;
- resource ledger;
- two fresh post-clean observations;
- producer semantic extraction;
- opposite-side raw semantic re-extraction;
- producer and peer qualification;
- complete source/tool/spec/result lineage.

Any unknown diagnostic, malformed or truncated stream, duplicate or missing
terminal, unqualified resource disposition, forced cleanup, survivor, EOF
failure, lineage mismatch, or peer re-extraction mismatch blocks the control.

All five controls must independently qualify before comparison begins.

## 7. Fresh intentional mutant

Construct the mutant before execution from exact final source.

Seal its provenance before launching the mutant suite.

The sole changed path is:

es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

Insert exactly:

t.Fatal("intentional Repair 10I mutant")

at the governed Repair 10I insertion site.

Expected source identity from the already frozen mutation recipe:

- base path mode:
  100644
- base size:
  268,924
- base SHA-256:
  cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec
- mutant mode:
  100644
- mutant size:
  268,966
- mutant SHA-256:
  5c5c75ba1c7ee712f006a692a07171b38775bead2dc638fc713e0d24512d9898
- mutant T:
  d57e0a07b3ac60359b0b61e85a5b083255e47f07
- mutant inventory:
  bdca359eb18fccc236c2f0b7bfa9f17d83be5c69d4853eebc0a2bb8675d8ea34

Independently reconstruct and verify those identities; do not merely copy the
values into a record.

Retain:

- base and resulting tuples;
- insertion offset and context digest;
- exact sole changed-path set;
- base and effective T/inventory;
- immutable pre-execution source inventory;
- provenance payload identity.

No post-launch source mutation is permitted.

The intended semantic delta must be exactly the comparison-spec-declared
lifecycle and diagnostic delta. No second semantic or source delta is allowed.

## 8. Independent external requalification

Use the opposite A4 successor side for each control.

Qualification must:

- reopen and identity-bracket raw streams;
- independently extract semantics from raw bytes;
- reject producer captions as proof;
- require independent canonical semantic bytes to match the stored envelope;
- bind source class, source T/inventory, suite spec, command result, terminal
  reconciliation, raw stream, extractor identity, mapping-table identity, and
  qualification record;
- require zero unknowns;
- require complete containment, resource, terminal, and cleanup disposition;
- require physical source/control independence.

No comparison begins until all five peer qualifications are `qualified`.

## 9. Five semantic comparisons

Create five exact comparison specifications.

### Final ↔ fresh

Require:

- both independently qualified;
- physical disjointness passed;
- lifecycle equal;
- diagnostics equal;
- canonical comparable semantics equal;
- zero unknowns;
- AcceptedEqual=true;
- Outcome=qualified-equal;
- reason codes limited to the governed accepted-equality set;
- exit 0.

Raw bytes may differ and must remain reported factually.

### Final ↔ mutant

Require:

- both independently qualified;
- physical mappings valid and disjoint;
- exact mutant provenance;
- zero unknowns;
- exact declared semantic delta only;
- AcceptedEqual=false;
- Outcome=qualified-different;
- no `mutant-delta-policy-mismatch`;
- exit 2.

### Mutant ↔ fresh

Require the exact inverse declared mutant delta:

- both independently qualified;
- zero unknowns;
- Outcome=qualified-different;
- exit 2.

### HEAD ↔ final

Require:

- both independently qualified;
- qualified-different;
- zero unknowns;
- no undeclared final-only:
  - fail;
  - skip;
  - disappearance;
  - package abort;
  - panic;
  - race;
  - warning;
  - malformed stream;
  - unknown diagnostic;
- exit 2.

### Repair 9 ↔ final

Apply the same no-regression rules independently.

Never union HEAD and Repair 9 baseline negatives.

Only explicitly declared new passing identities are permitted.

Any late custody, terminal, resource, mapping, qualification, or close fault
forces:
- AcceptedEqual=false;
- Outcome blocked/rejected;
- exit 1.

## 10. Product A/B

Only after all five comparisons pass, create two fully independent final-source
product controls A and B.

Each side must independently own:

- source;
- private Git repository/common store/refs/index;
- HOME and XDG;
- GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- runtime root and slots;
- PackageFloor and generation hierarchy;
- process/session state;
- sockets/listeners;
- evidence and retained-output roots.

Construct the same deterministic synthetic commit C over exact final T.

Run the exact-candidate compiler-input and deterministic preparation controls
with:

ES_T2AP_PRIVATE_REPOSITORY
ES_T2AP_PRIVATE_COMMIT
ES_T2AP_PRIVATE_TREE

No required test may skip.

Require independently equal:

- C
- T
- D
- E
- source inventory
- compiler closure
- module closure
- GOROOT closure
- tool identities

While origins remain live:

1. open and compare both artifact files through EOF;
2. open and compare both `build-evidence.v2.json` files through EOF;
3. retain independent mode-0600, single-link copies;
4. compare each origin to its retained copy through EOF;
5. prove no inode aliases, hardlinks, path containment, or shared mutable state;
6. parse evidence and independently verify C/T/D, source, compiler, module,
   GOROOT, and tool bindings.

Then:

- close every comparison descriptor;
- remove both mutable controls;
- perform two fresh post-clean absence epochs;
- retain only authorized B4 evidence and the four retained payload copies.

Any C/T/D/E or actual-byte mismatch blocks B4.

## 11. Carry-forward Repair 10I-A evidence

Reverify but do not mutate:

- repository validation;
- no-skip external-TLS regression;
- module verification;
- vet;
- four build records;
- protected package.go identity;
- final source T/inventory.

Label those records:

sealed Repair 10I-A predecessor validation against identical source bytes

Do not represent them as freshly executed by B4.

B4’s five complete source controls and product A/B are fresh.

## 12. B4 closeout and seal

Before sealing:

- recompute final repository T/inventory/membership;
- verify branch/HEAD/parent/HEAD tree/upstream/index;
- require staged/deleted/renamed/unmerged = 0/0/0/0;
- verify protected package.go and all source members;
- reverify A, A2, A3, A4, H, B, B2, and B3;
- prove no Git operation marker or lock;
- prove no private process, group, descriptor, listener, socket, cache, source,
  Git store, runtime root, fixed slot, PackageFloor, generation, build,
  mutation, or temporary report remains;
- perform two absence epochs.

Retain:

- all opening and closing identities;
- all five source-control records;
- fresh mutant provenance;
- all producer and peer qualifications;
- all five comparison specs, results, custody, and reason-code records;
- product A/B source and ownership topology;
- C/T/D/E and byte-comparison transcripts;
- retained A/B payloads;
- complete failed/superseded index;
- command index;
- literal assertion mapping;
- provenance recipe and payload inventories;
- cleanup and absence records;
- implementation report;
- B4 closeout adjudication.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as B4’s final mutation.

Write nothing into B4 afterward.

Perform complete read-only post-seal verification.

B4 readiness must be false unless:

- all five controls qualified;
- final/fresh accepted equality with exit 0 and zero unknowns;
- both mutant comparisons show exactly the declared delta;
- both historical comparisons independently show no undeclared regression;
- product A/B C/T/D/E and actual bytes are equal;
- cleanup and sealing are complete.

## 13. Option-B integrated capture

Start capture only after B4 is sealed and completely reverified.

Use an outer recorder from before the first capture command. It owns:

- exact argv;
- cwd;
- bounded environment;
- raw stdout/stderr through EOF;
- process birth/session/group identity;
- exit;
- Wait/reap disposition;
- original failure and recovery records.

Do not synthesize a failed caller record after the fact.

Require all public targets and the capture child to be absent.

Option-B acceptance binds:

- exact ZIP bytes, size, and SHA-256;
- safe unique member paths;
- member types and logical modes;
- raw ZIP headers;
- CRCs;
- complete membership;
- source inventory and T;
- two independent inode-disjoint extractions;
- archive regular-file type;
- mode 0600;
- link count one;
- captured effective owner UID/GID;
- atomic same-filesystem no-clobber publication;
- completed write, fsync, close, directory sync, and publication record;
- forward and reverse handoff bindings;
- sealed capture manifest.

Treat as supplementary/report-only:

- container ctime;
- birth time;
- device/inode transport identity;
- host flags;
- host-managed xattr names and value digests.

Do not claim historical equality without an opening baseline.
Do not intentionally mutate xattrs.

On any failure:

- retain the original outer record and all completed evidence;
- do not overwrite or reuse the target;
- do not retroactively qualify a partial capture;
- stop with the capture-blocked verdict.

Seal the capture child only after publication, verification, handoff
construction, cleanup, and closing equality.

Do not perform or claim an independent audit.

## 14. Verdicts

Opening mismatch:

REPAIR10I_B4_BASELINE_MISMATCH

Source or successor defect:

REPAIR10I_B4_SOURCE_OR_TOOL_REPAIR_REQUIRED

Validation, comparison, product A/B, cleanup, or B4 seal failure:

REPAIR10I_B4_VALIDATION_BLOCKED

Capture failure after B4 sealing:

REPAIR10I_B4_CAPTURE_BLOCKED

Complete success:

REPAIR10I_B4_SEALED_INTEGRATED_SNAPSHOT_CREATED_READY_FOR_FRESH_AUDIT

The success report must include:

- repository T/inventory/membership;
- A4 source, manifest, and binary identities;
- all five control raw/semantic/qualification identities;
- all five comparison outcomes and exact reason codes;
- fresh mutant provenance;
- product A/B C/T/D/E and compared byte counts;
- B4 manifest identity and payload count;
- ZIP identity, member count, extraction identities, and T;
- handoff identity;
- capture manifest identity and payload count;
- opening/closing repository and Git equality;
- cleanup and absence results;
- failed/superseded attempts;
- explicit nonclaims.

Do not create subagents.
Do not edit repository or successor source.
Do not mutate immutable lineage.
Do not stage, commit, push, install, invoke a live route, contact a remote host,
execute Linux binaries, or perform an independent audit.
```

A4 is implementation validation, not acceptance. The project protocol still requires independent audit to occur later, in a fresh read-only conversation against the exact captured bytes.  Provenance at the B4 and capture gates can establish byte identity, but it cannot by itself establish correctness, sufficient testing, or sound authority boundaries. 

### Sources

- Codex’s Repair 10I-A4 report in the current turn.
- Sealed A2 precedent requiring a fresh downstream restart after a successor amendment. 
- Governed Execution implementation/audit separation protocol. 
- Governed Execution provenance guidance. 

**Confidence:** 0.995 that A4 closes the exact B3 comparison-policy defect; 0.99 that B4 should start immediately without another successor or repository amendment; 0.98 that all five source controls must be freshly executed rather than promoted from B3.
