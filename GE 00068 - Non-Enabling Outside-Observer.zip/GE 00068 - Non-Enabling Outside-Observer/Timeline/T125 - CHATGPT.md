## Assessment

The second audit’s **BLOCK** is well-founded and materially narrower than the first one.

What passed:

- Opening and closing provenance matched the repaired 13-path manifest.
- All four audit perspectives completed.
- The 52-test suite passed under both `077` and `022`.
- Real A6D, real amendment, and synthetic pre-seal/sealed checks passed.
- No authority, decomposition, registry, layout, or non-recursive-bootstrap defect was reported.

What remains is one parser/resource-accounting repair in the existing verifier:

| Residual defect | Required treatment |
|---|---|
| Manifest input can allocate substantially before row/path limits | Bound the manifest file, lines, row count, encoded path, decoded path, and retained row structures **before** allocation or decoding |
| Manifest and sidecar reads bypass the documented scan-byte ceiling | Account for or independently cap every seal-file read before it occurs |
| A malformed decimal suffix gets the wrong error class | Require full-token consumption and classify lexical failure as `MANIFEST_CANONICAL` |
| A malformed spec path may become `IO_OR_RACE` | Reject malformed spec paths during strict spec validation, before filesystem access |

This does **not** justify another architecture reset, registry change, layout change, or broader framework. The selected architecture is still the ES-owned external verifier with committed layout specifications, and the verifier still owns structural closure only.  

No commit or A6 restart should occur. The operating protocol requires repair, new validation and provenance, then a fresh audit of the changed bytes. 

## Codex repair prompt

```text
Permission is workspace-write.

Resume the Evidence Verification v1 implementation in the same implementation
worktree and repair the four residual defects reported by the second
independent audit.

This is a bounded second audit-repair turn.

Do not redesign the external-verifier architecture.
Do not create another worktree.
Do not reset, clean, restore, rebase, or discard the current patch.
Do not modify the Repair 10I candidate.
Do not modify the sealed A6D or amendment children.
Do not modify either completed audit root.
Do not stage, commit, push, create a PR, install, deploy, restart A6, invoke a
live service, contact a network, or perform an independent audit.

No subagents. You are the sole repository writer.

## 1. Paths

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Implementation branch:

codex/evidence-verification-v1

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

First independent audit, read-only:

AUDIT_V1=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-567bceced5df-v1

Second independent audit, read-only:

AUDIT_V2=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v2

Second-audit report:

AUDIT_V2/closeout/final-report.md

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as implementation cwd or source root:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required new repair-evidence directory:

REPAIR_EVIDENCE=$EVIDENCE/audit-repair-v2

Require REPAIR_EVIDENCE to be absent before creation.

## 2. Mandatory opening provenance gate

Before editing, require IMPL_R:

- physical root equals lexical path;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked files;
- exactly nine untracked files;
- every path regular;
- every working-tree mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no path outside the audited set;
- no Git operation marker or lock.

Expected 13 paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Require current audited identities:

- repaired canonical patch-manifest SHA-256:
  `7d114a1479d62ea613957ee7e80f7cf0c37c46a4279d1c26e2ce3474d56a26f5`
- verifier SHA-256:
  `ee8809b8b67b18751d29893bff7d624fc85edee10e84b9eb0e72bf33c7437a68`
- registry SHA-256:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`
- A6D successor layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`
- A6D amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`
- A6 policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`
- final provenance recipe source SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`.

Recover the complete current tracked binary-diff SHA-256 from the second audit
report and retained implementation evidence. Do not infer it from an
abbreviated value.

Run the exact final provenance recipe twice before editing.

Require:

- byte-identical output;
- equality with the repaired retained manifest;
- exact 13-path set;
- exact current per-file identities;
- exact tracked binary-diff digest.

Require AUDIT_V1 and AUDIT_V2 to remain byte-exact, including:

- both final reports;
- all finding ledgers;
- all causal reproduction records;
- opening and closing provenance records;
- validation outputs;
- path inventories.

Require CANDIDATE_R unchanged:

- device/inode:
  `16777234/122118502`;
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`;
- source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
- membership:
  `389 / 375 / 14`;
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require A6D manifest unchanged:

`dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`

Require A6D_AMEND manifest unchanged:

`a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_BASELINE_MISMATCH

## 3. Repair-evidence root

After the opening gate, create REPAIR_EVIDENCE under umask `077` with:

- `opening/`
- `findings/`
- `validation/`
- `provenance/`
- `closeout/`

All directories mode `0700`.

All files regular, single-link, mode `0600`.

Do not overwrite any prior implementation or audit evidence.

Create a finding-disposition record binding every residual finding from
AUDIT_V2 to:

- exact finding ID;
- severity;
- source mechanism;
- authorized repair;
- required causal;
- final disposition.

## 4. Exact repository repair scope

The final repository patch remains the same 13-path tranche.

For this repair turn, authorize modifications to exactly:

1. `tools/evidence_verify/verify_v1.py`
2. `tools/evidence_verify/test_verify_v1.py`

Keep every other repository path byte-identical during this turn, including:

- all five documentation files;
- `registry_v1.json`;
- all three layout specifications;
- both historical fixture files.

No new path.
No deletion.
No rename.
No mode change.
No dependency.
No schema ID or tool ID change.
No layout ID change.
No authority or public-contract change.

If a documentation, registry, layout, fixture, or third source path appears
necessary, stop:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_SCOPE_EXPANSION_REQUIRED

## 5. Residual finding A — bounded manifest parsing

Recover the exact finding and causal evidence from AUDIT_V2.

The manifest parser must not allocate or decode unbounded manifest content
before applying the layout’s row, path, and byte limits.

Implement a bounded, descriptor-based manifest reader.

Requirements:

1. Stat and identity-bind the manifest or external manifest candidate before
   reading.
2. Derive a hard maximum manifest-byte size from:
   - admitted maximum payload rows;
   - maximum encoded relative-path bytes;
   - fixed row grammar overhead;
   - header/count lines;
   - one terminal LF.
3. Reject a manifest whose stat size exceeds that bound before reading it.
4. Do not use:
   - `read_bytes()` on an unbounded manifest;
   - `splitlines()`;
   - an unbounded `.split(b"\n")`;
   - another operation that materializes all unvalidated lines at once.
5. Read literal-LF lines incrementally with a fixed per-line ceiling.
6. Validate the header and count line before allocating the row collection.
7. Parse the count through the bounded canonical decimal parser.
8. Reject count above `max_files` before row allocation.
9. For each row, before decoding or storing:
   - enforce exact field count;
   - enforce maximum line bytes;
   - enforce maximum encoded-path bytes;
   - enforce canonical mode, size, and digest lexical bounds.
10. Decode the relative path only after encoded-length checks.
11. Enforce maximum decoded path bytes and segment count before storing it.
12. Reject a duplicate or out-of-order row immediately.
13. Reject extra or missing rows without retaining unrelated trailing data.
14. Require exactly one final LF and no additional empty row.
15. Keep memory proportional to the admitted manifest limit rather than the
    supplied malformed input.

Do not change the manifest grammar or supported headers.

### Required bounded-parser causals

Use small audit-owned fixtures and, where useful, instrumented read wrappers.

Cover:

- manifest stat size above the derived maximum rejects before body read;
- count above `max_files` rejects before row-list allocation;
- row longer than the derived row ceiling rejects before path decoding;
- encoded path above the maximum rejects before base64 decoding;
- decoded path above the maximum rejects before storage;
- too many rows rejects on the first excess row;
- missing rows rejects;
- exact maximum count and maximum legal path pass in a bounded fixture;
- no test allocates a real large manifest.

The causal must demonstrate early rejection, not merely eventual failure.

## 6. Residual finding B — seal-file scan-byte ceiling

Recover the exact documented scan-byte ceiling and the audit’s causal evidence.

Every byte read by structural verification must be covered by an explicit
pre-read bound.

At minimum:

### Pre-seal

- stat the external manifest candidate before reading;
- apply the manifest-byte ceiling before reading;
- include the admitted candidate size in the invocation’s structural scan
  accounting.

### Sealed

- stat `evidence-manifest-v1.txt` before reading;
- apply the same manifest-byte ceiling;
- stat `evidence-manifest-v1.txt.sha256` before reading;
- require its exact canonical byte size before reading;
- include both seal-file sizes in structural scan accounting before reads.

### Payload scans

- retain the existing per-file and aggregate payload limits;
- account for actual payload sizes before each hash read;
- bound both stability traversals;
- reject before reading the object that would exceed the applicable scan
  ceiling.

Do not weaken the documented payload limits.

Do not represent seal files as manifest payload rows.

Preserve exact sidecar grammar.

### Required seal-budget causals

Cover:

- oversized pre-seal manifest candidate rejects before read;
- oversized sealed manifest rejects before read;
- oversized sidecar rejects before read;
- exact sidecar size with malformed content reaches canonical sidecar
  rejection, not size rejection;
- aggregate structural-scan budget exact boundary passes;
- one-byte structural-scan overflow rejects before overflow-causing read;
- real A6D and amendment children remain within the frozen bound.

Use small injected limits or instrumented wrappers. Do not create large files.

## 7. Residual finding C — malformed decimal suffix classification

Recover the exact malformed decimal input from AUDIT_V2.

The canonical unsigned-decimal parser must consume the complete token.

Requirements:

- no accepted trailing byte;
- no accepted suffix;
- no leading or trailing whitespace;
- no sign;
- no non-ASCII digit;
- no underscore;
- no decimal point;
- no exponent;
- no NUL or control byte;
- canonical leading-zero treatment;
- bounded lexical length;
- early numeric ceiling.

A lexically malformed decimal token must produce:

- outcome `reject`;
- error class `MANIFEST_CANONICAL`;
- the documented manifest-canonical exit;
- exactly one canonical stdout line;
- empty stderr;
- no traceback.

A fully canonical integer that exceeds a layout resource limit must remain in
the resource/closure classification rather than `MANIFEST_CANONICAL`.

Apply the parser consistently to:

- manifest payload count;
- manifest payload size;
- any other manifest decimal token.

### Required decimal causals

Cover:

- the exact audited malformed suffix;
- `1x`;
- `1 `;
- `1_0`;
- `+1`;
- `-1`;
- non-ASCII digit;
- exact lexical maximum;
- lexical maximum plus one;
- exact numeric maximum;
- numeric maximum plus one.

Assert exact error class and exit.

## 8. Residual finding D — malformed spec path classification

Recover the exact malformed layout-spec path and resulting audit output from
AUDIT_V2.

A malformed path originating in a committed layout specification must be
rejected during strict spec validation, before any target filesystem access.

Requirements:

1. Validate every required root directory, required directory, required file,
   and optional-subtree path through one strict path validator.
2. Validate:
   - canonical ASCII segment grammar;
   - nonempty segments;
   - no `.` or `..`;
   - no slash within a segment;
   - no backslash;
   - no NUL or control byte;
   - no absolute path;
   - maximum segment count;
   - maximum encoded path bytes;
   - any existing spec-level depth bound.
3. Validate required-file mode and structural fields before target traversal.
4. Do not call `open`, `stat`, `scandir`, `readlink`, or another target
   filesystem operation for an invalid spec path.
5. Classify malformed spec paths under the exact spec-schema error class and
   exit defined by the current contract.
6. Preserve `IO_OR_RACE` for genuine runtime filesystem or capability
   uncertainty after a valid spec has been accepted.
7. Emit one canonical stdout line and no traceback.

Do not change the layout schema or registered layout bytes.

### Required malformed-spec causals

Cover:

- exact audited malformed path;
- too many segments;
- overlong encoded path;
- empty segment;
- `.` segment;
- `..` segment;
- backslash;
- control byte;
- absolute path;
- invalid required-file mode;
- malformed optional-subtree root.

Instrument the target filesystem boundary and prove it receives zero calls for
each malformed-spec case.

Assert exact error class and exit.

## 9. Preserve prior repairs and architecture

Rerun and preserve all existing coverage for:

- descriptor-bound physical ancestry;
- case-variant containment;
- candidate identity;
- literal-LF grammar;
- bounded registry/spec JSON parsing;
- previous resource-limit causals;
- capability preflight;
- umask independence;
- isolated missing-root/symlink/FIFO cases;
- bounded decimal parser;
- exact helper `0700` modes;
- fixed-record `0600` modes;
- unknown layout rejection;
- no runtime layout injection;
- zero writes;
- deterministic canonical output;
- readiness-content noninterpretation.

Do not weaken or remove a prior causal to obtain a pass.

## 10. Complete fresh validation

After the repairs, rerun the entire validation program from the beginning.

Use the exact interpreter:

`/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`

Expected:

- version `3.13.4`;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Use:

- `-I`;
- `-B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- repair-owned private `TMPDIR`;
- no network.

Required gates:

1. Parse all Python source with `ast.parse`.
2. Strictly parse registry and all three specs.
3. Require registry and all layout bytes/hashes unchanged.
4. Discover and retain the complete test set.
5. Run the complete suite twice under umask `077`.
6. Run the complete suite twice under umask `022`.
7. Require identical discovered test sets.
8. Require zero failure, error, or skip.
9. Run every new residual-finding causal explicitly.
10. Reproduce each vulnerable predecessor and prove the repaired outcome.
11. Run sealed A6D verification twice.
12. Run sealed amendment verification twice.
13. Run synthetic A6 pre-seal verification twice.
14. Seal the synthetic A6 fixture using the existing test-owned writer.
15. Run synthetic A6 sealed verification twice.
16. Require repeated canonical stdout byte equality.
17. Snapshot each target and the verifier package before and after invocation.
18. Require exact equality.
19. Verify historical fixture bytes and hashes unchanged.
20. Run parent-rooted:
    `git -C "$IMPL_R" diff --check`
    with `GIT_OPTIONAL_LOCKS=0`.
21. Scan IMPL_R for cache, bytecode, fixtures, generated manifests, databases,
    journals, locks, and temporary output.

Remove every repair-owned fixture root after its check.

No Go suite.
No product process.
No target mutation.
No child process from the verifier.
No network.

## 11. Repair evidence

Retain beneath REPAIR_EVIDENCE:

- opening provenance;
- second-audit finding ledger;
- exact finding dispositions;
- vulnerable causal reproductions;
- repaired causal results;
- all four complete test runs;
- complete discovered test list;
- real-child checks;
- synthetic checks;
- no-write snapshots;
- failed/superseded attempt index;
- cleanup;
- implementation report inputs.

Preserve EVIDENCE, AUDIT_V1, and AUDIT_V2 byte-exact.

## 12. Final provenance

After all validation passes, use the exact existing provenance recipe source:

- SHA-256:
  `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`

Do not modify or reconstruct it.

Run it twice against IMPL_R.

Require:

- byte-identical output;
- exact same 13-path scope;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deletion;
- zero rename;
- zero unsupported type;
- no path outside scope.

Retain:

- exact recipe source;
- both outputs;
- new canonical patch-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities.

The prior manifests and both prior audit verdicts become predecessor evidence
only and do not qualify these changed bytes.

## 13. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- upstream:
  absent;
- exactly 13 changed or untracked paths;
- four modified tracked paths;
- nine untracked paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- every path regular logical mode `100644`;
- `git diff --check` clean;
- no repository cache, bytecode, generated manifest, fixture, database, lock,
  journal, or temporary output.

Require CANDIDATE_R closing identity equal to opening.

Require A6D and A6D_AMEND unchanged.

Require AUDIT_V1 and AUDIT_V2 unchanged.

Require PRIMARY_R never used as implementation cwd or source root.

Do not remove IMPL_R or EVIDENCE.

## 14. Mandatory stops

Stop on:

- opening provenance mismatch;
- audit evidence mutation;
- need for a third repository repair path;
- need to change docs, registry, layouts, or fixtures;
- manifest parser still performs unbounded whole-input allocation;
- seal files remain outside the enforced read ceiling;
- malformed decimal suffix does not map to `MANIFEST_CANONICAL`;
- malformed spec path reaches target filesystem access;
- malformed spec path maps to `IO_OR_RACE`;
- prior EV-01 through EV-07 regress;
- tests differ by umask;
- real A6D or amendment child fails;
- target or package mutation;
- unstable final provenance.

## 15. Verdicts

Opening mismatch:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_BASELINE_MISMATCH

Scope expansion:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_SCOPE_EXPANSION_REQUIRED

Repair or validation failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_BLOCKED

Final provenance failure:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_PROVENANCE_BLOCKED

Complete success:

EVIDENCE_VERIFICATION_V1_AUDIT_REPAIR2_IMPLEMENTED_READY_FOR_FRESH_REAUDIT

## 16. Required final report

Include:

1. Opening repository and provenance identity.
2. Exact second-audit finding ledger consumed.
3. Exact two-file repair scope.
4. Per-finding vulnerable mechanism.
5. Per-finding implementation correction.
6. Bounded manifest-reader algorithm and derived limits.
7. Seal-file scan accounting.
8. Decimal lexical versus numeric classification.
9. Spec-path prevalidation and zero-filesystem-call proof.
10. Complete discovered test set.
11. Results under umask `077` and `022`.
12. Vulnerable and repaired causal outcomes.
13. Real A6D and amendment checks.
14. Synthetic A6 pre-seal and sealed checks.
15. No-write and deterministic-output results.
16. Final verifier SHA-256.
17. Registry and layout hashes, confirming unchanged bytes.
18. Final exact 13-path manifest.
19. Final provenance recipe identity.
20. New tracked binary-diff SHA-256.
21. New canonical patch-manifest SHA-256.
22. Artifact hygiene and cleanup.
23. Authority/security widening:
    explicitly none, or exact contrary finding.
24. Remaining uncertainty and uninspected areas.
25. Explicit statements:
    - both prior audits no longer qualify changed bytes;
    - fresh third audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests/live services not invoked.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## Next gate

A successful repair requires a **third fresh audit** with a new audit root. That audit should start with the new canonical manifest and independently reproduce the four residual adversarial cases before reviewing the rest of the patch.

No prior audit can bind changed bytes; every repair requires new validation, provenance, and a fresh independent audit.  Provenance must again be reproduced before correctness inspection. 

### Sources

- Codex’s second independent-audit `BLOCK` report supplied in this turn.
- External-verifier architecture decision and non-recursive bootstrap.  
- Frozen verifier limits, manifest grammar, and error taxonomy. 
- Proof scaffolding remains non-authoritative. 
- Repair and fresh re-audit protocol. 
- Exact audit provenance sequence. 

**Confidence**

- Second-audit provenance and BLOCK verdict: **0.997**
- Architecture remains sound: **0.995**
- Repairability within `verify_v1.py` and `test_verify_v1.py`: **0.96**
- Confidence that no registry/layout/doc change is required: **0.94**
- Correct next gate after repair: fresh third audit, **0.999**
