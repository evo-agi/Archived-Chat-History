## Assessment

This is a **credible implementation-gate pass**. I would authorize the integrated source snapshot next—not a commit gate and not another reconnaissance cycle.

The report closes the exact Repair 10H failure that mattered:

- Final and fresh now have the same logical suite fingerprint.
- Both controls are independently qualified.
- Lifecycle, diagnostics, and canonical semantics are equal.
- `AcceptedEqual=true`.
- `UnknownDifferenceCount=0`.
- The comparison exits `0`.
- Raw bytes are allowed to differ because the typed canonicalization contract now accounts for control-local nondeterminism.

That is precisely the frozen restoration criterion. The reconnaissance required final↔fresh to be `qualified-equal`, accepted, unknown-free, and exit zero; expected-difference exit `2` was reserved for the deliberate mutant and the historical baselines. 

The other important gates also appear satisfied:

- The eight-file repository scope and seven-file successor scope match the freeze. Product production source and public schemas remained unchanged. 
- The two privacy tests were changed structurally rather than merely receiving new sentinel values.
- The complete eight-rule diagnostic taxonomy was implemented, with malformed or partial matches remaining blocking.
- The deliberate mutant was frozen before execution and qualified as a distinct source.
- HEAD→final and Repair 9→final report no undeclared final-only regressions.
- Two independent exact-candidate preparations reproduced the same C/T/D/E.
- Phase H was sealed with the manifest as its final mutation and then fully reverified.

No open architectural or operating-model decision remains. The next uncertainty is **independent verification of the claimed bytes and evidence**, which belongs to a fresh audit after source transport. The project operating protocol requires implementation and independent audit to remain separate, with the latter in a fresh read-only conversation. 

### What the later audit must scrutinize

The snapshot handoff should make these points especially easy to audit:

1. The structural privacy assertions must be demonstrably independent of the production serializer rather than mirroring its implementation.
2. Every canonicalization rule must be exact, typed, full-match, and fail-closed; no generic decimal, path, UUID, hexadecimal, timestamp, or panic scrubbing may have entered indirectly.
3. The external qualification recomputation must genuinely derive qualification from bound raw records rather than restating retained captions.
4. The deliberate mutant comparison must contain exactly the declared delta, not merely “some expected difference.”
5. The product A/B evidence must bind the final tree `002800…`, not inherit Phase G’s earlier source identity.
6. The broad suite’s actual non-green/common-failure status must be reported verbatim in the handoff; the current summary does not provide its exact final counts.

None of those is a reason to reopen implementation now. They are audit targets.

## Codex prompt — integrated snapshot

```text
Objective

Create and independently verify the integrated source-only snapshot and fresh-audit handoff for the exact sealed Repair 10H implementation.

This is a transport/capture turn only. Do not implement, repair, format, test, build, prepare product artifacts, mutate Phase H, stage, commit, push, install, invoke a live route, contact a remote host, or perform an independent audit.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Posture

Parent-only. Create no subagents.

Repository source and Git administration are read-only. You may create only:

1. the requested integrated source ZIP;
2. the requested audit handoff;
3. one new source-external capture-evidence child;
4. private capture scratch beneath one exclusive mode-0700 root.

Do not modify any existing evidence bundle, predecessor artifact, repository path, Git index, object, ref, configuration, worktree administration, ignored state, or shared provenance file.

Authority and classification

- T1 remains a Current invariant.
- Repair 10H/T2A-P remains an unaccepted Bounded slice rule.
- Legacy operator behavior remains a Temporary compatibility edge.
- T2A-I and T2B remain absent future work.
- No Reopened redesign seam is exercised.
- Phase G is immutable historical nonqualifying evidence.
- Phase H is immutable implementation/validation evidence, not authority.
- The ZIP and handoff are supplementary transport/evidence only.
- Exact-byte commit remains unauthorized until a fresh independent audit returns ACCEPT.

Mandatory opening baseline

Require exactly:

Repository:
  /Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Branch:
  codex/remote-alpha-external-tls-status-observation-v1

HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c

Parent:
  05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338

Upstream:
  absent

Index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

Final Repair 10H source tree T:
  00280085500a40dc4a931b416fc00f0f1c9bf1e9

Final source inventory SHA-256:
  ede21d8fe52e22ed12b37bca9c4ed97f89ae0a99a0198d77160fcbe16e4545ec

Membership:
  389 total
  375 tracked
  14 nonignored untracked

Staged/deleted/renamed/unmerged:
  0/0/0/0

Exact Repair 10H changed subset relative to Repair 10G:

1. PLANS.md
2. .docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
3. .docs/system_overview/boundaries.md
4. .docs/system_overview/capability_probing.md
5. .docs/system_overview/artifact_hygiene.md
6. .docs/system_overview/configuration.md
7. docs_contract_test.go
8. es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

Require every other source tuple to remain byte- and mode-identical to the opening Repair 10G candidate.

Sealed Phase H

Path:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Require:

Manifest SHA-256:
  fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Manifest size:
  1,223,514 bytes

Manifested members:
  6,191

Total files including manifest and detached digest:
  6,193

Directories including root:
  1,102

Detached-digest-file SHA-256:
  238f72b2f71983f632d20c99de5848b83dd377735eeac3c09fcddb2e1bc6486c

Before capture:

1. Verify the complete Phase H manifest path set, file types, modes, sizes, hashes, link counts, unique-inode policy, directory modes, manifest/detached-digest relationship, and absence of symlinks or special files.
2. Verify the manifest is still Phase H’s final mutation.
3. Verify there is no active Phase H writer or open mutation process.
4. Reverify the repository source tree, inventory, membership, index, branch, HEAD, parent, upstream absence, and zero staged/deleted/renamed/unmerged posture.
5. Verify no Git operation marker, index lock, apparent repository writer, fixed runtime slot, PackageFloor, package root, or generation root exists.
6. Stop before creating outputs on any mismatch.

Use verdict:

INTEGRATED_SNAPSHOT_BASELINE_MISMATCH

Public output paths

Require both to be absent before work:

/Users/ds/Downloads/ES-T2AP-repair10-integrated-00280085500a.zip

/Users/ds/Downloads/ES-T2AP-repair10-integrated-00280085500a-audit-handoff.md

Do not overwrite, rename over, truncate, or reuse an existing target.

Create one new, exclusive capture child beneath:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/

Use a unique name beginning:

snapshot-00280085500a-

Require the selected child to be absent before exclusive creation. Report its exact final path.

Source enumeration

Derive the governed source set only from the exact equivalents of:

git ls-files -z
git ls-files --others --exclude-standard -z

Use optional-lock-free, nonmutating reads. Do not enumerate ignored/private state.

Expected:

- 375 tracked paths;
- 14 nonignored-untracked paths;
- 389 total regular files.

The tracked `.out/Dockerfile` may be included because it is governed source. Do not traverse any other `.out` descendant.

For every source member:

- reject absolute paths, traversal, duplicates, case/Unicode-normalization collisions, Gitlinks, symlinks, hardlinks, unsupported object types, missing paths, and multi-link regular files;
- open no-follow;
- bracket identity before, during, and after reading;
- record repo-relative raw path, logical Git mode, size, and SHA-256;
- require one regular-file inode per source member;
- copy individually into exclusive destinations with no source/copy inode alias;
- preserve logical 0644/0755 Git-mode semantics;
- derive directories only from admitted paths;
- use no broad worktree copy.

Do not invoke a Git operation capable of writing or freshening real Git objects, refs, the real index, or worktree administration. Use private indices/object stores or in-process Git-object hashing for tree reconstruction.

ZIP requirements

Create a deterministic source-only ZIP with:

- exact filename specified above;
- sole top-level prefix:
  Execution Substrate - external-tls-status-observation-v1/
- exactly 389 regular-file members;
- no explicit directory members;
- no symlinks or special files;
- logical source modes retained;
- deterministic unsigned-byte lexical member order;
- fixed DOS-compatible timestamp;
- no archive comment;
- no member comment;
- no extra fields;
- no encryption;
- no data descriptors;
- no duplicate normalized paths;
- no .git;
- no __MACOSX, AppleDouble, resource fork, Finder metadata, capture-root path,
  manifest, report, inventory, evidence, cache, binary, credential, runtime,
  database, socket, FIFO, or generated sidecar member.

Create and fully verify a private temporary archive first.

Verify:

- Python CRC/integrity;
- /usr/bin/unzip -tqq;
- raw header policy;
- member count and prefix;
- extracted path/type/mode/size/SHA inventory;
- no hardlink representation or extraction inode alias;
- pure reconstructed tree equals:
  00280085500a40dc4a931b416fc00f0f1c9bf1e9
- extracted inventory equals the live source inventory exactly.

Publish only by same-filesystem atomic no-clobber rename with no-follow semantics. Reverify the published archive independently after publication.

The public ZIP must be a regular single-link mode-0600 file. A host-managed container xattr outside the ZIP byte stream may be reported but must not be treated as transported source.

Audit handoff

Create the handoff at the exact requested path, mode 0600, regular, single-link.

It must bind, at minimum:

Repository/source:

- repository path;
- branch, HEAD, parent, HEAD tree, subject, and absent upstream;
- index identity;
- final source T and inventory;
- membership and cumulative status;
- exact eight-file Repair 10H subset;
- explicit statement that all product production source and public schema bytes are unchanged.

Phase H:

- exact Phase H path;
- manifest and detached-digest identities;
- complete member/directory counts;
- successor source T and inventory;
- runner, comparator, semantic-extractor, and fixture binary identities;
- the complete Repair 10H private schema set;
- logical suite fingerprints and complete spec hashes for final, fresh, mutant, HEAD, and Repair 9;
- all five comparison outcomes, exits, AcceptedEqual, UnknownDifferenceCount,
  LogicalSuiteFingerprintEqual, and exact reason codes;
- exact deliberate-mutant provenance and sole changed path;
- product A/B C/T/D/E identities;
- command index identity;
- failed/superseded index identity;
- closeout adjudication identity;
- implementation report identity;
- evidence-manifest identity and post-seal verification.

Validation disclosure:

- exact privacy-test structural contract and count-three result;
- exact eight-rule typed-canonicalization taxonomy;
- logical_bytes 134217727/134217728 boundary result;
- independent qualification recomputation claim;
- successor A/B rebuild and self-test results;
- literal full-suite command and its exact final pass/fail/skip/package counts;
- exact common/inherited failure classification—common failures remain failures;
- exact no-final-only-regression conclusions for HEAD→final and Repair 9→final;
- two independent exact-candidate preparation results;
- Darwin build results and unexecuted Linux cross-build qualification;
- all disclosed failed and superseded attempts.

Nonclaims:

- snapshot and handoff are transport/evidence only;
- no independent audit has occurred;
- no audit acceptance exists;
- no staging, commit, push, PR, installation, live-route invocation, remote
  contact, T2A-I, T2B, binding, witness, deployment, or TLS-recovery effect
  occurred;
- production correctness is not established by provenance or validation alone.

The handoff must instruct the later auditor to independently inspect:

1. structural privacy-test independence from production serialization;
2. each typed canonicalization rule and its causal mutants;
3. complete qualification lineage and recomputation;
4. exact deliberate-mutant delta;
5. final/fresh accepted equality;
6. directional baseline-regression analysis;
7. product A/B C/T/D/E evidence;
8. evidence sealing and failed-attempt retention.

Capture evidence

Retain in the new capture child:

- opening source and repository identity;
- full Phase H verification;
- source enumeration and inventory;
- copy/extraction inventories;
- private and published ZIP records;
- pure-tree reconstruction records;
- archive raw-header and integrity records;
- handoff source and final identity;
- source/copy/extraction inode-isolation records;
- opening/closing Git/source/admin comparisons;
- command intents, argv, cwd, environment, limits, stdout/stderr, exits, and
  terminal records for capture-owned commands;
- failed and superseded capture attempts;
- cleanup and quiescence records;
- final capture report;
- literal assertion mapping;
- capture provenance recipe/source inventory.

Use only regular single-link mode-0600 files and mode-0700 directories, with no hardlinks or symlinks.

Precompute the capture manifest digest and install its detached digest before installing evidence-manifest-v1.txt as the capture child’s final mutation. Write nothing beneath the child afterward.

Perform complete post-seal read-only verification.

Opening/closing no-mutation gate

Compare opening and closing:

- source inventory and T;
- branch, HEAD, parent, HEAD tree, upstream absence, and status;
- real index bytes and mutation-sensitive metadata;
- persistent config;
- packed refs;
- candidate-authoritative ref;
- nonvolatile refs;
- linked-worktree administration;
- common-object hard identity;
- .out root metadata and tracked Dockerfile only;
- fixed runtime slots, PackageFloor, package root, and generation-root absence;
- Phase H complete seal.

Treat only explicitly identified host-managed volatile metadata as report-only. Do not silently exclude generic refs, objects, packs, configuration, index, or administration.

If project-managed refs/codex/turn-diffs activity occurs, enumerate and adjudicate it narrowly. Stop on any unclassifiable source, index, candidate-authoritative ref, nonvolatile-ref, configuration, or hard-object change.

Cleanup

Use one exclusive physical mode-0700 scratch root.

Keep every capture-owned temporary path and command stream beneath that root.

Before deletion:

- prove no attributed process survives;
- prove no open descriptor, cwd, text, mmap, socket, FIFO, or listener remains;
- use a bounded, retained quiescence check;
- do not place cleanup streams outside the scratch root.

Remove only the exact identity-bound scratch. If read-only cache permissions block removal, revalidate the exact owned root before owner-write normalization confined to that root.

Prove scratch absence afterward.

Stop conditions

Stop without accepting the transport if:

- baseline or Phase H identity drifts;
- an output target already exists;
- source membership or an expected tuple differs;
- an ignored/private path must be traversed;
- an unsupported object, symlink, hardlink, duplicate, alias, or unsafe archive
  member appears;
- any reconstruction does not equal final T;
- live, copied, extracted, or archive inventory differs;
- capture requires a repository/Git/evidence mutation;
- Phase H changes or gains a writer;
- ZIP or handoff publication cannot be atomic/no-clobber;
- an opening/closing no-mutation gate fails;
- a capture-owned resource survives;
- the capture manifest cannot be the child’s final mutation.

Final disposition

Return:

INTEGRATED_SNAPSHOT_CREATED_AND_VERIFIED_READY_FOR_FRESH_AUDIT

only if every gate passes.

Otherwise return a precise blocking verdict and retain any failed attempt as
nonqualifying evidence without overwriting it.

Final report must include:

- complete repository and Phase H opening identities;
- exact source membership, inventory, T, and eight-file delta;
- ZIP mode, size, SHA-256, member count, prefix, and integrity results;
- handoff mode, size, and SHA-256;
- capture-child path and sealed-manifest identity;
- all tree/inventory reconstructions;
- source/copy/extraction inode-isolation results;
- opening/closing no-mutation evidence;
- cleanup/quiescence result;
- exact procedural deviations, retries, failed attempts, limitations, and
  nonclaims.

End with:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
```

The provenance guidance treats snapshots as transport for broad independent inspection, while patch/evidence identities bind later work to exact bytes; neither mechanism proves correctness.  The fresh audit must reproduce provenance before correctness inspection and stop before source review on any mismatch. 

**Sources:** Codex’s pasted Phase H implementation report; the frozen Repair 10H reconnaissance and comparison matrix.   

**Confidence:** 0.97 that Repair 10H has reached the integrated-snapshot gate; 0.91 that the implementation satisfies the frozen design pending independent inspection; 0.99 that commit remains premature until a fresh audit returns `ACCEPT`.
