## Assessment

This is another **audit-harness failure before the audit began**, not a successor-package finding.

The parent source never compiled because of a Python syntax error at line 1860: a conditional expression lacked its required `else` branch. Consequently:

- no fresh audit root was allocated;
- no supplied root was opened;
- no package byte was inspected or mutated;
- no A/C/H/I/J conclusion was reached;
- no new implementation or findings-reconciliation work is authorized.

The correct next step is still the same decisive independent audit. The only change needed is a **mandatory pre-epoch source compilation gate**: Codex must construct and compile the entire one-shot parent program before emitting `AUDIT_EPOCH_START` or inspecting any supplied input. The exact precompiled bytes must then be frozen and used without modification for the audit.

This avoids another giant harness tranche while ensuring syntax errors cannot invalidate another attempted audit.

## Prompt for Codex

```text
FRESH AUDIT RETRY WITH MANDATORY PRE-EPOCH PARENT-SOURCE COMPILE GATE

Perform the immediately preceding complete:

FRESH FINITE PARENT-OWNED INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 FULL-AUDIT BOOTSTRAP A/C/H/I REPAIR SUCCESSOR

The exact audit target, supplied roots, identities, A/C/H/I/J scope, corrected
audit-harness execution contract, materialization commands, parser grammars,
causal matrices, cleanup rules, verdict rules, inline report requirements, and
confirmation registry remain unchanged.

This addendum changes only how the one-shot parent source is prepared and
launched.

Do not create another bootstrap package, wrapper package, supervisor package,
importer package, findings-reconciliation capsule, or successor-package
implementation.

Do not modify the successor package.

──────────────────────────────────────────────────────────────────────────────
1. CLASSIFY THE PREVIOUS ATTEMPT
──────────────────────────────────────────────────────────────────────────────

The previous attempted audit failed before source execution because the frozen
parent source did not compile:

- syntax error location:
  line 1860;
- mechanism:
  conditional expression missing its required `else` branch;
- fresh audit root:
  none allocated;
- supplied roots opened:
  none;
- package findings reached:
  none.

Treat that attempt as nonqualifying audit-harness evidence only.

It grants no package repair authority.

──────────────────────────────────────────────────────────────────────────────
2. PRE-EPOCH ADMINISTRATIVE BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Before emitting `AUDIT_EPOCH_START`, perform only these administrative actions:

1. Allocate one fresh private audit root beneath `/Users/ds/Downloads` using
   `tempfile.mkdtemp`, umask `077`, with prefix:

   ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-

2. Create only the minimum pre-epoch directories required to retain:
   - parent-source attempts;
   - compile results;
   - the final frozen source;
   - the source-preflight attempt index.

3. Construct the complete finite one-shot parent source implementing the
   immediately preceding full audit brief.

4. Do not inspect or stat any supplied root.

5. Do not open the successor, predecessor, blocking audit, launcher,
   reconciliation, candidate, Strategic B, or target roots.

6. Do not run any package test or target-facing process.

The pre-epoch boundary is administrative source preparation only.

──────────────────────────────────────────────────────────────────────────────
3. RETAIN EVERY SOURCE-PREFLIGHT ATTEMPT
──────────────────────────────────────────────────────────────────────────────

Retain each attempted parent source separately under:

opening/parent-source-preflight-attempts/

For every attempt record:

- ordinal;
- source path;
- size;
- SHA-256;
- compilation command;
- compiler stdout;
- compiler stderr;
- exit;
- syntax-error type;
- syntax-error line and column;
- disposition;
- superseding attempt, if any;
- supplied roots opened:
  none;
- target content inspected:
  false.

Do not overwrite a failed source attempt.

A failed preflight attempt contributes no final parent-source identity.

──────────────────────────────────────────────────────────────────────────────
4. EXACT COMPILATION GATE
──────────────────────────────────────────────────────────────────────────────

Compile the complete candidate parent source without executing it, using the
pinned Python interpreter:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

with isolation flags:

-I -S -B

Use an in-memory compile operation equivalent to:

python3.13 -I -S -B -c '
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
source = path.read_bytes()
compile(source, str(path), "exec", dont_inherit=True, optimize=0)
' <candidate-parent-source>

Do not use `py_compile` if it would create `__pycache__`.

Require:

- exit 0;
- empty stderr;
- valid complete module compilation;
- no source execution;
- no supplied-root access;
- no child process other than the compiler process;
- no generated bytecode.

Correct the exact line-1860 syntax defect before the final compile gate.

If another syntax error exists, retain that failed source attempt and compile a
new source attempt.

Do not emit `AUDIT_EPOCH_START` until one complete source passes compilation.

──────────────────────────────────────────────────────────────────────────────
5. STATIC NONINTERACTIVE SOURCE GATE
──────────────────────────────────────────────────────────────────────────────

After compilation passes, parse the final source AST without executing it.

Reject the source before the audit epoch if it contains a reachable use of:

- `input`;
- `sys.stdin.read`;
- `sys.stdin.readline`;
- iteration over `sys.stdin`;
- `code.interact`;
- `cmd.Cmd`;
- a command socket;
- an externally driven phase loop;
- a persistent loop whose progression depends on later input.

Also require:

- one finite top-level `main`;
- one bounded terminal execution path;
- one top-level catchable-failure handler;
- no administrative continuation entry point;
- no supplied-root inspection at import time;
- no audit work at module import time;
- no target-facing operation before the opening gate.

Retain:

opening/parent-source-static-preflight.json

with:

- final source identity;
- compilation result;
- AST checks;
- prohibited-call inventory;
- finite-parent result;
- pass/fail;
- first blocker.

──────────────────────────────────────────────────────────────────────────────
6. FREEZE THE FINAL PARENT SOURCE
──────────────────────────────────────────────────────────────────────────────

Once compilation and the static noninteractive gate pass:

1. Copy or rename the exact passing source to:

   provenance/parent-source.py

2. Retain:

   opening/parent-source-freeze.json

   containing:
   - source path;
   - size;
   - SHA-256;
   - compile-result identity;
   - static-preflight identity;
   - failed-attempt count;
   - source frozen:
     true;
   - later source modification allowed:
     false.

3. Reopen `provenance/parent-source.py` and verify its bytes equal the passing
   preflight source exactly.

4. From this point onward, do not edit, regenerate, append to, normalize, or
   replace the frozen parent source.

──────────────────────────────────────────────────────────────────────────────
7. BEGIN THE AUDIT EPOCH ONLY AFTER SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

After the source is frozen and verified, emit exactly:

AUDIT_EPOCH_START

The audit epoch begins at that point.

Pre-epoch source attempts are administrative provenance and are not package
audit results.

Immediately after the epoch begins, the first action of the frozen parent must:

1. Read its own exact retained source bytes.
2. Verify size and SHA-256 against `opening/parent-source-freeze.json`.
3. Compile its own bytes again in memory.
4. Verify:
   - source identity exact;
   - compilation passes;
   - no source drift.
5. Retain:
   `opening/parent-source-runtime-self-check.json`

Do this before supplied-root inspection.

A source mismatch or runtime compile failure requires:

AUDIT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
8. EXECUTE THE COMPLETE PRIOR AUDIT BRIEF UNCHANGED
──────────────────────────────────────────────────────────────────────────────

After the source runtime self-check passes, execute every substantive
requirement of the immediately preceding complete audit brief without omission
or semantic change.

This includes:

- opening fixed identities and manifest closure;
- corrected child filesystem-effect attribution;
- dynamic root-locator parsing;
- exact successor materialization commands;
- corrected package producer and independent-validator commands;
- corrected Finding A reason oracle;
- corrected Finding C reason oracle;
- Finding H publication-state and `RENAME_EXCL` causals;
- Finding I real wrapper execution and 50-case classification;
- Finding J 928-case regression;
- 14-family / 1,052-row field-map parsing;
- qualification-result parsing;
- source-aware security/export analysis;
- two fresh materializations;
- two Carrier 0002 handoffs;
- fresh audit-owned validator;
- exact cleanup-set reconciliation;
- supplied-root closing equality;
- parent-generated analytical perspectives;
- truthful preseal gate;
- terminal success or failure capsule.

Do not narrow any causal set or acceptance rule.

──────────────────────────────────────────────────────────────────────────────
9. ONE-SHOT PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

Use the frozen parent exactly once.

It must be:

- finite;
- noninteractive;
- one-shot;
- stdin-independent;
- parent-owned;
- bounded by explicit child timeouts;
- free of later external phase commands.

Do not launch a replacement parent after epoch start.

Do not patch the source after epoch start.

Do not resume a failed audit root.

Do not use an administrative continuation.

──────────────────────────────────────────────────────────────────────────────
10. COMPILER AND SOURCE ATTEMPT CLEANUP
──────────────────────────────────────────────────────────────────────────────

The final audit capsule must retain:

- every failed preflight source attempt;
- every compile result;
- the preflight attempt index;
- the final frozen source;
- the freeze record;
- the runtime self-check.

Do not delete failed source attempts.

Any temporary compiler-only directory not retained as provenance must:

- be audit-owned;
- be inventoried;
- be removed before preseal;
- receive two fresh ENOENT observations.

No `__pycache__` or `.pyc` may remain.

──────────────────────────────────────────────────────────────────────────────
11. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

After `AUDIT_EPOCH_START`, use the exact four verdicts and rules from the
immediately preceding complete audit brief:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

A pre-epoch compile attempt is not itself a package-audit verdict.

If the final source cannot pass the pre-epoch compile and static gates, do not
inspect any supplied root and return:

PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED

with:

- all source-attempt identities;
- all compiler results;
- exact unresolved syntax/static blocker;
- confirmation that no audit epoch began;
- confirmation that no supplied root was inspected or mutated.

Do not misclassify a pre-epoch syntax error as a successor-package defect.

──────────────────────────────────────────────────────────────────────────────
12. ADDITIONAL REQUIRED REPORTING
──────────────────────────────────────────────────────────────────────────────

In addition to every section required by the immediately preceding complete
audit brief, report:

1. Pre-epoch administrative root identity.
2. Parent-source preflight attempt count.
3. Identity of every failed source attempt.
4. Exact compiler result for every attempt.
5. Final frozen parent-source identity.
6. Static noninteractive source-gate result.
7. Parent-source freeze-record identity.
8. Runtime self-check identity.
9. Confirmation the source did not change after freeze.
10. Confirmation no supplied root was inspected before `AUDIT_EPOCH_START`.
11. Confirmation line 1860 and the complete source compile successfully.
12. Confirmation no `__pycache__` or `.pyc` remains.

Additional required confirmations:

PARENT_SOURCE_PREFLIGHT_COMPLETED
EVERY_FAILED_SOURCE_ATTEMPT_RETAINED
FINAL_PARENT_SOURCE_COMPILED_SUCCESSFULLY
FINAL_PARENT_SOURCE_STATIC_GATE_PASSED
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PARENT_SOURCE_RUNTIME_SELF_CHECK_PASSED
AUDIT_EPOCH_STARTED_ONLY_AFTER_SOURCE_FREEZE
NO_SUPPLIED_ROOT_INSPECTED_BEFORE_AUDIT_EPOCH
LINE_1860_SYNTAX_DEFECT_CORRECTED
COMPLETE_PARENT_SOURCE_SYNTAX_VALID
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_PYC_OR_PYTHON_CACHE_RETAINED

Retain every confirmation from the immediately preceding full audit brief.

Do not begin another package implementation, harness-reconciliation tranche,
or findings-reconciliation tranche unless this fresh audit identifies a new
concrete discrepancy.
```

**Source:** Codex’s latest `AUDIT_PROVENANCE_MISMATCH` report.

**Confidence:** 1.00 that no package conclusion was reached; 0.995 that precompiling and freezing the complete parent source before the audit epoch addresses the exact failure; 0.98 that the successor remains ready for the unchanged substantive audit.
