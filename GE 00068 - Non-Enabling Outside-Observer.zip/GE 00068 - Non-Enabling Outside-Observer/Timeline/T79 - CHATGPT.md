Codex reached the right conclusion. The `/dev/fd/62` problem is **not** another sandbox capability gap:

- FD 62 is chosen dynamically by Bash for process substitution.
- It is shell-local, not runner-owned, inherited by policy, transferred by `SCM_RIGHTS`, or represented in A5P2’s custody ledger.
- A `/dev/fd` grant could not be bound in advance to a stable role, generation, type, or lifetime.
- Opening `/dev/fd/N` duplicates an existing descriptor, introducing close and EOF behavior that the runner cannot govern.
- The full lifecycle divergence is completely explained: 5 A5T fixture improvements, 18 A5P2 improvements, and 107 `/dev/fd` cascade transitions. Codex found no unresolved transition or production regression.

The selected repository-test derivative is therefore the safer correction. It keeps the production wrapper unchanged and removes an incidental process-substitution dependency from the sandboxed test copy.

There is one subtle requirement to retain: `for name in $(compgen -v)` must be proven equivalent for the actual variable-name domain and environment-scrub contract. Bash variable names make word splitting and glob expansion materially safer here than for arbitrary text, but the implementation still needs direct equivalence, malformed/inverse, and source-line-compatibility controls. It must not be accepted merely because the full suite improves.

I recommend folding this one-file harness correction into a fresh **A5T4 implementation-and-validation closure**, rather than adding another narrow seal and then repeating A5T yet again. A5T4 should bind all three repository test-file changes and run the complete downstream gate from new materializations.

## Next Codex prompt

```text
Permission is workspace-write.

Objective

Implement, validate, close out, and seal Repair 10I-A5T4: the complete
repository-test repair comprising:

1. the already implemented compact Unix-socket fixtures in:
   - remote_alpha_operator_test.go
   - es/runtimehelper/supervisor_test.go

2. one bounded test-private derivative correction in:
   - remote_alpha_prepare_external_tls_status_test.go

The new correction removes the sandbox-incompatible Bash process-substitution
form from test-owned derivative copies only:

    while ...; do
        ...
    done < <(compgen -v)

and replaces it with the uniquely matched, line-count-preserving derivative
form frozen by the sealed A5FD reconnaissance:

    for ... in $(compgen -v); do
        ...
    done

The production script must remain byte-identical. Its normal static
grammar/hash checks must remain active. The derivative must preserve the
environment-scrub contract and must not obtain `/dev/fd` authority.

This turn must also rerun the complete A5T validation from fresh private
materializations using the sealed A5P2 successor.

Do not edit A5P2.
Do not modify production scripts.
Do not implement A5C.
Do not restart the A6 policy-evidence refresh.
Do not implement A6 or start B6.
Do not create an integrated snapshot, ZIP, handoff, or capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.
Do not perform or claim an independent audit.

No subagents. You are the sole writer.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5 predecessor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Sealed A5P2 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p2-successor-closure-ab646e5a0e66

Sealed A5FD reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5fd-devfd-recon-ab646e5a0e66

Failed A5T3 child, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t3-test-fixture-closure-ab646e5a0e66

Failed A6 policy-evidence refresh, immutable and unsealed

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

Required new A5T4 child, absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t4-harness-closure-ab646e5a0e66

## 1. Mandatory opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- opening repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- opening repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- inventory size:
  54314
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the existing delta from sealed A5 to remain exactly:

1.
remote_alpha_operator_test.go

- mode:
  100644
- size:
  333580
- SHA-256:
  f294b00d9b4bfd4e10c8ad23ceacc4da5284e53c660018b6d586aa162e784578

2.
es/runtimehelper/supervisor_test.go

- mode:
  100644
- size:
  5293
- SHA-256:
  842365859e223188bfd6e2c4ed9d2f915d566600b1725d78fe4ca3b06b43c226

Every other current source member, including
remote_alpha_prepare_external_tls_status_test.go, must match the opening
inventory.

Require exact sealed A5P2:

- manifest SHA-256:
  67002939082d25a46ec50fdb4a5725e936816ea930e6ed9ac684608238a833a4
- manifest size:
  114860
- payloads:
  613
- directories:
  112
- source T:
  ff7a4688b1244277eccc8eee26b57eb4f0858d01
- source inventory:
  a17d8e3d5925b17d2eda187a51953dcf0d171d81d5e5409ea70827d92a6cda2e

A5P2 binaries:

repair10-runner:
  153013c19a717a37a677c0c5fa4e91837c78ccc16db909a9b1e360ff2efb483d

repair10-compare:
  d09e0e0d510872fb457f1308219f471bcbd147c7fc6d4a19da29a026182055a3

repair10-semantic:
  25893d292a20e0af99e494779802dbd73c1fe1e180f3c9e2873c5ea52e86d325

repair10-fixture:
  d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4

Require exact sealed A5FD reconnaissance:

- manifest SHA-256:
  f4bfa2b8479a8679d4a2af4173f2bc9d76bc6f4085cdda3bb4c60d06c0b9b768
- manifest size:
  4951
- payloads:
  37
- directories:
  6
- payload modes:
  28 mode-0600 and 9 mode-0700

Reverify:

- closeout/final-report-v1.md
- analysis/exact-three-unknown-ledger-v2.json
- analysis/complete-lifecycle-delta-v1.json
- findings/full-suite-historical-outcome-adjudication-v1.json
- source/source-call-graph-and-caller-inventory-v1.json
- probes/probe-matrix-v1.json
- findings/causal-and-validation-matrix-v1.json

Require A5T3 to remain present, unsealed, and byte-exact:

- snapshot:
  5793d7f1…de650
- entries:
  1082
- manifest:
  absent
- detached digest:
  absent

Bind its exact negative result:

- suite exit:
  1
- failures:
  206
- skips:
  8
- exactly three unknown diagnostics;
- all three caused by:
  `done < <(compgen -v)`
  rendering a dynamic `/dev/fd/N`;
- all five repaired socket tests passed;
- 21/21 PTY allocations acknowledged;
- complete cleanup and two zero-observation epochs.

Require the new A5T4 child to be absent.

Stop on any mismatch:

REPAIR10I_A5T4_BASELINE_MISMATCH

## 2. Evidence-child creation

After the opening gate, create A5T4 exclusively under umask 077.

Use exactly:

opening/
source/
commands/
controls/
validation/
findings/
closeout/

All directories mode 0700.

All files regular, single-link, non-symlink, mode 0600 or 0700 as intended.

No hardlinks.

Do not import executable Python modules from predecessor evidence children.

Copy the sealed A5P2 A/B binaries independently into private tool locations
beneath the child.

Require:

- origin-to-copy byte equality;
- A/B equality;
- all copy inodes distinct;
- link count one;
- no shared writable tool state.

## 3. Exact authorized repository scope

Exactly one additional repository file may change in this turn:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/remote_alpha_prepare_external_tls_status_test.go

The final A5T4 repository delta relative to sealed A5 must therefore contain
exactly three existing test files:

1. remote_alpha_operator_test.go
2. es/runtimehelper/supervisor_test.go
3. remote_alpha_prepare_external_tls_status_test.go

No addition, deletion, rename, or mode change.

Do not change:

- scripts/remote_alpha_prepare_external_tls_status.sh
- scripts/remote_alpha_operator.sh
- repository production Go source
- internal/testsupport
- docs
- module files
- public schemas
- A5P2 source or evidence

If a fourth repository file is required, stop:

REPAIR10I_A5T4_SCOPE_EXPANSION_REQUIRED

## 4. Production-wrapper protection

Before editing:

1. Record the exact production-wrapper mode, size, and SHA-256.
2. Record the exact startup environment-scrub block.
3. Run `/bin/bash -n` on the production wrapper.
4. Reproduce all existing static grammar/hash/oracle tests that protect it.
5. Prove the test harness reads the exact production bytes before constructing
   a derivative.

After editing and at closeout, require the production-wrapper tuple to remain
exactly unchanged.

The derivative may not replace, rewrite, or install the production script.

## 5. Exact derivative transformation

Recover the exact uniquely matched derivative-construction site from
remote_alpha_prepare_external_tls_status_test.go.

The source transformation must:

- match one and only one complete startup block;
- fail if zero or multiple matches exist;
- preserve all nonmatched bytes exactly;
- preserve source line count;
- preserve the loop body exactly;
- replace only the redirection/loop form needed to remove Bash process
  substitution;
- remain reversible from the retained transformation record;
- retain before/after size, SHA-256, match offset, and replacement bytes.

The intended semantic replacement is:

- before:
  `while ...; do ...; done < <(compgen -v)`
- after:
  `for ... in $(compgen -v); do ...; done`

Use the exact source block, not this abbreviated textual representation.

Do not introduce:

- a generic production-script rewrite;
- an arbitrary shell regex;
- `/dev/fd` permission;
- temporary world-readable files;
- external commands not already admitted;
- a new public/product behavior.

## 6. Mandatory shell-semantics equivalence

Before accepting the derivative, prove the original and transformed
environment-scrub loops are equivalent for the actual Bash variable-name
domain.

Use private, bounded shell controls.

Require equivalent:

- enumerated variable-name sequence;
- retained versus removed variable sets;
- loop-body execution order;
- exported and unexported scalar variables;
- indexed and associative array names where admitted by the owning script;
- variables with numeric suffixes and underscores;
- empty or minimal user-variable set;
- a large bounded variable set;
- default Bash `IFS`;
- any startup `IFS` posture reachable under the production wrapper;
- shell glob options relevant to command-substitution expansion;
- command and loop terminal status where contractually material.

Explicitly prove why command-substitution word splitting is safe:

- Bash variable names are identifier-shaped;
- no valid name contains whitespace;
- no valid name contains pathname-expansion metacharacters;
- ordering remains the `compgen -v` order;
- parent-shell unsets do not alter the already captured child/subshell list.

If any reachable environment produces a different scrub result, stop:

REPAIR10I_A5T4_HARNESS_SEMANTICS_MISMATCH

Do not weaken the scrub contract merely to avoid `/dev/fd`.

## 7. Vulnerable and repaired causals

### Vulnerable predecessor

In a private no-hardlink opening-source copy using exact A5P2 policy, reproduce
the bounded vulnerable condition:

- original derivative retains process substitution;
- Bash dynamically renders `/dev/fd/N`;
- current A5P2 profile denies the pathname reopen;
- owning tests produce the known EPERM diagnostics;
- no generic descriptor permission exists;
- cleanup completes.

This expected-negative is not qualification evidence.

### Repaired derivative

Using the same source except the exact derivative transformation:

- no `/dev/fd/N` pathname appears in the command or diagnostic stream;
- environment scrub completes;
- affected owning tests proceed beyond startup;
- no new descriptor role or custody record is required;
- A5P2 resource and terminal reconciliation completes.

### Exact inverse mutant

Restore the original process-substitution form in one private mutant.

Require the known EPERM failure to return.

### Transformation mutants

Reject:

- zero matches;
- duplicate matches;
- altered loop body;
- omitted variable;
- reordered scrub clause;
- partial replacement;
- appended shell text;
- changed production-wrapper hash;
- changed line count where it would invalidate active exact-line grammars.

## 8. Source-line compatibility

Before repository validation, compare final A5T4 source against every active
A5P2 exact-line grammar referring to:

- remote_alpha_prepare_external_tls_status_test.go
- remote_alpha_operator_test.go
- es/runtimehelper/supervisor_test.go

Require:

- line-bound recognized diagnostics retain their exact lines; or
- old fixture/process-substitution diagnostics are now unreachable because
  the corrected path succeeds.

No generic line-number normalization.

Stop if A5P2 source compatibility requires an edit:

REPAIR10I_A5T4_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

## 9. Focused affected-identity validation

Recover the exact affected identity set from the sealed A5FD call graph and
causal matrix.

The report states that 25 active callers and 64 affected test/subtest
identities are governed by this derivative path. Use the exact retained set;
do not reconstruct it approximately from a name prefix.

Run all affected identities from fresh private materializations using A5P2.

Require:

- every one of the 64 identities executes;
- no affected identity is absent;
- all formerly `/dev/fd`-cascaded identities recover their expected terminal;
- no unknown diagnostic;
- no `/dev/fd/... Operation not permitted` diagnostic;
- no new failure, skip, abort, malformed stream, or missing terminal;
- producer and peer semantic extraction agree;
- resource and terminal reconciliation pass.

Retain the exact test-selection expression and complete identity set.

## 10. Socket-fixture and PTY regression preservation

Re-run the complete repaired A5T socket and PTY matrix from fresh short private
roots:

- all four repaired remote root tests;
- runtimehelper stable-alias test;
- three disjoint count-three controls;
- targeted race;
- exact 100-byte admission causal;
- exact 101-byte pre-listen rejection causal;
- socket negative and rebind controls;
- no-capability PTY denial;
- explicit-capability PTY success;
- direct `/dev/ptmx` denial;
- unrelated-terminal denial;
- acknowledged handoff;
- parent alias closure before process wait;
- actual EOF/EIO reconciliation;
- two absence epochs.

Require:

- all five repaired tests pass;
- zero required skips;
- all actual paths at most 100 bytes;
- no old socket EINVAL fixture diagnostic;
- A5P2 PTY behavior unchanged;
- no raw terminal payload retained.

## 11. Static and repository gates

Run:

- pinned `gofmt -d` on exactly:
  - remote_alpha_operator_test.go
  - es/runtimehelper/supervisor_test.go
  - remote_alpha_prepare_external_tls_status_test.go
- require empty output;
- `git diff --check`;
- `/bin/bash -n` on the protected production scripts;
- documentation/contract tests whose source-order and production-wrapper hashes
  cover the derivative;
- `go mod verify` from a complete private offline cache;
- `go vet ./...`.

Require all pass.

Do not run a general formatting sweep.

## 12. Broader affected validation

Run, through A5P2 and fresh private controls:

1. Complete `./es/runtimehelper`.
2. Complete `./es/externaltls/...`, with the governed private
   repository/commit/tree environment required by its exact-candidate tests.
3. The complete affected root/operator family containing:
   - all 64 derivative callers;
   - four repaired socket tests;
   - PTY/forkpty and signal tests;
   - Repair 10I setpgid tests;
   - structural isolation guards;
   - wrapper source-order/hash/oracle tests.

Require:

- zero required skip;
- no unknown diagnostic;
- no source-line incompatibility;
- no undeclared PTY request;
- complete custody and cleanup.

## 13. Complete private full-suite control

Create one new complete short private control bound to the final A5T4 source:

- final T:
  compute from exact final bytes
- final inventory:
  compute from exact final bytes
- membership:
  389

Before launch, retain:

- active test inventory;
- exact PTY-capable helper graph;
- finite PTY role/count declaration;
- proof no non-PTY command receives implicit capability;
- path-budget reports;
- production-wrapper and derivative identities.

Run literal:

go test -json -count=1 -p=1 -parallel=1 ./...

through one A5P2 side.

Use the opposite A5P2 side for raw re-extraction and external qualification.

Expected process exit membership:

{0,1}

Exit alone does not qualify.

Require:

- containment enforced;
- complete stdout/stderr through EOF;
- exactly one Wait;
- complete terminal and resource reconciliation;
- no forced cleanup;
- no survivor;
- well-formed complete JSONL;
- zero unknown diagnostics;
- producer and peer canonical semantics byte-equal;
- producer and peer qualification both `qualified`;
- logical and PTY fingerprints bound;
- every declared PTY request consumed exactly;
- no undeclared PTY request;
- direct `/dev/ptmx` remains denied;
- arbitrary `/dev/fd/*` remains denied;
- no affected test needs `/dev/fd`;
- unrelated terminals remain inaccessible;
- parent PTY aliases close before process wait;
- real helper EOF/EIO evidence reconciles;
- every prospective and actual socket path at most 100 bytes;
- two cleanup epochs;
- verified-empty next-command barrier.

Require the five repaired socket tests to pass.

Require the seven previously governed A5 outcomes to remain correct:

- TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7/
  one_pipe_closes_first
- TestRepair10IDualSetpgidRaceReconciliationV1
- TestRepair10ISetpgidFailureRequiresExactGroupProofV1
- TestRepair10ISetpgidInverseMutantsV1
- TestRepair10IStructuralPrivacyProjectionCausalControlsV1
- TestRemoteAlphaExternalTLST2APRepair10Contract
- TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2

Require all 64 derivative-affected identities to have their expected terminal
outcomes.

Require absence of:

- the five old socket EINVAL diagnostics;
- all `/dev/fd/N: Operation not permitted` diagnostics;
- any new unknown diagnostic.

Inherited unrelated failures and skips remain explicit.

Do not claim a green suite unless it is actually green.

## 14. Exact historical-outcome reconciliation

Compare the final A5T4 full-suite semantics independently against both retained
qualified A5 controls.

Require the previously classified A5T3 cascade to be repaired exactly:

- all 69 prior pass→fail transitions are restored;
- all 38 prior pass→absent transitions are restored;
- no new pass→fail;
- no new pass→skip;
- no new pass→absent;
- no new final-only failure or skip;
- no new package failure or abort;
- no new panic, race, warning, fatal-runtime, malformed, truncated, missing,
  duplicate, or unknown state.

Preserve the source-grounded improvements:

- 5 A5T socket-fixture improvements;
- 18 A5P2/private-PTY improvements.

Require:

- 137 inherited fail→fail identities;
- 23 fail→pass improvements;
- all 2,730 historical pass identities present and passing;
- 8 skip→skip identities;
- package transitions remain:
  - 11 fail→fail
  - 14 pass→pass
  - 23 skip→skip
- zero final-only identity;
- zero lost identity.

If the terminal universe remains unchanged, the expected test totals are:

- pass:
  2,753
- fail:
  137
- skip:
  8

Do not accept aggregate counts without exact identity-array equality.

Retain canonical arrays, sizes, and hashes for every transition class.

A remaining unexplained transition blocks sealing.

## 15. Security and authority controls

Require:

- no generic `/dev/fd` grant;
- no broad `/dev` grant;
- no production-wrapper mutation;
- no production API/schema/authority change;
- no live PackageFloor or fixed runtime slot access;
- no `.out` traversal or write;
- no credential, keychain, TLS, SPIFFE, Vault, private endpoint, or unrelated
  user-data exposure;
- no repository-local generated evidence;
- no raw PTY payload retained;
- test-private derivative clearly classified as proof/validation scaffolding,
  not product behavior.

## 16. Evidence retention

Retain:

- complete opening identities and lineage;
- exact A5FD reconnaissance binding;
- vulnerable process-substitution causal;
- derivative transformation recipe and reversibility proof;
- original/derivative shell-equivalence evidence;
- inverse and transformation mutants;
- exact three-file repository delta;
- source-line compatibility;
- all 64 affected identities and results;
- socket/PTTY regressions;
- static/module/vet gates;
- broader package/family validation;
- complete full-suite streams through EOF;
- producer and peer semantics/qualification;
- transition arrays and historical reconciliation;
- failed and superseded attempts;
- closing source/admin identities;
- cleanup and two absence epochs;
- implementation report;
- exact path/mode/size/hash inventory.

Do not retain raw terminal payload or sensitive environment contents.

## 17. Closeout and sealing

Require the final repository delta from sealed A5 to be exactly:

1. remote_alpha_operator_test.go
2. es/runtimehelper/supervisor_test.go
3. remote_alpha_prepare_external_tls_status_test.go

Require:

- zero additions;
- zero deletions;
- zero renames;
- zero mode changes;
- all other 386 source tuples byte- and mode-identical to sealed A5;
- production wrapper unchanged;
- branch/HEAD/parent/HEAD tree/upstream/index unchanged;
- staged/deleted/renamed/unmerged remain zero;
- A5, A5S, A5P reconnaissance, failed A5P, A5P2, failed A5T, A5T2, A5T3,
  failed A6, A5FD reconnaissance, and all earlier lineage unchanged;
- no predecessor cache or bytecode;
- no private source, Git store, cache, runtime, PTY, process/group, worker,
  broker socket, listener, descriptor, build, or report root;
- two fresh zero-observation epochs.

Install the detached digest before the manifest.

Install `evidence-manifest-v1.txt` as the final mutation.

Write nothing afterward.

Perform complete read-only post-seal verification.

## 18. Mandatory stop conditions

Stop on:

- baseline or lineage mismatch;
- need for a second new repository file;
- production-wrapper byte change;
- A5P2 change;
- derivative transformation is not unique or reversible;
- shell-equivalence mismatch;
- active source-line grammar incompatibility;
- any of the 64 identities missing or unexpectedly changed;
- any `/dev/fd` EPERM remains;
- a repaired socket test fails;
- actual socket path exceeds 100 bytes;
- PTY role/count mismatch;
- direct PTY allocation succeeds;
- unrelated terminal becomes accessible;
- unknown diagnostic;
- lifecycle transition not fully explained;
- any of the 69 failures or 38 lost identities remains;
- required skip, race, malformed stream, incomplete terminal/resource
  reconciliation, survivor, or forced cleanup;
- external qualification failure;
- cleanup or seal failure.

## 19. Verdicts

Opening mismatch:

REPAIR10I_A5T4_BASELINE_MISMATCH

Scope expansion required:

REPAIR10I_A5T4_SCOPE_EXPANSION_REQUIRED

Derivative semantics mismatch:

REPAIR10I_A5T4_HARNESS_SEMANTICS_MISMATCH

Successor compatibility expansion required:

REPAIR10I_A5T4_SUCCESSOR_COMPATIBILITY_EXPANSION_REQUIRED

Implementation or validation failure:

REPAIR10I_A5T4_SOURCE_OR_TEST_REPAIR_REQUIRED

Complete implementation, validation, and seal:

REPAIR10I_A5T_SOCKET_AND_DEVFD_HARNESS_REPAIR_SEALED_READY_FOR_A5C

The success report must include:

1. Opening and final repository T/inventory.
2. Exact three-file delta.
3. Production-wrapper unchanged identity.
4. Exact derivative transformation and reversibility identity.
5. Shell-equivalence causal results.
6. Vulnerable, repaired, and inverse-mutant outcomes.
7. A5P2 identities and input hard gate.
8. All 64 affected-identity results.
9. Socket and PTY regression results.
10. Static/module/vet results.
11. Full-suite raw and semantic identities.
12. Producer and peer qualification.
13. Exact transition matrices versus both A5 controls.
14. Confirmation that 69 pass→fail and 38 pass→absent transitions were
    restored.
15. Preserved 5 A5T and 18 A5P2 improvements.
16. Remaining inherited failures and skips.
17. Confirmation of zero unknowns and no `/dev/fd` EPERM.
18. Manifest SHA-256, size, and payload count.
19. Cleanup and two absence epochs.
20. Explicit statement that A5C was not started and A6 was not restarted.

No A5C.
No A6.
No B6.
No product A/B.
No snapshot.
No integrated ZIP.
No handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

## After A5T4

Once A5T4 seals, the next tranche remains the already identified **A5C observability-duration amendment**. That change must affect only the successor’s typed canonicalization rule: duration tokens become diagnostic-position-based while trace/request identifiers retain correlation topology. Only after A5C seals should the two-control A6 policy-evidence refresh restart.

This repair remains proof/test scaffolding. The MVP claim freeze explicitly says proof-harness behavior must not become architecture or product authority by inertia.  The project also requires implementation and independent audit to remain separate; any changed bytes need new validation, provenance, and later a fresh audit.   Provenance will establish the exact A5T4 bytes, but not that the shell transformation or test coverage is correct. 

### Sources

- Codex’s sealed `REPAIR10I_A5FD_HARNESS_REPAIR_REQUIRED` reconnaissance supplied in the current turn.
- Milestone 0 MVP claim freeze. 
- Governed Execution implementation/audit and repair protocol.  
- Governed Execution provenance guidance. 

**Confidence:** 0.995 that a successor `/dev/fd` capability would be the wrong repair; 0.98 that the exact test-private derivative is the right bounded correction; 0.92 that the `for … in $(compgen -v)` form can be proven equivalent for the actual Bash variable-name domain; 0.97 that the complete lifecycle divergence will collapse to the intended A5T/A5P2 improvements after the repair; 0.995 that A5C and A6 must remain separate later gates.
