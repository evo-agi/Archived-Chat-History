## Assessment

This audit’s **BLOCK** is valid, but it does **not** justify another edit to the 13-path repository patch.

The audit independently reproduced the exact `ed268…` patch, reran all 88 tests under both umasks, exercised launch protocol v2, independently built a caller, closed the original SEC-02 script-load race, and reproduced A6D, amendment, and synthetic compatibility. It found no defect in `verify_v1.py`.

The remaining problem is narrower:

> The source-external caller hashes one Python executable object, then asks the operating system to execute whatever object is later found at that pathname.

That is a gap in the **acceptance-bearing validation launcher**, not in the repository verifier. The correct next action is therefore:

1. **Do not alter the repository.**
2. **Keep the same `ed268…` canonical manifest as the audit target.**
3. Repair only the source-external caller evidence so it executes the already-opened, hashed interpreter object rather than reopening its pathname.
4. Rerun the acceptance-bearing validation.
5. Start another fresh independent audit.

This also needs a deliberate root-of-trust boundary. The already-running producer or audit parent process, the kernel, and its command-execution substrate are trusted. The task is to bind the **child interpreter object**. Attempting to attest the runtime that launches the caller, then the runtime that launched that runtime, would create an endless bootstrap recursion.

### Preferred bounded mechanism

Use **file-descriptor-based `execve`** if the pinned Python/macOS combination behaviorally supports it:

- no-follow open the interpreter;
- hash and identify that open file descriptor;
- fork a minimal child;
- attach stdout/stderr pipes;
- call `os.execve(interpreter_fd, argv, environment)` in the child;
- retain the parent’s interpreter fd through child wait/reap;
- recheck its identity at closeout;
- never fall back to pathname execution.

Python 3.13 documents that `os.execve()` can accept an open file descriptor on supported platforms, that support must be checked through `os.supports_fd`, and that unsupported use raises `NotImplementedError`. This must be probed on the actual pinned host rather than assumed. 

If fd execution is unavailable, stop. Do **not** silently use `/dev/fd`, `ctypes`, a compiled launcher, or a “stable enough” pathname. Those are separate design decisions.

The patch should remain evidence tooling, not product or runtime authority. Generated proof artifacts remain non-authoritative.  Provenance can establish that everyone examined the same repository bytes, but not that the implementation is correct or that a launcher has authority. 

## Codex prompt: FD-bound interpreter-custody repair

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete report inline in Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a local report;
- “full report available at …”;
- or an attachment reference.

A source-external report file may be linked as supplemental evidence, but every
required report section must also appear in the response body.

This applies to all outcomes, including:

- capability unavailable;
- baseline mismatch;
- evidence-repair block;
- validation block;
- provenance block;
- ready for fresh audit.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh Codex conversation.

Do not resume the audit conversation that returned BLOCK for VC-01 / SEC-A1.
Do not resume the producer implementation conversation.

Objective

Repair the source-external validation caller’s interpreter-custody gap without
changing any repository byte.

The current 13-path repository patch is the fixed audit target. The prior audit
found no repository verifier defect. It found that both producer and auditor
callers:

1. no-follow opened and hashed the pinned Python executable;
2. closed or retained that descriptor only as evidence;
3. later passed the executable pathname to `subprocess.run`;
4. therefore did not prove that the child loaded the same object that was
   hashed if the pathname changed between preflight and exec.

The selected bounded repair is:

FD-BOUND CHILD INTERPRETER EXECUTION

Probe whether the pinned Python 3.13.4 host supports passing an open executable
file descriptor to `os.execve`.

If supported, implement a new source-external validation caller that executes
the exact opened and hashed interpreter object by fd.

If unsupported, stop. Do not introduce an automatic fallback.

No repository mutation is authorized.

Writes are authorized only beneath the new evidence root stated below.

No documentation edit.
No formatting.
No staging, commit, push, PR, merge, installation, deployment, A6 restart,
product execution, product A/B, live-service invocation, network contact, or
Linux binary execution.

No subagents.

## 1. Trust-root decision

Freeze this boundary before any probe:

Trusted for this bounded evidence activity:

- the already-running foreground Codex parent process;
- the host kernel and process-execution substrate;
- the exact source-external caller source retained by this activity;
- the exact external provenance inputs supplied below.

In scope for custody proof:

- the child Python interpreter object used for each acceptance-bearing verifier
  launch;
- verifier source bytes;
- package, registry, layout, target, and candidate objects;
- child exit and streams.

Out of scope:

- recursively attesting the interpreter or runtime that launched the already-
  running Codex parent;
- privileged kernel compromise;
- debugger or process-memory compromise;
- a compromised operating system;
- cryptographic collision.

Do not reopen this root-of-trust boundary during implementation.

## 2. Exact repository target

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Exact canonical patch manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/provenance/qualified/provenance/manifest-run-1.json

Expected manifest SHA-256:

ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98

Expected tracked binary-diff SHA-256:

6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7

Expected verifier:

- size: 40121
- SHA-256:
  bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected tests:

- size: 70730
- SHA-256:
  7e2dcf579c5e4bf3fd72762662e3a66f96668af1470be00a665e893a9efa15a1

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Pinned interpreter pathname:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- version: Python 3.13.4
- regular single-link object at opening;
- size: 119424
- SHA-256:
  f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b

Current producer launch capsule, read-only predecessor evidence:

OLD_CALLER=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/commands/launch_v2.py

Expected old caller SHA-256:

856cc81650330deb776cbf9bff74644176405acf3163839547acfce3d73ba1e2

Blocking independent audit, read-only:

BLOCKING_AUDIT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-ed26813371b3-v1

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Required new source-external evidence root:

FD_EXEC_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-fdexec-caller-ed26813371b3

Require FD_EXEC_ROOT absent before creation.

Forbidden primary checkout for Git or repository-relative reads:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 3. Process and Git boundary

Every Git command must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - GIT_OPTIONAL_LOCKS=0;
  - GIT_CONFIG_NOSYSTEM=1;
  - LC_ALL=C;
  - LANG=C;
  - PYTHONDONTWRITEBYTECODE=1;
- be recorded with argv, cwd, environment, exit, stdout SHA-256, and stderr
  SHA-256.

No Git command may run in PRIMARY_R, A6D, A6D_AMEND, an evidence root, an
audit root, or FD_EXEC_ROOT.

Non-Git absolute-path reads before the first Git command are permitted.

No repository-relative operand may resolve through PRIMARY_R.

A nonconforming Git command is an immediate process-boundary block.

## 4. Repository opening gate

Require IMPL_R:

- exact physical root;
- expected branch, HEAD, tree, sole parent, and absent upstream;
- exactly 13 changed or untracked paths;
- exactly four modified tracked and nine untracked;
- every path regular, single-link, working mode 0644, logical mode 100644;
- zero staged, deleted, renamed, or unmerged;
- no extra path;
- no Git operation marker or lock.

Verify EXPECTED_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact manifest and recipe hashes;
- every manifest row equals live bytes;
- exact tracked binary diff;
- exact verifier and test identities;
- unchanged registry, layouts, historical fixtures, and boundary file;
- OLD_CALLER present and exact;
- BLOCKING_AUDIT present and stable;
- A6D and A6D_AMEND manifests exact.

Run RECIPE twice into fresh external opening paths and require outputs exactly
equal EXPECTED_MANIFEST.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_BASELINE_MISMATCH

## 5. Evidence root

Only after the opening gate succeeds, create FD_EXEC_ROOT under umask 077:

opening/
probe/
commands/
validation/
provenance/
closeout/
tmp/

Directories must be 0700.
Retained files must be regular, single-link, mode 0600 unless explicitly
classified otherwise.

Do not write to IMPL_R or supplied evidence.

## 6. Mandatory fd-exec capability probe

Use the pinned interpreter to establish actual host behavior.

Record:

- Python version and executable object identity;
- whether `os.execve` is in `os.supports_fd`;
- exact open flags used;
- exact failure type and errno if unsupported.

Run a real child probe:

1. no-follow open the pinned interpreter;
2. hash its bytes through the held descriptor;
3. verify expected interpreter hash and metadata;
4. create stdout and stderr pipes;
5. fork once from a deliberately minimal, single-threaded probe process;
6. child duplicates pipe writers to fd 1 and 2;
7. child calls:
   `os.execve(interpreter_fd, argv, environment)`;
8. child argv runs:
   `-I -S -B -c <small canonical probe>`;
9. parent reads streams through EOF and waits/reaps;
10. parent rechecks the held interpreter descriptor and pathname.

Require:

- child exit 0;
- exact expected probe output;
- empty stderr;
- no path-based `execve`;
- no `subprocess.run` or `posix_spawn` for the child interpreter;
- held descriptor stable through reap.

If `os.execve(fd, ...)` is unavailable, raises `NotImplementedError`, or cannot
reliably execute the pinned interpreter:

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_CAPABILITY_UNAVAILABLE

Stop. Do not fall back to:

- pathname exec;
- `/dev/fd`;
- `ctypes`;
- private libc calls;
- a compiled launcher;
- a copied interpreter;
- a stable-path assumption.

## 7. Independent private fd-exec race causal

Under FD_EXEC_ROOT only, prove the semantic distinction between path exec and
fd exec.

Preferred bounded fixture:

- create private executable A whose observable result is A;
- create private executable B whose observable result is B;
- no-follow open A and retain its fd;
- atomically replace A’s pathname with B;
- path execution of the pathname observes B;
- fd execution of the retained descriptor observes A.

Use either:

- private copies of already available harmless host executables whose exit
  behavior differs; or
- a minimal locally compiled audit-only fixture when compilation is already
  available and its exact source, compiler identity, command, and binary hashes
  are retained.

Do not install a compiler or dependency.
Do not retain a compiled fixture outside FD_EXEC_ROOT.
Do not use the system Python path as the mutable race target.

Require fd-exec to prove that pathname replacement does not alter the executed
open object.

## 8. New source-external caller

Create:

FD_EXEC_ROOT/commands/launch_v2_fdexec.py

Classification:

source-external validation/provenance evidence

It is not:

- repository source;
- verifier source;
- product source;
- runtime source;
- readiness authority;
- an independent correctness oracle;
- a durable cross-repository framework.

The caller must be standard-library-only and must:

1. no-follow traverse and open the pinned interpreter;
2. require regular file, link count one, expected mode policy, expected size,
   and expected SHA-256;
3. retain the interpreter fd until the child is reaped;
4. hash through the held descriptor without relying on a later pathname read;
5. no-follow bind package/source, registry, selected layout, target, and
   candidate when applicable;
6. authenticate source bytes against EXPECTED_MANIFEST;
7. enforce canonical UTF-8, no NUL/BOM, terminal LF, size, round trip, and argv
   capacity;
8. build exact launch-protocol-v2 argv;
9. create child stdout/stderr pipes;
10. fork from a minimal single-threaded state;
11. in the child:
    - connect stdout/stderr;
    - close unrelated descriptors;
    - invoke only `os.execve(interpreter_fd, argv, environment)`;
12. in the parent:
    - capture stdout/stderr through EOF;
    - wait and reap exactly once;
    - recheck interpreter fd identity;
    - recheck interpreter pathname as tamper evidence;
    - recheck source/package/target/candidate snapshots;
13. compare returned registry/layout hashes with external expected identities;
14. emit a private launch record without source text or sensitive paths.

No pathname-based child exec is permitted.

No fallback is permitted.

## 9. Root-of-trust non-recursion

The caller must document:

- its already-running foreground parent and kernel are the root of trust;
- its own process launch is not recursively attested;
- the fd-exec proof binds the child interpreter object only;
- this bounded root is necessary to avoid infinite launcher recursion.

Do not claim the caller proves the integrity of:

- its own runtime;
- the operating system;
- the Codex host;
- the kernel;
- privileged administrators.

## 10. FD-exec caller causals

Run at minimum:

1. `os.execve` fd capability present.
2. Pinned Python fd executes expected probe.
3. Private A/B pathname replacement:
   - path exec observes B;
   - fd exec observes A.
4. Interpreter hash mismatch blocks before fork.
5. Interpreter symlink blocks.
6. Interpreter hardlink or disallowed link count blocks.
7. Interpreter nonregular object blocks.
8. Interpreter descriptor identity changes or becomes uncertain blocks.
9. Interpreter pathname changes after open:
   - child may only execute the original fd;
   - launch record is nonqualifying because tamper was observed.
10. Child fd-exec failure is retained and blocks.
11. Fork failure is retained and blocks.
12. Pipe or stream failure blocks.
13. Wait/reap uncertainty blocks.
14. Duplicate wait is impossible.
15. Unrelated descriptors are not inherited.
16. Verifier source mismatch blocks.
17. Registry/layout mismatch blocks at caller.
18. Target/candidate/package mutation blocks.
19. Caller output does not expose source text or sensitive absolute paths.
20. No path-based interpreter execution exists in the caller source.

Retain exact commands, identities, streams, exits, waits, and cleanup.

## 11. Fresh acceptance-bearing validation

Using only the final `launch_v2_fdexec.py` bytes:

1. Parse caller, verifier, and test source with `ast.parse`.
2. Strictly parse registry and three layouts.
3. Verify historical fixture hashes.
4. Discover the exact 88-test set.
5. Run the full suite twice under umask 077.
6. Run the full suite twice under umask 022.
7. Require all four owning commands:
   - exit 0;
   - 88 tests;
   - zero failure/error/skip;
   - identical identities.
8. Run all launch-protocol-v2 targeted causals independently.
9. Run a fresh SEC-02 timed negative:
   - mutable script pathname may race;
   - authenticated argv source executes;
   - target marker never executes;
   - child interpreter is executed by held fd;
   - no forged pass.
10. Run sealed A6D twice.
11. Run sealed amendment twice.
12. Run synthetic A6 pre-seal twice.
13. Seal only the evidence-owned synthetic fixture.
14. Run synthetic A6 sealed twice.
15. Require pairwise deterministic canonical outputs.
16. Require no-write snapshots.
17. Run rooted `git diff --check`.
18. Scan IMPL_R for unexpected artifacts.

Expected real-child stdout hashes remain:

A6D:
3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606

Amendment:
be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc

Any change to repository bytes is an immediate block.

## 12. Interpreter-custody acceptance record

Retain a closed private record containing:

- schema:
  `execution-substrate.evidence-closure-fdexec-launch-record.v1`;
- interpreter requested pathname;
- safe pathname-role label, not a user-private absolute path in shared output;
- opening descriptor identity;
- interpreter size and SHA-256;
- `os.execve in os.supports_fd`;
- fd-exec probe result;
- path-race causal result;
- child PID;
- argv-shape digest without source text;
- environment inventory;
- descriptor inheritance inventory;
- stdout/stderr sizes and SHA-256;
- child exit;
- wait/reap result;
- closing descriptor identity;
- closing pathname observation;
- source/package/registry/layout identities;
- target/candidate snapshot outcomes;
- final outcome and ordered errors.

This record remains evidence only.

## 13. Repository provenance and no-change requirement

Because no repository edit is authorized, the opening and closing repository
manifest must remain exactly:

ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98

Tracked binary diff must remain exactly:

6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7

At closeout, run the exact unchanged RECIPE twice into fresh evidence-owned
paths.

Require byte equality with EXPECTED_MANIFEST.

Any repository change yields:

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_REPOSITORY_MUTATION

## 14. Closing gate

Require:

- exact repository opening/closing identity;
- exact same 13 file rows;
- zero staged/deleted/renamed/unmerged;
- no repository artifact;
- A6D unchanged;
- amendment unchanged;
- BLOCKING_AUDIT unchanged;
- OLD_CALLER unchanged;
- all temporary private fixtures removed;
- no child process, pipe owner, or open private descriptor survives;
- FD_EXEC_ROOT contains only classified retained evidence;
- no network or product operation occurred.

## 15. Verdicts

Use exactly one:

### Capability unavailable

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_CAPABILITY_UNAVAILABLE

Use when open-fd `os.execve` is unavailable or nonfunctional.

### Baseline mismatch

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_BASELINE_MISMATCH

### Process violation

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_PROCESS_BOUNDARY_VIOLATION

### Repository mutation

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_REPOSITORY_MUTATION

### Validation block

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_VALIDATION_BLOCKED

### Clean success

EVIDENCE_VERIFICATION_V1_FDEXEC_CALLER_READY_FOR_FRESH_AUDIT

Use only when:

- fd execution is behaviorally supported;
- the final caller uses no pathname-based interpreter exec;
- private path-race causal proves open-object execution;
- all fresh validation passes;
- real and synthetic compatibility passes;
- repository provenance is unchanged;
- cleanup and process reconciliation pass.

## 16. Complete inline report

Include:

1. Verdict.
2. Response-format confirmation.
3. Exact root-of-trust boundary.
4. Opening repository provenance.
5. Audit VC-01 disposition.
6. `os.supports_fd` result.
7. Exact fd-exec probe.
8. Private path-versus-fd race causal.
9. Final caller source path, size, and SHA-256.
10. Final caller classification.
11. Caller algorithm.
12. Interpreter descriptor lifecycle.
13. Child descriptor inventory.
14. Every caller causal and result.
15. Full 88-test identities or complete safe reference plus count.
16. Two umask-077 suite results.
17. Two umask-022 suite results.
18. Targeted launch results.
19. Fresh SEC-02 result.
20. A6D run 1 and run 2.
21. Amendment run 1 and run 2.
22. Synthetic pre-seal and sealed results.
23. Deterministic output and no-write evidence.
24. Interpreter-custody record identity.
25. Repository opening/closing manifest equality.
26. Artifact cleanup and surviving-process checks.
27. Remaining uncertainty.
28. Explicit nonclaims.
29. Confirmation:
    - repository not modified;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created;
    - fresh independent audit not performed.

Do not replace a section with a link.

No repository repair.
No staging.
No commit.
No push.
No A6 restart.
```

## After success

A clean FD-exec caller result still requires a **fresh independent audit**. The auditor should:

- reproduce fd-exec capability independently;
- inspect the final caller;
- repeat the private pathname-replacement causal;
- independently launch the verifier through a held interpreter fd;
- rerun SEC-02;
- reproduce the unchanged `ed268…` repository manifest at opening and closeout.

No exact-byte commit is permitted until that audit returns `ACCEPT`. The project protocol requires changed repair evidence to receive a new audit, while repository bytes may remain unchanged.  Commit remains a separate gate after acceptance, with staged and committed blobs compared to the accepted manifest. 

### Sources

- Codex’s complete inline independent-audit report supplied in this turn.
- Python 3.13 `os.execve()` file-descriptor support is platform-dependent and must be checked with `os.supports_fd`; unsupported fd use raises `NotImplementedError`. 
- The verifier architecture keeps source trust external and rejects verifier self-certification. 
- Provenance is evidence rather than correctness or authority. 
- Proof and generated evidence must not silently become architecture or authority. 
- Audit findings require repair evidence and a fresh audit; commit follows only after acceptance. 

**Confidence**

- Audit’s VC-01 diagnosis: **0.99**
- Classification as caller/evidence rather than repository-patch defect: **0.995**
- FD-exec as the narrowest principled closure: **0.90**
- Actual macOS/Python host support before probing: **uncertain**
- Need to stop rather than improvise if fd-exec is unavailable: **0.999**
