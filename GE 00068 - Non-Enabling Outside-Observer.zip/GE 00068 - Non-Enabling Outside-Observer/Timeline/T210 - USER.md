Here is Codex's response:



# 1. Verdict

`RECONCILIATION_BLOCKED`

All repository, commit, manifest, candidate, A6D, amendment, caller, recipe, and retained evidence identities matched. Phase entry remains blocked because the exact current A6 execution contract is incomplete:

- the five retained suite specifications are v5/v2 records, while sealed A6D requires v6/v3;
- the historical acceptance comparator is explicitly recorded as unimplemented;
- the retained transition analyzer accepts v5 qualification records and has no v6/v3 successor;
- no authoritative fresh-child prefix or deterministic naming rule was frozen.

The committed generic verifier resolves A6V’s structural-verification bootstrap problem. It does not supply these missing semantic and allocation contracts.

# 2. Governance treatment of the commit process exception

The preceding gate remains truthfully classified `COMMIT_GATE_BLOCKED`. Its sole stated blocker remains the missing explicit environment evidence for the successful commit subprocess.

The supplied `COMMIT_OBJECT_ACCEPTED_WITH_PROCESS_PROVENANCE_EXCEPTION` decision was applied narrowly:

- commit `05dcedb75b674660215504dcf5b5fab9dbb8aa2f` was accepted as the Git object baseline after fresh read-only verification;
- its tree, sole parent, subject, path set, modes, sizes, and blob hashes are acceptance-bearing;
- no claim is made about the commit subprocess environment;
- that missing process evidence was neither inferred nor reconstructed;
- no reset, amendment, replacement commit, push, upstream, PR, or A6 restart was attempted.

# 3. Current Evidence Verification repository

Repository: `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`

| PropertyObserved           |                                                                                                            |
| -------------------------- | ---------------------------------------------------------------------------------------------------------- |
| Physical root              | Exact requested root                                                                                       |
| Branch                     | `codex/evidence-verification-v1`                                                                           |
| HEAD                       | `05dcedb75b674660215504dcf5b5fab9dbb8aa2f`                                                                 |
| HEAD tree                  | `1705df78364003806e2463bb54588c09dc69c60d`                                                                 |
| Sole parent                | `567bceced5df95ecfe787cc66038d463a854e12c`                                                                 |
| Subject                    | `add evidence verification v1`                                                                             |
| Upstream                   | Absent                                                                                                     |
| Working tree/index         | Clean                                                                                                      |
| Ignored repository paths   | 0                                                                                                          |
| Operation markers or locks | None                                                                                                       |
| Git directory              | `/Users/ds/Repositories/Execution Substrate/.git/worktrees/Execution-Substrate---evidence-verification-v1` |
| Common Git directory       | `/Users/ds/Repositories/Execution Substrate/.git`                                                          |

No Git command targeted the primary checkout.

# 4. Complete 13-path committed-blob reconciliation

The commit contains exactly 13 changed paths: four modified and nine added. Every committed mode is `100644`; there is no extra path. “Equal” compares the committed Git blob directly with the audited manifest row.

| PathManifest classCommit classModeBytesCommitted SHA-256Equal             |                    |          |          |         |                                                                    |     |
| ------------------------------------------------------------------------- | ------------------ | -------- | -------- | ------- | ------------------------------------------------------------------ | --- |
| `.docs/system_overview/artifact_hygiene.md`                               | `tracked_modified` | Modified | `100644` | 14,292  | `b5e6d44c442905b95b3006f47ce96b38bc6ea7a4097aef467057163162fe1fa7` | Yes |
| `.docs/system_overview/boundaries.md`                                     | `tracked_modified` | Modified | `100644` | 65,156  | `643cdd7690c0225d6e185ae4dfd867f7861e32b20e3711fa575b41c45142414e` | Yes |
| `.docs/system_overview/capability_probing.md`                             | `tracked_modified` | Modified | `100644` | 10,569  | `80857e6e6b90d01ac72f91f6c1c6d23de69824d74febd59ad0f0194e95204f95` | Yes |
| `.docs/system_overview/evidence_verification.md`                          | `untracked`        | Added    | `100644` | 23,125  | `0980d65adf5af833fefcbb2cf0354e8154a5ee69a1eee0e595fedd40f5caa6f6` | Yes |
| `PLANS.md`                                                                | `tracked_modified` | Modified | `100644` | 223,126 | `187effc20ab50cf42c08e0be7b9fa45c5db9ba0a0aa66c6b8c07ac0280b52226` | Yes |
| `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`  | `untracked`        | Added    | `100644` | 14,418  | `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f` | Yes |
| `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt` | `untracked`        | Added    | `100644` | 3,338   | `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98` | Yes |
| `tools/evidence_verify/layouts/a6_policy_v1.json`                         | `untracked`        | Added    | `100644` | 1,015   | `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8` | Yes |
| `tools/evidence_verify/layouts/a6d_amendment_v1.json`                     | `untracked`        | Added    | `100644` | 856     | `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4` | Yes |
| `tools/evidence_verify/layouts/a6d_successor_v1.json`                     | `untracked`        | Added    | `100644` | 892     | `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc` | Yes |
| `tools/evidence_verify/registry_v1.json`                                  | `untracked`        | Added    | `100644` | 585     | `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880` | Yes |
| `tools/evidence_verify/test_verify_v1.py`                                 | `untracked`        | Added    | `100644` | 91,210  | `721bfc331f051292f249a343fe69c2e7730d08a94bc2a5418ab9d20524bae6a5` | Yes |
| `tools/evidence_verify/verify_v1.py`                                      | `untracked`        | Added    | `100644` | 40,121  | `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c` | Yes |

# 5. Manifest, recipe, caller, audit, and commit-gate evidence

## Accepted manifest and source inputs

| InputSizeSHA-256Current posture |        |                                                                    |                              |
| ------------------------------- | ------ | ------------------------------------------------------------------ | ---------------------------- |
| Audited manifest                | 3,193  | `6ca8f5513d9c4bcd8fe930c1f28144e4f3e86a1a847537a01de4f7a91abd5445` | Regular, single-link, `0600` |
| Provenance recipe               | 5,143  | `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333` | Regular, single-link, `0600` |
| Source-external caller          | 49,047 | `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5` | Regular, single-link, `0600` |

Recipe ID: `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`.

The preceding independent adjudication supplied an exact-byte `ACCEPT`. No separate audit-report file was invented. The audit root currently has 157 objects including its root, with all directories `0700` and all files regular, single-link, `0600`.

## Commit-gate evidence

Commit-gate root:

`/Users/ds/Downloads/ES-evidence-verification-v1-commit-gate-6ca8f5513d9c-hwfocnl2`

Its final inventory is:

- size: 3,043 bytes;
- SHA-256: `e7e7b692a04343b508b3b3b1d7b3f66d6e48c2bbc93b9effd5010e564525e4ca`;
- schema: `execution-substrate.evidence-verification-v1.commit-gate-final-inventory.v1`;
- self-excluded path: `closeout/final-inventory.json`.

All 22 inventory rows match the retained objects, with the self-excluded inventory as the sole additional object. The root has 23 objects including the root itself. No mode, link, size, hash, or membership mismatch was found.

# 6. Candidate repository identity

Candidate: `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1`

| PropertyObserved                |                                                                                       |
| ------------------------------- | ------------------------------------------------------------------------------------- |
| Physical root                   | Exact requested root                                                                  |
| Candidate device/inode          | `16777234 / 122118502`                                                                |
| Primary sibling device/inode    | `16777234 / 47685738`                                                                 |
| Sibling distinction             | Proven                                                                                |
| Branch                          | `codex/remote-alpha-external-tls-status-observation-v1`                               |
| HEAD                            | `567bceced5df95ecfe787cc66038d463a854e12c`                                            |
| Sole parent                     | `05dde14d185b6e022dcc169ef1a658a97961850f`                                            |
| HEAD tree                       | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                            |
| Upstream                        | Absent                                                                                |
| Repository source T             | `8de797304ea944b6a155924e0d1e9e8bbe79534e`                                            |
| Inventory SHA-256               | `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`                    |
| Inventory size                  | 54,314 bytes                                                                          |
| Membership                      | `389 / 375 / 14` total/tracked/untracked                                              |
| Tracked modifications           | 22                                                                                    |
| Staged/deleted/renamed/unmerged | `0 / 0 / 0 / 0`                                                                       |
| Ignored paths                   | 0                                                                                     |
| `.git` pointer                  | 123 bytes, SHA-256 `79247c70d443aba211d972b5316847bb38cac45d7caf03c766b9ae5d2e2d0419` |
| Index SHA-256                   | `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`                    |

The inventory and pure tree were independently recomputed from all 375 tracked and 14 nonignored untracked live files.

# 7. A6D, amendment, and joint qualification

## Sealed A6D

Root: `phase-i-a6d-device-security-successor-closure-8de797304ea9`

- manifest: 103,293 bytes, 623 payloads;
- manifest SHA-256: `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`;
- directories including root: 205;
- source T: `8c237318e3a72172e5cbbdf41f5e68244ae15895`;
- source inventory: `7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852`.

Every manifest row was rehashed. File membership, modes, sizes, hashes, sidecar, directory modes, and absence of symlinks all matched.

Current A6D binary pairs are byte-identical across sides A and B, inode-distinct, single-link, mode `0700`:

| BinaryBytesSHA-256  |           |                                                                    |
| ------------------- | --------- | ------------------------------------------------------------------ |
| `repair10-runner`   | 6,203,202 | `44280431013579568ee1e3dc54c834f5755291372977b50a16c82260dcd3598e` |
| `repair10-compare`  | 4,973,858 | `ef694c89a7b3c89f94f1c1d7f11de1ec8d5690e066c0ab0d0f9d0bf94f248482` |
| `repair10-semantic` | 4,146,802 | `c916cb7fdfffbcfd090605171ba2c43ba895ca5af2f727fb4cf847f6ce1137e7` |
| `repair10-fixture`  | 7,709,426 | `d058ebdeb01b960868e4784abafbaaef9d57e8e71b12bdaa71f55aca9786c2f4` |

A6D establishes outer schema v6 and effective-read-policy v3. v5/v2 is historical and parse only.

## Sealed amendment

Root: `phase-i-a6d-seal-verifier-amendment-8de797304ea9`

- manifest: 3,801 bytes, 29 payloads;
- manifest SHA-256: `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`;
- directories including root: 9;
- corrected post-seal helper: 9,386 bytes, SHA-256 `746d63cfab5256766a366b8f829ac0f00de0c6a38f6bc70598231d55d2c08461`;
- corrected closing helper: 14,633 bytes, SHA-256 `52003d2bb42e96ada233b341543d744dfd288228dd826da6905233d7594249e1`.

All manifest rows and filesystem properties matched.

The joint qualification is 6,084 bytes with SHA-256:

`e9af0475fb0855404616630c3dfc5749be6d5b7f7ec9107a8de0eee2e7eb92c9`

It binds A6D, the amendment, corrected helpers, original binaries, and 20 passing verifier causals. It also explicitly records:

- `historical_comparator_not_implemented: true`;
- fresh A6 was not restarted;
- the original target-specific verifier was superseded for qualification;
- the amendment and A6D must remain joint downstream inputs.

# 8. Existing failed and reconnaissance child dispositions

No existing policy-evidence child is an eligible fresh target.

| ChildSeal postureQualification dispositionResumable |                         |                                                                                                       |    |
| --------------------------------------------------- | ----------------------- | ----------------------------------------------------------------------------------------------------- | -- |
| `phase-i-a6-policy-evidence-e260e1bb5ac4`           | Unsealed                | Final control command failed; evidence refresh blocked                                                | No |
| `phase-i-a6-policy-evidence-a5s-e260e1bb5ac4`       | Unsealed                | Final/fresh comparison exited unexpectedly; refresh blocked                                           | No |
| `phase-i-a6-policy-evidence-a5c-8de797304ea9`       | Unsealed                | Historical overlay construction required; mandatory stop                                              | No |
| `phase-i-a6-policy-evidence-a6o-8de797304ea9`       | Unsealed                | Partial predecessor-dialect work; comparison/analysis never completed                                 | No |
| `phase-i-a6-policy-evidence-a6r-8de797304ea9`       | Unsealed                | Pristine control stopped before process launch on `/dev/null` ACL `EINVAL`; no comparison or analysis | No |
| `phase-i-a6-policy-evidence-a6d-8de797304ea9`       | Unsealed                | Zero controls; old verifier rejected its target path before layout checking                           | No |
| `phase-i-a6v-evidence-target-recon-8de797304ea9`    | Unsealed reconnaissance | No tests, controls, comparisons, or analyzer; reconnaissance-only block                               | No |

Each has absent manifest and detached digest. Their private roots were removed or never created. Their closeouts forbid continuation, and their predecessor dialect or target assumptions are obsolete. Reusing any one would violate the fresh-child requirement.

# 9. Exact retained five-control plan

## Common retained suite

The retained plan names seven commands in this order:

1. `denied-read-causality`, expected exit `0`;
2. `seed-existing-transitive-mod-metadata`, expected exit `0`;
3. `initialize-private-git-administration-and-object-store`, expected exit `0`;
4. `install-control-root-private-mktemp-wrapper`, expected exit `0`;
5. `seed-hash-bound-historical-head-corpus`, expected exit `0`;
6. `complete-active-test-inventory-before-launch`, expected exit `0`;
7. `literal-complete-private-repository-suite`, allowed process exit `0` or `1`, with terminal and semantic consistency required.

All seven require terminal reconciliation, complete stream EOF, no overflow, clean resource disposition, and an empty next-command barrier. The full suite requires the private PTY v2 protocol: 21 `openpty-no-ctty` requests except historical HEAD, which requires one.

Pinned paths in the retained specifications include Go 1.26.5, Xcode Git and clang, Python 3.13, OpenSSL 3.6.2, and the MacOSX 26.5 SDK.

## Controls

| Control IDSource and materializationRetained sideRequired qualification and terminal disposition |                                                                                                                                                        |           |                                                                                                                                                                                                                                                        |
| ------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `repair10i-pristine-final-v1`                                                                    | `pristine-final`; T `8de797…34e`, inventory `64b2f9…5c2`, 389 members; independent direct materialization, no overlay                                  | A, peer B | Current qualification must be v6/v3, producer and peer qualified, byte-identical peer semantic extraction, terminal/resource/PTY/read-policy gates true. Retained final semantic counts are tests `2753/137/8` pass/fail/skip and packages `14/11/23`. |
| `repair10i-fresh-independent-final-v1`                                                           | Same logical T/inventory and membership as pristine final, but a separately materialized physical source with no inode alias                           | B, peer A | Same v6/v3 qualification and exact terminal universe as pristine final. Source-class equality cannot substitute for physical independence.                                                                                                             |
| `repair10i-intentional-mutant-v1`                                                                | Base T/inventory `8de797…34e` / `64b2f9…5c2`; one existing `100644` file changed before execution; effective T `f981be…033`, inventory `7e2524…802`    | A, peer B | Must qualify independently. Exact mutation: `observe_test.go`, 268,924 bytes/`cb9b…39ec` to 268,966 bytes/`5c5c…9898`; exactly one expected material diagnostic and two frozen lifecycle transitions.                                                  |
| `repair10i-historical-head-v1`                                                                   | `historical-head`; T `b7cab2…5338`, inventory `291d9e…399a`, 375 members; no overlay                                                                   | B, peer A | Must qualify under the current dialect. Aggregate suite exit may be 0 or 1 only when consistent with captured semantics. Historical-direction analysis is mandatory.                                                                                   |
| `repair10i-historical-repair9-v1`                                                                | Base T `0ea3b6…1198`, inventory `7b8cfa…199e`, 382 members; exact one-file validation overlay yields effective T `4bd05d…ff6e`, inventory `e17a77…583` | A, peer B | Base and effective roots must be distinct and independently verified. Overlay provenance must be frozen before execution, reversible, single-path, mode preserving, and nonproduct. Historical-direction analysis is mandatory.                        |

The five physical source roots, their private control roots, Git stores, caches, runtime roots, sockets, processes, and member inodes must be pairwise disjoint. The Repair 9 base and effective proof roots must also be distinct.

## Current-contract gap

The only retained five suite-spec files are v5:

| ControlRetained v5 spec SHA-256 |                                                                    |
| ------------------------------- | ------------------------------------------------------------------ |
| Pristine final                  | `6ffefbf9bfc835bd0b7015511e1485d9e8f5a2e3da68735314ea50010057fb22` |
| Fresh independent final         | `ad9577c08b56a9461e18928e15423f0df5cbdcacf70abd06f7faed22edab1879` |
| Intentional mutant              | `bfb93ab722235250e978f2d9d836dbbf769f03327512b50de74e3c564122a596` |
| Historical HEAD                 | `842c88ac69ab543436b91c8f3053047625fad49ddf90f7c6e4e72c15926d9ac7` |
| Historical Repair 9             | `6ef309cb6695c565e389958f799af23c4d2e8e9e1d7c87ea190e87e5ace2aff9` |

Those records point to A6R binaries and effective-read-policy v2. Sealed A6D makes them parse-only. No exact five-spec v6/v3 set exists, so the current suite identity cannot be completed by substitution or silent relabeling.

# 10. Comparison and expected-exit matrix

The retained plan contains five pairs:

| ComparisonComparator sideRequired factual resultAcceptance resultProcess exit |   |                                                                                                                                                                     |                                               |                                                                                          |
| ----------------------------------------------------------------------------- | - | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------- | ---------------------------------------------------------------------------------------- |
| Pristine final → fresh final                                                  | A | Canonical lifecycle, diagnostics, semantics, logical suite fingerprint, terminal universe, and declared read-policy semantics equal; physical roots remain distinct | `qualified-equal`                             | `0`                                                                                      |
| Pristine final → intentional mutant                                           | B | Only the frozen mutant diagnostic and lifecycle delta; zero unknowns                                                                                                | `qualified-different`, expected mutant delta  | `2`                                                                                      |
| Intentional mutant → fresh final                                              | A | Inverse view of exactly the same mutant delta; zero unknowns                                                                                                        | `qualified-different`, expected mutant delta  | `2`                                                                                      |
| Historical HEAD → pristine final                                              | B | Directional complete transition matrix; no regression, hazard, integrity error, missing baseline identity, or unknown difference                                    | Accepted historical directional no-regression | Intended `2`; retained factual v5 path allowed `1` or `2` and had no readiness authority |
| Historical Repair 9 effective → pristine final                                | A | Same directional policy, plus exact qualified overlay custody and no product-improvement credit                                                                     | Accepted historical directional no-regression | Intended `2`; retained factual v5 path allowed `1` or `2` and had no readiness authority |

Every comparison must bind:

- source class and complete base/effective source binding;
- suite-result path, size, and hash;
- producer and peer qualification identities;
- semantic and raw stream paths, sizes, and hashes;
- raw streams reopened through EOF;
- externally recomputed qualifications;
- physical-control disjointness;
- clean terminal and resource custody;
- comparator, command, specification, result, and custody identities;
- for historical pairs, baseline/final direction, overlay requirement, deterministic analysis identity, and read-policy qualification references.

Unknown differences always block. New passing tests cannot mask one blocked transition. Final-only fail or skip, pass-to-fail/skip/absent, deleted or renamed baseline tests, new panic/race/warning/fatal/unknown diagnostics, malformed or incomplete streams, qualification failure, or a late terminal/resource/custody fault all require exit `1`.

The retained analyzer is an evidence-only program:

- source: 26,232 bytes;
- SHA-256: `5939f93895abf8a798473c1162ac3ccbc7ae42d197e4d95d278baacc883c0b0d`;
- tests: 7,651 bytes, SHA-256 `cf061625fe0195f569aff08ed4c9587184571862ec6e34fc7a527840967ee038`;
- expected analyzer process exit: `0`, with acceptance carried in its output.

It explicitly requires `control-qualification.v5` and v2 read-policy evidence. No v6/v3 analyzer is retained. A6D and its joint qualification also explicitly disclaim historical-comparator readiness. These are acceptance-bearing missing components.

# 11. Committed verifier and caller invocation contract

## Frozen identities

- verifier commit: `05dcedb75b674660215504dcf5b5fab9dbb8aa2f`;
- verifier blob SHA-256: `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`;
- registry blob SHA-256: `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`;
- layout ID: `execution-substrate.repair10i.a6-policy-layout/v1`;
- layout blob SHA-256: `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`;
- source-external caller SHA-256: `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`.

The package must be materialized from those committed Git blobs with provenance binding the commit and blob identities. A mutable uncommitted package copy is ineligible.

Accepted interpreter:

- `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`;
- version `3.13.4`;
- regular, direct, single-link;
- size 119,424;
- SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

## Exact verifier argv semantics

Pre-seal:
```
python3.13 -I -S -B -c SOURCE_TEXT \
  --package-root ABSOLUTE_PHYSICAL_EXTERNAL_PACKAGE \
  --root ABSOLUTE_PHYSICAL_FRESH_TARGET \
  --layout-id execution-substrate.repair10i.a6-policy-layout/v1 \
  --stage pre-seal \
  --manifest ABSOLUTE_PHYSICAL_EXTERNAL_CANDIDATE
```

Sealed:
```
python3.13 -I -S -B -c SOURCE_TEXT \
  --package-root ABSOLUTE_PHYSICAL_EXTERNAL_PACKAGE \
  --root ABSOLUTE_PHYSICAL_FRESH_TARGET \
  --layout-id execution-substrate.repair10i.a6-policy-layout/v1 \
  --stage sealed
```

The order is exact. `--manifest` is permitted only for pre-seal. The source string must equal the committed verifier blob byte for byte after canonical UTF-8 decoding.

Expected returned hashes are:

- registry: `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`;
- layout: `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`.

The caller record schema is `execution-substrate.evidence-closure-launch-record.v4`, using launch protocol `execution-substrate.evidence-closure-launch/v2`.

Each caller publication uses one private `0700` stage directory containing exactly:

- `<name>.json`;
- `<name>.stdout`;
- `<name>.stderr`.

All three are regular, single-link, mode `0600`. Publication is one exclusive whole-directory rename into an absent bundle parent. There is no file-by-file fallback, copy/delete publication, or fourth public output.

Verifier output proves structural closure only. It cannot decide control success, comparison acceptability, Repair 10I correctness, readiness, commit fitness, or publication authority.

# 12. Fresh-child structural contract

## Allocation status

An exact fresh target path cannot currently be frozen.

A6V expressly records that `a6-policy-evidence` and a future root naming rule were design candidates rather than a qualifying frozen contract. The deterministic `phase-i-a6-policy-evidence-a6d-8de797304ea9` path already exists and is nonresumable. Inventing a suffix or reusing that child is forbidden.

The abstract allocation constraints are known:

- create one absent direct child beneath `EVIDENCE_ROOT`;
- use exclusive creation;
- require a direct physical directory, mode `0700`;
- reject symlinks, aliases, nesting with the candidate/package/output roots, or an existing name;
- never select or resume an existing child.

A concrete prefix/name requires an authoritative contract before allocation.

## Frozen layout

Top-level directories, and the exact allowed root-directory set:

- `analysis`
- `closeout`
- `commands`
- `comparisons`
- `controls`
- `findings`
- `opening`
- `sources`
- `tool`
- `validation`

Required fixed records, all mode `0600`:

- `opening/opening-capsule-v1.json`
- `closeout/closing-gate-v1.json`
- `closeout/cleanup-v1.json`
- `closeout/command-root-audit-v1.json`
- `closeout/final-report-v1.md`

Other records may occur only under the ten bounded optional subtrees.

Bounds:

- directories: 2,048;
- files: 8,192;
- bytes per file: 268,435,456;
- total payload bytes: 4,294,967,296;
- path segments: 12;
- encoded relative-path bytes: 1,024;
- directory mode: `0700`;
- file modes: `0600` or `0700`;
- manifest magic: `GE-EVIDENCE-MANIFEST-V1`.

At pre-seal, both seal files are absent. The complete candidate manifest is a regular, single-link, externally placed file and is checked without installation.

Sealing order is:

1. finish all child payloads, including child cleanup and final report;
2. generate the external candidate over that final payload;
3. pass pre-seal closure;
4. install `evidence-manifest-v1.txt.sha256`, containing lowercase candidate SHA-256 plus LF;
5. install `evidence-manifest-v1.txt` as the final child mutation;
6. perform sealed closure.

Verifier results and caller bundles remain outside the target. Private TMPDIRs, package materializations, source/control roots, caches, processes, descriptors, sockets, and stages must be absent after their governed cleanup.

# 13. Frozen execution sequence

No A6 execution is authorized while the missing contracts remain.

After separately implementing and auditing those contracts, the retained dependency order is:

1. Reverify the accepted commit, caller, interpreter, candidate, A6D, amendment, joint qualification, lineage, and all nonresumable children.
2. Freeze an authoritative fresh-child naming rule and exclusively allocate an absent child.
3. Materialize the verifier package directly from the committed blobs and verify its source, registry, and layout identities.
4. Create the ten structural directories and opening capsule.
5. Independently materialize all five source roots; freeze mutant and Repair 9 overlay provenance before execution; prove cross-root inode and path disjointness.
6. Run and peer-qualify pristine final, then fresh independent final.
7. Compare final/fresh and require exit `0`.
8. Run and peer-qualify the intentional mutant.
9. Run the two mutant comparisons and require exit `2` for both.
10. Run and peer-qualify historical HEAD and historical Repair 9.
11. Prove all-five control, cache, runtime, Git-store, source, PTY, process, socket, and descriptor isolation.
12. Run the two factual historical comparisons.
13. Run deterministic HEAD→final and Repair9→final analyses and require both independent directional adjudications to accept.
14. Apply the implemented v6 historical-comparator acceptance gate.
15. Complete closeout adjudication, command-root audit, candidate/lineage revalidation, private-root cleanup, and two zero-observation epochs.
16. Finalize the child cleanup record and final report.
17. Build the external manifest candidate and perform pre-seal closure.
18. Install the detached digest, then install the manifest as the final child mutation.
19. Perform sealed closure through the exact caller and consume the complete three-file caller bundle.
20. Clean caller-owned temporary state without mutating the sealed child.
21. Conduct a separate later independent A6 audit.

Independent read-only opening hashes may run in parallel. The retained execution plan otherwise orders controls, peer qualifications, comparison gates, analysis, child mutations, and sealing serially. Producer/peer qualification depends on the completed producer result. Final/fresh must close before the mutant; mutant comparisons must close before historical controls. No concurrent writer may target the child or any control root.

# 14. Mandatory stop conditions

Stop immediately on:

- committed verifier, registry, layout, caller, interpreter, recipe, manifest, or commit-object drift;
- candidate, index, source T, inventory, membership, Git identity, A6D, amendment, or joint-qualification drift;
- any attempt to use v5/v2 records as current v6/v3 qualification;
- an ambiguous five-control plan or missing current suite specification;
- missing historical comparator or compatible analyzer;
- any reused, resumed, renamed, or pre-existing A6 target;
- source T, inventory, membership, mutant, overlay, or materialization mismatch;
- path, inode, cache, Git-store, runtime, PTY, process, socket, descriptor, or writable-state overlap;
- failed producer/peer qualification or differing peer semantic extraction;
- unknown semantic difference or unclassified diagnostic;
- wrong expected exit, inconsistent terminal disposition, incomplete EOF, overflow, or late resource/custody fault;
- wrong historical direction, unqualified overlay, product-improvement credit for overlay bytes, or aggregate-exit substitution for structural analysis;
- target/package/candidate/TMPDIR/caller-output/interpreter containment or aliasing;
- pre-seal or sealed closure failure;
- any readiness interpretation inside the verifier or caller;
- a fourth public caller output or nonexclusive publication fallback;
- any repository or supplied-evidence mutation;
- any push, installation, product path, live route, remote contact, PR, merge, or upstream creation.

# 15. Remaining ambiguity and uninspected scope

Acceptance-bearing unresolved items are:

1. No authoritative fresh-child prefix or deterministic name.
2. No five-control v6 suite-spec set bound to A6D binaries and effective-read-policy v3.
3. No implemented historical directional comparator despite a retained design contract.
4. No transition analyzer compatible with v6 qualifications and v3 policy evidence.
5. No retained current orchestration record resolving those components into one executable contract.

The read-only inspection did not execute or validate product behavior, tests, controls, comparisons, the analyzer, verifier, caller, product paths, live services, or remote systems. No claim about A6 readiness can be made from the structurally committed verifier alone.

# 16. Explicit confirmations

- No file was created.
- No file was modified.
- No file was deleted.
- No test or control was run.
- No comparison or analyzer was run.
- No verifier or caller was invoked.
- No A6 child was created or resumed.
- No staging, commit, reset, amendment, revert, push, PR, merge, or upstream operation occurred.
- No product or live-service operation occurred.
- No network contact occurred.
- No subagent was spawned, contacted, or used.
