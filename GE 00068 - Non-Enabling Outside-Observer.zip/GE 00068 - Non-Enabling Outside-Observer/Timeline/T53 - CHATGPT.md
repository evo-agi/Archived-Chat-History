Codex is right again, and this time the result invalidates the **entire declaration-list design**, not merely one missing identity.

The fifth test is only the immediate contradiction. The decisive evidence is:

- HEAD → final has **638** final-only passing test terminals.
- Repair 9 → final has **194**.
- Many are subtests or tests that never reached a terminal in the historical control because an earlier package failure or abort prevented execution.
- The two historical baselines therefore have different final-only-pass sets.

A predeclared identity allowlist is the wrong abstraction. Expanding it from four to five, or even generating lists of 638 and 194 names, would be brittle and partly circular: the comparator would require the expected output of the qualifying executions as policy input.

## Correct policy direction

Historical comparison is **directional regression analysis**, not semantic equality and not an identity-exception list.

For test and subtest terminals, the durable rule should provisionally be:

| Baseline | Final | Disposition |
|---|---|---|
| absent | pass | allowed improvement; report exactly |
| absent | fail or skip | block |
| pass | pass | allowed |
| pass | fail, skip, or absent | block |
| fail | fail or pass | allowed, while common failures remain explicitly reported |
| fail | skip or absent | block |
| skip | skip or pass | allowed |
| skip | fail or absent | block |

Package terminals need a separately derived rule, especially for newly introduced packages with a legitimate `[no test files]` package skip. Panics, races, warnings, malformed streams, unknown diagnostics, package aborts, and incomplete or duplicate terminal evidence remain independently blocking.

This model has three important properties:

1. It permits genuinely new passing coverage without hardcoded test names.
2. It cannot hide a renamed or deleted historical test, because baseline disappearance remains blocking.
3. It preserves the strict rule that **only absent → pass** receives automatic new-identity treatment.

I would not send another implementation prompt yet. Two failed declaration freezes show that we have not recovered the actual historical terminal lattice sufficiently. The next turn should be a narrow, parent-only, read-only A6 policy reconnaissance. A6 has never been created, so there is no need for A7.

Pass this to Codex:

```text
Objective

Perform a parent-only, read-only Repair 10I-A6 historical-comparison-policy
reconnaissance.

Recover the complete terminal-transition and diagnostic policy required for
HEAD→Repair-10I-A5 and Repair-9→Repair-10I-A5 comparisons, and freeze one
durable A6 successor amendment.

Do not implement A6 in this turn.

The prior finite `declared_final_only_passes` design is withdrawn. Do not
attempt to expand it to five, 194, or 638 identities.

Provisional strategic target:

- historical comparisons are directional no-regression checks;
- a final-only test/subtest terminal is allowed only when its action is pass;
- final-only passing identities are reported exactly, not predeclared;
- every hazardous terminal transition and hazardous diagnostic class remains
  blocking.

This target must be checked against the exact A4 implementation and exact
retained semantic records before it is frozen.

No subagents. No repository or evidence mutation.

Do not create A6.
Do not modify A4, A5, B5, or any predecessor.
Do not run a full test suite.
Do not create source copies, caches, bytecode, temporary reports, or evidence
children.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or create a snapshot.

Use only read-only inspection. For any inline Python parsing:

- invoke `/usr/bin/python3 -`;
- set `PYTHONDONTWRITEBYTECODE=1`;
- import no module from a sealed child;
- emit results to stdout only;
- create no external scratch file.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A4 successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a4-successor-closure-4dd211207800

Sealed A5 source repair

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5-product-closure-4dd211207800

Failed B5 child

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b5-closure-e260e1bb5ac4

Phase H retained semantic evidence

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

A6 target, required absent

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-successor-closure-e260e1bb5ac4

## 1. Opening gate

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- repository inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require exact A5:

- manifest:
  29702284ed6e5a5d44758e27a7211cf83e20dbe13dbd8a9964b87f3f1724b1fc
- payloads:
  341
- directories:
  84
- T:
  e260e1bb5ac44ee4ba732265eddd4a27aa1d3e0c
- inventory:
  9fb9765a4b0b41ae40da758d9a0315739b615a4c4c2027cd1bc1c83c3c92589b

Require exact A4:

- T:
  fca111f0c8b91af4b1f60f5afbb74a0bdbe818ac
- inventory:
  7c2fd63c2eeb02412d2e1a625f88887e045def7b69974a5b604bd391ecdf6c06
- manifest:
  772cd3d85de7505dad6d9ae4ee38f808b8668f9056c0df784fd81d34814957bf
- payloads:
  540

Require B5 to remain unsealed and byte-exact.

Require A6 to remain absent.

Also reverify A, A2, A3, Phase H, B, B2, B3, B4, and the B4
divergence-reconciliation child sufficiently to establish that this
reconnaissance is bound to the same active lineage.

Stop on any mismatch:

REPAIR10I_A6_RECONNAISSANCE_BASELINE_MISMATCH

## 2. Current comparator inspection

Inspect exact A4 source, especially:

- `tool/source/FORMAT.md`
- `tool/source/envelope/semantic.go`
- `tool/source/envelope/envelope_test.go`

Recover with path and line references:

1. `SemanticComparisonSpecV1`.
2. `SemanticComparisonResultV1`.
3. `declaredRepair10INewPassingIdentityV1`.
4. `noFinalOnlyRegressionV1`.
5. Every caller of the historical no-regression predicate.
6. How package, test, and subtest terminal identities are represented.
7. How missing identities, package aborts, panics, races, warnings, malformed
   streams, unknown diagnostics, and skips affect the result.
8. How CLI exit 0/1/2 is derived.
9. Which fields are factual and which fields authorize acceptance.

State exactly why the current compiled-in declaration mechanism cannot
represent the retained historical comparisons.

## 3. Recover the exact historical transition matrices

From exact retained, identity-bound semantic records, derive separate matrices
for:

1. historical HEAD → exact A5 final;
2. exact Repair 9 → exact A5 final.

Do not rely solely on the reported totals 638 and 194. Recompute them.

For each direction, separately enumerate and count:

### Test/subtest terminal identities

- absent → pass
- absent → fail
- absent → skip
- pass → pass
- pass → fail
- pass → skip
- pass → absent
- fail → pass
- fail → fail
- fail → skip
- fail → absent
- skip → pass
- skip → fail
- skip → skip
- skip → absent

### Package terminal identities

Derive the same matrix separately for packages.

Also distinguish, when represented by the retained semantics:

- ordinary package pass;
- package fail;
- package skip caused by no test files;
- package setup/build abort;
- package terminal missing or incomplete.

### Identity shape

For every final-only pass set, report:

- total identities;
- top-level test count;
- subtest count;
- package distribution;
- canonical byte length;
- canonical SHA-256.

Do not print all hundreds of identities in the final report. Identify the exact
sealed record or array from which they can be recovered and report canonical
set hashes.

### Hazard classes

For each historical direction independently report final-only or newly
introduced:

- panic identities;
- race identities;
- warnings;
- fatal-runtime identities;
- malformed JSON;
- duplicate terminals;
- missing terminals;
- unknown diagnostics;
- package aborts.

Also report baseline hazardous identities that disappeared or changed class.

## 4. Determine why identities are final-only

Without running a new full suite, classify as far as retained evidence safely
supports:

- tests absent from baseline source;
- tests present in source but not executed because a baseline package aborted;
- newly introduced subtests;
- identities whose reason cannot be established from the sealed material.

Do not silently infer source absence from terminal absence.

A full explanation of all 638/194 identities is not required to select the
policy. State where source-grounding stops.

## 5. Adjudicate the durable policy

Evaluate these three models against the recovered matrices:

A. finite predeclared passing-identity allowlist;
B. declaration generated from a prior execution;
C. structural directional no-regression relation.

The parent must recommend one model.

The provisional target is C:

### Test and subtest terminals

- absent → pass:
  allowed improvement, but retained and reported exactly;
- absent → fail or skip:
  blocking;
- pass → pass:
  allowed;
- pass → fail, skip, or absent:
  blocking;
- fail → fail or pass:
  allowed, while inherited failures remain explicitly reported;
- fail → skip or absent:
  blocking;
- skip → skip or pass:
  allowed;
- skip → fail or absent:
  blocking.

### Package terminals

Do not blindly reuse the test lattice.

Freeze a separate package policy grounded in the recovered package matrix,
including exact treatment of a newly added package whose terminal is `skip`
because it has no tests.

At minimum:

- final-only package failure or setup/build abort blocks;
- baseline passing package becoming fail, skip, abort, or absent blocks;
- baseline package disappearance blocks;
- fail → pass may be admitted as improvement;
- any admitted final-only package skip must be narrowly and causally
  classified, not treated as a generic skip exception.

### Hazardous semantic classes

The historical policy must independently block any newly introduced:

- failure;
- test skip;
- package abort;
- panic;
- race;
- warning;
- fatal runtime condition;
- malformed stream;
- unknown diagnostic;
- incomplete or duplicate terminal;
- qualification, custody, resource, or terminal-reconciliation failure.

A source-bound final-only pass is not itself hazardous and must not require an
identity-name allowlist.

Confirm whether this provisional lattice fits every retained transition.
Identify any counterexample or unresolved case.

## 6. Freeze the A6 schema direction

Assuming the directional policy is supported, freeze whether A6 should use:

- `execution-substrate.repair10i.semantic-comparison-spec.v2`
- `execution-substrate.repair10i.semantic-comparison-result.v2`

The preferred design is:

- no `declared_final_only_passes` field;
- a closed comparison-policy value such as:
  `historical-directional-no-regression-v2`;
- v1 historical comparison inputs remain parse-only and nonqualifying;
- final/fresh and mutant policies remain exact and unaffected;
- the result records exact transition sets or their canonical references and
  hashes.

Freeze exact result fields sufficient to report:

- final-only passing tests/subtests;
- final-only passing packages;
- final-only nonpassing identities;
- baseline regressions by transition;
- baseline improvements by transition;
- missing baseline identities;
- package aborts;
- hazardous diagnostic/class deltas;
- accepted historical-no-regression boolean;
- reason codes.

Freeze a closed reason-code set.

At minimum distinguish:

- final-only-pass-observed
- final-only-fail
- final-only-test-skip
- final-only-package-abort
- baseline-pass-regressed
- baseline-terminal-disappeared
- baseline-fail-became-skip
- baseline-skip-became-fail
- new-panic
- new-race
- new-warning
- malformed-stream
- unknown-diagnostic
- package-no-tests-admitted
- historical-policy-v1-nonqualifying
- historical-no-regression-satisfied

Do not finalize names that conflict with existing A4 naming; report the exact
recommended spellings.

## 7. Freeze the A6 touched surface

Determine the minimal successor scope after exact source inspection.

Expected likely scope:

- `tool/source/FORMAT.md`
- `tool/source/envelope/semantic.go`
- `tool/source/envelope/envelope_test.go`

But do not assume this is sufficient.

Report whether runner or CLI source must change because of schema registration,
strict decoding, output fields, or exit handling.

No implementation authorization is granted.

## 8. Freeze the causal test matrix

Define mandatory A6 tests for:

1. hundreds of absent→pass identities accepted without a name allowlist;
2. exact retention/reporting of those identities and hashes;
3. final-only fail blocked;
4. final-only test skip blocked;
5. final-only package abort blocked;
6. baseline pass→fail blocked;
7. baseline pass→skip blocked;
8. baseline pass disappearance blocked;
9. fail→pass admitted as improvement;
10. skip→pass admitted as improvement;
11. fail→skip blocked;
12. skip→fail blocked;
13. new panic/race/warning/malformed/unknown blocked;
14. HEAD and Repair 9 evaluated independently;
15. package-no-tests treatment exactly as frozen;
16. v1 historical record nonqualifying;
17. final/fresh and mutant comparison behavior unchanged;
18. removal of the compiled-in structural-privacy identity rule from active
    policy.

Include controls proving that:

- renaming a baseline test cannot be hidden as one disappearance plus one new
  pass;
- deleting a failing baseline test cannot be represented as improvement;
- adding arbitrary passing tests cannot hide a hazardous transition elsewhere;
- a final-only passing subtest is handled structurally, not by name prefix.

## 9. Required output

Return:

1. Opening and closing identities.
2. Exact current A4 mechanism, with path/line references.
3. HEAD→A5 transition matrix and canonical set hashes.
4. Repair-9→A5 transition matrix and canonical set hashes.
5. Package-terminal policy analysis.
6. Hazard-class analysis.
7. Model A/B/C comparison.
8. One recommended durable policy.
9. Exact v2 schema/result design.
10. Exact touched-file recommendation.
11. Exact causal test matrix.
12. B6 restart implications.
13. Inspection limits and unresolved evidence gaps.
14. Confirmation that no file, evidence child, cache, bytecode, or scratch
    artifact was created.

Verdict:

REPAIR10I_A6_RECONNAISSANCE_READY

Use instead:

REPAIR10I_A6_RECONNAISSANCE_BLOCKED

if the sealed material is insufficient to freeze a safe policy.

No implementation.
No A6 child.
No B6.
No snapshot.
No ZIP or handoff.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

The key correction is conceptual: **new passing coverage is evidence to report, not a regression exception requiring a name whitelist**. The whitelist model would turn every legitimate test addition into a successor-schema amendment and would still fail to represent tests newly reached after historical package aborts.

After the eventual A6 byte change, B6 must still restart from fresh controls. The sealed A2 report explicitly distinguishes a bounded successor causal from the required newly materialized downstream source control.  Repair bytes also require new validation, provenance, and a later fresh audit; previous audits do not remain binding after byte changes.  Provenance can bind the bytes but cannot establish that the comparator policy is correct or that its tests are sufficient. 

### Sources

- Codex’s `REPAIR10I_A6_DECLARATION_SET_MISMATCH` response supplied in this turn.
- Sealed Repair 10I-A2 restart boundary. 
- Governed Execution repair/re-audit protocol. 
- Governed Execution provenance limitations. 

**Confidence:** 0.999 that Codex stopped correctly; 0.995 that the finite identity-declaration model is invalid; 0.94 that structural absent→pass treatment is the correct durable direction; 0.86 on the exact package-terminal lattice until the retained package transitions are recovered; 0.995 that no implementation should begin before that policy is frozen.
