## Assessment

The parent source itself is now a strong freeze candidate. It compiled successfully, passed the noninteractive and finite-parent checks, routed child launches through the recorder, and satisfied 24 of 25 structural checks. The two reported blockers are defects in the **preflight checker**, not demonstrated defects in the source:

- The “no write after terminal manifest closure” check was not control-flow- or sink-aware. It scanned beyond the successful path and treated an `os.write` in a separate failure-only handler as a filesystem mutation. A corrected check must distinguish writes to stdout/stderr from filesystem writes and prove that a post-seal exception cannot enter a filesystem-writing handler.
- The line-1860 check used substring matching. The malformed historical expression naturally appears as a substring of the corrected expression ending in `else 0`. Successful compilation is the authoritative syntax check.

Do **not** reconstruct or edit the 167,291-byte candidate unless a corrected path-sensitive analysis finds a real defect. The next task should authenticate those exact bytes, run corrected independent structural checks, and freeze them for the eventual audit.

```text
EXACT-BYTE PARENT-AUDIT SOURCE QUALIFICATION AND FREEZE

This task qualifies and freezes one already-compiled parent-audit source.

It is not:

- a package audit;
- a source-authoring or rewrite task;
- a successor-package repair;
- a findings reconciliation;
- a V3 target audit;
- a repository or product audit.

Do not inspect or access any successor package, predecessor package, blocking
audit, launcher package, reconciliation package, candidate repository,
Strategic B, V1/V2/V3 target, product source, or unrelated evidence.

Do not use the network.
Do not run Git.
Do not run product or repository tests.
Do not create subagents.
Do not emit `AUDIT_EPOCH_START`.
Do not execute the parent source.

Return exactly one primary verdict:

PARENT_AUDIT_SOURCE_PREFLIGHT_READY
PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT HISTORICAL PREFLIGHT CAPSULE
──────────────────────────────────────────────────────────────────────────────

HISTORICAL_PREFLIGHT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-parent-audit-source-preflight-mot27ibm

Expected root identity:

- device/inode:
  16777234 / 179686447
- mode:
  0700
- historical verdict:
  PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED

Expected bootstrap record:

opening/bootstrap-start.json

- SHA-256:
  4189a8627aca5658450b95ebb9b351ca765bf666ff68f0dc9780282812f609a9

Expected temporal inventory:

closeout/temporal-final-inventory.json

- SHA-256:
  93e947e77eec371f0ed73e9b57305853fe8aa20c99e6ca4bb0d06b4bd4c41b5f

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  3539 each
- SHA-256:
  79d85e59ad98771a8eeba299ad6400ba4f7131c2197ae5b00ef7b900c1738f4b
- byte-identical:
  required
- represented entries:
  21
- self-exclusions:
  exactly the two manifests

Independently reproduce the manifest closure before using any contained source.

Capture a complete lstat/no-follow opening inventory.

Do not modify, clean, normalize, chmod, or resume this historical root.

──────────────────────────────────────────────────────────────────────────────
2. EXACT SOURCE CANDIDATE
──────────────────────────────────────────────────────────────────────────────

The exact candidate source is:

- size:
  167291
- SHA-256:
  c532092395cadf3517af22aab4275e1f05b0714abe39cf9fb3f7c33c5af2709e
- prior compilation:
  exit 0
- prior compiler stdout:
  empty
- prior compiler stderr:
  empty

Locate the source only through the authenticated historical manifest:

1. Select regular manifest entries whose size and SHA-256 equal the values
   above.
2. Require exactly one match.
3. Retain its exact relative path.
4. Open that exact path no-follow.
5. Require:
   - regular file;
   - single link;
   - mode 0600;
   - exact size;
   - exact SHA-256;
   - stable pre/post-read fstat identity.
6. Retain the exact source bytes as the sole source candidate.

Do not use:

- basename searching;
- filename scoring;
- content scoring;
- first viable candidate;
- recursive search outside the historical preflight root;
- fallback selection.

If there are zero or multiple exact matches, return
`PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED`.

──────────────────────────────────────────────────────────────────────────────
3. FRESH FREEZE-CAPSULE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-parent-audit-source-freeze-

Immediately emit:

FREEZE_ROOT=<absolute-path>

Before further work retain:

opening/bootstrap-start.json

containing:

- root path;
- device/inode/mode;
- uid/gid;
- parent identity;
- allocation method;
- umask;
- historical preflight root identity;
- supplied package roots inspected:
  [];
- audit epoch begun:
  false.

Create directories lazily. Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
4. EXACT-BYTE COPY — NO SOURCE EDITING
──────────────────────────────────────────────────────────────────────────────

Copy the exact candidate bytes to:

opening/source-candidate.py

Use:

- no-follow source read;
- exclusive destination creation;
- mode 0600;
- fsync;
- close;
- reopen no-follow;
- exact byte comparison;
- exact size/SHA-256 comparison.

The source bytes must remain:

- size:
  167291
- SHA-256:
  c532092395cadf3517af22aab4275e1f05b0714abe39cf9fb3f7c33c5af2709e

Source editing, normalization, formatting, regeneration, or patching is
forbidden in this task.

If any corrected structural check finds a real source defect, return
`PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED`. Do not repair it.

──────────────────────────────────────────────────────────────────────────────
5. AUTHORITATIVE COMPILATION GATE
──────────────────────────────────────────────────────────────────────────────

Compile `opening/source-candidate.py` without executing it using:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

with:

-I -S -B

Use an in-memory compile operation equivalent to:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B -c '
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
source = path.read_bytes()
compile(source, str(path), "exec", dont_inherit=True, optimize=0)
' opening/source-candidate.py

Do not use `py_compile`.
Do not create `.pyc`.
Do not create `__pycache__`.

Require:

- compiler exit 0;
- empty stdout;
- empty stderr;
- exact candidate bytes unchanged.

Successful complete compilation is authoritative for syntax validity.

Do not use substring matching to detect the old line-1860 defect.

Do not make traceback parsing acceptance-bearing.

Retain:

validation/source-compilation.json
validation/source-compilation.stdout
validation/source-compilation.stderr

──────────────────────────────────────────────────────────────────────────────
6. CORRECTED LINE-1860 ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

The historical malformed conditional expression lacked an `else` branch.

The prior checker falsely failed because it searched for the malformed text as
a substring of the corrected expression ending with `else 0`.

Use only syntax-aware adjudication:

1. Complete source compilation must pass.
2. Parse the source into an AST.
3. Require every `ast.IfExp` to contain:
   - `test`;
   - `body`;
   - `orelse`.
4. Retain the AST node corresponding to the corrected expression or its exact
   source span when deterministically identifiable.
5. Do not perform malformed-expression substring searching.

Record:

- historical defect:
  conditional expression missing `else`;
- current compilation:
  pass;
- incomplete `IfExp` nodes:
  0;
- result:
  corrected.

──────────────────────────────────────────────────────────────────────────────
7. CORRECTED NO-WRITE-AFTER-SEAL CHECK
──────────────────────────────────────────────────────────────────────────────

The prior checker falsely failed because it:

- scanned beyond the successful path;
- encountered a separate failure-only handler;
- treated an `os.write` call as a filesystem write without classifying its
  descriptor or reachability.

Implement a path-sensitive and sink-aware check.

A. Identify the successful terminal-seal path

Locate the exact successful control-flow path that:

1. finalizes all nonmanifest artifacts;
2. creates manifest A;
3. creates manifest B;
4. independently reproduces and compares both manifests;
5. emits the terminal success line;
6. terminates successfully.

Retain exact function names and source ranges.

B. Define filesystem writes

Filesystem writes include reachable operations that can create, replace,
truncate, append, rename, unlink, chmod, link, or otherwise mutate a path or
file-backed descriptor.

Examples include, when used for filesystem mutation:

- built-in `open` in write/append/update mode;
- `os.open` with write/create/truncate flags;
- `os.write` to a descriptor proven or unresolved as file-backed;
- `Path.write_*`;
- rename/replace/link/unlink/remove/rmdir/mkdir;
- copy/move;
- chmod/chown;
- fsync of a newly mutated file when part of a post-seal mutation.

C. Do not classify terminal streams as filesystem mutation

These are not filesystem writes when the descriptor is statically proven:

- `os.write(1, ...)`;
- `os.write(2, ...)`;
- `sys.stdout.write`;
- `sys.stderr.write`;
- terminal flush;
- process return;
- `sys.exit`;
- `os._exit`.

Retain the exact descriptor/stream classification.

An unresolved dynamic descriptor is not automatically allowed.

D. Analyze reachability

After manifest B reaches its authoritative final state, require that every
reachable successor operation on the successful path is limited to:

- in-memory verification;
- read-only observation;
- the terminal stdout line;
- bounded flush;
- process termination.

Require zero reachable filesystem mutation.

E. Analyze exception/failure reachability

Determine whether any exception after terminal manifest closure could enter a
handler that writes a filesystem failure record.

Require one of:

1. no catchable operation exists after closure except terminal stream output
   and immediate process termination; or
2. post-seal exceptions are handled without filesystem writes; or
3. the success path terminates through `os._exit` before a generic
   filesystem-writing failure handler can run.

If a filesystem-writing failure handler is reachable after successful seal,
return `PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED`.

Do not pass merely because the handler is defined outside `main`.

F. Independent second check

Use a second independently implemented checker with no shared traversal helper.

It may use:

- an independently constructed AST call graph;
- bytecode/control-flow disassembly;
- a separately implemented source-slice reachability analysis.

Both checks must agree.

Retain:

validation/postseal-write-check-a.json
validation/postseal-write-check-b.json
validation/postseal-write-reconciliation.json

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE 25-ITEM STRUCTURAL CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Re-run all 25 structural requirements against the exact candidate bytes.

At minimum require closed implementations for:

1. Fresh audit-root allocation.
2. Bootstrap-start retention.
3. Frozen audit-plan retention.
4. Child ENOENT and `/usr/bin/true` recorder causals.
5. Opening supplied-root inventory.
6. Manifest closure.
7. Strict `AUDIT_ROOT=` locator grammar.
8. Dynamic root attribution on zero and nonzero child exits.
9. Exact canonical materialization command.
10. Exact Carrier 0002 handoff command builder.
11. Producer validator command with `--package-root` and `--result`.
12. Package independent-validator command with `--package-root`, `--root-a`,
    `--root-b`, and `--result`.
13. Finding A allowed-reason sets and duplicate-token rejection.
14. Finding C allowed-reason sets.
15. Finding J `/cases` and `/case_names` parser.
16. Field-map `/families/*/fields/*` parser.
17. Qualification-result exact-shape parser.
18. Operation-aware security analysis.
19. Cleanup registry populated from validated dynamic locators.
20. Set equality:
    created = inventoried = cleanup rows = twice absent.
21. Supplied-root closing equality.
22. Truthful preseal gate.
23. Failure capsule path with no success caption.
24. Terminal manifests only after successful preseal.
25. No filesystem write after successful terminal manifest closure.

For every item retain:

- requirement;
- source function;
- exact line range;
- AST or control-flow evidence;
- pass/fail;
- first blocker;
- limits.

Require 25/25.

Do not convert structural presence into a future runtime-success claim.

──────────────────────────────────────────────────────────────────────────────
9. STATIC NONINTERACTIVE GATE
──────────────────────────────────────────────────────────────────────────────

Parse the exact candidate AST without executing it.

Reject reachable uses of:

- `input`;
- `sys.stdin.read`;
- `sys.stdin.readline`;
- iteration over `sys.stdin`;
- `code.interact`;
- `cmd.Cmd`;
- command sockets or pipes accepting phase instructions;
- persistent loops depending on later external input;
- administrative continuation entry points;
- replacement-parent launchers;
- supplied-root inspection at module import time;
- target-facing behavior at module import time.

Require:

- one finite top-level `main`;
- one finite ordered plan;
- one bounded success path;
- one bounded failure path;
- top-level catchable-failure handling;
- all supplied-root activity after the future audit epoch;
- all child launches routed through the recorder;
- no direct-auditor or subagent interface;
- no import-time audit execution.

Retain:

validation/final-static-preflight.json

──────────────────────────────────────────────────────────────────────────────
10. FREEZE THE EXACT SOURCE
──────────────────────────────────────────────────────────────────────────────

Only after:

- compilation passes;
- line-1860 AST adjudication passes;
- both postseal-write checks pass;
- all 25 structural items pass;
- static noninteractive gate passes;

install the exact same bytes at:

provenance/parent-source.py

Use:

- exclusive creation;
- mode 0600;
- fsync;
- close;
- reopen no-follow;
- exact byte comparison.

Retain:

opening/parent-source-freeze.json

with:

- source path;
- size;
- SHA-256;
- mode/link count;
- historical source path and identity;
- compilation-result identity;
- line-1860 adjudication identity;
- postseal-check identities;
- structural-crosswalk identity;
- static-preflight identity;
- source frozen:
  true;
- later modification allowed:
  false;
- supplied package roots inspected:
  [];
- audit epoch begun:
  false.

──────────────────────────────────────────────────────────────────────────────
11. FROZEN-BYTE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against `provenance/parent-source.py`:

1. Reopen no-follow and verify identity.
2. Compile again in memory.
3. Re-run line-1860 AST adjudication.
4. Re-run both independent postseal-write checks.
5. Re-run the complete 25-item structural crosswalk.
6. Re-run the static noninteractive gate.
7. Compare every result to the candidate-source result.

Require complete equality.

Retain:

validation/frozen-source-requalification.json

Any discrepancy requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit the frozen bytes.

──────────────────────────────────────────────────────────────────────────────
12. NO AUDIT EPOCH AND NO SOURCE EXECUTION
──────────────────────────────────────────────────────────────────────────────

Do not emit:

AUDIT_EPOCH_START

Do not execute `provenance/parent-source.py`.

Do not import it as a module.
Do not call `main`.
Do not allocate a future audit root through it.
Do not open any supplied package root.
Do not execute package validators, materializations, handoffs, causals, or
security scans.

This task ends after exact-byte freeze qualification.

──────────────────────────────────────────────────────────────────────────────
13. OPENING/CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat a complete lstat/no-follow inventory of the historical preflight root.

Require exact opening/closing equality.

The new freeze root may change only through this task’s own declared writes.

Do not modify or clean the historical preflight root.

──────────────────────────────────────────────────────────────────────────────
14. FREEZE-CAPSULE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before terminal sealing:

- bootstrap start;
- historical-root opening identity;
- source-selection record;
- copied candidate;
- compilation records;
- line-1860 adjudication;
- postseal checks A and B;
- postseal reconciliation;
- 25-item structural crosswalk;
- static preflight;
- frozen source;
- freeze record;
- frozen-source requalification;
- historical-root closing equality;
- final report;
- temporal final inventory.

Then create two independently generated terminal manifests.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files regular, single-link mode 0600;
- manifests byte-identical;
- no write after manifest closure.

──────────────────────────────────────────────────────────────────────────────
15. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

PARENT_AUDIT_SOURCE_PREFLIGHT_READY

only when:

- historical root authenticates and closes;
- exactly one candidate matches the fixed identity;
- candidate compiles;
- line-1860 AST adjudication passes;
- both independent postseal-write checks pass;
- all 25 structural items pass;
- static noninteractive gate passes;
- exact bytes are frozen;
- frozen-source requalification passes;
- historical-root closing equality passes;
- freeze capsule closes;
- no supplied package root was inspected;
- audit epoch did not begin;
- source was not executed.

Return:

PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED

when the exact candidate has a real structural or control-flow defect,
including a reachable postseal filesystem write.

Do not edit it.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- historical-root mutation;
- zero/multiple candidate selection;
- copied-source drift;
- frozen-source drift;
- preflight-root aliasing;
- frozen requalification mismatch;
- capsule closure failure;
- any supplied package-root inspection.

──────────────────────────────────────────────────────────────────────────────
16. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh freeze-root identity
3. Historical preflight-root identity and closure
4. Exact candidate relative path
5. Candidate identity
6. Source-selection method
7. Compilation result
8. Line-1860 AST adjudication
9. Postseal successful-path function and source range
10. Postseal allowed operations
11. Postseal filesystem-write sink inventory
12. Failure-handler reachability adjudication
13. Independent postseal check A
14. Independent postseal check B
15. Postseal check reconciliation
16. Complete 25-item structural crosswalk
17. Static noninteractive-gate result
18. Frozen parent-source identity
19. Parent-source freeze-record identity
20. Frozen-source compilation result
21. Frozen-source structural requalification
22. Historical-root closing equality
23. Freeze-capsule inventory and manifests
24. Confirmation audit epoch did not begin
25. Confirmation source was not executed
26. Remaining uncertainty and nonclaims
27. Explicit confirmations

Required confirmations:

HISTORICAL_PREFLIGHT_ROOT_MUTATION_NOT_PERFORMED
HISTORICAL_PREFLIGHT_ROOT_NOT_RESUMED
EXACTLY_ONE_SOURCE_CANDIDATE_SELECTED
SOURCE_SELECTION_USED_EXACT_MANIFEST_IDENTITY
FILENAME_SCORING_NOT_USED
CONTENT_SCORING_NOT_USED
FALLBACK_NOT_USED
SOURCE_BYTES_NOT_EDITED
SOURCE_NORMALIZATION_NOT_PERFORMED
SOURCE_COMPILATION_PASSED
COMPILER_STDERR_EMPTY
TRACEBACK_PARSER_NOT_ACCEPTANCE_BEARING
LINE_1860_SYNTAX_DEFECT_ABSENT_BY_AST
INCOMPLETE_IFEXP_COUNT_ZERO
POSTSEAL_CHECK_PATH_SENSITIVE
POSTSEAL_CHECK_SINK_AWARE
STDOUT_STDERR_WRITES_NOT_MISCLASSIFIED_AS_FILESYSTEM_WRITES
POSTSEAL_FAILURE_HANDLER_REACHABILITY_ADJUDICATED
POSTSEAL_FILESYSTEM_WRITE_ABSENT
INDEPENDENT_POSTSEAL_CHECKS_AGREE
ALL_25_STRUCTURAL_ITEMS_PASSED
STATIC_NONINTERACTIVE_GATE_PASSED
PARENT_STDIN_NOT_READ
PERSISTENT_INPUT_LOOP_NOT_USED
ADMINISTRATIVE_CONTINUATION_ENTRY_ABSENT
SUPPLIED_ROOT_ACCESS_AT_IMPORT_TIME_ABSENT
TARGET_FACING_IMPORT_TIME_BEHAVIOR_ABSENT
CHILD_LAUNCHES_ROUTED_THROUGH_RECORDER
FINAL_PARENT_SOURCE_FROZEN
FINAL_PARENT_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_SOURCE_RECOMPILE_PASSED
FROZEN_SOURCE_REQUALIFICATION_PASSED
AUDIT_EPOCH_NOT_STARTED
FROZEN_PARENT_SOURCE_NOT_EXECUTED
NO_SUPPLIED_PACKAGE_ROOT_INSPECTED
NO_SUPPLIED_PACKAGE_ROOT_MUTATED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS_CREATED
```

After `PARENT_AUDIT_SOURCE_PREFLIGHT_READY`, the next audit must execute the
exact frozen `provenance/parent-source.py` bytes from this freeze capsule.
It must not regenerate or edit the parent source.
```

**Source:** Codex’s latest `PARENT_AUDIT_SOURCE_PREFLIGHT_BLOCKED` report.  
**Confidence:** 0.995 that the retained 167,291-byte source is ready for exact-byte freeze qualification; 0.99 that both reported blockers are checker defects; 0.96 that path-sensitive failure-handler analysis is the only remaining meaningful static risk before freezing.
