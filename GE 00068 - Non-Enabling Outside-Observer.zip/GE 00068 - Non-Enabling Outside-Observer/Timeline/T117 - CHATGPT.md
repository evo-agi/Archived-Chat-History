## Assessment

Codex stopped correctly. The required comparison was impossible because the retained blocked closeout recorded the 13-path scope but not the 13 per-file hashes.

This is an **evidence-coverage gap**, not demonstrated repository drift:

- The path set, classifications, modes, branch, HEAD, and verifier source hash still match.
- No differing file byte has been identified.
- The prior partial validation cannot be claimed to bind the other twelve current files.
- It also does not need to: the complete validation program was already required to restart after the mode correction.

The safe continuation is to establish the **current live 13-file patch as a new exact implementation baseline before any further edit**, explicitly discard the prior partial validation as nonqualifying, apply the bounded mode correction, and rerun every validation gate from the beginning.

This is not `PROVENANCE_BASELINE_READY` in the narrow guidance sense, because equality to a prior per-file manifest cannot be shown. It is an authorized **implementation re-baseline**. The final audit will bind to the later final provenance, not to the incomplete blocked-attempt record.

That keeps the external verifier architecture unchanged: the committed tool remains the selected non-recursive design, with exact source supplied to a fresh audit before its first commit.  It also preserves the MVP rule that proof scaffolding and generated evidence do not become architecture or authority. 

## Codex continuation prompt

```text
Permission remains workspace-write.

Continue in the same foreground Codex implementation conversation and the same
clean implementation worktree.

The preceding stop is accepted:

EVIDENCE_VERIFICATION_V1_CONTINUATION_BASELINE_MISMATCH

The impossible baseline condition is now explicitly superseded.

The retained blocked closeout proves the expected 13-path scope and selected
identities, but it does not contain per-file hashes for all 13 paths.
Therefore:

- do not claim that the current bytes of all 13 files equal the exact bytes at
  the prior blocked attempt;
- do not require that unprovable equality;
- preserve the prior attempt and all of its validation output as historical,
  nonqualifying, and superseded;
- establish the current live 13-file patch as a new exact continuation
  baseline before any edit;
- apply the already frozen amendment-layout mode correction;
- rerun the complete validation program from the beginning;
- generate final provenance only after all fresh validation passes.

This is an implementation re-baseline, not an audit reconciliation and not a
claim that prior validation binds current bytes.

Do not create another worktree.
Do not reset, restore, clean, or discard the current patch.
Do not overwrite or delete any prior evidence record.
Do not modify the Repair 10I candidate.
Do not modify either sealed evidence child.
Do not stage, commit, push, create a PR, install, deploy, restart A6, invoke a
live route, contact a network, or perform an independent audit.

No subagents. You remain the sole writer.

## 1. Paths

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Implementation branch:

codex/evidence-verification-v1

Implementation evidence root:

EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Forbidden primary checkout as implementation cwd/source root:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Required new continuation evidence directory:

CONTINUATION=$EVIDENCE/continuation-v2

Require CONTINUATION to be absent before creation.

## 2. Mandatory current-state gate

Before creating CONTINUATION or editing any repository file, require IMPL_R:

- physical root equals lexical root;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- exactly 13 changed or untracked repository paths;
- exactly four modified tracked paths;
- exactly nine untracked added paths;
- all 13 are regular files;
- all 13 have working-tree mode `0644` and logical Git mode `100644`;
- nothing staged, deleted, renamed, or unmerged;
- no path outside the authorized set;
- no unsupported file type;
- no Git operation marker or lock.

Exact authorized paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Require current verifier source:

- path:
  `tools/evidence_verify/verify_v1.py`
- SHA-256:
  `63b79cc7781db7e7ba78b8d1321e33785f896156813105733c7e01cd23dd1f27`

Require the retained blocked-attempt evidence to remain present and unchanged,
including:

- `EVIDENCE/closeout/validation-blocked-v1.json`;
- prior raw stdout and stderr;
- prior test records;
- the real amendment compatibility failure.

The blocked closeout may be used to verify:

- expected path set;
- tracked/untracked classifications where recorded;
- branch and HEAD;
- verifier source SHA-256;
- the reported validation failure.

It must not be represented as proof of the other twelve prior file hashes.

Require CANDIDATE_R to remain exact:

- physical device/inode:
  `16777234/122118502`;
- branch:
  `codex/remote-alpha-external-tls-status-observation-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- upstream:
  absent;
- index SHA-256:
  `012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31`;
- source T:
  `8de797304ea944b6a155924e0d1e9e8bbe79534e`;
- inventory:
  `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`;
- membership:
  `389 / 375 / 14`;
- staged/deleted/renamed/unmerged:
  `0/0/0/0`.

Require A6D manifest unchanged:

`dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`

Require A6D_AMEND manifest unchanged:

`a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`

Stop on any demonstrated mismatch:

EVIDENCE_VERIFICATION_V1_CONTINUATION_REBASELINE_BLOCKED

## 3. Establish a new exact continuation baseline

After section 2 passes, create CONTINUATION under umask `077` with:

- `opening/`
- `validation/`
- `provenance/`
- `closeout/`

All directories mode `0700`.
All files regular and single-link.
No hardlinks or symlinks.

Create one source-external deterministic baseline recipe:

`CONTINUATION/opening/capture-continuation-baseline-v1.py`

The recipe source must:

- use Python standard library only;
- receive or require IMPL_R explicitly;
- set deterministic locale;
- use explicitly rooted Git commands;
- handle absent upstream as JSON `null`;
- enumerate exactly tracked modifications and untracked additions;
- reject deletions, renames, staged paths, unsupported file types, and paths
  outside the authorized 13-path set;
- classify each path as:
  - `tracked_modified`; or
  - `untracked`;
- record for every path:
  - repo-relative path;
  - classification;
  - file type;
  - logical mode;
  - byte size;
  - complete SHA-256;
- record:
  - schema;
  - recipe ID;
  - branch;
  - HEAD;
  - upstream;
  - complete sorted file array;
  - deterministic tracked binary-diff SHA-256;
- sort paths by raw UTF-8 bytes;
- use compact sorted-key canonical JSON plus one LF;
- contain no timestamp, random value, hostname, username, or absolute path;
- write only beneath CONTINUATION.

Use a stable recipe ID:

`execution-substrate.evidence-verification-v1.continuation-baseline.v1`

Run the exact recipe twice before any edit.

Require:

- byte-identical canonical outputs;
- exact 13-path set;
- exactly four `tracked_modified`;
- exactly nine `untracked`;
- zero path outside scope;
- all regular;
- all logical mode `100644`;
- current verifier SHA-256 matches the required value;
- tracked binary-diff digest stable.

Retain:

- exact recipe source;
- recipe source SHA-256;
- both complete outputs;
- canonical baseline SHA-256;
- tracked binary-diff SHA-256.

Create:

`CONTINUATION/opening/continuation-baseline-adjudication-v1.json`

It must state exactly:

- `prior_attempt_path_scope_verified=true`;
- `prior_attempt_complete_per_file_identity_available=false`;
- `prior_attempt_byte_continuity_for_all_files_claimed=false`;
- `prior_partial_validation_qualifies_current_bytes=false`;
- `current_live_patch_exactly_captured=true`;
- `fresh_complete_validation_required=true`;
- `baseline_source=live-working-tree-before-continuation-edit`;
- the recipe and canonical-output identities.

This is the only authorized re-baseline.

Do not use the project verdict `PROVENANCE_BASELINE_READY`, because prior
per-file equality has not been established.

Stop on unstable output or unexpected state:

EVIDENCE_VERIFICATION_V1_CONTINUATION_REBASELINE_BLOCKED

## 4. Prior validation disposition

Before editing, add a source-external record:

`CONTINUATION/opening/prior-validation-disposition-v1.json`

Classify every prior implementation validation record as:

- retained;
- historical;
- nonqualifying for final implementation bytes;
- superseded by the required fresh validation restart.

Specifically:

- the prior 30-case passing test run remains useful diagnostic evidence;
- the prior real A6D success remains useful diagnostic evidence;
- the prior real amendment failure remains the defect reproduction;
- none substitutes for the fresh postrepair validation required below.

Do not delete or overwrite the prior records.

## 5. Exact defect repair

Apply the already frozen mode-contract correction.

Affected target:

`execution-substrate.repair10i.a6d-amendment-layout/v1`

Mechanism:

- two required executable helper-source paths were misclassified as fixed
  evidence records at mode `0600`;
- historical sealed truth records both as regular single-link mode `0700`
  files.

Exact required executable helper paths:

- `tool/corrected/verify-closing-v1.py`
- `tool/corrected/verify-postseal-v1.py`

For those two paths only, require exact mode `0700`.

Fixed JSON, Markdown, text, report, index, and closeout records remain exact
mode `0600`.

Do not add:

- wildcard executable modes;
- caller-selected modes;
- mode alternatives;
- executable optional-subtree defaults;
- another layout;
- another registry schema;
- another verifier version;
- another repository path.

Inspect whether the existing required-file spec model already supports exact
per-file modes.

### If supported

Keep `verify_v1.py` byte-identical and modify only the existing authorized
spec, registry entry, docs, and tests necessary for the correction.

### If not supported

A minimal edit to the already authorized `verify_v1.py` is permitted only to
implement exact per-required-file modes already frozen by the architecture
decision.

If the repair cannot remain inside the existing 13 paths and closed spec
schema, stop:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

## 6. Registry and documentation

After changing `a6d_amendment_v1.json`:

- canonicalize it under the existing strict encoding;
- recompute its complete SHA-256;
- update only its registry entry unless another authorized file genuinely
  changed;
- preserve the other layout IDs and filenames;
- require registry/spec embedded ID and digest consistency.

Update the governing docs only as necessary to make explicit:

- required executable helper source may be exact mode `0700`;
- fixed evidence records remain exact mode `0600`;
- executable mode is admitted only for explicitly enumerated audited paths;
- no wildcard or optional-subtree executable authority exists.

Remain inside the four already authorized modified documentation files and the
already authorized new evidence-verification page.

## 7. Mandatory mode tests

Add exact coverage for:

1. Historical amendment fixture with the two exact helpers at `0700` passes.
2. `verify-closing-v1.py` changed to `0600` rejects.
3. `verify-postseal-v1.py` changed to `0600` rejects.
4. Either helper at `0644` rejects.
5. Either helper at `0755` rejects.
6. Either helper at another mode rejects.
7. Unrelated fixed JSON record changed from `0600` to `0700` rejects.
8. Unrelated Markdown/report record changed from `0600` to `0700` rejects.
9. Unenumerated executable-mode file rejects.
10. Optional subtree does not acquire executable authority by implication.
11. A6D successor layout remains unchanged.
12. A6 policy layout remains unchanged.
13. Registry/spec hash mismatch rejects.

Do not weaken an existing test.

## 8. Complete fresh validation restart

Rerun the entire implementation validation program from the beginning after
the repair.

Do not cite a prior pass as a substitute.

Use the exact pinned Python 3.13 identity and deterministic environment.

Required gates:

1. Parse all Python source through `ast.parse`, creating no bytecode.
2. Strictly parse registry and all three specs.
3. Run the complete test command.
4. Run the complete test command a second time.
5. Require equivalent outcomes across both runs.
6. Run every one of the original 30 frozen causal cases.
7. Run every new exact-mode regression.
8. Run sealed A6D verification twice.
9. Require:
   - exit `0` twice;
   - byte-identical canonical stdout;
   - unchanged target and verifier-package snapshots.
10. Run sealed A6D amendment verification twice.
11. Require:
   - exit `0` twice;
   - byte-identical canonical stdout;
   - both corrected helpers accepted at exact mode `0700`;
   - fixed records retained at exact declared mode `0600`;
   - unchanged target and verifier-package snapshots.
12. Run synthetic A6 pre-seal verification twice.
13. Seal the synthetic A6 fixture using the test-owned fixture writer.
14. Run synthetic A6 sealed verification twice.
15. Require byte-identical repeated outputs.
16. Verify historical defect fixtures retain exact original bytes and hashes.
17. Verify the verifier performs zero target, package, cwd, cache, temporary,
    or repository writes.
18. Run `git diff --check`.

Every validation fixture/root must be removed after its owning check.

No Go suite.
No network.
No product process.
No child process from the verifier.
No write to a real sealed input.

## 9. Evidence continuation

Preserve all earlier EVIDENCE records.

Write fresh continuation records only beneath CONTINUATION.

Retain:

- exact current baseline recipe and outputs;
- prior-validation disposition;
- defect adjudication;
- pre-repair and postrepair bytes/hashes for every changed authorized path;
- exact fresh validation argv, cwd, safe environment, exit, stdout, stderr;
- repeated test outcomes;
- all original and new causal outcomes;
- both real-child repeated checks;
- no-write snapshots;
- failed/superseded attempt index;
- final implementation report inputs.

Do not overwrite:

- `EVIDENCE/closeout/validation-blocked-v1.json`;
- any prior raw output;
- the original amendment rejection.

## 10. Final provenance

Only after all fresh validation passes, create the final deterministic
implementation provenance recipe required by the original tranche.

The final recipe is separate from the continuation-baseline recipe.

Retain its complete source bytes.

It must:

- bind IMPL_R explicitly;
- record branch, HEAD, and absent upstream;
- enumerate tracked modifications and untracked additions;
- include exact classification, type, logical mode, size, and SHA-256;
- include deterministic tracked binary-diff SHA-256;
- use canonical sorted compact JSON plus LF;
- include no timestamp, randomness, hostname, username, or machine-specific
  absolute path;
- write only under CONTINUATION/provenance or EVIDENCE/provenance;
- run twice;
- produce byte-identical complete output.

Require final provenance:

- exactly 13 paths;
- exactly four modified tracked paths;
- exactly nine untracked additions;
- zero staged;
- zero deletion;
- zero rename;
- zero unsupported type;
- no path outside scope.

Retain:

- recipe ID;
- complete recipe source;
- recipe source SHA-256;
- both outputs;
- tracked binary-diff SHA-256;
- canonical patch-manifest SHA-256;
- complete canonical manifest.

## 11. Closeout

Require final IMPL_R:

- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- upstream:
  absent;
- exactly 13 changed/untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked added paths;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- zero path outside scope;
- `git diff --check` clean;
- no `__pycache__`, `.pyc`, `.pytest_cache`, database, journal, lock,
  generated repository manifest, retained fixture root, or temporary output.

Require CANDIDATE_R closing identity equals opening identity exactly.

Require A6D and A6D_AMEND remain byte-exact.

Require PRIMARY_R was never an implementation cwd or source root.

Do not remove IMPL_R or EVIDENCE.

## 12. Verdicts

Current-state or re-baseline failure:

EVIDENCE_VERIFICATION_V1_CONTINUATION_REBASELINE_BLOCKED

Scope expansion:

EVIDENCE_VERIFICATION_V1_SCOPE_EXPANSION_REQUIRED

Fresh validation failure:

EVIDENCE_VERIFICATION_V1_VALIDATION_BLOCKED

Final provenance failure:

EVIDENCE_VERIFICATION_V1_PROVENANCE_BLOCKED

Complete success:

EVIDENCE_VERIFICATION_V1_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

## 13. Required success report

Include:

1. Candidate opening/closing identity.
2. Implementation worktree identity.
3. Explanation that the prior record lacked complete per-file hashes.
4. Explicit nonclaim of prior 13-file byte continuity.
5. Continuation-baseline recipe ID and source SHA-256.
6. Continuation-baseline canonical SHA-256.
7. Complete pre-repair 13-file baseline or safe reference.
8. Prior-validation supersession.
9. Exact mode-contract correction.
10. Exact files changed during continuation.
11. Whether `verify_v1.py` changed and why.
12. Final verifier source SHA-256.
13. Final registry SHA-256.
14. All layout IDs and final spec SHA-256 values.
15. Exact two required mode-`0700` helper paths.
16. Confirmation fixed records remain `0600`.
17. Complete fresh test results from both full runs.
18. All original 30 causals and new mode regressions.
19. Real A6D checks, both runs.
20. Real amendment checks, both runs.
21. Synthetic A6 pre-seal and sealed checks.
22. No-write and deterministic-output evidence.
23. Python interpreter identity.
24. Final 13-path delta and classifications.
25. Final provenance recipe ID and complete source SHA-256.
26. Tracked binary-diff SHA-256.
27. Canonical patch-manifest SHA-256.
28. Complete final canonical manifest or safe reference.
29. Artifact hygiene.
30. Authority/security widening:
    explicitly none, or exact contrary finding.
31. Remaining uncertainty.
32. Confirmation:
    - independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product tests and live services not invoked.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
No product A/B.
No snapshot or deployment.
```

## Why this is the right correction

The deterministic recipe requirement exists to bind the eventual audit to exact tracked **and untracked** bytes, including type, mode, size, and SHA-256; it does not require an unavailable historical fingerprint before implementation can continue, provided the current bytes are explicitly re-baselined and the affected validation is rerun completely. 

Implementation validation may repair patch-caused failures in the same parent-only tranche, but the final bytes then require fresh exact provenance and a later independent audit in a separate read-only conversation.  Any later byte change after audit would return the patch to implementation and re-audit. 

### Sources

- Codex’s `EVIDENCE_VERIFICATION_V1_CONTINUATION_BASELINE_MISMATCH` report supplied in this turn.
- Frozen non-recursive evidence-verifier architecture. 
- MVP proof-scaffolding/non-authority boundary. 
- Implementation versus independent-audit separation. 
- Deterministic provenance requirements and exact recipe-source retention. 

**Confidence**

- Correctness of Codex’s stop under the prior prompt: **0.999**
- Evidence of actual implementation-byte drift: **none demonstrated**
- Confidence that an explicit live-byte re-baseline plus full validation restart is safe: **0.97**
- Confidence that prior partial validation must be treated as superseded: **0.999**
- Confidence that final provenance and a fresh independent audit remain mandatory: **0.999**
