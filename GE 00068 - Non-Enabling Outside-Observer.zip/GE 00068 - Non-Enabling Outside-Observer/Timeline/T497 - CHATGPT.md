## Engineering assessment

The authority-chain adjudication resolved the ambiguity cleanly: the prior wrapper’s **filename-specific** reasoning was too narrow, but its **nonlaunch outcome was correct**.

The exact PYZ is structurally sound. Its 93-member registry matches the archive exactly; member ordering, ZIP grammar, modes, timestamps, and safety posture all pass. The external authority JSON binds the exact PYZ, source freeze, general qualification result, member registry, and runtime governing records. :chatgpt-content-reference{index="0"}

The blocker is semantic rather than nominal. The bound `qualification-result-v1.json` proves the matrix identities and exact `15/595` aggregate, plus aggregate claims for custody, synthetic lanes, replay, rehearsals, and independent validators. But it does **not** bind several indispensable post-packaging facts:

- exact final PYZ identity;
- exact source-freeze identity;
- deterministic final PYZ Build-A/Build-B equality;
- exact final member closure;
- final authority-JSON coherence;
- byte-identical rehearsal PYZs;
- complete post-freeze requalification semantics. :chatgpt-content-reference{index="1"}

Codex therefore correctly classified the bound record as `GENERAL_QUALIFICATION_ONLY`, not frozen-PYZ requalification. The sealed package contract permits a transitive authority chain in principle, but the present chain lacks the terminal edge proving that the **externally bound final PYZ bytes** passed post-package requalification and final authority reconciliation. :chatgpt-content-reference{index="2"}

This is not a harness source defect. It is an **external launch-authority packaging defect**:

- harness source repair required: **false**;
- PYZ byte change required: **false**, unless fresh qualification disproves it;
- implementation package remains unaudited;
- no process, preflight, audit root, package finding, or verdict was produced. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

### Progression decision

Create a fresh **external harness authority v2** around the unchanged PYZ.

The task should:

1. authenticate the unchanged PYZ, predecessor authority v1, bundle, and bundle authority;
2. run platform-capture preflight;
3. execute `qualify-harness` exactly once using the exact frozen CLI contract;
4. bind the qualification result to the exact executed PYZ through platform custody;
5. independently recompute the post-package facts omitted from the old qualification result;
6. create one self-contained authority-v2 JSON with:
   - fresh qualification process custody;
   - full fresh result;
   - exact source-freeze binding;
   - exact member closure;
   - deterministic package evidence;
   - rehearsal and independent-validator linkage;
   - final cross-document reconciliation;
   - future invocation and one-audit authorization;
7. leave the PYZ and authority v1 untouched;
8. not execute the real audit in the same tranche.

After authority v2 succeeds, the next task should run exactly one fresh audit using the unchanged PYZ and the new authority v2.

---

## Complete replacement Codex prompt

```text
CREATE A FRESH EXTERNAL HARNESS AUTHORITY V2 FOR THE UNCHANGED
GENERATION-2 CLEAN SOURCE-EXTERNAL INDEPENDENT-AUDIT HARNESS

FRESH QUALIFY-HARNESS EXECUTION AND POST-PACKAGE RECONCILIATION

Objective

Create a new external authority-v2 JSON for the existing, unchanged harness
PYZ.

The current authority-v1 JSON correctly binds the PYZ, source freeze, member
registry, and a general qualification result, but it does not bind complete
post-package frozen-PYZ requalification and final cross-document
reconciliation semantics.

This task must:

1. authenticate the unchanged PYZ and all current file-level inputs;
2. run one platform-capture preflight;
3. execute the unchanged PYZ in `qualify-harness` mode exactly once;
4. retain complete top-level process custody and raw streams;
5. bind that fresh result to the exact executed final PYZ;
6. independently recompute all required post-package qualification facts;
7. generate a self-contained external authority-v2 JSON;
8. independently validate that authority-v2 JSON;
9. leave the PYZ and all existing authority files unchanged;
10. not execute `run-full-audit`.

Do not repair or rebuild harness source.

Do not modify or repackage the PYZ.

Do not create a new PYZ.

Do not modify authority v1.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the current schema subject.

Do not execute the real full independent audit.

Do not open any original contaminated package directory.

Do not open any historical harness, verifier, builder, repair, or audit root.

Do not perform another historical findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or start A6.

Use one finite parent-owned authority-generation process in one fresh private
working root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_CREATED_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_BLOCKED

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT FIXED INPUT FILES
──────────────────────────────────────────────────────────────────────────────

UNCHANGED_HARNESS_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-attempt2-qw4sqw4r/gen2-clean-source-external-independent-audit-harness-v1.pyz

Expected identity:

- device:
  16777234
- inode:
  181950905
- mode:
  0400
- link count:
  1
- size:
  1442390
- SHA-256:
  19496183b8eb3e7545f9ebda8f966a41839ad67251239d5be2ba801d84cb0174

PREDECESSOR_HARNESS_AUTHORITY_V1:

/Users/ds/Downloads/ES-repair10i-v3-gen2-clean-independent-audit-harness-corrected-input-output-attempt2-qw4sqw4r/gen2-clean-source-external-independent-audit-harness-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181950910
- mode:
  0400
- link count:
  1
- size:
  14748
- SHA-256:
  6c39b301198727e7a152e27c5d3db0e3bf53b3b45b4ae6deabd955c74cc067ae

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

The two containing directories are nonauthoritative.

Do not inspect or depend on any other directory member.

──────────────────────────────────────────────────────────────────────────────
2. STABLE INPUT AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

For all four files:

1. open no-follow;
2. require regular file;
3. require link count one;
4. require mode 0400;
5. retain device, inode, size, and SHA-256;
6. perform two stable reads;
7. require byte equality.

Strict-parse both authority JSON files:

- UTF-8;
- duplicate-key rejection;
- nonfinite-value rejection.

Any mismatch:

- do not launch any process;
- return:
  GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_PROVENANCE_MISMATCH.

──────────────────────────────────────────────────────────────────────────────
3. FRESH AUTHORITY-BUILD ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate one private working root beneath `/private/tmp` using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-clean-harness-external-authority-v2-build-

Immediately emit:

AUTHORITY_BUILD_ROOT=<absolute-path>

Allocate one private final-output directory beneath `/Users/ds/Downloads`
using:

- tempfile.mkdtemp;
- umask 077;
- prefix:

ES-repair10i-v3-clean-harness-external-authority-v2-output-

Immediately emit:

AUTHORITY_OUTPUT_ROOT=<absolute-path>

The build root is temporary.

The output directory is nonauthoritative.

The sole successful authority-bearing output is:

gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json

Before process launch retain:

opening/bootstrap-start.json
opening/authority-v2-generation-authority-v1.json
opening/fixed-input-file-registry-v1.json
opening/predecessor-authority-v1-disposition-v1.json
opening/process-execution-policy-v1.json

Bind:

- PYZ modification:
  forbidden;
- authority-v1 modification:
  forbidden;
- source repair:
  forbidden;
- PYZ rebuild:
  forbidden;
- run-full-audit:
  forbidden;
- implementation verdict:
  forbidden;
- current-subject construction:
  forbidden;
- same-root retry:
  false.

──────────────────────────────────────────────────────────────────────────────
4. PREDECESSOR-AUTHORITY DISPOSITION
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/predecessor-authority-v1-disposition-v1.json

Authenticate these predecessor facts:

- exact PYZ identity bound;
- exact PYZ member count:
  93;
- source-freeze identity bound;
- general qualification-result identity bound;
- exact member-registry identity bound;
- exact future run-full-audit invocation bound;
- full real audit executed:
  false;
- implementation verdict:
  not issued.

Retain the exact predecessor limitation:

- general qualification result does not bind the exact final PYZ;
- no complete external post-package frozen-PYZ requalification binding;
- no complete external final cross-document reconciliation binding.

Classify authority v1 as:

historical_predecessor_launch_authority_incomplete

It remains:

- immutable;
- valid historical evidence;
- noncurrent for future launch after authority v2 succeeds.

Do not call authority v1 false or corrupt.

──────────────────────────────────────────────────────────────────────────────
5. EXACT PYZ MEMBER CLOSURE
──────────────────────────────────────────────────────────────────────────────

Parse the unchanged PYZ directly.

Require:

- exactly 93 members;
- registry/archive member equality;
- raw UTF-8 byte sorting;
- ZIP_STORED only;
- fixed timestamp;
- create_system 3;
- fixed member modes;
- no duplicates;
- no unsafe names;
- no directory members;
- no symlinks;
- no special members;
- no comments;
- no uncontrolled extra fields;
- no cache or bytecode.

Resolve current embedded roles only through the exact embedded member registry.

Retain:

validation/unchanged-pyz-member-closure-v1.json

At minimum resolve exact identities for:

- `__main__.py`;
- final source-freeze record;
- production source registry;
- qualification source registry;
- independent source registry;
- package member registry;
- package status;
- qualification result;
- five-domain contract;
- 66-row runtime report registry;
- 81-name runtime confirmation registry;
- 15/595 runtime matrix registry;
- aggregate owner/consumer registry;
- future invocation;
- matrix results;
- process-custody qualification;
- synthetic lane results;
- compatibility replay;
- rehearsal A;
- rehearsal B;
- rehearsal comparison;
- independent validator results;
- cleanup result;
- input closing equality;
- runtime report;
- runtime confirmations.

Unknown or multiply occupied roles fail closed.

──────────────────────────────────────────────────────────────────────────────
6. DERIVE EXACT QUALIFY-HARNESS INVOCATION
──────────────────────────────────────────────────────────────────────────────

Derive the exact `qualify-harness` invocation only from:

- embedded CLI contract;
- `__main__.py`;
- package status;
- predecessor authority v1;
- future invocation contract where applicable.

Do not guess an option.

Do not infer from an earlier prompt.

Permitted result:

- exact invocation uses only:
  - unchanged PYZ;
  - current-authority bundle;
  - current-authority JSON;

or:

- the exact embedded CLI contract requires one additional current fixed input.

If an additional fixed input is required:

- it must be explicitly identified by exact embedded contract path and
  identity;
- do not search for it;
- do not infer a path;
- if its exact current identity is not already bound by the four fixed inputs,
  return:
  GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_BLOCKED;
- state the missing exact input;
- do not launch.

Retain:

contract/fresh-qualify-harness-invocation-v1.json

The invocation must use:

- pinned Python 3.13;
- `-I -S -B`;
- exact unchanged PYZ path;
- `--mode qualify-harness`;
- exact required input operands;
- no extra operand.

──────────────────────────────────────────────────────────────────────────────
7. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────────────────────────────────────

Before `qualify-harness`, run exactly one harmless synchronous preflight.

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

The program must:

- write exactly:
  `PLATFORM_CAPTURE_STDOUT_V1\n`
  to stdout;
- write exactly:
  `PLATFORM_CAPTURE_STDERR_V1\n`
  to stderr;
- exit exactly:
  23;
- read no stdin;
- create no file;
- create no child.

Environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Require capture of:

- exact argv;
- exact cwd;
- exact environment;
- PID;
- start/completion;
- duration;
- stdout bytes;
- stderr bytes;
- exit code:
  23;
- signal:
  null;
- reaping;
- descriptor closure.

Expected stdout:

- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

If any preflight condition fails:

- do not launch `qualify-harness`;
- return:
  GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_PROVENANCE_MISMATCH;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
8. EXECUTE QUALIFY-HARNESS EXACTLY ONCE
──────────────────────────────────────────────────────────────────────────────

After Sections 2–7 pass, execute the exact invocation derived in Section 6.

Use exact environment:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Run synchronously in the foreground.

Use the cwd bound by the exact CLI/package contract.

If no cwd is bound, use the directory containing the unchanged PYZ and retain
that choice as platform-wrapper custody with no qualification-authority effect.

Launch count:

exactly one.

Do not execute:

- `run-full-audit`;
- a replacement qualifier;
- a recovery process;
- a direct package auditor;
- a source compiler outside the PYZ;
- a second qualification run.

──────────────────────────────────────────────────────────────────────────────
9. FRESH QUALIFICATION PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

Retain before interpreting output:

- custody ID;
- PID;
- start/completion;
- duration;
- exact argv;
- exact cwd;
- exact environment;
- stdin/shell/TTY/detachment;
- raw stdout bytes;
- raw stderr bytes;
- stdout size and SHA-256;
- stderr size and SHA-256;
- exit code;
- signal;
- process error or null;
- reaping;
- descriptor closure;
- executable file identity at launch;
- bundle and bundle-authority identities at launch.

The platform record, prelaunch PYZ identity, and exact argv together must bind
the fresh qualification result to the exact unchanged final PYZ.

Missing completion custody is:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_PROVENANCE_MISMATCH

Do not retry.

──────────────────────────────────────────────────────────────────────────────
10. QUALIFICATION OUTPUT PARSING
──────────────────────────────────────────────────────────────────────────────

Retain raw streams before parsing.

Strictly parse according to the exact embedded `qualify-harness` output
contract.

Require:

- exact expected framing;
- no progress chatter;
- no duplicate terminal record;
- no trailing unframed bytes;
- handled-result stderr posture;
- strict UTF-8 JSON;
- duplicate-key rejection;
- nonfinite rejection;
- exact schema.

If qualification emits a root locator:

- use only that exact unique locator;
- do not scan;
- retain its identity;
- inspect it read-only;
- retain complete evidence before cleanup.

If no root is part of the contract:

- do not require one.

Retain:

validation/fresh-qualify-harness-process-result-v1.json

Require overall fresh qualification pass.

A substantive qualification failure returns:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_BLOCKED

unless the failure is a provenance failure.

──────────────────────────────────────────────────────────────────────────────
11. FRESH FROZEN-PYZ REQUALIFICATION CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Independently crosswalk the fresh result and exact embedded evidence.

Retain:

validation/fresh-frozen-pyz-requalification-crosswalk-v1.json

Require proof of all these facts:

1. exact executed PYZ identity;
2. exact 93-member closure;
3. exact source-freeze identity;
4. no post-freeze source modification;
5. exact production source registry;
6. exact qualification source registry;
7. exact independent source registry;
8. exact input bundle identity;
9. exact input-authority identity;
10. exact embedded five-domain contract;
11. exact runtime report registry:
    66;
12. exact runtime confirmation registry:
    81;
13. exact runtime matrix registry:
    15;
14. exact runtime matrix case total:
    595;
15. stale 645 rejected;
16. B00 result identity and pass;
17. D01–D14 result identities and pass;
18. process-custody qualification;
19. synthetic ACCEPT;
20. synthetic BLOCK;
21. synthetic provenance failure;
22. synthetic constructed-subject lane;
23. bounded compatibility replay;
24. rehearsal A;
25. rehearsal B;
26. byte-identical rehearsal PYZs;
27. zero unexplained normalized rehearsal difference;
28. independent validators passed;
29. deterministic final PYZ Build-A/Build-B equality;
30. exact final member closure;
31. predecessor authority-v1 identity;
32. package status:
    ready for one fresh audit;
33. full real audit executed:
    false;
34. implementation verdict:
    not issued;
35. current subject constructed:
    false;
36. fresh qualify-harness executed against the exact final PYZ;
37. fresh qualification pass;
38. future run-full-audit invocation exact.

Every fact must have:

- exact evidence pointer;
- direct or transitive authority;
- independently recomputed value where applicable;
- no generic-success substitution.

──────────────────────────────────────────────────────────────────────────────
12. FINAL CROSS-DOCUMENT RECONCILIATION V2
──────────────────────────────────────────────────────────────────────────────

Create a fresh external reconciliation:

validation/final-external-harness-authority-reconciliation-v2.json

Independently reconcile:

- exact PYZ bytes;
- predecessor authority v1;
- fresh qualification process custody;
- fresh qualification result;
- source freeze;
- source registries;
- member registry;
- package status;
- five documentary domains;
- 66 report rows;
- 81 confirmation names;
- 15 matrices;
- 595 cases;
- matrix-result identities;
- process custody;
- synthetic lanes;
- compatibility replay;
- rehearsals;
- independent validators;
- deterministic final PYZ package evidence;
- future invocation;
- current bundle;
- current bundle authority.

Require zero disagreement.

Require no acceptance-bearing fact available only in human prose.

Required conclusion:

UNCHANGED_FINAL_PYZ_FRESHLY_REQUALIFIED_AND_EXTERNALLY_RECONCILED

──────────────────────────────────────────────────────────────────────────────
13. AUTHORITY-V2 SCHEMA AND CONTENT
──────────────────────────────────────────────────────────────────────────────

Create one self-contained authority file:

gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json

Use strict canonical UTF-8 JSON with one trailing newline.

The authority-v2 JSON must contain:

- schema;
- authority version:
  2;
- harness ID and version;
- current authority:
  true;
- predecessor authority-v1:
  - exact path;
  - exact identity;
  - current:
    false;
  - historical-valid:
    true;
  - supersession reason:
    incomplete post-package launch authority;
- unchanged PYZ:
  - exact path;
  - exact device/inode/mode/link/size/SHA-256;
  - exact member count:
    93;
  - exact member-list digest;
  - exact member-registry identity;
- exact `__main__.py` identity;
- exact source-freeze identity;
- exact source-registry identities;
- current bundle identity;
- current bundle-authority identity;
- fresh platform-capture preflight result;
- fresh qualify-harness process custody;
- exact raw-stream hashes;
- exact parsed fresh qualification result, embedded as a JSON object;
- fresh qualification-result canonical digest;
- complete frozen-PYZ requalification crosswalk, embedded or fully represented;
- final external reconciliation v2, embedded or fully represented;
- exact runtime governing identities:
  - five-domain contract;
  - report registry;
  - confirmation registry;
  - matrix registry;
  - aggregate owner/consumer registry;
- exact derived values:
  - documentary domains:
    5;
  - report rows:
    66;
  - confirmation names:
    81;
  - matrix rows:
    15;
  - matrix cases:
    595;
  - PYZ members:
    93;
  - input-bundle roles:
    8;
  - input-bundle members:
    479;
- source frozen:
  true;
- source unchanged after freeze:
  true;
- deterministic final package:
  true;
- fresh frozen-PYZ requalification:
  passed;
- final cross-document reconciliation:
  passed;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current schema subject constructed:
  false;
- source repair performed:
  false;
- PYZ modified:
  false;
- PYZ rebuilt:
  false;
- launch authorized:
  true;
- future audit count authorized:
  1;
- exact future run-full-audit invocation;
- exact future environment;
- exact future stdout/stderr contract;
- containing directory:
  nonauthoritative.

The authority-v2 JSON must not depend on the build root after success.

No supporting build-root file may be required for future launch.

──────────────────────────────────────────────────────────────────────────────
14. DETERMINISTIC AUTHORITY-V2 GENERATION
──────────────────────────────────────────────────────────────────────────────

Generate authority-v2 bytes independently twice:

- Authority Build A;
- Authority Build B.

Require byte-identical output.

Retain:

validation/authority-v2-build-a-b-comparison-v1.json

Require:

- same size;
- same SHA-256;
- same parsed object;
- same key ordering;
- same canonical serialization;
- same trailing newline;
- no uncontrolled timestamp;
- no process ID in authority-bearing fields;
- no build-root path in future authority;
- no mutable evidence pointer.

Only after equality may one copy become final.

──────────────────────────────────────────────────────────────────────────────
15. INDEPENDENT AUTHORITY-V2 VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement one source-external validator that imports neither:

- authority-v2 builder helpers;
- qualification-output parser helpers;
- reconciliation generator;
- expected-result maps.

It must independently:

1. authenticate unchanged PYZ;
2. authenticate predecessor authority v1;
3. authenticate bundle and bundle authority;
4. authenticate the 93-member closure;
5. parse fresh qualification raw streams and result;
6. bind the process result to the exact executed PYZ;
7. recompute 5/66/81/15/595/93/8/479;
8. verify source freeze and source registries;
9. verify matrix-result identities;
10. verify custody/synthetic/replay/rehearsal/validator evidence;
11. verify deterministic package evidence;
12. verify package status;
13. verify future invocation;
14. verify authority-v2 Build-A/Build-B equality;
15. verify no source or PYZ modification;
16. verify no real audit execution;
17. verify authority v2 is self-contained;
18. verify launch authorization is justified;
19. reject authority v1 as sufficient current launch authority;
20. require zero errors.

Retain:

validation/independent-external-harness-authority-v2-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
16. FINAL AUTHORITY-V2 FILE
──────────────────────────────────────────────────────────────────────────────

Write final authority v2 into the fresh output directory:

gen2-clean-source-external-independent-audit-harness-v1.authority-v2.json

After complete validation:

- chmod to 0400;
- reopen no-follow;
- require regular file;
- require link count one;
- verify size and SHA-256;
- verify exact canonical bytes;
- prohibit later modification.

The unchanged PYZ remains at its original exact path and identity.

Do not copy or replace the PYZ.

The output directory is nonauthoritative.

Report the final authority-v2 file’s exact:

- absolute path;
- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

──────────────────────────────────────────────────────────────────────────────
17. INPUT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for all four fixed input files.

Require exact equality with opening:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

Do not reopen original contaminated roots.

──────────────────────────────────────────────────────────────────────────────
18. QUALIFICATION-ROOT AND BUILD-ROOT CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing any authority-owned disposable root retain:

- exact root identity;
- complete inventory;
- process records and streams;
- fresh qualification result;
- crosswalk;
- reconciliation;
- validation results;
- failure outcome when applicable.

Then:

- revalidate identity;
- remove the exact root;
- observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice-absent roots

Do not remove the final output directory or authority-v2 file on success.

──────────────────────────────────────────────────────────────────────────────
19. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process ledger and raw streams;
- complete partial inventory;
- indispensable evidence;
- qualification-root posture;
- cleanup;
- input closing equality;
- authority-v2 posture;
- same-root retry:
  false.

Do not create a current authority-v2 file on failure.

If a provisional authority-v2 file exists:

- retain identity;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- fixed-input mismatch;
- platform-capture failure;
- missing qualify-harness completion custody;
- input mutation;
- source or PYZ drift;
- unregistered process/filesystem effect;
- evidence loss;
- cleanup inequality;
- closing inequality;
- final authority-v2 mismatch.

──────────────────────────────────────────────────────────────────────────────
20. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_CREATED_READY_FOR_FRESH_AUDIT

only when:

- all four fixed inputs authenticate;
- PYZ member closure passes;
- exact qualify-harness invocation derives;
- platform preflight passes;
- qualify-harness executes exactly once;
- complete process custody is retained;
- fresh qualification passes;
- exact final PYZ is bound to the result;
- every post-package requalification fact closes;
- final external reconciliation has zero disagreement;
- authority Build A/B bytes match;
- independent authority-v2 validator passes;
- input files close equal;
- disposable roots clean exactly;
- final authority-v2 file is mode 0400;
- unchanged PYZ remains exact;
- no real audit ran;
- no implementation verdict was issued.

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_BLOCKED

when:

- fresh qualification reports a substantive harness qualification failure;
- a required post-package fact cannot be proven without changing PYZ bytes;
- authority v2 cannot be self-contained;
- independent validation fails without a provenance failure.

Required disposition on BLOCKED:

- source repair required:
  report exact result;
- PYZ rebuild required:
  report exact result;
- real audit:
  not authorized.

Return:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_PROVENANCE_MISMATCH

for provenance failures defined in Section 19.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh authority-build root identity
3. Fresh authority-output root identity
4. Unchanged PYZ identity
5. Predecessor authority-v1 identity
6. Content-bundle identity
7. Content-authority identity
8. Stable input authentication
9. Predecessor-authority disposition
10. Exact PYZ member closure
11. Exact qualify-harness invocation derivation
12. Platform-capture preflight
13. Exact qualify-harness argv
14. Exact cwd and environment
15. Qualify-harness platform custody
16. Raw stdout identity and complete framing
17. Raw stderr identity and complete framing
18. Exit code and signal
19. Qualification result identity
20. Qualification result contents
21. Exact final-PYZ binding
22. Source-freeze binding
23. Source-registry bindings
24. Runtime-governance bindings
25. Matrix-result bindings
26. Process-custody qualification binding
27. Synthetic-lane bindings
28. Compatibility-replay binding
29. Rehearsal bindings
30. Independent-validator bindings
31. Deterministic-package binding
32. Package-status binding
33. Frozen-PYZ requalification crosswalk
34. Final external reconciliation v2
35. Authority-v2 schema and complete contents
36. Authority Build A
37. Authority Build B
38. Authority-A/B equality
39. Independent authority-v2 validation
40. Confirmation no source repair was performed
41. Confirmation no PYZ modification or rebuild occurred
42. Confirmation no real audit was executed
43. Confirmation no implementation verdict was issued
44. Input closing equality
45. Qualification/build-root cleanup
46. Failure-closeout capability and use
47. Final authority-v2 path and identity
48. Mandatory next treatment
49. Remaining uncertainty and nonclaims
50. Explicit confirmations

Required confirmations:

UNCHANGED_HARNESS_PYZ_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V1_IDENTITY_MATCHED
CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
PREDECESSOR_AUTHORITY_V1_DISPOSITION_RETAINED
PYZ_MEMBER_SET_CLOSED
EXACT_QUALIFY_HARNESS_INVOCATION_DERIVED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
QUALIFY_HARNESS_EXECUTED_EXACTLY_ONCE
RUN_FULL_AUDIT_MODE_NOT_EXECUTED
QUALIFY_HARNESS_PROCESS_CUSTODY_COMPLETE
QUALIFY_HARNESS_RAW_STDOUT_RETAINED
QUALIFY_HARNESS_RAW_STDERR_RETAINED
QUALIFY_HARNESS_EXIT_AND_SIGNAL_RETAINED
FRESH_QUALIFICATION_RESULT_STRICTLY_PARSED
FRESH_QUALIFICATION_PASSED
FRESH_RESULT_BOUND_TO_EXACT_FINAL_PYZ
SOURCE_FREEZE_IDENTITY_BOUND
SOURCE_NOT_MODIFIED_AFTER_FREEZE
FINAL_SOURCE_REGISTRIES_BOUND
FIVE_DOCUMENTARY_DOMAINS_RECOMPUTED
RUNTIME_REPORT_ROW_COUNT_66_RECOMPUTED
RUNTIME_CONFIRMATION_NAME_COUNT_81_RECOMPUTED
RUNTIME_MATRIX_COUNT_15_RECOMPUTED
RUNTIME_MATRIX_CASE_TOTAL_595_RECOMPUTED
STALE_MATRIX_TOTAL_645_REJECTED
PROCESS_CUSTODY_QUALIFICATION_BOUND
SYNTHETIC_LANES_BOUND
BOUNDED_COMPATIBILITY_REPLAY_BOUND
COMPLETE_REHEARSAL_A_BOUND
COMPLETE_REHEARSAL_B_BOUND
REHEARSAL_PYZS_BYTE_IDENTICAL_BOUND
REHEARSAL_NORMALIZED_DIFFERENCE_ZERO_BOUND
INDEPENDENT_VALIDATORS_BOUND
DETERMINISTIC_FINAL_PYZ_BUILD_BOUND
FINAL_PYZ_MEMBER_CLOSURE_BOUND
FINAL_AUTHORITY_V1_RECONCILED_AS_PREDECESSOR
FINAL_EXTERNAL_RECONCILIATION_V2_PASSED
AUTHORITY_V2_SELF_CONTAINED
AUTHORITY_V2_BUILD_A_CREATED
AUTHORITY_V2_BUILD_B_CREATED
AUTHORITY_V2_BUILD_A_B_BYTES_IDENTICAL
INDEPENDENT_AUTHORITY_V2_VALIDATOR_PASSED
HARNESS_SOURCE_REPAIR_NOT_PERFORMED
HARNESS_PYZ_MODIFICATION_NOT_PERFORMED
HARNESS_PYZ_REBUILD_NOT_PERFORMED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_PYZ_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_V1_CLOSING_EQUALITY_PASSED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_CONTENT_AUTHORITY_CLOSING_EQUALITY_PASSED
AUTHORITY_OWNED_CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
FINAL_AUTHORITY_V2_CREATED
FINAL_AUTHORITY_V2_MODE_0400
FINAL_AUTHORITY_V2_IDENTITY_VERIFIED
FINAL_AUTHORITY_V2_BINDS_UNCHANGED_PYZ
FUTURE_AUDIT_COUNT_AUTHORIZED_ONE
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_HARNESS_EXTERNAL_AUTHORITY_V2_CREATED_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit using:

- the unchanged final harness PYZ;
- the exact new authority-v2 JSON;
- the exact current-authority content bundle;
- the exact content-bundle authority JSON.

Do not include predecessor authority v1 as current launch authority.

Do not combine authority-v2 creation with the real audit.
```

### Sources

The exact PYZ closes cleanly at 93 members, and authority v1 binds the PYZ, source freeze, general qualification result, member registry, and runtime governance records. :chatgpt-content-reference{index="5"}

The bound qualification result does not prove exact final-PYZ identity, deterministic final packaging, final member closure, or final authority coherence, so it is correctly classified as general qualification only. :chatgpt-content-reference{index="6"}

A transitive chain is allowed in principle, but the existing exact authority/PYZ bytes omit the required post-package requalification and final-reconciliation edge. :chatgpt-content-reference{index="7"}

No process or audit was launched, and the mandatory next treatment is a fresh external authority v2 around the unchanged PYZ after one fresh qualification execution. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

**Confidence:** 0.999 that the implementation remains unaudited; 0.999 that no harness-source repair is presently justified; 0.99 that the unchanged PYZ can likely be authorized through a fresh qualification plus external reconciliation; 0.97 that authority-v2 creation should remain separate from the real audit.

Some older uploaded project files are no longer accessible. Re-upload an older file if a later review needs its original contents rather than the retained reports and identities.
