## Assessment

This reconciliation cleanly separates **contract truth** from **defective package evidence**:

- All four supplied roots are physically and byte-for-byte unchanged.
- The normative contract does not make display labels acceptance-bearing.
- The failed equality generator compared entire inventory objects, including two nonnormative label differences:
  - `source_sufficiency_root` → `source_sufficiency`
  - `sealed_harness_predecessor` → `sealed_predecessor`
- The confirmation generator independently hard-coded every confirmation to `true` instead of deriving `SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED` from the retained equality result.
- The normative contract and all schemas must remain byte-identical.
- A construction-parent implementation is still unauthorized.

The next tranche is therefore a **fresh contract-package re-seal**, not another reconciliation and not a contract rewrite. Root-independent substantive artifacts may be copied byte-for-byte; root-bound records must be regenerated. The equality generator must pair rows by canonical role and absolute path, exclude display labels from acceptance, and derive confirmations from retained evidence.

Forward this prompt to Codex:

```text
FRESH RE-SEAL OF THE VALIDATION-CUSTODY V3
PACKAGE-CONSTRUCTION-PARENT CONTRACT PACKAGE —
CANONICAL SUPPLIED-ROOT EQUALITY AND EVIDENCE-DERIVED CONFIRMATIONS

This task creates a fresh, terminally sealed, authoritative contract package
from an exact mechanically sealed but nonauthoritative predecessor.

It repairs only:

1. supplied-root opening/closing equality normalization;
2. confirmation derivation;
3. root-bound evidence identities and package closure.

It does not change:

- the normative construction-parent contract;
- any contract schema;
- the construction-parent operating model;
- the construction state machine;
- authority or nonauthority;
- semantic export roles;
- qualification requirements;
- terminal-closure rules;
- failure or retry rules.

It does not implement the construction parent.
It does not construct a target-audit harness package.
It does not execute a target audit.
It does not rerun runtime validation.
It does not run repository tests or product code.

Do not modify, resume, clean, finish, or reseal any supplied root.
Do not create construction-parent implementation source.
Do not run Git.
Do not use the network.
Do not install, deploy, publish, externally commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED
TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEAL_BLOCKED
CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. NONAUTHORITATIVE SEALED PREDECESSOR PACKAGE
──────────────────────────────────────────────────────────────────────────────

SEALED_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-lmj3zfrw

Expected identity:

- device/inode:
  16777234 / 180396851
- mode:
  0700
- retained verdict:
  CONTRACT_PROVENANCE_MISMATCH

Expected normative contract:

contract/package-construction-parent-v1.json

- size:
  32038
- SHA-256:
  874cbb427dbec96e720ca8f860f899614e87ef70c801afffa0262cac3bbe4a19
- status:
  frozen-pending-implementation
- implementation present:
  false
- implementation authority:
  false

Expected temporal inventory:

closeout/temporal-final-inventory-v1.json

- size:
  11595
- SHA-256:
  623ee37c5e7dc1d4fc9050203038a47b2065c881cb3f8b390130b8a324a6e19a

Expected manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  11847 each
- SHA-256:
  f12de7deda6851668aa9c1597e1c63fe1d6194e6be16fc356ce5f50d406fea19
- byte-identical:
  required

Authenticate the complete predecessor package and independently reproduce its
51-entry self-excluding manifest projection before using any predecessor byte.

This package is immutable historical evidence. It is not current contract
authority.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING CLOSING-EQUALITY RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-closing-reconciliation-wt5eh322

Expected identity:

- device/inode:
  16777234 / 180436059
- mode:
  0700
- verdict:
  CONSTRUCTION_PARENT_CONTRACT_CLOSING_RECONCILED_RECORD_NORMALIZATION_DEFECT

Expected final diagnostic inventory:

- size:
  5618
- SHA-256:
  f708c29868fc06cc50e242dedd57b42629198935aa346a0a81cb12df39fdc66f

Authenticate and inspect at minimum:

analysis/supplied-root-opening-closing-crosswalk-v1.json
analysis/closing-equality-label-differences-v1.json
analysis/normative-contract-schema-adjudication-v1.json
analysis/closing-equality-generator-crosswalk-v1.json
analysis/closing-equality-confirmation-crosswalk-v1.json
analysis/substantive-contract-artifact-adjudication-v1.json
analysis/minimal-next-tranche-v1.json
validation/live-supplied-root-equality-reprojection-v1.json
validation/closing-equality-reconciliation-matrix-v1.json
closing/reconciliation-supplied-root-closing-equality-v1.json

The governing classifications are:

- root cause:
  AUDIT_LOCAL_LABEL_NORMALIZATION_DEFECT
- confirmation contradiction:
  confirmation-generator defect
- normative contract amendment required:
  false
- schema amendment required:
  false
- supplied-root drift:
  false
- construction-parent implementation authorized:
  false

──────────────────────────────────────────────────────────────────────────────
3. EXACT DEFECTIVE PREDECESSOR RECORDS
──────────────────────────────────────────────────────────────────────────────

Authenticate:

closing/supplied-root-closing-equality-v1.json

- size:
  1779
- SHA-256:
  4af0d122452b5b8eda972ffc08ec63677177e07f3af0df43bd67abe31733d892
- schema:
  execution-substrate.target-audit-harness.contract-package-supplied-root-equality.v1
- retained overall pass:
  false

Authenticate:

closeout/explicit-confirmations-v1.json

- size:
  2558
- SHA-256:
  03a6ab085bbce11e4d838e7b20e5602d310d57fc3440f2e14bc2ffd0311bab52
- contradictory field:
  /confirmations/SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
- retained value:
  true

Authenticate the exact generator source:

validation/contract_package_builder.py

- size:
  73051
- SHA-256:
  343eba52d498a0a920922152cc0edfb9408e8abff62c3968623097f1864ff98c

Do not execute this predecessor builder as current tooling.

Use it only as authenticated source evidence for a bounded evidence-generator
repair.

──────────────────────────────────────────────────────────────────────────────
4. EXACT SUPPLIED-ROOT ROLE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Freeze the exact canonical supplied-root roles:

1. role_id:
   source_sufficiency

   path:
   /Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-qualified-c57x2xh0

   expected identity:
   - device/inode:
     16777234 / 180357741
   - mode:
     0700
   - entries:
     16
   - retained verdict:
     TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_BLOCKED

2. role_id:
   sealed_predecessor

   path:
   /Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-package-rebound-voptrogn

   expected identity:
   - device/inode:
     16777234 / 180248929
   - mode:
     0700
   - entries:
     74

3. role_id:
   accepted_bootstrap

   path:
   /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

   expected identity:
   - device/inode:
     16777234 / 179405897
   - mode:
     0700
   - entries:
     1209

4. role_id:
   accepted_bootstrap_audit

   path:
   /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-independent-audit-sbv__euv

   expected identity:
   - device/inode:
     16777234 / 180047263
   - mode:
     0700
   - entries:
     197

The canonical pairing key is exactly:

(role_id, absolute_path)

Display labels are nonauthoritative report metadata.

Display labels:

- may differ between opening and closing;
- may not select a row;
- may not pair rows;
- may not affect equality;
- may not affect package success;
- may not affect confirmation generation.

Require exactly one opening row and one closing row for every canonical
pairing key.

Reject duplicate role IDs, duplicate absolute paths, missing rows, extra rows,
or conflicting role/path mappings.

──────────────────────────────────────────────────────────────────────────────
5. FRESH CONTRACT-PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-package-construction-parent-contract-resealed-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Retain before substantive work:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method;
- umask;
- predecessor-package identity;
- reconciliation identity;
- exact canonical supplied-root registry;
- contract-reseal-only authority;
- normative contract change authorized:
  false;
- schema change authorized:
  false;
- implementation creation authorized:
  false;
- package construction authorized:
  false;
- target audit executed:
  false;
- runtime validation rerun:
  false.

Create directories lazily.

Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
6. COMPLETE ARTIFACT DISPOSITION LEDGER
──────────────────────────────────────────────────────────────────────────────

Use:

analysis/substantive-contract-artifact-adjudication-v1.json

from the reconciliation root as the governing classification input.

Independently authenticate every predecessor artifact and retain:

analysis/contract-package-artifact-disposition-v1.json

Classify every predecessor path exactly once as:

COPY_BYTE_FOR_BYTE_ROOT_INDEPENDENT
REGENERATE_ROOT_BOUND
HISTORICAL_DEFECTIVE_EVIDENCE
PACKAGE_CLOSURE_OUTPUT
FORBIDDEN_OR_UNKNOWN

Required byte-reusable classes include, as established by the reconciliation:

- sole normative contract;
- all 15 schemas;
- construction-parent contract mutation matrix;
- four analytical perspectives;
- implementation source architecture.

Required root-bound regeneration includes, as established by the
reconciliation:

- contract/schema field map;
- independent-validator result;
- parent reconciliation;
- state-machine projection;
- opening inventories and bindings;
- closing inventories and equality;
- confirmations;
- root-bound fixed-input identities;
- report;
- temporal inventory;
- manifests.

The exact path set must come from the authenticated adjudication record and
predecessor manifest membership.

Do not infer paths from prose alone.

Any `FORBIDDEN_OR_UNKNOWN` path blocks the task.

──────────────────────────────────────────────────────────────────────────────
7. BYTE-IDENTICAL NORMATIVE ARTIFACTS
──────────────────────────────────────────────────────────────────────────────

Copy byte-for-byte using no-follow reads and exclusive mode-0600 writes:

- contract/package-construction-parent-v1.json;
- all 15 closed Draft 2020-12 schemas;
- every other artifact classified
  `COPY_BYTE_FOR_BYTE_ROOT_INDEPENDENT`.

For every copied artifact:

- bind predecessor path;
- predecessor size/SHA-256;
- destination path;
- destination size/SHA-256;
- byte equality;
- mode/link count;
- no-follow stable read.

Retain:

opening/root-independent-artifact-copy-v1.json

Require the normative contract and every schema to remain exactly unchanged.

No normalization or reserialization is permitted for copied artifacts.

──────────────────────────────────────────────────────────────────────────────
8. BOUNDED EVIDENCE-GENERATOR SOURCE REPAIR
──────────────────────────────────────────────────────────────────────────────

Create fresh audit-owned source:

provenance/contract_package_builder_v2.py

Use the authenticated predecessor builder only as a source basis.

The repair scope is exactly:

contract-package-equality-and-confirmation-evidence-generation

Authorized changes:

1. canonical supplied-root role/path registry;
2. opening/closing pairing key;
3. display-label exclusion from acceptance equality;
4. exact-set checks for opening/closing roles;
5. equality-result generation;
6. confirmation evidence mapping;
7. confirmation derivation from retained evidence;
8. root-bound output paths and identities for the fresh package.

Unauthorized changes:

- normative contract generation;
- schema generation or semantics;
- construction state machine;
- authority or nonauthority;
- qualification requirements;
- mutation cases outside closing-equality and confirmation logic;
- source architecture semantics;
- implementation authority;
- package output roles;
- terminal manifest grammar.

Retain:

analysis/builder-v1-v2-semantic-delta.json

For every changed hunk record:

- original and repaired source range;
- defect owner:
  label normalization,
  role/path pairing,
  equality aggregation,
  confirmation derivation,
  or fresh-root binding;
- behavior before;
- behavior after;
- contract semantic effect:
  none.

Require function-level AST equality for every unrelated function.

If an unrelated semantic function must change, return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEAL_BLOCKED

──────────────────────────────────────────────────────────────────────────────
9. CORRECT SUPPLIED-ROOT EQUALITY MODEL
──────────────────────────────────────────────────────────────────────────────

Opening and closing records must each contain:

- role_id;
- absolute_path;
- display_label;
- root device;
- root inode;
- root mode;
- entry count;
- complete inventory digest;
- complete retained inventory rows or an exact retained inventory binding;
- inventory grammar identity.

Pair rows by:

(role_id, absolute_path)

Require exact opening/closing set equality over canonical keys.

For each pair compare the normative physical and content fields required by the
contract and inventory grammar.

Do not compare `display_label` for acceptance.

Retain label differences as report-only diagnostics.

Generate:

closing/supplied-root-closing-equality-v2.json

Required fields include:

- exact canonical role registry;
- opening canonical-key set;
- closing canonical-key set;
- missing/extra/duplicate rows;
- per-role physical equality;
- per-role content equality;
- per-role pass;
- display-label diagnostics;
- overall pass.

Overall pass must be true only when:

- canonical key sets match exactly;
- every per-role physical comparison passes;
- every per-role content comparison passes;
- no ambiguity exists.

──────────────────────────────────────────────────────────────────────────────
10. CONFIRMATION-EVIDENCE MAP
──────────────────────────────────────────────────────────────────────────────

Do not assign confirmation tokens literal `true`.

Retain:

contract/confirmation-evidence-map-v1.json

For every confirmation token bind:

- source record path;
- exact JSON pointer;
- required type;
- required value;
- applicability;
- evaluation rule.

At minimum:

SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED

must bind exactly:

record:
  closing/supplied-root-closing-equality-v2.json
pointer:
  /pass
required_type:
  boolean
required_value:
  true

Generate:

closeout/explicit-confirmations-v2.json

only after every mapped source record exists.

For every confirmation:

- strict-parse the source record;
- resolve the exact pointer;
- require the exact type and value;
- retain source record size/SHA-256;
- retain resolved value.

A false, absent, unresolved, mistyped, or stale source value must produce a
false confirmation and must prevent a success package seal.

No absence-as-success.
No hard-coded success.
No copied confirmation from the predecessor package.

──────────────────────────────────────────────────────────────────────────────
11. FRESH CLOSING-EQUALITY MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement the exact 25-case registry from:

validation/closing-equality-reconciliation-matrix-v1.json

in the reconciliation root.

Freshly run it against builder V2.

At minimum verify:

- same roots/inventories and same labels:
  pass;
- same roots/inventories and different display labels:
  pass;
- different normative role:
  reject;
- same label and different root:
  reject;
- device/inode drift:
  reject;
- content drift:
  reject;
- duplicate opening/closing labels:
  diagnostic unless they cause role/path ambiguity;
- duplicate normative role:
  reject;
- duplicate absolute path:
  reject;
- missing/extra row:
  reject;
- reordered rows:
  no effect;
- hard-coded confirmation true while equality false:
  reject;
- confirmation derived from `/pass:true`:
  pass.

Require:

- exactly 25 unique literal cases;
- two-way name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/closing-equality-mutation-matrix-v2.json

──────────────────────────────────────────────────────────────────────────────
12. INDEPENDENT CLOSING-EQUALITY VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Create a second validator that imports neither:

- builder V2;
- the first matrix helper;
- producer fixtures;
- producer expected-result maps.

It must independently:

- parse the normative contract;
- reconstruct canonical supplied-root roles;
- parse opening and closing rows;
- pair by role/path;
- ignore display labels for acceptance;
- compare physical/content facts;
- validate confirmation evidence mapping;
- run its own literal case registry.

Retain:

validation/independent-closing-equality-validator-v1.json

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
13. REGENERATE ROOT-BOUND ARTIFACTS
──────────────────────────────────────────────────────────────────────────────

Regenerate every artifact classified `REGENERATE_ROOT_BOUND`.

This includes the exact paths identified by the artifact-disposition ledger.

At minimum regenerate:

- opening fixed-input authentication;
- opening root inventories and role registry;
- state-machine projection with fresh contract identity bindings;
- contract/schema field map with fresh package-relative paths and identities;
- independent-validator result bound to current contract/schema bytes;
- parent perspective reconciliation;
- closing inventories;
- supplied-root equality V2;
- confirmation evidence map;
- explicit confirmations V2;
- package authority/status record;
- final report;
- closeout records.

Do not change the normative contract or schema bytes while regenerating their
bindings.

Any regenerated artifact that contains a package-root path must bind the fresh
root.

No stale predecessor package path may remain in a current root-bound record.

──────────────────────────────────────────────────────────────────────────────
14. CONTRACT AND SCHEMA REVALIDATION
──────────────────────────────────────────────────────────────────────────────

Against the copied normative contract and schemas:

- rerun strict JSON parsing;
- rerun all 15 schema validations;
- rerun the 766-leaf field-map reconstruction;
- rerun the 57-case construction-parent contract mutation matrix;
- rerun the independent construction-parent contract validator;
- rerun phase-graph validation;
- rerun authority/nonauthority validation;
- rerun package-output and four-consumer policy validation;
- rerun terminal-closure and failure/retry validation.

The normative contract and schema outputs must be semantically identical to
the predecessor results.

Retain fresh result records bound to the new package.

No implementation-consistency claim is permitted.

──────────────────────────────────────────────────────────────────────────────
15. FOUR PERSPECTIVES AND PARENT RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

The four root-independent perspective records may be copied byte-for-byte only
when the governing artifact-disposition record classifies them that way.

Regenerate:

analysis/parent-perspective-reconciliation-v2.json

Bind:

- fresh package identity;
- exact normative contract identity;
- exact copied perspective identities;
- regenerated equality evidence;
- no disagreements;
- no unresolved operating-model decisions;
- no implementation present.

Do not reinterpret perspective content.

──────────────────────────────────────────────────────────────────────────────
16. HISTORICAL LINEAGE
──────────────────────────────────────────────────────────────────────────────

Retain:

lineage/contract-package-reseal-lineage-v1.json

Bind:

- nonauthoritative predecessor contract-package identity;
- contradictory equality record identity;
- contradictory confirmation identity;
- reconciliation identity;
- exact label differences;
- equality-generator defect;
- confirmation-generator defect;
- new package identity;
- normative contract unchanged;
- schemas unchanged;
- root-independent artifacts copied;
- root-bound artifacts regenerated;
- predecessor package:
  historical,
  noncurrent,
  nonauthoritative,
  ineligible for implementation authority.

Do not copy contradictory predecessor equality or confirmation files into
current paths.

They may be represented only through lineage identities.

──────────────────────────────────────────────────────────────────────────────
17. PACKAGE STATUS AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Retain:

opening/contract-package-authority-v2.json

Before terminal closure it must state:

- normative contract status:
  frozen-pending-implementation;
- implementation present:
  false;
- implementation authority:
  false;
- contract package authority established:
  false;
- terminal closure established:
  false;
- supplied-root equality pending or passed as actually observed;
- confirmation evidence pending or passed as actually observed.

After all nonmanifest validation is final but before temporal inventory, the
report may state all evidence gates passed.

Do not create a success-authority record before manifest closure.

Current package authority arises only when:

- supplied-root equality V2 passes;
- evidence-derived confirmations pass;
- all contract validations pass;
- supplied-root closing equality passes;
- temporal inventory verifies;
- terminal manifests verify;
- no write follows closure.

──────────────────────────────────────────────────────────────────────────────
18. NO IMPLEMENTATION
──────────────────────────────────────────────────────────────────────────────

Do not create:

- construction-parent implementation source;
- implementation skeleton;
- executable mock;
- target-audit harness package;
- consumer-facing package exports;
- target-audit execution fixture that claims runtime qualification.

Allowed executable code is limited to audit-owned:

- builder V2;
- closing-equality validator;
- contract documentary validators;
- inventory generators;
- manifest generators.

No package construction, target audit, or runtime validation may occur.

──────────────────────────────────────────────────────────────────────────────
19. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for all four canonical supplied
roots.

Use the exact canonical role/path registry.

Generate:

closing/supplied-root-closing-equality-v2.json

Require:

- exact role/path set equality;
- exact root identity equality;
- exact entry-count equality;
- exact path-set equality;
- exact required metadata equality;
- exact regular-file byte equality;
- exact inventory-digest equality;
- label differences diagnostic only;
- overall pass true.

Then generate confirmations from this exact retained record.

Do not seal a successful package when equality is false or absent.

──────────────────────────────────────────────────────────────────────────────
20. SUPPLIED-ROOT CLOSING EQUALITY FOR ALL OTHER OPENED ROOTS
──────────────────────────────────────────────────────────────────────────────

If the reconciliation root or predecessor package is treated as an additional
supplied root for this re-seal task, retain separate opening/closing equality
for it.

Do not add it to the normative four-role equality registry unless the normative
contract identifies it as a construction fixed input.

All opened roots must close exactly equal.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
21. PRETERMINAL REPORT AND CONFIRMATIONS
──────────────────────────────────────────────────────────────────────────────

Before temporal inventory, finalize:

closeout/final-contract-package-report-v2.md
closeout/explicit-confirmations-v2.json

The report must state:

- normative contract unchanged;
- schemas unchanged;
- equality normalization repaired;
- display labels nonauthoritative;
- canonical role/path equality passed;
- confirmations evidence-derived;
- implementation absent;
- package construction not performed;
- target audit not executed;
- contract package not yet terminally authoritative until manifests close.

The confirmation file must be entirely evidence-derived through the retained
confirmation-evidence map.

──────────────────────────────────────────────────────────────────────────────
22. TEMPORAL FINAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final, generate:

closeout/temporal-final-inventory-v2.json

Require:

- root represented;
- all current directories represented;
- all current nonmanifest regular files represented;
- exact declared exclusions:
  - temporal inventory itself;
  - future manifest A;
  - future manifest B;
- reserved future `manifest/` directory declared;
- stable no-follow grammar;
- no symlink;
- no special object;
- no multiply linked file;
- directories mode 0700;
- files mode 0600;
- no cache or bytecode;
- no empty retained directory except reserved `manifest/` premanifest.

Reopen and verify the temporal inventory before manifest generation.

──────────────────────────────────────────────────────────────────────────────
23. TERMINAL MANIFEST CLOSURE
──────────────────────────────────────────────────────────────────────────────

After temporal-inventory verification:

1. Ensure exact reserved `manifest/` directory exists, mode 0700.
2. Independently generate manifest A.
3. Independently generate manifest B.
4. Require generated bytes byte-identical.
5. Exclusively create:
   manifest/canonical-manifest-a-v2.json
6. Write/fsync/close A.
7. Exclusively create:
   manifest/canonical-manifest-b-v2.json
8. Write/fsync/close B.
9. Fsync the manifest directory.
10. Reopen both no-follow.
11. Verify size and SHA-256.
12. Require each equals its generated bytes.
13. Require A equals B.
14. Independently reproject the complete root.
15. Require reprojection equals A and B.
16. Require no empty directory.
17. Require no symlink, special object, or multi-link regular file.
18. Require all modes 0700/0600.
19. Require no cache or bytecode.

After terminal manifest closure, perform no filesystem write.

The final inline response may inspect the sealed root read-only and report
terminal identities.

Do not create another verdict or confirmation file after closure.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED

only when:

- predecessor package authenticates and closes;
- reconciliation authenticates and closes;
- normative contract is byte-identical;
- all schemas are byte-identical;
- root-independent artifacts copy exactly;
- root-bound artifacts regenerate correctly;
- builder repair is bounded to evidence-generation logic;
- canonical role/path equality passes;
- display-label differences do not affect acceptance;
- closing-equality matrix passes;
- independent equality validator passes;
- confirmations resolve from retained evidence;
- contract/schema revalidation passes;
- mutation matrix passes;
- independent contract validator passes;
- no implementation exists;
- supplied-root closing equality passes;
- temporal inventory verifies;
- terminal manifests exist and match;
- independent reprojection passes;
- no write follows closure.

Return:

TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEAL_BLOCKED

when:

- a normative contract or schema change becomes necessary;
- root-independent artifacts cannot be reused consistently;
- canonical root roles are ambiguous;
- equality or confirmation logic cannot be repaired without wider semantics;
- contract documentary validation fails;
- implementation semantics must be invented.

Return:

CONTRACT_PROVENANCE_MISMATCH

for:

- supplied-root mutation;
- closing inequality;
- copied-artifact identity mismatch;
- unauthorized normative drift;
- stale root-bound identity;
- terminal closure failure;
- write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh contract-package root identity
3. Predecessor contract-package identity and closure
4. Reconciliation identity and closure
5. Complete artifact-disposition ledger
6. Byte-identical normative contract identity
7. Byte-identical schema identities
8. Root-independent artifact copy result
9. Builder V1 identity
10. Builder V2 identity
11. Exact builder semantic delta
12. Canonical supplied-root role registry
13. Opening supplied-root identities
14. Closing supplied-root identities
15. Canonical role/path equality result
16. Display-label diagnostics
17. Fresh closing-equality record identity
18. Confirmation-evidence map
19. Evidence-derived confirmation record
20. Closing-equality mutation matrix
21. Independent closing-equality validator
22. Regenerated root-bound artifact identities
23. Contract/schema field-map result
24. Contract mutation matrix
25. Independent contract validator
26. Four perspectives
27. Parent perspective reconciliation
28. Historical lineage
29. Confirmation no implementation exists
30. Confirmation no package construction occurred
31. Confirmation no target audit ran
32. Supplied-root closing equality
33. Temporal inventory identity
34. Manifest A identity
35. Manifest B identity
36. Independent terminal reprojection
37. Terminal membership and modes
38. No-write-after-closure result
39. Remaining uncertainty and nonclaims
40. Explicit confirmations

Required confirmations:

PREDECESSOR_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
CLOSING_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
SOURCE_SUFFICIENCY_ROOT_MUTATION_NOT_PERFORMED
SEALED_PREDECESSOR_ROOT_MUTATION_NOT_PERFORMED
ACCEPTED_BOOTSTRAP_ROOT_MUTATION_NOT_PERFORMED
ACCEPTED_BOOTSTRAP_AUDIT_ROOT_MUTATION_NOT_PERFORMED
NORMATIVE_CONTRACT_BYTES_UNCHANGED
ALL_SCHEMA_BYTES_UNCHANGED
ROOT_INDEPENDENT_ARTIFACTS_COPIED_BYTE_IDENTICAL
ROOT_BOUND_ARTIFACTS_REGENERATED
BUILDER_REPAIR_BOUNDED_TO_EVIDENCE_GENERATION
CANONICAL_SUPPLIED_ROOT_ROLE_REGISTRY_FROZEN
OPENING_CLOSING_ROWS_PAIRED_BY_ROLE_AND_PATH
DISPLAY_LABELS_NONAUTHORITATIVE
DISPLAY_LABEL_DIFFERENCES_RETAINED_AS_DIAGNOSTICS
PHYSICAL_ROOT_EQUALITY_PASSED
CONTENT_INVENTORY_EQUALITY_PASSED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETE
SUPPLIED_ROOT_EQUALITY_CONFIRMATION_DERIVED_FROM_PASS_TRUE
NO_HARDCODED_CONFIRMATION_SUCCESS
CLOSING_EQUALITY_MUTATION_MATRIX_PASSED
INDEPENDENT_CLOSING_EQUALITY_VALIDATOR_PASSED
CONTRACT_SCHEMA_FIELD_MAP_CLOSED
CONTRACT_MUTATION_MATRIX_PASSED
INDEPENDENT_CONTRACT_VALIDATOR_PASSED
SOLE_NORMATIVE_CONTRACT_PRESERVED
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
NO_CONSTRUCTION_PARENT_IMPLEMENTATION_CREATED
NO_PACKAGE_CONSTRUCTION_PERFORMED
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
CONTRACT_PACKAGE_TEMPORAL_INVENTORY_CREATED
CONTRACT_PACKAGE_TEMPORAL_INVENTORY_VERIFIED
CONTRACT_PACKAGE_MANIFEST_A_CREATED
CONTRACT_PACKAGE_MANIFEST_B_CREATED
CONTRACT_PACKAGE_MANIFESTS_BYTE_IDENTICAL
CONTRACT_PACKAGE_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_CONSTRUCTION_PARENT_CONTRACT_RESEALED`, authorize a
separate implementation task bound to the exact normative contract identity.
Do not reinterpret the contract during implementation.
```

## Decision

Proceed with a fresh re-seal. Preserve the normative contract and schemas exactly; regenerate only root-bound evidence and repair the equality/confirmation generator.

**Source:** Codex’s `CONSTRUCTION_PARENT_CONTRACT_CLOSING_RECONCILED_RECORD_NORMALIZATION_DEFECT` report in the current turn.  
**Confidence:** 1.00 that the supplied roots did not drift; 0.99 that the normative contract and schemas need no change; 0.98 that a narrow evidence-generation re-seal is the correct next tranche.
