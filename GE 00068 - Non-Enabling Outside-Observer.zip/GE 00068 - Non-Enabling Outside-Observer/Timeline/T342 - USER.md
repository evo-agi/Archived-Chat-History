Here is Codex's response:

### 1. Primary verdict

`FAILED_AUDIT_HARNESS_RECONCILED_READY_FOR_FRESH_AUDIT`

This is a harness-reconciliation verdict only. It is not a successor-package verdict.

### 2. Failed-audit-root identity and closure

Root:

`/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj`

- Device/inode: `16777234 / 179539317`
- Mode: `0700`
- Birth: `2026-09-23T05:47:43.600015Z`
- Closing mtime/ctime: `2026-09-23T05:47:56.822716Z`
- Physical no-follow closure: `177 = 31 directories + 146 regular files`
- Symlinks/special files: `0 / 0`
- Represented manifest closure: `175 = 31 directories + 144 nonmanifest regular files`
- Two manifest self-exclusions account for the physical/represented difference.
- Both canonical manifests are byte-identical, each `37,614` bytes, SHA-256 `19561231e769b6d9dc794eb5060732c39b18123b8165d70a5584fd0f8370f7c1`.
- Closing inventory SHA-256: `7261fb8290be224ebbe7f3e222cd369327c7d7436e147d2ac0cfd71c41ca564b`.

The retained capsule says `BLOCK`, but its unaccounted child-created roots and false cleanup assertion make the failed attempt an `AUDIT_PROVENANCE_MISMATCH` under the supplied classification rule.

Two requested labels were not retained literally:

- `provenance/complete-child-process-ledger.json` is absent; the authenticated ledger is [child-process-ledger.json](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj/provenance/child-process-ledger.json).
- `analysis/fixed-identity-and-discovery-results.json` is absent; the relevant evidence is distributed across the opening gate/inventories, materialization records, child streams, and failure roots.

That naming/retention defect did not remove indispensable evidence.

### 3. Successor-package identity and closure

Root:

`/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t`

- Device/inode: `16777234 / 179405897`
- Mode: `0700`
- Birth: `2026-09-23T01:06:49.843465Z`
- Closing mtime/ctime: `2026-09-23T04:23:38.540412Z`
- Physical closure: `1,209 = 334 directories + 875 regular files`
- Symlinks/special files: `0 / 0`
- Represented closure: `1,207 = 334 directories + 873 nonmanifest regular files`
- Canonical manifests: byte-identical, each `313,487` bytes, SHA-256 `34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d`.
- Closing inventory SHA-256: `9723bd3b553afa8095bdb6a4ec85db90b4c7bec7343a02e7974e402447f77d48`.

It was inspected only for the permitted interfaces, grammars, source check ordering, and retained successful invocation evidence.

### 4. Surviving-root identities and classifications

All rows below have device `16777234`, uid/gid `501/20`. Hash is SHA-256; times are nanoseconds.

**`vg7cmoay`****\*\*\*\* — child 18**

| PathInodeMode/link/sizeBirth / mtime / ctimeHash |           |               |                                                                   |                                                                    |
| ------------------------------------------------ | --------- | ------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------ |
| `.`                                              | 179539630 | `0700/3/96`   | `1790142464345351936 / 1790142464345444791 / 1790142464545426450` | —                                                                  |
| `opening`                                        | 179539631 | `0700/5/160`  | `1790142464345443328 / 1790142464346374710 / 1790142464346374710` | —                                                                  |
| `opening/bootstrap-start.json`                   | 179539632 | `0600/1/1997` | `1790142464345530368 / 1790142464345579041 / 1790142464345579041` | `7dc2103dc8523c5d77f5ff873333e55dcd0f6ab2aa71138edb99b8c84cbe1795` |
| `opening/bootstrap-failure.json`                 | 179539633 | `0600/1/1408` | `1790142464346233088 / 1790142464346278126 / 1790142464346278126` | `3c752d0d81c0bfcfde8f5f92acbc95448495e85869ab878fb222bce254495e15` |
| `opening/bootstrap-outcome.json`                 | 179539634 | `0600/1/1447` | `1790142464346373632 / 1790142464346410585 / 1790142464346410585` | `29ddfe55b8a6224850f285c10f925446ad32e975b4b2d9486edc797bf0a98194` |

Inventory SHA-256: `15a398f954376b2ad3f01db8005efa822a9cbb022615c1aa329b365c8b7b32f9`.

**`oz_rmxfq`****\*\*\*\* — child 21**

| PathInodeMode/link/sizeBirth / mtime / ctimeHash |           |               |                                                                   |                                                                    |
| ------------------------------------------------ | --------- | ------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------ |
| `.`                                              | 179539660 | `0700/3/96`   | `1790142464535015424 / 1790142464535089218 / 1790142464545448325` | —                                                                  |
| `opening`                                        | 179539661 | `0700/5/160`  | `1790142464535088384 / 1790142464536130012 / 1790142464536130012` | —                                                                  |
| `opening/bootstrap-start.json`                   | 179539662 | `0600/1/1997` | `1790142464535169280 / 1790142464535226302 / 1790142464535226302` | `d3f8972d931c60b739755524482b2538e6ca0ece6880b4d70e4b45c4c8127100` |
| `opening/bootstrap-failure.json`                 | 179539663 | `0600/1/1408` | `1790142464535949824 / 1790142464535995887 / 1790142464535995887` | `3d1f21e04228799f8c3faefb515533421dae0b6b417762f9a6ab461e349f1779` |
| `opening/bootstrap-outcome.json`                 | 179539664 | `0600/1/1447` | `1790142464536128256 / 1790142464536176262 / 1790142464536176262` | `45d26bb07dc491fe3d77c9c56c205cc92208f3789dd0d9a16464a093014aa18c` |

Inventory SHA-256: `e1449b5446fd9a7ac378beb06504810bee6ad3586d826ae374f5e433ded30ce4`.

**`0fv56xan`****\*\*\*\* — child 22**

| PathInodeMode/link/sizeBirth / mtime / ctimeHash |           |               |                                                                   |                                                                    |
| ------------------------------------------------ | --------- | ------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------ |
| `.`                                              | 179539671 | `0700/3/96`   | `1790142464573806592 / 1790142464573895264 / 1790142465416634495` | —                                                                  |
| `opening`                                        | 179539672 | `0700/5/160`  | `1790142464573894144 / 1790142464574843225 / 1790142464574843225` | —                                                                  |
| `opening/bootstrap-start.json`                   | 179539673 | `0600/1/1997` | `1790142464573979648 / 1790142464574026931 / 1790142464574026931` | `85549ba1b9f696db188640e112e77130db929485ef88f07474f4397dc4692477` |
| `opening/bootstrap-failure.json`                 | 179539674 | `0600/1/1408` | `1790142464574697728 / 1790142464574748808 / 1790142464574748808` | `c3dd6b57662d5d5591c5dabb96b3fa523f06aeb5724bba708a227ab64dbe21ec` |
| `opening/bootstrap-outcome.json`                 | 179539675 | `0600/1/1447` | `1790142464574841856 / 1790142464574881016 / 1790142464574881016` | `8783835d0c14c5b0ccb8d683773ffc199514bc1da0f1fae18cb7b6a2eb3b7a4d` |

Inventory SHA-256: `abb42e9772abdacc667582947c873f421fc410518e90ed34fe819d1453c71450`.

All three are partial, failed, precommit materialization roots:

- Bootstrap outcome exists and says `success:false`.
- `failed_operation=parse-cli`
- `exception_type=BootstrapFailure`
- `exception_message=audit_parent_value`
- `exit_class=cli`, `exit_code=20`
- Completed step `1`; failed step `2`, `validate-cli-contract-and-create-layout`
- Carrier 0002 did not run and was not authorized.
- No authoritative success commit exists.
- `final_commit_posture=absent`
- Same-root retry is false.

### 5. Failed parent-source identity

[parent-source.py](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj/provenance/parent-source.py)

- Device/inode: `16777234 / 179539321`
- Mode/link count: `0600 / 1`
- Size: `163,230`
- SHA-256: `c615107a703f03befdbe60146147826d80ae91badf55d3a24076b5becbf9e4f6`
- mtime\_ns: `1790142463601144407`
- ctime\_ns: `1790142463601152157`

Concrete defect locations include:

- Child recording and scope-only diff: lines 345–470.
- A oracle: lines 950–1050.
- C check order: lines 1097–1154.
- I lexical ownership error: lines 1552–1590.
- J parser: lines 1597–1645.
- Field-map parser: lines 1691–1710.
- Omitted producer CLI options: lines 1769–1777.
- Self-generated circular validator: lines 1794–1838.
- Replay operand rewriting: lines 1920–1957.
- Root discovery/scoring: lines 1960–1989.
- Materialization runner: lines 2013–2031.
- Broad security literal heuristic: lines 2330–2383.
- Hard-coded cleanup registry: lines 2490–2518.
- Unsupported preseal assertions: lines 2675–2695.
- Unconditional seal path: lines 2836–2868.

### 6. Complete child-ledger crosswalk

Exact aliases:
```
P = /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
F = /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj
S = /Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t
W = /Users/ds/Downloads/ES-v3-independent-audit-owned-fixtures-f6kyn3c_
A = F/validation/audit-interpreter-probe.py
AS = F/validation/audit-probe--I--S--B.py
Q = /Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38
R = /Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s
E0 = {"LANG":"C","LC_ALL":"C","PATH":"/usr/bin:/bin",
      "PYTHONDONTWRITEBYTECODE":"1","PYTHONHASHSEED":"0"}
EMPTY = size 0, SHA-256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

All 22 rows have `paths_written:[]`, signal `null`, were reaped, and had both stream descriptors closed.

| #Purpose and exact argvCwd / environmentExitStream identityDeclared/result paths; actual effect |                                                                                                                                                                                                                           |                                                                   |            |                                                                                               |                                                                    |
| ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- | ---------- | --------------------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| 1                                                                                               | Recorder ENOENT causal: `/definitely/nonexistent/es-finite-audit-recorder-self-causal`                                                                                                                                    | `F / E0`                                                          | no process | stdout/stderr `EMPTY`; `FileNotFoundError`, errno 2                                           | None; no effect                                                    |
| 2                                                                                               | Recorder empty-stream causal: `/usr/bin/true`                                                                                                                                                                             | `F / E0`                                                          | 0          | both `EMPTY`                                                                                  | None; no effect                                                    |
| 3                                                                                               | Python identity: `P -I -S -B --version`                                                                                                                                                                                   | `F / E0`                                                          | 0          | stdout `14/727261e4e91d8b24734db9190c886c3ad33049e88e97641890c976c9b4b7ffa0`; stderr `EMPTY`  | None; no effect                                                    |
| 4                                                                                               | A exact: `P -I -S -B A`                                                                                                                                                                                                   | `F / E0`                                                          | 0          | `556/9b70c112cfb4e584b83e4dd97c6bdcfa0b454da756e356d510717b9eee4e0f16`; stderr `EMPTY`        | None; probe file was parent-created                                |
| 5                                                                                               | A reordered: `P -B -I -S A`                                                                                                                                                                                               | `F / E0`                                                          | 0          | `556/9af9ee66e2d3ebe40ca86ab743d6a62baf902e27f4c1bc2b14ccbf6498b72642`; stderr `EMPTY`        | None                                                               |
| 6                                                                                               | A duplicate: `P -I -I -S -B A`                                                                                                                                                                                            | `F / E0`                                                          | 0          | `562/83288ea457d787bf046e308a22281e60ce3943fb2bc79ca9ce70326de2414052`; stderr `EMPTY`        | None                                                               |
| 7                                                                                               | A combined: `P -ISB A`                                                                                                                                                                                                    | `F / E0`                                                          | 0          | `546/7d1d5ed9bdb45d7838326f387d4a01a1045e714a219ffab1618a0b5a90e6d7ec`; stderr `EMPTY`        | None                                                               |
| 8                                                                                               | A missing-I: `P -S -B A`                                                                                                                                                                                                  | `F / E0`                                                          | 0          | `550/99af1c6c525692f9083a7fef01f6b3c5e51a95d869c3ad6bee69d9c90c32b231`; stderr `EMPTY`        | None                                                               |
| 9                                                                                               | A missing-S: `P -I -B A`                                                                                                                                                                                                  | `F / E0`                                                          | 0          | `550/b44b35b0a01971ebfb0c588cb87033eeff795e2b88a6ed0cb71122a61c3f39b3`; stderr `EMPTY`        | None                                                               |
| 10                                                                                              | A missing-B: `P -I -S A`                                                                                                                                                                                                  | `F / E0`                                                          | 0          | `550/5e2681b119ba0183526cba1d4cf68c62dd61e09582c527571f076def0a227746`; stderr `EMPTY`        | None                                                               |
| 11                                                                                              | A missing-all: `P A`                                                                                                                                                                                                      | `F / E0`                                                          | 0          | `538/ebc105ca7e0e94af97ba3007498e01638758019d1b05100fa282a581bc2f8f1e`; stderr `EMPTY`        | None                                                               |
| 12                                                                                              | A env substitute B: `P -I -S A`                                                                                                                                                                                           | `F / E0`                                                          | 0          | `550/5e2681b119ba0183526cba1d4cf68c62dd61e09582c527571f076def0a227746`; stderr `EMPTY`        | None                                                               |
| 13                                                                                              | A tokens after script: `P A -I -S -B`                                                                                                                                                                                     | `F / E0`                                                          | 0          | `574/64b8987162df5fd37d831a234b290c4601b16b7a5cceb61354cd81a60e1c7cea`; stderr `EMPTY`        | None                                                               |
| 14                                                                                              | A duplicate-I, no-S: `P -I -I -B A`                                                                                                                                                                                       | `F / E0`                                                          | 0          | `556/e81617abe79998716cd9512f0932c00b1e4ee2ac78c77c90513c5efc79b1ad37`; stderr `EMPTY`        | None                                                               |
| 15                                                                                              | A payload token: `P -I -S -B A -I`                                                                                                                                                                                        | `F / E0`                                                          | 0          | `568/0d6fea1e917ddd1031c1c51d1ff9cdafa94081cd181c62a60b9d55c319084c9a`; stderr `EMPTY`        | None                                                               |
| 16                                                                                              | A flag substring: `P AS`                                                                                                                                                                                                  | `F / E0`                                                          | 0          | `532/afcced1841116ca3f6eb3074f8959627187333c0d2e8a98390a3a0da3ab2c094`; stderr `EMPTY`        | None                                                               |
| 17                                                                                              | A wrong interpreter: `/usr/bin/python3 -I -S -B A`                                                                                                                                                                        | `F / E0`                                                          | 1          | stdout `EMPTY`; stderr `491/ec2dc90d2d2b8f23fceb0980594ecb7c2748f1f98c37c2f9dc51e6725aaf2bb2` | None; rejected after probe error                                   |
| 18                                                                                              | I case-28 materialization: `P -I -S -B S/source/full_audit_bootstrap_v1.py --qualified-launcher-root Q --import-reconciliation-root R --audit-parent W/materialization-parent-28 --audit-prefix es-independent-audit-28-` | cwd/path-scope/TMPDIR=`W/materialization-parent-28`; otherwise E0 | 20         | stdout `76/72643c0585ea89a415c6a66529c47d1bf3498a8626ea0451b3a36e8e304bda67`; stderr `EMPTY`  | Locator `AUDIT_ROOT=…vg7cmoay`; created that five-entry root       |
| 19                                                                                              | Package producer test: `P -I -S -B S/tests/test_full_audit_bootstrap_v1.py`                                                                                                                                               | cwd/path-scope/TMPDIR=`W/successor-tests-tmp`; otherwise E0       | 2          | stdout `EMPTY`; stderr `230/1210bcc5386f3b86ed55568e4a3cd2de700d39e17ccce38cfa7eed74fcd05b63` | Required `--package-root` and `--result` omitted; no result/effect |
| 20                                                                                              | Audit-generated validator: `P -I -S -B F/validation/fresh-independent-validator.py F/validation/independent-validator-literal-registry.json S/source/full_audit_bootstrap_v1.py`                                          | `F / E0+TMPDIR=W`                                                 | 1          | stdout `314/45321b121272fb4aa4d5c2928d72ce5efc23558f1774d777276c898bcd9b661b`; stderr `EMPTY` | No declared result; only stdout summary; no child effect           |
| 21                                                                                              | Materialization 1: same as 18 with `W/materialization-parent-1`, prefix `es-independent-audit-1-`                                                                                                                         | cwd/path-scope/TMPDIR=`W/materialization-parent-1`                | 20         | stdout `76/ebc1faf7dcd3afe2469076c8b4b93de680cf892f8236a00499928c4afb35c305`; stderr `EMPTY`  | Locator `AUDIT_ROOT=…oz_rmxfq`; created that root                  |
| 22                                                                                              | Materialization 2: same as 18 with `W/materialization-parent-2`, prefix `es-independent-audit-2-`                                                                                                                         | cwd/path-scope/TMPDIR=`W/materialization-parent-2`                | 20         | stdout `76/6611f8a3bf64229eece36f8de44abdb08998859466d452a32f645d32facf0b38`; stderr `EMPTY`  | Locator `AUDIT_ROOT=…0fv56xan`; created that root                  |

Children 18, 21, and 22 are the only child processes with filesystem effects.

### 7. Exact child-to-root attribution

| ChildProcess intervalRoot birthExact retained locator |                                       |                    |                                                                                 |
| ----------------------------------------------------- | ------------------------------------- | ------------------ | ------------------------------------------------------------------------------- |
| 18                                                    | `05:47:44.312971Z`–`05:47:44.349998Z` | `05:47:44.345352Z` | `AUDIT_ROOT=/Users/ds/Downloads/ES-validation-custody-v3-full-audit-vg7cmoay\n` |
| 21                                                    | `05:47:44.503199Z`–`05:47:44.540605Z` | `05:47:44.535015Z` | `AUDIT_ROOT=/Users/ds/Downloads/ES-validation-custody-v3-full-audit-oz_rmxfq\n` |
| 22                                                    | `05:47:44.541498Z`–`05:47:44.579243Z` | `05:47:44.573807Z` | `AUDIT_ROOT=/Users/ds/Downloads/ES-validation-custody-v3-full-audit-0fv56xan\n` |

Each locator equals the `fresh_root` in that root’s failure and outcome records. The failed audit knew—or necessarily should have known—each exact path because it durably retained the corresponding stdout bytes before sealing.

### 8. Cause of empty `paths_written`

The exact mechanism is:

1. `record_child` inventories only its optional `path_scope` before and after execution ([lines 353 and 422–426 (line 353)](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj/provenance/parent-source.py:353)).
2. For children 18/21/22, `path_scope` was the invented `W/materialization-parent-*`.
3. The production bootstrap always allocates under `/Users/ds/Downloads`, outside those scopes.
4. The recorder did not inspect argv-declared output fields and did not parse stdout before writing `outcome.json`.
5. The correct stdout bytes were retained at line 427, but the child outcome—with `paths_written:[]`—was already finalized.
6. The later discovery routine rejected each exact locator because the root was not a descendant of the rewritten parent, then attempted prohibited parent scanning and score/max selection.
7. The child ledger was never amended after that failed discovery.

Therefore:

- Narrow filesystem attribution was attempted, but against the wrong scope.
- Dynamic root locators were ignored by the authoritative child record.
- The stdout parser/discovery rejected valid locators through its false ancestry assumption.
- Nonzero exit was not a valid reason to skip attribution.
- No structured result parser was reached because discovery returned no root.
- Cleanup was not derived from `paths_written`; it was independently hard-coded to `[WORKSPACE]`, which was even narrower.

### 9. Corrected filesystem-effect contract

For each child, before launch retain:

- Exact argv, cwd, explicit environment, timeout, stdin/stdout/stderr posture.
- Every fixed output path declared by recognized options or bound request records.
- Pre-launch `lstat` state for each fixed path.
- Whether the child can allocate a dynamic root and its only permitted parent/prefix.

For the bootstrap children, stdout must match by byte-level full match:
```
\AAUDIT_ROOT=(/Users/ds/Downloads/ES-validation-custody-v3-full-audit-[a-z0-9_]{8})\n\Z
```

The recorder must require:

- Exactly one locator and no other stdout bytes.
- Empty stderr for a handled bootstrap result.
- Absolute path.
- Direct parent exactly `/Users/ds/Downloads`.
- Basename beginning exactly `ES-validation-custody-v3-full-audit-`.
- No `..`, alternate parent, symlink resolution, multiple locator, or guessed path.
- Fresh `lstat` of the exact path, type directory, mode `0700`.
- Root identity plus complete no-follow inventory.
- Addition to `paths_written` and the cleanup registry even on nonzero exit, timeout, or later parse failure.
- Presence/identity of `bootstrap-start`, and failure/outcome or success records as applicable.
- Failed-root retention posture and cleanup eligibility/disposition.

No broad prefix scan, recursive Downloads traversal, “latest” selection, or score/max fallback is permitted.

If a dynamic root may have been created but no single valid locator is available, freeze:

`filesystem_effect_attribution:dynamic-root-locator-missing-or-invalid`

That is provenance-fatal: stop new root-creating phases, retain the failure capsule, do not claim complete attribution, and do not produce acceptance manifests.

### 10. Failed materialization commands

All three used the correct interpreter, isolation flags, successor source, qualified root, and reconciliation root. They changed these fields:

| FieldAccepted package invocationFailed invocation |                                                                                                               |                                              |
| ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- | -------------------------------------------- |
| Audit parent                                      | `/Users/ds/Downloads`                                                                                         | `W/materialization-parent-28`, `-1`, or `-2` |
| Prefix                                            | `ES-validation-custody-v3-full-audit-`                                                                        | `es-independent-audit-28-`, `-1-`, or `-2-`  |
| Cwd                                               | `S`                                                                                                           | Corresponding invented parent                |
| `HOME`                                            | `S/private`                                                                                                   | Omitted                                      |
| `TMPDIR`                                          | `S/private/tmp`                                                                                               | Invented parent                              |
| `PATH`                                            | `/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin`                                                             | `/usr/bin:/bin`                              |
| Extra env                                         | none                                                                                                          | `PYTHONHASHSEED=0`                           |
| Script spelling                                   | Contract: relative `source/full_audit_bootstrap_v1.py`; successful records also prove the absolute path works | Absolute current successor source            |
| Output option                                     | None; root is returned by stdout                                                                              | None                                         |

The absolute script path was demonstrated by retained successful invocations, so it was not causal. The cwd/environment deviations were not reached as the recorded blocker, but they were not the accepted producer invocation shape and must not be carried forward.

### 11. Exact exit-20 causes

The source allocates the root and emits its locator before parsing the CLI ([lines 1942–1966 (line 1942)](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/source/full_audit_bootstrap_v1.py:1942)).

For all three children, parsing then reached:
```
--audit-parent != /Users/ds/Downloads
```

and failed at lines 1990–1991 with:
```
failed_operation=parse-cli
exception_message=audit_parent_value
exit_class=cli
exit_code=20
```

The altered prefix was a second independent invalid operand, but it was not reached because parent validation came first. Correcting only the parent would next fail with `audit_prefix_value`.

### 12. Corrected materialization commands

Run twice, unchanged between runs:
```
{
  "argv": [
    "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
    "-I",
    "-S",
    "-B",
    "source/full_audit_bootstrap_v1.py",
    "--qualified-launcher-root",
    "/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38",
    "--import-reconciliation-root",
    "/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s",
    "--audit-parent",
    "/Users/ds/Downloads",
    "--audit-prefix",
    "ES-validation-custody-v3-full-audit-"
  ],
  "cwd": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t",
  "environment": {
    "HOME": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private",
    "LANG": "C",
    "LC_ALL": "C",
    "PATH": "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private/tmp"
  },
  "stdin": "DEVNULL",
  "timeout_seconds": 1800,
  "expected_success_exit": 0,
  "result_argument": null,
  "root_result": "strict stdout locator"
}
```

The two returned roots must be distinct by path and device/inode.

### 13. Cleanup-registry defect

[cleanup\_owned\_fixtures (line 2490)](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj/provenance/parent-source.py:2490) set:
```
roots = [WORKSPACE]
```

Consequences:

- None of the three child-created roots entered the registry.
- Cleanup never ran against any survivor.
- No exact absence check was made for them.
- Double ENOENT was checked only for `W`.
- `cleanup_complete:true` was computed as `all()` over that single incomplete registry.
- Process/descriptor checks were global child-stream checks, not per-root survivor checks.
- The final report and preseal repeated the resulting false completion claim.

### 14. Corrected cleanup algorithm

1. Construct the root registry from validated dynamic locators plus fixed audit-owned root outputs.
2. Reject duplicate ownership, identity rebinding, parent/prefix mismatch, or unlocatable dynamic effects.
3. Retain a complete no-follow pre-removal inventory for each root.
4. Require the originating child/process group reaped and every tracked descriptor closed.
5. Immediately before removal, re-lstat and require the original device/inode and authorized direct parent/prefix.
6. Remove only that exact registered root.
7. Perform two fresh `lstat` calls on the exact path.
8. Require `ENOENT` from both.
9. Retain, per row: child ordinal, locator bytes, root identity, inventory identity, removal disposition, both absence observations, and process/descriptor result.
10. Require exact set equality:
```
created_roots
= inventoried_roots
= cleanup_rows
= twice_absent_roots
```

`cleanup_complete` is true only when that equality holds. Cleanup executes in the finite parent’s `finally` path; no administrative continuation is authorized after sealing.

### 15. Finding A reason-oracle reconciliation

| CaseInvocation/mutationActualFailed expectedFailed matchCorrect future disposition |                               |                                                            |                         |     |                                                                            |
| ---------------------------------------------------------------------------------- | ----------------------------- | ---------------------------------------------------------- | ----------------------- | --- | -------------------------------------------------------------------------- |
| exact-separate                                                                     | `P -I -S -B A`                | accept / `pass`                                            | accept / `pass`         | yes | Accept                                                                     |
| reordered-separate                                                                 | `P -B -I -S A`                | accept / `pass`                                            | accept / `pass`         | yes | Accept                                                                     |
| duplicate-complete                                                                 | `P -I -I -S -B A`             | accept / `pass`                                            | accept / `pass`         | yes | **Reject**: `missing_or_duplicate_literal_token:-I`                        |
| combined                                                                           | `P -ISB A`                    | reject / `interpreter_tokens:-I`                           | same                    | yes | Reject; token-count reason for `-I`, `-S`, or `-B`                         |
| missing-I                                                                          | `P -S -B A`                   | reject / `interpreter_effective_state:isolated`            | same                    | yes | Reject; effective `isolated` or missing `-I`                               |
| missing-S                                                                          | `P -I -B A`                   | reject / `interpreter_effective_state:no_site`             | `interpreter_tokens:-S` | no  | Reject; either exact violated invariant                                    |
| missing-B                                                                          | `P -I -S A`                   | reject / `interpreter_effective_state:dont_write_bytecode` | `interpreter_tokens:-B` | no  | Reject; either exact violated invariant                                    |
| missing-all                                                                        | `P A`                         | reject / `…:isolated`                                      | same                    | yes | Reject; closed set of three effective flags or three missing tokens        |
| env substitute B                                                                   | `P -I -S A`, env bytecode=1   | reject / `…:dont_write_bytecode`                           | `interpreter_tokens:-B` | no  | Reject; effective flag or missing `-B`                                     |
| tokens-after-script                                                                | `P A -I -S -B`                | reject / `…:isolated`                                      | same                    | yes | Reject; post-script tokens are nonauthoritative                            |
| duplicate-I/no-S                                                                   | `P -I -I -B A`                | reject / `…:no_site`                                       | `interpreter_tokens:-S` | no  | Reject; no-site, missing-S, or duplicate-I                                 |
| payload token                                                                      | `P -I -S -B A -I`             | accept / `pass`                                            | same                    | yes | Accept; payload token is nonauthoritative                                  |
| flag substring                                                                     | `P AS`                        | reject / `…:isolated`                                      | same                    | yes | Reject; filename text is nonauthoritative                                  |
| wrong interpreter                                                                  | `/usr/bin/python3 -I -S -B A` | reject / `interpreter_identity:sha256`                     | same                    | yes | Reject before success                                                      |
| stale observation                                                                  | mutated child-4 observation   | reject / `interpreter_identity:sha256`                     | same                    | yes | Package mutation oracle: `stale_or_forged_observation`                     |
| absent observation                                                                 | `{}`                          | reject / `interpreter_identity:sha256`                     | same                    | yes | Package mutation oracle: `field_set:record_type`                           |
| contradictory observation                                                          | effective isolated set false  | reject / `…:isolated`                                      | same                    | yes | Package mutation oracle: `success` for its canonical contradictory fixture |

The package contract freezes required effective flags and exactly one occurrence of every literal token, but not a universal order among independent rejection mechanisms. Current source checks effective flags before token counts; that implementation order is evidence, not a cross-version contract promise.

The failed harness had one real false acceptance: duplicate `-I` was accepted. The four reason mismatches were rejections, not package false acceptances. Future pass logic requires rejection before authoritative success and a raw reason in the case-specific closed set.

### 16. Finding C reason-oracle reconciliation

Current audit-source order was: type → mode → link count → identity/path rebinding → read stability → bytes.

| CaseActual reasonFuture allowed reason   |                                    |                                                        |
| ---------------------------------------- | ---------------------------------- | ------------------------------------------------------ |
| stable-copied-destination                | `pass`                             | `pass`                                                 |
| same-size-in-place-before-reopen         | `destination:sha256`               | exact                                                  |
| same-size-replacement-before-reopen      | `destination:sha256`               | exact                                                  |
| replacement-between-observation-and-open | `destination:path-rebinding`       | exact                                                  |
| replacement-after-open                   | `destination:link-count`           | `{destination:link-count, destination:path-rebinding}` |
| pathname-replacement-held-old-descriptor | `destination:link-count`           | `{destination:link-count, destination:path-rebinding}` |
| in-place-mutation-during-held-read       | `destination:mutation-during-read` | exact                                                  |
| mode-change                              | `destination:mode`                 | exact                                                  |
| hardlink-count-change                    | `destination:link-count`           | exact                                                  |
| truncate                                 | `destination:sha256`               | exact                                                  |
| append                                   | `destination:sha256`               | exact                                                  |
| disappearance                            | `destination:disappeared`          | exact                                                  |
| regular-to-symlink                       | `destination:open:62`              | `destination:open:<errno>`                             |
| regular-to-directory                     | `destination:read-error:21`        | `destination:read-error:<errno>`                       |
| cached-observation-substitution          | `destination:sha256`               | exact                                                  |
| unsupported-no-follow-capability         | `capability:no-follow-unproven`    | exact                                                  |
| read-error-partial-read                  | `destination:read-error`           | exact                                                  |

For the two disputed replacements, the old open inode had post-read link count zero while the pathname named a new single-link inode. Both single-link custody and stable path identity were violated. Link count was checked first, so the recorded reason was valid. Both destinations rejected, neither reached authoritative success, and no false acceptance occurred.

### 17. Independent-validator invocation defect

Child 19 invoked:
```
P -I -S -B S/tests/test_full_audit_bootstrap_v1.py
```

The parser at [test\_full\_audit\_bootstrap\_v1.py (line 906)](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/tests/test_full_audit_bootstrap_v1.py:906) requires:

- `--package-root`
- `--result`

Argparse does not constrain their mutual order. The builder omitted them because it hard-coded only interpreter, flags, and script at parent-source lines 1773–1775. It did not inspect the parser or replay the retained successful producer commands.

A second, separate defect exists in child 20: the failed parent generated its own “independent validator” and populated its registry from the parent’s own A/C/H/I/J pass bits. It was circular and was not either package validator.

### 18. Corrected independent-validator command

First, the exact correction for child 19’s package producer-validation surface is:
```
argv:
  P -I -S -B
  S/tests/test_full_audit_bootstrap_v1.py
  --package-root S
  --result ${NEXT_AUDIT_ROOT}/validation/producer-matrix-fresh.json
cwd: S
env:
  HOME=S/private
  LANG=C
  LC_ALL=C
  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
  PYTHONDONTWRITEBYTECODE=1
  TMPDIR=S/private/tmp
timeout: 1800
```

The result must be absent before launch and is created exclusively. Schema:

`execution-substrate.validation-custody-v3.producer-process-self-check-matrix.v1`

Exit semantics: `0` success, `1` completed semantic failure, `2` CLI failure.

The actual package independent runtime validator is:
```
argv:
  P -I -S -B
  S/tests/independent_bootstrap_validator_v1.py
  --package-root S
  --root-a ${ROOT_1}
  --root-b ${ROOT_2}
  --result ${NEXT_AUDIT_ROOT}/validation/independent-bootstrap-validator-result-v1.json
cwd: S
environment: same exact package environment above
timeout: 1800
```

Its result schema is:

`execution-substrate.validation-custody-v3.independent-bootstrap-validator-result.v1`

Exit semantics are likewise `0` success, `1` semantic failure, `2` CLI failure.

### 19. Finding J record grammar

Record:

`S/validation/a-c-h-i-repair/fresh-independent-j-regression-final-v1.json`

- Size: `299,513`
- SHA-256: `7a97496c7c38315dd51773b40d710f12c7eb1c5d541ea4f7fca8adc056fe9145`
- Top-level type: object
- Schema: `execution-substrate.validation-custody-v3.fresh-independent-j-regression.v1`
- `/cases`: list of 928 case objects
- `/case_names`: list of 928 strings
- Case fields: `case_name`, `detail`, `expected_acceptance`, `expected_mechanism`, `kind`, `observed_acceptance`, `observed_mechanisms`, `passed`
- Error metrics are empty arrays, not integer zero:
  - `false_acceptances`
  - `false_rejections`
  - `reason_mismatches`
  - `duplicate_names`
  - `missing_expected_names`
- `skip_count` is integer `0`.
- `success` is boolean.

The name digest is:
```
SHA256(
  json.dumps(case_names,
             sort_keys=True,
             separators=(",", ":"),
             ensure_ascii=True,
             allow_nan=False)
  + "\n"
)
= 1182d02ab865ca2f504dc69d0a88ff118022e98a75433b30701ee0cbd0032d80
```

The failed parser required integer-zero error fields and omitted the compact-JSON-plus-newline digest candidate.

### 20. Field-map record grammar

Record:

`S/analysis/a-c-h-i-field-map-and-consistency-v1.json`

- Size: `786,291`
- SHA-256: `c013aee294e9efbffc9cca79ed5b16982bf64b521187ec5480a74433d3b9fdcb`
- Schema: `execution-substrate.validation-custody-v3.a-c-h-i-repair.field-map-and-consistency.v1`
- `/families`: list of 14 family objects.
- Each family has a `fields` list; flattened sum is 1,052.
- Top fields include `family_count=14` and `field_row_count=1052`.

Family counts are:
```
main-bootstrap-contract                         158
interpreter-invocation-observation              26
copied-artifact-initial-observation             22
copied-artifact-fresh-reverification            43
bootstrap-result                               280
bootstrap-outcome                               40
bootstrap-failure                               38
staged-success-commit                           53
final-success-commit                            53
postcommit-observation                          24
process-self-check-result                       82
qualification-result                           126
publication-matrix                              65
producer-case-registry                          42
```

Each row contains:

`applicability`, `authority_role`, `cardinality`, `contract_identity`, `cross_field_rule`, `enum_or_const`, `json_pointer`, `owner`, `required_or_optional`, `type`, `unknown_field_rule`.

The failed parser searched for one list of exactly 1,052 objects. No such flat list exists.

### 21. Qualification-result grammar

Record:

`S/validation/qualification-result-v1.json`

- Size: `5,338`
- SHA-256: `a2cfaaa9c326aab3628d1929ab6f8e0dfe8412a2d6a0c8dd0baff398e4c46811`
- Schema: `execution-substrate.validation-custody-v3.audit-repair.qualification-result.v1`
- Top-level type: object with these 21 fields:
```
a6_started
authority
candidate_repository_inspected
carrier_0002_handoffs
copy_reverification_causals
finding_j_mutation_matrix
finding_j_regression
first_blocker
full_v3_audit_started
independent_validator
interpreter_causals
materializations
nonauthority
owning_contract
primary_verdict
producer_case_classification
producer_regression
publication_boundary_matrix
schema
success
target_content_inspected
```

Nested grammar recovered from the actual bytes:

- Publication boundary: `case_count=30`, with pass/fail/false-acceptance/false-rejection/reason-mismatch/skip/replay fields.
- J mutation and regression: `case_count=928`.
- Producer regression and classification: `case_count=50`.
- Independent validator: `case_count=104`.
- Interpreter causals: `case_count=10`.
- Copy-reverification causals: `case_count=11`.
- Materializations: `count`, `pass_count`, `roots`, `normalized_equal`, `identity`.
- Carrier handoffs: `count`, `pass_count`, `normalized_equal`, `identity`.

This grammar is frozen without endorsing the values or package verdict.

### 22. Corrected parser specifications

The in-memory read-only fixtures produced the expected structural projections:

| RecordSize / SHA-256Correct extraction |                          |                                                                                                                                    |
| -------------------------------------- | ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------- |
| J final                                | `299513 / 7a97496c…9145` | `/cases` and `/case_names`, both 928; empty error arrays; `skip_count=0`; compact JSON plus newline digest                         |
| Field map                              | `786291 / c013aee2…fdcb` | Flatten `families[*].fields[*]`; require 14 families, sum 1052, per-family declared count equality, unique `(family,json_pointer)` |
| Qualification                          | `5338 / a2cfaaa9…6811`   | Exact 21-field object and explicit nested paths                                                                                    |
| Producer final v2                      | `26762 / 7a859654…ae30`  | Schema producer matrix; `/cases` 50; empty false-acceptance/rejection arrays; nested H/J matrix count 31                           |
| Fresh independent final                | `275948 / b18b9c1f…c229` | Schema fresh independent A/C/H/I/J validator; cases/literal names 104; pass/fail/error arrays and child ledger                     |
| Older producer result                  | `11354 / 6931d34f…5bba`  | Producer schema; cases 50                                                                                                          |
| Older independent result               | `13543 / 96a7f310…38ab`  | Independent-bootstrap-validator schema; cases 50; two runtime roots                                                                |

Every parser must:

- Verify exact byte identity before extraction.
- Reject duplicate JSON object keys and wrong top-level type.
- Require the exact schema string.
- Validate type, presence, and cross-count consistency explicitly.
- Never treat absence as zero.
- Never recursively select an arbitrary same-length list.
- Retain the exact JSON pointer used.
- Separate “grammar parsed” from “claim independently verified”.

The parser fixtures wrote no files and did not execute any validation suite.

### 23. Security-heuristic defect

The failed scanner at parent-source lines 2370–2373 used:
```
if "candidate" in value_lower and "/users/" in value_lower or "v3-target" in value_lower:
```

Because of the final `or`, any string containing `v3-target` was classified as an operational target path.

It matched `v3-target-correctness` in NONAUTHORITY data at:

- `source/full_audit_bootstrap_v1.py:199`
- `source/qualification_harness_v1.py:65`

Both AST constants had source-segment SHA-256:

`1ccd9673cb38f30c158c602898294e3007f3582727e6e6bf73fc181e45ba19fa`

They are contract classification labels, not filesystem paths. The failed scan found no network imports, shell calls, Git invocations, broad Downloads scan, prefix/latest selection, or process/file operation associated with these constants. That establishes the two findings as nonoperational; it does not establish full production-export closure.

### 24. Corrected security-analysis algorithm

1. Parse every in-scope production file to AST; syntax failure is terminal.
2. Classify each literal by AST context:
   - contract data;
   - test fixture;
   - report/error text;
   - filesystem operand;
   - process operand;
   - network operand.
3. Track direct assignments and simple container/argument propagation into sensitive sinks.
4. Filesystem sinks include `open`, `os.open`, stat/lstat/scandir/glob/rglob, `Path` read/write operations, copy/move/remove, and dynamic imports.
5. Process sinks include subprocess/spawn/exec/system and argv passed to them.
6. Network sinks include sockets, URL clients, HTTP libraries, and dynamically imported equivalents.
7. Git sinks include CLI execution and Git-library operations.
8. Permit a literal allowlist only when keyed by file identity, AST node identity, classification, and proof that it cannot flow to an operational sink.
9. For dynamic path expressions, require proof of exact bounded ownership; unresolved dynamic flow is a stop, not a pass.
10. Use behavioral causals for access/export claims that static flow cannot settle.

Exact stops are: parse failure, target/candidate operand reaching a sink, broad Downloads traversal, prefix/latest selection, shell/Git/network execution, unresolved dynamic sink flow, or a failed required behavioral causal.

### 25. Preseal false assertions

[Parent preseal record](/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj/closeout/parent-process-preseal-outcome.json):

- Size: `791`
- SHA-256: `b3e646f4568243b97129b03496d434920255f335b1dba4f544600f1b008fb8e4`

Adjudication:

| Field/statusReconciliation                          |                                                                                                     |
| --------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `every_substantive_phase_completed:true`            | False: materializations failed; handoffs were not reached; producer and validator children failed   |
| `all_child_records_complete:true`                   | Only syntactically true for contiguous/reaped rows; false as a filesystem-effect completeness claim |
| `closing_equality_complete:true`                    | True only for the original supplied-root subset; insufficient as total effect closure               |
| `cleanup_complete:true`                             | False: three created roots were absent from the registry and survived                               |
| A complete/pass                                     | False: four ordering mismatches plus hidden duplicate-token false acceptance                        |
| C complete/pass                                     | False under the failed exact-reason oracle; rejection behavior itself had no false acceptance       |
| H complete/pass                                     | Supported by its retained phase result                                                              |
| I complete/pass                                     | False: wrong-file lexical static test and invalid materialization prevented real-wrapper case 28    |
| J complete/pass                                     | False because of array/digest parser defects                                                        |
| Field-map complete/pass                             | False because nested families were projected as zero rows                                           |
| Validator complete/pass                             | False: child 19 exited 2; child 20 exited 1 and was circular                                        |
| Materialization complete/pass                       | False: all three exited 20                                                                          |
| Security complete/pass                              | False because the literal heuristic was invalid                                                     |
| `temporal_inventory_ready:true`                     | False as an audit-completion assertion because created roots were unattributed/unremoved            |
| `terminal_sealing_is_only_remaining_operation:true` | False                                                                                               |
| `intended_terminal_exit:0`                          | Invalid for this nonqualifying run                                                                  |
| Final report finalized                              | Mechanically true, but its completion claims were not authoritative                                 |
| Successful terminal manifests                       | Improperly produced despite failed success gate                                                     |

### 26. Corrected preseal gate

Successful preseal requires every condition below:

- Every required phase has a terminal record.
- Each record passes its exact schema and internal consistency rules.
- Every child has complete start/outcome/stream/effect attribution.
- Every dynamic root is bound by a valid locator.
- No required phase is “not reached”.
- All materializations and handoffs required by the plan completed successfully.
- Required parsers produced nonempty, type-correct, cross-count-consistent projections.
- A/C/H/I/J, field-map, validator, and security outcomes pass their corrected oracles.
- `created = inventoried = cleanup rows = twice absent`.
- All supplied roots opened by the audit close equal.
- All required confirmations are true.
- No failed child is reclassified merely as “completed”.
- No process, process-group, pipe, file descriptor, or audit-owned root survives.

On failure, the parent may retain a failure capsule, but it must:

- mark successful preseal false;
- omit terminal acceptance manifests/captions;
- record a nonzero terminal disposition;
- perform the registered cleanup before final failure retention;
- prohibit administrative continuation.

### 27. Corrected full-audit execution contract
```
{
  "schema": "execution-substrate.failed-audit-harness-reconciliation.corrected-full-audit-contract.v1",
  "status": "FROZEN_NOT_EXECUTED",
  "fixed_inputs": {
    "failed_audit": {
      "path": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-fbta52kj",
      "device": 16777234,
      "inode": 179539317,
      "mode": "0700",
      "role": "immutable_reconciliation_evidence_only"
    },
    "successor": {
      "path": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t",
      "device": 16777234,
      "inode": 179405897,
      "mode": "0700",
      "manifest_size": 313487,
      "manifest_sha256": "34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d"
    },
    "surviving_evidence_roots": [
      {"path": "/Users/ds/Downloads/ES-validation-custody-v3-full-audit-vg7cmoay", "device": 16777234, "inode": 179539630, "mode": "0700", "role": "immutable_excluded_from_fresh_audit"},
      {"path": "/Users/ds/Downloads/ES-validation-custody-v3-full-audit-oz_rmxfq", "device": 16777234, "inode": 179539660, "mode": "0700", "role": "immutable_excluded_from_fresh_audit"},
      {"path": "/Users/ds/Downloads/ES-validation-custody-v3-full-audit-0fv56xan", "device": 16777234, "inode": 179539671, "mode": "0700", "role": "immutable_excluded_from_fresh_audit"}
    ],
    "interpreter": {
      "path": "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13",
      "version": "Python 3.13.4",
      "size": 119424,
      "sha256": "f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b"
    },
    "qualified_launcher_root": "/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38",
    "import_reconciliation_root": "/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s"
  },
  "parent_model": {
    "finite_one_shot": true,
    "direct_parent_owned_execution": true,
    "subagents": false,
    "direct_auditors": false,
    "administrative_continuation": false,
    "shell": false,
    "stdin": "DEVNULL",
    "failure_flow": "stop_dependent_work_then_cleanup_close_and_retain_failure_capsule"
  },
  "child_recorder": {
    "record_before_launch": ["ordinal", "argv", "cwd", "explicit_environment", "timeout", "fixed_output_paths", "dynamic_output_contract"],
    "record_after_exit": ["exit_or_signal", "stdout_bytes", "stderr_bytes", "reaped", "descriptor_closure", "fixed_path_post_state", "dynamic_locators", "paths_written", "complete_root_inventories", "cleanup_registry_rows"],
    "root_locator_regex": "\\AAUDIT_ROOT=(/Users/ds/Downloads/ES-validation-custody-v3-full-audit-[a-z0-9_]{8})\\n\\Z",
    "locator_count": 1,
    "permitted_parent": "/Users/ds/Downloads",
    "permitted_prefix": "ES-validation-custody-v3-full-audit-",
    "parse_on_nonzero_exit": true,
    "prohibited": ["broad_prefix_scan", "recursive_downloads_scan", "latest_selection", "score_or_max_selection", "pathname_guessing"],
    "missing_locator_failure": "filesystem_effect_attribution:dynamic-root-locator-missing-or-invalid"
  },
  "oracles": {
    "A": {
      "accept": ["exact-separate", "reordered-separate", "payload-flag-token"],
      "reject": {
        "duplicate-with-complete-set": ["missing_or_duplicate_literal_token:-I"],
        "combined-options": ["interpreter_tokens:-I", "interpreter_tokens:-S", "interpreter_tokens:-B"],
        "missing-I": ["interpreter_effective_state:isolated", "interpreter_tokens:-I"],
        "missing-S": ["interpreter_effective_state:no_site", "interpreter_tokens:-S"],
        "missing-B": ["interpreter_effective_state:dont_write_bytecode", "interpreter_tokens:-B"],
        "environment-substitute-B": ["interpreter_effective_state:dont_write_bytecode", "interpreter_tokens:-B"],
        "tokens-after-script": ["interpreter_effective_state:isolated", "interpreter_effective_state:no_site", "interpreter_effective_state:dont_write_bytecode", "interpreter_tokens:-I", "interpreter_tokens:-S", "interpreter_tokens:-B"],
        "duplicate-I-absent-S": ["interpreter_effective_state:no_site", "interpreter_tokens:-S", "missing_or_duplicate_literal_token:-I"],
        "flag-substring-in-script": ["interpreter_effective_state:isolated", "interpreter_effective_state:no_site", "interpreter_effective_state:dont_write_bytecode", "interpreter_tokens:-I", "interpreter_tokens:-S", "interpreter_tokens:-B"],
        "wrong-interpreter": ["interpreter_identity:sha256", "interpreter_path", "interpreter_version", "interpreter_identity"],
        "stale-observation": ["stale_or_forged_observation"],
        "missing-observation": ["field_set:record_type"],
        "contradictory-observation": ["success"]
      },
      "common_rule": "all reject cases must reject before authoritative success"
    },
    "C": {
      "stable-copied-destination": ["pass"],
      "same-size-in-place-before-reopen": ["destination:sha256"],
      "same-size-replacement-before-reopen": ["destination:sha256"],
      "replacement-between-observation-and-open": ["destination:path-rebinding"],
      "replacement-after-open": ["destination:link-count", "destination:path-rebinding"],
      "pathname-replacement-held-old-descriptor": ["destination:link-count", "destination:path-rebinding"],
      "in-place-mutation-during-held-read": ["destination:mutation-during-read"],
      "mode-change": ["destination:mode"],
      "hardlink-count-change": ["destination:link-count"],
      "truncate": ["destination:sha256"],
      "append": ["destination:sha256"],
      "disappearance": ["destination:disappeared"],
      "regular-to-symlink": ["destination:open:<errno>"],
      "regular-to-directory": ["destination:read-error:<errno>"],
      "cached-observation-substitution": ["destination:sha256"],
      "unsupported-no-follow-capability": ["capability:no-follow-unproven"],
      "read-error-partial-read": ["destination:read-error"]
    }
  },
  "parsers": {
    "J": {
      "cases_pointer": "/cases",
      "names_pointer": "/case_names",
      "required_count": 928,
      "zero_array_fields": ["false_acceptances", "false_rejections", "reason_mismatches", "duplicate_names", "missing_expected_names"],
      "name_digest_encoding": "compact_sorted_ascii_json_plus_newline"
    },
    "field_map": {
      "families_pointer": "/families",
      "required_family_count": 14,
      "row_projection": "/families/*/fields/*",
      "required_row_count": 1052,
      "unique_key": ["family", "json_pointer"]
    },
    "qualification": {
      "top_level_field_count": 21,
      "explicit_nested_paths_required": true,
      "recursive_same_length_selection": false
    }
  },
  "cleanup": {
    "registry_sources": ["validated_dynamic_locators", "fixed_audit_owned_output_roots"],
    "pre_removal_complete_inventory": true,
    "revalidate_device_inode_before_remove": true,
    "exact_registered_root_only": true,
    "fresh_lstat_enoent_observations": 2,
    "required_set_equality": ["created_roots", "inventoried_roots", "cleanup_rows", "twice_absent_roots"]
  },
  "preseal": {
    "all_required_phases_terminal": true,
    "all_required_phases_pass": true,
    "all_child_effects_attributed": true,
    "cleanup_set_equality": true,
    "supplied_root_closing_equality": true,
    "nonempty_consistent_parser_results": true,
    "no_not_reached_phase": true,
    "all_confirmations_true": true,
    "failed_child_never_counts_as_pass": true
  },
  "terminal_gates": {
    "success": "only_if_preseal_all_true",
    "failure_capsule": "any_required_failure_or_blocker",
    "provenance_mismatch": "supplied_root_inequality_or_incomplete_filesystem_effect_attribution",
    "acceptance_manifests_on_failure": false
  },
  "phases": [
    {
      "phase_id": "P00_OPENING",
      "prerequisites": [],
      "operands": ["fixed_inputs"],
      "classification": "in_process",
      "expected_outputs": ["authenticated identities", "complete opening inventories"],
      "pass_rule": "all fixed identities and manifests exact",
      "failure_rule": "provenance failure; no substantive child launch",
      "may_continue_on_failure": false,
      "cleanup_obligations": [],
      "preseal_contribution": "opening_identity_pass"
    },
    {
      "phase_id": "P01_RECORDER_CAUSALS",
      "prerequisites": ["P00_OPENING"],
      "operands": ["ENOENT child", "/usr/bin/true", "pinned Python --version"],
      "classification": "child",
      "expected_outputs": ["complete start/outcome/stream records"],
      "pass_rule": "spawn error, empty streams, reaping and closure classified exactly",
      "failure_rule": "recorder nonqualifying",
      "may_continue_on_failure": false,
      "cleanup_obligations": [],
      "preseal_contribution": "recorder_pass"
    },
    {
      "phase_id": "P02_STATIC_INTERFACES",
      "prerequisites": ["P01_RECORDER_CAUSALS"],
      "operands": ["successor contract, source interfaces, parser grammars"],
      "classification": "in_process",
      "expected_outputs": ["identity-bound interface record"],
      "pass_rule": "exact CLI and grammar recovered without target inspection",
      "failure_rule": "BLOCK",
      "may_continue_on_failure": true,
      "cleanup_obligations": [],
      "preseal_contribution": "static_interface_pass"
    },
    {
      "phase_id": "P03_FINDING_A",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["oracles.A", "direct probe cases"],
      "classification": "child_and_in_process",
      "expected_outputs": ["complete A matrix with raw reasons"],
      "pass_rule": "accept/reject and case-specific reason closure",
      "failure_rule": "A phase fails; evidence collection may continue",
      "may_continue_on_failure": true,
      "cleanup_obligations": ["remove private probe files during parent cleanup"],
      "preseal_contribution": "A_pass"
    },
    {
      "phase_id": "P04_FINDING_C",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["oracles.C", "private custody fixtures"],
      "classification": "in_process",
      "expected_outputs": ["complete C matrix and traces"],
      "pass_rule": "no false acceptance and reason in closed set",
      "failure_rule": "C phase fails",
      "may_continue_on_failure": true,
      "cleanup_obligations": ["register all C fixture roots"],
      "preseal_contribution": "C_pass"
    },
    {
      "phase_id": "P05_FINDING_H",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["publication state machine", "behavioral no-replace capability causal"],
      "classification": "in_process",
      "expected_outputs": ["H matrix", "capability evidence"],
      "pass_rule": "behavior proves required capability; no OS-label branch",
      "failure_rule": "fail fast; no fallback publication",
      "may_continue_on_failure": true,
      "cleanup_obligations": ["register H fixtures"],
      "preseal_contribution": "H_pass"
    },
    {
      "phase_id": "P06_FINDING_I_STATIC",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["materialized wrapper, phase runner, request and launch contracts"],
      "classification": "in_process",
      "expected_outputs": ["ownership-aware I classification"],
      "pass_rule": "payload verification and compile/execute boundaries found at owning layers",
      "failure_rule": "I phase fails",
      "may_continue_on_failure": true,
      "cleanup_obligations": [],
      "preseal_contribution": "I_static_pass"
    },
    {
      "phase_id": "P07_RECORD_PARSERS",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["J, field-map, qualification, producer and validator records"],
      "classification": "in_process",
      "expected_outputs": ["nonempty identity-bound parser projections"],
      "pass_rule": "all grammar and cross-count rules pass",
      "failure_rule": "parser phase fails",
      "may_continue_on_failure": true,
      "cleanup_obligations": [],
      "preseal_contribution": "parser_pass"
    },
    {
      "phase_id": "P08_PRODUCER_VALIDATION",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["corrected producer command"],
      "classification": "child",
      "expected_outputs": ["fresh producer result"],
      "pass_rule": "exit 0 and result schema/success pass independently",
      "failure_rule": "validation fails",
      "may_continue_on_failure": true,
      "cleanup_obligations": ["attribute and clean any nested audit-owned roots"],
      "preseal_contribution": "producer_validation_pass"
    },
    {
      "phase_id": "P09_MATERIALIZE_1",
      "prerequisites": ["P00_OPENING", "P01_RECORDER_CAUSALS"],
      "operands": ["canonical materialization command"],
      "classification": "child",
      "expected_outputs": ["one strict locator", "ROOT_1 complete inventory"],
      "pass_rule": "exit 0, success commit present, exact effect attribution",
      "failure_rule": "jump to cleanup/failure; locator still mandatory",
      "may_continue_on_failure": false,
      "cleanup_obligations": ["register ROOT_1 on every exit"],
      "preseal_contribution": "materialization_1_pass"
    },
    {
      "phase_id": "P10_MATERIALIZE_2",
      "prerequisites": ["P09_MATERIALIZE_1"],
      "operands": ["same canonical materialization command"],
      "classification": "child",
      "expected_outputs": ["one strict locator", "ROOT_2 complete inventory"],
      "pass_rule": "exit 0, success commit present, ROOT_2 distinct from ROOT_1",
      "failure_rule": "jump to cleanup/failure",
      "may_continue_on_failure": false,
      "cleanup_obligations": ["register ROOT_2 on every exit"],
      "preseal_contribution": "materialization_2_pass"
    },
    {
      "phase_id": "P11_HANDOFF_1",
      "prerequisites": ["P09_MATERIALIZE_1", "P10_MATERIALIZE_2"],
      "operands": ["ROOT_1 bound handoff command"],
      "classification": "child",
      "expected_outputs": ["ROOT_1 process-self-check result and phase records"],
      "pass_rule": "exit 0 and bound result validates",
      "failure_rule": "handoff failure",
      "may_continue_on_failure": false,
      "cleanup_obligations": ["ROOT_1 remains registered"],
      "preseal_contribution": "handoff_1_pass"
    },
    {
      "phase_id": "P12_HANDOFF_2",
      "prerequisites": ["P11_HANDOFF_1"],
      "operands": ["ROOT_2 bound handoff command"],
      "classification": "child",
      "expected_outputs": ["ROOT_2 process-self-check result and phase records"],
      "pass_rule": "exit 0, bound result validates, normalized handoffs equal",
      "failure_rule": "handoff failure",
      "may_continue_on_failure": false,
      "cleanup_obligations": ["ROOT_2 remains registered"],
      "preseal_contribution": "handoff_2_pass"
    },
    {
      "phase_id": "P13_INDEPENDENT_VALIDATOR",
      "prerequisites": ["P11_HANDOFF_1", "P12_HANDOFF_2"],
      "operands": ["package independent validator command", "ROOT_1", "ROOT_2"],
      "classification": "child",
      "expected_outputs": ["fresh independent validator result"],
      "pass_rule": "exit 0, exact schema, two roots bound, success true",
      "failure_rule": "validator failure",
      "may_continue_on_failure": true,
      "cleanup_obligations": ["ROOT_1 and ROOT_2 remain registered"],
      "preseal_contribution": "independent_validator_pass"
    },
    {
      "phase_id": "P14_SECURITY",
      "prerequisites": ["P02_STATIC_INTERFACES"],
      "operands": ["source-aware AST/dataflow algorithm"],
      "classification": "in_process",
      "expected_outputs": ["operation-classified findings"],
      "pass_rule": "no unresolved or prohibited operational flow",
      "failure_rule": "security phase fails; export not declared closed",
      "may_continue_on_failure": true,
      "cleanup_obligations": [],
      "preseal_contribution": "security_pass"
    },
    {
      "phase_id": "P15_CLEANUP",
      "prerequisites": [],
      "operands": ["exact cleanup registry"],
      "classification": "in_process_finally",
      "expected_outputs": ["one cleanup row per created root"],
      "pass_rule": "created=inventoried=cleanup=twice absent; no survivors",
      "failure_rule": "AUDIT_PROVENANCE_MISMATCH",
      "may_continue_on_failure": false,
      "cleanup_obligations": ["self"],
      "preseal_contribution": "cleanup_set_equality"
    },
    {
      "phase_id": "P16_CLOSING_EQUALITY",
      "prerequisites": ["P15_CLEANUP"],
      "operands": ["every supplied root opened by P00 or later"],
      "classification": "in_process",
      "expected_outputs": ["complete closing inventories and zero-diff rows"],
      "pass_rule": "opening and closing projections exactly equal",
      "failure_rule": "AUDIT_PROVENANCE_MISMATCH",
      "may_continue_on_failure": false,
      "cleanup_obligations": [],
      "preseal_contribution": "supplied_root_closing_equality"
    },
    {
      "phase_id": "P17_PRESEAL",
      "prerequisites": ["P15_CLEANUP", "P16_CLOSING_EQUALITY"],
      "operands": ["all terminal phase records"],
      "classification": "in_process",
      "expected_outputs": ["success preseal or failure-gate record"],
      "pass_rule": "every preseal condition true",
      "failure_rule": "failure capsule only; no acceptance manifests",
      "may_continue_on_failure": false,
      "cleanup_obligations": [],
      "preseal_contribution": "gate"
    },
    {
      "phase_id": "P18_TERMINAL",
      "prerequisites": ["P17_PRESEAL"],
      "operands": ["preseal decision"],
      "classification": "in_process",
      "expected_outputs": ["success seal or unsealed failure capsule"],
      "pass_rule": "success manifests only on successful preseal",
      "failure_rule": "nonzero terminal failure disposition",
      "may_continue_on_failure": false,
      "cleanup_obligations": [],
      "preseal_contribution": "terminal"
    }
  ]
}
```

### 28. Exact next full-audit command plan

Common package environment:
```
{
  "HOME": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private",
  "LANG": "C",
  "LC_ALL": "C",
  "PATH": "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
  "PYTHONDONTWRITEBYTECODE": "1",
  "TMPDIR": "/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private/tmp"
}
```

1. **Materialization 1:** exact invocation from section 12; timeout 1,800; success exit 0; strict locator yields `${ROOT_1}`.
2. **Materialization 2:** byte-identical invocation; timeout 1,800; strict locator yields distinct `${ROOT_2}`.
3. **Carrier 0002 handoff 1:**
```
P -I -S -B
${ROOT_1}/source/wrapped_carrier_launcher.py
--launch-contract ${ROOT_1}/contract/wrapped-carrier-launch-contract-v1.json
--request ${ROOT_1}/provenance/carrier-0002.request.json
```

Cwd `${ROOT_1}`; environment is the six-key map with `HOME=${ROOT_1}/private/home`, `TMPDIR=${ROOT_1}/private/tmp`; timeout 600; result `${ROOT_1}/opening/process-self-check-payload-result.json`; exit 0 required; stderr empty.

4. **Carrier 0002 handoff 2:** same template with `${ROOT_2}`; same timeout/result/exit rules.
5. **Package independent validator:**
```
P -I -S -B
S/tests/independent_bootstrap_validator_v1.py
--package-root S
--root-a ${ROOT_1}
--root-b ${ROOT_2}
--result ${NEXT_AUDIT_ROOT}/validation/independent-bootstrap-validator-result-v1.json
```

Cwd `S`; common package environment; timeout 1,800; result must be absent before launch; exit 0 and schema success required.

The corrected producer command from section 18 is also a required validation phase and uses `${NEXT_AUDIT_ROOT}/validation/producer-matrix-fresh.json`.

6. **External security/capability causals:** no separate external security command is required. Security AST/dataflow and C/H filesystem capability checks are direct in-process operations. H must use a behavioral no-replace operation, never an OS-name branch. Finding A’s external command matrix is exactly children 4–17, with the corrected duplicate-token expectation in section 15; each has timeout 60.
7. **Cleanup:** no shell cleanup command is permitted. The finite parent invokes the in-process registry algorithm from section 14 against the exact device/inode-bound `${ROOT_1}`, `${ROOT_2}`, and every other registered private fixture root. No glob, prefix deletion, broad `rm`, or post-seal continuation is allowed.

### 29. Supplied-root closing equality

The closing projection uses path, type, device, inode, mode, link count, size, mtime\_ns, ctime\_ns, symlink target where applicable, and regular-file SHA-256.

| RootClosing entriesClosing inventory SHA-256Opening→closing difference |       |                                                                    |   |
| ---------------------------------------------------------------------- | ----- | ------------------------------------------------------------------ | - |
| Failed audit                                                           | 177   | `7261fb8290be224ebbe7f3e222cd369327c7d7436e147d2ac0cfd71c41ca564b` | 0 |
| Successor                                                              | 1,209 | `9723bd3b553afa8095bdb6a4ec85db90b4c7bec7343a02e7974e402447f77d48` | 0 |
| `vg7cmoay`                                                             | 5     | `15a398f954376b2ad3f01db8005efa822a9cbb022615c1aa329b365c8b7b32f9` | 0 |
| `oz_rmxfq`                                                             | 5     | `e1449b5446fd9a7ac378beb06504810bee6ad3586d826ae374f5e433ded30ce4` | 0 |
| `0fv56xan`                                                             | 5     | `abb42e9772abdacc667582947c873f421fc410518e90ed34fe819d1453c71450` | 0 |

No optional external package root was directly opened. No diagnostic output root was created. Closing equality passed for every supplied root opened.

### 30. Remaining uncertainty and nonclaims

- No successor-package finding or verdict was adjudicated.
- Package-reported case counts were parsed structurally, not accepted as independently correct.
- This reconciliation does not declare production export/security closed.
- The qualified-launcher and import-reconciliation roots were not independently reopened; their exact paths and use were recovered from the authenticated package contract and successful process records. The next full audit must bind their identities through its opening and bootstrap verification.
- The failed audit’s H result is reported as retained harness evidence, not newly rerun evidence.
- No indispensable command, child stream, failure record, root locator, or parser input was missing.

### 31. Explicit confirmations
```
FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
SUCCESSOR_PACKAGE_MUTATION_NOT_PERFORMED
SURVIVING_MATERIALIZATION_ROOTS_MUTATION_NOT_PERFORMED
SURVIVING_MATERIALIZATION_ROOTS_NOT_CLEANED
PACKAGE_FINDINGS_NOT_READJUDICATED
NO_SUCCESSOR_REPAIR_PERFORMED
EVERY_CHILD_CROSSWALKED
EVERY_SURVIVING_ROOT_ATTRIBUTED
DYNAMIC_ROOT_LOCATOR_CONTRACT_FROZEN
PATHS_WRITTEN_FALSE_CLAIM_CAUSE_IDENTIFIED
MATERIALIZATION_EXIT_20_CAUSES_IDENTIFIED
CORRECTED_MATERIALIZATION_COMMANDS_FROZEN
INDEPENDENT_VALIDATOR_COMMAND_CORRECTED
FINDING_A_REASON_ORACLE_CORRECTED
FINDING_C_REASON_ORACLE_CORRECTED
FINDING_J_RECORD_GRAMMAR_RECONSTRUCTED
FIELD_MAP_RECORD_GRAMMAR_RECONSTRUCTED
SECURITY_ORACLE_CORRECTED
CLEANUP_SET_EQUALITY_RULE_FROZEN
PRESEAL_SUCCESS_GATE_FROZEN
NO_FULL_AUDIT_EXECUTED
NO_GIT_INVOCATION
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_SUBAGENTS_CREATED
```
