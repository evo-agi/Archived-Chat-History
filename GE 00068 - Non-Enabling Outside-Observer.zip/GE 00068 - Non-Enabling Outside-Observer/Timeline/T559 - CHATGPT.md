## Engineering assessment

The real audit still has **not** executed, and the single authorization remains unconsumed. All fixed inputs, the replacement subject, the accepted implementation chain, and the 89-member audit PYZ authenticated successfully. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The current launch authority is not merely incomplete; it is internally unexecutable:

```text
launch profile:
  tempfile.mkdtemp(...) creates FRESH_PRIVATE_AUDIT_ROOT
  cwd = FRESH_PRIVATE_AUDIT_ROOT
  --output-root = FRESH_PRIVATE_AUDIT_ROOT

frozen audit runtime:
  os.makedirs(output_root, mode=0o700, exist_ok=False)
```

The profile therefore guarantees that the harness receives an already-existing path while the frozen runtime requires that exact path to be absent. Launching would deterministically fail with `FileExistsError` before capsule construction or terminal framing. :chatgpt-content-reference{index="2"}

Codex correctly stopped before allocating roots, running the platform preflight, or creating the audit process. No streams, PID, capsule, or subject result exist. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

### Classification

```text
SELF_CONTRADICTORY_EXTERNAL_ROOT_LIFECYCLE_CONTRACT
```

This is not a defect in:

- the replacement subject;
- the audit oracle or semantic logic;
- the audit PYZ’s package closure;
- the runtime authority’s fixed identities;
- the accepted reconstruction-parent implementation.

The defect lies at the **external launch-profile ↔ frozen runtime integration boundary**. The report itself identifies the same repair surface and asserts no subject blocker. :chatgpt-content-reference{index="5"}

## Correct root model

The safest additive correction is a two-path model:

```text
WRAPPER_WORKSPACE_ROOT
  existing directory created by tempfile.mkdtemp
  submitted cwd

AUDIT_CAPSULE_ROOT
  exact absent child:
  <WRAPPER_WORKSPACE_ROOT>/audit-capsule
  passed through --output-root
  created by the frozen audit runtime
```

This preserves both necessary facts:

- the process receives a valid existing cwd;
- `core.create_synthetic_capsule` receives a nonexistent output path.

Before adopting that model, the next task must prove from the frozen PYZ and runtime authority that:

1. no runtime contract requires `cwd == output_root`;
2. `output_root` is passed independently to the capsule creator;
3. the terminal frame’s `capsule_root` must equal the absent child path, not cwd;
4. no other source or self-authentication rule implicitly conflates the two paths.

If any such equality is required by the frozen runtime, launch-authority-only repair is impossible. The task must stop and select a separately governed harness repair rather than silently widening the profile.

## Progression decision

Create a second additive successor launch authority:

- **launch profile v2**;
- **launch certificate v3**.

Keep the audit PYZ and runtime authority byte-identical.

The current profile v1 and certificate v2 become historical and contribute zero current authorizations. Certificate v3 replaces—not supplements—their unconsumed authorization. There must remain exactly one active future audit authorization.

Do not execute the real audit in this tranche.

---

## Complete replacement Codex prompt

```text
REPAIR AND COMPLETE THE EXTERNAL ROOT-LIFECYCLE AUTHORITY FOR THE
CLEAN REPLACEMENT-SUBJECT INDEPENDENT-AUDIT HARNESS

PRESERVE THE AUDIT PYZ AND RUNTIME AUTHORITY BYTE-FOR-BYTE;
CREATE LAUNCH PROFILE V2 AND LAUNCH CERTIFICATE V3

Objective

Repair the self-contradictory external root-lifecycle contract that prevented
the real replacement-subject audit from launching.

The current launch profile requires:

- wrapper allocation of `FRESH_PRIVATE_AUDIT_ROOT` by `tempfile.mkdtemp`;
- submitted cwd equal to that root;
- `--output-root` equal to that same root.

The frozen audit runtime then forwards `--output-root` to:

core.create_synthetic_capsule(...)

which executes:

os.makedirs(root, mode=0o700, exist_ok=False)

The current profile therefore supplies an existing path where the frozen
runtime requires an absent path.

No audit process was created.
No platform preflight ran.
No wrapper root or audit root was allocated.
The single real-audit authorization remains unconsumed.
No subject verdict exists.

Create one additive successor launch-authority generation.

First determine whether the unchanged frozen runtime supports this split-root
model:

- an existing wrapper-owned workspace used as cwd;
- an absent exact child path passed through `--output-root`;
- the frozen runtime creates that child as the audit capsule root.

If the frozen runtime, runtime authority, parent self-authentication contract,
or terminal-frame contract requires `cwd == output_root`, do not create a
successor profile that violates it.

Instead return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_REPAIR_BLOCKED_REQUIRES_HARNESS_CHANGE

Do not modify the harness in this task.

If the split-root model is fully compatible, create:

1. launch profile v2;
2. launch certificate v3.

Do not modify, rebuild, or replace:

- the final audit PYZ;
- the runtime authority;
- audit source;
- source freeze;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Do not execute the real replacement-subject audit in this task.

Do not execute audit mode.

Qualification or synthetic mode may be used only when the exact embedded CLI
supports it and only to qualify the split-root lifecycle without issuing a real
subject verdict.

Do not mutate the replacement subject.

Do not promote or rebind current schema authority.

Do not modify a repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not install dependencies.

Do not invoke product or live-service behavior.

Do not run target audit.

Do not rerun product runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Use one finite source-external launch-authority builder in one fresh private
root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_REPAIR_BLOCKED_REQUIRES_HARNESS_CHANGE

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. UNCHANGED AUDIT PYZ
──────────────────────────────────────────────────────────────────────────────

FINAL_AUDIT_PYZ:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz

Expected identity:

- device:
  16777234;
- inode:
  182699827;
- mode:
  0400;
- link count:
  1;
- size:
  4589679;
- SHA-256:
  00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0.

Authenticate using two stable no-follow reads.

Require complete opening/closing equality.

Do not mutate the PYZ.

──────────────────────────────────────────────────────────────────────────────
2. UNCHANGED RUNTIME AUTHORITY
──────────────────────────────────────────────────────────────────────────────

FINAL_RUNTIME_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182699838;
- mode:
  0400;
- link count:
  1;
- size:
  56463;
- SHA-256:
  9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0.

Strict-parse with duplicate-key and nonfinite-number rejection.

Require complete opening/closing equality.

Do not mutate the authority.

──────────────────────────────────────────────────────────────────────────────
3. CURRENT INVALID LAUNCH PROFILE V1
──────────────────────────────────────────────── LIMITED TO SUPERSESSION EVIDENCE
────────────────────────────────────────────────

CURRENT_LAUNCH_PROFILE_V1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182723650;
- mode:
  0400;
- link count:
  1;
- size:
  9131;
- SHA-256:
  14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568.

Authenticate its exact current bytes and schema.

Classify after successor closure:

HISTORICAL_SUPERSEDED_SELF_CONTRADICTORY_ROOT_LIFECYCLE_PROFILE

Required facts:

- profile identity valid:
  true;
- profile schema valid:
  true;
- profile current before successor closure:
  true;
- real audit count consumed:
  0;
- deterministic root contradiction:
  proven;
- may authorize a future launch after successor closure:
  false;
- mutation:
  forbidden;
- deletion:
  forbidden.

──────────────────────────────────────────────── LIMITED TO CERTIFICATE LINEAGE
────────────────────────────────────────────────

4. CURRENT INVALID SUCCESSOR CERTIFICATE V2

CURRENT_LAUNCH_CERTIFICATE_V2:

/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json

Expected identity:

- device:
  16777234;
- inode:
  182723661;
- mode:
  0400;
- link count:
  1;
- size:
  12987;
- SHA-256:
  f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f.

Authenticate its exact current bytes and schema.

Classify after successor closure:

HISTORICAL_SUPERSEDED_SELF_CONTRADICTORY_ROOT_LIFECYCLE_CERTIFICATE

Required facts:

- certificate identity valid:
  true;
- certificate schema valid:
  true;
- PYZ/runtime bindings valid:
  true;
- real audit authorization consumed:
  false;
- current before successor closure:
  true;
- current after successor closure:
  false;
- authorization count after successor closure:
  0;
- mutation:
  forbidden;
- deletion:
  forbidden.

The new certificate replaces its unconsumed authorization.

It does not create an additional authorization.

──────────────────────────────────────────────── LIMITING EARLIER CERTIFICATE
────────────────────────────────────────────────

5. HISTORICAL PREDECESSOR CERTIFICATE V1

PREDECESSOR_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.launch-certificate-v1.json

Expected identity:

- device:
  16777234;
- inode:
  182699841;
- mode:
  0400;
- link count:
  1;
- size:
  3572;
- SHA-256:
  525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c.

Authenticate only predecessor lineage.

Require:

- current:
  false;
- authorization count:
  0;
- mutation:
  forbidden.

────────────────────────────────────────────────

6. REPLACEMENT SUBJECT AND CONSTRUCTION CHAIN

REPLACEMENT_SUBJECT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54

Expected identity:

- device:
  16777234;
- inode:
  182649818;
- mode:
  0700;
- UID/GID:
  501/20.

REPLACEMENT_CONSTRUCTION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a

Expected identity:

- device:
  16777234;
- inode:
  182648782;
- mode:
  0700;
- UID/GID:
  501/0.

Authenticate only:

- replacement-subject identity and terminal closure;
- construction-wrapper identity;
- one-shot construction custody;
- pending-independent-audit posture;
- no second construction.

Do not independently audit subject semantics.

Do not mutate or clean either root.

Require opening/closing equality.

──────────────────────────────────────────────── LIMITING ACCEPTED IMPLEMENTATION
────────────────────────────────────────────────

7. ACCEPTED IMPLEMENTATION AUTHORITY

ACCEPTED_IMPLEMENTATION_AUDIT_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04

Expected identity:

- device:
  16777234;
- inode:
  182593190;
- mode:
  0700.

ACCEPTED_IMPLEMENTATION_WRAPPER_ROOT:

/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg

Expected identity:

- device:
  16777234;
- inode:
  182593189;
- mode:
  0700.

Expected disposition:

GEN2_IMPLEMENTATION_PACKAGE_ACCEPT

Authenticate only current chain bindings.

Do not re-audit the implementation package.

Require opening/closing equality.

────────────────────────────────────────────────

8. CURRENT CONTENT INPUTS

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234;
- inode:
  181651092;
- mode:
  0400;
- link count:
  1;
- size:
  13598758;
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671.

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234;
- inode:
  181651098;
- mode:
  0400;
- link count:
  1;
- size:
  19737;
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563.

Authenticate authority before ZIP interpretation.

Require opening/closing equality.

────────────────────────────────────────────────

9. FRESH BUILD AND OUTPUT ROOTS

Allocate one fresh private build root beneath `/private/tmp`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-`.

Immediately emit:

ROOT_LIFECYCLE_AUTHORITY_BUILD_ROOT=<absolute-path>

Allocate one fresh output directory beneath `/Users/ds/Downloads`:

- `tempfile.mkdtemp`;
- umask:
  `077`;
- prefix:
  `ES-repair10i-v3-replacement-subject-audit-root-lifecycle-authority-output-`.

Immediately emit:

ROOT_LIFECYCLE_AUTHORITY_OUTPUT_ROOT=<absolute-path>

Successful final outputs:

gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json

gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json

The output directory is nonauthoritative.

Before source creation retain:

opening/bootstrap-start.json
opening/root-lifecycle-authority-builder-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-profile-certificate-disposition-v1.json
opening/process-execution-policy-v1.json

──────────────────────────────────────────────────────────────────────────────
10. FROZEN RUNTIME ROOT-FLOW ADJUDICATION
────────────────────────────────────────────────

Before selecting a repair, retain:

analysis/frozen-runtime-root-flow-adjudication-v1.json

Inspect the exact frozen PYZ members and runtime-authority records governing:

- CLI argument parsing;
- `--output-root`;
- cwd observation and validation;
- audit-parent forwarding;
- capsule creation;
- parent runtime self-authentication;
- terminal-frame generation;
- capsule-root reporting;
- cleanup and terminal closure.

At minimum authenticate and crosswalk:

__main__.py

- expected size:
  2326;
- expected SHA-256:
  09798990a92fdf4288ab21864c7604887fcec897f3deafe20c71465506b78da3.

audit_parent.py

- expected size:
  8550;
- expected SHA-256:
  ba6adc73b27444743cbd49dd71d4f5894d92d3bfe011975e5fe7cc845e9d63bd.

Resolve the exact current `core.py` role and identity through the embedded member
registry. Do not select it by basename alone.

Retain exact answers:

1. Does the CLI accept an absolute nonexistent `--output-root` path?
2. Does the parent forward that path without precreating it?
3. Does the capsule creator require it to be absent?
4. Does the capsule creator create the path exactly once?
5. Does any frozen source require cwd to equal output root?
6. Does runtime self-authentication require cwd to equal output root?
7. Does the terminal frame require `capsule_root` to equal output root?
8. Does any cleanup or terminal logic treat cwd as capsule root?
9. Does any code derive output root from cwd rather than the explicit operand?
10. Can an existing workspace cwd and absent child output path coexist without
    semantic change?

Retain exact:

- source path;
- function/class;
- AST node;
- call chain;
- governing authority record;
- result;
- direct evidence.

──────────────────────────────────────────────── LIMITING REPAIR CHOICE
────────────────────────────────────────────────

11. ROOT-LIFECYCLE REPAIR DECISION

Retain:

analysis/root-lifecycle-repair-decision-v1.json

Select exactly one.

A. SPLIT_ROOT_LAUNCH_AUTHORITY

Select only when Section 10 proves:

- cwd and output root are independent;
- runtime accepts an absent output path;
- runtime creates that path;
- terminal frame reports that path;
- no runtime authority requires equality.

Then continue with launch profile v2 and certificate v3.

B. HARNESS_CHANGE_REQUIRED

Select when any frozen runtime or authority rule requires:

- cwd equals output root;
- output root preexists;
- output root is derived from cwd;
- another contradiction that cannot be solved externally.

Then:

- do not create current successor profile/certificate;
- do not mutate the harness;
- return:
  GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_REPAIR_BLOCKED_REQUIRES_HARNESS_CHANGE;
- identify the exact harness source/authority repair surface;
- stop.

Do not select by preference.

Select from exact frozen evidence.

──────────────────────────────────────────────── LIMITED TO ADDITIVE POLICY
────────────────────────────────────────────────

12. SPLIT-ROOT EXTERNAL LAUNCH POLICY

Only when `SPLIT_ROOT_LAUNCH_AUTHORITY` is selected, retain:

opening/split-root-external-launch-policy-v1.json

Freeze:

A. Wrapper workspace allocation

Owner:

external wrapper

Algorithm:

- `tempfile.mkdtemp`;
- parent:
  `/private/tmp`;
- prefix:
  `ES-repair10i-v3-replacement-schema-subject-real-audit-workspace-`;
- umask:
  `077`.

Requirements:

- freshly allocated;
- absolute;
- directory;
- no symlink;
- mode:
  `0700`;
- empty at allocation;
- no broad scan or fallback.

Placeholder:

`<FRESH_PRIVATE_AUDIT_WORKSPACE>`

B. Capsule output path

Exact path:

`<FRESH_PRIVATE_AUDIT_WORKSPACE>/audit-capsule`

Placeholder:

`<ABSENT_AUDIT_CAPSULE_ROOT>`

Requirements before preflight and audit launch:

- absolute path;
- direct child of workspace;
- basename exactly:
  `audit-capsule`;
- does not exist;
- no symlink;
- no existing path component below workspace;
- no alternative candidate;
- no fallback;
- no scan.

Owner of creation:

frozen audit runtime

The wrapper must not create this child path.

C. Submitted cwd

Exactly:

`<FRESH_PRIVATE_AUDIT_WORKSPACE>`

Classification:

EXTERNAL_WRAPPER_NONAUTHORITATIVE_LAUNCH_CONTEXT

D. Audit argv

Use the existing exact argv, replacing only:

```text
--output-root
<ABSENT_AUDIT_CAPSULE_ROOT>
```

Do not change another operand.

E. Environment and process posture

Preserve exactly:

```text
PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0
```

No inherited environment.

```text
stdin = DEVNULL
shell = false
TTY = false
detachment = false
foreground = true
synchronous = true
```

F. Platform preflight

Run in workspace cwd.

Require:

- workspace remains empty;
- capsule child remains absent;
- exact stdout/stderr markers;
- exit 23;
- signal null;
- no file or child.

G. Real launch preconditions

Immediately before process creation:

- workspace identity unchanged;
- workspace empty;
- capsule child absent;
- all fixed inputs reauthenticated.

H. Authorization consumption

Preserve:

- consumed only on successful audit-parent creation;
- prelaunch failure leaves authorization unconsumed;
- after creation consumption is final.

I. Post-launch root authority

The audit capsule root is:

`<ABSENT_AUDIT_CAPSULE_ROOT>`

not the workspace.

The terminal frame must report this exact child path.

The workspace is not capsule authority.

──────────────────────────────────────────────── LIMITED TO SCHEMA
────────────────────────────────────────────────

13. LAUNCH PROFILE V2 SCHEMA

Create:

contract/external-audit-launch-profile-v2.schema.json

Require:

- schema/version/status;
- profile predecessor identity;
- PYZ identity;
- runtime-authority identity;
- subject identity;
- construction-wrapper identity;
- content identities;
- accepted implementation roots;
- interpreter identity;
- exact argv template;
- workspace placeholder;
- absent capsule-root placeholder;
- workspace allocation owner/algorithm;
- workspace parent/prefix/umask;
- capsule child name;
- capsule initial absence;
- capsule creation owner;
- cwd equals workspace;
- output root equals absent child;
- exact environment;
- stdin/shell/TTY/detachment/foreground/synchronous posture;
- preflight contract;
- authorization-consumption rule;
- framing references;
- one-audit count;
- real audit false;
- subject verdict not issued;
- authority promotion false.

Reject unknown fields.

No optional acceptance-bearing root field.

────────────────────────────────────────────────

14. LAUNCH CERTIFICATE V3 SCHEMA

Create:

contract/external-audit-launch-certificate-v3.schema.json

Bind:

- exact profile-v2 identity;
- profile-v1 identity and supersession;
- certificate-v2 identity and supersession;
- certificate-v1 lineage;
- exact PYZ;
- exact runtime authority;
- exact subject;
- exact construction wrapper;
- exact content inputs;
- exact accepted implementation roots;
- source freeze;
- 89-member registry;
- qualification evidence;
- synthetic rehearsals;
- independent qualification;
- post-package qualification;
- frozen-package requalification;
- exact root-flow adjudication;
- exact split-root repair decision;
- exact stream/framing contract;
- exact one-audit authorization;
- profile v1 current false;
- certificate v2 current false;
- certificate v3 current true;
- total active authorization count one;
- real audit false;
- subject verdict not issued;
- authority promotion false.

Reject unknown fields.

────────────────────────────────────────────────

15. BUILDER SOURCE AUTHORITY

Create fresh standard-library-only builder and validators.

They may read only:

- Sections 1–8 inputs;
- current PYZ member registry;
- exact embedded source and authority members needed for root-flow adjudication;
- this task’s additive policy and schemas.

They must not:

- execute audit mode;
- execute subject source;
- execute construction source;
- modify the PYZ or runtime authority;
- use Git/VCS;
- use network;
- broad-scan directories;
- select by basename, recency, score, or first match.

Retain:

opening/root-lifecycle-authority-source-registry-v1.json
opening/root-lifecycle-authority-source-authority-v1.json

Compile with pinned Python `-I -S -B`.

Run static:

- AST;
- call graph;
- dataflow;
- source/member boundary;
- process effects;
- filesystem effects;
- deterministic serialization;
- root-flow semantics;
- authorization-count logic;
- no-Git/no-network;
- terminal operations.

────────────────────────────────────────────────

16. ROOT-LIFECYCLE AUTHORITY MATRIX

Run at least 70 uniquely named cases.

A. Frozen runtime flow

- exact absent child baseline;
- existing output path;
- cwd equals output path;
- cwd workspace/output child;
- output path omitted;
- output path relative;
- output outside workspace;
- parent forwards wrong path;
- capsule creator does not create path;
- capsule creator creates twice;
- terminal frame reports cwd;
- terminal frame reports wrong child;
- cleanup treats workspace as capsule;
- self-auth requires equality;
- self-auth accepts independent paths.

B. Workspace allocation

- exact baseline;
- wrong parent;
- wrong prefix;
- wrong umask;
- symlink workspace;
- nonempty workspace;
- preexisting workspace adoption;
- root scan;
- root fallback.

C. Capsule child

- absent exact child;
- child preexists;
- child is symlink;
- child name wrong;
- nested extra component;
- sibling path;
- relative path;
- two candidate children;
- wrapper precreates child.

D. Preflight

- exact markers and exit;
- workspace remains empty;
- child remains absent;
- preflight creates file;
- preflight creates child;
- wrong cwd;
- wrong environment.

E. Authorization lineage

- profile v1 and v2 both current;
- certificate v2 and v3 both current;
- zero active authorization;
- two active authorizations;
- predecessor consumed unexpectedly;
- prelaunch failure consumes;
- process creation does not consume.

F. Artifact and framing

- wrong PYZ;
- wrong authority;
- wrong subject;
- wrong construction wrapper;
- wrong framing schema;
- frame root equals workspace;
- frame root equals capsule child;
- trailing bytes;
- duplicate frame.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/root-lifecycle-authority-matrix-v1.json

────────────────────────────────────────────────

17. INDEPENDENT ROOT-LIFECYCLE VALIDATOR

Create one independently authored standard-library-only validator that imports
neither:

- builder;
- root-flow analyzer;
- matrix generator;
- expected-result map;
- profile producer;
- certificate producer.

It must independently:

1. authenticate all fixed inputs;
2. parse the PYZ member registry;
3. parse `__main__.py`, `audit_parent.py`, and current `core.py`;
4. reconstruct root/cwd/output dataflow;
5. determine whether split-root launch is valid;
6. validate profile-v2 schema;
7. validate certificate-v3 schema;
8. reconstruct workspace/capsule policy;
9. reconstruct argv;
10. validate preflight;
11. validate framing;
12. validate profile/certificate supersession;
13. prove one active authorization;
14. run independent negative cases;
15. require zero errors.

Retain:

validation/independent-root-lifecycle-authority-validator-v1.json

──────────────────────────────────────────────── LIMITED TO DYNAMIC QUALIFICATION
────────────────────────────────────────────────

18. SPLIT-ROOT PLATFORM QUALIFICATION

Only when split-root repair is selected:

1. allocate one disposable workspace under `/private/tmp` using the exact
   profile-v2 policy;
2. derive the absent `audit-capsule` child;
3. require workspace empty and child absent;
4. run the exact platform preflight in workspace cwd;
5. require exact markers, exit, and no side effects;
6. require workspace still empty and child absent.

Retain complete external custody.

Then run one source-external filesystem lifecycle probe that:

- uses a separate disposable workspace;
- derives an absent `audit-capsule` child;
- creates the child exactly once with:
  `os.makedirs(child, mode=0o700, exist_ok=False)`;
- confirms workspace remains the cwd;
- confirms child identity and mode;
- confirms second creation fails;
- removes the child and workspace after evidence retention;
- observes ENOENT twice.

This probe qualifies the filesystem contract only.

It does not execute audit mode or produce a subject verdict.

──────────────────────────────────────────────── LIMITING ACTUAL PACKAGE
────────────────────────────────────────────────

19. OPTIONAL PACKAGED ROOT-PATH CROSSWALK

Inspect the embedded CLI contract.

If the final PYZ supports a qualification or synthetic mode that exercises the
same output-root creation path without auditing the real replacement subject:

- invoke that exact mode once with:
  - disposable workspace cwd;
  - absent child output root;
  - unchanged runtime authority;
  - synthetic or qualification operands explicitly governed by the PYZ;
- retain complete custody;
- require the child is created by the harness;
- require the terminal frame reports the child;
- require no real subject audit;
- require no subject verdict;
- remove disposable roots after evidence retention and double ENOENT.

If no such exact mode exists:

- retain `not_applicable`;
- do not invent one;
- rely on frozen source dataflow, filesystem qualification, matrices, and
  independent validation.

Absence of such a mode is not itself a blocker.

────────────────────────────────────────────────

20. DETERMINISTIC LAUNCH PROFILE V2

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-profile-v2.json

Use deterministic canonical JSON.

Require Build A/B byte equality.

Set final mode:

0400.

Bind the exact split-root policy.

Retain exact identity.

────────────────────────────────────────────────

21. DETERMINISTIC LAUNCH CERTIFICATE V3

Build independently twice:

gen2-replacement-schema-subject-independent-audit.launch-certificate-v3.json

Use deterministic canonical JSON.

Require Build A/B byte equality.

Set final mode:

0400.

Bind:

- profile v2;
- superseded profile v1;
- superseded certificate v2;
- historical certificate v1;
- unchanged PYZ;
- unchanged runtime authority;
- subject;
- construction wrapper;
- content inputs;
- accepted implementation roots;
- source freeze;
- root-flow adjudication;
- root-lifecycle matrices;
- independent validation;
- split-root platform qualification;
- optional packaged crosswalk;
- one active unconsumed audit authorization.

Retain exact identity.

────────────────────────────────────────────────

22. CERTIFICATE-INPUT VALIDATION

Run a separate certificate-input validator over final bytes.

Require:

- exact profile-v2 binding;
- exact artifact identities;
- exact predecessor/successor lineage;
- exact split-root workspace/capsule policy;
- exact argv;
- exact cwd;
- exact environment;
- exact preflight;
- exact framing;
- one active authorization;
- real audit false;
- subject verdict not issued;
- authority promotion false;
- no unknown field;
- zero errors.

Retain:

validation/successor-certificate-v3-input-validation-v1.json

────────────────────────────────────────────────

23. CURRENT LAUNCH-AUTHORITY ROLE REGISTRY

Retain:

contract/current-external-launch-authority-role-registry-v2.json

Current rows:

- external-audit-launch-profile-v2;
- external-audit-launch-certificate-v3.

Historical rows:

- profile v1;
- certificate v2;
- certificate v1.

Require:

- exactly one current profile;
- exactly one current certificate;
- no duplicate current role;
- no ambiguous path;
- exact identities;
- profile v1 current false;
- certificate v2 current false;
- certificate v1 current false;
- total active authorization count one.

────────────────────────────────────────────────

24. INPUT CLOSING EQUALITY AND CLEANUP

Repeat complete opening/closing equality for:

- PYZ;
- runtime authority;
- profile v1;
- certificate v2;
- certificate v1;
- replacement subject;
- construction wrapper;
- accepted implementation roots;
- content bundle;
- content authority.

Do not mutate supplied inputs.

Before removing disposable roots retain complete evidence.

Revalidate, remove, and observe ENOENT twice.

Require exact cleanup-set equality.

Do not remove successful final outputs.

────────────────────────────────────────────────

25. FAILURE CLOSEOUT

On failure retain:

- first blocker;
- exact root-flow adjudication;
- structured exception;
- source identities;
- process records and streams;
- matrices and validator results;
- partial output inventory;
- cleanup;
- input equality;
- profile/certificate lineage;
- authorization posture;
- real audit not executed;
- subject verdict not issued.

Do not create current successor authority on failure.

Remove provisional outputs only after evidence retention and double ENOENT.

────────────────────────────────────────────────

26. VERDICT RULES

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

only when:

- every fixed input authenticates;
- root-flow adjudication proves split-root compatibility;
- split-root repair is selected;
- profile-v2 and certificate-v3 schemas close;
- builder source qualifies;
- root-lifecycle matrix passes;
- independent validator passes;
- platform and filesystem split-root qualification pass;
- optional packaged crosswalk passes or is correctly not applicable;
- profile-v2 Build A/B match;
- certificate-v3 Build A/B match;
- certificate-input validation passes;
- current role registry closes;
- exactly one active current authorization exists;
- input equality and cleanup pass;
- final files are mode 0400;
- real audit did not execute;
- no subject verdict was issued.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_REPAIR_BLOCKED_REQUIRES_HARNESS_CHANGE

only when:

- fixed inputs authenticate;
- frozen runtime evidence proves split-root launch is incompatible;
- launch-authority-only repair cannot satisfy the current runtime;
- no successor profile/certificate is made current;
- exact harness repair surface is identified.

Return:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_PROVENANCE_MISMATCH

for:

- fixed-input mismatch;
- predecessor profile/certificate mismatch;
- forbidden source use;
- unresolved root-flow evidence;
- evidence loss;
- custody failure;
- cleanup inequality;
- supplied-input mutation;
- deterministic-output mismatch;
- final-output identity failure;
- Git/VCS or network activity.

────────────────────────────────────────────────

27. NO FOLLOW-ON EXECUTION

After reporting:

- stop;
- preserve replacement subject unchanged;
- preserve PYZ and runtime authority;
- preserve all predecessor profiles/certificates;
- preserve accepted implementation roots;
- preserve content inputs;
- preserve successful profile-v2 and certificate-v3 outputs;
- do not execute the real audit;
- do not promote or rebind current schema authority;
- do not construct another subject;
- do not execute product/live-service modes;
- do not run target audit;
- do not rerun runtime validation;
- do not modify a repository;
- do not publish or deploy;
- do not begin A6;
- do not launch another agent.

────────────────────────────────────────────────

28. REQUIRED INLINE OPERATIVE REPORT

Return:

1. Exact primary verdict
2. Fresh build-root identity
3. Fresh output-root identity
4. PYZ identity
5. Runtime-authority identity
6. Profile-v1 identity and disposition
7. Certificate-v2 identity and disposition
8. Certificate-v1 identity and disposition
9. Replacement-subject identity
10. Construction-wrapper identity
11. Accepted implementation-chain identities
12. Content identities
13. Frozen runtime root-flow adjudication
14. CLI output-root semantics
15. Audit-parent forwarding semantics
16. Capsule-creation semantics
17. Cwd/self-authentication semantics
18. Terminal-frame capsule-root semantics
19. Root-lifecycle repair decision
20. Split-root launch policy
21. Workspace allocation contract
22. Absent capsule-root contract
23. Exact argv/cwd/environment
24. Platform-preflight contract
25. Authorization-consumption rule
26. Profile-v2 schema
27. Certificate-v3 schema
28. Builder-source registry
29. Builder compilation/static qualification
30. Root-lifecycle authority matrix
31. Independent root-lifecycle validator
32. Split-root platform qualification
33. Filesystem lifecycle probe
34. Optional packaged root-path crosswalk
35. Profile-v2 Build A
36. Profile-v2 Build B
37. Profile-v2 equality and identity
38. Certificate-v3 Build A
39. Certificate-v3 Build B
40. Certificate-v3 equality and identity
41. Certificate-input validation
42. Current launch-authority role registry
43. Exactly-one-current-authorization result
44. Input closing equality
45. Cleanup
46. Confirmation real audit not executed
47. Confirmation no subject verdict
48. Final profile-v2 path and identity
49. Final certificate-v3 path and identity
50. Remaining uncertainty and nonclaims
51. Explicit confirmations

Required confirmations:

FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
PROFILE_V1_IDENTITY_MATCHED
CERTIFICATE_V2_IDENTITY_MATCHED
CERTIFICATE_V1_IDENTITY_MATCHED
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
SELF_CONTRADICTORY_ROOT_LIFECYCLE_PROVEN
FROZEN_RUNTIME_ROOT_FLOW_ADJUDICATED
CWD_OUTPUT_ROOT_EQUALITY_REQUIREMENT_ADJUDICATED
SPLIT_ROOT_COMPATIBILITY_ADJUDICATED
ROOT_LIFECYCLE_REPAIR_DECISION_SELECTED
PROFILE_V1_CLASSIFIED_HISTORICAL_SUPERSEDED
CERTIFICATE_V2_CLASSIFIED_HISTORICAL_SUPERSEDED
PREDECESSOR_AUTHORIZATIONS_UNCONSUMED
ADDITIVE_SPLIT_ROOT_POLICY_FROZEN
WRAPPER_WORKSPACE_ALLOCATION_FROZEN
ABSENT_CAPSULE_CHILD_CONTRACT_FROZEN
WRAPPER_DOES_NOT_PRECREATE_CAPSULE_ROOT
CWD_EQUALS_WORKSPACE
OUTPUT_ROOT_EQUALS_ABSENT_CHILD
TERMINAL_FRAME_BINDS_CAPSULE_CHILD
EXACT_AUDIT_ARGV_FROZEN
EXACT_SUBMITTED_ENVIRONMENT_FROZEN
STDIN_DEVNULL_FROZEN
SHELL_FALSE_FROZEN
TTY_FALSE_FROZEN
DETACHMENT_FALSE_FROZEN
AUTHORIZATION_CONSUMPTION_RULE_FROZEN
PROFILE_V2_SCHEMA_COMPLETE
CERTIFICATE_V3_SCHEMA_COMPLETE
ROOT_LIFECYCLE_BUILDER_SOURCE_EXTERNAL
ROOT_LIFECYCLE_BUILDER_COMPILED
ROOT_LIFECYCLE_STATIC_QUALIFICATION_PASSED
ROOT_LIFECYCLE_AUTHORITY_MATRIX_PASSED
INDEPENDENT_ROOT_LIFECYCLE_VALIDATOR_PASSED
SPLIT_ROOT_PLATFORM_PREFLIGHT_PASSED
PREFLIGHT_WORKSPACE_REMAINED_EMPTY
PREFLIGHT_CAPSULE_CHILD_REMAINED_ABSENT
FILESYSTEM_SPLIT_ROOT_LIFECYCLE_PROBE_PASSED
OPTIONAL_PACKAGED_ROOT_PATH_CROSSWALK_PASSED_OR_NOT_APPLICABLE
PROFILE_V2_BUILD_A_B_BYTES_IDENTICAL
PROFILE_V2_MODE_0400
PROFILE_V2_IDENTITY_VERIFIED
CERTIFICATE_V3_BUILD_A_B_BYTES_IDENTICAL
CERTIFICATE_V3_MODE_0400
CERTIFICATE_V3_IDENTITY_VERIFIED
CERTIFICATE_V3_INPUT_VALIDATION_PASSED
CURRENT_LAUNCH_AUTHORITY_ROLE_REGISTRY_COMPLETE
EXACTLY_ONE_CURRENT_LAUNCH_PROFILE
EXACTLY_ONE_CURRENT_LAUNCH_CERTIFICATE
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
SUBJECT_VERDICT_NOT_ISSUED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
CURRENT_AUDIT_PYZ_MUTATION_NOT_PERFORMED
CURRENT_RUNTIME_AUTHORITY_MUTATION_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_REPLACEMENT_SCHEMA_SUBJECT_AUDIT_ROOT_LIFECYCLE_AUTHORITY_COMPLETED_READY_FOR_ONE_REAL_AUDIT

the next task is exactly one real audit using:

1. unchanged audit PYZ;
2. unchanged runtime authority;
3. launch profile v2;
4. launch certificate v3;
5. replacement subject;
6. construction wrapper;
7. current content bundle;
8. current content authority;
9. accepted implementation authority chain.

Do not combine root-lifecycle authority repair with the real audit.
```

## Source and confidence

The attached report establishes the deterministic root-lifecycle contradiction, confirms that no audit process or root was created, and preserves the authorization as unconsumed. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

It also confirms that all supplied identities and package closure passed and that no subject blocker was established. :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

**Provenance confidence:** 0.999  
**Root-lifecycle contradiction confidence:** 0.999  
**Authorization-unconsumed confidence:** 0.999  
**Split-root repair-path confidence:** 0.95, conditional on the frozen runtime not requiring `cwd == output_root`.

The latest attachment was fully readable. Some older uploaded artifacts have expired; re-upload an older file only if a later review requires its original bytes rather than the retained reports and identities.
