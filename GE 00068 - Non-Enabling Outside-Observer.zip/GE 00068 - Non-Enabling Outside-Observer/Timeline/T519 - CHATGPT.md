## Engineering assessment

The final localized repair correctly diagnosed the original runtime failure, but the repair generation is now exhausted and retired.

Two facts are now firm:

1. The real audit failed because `run_full_audit` used the stale hardcoded member path:

```text
qualification/runtime-matrix-suite-v2.json
```

The authoritative role is:

```text
governed_runtime_matrix_evidence
```

and its current member is:

```text
qualification/runtime-matrix-v2.json
```

with schema `governed-runtime-matrix-suite-v2` and SHA-256 `76892937388dc5fdea144d872e396185572cf8b1dcc336356aec678b02e0c5e5`. :chatgpt-content-reference{index="0"}

2. The attempted repair then failed on a **different modeling error**. Its dependency registry required every JSON dependency to contain a `schema` field. The first conflicting record was:

```text
governance/five-domain/opening/bootstrap-start.json
```

which uses `schema_version` rather than `schema`. :chatgpt-content-reference{index="1"}

That does **not** prove the bootstrap record is defective. It proves that the attempted dependency descriptor model imposed one uniform JSON discriminator on heterogeneous governed records.

### What the retired attempt established

The useful parts of the attempt are strong:

- the stale lookup and exact current role/member were identified;
- no compatibility alias was added;
- no path fallback was implemented;
- the source delta stayed within the declared repair surface;
- 114 protected functions and classes remained AST-identical;
- all 33 sources compiled;
- static gates found no fallback, network, VCS, shell lookup, unbounded flow, or unreachable closeout. :chatgpt-content-reference{index="2"}
- fixed inputs remained unchanged and cleanup completed without process, descriptor, cache, or bytecode survivors. :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

But compilation had already begun, so Attempt 3 was consumed. The source-attempt budget is now zero, no source freeze occurred, and no PYZ v3, authority v4, or launch certificate v2 was produced. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

### Correct classification

**Original runtime defect:** `STALE_HARDCODED_MEMBER_PATH`

**Repair-attempt blocker:** `OVERUNIFORM_EMBEDDED_DEPENDENCY_DESCRIPTOR_MODEL`

**Generation status:** retired; no Attempt 4.

**Generation-2 implementation-package defect:** still not established.

**Next treatment:** new clean harness implementation generation—but not yet. First freeze one additive documentary contract that defines how heterogeneous embedded records are described and validated.

### Why another contract tranche is necessary

The next clean implementation needs a governing model in which an embedded dependency is not assumed to be “JSON containing `schema`.” It is a typed tuple:

```text
semantic role
+ exact current member path
+ exact member identity
+ media/content kind
+ record class
+ discriminator contract
+ parser/validation contract
+ owning registry
+ consumers
+ authority contribution
```

At minimum, the current archive already proves the need for two distinct record classes:

- JSON records discriminated by `schema`;
- JSON records discriminated by `schema_version`.

Any additional class must be derived from actual required members and explicitly frozen. No class may be inferred through generic aliases or recursive field search.

The documentary tranche should derive the complete `run-full-audit` dependency set from the current PYZ source and archive, freeze the exact descriptor for every dependency, and validate that model independently. Only then should a new clean implementation generation begin.

---

## Complete replacement Codex prompt

```text
FREEZE AN ADDITIVE GOVERNING DOCUMENTARY CONTRACT FOR
RUN-FULL-AUDIT EMBEDDED DEPENDENCY DESCRIPTORS AND ROLE RESOLUTION

HETEROGENEOUS RECORD CLASSES, EXACT MEMBER AUTHORITY, AND
COMPLETE RUNTIME DEPENDENCY CLOSURE

Objective

Create and terminally close an additive governing documentary package that
resolves the final operating-model defect exposed by the retired embedded-record
repair generation.

The original runtime failure is fully diagnosed:

- stale requested path:
  qualification/runtime-matrix-suite-v2.json

- authoritative semantic role:
  governed_runtime_matrix_evidence

- authoritative current member:
  qualification/runtime-matrix-v2.json

- authoritative schema:
  governed-runtime-matrix-suite-v2

The retired repair correctly replaced path-literal resolution with semantic-role
resolution, but its dependency descriptor model then required every governed
JSON member to contain a `schema` field.

That blanket rule is invalid for the current package.

The first conflicting current member was:

governance/five-domain/opening/bootstrap-start.json

It contains `schema_version`, not `schema`.

Freeze a typed embedded-dependency authority model that supports heterogeneous
record classes without aliases, fallback lookup, or weakened validation.

This is a documentary-contract tranche only.

Do not implement future harness production source.
Do not implement future harness qualification source.
Do not implement future independent-validator source.
Do not compile or package a future harness.
Do not create a PYZ.
Do not execute `qualify-harness`.
Do not execute `run-full-audit`.
Do not execute implementation production source.
Do not adjudicate the Generation-2 implementation package.
Do not construct the authoritative current schema subject.
Do not modify any supplied root or file.
Do not resume the retired repair root.
Do not create Attempt 4.
Do not copy or patch retired harness source into a future implementation.
Do not perform another historical package-findings reconciliation.

The task may create bounded documentary tooling, matrices, projections, and
independent documentary validators solely to freeze and validate this additive
contract. Those files are not future harness implementation source.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git`.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or begin A6.

Use one finite parent-owned documentary build in one fresh private root.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_BLOCKED

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. GOVERNING INPUT A — FIVE-DOMAIN DOCUMENTARY PACKAGE
──────────────────────────────────────────────────────────────────────────────

FIVE_DOMAIN_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-governing-documentary-contract-v2-pakmtp5u

Expected root identity:

- device:
  16777234
- inode:
  181874306
- mode:
  0700

Expected temporal record:

manifest/documentary-temporal-inventory-v2.json

- device:
  16777234
- inode:
  181887815
- mode:
  0600
- link count:
  1
- size:
  13133
- SHA-256:
  31b54fd909201b993d36dbd5b0696e4efc8f99bfa3e8d7599e9152d16f0a3028

Expected manifest A:

manifest/documentary-manifest-a-v2.json

- device:
  16777234
- inode:
  181887816
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Expected manifest B:

manifest/documentary-manifest-b-v2.json

- device:
  16777234
- inode:
  181887817
- mode:
  0600
- link count:
  1
- size:
  13478
- SHA-256:
  6c61ac791a24b0453466c7e560453420047db9d4b0de21e0fac698fb4633913d

Authenticate:

- root identity;
- temporal identity;
- manifest identities;
- manifest byte equality;
- independent terminal reprojection;
- root row exactly once;
- terminal topology and modes;
- one seal transition;
- no postseal activity.

Resolve current roles only through:

contract/current-governing-documentary-role-registry-v2.json

Preserve unchanged:

- five documentary domains;
- R01–R66 report registry;
- exact 81-name confirmation registry;
- B00 and D01–D14 matrix registry;
- 15 matrices;
- 595 matrix cases;
- stale 645 rejection;
- aggregate ownership;
- package acceptance semantics.

Documentary-package tooling source is not future implementation source.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING INPUT B — INTERPRETER-OBSERVATION PACKAGE
──────────────────────────────────────────────────────────────────────────────

INTERPRETER_TUPLE_DOCUMENTARY_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-clean-audit-harness-interpreter-observation-tuple-contract-f5ys2h7f

Expected root identity:

- device:
  16777234
- inode:
  182148007
- mode:
  0700

Expected temporal record:

manifest/interpreter-observation-temporal-inventory-v1.json

- device:
  16777234
- inode:
  182159647
- mode:
  0600
- link count:
  1
- size:
  11608
- SHA-256:
  181015fc4ef80841995af4005e068b0a348a3d0e8cbb2ef9fac6ef6424af0031

Expected manifests:

manifest/interpreter-observation-manifest-a-v1.json
manifest/interpreter-observation-manifest-b-v1.json

Expected identities:

- inodes:
  182159648
  182159649
- mode:
  0600
- link count:
  1
- size:
  11968 each
- SHA-256:
  cc5d5d48d0f5d862ec4310e41ee377c9ce89330b356da562220960d9556dcd66

Authenticate terminal closure and resolve additive roles only through:

contract/current-launch-runtime-successor-role-registry-v1.json

Preserve unchanged:

- exact three-role interpreter taxonomy;
- observation tuple;
- argv/cwd/PID/flag crosswalks;
- environment-injection policy;
- self-authentication schema;
- package acceptance semantics.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
3. CURRENT HARNESS AND CONTENT EVIDENCE
──────────────────────────────────────────────── LIMITED TO DOCUMENTARY INSPECTION
────────────────────────────────────────────────

CURRENT_HARNESS_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz

Expected identity:

- size:
  2822218
- SHA-256:
  2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2

CURRENT_RUNTIME_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Expected identity:

- size:
  7193
- SHA-256:
  349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986

CONSUMED_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-launch-certificate-v2-output-mchfmdqd/gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json

Expected identity:

- size:
  67057
- SHA-256:
  eaee84d823cbea4ae88ccf0a7ed01429e2b451f5bac128190e760e4d4e528bb8

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate every exact file.

The harness PYZ and source members may be inspected read-only to derive:

- lookup sites;
- semantic dependency roles;
- exact current members;
- record shapes;
- content classes.

They are historical implementation evidence and test input.

They are not future implementation source authority.

Do not execute the PYZ.

Do not import a PYZ source module.

Require complete opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
4. RETIRED REPAIR ROOT
──────────────────────────────────────────────── LIMITED TO FAILURE EVIDENCE
────────────────────────────────────────────────

RETIRED_REPAIR_ROOT:

/private/tmp/ES-repair10i-v3-clean-audit-harness-v3-embedded-record-repair-sfzk1hlv

Expected root identity:

- device:
  16777234
- inode:
  182333888
- mode:
  0700

Expected verdict:

GEN2_CLEAN_AUDIT_HARNESS_V3_REPAIR_BLOCKED

Open only this exact root if it exists.

Do not scan for it.

Authenticate exact retained records through its registries and closeout.

At minimum authenticate:

analysis/source-v2-v3-bounded-delta-v1.json
contract/protected-source-surface-v1.json
qualification/attempt-3-all-source-compilation-v3.json
qualification/attempt-3-static-source-gates-v3.json
cleanup/failed-repair-cleanup-v1.json
closing/failure-input-closing-equality-v1.json
report/failure-operative-report-v1.json

Authenticate the exact findings:

- Attempt 3 consumed;
- remaining attempt count zero;
- stale hardcoded path identified;
- authoritative role:
  governed_runtime_matrix_evidence;
- authoritative member:
  qualification/runtime-matrix-v2.json;
- authoritative schema:
  governed-runtime-matrix-suite-v2;
- no compatibility alias;
- no fallback;
- all 33 sources compiled;
- static gates passed;
- dependency closure failed at:
  governance/five-domain/opening/bootstrap-start.json;
- record has `schema_version` and no `schema`;
- no PYZ v3, authority v4, or certificate v2;
- implementation generation retired;
- new clean implementation generation required.

Classify the root as:

historical_noncurrent_overuniform_dependency_descriptor_failure

It is not future implementation source authority.

Require opening/closing equality if opened.

──────────────────────────────────────────────────────────────────────────────
5. FRESH ADDITIVE DOCUMENTARY ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh private root beneath `/Users/ds/Downloads` with:

- tempfile.mkdtemp;
- umask:
  077;
- prefix:

ES-repair10i-v3-clean-audit-harness-embedded-dependency-descriptor-contract-

Immediately emit:

CONTRACT_ROOT=<absolute-path>

Before documentary analysis retain:

opening/bootstrap-start.json
opening/additive-documentary-authority-v1.json
opening/fixed-input-registry-v1.json
opening/predecessor-package-authentication-v1.json
opening/current-harness-evidence-authentication-v1.json
opening/retired-repair-disposition-v1.json
opening/process-execution-policy-v1.json

Authority is limited to:

- fixed-input authentication;
- embedded dependency taxonomy;
- dependency-role derivation;
- record-class derivation;
- parser/validator contracts;
- member-role authority;
- lookup contracts;
- documentary matrices;
- independent documentary validation;
- supplied-input equality;
- package terminal closure.

Nonauthority includes:

- harness source implementation;
- harness source repair;
- implementation-package adjudication;
- current-subject construction;
- product/runtime/target/repository activity;
- publication/deployment/A6.

──────────────────────────────────────────────────────────────────────────────
6. EMBEDDED DEPENDENCY AUTHORITY MODEL
──────────────────────────────────────────────────────────────────────────────

Retain:

contract/embedded-dependency-authority-model-v1.json

Every acceptance-bearing embedded dependency is identified by this tuple:

- dependency_id;
- semantic_role;
- owning_authority_registry;
- exact_current_member_role;
- exact_current_member_path;
- exact_member_identity;
- media_type;
- content_kind;
- record_class;
- discriminator_contract;
- parser_contract;
- validation_contract;
- required_fields;
- authority_contribution;
- required_or_optional;
- consumer_lookup_sites;
- phase_consumers;
- report_consumers;
- confirmation_consumers;
- failure_reasons.

Rules:

- semantic role is authoritative;
- current member path is resolved through one exact current member-role
  registry;
- member identity and shape must match;
- source consumers request semantic roles, not package paths;
- no acceptance-bearing source consumer directly owns a member path literal;
- no path fallback;
- no compatibility alias;
- no basename, suffix, prefix, version, score, first-match, recency, or
  recursive lookup;
- no content-equality search;
- unknown or duplicate role fails closed;
- missing or duplicate member fails closed;
- wrong record class fails closed.

A member path is an exact projection of a current semantic role.

It is not an independently selected authority.

──────────────────────────────────────────────────────────────────────────────
7. RECORD-CLASS TAXONOMY
──────────────────────────────────────────────── LIMITED TO ACTUAL MEMBERS
────────────────────────────────────────────────

Retain:

contract/embedded-record-class-taxonomy-v1.json

Derive every record class from actual required run-full-audit members.

At minimum adjudicate these classes.

A. SCHEMA_DISCRIMINATED_JSON

Required:

- strict canonical JSON;
- exact `schema` field;
- exact schema value;
- record-specific required fields;
- duplicate-key and nonfinite rejection.

B. SCHEMA_VERSION_DISCRIMINATED_JSON

Required:

- strict canonical JSON;
- exact `schema_version` field;
- exact version value;
- record-specific required fields;
- duplicate-key and nonfinite rejection.

A `schema` field is not required unless the exact record contract requires it.

The exact current record:

governance/five-domain/opening/bootstrap-start.json

must be adjudicated from its actual bytes.

If exact evidence confirms `schema_version` and no `schema`, classify it under:

SCHEMA_VERSION_DISCRIMINATED_JSON

Do not add a `schema` requirement.

C. Additional classes

An additional class is permitted only when:

- at least one required current dependency actually needs it;
- every exact member is listed;
- discriminator and parser contracts are explicit;
- the independent validator reconstructs the need;
- no existing class applies;
- the class is not a fallback.

Potential additional classes may include, only if actual evidence requires:

- REGISTRY_DISCRIMINATED_JSON;
- MANIFEST_JSON;
- SOURCE_TEXT;
- OPAQUE_BYTES.

Do not create a generic:

JSON_WITH_ANY_DISCRIMINATOR

class.

Do not accept schema-less JSON without an exact frozen class and validation
contract.

Derived class count must come exclusively from exact taxonomy rows.

──────────────────────────────────────────────────────────────────────────────
8. COMPLETE RUN-FULL-AUDIT DEPENDENCY DERIVATION
──────────────────────────────────────────────── LIMITED TO STATIC EVIDENCE
────────────────────────────────────────────────

Retain:

analysis/derived-run-full-audit-dependency-set-v1.json
analysis/run-full-audit-lookup-site-crosswalk-v1.json

Derive every acceptance-bearing embedded dependency reachable from:

- CLI dispatch into `run-full-audit`;
- parent/runtime self-authentication;
- P00–P24;
- fixed-input authentication;
- role/index closure;
- source/attempt/freeze analysis;
- security analysis;
- E00/G00–G29 crosswalk;
- documentary lifecycle;
- runtime matrix evidence;
- 946-case evidence;
- 137-case evidence;
- 766/333 field-map evidence;
- producer rehearsals;
- Attempt-2 failure evidence;
- implementation confirmation evidence;
- constructed-subject evidence;
- fresh behavioral causals;
- source-external validation;
- report projection;
- confirmation projection;
- finding/dependency construction;
- cleanup;
- fixed-input closing equality;
- terminal capsule closure.

Use:

- AST imports;
- direct calls;
- statically resolved attribute calls;
- string constants at lookup sites;
- bytecode targets;
- serialized-record readers;
- role registries;
- member registries.

For every lookup site retain:

- source member;
- function/class;
- line/AST location;
- call chain;
- current lookup mechanism;
- requested literal if any;
- semantic purpose;
- semantic role;
- exact current member role;
- exact current member path;
- record class;
- authority effect;
- historical defect relationship.

The derivation is documentary evidence.

It does not authorize future source copying or patching.

──────────────────────────────────────────────────────────────────────────────
9. CURRENT MEMBER-ROLE REGISTRY
──────────────────────────────────────────────── LIMITED TO DEPENDENCIES
────────────────────────────────────────────────

Retain:

contract/current-run-full-audit-member-role-registry-v1.json

Require exactly one current row per dependency semantic role.

Every row contains:

- member_role;
- semantic_role;
- exact path;
- exact size;
- exact SHA-256;
- exact mode;
- media type;
- record class;
- discriminator pointer/value;
- owning package registry;
- current:
  true;
- historical aliases:
  none;
- duplicate current paths:
  none.

At minimum include:

governed_runtime_matrix_evidence

with exact current member:

qualification/runtime-matrix-v2.json

and exact schema:

governed-runtime-matrix-suite-v2

Do not include:

qualification/runtime-matrix-suite-v2.json

as a current or compatibility member unless current package bytes and governing
registries independently prove that it is authoritative. Current evidence says
it is absent and stale.

──────────────────────────────────────────────────────────────────────────────
10. COMPLETE DEPENDENCY-DESCRIPTOR REGISTRY
──────────────────────────────────────────────── LIMITING ACCEPTANCE
────────────────────────────────────────────────

Retain:

contract/run-full-audit-embedded-dependency-descriptor-registry-v1.json

For every derived dependency require:

- one descriptor;
- one semantic role;
- one current member role;
- one current member path;
- one member identity;
- one record class;
- one parser contract;
- one validation contract;
- complete consumer set.

Require exact set equality:

derived dependency IDs
=
descriptor-registry dependency IDs
=
current member-role IDs used by run-full-audit
=
actual required member paths in the current PYZ
=
direct documentary test IDs
=
independent documentary test IDs

Do not require every descriptor to bind a `schema` field.

Require every descriptor to bind its exact record-class discriminator.

Unknown, missing, extra, duplicate, or ambiguous descriptor fails closed.

──────────────────────────────────────────────────────────────────────────────
11. DEPENDENCY LOOKUP CONTRACT
──────────────────────────────────────────────── LIMITED TO FUTURE IMPLEMENTATION
────────────────────────────────────────────────

Retain:

contract/semantic-role-to-member-resolution-v1.json

Future source must request:

semantic_role

The resolver must:

1. resolve exactly one current descriptor by semantic role;
2. resolve exactly one current member role;
3. resolve exactly one exact member path;
4. authenticate member identity;
5. parse according to record class;
6. validate exact discriminator and required fields;
7. return typed content to the consumer.

It must not accept:

- direct package-path literals at consumers;
- fallback path lists;
- compatibility aliases;
- basename or suffix lookup;
- recursive member scan;
- first existing path;
- version-score selection;
- same-byte search;
- schema-field search;
- discriminator-field fallback.

The stale runtime-matrix failure must be represented as a mandatory historical
regression.

──────────────────────────────────────────────────────────────────────────────
12. RECORD-CLASS AND DEPENDENCY MATRICES
────────────────────────────────────────────────

Run at least 120 uniquely named cases.

A. Record-class cases

- exact schema-discriminated baseline;
- exact schema-version-discriminated baseline;
- bootstrap-start exact baseline;
- bootstrap record wrongly required to contain `schema`;
- bootstrap missing `schema_version`;
- bootstrap wrong version;
- schema record missing `schema`;
- schema record using only `schema_version`;
- duplicate discriminator;
- Boolean discriminator;
- nonstring discriminator;
- duplicate JSON key;
- nonfinite value;
- unknown record class;
- unregistered extra record class;
- schema-less JSON without explicit class;
- opaque bytes assigned JSON class;
- source text assigned manifest class.

B. Role/member cases

- exact governed matrix evidence baseline;
- stale path requested;
- missing role;
- duplicate role;
- two current paths;
- path absent from archive;
- archive member absent from registry;
- wrong size;
- wrong hash;
- wrong mode;
- wrong schema;
- wrong schema version;
- correct bytes under stale alias;
- same bytes at two paths;
- compatibility alias added;
- required member marked optional;
- optional member marked required.

C. Consumer closure cases

- exact all-dependency baseline;
- source lookup missing descriptor;
- descriptor without source lookup;
- phase consumer omitted;
- report consumer omitted;
- confirmation consumer omitted;
- duplicate consumer;
- unreachable registered lookup;
- direct path literal in consumer;
- generic resolver fallback;
- recursive search;
- first-match selection;
- basename/suffix/prefix selection;
- version scoring;
- content-equality lookup.

D. Actual historical regressions

- stale matrix-suite path;
- authoritative matrix-v2 role;
- bootstrap-start `schema_version` shape;
- blanket-schema-field requirement;
- no compatibility alias;
- exact complete dependency closure.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/embedded-dependency-descriptor-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
13. INDEPENDENT DOCUMENTARY VALIDATOR
────────────────────────────────────────────────

Create one standard-library-only source-external documentary validator that
imports neither:

- dependency producer helpers;
- matrix generator;
- expected-result map;
- role resolver;
- record-class parser;
- projector;
- normalizer.

It must independently:

1. authenticate every supplied input;
2. parse the current PYZ member registry;
3. inspect source lookup sites independently;
4. derive the run-full-audit dependency set;
5. derive actual record classes from member bytes;
6. classify bootstrap-start correctly;
7. classify governed matrix evidence correctly;
8. reconstruct member-role closure;
9. reject stale path and compatibility alias;
10. reject blanket `schema` requirements;
11. validate every descriptor;
12. run independent negative cases;
13. verify exact set equality across source, descriptors, members, and tests;
14. verify no future source exists;
15. require zero errors.

Retain:

validation/independent-embedded-dependency-descriptor-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
14. DOCUMENTARY PERSPECTIVES
────────────────────────────────────────────────

Retain independently authored projections:

analysis/perspective-semantic-role-authority-v1.json
analysis/perspective-member-registry-authority-v1.json
analysis/perspective-record-class-validation-v1.json
analysis/perspective-source-consumer-closure-v1.json
analysis/perspective-package-assembly-closure-v1.json
analysis/perspective-new-implementation-boundary-v1.json

Reconcile them in:

analysis/embedded-dependency-descriptor-perspective-reconciliation-v1.json

Require:

- no disagreement;
- no open operating-model decision;
- no hidden implementation decision;
- no package-verdict change;
- no documentary-domain change;
- no runtime-registry change;
- no acceptance-semantic change;
- exact predecessor/additive authority split;
- exact successor-package identity binding.

──────────────────────────────────────────────────────────────────────────────
15. ADDITIVE SUCCESSOR ROLE REGISTRY
────────────────────────────────────────────────

Retain:

contract/current-embedded-dependency-successor-role-registry-v1.json

The registry must:

- bind the five-domain predecessor package;
- bind the interpreter-tuple additive package;
- state both remain current for their existing seams;
- make this successor current only for:
  RUN_FULL_AUDIT_EMBEDDED_DEPENDENCY_AUTHORITY;
- contain one current artifact per new role;
- contain no duplicate or ambiguous role;
- contain no future implementation-source role;
- contain no future harness-package role.

Required successor roles include:

- dependency authority model;
- record-class taxonomy;
- derived dependency set;
- lookup-site crosswalk;
- current member-role registry;
- dependency-descriptor registry;
- role-to-member lookup contract;
- descriptor matrix;
- independent validator;
- six perspectives;
- perspective reconciliation;
- package status;
- explicit confirmations.

──────────────────────────────────────────────────────────────────────────────
16. PACKAGE STATUS
────────────────────────────────────────────────

Retain:

analysis/embedded-dependency-descriptor-contract-status-v1.json

Required status:

gen2-clean-audit-harness-embedded-dependency-descriptor-contract-frozen-pending-new-clean-implementation-generation

Required facts:

- predecessor five-domain package authenticated:
  true;
- interpreter-tuple package authenticated:
  true;
- this successor is additive:
  true;
- successor authority seam:
  RUN_FULL_AUDIT_EMBEDDED_DEPENDENCY_AUTHORITY;
- five documentary domains unchanged:
  true;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrices:
  15;
- runtime matrix cases:
  595;
- record classes:
  derived from exact taxonomy;
- blanket schema-field requirement:
  false;
- schema-version records supported:
  true;
- stale matrix-suite path current:
  false;
- governed matrix-v2 role current:
  true;
- compatibility alias:
  false;
- generic path fallback:
  false;
- complete dependency descriptor set:
  true;
- future implementation source present:
  false;
- future implementation authority:
  false;
- real audit executed:
  false;
- implementation verdict:
  not issued;
- next treatment:
  NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION.

──────────────────────────────────────────────────────────────────────────────
17. SUPPLIED-INPUT CLOSING EQUALITY
────────────────────────────────────────────────

Repeat exact no-follow checks and complete inventories as appropriate for:

- five-domain documentary package;
- interpreter-tuple documentary package;
- current PYZ;
- authority v3;
- consumed certificate v1;
- content bundle;
- content authority;
- retired repair root if opened.

Require exact opening/closing equality.

Do not mutate or clean supplied inputs.

──────────────────────────────────────────────────────────────────────────────
18. TERMINAL SUCCESSOR-PACKAGE CLOSURE
────────────────────────────────────────────────

Use explicit closure paths:

manifest/embedded-dependency-temporal-inventory-v1.json
manifest/embedded-dependency-manifest-a-v1.json
manifest/embedded-dependency-manifest-b-v1.json

Before projection:

- finalize all nonclosure records;
- create only used directories;
- ensure closeout/ and manifest/ exist;
- retain no empty descendant;
- exclusively reserve all three closure paths;
- retain descriptors;
- freeze the directory set.

Then:

1. generate temporal bytes independently twice;
2. require equality;
3. write through retained descriptor;
4. fsync and reopen no-follow;
5. independently reproject temporal cut;
6. independently generate A and B from one frozen namespace;
7. require A/B byte equality;
8. write through retained descriptors;
9. fsync files and directories;
10. reopen no-follow;
11. verify path/descriptor inode equality;
12. independently reproject final root;
13. require root row exactly once;
14. require no empty descendant;
15. require no symlink or special object;
16. require no multiply linked regular file;
17. require modes 0700/0600;
18. require no cache or bytecode;
19. transition seal once;
20. emit guarded verdict and terminal marker;
21. exit nonreturningly;
22. perform no postseal filesystem or tool operation.

──────────────────────────────────────────────────────────────────────────────
19. FAILURE CLOSEOUT
────────────────────────────────────────────────

On failure retain:

- first blocker;
- structured exception;
- process records and streams;
- partial inventory;
- indispensable evidence;
- cleanup;
- supplied-input equality;
- terminal posture;
- same-root retry false.

Do not create success manifests on failure.

Return provenance mismatch for:

- fixed-input mismatch;
- prohibited source use;
- supplied-input mutation;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- terminal-closure failure;
- postseal activity.

──────────────────────────────────────────────────────────────────────────────
20. VERDICT RULES
────────────────────────────────────────────────

Return:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

only when:

- every supplied input authenticates;
- both predecessor documentary packages terminally authenticate;
- retired failure evidence authenticates or is explicitly unavailable;
- dependency authority model freezes;
- record-class taxonomy freezes;
- complete dependency set derives;
- lookup-site crosswalk closes;
- member-role registry closes;
- dependency-descriptor registry closes;
- semantic lookup contract freezes;
- descriptor matrix passes;
- independent validator passes;
- six perspectives reconcile;
- additive successor registry closes;
- package status closes;
- supplied inputs close equal;
- successor package terminally closes;
- no postseal operation occurs.

Return:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_BLOCKED

when:

- an actual required record cannot be classified uniquely;
- dependency closure remains incomplete;
- source/member/descriptor sets cannot be reconciled;
- an operating-model decision remains open;
- independent validation fails without provenance failure.

Return:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_PROVENANCE_MISMATCH

for provenance failures defined in Section 19.

──────────────────────────────────────────────────────────────────────────────
21. REQUIRED INLINE OPERATIVE REPORT
────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor-root identity
3. Five-domain documentary-package identity
4. Interpreter-tuple package identity
5. Current PYZ identity
6. Authority-v3 identity
7. Consumed-certificate identity/disposition
8. Content-bundle identity
9. Content-authority identity
10. Retired-repair identity/disposition
11. Documentary authority and nonauthority
12. Embedded dependency authority model
13. Derived dependency count
14. Record-class taxonomy
15. Derived record-class count
16. Bootstrap-start record-class adjudication
17. Governed-matrix record-class adjudication
18. Complete source lookup-site inventory
19. Complete derived dependency set
20. Current member-role registry
21. Complete dependency-descriptor registry
22. Source/dependency/member/test set equality
23. Semantic-role-to-member lookup contract
24. Stale matrix-suite path disposition
25. Compatibility-alias disposition
26. Generic-fallback disposition
27. Descriptor mutation matrix
28. Independent documentary validator
29. Semantic-role perspective
30. Member-registry perspective
31. Record-class perspective
32. Source-consumer perspective
33. Package-assembly perspective
34. New-implementation-boundary perspective
35. Perspective reconciliation
36. Additive successor role registry
37. Package status
38. Confirmation no future harness source was created
39. Confirmation no audit was executed
40. Confirmation no implementation verdict was issued
41. Supplied-input closing equality
42. Failure-closeout capability/use
43. Temporal-inventory identity
44. Manifest A identity
45. Manifest B identity
46. Terminal reprojection
47. Terminal topology/modes
48. No-write-after-closure
49. Remaining uncertainty/nonclaims
50. Explicit documentary confirmations

Required confirmations:

FIVE_DOMAIN_DOCUMENTARY_PACKAGE_AUTHENTICATED
INTERPRETER_TUPLE_DOCUMENTARY_PACKAGE_AUTHENTICATED
CURRENT_PYZ_IDENTITY_MATCHED
CURRENT_AUTHORITY_V3_IDENTITY_MATCHED
CONSUMED_CERTIFICATE_IDENTITY_MATCHED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
RETIRED_REPAIR_DISPOSITION_AUTHENTICATED_OR_EXPLICITLY_UNAVAILABLE
NO_RETIRED_SOURCE_USED_AS_IMPLEMENTATION_SOURCE
EMBEDDED_DEPENDENCY_AUTHORITY_MODEL_FROZEN
RECORD_CLASS_TAXONOMY_FROZEN
RECORD_CLASS_COUNT_DERIVED
SCHEMA_DISCRIMINATED_JSON_CLASS_FROZEN
SCHEMA_VERSION_DISCRIMINATED_JSON_CLASS_FROZEN
BOOTSTRAP_START_CLASSIFIED_WITHOUT_BLANKET_SCHEMA_REQUIREMENT
GOVERNED_RUNTIME_MATRIX_EVIDENCE_CLASSIFIED
COMPLETE_RUN_FULL_AUDIT_LOOKUP_SITE_SET_DERIVED
COMPLETE_RUN_FULL_AUDIT_DEPENDENCY_SET_DERIVED
CURRENT_MEMBER_ROLE_REGISTRY_COMPLETE
COMPLETE_DEPENDENCY_DESCRIPTOR_REGISTRY_FROZEN
SOURCE_LOOKUPS_EQUAL_DEPENDENCY_DESCRIPTORS
DEPENDENCY_DESCRIPTORS_EQUAL_CURRENT_MEMBER_ROLES
CURRENT_MEMBER_ROLES_EQUAL_REQUIRED_PYZ_MEMBERS
DIRECT_DOCUMENTARY_TESTS_EQUAL_DEPENDENCY_SET
INDEPENDENT_DOCUMENTARY_TESTS_EQUAL_DEPENDENCY_SET
SEMANTIC_ROLE_TO_MEMBER_RESOLUTION_FROZEN
NO_ACCEPTANCE_BEARING_DIRECT_MEMBER_PATH_LITERAL
STALE_MATRIX_SUITE_PATH_NONCURRENT
GOVERNED_MATRIX_V2_MEMBER_CURRENT
NO_COMPATIBILITY_ALIAS
NO_PATH_FALLBACK
NO_BASENAME_SUFFIX_PREFIX_OR_SCORE_SELECTION
NO_RECURSIVE_MEMBER_SEARCH
NO_GENERIC_DISCRIMINATOR_FALLBACK
DESCRIPTOR_MATRIX_PASSED
INDEPENDENT_DESCRIPTOR_VALIDATOR_PASSED
SIX_DOCUMENTARY_PERSPECTIVES_RECONCILED
NO_OPEN_OPERATING_MODEL_DECISION
PREDECESSOR_FIVE_DOMAIN_AUTHORITY_PRESERVED
INTERPRETER_TUPLE_AUTHORITY_PRESERVED
FIVE_DOCUMENTARY_DOMAINS_UNCHANGED
RUNTIME_REPORT_REGISTRY_UNCHANGED
RUNTIME_CONFIRMATION_REGISTRY_UNCHANGED
RUNTIME_MATRIX_REGISTRY_UNCHANGED
PACKAGE_ACCEPTANCE_SEMANTICS_UNCHANGED
ADDITIVE_SUCCESSOR_ROLE_REGISTRY_COMPLETE
FUTURE_IMPLEMENTATION_SOURCE_NOT_CREATED
FUTURE_IMPLEMENTATION_AUTHORITY_FALSE
NEXT_TREATMENT_NEW_CLEAN_HARNESS_IMPLEMENTATION_GENERATION
SUPPLIED_INPUT_CLOSING_EQUALITY_PASSED
SUCCESSOR_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_MANIFEST_A_CREATED
SUCCESSOR_MANIFEST_B_CREATED
SUCCESSOR_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_AUDIT_HARNESS_EMBEDDED_DEPENDENCY_DESCRIPTOR_CONTRACT_FROZEN_READY_FOR_NEW_IMPLEMENTATION_GENERATION

the next tranche is a new clean harness implementation generation governed by:

1. the five-domain documentary package;
2. the interpreter-observation-tuple package;
3. this embedded-dependency-descriptor package;
4. the current content bundle;
5. the current content authority.

Do not classify the new generation as Attempt 4 of the retired generation.

Do not copy or patch retired harness source.

Do not combine documentary-contract freezing with source implementation.
```

### Sources

The stale hardcoded lookup, authoritative semantic role, and exact current member are directly established by the report. :chatgpt-content-reference{index="8"}

The repair stopped because it required a `schema` field on a current bootstrap record that instead contains `schema_version`; dependency closure therefore did not complete. :chatgpt-content-reference{index="9"}

The bounded delta, protected-source comparison, all source registries, compilation, and static gates passed before that blocker. :chatgpt-content-reference{index="10"}

Attempt 3 is consumed, the generation is retired, and no v3 package or authority artifacts exist. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

**Confidence:** 0.999 that the stale runtime-matrix path is fully diagnosed; 0.999 that another localized repair is prohibited by the frozen attempt budget; 0.995 that the immediate blocker was an overuniform dependency descriptor rather than a defective bootstrap record; 0.98 that freezing the heterogeneous record-class model before a new clean implementation generation is the safest progression.

The latest attachment was fully readable. Some older uploaded files have expired; re-upload them only if a later review needs their original bytes rather than the retained identities and reports.
