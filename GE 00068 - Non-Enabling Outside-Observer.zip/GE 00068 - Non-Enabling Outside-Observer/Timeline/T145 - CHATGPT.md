## Assessment

This is a **procedural qualification failure, not a demonstrated defect in the implementation bytes**.

The report gives strong technical evidence:

- launch protocol v2 was implemented within the six-file scope;
- the final patch remained exactly 13 paths;
- 88 tests passed four times across umasks `077` and `022`;
- the independent SEC-02 negative did not execute the target marker;
- A6D, the amendment, and synthetic A6 all passed through the source-by-value launcher;
- the final canonical manifest is stable;
- the repository and protected evidence remained unchanged.

But Codex correctly refused to label that run qualifying. The extra `git status --short` lacked the required environment bindings, and a later compliant command cannot retroactively make the earlier command conforming.

**Do not change the six implementation files again. Do not repeat reconnaissance. Do not start the independent audit from this blocked producer report.**

The proportionate next step is a **fresh, qualification-only implementation closeout**:

1. Start a new Codex conversation.
2. Permit writes only to a new source-external evidence root.
3. Treat the repository as read-only.
4. Reproduce the exact current manifest before validation.
5. Rerun the complete final validation against the unchanged bytes under a clean command boundary.
6. Reproduce the same manifest at closeout.
7. Produce a clean implementation-qualification report.
8. Then begin a fresh independent audit.

That preserves the separation between implementation validation and later independent audit required by the project protocol.  It also follows the provenance lifecycle: validation and two deterministic recipe runs at implementation closeout, followed by a later audit that independently reproduces the target.  None of this makes the launch capsule, test evidence, or provenance outputs authoritative; they remain evidence/projection. 

## Codex prompt: clean qualification replay

```text
MANDATORY RESPONSE-FORMAT REQUIREMENT

Your final response must embed the complete qualification report inline in
Markdown.

Do not respond with only:

- a verdict;
- a short summary;
- a link to a report;
- “full report available at …”;
- or an attachment reference.

A source-external report file may be created and linked as supplemental
evidence, but every required report section must also appear in the response
body.

This applies to every outcome, including:

- success;
- baseline mismatch;
- process-boundary violation;
- repository mutation;
- validation block;
- provenance block.

Do not silently truncate the inline report.

FRESH-CONVERSATION REQUIREMENT

This must be a fresh Codex conversation.

Do not resume the implementation conversation that produced:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_IMPLEMENTATION_BLOCKED

That implementation conversation is permanently nonqualifying because one
read-only `git status --short` invocation did not explicitly carry the frozen
Git environment.

The source bytes are not being repaired in this turn.

Objective

Perform a clean, qualification-only implementation closeout of the existing,
unchanged Evidence Verification v1 launch-protocol-v2 patch.

The implementation bytes already exist. This turn must:

1. verify their exact opening provenance;
2. make no repository edits;
3. rerun the complete final validation under a fully compliant process
   boundary;
4. reproduce the exact same provenance at closeout;
5. produce a new clean producer qualification report suitable as input to a
   fresh independent audit.

No implementation edit is authorized.
No documentation edit is authorized.
No formatting is authorized.
No source repair is authorized.

Workspace-write permission applies only to a new source-external qualification
evidence root.

Do not stage, commit, push, create a PR, merge, install, deploy, restart A6,
invoke product paths or live services, contact a network, or execute Linux
binaries.

No subagents.

## 1. Exact inputs

Implementation worktree:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

Expected branch:

codex/evidence-verification-v1

Expected HEAD:

567bceced5df95ecfe787cc66038d463a854e12c

Expected HEAD tree:

b7cab23732572c2aaea9d5f2f1593338e2e75338

Expected sole parent:

05dde14d185b6e022dcc169ef1a658a97961850f

Expected upstream:

absent

Current canonical patch manifest:

EXPECTED_MANIFEST=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4/provenance/qualified/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98

Expected tracked binary-diff SHA-256:

6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7

Expected verifier SHA-256:

bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c

Expected verifier size:

40121 bytes

Expected test SHA-256:

7e2dcf579c5e4bf3fd72762662e3a66f96668af1470be00a665e893a9efa15a1

Expected test size:

70730 bytes

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Expected recipe ID:

execution-substrate.evidence-verification-v1.final-patch-provenance.v1

Prior technically complete but procedurally blocked implementation evidence,
read-only:

BLOCKED_EVIDENCE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v4

Blocked-run validation index:

BLOCKED_VALIDATION_INDEX=$BLOCKED_EVIDENCE/closeout/validation-index-qualified.json

Blocked-run evidence inventory:

BLOCKED_INVENTORY=$BLOCKED_EVIDENCE/closeout/final-evidence-inventory-qualified.json

Blocked-run process deviation:

BLOCKED_DEVIATION=$BLOCKED_EVIDENCE/closeout/git-command-deviation.json

Exact source-external launch capsule:

LAUNCH_CAPSULE=$BLOCKED_EVIDENCE/commands/launch_v2.py

Expected launch-capsule SHA-256:

856cc81650330deb776cbf9bff74644176405acf3163839547acfce3d73ba1e2

Load-custody reconnaissance, read-only:

RECON=/Users/ds/Downloads/ES-evidence-verification-v1-load-custody-recon-v2-f900d6abb37f

Fifth audit, read-only:

AUDIT_V5=/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5

Original sealed A6D child:

A6D=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9

Expected A6D manifest SHA-256:

dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9

Sealed A6D amendment:

A6D_AMEND=/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9

Expected amendment manifest SHA-256:

a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e

Pinned interpreter:

PYTHON=/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Expected interpreter:

- Python 3.13.4;
- regular single-link file;
- mode `0775`;
- size `119424`;
- SHA-256:
  `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

Read-only Repair 10I candidate:

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Required new qualification evidence root:

QUAL_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/load-custody-requalification-ed26813371b3

Require QUAL_ROOT absent before creation.

Forbidden primary checkout:

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

## 2. First-command and process boundary

Before executing any command, read this entire prompt.

The first command in this conversation must be exactly equivalent to:

env -i \
  PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin \
  GIT_OPTIONAL_LOCKS=0 \
  GIT_CONFIG_NOSYSTEM=1 \
  LC_ALL=C \
  LANG=C \
  PYTHONDONTWRITEBYTECODE=1 \
  git -C "/Users/ds/Repositories/Execution Substrate - evidence-verification-v1" \
  rev-parse --show-toplevel

No Git command may precede it.

If a Git command has already run in this conversation, stop immediately with:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROCESS_BOUNDARY_VIOLATION

Every later Git invocation must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - `GIT_OPTIONAL_LOCKS=0`;
  - `GIT_CONFIG_NOSYSTEM=1`;
  - `LC_ALL=C`;
  - `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
- be recorded with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in:

- PRIMARY_R;
- CANDIDATE_R;
- A6D;
- A6D_AMEND;
- BLOCKED_EVIDENCE;
- RECON;
- AUDIT_V5;
- QUAL_ROOT;
- another evidence root.

Do not use implicit-cwd Git.

The exact provenance recipe may execute its own verified internal rooted Git
commands. Record those as source-derived recipe operations and retain each
recipe run’s exit and output identities.

Any nonconforming Git invocation requires immediate stop:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROCESS_BOUNDARY_VIOLATION

A later compliant rerun does not erase a process-boundary violation in this
fresh qualification conversation.

## 3. Repository is read-only

Repository mutation is not authorized.

Do not:

- edit;
- rewrite;
- chmod;
- format;
- touch;
- create;
- delete;
- rename;
- restore;
- clean;
- stage;
- update the index intentionally;
- generate a repository-local fixture;
- create cache or bytecode in IMPL_R.

All new outputs must remain beneath QUAL_ROOT.

Any repository byte, mode, type, path, staging, or status change requires:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_MUTATION_DETECTED

## 4. Opening identity gate

Require IMPL_R:

- physical root equals lexical path;
- root is a direct real directory;
- branch:
  `codex/evidence-verification-v1`;
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`;
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`;
- parent count exactly one;
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`;
- upstream query fails only because upstream is absent;
- exactly 13 changed or untracked paths;
- exactly four modified tracked paths;
- exactly nine untracked paths;
- every patch path regular and single-link;
- every working mode `0644`;
- every logical mode `100644`;
- zero staged;
- zero deleted;
- zero renamed;
- zero unmerged;
- no extra path;
- no Git operation marker or lock.

Expected patch paths:

1. `PLANS.md`
2. `.docs/system_overview/boundaries.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `.docs/system_overview/evidence_verification.md`
6. `tools/evidence_verify/verify_v1.py`
7. `tools/evidence_verify/registry_v1.json`
8. `tools/evidence_verify/layouts/a6d_successor_v1.json`
9. `tools/evidence_verify/layouts/a6d_amendment_v1.json`
10. `tools/evidence_verify/layouts/a6_policy_v1.json`
11. `tools/evidence_verify/test_verify_v1.py`
12. `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`
13. `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt`

Open EXPECTED_MANIFEST and RECIPE through stable no-follow reads.

Require:

- exact object types, modes, sizes, link counts, and SHA-256;
- exact recipe ID;
- exact branch and HEAD;
- absent upstream;
- exact 13 manifest rows;
- exact four/nine classifications;
- every row matches live path, type, logical mode, size, and SHA-256;
- tracked binary diff equals:
  `6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7`;
- verifier and test hashes and sizes equal section 1;
- registry and three layouts equal the hashes recorded in EXPECTED_MANIFEST.

Require:

- LAUNCH_CAPSULE exact and stable;
- BLOCKED_VALIDATION_INDEX present and stable;
- BLOCKED_INVENTORY present and stable;
- BLOCKED_DEVIATION present and stable;
- RECON and AUDIT_V5 unchanged;
- A6D and A6D_AMEND manifests exact;
- CANDIDATE_R opening identity equals the baseline recorded by the blocked
  implementation report.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_BASELINE_MISMATCH

## 5. Opening provenance replay

Only after the complete opening gate passes, require QUAL_ROOT absent.

Create QUAL_ROOT under umask `077` with:

opening/
commands/
validation/
provenance/
closeout/
tmp/

All directories mode `0700`.

All retained files regular, single-link, mode `0600`, except deliberately
classified executable private validation artifacts, if any.

Create:

OPENING_CONTINUATION=$QUAL_ROOT/opening/provenance-replay-v1

OPENING_PROVENANCE=$OPENING_CONTINUATION/provenance

Require both output manifest paths absent.

Run the exact unchanged RECIPE twice against IMPL_R using the pinned
interpreter and a sanitized environment.

Require:

- both exits `0`;
- stderr empty;
- both canonical output files byte-identical;
- stdout byte-identical to the output file for each run;
- all outputs byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  `ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98`;
- tracked binary diff:
  `6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7`;
- no repository or supplied-evidence mutation.

Stop on mismatch:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROVENANCE_BLOCKED

## 6. Prior blocked-run disposition

Retain a qualification-disposition record stating:

- the previous implementation produced the current bytes;
- its technical validation and final provenance completed;
- its formal verdict was blocked solely because one extra read-only
  `git status --short` lacked explicit frozen environment bindings;
- the previous run is predecessor evidence only;
- the process violation is not erased or relabeled;
- this fresh conversation is independently rerunning qualification against the
  exact unchanged bytes;
- no source repair occurs here.

Inspect BLOCKED_DEVIATION and verify it agrees with that statement.

If the prior block had another undisclosed source, validation, provenance, or
repository mutation failure, stop:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_BASELINE_MISMATCH

## 7. Exact source and support identities

Require final live identities:

- verifier:
  `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`;
- tests:
  `7e2dcf579c5e4bf3fd72762662e3a66f96668af1470be00a665e893a9efa15a1`;
- launch capsule:
  `856cc81650330deb776cbf9bff74644176405acf3163839547acfce3d73ba1e2`;
- registry:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`;
- A6D successor layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`;
- amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`;
- A6 policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`;
- historical fixtures:
  - `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98`;
  - `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f`.

Copy LAUNCH_CAPSULE into QUAL_ROOT/commands only as an inert, byte-exact,
mode-0600 evidence copy. Do not modify it.

Its status remains:

source-external validation/provenance evidence

It is not repository source, verifier authority, readiness authority, product
source, runtime source, or an independent correctness oracle.

## 8. Fresh validation construction

Do not reuse a prior command result as qualification.

Use BLOCKED_VALIDATION_INDEX only to recover and cross-check the intended
final qualifying command set.

Reconstruct every qualifying validation command with:

- current exact repository bytes;
- current exact launch capsule;
- fresh, private roots beneath QUAL_ROOT;
- pinned interpreter;
- sanitized environment;
- no network;
- no repository output;
- no supplied-evidence output.

Record exact argv, cwd, full safe environment, exit, stdout/stderr byte counts
and SHA-256, relevant result summary, and cleanup.

Do not rerun superseded implementation attempts unless required as a specific
negative causal.

## 9. Static and contract gates

Run fresh:

1. `ast.parse` over:
   - `verify_v1.py`;
   - `test_verify_v1.py`.
2. Parse the two historical `.py.txt` fixtures without executing them.
3. Strictly parse:
   - registry;
   - all three layouts.
4. Verify registry-to-layout hash bindings.
5. Verify historical fixture hashes.
6. Verify authoritative documentation statements for:
   - launch protocol v2;
   - external caller versus verifier responsibility;
   - source-by-value transport;
   - direct-script nonqualification;
   - unchanged structural evidence and non-readiness authority;
   - package, target, and candidate disjointness;
   - fail-closed capability posture.
7. Run `git -C "$IMPL_R" diff --check` under the complete required Git
   environment.

Any repository mutation is a hard stop.

## 10. Complete test-suite replay

Independently discover and retain the exact test set.

Require exactly 88 unique tests with the identities reported by the blocked
implementation, or stop on unexplained difference.

Run the complete suite:

- twice under umask `077`;
- twice under umask `022`.

Use:

- pinned Python;
- `-I -B`;
- `PYTHONDONTWRITEBYTECODE=1`;
- `LC_ALL=C`;
- `LANG=C`;
- a fresh private `TMPDIR` per run;
- no network.

Require every run:

- process exit `0`;
- exactly 88 tests;
- zero failure;
- zero error;
- zero skip;
- identical test identity set;
- no repository artifact;
- no supplied-evidence mutation.

A shell-wrapper error after a successful suite does not qualify. The complete
owning command must exit `0`.

## 11. Targeted launch-protocol-v2 causals

Run every final positive and negative launch-protocol causal independently,
including at minimum:

- exact v2 pre-seal pass;
- exact v2 sealed pass;
- direct script rejection;
- final-symlink script rejection;
- parent-symlink script rejection;
- stdin rejection;
- `/dev/fd/N` rejection;
- missing package root;
- reordered application arguments;
- extra application arguments;
- extra, combined, or reordered interpreter flags;
- `__file__` presence;
- missing isolation/no-site/no-bytecode flags;
- captured argv versus later live argv mutation;
- exact source/package byte equality;
- one-byte source mismatch;
- package source replacement after argv construction;
- source replacement/disappearance during checking;
- invalid UTF-8 caller pre-exec rejection;
- NUL caller pre-exec rejection;
- missing terminal LF caller pre-exec rejection;
- Unicode source round trip;
- over-limit source caller pre-exec rejection;
- injected insufficient argv capacity;
- target-contained source present but never loaded;
- registry returned-hash mismatch and caller rejection;
- layout returned-hash mismatch and caller rejection;
- output source/path/hash non-disclosure.

For verifier failures require:

- exact outcome;
- exact error class;
- exact exit;
- one canonical stdout line;
- empty stderr;
- no traceback;
- no forbidden path or source leak.

For caller pre-exec rejections require:

- no verifier child launch;
- zero child stdout/stderr;
- exact launch-record reason;
- unchanged target/package/candidate.

## 12. Independent SEC-02 replay

Run a fresh source-external SEC-02 timed negative outside the unit-suite
wrapper.

Do not reuse the prior result.

The test must demonstrate:

- target-contained marker source exists;
- an external symlink or mutable path is raced as in SEC-02;
- the valid v2 caller supplies authenticated source bytes directly through
  `-c`;
- target marker never executes;
- target marker does not appear in stdout or stderr;
- every qualifying pass comes only from the authenticated argv source;
- any package inconsistency detected later rejects or blocks;
- no forged pass from target-contained code is observed.

Retain all attempted timings, including early and late swaps.

Do not claim exhaustive race proof.

## 13. Real A6D compatibility replay

Using the exact current LAUNCH_CAPSULE and verifier bytes, run sealed A6D twice.

Require:

- launch protocol v2;
- exact authenticated verifier source by value;
- explicit package root;
- pinned registry and layout hashes;
- both exits `0`;
- empty stderr;
- byte-identical canonical stdout;
- stdout SHA-256:
  `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`;
- target, package, TMPDIR, and caller-evidence no-write snapshots equal before
  and after;
- A6D manifest still:
  `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`.

This remains structural compatibility evidence only.

## 14. Real amendment compatibility replay

Run the sealed amendment twice under the same v2 caller requirements.

Require:

- both exits `0`;
- empty stderr;
- byte-identical canonical stdout;
- stdout SHA-256:
  `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`;
- unchanged target/package/TMPDIR/caller-evidence snapshots;
- amendment manifest still:
  `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`.

This remains structural compatibility evidence only.

## 15. Synthetic A6 replay

Use the existing test-owned private writer under a fresh QUAL_ROOT fixture.

Run:

1. pre-seal twice through v2;
2. seal only the qualification-owned synthetic fixture;
3. sealed twice through v2.

Require:

- all four exits `0`;
- empty stderr;
- deterministic pairwise output per stage;
- target, package, candidate when applicable, TMPDIR, and caller-evidence
  snapshots unchanged by verifier invocation;
- verifier installs nothing;
- fixture removed at cleanup.

## 16. No-write and artifact checks

For every verifier and launch-capsule invocation, snapshot before and after:

- target;
- verifier package;
- manifest candidate when applicable;
- private TMPDIR;
- caller evidence root excluding the intended new record itself.

Require:

- no target mutation;
- no package mutation;
- no candidate mutation;
- no TMPDIR residue;
- only the intended caller-owned record beneath QUAL_ROOT.

Scan IMPL_R for:

- `__pycache__`;
- `.pyc`;
- `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixture roots;
- databases;
- journals;
- locks;
- build outputs;
- unexpected executable modes;
- unsupported objects.

Do not delete anything from IMPL_R. Any newly created repository artifact is a
mutation and blocks qualification.

## 17. Process-boundary audit

At closeout, inspect the complete command ledger.

Require:

- every direct Git command conformed;
- every Git command was rooted at IMPL_R;
- every Git command explicitly carried the complete required environment;
- no Git command ran in PRIMARY_R or another forbidden root;
- no subagent ran;
- no repository mutation command ran;
- no network command ran;
- no product/live-service command ran.

A single nonconforming Git command in this fresh conversation requires:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROCESS_BOUNDARY_VIOLATION

Do not downgrade it based on later clean checks.

## 18. Closing provenance replay

Remove only QUAL_ROOT-owned temporary fixtures and caches.

Require a fresh absent closing continuation:

CLOSING_CONTINUATION=$QUAL_ROOT/closeout/provenance-replay-v1

Run the exact unchanged RECIPE twice against IMPL_R.

Require:

- both exits `0`;
- stderr empty;
- output files byte-identical;
- stdout byte-identical to output files;
- outputs byte-identical to EXPECTED_MANIFEST;
- SHA-256:
  `ed26813371b3f77902613b820a1e0ad3964c3930fc6603e8daafa7ec1c1fff98`;
- tracked binary diff:
  `6e2e757d0a09bf0f4ee38eb848e029391cc431c0813ab67552d1146f46846cd7`;
- exact opening/closing path, classification, mode, size, and per-file hash
  equality;
- zero staged/deleted/renamed/unmerged;
- no repository or supplied-evidence mutation.

Any mismatch requires:

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROVENANCE_BLOCKED

## 19. Closing identity

Require final IMPL_R:

- same physical root;
- same branch, HEAD, tree, sole parent, and absent upstream;
- exact same 13 paths;
- exact four modified tracked and nine untracked;
- every path regular, single-link, working mode `0644`, logical mode `100644`;
- exact same per-file size and SHA-256;
- zero staged/deleted/renamed/unmerged;
- no operation marker or lock;
- `git diff --check` clean;
- no generated repository artifact.

Require:

- BLOCKED_EVIDENCE unchanged;
- RECON unchanged;
- AUDIT_V5 unchanged;
- CANDIDATE_R unchanged;
- A6D unchanged;
- A6D_AMEND unchanged;
- PRIMARY_R never used as cwd or Git root.

## 20. Verdicts

Use exactly one:

### Clean success

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFIED_READY_FOR_FRESH_AUDIT

Use only when:

- opening provenance equals the expected current manifest;
- no repository byte changes;
- every command obeyed the frozen process boundary;
- all fresh validation passed;
- SEC-02 negative passed;
- real and synthetic compatibility checks passed;
- closing provenance equals opening exactly.

### Baseline mismatch

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_BASELINE_MISMATCH

### Process violation

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROCESS_BOUNDARY_VIOLATION

### Repository mutation

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_MUTATION_DETECTED

### Validation block

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_VALIDATION_BLOCKED

### Provenance block

EVIDENCE_VERIFICATION_V1_LOAD_CUSTODY_REQUALIFICATION_PROVENANCE_BLOCKED

## 21. Required complete inline report

Your final response must embed the complete qualification report inline.

Do not replace a section with a link.

Supplemental links may follow the complete inline report.

Include:

1. Verdict.
2. Response-format confirmation.
3. Purpose and statement that no source repair was authorized.
4. Previous blocked-run disposition.
5. Opening repository identity.
6. Opening canonical manifest and tracked-diff identities.
7. Process-boundary record.
8. Exact current verifier, test, and launch-capsule identities.
9. Static and documentation gates.
10. Complete discovered test set and count.
11. First umask-077 result.
12. Second umask-077 result.
13. First umask-022 result.
14. Second umask-022 result.
15. Every targeted v2 causal result.
16. Fresh SEC-02 timed-negative result.
17. Real A6D run 1.
18. Real A6D run 2.
19. Real amendment run 1.
20. Real amendment run 2.
21. Synthetic pre-seal runs.
22. Synthetic sealed runs.
23. No-write evidence.
24. Artifact scan.
25. Validation command/result index.
26. Opening and closing provenance replay.
27. Exact final 13-path manifest or complete inline table.
28. Final canonical-manifest SHA-256.
29. Final tracked binary-diff SHA-256.
30. Qualification-evidence inventory.
31. Authority and nonclaim statement.
32. Remaining uncertainty.
33. Explicit confirmations:
    - no repository source or documentation byte changed;
    - no formatting performed;
    - no staging performed;
    - no commit performed;
    - no push performed;
    - no A6 restart;
    - no product tests or live services;
    - no network contact;
    - no subagents;
    - fresh independent audit not performed.

No implementation.
No repair.
No staging.
No commit.
No push.
No A6 restart.
```

## After a clean replay

A clean success does not itself establish correctness. It supplies a procedurally qualifying producer report bound to the unchanged `ed268…` manifest. The next conversation must be a fresh, read-only independent audit. The auditor should independently construct or inspect the source-by-value caller, rerun SEC-02, reproduce the exact manifest at opening and closeout, and return `ACCEPT`, `BLOCK`, `REJECT`, or `AUDIT_PROVENANCE_MISMATCH`.

The prior blocked run remains preserved rather than rewritten. Provenance can establish that validation and audit address the same bytes, but it cannot establish correctness or authority by itself. 

### Sources

- Codex’s complete inline load-custody implementation report supplied in this turn.
- Parent-only implementation includes validation and exact provenance but not independent audit. 
- Implementation closeout requires validation, artifact cleanup, and two deterministic provenance runs. 
- Independent audit begins later in a fresh read-only conversation. 
- Provenance is evidence, not correctness or authority. 
- The MVP freeze prohibits proof-harness behavior and generated evidence from silently becoming architecture or authority. 

**Confidence**

- Technical implementation completion: **0.97**
- Formal nonqualification of the reported run: **0.999**
- Evidence that repository bytes were harmed by the extra Git command: **none reported**
- Correctness of a fresh qualification-only replay as the next step: **0.995**
- Need for any source repair before that replay: **low, approximately 0.01**
