Here is Codex's response:



# Repair 10I A6 Current Contract Reconnaissance

## 1. Verdict

`REPAIR10I_A6_CURRENT_CONTRACT_RECONNAISSANCE_BLOCKED`

Opening identities are stable, the five control roles are recoverable, and the structural verifier gap is closed. A fresh A6 remains blocked because:

1. The sealed A6D runner fingerprints `observability-inbound-request-complete-v1`, while its semantic extractor and FORMAT require `...-v2`. Final/fresh equality would conceal the mismatch. See [runner.go (line 1533)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/runner.go:1533), [semantic.go (line 26)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/semantic.go:26), and [FORMAT.md (line 503)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/FORMAT.md:503).
2. Candidate `PLANS.md` and `.docs/` still govern an older v1 Repair 10I family, while A6D implements v6/v3/v2/v1. Repository rules require that conflict to be repaired in documentation before implementation. See [AGENTS.md (line 21)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/AGENTS.md:21>) and [PLANS.md (line 4044)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:4044>).
3. Historical comparison has partial source, but no qualified directional acceptance contract. Current v6 and the older unexecuted future-v6 draft have different field maps and policies.
4. No five current suite specifications exist as complete bytes. Fresh paths, corrected successor binary hashes, provenance paths, complete-spec digests, and physical identities do not yet exist.

## 2. Opening identities and inspected roots

### Committed Evidence Verification package

| PropertyObserved |                                                                         |
| ---------------- | ----------------------------------------------------------------------- |
| Root             | `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1` |
| Branch           | `codex/evidence-verification-v1`                                        |
| HEAD             | `05dcedb75b674660215504dcf5b5fab9dbb8aa2f`                              |
| Tree             | `1705df78364003806e2463bb54588c09dc69c60d`                              |
| Sole parent      | `567bceced5df95ecfe787cc66038d463a854e12c`                              |
| Subject          | `add evidence verification v1`                                          |
| Upstream         | Absent                                                                  |
| Worktree/index   | Clean                                                                   |
| Verifier SHA-256 | `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`      |
| Registry SHA-256 | `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`      |
| A6 layout ID     | `execution-substrate.repair10i.a6-policy-layout/v1`                     |
| Layout SHA-256   | `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`      |

The verifier owns structural closure only; its documentation expressly withholds semantic readiness authority. See [evidence\_verification.md (line 102)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:102>) and [evidence\_verification.md (line 218)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:218>).

### Source-external caller

| PropertyObserved |                                                                                                                                                         |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Path             | `/Users/ds/Downloads/ES-evidence-verification-v1-caller-bundle-publication-repair-3c06a1c8dae1-dt7_82mr/source/launch_v4_trusted_host_atomic_bundle.py` |
| Type/mode/links  | Regular, `0600`, one link                                                                                                                               |
| Size             | 49,047 bytes                                                                                                                                            |
| SHA-256          | `643fc7d12dd26463e26310db4bbf500fd942b411ff27e4a29365a5a124e27bf5`                                                                                      |
| Launch protocol  | `execution-substrate.evidence-closure-launch/v2`                                                                                                        |
| Record schema    | `execution-substrate.evidence-closure-launch-record/v4`                                                                                                 |

The whole-directory publication contract is documented at [evidence\_verification.md (line 153)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:153>).

### Candidate repository

| PropertyObserved                |                                                                                   |
| ------------------------------- | --------------------------------------------------------------------------------- |
| Root                            | `/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1` |
| Branch                          | `codex/remote-alpha-external-tls-status-observation-v1`                           |
| HEAD                            | `567bceced5df95ecfe787cc66038d463a854e12c`                                        |
| Tree                            | `b7cab23732572c2aaea9d5f2f1593338e2e75338`                                        |
| Sole parent                     | `05dde14d185b6e022dcc169ef1a658a97961850f`                                        |
| Upstream                        | Absent                                                                            |
| Rebuilt source T                | `8de797304ea944b6a155924e0d1e9e8bbe79534e`                                        |
| Inventory                       | `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`                |
| Membership                      | 389 total, 375 tracked, 14 nonignored untracked                                   |
| Staged/deleted/renamed/unmerged | 0/0/0/0                                                                           |
| Modified tracked                | 22                                                                                |
| Physical device/inode           | `16777234/122118502`                                                              |

All 389 inventory rows were independently checked for membership, mode, size, and digest. A pure read-only reconstruction reproduced source T.

### Evidence roots

| RootVerified identity/result |                                                                                                                                              |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| A6D                          | Manifest `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9`; 623 payload files and 205 directories; complete closure checked |
| A6D source                   | T `8c237318e3a72172e5cbbdf41f5e68244ae15895`; inventory `7f858d9c8d38d70b0a8bd7a2b15901af677196839affe1059b39be1e2c1c6852`                   |
| Amendment                    | Manifest `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`; 29 payload files and 9 directories; complete closure checked    |
| Joint qualification          | SHA-256 `e9af0475fb0855404616630c3dfc5749be6d5b7f7ec9107a8de0eee2e7eb92c9`                                                                   |
| A6V                          | Inspected as design reconnaissance, not execution authority                                                                                  |
| A6R                          | Retained v5/v2 source and records inspected as historical compatibility                                                                      |

The joint qualification explicitly records that fresh A6 was not restarted and the historical comparator was not implemented. See [joint-qualification-v1.json (line 11)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-seal-verifier-amendment-8de797304ea9/closeout/joint-qualification-v1.json:11).

Existing children inspected and rejected for reuse were the bare, `a5s`, `a5c`, `a6o`, `a6r`, and `a6d` variants of `phase-i-a6-policy-evidence-*`. All remain immutable and nonresumable.

All repository Git observations were parent-only, read-only, used exact `git -C` roots and the required environment, and did not target the primary checkout.

## 3. Explorer identities, scopes, scheduling, failures/retries, and completion

| ExplorerCanonical identityScopeSchedulingResult |                                 |                                                           |                                                             |           |
| ----------------------------------------------- | ------------------------------- | --------------------------------------------------------- | ----------------------------------------------------------- | --------- |
| 1                                               | `/root/dialect_specs`           | Current dialect and five suite specifications             | Started after opening verification, concurrent with 2 and 3 | Completed |
| 2                                               | `/root/comparator_analyzer`     | Historical comparator and transition analyzer             | Started after opening verification, concurrent with 1 and 3 | Completed |
| 3                                               | `/root/allocator_orchestration` | Fresh allocation, orchestration, closeout, sealing        | Started after opening verification, concurrent with 1 and 2 | Completed |
| 4                                               | `/root/authority_ownership`     | Authority, ownership, security, provenance, tranche split | Started only after Explorer 1 closed                        | Completed |

There were no start failures and no retries. Explorers ran no Git commands and spawned no nested subagents.

## 4. Evidence/inference/uncertainty ledger

| IDClassFinding |                               |                                                                                                                                                                                                                                                                                     |
| -------------- | ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| E-01           | Evidence                      | All opening repository, caller, candidate, manifest, and source identities matched expected values.                                                                                                                                                                                 |
| E-02           | Evidence                      | A6D implements the v6/v3 dialect and strict current qualification machinery. See [runner.go (line 30)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/runner.go:30).                   |
| E-03           | Evidence                      | The five retained instantiated specs are v5 and therefore parse-only.                                                                                                                                                                                                               |
| E-04           | Evidence                      | The logical fingerprint says observability v1, while the extractor and FORMAT say v2.                                                                                                                                                                                               |
| E-05           | Evidence                      | Historical comparator completion is expressly disclaimed by the joint qualification.                                                                                                                                                                                                |
| E-06           | Evidence                      | The retained analyzer hardcodes control qualification v5 and read policy v2. See [transition analyzer:452 (line 452)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9/commands/repair10i_a6_transition_analyzer_v1.py:452). |
| E-07           | Evidence                      | A6V labels its target identifier and naming proposal as design candidates. See [A6V final report:31 (line 31)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6v-evidence-target-recon-8de797304ea9/closeout/final-report-v1.md:31).                          |
| E-08           | Evidence                      | EV now registers the ten-directory A6 structural layout but does not inspect semantic contents.                                                                                                                                                                                     |
| I-01           | Inference                     | A successor copy of the A6D source is necessary; using sealed A6D binaries unchanged would retain the fingerprint defect.                                                                                                                                                           |
| I-02           | Inference                     | A version advance is safer than redefining active v6 records because acceptance semantics and historical fields change.                                                                                                                                                             |
| I-03           | Inference                     | Pairwise factual comparison and directional transition acceptance require distinct outputs even if implemented in one source package.                                                                                                                                               |
| U-01           | Current governing uncertainty | Candidate authority has not selected v7 versus a separate successor adjudication layered on v6 facts.                                                                                                                                                                               |
| U-02           | Current governing uncertainty | Historical policy conflicts over arbitrary `absent→pass`, aggregate exit equality, and acceptance exit semantics remain unresolved.                                                                                                                                                 |
| U-03           | Instance uncertainty          | Fresh absolute paths, inodes, complete-spec hashes, corrected tool hashes, and generated provenance cannot exist before implementation and allocation.                                                                                                                              |

## 5. Current contract ledger

| ItemClassificationCurrent state   |                                                       |                                                                                                             |
| --------------------------------- | ----------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| Suite specification schema        | Current implemented contract                          | Strict `suite-spec.v6` loader and validator exist.                                                          |
| Pristine final spec               | Missing current instance                              | Exact v5 historical instance exists; no v6 current instance.                                                |
| Fresh independent final spec      | Missing current instance                              | Exact v5 historical instance exists; no v6 current instance.                                                |
| Intentional mutant spec           | Missing current instance                              | Exact v5 historical instance and provenance exist; fresh constructor binding is missing.                    |
| Historical HEAD spec              | Missing current instance                              | Exact v5 historical instance exists; no v6 current instance.                                                |
| Historical Repair 9 spec          | Missing current instance                              | Exact v5 instance and overlay provenance exist; no v6 current instance.                                     |
| Suite result                      | Current implemented contract                          | `suite-result.v6`.                                                                                          |
| Control qualification             | Current implemented contract                          | `control-qualification.v6`.                                                                                 |
| Peer qualification                | Current implemented contract                          | A second independently recomputed `control-qualification.v6`; no separate peer schema.                      |
| Effective read policy             | Current implemented contract                          | `effective-read-policy.v3`.                                                                                 |
| Semantic extraction               | Current implemented contract                          | `go-test-semantics.v1`, with the v2 observability canonicalization rule.                                    |
| Factual comparison                | Current implemented contract with incomplete custody  | v6 spec/result logic exists; v6 custody ID is declared but no current producer/field implementation exists. |
| Historical directional comparator | Missing implementation and governing decision         | Partial helper exists, but no qualified direction/custody/acceptance chain.                                 |
| Transition analyzer               | Current retained historical compatibility             | Analyzer v1 works on v5/v2 inputs; no current v6/v3 analyzer exists.                                        |
| Closeout adjudicator              | Missing governing decision and current implementation | Retained A6R structural records cannot qualify a successor.                                                 |
| Orchestration state/progression   | Missing governing decision and current implementation | Retained script is v5/v2 and path-bound to a failed child.                                                  |
| Fresh-child allocator             | Missing governing decision and implementation         | A6V proposed names but froze none.                                                                          |
| Evidence Verification closure     | Current implemented contract                          | Structural pre-seal/sealed closure through registered layout v1.                                            |
| Caller publication                | Current implemented contract                          | Frozen caller v4 publishes external three-file bundles.                                                     |
| Failed children                   | Superseded/nonresumable evidence                      | Read-only historical evidence only.                                                                         |

## 6. Current-versus-historical dialect map

### Implemented A6D active set

The closed 24-schema set is documented at [FORMAT.md (line 905)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/FORMAT.md:905) and enforced at [runner.go (line 57)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/runner.go:57):

- `execution-substrate.repair10i.suite-spec.v6`
- `execution-substrate.repair10i.ab-suite-spec.v6`
- `execution-substrate.repair10i.suite-result.v6`
- `execution-substrate.repair10i.binding-recomputation.v6`
- `execution-substrate.repair10i.control-qualification.v6`
- `execution-substrate.repair10i.semantic-comparison-spec.v6`
- `execution-substrate.repair10i.semantic-comparison-result.v6`
- `execution-substrate.repair10i.semantic-comparison-custody.v6`
- `execution-substrate.repair10i.command-intent.v3`
- `execution-substrate.repair10i.command-result.v3`
- `execution-substrate.repair10i.terminal-reconciliation.v3`
- `execution-substrate.repair10i.effective-read-policy.v3`
- Four private PTY v2 schemas
- `control-observation.v1`
- `mutable-inventory.v1`
- `intentional-mutant-provenance.v1`
- `validation-harness-overlay-provenance.v1`
- `go-test-semantics.v1`
- `byte-capture.v1`
- `byte-comparison-spec.v1`
- `byte-comparison-result.v1`

### Historical compatibility

- v5 suite, result, qualification, and comparison records plus v2 read policies are parse/report-only.
- Earlier v4/v1 records remain historical only.
- Mixed current/historical chains reject.
- Command v3, PTY v2, and the enumerated v1 schemas are not automatically advanced because the outer suite version changes.
- No relabeling or adapter may promote a retained record.

The transition rules are recorded in [schema-transition-v1.json (line 2)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/controls/schema-transition-v1.json:2).

### Governance conflict

Candidate docs still describe the active Repair 10I family as v1 in:

- [PLANS.md (line 4044)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md:4044>)
- [configuration.md (line 2103)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/configuration.md:2103>)
- [boundaries.md (line 1353)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/boundaries.md:1353>)
- [artifact\_hygiene.md (line 592)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md:592>)
- [capability\_probing.md (line 677)](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md:677>)

That conflict must be resolved before a successor dialect becomes current authority.

## 7. Exact version/schema map

### Exact implemented IDs

| SurfaceExact current implemented ID |                                                                                                      |
| ----------------------------------- | ---------------------------------------------------------------------------------------------------- |
| Suite specification                 | `execution-substrate.repair10i.suite-spec.v6`                                                        |
| Suite result                        | `execution-substrate.repair10i.suite-result.v6`                                                      |
| Control qualification               | `execution-substrate.repair10i.control-qualification.v6`                                             |
| Peer qualification                  | Same `control-qualification.v6`, independently produced                                              |
| Effective read policy               | `execution-substrate.repair10i.effective-read-policy.v3`                                             |
| Semantic envelope                   | `execution-substrate.repair10i.go-test-semantics.v1`                                                 |
| Comparison specification            | `execution-substrate.repair10i.semantic-comparison-spec.v6`                                          |
| Comparison result                   | `execution-substrate.repair10i.semantic-comparison-result.v6`                                        |
| Comparison custody                  | ID `execution-substrate.repair10i.semantic-comparison-custody.v6`; implementation missing            |
| Historical analysis                 | Retained `execution-substrate.repair10i-a6.historical-transition-analysis.v1`; not current-qualified |
| Cleanup                             | Retained `execution-substrate.repair10i-a6.cleanup-absence.v1`; not a current governing contract     |

No current authoritative IDs exist for comparison adjudication, child allocation, current opening/orchestration, current closeout adjudication, failed-attempt index, or command index.

### Suite specification field map

The strict Go map at [runner.go (line 174)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/runner.go:174) is:
```
schema
name
source_class
intended_comparison_role
source_origin
inventory_path
expected_tree
base_tree
base_inventory_sha256
effective_inventory_sha256
mutation_provenance_path?
mutation_provenance_sha256?
validation_harness_overlay? {
  overlay_id
  provenance_path
  provenance_sha256
  base_inventory_path
  base_members
  effective_members
}
control_parent
evidence_dir
go_root
go_path
git_path
python_path
openssl_path
cc_path?
sdk_root?
self_host_peer_path
runtime_read_paths[]
module_cache_from
retain_control_for_comparison?
commands[]
```

Each command contains:
```
name, argv[], env?, lane, timeout_ms, stdout_cap, stderr_cap,
expected_exit[], extract_go_test?, race?, extra_read_paths[]?,
extra_traversal_paths[]?, denied_read_paths[]?,
require_denied_read_probe?, outside_sentinel?,
open_ungranted_listener?, signal_after_ms?, signal?,
expect_survivor_cleanup?, historical?, private_pty?
```

### Control qualification map

The exact fields are defined at [runner.go (line 644)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/runner.go:644):
```
schema, control_id, outcome,
materialization_verified, base_materialization_verified,
overlay_provenance_verified, overlay_recipe_recomputed,
effective_materialization_verified, inherited_umask_verified,
self_host_verified, read_policy_verified,
denied_path_causality_verified, commands_accepted,
terminal_reconciliation_verified, fresh_zero_observations_verified,
resource_disposition_verified, private_pty_verified,
error_class?, suite_result_path, suite_result_sha256,
tool_binary_sha256, source_class,
base_tree, base_inventory_sha256,
effective_tree, effective_inventory_sha256,
source_tree, source_inventory_sha256,
complete_suite_spec_sha256, logical_suite_fingerprint,
mutation_provenance_path?, mutation_provenance_sha256?,
source_binding, command_bindings[]
```

### Recommended successor map

This is a proposed repair contract, not current authority:

| SurfaceRecommended successor ID                |                                                                           |
| ---------------------------------------------- | ------------------------------------------------------------------------- |
| Suite specification/result/qualification chain | Advance corresponding v6 IDs to v7                                        |
| Comparison spec/result/custody                 | Advance corresponding v6 IDs to v7                                        |
| Effective read policy                          | Retain v3                                                                 |
| Semantic envelope                              | Retain v1, with canonicalization rule v2                                  |
| Historical analysis                            | `execution-substrate.repair10i-a6.historical-transition-analysis.v2`      |
| Historical acceptance                          | `execution-substrate.repair10i-a6.historical-comparison-adjudication.v1`  |
| Child allocation                               | `execution-substrate.repair10i-a6.child-allocation.v1`                    |
| Opening capsule                                | `execution-substrate.repair10i-a6.opening-capsule.v1`                     |
| Orchestration record                           | `execution-substrate.repair10i-a6.orchestration-record.v1`                |
| Closeout adjudication                          | `execution-substrate.repair10i-a6.closeout-adjudication.v1`               |
| Cleanup                                        | `execution-substrate.repair10i-a6.cleanup.v1`                             |
| Failed-attempt index                           | `execution-substrate.repair10i-a6.failed-and-superseded-attempt-index.v1` |
| Command index                                  | `execution-substrate.repair10i-a6.command-index.v1`                       |

These IDs must be adopted in candidate governance before they become current.

## 8. Five complete current suite-specification capsules

No complete current instances exist. The following are the exact recovered logical cores and the fields that prevent byte-exact current instantiation.

### Common command sequence

All commands use lane `no-tcp`.

| OrdinalCommandExpected exitTimeoutstdout/stderr cap |                                                          |         |            |                  |
| --------------------------------------------------- | -------------------------------------------------------- | ------- | ---------- | ---------------- |
| 1                                                   | `denied-read-causality`                                  | `[0]`   | 5,000 ms   | 1 MiB / 1 MiB    |
| 2                                                   | `seed-existing-transitive-mod-metadata`                  | `[0]`   | 30,000 ms  | 1 MiB / 1 MiB    |
| 3                                                   | `initialize-private-git-administration-and-object-store` | `[0]`   | 120,000 ms | 1 MiB / 1 MiB    |
| 4                                                   | `install-control-root-private-mktemp-wrapper`            | `[0]`   | 5,000 ms   | 1 MiB / 1 MiB    |
| 5                                                   | `seed-hash-bound-historical-head-corpus`                 | `[0]`   | 30,000 ms  | 128 MiB / 32 MiB |
| 6                                                   | `complete-active-test-inventory-before-launch`           | `[0]`   | 600,000 ms | 128 MiB / 32 MiB |
| 7                                                   | `literal-complete-private-repository-suite`              | `[0,1]` | 900,000 ms | 128 MiB / 32 MiB |

Command 6 is pinned Go `test -json -list ^Test ./...`. Command 7 invokes pinned Go as `test -json -count=1 -p=1 -parallel=1 ./...` with `ES_REPAIR10_A5T_SOCKET_TRACE=1`.

The authoritative retained command bytes are visible in [the pristine spec:5 (line 5)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9/controls/repair10i-pristine-final-v1-suite-spec-v1.json:5). Those v5 bytes are historical inputs and cannot simply be recaptioned.

Common runtime reads are:
```
/System/Library
/usr/lib
/usr/bin/sandbox-exec
/bin/sh
/bin/bash
/private/var/select/sh
/bin/sleep
/dev/null
/usr/bin/shasum
/bin/mkdir
/bin/cp
/bin/chmod
```

Command 7 requires private PTY v2 with role `openpty-no-ctty`. Final, fresh, mutant, and Repair 9 require exactly 21 pairs; historical HEAD requires exactly 1.

Every suite must produce seven command intent v3 records, seven command result v3 records, seven terminal reconciliation v3 records, v3 effective-read policies, a v7 successor suite result, producer qualification, and opposite-side peer qualification. The aggregate runner exit must be 0 because every command exit must belong to its declared set.

### Control capsules

| ControlSource classBase identityEffective identityProducer/peer |                      |                                                                                                                                         |                                                                                                                                         |     |
| --------------------------------------------------------------- | -------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | --- |
| `repair10i-pristine-final-v1`                                   | `pristine-final`     | T `8de797304ea944b6a155924e0d1e9e8bbe79534e`; inventory `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`; 389 members | Same                                                                                                                                    | A/B |
| `repair10i-fresh-independent-final-v1`                          | `pristine-final`     | Same logical identity                                                                                                                   | Same, independently materialized and physically disjoint                                                                                | B/A |
| `repair10i-intentional-mutant-v1`                               | `intentional-mutant` | Final tuple, 389 members                                                                                                                | T `f981be84add168983b88b6afe15797fcbbb8e033`; inventory `7e252406cb345e1c9380fdf23ddae131eca91d1ce7ee23a817a7b333eccb6802`; 389 members | A/B |
| `repair10i-historical-head-v1`                                  | `historical-head`    | T `b7cab23732572c2aaea9d5f2f1593338e2e75338`; inventory `291d9e9b2cf2f3875f5c06378415fb49e0b17703adc846874a0026af843f399a`; 375 members | Same                                                                                                                                    | B/A |
| `repair10i-historical-repair9-v1`                               | `historical-repair9` | T `0ea3b661f09e73e1126bae0f6e993e22bbf21198`; inventory `7b8cfa43f5338a15b632a3ce8fc20f8df56a192702d951b4d5967deba494199e`; 382 members | T `4bd05d4f949e6239ff7aaeb68ac229143ddeff6e`; inventory `e17a7732e260a8af7305d5e130bbbc2cc9608175390c2d763f8c655471ea6583`; 382 members | A/B |

#### Pristine final

- Materialize exactly the 389-member final inventory into a fresh physical source root.
- Verify modes, hashes, membership, T, absence of aliases, and unchanged post-run identity.
- No mutation and no overlay.
- Compare with fresh as qualified equal; compare with mutant as exact qualified difference.
- PTY count: 21.

#### Fresh independent final

- Materialize the same 389 logical members into a separately created root.
- No shared inode, Git store, cache, runtime, socket, temp, or control state with pristine final.
- Logical fingerprint must equal pristine final; complete spec digest must differ because physical bindings differ.
- PTY count: 21.

#### Intentional mutant

Exactly one path changes:
```
es/externaltls/internal/statusobservation/remoteobserver/observe_test.go
```

| PropertyBeforeAfter |                                                                    |                                                                    |
| ------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| Mode                | `100644`                                                           | `100644`                                                           |
| Size                | 268,924                                                            | 268,966                                                            |
| SHA-256             | `cb9b48199469b4ff4a15b7e0180e52c63babbd5a08b9c341c6f065d6c44939ec` | `5c5c75ba1c7ee712f006a692a07171b38775bead2dc638fc713e0d24512d9898` |

The retained provenance is [intentional-mutant-provenance-v1.json (line 2)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9/sources/intentional-mutant-provenance-v1.json:2). A successor record must bind the new constructor’s actual path, size, and digest.

#### Historical HEAD

- Materialize the exact 375 tracked-member HEAD tree.
- Mark the full-suite command historical.
- PTY count: 1.
- It may contribute only the baseline side of `historical-head → pristine-final`.

#### Historical Repair 9

The sole overlay path is:
```
remote_alpha_prepare_external_tls_status_test.go
```

Required lineage:
```
overlay_id:
  repair10i-historical-repair9-a5t4-validation-harness-overlay-v1
recipe_id:
  repair10i-historical-repair9-a5t4-validation-harness-overlay-recipe-v1
recipe SHA-256:
  811c420adc61f33a4117ae553863d194d021ede9f0a8d0ae5dfee9c3fe0e64e5
```

The overlay must be constructed before execution, independently recomputed, frozen, and labeled validation-only, nonauthoritative, and nonproduct. See [overlay provenance:2 (line 2)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9/sources/repair9-overlay-authority/overlay-provenance-v1.json:2).

### Common terminal, resource, cleanup, and qualification requirements

For every command:

- intent/result/reconciliation identities agree;
- owner disposition completes;
- workers join;
- endpoints release;
- resource ledger closes;
- PTY broker state reconciles;
- two genuinely fresh zero observations succeed;
- next-command barrier is `verified-empty`;
- raw stdout/stderr are retained through EOF;
- effective read policy v3 is independently verified.

All five control roots remain retained until comparisons and analysis finish. Cleanup removes only allowlisted private roots after confirming no process, descriptor, or socket survivors, then records two new absence epochs.

### Fields that prevent current byte-exact instantiation

The following acceptance-bearing values do not yet exist:

- fresh source, control, evidence, cache, runtime, Git, socket, and temporary paths;
- allocation-bound device/inode observations;
- corrected successor runner/comparator/analyzer hashes;
- current producer and peer binary paths;
- fresh mutant constructor path/hash;
- fresh Repair 9 provenance copy paths;
- complete suite-spec SHA-256 values;
- current logical fingerprints;
- current suite, qualification, policy, semantic, and custody output identities.

A fresh A6 cannot manufacture those choices itself.

## 9. Historical comparator contract

### Current implemented behavior

`repair10-compare` currently accepts:
```
repair10-compare -spec ABSOLUTE_SPEC -output ABSENT_ABSOLUTE_OUTPUT
repair10-compare bytes -spec ABSOLUTE_SPEC -output ABSENT_ABSOLUTE_OUTPUT
```

It exclusively creates a mode-`0600` result, prints the same JSON to stdout, and exits:

- `0` for accepted qualified equality;
- `2` for a qualified difference with both sides qualified and no unknowns;
- `1` otherwise.

See [repair10-compare/main.go (line 14)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/cmd/repair10-compare/main.go:14) and [semantic.go (line 1884)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/semantic.go:1884).

The v6 comparison spec fields are:
```
schema, name, policy, left, right,
mutant_side,
expected_mutant_diagnostic,
expected_mutant_source_identity,
expected_mutant_lifecycle_transitions
```

Each side binds control ID, source class and source binding, suite result, qualification, semantic envelope, and raw stream by path, size, and hash. See [semantic.go (line 109)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/semantic.go:109).

The current result preserves factual equality, difference, qualification, unknown, fingerprint, source, overlay, and nonclaim fields. See [semantic.go (line 153)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/envelope/semantic.go:153).

### Exact answer on absence

The historical comparator is:

- **not absent source:** a partial baseline helper exists;
- **absent complete wiring:** no qualified historical specs/results/custody/acceptance chain was instantiated;
- **schema incomplete:** active v6 has no explicit direction or complete custody producer;
- **acceptance policy unresolved:** current Go and retained analyzer disagree.

### Direction and policy conflicts

Required directions are exactly:
```
historical-head → pristine-final
historical-repair9 → pristine-final
```

They remain separate; their transition sets may not be unioned. See [FORMAT.md (line 681)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/tool/source/FORMAT.md:681).

Conflicts:

1. Current Go admits one hardcoded final-only pass; retained analyzer admits arbitrary qualified `absent→pass`.
2. Current Go requires equal aggregate suite exits; retained policy says aggregate equality is not the transition decision.
3. Active v6 has implicit left/right direction; older future-v6 draft required explicit baseline/final fields.
4. Current v6 custody ID has no producer or field implementation.
5. The result of factual comparison and the result of historical acceptance are not separated in a governed contract.

### Recommended successor

Advance the comparison chain to v7 and add:
```
historical_direction? {
  baseline_side
  final_side
  baseline_source_class
  final_source_class
  policy_id
  overlay_requirement
}
```

For historical policies:
```
baseline_side = "left"
final_side = "right"
final_source_class = "pristine-final"
```

The pairwise comparator should emit factual v7 results only. A separate historical adjudication record should bind the factual result, analyzer result, custody, qualification recomputation, overlay result, unknown count, late faults, reason codes, and final acceptance.

Unknown differences or late qualification, EOF, terminal, resource, alias, custody, overlay, or source faults preserve factual fields but force acceptance false and exit 1.

## 10. Transition analyzer contract

### Retained v1 behavior

The retained analyzer emits:
```
execution-substrate.repair10i-a6.historical-transition-analysis.v1
```

Its output fields are:
```
schema
direction
baseline_source_class
baseline_exit_code
final_exit_code
baseline_identity
final_identity
test_transition_sets
package_transition_sets
package_failure_classifications
final_only_passing_tests
final_only_passing_packages
integrity_deltas
hazardous_diagnostic_class_deltas
overlay_accounting
read_policy_qualification_references
policy_adjudication
canonicalization
```

It covers all 15 nonempty transitions over `absent`, `pass`, `fail`, and `skip`. See [transition analyzer:21 (line 21)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a6r-8de797304ea9/commands/repair10i_a6_transition_analyzer_v1.py:21).

Current CLI:
```
--baseline
--final
--baseline-raw
--final-raw
--baseline-source-class historical-head|historical-repair9
--baseline-identity
--final-identity
[--overlay-recipe]
--baseline-qualification
--final-qualification
--output
```

It writes canonical mode-`0600` JSON and currently exits 0 whenever analysis production succeeds, even if policy rejects.

### Required successor behavior

The transition matrix model is reusable. Its qualification, custody, overlay, and late-fault model needs redesign.

A v2 successor must add exact bindings for:
```
analysis_name
policy_id
baseline_side
final_side
comparison_spec_identity
comparison_result_identity
comparison_custody_identity
analyzer_identity
baseline_suite_result_identity
final_suite_result_identity
baseline_qualification_identity
final_qualification_identity
baseline_qualification_recomputed
final_qualification_recomputed
baseline_semantic_identity
final_semantic_identity
baseline_raw_identity_and_eof
final_raw_identity_and_eof
physical_controls_disjoint
overlay_provenance_identity
overlay_qualification_recomputed
effective_read_policy_v3_references
terminal_and_resource_custody_clean
late_faults
reason_codes
outcome
```

It must independently verify current qualification and v3 policy evidence, reject reversed direction, and retain factual matrices when later acceptance fails.

Recommended exit contract:

- analyzer exit `0`: valid analysis record produced;
- analyzer exit `1`: input/custody/qualification failure and no valid analysis;
- adjudication exit `0`: accepted historical no-regression;
- adjudication exit `1`: rejected or unqualified.

The JSON adjudication remains authoritative; suite aggregate exit cannot substitute for transition analysis.

## 11. Comparator/analyzer source and build ownership

- `repair10-semantic` remains the semantic-envelope producer.
- `repair10-compare` owns pairwise factual comparison and independent control qualification recomputation.
- A separate transition analyzer owns directional matrices and historical policy.
- The analyzer may also produce a distinct adjudication output, but that output must remain separate from the factual comparison result.
- The future A6 orchestrator owns specs and custody records; tools write only their declared absent result paths.
- EV and the caller own none of these semantics.

The sealed A6D lineage can be evolved only by copying it into a new audited source-external package. A6D itself remains unchanged.

Minimum successor source surfaces:
```
source/FORMAT.md
source/envelope/runner.go
source/envelope/semantic.go
source/envelope/transition.go                 # new
source/envelope/envelope_test.go
source/cmd/repair10-transition/main.go        # new
```

Existing mains for runner, fixture, semantic, and comparator may remain structurally unchanged.

Required outputs are two physically disjoint A/B sets of:
```
repair10-runner
repair10-fixture
repair10-semantic
repair10-compare
repair10-transition
```

A and B must be byte-identical by filename, inode-distinct, regular, single-link, and mode `0700`.

## 12. Fresh-child allocation contract

No current authoritative allocator exists. The following is the parent’s exact repair recommendation and must be adopted verbatim in governance before use.

### Name
```
Parent:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1

Prefix:
  phase-i-a6-policy-evidence-v7-

Suffix:
  exactly 32 lowercase hexadecimal characters from 16 CSPRNG bytes

Complete basename:
  phase-i-a6-policy-evidence-v7-<32-lowercase-hex>
```

### Allocation algorithm

1. Set `umask(0077)`.
2. Open the exact evidence parent component by component without following links.
3. Capture and hold its directory descriptor and physical identity.
4. Generate 16 bytes using the operating system CSPRNG and lowercase-hex encode them.
5. Use descriptor-relative exclusive `mkdirat(..., 0700)`.
6. On `EEXIST`, generate another token. Permit at most 128 attempts.
7. On any other error, stop.
8. Open the created child without following links and retain its descriptor.
9. Require direct parentage, directory type, invoking UID ownership, expected parent GID, mode `0700`, stable device/inode, and no pre-existence or rename.
10. Record the successful attempt. Never scan for “latest,” select by prefix, reuse, rename, or adopt an existing entry.

### Allocation record

Recommended schema:
```
execution-substrate.repair10i-a6.child-allocation.v1
```

Closed fields:
```
schema
allocator
evidence_parent
prefix
suffix
attempt_ordinal
child
creation
candidate_source
lineage
prior_child_dispositions
authority
```

Consumers receive the exact allocation record and its SHA-256 directly. The pathname is a locator; device/inode, direct parentage, lineage, and record identity carry authority.

### Separation requirements

The child must be physically distinct from:

- tool packages;
- candidate repository;
- caller output;
- `TMPDIR`;
- all control roots;
- caches;
- runtime roots;
- private Git stores;
- sockets;
- materialized sources;
- manifest candidate;
- verifier and caller packages.

## 13. Orchestration and closeout ownership model

### Sole writer

One source-external orchestrator owns:

- allocation;
- child namespaces;
- command progression;
- control completion;
- peer qualification completion;
- comparison completion;
- analysis completion;
- closeout adjudication;
- cleanup recording;
- detached digest installation;
- manifest installation.

Runners, comparator, analyzer, verifier, caller, and auditor cannot advance orchestration state.

### Records

Recommended opening capsule fields:
```
schema
authority_class
allocation
child
candidate
lineage
evidence_verification
semantic_toolchain
plan
private_boundaries
writer
opened_at_report_only
```

Recommended final orchestration record fields:
```
schema
orchestration_id
writer
allocation
opening_capsule
outcome
first_blocker
late_faults
events
controls
peer_qualifications
comparisons
historical_analyses
command_index
failed_attempt_index
closeout_adjudication
cleanup
closing_gate
final_report
seal_plan
```

Every event contains:
```
ordinal
kind
id
prerequisite_ordinals
input_refs
expected_exit
actual_exit
status
output_refs
command_ref
blocker_codes
```

There is no mutable “current state” file. After an interruption, the child becomes failed or superseded and may only be inspected. It cannot be resumed. This resolves the explorer disagreement in favor of the prompt’s no-resume rule.

### Serial progression

1. Reverify all opening identities.
2. Allocate one fresh child.
3. Create the ten structural directories.
4. Write allocation and opening records.
5. Bind the audited toolchain and five exact specs.
6. Materialize the five source roots.
7. Execute and peer-qualify final.
8. Execute and peer-qualify fresh.
9. Compare final/fresh; require accepted equality and exit 0.
10. Execute and peer-qualify mutant.
11. Compare final/mutant and mutant/fresh; require qualified differences and exit 2.
12. Execute and peer-qualify historical HEAD.
13. Execute and peer-qualify historical Repair 9.
14. Recompute all-five physical isolation.
15. Produce factual HEAD/final and Repair 9/final comparisons.
16. Run each directional transition analysis twice and require identical output.
17. Produce historical adjudications.
18. Produce closeout adjudication.
19. Clean private roots and record two fresh absence epochs.
20. Produce closing gate, command audit, indexes, orchestration record, and final report.
21. Create the manifest candidate outside the child.
22. Run pre-seal structural verification through the caller.
23. Install detached digest.
24. Install manifest as the final child mutation.
25. Run sealed structural verification into a fresh external bundle.
26. Perform independent semantic and provenance audit.

Only independent opening reads and physically disjoint A/B work may run concurrently.

## 14. Structural Evidence Verification and caller integration

The registered layout requires exactly these top-level directories:
```
analysis/
closeout/
commands/
comparisons/
controls/
findings/
opening/
sources/
tool/
validation/
```

Required landmarks are:
```
opening/opening-capsule-v1.json
closeout/cleanup-v1.json
closeout/closing-gate-v1.json
closeout/command-root-audit-v1.json
closeout/final-report-v1.md
```

The exact registered layout is [a6\_policy\_v1.json (line 1)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/tools/evidence_verify/layouts/a6_policy_v1.json:1>).

Integration rules:

- verifier package, target, manifest candidate, caller output, interpreter, and private roots remain physically separate;
- pre-seal requires both manifest and detached digest absent;
- install detached digest before manifest;
- manifest installation is the final target mutation;
- sealed verification is read-only;
- every caller attempt uses a new absent external bundle;
- caller bundles contain exactly JSON, stdout, and stderr;
- structural success does not imply semantic acceptance, readiness, product correctness, or commit fitness.

No EV commit or caller change belongs in the successor work.

## 15. Exact implementation tranche decomposition

### Tranche A — Governance repair

- **Objective:** Resolve the candidate v1 versus successor dialect conflict and freeze direction, policy, allocation, ownership, and nonauthority.
- **Owner/root:** Candidate repository.
- **Touched files:** Exact repository paths in §16.
- **New files:** None recommended.
- **Tests:** No product tests; perform strict cross-document schema/ownership consistency review.
- **Build:** None.
- **Validation:** Confirm one dialect map, both historical directions, no product/public schema widening, and no EV readiness semantics.
- **Provenance:** Dedicated documentation commit with exact tree and inventory.
- **Independent audit:** Required before successor code is accepted.
- **Stop:** Any unresolved policy or version choice.
- **Dependency:** None.

### Tranche B — Current semantic successor

- **Objective:** Correct the fingerprint, establish successor dialect, implement factual historical direction/custody, transition analysis, and adjudication.
- **Owner/root:** New source-external audited semantic package.
- **Touched/new files:** Exact package paths in §17.
- **Tests:** Strict decoder, fingerprint equality, 15 transition classes, direction reversal, overlay, unknown, late-fault, custody, mixed-dialect, and exit causals.
- **Build:** Two private A/B builds of five binaries.
- **Validation:** Byte-equal A/B outputs, inode distinction, full predecessor causal matrix plus new causals.
- **Provenance:** Complete source inventory, pure tree identity, toolchain/argv/environment bindings.
- **Independent audit:** Required.
- **Seal:** Package must be sealed or otherwise immutable and exact-byte accepted.
- **Stop:** Any divergence, schema collision, or unbound binary.
- **Dependency:** Tranche A.

### Tranche C — Allocator and orchestration successor

- **Objective:** Implement exclusive allocation, sole-writer progression, closeout, cleanup, and sealing choreography.
- **Owner/root:** Separate source-external orchestration package.
- **Touched/new files:** Exact package paths in §17.
- **Tests:** Collision, alias, wrong type/mode/owner, crash, no-resume, progression gaps, multiple writer, cleanup, two epochs, and final-manifest causals.
- **Build:** No compiled product build required if retained as pinned isolated Python; package source itself is the executable artifact.
- **Validation:** Two physically independent package copies and deterministic record bytes.
- **Provenance:** Exact source inventory and interpreter identity.
- **Independent audit:** Required.
- **Seal:** Immutable accepted package before allocation.
- **Stop:** Any prefix ambiguity, scan-based discovery, resumability, or overlapping writer.
- **Dependency:** Tranches A and B.

### Tranche D — Pre-A6 independent qualification

- **Objective:** Accept exact candidate governance commit and exact semantic/orchestration package bytes.
- **Owner/root:** Independent source-external audit.
- **Inputs:** Tranches A–C.
- **Outputs:** Sealed qualification package binding docs commit, source inventories, A/B binaries, schemas, causals, and allocator/orchestrator bytes.
- **Tests/builds:** Reproduce A/B builds and causals from fresh private roots.
- **Stop:** Any unreproduced hash, hidden dependency, source import, or authority widening.

### Tranche E — Fresh A6

Allocate one new child and execute the five controls and five comparisons from the beginning. Existing children remain untouched.

### Tranche F — Independent A6 audit

Recompute semantic acceptance, provenance, qualification, layout, seal order, and nonauthority from retained bytes. EV success alone is insufficient.

No tranche mutates both candidate product source and an unrelated repository.

## 16. Exact touched repository paths

Only candidate governance documents should change:

- [PLANS.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/PLANS.md>)
- [.docs/system\_overview/configuration.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/configuration.md>)
- [.docs/system\_overview/boundaries.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/boundaries.md>)
- [.docs/system\_overview/artifact\_hygiene.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/artifact_hygiene.md>)
- [.docs/system\_overview/capability\_probing.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/capability_probing.md>)
- [.docs/system\_overview/remote\_alpha\_external\_tls\_status\_deployment\_v1.md](</Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1/.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md>)

No candidate Go product source, public schema, module graph, production command, or runtime path should change.

The EV repository and caller have an empty touched-file set.

## 17. Exact source-external files and proposed root structure

### Semantic successor package
```
ES-repair10i-a6-semantic-v7-<source-tree-12>-<32hex>/
  source/
    FORMAT.md
    go.mod
    envelope/
      runner.go
      semantic.go
      transition.go
      envelope_test.go
    cmd/
      repair10-runner/main.go
      repair10-fixture/main.go
      repair10-semantic/main.go
      repair10-compare/main.go
      repair10-transition/main.go
  schemas/
    suite-spec-v7.schema.json
    suite-result-v7.schema.json
    control-qualification-v7.schema.json
    semantic-comparison-spec-v7.schema.json
    semantic-comparison-result-v7.schema.json
    semantic-comparison-custody-v7.schema.json
    historical-transition-analysis-v2.schema.json
    historical-comparison-adjudication-v1.schema.json
  fixtures/
    transitions/
    direction/
    overlay/
    unknown/
    late-fault/
    custody/
    mixed-dialect/
  validation/
    source-inventory-v1.txt
    ab-build-record-v1.json
    causal-matrix-v1.json
    qualification-v1.json
  bin/
    side-a/
    side-b/
```

Changed source files are `FORMAT.md`, `envelope/runner.go`, `envelope/semantic.go`, and `envelope/envelope_test.go`. `envelope/transition.go`, `cmd/repair10-transition/main.go`, schemas, and fixtures are new.

### Orchestration package
```
ES-repair10i-a6-orchestration-v1-<source-sha12>-<32hex>/
  source/
    FORMAT.md
    repair10i_a6_contract_v1.py
    repair10i_a6_orchestrate_v1.py
  schemas/
    child-allocation-v1.schema.json
    opening-capsule-v1.schema.json
    orchestration-record-v1.schema.json
    closeout-adjudication-v1.schema.json
    cleanup-v1.schema.json
    command-index-v1.schema.json
    failed-and-superseded-attempt-index-v1.schema.json
    closing-gate-v1.schema.json
    command-root-audit-v1.schema.json
  tests/
    test_allocator_v1.py
    test_orchestration_state_v1.py
    test_crash_no_resume_v1.py
    test_closeout_and_seal_v1.py
    fixtures/
  validation/
    source-inventory-v1.txt
    causal-matrix-v1.json
    qualification-v1.json
```

These roots and their hashes do not exist yet; they must be allocated and qualified outside the candidate, evidence target, EV package, caller output, and private control roots.

## 18. Validation and causal matrix

| GateRequired evidence |                                                                                                    |
| --------------------- | -------------------------------------------------------------------------------------------------- |
| Strict schemas        | Unknown/trailing fields reject; current versions exact; mixed generations reject                   |
| Fingerprint           | Fingerprint policy list equals extractor canonicalization list exactly; v2→v1 mutation fails       |
| Five specs            | Exact IDs, command order, exits, PTY counts, source identities, peer sides, retention              |
| Final/fresh           | Same logical fingerprint, distinct complete spec digest and physical roots                         |
| Mutant                | Exactly one file delta; both mutant comparisons produce the exact qualified difference             |
| Repair 9              | Exact base/effective tuple, recipe, one path, no product/improvement credit                        |
| Historical direction  | Reversed sides reject before analysis                                                              |
| Transition matrices   | All 15 test and package transitions represented deterministically                                  |
| New passes            | Governing policy must explicitly decide arbitrary qualified `absent→pass`                          |
| Aggregate exits       | Governing policy must explicitly decide whether equality is required                               |
| Unknowns              | Any unknown blocks acceptance and remains visible factually                                        |
| Late faults           | EOF, qualification, alias, terminal, resource, custody, source, or overlay fault clears acceptance |
| Comparator custody    | Exact spec/result/binary/argv/environment/input/output/exit bindings                               |
| Peer qualification    | Opposite side independently recomputes each control                                                |
| A/B builds            | Byte-identical binaries, inode-distinct, regular single-link, mode `0700`                          |
| Analyzer determinism  | Two runs per direction per side; outputs byte-identical                                            |
| Allocator             | Collision, symlink, wrong type/mode/owner, rename/replacement, retry bound                         |
| Orchestrator          | Missing/duplicate/out-of-order event, second writer, crash, no-resume                              |
| Cleanup               | No survivors plus two genuinely fresh absence epochs                                               |
| Sealing               | Pre-seal absence, sidecar before manifest, manifest final, no later target writes                  |
| Structural closure    | EV pre-seal and sealed checks through separate caller bundles                                      |
| Independent audit     | Fresh reconstruction without producer imports or mutable state reuse                               |

The predecessor 46-case A/B causal matrix is recorded at [future-causal-matrix-v1.json (line 2)](/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6d-device-security-successor-closure-8de797304ea9/controls/future-causal-matrix-v1.json:2) and must be rerun against successor bytes.

## 19. Provenance and independent-audit plan

1. Commit the corrected candidate governance documents.
2. Record candidate commit, tree, source T, inventory, and membership.
3. Inventory every semantic successor source byte and compute a pure tree identity.
4. Build A/B binaries in disjoint private roots with bound compiler, SDK, Go root, argv, environment, caches, and outputs.
5. Record exact binary hashes, sizes, modes, links, devices, and inodes.
6. Run the bounded successor causal matrix independently on A and B.
7. Inventory and qualify the orchestration package under pinned isolated Python.
8. Independently reproduce allocator/orchestrator causals from another physical copy.
9. Seal an external qualification package binding candidate docs, schemas, source, binaries, tests, fixtures, and results.
10. Require independent acceptance of that package before child allocation.
11. Bind the accepted package identities in the child opening capsule.
12. Preserve per-control source and construction provenance.
13. Preserve producer and peer qualification independently.
14. Preserve factual comparison even if later analysis rejects.
15. Preserve cleanup, closeout, seal order, caller outputs, and structural records.
16. After sealing, independently recompute semantic and provenance acceptance from retained bytes.

## 20. Compatibility and migration treatment

- v5/v2 records remain immutable parse/report-only evidence.
- A6D v6/v3 records remain immutable evidence of implemented behavior and identified defects.
- If v7 is adopted, v6 comparison and suite records become retained predecessor evidence; they are not rewritten.
- Command v3 and PTY v2 advance only if their own semantics change.
- Existing mutant and overlay v1 provenance formats may remain v1 when newly instantiated records bind current constructors and paths.
- Analyzer v1 remains available for historical inspection but cannot qualify current A6.
- No adapter may alter a schema caption, insert missing qualification, or convert an old result into current acceptance.
- Every old/new mixture fails closed.

## 21. Security, authority, and sensitive-material boundaries

- Evidence children and private roots are mode `0700`.
- Payloads are mode `0600`; only enumerated executables are `0700`.
- Symlinks, unexpected hardlinks, devices, FIFOs, sockets, special files, wrong modes, and unexpected paths fail closure.
- Raw command streams and semantic envelopes remain private evidence.
- Mutable HOME, caches, temp, runtime, Git, socket, probe, and process state stay outside the candidate, packages, and evidence child.
- Verifier projection must not expose absolute paths, payload contents, timestamps, hostnames, usernames, credentials, or readiness captions. See [evidence\_verification.md (line 252)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:252>).
- Repair 9 overlay bytes never become historical product source or product-improvement evidence.
- Harness schemas and records do not become public/product schemas.
- The orchestrator has evidence-instance authority only.
- EV has structural byte/layout authority only.
- The caller has launch/custody/publication authority only.
- Neither tool grants runtime, deployment, installation, route, credential, admission, readiness, handback, or commit authority.
- The trusted-host model does not cover hostile privileged replacement, kernel compromise, debugger compromise, or process-memory compromise. See [evidence\_verification.md (line 120)](</Users/ds/Repositories/Execution Substrate - evidence-verification-v1/.docs/system_overview/evidence_verification.md:120>).

## 22. Preserved explorer disagreements and parent resolution

| DisagreementParent resolution                                                                              |                                                                                                                                                                                  |
| ---------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Explorer 1 viewed the implementation as substantially present; Explorers 2 and 4 found acceptance blockers | Current reconnaissance is blocked because exact acceptance semantics and byte-exact specs do not exist.                                                                          |
| Keep v6 with separate adjudication versus advance the comparison chain                                     | Recommend v7 because fingerprint and historical acceptance semantics change; governance must adopt it.                                                                           |
| Allocator prefix included source T versus dialect version                                                  | Recommend fixed `phase-i-a6-policy-evidence-v7-` plus 128-bit random suffix.                                                                                                     |
| Collision retry bound 32 versus 128                                                                        | Recommend 128 attempts, then fail without fallback.                                                                                                                              |
| Embed allocation in opening capsule versus separate record                                                 | Use a separate allocation record referenced by the opening capsule.                                                                                                              |
| Immutable final orchestration record versus resumable contiguous phase records                             | Write immutable phase evidence during one live run and a final record; after interruption, never resume the child.                                                               |
| Python analyzer successor versus compiled Go successor                                                     | Recommend a distinct Go `repair10-transition` binary in the copied envelope lineage to share strict current qualification structures while retaining a separate output contract. |
| One result versus factual and acceptance separation                                                        | Keep factual comparison result and historical adjudication as distinct records.                                                                                                  |

## 23. Stop conditions

Stop before implementation or fresh A6 on any of these conditions:

- any opening identity changes;
- any mutation of A6D, amendment, A6V, or an existing A6 child;
- candidate governing docs remain inconsistent with the successor dialect;
- the v1/v2 fingerprint mismatch remains;
- v6 is silently redefined;
- historical direction, new-pass policy, aggregate-exit policy, or acceptance exits remain undecided;
- a v5/v2 record is promoted or mixed into a current chain;
- successor source, schema, binary, or package identity is absent;
- independent package audit is absent;
- any existing child is reused, resumed, renamed, deleted, or sealed;
- allocation depends on scanning, “latest,” timestamp, PID, or pathname-only authority;
- allocation collision adopts an existing entry;
- physical roots alias or violate separation;
- more than one writer owns mutable progression;
- an output path is overwritten or nonexclusively created;
- any control or peer qualification fails;
- unknown differences, final-only regressions, overlay faults, or late faults occur;
- cleanup cannot prove no survivors and two fresh absence epochs;
- pre-seal verification fails;
- detached digest cannot precede the manifest;
- manifest cannot be the final target mutation;
- sensitive material would leave private roots;
- structural verification is treated as semantic readiness.

## 24. Remaining ambiguity

The following are unresolved current-authority questions, rather than implementation details:

1. Formal adoption of the recommended v7 successor.
2. Whether arbitrary qualified `absent→pass` is admitted.
3. Whether historical baseline/final aggregate exits must match.
4. The authoritative split between comparison v7 facts, transition analysis v2, and adjudication v1.
5. The exact adopted allocator, opening, orchestration, closeout, index, and cleanup schema IDs.
6. The exact successor package hashes and binary identities.
7. The five allocation-bound complete suite specifications and their digests.
8. Fresh host capability and tool-path identities.
9. Fresh physical identities and custody paths.

The report supplies a bounded repair recommendation for each, but an inline reconnaissance report cannot replace the repository’s required docs-first governing decision.

## 25. Uninspected scope

- No unrelated repository sibling or unrelated Downloads subtree was traversed.
- No live service, network endpoint, remote repository, package registry, or credential store was inspected.
- No retained binary was executed or disassembled.
- No product test suite or current control was executed.
- No future successor source, package, binary, schema file, or A6 child exists to inspect.
- Product bytes were checked through the supplied inventory and source-tree reconstruction; their runtime behavior was not re-executed.
- EV semantic-readiness behavior was not inspected because the verifier intentionally has none.

## 26. Explicit confirmations

- No file was created.
- No file was modified.
- No file was deleted.
- No file mode was changed.
- No test, build, control, comparator, analyzer, verifier, or caller was run.
- No A6 child was created or resumed.
- No evidence root was allocated.
- No staging, commit, reset, amend, revert, push, PR, merge, or upstream creation occurred.
- No product or live service was invoked.
- No network contact occurred.
- No nested subagent was spawned.
