## Assessment

`AUDIT_PROVENANCE_MISMATCH` is the correct verdict. The audit stopped before process-package materialization, target inspection, or V3 correctness work, so it provides **no negative evidence about the V3 audit-repair capsule**.

This failure is materially different from the earlier launcher-process failures:

- The qualified launcher package’s root counts matched.
- Both manifest files matched their pinned size, digest, and byte equality.
- Pinned Python passed.
- The failure was in the bootstrap’s **interpretation of manifest content** and its inability to assign unambiguous roles to some auxiliary identity records.

The qualified launcher report claims that two independent generators reproduced the manifest pair exactly, with 73 represented entries, exactly two manifest exclusions, and no empty, linked, symlink, special, or mode-invalid objects.  The fresh bootstrap agreeing on counts and manifest identities but failing the row comparison creates a precise unresolved conflict: either the bootstrap implemented the wrong manifest semantics, or the package’s retained manifest/projection claims do not hold under fresh reconstruction.

The “auxiliary identity-record roles” issue also exposes an import-interface gap. Our last full-audit prompt said to copy the exact source-identity records required by the launcher but did not freeze:

- their exact relative paths;
- which ones must be copied byte-for-byte;
- which ones must be regenerated after root rebinding;
- their creation order;
- which launch-contract fields reference them;
- whether they are package-internal evidence or exported consumer inputs.

Another full V3 audit would be premature. The narrow next step is a **read-only package import-interface reconciliation**. It should determine the exact row-level manifest mismatch and produce a closed consumer import map. It must not modify the qualified package or inspect the V3 targets.

## Codex prompt

```text
READ-ONLY QUALIFIED LAUNCHER-PACKAGE
MANIFEST AND IMPORT-INTERFACE RECONCILIATION

This is a bounded, parent-only, read-only reconciliation.

Do not repair anything.
Do not mutate any supplied root.
Do not resume or clean the failed audit root.
Do not execute the launcher or wrapper.
Do not run the full V3 audit.
Do not inspect the candidate repository, Strategic B, blocked V1, V2, V2
audit, V3 predecessor, V3 audit-repair target, product source, or any
unrelated evidence root.
Do not run Git.
Do not run repository tests or product code.
Do not use the network.
Do not create subagents.

Return exactly one primary verdict:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT
LAUNCHER_IMPORT_REQUIRES_INTERFACE_ADDENDUM
LAUNCHER_PACKAGE_REPAIR_REQUIRED
RECONCILIATION_PROVENANCE_MISMATCH

OBJECTIVE

Reconcile two precise issues from the failed full-audit bootstrap:

1. The qualified package’s manifest identities and represented-entry counts
   matched, but the bootstrap’s manifest-content comparison failed.
2. The bootstrap could not resolve the roles of auxiliary identity records
   needed to materialize a root-rebound launcher instance.

Determine conclusively:

- the exact manifest grammar and ordering;
- whether the supplied manifests reproduce from the immutable package;
- the exact first row or field mismatch in the failed bootstrap;
- whether that mismatch is a package defect or a bootstrap-checker defect;
- every launcher-package artifact exported to a consumer;
- every package-internal artifact not exported;
- which exported artifacts are copied byte-for-byte;
- which records must be freshly generated after root rebinding;
- exact creation and dependency order;
- exact launch-contract fields that reference generated identity records;
- whether the package contains enough information for an unambiguous import
  without another package repair.

Do not use the package producer report as the oracle. Adjudicate from retained
bytes and source.

──────────────────────────────────────────────────────────────────────────────
1. EXACT INPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700

Expected primary verdict:

WRAPPED_CARRIER_LAUNCHER_READY

Expected launcher-package fixed identities:

Accepted wrapper:

- size:
  15300
- SHA-256:
  6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Qualified launcher:

- size:
  16603
- SHA-256:
  12e4c0bd37581c7c9634133fd5cb0c30f9db4871f13f8f6825a1efed1f51fd9e

CLI contract:

- size:
  6937
- SHA-256:
  be46e39be6b72c2a49ca510807d6aa346a477fe13dad0911bc1965c389f1695f

Request contract:

- size:
  1606
- SHA-256:
  bdd167b775281418364b362270dbba366a2f4f4c6dc8257ce1a3e829834a3790

Qualification-root launch contract:

- size:
  2260
- SHA-256:
  b9ac95c264d88d0a0cd76f17c7089b65229bed9c4eb65ea949ef4f745c5e57d1

Manifest A and Manifest B:

- size:
  12404 each
- SHA-256:
  a81be4da4d3c767e0e1c1b98db8e7ccf4403977e2b1ef66d21263adbcd1acebb
- expected:
  byte-identical

Expected manifest projection:

- 73 represented entries;
- 9 represented directories including root;
- 64 represented nonmanifest regular files;
- exactly two self-exclusions:
  the two manifest files;
- 66 physical regular files including manifests;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

FAILED_BOOTSTRAP_AUDIT_ROOT:

/Users/ds/Downloads/ES-validation-custody-v3-audit-repair-independent-audit-glydyhph

Treat this root as immutable, nonqualifying bootstrap-failure evidence.

Inspect only:

- bootstrap-start and bootstrap-outcome records;
- bootstrap payload/program source;
- manifest-comparison source and records;
- package-inventory observations;
- auxiliary-role observations;
- any retained stream or exception evidence needed to identify the failure.

Do not resume, clean, repair, or adopt that root.

ACCEPTED_GENERIC_WRAPPER_ROOT:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Inspect only when needed to verify an exported wrapper or CLI role. Do not
requalify the wrapper capability.

──────────────────────────────────────────────────────────────────────────────
2. FRESH RECONCILIATION ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-launcher-package-import-reconciliation-

Recommended retained structure:

opening/
manifest/
interface/
analysis/
provenance/
closeout/

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No empty retained directory, symlink, special object, or multiply linked file
is permitted.

──────────────────────────────────────────────────────────────────────────────
3. OPENING PROVENANCE
──────────────────────────────────────────────────────────────────────────────

Before interpretation:

1. Capture a complete lstat/no-follow inventory of the qualified package.
2. Capture a bounded complete inventory of the failed bootstrap root.
3. Verify every fixed package identity above.
4. Verify the failed bootstrap outcome identity and failure disposition.
5. Record every expected package object that is missing.
6. Record every package object not represented by the supplied manifests.
7. Retain source identities for:
   - both package manifest generators;
   - the failed bootstrap manifest checker;
   - any import/materialization helper used by the failed bootstrap.

Stop with RECONCILIATION_PROVENANCE_MISMATCH on:

- supplied-root opening drift;
- manifest-file identity mismatch;
- missing indispensable bootstrap failure evidence;
- closing supplied-root inequality.

The incomplete failed audit root is not itself a mismatch.

──────────────────────────────────────────────────────────────────────────────
4. EXACT MANIFEST GRAMMAR
──────────────────────────────────────────────────────────────────────────────

Inspect both qualified-package manifest generators completely.

Derive and retain:

manifest/qualified-package-manifest-contract-v1.json

It must state exactly:

- file format;
- root representation;
- relative-path encoding;
- path ordering;
- type vocabulary;
- directory fields;
- regular-file fields;
- mode encoding;
- whether link count is represented;
- whether size is represented;
- whether SHA-256 is represented;
- treatment of root;
- treatment of manifests;
- exact self-exclusions;
- terminal newline/encoding;
- duplicate-path handling;
- invalid UTF-8 handling;
- symlink handling;
- special-object handling;
- hardlink handling;
- empty-directory handling;
- volatile-field exclusions.

Do not infer semantics from the producer report when source is available.

Require the two generator implementations to implement the same grammar.

──────────────────────────────────────────────────────────────────────────────
5. INDEPENDENT MANIFEST REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Build two audit-owned independent reproducers:

- one Python implementation;
- one implementation in a different available language or a separately
  structured Python implementation sharing no traversal/parser helper.

Neither may import the producer generators.

Both must:

- enumerate the immutable qualified package with lstat/no-follow semantics;
- apply the derived grammar exactly;
- produce a complete candidate manifest in memory or beneath the
  reconciliation root;
- compare byte-for-byte with both supplied manifests.

Retain:

- each reproducer source and identity;
- each reproduced manifest;
- exact byte comparison;
- per-row comparison;
- membership comparison;
- ordering comparison;
- field comparison.

If reproduction differs, report:

- first differing row;
- first differing field;
- exact expected value;
- exact observed value;
- all additional or missing rows;
- whether the cause is package content, producer-generator semantics, or audit
  reproducer error.

Do not classify the package as defective merely because a different,
unauthorized grammar produces different bytes.

──────────────────────────────────────────────────────────────────────────────
6. FAILED BOOTSTRAP CHECKER RECONSTRUCTION
──────────────────────────────────────────────────────────────────────────────

Inspect the failed bootstrap’s exact manifest checker.

Reconstruct:

- the input files it read;
- expected schema;
- generated schema;
- ordering rule;
- self-exclusion rule;
- represented fields;
- comparison algorithm;
- root handling;
- directory handling;
- manifest-file handling;
- exact first failed assertion;
- exact expected and observed values;
- exception or failure code.

Retain:

analysis/bootstrap-manifest-failure.json

Classify the causal as exactly one of:

- wrong row ordering;
- wrong root representation;
- wrong self-exclusion treatment;
- wrong field set;
- wrong mode encoding;
- wrong directory treatment;
- wrong link/size treatment;
- stale expected identity;
- package content mismatch;
- producer manifest defect;
- another specifically identified mechanism.

Do not report merely “manifest content mismatch.”

──────────────────────────────────────────────────────────────────────────────
7. PACKAGE ARTIFACT AND ROLE LEDGER
──────────────────────────────────────────────────────────────────────────────

Enumerate every qualified-package object.

Create:

interface/complete-package-role-ledger.json

For every path include:

- relative path;
- type;
- size;
- SHA-256 where regular;
- mode;
- role;
- authority class;
- producer;
- consumer;
- exported to a future audit:
  true/false;
- copied byte-for-byte:
  true/false;
- regenerated after root rebinding:
  true/false;
- retained only as qualification evidence:
  true/false;
- required at audit bootstrap:
  true/false;
- required after bootstrap:
  true/false;
- dependencies;
- dependents;
- root-bound:
  true/false;
- reason.

Use closed role values, including at least:

- wrapper-source;
- launcher-source;
- phase-runner-cli-contract;
- carrier-request-contract;
- environment-observation-policy;
- qualification-root-launch-contract-instance;
- launcher-identity-record;
- fixed-environment-record;
- root-rebinding-record;
- source-identity-record;
- qualification-payload;
- qualification-result;
- qualification-phase-record;
- qualification-validator;
- qualification-closeout;
- qualification-final-inventory;
- qualification-manifest;
- internal-evidence-only.

Do not collapse records with different lifecycle roles merely because they
contain similar identities.

──────────────────────────────────────────────────────────────────────────────
8. EXPORTED CONSUMER INTERFACE
──────────────────────────────────────────────────────────────────────────────

Derive a proposed closed consumer interface:

interface/qualified-launcher-consumer-import-contract-v1.json

It must identify exact exported inputs by:

- source root;
- relative path;
- size;
- SHA-256;
- mode;
- type;
- role.

At minimum adjudicate these roles explicitly:

A. Copy byte-for-byte into a fresh audit root:

- accepted wrapper source;
- qualified launcher source;
- phase-runner CLI contract;
- carrier-request contract;
- environment-observation policy;
- any root-independent source-identity contract required by the launcher.

B. Do not copy as current audit process inputs:

- qualification payloads;
- qualification results;
- qualification phase records;
- qualification closeout payload;
- qualification carrier index;
- qualification final inventory;
- qualification manifests;
- failed/superseded attempt records, except as historical evidence.

C. Regenerate after fresh-root materialization:

- copied-launcher identity record;
- fresh fixed-environment record;
- fresh root-bound launch-contract instance;
- fresh launch-contract root-rebinding proof;
- fresh audit payload identities;
- per-carrier requests;
- per-carrier constructed-launch records.

For every regenerated record, state:

- exact schema;
- exact required fields;
- inputs;
- creation stage;
- output path;
- fields that are root-derived;
- fields that must match the qualification package;
- whether its identity is referenced by another record.

──────────────────────────────────────────────────────────────────────────────
9. DEPENDENCY AND CREATION ORDER
──────────────────────────────────────────────────────────────────────────────

Create:

interface/bootstrap-materialization-order-v1.json

Freeze one acyclic sequence, such as:

1. Allocate fresh audit root.
2. Create retained bootstrap-start.
3. Verify qualified package and import contract.
4. Copy wrapper, launcher, CLI contract, request contract, and environment
   observation policy byte-for-byte.
5. Verify copied source identities.
6. Create copied-launcher identity record.
7. Create fresh fixed-environment record.
8. Create fresh root-bound launch-contract instance referencing the fresh
   identity records.
9. Create launch-contract root-rebinding proof.
10. Create first audit-owned payload and identity.
11. Create first carrier request.
12. Launch process self-check.

Do not assume this order is correct merely because it appears here. Derive and
validate it from the actual launcher source and contracts.

Require:

- no circular identity dependency;
- no record referenced before its bytes are final;
- no launch contract referencing a stale qualification-root identity record;
- no copied qualification result used as fresh audit truth.

──────────────────────────────────────────────────────────────────────────────
10. AUXILIARY IDENTITY-RECORD ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Locate every “auxiliary identity record” mentioned by the failed bootstrap.

For each, determine:

- exact path;
- schema;
- role;
- whether it is exported;
- whether it is root-independent;
- whether it describes package bytes or copied audit-root bytes;
- whether it must be copied or regenerated;
- which launch-contract pointer refers to it;
- whether its digest participates in normalized root equivalence.

Retain:

analysis/auxiliary-identity-record-adjudication.json

If the package itself leaves a required record’s role ambiguous after complete
source inspection, return:

LAUNCHER_IMPORT_REQUIRES_INTERFACE_ADDENDUM

Do not silently resolve genuine package ambiguity through audit discretion.

──────────────────────────────────────────────────────────────────────────────
11. ROOT-REBINDING FIELD MAP
──────────────────────────────────────────────────────────────────────────────

Independently derive the exact root-bound pointer set from the qualified launch
contract and launcher source.

Compare with the qualification report’s claimed pointer families:

- `/qualification_root`
- `/wrapper/path`
- `/phase_runner_cli_contract/path`
- `/carrier_request_contract/path`
- `/fixed_environment/HOME`
- `/fixed_environment/TMPDIR`
- `/fixed_environment_record/path`
- `/fixed_environment_record/size`
- `/fixed_environment_record/sha256`
- `/launcher_identity_record/path`
- `/launcher_identity_record/size`
- `/launcher_identity_record/sha256`

Determine whether that list is:

- exact;
- incomplete;
- overbroad;
- ambiguous.

Retain:

interface/root-rebinding-field-map-v1.json

Freeze normalization semantics and prohibit non-root-bound differences.

──────────────────────────────────────────────────────────────────────────────
12. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT

only if:

- both supplied manifests reproduce exactly;
- package membership is correct;
- the failed bootstrap used incorrect comparison semantics or an incorrect
  import-role assumption;
- complete exported roles and creation order can be derived unambiguously from
  retained package bytes;
- no package repair or addendum is required.

Return:

LAUNCHER_IMPORT_REQUIRES_INTERFACE_ADDENDUM

only if:

- package content and manifests are correct;
- launcher capability remains sound;
- a required consumer-facing role, export boundary, creation order, or
  root-rebinding rule is not unambiguously frozen by the package;
- a small source-external interface addendum is required before another full
  V3 audit.

Return:

LAUNCHER_PACKAGE_REPAIR_REQUIRED

only if:

- a supplied manifest cannot be reproduced under its own generator semantics;
- a required exported artifact is absent or internally inconsistent;
- a package object has an actual membership, type, mode, link, size, hash, or
  role defect that cannot be resolved through a consumer-only addendum.

Return:

RECONCILIATION_PROVENANCE_MISMATCH

only for:

- supplied-root drift;
- supplied-root mutation;
- missing indispensable failure evidence;
- closing inequality;
- reconciliation-process provenance failure.

Do not retry the full V3 audit in this task.

──────────────────────────────────────────────────────────────────────────────
13. REQUIRED NEXT-STEP SPECIFICATION
──────────────────────────────────────────────────────────────────────────────

If the verdict is
`LAUNCHER_IMPORT_RECONCILED_BOOTSTRAP_VERIFIER_DEFECT`:

- provide the exact corrected bootstrap algorithm;
- provide the exact consumer import contract;
- identify the failed bootstrap lines or predicate to replace;
- state that the qualified package bytes remain unchanged.

If the verdict is
`LAUNCHER_IMPORT_REQUIRES_INTERFACE_ADDENDUM`:

- provide the exact proposed addendum field map;
- list the exact supplied package identities it binds;
- state the minimal independent audit needed for the addendum;
- do not implement it.

If the verdict is
`LAUNCHER_PACKAGE_REPAIR_REQUIRED`:

- identify exact defective package paths and identities;
- define the smallest bounded repair;
- state what qualification must be repeated;
- do not perform the repair.

──────────────────────────────────────────────────────────────────────────────
14. CLOSING
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for:

- qualified launcher package;
- failed bootstrap audit root;
- accepted generic-wrapper root if opened.

Require byte-for-byte opening/closing equality.

Remove only reconciliation-owned private temporary state.

Retain:

- opening inventories;
- package manifest contract;
- both independent reproducers and outputs;
- failed-bootstrap checker reconstruction;
- complete package role ledger;
- consumer import contract;
- materialization order;
- auxiliary-role adjudication;
- root-rebinding field map;
- verdict record;
- final report;
- final inventory;
- two independent covering manifests.

──────────────────────────────────────────────────────────────────────────────
15. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Reconciliation-root identity
3. Supplied-root opening identities
4. Exact package manifest grammar
5. Independent manifest reproduction A
6. Independent manifest reproduction B
7. Supplied-manifest byte comparison
8. Failed bootstrap checker algorithm
9. Exact first failed predicate and values
10. Manifest-failure root cause
11. Complete package role ledger
12. Exact exported consumer interface
13. Exact copy-versus-regenerate classification
14. Auxiliary identity-record adjudication
15. Root-rebinding field map
16. Bootstrap materialization order
17. Whether package repair or addendum is required
18. Exact recommended next step
19. Supplied-root closing equality
20. Reconciliation capsule closure
21. Remaining uncertainty and nonclaims
22. Explicit confirmations

Required confirmations:

QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
FAILED_BOOTSTRAP_AUDIT_ROOT_MUTATION_NOT_PERFORMED
GENERIC_WRAPPER_ROOT_MUTATION_NOT_PERFORMED
LAUNCHER_OR_WRAPPER_NOT_EXECUTED
FULL_V3_AUDIT_NOT_RETRIED
PACKAGE_MANIFEST_GRAMMAR_RECONSTRUCTED
PACKAGE_MANIFEST_A_INDEPENDENTLY_REPRODUCED
PACKAGE_MANIFEST_B_INDEPENDENTLY_REPRODUCED
MANIFEST_CONTENT_MISMATCH_CAUSAL_IDENTIFIED
COMPLETE_PACKAGE_ROLE_LEDGER_PRODUCED
EXPORTED_CONSUMER_INTERFACE_ADJUDICATED
COPY_VERSUS_REGENERATE_BOUNDARY_ADJUDICATED
AUXILIARY_IDENTITY_RECORDS_ADJUDICATED
ROOT_REBINDING_FIELD_MAP_ADJUDICATED
BOOTSTRAP_MATERIALIZATION_ORDER_ADJUDICATED
NO_TARGET_CONTENT_INSPECTED
CANDIDATE_GIT_NOT_INVOKED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
SUBAGENTS_CREATED: 0
```

Do not run another full V3 audit until this reconciliation determines whether the failure belongs to the bootstrap checker, the package interface, or the package itself.

**Source:** Codex’s latest bootstrap `AUDIT_PROVENANCE_MISMATCH` report and the qualified launcher package report, which records the claimed exact manifest closure. 

**Confidence:** 0.99 that the latest attempt failed before any V3 target adjudication; 0.82 that the immediate cause is a bootstrap manifest/import-interface defect rather than package corruption; 0.99 that a read-only reconciliation is safer than another full-audit retry.

Some older uploaded project files have expired from this session. They were not needed for this process assessment. Re-upload them when direct byte-level inspection of those artifacts is required.
