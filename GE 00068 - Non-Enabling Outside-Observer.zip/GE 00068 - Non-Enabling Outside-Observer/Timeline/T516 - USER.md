Here is Codex's response:

# AUDIT_PROVENANCE_MISMATCH

Exactly one `run-full-audit` parent was launched. Its creation consumed the sole authorization. It exited under the frozen unhandled-failure posture:
```
{"detail":"qualification/runtime-matrix-suite-v2.json","reason":"embedded-record-unavailable","schema":"harness-v2-failure-v1"}
```

Exit was `1`, signal was `null`, stdout was empty, and no terminal frame was emitted. Therefore no audit root was selected, inferred, scanned, inspected, mutated, or cleaned. No retry is authorized or was attempted.

The complete wrapper report is [operative-report-v1.json (line 1)](/private/tmp/ES-repair10i-v3-gen2-fresh-independent-audit-wrapper-8qz1_nhg/report/operative-report-v1.json:1), SHA-256 `88f41f40488bc9023cc211fae3b468de20ea11fd398779484a1ea4494357f151`.

### Fixed inputs

| InputDevice / inodeMode / linksSizeSHA-256                                                                                                                                                                              |                        |            |            |                                                                    |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------- | ---------- | ---------- | ------------------------------------------------------------------ |
| [PYZ v2](/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz)                                             | `16777234 / 182181777` | `0400 / 1` | `2822218`  | `2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2` |
| [Authority v3 (line 1)](/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json:1)              | `16777234 / 182181917` | `0400 / 1` | `7193`     | `349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986` |
| [Launch certificate v1 (line 1)](/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-launch-certificate-v2-output-mchfmdqd/gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json:1) | `16777234 / 182301064` | `0400 / 1` | `67057`    | `eaee84d823cbea4ae88ccf0a7ed01429e2b451f5bac128190e760e4d4e528bb8` |
| [Content bundle](/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip)                                                        | `16777234 / 181651092` | `0400 / 1` | `13598758` | `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671` |
| [Content authority (line 1)](/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json:1)                               | `16777234 / 181651098` | `0400 / 1` | `19737`    | `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563` |

### Operative report

1. **Exact primary verdict:** `AUDIT_PROVENANCE_MISMATCH`.
2. **Five identities:** Exact values are recorded above.
3. **Stable authentication:** Two no-follow reads per file; regular-file, `0400`, single-link, metadata and bytes equal.
4. **Certificate authentication:** Schema/version/status/bindings passed.
5. **Certificate authority model:** Current wrapper authority; one future audit authorized; containing directory nonauthoritative.
6. **Authority-v3 role:** Passed only through `--harness-authority`; not treated as standalone wrapper authority.
7. **PYZ closure:** 124 members, exact registry closure, deterministic ZIP predicates passed; governance counts `5/66/81/15/595`; stale `645` rejected.
8. **Platform preflight:** Passed once. PID `86739`; exit `23`; signal `null`; reaped and descriptors closed. Both streams were 27 bytes with their expected hashes.
9. **Audit argv:** Exact frozen 13-element invocation using Framework Python, `-I -S -B`, PYZ, `run-full-audit`, authority v3, bundle, and bundle authority. Certificate was not passed.
10. **Cwd/environment:** Cwd was the PYZ directory. Submitted environment was exactly `PATH=/usr/bin:/bin`, `LANG=C`, `LC_ALL=C`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONHASHSEED=0`.
11. **Top-level custody:** Custody ID `b942b6d4-a314-4563-ac42-abbfbf591d8b`; PID `86740`; created successfully; start `1790897164108298000`, completion `1790897164336676000`, duration `228375542 ns`; reaped; descriptors closed; no process error.
12. **Raw streams:** [stdout](/private/tmp/ES-repair10i-v3-gen2-fresh-independent-audit-wrapper-8qz1_nhg/raw/run-full-audit-stdout.bin) is 0 bytes, SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. [stderr](/private/tmp/ES-repair10i-v3-gen2-fresh-independent-audit-wrapper-8qz1_nhg/raw/run-full-audit-stderr.bin) is 128 bytes, SHA-256 `8b5e4c03ed2006ce66803b4aa1eb3b314c7e1d63e0047d3fac61a299f194dac8`.
13. **Exit/signal:** Exit `1`; signal `null`.
14. **Terminal frame:** Absent. The stderr object is a harness failure frame, not a terminal frame.
15. **Audit-root identity:** Unavailable. No locator was accepted and no root scan occurred.
16. **Parent self-authentication:** Not available without the terminal capsule.
17. **Interpreter tuple:** Not established.
18. **Environment crosswalk:** Exact submitted environment retained; capsule runtime crosswalk not established.
19. **P00–P24:** Not authenticated because no terminal root was available.
20. **Child ledger/custody:** Capsule ledger unavailable. The externally owned audit parent itself was reaped and its descriptors closed.
21. **Content closure:** 479 members, 478 indexed members, eight exact roles; prelaunch closure passed.
22. **Source/freeze closure:** Frozen source and source registries authenticated prelaunch; terminal audit evidence unavailable.
23. **Production authority/security:** Not terminally authenticated.
24. **E00/G00–G29:** Not terminally authenticated.
25. **Documentary lifecycle/writers:** Not terminally authenticated.
26. **Runtime matrices:** Embedded governed registry and existing `runtime-matrix-v2` record authenticated as 15 matrices/595 cases; audit failed while requesting unavailable `qualification/runtime-matrix-suite-v2.json`.
27. **946 negatives:** Not terminally authenticated.
28. **137 contradictions:** Not terminally authenticated.
29. **766/333 field map:** Not terminally authenticated.
30. **Producer rehearsals:** Prelaunch bindings passed; capsule result unavailable.
31. **Attempt-2 evidence:** Prelaunch binding passed; capsule result unavailable.
32. **Implementation confirmations:** Not terminally authenticated.
33. **Constructed-subject evidence:** No current subject was constructed; capsule record unavailable.
34. **Fresh behavioral causals:** Not terminally authenticated.
35. **Fresh source-external validation:** Not terminally authenticated.
36. **Security/authority closure:** Capsule result unavailable; wrapper performed no network, Git, product, target-audit, or live-service activity.
37. **R01–R66:** Registry authenticated prelaunch; runtime report unavailable.
38. **81 confirmations:** Name registry authenticated prelaunch; runtime rows unavailable.
39. **Complete findings:** Unavailable.
40. **Finding ownership:** Unavailable.
41. **Dependency graph:** Unavailable.
42. **Severity findings:** Unavailable.
43. **Preseal disposition:** Unavailable.
44. **Cleanup:** Capsule cleanup evidence unavailable; wrapper performed no capsule cleanup.
45. **Capsule fixed-input equality:** Unavailable.
46. **Wrapper five-file equality:** Passed for all five files after process completion.
47. **Temporal identity:** Unavailable.
48. **Manifest A:** Unavailable.
49. **Manifest B:** Unavailable.
50. **Final reprojection:** Not established.
51. **Terminal topology/modes:** Not established.
52. **Seal/marker:** No terminal seal or marker was emitted.
53. **No-write result:** Wrapper did not mutate the capsule; the post-seal no-write predicate cannot be established because no terminal seal was reached.
54. **Current subject:** Confirmed not constructed.
55. **Prohibited activity:** No product/runtime-validation/target/A6 activity, repository modification, Git, network, retry, replacement, continuation, or subagent.
56. **Remaining uncertainty:** No capsule verdict, root identity, phase evidence, findings, manifests, topology, or closure claim is inferred from a partial failed run.
57. **Explicit confirmations:** 32 confirmed; 28 terminal-capsule confirmations not established.

Confirmed:
```
PYZ_V2_IDENTITY_MATCHED
AUTHORITY_V3_IDENTITY_MATCHED
LAUNCH_CERTIFICATE_IDENTITY_MATCHED
CONTENT_BUNDLE_IDENTITY_MATCHED
CONTENT_AUTHORITY_IDENTITY_MATCHED
LAUNCH_CERTIFICATE_CURRENT_AND_COHERENT
LAUNCH_CERTIFICATE_AUTHORIZED_ONE_AUDIT
PYZ_MEMBER_SET_124_CLOSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
LAUNCH_CERTIFICATE_NOT_PASSED_TO_HARNESS
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_SCAN_NOT_PERFORMED
WRAPPER_FIVE_FILE_CLOSING_EQUALITY_PASSED
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

Not established because the terminal frame was absent:
```
AUDIT_ROOT_FROM_TERMINAL_FRAME_USED
TERMINAL_FRAME_STRICTLY_PARSED
PARENT_RUNTIME_SELF_AUTHENTICATION_RETAINED
INTERPRETER_OBSERVATION_TUPLE_PASSED
RUNTIME_ENVIRONMENT_POLICY_PASSED
CAPSULE_PRIMARY_VERDICT_REPORTED_EXACTLY
COMPLETE_RUNTIME_REPORT_RETAINED
COMPLETE_RUNTIME_CONFIRMATIONS_RETAINED
EVERY_REQUIRED_PHASE_TERMINAL
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_RESULT_RETAINED
CAPSULE_FIXED_INPUT_CLOSING_EQUALITY_RETAINED
TEMPORAL_INVENTORY_RETAINED
MANIFEST_A_RETAINED
MANIFEST_B_RETAINED
MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_PASSED
ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_SEAL
```
