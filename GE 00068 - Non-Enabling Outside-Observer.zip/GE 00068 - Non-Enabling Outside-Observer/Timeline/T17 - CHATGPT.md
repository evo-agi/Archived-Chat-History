This is **two distinct failures**, and they should not be allowed to blur together.

First, `AUDIT_PROVENANCE_MISMATCH` is procedurally defensible. The audit was asked to prove that the already-published ZIP underwent no xattr mutation through the failed `os.listxattr` attempt and continuation. Its bytes, inode, membership, source tree, and source inventory still match, but the changed `ctime` plus the missing pre-recovery xattr-value baseline make that historical metadata claim unprovable. Nothing can now reconstruct the missing baseline honestly.

That does **not** mean the source snapshot bytes are corrupted or ambiguous. It means that this specific capture lineage cannot qualify under the overly strong no-xattr-mutation claim.

Second, the audit should have stopped correctness inspection when it returned `AUDIT_PROVENANCE_MISMATCH`. The project protocol requires stopping before implementation judgment when exact required provenance cannot be reproduced.   Accordingly, the reported authority, canonicalization, regression-detection, mutant-validation, and qualification defects are **valuable leads**, but they are not a completed independent-audit adjudication. They need to be recovered from the full report, verified against the exact source, and frozen into a repair plan.

The secondary findings are nevertheless serious enough that **another capture of the current bytes would be wasted work**. Even a perfect new ZIP would still lead to `BLOCK`.

The critical path is:

1. Retain the present ZIP, handoff, Phase H, capture child, and audit bundle unchanged as nonqualifying historical evidence.
2. Perform one read-only Repair 10I reconnaissance against the full audit report and exact live source.
3. Recover and verify every secondary finding, separating candidate defects from successor-tool, validation-construction, report, and capture defects.
4. Freeze the new capture contract explicitly. Either future snapshots cryptographically bind xattr names and value digests across the final publication interval, or the governing contract states that ZIP-container xattrs and `ctime` are report-only host metadata outside source-transport identity. Do not make both claims.
5. Implement the frozen repair parent-only.
6. Create a completely new sealed validation lineage and integrated snapshot.
7. Run another fresh independent audit.
8. Keep staging and commit prohibited until `ACCEPT`.

The Repair 10H design required final↔fresh accepted equality, independently recomputed qualification, zero unknown differences, and a separately qualified deliberate mutant.  Its frozen comparison matrix made final↔fresh equality a direct readiness condition rather than an optional report interpretation.  The reconnaissance now needs to determine exactly how the audit says the implemented source or successor violated those conditions.

Use this next.

```text
Objective

Perform a read-only Repair 10I reconnaissance against the exact Repair 10H
candidate, its sealed implementation and capture evidence, and the complete
fresh-audit report.

Recover, independently verify, classify, and reconcile every reported secondary
finding. Freeze one executable repair plan and the future snapshot-provenance
contract.

Do not implement or repair anything in this turn.

Return exactly one:

REPAIR10I_RECONNAISSANCE_READY
REPAIR10I_RECONNAISSANCE_PARTIAL
REPAIR10I_RECONNAISSANCE_BLOCKED
AUDIT_INPUT_MISMATCH

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected live source identity

Branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

Sole parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

Upstream:
absent

Index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

Candidate source T:
00280085500a40dc4a931b416fc00f0f1c9bf1e9

Candidate inventory:
ede21d8fe52e22ed12b37bca9c4ed97f89ae0a99a0198d77160fcbe16e4545ec

Membership:
389 total
375 tracked
14 nonignored untracked

Staged/deleted/renamed/unmerged:
0/0/0/0

Relevant immutable inputs

Phase H:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Expected Phase H manifest SHA-256:

fdfc710eca48306813f505766f70da35f23e34e32f177f714ab178ee4eee1abb

Integrated ZIP:

/Users/ds/Downloads/ES-T2AP-repair10-integrated-00280085500a.zip

Expected ZIP:

size:
2338208

SHA-256:
86f3d17a2d672964575f2273ae397ee71f479fc5d8d057065a206d83f9205ca6

members:
389

Handoff:

/Users/ds/Downloads/ES-T2AP-repair10-integrated-00280085500a-audit-handoff.md

Expected handoff SHA-256:

abd1526c155644f3f576ede15c0de5d39773da96be4717ad8e8784a8f7d8da0d

Capture child:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/snapshot-00280085500a-fwAgN6fQWCdn

Expected capture manifest SHA-256:

c27f7dbe00bd27ad4abf4d2564792b9bb73918bd594ce6a6aab5498cef89e090

Fresh audit:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/audit-integrated-00280085500a-gBIiZSZFeFK4

Audit report:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/audit-integrated-00280085500a-gBIiZSZFeFK4/audit-report-v1.md

Audit evidence manifest:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/audit-integrated-00280085500a-gBIiZSZFeFK4/audit-evidence-manifest-v1.txt

Expected audit manifest:

size:
193460

SHA-256:
f020099e959e8a4cce0d929fbbcdf99aaa0ddd44e6c6d915bb5ab4ead0817152

manifested payloads:
815

total files:
817

directories:
196

Posture

This is a read-only reconnaissance turn.

Do not:

- edit, create, delete, rename, chmod, normalize, or format repository files;
- modify Phase H, the capture child, the ZIP, the handoff, or the audit child;
- run product tests or builds;
- create another snapshot;
- stage, commit, push, install, invoke a live route, or contact a remote host;
- repair the old ZIP’s metadata or attempt to forge historical ctime/xattr state;
- claim an independent audit verdict.

Use GIT_OPTIONAL_LOCKS=0 for every Git read. Do not use ordinary git status unless
the opening protocol explicitly proves it nonmutating for this exact posture.

Opening gate

Before creating subagents:

1. Verify the exact repository/source identity above.
2. Verify Phase H, capture-child, ZIP, handoff, and audit-child path sets and
   manifest identities.
3. Verify the audit report and audit manifest are sealed and internally
   consistent.
4. Verify the audit’s claimed ZIP ctime values and determine exactly which
   records support them.
5. Confirm that no pre-recovery xattr name/value-digest baseline exists.
6. Confirm ZIP bytes, inode, source T, inventory, and membership remain exact.
7. Record the opening Git-administration state narrowly enough to detect any
   change caused by this reconnaissance.

Stop with AUDIT_INPUT_MISMATCH on any unexpected byte, source, seal, membership,
or manifest mismatch.

Interpretive rule

Treat the audit outcome as two separate records:

A. Capture-provenance record

The old integrated ZIP is historically nonqualifying for a no-xattr-mutation
claim because:

- ctime changed;
- the pre-recovery xattr value baseline is absent;
- the missing baseline cannot be reconstructed retrospectively.

Do not treat this as source-byte drift or ZIP corruption unless evidence proves
one.

B. Secondary finding record

Because the audit protocol required stopping at provenance mismatch, treat all
subsequent source/correctness findings as audit-reported leads, not as an
accepted independent-audit adjudication.

Recover every lead from the complete report and independently verify its source,
test, evidence, and causal basis before freezing implementation.

Subagent workflow

After the opening gate, create exactly four bounded read-only explorers. No
nested delegation.

Every explorer receives the same baseline identities, exact audit report, and
this interpretive rule.

Explorer 1 — authority, contracts, and capture lineage

Inspect:

- AGENTS.md and PLANS.md;
- the six Repair 10H governing system-overview pages;
- artifact-hygiene and provenance requirements;
- Phase H capture requirements;
- fresh-audit report sections concerning authority and the ZIP/xattr mismatch;
- failed os.listxattr attempt and continuation evidence.

Return:

- whether any authority or lifecycle statement is contradictory;
- every reported authority defect, with exact path and line;
- whether it is a candidate defect, report defect, capture-contract defect, or
  audit-process defect;
- the exact future snapshot contract:
  either exact xattr name/value-digest stability, or explicit report-only
  container metadata;
- docs and tests that must change;
- stop conditions.

Do not silently choose the future xattr/ctime policy if owning docs conflict.
State the unresolved decision and return it to the parent.

Explorer 2 — product tests and typed canonicalization

Inspect:

- remoteobserver privacy tests;
- Repair 10H typed canonicalization rules;
- semantic extraction and canonicalization source;
- successor tests;
- audit findings concerning canonicalization, privacy, diagnostics, and
  regression detection;
- raw evidence cited by those findings.

For every reported defect:

- recover its exact ID, severity, wording, paths, lines, control, mutant, and
  retained evidence;
- verify whether the mechanism is reachable in the exact source;
- distinguish production defect from product-test defect and successor defect;
- determine whether Phase H tests causally kill the defect;
- identify the smallest coherent source/test/doc repair.

Specifically examine whether:

- any typed rule admits partial matches or generic replacement;
- occurrence order, multiplicity, or correlation is lost;
- route/status, EPERM/EACCES, SHA/OID, panic structure, scalar/nil, or lifecycle
  changes can be hidden;
- baseline directional regression checks can miss a final-only regression;
- common inherited failures are unioned or otherwise normalized unsafely.

Explorer 3 — mutant, qualification, and comparator

Inspect:

- the intentional-mutant provenance and source materialization;
- suite specs, suite results, command results, terminal reconciliations, raw
  streams, semantic envelopes, qualification records, custody records,
  comparison results, and adjudication;
- successor comparator, runner, semantic extractor, FORMAT, and causal tests;
- all audit findings concerning mutant validation and qualification.

For every reported defect:

- recover exact ID, severity, evidence, path, line, and mechanism;
- determine whether producer captions are trusted instead of recomputed facts;
- determine whether a mutant can be qualified without exact source
  materialization and immutable sole-path provenance;
- determine whether final↔fresh acceptance can pass without all required factual
  and qualification predicates;
- determine whether late custody/resource/terminal faults can leave an accepted
  outcome;
- determine whether HEAD→final and Repair9→final directional comparisons can
  miss pass-to-fail, skip, abort, panic, race, warning, malformed-stream, or
  unknown-diagnostic regressions.

Return the exact private schema changes, if any. Product/public schemas are not
in scope.

Explorer 4 — validation, evidence, and repair sequencing

Inspect:

- Phase H command index;
- failed/superseded attempts;
- literal assertion mapping;
- provenance-recipe inventory;
- closeout adjudication;
- fresh-audit unexecuted matrix;
- all reported validation-construction, evidence, and capture defects.

Return:

- exact validation that was actually run;
- validation that the fresh audit reran;
- validation stopped or unexecuted;
- every reported regression-detection defect;
- whether any finding lacks a valid control or causal reproduction;
- exact future commands, isolation requirements, retained evidence, and
  closeout requirements;
- whether one coherent Repair 10I tranche is safe or whether source/tool repair
  and capture-policy repair must be sequenced as two finite subtranches.

Parent synthesis responsibilities

The parent must independently inspect every material finding and reconcile the
four reports.

Produce a complete finding ledger. Each row must contain:

- exact audit finding ID;
- audit severity;
- parent-adjudicated severity;
- category:
  candidate source
  product test
  successor tool
  qualification/comparator
  validation construction
  evidence/report
  capture/transport
  audit process
  inherited unrelated issue;
- current contract;
- exact paths and lines;
- valid positive control;
- causal mutant or conclusive source mechanism;
- impact;
- required correction;
- touched docs/source/tests/tool surfaces;
- whether it blocks implementation readiness;
- whether it blocks only snapshot qualification;
- uncertainty.

Do not accept “high-severity authority, canonicalization, regression-detection,
mutant-validation, and qualification defects” as sufficiently precise. Recover
the exact findings from the full report.

Prior-finding handling

For every Repair 10H claim, return one:

- CLOSED_CONFIRMED
- PARTIAL
- OPEN
- SUPERSEDED
- REPORT_ONLY
- NOT_INDEPENDENTLY_RECOVERED

Do not mark anything closed based only on Phase H’s implementation report.

Capture-policy decision

Freeze one of these, with owning-doc support:

Option A — strict container-metadata lineage

- Capture exact published-file xattr names.
- Capture exact value bytes or safe value digests for every xattr.
- Capture mode, owner, link count, flags, inode, size, bytes, mtime, ctime, and
  birth time.
- Establish the baseline only after atomic publication and all authorized
  publication-time metadata effects.
- Prohibit every later metadata mutation.
- Compare the complete state at handoff and closeout.
- Stop if the required low-level xattr observation is unavailable.

Option B — byte-transport identity

- State explicitly that ZIP-container ctime and host-managed xattrs are
  report-only and outside transported-source identity.
- Bind source transport to ZIP bytes, safe ZIP member metadata, membership,
  extraction inventory, reconstructed T, mode, owner policy, and link policy.
- Prohibit intentional xattr mutation, but do not claim historical xattr
  equality without a captured baseline.
- Keep xattr names/value digests as supplementary host metadata only.

Do not combine strict no-xattr-mutation acceptance with report-only xattrs.
Do not attempt to repair or recertify the old ZIP.

Intended sequence

Unless reconnaissance finds a stronger reason to stop, the expected sequence is:

1. Freeze Repair 10I docs, source, tests, successor-tool, validation, and capture
   changes.
2. Parent-only implementation against the exact live source.
3. Full affected validation plus separately directional HEAD and Repair 9
   comparisons.
4. Fresh qualified deliberate mutant.
5. Fresh final↔fresh accepted equality.
6. New sealed implementation evidence.
7. New integrated ZIP and handoff under the newly frozen capture policy.
8. Fresh independent audit.
9. Exact-byte commit review only after ACCEPT.

No current Repair 10H ZIP or audit child becomes qualifying through this plan.

Required final report

Return:

1. Verdict.
2. Opening and closing identities.
3. Audit-protocol deviation assessment:
   - primary mismatch validity;
   - status of secondary findings.
4. Four explorer outcomes and preserved disagreements.
5. Complete recovered finding ledger.
6. Capture-policy decision or explicit unresolved authority decision.
7. Exact intended repository touched files.
8. Exact intended successor/evidence touched files.
9. Docs-first implementation order.
10. Exact validation and causal-mutant matrix.
11. Evidence-retention and new-snapshot requirements.
12. Stop conditions.
13. Inspection limits and uncertainty.
14. Confirmation of no mutation.

Required effect footer

REPOSITORY_SOURCE_MUTATION_NOT_PERFORMED
GIT_ADMINISTRATION_MUTATION_NOT_PERFORMED
PHASE_H_MUTATION_NOT_PERFORMED
CAPTURE_MUTATION_NOT_PERFORMED
AUDIT_CHILD_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
BUILDS_NOT_RUN
NEW_SNAPSHOT_NOT_CREATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
NESTED_SUBAGENTS_CREATED: 0
```

The key judgment is: **do not spend another cycle trying to rehabilitate the existing capture**. The old capture can never prove a pre-recovery xattr state that was not recorded. Preserve it, learn from it, repair the substantive findings, and replace it with a new capture governed by an honest metadata contract.

### Sources

The Repair 10H freeze explicitly required independently recomputed qualification, separate factual and accepted equality, and fail-closed handling for unknown or late-fault states.  Its matrix required final↔fresh accepted equality and zero unknown differences.  Project provenance guidance requires stopping source judgment on a required provenance mismatch and distinguishes exact-byte provenance from correctness.   The project audit workflow keeps repair in a subsequent writer-owned turn and requires a fresh audit after changed bytes.  

**Confidence:** 0.98 that the reported ZIP issue is a capture-lineage failure rather than source-byte drift; 0.99 that commit remains blocked; 0.95 that read-only Repair 10I reconnaissance is the correct next gate; 0.82 on the eventual repair scope until the full audit report’s finding ledger is recovered.
