## Assessment

This is a clean, authority-bearing **`ACCEPT`** for the full-audit bootstrap package. It qualifies the exact successor bytes and bounded source-external process behavior; it does **not** qualify the Validation-Custody V3 target, any repository state, deployment, or A6. 

The result closes the bootstrap-package line:

- All phases P00–P18 passed. 
- Both materializations and handoffs passed with exact PID, environment, CLI, and output evidence. 
- Producer validation, package-independent validation, and the fresh audit-owned validator all passed. 
- The security/export boundary closed with no production-reachable fault hook or authority widening. 
- Supplied-root equality and cleanup passed, and the terminal manifests were byte-identical and stable after an exit-zero terminal seal. 

No further bootstrap repair, audit-oracle reconciliation, or parent-source work is warranted. The next authority-bearing step is the **fresh independent audit of the Validation-Custody V3 audit-repair target**, using this accepted bootstrap package unchanged. A6 remains blocked until that target audit accepts.

## Prompt for Codex

```text
FRESH INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 AUDIT-REPAIR TARGET
USING THE ACCEPTED FULL-AUDIT BOOTSTRAP

This is the substantive fresh independent audit of the exact
Validation-Custody V3 audit-repair target.

Use the accepted full-audit bootstrap package as the sole process-bootstrap
mechanism.

Do not create or repair another:

- bootstrap package;
- parent source;
- process wrapper;
- launcher;
- supervisor;
- importer;
- capability probe;
- process-harness reconciliation;
- package implementation.

Do not modify any supplied root.
Do not run Git.
Do not inspect or edit repository source beyond the exact read-only candidate
identity checks required by the target package.
Do not run Plan V3 or Plan V4 commands.
Do not rerun V2 dynamic validation.
Do not invoke product or live-service behavior.
Do not install, deploy, publish, commit, or start A6.
Do not create subagents or direct auditors.

Use one finite parent-owned audit with parent-generated analytical
perspectives.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact Validation-Custody V3 documentary,
provenance, lineage, authority, and bounded evidence-composition package.

It grants no:

- repository implementation authority;
- product or runtime authority;
- deployment or publication authority;
- readiness authority;
- V3 target-execution authority;
- semantic-successor authority;
- orchestrator authority;
- A6 authority.

──────────────────────────────────────────────────────────────────────────────
1. ACCEPTED PROCESS BOOTSTRAP
──────────────────────────────────────────────────────────────────────────────

ACCEPTED_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected root identity:

- device/inode:
  16777234 / 179405897
- mode:
  0700

Expected terminal manifests:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  313487 each
- SHA-256:
  34ef0627aedde05ac847a9ae1a9d8568d6773cd8fb1b619724e74019da6b3a4d
- byte-identical:
  required

Accepted bootstrap-audit root:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv

Expected accepted-audit facts:

- primary verdict:
  ACCEPT
- primary-verdict record:
  348 bytes
  SHA-256:
  34e1e76806d19546c194620ac49376189a81a19583ef5ed639831d7b3fbd7aae
- final report:
  3706 bytes
  SHA-256:
  4760e58a5324d79a5f61f00962a6fe4e703c0b74203de6c9bbb5a20d432082d8
- terminal manifests:
  33492 bytes each
  SHA-256:
  22e16d8bee120631b5e5dd26f7ecb494cde69625b1c0be8b16e16a72df91993a
  byte-identical
- all P00–P18 phases:
  passed
- substantive findings:
  none

Authenticate these fixed identities before using the bootstrap.

Do not re-audit the bootstrap package.

──────────────────────────────────────────────────────────────────────────────
2. EXACT TARGET
──────────────────────────────────────────────────────────────────────────────

TARGET_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b

Expected target-root identity:

- device/inode:
  16777234 / 178948757
- mode:
  0700
- producer verdict:
  REPAIR10I_T2AP_VALIDATION_CUSTODY_V3_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

Expected terminal artifacts:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- size:
  12587 each
- SHA-256:
  b7836cb66f5e23811914e69e140d544b7dbabb1e6437f819e7ff2da4a0849206
- byte-identical:
  required

closeout/final-evidence-inventory-v2.json

- size:
  12106
- SHA-256:
  fb8b2c509121cde9bc80365ec25597b1aab1e3bfe9e7a5f274da8c2b9a4811e6

closeout/final-implementation-report-v2.md

- size:
  10650
- SHA-256:
  b6efb70d366844ed41a386d30d912e2df01c8e499fc97544aab65473b34a51e5

Authenticate complete target membership and closure independently.

Do not treat the implementation report as artifact authority.

──────────────────────────────────────────────────────────────────────────────
3. FIXED TARGET RECORDS
──────────────────────────────────────────────────────────────────────────────

Authenticate at minimum:

contract/strategic-b-validation-custody-v3.json

- size:
  4878
- SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

contract/validation-plan-v4.json

- size:
  26001
- SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

lineage/failed-and-superseded-attempt-index-v2.json

- size:
  6884
- SHA-256:
  f7e19e44047e764f80f72e4f59b7d9f055d8a52e905c3b6482a790bd4bfc9d83

lineage/authoritative-supersession-v1.json

- size:
  4816
- SHA-256:
  1db6abcf4c077d1b303772ad190981ad11de5af49e6d6430cebd8a836bbfdc4c

adoption/v2-technical-evidence-adoption-v2.json

- size:
  56563
- SHA-256:
  fdafef48a62bbe04e71c3cf5f805c93e25b71daa86aec1a7b521a781383674e9

adoption/complete-observation-lineage-ledger-v1.json

- size:
  50136
- SHA-256:
  d7afb786f724e620c49c74fac68b09aba4ac5fd0a1b96d67837a39979c04f396

Authenticate all further records through the target manifests and inventory,
not by filename inference.

──────────────────────────────────────────────────────────────────────────────
4. SUPPORTING INPUTS
──────────────────────────────────────────────────────────────────────────────

The target package’s opening, lineage, supersession, adoption, and validation
records are authoritative for the exact supporting-root paths and identities.

Expected supporting paths include:

CANDIDATE_REPOSITORY:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

STRATEGIC_B_GATE_ROOT:

/Users/ds/Downloads/ES-strategic-b-gate-requalification-uTwKU7hS

STRATEGIC_B_SNAPSHOT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

BLOCKED_V1_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

V3_PREDECESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

PREVIOUS_BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-independent-audit-cjba38lf

FAILED_REPAIR_ATTEMPT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-4i5hddd3

Do not silently substitute another path.

Authenticate exact device/inode/mode, complete membership, fixed records, and
opening/closing equality as required by the target package.

The candidate repository is read-only evidence. Do not run tests, formatting,
staging, commit, push, or product behavior.

──────────────────────────────────────────────────────────────────────────────
5. BOOTSTRAP MATERIALIZATION
──────────────────────────────────────────────────────────────────────────────

Use the accepted bootstrap package’s exact canonical command:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  source/full_audit_bootstrap_v1.py \
  --qualified-launcher-root \
  /Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38 \
  --import-reconciliation-root \
  /Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s \
  --audit-parent \
  /Users/ds/Downloads \
  --audit-prefix \
  ES-validation-custody-v3-full-audit-

Cwd:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Environment:

HOME=/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private
TMPDIR=/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t/private/tmp
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

Require:

- exit 0;
- exactly one valid `AUDIT_ROOT=` locator;
- empty stderr;
- fresh direct child of `/Users/ds/Downloads`;
- expected prefix;
- complete filesystem-effect attribution.

Do not scan for, score, or adopt another root.

──────────────────────────────────────────────────────────────────────────────
6. CARRIER 0002 PROCESS SELF-CHECK
──────────────────────────────────────────────────────────────────────────────

Invoke the fresh root’s exact copied launcher:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
  -I -S -B \
  ${AUDIT_ROOT}/source/wrapped_carrier_launcher.py \
  --launch-contract \
  ${AUDIT_ROOT}/contract/wrapped-carrier-launch-contract-v1.json \
  --request \
  ${AUDIT_ROOT}/provenance/carrier-0002.request.json

Use:

- cwd:
  `${AUDIT_ROOT}`
- exact six-key fixed environment from the launch contract;
- timeout:
  600 seconds.

Require:

- exit 0;
- request admission;
- constructed launch;
- wrapper admission;
- phase start and outcome;
- same PID;
- exact owned environment;
- diagnostic-only extra environment names;
- wrapper SHA exact and once;
- CLI conformance;
- no child;
- no target inspection;
- complete expected outputs;
- successful self-check result;
- authoritative bootstrap success commit.

If Carrier 0002 fails, stop with `AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
7. TARGET-AUDIT PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

After Carrier 0002 passes, use the accepted copied launcher/wrapper for the
finite target-audit carrier.

Do not introduce another wrapper, supervisor, importer, or persistent command
loop.

Use one finite parent-owned target-audit payload.

Before target inspection retain and hash-bind:

- target-audit plan;
- target-audit payload source;
- payload size and SHA-256;
- request;
- authorized operands;
- expected outputs;
- exact authority and nonauthority;
- child-process policy;
- cleanup policy;
- verdict rules.

Compile the complete payload before target inspection.

The payload must be:

- finite;
- noninteractive;
- stdin-independent;
- free of subagents and direct auditors;
- parent-owned;
- bounded by explicit child timeouts;
- incapable of package repair.

Use four parent-generated analytical perspectives:

1. contract and authority;
2. evidence adoption and lineage;
3. source closure, plan equivalence, and mutation resistance;
4. filesystem closure, security, chronology, and provenance.

They are projections, not separate authorities.

──────────────────────────────────────────────────────────────────────────────
8. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before semantic adjudication:

1. Authenticate the accepted bootstrap package and accepted bootstrap audit.
2. Authenticate the exact target root and terminal closure.
3. Authenticate every supporting root opened.
4. Authenticate the candidate repository identity and read-only posture.
5. Verify pairwise physical distinction.
6. Retain complete lstat/no-follow opening inventories.
7. Authenticate all fixed target records and governing identities.
8. Require no symlink, special object, multi-link file, undeclared empty
   directory, or mode violation.
9. Retain one consolidated opening-gate record.

Do not start correctness adjudication until this gate passes.

Return `AUDIT_PROVENANCE_MISMATCH` for actual input drift, missing fixed input,
root aliasing, process-record gaps, or supplied-root mutation.

──────────────────────────────────────────────────────────────────────────────
9. SOLE NORMATIVE WRITER
──────────────────────────────────────────────────────────────────────────────

Independently enumerate every contract-shaped and Plan-V4-shaped object in the
target capsule.

Require:

- exactly one current V3 normative contract;
- exactly one current Plan V4 writer;
- exactly zero failed-attempt current writers;
- exactly zero historical object eligible for runtime or acceptance use.

The current contract must be:

contract/strategic-b-validation-custody-v3.json

The current Plan must be:

contract/validation-plan-v4.json

Inspect raw content, enclosing lineage, supersession records, and effective
flags.

Do not rely only on directory names.

Return `BLOCK` for a second current or ambiguous normative writer.

──────────────────────────────────────────────────────────────────────────────
10. FAILED-ATTEMPT LINEAGE
──────────────────────────────────────────────────────────────────────────────

Independently authenticate all nine predecessor failed-attempt artifacts bound
by:

lineage/failed-and-superseded-attempt-index-v2.json

Require every historical entry to be explicitly:

- normative:
  false
- effective:
  false
- authoritative:
  false
- current contract writer:
  false
- current Plan writer:
  false
- runtime/acceptance eligible:
  false

Require no historical contract, Plan, source-closure, or opening-binding object
to be copied into the current repair root as an additional historical content
path.

Shared content digest with the one current object is permitted only when the
current object occurs exactly once at the current authoritative path and the
historical object is represented externally by identity.

──────────────────────────────────────────────────────────────────────────────
11. AUTHORITATIVE SUPERSESSION
──────────────────────────────────────────────────────────────────────────────

Independently validate:

lineage/authoritative-supersession-v1.json

Require exact binding of:

- predecessor root identity;
- predecessor complete-entry digest;
- predecessor current contract;
- predecessor Plan V4;
- predecessor source closure;
- predecessor equivalence record;
- all nine failed-attempt identities;
- current repair-root identity;
- unchanged current contract and Plan identities;
- current writer counts.

Require narrow supersession scope:

- authority location;
- historical custody;
- unchanged-current-location selection;
- documentary adoption-lineage repair.

It must not supersede or modify:

- V3 contract semantics;
- Plan V4 command semantics;
- V2 dynamic observations;
- Strategic B source authority;
- runtime results;
- publication or readiness authority.

──────────────────────────────────────────────────────────────────────────────
12. V2 TECHNICAL-EVIDENCE ADOPTION
──────────────────────────────────────────────────────────────────────────────

Parse all nine rows of:

adoption/v2-technical-evidence-adoption-v2.json

For every row independently authenticate:

- observation ID;
- raw absolute and relative path;
- raw size and SHA-256;
- raw schema presence/value;
- exact raw status fields;
- adopted fact;
- adoption basis;
- bounded authority;
- dynamic replay:
  false;
- V2 audit verdict:
  BLOCK;
- verdict promoted:
  false;
- product/runtime/readiness/A6 authority:
  false.

Require all raw false values to remain visible.

Specifically for OBS-05 and OBS-07:

- raw records remain false;
- adoption basis is `raw-plus-correction-record`;
- the exact correction record is authenticated;
- the exact correction fields support only the bounded adopted fact;
- the correction does not promote the V2 verdict;
- no corrected dynamic output is substituted for the raw record.

Correction record:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy/adjudication/replay-and-cleanup-corrections.json

Expected identity:

- size:
  2128
- SHA-256:
  7bfd935591ba24e30d97ddbfc03827d617ed460086ed971c76ebd6874200ee75

Its absent `schema` field must remain explicitly recorded as absent.

Return `BLOCK` for unsupported adoption, hidden raw failure, broadened fact,
verdict promotion, or authority widening.

──────────────────────────────────────────────────────────────────────────────
13. COMPLETE OBSERVATION LINEAGE
──────────────────────────────────────────────────────────────────────────────

Independently validate:

adoption/complete-observation-lineage-ledger-v1.json

Require complete source-to-adoption lineage for OBS-01 through OBS-09.

Require exactly:

- seven `raw-record` rows;
- two `raw-plus-correction-record` rows:
  OBS-05 and OBS-07.

Verify:

- raw record identity;
- correction identity when applicable;
- exact fields used;
- adopted fact;
- bounded authority;
- nonauthority;
- no missing intermediate record;
- no rewritten raw status.

──────────────────────────────────────────────────────────────────────────────
14. V3 CONTRACT AND AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Strict-parse the current V3 contract:

- reject duplicate keys;
- reject nonfinite values;
- require exact field map;
- require exact status:
  proposed-effective-pending-independent-audit;
- require supported-local scope;
- require Strategic B to remain the sole B source/provenance package;
- require the contract to lack source authority.

Require all authority flags false:

- source;
- product;
- runtime;
- deployment;
- publication;
- commit;
- readiness;
- A6.

Require all unsupported-environment flags false:

- shared/adversarial host;
- hostile/remotely administered host;
- symlink alias;
- bind-mount alias;
- mount alias;
- pathname alias.

Treat those as explicit nonauthority, not claims of hostile-environment
resistance.

──────────────────────────────────────────────────────────────────────────────
15. PLAN V3 TO V4 EQUIVALENCE
──────────────────────────────────────────────────────────────────────────────

Authenticate Plan V3 from the V2 capsule and Plan V4 from the target.

Independently normalize them using an audit-owned comparator.

Require:

- exactly eight commands;
- exact order;
- exact argv;
- exact cwd semantics;
- exact environment parameter names and values;
- shared `${SHORT_ROOT}/r` custody;
- pinned tools;
- reasons;
- expected pass/fail/skip identity policy;
- B source identities;
- authority and nonauthority;
- unchanged validation semantics.

Only explicitly permitted metadata/reference differences may remain.

Expected normalized identity:

- size:
  24483
- SHA-256:
  bd9802aeb6eb316a30d8582e6911e7fb38233aca24c3519cf15217eed818959f

Do not execute any Plan command.

──────────────────────────────────────────────────────────────────────────────
16. FIVE-SOURCE CLOSURE AND 86-BYTE DERIVATION
──────────────────────────────────────────────────────────────────────────────

Authenticate and reread the exact five sources:

1. B `internal/testsupport/controlroot.go`
2. B `internal/testsupport/controlroot_test.go`
3. B `es/runtimehelper/helper_test.go`
4. pinned Go `src/os/tempfile.go`
5. pinned Go `src/internal/strconv/itoa.go`

Require exact sizes and SHA-256 identities from the target source-closure
record.

Independently derive:

59 + 1 + (2 + 10) + 1 + 13 = 86 <= 100

Require:

- generated component maximum:
  12;
- socket-path maximum:
  86;
- configured limit:
  100;
- margin:
  14.

Do not rely on an observed random sample.

Do not rerun runtime validation.

──────────────────────────────────────────────────────────────────────────────
17. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement a fresh audit-owned validator.

Do not import:

- producer validator;
- independent producer validator;
- producer mutation fixtures;
- producer expected-result maps.

Build a literal audit-owned case registry covering at minimum:

- allocator CSPRNG and exclusive-creation contract;
- no-follow traversal;
- EEXIST-only retry;
- non-EEXIST terminal behavior;
- forbidden adoption, rename, scan, PID, counter, timestamp, and Git-hash
  authority;
- all six unsupported-host/alias nonauthority flags;
- exact five-source closure;
- `itoa.go` and `tempfile.go` identities;
- 10-digit uint32 decimal maximum;
- 12-byte component maximum;
- 86-byte worst case;
- 100-byte limit;
- exact eight-command set and order;
- argv and expected-identity preservation;
- expected failure and skip preservation;
- Strategic B source/tree identity;
- shared-`r` custody;
- V2 BLOCK preservation;
- Plan V3 non-effectiveness;
- Plan V4 pending-audit status;
- source/publication/commit/readiness/A6 nonauthority;
- exactly one current V3 contract;
- exactly one current Plan V4;
- failed-attempt nonauthority;
- supersession predecessor binding;
- no semantic-scope widening;
- raw false OBS-05 handling;
- OBS-05 correction identity and fields;
- raw false OBS-07 handling;
- OBS-07 correction identity and fields;
- bounded adopted-fact semantics;
- directory-symlink rejection;
- special-object rejection;
- hardlink rejection;
- empty-directory rejection;
- stable inventory grammar;
- final sensitive-scan coverage;
- report and validator nonnormativity;
- historical bytes ineligible for runtime use.

Add further cases required by the actual target source and contract.

Require:

- unique literal names;
- two-way name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain complete source, fixtures, result, and replay instructions.

──────────────────────────────────────────────────────────────────────────────
18. CAPSULE, INVENTORY, AND MANIFEST CLOSURE
──────────────────────────────────────────────────────────────────────────────

Independently enumerate the target root with no-follow traversal.

Require:

- complete membership;
- exact directory and file counts;
- only the two manifests self-excluded;
- manifests byte-identical;
- independent reprojection exact;
- no missing or extra entry;
- no duplicate path;
- no empty retained directory;
- directories mode 0700;
- files regular, single-link mode 0600;
- no symlink;
- no special object;
- no multiply linked regular file;
- stable directory grammar excluding unstable size/link metadata.

Authenticate final inventory chronology and exact exclusions.

──────────────────────────────────────────────────────────────────────────────
19. SENSITIVE-MATERIAL AND ARTIFACT REVIEW
──────────────────────────────────────────────────────────────────────────────

Perform a bounded scan over all target regular files, including:

- current contract and Plan;
- adoption and lineage;
- supersession and failed-attempt index;
- validators and mutation records;
- final report;
- final inventory;
- finalized sensitive-scan record.

Classify:

- operational path and metadata evidence;
- fake/redaction fixtures;
- plausible live credentials or secrets;
- dynamic V2 outputs;
- raw sensitive payload exposure;
- archives, caches, databases, bytecode, build output, or unexpected artifacts.

Do not emit matched secret payloads.

Require no plausible live sensitive material.

──────────────────────────────────────────────────────────────────────────────
20. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3 commands;
- Plan V4 commands;
- Go tests;
- repository tests;
- product code;
- V2 allocator;
- V2 causal harness;
- live services;
- deployment or installation.

This is a documentary, provenance, authority, lineage, closure, and static
source audit.

The retained V2 dynamic evidence is a bounded input, not a replacement for
current runtime validation and not an instruction to rerun it.

──────────────────────────────────────────────────────────────────────────────
21. AUTHORITY AND NONAUTHORITY
──────────────────────────────────────────────────────────────────────────────

Independently derive the final authority split.

Strategic B owns:

- B source bytes;
- logical repository modes;
- source inventory;
- source tree;
- H-to-B classification;
- evidence-only synthetic commit.

V2 owns only:

- exact retained dynamic observations.

V3 target may own only:

- documentary validation-custody contract;
- Plan V4;
- exact source closure;
- explicit nonauthority;
- Plan V3/V4 equivalence;
- bounded references to V2 technical evidence;
- repair-specific supersession and failed-attempt custody.

V3 target must not own:

- B source;
- repository truth;
- product/runtime behavior;
- publication;
- commit;
- readiness;
- deployment;
- target execution;
- A6;
- hostile/shared-host support;
- alias support.

Return `BLOCK` for hidden or widened authority.

──────────────────────────────────────────────────────────────────────────────
22. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Inspect:

- predecessor failed build attempt;
- audit-repair attempt 1;
- all target failed/superseded indexes;
- all source, result, and inventory bindings.

For every attempt record:

- exact identity;
- operation;
- first blocker;
- whether target correctness began;
- outputs;
- mutation posture;
- superseding attempt;
- contribution to final target.

Require contribution to current authority:

none

unless the current package explicitly incorporates an identity as bounded
historical evidence.

No failed attempt may contribute a current source, contract, Plan, validation
count, manifest identity, or readiness verdict.

──────────────────────────────────────────────────────────────────────────────
23. FOUR PARENT-GENERATED PERSPECTIVES
──────────────────────────────────────────────────────────────────────────────

Retain four parent-generated analytical perspectives:

analysis/perspective-contract-authority.json
analysis/perspective-adoption-lineage.json
analysis/perspective-source-plan-mutations.json
analysis/perspective-filesystem-security.json

Each must identify:

- exact operands;
- findings;
- limits;
- unresolved uncertainty;
- uninspected scope.

They are analytical projections, not independent verdict authorities.

──────────────────────────────────────────────────────────────────────────────
24. CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality.

Require:

- no candidate-repository mutation;
- no target mutation;
- no supplied-root mutation;
- no process or descriptor survivor;
- no unregistered audit-owned root;
- complete cleanup-set equality.

Do not clean or remove supplied roots.

──────────────────────────────────────────────────────────────────────────────
25. TARGET-AUDIT CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On a successful audit path finalize before terminal manifests:

- opening records;
- process and child records;
- target identity and closure;
- sole-writer adjudication;
- failed-attempt lineage;
- supersession adjudication;
- adoption and observation lineage;
- contract field map;
- Plan equivalence;
- source closure and path derivation;
- independent mutation matrix;
- capsule closure;
- security review;
- authority split;
- attempt adjudication;
- four parent perspectives;
- closing equality;
- cleanup;
- final report;
- preseal outcome;
- temporal final inventory.

Then independently generate terminal manifest A and B.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink or special object;
- no multiply linked file;
- directories 0700;
- files regular, single-link 0600;
- byte-identical manifests;
- no write after manifest closure.

On failure, retain a truthful failure capsule without success captions.

──────────────────────────────────────────────────────────────────────────────
26. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only when:

- process provenance qualifies;
- opening provenance qualifies;
- target and all supporting roots close;
- exactly one current V3 contract exists;
- exactly one current Plan V4 exists;
- failed-attempt bytes are noncurrent and nonauthoritative;
- supersession is exact and narrow;
- all nine V2 adoption rows are supported;
- OBS-05 and OBS-07 correction lineage is exact;
- V2 verdict remains BLOCK and unpromoted;
- contract and explicit nonauthority pass;
- Plan equivalence passes;
- five-source closure and 86-byte derivation pass;
- fresh independent mutation matrix passes;
- capsule closure passes;
- sensitive-material review passes;
- authority remains bounded;
- closing equality and cleanup pass;
- no acceptance-affecting finding remains.

Return BLOCK for a repairable target defect in:

- authority;
- supersession;
- adoption;
- lineage;
- contract;
- Plan equivalence;
- source closure;
- mutation resistance;
- capsule closure;
- security;
- evidence chronology.

Return REJECT only for fundamental unsoundness outside bounded repair.

Return AUDIT_PROVENANCE_MISMATCH for:

- fixed-input drift;
- process-record gap;
- child filesystem-effect gap;
- supplied-root mutation;
- closing inequality;
- cleanup-set inequality;
- terminal capsule failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
27. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Accepted bootstrap identity and authority
3. Fresh audit-root identity
4. Process and child-record posture
5. Target identity and capsule closure
6. Supporting-root identities
7. Opening-gate result
8. Sole current V3 normative writer
9. Sole current Plan V4 writer
10. Failed-attempt authority adjudication
11. Authoritative supersession result
12. V2 adoption row-by-row result
13. OBS-05 correction lineage
14. OBS-07 correction lineage
15. Complete observation-lineage result
16. V2 BLOCK preservation
17. V3 contract field map
18. Authority and nonauthority result
19. Plan V3/V4 equivalence
20. Five-source closure
21. 86-byte path derivation
22. Fresh independent mutation matrix
23. Capsule inventory and manifest closure
24. Sensitive-material and artifact findings
25. Failed/superseded attempt adjudication
26. Four parent-generated perspectives
27. Supplied-root closing equality
28. Cleanup-set result
29. Audit-capsule inventory and terminal manifests
30. Severity-ranked residual findings
31. Remaining uncertainty and nonclaims
32. Explicit confirmations

Required confirmations:

ACCEPTED_BOOTSTRAP_PACKAGE_MUTATION_NOT_PERFORMED
ACCEPTED_BOOTSTRAP_AUDIT_MUTATION_NOT_PERFORMED
TARGET_ROOT_MUTATION_NOT_PERFORMED
CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_GATE_ROOT_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_ROOT_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_ROOT_MUTATION_NOT_PERFORMED
V3_PREDECESSOR_ROOT_MUTATION_NOT_PERFORMED
PREVIOUS_BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
FAILED_REPAIR_ATTEMPT_ROOT_MUTATION_NOT_PERFORMED
EXACTLY_ONE_CURRENT_V3_NORMATIVE_WRITER
EXACTLY_ONE_CURRENT_PLAN_V4_WRITER
FAILED_ATTEMPT_NORMATIVE_BYTES_NOT_CURRENT
FAILED_ATTEMPT_PLAN_BYTES_NOT_CURRENT
AUTHORITATIVE_SUPERSESSION_EXACT
AUTHORITATIVE_SUPERSESSION_SCOPE_NARROW
V2_RAW_FAILURES_PRESERVED
V2_CORRECTION_LINEAGE_EXPLICIT
OBS_05_SUPPORT_VERIFIED
OBS_07_SUPPORT_VERIFIED
ALL_NINE_ADOPTION_ROWS_SUPPORTED
V2_BLOCK_VERDICT_NOT_PROMOTED
V3_CONTRACT_FIELD_MAP_VERIFIED
HOSTILE_SHARED_HOST_SUPPORT_EXPLICITLY_FALSE
SYMLINK_MOUNT_ALIAS_SUPPORT_EXPLICITLY_FALSE
PLAN_V3_V4_EQUIVALENCE_VERIFIED
PATH_SOURCE_CLOSURE_INCLUDES_ITOA_GO
PATH_BUDGET_86_OF_100_VERIFIED
FRESH_INDEPENDENT_MUTATION_MATRIX_PASSED
CAPSULE_CLOSURE_VERIFIED
SENSITIVE_MATERIAL_REVIEW_PASSED
RUNTIME_VALIDATION_NOT_RERUN
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
GIT_NOT_INVOKED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
NO_SUBAGENTS_CREATED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
CLEANUP_SET_EQUALITY_PASSED
```

An `ACCEPT` qualifies the exact Validation-Custody V3 package as the current
bounded documentary/evidence contract. It still does not start A6 or execute
Plan V4.

A qualifying `BLOCK` authorizes only a bounded repair of its exact concrete
findings.

An `AUDIT_PROVENANCE_MISMATCH` authorizes no target repair.
```

### Decision

Proceed with the target audit above. Do not modify the accepted bootstrap package or the V3 target before that result.

**Source:** Attached Codex `ACCEPT` report.     
**Confidence:** 0.998 that the bootstrap-package line is closed; 0.99 that the fresh V3 target audit is now the correct critical path; 0.97 that no further process-harness work is justified before that audit.
