## Assessment

The repair is ready for a fresh independent audit. The implementation stayed within the correct bounded scope:

- It added explicit `commit` and `publication` nonauthority without widening the importer’s authority.
- It formalized one 12-step bootstrap state machine and one generic commit-point rule for `completed_step_ordinal`.
- It corrected the three reported failure records to completed ordinals `6`, `8`, and `10`.
- It preserved the importer CLI, five-artifact copy boundary, root-rebinding semantics, Carrier 0002 semantics, and launcher handoff.
- Producer regression, an independent validator, two deterministic materializations, and the Carrier 0002 handoff all passed.
- The new package remained source-external, private, and manifest-closed.

One detail merits explicit pressure in the audit: the report says the 96-cell boundary matrix contains 44 supported cells, 49 unsafe or impossible cells, and one terminal-success cell. Those categories account for only 94 cells. The independent audit must reconcile all 96 cells and reject any unexplained disposition rather than accepting the aggregate statement.

The next step is exactly one fresh independent audit of the repaired package. The audit-process design must also prevent the prior all-process ledger failure: root allocation is the sole unwrapped bootstrap exception; every later local process must use the already-qualified wrapped-carrier mechanism and be represented contemporaneously.

```text
FRESH INDEPENDENT AUDIT —
VALIDATION-CUSTODY V3 BOOTSTRAP IMPORTER V1 AUDIT REPAIR

This is an independent audit of a source-external audit-process package.

Do not modify or repair the audit target.
Do not modify any supplied root.
Do not inspect the candidate repository, Strategic B source, blocked V1,
Validation-Custody V2, the V2 audit, V3 predecessor, V3 audit-repair target,
product source, or unrelated evidence.
Do not run Git.
Do not run repository tests or product code.
Do not execute Plan V3 or Plan V4.
Do not invoke any live service.
Do not use the network.
Do not stage, commit, push, install, deploy, or start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

ACCEPT qualifies only the exact repaired bootstrap-importer package and its
bounded process-materialization behavior. It grants no authority over V3,
Strategic B, the candidate repository, product behavior, publication, commit,
deployment, readiness, or A6.

──────────────────────────────────────────────────────────────────────────────
1. EXACT AUDIT TARGET
──────────────────────────────────────────────────────────────────────────────

REPAIRED_IMPORTER_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-v1-audit-repair-h585ymcr

Expected root identity:

- device/inode:
  16777234 / 179080164
- physical mode:
  0700
- expected producer verdict:
  VALIDATION_CUSTODY_V3_BOOTSTRAP_IMPORTER_AUDIT_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT
- status:
  proposed successor pending fresh independent audit

Expected repaired importer source:

source/bootstrap_importer_v1.py

- size:
  84255
- SHA-256:
  1a7032d6ade79c3c5046f922fccbf870c716ede8100abc1969da5fad580b27bd
- regular:
  true
- links:
  1
- mode:
  0600

Expected semantic contract and schema identities:

contract/bootstrap-importer-contract-v1.json

- SHA-256:
  bc495ce1b48a4b1f9276d7285fa681ae7097cc1e68af4e0173ef18bffb0b2c9d

contract/bootstrap-failure-contract-v1.json

- SHA-256:
  5767da95be59c832faa48224ad7b2b1137039dbcf114618ab2062e2af12f44ca

contract/bootstrap-result-contract-v1.json

- SHA-256:
  5898512c4140a165ad0da5b220d5eda8a59864f215c2ae857f710d4094a1e85e

schemas/bootstrap-importer-contract-v1.schema.json

- SHA-256:
  9fb850ce7782912793c068689c3b1e300c3460e3320fc9a1f2f7857d96a901b7

schemas/bootstrap-failure-v1.schema.json

- SHA-256:
  32b53b15f74b2b6887b4b05743e535dd72339075c5bbf7f777a4945cd0b7151e

schemas/bootstrap-result-v1.schema.json

- SHA-256:
  a38666f9e1fb532737fa8088085ae6a84fb86f3b0964443398c76cd7aa6a1968

schemas/authority-boundary-v1.schema.json

- SHA-256:
  155982903ef22b38d68b01200e129004f724a11bea9bbc974e9cbbae3f079f6f

Expected terminal manifest pair:

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  16245 each
- SHA-256:
  55d31fb588c030c0ad13ce24fb0902f8090ef6f6474458a30c2ebf4b81bd75c2
- required:
  byte-identical

Expected terminal closure:

- 92 represented entries;
- 12 represented directories including root;
- 80 represented nonmanifest regular files;
- 82 physical regular files including both manifests;
- exactly two manifest self-exclusions;
- no retained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

The implementation report states that the temporal final inventory contains
91 entries: 12 directories and 79 regular files, excluding itself and both
future manifests. Independently locate, authenticate, and bind the exact
temporal-inventory path, size, and SHA-256 from the live package and manifest
closure. Do not invent an identity absent from the supplied report.

──────────────────────────────────────────────────────────────────────────────
2. IMMUTABLE INPUTS AND LINEAGE
──────────────────────────────────────────────────────────────────────────────

PREDECESSOR_IMPORTER_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-v1-s5l048qh

Expected root identity:

- device/inode:
  16777234 / 179051602
- mode:
  0700

Expected predecessor source:

source/bootstrap_importer_v1.py

- size:
  66362
- SHA-256:
  f7f5a6f308e9a7a4af043a4c64b95c854f1d433787308c06647d5318452fe6ee

Expected predecessor terminal identities:

closeout/final-evidence-inventory-v1.json

- size:
  8815
- SHA-256:
  2000c0f9bd52bf4a98cf2d74091679334259b1f1759dbf3b245224a236a02129

manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

- size:
  8937 each
- SHA-256:
  336436ce9686344735fd5fbc0a4793d3b78e2949c32d41980e2ab7493a6e9d0f
- required:
  byte-identical

BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-bootstrap-importer-independent-audit-_p93agae

Expected root identity:

- device/inode:
  16777234 / 179066467

Treat its primary `AUDIT_PROVENANCE_MISMATCH` verdict as nonqualifying audit
process evidence.

Consume only the authenticated target-level findings:

1. closed importer contract omitted explicit commit nonauthority;
2. generated authority boundary omitted explicit commit and publication
   nonauthority;
3. fixed-environment failure recorded completed step 5 rather than 6;
4. normalization-proof failure recorded 7 rather than 8;
5. request-retention failure recorded 9 rather than 10.

At minimum authenticate:

closeout/final-audit-report-terminal.json
analysis/process-ledger-gap-terminal.json
auditors/direct-auditor-schedule-v2.json
validation/fresh-independent-82-case-matrix.json
causals/failure-atomicity-causals.json
analysis/root-layout-artifact-adjudication-v2.json
analysis/security-sensitive-material-review-v2.json
closeout/supplied-root-closing-equality-v2.json
closeout/fixture-cleanup-v2.json
closeout/terminal-audit-manifest-a-v1.json
closeout/terminal-audit-manifest-b-v1.json

Expected terminal audit manifest pair:

- size:
  27073 each
- SHA-256:
  df83247be3605f63247b77a689a5d830db975bb72696d69d05ee21311a324d76
- required:
  byte-identical

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

Expected root identity:

- device/inode:
  16777234 / 179032804
- mode:
  0700

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

Expected root identity:

- device/inode:
  16777234 / 179045387
- mode:
  0700

Use these two roots only for importer process-materialization and handoff
causals. Do not re-audit their substantive qualification except as necessary
to bind exact immutable inputs.

──────────────────────────────────────────────────────────────────────────────
3. AUDIT PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

Read this complete prompt before invoking a tool.

Then state exactly:

AUDIT_EPOCH_START

Carrier 0001 is the sole unwrapped bootstrap exception.

Carrier 0001 may only:

- allocate the fresh audit root;
- retain and fsync bootstrap-start and bootstrap-outcome records;
- verify pinned Python;
- verify and copy the already-qualified wrapped-carrier process mechanism;
- create the fresh process launch contract and self-check material;
- emit the fresh audit-root path.

After Carrier 0001, every local process launched by the parent— including
inventorying, parsing, static inspection, causals, validation, scanning,
cleanup, and closeout—must execute through the exact qualified launcher and
mode-0600 wrapper.

For every wrapped parent carrier retain:

- request;
- constructed-launch record;
- phase-start;
- phase-outcome;
- payload identity;
- launcher identity;
- wrapper identity;
- interpreter identity;
- fixed environment;
- submitted cwd;
- platform-reported disposition;
- child ordinal range;
- generated artifacts.

Use:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Every external child process launched within a payload must use one
audit-owned child recorder with:

- contemporaneous start-before-spawn record;
- full argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit or signal;
- reaping;
- descriptor closure;
- contiguous child ordinal.

No post-bootstrap direct shell, Python, utility, test, scan, or cleanup process
may bypass the wrapped carrier and child recorder.

Any unwrapped post-bootstrap local process or process-record gap requires:

AUDIT_PROVENANCE_MISMATCH

Direct auditor interactions are not local subprocesses. Record them separately
in a direct-auditor interaction index.

──────────────────────────────────────────────────────────────────────────────
4. FRESH AUDIT ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-v3-bootstrap-importer-audit-repair-independent-audit-

Retain at minimum:

opening/
auditors/
analysis/
validation/
causals/
provenance/
fixtures/
closeout/
private/

No retained empty directory is permitted at close.

All retained directories must be mode 0700.
All retained files must be regular, single-link mode 0600.
No symlink, special object, or multiply linked file is permitted.

──────────────────────────────────────────────────────────────────────────────
5. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Verify complete repaired-package membership and both manifests.
2. Bind the exact temporal final inventory.
3. Verify predecessor package closure.
4. Verify blocking-audit closure and consumed finding identities.
5. Verify the qualified launcher and import-reconciliation roots.
6. Verify pinned Python.
7. Verify the repair package’s lineage and proposed-supersession records.
8. Retain complete lstat/no-follow opening inventories.
9. Confirm the audit root aliases no supplied root.
10. Confirm no supplied root was modified during bootstrap.
11. Complete wrapped-process and child-recorder self-causals:
    - missing executable / ENOENT;
    - `/usr/bin/true` / exit 0;
    - stream hashes;
    - reaping;
    - descriptor closure.

Stop with AUDIT_PROVENANCE_MISMATCH on any opening identity, membership,
manifest, mode, type, link, lineage, process, or alias mismatch.

Do not start auditors or target correctness work until the opening gate passes.

──────────────────────────────────────────────────────────────────────────────
6. FOUR DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance qualifies:

- Start Auditors 1–3 concurrently.
- Start Auditor 4 only after the first of Auditors 1–3 completes.
- Do not retry a completed auditor.
- No auditor may create a nested agent.

Auditor 1 — authority and contract

Inspect:

- complete repaired importer contract;
- failure and result contracts;
- all schema projections;
- generated authority-boundary semantics;
- classification, authority, and nonauthority;
- version preservation;
- predecessor/repaired semantic delta.

Auditor 2 — step state machine and failure custody

Inspect:

- ordered 12-step model;
- commit points;
- generic transition mechanism;
- completed/failed ordinal semantics;
- all three reported causals;
- complete step-boundary matrix;
- test-hook or failure-injection reachability.

Auditor 3 — validation, determinism, and handoff

Inspect:

- predecessor 56-case suite;
- repaired 46-case suite;
- producer results;
- independent 52-case validator;
- deterministic materializations;
- Carrier 0002 handoff;
- failed/superseded attempts.

Auditor 4 — provenance, security, filesystem, and artifacts

Inspect:

- every package object;
- manifests and final inventory;
- lineage;
- process records;
- cleanup;
- modes and links;
- sensitive-material posture;
- source-level network/Git/shell/subprocess/target access.

Auditors:

- run no Git;
- execute no test or product command;
- use no network;
- write no file;
- mutate no supplied root;
- create no nested agent.

Retain exact prompts, authorized operands, reports, timing/order, findings,
uncertainty, and uninspected scope.

──────────────────────────────────────────────────────────────────────────────
7. EXACT SOURCE AND DELTA AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently compare the complete predecessor and repaired importer packages.

Separate:

- semantic implementation files;
- validation-only files;
- lineage/provenance files;
- closeout artifacts.

Require the semantic touched set to match the implementation report:

source/bootstrap_importer_v1.py
contract/bootstrap-importer-contract-v1.json
contract/bootstrap-failure-contract-v1.json
contract/bootstrap-result-contract-v1.json
schemas/bootstrap-importer-contract-v1.schema.json
schemas/bootstrap-failure-v1.schema.json
schemas/bootstrap-result-v1.schema.json
schemas/authority-boundary-v1.schema.json

Identify every additional semantic byte difference.

Reject unexplained semantic scope expansion.

Verify that these remain unchanged in semantics:

- importer CLI;
- qualified-package manifest grammar;
- exact reconciliation-verdict lookup;
- five-artifact copy boundary;
- auxiliary-record roles and schemas except explicit authority closure;
- exact twelve-pointer root rebinding;
- normalization;
- Carrier 0002 payload and request;
- stdout/stderr contract;
- process exit classes;
- target-inspection prohibition;
- no-network and no-Git posture.

──────────────────────────────────────────────────────────────────────────────
8. AUTHORITY AND NONAUTHORITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Require the closed nonauthority set to include exactly the package’s governed
dimensions and explicitly include:

- candidate-repository;
- source;
- product;
- runtime;
- deployment;
- publication;
- commit;
- v3-target-correctness;
- v3-audit-verdict;
- readiness;
- a6.

Require all to be explicitly nonauthoritative.

Require the positive authority set to remain exactly:

- process-input-verification;
- bootstrap-provenance;
- process-artifact-materialization.

Require exact agreement among:

- importer contract;
- contract schema;
- generated authority-boundary record;
- result contract/schema;
- failure contract/schema where authority fields are present;
- successful materialization outputs;
- failed materialization outputs where authority fields are present;
- implementation classification.

Reject:

- omitted commit;
- omitted publication;
- any authority value true;
- unknown authority dimension;
- contract/record disagreement;
- generated record narrowing;
- generated record widening;
- broad process-only prose substituting for explicit fields;
- duplicate synonym fields with inconsistent semantics.

Construct independent audit-only mutations for each mechanism.

──────────────────────────────────────────────────────────────────────────────
9. ORDERED STEP MODEL
──────────────────────────────────────────────────────────────────────────────

Require exactly twelve steps in this order:

1. `allocate-root-and-retain-bootstrap-start`
2. `validate-cli-contract-and-create-layout`
3. `verify-inputs-and-retain-verification-records`
4. `copy-exact-process-artifacts`
5. `reverify-copied-process-artifacts`
6. `retain-copied-launcher-identity`
7. `retain-fixed-environment`
8. `retain-root-bound-launch-contract`
9. `retain-root-rebinding-proof`
10. `retain-carrier-0002-payload`
11. `retain-carrier-0002-request`
12. `retain-bootstrap-success`

Independently verify for every step:

- stable ID;
- ordinal;
- operation;
- prerequisites;
- commit point;
- complete persistent artifact set;
- whether it advances completed state;
- next permitted step.

Require:

`completed_step_ordinal`

to mean exactly the greatest ordinal whose defined commit point completed
successfully before the failure record was created.

Require separate:

- failed step ordinal;
- failed step ID;
- exact failed operation;
- exception or injected failure;
- exact partial artifacts;
- next-action authorization.

Inspect source for one generic monotonic state-transition mechanism.

Reject:

- fixed `failed ordinal - 1`;
- label-specific ordinal exceptions;
- advancement before commit;
- duplicate advancement;
- regression;
- advancement after failure;
- artifact-derived guesswork inconsistent with the closed step table.

──────────────────────────────────────────────────────────────────────────────
10. THREE REQUIRED FAILURE CAUSALS
──────────────────────────────────────────────────────────────────────────────

Using audit-owned fresh fixtures, independently reproduce:

A. Failure during Step 7: `retain-fixed-environment`

Require:

- completed step:
  6;
- failed step:
  7;
- exact step-6 artifacts complete;
- step-7 commit not complete;
- no step-8 artifact;
- target inspection false.

B. Failure during Step 9: `retain-root-rebinding-proof`

Require:

- completed step:
  8;
- failed step:
  9;
- exact step-8 artifacts complete;
- step-9 commit not complete;
- no step-10 artifact.

C. Failure during Step 11: `retain-carrier-0002-request`

Require:

- completed step:
  10;
- failed step:
  11;
- exact step-10 artifacts complete;
- step-11 commit not complete;
- no step-12 artifact.

Independently reproduce the predecessor behavior or authenticate the exact
predecessor failure records before adjudicating the repair.

Retain byte-level predecessor/repaired comparisons.

──────────────────────────────────────────────────────────────────────────────
11. COMPLETE 96-CELL BOUNDARY LEDGER
──────────────────────────────────────────────────────────────────────────────

Independently inspect the reported 96-cell step/boundary ledger.

The implementation report states:

- 96 cells classified;
- 44 supported cell references passed;
- 49 unsafe or impossible internal descriptor boundaries were nonclaimed;
- Step 12 postcommit is terminal success.

Those stated categories account for only 94 cells.

Do not accept the aggregate claim without resolving the arithmetic.

Require:

1. exactly 96 unique step/boundary cells;
2. every cell assigned exactly one closed disposition;
3. no duplicate or omitted cell;
4. disposition counts that sum exactly to 96;
5. a source-backed explanation for every nonexecuted cell;
6. no unsupported cell described as passed;
7. no safe injectable cell silently classified impossible;
8. no impossible internal boundary used as acceptance evidence.

Closed disposition values must distinguish at least:

- executed-pass;
- executed-expected-failure;
- structurally-impossible;
- unsafe-to-inject-and-explicitly-nonclaimed;
- terminal-success;
- not-applicable-by-step-contract.

Identify the two cells not explained by the implementation report’s summary,
or prove that the summary collapsed additional explicit categories.

Any unexplained cell is a blocking evidence defect.

──────────────────────────────────────────────────────────────────────────────
12. FAILURE-INJECTION REACHABILITY
──────────────────────────────────────────────────────────────────────────────

Discover every mechanism used to inject failure:

- module global;
- callback;
- hook;
- environment variable;
- CLI option;
- fixture substitution;
- monkeypatch;
- imported test helper;
- source rewrite;
- filesystem fault;
- wrapper around I/O.

For each mechanism determine:

- production default;
- ordinary CLI reachability;
- environment reachability;
- request reachability;
- copied-input reachability;
- whether normal execution rejects a nondefault value;
- whether the hook can suppress or reorder validation;
- whether test execution used only audit-owned or implementation-owned exact
  source copies;
- whether source identity remained bound.

Require no hidden production route to an audit-only failure hook.

A reachable authority-bearing test hook blocks acceptance.

──────────────────────────────────────────────────────────────────────────────
13. PRODUCER REGRESSION
──────────────────────────────────────────────────────────────────────────────

Run, through the wrapped process mechanism:

- the complete predecessor 56-case suite;
- the complete repaired 46-case suite;
- the retained independent 52-case validator;
- any source-identity or schema checks required by the package.

Before execution, independently discover and pin:

- exact case names;
- counts;
- uniqueness;
- expected reasons;
- no skip behavior.

Do not trust report counts alone.

Require:

- every predecessor mechanism still passes;
- every repaired mechanism passes;
- zero false acceptance;
- exact mechanism-specific reasons;
- no hidden platform branch;
- no missing or renamed case;
- no failed-attempt output counted.

──────────────────────────────────────────────────────────────────────────────
14. FRESH AUDIT-OWNED MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Construct a fresh independent matrix without importing producer helpers or
using producer fixtures as the case generator.

Cover at minimum:

A. Authority

- each required nonauthority field omitted;
- each set true;
- unknown field;
- contract/record mismatch;
- generated narrowing;
- generated widening;
- process-only prose without explicit fields.

B. Step model

- missing step;
- duplicate step;
- reordered step;
- wrong prerequisite;
- wrong commit point;
- wrong artifact set;
- duplicate ordinal;
- nonmonotonic transition;
- completed-state advance before commit;
- fixed `failed - 1` behavior;
- failed-step ID/ordinal mismatch;
- inaccurate partial-artifact inventory.

C. The three reported causals

- expected `6/7`;
- expected `8/9`;
- expected `10/11`.

D. Copy and rebinding invariants

- extra copied qualification result;
- missing copied process artifact;
- stale auxiliary record;
- omitted rebinding pointer;
- extra pointer;
- non-root semantic change;
- normalized mismatch;
- stale qualification-root path.

E. Carrier 0002

- invariant request override;
- wrong payload identity;
- wrong wrapper-SHA handling;
- whole-map environment oracle;
- target-inspection true.

F. Failure atomicity

- success result on failure;
- root not retained;
- missing bootstrap start;
- missing failure outcome;
- progression after failure;
- retry inside failed root;
- overwrite.

Pin exact audit case names and expected reasons.

Require zero false acceptance.

──────────────────────────────────────────────────────────────────────────────
15. TWO FRESH MATERIALIZATIONS
──────────────────────────────────────────────────────────────────────────────

Execute the exact repaired importer twice into distinct audit-owned roots.

For each retain:

- exact argv;
- cwd;
- explicit environment;
- stdout;
- stderr;
- exit;
- root locator;
- complete inventory;
- bootstrap start/outcome/result;
- copied artifacts;
- generated authority boundary;
- launcher identity;
- fixed-environment record;
- root-bound launch contract;
- rebinding proof;
- Carrier 0002 payload and request.

Require:

- distinct physical roots;
- one exact root line;
- empty handled stderr;
- exit 0;
- copied bytes exact;
- normalized generated records equal;
- normalized launch contracts equal;
- normalized results equal;
- payload source equal;
- normalized requests equal;
- target inspection false;
- Carrier 0002 not yet executed.

──────────────────────────────────────────────────────────────────────────────
16. IMPORTER-TO-LAUNCHER HANDOFF
──────────────────────────────────────────────────────────────────────────────

Use exactly one successful audit-owned materialization for a bounded no-target
handoff causal.

Invoke Carrier 0002 through:

pinned Python
→ copied qualified launcher
→ same-PID execve
→ pinned Python
→ copied mode-0600 wrapper
→ generated self-check payload

Require:

- request admitted;
- constructed-launch record complete;
- wrapper parser admission;
- phase start/outcome complete;
- expected-wrapper SHA exactly once and exact;
- same PID;
- constructed environment exact;
- every contract-owned observed value exact;
- additional observed environment keys diagnostic only;
- payload and wrapper success;
- no child process;
- target inspection false.

Do not execute Carrier 0002 from the second materialization.

──────────────────────────────────────────────────────────────────────────────
17. SECURITY AND STATIC SOURCE REVIEW
──────────────────────────────────────────────────────────────────────────────

Inspect the complete repaired source and package for:

- network APIs;
- subprocess or shell use in importer source;
- Git;
- candidate or target paths;
- broad Downloads scanning;
- latest/prefix selection;
- existing-root adoption;
- symlink traversal;
- overwrite;
- unsafe permissions;
- inherited environment disclosure;
- secret-bearing output;
- private keys;
- cloud/API tokens;
- bearer/JWT/Vault material.

Do not emit matched sensitive payload content.

Require no authority dimension to become implicit, omitted, or true.

──────────────────────────────────────────────────────────────────────────────
18. FAILED AND SUPERSEDED ATTEMPTS
──────────────────────────────────────────────────────────────────────────────

Inspect every repair-package attempt and predecessor attempt referenced by
lineage.

Require:

- failed attempts remain distinct;
- no failed result supplies a passing count or identity;
- the reported test-harness defect is classified correctly;
- no failed source is presented as final;
- no overwritten artifact;
- proposed supersession is bounded to:
  - nonauthority closure;
  - failure-step custody;
  - related schemas, tests, and evidence.

The repaired package remains proposed pending this audit.

──────────────────────────────────────────────────────────────────────────────
19. PACKAGE CLOSURE AND INVENTORY CHRONOLOGY
──────────────────────────────────────────────────────────────────────────────

Independently inspect both manifest generators.

Reproduce both manifests byte-for-byte.

Verify:

- exact 12 directories;
- exact 80 nonmanifest regular files;
- exact 92 represented entries;
- exactly two manifest self-exclusions;
- no unexplained object;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600.

Locate and bind the temporal final inventory.

Verify:

- its exact exclusions;
- it was finalized before the two terminal manifests;
- it contains no unstable directory size or link-count authority unless the
  contract explicitly permits them;
- both manifests subsequently cover it;
- no artifact was written after manifest closure.

──────────────────────────────────────────────────────────────────────────────
20. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all auditors and parent work:

- repeat complete inventories for repaired importer, predecessor importer,
  blocking audit, qualified launcher, and import reconciliation roots;
- verify pinned Python unchanged;
- verify all supplied roots equal opening;
- verify every wrapped carrier and child record complete;
- verify no child, process, or descriptor survivor;
- retain complete inventories of every audit-owned fixture;
- remove only audit-owned fixture and private roots;
- perform two fresh `lstat` calls for every removed root;
- require ENOENT twice.

Do not mutate or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
21. FINAL AUDIT CAPSULE
──────────────────────────────────────────────────────────────────────────────

Retain:

- opening inventories;
- wrapped-carrier and child-process records;
- four auditor reports;
- exact repaired-source identity;
- predecessor/repaired delta;
- authority audit;
- step-state audit;
- 96-cell reconciliation;
- hook-reachability analysis;
- producer regression;
- fresh mutation matrix;
- two materializations;
- handoff causal;
- security review;
- attempt adjudication;
- closing equality;
- cleanup;
- final report;
- final inventory;
- two independent covering manifests.

Use two independently implemented lstat/no-follow manifest generators.

Require:

- root and every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no unexplained empty directory;
- no symlink;
- no special object;
- no multiply linked regular file;
- directories mode 0700;
- files regular, single-link mode 0600;
- byte-identical manifests.

Use a final wrapped carrier for closeout.

Exactly two temporal self-exclusions are permitted in the final audit
inventory:

1. the inventory itself;
2. its final wrapper-created phase-outcome record.

No later filesystem-writing carrier is permitted.

──────────────────────────────────────────────────────────────────────────────
22. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- opening and closing provenance qualify;
- every post-bootstrap process is contemporaneously recorded;
- repaired-package closure qualifies;
- semantic scope is exact;
- commit and publication nonauthority are explicit and consistent;
- all authority records agree;
- the 12-step model is complete and monotonic;
- the three reported causals produce completed ordinals 6, 8, and 10;
- all 96 boundary cells are completely and coherently dispositioned;
- no failure hook is production-reachable;
- producer regression passes;
- fresh independent matrix passes;
- two materializations pass deterministically;
- Carrier 0002 handoff passes;
- security review passes;
- four auditors complete;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable importer, authority, step-state, causal,
validation, lineage, artifact, or evidence defect.

Return REJECT only for fundamental unsoundness outside the bounded repair
scope.

Return AUDIT_PROVENANCE_MISMATCH for:

- any unwrapped post-bootstrap local process;
- missing phase or child-process record;
- supplied-input drift or mutation;
- missing fixed input;
- opening/closing inequality;
- audit-capsule closure failure.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
23. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh audit-root identity
3. Repaired-package identity and closure
4. Immutable-input identities
5. Complete process-record posture
6. Four auditor identities, schedule, findings, and limits
7. Exact repaired-source identity
8. Predecessor/repaired semantic delta
9. Authority and nonauthority adjudication
10. Generated authority-boundary adjudication
11. Ordered 12-step model
12. Completed-step semantics
13. Three required failure causals
14. Complete 96-cell disposition and arithmetic
15. Failure-hook reachability
16. Producer regression
17. Fresh independent mutation matrix
18. Two fresh materializations
19. Carrier 0002 handoff
20. Security and sensitive-material findings
21. Failed/superseded-attempt adjudication
22. Package manifest and inventory chronology
23. Supplied-root closing equality
24. Fixture cleanup and ENOENT observations
25. Audit-capsule inventory and manifests
26. Severity-ranked findings
27. Minority findings and parent resolution
28. Remaining uncertainty and nonclaims
29. Explicit confirmations

Required confirmations:

REPAIRED_IMPORTER_PACKAGE_MUTATION_NOT_PERFORMED
PREDECESSOR_IMPORTER_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_PACKAGE_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
REPAIRED_SOURCE_HASH_INDEPENDENTLY_BOUND
SEMANTIC_REPAIR_SCOPE_EXACT
IMPORTER_CLI_NOT_CHANGED
COPY_BOUNDARY_NOT_CHANGED
ROOT_REBINDING_SEMANTICS_NOT_CHANGED
CARRIER_0002_SEMANTICS_NOT_CHANGED
COMMIT_AUTHORITY_EXPLICITLY_FALSE
PUBLICATION_AUTHORITY_EXPLICITLY_FALSE
CONTRACT_AND_AUTHORITY_RECORD_NONAUTHORITY_SETS_EQUAL
ORDERED_TWELVE_STEP_MODEL_VERIFIED
COMPLETED_STEP_ORDINAL_SEMANTICS_VERIFIED
FIXED_ENVIRONMENT_FAILURE_COMPLETED_STEP_6
NORMALIZATION_FAILURE_COMPLETED_STEP_8
REQUEST_FAILURE_COMPLETED_STEP_10
ALL_96_BOUNDARY_CELLS_ACCOUNTED_FOR
NO_PRODUCTION_REACHABLE_FAILURE_HOOK
PRODUCER_REGRESSION_PASSED
FRESH_INDEPENDENT_MATRIX_PASSED
TWO_FRESH_MATERIALIZATIONS_PASSED
IMPORTER_TO_LAUNCHER_HANDOFF_PASSED
ALL_POST_BOOTSTRAP_LOCAL_PROCESSES_WRAPPED
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_TARGET_CONTENT_INSPECTED
NO_CANDIDATE_GIT_INVOKED
NO_NETWORK_CONTACT
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
A6_NOT_STARTED
NO_NESTED_SUBAGENTS
FULL_V3_AUDIT_NOT_STARTED
```

After an `ACCEPT`, the next step is the fresh full Validation-Custody V3 independent audit consuming the exact accepted repaired-importer package. No additional process-infrastructure implementation tranche is justified absent a new audit finding.

**Source:** Codex’s bootstrap-importer audit-repair implementation report above.

**Confidence:** 0.99 that the package is ready for independent audit; 0.98 that the remaining substantive risk is concentrated in step-state evidence and nonauthority consistency; 0.97 that the process-ledger rule above prevents recurrence of the prior audit mismatch.
