The stop is correct. The frozen A5P contract conflated two different lifetimes:

- **Custody-record lifetime:** the runner must retain authoritative ownership and disposition evidence through closeout.
- **Open-descriptor lifetime:** the runner must not keep a redundant slave descriptor open after the child has safely inherited its slave endpoint.

A PTY master reaches EOF only after **every** slave reference is closed. The repository helper closes its slave and then waits for EOF on the master; the runner’s retained slave therefore creates a deterministic circular wait:

```text
helper waits for master EOF
        ↓
EOF waits for runner’s slave to close
        ↓
runner waits for process-group completion
        ↓
process group cannot complete because helper is waiting
```

The correct design is not “weaken custody” or “close something opportunistically.” It is:

> **Retain the immutable custody/disposition record until closeout, but dispose the runner-owned slave alias immediately after a proven handoff boundary and before waiting for process-group completion.**

The child-owned inherited slave and the runner-owned allocation alias must be modeled as distinct ownership epochs. The runner alias reaches a terminal closed disposition; the record remains. The process group then owns whatever child descriptor was actually transferred.

I would not resume or seal the current A5P child. Its failed candidate and kernel causal are valuable negative evidence, but the sealed contract itself is now wrong. Before another implementation attempt, freeze the exact handoff acknowledgment and lifecycle semantics. That avoids replacing one deadlock with a premature-close race.

## Next gate: A5P2 custody-contract reconciliation

Pass this to Codex:

```text
Objective

Perform a parent-only, read-only Repair 10I-A5P2 contract reconciliation.

The sealed A5P reconnaissance contract contains a lifecycle defect:

- it requires the runner to retain the original PTY pair until process-group
  completion;
- the repository helper closes its slave endpoint and waits for EOF on the
  master;
- the runner-retained slave prevents EOF;
- the helper cannot finish;
- the runner therefore cannot observe process-group completion.

Freeze a corrected PTY handoff, ownership, disposition, EOF, cleanup, private
schema, touched-file, causal-test, and restart contract.

Do not implement the correction in this turn.

Do not modify repository source.
Do not modify the sealed A5S successor.
Do not modify the sealed A5P reconnaissance.
Do not resume, modify, overwrite, or seal the failed A5P implementation child.
Do not resume or seal the failed A5T child.
Do not implement A5C.
Do not restart the A6 policy-evidence refresh.
Do not implement A6 or start B6.
Do not create a new successor implementation child, snapshot, ZIP, handoff, or
capture child.
Do not stage, commit, push, install, invoke a live route, contact a remote
host, or execute Linux binaries.

No subagents. This is one bounded parent-only source/evidence reconciliation.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Sealed A5S successor

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5s-successor-closure-e260e1bb5ac4

Sealed A5P reconnaissance

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-pty-recon-ab646e5a0e66

Failed and unsealed A5P implementation

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5p-successor-closure-ab646e5a0e66

Failed and unsealed A5T child

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a5t-test-fixture-closure-e260e1bb5ac4

Failed and unsealed A6 policy-evidence refresh

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a6-policy-evidence-a5s-e260e1bb5ac4

## 1. Mandatory opening and closing gates

Require exact repository identity:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  ab646e5a0e66a30c00ca405ab43fbf6903224043
- repository inventory:
  c06fda4cd2f706ea9f739fc1050434126cc04dd64d5a93de546345081617f0d3
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Require the current repository delta from sealed A5 to remain exactly:

1.
remote_alpha_operator_test.go

2.
es/runtimehelper/supervisor_test.go

No additions, deletions, renames, or mode changes.

Require exact sealed A5S:

- manifest SHA-256:
  57a3b060633348f125933b1b577972ae2759256e776745d3ab95cf3a6829ee4f
- payloads:
  271
- source T:
  983943e612dd4d48ca4f0fabbc48ad51909c2e11
- source inventory:
  799bf5e9bac3849e338adf16901d2f2debeb53d07dabb5108547e6c29ed01c8a
- members:
  12

Require exact sealed A5P reconnaissance:

- manifest SHA-256:
  1a1d3362886deb9b5b8e7358bf711af191f358faa164c0a3c58d7f7539042550
- payloads:
  148
- directories including root:
  7

Require complete member verification of:

- findings/reconnaissance-report-v1.md
- findings/successor-capability-contract-v1.json
- probes/probe-matrix-summary-v2.json
- the direct `/dev/ptmx` denial;
- the brokered PTY positive;
- the unrelated-terminal denial;
- cleanup and absence records.

Require the failed A5P child to remain present, unsealed, and byte-exact.

Bind its candidate identity:

- source T:
  c9831fd4c3365b8e47e5174ea6177ba4d8894d57
- inventory:
  b4d5b80e1719a80a6fb2b164ccffb99bec279c04cc3166369b9e97d74ecbcce3

Require exact verification of:

- its A/B hard-gate result;
- the bounded current-A5T causal;
- the conflict report:
  findings/bounded-current-a5t-custody-contract-conflict-v1.md
- the kernel causal:
  findings/pty-eof-retained-slave-causal-v1.json
- absence of a manifest and detached digest.

Require the failed A5T and failed A6-refresh children to remain unsealed and
unchanged.

Repeat all checks at closeout.

Stop on any mismatch:

REPAIR10I_A5P2_RECONNAISSANCE_BASELINE_MISMATCH

## 2. Exact conflict recovery

Recover with exact source and evidence references:

1. The sealed A5P contract clause requiring the original PTY pair to remain
   open until process-group completion.
2. Every implementation path that retains the runner-owned slave.
3. The repository helper that:
   - closes its own slave;
   - reads the master until EOF;
   - cannot finish while another slave reference remains open.
4. The bounded integration causal showing the deadlock.
5. The independent kernel causal proving EOF appears after the retained slave
   is released.
6. Every launch, transfer, acknowledgment, readiness, close-receipt, process,
   output-worker, and terminal-reconciliation mechanism already present in the
   candidate.
7. Every alias of the PTY master and slave in:
   - runner locals;
   - resource structs;
   - exec.Cmd;
   - inherited descriptor tables;
   - child setup;
   - output workers;
   - deferred cleanup;
   - fallback cleanup.

Distinguish evidence from inference. State where inspection stops.

## 3. Governing correction

Adopt this governing distinction unless exact source disproves it:

### Custody-record lifetime

The immutable PTY custody and disposition record remains acceptance-bearing
through:

- allocation;
- transfer;
- child acknowledgment;
- parent-alias disposal;
- command execution;
- process-group completion;
- child-resource release;
- final cleanup;
- external qualification.

### Descriptor-open lifetime

A runner-owned descriptor remains open only while its operational role requires
it.

Custody does not require a redundant live alias.

The runner-owned original slave must not remain open merely to preserve
custody evidence after the child owns an independently inherited slave
descriptor.

## 4. Required ownership model

Freeze distinct generations and owners for at least:

1. runner-allocated master;
2. runner-allocated slave;
3. child-inherited master, when the declared role transfers one;
4. child-inherited slave;
5. runner output worker or terminal worker borrow;
6. child process/session/group epoch;
7. literal slave-device ioctl grant;
8. every duplicate or temporary setup descriptor.

A transfer must not reuse one ownership record for both the parent alias and
the child-owned descriptor.

The state machine must distinguish:

```text
allocated
→ identity-attached
→ transfer-prepared
→ child-inherited-and-acknowledged
→ parent-alias-disposing
→ parent-alias-closed
→ child-active
→ child-released/process-complete
→ final-accounting-complete
```

Failure states must be explicit and terminal.

Determine whether a kernel-duplicated child descriptor can be identified
independently at the required granularity. If it cannot, freeze the strongest
honest transfer evidence and state the limit.

## 5. Exact handoff boundary

Determine which existing event can safely authorize closing the runner-owned
slave alias.

Evaluate separately:

A. successful `exec.Cmd.Start`;
B. existing launch-sync acknowledgment;
C. child acknowledgment that inherited descriptor identities and terminal
   setup are complete;
D. repository-helper close receipt;
E. another existing exact event.

The selected boundary must prove, before the parent alias closes:

- child process identity is established;
- intended inherited descriptor numbers exist;
- inherited descriptor role/count is correct;
- controlling-terminal/session/process-group setup succeeded where required;
- no launch/setup error remains pending;
- the child can no longer lose the descriptor because of parent alias closure.

Do not select process-group completion; that is the deadlocking boundary.

Prefer an already implemented acknowledgment when sufficient.

If no existing mechanism proves safe transfer, determine the exact bounded
sideband acknowledgment required and its touched-file implications.

Do not invent a caption-only acknowledgment. It must be derived from an
observable launch/setup event and participate in terminal reconciliation.

## 6. Corrected lifetime rule

Freeze a replacement for the erroneous sealed clause.

The intended direction is:

> Retain the custody record through process-group completion, but close the
> runner-owned original slave exactly once after successful inherited-descriptor
> and terminal-setup acknowledgment and before waiting for process-group
> completion or master EOF.

Also freeze:

- whether the runner-owned master remains open, and for which exact role;
- which side drains terminal output;
- whether the repository helper or runner owns the master EOF read;
- when the child-owned slave is expected to close;
- how child process exit supplies final release evidence;
- how descriptor closure and worker completion are ordered.

A runner-owned slave alias that remains open past the selected transfer
boundary must be a qualification-blocking resource leak.

## 7. Failure semantics

Freeze behavior for:

- pair allocation failure;
- partial allocation;
- child start failure;
- acknowledgment failure;
- wrong inherited FD;
- wrong device/inode/type;
- wrong PTY role/count;
- controlling-terminal setup failure;
- process-group setup failure;
- parent-slave close failure;
- parent-slave close EINTR;
- stale/reused FD;
- child exits before acknowledgment;
- child closes slave before acknowledgment;
- child never closes its slave;
- master EOF before expected;
- master EOF never arrives;
- output worker failure;
- process timeout;
- signal failure;
- Wait uncertainty;
- repeated cleanup entry;
- late resource-ledger or terminal-record failure.

For each state specify:

- whether the process group is terminated;
- which later cleanup continues;
- exact close cardinality;
- whether any close is retried;
- how actual causes are retained;
- whether qualification can remain true.

A failed acknowledgment or uncertain parent-alias close must never result in a
qualifying command.

## 8. EOF and deadlock invariants

Freeze explicit invariants:

1. Master EOF is not expected while any intended slave owner remains live.
2. The runner must not create an unintended additional slave owner.
3. After the child/helper closes its final intended slave, the master reader
   must receive EOF within a bounded interval.
4. A retained parent slave mutant must reproducibly prevent EOF and be detected.
5. Releasing the parent alias before proven transfer must be detected as an
   invalid early close.
6. Duplicate inherited slave aliases must be rejected.
7. Process-group completion must not be a prerequisite for closing the
   runner-owned slave alias.
8. Parent-alias closure must not invalidate the child-owned slave.

## 9. Schema/versioning adjudication

Recover the complete private schema set introduced by the failed A5P
candidate.

Determine which records changed meaning because:

- parent and child PTY ownership are now distinct;
- transfer acknowledgment is acceptance-bearing;
- parent-slave disposition occurs before process completion;
- resource ledgers must retain a closed parent owner plus a live child owner;
- EOF and process-completion ordering are explicit.

The failed A5P candidate is unsealed and non-authoritative, but the sealed A5P
reconnaissance contract is being amended.

Freeze a complete A5P2 active schema dialect. Do not partially reuse an
acceptance-bearing A5P schema whose meaning has changed.

Historical A5S and failed A5P records may remain parseable only as explicitly
historical/nonqualifying evidence.

Report exact proposed schema identifiers and every producer/consumer requiring
change.

## 10. Exact touched-file freeze

Recover:

- the sealed A5P reconnaissance touched-file array;
- the actual failed A5P candidate delta;
- every source file required by the corrected lifecycle and schema.

Freeze the minimal A5P2 successor touched-file set.

Do not assume it equals the failed A5P set.

State whether any change is required to:

- repository source;
- A5T test source;
- fixture main;
- runner main;
- semantic main;
- comparator main;
- envelope runner;
- envelope source;
- envelope semantic logic;
- envelope tests;
- FORMAT.md;
- golden files;
- go.mod.

Repository source must remain unchanged in A5P2.

If a thirteenth successor member or new dependency would be required, return
the blocked verdict.

## 11. Mandatory causal matrix

Freeze exact tests for:

### Vulnerable predecessor

- failed A5P retains parent slave;
- helper closes child slave;
- helper master read does not receive EOF;
- process group cannot complete;
- timeout/deadlock is detected.

### Correct transfer

- child descriptor inheritance is proven;
- terminal setup is proven;
- parent slave closes exactly once;
- helper closes child slave;
- master receives EOF;
- process group completes;
- terminal reconciliation and resource ledger qualify.

### Early-close mutant

- parent slave closes before handoff acknowledgment;
- child inheritance/setup proof fails;
- command is nonqualifying;
- no false success or uncontrolled child survives.

### Retained-alias mutant

- an extra parent slave alias remains;
- EOF fails within the bound;
- resource ledger detects the live alias;
- command is nonqualifying.

### Duplicate-child-alias mutant

- child receives two slave aliases;
- role/count validation rejects it;
- cleanup disposes both without deadlock.

### Close faults

- parent-slave close error;
- EINTR;
- FD reuse;
- repeated disposal;
- child-slave close uncertainty;
- master EOF failure;
- worker failure.

All must preserve exact once-only disposition and complete later cleanup.

### Security nonregression

- `/dev/ptmx` remains denied;
- unrelated PTY remains inaccessible;
- broad `/dev` and `/dev/ttys*` remain absent;
- literal ioctl grant remains exact;
- another PTY cannot be allocated;
- non-PTY commands receive no capability.

### A5T bounded integration

- explicit capability passes all four remote tests;
- no-capability control fails at the expected PTY denial;
- repaired socket paths remain at most 100 bytes;
- intended assertions are reached;
- no survivor or resource residue remains.

## 12. Validation and restart plan

Freeze the post-reconciliation implementation sequence:

1. Create a new A5P2 implementation child from sealed A5S—not from the failed
   unsealed A5P candidate.
2. Reimplement the broker under the amended contract.
3. Preserve the failed A5P child as expected-negative evidence.
4. Run two disjoint successor A/B source, tests, races, security mutants, and
   deterministic builds.
5. Run the vulnerable retained-slave causal and repaired EOF causal.
6. Run the bounded current-A5T capability/no-capability integration.
7. Seal A5P2 only after complete cleanup and two zero-observation epochs.
8. Start a new A5T validation/closure child; do not resume the current A5T
   child.
9. Run A5T’s complete gate from the beginning.
10. After A5T seals, implement and seal A5C.
11. Restart the complete two-control A6 policy-evidence refresh from fresh
    materializations.

No failed or bounded causal substitutes for the fresh downstream control.

## 13. Required verdict

Return exactly one:

### Contract can be safely amended

REPAIR10I_A5P2_RECONNAISSANCE_READY

Use only when:

- the exact safe handoff boundary is frozen;
- parent/child ownership semantics are complete;
- EOF and process-group ordering are coherent;
- failure semantics are complete;
- schema dialect and touched-file scope are complete;
- causal and validation matrices are frozen;
- no repository or dependency widening is required.

### Contract cannot yet be frozen

REPAIR10I_A5P2_RECONNAISSANCE_BLOCKED

Use when:

- no safe observable handoff boundary exists;
- the acknowledgment protocol is ambiguous;
- child ownership cannot be represented honestly;
- fixing the deadlock requires repository production changes;
- scope or schema effects remain unresolved;
- retained evidence is insufficient.

## 14. Required report

Include:

1. Opening and closing identities.
2. Exact erroneous sealed clause.
3. Exact failed implementation mechanism.
4. Repository-helper EOF mechanism.
5. Kernel-causal result.
6. Complete descriptor/alias graph.
7. Selected handoff boundary and rejected alternatives.
8. Corrected ownership state machine.
9. Corrected lifetime rule.
10. Failure and cleanup semantics.
11. EOF/deadlock invariants.
12. Complete A5P2 schema dialect.
13. Exact successor touched-file set.
14. Exact causal-test matrix.
15. Implementation/validation/restart sequence.
16. Inspection limits and uncertainty.
17. Confirmation that no source, evidence, cache, bytecode, scratch, test, or
    build artifact was created.

No implementation.
No A5P2 child.
No A5T seal.
No A5C.
No A6 or B6.
No product A/B.
No snapshot.
No ZIP or handoff.
No capture child.
No independent audit.
No staging, commit, push, installation, live route, remote contact, or Linux
execution.
```

This is a contract amendment, not merely a code fix. The failed implementation candidate may inform the new design, but it must not become the new source baseline. A fresh A5P2 child should start from sealed A5S.

The established workflow requires changed bytes to return through fresh validation and later fresh audit; prior audit or validation cannot remain binding after a repair.  Exact provenance can show that the failed candidate and future repair are different bytes, but cannot establish that the revised transfer point is correct or deadlock-free.  The earlier A2 closeout likewise states that a bounded tool causal cannot replace the freshly materialized downstream source control. 

### Sources

- Codex’s `REPAIR10I_A5P_SOURCE_OR_TOOL_REPAIR_REQUIRED` report supplied in this turn.
- Governed Execution repair and re-audit protocol. 
- Governed Execution Provenance Guidance. 
- Sealed Repair 10I-A2 restart/non-substitution boundary. 

**Confidence:** 0.999 that the stop was correct; 0.995 that the deadlock is caused by conflating custody-record retention with live-descriptor retention; 0.93 that a safe post-handoff parent-slave close is feasible; 0.82 that the existing candidate already contains a sufficient acknowledgment boundary; 0.995 that A5T and the A6 evidence refresh must restart after the amended successor is sealed.
