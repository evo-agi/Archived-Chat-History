## Assessment

The baseline is now correctly reconciled. Codex inspected the intended Evidence Verification worktree and reproduced the exact audit target:

- branch `codex/evidence-verification-v1`;
- HEAD `567bce…12c`;
- canonical manifest `2aedcf…090e`;
- tracked diff `d91b76…03f1c`;
- exactly four modified tracked and nine untracked paths;
- no C2B2 contamination;
- no mutation during reconciliation.

Proceed in the **same fresh Codex conversation** with the workspace-write continuation below. There is no need for another reconnaissance or baseline revision.

The repair remains narrowly defined: the audit found the current trusted-host contract coherent and found no verifier or caller defect; the sole repository blocker is that test 89 uses independent phrase checks and can remain green while contradictory contract text is introduced.  

AP-06 is not part of this implementation. It is an audit-orchestration issue concerning the number of distinct auditor instances and must be addressed in the later fresh audit, not by changing repository behavior. 

## Codex continuation prompt

```text
Permission is now workspace-write.

Implement the CT-01 trusted-host contract-test repair against the exact
baseline you just reconciled.

You are the sole writer.

Do not spawn subagents.

Do not reopen reconnaissance, interpreter custody, launch protocol v2, the
trusted-host decision, or the verifier architecture.

Do not change the verifier or source-external caller.

Do not stage, commit, push, create a PR, merge, install, deploy, restart A6,
invoke product paths or live services, contact a network, or execute Linux
binaries.

MANDATORY RESPONSE FORMAT

Your final response must embed the complete implementation report inline in
Markdown.

Do not return only:

- a verdict;
- a summary;
- a link to a local report;
- or “full report available at …”.

Supplemental evidence links are permitted after the complete inline report.

## 1. Reconciled opening baseline

Repository:

IMPL_R=/Users/ds/Repositories/Execution Substrate - evidence-verification-v1

The immediately preceding read-only reconciliation returned:

EVIDENCE_VERIFICATION_V1_CT01_BASELINE_READY

Reverify before editing:

- physical root:
  `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`
- branch:
  `codex/evidence-verification-v1`
- HEAD:
  `567bceced5df95ecfe787cc66038d463a854e12c`
- HEAD tree:
  `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- sole parent:
  `05dde14d185b6e022dcc169ef1a658a97961850f`
- upstream:
  absent
- exactly 13 patch paths:
  - four modified tracked;
  - nine untracked;
- zero staged, deleted, renamed, or unmerged;
- every patch path regular and single-link;
- working mode `0644`;
- logical mode `100644`.

Canonical opening manifest:

/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/interpreter-trust-boundary-repair-ed26813371b3/provenance/run-1/provenance/manifest-run-1.json

Expected canonical-manifest SHA-256:

2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e

Expected tracked binary-diff SHA-256:

d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c

Exact provenance recipe:

RECIPE=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py

Expected recipe SHA-256:

bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333

Blocking audit root, read-only:

AUDIT_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-independent-audit-2aedcf930bfa-v1

New implementation evidence root:

REPAIR_ROOT=/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/trusted-host-contract-test-repair-2aedcf930bfa

Require REPAIR_ROOT absent before creation.

If the repository identity or exact opening path set differs, stop with:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_BASELINE_MISMATCH

## 2. Git and process boundary

Every Git invocation must:

- use `git -C "$IMPL_R" ...`;
- use cwd equal to IMPL_R;
- explicitly carry:
  - `GIT_OPTIONAL_LOCKS=0`;
  - `GIT_CONFIG_NOSYSTEM=1`;
  - `LC_ALL=C`;
  - `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
- be retained with full argv, cwd, environment, exit, stdout SHA-256, and
  stderr SHA-256.

Do not run Git in the primary checkout or any evidence/audit root.

No repository-relative operand may resolve through the primary checkout.

## 3. Evidence root and opening provenance

After the repository gate passes, create REPAIR_ROOT under umask `077` with:

opening/
decision/
validation/
provenance/
closeout/
tmp/

All directories mode `0700`.
All retained files regular, single-link, mode `0600`.

Run the exact unchanged RECIPE twice into fresh absent outputs beneath:

REPAIR_ROOT/opening/provenance/

Require:

- both exits `0`;
- empty stderr;
- byte-identical canonical outputs;
- equality with the reconciled opening manifest;
- canonical SHA-256:
  `2aedcf930bfa0c44dc906802a070badb218bfebeff669179611e8a51e878090e`;
- tracked diff:
  `d91b768e1d901e89dff6113b834f11a101c289e1d3f825e3be0bb4f428003f1c`.

Retain a decision record stating:

- CT-01 is the sole repository repair objective;
- current trusted-host prose is coherent;
- the existing test is not contradiction-resistant;
- verifier and caller source remain unchanged;
- AP-06 is an audit-process issue and receives no repository repair;
- changed bytes will require a fresh independent audit.

## 4. Authorized repository scope

Maximum authorized scope:

1. `PLANS.md`
2. `.docs/system_overview/evidence_verification.md`
3. `.docs/system_overview/artifact_hygiene.md`
4. `.docs/system_overview/capability_probing.md`
5. `tools/evidence_verify/test_verify_v1.py`

Use the smallest actual subset that fully closes CT-01.

Keep byte-identical:

- `.docs/system_overview/boundaries.md`
- `tools/evidence_verify/verify_v1.py`
- `tools/evidence_verify/registry_v1.json`
- all three layout JSON files
- both historical `.py.txt` fixtures.

No new repository path.
No deletion.
No rename.
No mode change.
No dependency.
No runtime or public schema.
No product/runtime source.
No caller source in the repository.

If closure requires another repository path or changing `verify_v1.py`, stop:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_SCOPE_EXPANSION_REQUIRED

## 5. One authoritative trusted-host contract

Create one and only one authoritative structured contract inside:

`.docs/system_overview/evidence_verification.md`

Use exact unique markers, for example:

<!-- BEGIN execution-substrate.evidence-verification.trusted-host-contract.v1 -->
```json
{...}
```
<!-- END execution-substrate.evidence-verification.trusted-host-contract.v1 -->

The JSON must be strict, canonical, and privately normative.

Contract ID:

execution-substrate.evidence-verification.trusted-host-contract.v1

This is:

- a private documentation/assurance contract;
- not a product schema;
- not a runtime protocol;
- not a public API;
- not readiness or execution authority.

Use a closed object with exact keys and exact values.

Required typed facts include:

- `schema`:
  `"execution-substrate.evidence-verification.trusted-host-contract.v1"`
- `scope`:
  `"supported-local"`
- `interpreter_trust_model`:
  `"trusted-host-stable-path-v1"`
- `operator_controlled_host_required`:
  `true`
- `kernel_and_process_execution_substrate_trusted`:
  `true`
- `foreground_validation_process_trusted`:
  `true`
- `pinned_interpreter_installation_and_ancestors_trusted`:
  `true`
- `all_interpreter_installation_writers_trusted`:
  `true`
- `supplied_repository_and_provenance_inputs_trusted`:
  `true`
- `target_content_untrusted`:
  `true`
- `preseal_candidate_untrusted`:
  `true`
- `target_controlled_script_paths_untrusted`:
  `true`
- `unproven_package_registry_layout_inputs_untrusted`:
  `true`
- `out_of_contract_argv_and_environment_untrusted`:
  `true`
- `atomic_loaded_object_binding_claimed`:
  `false`
- `transient_trusted_principal_replacement_covered`:
  `false`
- `shared_or_adversarial_host_supported`:
  `false`
- `remotely_administered_hostile_host_supported`:
  `false`
- `production_host_attestation`:
  `false`
- `interpreter_observation_authority`:
  `"corroboration-only"`
- `undocumented_launcher_fallback_authorized`:
  `false`
- `verifier_result_authority`:
  `"structural-evidence-only"`

Use exact booleans and closed strings.

Do not leave any of these facts represented only in prose.

Reject in the validator:

- duplicate keys;
- unknown keys;
- missing keys;
- wrong types;
- wrong values;
- multiple authoritative blocks;
- malformed marker or fenced-block structure.

## 6. Consumer-document references

`PLANS.md`, `artifact_hygiene.md`, and `capability_probing.md` must contain one
bounded reference section each.

Each reference section must:

- name the exact contract ID;
- state that `evidence_verification.md` is the sole authoritative writer;
- state that the consumer document does not redefine, override, narrow, or
  widen the contract;
- preserve its own explanatory purpose without duplicating another complete
  independently editable contract.

Use unique begin/end markers or a strict structured reference object that
test 89 can parse as a complete section.

Do not create authoritative contract blocks in consumer documents.

Preserve the existing trusted-host semantics exactly. This repair strengthens
regression detection; it does not widen or narrow the threat model.

## 7. Test 89 implementation

Preserve the test identity:

InterpreterTrustContract.test_89_supported_local_interpreter_nonclaim

Replace isolated phrase checks with strict complete-contract validation.

A helper may be added inside `test_verify_v1.py`; no new module is authorized.

Test 89 must:

1. Find exactly one authoritative contract block in
   `evidence_verification.md`.
2. Parse JSON with duplicate-key detection.
3. Reject unknown keys.
4. Reject missing keys.
5. Reject wrong types.
6. Require every exact value.
7. Require the exact contract ID.
8. Require exactly one bounded reference section in each consumer document.
9. Require each consumer reference to name the exact contract ID.
10. Require each reference to declare itself non-overriding.
11. Reject a second authoritative block in any document.
12. Pin `verify_v1.py` to SHA-256:
    `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`.
13. Pass against the final complete current documents.
14. Apply contradictory in-memory mutations and require mechanism-specific
    rejection.

Do not merely add more `assertIn` calls.

## 8. Mandatory contradiction matrix

Exercise and retain outcomes for at least:

1. `atomic_loaded_object_binding_claimed = true`
2. `transient_trusted_principal_replacement_covered = true`
3. `shared_or_adversarial_host_supported = true`
4. `remotely_administered_hostile_host_supported = true`
5. `production_host_attestation = true`
6. `interpreter_observation_authority = "proof"`
7. `all_interpreter_installation_writers_trusted = false`
8. `undocumented_launcher_fallback_authorized = true`
9. `verifier_result_authority = "readiness"`
10. `verifier_result_authority = "execution-authority"`
11. `verifier_result_authority = "commit-authority"`
12. `scope` widened beyond `"supported-local"`
13. missing mandatory field
14. unknown field
15. duplicate JSON key
16. wrong boolean/string type
17. duplicate authoritative block
18. wrong contract ID in one consumer reference
19. missing consumer reference
20. consumer reference asserting a local override
21. contradictory text inserted inside a bounded authoritative or reference
    section

Each mutation must fail for its intended reason, not merely because the JSON or
Markdown became accidentally malformed.

Retain a machine-readable mutation/result ledger.

## 9. AP-06 disposition

Do not edit repository files for AP-06.

The implementation report must state:

- AP-06 is an independent-audit orchestration issue;
- it is not a patch defect;
- no repository behavior changed for it;
- the next audit must use four distinct audit instances.

Recommended next-audit schedule:

- three distinct auditors concurrently;
- after one closes, start a fourth distinct security auditor;
- one retry maximum;
- if the fourth distinct auditor cannot start, return `SUBAGENT_UNAVAILABLE`.

## 10. Validation

Use the pinned Python 3.13.4 already established in project evidence.

Run fresh:

### Static gates

- `ast.parse` on `verify_v1.py` and `test_verify_v1.py`;
- parse both historical `.py.txt` files without executing them;
- strict-parse registry and all three layouts;
- require verifier, registry, layouts, historical fixtures, and boundaries
  byte-identical to opening;
- independently parse the authoritative contract outside test 89;
- independently run the complete contradiction matrix outside test 89;
- verify all three consumer references;
- run rooted `git diff --check`.

### Targeted test 89

Run test 89 alone at least three times.

Require:

- every run passes;
- every contradiction case executes;
- zero failure/error/skip;
- no repository artifact.

### Complete suite

Discover the exact test identities.

Require exactly 89 identities, including the preserved test 89 identity.

Run:

- twice under umask `077`;
- twice under umask `022`.

Every owning command must:

- exit `0`;
- run 89 tests;
- have zero failure;
- zero error;
- zero skip;
- discover the identical identity set;
- create no repository artifact.

Do not accept an inner passing suite when the owning shell exits nonzero.

### Regression identity checks

Require exact unchanged hashes for:

- verifier:
  `bf2cf27c5c747e2bb75d14fe744b9ff77cc09c67e951284d2faf3873d211ad5c`
- source-external caller:
  `002499add110242dd6ab5e1ba11b617ff623aa57dec642e6784336dc106f4104`
- registry:
  `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`
- A6D layout:
  `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`
- amendment layout:
  `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`
- A6-policy layout:
  `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`
- historical fixtures:
  `e7dbe726d051f8f4fbb8f050510887c6fc9076b8b81e8df3a3656121bbc1eb98`
  and
  `5fa9c3bd31dd1e77a5d85365244c7a7dc12d948bccb8d3a22e4b92546b8a114f`.

Do not rerun A6D, amendment, or synthetic compatibility as implementation
qualification solely for this documentation/test repair. Their prior results
remain predecessor evidence; the fresh audit must rerun acceptance-bearing
compatibility.

## 11. Artifact hygiene

Scan IMPL_R for:

- `__pycache__`;
- `.pyc`;
- `.pyo`;
- `.pytest_cache`;
- generated manifests;
- temporary fixtures;
- databases;
- journals;
- locks;
- build output;
- unexpected executable modes;
- unsupported file types.

Remove only artifacts created by this repair activity.

Do not delete, chmod, or normalize pre-existing repository objects.

Require the blocking audit, earlier implementation evidence, FD-exec evidence,
A6D, amendment, candidate, and primary checkout remain unchanged.

## 12. Final provenance

After validation and cleanup, run the exact unchanged RECIPE twice into fresh
paths beneath:

REPAIR_ROOT/provenance/

Require:

- both exits `0`;
- empty stderr;
- byte-identical canonical manifests;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- every path regular, single-link, logical mode `100644`;
- no extra path;
- deterministic tracked binary diff.

Retain:

- exact recipe source and SHA-256;
- both manifests;
- new canonical-manifest SHA-256;
- new tracked binary-diff SHA-256;
- complete per-file identities;
- actual touched-file subset;
- final test hash;
- unchanged verifier hash;
- targeted test-89 records;
- independent contradiction-matrix record;
- four full-suite records;
- artifact scan and cleanup;
- failed/superseded attempt index.

## 13. Closing gate

Require final IMPL_R:

- branch, HEAD, tree, parent, and absent upstream unchanged;
- exact 13-path scope;
- four modified tracked and nine untracked;
- zero staged/deleted/renamed/unmerged;
- no extra path;
- every patch object regular and single-link;
- logical mode `100644`;
- `git diff --check` clean;
- no generated repository artifact;
- verifier, boundaries, registry, layouts, and historical fixtures unchanged.

Do not stage or commit.

## 14. Mandatory stop conditions

Stop if:

- opening provenance differs;
- verifier source must change;
- caller source must change;
- a sixth repository file is needed;
- a fourteenth patch path is needed;
- registry/layout/output schema must change;
- the structured contract would become a runtime or public schema;
- the threat model must be widened or narrowed;
- contradiction cases cannot be made mechanism-specific;
- consumer documents need independent overriding semantics;
- test count differs without a justified identity-preserving cause;
- complete suite differs by umask;
- validation creates repository artifacts;
- final provenance is unstable.

Use exactly one verdict:

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_BASELINE_MISMATCH

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_SCOPE_EXPANSION_REQUIRED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_VALIDATION_BLOCKED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_PROVENANCE_BLOCKED

EVIDENCE_VERIFICATION_V1_TRUST_CONTRACT_TEST_REPAIR_IMPLEMENTED_READY_FOR_FRESH_AUDIT

## 15. Complete inline final report

Include:

1. Verdict.
2. Response-format confirmation.
3. Opening repository and provenance identity.
4. CT-01 finding consumed.
5. AP-06 disposition.
6. Exact actual touched files.
7. One-authoritative-writer design.
8. Authoritative contract ID.
9. Complete typed contract field inventory.
10. Consumer-reference mechanism.
11. Test 89 implementation.
12. Complete contradictory mutation matrix and outcomes.
13. Three targeted test-89 runs.
14. Complete final test count and identities.
15. Both umask-077 results.
16. Both umask-022 results.
17. Static and independent documentary validation.
18. Unchanged verifier SHA-256.
19. Unchanged caller SHA-256.
20. Unchanged registry/layout/fixture hashes.
21. Artifact and no-write results.
22. Exact final 13-path manifest.
23. Provenance recipe identity and SHA-256.
24. New tracked binary-diff SHA-256.
25. New canonical-manifest SHA-256.
26. Evidence inventory and cleanup.
27. Authority and non-authority adjudication.
28. Remaining uncertainty and nonclaims.
29. Explicit confirmations:
    - prior audit no longer qualifies changed bytes;
    - fresh independent audit not performed;
    - staging not performed;
    - commit not performed;
    - push not performed;
    - A6 not restarted;
    - product/live services not invoked;
    - network not contacted;
    - no subagents created.

No independent audit.
No staging.
No commit.
No push.
No A6 restart.
```

## Next gate

A successful repair requires a fresh read-only audit against the new exact manifest. The fresh audit must use **four distinct auditor instances**: three concurrently, then a fourth distinct security auditor after a slot closes. The repository operating protocol requires implementation repair to produce new validation and provenance, followed by a fresh audit; any changed bytes invalidate the prior audit. 

### Sources

- The independent audit identifies CT-01 as the blocking patch defect and says the current governing documents themselves are coherent. 
- The same audit records AP-06 as a separate audit-process limitation, not a repository behavior defect. 
- Parent-only mutation after a read-only baseline freeze is the project’s recommended implementation shape. 
- Exact provenance must include tracked and untracked paths and two byte-identical recipe outputs. 
- The MVP freeze requires proof and generated evidence to remain non-authoritative. 

**Confidence**

- Baseline is ready for mutation: **0.999**
- CT-01 is the only authorized repository repair: **0.995**
- Structured single-authority contract is the strongest proportional closure: **0.97**
- Verifier and caller should remain unchanged: **0.997**
- Correct next gate after implementation: fresh four-perspective audit, **0.999**
