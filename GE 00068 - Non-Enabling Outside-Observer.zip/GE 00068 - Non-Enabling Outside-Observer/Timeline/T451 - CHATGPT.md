## Engineering assessment

This was the correct fail-closed result, but it does **not** consume the final repair opportunity.

The provenance mismatch came from the fixed identity I supplied in the previous prompt: it was only 48 hexadecimal characters and therefore could not be a SHA-256 digest. Codex independently observed the predecessor file at the valid 64-character digest:

`fad5526228906c0845f9b34d6e3d0a1845ddc409c13838e666df92aba6dc0556`

The predecessor capsule otherwise authenticated: its temporal inventory and byte-identical manifests reprojected successfully, its root row and physical topology closed, and its failure-closeout identity matched. :chatgpt-content-reference{index="0"}

This is therefore a **prompt-supplied fixed-identity defect**, not:

- a new audit-harness defect;
- an implementation-package defect;
- source-attempt exhaustion;
- a reason to retire the harness lineage.

No source was copied or changed, compilation did not begin, and zero of the two authorized source attempts were consumed. :chatgpt-content-reference{index="1"}

The useful preflight work remains valid as bounded evidence:

- all six Attempt-2 source identities were authenticated;
- no Attempt-1 source was promoted;
- the implementation, successor, external roots, and Attempt-2 failed root all closed equal;
- the terminal-adapter causal chain was reproduced exactly;
- existing evidence supports `/inventory/root_identity` as the sole authoritative root identity;
- neither the implementation source nor the full audit was executed. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"}

### Progression decision

Reissue the final bounded terminal-adapter repair with one explicit correction:

- reject the malformed 48-character value;
- authenticate the corrected 64-character digest through the predecessor manifests and an independent no-follow read;
- preserve the full two-attempt source budget;
- proceed with the already bounded repair;
- retire the incremental lineage only if those two actual source attempts fail or expose another acceptance-bearing defect outside the frozen interface surface.

This is a corrected input designation, not another retrospective reconciliation and not another repair layer.

```text
FINAL BOUNDED REPAIR OF THE GENERATION-2 IMPLEMENTATION
INDEPENDENT-AUDIT HARNESS — CORRECTED PREDECESSOR IDENTITY,
TERMINAL ADAPTER, AND CROSS-MODULE INTERFACES

Objective

Create a fresh successor to the blocked independent-audit-harness repair by:

1. authenticating the corrected fixed identity of the predecessor’s blocked
   status record;
2. correcting the exact terminal provider/consumer mismatch;
3. closing the cross-module interface coverage that allowed that mismatch to
   escape qualification;
4. qualifying and freezing the repaired audit harness;
5. terminally closing a successor harness package.

This is the final permitted bounded incremental repair of this audit-harness
source lineage.

The previous retry stopped during fixed-input authentication. It copied or
modified no source, began no compilation, and consumed zero source attempts.
The full two-attempt repaired-source budget remains available.

Do not run the full independent implementation-package audit in this task.

Do not execute the production reconstruction parent.

Do not construct subject rehearsals.

Do not modify, repair, reinterpret, or adjudicate the sealed implementation
package.

Do not change package acceptance rules, verdict thresholds, governing
Generation-2 semantics, the normative construction-parent contract, current
schemas, validation case semantics, or implementation source.

If this final bounded repair cannot qualify within two actual source attempts,
or if it uncovers another acceptance-bearing source defect outside the exact
frozen cross-module-interface surface, stop and select:

RETIRE_INCREMENTAL_AUDIT_HARNESS_LINEAGE_AND_CLEANLY_REIMPLEMENT

Do not issue or recommend another localized repair after that disposition.

Do not create subagents or direct auditors.
Do not run Git.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not deploy, publish, externally commit, or start A6.

Use one finite parent-owned repair and qualification process in one fresh
private root.

Return the complete operative report inline. Artifact paths may supplement but
must not replace material identities, causal findings, source deltas, interface
contracts, validation results, and final disposition.

Return exactly one primary verdict:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIR_BLOCKED

HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CORRECTED FIXED PREDECESSOR IDENTITY
──────────────────────────────────────────────────────────────────────────────

BLOCKED_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-repair-y0atdjv6

Expected root identity:

- device:
  16777234
- inode:
  181082379
- mode:
  0700
- verdict:
  SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_REPAIR_BLOCKED

Expected terminal identities:

Temporal inventory:

closeout/temporal-final-inventory-v1.json

- inode:
  181094949
- mode:
  0600
- link count:
  1
- size:
  32055
- SHA-256:
  c6a3532ff28528f95b61d66ab4c7667f605996db5a65b3ff2abefad13eaad4ab

Manifest A:

manifest/canonical-manifest-a-v1.json

- inode:
  181094947
- mode:
  0600
- link count:
  1
- size:
  33301
- SHA-256:
  0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf

Manifest B:

manifest/canonical-manifest-b-v1.json

- inode:
  181094948
- mode:
  0600
- link count:
  1
- size:
  33301
- SHA-256:
  0a012d51d1bd2608c4a9208e0986f1291602e8dc7586cbb4f9784f62c2572ebf

Expected failure-closeout SHA-256:

e2c6fffee7a36a4c9389a318abf6161fe255b47456465bb0273baba7bff4c8c1

The previously supplied blocked-status value is invalid and nonauthoritative:

fad5526228906c0845ddc409c13838e666df92aba6dc0556

It is only 48 hexadecimal characters and must be rejected as an exact
SHA-256 identity.

The corrected externally designated blocked-status SHA-256 is:

fad5526228906c0845f9b34d6e3d0a1845ddc409c13838e666df92aba6dc0556

Before adopting that correction, independently require all of the following:

1. The corrected value is exactly 64 lowercase hexadecimal characters.
2. The predecessor’s terminal manifest A authenticates exactly one regular
   file with that digest.
3. Terminal manifest B authenticates the same exact path, size, mode, link
   count, and digest.
4. A fresh stable no-follow read independently recomputes that digest.
5. The file is the exact predecessor blocked-status role through authenticated
   predecessor references.
6. No file is selected solely by basename, uniqueness, content scoring, or
   recursive first match.
7. The malformed 48-character value is retained as superseded supplied-input
   error evidence and never used as a hash prefix.
8. No predecessor byte is modified.

Retain:

opening/supplied-predecessor-status-identity-correction-v1.json

Bind:

- malformed value;
- malformed length;
- corrected value;
- corrected length;
- exact file path;
- exact file identity;
- manifest-A row;
- manifest-B row;
- independently observed identity;
- correction authority:
  externally designated fixed-input correction;
- semantic effect:
  none;
- source-attempt effect:
  none;
- package effect:
  none.

If the three corrected-identity observations do not agree exactly, return:

HARNESS_REPAIR_PROVENANCE_MISMATCH

Do not proceed through an inferred or silently repaired identity.

──────────────────────────────────────────────────────────────────────────────
2. PRIOR CORRECTION-EVIDENCE ROOT
──────────────────────────────────────────────────────────────────────────────

CORRECTION_EVIDENCE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-h3yhmdqh

Expected identity:

- device:
  16777234
- inode:
  181097643
- mode:
  0700
- verdict:
  HARNESS_REPAIR_PROVENANCE_MISMATCH
- status:
  terminal-adapter-repair-provenance-mismatch
- complete source attempts begun:
  0
- compilation begun:
  false
- repaired source created:
  false
- implementation mutated:
  false
- full independent audit executed:
  false

Expected evidence:

opening/predecessor-repair-root-authentication-v1.json
analysis/fixed-predecessor-provenance-mismatch-v1.json
opening/attempt-2-source-authority-v1.json
closing/source-attempt-ledger-v1.json
closing/supplied-root-closing-equality-final-v1.json
closeout/failure-closeout-v1.json

Expected closing-equality record:

- inode:
  181102861
- mode:
  0600
- size:
  275366
- SHA-256:
  ab46434bcb726e4bbce47b6b3bae88a138a2c6e4306a57be078d9128bbf1cc78

Expected failure-closeout:

- size:
  2869
- SHA-256:
  99e202ebf68fe60ff248cb12dc0823144574a459560c08474184ece91adf722c

Use this root only as historical evidence of:

- the malformed supplied identity;
- the corrected independent observation;
- zero source attempts;
- authenticated Attempt-2 source authority;
- supplied-root preservation.

It is not:

- a repair base;
- a current source authority;
- a source attempt;
- a successor package;
- package acceptance evidence.

Require complete opening/closing equality if opened.

Do not mutate, resume, or clean it.

──────────────────────────────────────────────────────────────────────────────
3. FIXED PREDECESSOR CLOSURE
──────────────────────────────────────────────────────────────────────────────

After the corrected identity passes, authenticate the complete predecessor:

- root identity;
- temporal inventory;
- A/B byte equality;
- terminal reprojection;
- root row exactly once;
- physical topology:
  115 objects;
  23 directories;
  92 regular files;
- no empty descendant;
- no symlink or special object;
- no multiply linked regular file;
- modes 0700/0600;
- no cache or bytecode;
- no-write-after-terminal-closure posture;
- blocked status;
- failure closeout;
- explicit confirmation registry;
- current source registry;
- Attempt-1 and Attempt-2 ledgers;
- bounded live replay;
- all matrix and synthetic-capsule results;
- exact terminal-adapter blocker.

Classify:

historical_blocked_terminal_adapter_repair_predecessor

The predecessor becomes noncurrent only after a successful successor package
terminally closes.

──────────────────────────────────────────────────────────────────────────────
4. EXACT ATTEMPT-2 SOURCE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Resolve all current Attempt-2 source paths only through the authenticated
predecessor current source registry.

Expected registry:

- six source files;
- fourteen source roles;
- SHA-256:
  910eb1a344f73bc1d9679b32c9af1ca038a5f6219454fdb0322fbb0f9a1fc6bb

Expected exact source identities:

Audit parent:

- size:
  239303
- SHA-256:
  1caa2554c923ce2f1e9bc684301860654bfd18b1a18e614613e7115eafce7d6c

Repair core:

- size:
  46559
- SHA-256:
  adaecf6cf565748a95e2afe2059ea811638fbbae60188d8133adb3b69ccb65d5

Qualification driver:

- size:
  59954
- SHA-256:
  c55912bd92be12f844761e3f2a04f4ee878c528d3b665b36bde535fd00ed3e48

Independent validator:

- size:
  18809
- SHA-256:
  2345012ade8e63c3a5e96a19c57b42be2428c8a284238cbe69bdc81479bdca21

Recorder:

- size:
  6209
- SHA-256:
  ec724c7dd00feb63d918cc8497336b01d681b542b0aa7e76f5b7dc0fec40119a

Platform capture:

- size:
  3344
- SHA-256:
  1a53f3d74297c42e0e7d9002fed551dca685caed280357a657910c40e2d85670

Do not select source by basename, uniqueness, recency, or fallback.

Use only these exact Attempt-2 current source bytes as the bounded repair base.

No Attempt-1 source may become current.

Retain:

opening/attempt-2-source-authority-v2.json

Require:

- every current role resolved;
- every source identity exact;
- no historical source substituted;
- no stale source binding;
- Attempt 2 classified as the sole repair base;
- Attempt 2 remains nonqualified until the successor closes.

──────────────────────────────────────────────────────────────────────────────
5. ORIGINAL FAILED AUDIT AND OTHER SUPPLIED ROOTS
──────────────────────────────────────────────────────────────────────────────

ORIGINAL_FAILED_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-gen2-implementation-independent-audit-5uk1tj8s

Expected inventory digest:

de3a62f894eafdea54d0af85914d41c614804ea83c1b66add27da08e73c7f3bd

IMPLEMENTATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-implementation-k2hqc634

Expected identity:

- device/inode:
  16777234 / 180884963
- mode:
  0700
- inventory digest:
  d272be8e9ea33eab1cd5f78c8840b4d5d073df6704d916d41981110b9c952b4e

GEN2_SUCCESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-parent-gen2-bootstrap-order-repair-t9kydqve

Expected identity:

- device/inode:
  16777234 / 180871216
- mode:
  0700
- inventory digest:
  8f8f383aae4bf5ebf96ea6c5ca053f6fe6e69f8bb318ee0272c68d7701fac0f6

AUTHORITATIVE_CONTRACT_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-contract-resealed-2y6tkl0n

Expected inode and inventory digest:

- inode:
  180472094
- digest:
  0cb2062afdd960a56792f90420e4f491b65f836886584dca586f0ed161831d36

SCHEMA_SOURCE_PACKAGE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-repair-pw27ydqf

Expected inode and inventory digest:

- inode:
  180513083
- digest:
  89b95b973e4e8158668c10dabf04fa66bb3a205ad048579c271e4f3f57fa450a

SCHEMA_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-construction-parent-schema-reconciliation-5e2lsx8t

Expected inode and inventory digest:

- inode:
  180480821
- digest:
  86ed69482adb4e20cdcdb47aab002178560229a702f91505be137478c0e2c889

VALIDATION_SPEC_SOURCE:

/Users/ds/Downloads/ES-repair10i-v3-package-construction-parent-schema-evidence-repair-lj_8xygs

Expected inode and inventory digest:

- inode:
  180576497
- digest:
  712600a53799b082cce3e015f497772d96230b9e0a27d8c28e422af450eae019

ATTEMPT_2_FAILED_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-hqsolb0v

Expected identity:

- device/inode:
  16777234 / 180892391
- mode:
  0700
- inventory digest:
  778d0c6e41b3d80ce8a9f326782a0c868af2b5dad8332a24b1c65af04e6297f1

Require complete opening/closing equality for every supplied root opened.

Do not modify, resume, repair, or clean any supplied root.

Do not execute the implementation production source.

Do not run the full independent audit.

──────────────────────────────────────────────────────────────────────────────
6. EXACT TERMINAL-ADAPTER BLOCKER REPRODUCTION
──────────────────────────────────────────────────────────────────────────────

Before modifying source, reproduce:

FUTURE_AUDIT_PARENT_TERMINAL_ADAPTER_INTERFACE_MISMATCH

Authenticate these predecessor source ranges:

Audit parent:

- `build_inline_report`:
  predecessor lines 4041–4199
- `seal_terminal_capsule`:
  predecessor lines 4201–4349

Repair core:

- `close_capsule`:
  predecessor lines 891–1025
- `seal_audit`:
  predecessor lines 1028–1048

Reproduce exactly:

1. `repair_core.close_capsule()` returns root identity at:
   `/inventory/root_identity`
2. It does not return:
   `/audit_root_identity`
3. `repair_core.seal_audit()` forwards that result unchanged.
4. `Audit.build_inline_report()` indexes:
   `terminal["audit_root_identity"]`
5. The real success path raises:
   `KeyError("audit_root_identity")`
6. Terminal marker and verdict preparation cannot complete.
7. Prior matrices stopped at `close_capsule`.
8. The prior independent validator did not execute the real:
   `seal_audit()` → `build_inline_report()` path.

Retain:

analysis/terminal-adapter-mismatch-reproduction-v2.json

Required classification:

AUDIT_HARNESS_CROSS_MODULE_INTERFACE_DEFECT

unless current governing evidence proves another owner.

──────────────────────────────────────────────────────────────────────────────
7. FINAL INCREMENTAL-REPAIR TERMINALITY
──────────────────────────────────────────────────────────────────────────────

Retain before source modification:

opening/final-incremental-repair-authority-v2.json

Bind:

- this is the final incremental repair of this harness source lineage;
- prior corrected-identity retry consumed zero source attempts;
- exactly two complete source attempts remain authorized;
- no third attempt;
- no post-attempt patch;
- no hidden waiver;
- only the terminal-adapter and cross-module-interface surface may change;
- implementation-package semantics may not change;
- package verdict rules may not change;
- full audit may not run;
- production reconstruction source may not run.

If either actual repaired source attempt fails qualification, or if
qualification discovers another acceptance-bearing defect outside the frozen
interface surface:

- stop;
- preserve all evidence;
- select:
  RETIRE_INCREMENTAL_AUDIT_HARNESS_LINEAGE_AND_CLEANLY_REIMPLEMENT
- set:
  further_localized_repair_authorized=false
- do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
8. FRESH SUCCESSOR REPAIR ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root under `/Users/ds/Downloads` using:

- `tempfile.mkdtemp`;
- umask `077`;
- prefix:

ES-repair10i-v3-gen2-independent-audit-harness-terminal-adapter-repair-

Immediately emit:

HARNESS_ROOT=<absolute-path>

Retain before supplied-root inspection:

opening/bootstrap-start.json

Bind:

- fresh-root identity;
- allocation method and umask;
- predecessor repair-root identity;
- correction-evidence-root identity;
- corrected blocked-status identity;
- Attempt-2 source authority;
- exact terminal-adapter defect;
- final incremental-repair terminality;
- bounded repair authority;
- implementation-package mutation authorized:
  false;
- full independent audit authorized:
  false;
- production-source execution authorized:
  false;
- rehearsal creation authorized:
  false;
- current-subject construction authorized:
  false;
- target audit authorized:
  false;
- runtime validation authorized:
  false;
- repository mutation authorized:
  false;
- A6 authorized:
  false;
- same-root retry authorized:
  false.

Create directories lazily.

No empty directory may remain at successful terminal closure.

──────────────────────────────────────────────────────────────────────────────
9. TERMINAL-ADAPTER AUTHORITY ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before source modification, retain:

analysis/terminal-adapter-authority-adjudication-v2.json

Crosswalk:

- terminal provider outputs;
- forwarding behavior;
- terminal-result consumers;
- lifecycle contracts;
- synthetic success/BLOCK/failure records;
- report-building consumers;
- terminal-marker consumers.

Determine one authoritative audit-root identity representation.

Expected adjudication absent contrary governing evidence:

- canonical value:
  terminal inventory root identity;
- canonical pointer:
  `/inventory/root_identity`;
- top-level `/audit_root_identity`:
  nonauthoritative and unnecessary;
- consumer adapts to the canonical nested pointer;
- no duplicate alias is introduced.

If a current governing contract explicitly requires top-level
`/audit_root_identity`, stop with the blocked verdict and report the contract
conflict.

Do not support both representations.

Do not add a fallback pointer.

──────────────────────────────────────────────────────────────────────────────
10. CLOSED TERMINAL-ADAPTER CONTRACT
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/terminal-adapter-interface-v2.json

Freeze:

- provider:
  `repair_core.close_capsule`
- forwarding function:
  `repair_core.seal_audit`
- consumer:
  `Audit.build_inline_report`
- canonical terminal-result schema;
- required top-level fields;
- nested inventory fields;
- canonical root pointer:
  `/inventory/root_identity`
- verdict field and type;
- terminal-posture fields;
- temporal and manifest identity fields consumed by the report;
- nullability;
- success/BLOCK/audit-failure applicability;
- unknown-field policy;
- missing-field policy;
- wrong-type policy;
- contradictory-alias policy;
- post-seal purity.

Require:

- typed total accessor;
- no unchecked direct object access;
- no alias;
- no fallback;
- no recursive field search;
- no duplicated root identity;
- provider and consumer share one closed shape;
- structured adapter error on mismatch;
- no success marker on adapter failure;
- adapter/report operations after seal are in-memory only;
- no filesystem access after seal.

──────────────────────────────────────────────────────────────────────────────
11. COMPLETE CROSS-MODULE INTERFACE REGISTRY
──────────────────────────────────────────────────────────────────────────────

Generate:

contract/audit-harness-cross-module-interface-registry-v2.json

Enumerate every acceptance-bearing provider/consumer interface among all six
current Attempt-2 source files.

For every interface bind:

- interface ID;
- provider file/function;
- consumer file/function;
- call path;
- input shape;
- output shape;
- exact fields or pointers consumed;
- types;
- nullability;
- exception semantics;
- authority;
- applicable verdict classes;
- direct integration test;
- independent-validator coverage.

Require:

- every cross-module edge classified;
- no unregistered acceptance-bearing edge;
- no consumer field outside provider shape;
- no acceptance-bearing provider field silently ignored;
- no recursive or fallback discovery;
- no conflicting duplicate representation;
- one real-function integration test per interface;
- terminal adapter explicitly included.

Unknown or unresolved interface blocks qualification.

This registry must not redefine package acceptance semantics.

──────────────────────────────────────────────────────────────────────────────
12. BOUNDED SOURCE-REPAIR SURFACE
──────────────────────────────────────────────────────────────────────────────

Retain:

analysis/terminal-adapter-repair-surface-v2.json

Default permitted production changes:

- `Audit.build_inline_report`;
- a typed terminal-result accessor used by that function;
- source-level interface declarations/constants required to bind the closed
  shape.

Protected by default:

- `repair_core.close_capsule`;
- `repair_core.seal_audit`;
- terminal inventory generation;
- manifest generation;
- package verdict constants;
- package acceptance rules;
- process recorder;
- package grammar and role logic;
- cleanup logic;
- security logic.

A provider change is permitted only when authority adjudication proves that the
provider violates a current governing contract.

If provider change is required:

- do not add a duplicated top-level alias;
- choose one canonical location;
- update every consumer;
- directly retest every affected interface.

Permitted qualification changes:

- terminal-adapter integration fixtures;
- cross-module interface fixtures;
- adapter matrix;
- interface matrix;
- independent interface validator;
- static checks proving provider/consumer compatibility.

No unrelated function may change.

Every unrelated common function must remain AST-identical.

──────────────────────────────────────────────────────────────────────────────
13. SOURCE ATTEMPT LIMIT
──────────────────────────────────────────────────────────────────────────────

At most two complete repaired-source attempts are permitted.

A complete attempt begins when:

- repaired source registry closes;
- compilation starts.

For each attempt retain:

- predecessor source identities;
- repaired source identities;
- exact textual and AST delta;
- changed functions;
- protected functions;
- compilation;
- static checks;
- matrices reached;
- integration tests;
- first blocker;
- supersession disposition.

Any source modification after compilation starts creates a new attempt.

If Attempt 2 fails:

- stop;
- return the blocked verdict;
- set:
  retire_incremental_harness_lineage=true
- set:
  clean_source_external_audit_harness_implementation_required=true
- set:
  further_localized_repair_authorized=false
- do not create Attempt 3.

──────────────────────────────────────────────────────────────────────────────
14. TERMINAL-ADAPTER INTEGRATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Exercise the real functions:

`repair_core.close_capsule`
→ `repair_core.seal_audit`
→ `Audit.build_inline_report`
→ guarded terminal marker/verdict preparation

Required positive lanes:

1. successful audit capsule;
2. substantive BLOCK capsule;
3. `AUDIT_PROVENANCE_MISMATCH` capsule;
4. source-preflight failure capsule where terminal adaptation applies;
5. terminal package-failure capsule.

For every positive case require:

- actual provider return;
- actual forwarding result;
- actual consumer call;
- no `KeyError`;
- exact root identity;
- exact verdict;
- exact report values;
- exact marker preparation;
- no verdict-class change;
- no filesystem operation after seal.

Required negative lanes:

- missing `/inventory`;
- `/inventory` wrong type;
- missing `/inventory/root_identity`;
- root identity wrong type;
- top-level alias only;
- nested plus equal top-level alias;
- nested plus conflicting top-level alias;
- stale root identity;
- malformed verdict;
- missing terminal posture;
- unknown acceptance-bearing field;
- provider returns `None`;
- forwarding changes shape;
- consumer requests an unprovided field;
- historical direct lookup of `terminal["audit_root_identity"]`.

Every negative case must fail closed with a structured adapter reason and no
terminal success marker.

Retain:

validation/terminal-adapter-integration-matrix-v2.json

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

──────────────────────────────────────────────────────────────────────────────
15. CROSS-MODULE INTERFACE MATRIX
──────────────────────────────────────────────────────────────────────────────

Retain:

validation/cross-module-interface-matrix-v2.json

For every registered interface cover:

- exact baseline;
- one required field missing;
- one required field wrong type;
- unknown acceptance-bearing field;
- forbidden null;
- exception propagation;
- provider/consumer identity mismatch.

Require at least 40 uniquely named cases and direct coverage of every
registered interface.

Require:

- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Static inspection alone is not interface coverage.

──────────────────────────────────────────────────────────────────────────────
16. STATIC AND BYTECODE INTERFACE GATES
──────────────────────────────────────────────────────────────────────────────

Compile every repaired source under pinned Python `-I -S -B`.

Require exit 0 and empty stderr.

Run source-external:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- return-shape analysis;
- consumer-field analysis;
- interface crosswalk;
- post-seal operation analysis.

Require:

- every `close_capsule` return path conforms;
- `seal_audit` preserves the shape;
- every terminal access in `build_inline_report` is contract-backed;
- no direct `terminal["audit_root_identity"]`;
- canonical `/inventory/root_identity` used exactly;
- no alias or fallback;
- no unchecked object access;
- every adapter call directly tested;
- no unregistered interface;
- no post-seal filesystem operation;
- package verdict constants unchanged;
- package acceptance rules unchanged.

Static pass is false when any interface lacks direct integration coverage.

──────────────────────────────────────────────────────────────────────────────
17. PRIOR QUALIFICATION REGRESSION
──────────────────────────────────────────────────────────────────────────────

Rerun the exact prior Attempt-2 registries:

- manifest/current-role:
  44 cases;
- invocation:
  39 cases;
- cleanup:
  26 cases;
- temporal/terminal:
  42 cases;
- security:
  32 cases;
- process custody:
  26 cases.

Require exact case-name and expectation equality.

Across all 209 cases require:

- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Do not replace prior cases with adapter cases.

The adapter and interface matrices are additional lanes.

──────────────────────────────────────────────────────────────────────────────
18. SYNTHETIC END-TO-END TERMINAL LANES
──────────────────────────────────────────────────────────────────────────────

Rerun all six prior synthetic lanes through the real terminal adapter and
inline-report path:

1. success capsule;
2. substantive BLOCK capsule;
3. zero-root causal failure;
4. one-root causal failure;
5. temporal-verification failure;
6. manifest-B write failure.

For every lane retain:

- complete process custody;
- actual provider result;
- actual forwarding result;
- actual report consumer result;
- verdict class;
- marker posture;
- temporal/manifest posture;
- root identity;
- cleanup;
- no post-seal filesystem operation.

Success and BLOCK must reach report and marker preparation.

Failure lanes must retain explicit failure outcomes and must not fabricate
terminal success.

Exercise all six lanes:

- in each source attempt that reaches them;
- again against exact frozen candidate bytes.

Retain every fixture inventory before removal and double ENOENT afterward.

──────────────────────────────────────────────────────────────────────────────
19. BOUNDED READ-ONLY LIVE REPLAY
──────────────────────────────────────────────────────────────────────────────

Run bounded read-only replay against unchanged supplied roots.

Do not execute:

- implementation production source;
- full independent audit parent;
- fresh rehearsal parent.

Require the repaired harness to:

1. authenticate the implementation package;
2. reproject its temporal inventory;
3. reproject manifest A/B;
4. resolve all 41 successor roles;
5. resolve production and qualification registries;
6. authenticate source freeze and frozen requalification;
7. derive one exact future rehearsal invocation;
8. authenticate Attempt-2 failure custody;
9. produce one consistent security result;
10. produce a passing empty-set cleanup result;
11. construct an in-memory terminal success result through the actual adapter;
12. construct the inline report without exception;
13. prepare the guarded terminal marker and verdict;
14. emit no package ACCEPT/BLOCK verdict in this repair task.

Retain:

validation/repaired-terminal-adapter-bounded-live-replay-v2.json

Allowed posture:

ready_for_fresh_full_audit

No package adjudication authority.

──────────────────────────────────────────────────────────────────────────────
20. INDEPENDENT TERMINAL-ADAPTER VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a fresh source-external independent validator.

It may not import:

- repaired audit-parent modules;
- repaired repair-core modules;
- producer fixtures;
- producer matrices;
- producer expected-result maps;
- producer interface-registry helpers.

It must independently verify:

- exact repair scope;
- predecessor/repaired source identities;
- unrelated-function AST equality;
- authority adjudication;
- adapter contract;
- complete interface registry;
- provider/consumer conformance;
- every adapter case;
- every cross-module interface case;
- all 209 prior cases;
- all six synthetic terminal lanes;
- bounded live replay;
- static and bytecode coverage;
- no full audit;
- no implementation mutation.

It must itself directly exercise the real:

`seal_audit()` → `build_inline_report()`

integration for success, BLOCK, and audit-failure shapes.

Retain:

validation/independent-terminal-adapter-repair-validator-v2.json

Require zero errors.

A validator that reads only copied result summaries is insufficient.

──────────────────────────────────────────────────────────────────────────────
21. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze only after:

- blocker reproduction;
- authority adjudication;
- bounded source delta;
- compilation/static gates;
- adapter matrix;
- interface matrix;
- prior 209-case regression;
- six synthetic terminal lanes;
- bounded live replay;
- independent validator;
- supplied-root equality.

Retain:

opening/final-terminal-adapter-repair-source-freeze-v2.json

Bind:

- exact source registry;
- predecessor identities;
- changed functions;
- protected-function identities;
- adapter contract;
- interface registry;
- all qualification results;
- bounded replay;
- no implementation mutation;
- full audit not executed;
- later modification permitted:
  false.

Reopen every source no-follow and verify exact identity.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
22. FROZEN-SOURCE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against exact frozen source bytes, rerun:

- compilation;
- static and bytecode gates;
- adapter matrix;
- interface matrix;
- all 209 prior cases;
- all six synthetic terminal lanes;
- bounded live replay;
- independent adapter validator;
- identity linkage;
- supplied-root closing equality.

Do not run the full audit.

Retain:

validation/frozen-terminal-adapter-repair-requalification-v2.json

Any mismatch blocks the task.

──────────────────────────────────────────────────────────────────────────────
23. HARNESS STATUS
──────────────────────────────────────────────────────────────────────────────

Generate preterminal status:

- status:
  gen2-independent-audit-harness-terminal-adapter-repaired-frozen-pending-fresh-audit;
- predecessor:
  historical noncurrent only after successor terminal closure;
- correction-evidence root:
  historical noncurrent;
- implementation mutated:
  false;
- implementation adjudicated:
  false;
- full audit executed:
  false;
- repaired harness qualification:
  passed;
- repaired harness frozen:
  true;
- fresh full audit required:
  true;
- current subject construction authorized:
  false;
- target audit:
  not executed;
- runtime validation:
  not rerun;
- product operation:
  not invoked;
- A6:
  not started.

Do not claim package acceptance or rejection.

──────────────────────────────────────────────────────────────────────────────
24. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete no-follow inventories for every supplied root opened:

- blocked predecessor repair;
- correction-evidence root;
- original failed audit;
- implementation package;
- successor Generation-2 package;
- authoritative contract;
- schema source;
- schema reconciliation;
- validation specification;
- Attempt-2 failed root;
- any other supplied root actually opened.

Require exact opening/closing equality.

Do not modify or clean supplied roots.

For every repair-owned fixture root:

- retain complete inventory;
- retain indispensable evidence;
- remove exact root;
- observe ENOENT twice;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
25. SUCCESSOR HARNESS-PACKAGE TERMINAL CLOSURE
──────────────────────────────────────────────────────────────────────────────

Before temporal projection:

- finalize all nonclosure artifacts;
- create only directories actually used;
- ensure `closeout/` and `manifest/` exist;
- ensure no empty descendant;
- exclusively create zero-length A/B;
- retain both descriptors;
- freeze the directory set;
- prohibit later directory creation.

Then:

1. generate temporal inventory excluding itself and A/B;
2. write into preexisting `closeout/`;
3. independently reproject immediately;
4. require equality;
5. independently generate A/B with A/B excluded;
6. require identical bytes;
7. write through retained descriptors;
8. fsync, close, fsync manifest directory;
9. reopen no-follow;
10. verify path/inode/type/mode/link/size/hash;
11. independently reproject final root;
12. require root row exactly once;
13. require no empty descendant;
14. require no symlink or special object;
15. require no multiply linked regular file;
16. require modes 0700/0600;
17. require no cache or bytecode;
18. transition seal once;
19. emit only guarded terminal marker;
20. exit nonreturningly;
21. perform no filesystem read or write after seal.

──────────────────────────────────────────────────────────────────────────────
26. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- exact source attempt;
- first blocker;
- structured exception;
- process ledger and streams;
- complete partial inventory;
- indispensable evidence before cleanup;
- fixture cleanup;
- supplied-root equality;
- harness authority false;
- source-freeze posture;
- terminal seal false;
- same-root retry false;
- lineage-retirement disposition when attempt budget is exhausted.

Do not create success manifests for a failed harness package.

Failure to retain indispensable evidence, complete cleanup, or close supplied
roots equally is:

HARNESS_REPAIR_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
27. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

only when:

- corrected predecessor status identity authenticates;
- predecessor repair root closes;
- Attempt-2 source authority closes;
- blocker reproduces;
- adapter authority is unambiguous;
- one closed adapter contract exists;
- no duplicate root alias exists;
- every cross-module interface is registered and directly tested;
- repair stays inside the bounded surface;
- adapter cases pass;
- interface cases pass;
- all prior 209 cases regress exactly;
- all six synthetic lanes pass through the real adapter;
- bounded live replay passes;
- independent validator directly covers the adapter;
- static and bytecode gates pass;
- source freezes;
- frozen requalification passes;
- implementation remains unchanged and unadjudicated;
- full audit remains unexecuted;
- supplied roots close equal;
- successor harness package terminally closes;
- no write follows seal.

Return:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIR_BLOCKED

when:

- adapter authority remains ambiguous;
- a governing contract requires conflicting shapes;
- another acceptance-bearing cross-module mismatch exists;
- repair exceeds the frozen surface;
- an interface cannot close;
- a matrix, synthetic lane, replay, static gate, or independent validator fails;
- actual source Attempt 2 fails.

When this verdict follows exhausted actual source attempts, retain:

- retire_incremental_harness_lineage:
  true
- clean_source_external_audit_harness_implementation_required:
  true
- further_localized_repair_authorized:
  false

Return:

HARNESS_REPAIR_PROVENANCE_MISMATCH

for:

- corrected predecessor identity mismatch;
- supplied-root mutation;
- fixed source/input mismatch;
- indispensable evidence loss;
- unaccounted process/filesystem effect;
- cleanup inequality;
- supplied-root closing inequality;
- harness-package closure failure;
- post-seal filesystem activity.

──────────────────────────────────────────────────────────────────────────────
28. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh successor repair-root identity
3. Corrected predecessor-status identity and authentication
4. Malformed predecessor-status identity disposition
5. Correction-evidence-root identity and disposition
6. Predecessor repair-root identity and closure
7. Exact Attempt-2 source authority
8. Original failed-audit identity and disposition
9. Implementation-package identity and closing equality
10. Successor Generation-2 identity and closing equality
11. External-root identities and closing equality
12. Attempt-2 failed-root identity and closing equality
13. Exact terminal-adapter blocker reproduction
14. Terminal-adapter authority adjudication
15. Canonical terminal-result schema
16. Canonical audit-root-identity pointer
17. Confirmation no duplicate alias exists
18. Complete cross-module interface registry
19. Repair authority and source surface
20. Source-attempt ledger
21. Final repaired source registry
22. Exact source delta
23. Protected-function equality
24. Terminal-adapter integration matrix
25. Cross-module interface matrix
26. Static and bytecode gates
27. Prior 209-case regression
28. Synthetic success path
29. Synthetic BLOCK path
30. Synthetic zero-root failure path
31. Synthetic one-root failure path
32. Synthetic temporal failure path
33. Synthetic manifest-B failure path
34. Bounded live replay
35. Independent adapter validator
36. Source freeze
37. Frozen-source requalification
38. Confirmation implementation source not executed
39. Confirmation full audit not executed
40. Harness status
41. Supplied-root closing equality
42. Fixture cleanup
43. Failure-closeout capability/use
44. Temporal-inventory identity
45. Manifest A identity
46. Manifest B identity
47. Independent terminal reprojection
48. Terminal membership and modes
49. No-write-after-closure
50. Incremental-lineage terminality disposition
51. Remaining uncertainty and nonclaims
52. Explicit confirmation registry

Required confirmations:

MALFORMED_PREDECESSOR_STATUS_IDENTITY_REJECTED
CORRECTED_PREDECESSOR_STATUS_IDENTITY_64_HEX
CORRECTED_PREDECESSOR_STATUS_IDENTITY_MANIFEST_A_AUTHENTICATED
CORRECTED_PREDECESSOR_STATUS_IDENTITY_MANIFEST_B_AUTHENTICATED
CORRECTED_PREDECESSOR_STATUS_IDENTITY_INDEPENDENTLY_RECOMPUTED
PREDECESSOR_STATUS_CORRECTION_SCOPE_ONE_FIXED_IDENTITY_ONLY
PREVIOUS_CORRECTION_RETRY_ROOT_MUTATION_NOT_PERFORMED
PREVIOUS_CORRECTION_RETRY_ROOT_NOT_RESUMED
PREVIOUS_CORRECTION_RETRY_CONSUMED_ZERO_SOURCE_ATTEMPTS
PREDECESSOR_REPAIR_ROOT_MUTATION_NOT_PERFORMED
PREDECESSOR_REPAIR_ROOT_NOT_RESUMED
EXACT_ATTEMPT_2_SOURCE_AUTHORITY_ESTABLISHED
ATTEMPT_1_SOURCE_NOT_PROMOTED
ORIGINAL_FAILED_AUDIT_ROOT_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_MUTATION_NOT_PERFORMED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
SUCCESSOR_GEN2_PACKAGE_MUTATION_NOT_PERFORMED
AUTHORITATIVE_CONTRACT_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_SOURCE_PACKAGE_MUTATION_NOT_PERFORMED
SCHEMA_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
VALIDATION_SPEC_SOURCE_MUTATION_NOT_PERFORMED
ATTEMPT_2_FAILED_ROOT_MUTATION_NOT_PERFORMED
TERMINAL_ADAPTER_MISMATCH_REPRODUCED
PROVIDER_RETURN_SHAPE_AUTHENTICATED
CONSUMER_REQUIRED_SHAPE_AUTHENTICATED
CANONICAL_ROOT_IDENTITY_POINTER_FROZEN
CANONICAL_ROOT_IDENTITY_POINTER_IS_INVENTORY_ROOT_IDENTITY
TOP_LEVEL_ROOT_IDENTITY_ALIAS_NOT_INTRODUCED
TERMINAL_ADAPTER_CONTRACT_CLOSED
TERMINAL_ADAPTER_TOTAL_ACCESSOR_IMPLEMENTED
NO_TERMINAL_ADAPTER_POINTER_FALLBACK
COMPLETE_CROSS_MODULE_INTERFACE_REGISTRY_PRODUCED
EVERY_ACCEPTANCE_BEARING_CROSS_MODULE_INTERFACE_REGISTERED
EVERY_REGISTERED_INTERFACE_DIRECTLY_TESTED
REPAIR_BOUNDED_TO_TERMINAL_ADAPTER_AND_INTERFACE_COVERAGE
PACKAGE_ACCEPTANCE_RULES_UNCHANGED
PACKAGE_VERDICT_CONSTANTS_UNCHANGED
UNRELATED_AUDIT_FUNCTIONS_AST_IDENTICAL
SOURCE_ATTEMPT_LIMIT_RESPECTED
TERMINAL_ADAPTER_SUCCESS_PATH_PASSED
TERMINAL_ADAPTER_BLOCK_PATH_PASSED
TERMINAL_ADAPTER_AUDIT_FAILURE_PATH_PASSED
OLD_KEYERROR_PATH_REJECTED_BY_REGRESSION
MISSING_INVENTORY_REJECTED
WRONG_INVENTORY_TYPE_REJECTED
MISSING_ROOT_IDENTITY_REJECTED
TOP_LEVEL_ALIAS_ONLY_REJECTED
CONFLICTING_ROOT_IDENTITY_ALIAS_REJECTED
NO_FILESYSTEM_OPERATION_IN_POSTSEAL_ADAPTER_PATH
TERMINAL_ADAPTER_MATRIX_PASSED
CROSS_MODULE_INTERFACE_MATRIX_PASSED
STATIC_INTERFACE_GATES_PASSED
BYTECODE_INTERFACE_GATES_PASSED
PRIOR_209_CASE_REGRESSION_PASSED
SYNTHETIC_SUCCESS_CAPSULE_PASSED
SYNTHETIC_BLOCK_CAPSULE_PASSED
SYNTHETIC_ZERO_ROOT_FAILURE_CAPSULE_PASSED
SYNTHETIC_ONE_ROOT_FAILURE_CAPSULE_PASSED
SYNTHETIC_TEMPORAL_FAILURE_CAUSAL_PASSED
SYNTHETIC_MANIFEST_B_FAILURE_CAUSAL_PASSED
BOUNDED_LIVE_REPLAY_PASSED
INDEPENDENT_TERMINAL_ADAPTER_VALIDATOR_PASSED
INDEPENDENT_VALIDATOR_EXERCISED_REAL_SEAL_TO_REPORT_PATH
REPAIRED_HARNESS_SOURCE_FROZEN
REPAIRED_HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_HARNESS_REQUALIFICATION_PASSED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_CREATED
SUCCESSOR_HARNESS_TEMPORAL_INVENTORY_VERIFIED
SUCCESSOR_HARNESS_MANIFEST_A_CREATED
SUCCESSOR_HARNESS_MANIFEST_B_CREATED
SUCCESSOR_HARNESS_MANIFESTS_BYTE_IDENTICAL
SUCCESSOR_HARNESS_TERMINAL_REPROJECTION_PASSED
SUCCESSOR_HARNESS_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_WRITE_AFTER_TERMINAL_CLOSURE
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

If the verdict is:

SCHEMA_SUBJECT_RECONSTRUCTION_PARENT_GEN2_INDEPENDENT_AUDIT_HARNESS_TERMINAL_ADAPTER_REPAIRED_READY_FOR_FRESH_AUDIT

the next tranche is exactly one new fresh independent audit of the unchanged
sealed implementation package.

Do not combine that audit with this repair.

If the blocked verdict follows the two actual source attempts, retire this
incremental harness lineage and require a clean source-external audit-harness
implementation. Do not issue another localized repair.
```

**Sources:** The attached report identifies the sole opening failure as the malformed 48-character expected digest and supplies the independently observed 64-character value. It also confirms that predecessor closure passed, Attempt-2 source authority was established, no source attempt began, no source changed, every supplied root closed equal, and neither the implementation source nor the full audit ran. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"} :chatgpt-content-reference{index="8"} :chatgpt-content-reference{index="9"}

**Confidence:** 0.999 that this was a malformed supplied-identity stop rather than a source or package defect; 0.995 that the two-attempt source budget remains intact; 0.98 that the corrected prompt should proceed with the same final bounded repair and retain the previously stated lineage-retirement stop condition.
