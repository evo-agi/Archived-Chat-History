## Assessment

The reconciliation is decisive: **the Validation-Custody V3 target and the live V2 audit root do not require repair.** Both failures belong to the newly generated target-audit harness.

The opening failure came from an authority-blind selector that ranked arbitrary path-containing JSON objects by size. It chose a diagnostic `raw_source` object with no device, inode, or mode fields, while the target already contained an exact current opening chain:

`target manifests` → `opening/accepted-opening-gate-v2.json` → `opening/v2-independent-audit-root.inventory-v2.json` → live V2 root.

That chain matches the live V2 root exactly.

The finalizer has four linked defects:

- It rejects the deliberately reserved empty `manifest/` directory **before** writing manifests A and B.
- It creates a positive “success commit” before the temporal inventory, manifests, read-back, terminal closure, and finalizer completion.
- It never reads back and compares A and B.
- Its direct-process custody and failure outcome are incomplete.

The best repair is therefore a new immutable **target-audit payload/finalizer package**, leaving the accepted bootstrap, target package, V2 evidence, and every supporting root unchanged. The finalizer should remain a terminal direct process, because routing it through the wrapper would create a wrapper outcome after capsule sealing. Its creation and termination must instead be explicitly split between an in-capsule prelaunch/self-start contract and the Codex platform transcript as top-level process authority.

Forward this prompt to Codex:

```text
BOUNDED VALIDATION-CUSTODY V3 TARGET-AUDIT HARNESS REPAIR —
AUTHORITATIVE ROOT BINDINGS AND TERMINAL FINALIZER

This task repairs only the audit harness defects established by:

TARGET_AUDIT_PROVENANCE_RECONCILED_AUDIT_HARNESS_DEFECT

It creates, qualifies, and freezes an immutable target-audit payload/finalizer
package for one later fresh target audit.

It is not:

- a Validation-Custody V3 target repair;
- a target audit retry;
- an accepted-bootstrap repair;
- a V2 evidence repair;
- a repository or product task.

Do not modify any supplied root.
Do not execute Plan V3 or Plan V4.
Do not rerun runtime validation.
Do not run Git.
Do not use the network.
Do not run repository tests, product code, installation, deployment,
publication, commit, or A6.
Do not create subagents or direct auditors.
Do not perform the full semantic target audit in this task.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_REPAIR_READY
TARGET_AUDIT_HARNESS_REPAIR_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. EXACT FAILED AUDIT AND BASE HARNESS SOURCE
──────────────────────────────────────────────────────────────────────────────

FAILED_TARGET_AUDIT_ROOT:

/Users/ds/Downloads/ES-validation-custody-v3-full-audit-xxatpfsc

Expected identity:

- device/inode:
  16777234 / 180052628
- mode:
  0700
- historical verdict:
  AUDIT_PROVENANCE_MISMATCH

BASE_TARGET_AUDIT_SOURCE:

/Users/ds/Downloads/ES-validation-custody-v3-full-audit-xxatpfsc/payloads/target_audit_payload_v1.py

Expected identity:

- device/inode:
  16777234 / 180053646
- mode/link count:
  0600 / 1
- size:
  165052
- SHA-256:
  5dfd0d9a77ed0dcae6c4a32954916f607ac582fcbb453e5955da6adfb701528f

Authenticate the failed audit’s complete retained inventory and open the source
no-follow.

Also authenticate:

provenance/carrier-0003.request.json

- size:
  12989
- SHA-256:
  5f823f5976e30c4b765bd68849b5cc77e16a006b4a5c7df2371c073b301cbf19

provenance/carrier-0003.phase-start.json

- size:
  12794
- SHA-256:
  ec029ab0a034c59f7abb833ed9920e17ed6a350d4d71829df9653ff9e9bf591b

provenance/carrier-0003.phase-outcome.json

- size:
  3363
- SHA-256:
  62098f471ba73dcced770c3a1dee20648fad3697feba0396f70fe0704fd59fff

closeout/finalization-success-commit-v1.json

- size:
  1198
- SHA-256:
  8312f04583b21cef3fdb05b5741effdad7a5a891dcc0da85f25309252ce492db

The failed audit root is historical evidence only. Do not resume, repair, clean,
complete, or reseal it.

──────────────────────────────────────────────────────────────────────────────
2. GOVERNING RECONCILIATION
──────────────────────────────────────────────────────────────────────────────

RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-provenance-reconciliation-wtfwwjks

Expected identity:

- device/inode:
  16777234 / 180074421
- mode:
  0700
- verdict:
  TARGET_AUDIT_PROVENANCE_RECONCILED_AUDIT_HARNESS_DEFECT

Authenticate the complete diagnostic closure and inspect at minimum:

analysis/v2-root-identity-claim-ledger.json
analysis/authoritative-binding-hierarchy.json
analysis/failed-audit-selector.json
analysis/v2-expected-observed.json
analysis/opening-counterfactual-matrix.json
analysis/finalizer-identity-process-custody.json
analysis/finalizer-control-flow.json
analysis/empty-directory-policy.json
analysis/finalization-success-commit-adjudication.json
analysis/failure-capsule-semantics.json
analysis/finalizer-mutation-matrix.json
analysis/classification-and-remediation.json
closing/supplied-root-equality.json
closeout/final-diagnostic-inventory.json

The governing classifications are:

- opening failure:
  AUDIT_OPENING_SELECTOR_DEFECT
- finalizer failure:
  MIXED_FINALIZER_DEFECT
- target defects established:
  none
- accepted-bootstrap defects established:
  none

No target or bootstrap repair authority exists.

──────────────────────────────────────────────────────────────────────────────
3. READ-ONLY FIXED INPUTS
──────────────────────────────────────────────────────────────────────────────

TARGET_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b

Expected identity:

- device/inode:
  16777234 / 178948757
- mode:
  0700

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected identity:

- device/inode:
  16777234 / 178646858
- mode:
  0700

ACCEPTED_BOOTSTRAP_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-v1-a-c-h-i-repair-kqe10x4t

Expected identity:

- device/inode:
  16777234 / 179405897
- mode:
  0700

ACCEPTED_BOOTSTRAP_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-full-audit-bootstrap-a-c-h-i-independent-audit-sbv__euv

QUALIFIED_LAUNCHER_ROOT:

/Users/ds/Downloads/ES-repair10i-wrapped-carrier-launcher-qualified-oh57ev38

IMPORT_RECONCILIATION_ROOT:

/Users/ds/Downloads/ES-repair10i-launcher-package-import-reconciliation-xqrjt92s

PINNED_PYTHON:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13

Every opened root is subject to complete lstat/no-follow opening and closing
equality.

Do not inspect repositories, Strategic B, V1/V2/V3 runtime targets, or product
source beyond the exact source-external records required to qualify this
harness repair.

──────────────────────────────────────────────────────────────────────────────
4. FRESH REPAIR PACKAGE
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-target-audit-harness-repair-

Immediately emit:

HARNESS_REPAIR_ROOT=<absolute-path>

Retain before semantic work:

opening/bootstrap-start.json

Record:

- fresh-root identity;
- allocation method;
- umask;
- failed-audit identity;
- base-source identity;
- reconciliation identity;
- exact read-only fixed inputs;
- full target audit executed:
  false;
- runtime validation rerun:
  false.

Create directories lazily. Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
5. EXACT OPENING SOURCE COPY
──────────────────────────────────────────────────────────────────────────────

Copy the exact 165052-byte base source to:

opening/original-target-audit-payload.py

Use:

- no-follow read;
- exclusive destination creation;
- mode 0600;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison;
- stable pre/post-read fstat identity.

Retain:

opening/original-source-identity.json

──────────────────────────────────────────────────────────────────────────────
6. CLOSED REPAIR SCOPE
──────────────────────────────────────────────────────────────────────────────

Create:

working/target_audit_payload_v2.py

Only these harness surfaces may change:

1. Supporting-root authoritative binding selection.
2. Binding-schema and role enforcement.
3. Target-audit finalizer lifecycle.
4. Reserved `manifest/` premanifest treatment.
5. Manifest A/B write, reopen, identity, and byte-equality checks.
6. Terminal empty-directory check.
7. Premature success-record authority.
8. Direct-finalizer process-custody contract.
9. Explicit finalizer failure outcome.
10. Terminal success region and no-write-after-seal behavior.

Preserve all substantive target-audit semantics, including:

- exact supplied operands;
- sole-writer adjudication;
- failed-attempt lineage;
- authoritative supersession;
- V2 adoption and observation lineage;
- contract field map;
- authority and nonauthority;
- Plan V3/V4 equivalence;
- five-source closure;
- 86-byte derivation;
- independent mutation matrix;
- capsule/security review;
- failed-attempt adjudication;
- analytical perspectives;
- verdict rules.

Do not change any target acceptance criterion to obtain a passing audit.

Repair ownership:

validation-custody-v3-target-audit-binding-and-finalizer-lifecycle

──────────────────────────────────────────────────────────────────────────────
7. AUTHORITATIVE SUPPORT-ROOT BINDING POLICY
──────────────────────────────────────────────────────────────────────────────

Remove authority from generic functions equivalent to:

`smallest_binding_document`
`binding_matches_root`

Do not recursively select arbitrary path-containing dictionaries.
Do not rank by canonical size, filename, discovery order, or first match.
Do not fall back to diagnostic, adoption, report, lineage, or historical
records.

For the current target, the sole authoritative support-root registry is:

opening/accepted-opening-gate-v2.json

Strictly require its exact schema and field map.

Resolve the V2 independent-audit binding only through:

/complete_opening_inventories/v2_independent_audit

The referenced operand must be:

opening/v2-independent-audit-root.inventory-v2.json

Require its exact schema:

execution-substrate.repair10i-t2ap.audit-repair.complete-supplied-root-inventory.v2

Require:

- label:
  v2_independent_audit
- exact root path;
- exact device/inode/mode;
- complete membership;
- exact content digest;
- exact binding from the accepted opening gate;
- exact authentication through target manifest closure.

The live required identity is:

- device/inode:
  16777234 / 178646858
- mode:
  0700
- entries:
  218
- target-grammar digest:
  d724b872ca99a7339f05c9dcd94318fbce0d1e69e8b24b736dbc6f0aab1f33e3

Unknown, missing, duplicate, ambiguous, stale, superseded, or wrong-role bindings
must fail closed.

Apply the same exact accepted-opening-gate registry mechanism to every support
root named there.

No diagnostic reproduction record may establish current physical root
identity.

──────────────────────────────────────────────────────────────────────────────
8. SUPPORT-BINDING MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Create a literal audit-owned matrix covering at minimum:

1. Exact accepted-opening-gate baseline.
2. Exact V2 inventory baseline.
3. Diagnostic reproduction record offered as binding.
4. Adoption row offered as binding.
5. Observation-lineage row offered as binding.
6. Supersession record offered as physical binding.
7. Report prose offered as binding.
8. Missing opening-gate field.
9. Duplicate V2 binding.
10. Unknown label.
11. Wrong inventory schema.
12. Wrong inventory label.
13. Wrong root path.
14. Wrong device.
15. Wrong inode.
16. Wrong mode.
17. Wrong membership digest.
18. Missing inventory file.
19. Stale inventory identity.
20. Superseded historical binding.
21. Content-only match with wrong physical root.
22. Physical match with wrong content.
23. Generic smallest-object selection attempt.
24. Filename-substring selection attempt.
25. First-match fallback attempt.

Require:

- exact literal names;
- uniqueness;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/support-binding-mutation-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
9. READ-ONLY SUPPORT-BINDING REPLAY
──────────────────────────────────────────────────────────────────────────────

Run the repaired binding resolver read-only against the exact target and live
V2 root.

Require:

- exact accepted-opening-gate path and pointer;
- exact referenced inventory path;
- exact schema and label;
- exact device/inode/mode;
- exact membership and digest;
- no diagnostic record considered authoritative;
- zero ambiguity;
- no target or V2-root write.

Retain:

validation/support-binding-live-replay-v1.json

Do not begin substantive target adjudication.

──────────────────────────────────────────────────────────────────────────────
10. TARGET-AUDIT FINALIZATION MODEL
──────────────────────────────────────────────────────────────────────────────

Preserve the two-stage target-audit execution model:

- Carrier 0003 performs semantic target adjudication and produces all preseal
  outputs.
- One direct terminal finalizer validates and seals the target-audit capsule.

The direct finalizer is necessary because a wrapper-created phase outcome after
manifest closure would violate the no-write-after-seal boundary.

Freeze this process-authority split explicitly.

The Codex platform transcript is authoritative for direct-finalizer process
creation and termination.

The audit capsule is authoritative for:

- finalizer invocation contract;
- finalizer self-start;
- preseal verification;
- closeout bytes;
- temporal inventory;
- manifest bytes;
- failure outcome when failure occurs;
- terminal marker contract.

No in-capsule success outcome may be written after terminal manifest closure.

──────────────────────────────────────────────────────────────────────────────
11. FINALIZER INVOCATION CONTRACT
──────────────────────────────────────────────────────────────────────────────

Carrier 0003 must retain before returning:

process/finalizer-invocation-contract-v1.json

It must bind:

- finalizer source path;
- source size and SHA-256;
- exact argv;
- exact cwd;
- exact explicit environment;
- no stdin;
- expected stdout contract;
- expected stderr contract;
- expected exit semantics;
- authorized operands;
- expected preseal files;
- expected finalizer-created files;
- process-authority split;
- failure behavior;
- terminal marker;
- no-write-after-seal rule.

The direct invocation must use pinned Python with:

-I -S -B

and the repaired payload source’s `--finalize` mode.

The finalizer must verify this invocation contract before touching closeout
state.

──────────────────────────────────────────────────────────────────────────────
12. FINALIZER PROCESS CUSTODY
──────────────────────────────────────────────────────────────────────────────

At finalizer start, retain:

process/finalizer-self-start-v1.json

Bind:

- actual source identity;
- actual argv;
- cwd;
- explicit owned environment;
- effective interpreter flags;
- PID;
- invocation-contract identity;
- audit-root identity;
- start timestamp;
- stdin posture.

The direct platform invocation must retain externally:

- submitted argv;
- cwd;
- explicit environment;
- PID, when exposed;
- raw stdout;
- raw stderr;
- exit or signal;
- duration.

On success, the platform transcript is the termination authority.

On failure before seal, the finalizer must retain:

process/finalizer-failure-outcome-v1.json

including:

- exact exception;
- operation;
- source line;
- paths written;
- manifest posture;
- seal posture;
- intended exit;
- no success claim.

Do not claim that the capsule self-attests the top-level process launch or
post-exit platform result.

──────────────────────────────────────────────────────────────────────────────
13. PRESEAL CLOSEOUT SEQUENCE
──────────────────────────────────────────────────────────────────────────────

The finalizer must perform this exact order before manifest generation:

1. Authenticate its source and invocation contract.
2. Authenticate Carrier 0003 request, start, outcome, payload, and outputs.
3. Verify every declared preseal output exists and matches.
4. Verify semantic audit phases and verdict records are terminal.
5. Verify supplied-root closing equality.
6. Verify cleanup-set equality.
7. Write and finalize:
   - primary verdict;
   - explicit confirmations;
   - severity findings;
   - uncertainty/nonclaims;
   - final report.
8. Write a nonauthoritative preseal-ready record.
9. Write the temporal final inventory.
10. Verify no unexpected output path exists.
11. Perform the premanifest empty-directory check.

The preseal-ready record must be named and typed as nonauthoritative, for
example:

closeout/finalizer-preseal-ready-v1.json

Required fields:

- authoritative:
  false;
- terminal_success:
  false;
- preseal_ready:
  true;
- required manifest names;
- exact closeout identities;
- temporal-inventory identity;
- process-authority split;
- no claim of finalizer completion;
- no claim of terminal capsule closure.

Do not retain a record named or typed as a success commit before manifests.

The historical `finalization-success-commit-v1.json` is not copied into the new
audit and is classified as failed-attempt evidence only.

──────────────────────────────────────────────────────────────────────────────
14. PREMANIFEST EMPTY-DIRECTORY POLICY
──────────────────────────────────────────────────────────────────────────────

At the premanifest checkpoint:

- `manifest/` may be absent and creatable; or
- `manifest/` may exist and be empty as the reserved destination.

No other retained directory may be empty.

Require the exact empty-directory set to be either:

- empty; or
- `["manifest"]`.

Reject:

- any unrelated empty directory;
- multiple empty directories;
- symlinked manifest directory;
- wrong manifest-directory mode;
- wrong manifest-directory ownership or identity.

Do not reject the reserved empty `manifest/` directory before A and B are
created.

──────────────────────────────────────────────────────────────────────────────
15. TEMPORAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

The temporal final inventory must be finalized before manifest A and B.

It must:

- represent the exact declared pre-manifest projection;
- exclude itself as declared;
- exclude future manifests A and B;
- represent the reserved manifest-directory policy explicitly;
- bind every current nonmanifest object;
- have stable grammar excluding unstable directory size/link metadata where
  required;
- be reopened and reverified before manifest generation.

No later nonmanifest write is permitted after the temporal inventory except the
predeclared manifest A/B sequence and directory metadata necessarily caused by
those writes.

──────────────────────────────────────────────────────────────────────────────
16. MANIFEST GENERATION AND READ-BACK
──────────────────────────────────────────────────────────────────────────────

After the premanifest checks pass:

1. Ensure `manifest/` exists as the exact reserved directory.
2. Independently generate manifest bytes A and B using separate implementations.
3. Require generated bytes to be byte-identical before writing.
4. Exclusively create manifest A.
5. Write all bytes, fsync, close.
6. Exclusively create manifest B.
7. Write all bytes, fsync, close.
8. Fsync the manifest directory.
9. Reopen A no-follow and read all bytes.
10. Reopen B no-follow and read all bytes.
11. Recompute size and SHA-256 for both.
12. Require:
    - exact expected identities;
    - A equals generated A;
    - B equals generated B;
    - A equals B.
13. Independently regenerate the whole-root projection after installation.
14. Require exact equality with both on-disk manifests.
15. Perform the terminal empty-directory check.

At terminal closure:

- no retained directory may be empty;
- no missing or extra path may exist;
- no symlink, special object, or multi-link file may exist;
- all modes must satisfy the capsule policy.

──────────────────────────────────────────────────────────────────────────────
17. TERMINAL SEAL
──────────────────────────────────────────────────────────────────────────────

Use one explicit state:

terminal_seal_committed = false

It may become true exactly once, only after:

- A and B are written;
- both are read back;
- identities pass;
- byte equality passes;
- independent reprojection passes;
- terminal empty-directory check passes;
- no acceptance-bearing filesystem operation remains.

After:

terminal_seal_committed = true

allow only:

- locally guarded terminal stdout:
  `TARGET_AUDIT_TERMINAL_SEAL_COMPLETE\n`
- immediate `os._exit(0)`.

No filesystem read or write may follow the seal transition.

The outer failure handler must contain a seal guard:

- when sealed:
  immediate `os._exit(0)`;
- when unsealed:
  retain explicit failure outcome and exit nonzero.

──────────────────────────────────────────────────────────────────────────────
18. FAILURE PATHS
──────────────────────────────────────────────────────────────────────────────

For failure before terminal seal:

- do not claim success;
- write the explicit finalizer failure outcome;
- retain exact partial-manifest posture;
- remove audit-owned partial A or B only when the failure policy authorizes it;
- retain the reserved empty `manifest/` directory when appropriate;
- keep the capsule explicitly unsealed;
- emit no terminal-seal marker;
- exit nonzero.

A failure capsule may contain:

- temporal inventory;
- empty reserved `manifest/`;
- absent manifests;
- partial failure evidence.

It may not contain:

- authoritative success claim;
- terminal-seal claim;
- success caption;
- authoritative “success commit.”

──────────────────────────────────────────────────────────────────────────────
19. FINALIZER MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Implement the exact 20-case registry established by the reconciliation:

1. Valid preseal outputs and reserved empty manifest directory.
2. Unrelated empty retained directory.
3. Temporal inventory absent.
4. Temporal inventory malformed.
5. Manifest directory absent but creatable.
6. Manifest directory present and empty.
7. Manifest A write failure.
8. Manifest B write failure.
9. A/B byte mismatch.
10. A/B identity mismatch.
11. Empty directory after A/B.
12. Success authority created before manifests.
13. Success authority created after manifest closure.
14. Failure after preseal-ready record.
15. Failure after A but before B.
16. Failure after A/B but before terminal seal.
17. Terminal seal followed by attempted write.
18. Failure capsule with absent manifests.
19. Success capsule with absent manifests.
20. Unknown output path.

Require exact expected classifications from the reconciliation.

Add further cases for:

- missing finalizer invocation contract;
- stale source identity;
- wrong argv;
- wrong cwd;
- wrong environment;
- missing self-start;
- unexpected stdout;
- nonempty stderr on success;
- missing terminal marker;
- nonzero success exit;
- write after seal;
- unrecorded finalizer failure.

Require:

- exact literal registry;
- uniqueness;
- two-way closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip.

Retain:

validation/finalizer-mutation-matrix-v2.json

──────────────────────────────────────────────────────────────────────────────
20. INDEPENDENT FINALIZER VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a second validator that imports neither the repaired target-audit
source nor the first matrix helper.

It must independently validate:

- binding resolver;
- invocation contract;
- process-authority split;
- preseal-ready nonauthority;
- temporal inventory;
- reserved manifest directory;
- A/B generation;
- A/B read-back;
- terminal empty-directory rule;
- success/failure classification;
- terminal seal;
- no-write-after-seal.

Use its own literal case registry and expected reasons.

Require the same zero-error conditions.

Retain:

validation/independent-finalizer-validator-v1.json

──────────────────────────────────────────────────────────────────────────────
21. BOUNDED QUALIFICATION CAUSALS
──────────────────────────────────────────────────────────────────────────────

Do not run the real target audit.

Use synthetic audit-owned fixture roots only.

Run at minimum:

A. Successful finalization causal

- complete valid synthetic preseal outputs;
- reserved empty manifest directory;
- exact direct-finalizer invocation contract;
- direct finalizer launched with pinned Python;
- platform process custody retained outside the fixture root;
- exit 0;
- terminal marker exact;
- stderr empty;
- A/B present and byte-identical;
- no postseal write;
- no authoritative preseal record.

B. Unrelated empty-directory failure

- add one unrelated empty directory;
- finalizer exits nonzero;
- failure outcome exists;
- manifests absent;
- no terminal marker;
- no success claim.

C. Manifest-B failure

- inject qualification-only B-write failure;
- A/B pair not accepted;
- failure outcome exact;
- capsule unsealed;
- no write after failure outcome beyond allowed failure closure.

D. A/B mismatch

- inject qualification-only independent-generator mismatch;
- reject before seal;
- retain failure outcome.

E. Failure after preseal-ready

- preseal-ready remains nonauthoritative;
- later failure cannot be interpreted as success.

Fault injection must remain qualification-only and unreachable from ordinary
future target-audit execution.

For every fixture:

- retain complete pre-removal inventory;
- remove only the exact fixture root;
- record two fresh ENOENT observations;
- require zero process and descriptor survivors.

──────────────────────────────────────────────────────────────────────────────
22. PROCESS-CUSTODY QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

For every direct-finalizer qualification launch retain externally:

- exact argv;
- cwd;
- explicit environment;
- child PID;
- stdout/stderr bytes;
- exit/signal;
- duration;
- reaping;
- descriptor closure;
- exact fixture root written.

Within each fixture require:

- finalizer invocation contract;
- finalizer self-start;
- success or failure posture;
- declared outputs only.

Demonstrate that the finalizer does not claim in-capsule authority over its
top-level process creation or termination.

──────────────────────────────────────────────────────────────────────────────
23. EXACT SEMANTIC DELTA
──────────────────────────────────────────────────────────────────────────────

Retain a complete original-to-repaired source delta.

For every changed hunk record:

- original and repaired source range;
- owning defect:
  opening selector,
  empty-directory checkpoint,
  premature success authority,
  manifest read-back,
  process custody,
  failure outcome,
  terminal seal;
- behavior before;
- behavior after;
- governing reconciliation evidence;
- authority effect;
- unrelated substantive target-audit semantics changed:
  false.

Expected ownership:

validation-custody-v3-target-audit-binding-and-finalizer-lifecycle

If another semantic target-audit change is indispensable, stop with:

TARGET_AUDIT_HARNESS_REPAIR_BLOCKED

Do not widen the repair.

──────────────────────────────────────────────────────────────────────────────
24. COMPILATION AND STATIC GATES
──────────────────────────────────────────────────────────────────────────────

Compile the complete repaired source using pinned Python with:

-I -S -B

without executing the real target audit.

Require:

- exit 0;
- empty stdout;
- empty stderr;
- source unchanged.

Run static checks for:

- finite Carrier 0003 path;
- finite direct-finalizer path;
- no stdin or persistent loop;
- no subagent/direct-auditor interface;
- exact support-root binding registry;
- no generic smallest-object selector;
- process-custody contract present;
- failure handler present;
- unique terminal-seal state;
- no postseal filesystem read/write;
- no production-reachable qualification injection hook.

Use two independent postseal analyses:

- AST/call graph;
- bytecode/exception-table CFG.

Require agreement.

──────────────────────────────────────────────────────────────────────────────
25. RETAINED-EVIDENCE REPLAY
──────────────────────────────────────────────────────────────────────────────

Run the repaired selector and finalizer logic read-only against the failed audit
and unchanged target records.

Require:

- V2 binding resolves to the dedicated opening inventory;
- live V2 identity/content pass;
- diagnostic reproduction record is rejected as authority;
- reserved empty `manifest/` is allowed premanifest;
- unrelated empties reject;
- historical premature success record is classified nonauthoritative;
- historical failure capsule remains unsealed;
- no target verdict is emitted.

Retain:

validation/retained-failed-audit-replay-v1.json

──────────────────────────────────────────────────────────────────────────────
26. FREEZE THE REPAIRED TARGET-AUDIT PACKAGE
──────────────────────────────────────────────────────────────────────────────

Only after all prior gates pass, retain:

source/target_audit_payload_v2.py
contract/target-audit-plan-v2.json
contract/support-root-binding-policy-v1.json
contract/finalizer-lifecycle-v1.json
contract/finalizer-process-custody-v1.json
templates/carrier-0003-request-template-v2.json
templates/finalizer-invocation-contract-template-v1.json

Freeze exact identities for every exported file.

The plan must preserve every substantive operand and acceptance rule from the
failed target audit, changing only the authorized harness surfaces.

Retain:

opening/target-audit-harness-freeze-v1.json

with:

- base-source identity;
- repaired-source identity;
- exact delta;
- all contract/template identities;
- selector matrix identity;
- finalizer matrix identity;
- independent-validator identity;
- qualification-causal identities;
- static-check identities;
- target audit executed:
  false;
- target bytes modified:
  false;
- accepted bootstrap bytes modified:
  false;
- later modification permitted:
  false.

──────────────────────────────────────────────────────────────────────────────
27. FROZEN-PACKAGE REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Against the frozen exported paths:

1. Reopen no-follow and verify every identity.
2. Recompile the payload.
3. Rerun support-binding matrix.
4. Rerun support-binding live replay.
5. Rerun finalizer matrix.
6. Rerun independent validator.
7. Rerun retained-failed-audit replay.
8. Rerun static and postseal analyses.
9. Compare all results with pre-freeze results under documented root-bound
   normalization.

Require complete equality.

Retain:

validation/frozen-harness-requalification-v1.json

Any mismatch requires:

PREFLIGHT_PROVENANCE_MISMATCH

Do not edit frozen files.

──────────────────────────────────────────────────────────────────────────────
28. NO REAL TARGET AUDIT
──────────────────────────────────────────────────────────────────────────────

Do not:

- materialize a real target-audit root for substantive adjudication;
- execute Carrier 0003 against the real target;
- invoke the real finalizer against a real audit capsule;
- adjudicate sole writer, adoption, Plan equivalence, source closure, security,
  or target authority;
- produce a target ACCEPT/BLOCK/REJECT verdict.

This task ends after harness qualification and freeze.

──────────────────────────────────────────────────────────────────────────────
29. SUPPLIED-ROOT CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat complete lstat/no-follow inventories for every supplied root opened.

Require exact opening/closing equality for:

- failed target-audit root;
- target root;
- V2 audit root;
- accepted bootstrap;
- accepted bootstrap audit;
- qualified launcher;
- import reconciliation;
- reconciliation root;
- pinned Python.

Do not modify or clean supplied roots.

──────────────────────────────────────────────────────────────────────────────
30. REPAIR-PACKAGE CLOSURE
──────────────────────────────────────────────────────────────────────────────

Finalize before terminal manifests:

- bootstrap start;
- supplied-root bindings;
- original source;
- repaired source;
- exact delta;
- binding policy;
- binding mutation matrix;
- binding live replay;
- finalizer lifecycle;
- process-custody contract;
- finalizer matrix;
- independent validator;
- qualification causals;
- process-custody evidence;
- retained-evidence replay;
- compilation;
- static analyses;
- frozen exports;
- freeze record;
- frozen requalification;
- supplied-root closing equality;
- final report;
- temporal final inventory.

Then independently generate manifest A and B.

Require:

- root represented;
- every retained directory represented;
- every nonmanifest regular file represented;
- exactly two manifest self-exclusions;
- no empty retained directory;
- no symlink;
- no special object;
- no multiply linked file;
- directories 0700;
- files regular, single-link 0600;
- byte-identical manifests;
- no write after closure.

──────────────────────────────────────────────────────────────────────────────
31. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_REPAIR_READY

only when:

- all supplied roots authenticate and close;
- source authority is exact;
- repair delta is bounded to the confirmed harness defects;
- authoritative binding selection passes;
- selector matrix passes;
- live binding replay passes;
- finalizer lifecycle passes;
- finalizer matrix passes;
- independent validator passes;
- success and failure qualification causals pass;
- process custody is complete;
- retained-evidence replay passes;
- source compiles;
- static and postseal checks pass;
- exported package is frozen;
- frozen requalification passes;
- supplied-root closing equality passes;
- repair package closes;
- no real target audit ran;
- no target or bootstrap byte changed.

Return:

TARGET_AUDIT_HARNESS_REPAIR_BLOCKED

when:

- the repair requires wider substantive audit changes;
- a target documentary defect is discovered;
- a bootstrap defect is discovered;
- exact binding authority remains ambiguous;
- finalizer success/failure semantics cannot close;
- process custody cannot be made complete;
- any static or qualification causal fails.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- supplied-root mutation or closing inequality;
- source-authority mismatch;
- unauthorized source drift;
- frozen-package mismatch;
- repair-package closure failure.

──────────────────────────────────────────────────────────────────────────────
32. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh repair-root identity
3. Failed target-audit identity
4. Reconciliation identity
5. Target identity and closure
6. V2 audit identity and closure
7. Accepted bootstrap identities
8. Original target-audit source identity
9. Repaired target-audit source identity
10. Exact semantic delta
11. Authoritative support-binding policy
12. Support-binding mutation matrix
13. Support-binding live replay
14. Finalizer process-authority split
15. Finalizer invocation contract
16. Finalizer self-start contract
17. Premanifest empty-directory policy
18. Preseal-ready nonauthority
19. Temporal inventory policy
20. Manifest generation and read-back
21. Terminal empty-directory policy
22. Terminal-seal control flow
23. Failure-outcome treatment
24. Finalizer mutation matrix
25. Independent finalizer validator
26. Successful finalization causal
27. Failure qualification causals
28. Direct-finalizer process custody
29. Retained failed-audit replay
30. Compilation and static gates
31. Frozen exported package identities
32. Freeze-record identity
33. Frozen-package requalification
34. Supplied-root closing equality
35. Repair-package inventory and manifests
36. Confirmation real target audit did not run
37. Remaining uncertainty and nonclaims
38. Explicit confirmations

Required confirmations:

FAILED_TARGET_AUDIT_ROOT_MUTATION_NOT_PERFORMED
TARGET_ROOT_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_ROOT_MUTATION_NOT_PERFORMED
ACCEPTED_BOOTSTRAP_ROOT_MUTATION_NOT_PERFORMED
ACCEPTED_BOOTSTRAP_AUDIT_ROOT_MUTATION_NOT_PERFORMED
QUALIFIED_LAUNCHER_ROOT_MUTATION_NOT_PERFORMED
IMPORT_RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
RECONCILIATION_ROOT_MUTATION_NOT_PERFORMED
EXACT_BASE_TARGET_AUDIT_SOURCE_VERIFIED
ORIGINAL_TARGET_AUDIT_SOURCE_BYTES_PRESERVED
REPAIR_BOUNDED_TO_BINDING_AND_FINALIZER_LIFECYCLE
SUBSTANTIVE_TARGET_AUDIT_SEMANTICS_UNCHANGED
AUTHORITATIVE_OPENING_BINDING_PATH_FIXED
DIAGNOSTIC_REPRODUCTION_RECORD_REJECTED_AS_AUTHORITY
SUPPORT_BINDING_MUTATION_MATRIX_PASSED
SUPPORT_BINDING_LIVE_REPLAY_PASSED
RESERVED_MANIFEST_DIRECTORY_ALLOWED_PREMANIFEST
UNRELATED_EMPTY_DIRECTORY_REJECTED
PREMATURE_SUCCESS_AUTHORITY_REMOVED
PRESEAL_READY_RECORD_NONAUTHORITATIVE
MANIFEST_A_READ_BACK_VERIFIED
MANIFEST_B_READ_BACK_VERIFIED
MANIFEST_PAIR_BYTE_EQUALITY_VERIFIED
TERMINAL_EMPTY_DIRECTORY_CHECK_PASSED
TERMINAL_SEAL_STATE_UNIQUE
NO_POSTSEAL_FILESYSTEM_WRITE
FINALIZER_FAILURE_OUTCOME_EXPLICIT
DIRECT_FINALIZER_PROCESS_AUTHORITY_SPLIT_FROZEN
FINALIZER_MUTATION_MATRIX_PASSED
INDEPENDENT_FINALIZER_VALIDATOR_PASSED
SUCCESSFUL_FINALIZATION_CAUSAL_PASSED
FAILURE_FINALIZATION_CAUSALS_PASSED
DIRECT_FINALIZER_PROCESS_CUSTODY_COMPLETE
RETAINED_FAILED_AUDIT_REPLAY_PASSED
REPAIRED_TARGET_AUDIT_SOURCE_COMPILED_SUCCESSFULLY
STATIC_TARGET_AUDIT_GATES_PASSED
FROZEN_TARGET_AUDIT_PACKAGE_CREATED
FROZEN_TARGET_AUDIT_PACKAGE_NOT_MODIFIED_AFTER_FREEZE
FROZEN_TARGET_AUDIT_PACKAGE_REQUALIFIED
SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
REAL_TARGET_AUDIT_NOT_EXECUTED
TARGET_BYTES_NOT_MODIFIED
ACCEPTED_BOOTSTRAP_BYTES_NOT_MODIFIED
RUNTIME_VALIDATION_NOT_RERUN
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_REPAIR_READY`, run one fresh target audit using the
accepted bootstrap and the exact frozen repaired target-audit package. Do not
regenerate the payload or finalizer.
```

**Source:** Codex’s `TARGET_AUDIT_PROVENANCE_RECONCILED_AUDIT_HARNESS_DEFECT` report in the current turn.

**Confidence:** 1.00 that no target or bootstrap repair is authorized; 0.995 that the opening selector is an audit-harness defect; 0.995 that the reserved-manifest checkpoint is defective; 0.98 that the terminal direct-finalizer model above is the narrowest sound repair.
