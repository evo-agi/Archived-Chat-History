Here is Codex's response:

# Fifth independent audit — Evidence Verification v1

**Verdict: BLOCK**

**Response-format confirmation:** This is the complete audit report inline. Linked audit records are supplemental evidence.

## 1. Inputs, repository identity, and scope

The exact recipe source used was [capture-final-provenance-v1.py](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v2/provenance/capture-final-provenance-v1.py). It is a regular, single-link `0600` file, 5,143 bytes, device/inode `16777234/176824598`, SHA-256 `bf393d56a428ab8667260a26deba78f636e41e37650388cf2bccf5a4a84c8333`.

The exact retained canonical manifest used was [manifest-run-1.json](/Users/ds/Downloads/ES-evidence-verification-v1-implementation-567bceced5df/audit-repair-v3/provenance/manifest-run-1.json). It is a regular, single-link `0600` file, 3,192 bytes, device/inode `16777234/176911418`, SHA-256 **`f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`**. Its recipe ID is `execution-substrate.evidence-verification-v1.final-patch-provenance.v1`; its tracked binary-diff SHA-256 is **`8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`**.

The implementation root was the physical, nonsymlinked `/Users/ds/Repositories/Execution Substrate - evidence-verification-v1`. Its branch was `codex/evidence-verification-v1`; HEAD `567bceced5df95ecfe787cc66038d463a854e12c`; tree `b7cab23732572c2aaea9d5f2f1593338e2e75338`; sole parent `05dde14d185b6e022dcc169ef1a658a97961850f`; upstream absent. There were exactly four modified tracked paths and nine untracked paths, with zero staged, deleted, renamed, or unmerged paths. Every patch object was regular, single-link, working mode `0644`, logical mode `100644`.

| ClassificationExact patch paths |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Modified tracked                | `PLANS.md`; `.docs/system_overview/boundaries.md`; `.docs/system_overview/artifact_hygiene.md`; `.docs/system_overview/capability_probing.md`                                                                                                                                                                                                                                                                                                                                                     |
| Untracked                       | `.docs/system_overview/evidence_verification.md`; `tools/evidence_verify/verify_v1.py`; `tools/evidence_verify/registry_v1.json`; `tools/evidence_verify/layouts/a6d_successor_v1.json`; `tools/evidence_verify/layouts/a6d_amendment_v1.json`; `tools/evidence_verify/layouts/a6_policy_v1.json`; `tools/evidence_verify/test_verify_v1.py`; `tools/evidence_verify/fixtures/historical_a6d_verify_postseal_v1.py.txt`; `tools/evidence_verify/fixtures/historical_a6d_verify_closing_v1.py.txt` |

The current verifier SHA-256 was `1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f`; the test SHA-256 was `cf2f786435787bdf0c19d133f3ea15ffab52083de4163d30db6d0eaa56077132`. Registry SHA-256 was `e35306141f58ab7b2908b3c62a74d173af17c6e7124acc92bd5737ec7004d880`. Successor, amendment, and A6-policy layout SHA-256 values were, respectively, `267053d083ecac7a7bcf8533e14d207c1438c032e66eaa95ba240d8b683eb0dc`, `3f6e47873c3760e2c2de6560aa9031d5657efff8d42ce9b5fda26fe396f56be4`, and `b98258468ad7815fe924c25aa7f9959db12570b952e2713c2bd8ee3083ce07e8`.

The pinned interpreter was Python `3.13.4` at `/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13`: regular, single-link, mode `0775`, 119,424 bytes, device/inode `16777234/2301718`, SHA-256 `f70035d9225815eca6c71970987963d36423039b2235e6305aa89b516d51ef9b`.

## 2. Opening and closing provenance

The recipe and retained manifest were read through no-follow descriptors with stable before/read/after identity checks. Source inspection confirmed required arguments, physical absolute root and continuation checks, bounded output names, exclusive creation at `0600`, canonical stdout equality, UTF-8-byte path ordering, exact binary-diff command, six explicitly rooted `git -C <root>` operations per recipe run, and compact sorted-key ASCII JSON plus one LF without timestamp or machine-specific output fields. The manifest contained the exact 13-path set, four/nine classifications, complete sizes and hashes, regular type, logical `100644`, expected branch and HEAD, and null upstream.

The initially absent audit root was created at `/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5` under umask `077`. Both opening runs used the exact supplied recipe, interpreter, implementation cwd, and sanitized launch environment. Each exited `0`; stderr was empty; both stdout streams and both output files were byte-identical to the retained manifest. The [opening replay record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/opening/replay-result.json) records the exact argv and captures.

After all four perspectives and validation completed, a fresh closing continuation was created under `closeout/provenance-replay-v1/provenance/`. Both closing runs again exited `0`, had empty stderr, and produced stdout and manifest files byte-identical to each other and to the retained canonical manifest. The [closing replay record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/replay-result.json) records all captures. Opening and closing manifest SHA-256 remained `f900d6abb37f74fbcd628f622354e8e7898fb341a074071e464288e978e5b9d8`; tracked binary-diff SHA-256 remained `8aea2e7529c49a2bcda866ad60dbab43b31bb594f705a320ada92576a99507ac`.

The closing branch, HEAD, tree, parent, absent upstream, 13 file identities, classifications, modes, and zero-staged/deleted/renamed/unmerged state matched opening. No Git operation marker or lock appeared. `git -C "$IMPL_R" diff --check` passed with empty output. Before/after content and metadata snapshots matched for the implementation repository outside `.git`, implementation evidence, audit v1–v4, sealed A6D, and its amendment. The real-child manifest hashes remained `dd8253bb1fbfd4c4df779724c6bd501216f8bb6f3fc460b6991ff538ec0ddcc9` and `a09012ef8aa574325dfc0b27a5b33123b47f27d85e546fd0383bab370a4d116e`. The private audit `tmp/` was empty at closeout.

## 3. Perspectives and audit lineage

| PerspectiveCompletionAssessment                                                                                                                                                |          |                                                                                                                                                  |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| [Contract and authority](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/contract-authority/report.md)                        | Complete | No authority blocker; low host-specific historical-fixture observation.                                                                          |
| [Verifier correctness and executable source](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/verifier-correctness/report.md)  | Complete | All 16 requested source scenarios matched expectations across 23 invocations; preserved a narrower launch-precondition view of the startup race. |
| [Test and validation](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/test-validation/report.md)                              | Complete | Four qualifying 75-test runs passed; no blocking test defect.                                                                                    |
| [Security, filesystem, capability, and artifact](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/security-artifact/report.md) | Complete | Found the conditional source-load timing gap, SEC-02; recommends BLOCK.                                                                          |

All four received the reproduced patch identity and relevant repair, audit, architecture, and ledger material. None executed Git or created a nested subagent.

Audit v3 remains permanently nonqualifying: its exact provenance inputs were unavailable to that run, correctness inspection did not begin, and it disclosed an unrooted Git command in the forbidden primary checkout. Its conclusions were not inherited. Audit v4 returned BLOCK for SEC-01 on predecessor verifier SHA-256 `60cdcab597cfc233d9406794886df02b54296cd392d7af4d082c75e87a5bc21e`; SEC-01 was its sole blocking residual. V4 evaluated predecessor bytes and neither qualifies nor rejects repair-v3 bytes. Its parser perspective’s minority position—that the exact externally pinned direct launches were contained—remains preserved as a narrow statement about those launches.

## 4. Authority and whole-patch adjudication

`PLANS.md` and `.docs/system_overview/evidence_verification.md` classify this ES-owned verifier as a **Bounded slice rule**. T1 remains a **Current invariant**; historical A6D verifier copies are **Temporary compatibility edges**; this tranche exercises no **Reopened redesign seam**. The whole 13-path patch contains documentation, the verifier, registry, three structure-only layouts, tests, and inert historical `.py.txt` fixtures. It changes no product API, public schema, route, service, runtime contract, admission, orchestration, durable-state, or execution authority.

A verifier pass is structural evidence/projection only. Closeout and a later independent audit retain readiness adjudication. The layouts describe paths, modes, stages, magic, and limits; they contain no product-result predicate. There is no caller-supplied runtime layout, evidence-child-local verifier authority, verifier-amendment chain, shared-kernel expansion, or self-verification. The verifier emits no source digest as self-certified authority. Exact source-byte trust remains with external implementation and audit provenance. Those ownership boundaries remain sound; SEC-02 concerns how a concurrent external launcher can establish which object Python loaded.

## 5. SEC-01, executable-source binding, and source causals

**SEC-01 is repaired for the predecessor’s stationary symlink mechanism.** V4’s retained reproduction recorded a pass when an external final symlink led to target-contained source. On current bytes, independent pre-seal and sealed causals returned `reject / TARGET_BOUNDARY / exit 2` for that shape. Direct, absolute, external, regular single-link source passed both stages. Exact predecessor source bytes were not retained as a recoverable standalone file, so I did not approximate or freshly rerun the old executable; the v4 report and reproduction retain that historical result.

Current `verify_v1.py:333-357` uses `__file__` as the invocation spelling and, in direct script execution, requires equality with `sys.argv[0]`. The spelling must be absolute and component-clean. Source-parent components are opened from `/` using no-follow directory stat/open and identity checks. The final component is no-follow-statted and opened with `O_RDONLY|O_NOFOLLOW|O_NONBLOCK|O_CLOEXEC`; it must be regular and single-link. Its descriptor remains open until `main` closes it. The identity tuple includes device, inode, mode, link count, size, nanosecond mtime, and nanosecond ctime. The physical package-parent descriptor and ancestry are captured. Descriptor ancestry compares package and target in both directions, including equality and case aliases. Before pass, source descriptor and path, package descriptor and ancestry, a fresh absolute package rebind, target rebind, and package/target ancestry are rechecked. Lexical `absolute()`, `resolve()`, `realpath()`, `commonpath()`, and case folding do not decide the physical boundary. Unsupported operations return canonical `IO_OR_RACE`/7 without pathname fallback.

The independent [source matrix](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/verifier-correctness/matrix-result.json) records every output. For **every** negative below, stdout was exactly one canonical JSON line, stderr was empty, and there was no traceback or absolute source/target path leak.

| #Independent causalResult |                                                                                    |                                            |
| ------------------------- | ---------------------------------------------------------------------------------- | ------------------------------------------ |
| 1                         | Direct external source, pre-seal and sealed                                        | `pass`, exit 0, both                       |
| 2                         | Direct source physically beneath target, both stages                               | `TARGET_BOUNDARY`, exit 2, both            |
| 3                         | External final symlink to target-contained source, both                            | `TARGET_BOUNDARY`, exit 2, both            |
| 4                         | External parent symlink to target package, both                                    | `TARGET_BOUNDARY`, exit 2, both            |
| 5                         | External hardlink to target source, observed link count 2, both                    | `TARGET_BOUNDARY`, exit 2, both            |
| 6                         | Source package beneath target                                                      | `TARGET_BOUNDARY`, exit 2                  |
| 7                         | Target beneath source package                                                      | `TARGET_BOUNDARY`, exit 2                  |
| 8                         | Source package equal to target                                                     | `TARGET_BOUNDARY`, exit 2                  |
| 9                         | Prohibited relationship through this host’s `/users` case alias                    | `TARGET_BOUNDARY`, exit 2                  |
| 10                        | Source content changed before closing check, injected                              | `indeterminate / IO_OR_RACE`, exit 7       |
| 11                        | Source disappeared before closing check, injected                                  | `indeterminate / IO_OR_RACE`, exit 7       |
| 12                        | Unsupported source no-follow and unsupported parent traversal, separately injected | `indeterminate / IO_OR_RACE`, exit 7, each |
| 13                        | Equal source bytes at distinct single-link inodes, both stages                     | `pass`, exit 0, both                       |
| 14                        | External source through an external symlinked parent                               | `TARGET_BOUNDARY`, exit 2                  |
| 15                        | Relative source invocation                                                         | `TARGET_BOUNDARY`, exit 2                  |
| 16                        | Final symlink to a physically external source                                      | `TARGET_BOUNDARY`, exit 2                  |

Cases 10–12 used audit-owned imported-source fault injection; they isolate the intended closing or unsupported-operation branch rather than reproduce a full external process race. The matrix’s first harness attempt incorrectly expected case 13 to reject; case 13 correctly passed. The expectation was corrected and all 23 invocations rerun successfully. Temporary fixtures were removed.

### Closing-race adjudication

Once the verifier has opened its source descriptor, substitution, disappearance, changed link count, mode or size, source-parent replacement, package rename, and case-alias swaps are checked through descriptor identity, path re-observation, ancestry, and absolute rebind. The checks are observations at opening and closing, not an atomic filesystem snapshot. Inode reuse would need to reproduce the full identity tuple and ancestor observations; privileged kernel-level identity forgery was not tested or claimed resistant. State changed after the last observation is likewise outside an atomic guarantee.

A distinct **earlier** interval remains: Python loads script bytes before `open_source_binding()` runs. SEC-02 below addresses that interval.

## 6. Prior EV/F closure and whole-verifier correctness

| Prior findingCurrent-byte adjudication |                                                                                                                                                                                                                                              |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SEC-01                                 | Static final-symlink-to-target mechanism closed independently at both stages. SEC-02 is a distinct temporal source-load case.                                                                                                                |
| EV-01                                  | Descriptor-bound target/package/candidate ancestry, case aliases, candidate symlink/hardlink rejection, and opening/closing identity remain effective for tested stationary and injected cases; qualified by SEC-02’s earlier load interval. |
| EV-02                                  | Literal-LF parser requires exact header, count, rows, final LF, and EOF; malformed separators and trailing data reject canonically. Closed.                                                                                                  |
| EV-03                                  | Package JSON is capped at 1 MiB, depth 64, and rejects malformed escapes, duplicate keys, floats, invalid UTF-8, and noncanonical bytes without traceback. Closed.                                                                           |
| EV-04                                  | Bounded resource behavior is represented by F-01 and F-02 below. Closed for tested mechanisms.                                                                                                                                               |
| EV-05                                  | Descriptor capability preflight and later exception mapping fail closed as `IO_OR_RACE`/7; no OS-label branch or pathname fallback. Closed.                                                                                                  |
| EV-06                                  | Four fresh, umask-independent 75-test runs passed without skip or repository artifact. Closed.                                                                                                                                               |
| EV-07                                  | Isolated missing-root, expected-path symlink, and special-file causals remain in tests 48–49. Closed.                                                                                                                                        |
| EV-08                                  | Complete ASCII-decimal lexical validation precedes overflow classification. Closed.                                                                                                                                                          |
| EV-09                                  | Audit-process issue, not a patch contract. V3 remains nonqualifying; all **current audit Git** operations conformed. Corrected non-Git deviations are disclosed below.                                                                       |
| F-01                                   | Manifest pre-stat cap is 12,017,724 bytes; the 4,096-byte streaming reader checks header/count before rows, bounded row and encoded-path lengths, ordering, and exact EOF. Closed.                                                           |
| F-02                                   | Candidate and both seal files enter each 4 GiB structural scan budget; manifest and exact 65-byte sidecar are checked before read. Closed.                                                                                                   |
| F-03                                   | Malformed decimal suffixes map to `MANIFEST_CANONICAL`/5; true count or size overflow maps to `LAYOUT`/4 or `SIZE_HASH`/6. Closed.                                                                                                           |
| F-04                                   | All spec path-bearing fields are validated before target open. Closed.                                                                                                                                                                       |

The complete verifier also checks exact root-directory closure, required and optional path sets, mode, regular type, link count, size, hash, detached sidecar, repeated traversal, and observable manifest-last metadata. It emits compact deterministic output and has no file write, child process, network call, target-code import, runtime layout injection, or readiness interpretation. Same-child metadata does not prove historical transport custody.

## 7. Test, compatibility, and validation results

Both current Python files and both historical `.py.txt` sources passed AST parsing; the historical files were **not executed**. Registry and three layouts passed independent strict canonical JSON parsing. Tests 01–59 remain present and effective. Tests 60–75 causally cover the source cases: test 62 uses an external package with only its *final source* symlinked into the target, so ordinary package/target containment alone cannot explain rejection; test 63 traverses an actual symlinked parent; test 64 observes link count two; tests 69–70 reach closing source re-observation; test 71 injects both no-follow and parent-traversal uncertainty; test 72 distinguishes equal bytes from identical inode; tests 74–75 distinguish relative spelling and a final external symlink. The fixture builder constructs manifests with separate stat, SHA-256, and base64 logic. Tests 53–55 share verifier-derived numeric formulas, test 59 is a representative rather than exhaustive invalid-spec cross-product, and some historical inputs are host-specific; these are nonblocking oracle limits, not independent proof by themselves.

The complete, exact 75-test identity list is in the [suite summary](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/test-validation/suite-summary.json). It contains unique consecutive identities `test_01` through `test_75`; coverage spans stage and seal behavior, structure/mode/hash closure, physical ancestry, parsing and resources, capability uncertainty, and the 16 source-boundary additions. Four qualifying runs discovered the identical set, with zero failure, error, or skip:

| UmaskQualifying run 1Qualifying run 2 |                       |                       |
| ------------------------------------- | --------------------- | --------------------- |
| `077`                                 | 75/75, process exit 0 | 75/75, process exit 0 |
| `022`                                 | 75/75, process exit 0 | 75/75, process exit 0 |

An earlier `077` suite itself printed `75/75 OK`, but its containing shell failed afterward on a reserved-variable assignment; it is retained as a superseded harness attempt. A replacement `077` run with captured process exit qualified. All qualifying stdout streams were empty; raw unittest logs and identities are retained.

Fresh sealed A6D verification passed twice with empty stderr and byte-identical canonical stdout, SHA-256 `3bbbc3d2ba257007e2d5b55991ce043d1cb7c5cb841e70e86f6421752e38d606`. Fresh sealed amendment verification passed twice likewise, stdout SHA-256 `be83077cf61b3250eb39239e0e60bdadcec42d6ae4c2e8d6a9542ccd1caffabc`. An audit-owned, test-written synthetic A6 child passed pre-seal twice, was sealed only within the audit-owned fixture, then passed sealed twice. Its paired stdout SHA-256 values were `c8fea47874d6c022e631edf6fb15391f44e048c2a21070ea4e6b769a4b4ac7` and `8535b9875405399f02f4e9729180af60168eab293aa36ba2482c27fb2e383111`. All eight runs exited 0, emitted canonical pass with empty stderr, and had matching before/after target, verifier-package, applicable candidate, and TMPDIR snapshots. The [compatibility record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/validation/compat-result.json) contains exact argv and per-run snapshots.

## 8. Repair-v3 evidence, security, and artifacts

Comparing retained predecessor and repair-v3 manifests showed exactly four changed paths: `verify_v1.py`, `test_verify_v1.py`, `.docs/system_overview/evidence_verification.md`, and `.docs/system_overview/artifact_hygiene.md`. The other nine, including registry and all three layouts, were byte-identical. The [scope comparison](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/validation/repair-scope.json) records this.

The repair-v3 report explicitly closes producer SEC-01, preserves the v4 minority view, labels its own validation producer-only, and does not portray earlier audits as qualifying changed bytes. Its retained vulnerable-predecessor result, 16 individual new-test runs, four full 75-test runs, real and synthetic checks, no-write snapshots, failed/superseded attempt index, cleanup, and final provenance were inspected. The indexed pre-code test failure, first causal-summary-parser mistake, and first synthetic TMPDIR mismatch were not silently used as final qualification. The source-external producer report materially agrees with the retained records inspected; a separate inline producer report was not supplied for direct comparison.

Independent artifact inspection found no implementation-repository cache, bytecode, pytest cache, generated manifest, database, journal, lock, fixture root, temporary output, unsupported object, or unexpected patch executable mode. The historical fixtures remain inert `.py.txt` files. Package reads, source and target traversal, and manifest reads use no-follow descriptors and stated resource ceilings. Capability enforcement occurs at verification validation, without OS branching or fallback. The verifier creates no target, package, cwd, bytecode, or temporary file.

## 9. Severity-ranked residual findings

### AUDIT FINDING — SEC-02

**ID:** SEC-02\
**Type:** Executable-source load-to-binding race.\
**Severity:** high.\
**Classification:** Residual repairable source-boundary defect and undocumented external launch-custody precondition.\
**Current contract or strategic target:** `.docs/system_overview/evidence_verification.md:49-64` and `.docs/system_overview/artifact_hygiene.md:185-193` categorically require a direct, physically external executable source and rejection of symlinked launch paths, while source-byte authentication remains external.\
**Path and line:** `tools/evidence_verify/verify_v1.py:333-357`, `:801-810`, `:365-383`, `:828-831`; stationary regression `tools/evidence_verify/test_verify_v1.py:994-1000`.\
**Evidence:** The [audit-owned causal](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/security-artifact/source-load-race-result.json) records a target-source execution marker followed by canonical `pass`, exit 0, and empty stderr. The target-contained source was instrumented with a synchronization prelude; the later external replacement was a direct regular file with exact current verifier SHA-256 `1379fd38799e12a44979812532f6100dc16e2af1a386b3297c5e85b450ab405f`.\
**Reachable mechanism:** Python loaded through an external symlink to target-contained source. After that load, an actor atomically replaced the external symlink with a direct regular external file. `open_source_binding()` and its closing checks observed only the replacement; `__file__` and `sys.argv[0]` retained the same pathname spelling and do not expose Python’s earlier loader inode.\
**Impact:** A verifier pass can coexist with target-contained code having executed when the external launcher path changes during startup. Post-load source and provenance checks alone cannot prove which object Python loaded.\
**Required correction:** Define and enforce stable, direct external source custody at the interpreter-load boundary, or change the launch design so the object Python executes is the object physically checked. Align the authoritative docs and add a timing causal. A post-load pathname recheck alone does not close this interval.\
**Containment/nonclaim:** This requires control of the **external launch path**; target-content control alone did not drive the causal. Its target source was instrumented for deterministic timing. It does not show a same-timing pass by unmodified exact verifier bytes, nor impugn the stable direct repository launches or real sealed-child results. The stationary SEC-01 symlink mechanism is repaired.\
**Uncertainty:** A precisely timed uninstrumented launch-path swap was not executed. Privileged kernel identity forgery and simultaneous real-child mutation were not tested. The docs do not explicitly state a trusted, immutable external launch-path assumption.\
**Patch defect, pre-existing issue, or audit-process issue:** Patch contract/source-boundary defect; repairable within an explicit external invocation and documentation contract.\
**Blocking:** yes.

### AUDIT FINDING — CA-01

**ID:** CA-01\
**Type:** Historical test-fixture portability.\
**Severity:** low.\
**Classification:** Bounded test-scaffolding observation.\
**Current contract or strategic target:** Historical verifiers remain inert, externally pinned temporary compatibility material.\
**Path and line:** `tools/evidence_verify/test_verify_v1.py:20-30`, `:98-100`, `:310-318`, `:340-348`.\
**Evidence:** Historical tests use fixed `/Users/ds/Downloads/...` sealed-evidence paths. The verifier itself does not use them.\
**Reachable mechanism:** On a different host without those exact external fixtures, the tests would fail despite unchanged verifier semantics.\
**Impact:** Test-suite portability outside this prescribed audit environment.\
**Required correction:** If distributed elsewhere, provide separately pinned external fixture provenance or document the required roots.\
**Containment/nonclaim:** All prescribed roots existed and tests passed on this host; no runtime or evidence-child authority follows.\
**Uncertainty:** Other hosts were not tested.\
**Patch defect, pre-existing issue, or audit-process issue:** Pre-existing test-scaffolding observation.\
**Blocking:** no.

### AUDIT FINDING — AP-01

**ID:** AP-01\
**Type:** Corrected non-Git audit-process deviations.\
**Severity:** low.\
**Classification:** Audit-process observation.\
**Current contract or strategic target:** Sanitized audit launches, transparent failed-attempt accounting, and strict parent-only rooted Git.\
**Path and line:** Audit-owned setup and perspective records, including the [contract perspective report](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/contract-authority/report.md), [test report](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/test-validation/report.md), and [verifier report](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/perspectives/verifier-correctness/report.md).\
**Evidence:** macOS injected `__CF_USER_TEXT_ENCODING` at Python startup despite an exact `env -i` launch, causing the first setup assertion to stop after creating the audit directories; child-process environments were then passed explicitly. Two audit-script-authoring `cat` calls used the inherited shell environment, but wrote only beneath the audit root; the scripts’ validation runs used the sanitized environment. One read-only `nl|sed` perspective inspection used `GIT_OPTIONAL_LOCKS=1` by typo, invoked no Git, and was rerun with `0` and identical output. The test harness’s first `077` shell wrapper failed after a successful suite, and a replacement qualified. The source-matrix harness corrected a mistaken expected result for case 13 and reran all cases.\
**Reachable mechanism:** These were setup, inspection, or harness errors; none was a nonconforming Git invocation or a repository/supplied-evidence write.\
**Impact:** They require disclosure and exclusion of superseded attempts; the qualifying provenance, suite, matrix, and compatibility results were rerun or launched with the required bindings.\
**Required correction:** Preserve this attempt record and use the exact sanitized environment for future audit command authoring as well as execution.\
**Containment/nonclaim:** This observation does not qualify the patch or erase SEC-02.\
**Uncertainty:** Recipe-internal Git calls were reconstructed from verified recipe source and successful executions, not individually intercepted.\
**Patch defect, pre-existing issue, or audit-process issue:** Audit-process issue.\
**Blocking:** no; no nonconforming Git operation occurred, and affected read-only checks were rerun or superseded.

## 10. Minority views, limits, cleanup, and process boundary

The v4 parser minority view remains: externally pinned, direct regular launches contained the predecessor’s stationary symlink case for those *specific* invocations. The v5 verifier perspective adds that SEC-02 starts with a symlinked launch that violates the stated direct-source precondition and requires external-path control; a continuously direct, stable path was not bypassed. The parent’s BLOCK resolution follows the docs’ categorical symlink/source-external wording, which does not make that additional trusted immutable-launch-path assumption explicit. This is a repairable bounded contract gap, not evidence of product authority or grounds for REJECT.

No 4 GiB pressure target, privileged timestamp-forgery or inode-reuse experiment, exhaustive adversarial concurrent rename campaign, or same-timing uninstrumented SEC-02 run was performed. Exact predecessor executable bytes were unavailable for a fresh run. No separate inline producer report was available for direct textual comparison. These limits are not represented as passing tests.

Audit output was confined to `/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5`. Its [created-path inventory](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/audit-created-paths.json) records 84 entries at final inventory; audit-owned temporary fixture roots were removed and `tmp/` was empty. No repository or supplied-evidence object was removed, chmodded, normalized, rewritten, or restored.

The [Git-process record](/Users/ds/Downloads/ES-evidence-verification-v1-independent-reaudit-567bceced5df-v5/closeout/git-process-boundary.json) contains 17 directly observed parent Git invocations, each exactly rooted `git -C "$IMPL_R"`, cwd `IMPL_R`, with `GIT_OPTIONAL_LOCKS=0` and `GIT_CONFIG_NOSYSTEM=1`. The verified recipe source yields six likewise rooted internal Git invocations per run, 24 across four runs; those argv are recorded as source-derived rather than individually intercepted. No perspective executed Git. No Git ran in the primary checkout, a candidate, A6D, its amendment, any evidence root, or this audit root. There was **no nonconforming Git operation**.

**Explicit prohibited-action confirmations:** repository mutation not performed; formatting not performed; staging not performed; commit not performed; push not performed; PR or merge not performed; installation or deployment not performed; A6 not restarted; product tests, product A/B, and live services not invoked; network contact not performed; Linux binary execution not performed; nested subagents not created. No repair was made.
