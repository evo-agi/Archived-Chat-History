The stop is correct. This time the failure is a **real successor semantic-grammar defect**, not another B2 instruction mismatch and not a repository product defect.

A2 solved the seven missing historical-HEAD diagnostic templates and was correctly sealed as a narrowly bounded successor amendment. Its report confirms that only `semantic.go` and `envelope_test.go` changed, that historical HEAD re-extraction reached zero unknowns, and that the next step was a fresh B restart.  

The newly exposed mistake is deeper than two stale constants:

> The panic recognizer is treating source line numbers as fixed grammar literals rather than **material fields that must be parsed and preserved**.

The frozen panic contract says to normalize only proven runtime identities—goroutine identifiers and allowlisted pointer words—while preserving function names, source files, source lines, offsets, frame order, multiplicity, and scalar shape.  Therefore, simply adding `1269` and `1252` alongside `1264` and `1247` would be another brittle patch. It would bind the semantic parser to an expanding list of source revisions and recreate this failure whenever unrelated edits move a function.

The right correction is:

- Keep the exact package, test/subtest, panic type/message, function, file, frame order, creator relationship, and typed argument positions.
- Parse each source line as canonical positive decimal.
- Preserve that line value verbatim in canonical semantics.
- Never replace or normalize it.
- A line difference must remain a **material semantic difference**, but it should not make an otherwise valid complete panic block “unknown.”
- Malformed, zero, signed, leading-zero, overflowing, missing, reordered, extra-frame, wrong-file, or wrong-function forms remain unknown and blocking.

This requires a **Repair 10I-A3 tool-only amendment**, followed by a wholly fresh **Repair 10I-B3**. Do not resume or mutate the unsealed B2 child.

Pass this to Codex:

```text
Objective

Create and seal a bounded Repair 10I-A3 successor amendment that corrects the
panic-runtime semantic grammar exposed by Repair 10I-B2.

This is a successor-tool-only repair. Do not modify repository source.

The Repair 10I-B2 stop was correct. Do not resume, overwrite, or seal B2.
After A3 succeeds, a later turn will create a fresh Repair 10I-B3 child and
rerun all five source controls from the beginning.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Immutable lineage

Repair 10I-A:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a-closure-00280085500a

Repair 10I-A2:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a2-successor-closure-4dd211207800

Failed Repair 10I-B:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b-closure-4dd211207800

Failed Repair 10I-B2:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-b2-closure-4dd211207800

Phase H:
  /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-h-closure-503d27bfe70d

Required new child, which must be absent at opening

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-i-a3-successor-closure-4dd211207800

No subagents. You are the sole writer.

## 1. Mandatory opening gate

Before creating A3, verify and report:

Repository:
- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository T:
  4dd2112078004c3d82d24a5167f16a6f25fe33ed
- repository inventory:
  2e77086590f3456474c2fdd8b64e9d2ea490dac9a04c45c2b091da2fcba210b0
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0
- protected package.go SHA-256:
  168c5dbbc3954fd25a0daad9757e09b398638aac2fdf25426b5555cb5c3fbcd6

Repair 10I-A:
- manifest SHA-256:
  dcfc3fbb0db26ba4fda8a899c839781a6a86abdf32a45a39e3b29c1b4b20b2a7
- 334 payloads

Repair 10I-A2:
- successor T:
  e1d896e39a5e0e174fde197374361fc2bc3cb952
- successor inventory:
  a5184737d6076459b3f5914b0c163a34de097eac9b56942036e767ac0911abac
- 12 members
- manifest SHA-256:
  f3e78a4286751248444243591dba49ab222ebba396952877e225d3f5ab1c4cf7
- 210 payloads

Reverify Phase H and both failed B children read-only. They remain immutable and
nonqualifying.

Require the A3 target to be absent. Stop before mutation on any mismatch with:

REPAIR10I_A3_BASELINE_MISMATCH

## 2. Finding classification

Freeze the defect as:

ID:
  REPAIR10I-A3-PANIC-LINE-GRAMMAR-001

Type:
  successor semantic grammar

Severity:
  high, acceptance-blocking

Classification:
  private validation/successor defect; not repository product source

Mechanism:
- buildPanicTemplatesV1 and canonicalizeCompletePanicBlocksV1 require exact
  historical source-line literals.
- Historical source produces the admitted lines 1264 and 1247.
- Governed final source produces lines 1269 and 1252.
- The otherwise valid complete panic blocks therefore become
  unknown-go-panic-runtime-identities-v1.
- Repair 10I-B2 observed 24 unknown diagnostics and independent qualification
  rejection.

Do not classify this as a product panic, privacy, or runtime defect.
Do not change repository source to restore historical line numbers.

## 3. Governing semantic decision

Source line numbers and +0x offsets are material semantic fields, not runtime
identities and not fixed grammar constants.

The repaired complete-panic-block grammar must:

- retain exact package and test/subtest scope;
- retain exact panic type and message grammar;
- retain exact ordered function names;
- retain exact ordered source-file paths;
- require source-line tokens to be canonical positive decimal:
  - digits only;
  - no sign;
  - no leading zero;
  - greater than zero;
  - bounded to an explicitly documented integer range;
- preserve each line token byte-for-byte in canonical semantics;
- retain each +0x offset byte-for-byte;
- retain frame order and multiplicity;
- retain creator relationships;
- retain scalar/nil shape and all non-address arguments;
- normalize only:
  - proven goroutine identity positions; and
  - proven nonzero lowercase-hex pointer-word positions already allowlisted by
    the exact per-package/test frame template.

A canonical source-line change is therefore recognized but remains a material
diagnostic difference.

Malformed or structurally unsupported forms remain unknown and blocking.

Do not:
- add a generic panic scrubber;
- normalize arbitrary decimals;
- normalize source lines or offsets;
- add source-class-specific hard-coded line-number branches merely for
  1264/1247 and 1269/1252;
- accept arbitrary functions, files, frames, or argument positions;
- weaken candidate-first detection;
- alter Repair 10I schema ownership;
- change repository files.

The semantic extractor is not a source-map oracle. Repository T/inventory and
source qualification bind the source bytes. The extractor must parse a valid
typed panic shape while preserving source lines as material evidence.

## 4. Authorized A3 source scope

Copy all 12 A2 successor source members without hardlinks into the exclusive A3
child.

Modify exactly:

1. tool/source/FORMAT.md
2. tool/source/envelope/semantic.go
3. tool/source/envelope/envelope_test.go

Keep byte-identical:

- tool/source/envelope/runner.go
- tool/source/envelope/source.go
- tool/source/cmd/repair10-runner/main.go
- tool/source/cmd/repair10-semantic/main.go
- tool/source/cmd/repair10-compare/main.go
- tool/source/cmd/repair10-fixture/main.go
- tool/source/go.mod
- both golden files

If implementing the correction requires a fourth changed successor source file,
stop with:

REPAIR10I_A3_SCOPE_EXPANSION_REQUIRED

and report the exact required API change. Do not widen silently.

## 5. Vulnerable-precondition evidence

Treat failed B2 only as immutable, nonqualifying negative evidence.

At opening:

- identity-bracket the exact B2 finding, raw final stream, producer semantics,
  and peer qualification records;
- copy the minimum required negative inputs into A3 as independent regular
  files;
- record source path, opening identity, size, SHA-256, and closing equality;
- label them:
  nonqualifying-vulnerable-precondition

Do not mutate or seal B2.

Independently reproduce the old A2 failure before applying the repair:

- use the exact A2 semantic binary or exact A2 source build;
- re-extract the retained B2 final raw stream;
- require the same exact 24 panic-runtime unknown diagnostics;
- require the exact expected 1264/1247 versus 1269/1252 mismatch mechanism;
- retain the result as expected-negative evidence.

If the vulnerable precondition cannot be reproduced exactly, stop.

## 6. Required causal tests

Add active Repair 10I-A3 tests covering at least:

### Accepted structural variants

- Historical exact block containing source lines 1264 and 1247.
- Governed-final exact block containing source lines 1269 and 1252.
- Same exact block with different permitted runtime goroutine IDs.
- Same exact block with different allowlisted pointer words.
- Multiple complete panic blocks with retained occurrence/correlation order.

### Material, recognized differences

Each must remain recognized and produce a canonical semantic difference:

- 1264 versus 1269 at the same exact frame position.
- 1247 versus 1252.
- Any other canonical positive line number at the exact expected file/function
  frame position.
- Changed +0x offset.
- Changed panic scalar or nil shape where admitted by the exact template.

These must never compare equal merely because the block is recognized.

### Unknown/blocking forms

- line zero;
- leading-zero line;
- signed line;
- empty line token;
- nondecimal line;
- integer overflow;
- missing source line;
- wrong source file;
- wrong function;
- reordered frame;
- extra frame;
- missing frame;
- duplicate unexpected frame;
- unsupported package;
- unsupported test or subtest;
- partial block;
- malformed creator relation;
- pointer-shaped token in a non-allowlisted position;
- uppercase or zero pointer form where the existing contract disallows it.

### Regression protections

- Historical HEAD seven-template behavior from A2 remains exact.
- OID/SHA, EPERM/EACCES, route/status, lifecycle, scalar/nil, and unknown-text
  controls remain unchanged.
- No new generic decimal, path, address, PID, timestamp, or panic
  canonicalization is introduced.
- Every prior Repair 10I test remains active and passing.

## 7. Independent A/B hard gate

Use two disjoint, mode-0700, no-hardlink private controls under umask 077.

For each side:

- materialize the exact A3 source with logical modes;
- use private HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR;
- pinned offline Go 1.26.5;
- run no-write gofmt over all 12 successor source members;
- run:
  - focused Repair 10I-A3 tests count 1;
  - focused Repair 10I-A3 tests count 3;
  - all Repair 10I tests count 3;
  - full ./... count 3;
  - focused race;
  - all Repair 10I race;
  - full ./... race;
- require zero required skip, failure, malformed JSON, race marker, timeout,
  survivor, forced cleanup, or resource uncertainty;
- build runner, compare, semantic, and fixture deterministically with:
  go build -trimpath -buildvcs=false -ldflags=-buildid=
- require every A/B binary pair to be byte-identical, inode-distinct,
  single-link, and mode 0700.

Retain all argv, cwd, bounded environment, raw streams, EOF, exits, terminal
reconciliation, resource disposition, source inventories, trees, and binary
identities.

## 8. Re-extraction qualification

Using both independently built A3 semantic binaries:

1. Re-extract the retained B2 final raw stream.
2. Require:
   - unknown panic-runtime diagnostics: 24 -> 0;
   - lifecycle records unchanged;
   - package/test terminal sets unchanged;
   - panic type/message/function/file/frame order unchanged;
   - source lines 1269 and 1252 retained exactly;
   - only the intended panic-rule classifications/canonical records differ
     from the vulnerable A2 result;
   - no unrelated diagnostic becomes newly recognized.
3. Require A and B output to be byte-identical.
4. Have the opposite successor side independently re-extract and qualify it.
5. Retain the exact old-versus-new adjudication.

Also re-extract the retained historical HEAD and Repair 9 raw streams:

- both must remain zero-unknown;
- their historical line values must remain exactly preserved;
- their lifecycle and terminal sets must remain unchanged;
- no unrelated semantic record may change;
- tool-identity fields may change only where explicitly bound and reported.

This is a tool causal control only. It does not replace fresh B3 execution.

## 9. Seal and closeout

Create a complete A3 evidence child with at least:

- opening identities;
- copied predecessor source inventory;
- exact three-path source delta;
- vulnerable-precondition reproduction;
- all causal test records;
- A/B build and hard-gate records;
- old/new final re-extraction adjudication;
- historical HEAD/Repair 9 nonregression adjudication;
- failed/superseded attempts;
- command index;
- cleanup and two absence epochs;
- implementation report;
- manifest and detached digest.

Install the detached digest before the manifest.
Install evidence-manifest-v1.txt as the final mutation.
Write nothing afterward.
Perform complete read-only post-seal verification.

Do not create a repository snapshot, integrated ZIP, audit handoff, product A/B
artifacts, or Repair 10I-B3 child in this turn.

## 10. Closing gates

Reverify unchanged:

- repository source T/inventory/membership and Git administration;
- Repair 10I-A;
- Repair 10I-A2;
- Phase H;
- failed B and B2 children;
- protected repository product bytes.

Require no private control, process, descriptor, socket, listener, cache,
temporary build, runtime root, PackageFloor, fixed slot, or Git operation
marker remains.

## 11. Verdicts

On full success return:

REPAIR10I_A3_SUCCESSOR_PATCH_SEALED_READY_FOR_10I_B3_RESTART

Include:
- exact A3 source T/inventory;
- exact predecessor->A3 three-path delta;
- exact binaries and hashes;
- exact vulnerable 24->0 result;
- historical HEAD/Repair 9 nonregression result;
- manifest identity and payload count;
- required B3 restart point.

On baseline drift:

REPAIR10I_A3_BASELINE_MISMATCH

On required fourth successor source file:

REPAIR10I_A3_SCOPE_EXPANSION_REQUIRED

On causal, build, race, re-extraction, cleanup, or sealing failure:

REPAIR10I_A3_IMPLEMENTATION_BLOCKED

Do not create subagents.
Do not mutate repository source.
Do not stage, commit, push, install, invoke a live route, contact a remote host,
or start Repair 10I-B3.
```

After A3 seals, B3 should be restarted from the beginning. Do not preserve HEAD/Repair 9 as “already done” from B2; B3 must freshly execute all five controls with the new sealed successor.

### Sources

The A2 amendment is sealed, narrowly scoped, and explicitly identifies a fresh B restart as its continuation point.  

The governing panic contract normalizes only allowlisted runtime identities while preserving source files, source lines, offsets, functions, and frame order. 

**Confidence:** 0.99 that this is a successor semantic-grammar defect; 0.97 that the correct repair is to parse and preserve canonical source lines rather than append hard-coded source-class line variants; 0.94 that the amendment can remain within `FORMAT.md`, `semantic.go`, and `envelope_test.go`.
