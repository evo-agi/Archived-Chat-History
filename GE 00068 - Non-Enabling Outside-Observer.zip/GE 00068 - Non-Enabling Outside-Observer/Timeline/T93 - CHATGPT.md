The stop is correct, but this is almost certainly **not Repair 10I candidate drift**. The observed identity—`trunk_dev`, HEAD `b92bd988…`, upstream `origin/trunk_dev`, and a different index—is characteristic of a different checkout, most likely the primary ES worktree:

```text
/Users/ds/Repositories/Execution Substrate/
```

The required A6R target was the dedicated linked worktree:

```text
/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1
```

The report omits the physical repository root that Codex actually inspected. Therefore the evidence currently supports **workspace-selection failure** more strongly than candidate mutation, but it does not yet prove that attribution.

Do not reset, clean, checkout, repair, or otherwise touch either worktree. The modified and untracked state seen on `trunk_dev` may belong to unrelated active work. Project protocol requires stopping on branch, HEAD, upstream, or working-tree drift and explicitly prohibits absorbing or rebasing unrelated work. 

The next pass should reconcile the physical worktree binding only. It should not begin A6R.

## Codex prompt: reconcile the A6R workspace

```text
Objective

Perform a parent-only, read-only workspace-location reconciliation after the
Repair 10I-A6R opening gate inspected an unexpected repository identity.

Determine conclusively whether the failed gate inspected:

1. the dedicated Repair 10I candidate worktree;
2. the primary Execution Substrate checkout;
3. a symlink, stale worktree binding, or other misbound path;
4. an unresolved location.

Do not rerun A6R reconnaissance in this turn.

Do not implement, edit, create, delete, format, stage, commit, push, checkout,
switch branches, reset, restore, clean, prune, repair a worktree, add/remove a
worktree, update a ref, install anything, run tests, invoke services, contact
networks, or mutate evidence.

Do not remove or normalize any modified or untracked path in either checkout.

No subagents.

Candidate worktree expected by Repair 10I

CANDIDATE_R=/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Primary ES checkout, inspection-only comparison surface

PRIMARY_R=/Users/ds/Repositories/Execution Substrate

Expected candidate identity

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- upstream:
  absent
- index SHA-256:
  012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31
- repository source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- source inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- membership:
  389 total / 375 tracked / 14 nonignored untracked
- staged/deleted/renamed/unmerged:
  0/0/0/0

Identity observed by the failed A6R gate

- branch:
  trunk_dev
- HEAD:
  b92bd9884106154d25342e1573dcc4c312311436
- sole parent:
  4f797fb63d3c5b95275b1455af36ebc9b695f773
- HEAD tree:
  cdd4e44bac15c1952d70997143040644361f0bb1
- upstream:
  origin/trunk_dev
- index SHA-256:
  546311e099e6e412d058a1e18e2086c3843de127873061dcd57735ce86fd6085

## 1. Filesystem-root proof before Git

Before invoking any Git command, inspect both lexical roots using no-follow
filesystem observations.

For CANDIDATE_R and PRIMARY_R record:

- lexical path;
- component-by-component physical resolution;
- final physical path;
- object type;
- device;
- inode;
- mode;
- UID/GID;
- link count;
- whether any component or final leaf is a symlink;
- whether the two roots are equal, aliases, nested, or inode-identical.

Require CANDIDATE_R to be an existing directory.

Do not create any scratch file.

After entering CANDIDATE_R, print and retain:

- lexical requested cwd;
- physical `pwd -P`;
- whether physical cwd equals the physical CANDIDATE_R exactly.

If physical cwd is not the exact candidate root, stop without Git inspection:

REPAIR10I_A6R_WORKTREE_MISSING_OR_MISBOUND

## 2. Direct `.git` binding inspection

For each root, inspect `.git` without following an unexpected final symlink.

Record:

- `.git` object type;
- mode, size, device, inode, and SHA-256 when it is a regular pointer file;
- exact safe pointer form;
- resolved linked-worktree Git directory;
- resolved common Git directory;
- whether the linked-worktree administration path exists;
- whether the candidate and primary roots share the expected common Git
  directory but have distinct linked-worktree administration.

Do not print unrelated config contents, hooks, credentials, remotes, or private
state.

For the candidate, bind the expected linked-worktree index path and hash it
directly.

## 3. Git observations must be explicitly rooted

Set:

GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C

Do not issue an unrooted Git command.

Every candidate Git invocation must use one of:

- `git -C "$CANDIDATE_R" ...`; or
- a subprocess whose explicit cwd/Dir is the proven physical candidate root.

Every primary-checkout Git invocation must use:

- `git -C "$PRIMARY_R" ...`; or
- an explicit physical PRIMARY_R cwd.

Do not rely on inherited shell cwd.

Do not use branch-switching, reset, restore, clean, worktree repair/prune, or
another mutating Git operation.

## 4. Candidate capsule

From CANDIDATE_R reproduce:

- repository top level;
- Git directory;
- common Git directory;
- branch;
- HEAD;
- parent count and sole parent;
- HEAD tree;
- subject;
- upstream presence or absence;
- index path, mode, size, and SHA-256;
- tracked membership;
- nonignored-untracked membership;
- tracked modification count;
- staged/deleted/renamed/unmerged counts;
- complete governed source inventory;
- source T.

Use the established deterministic inventory/tree procedure in memory or
stdout-only.

Do not import executable code from a sealed evidence child.
Use `PYTHONDONTWRITEBYTECODE=1` for any inline Python.
Do not create `__pycache__`, `.pyc`, reports, manifests, or temporary files.

Require exact comparison against the expected candidate capsule.

## 5. Primary-checkout identification

Inspect PRIMARY_R only far enough to establish:

- physical root;
- `.git` binding;
- repository top level;
- branch;
- HEAD;
- sole parent;
- HEAD tree;
- upstream;
- index SHA-256.

Do not enumerate, print, modify, clean, reset, or classify the primary
checkout’s modified and untracked file names.

Determine whether PRIMARY_R reproduces the identity observed by the failed
A6R opening gate:

- branch `trunk_dev`;
- HEAD `b92bd988…`;
- parent `4f797fb6…`;
- tree `cdd4e44b…`;
- upstream `origin/trunk_dev`;
- index `546311e0…`.

If it does, state that the attribution to PRIMARY_R is directly reproduced.

If it does not, preserve the discrepancy rather than guessing.

## 6. Worktree registry

Read the common repository’s worktree registry using read-only observations.

Retain:

- `git worktree list --porcelain` or equivalent complete read-only registry;
- physical worktree paths;
- HEADs;
- branches;
- lock/prunable status if reported;
- the registry member corresponding to CANDIDATE_R;
- the registry member corresponding to PRIMARY_R.

Require:

- CANDIDATE_R is registered to the expected candidate branch;
- PRIMARY_R is registered or recognized as the main worktree;
- neither path is silently redirected to the other.

Do not run `git worktree repair`, `prune`, `move`, `add`, `remove`, or `lock`.

## 7. Prior-gate attribution

Determine, from direct evidence where available, why the failed A6R gate read
the wrong capsule.

Inspect only:

- any retained stdout already supplied in the conversation;
- current physical-root identities;
- current Git capsules;
- worktree bindings.

Do not invent a command transcript that was not retained.

Classify attribution as:

- proven:
  the primary checkout exactly reproduces every observed failed-gate identity;
- strongly supported:
  it reproduces the capsule but no prior cwd transcript survives;
- unresolved:
  neither root reproduces the observed capsule or another ambiguity remains.

Do not label the candidate as drifted unless CANDIDATE_R itself fails its
expected capsule.

## 8. No evidence child

Do not create an A6R evidence or reconciliation child.

This is a stdout-only location reconciliation.

Do not modify the absent A6R target.

At closeout repeat:

- candidate physical-root identity;
- candidate branch/HEAD/tree/upstream/index;
- primary physical-root identity and compact capsule;
- worktree registry.

Require opening and closing equality.

## 9. Verdicts

Return exactly one.

### Candidate exact; wrong checkout reproduced

REPAIR10I_A6R_LOCATION_RECONCILED_READY_TO_RETRY

Use when:

- CANDIDATE_R is physically distinct and correctly registered;
- the complete candidate capsule matches;
- PRIMARY_R reproduces the failed A6R capsule;
- no mutation occurred.

State whether wrong-checkout attribution is proven or strongly supported.

### Candidate path absent, aliased, or misregistered

REPAIR10I_A6R_WORKTREE_MISSING_OR_MISBOUND

Use when CANDIDATE_R:

- does not exist;
- resolves to PRIMARY_R;
- has an invalid `.git` pointer;
- is absent or inconsistent in the worktree registry.

Do not repair it.

### Candidate exists but its own baseline differs

REPAIR10I_A6R_CANDIDATE_BASELINE_MISMATCH

Use only when the physically proven CANDIDATE_R itself fails one or more
expected candidate identities.

Report the exact mismatch.
Do not absorb or reset it.

### Attribution unresolved

REPAIR10I_A6R_LOCATION_RECONCILIATION_BLOCKED

Use when the candidate cannot be conclusively separated from the failed-gate
identity or neither root reproduces the observed state.

## 10. Required report

Include:

1. Candidate lexical and physical root.
2. Primary lexical and physical root.
3. Root device/inode and alias relation.
4. Candidate `.git` pointer, gitdir, and commondir.
5. Primary `.git` binding.
6. Complete candidate capsule.
7. Compact primary capsule.
8. Worktree-registry mapping.
9. Whether PRIMARY_R reproduces the failed A6R values.
10. Prior-gate attribution and confidence.
11. Exact opening/closing equality.
12. Confirmation:
    - no repository mutation;
    - no Git-administration mutation;
    - no evidence mutation;
    - no tests;
    - no build;
    - no A6R child;
    - no staging, commit, push, installation, live route, remote contact, or
      Linux execution.

Do not rerun A6R in this turn.
```

## After reconciliation

Only if Codex returns:

```text
REPAIR10I_A6R_LOCATION_RECONCILED_READY_TO_RETRY
```

should A6R be reissued. The retry should add an absolute root lock:

```text
Before any substantive observation:

1. lstat and physically resolve the exact candidate path;
2. require `pwd -P` to equal it;
3. inspect its `.git` worktree pointer;
4. require its branch/HEAD/index capsule;
5. use explicit `git -C <candidate>` or explicit subprocess cwd for every Git
   command;
6. never inherit the foreground session’s default repository cwd.
```

Do not reinterpret the `trunk_dev` checkout as the Repair 10I baseline and do not reset it. The worktree protocol treats baseline drift as a mandatory stop and forbids absorbing unrelated active work.  Proof-harness and evidence mechanics also remain non-authoritative and cannot redefine the candidate merely because a tool inspected the wrong checkout. 

### Sources

- Codex’s `REPAIR10I_A6R_RECONNAISSANCE_BASELINE_MISMATCH` report supplied in this turn.
- Governed Execution baseline-drift protocol. 
- Milestone 0 proof-harness and evidence-authority boundary. 
- Provenance establishes exact bytes and identity, not correctness or authority. 

**Confidence:** 0.999 that Codex correctly stopped; 0.97 that the failed gate inspected the primary `trunk_dev` checkout rather than the dedicated candidate worktree; 0.999 that neither checkout should be reset or cleaned; 0.995 that physical-root reconciliation must precede the A6R retry.
