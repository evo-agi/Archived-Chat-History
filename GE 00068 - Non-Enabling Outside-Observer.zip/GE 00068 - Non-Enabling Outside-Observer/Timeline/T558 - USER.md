Here is Codex's response:

1. **Exact primary verdict**

`AUDIT_PROVENANCE_MISMATCH`

`REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED`  
`FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED`

2. **Final PYZ identity**

Matched: device `16777234`, inode `182699827`, mode `0400`, link count `1`, size `4,589,679`, SHA-256 `00df367f2017a5677342520edd2715727d56dbb83c3067c7bb0a8e12bb74eae0`.

3. **Runtime-authority identity**

Matched: device `16777234`, inode `182699838`, mode `0400`, link count `1`, size `56,463`, SHA-256 `9c2b976f26b019bdab1995b3b6023a049e2cf87851d703114351902f95db79d0`.

4. **Current launch-profile identity**

[Launch profile](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-profile-v1.json): device `16777234`, inode `182723650`, mode `0400`, link count `1`, size `9,131`, SHA-256 `14566342da9e7f0198489b0b1a05f4fa9bce711e543602e8b0b7a9b658b58568`.

5. **Current successor-certificate identity**

[Certificate v2](/Users/ds/Downloads/ES-repair10i-v3-replacement-subject-audit-launch-authority-output-ngec4nj0/gen2-replacement-schema-subject-independent-audit.launch-certificate-v2.json): device `16777234`, inode `182723661`, mode `0400`, link count `1`, size `12,987`, SHA-256 `f0a5aedc41f5e743ed4d2d07b1bab1b3363f90141bd18d38aff7c5d7f0b9023f`.

6. **Historical predecessor disposition**

Identity matched: inode `182699841`, mode `0400`, size `3,572`, SHA-256 `525ac09ba02b200853d059abc2a1224cb616823ca5c2647052cd1f386152a50c`. It remains historical, superseded, noncurrent, unmodified, and contributes zero active authorization.

7. **Replacement-subject identity**

Matched: device `16777234`, inode `182649818`, mode `0700`, UID/GID `501/20`. Physical closure remained 73 entries, 12 directories, 61 files, with required modes and no cache, symlink, special object, or multiply linked file.

8. **Construction-wrapper authentication**

Matched device `16777234`, inode `182648782`, mode `0700`, UID/GID `501/0`. Required one-shot construction, custody, locator, accepted-parent, and pending-audit evidence authenticated.

9. **Accepted implementation-chain authentication**

Both roots matched:

- Audit root inode `182593190`, mode `0700`.
- Wrapper root inode `182593189`, mode `0700`.

Accepted disposition remained `GEN2_IMPLEMENTATION_PACKAGE_ACCEPT`; no implementation re-audit occurred.

10. **Content identities**

Bundle matched inode `181651092`, mode `0400`, size `13,598,758`, SHA-256 `b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671`.

Authority matched inode `181651098`, mode `0400`, size `19,737`, SHA-256 `276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563`.

The 479-member deterministic archive and eight-role content closure passed.

11. **Stable prelaunch authentication**

All eleven supplied files/roots authenticated through stable no-follow reads and strict JSON parsing. The independent prelaunch validator reported zero errors, zero schema errors, 89 PYZ members, 479 content members, and all fixed-input comparisons true.

12. **Current launch-authority closure**

The profile and certificate are individually schema-valid and mutually bound, but the required runtime correspondence fails:

- The profile mandates `tempfile.mkdtemp`, producing an already-existing directory.
- That same directory must be the submitted cwd and `--output-root`.
- Frozen `audit_parent.py` forwards the exact `output_root` to `core.create_synthetic_capsule`.
- Frozen `core.py` immediately executes `os.makedirs(root, mode=0o700, exist_ok=False)`.

Therefore the exact profile necessarily supplies an existing path to code that requires that path not to exist. Launching would deterministically raise `FileExistsError` before capsule construction or terminal framing.

13. **PYZ member/governance closure**

Structural closure passed: 89 unique sorted members, 88 registered non-self rows, `ZIP_STORED`, timestamp `2020-01-01T00:00:00`, `create_system=3`, mode `0600`, no comments/extras, and deterministic archive equality.

Governance closure failed specifically at the external-root/runtime semantic boundary described above.

14. **Wrapper-root identity**

Not allocated. The failure occurred in Sections 10–12, before root allocation was permitted.

15. **Fresh audit-root identity**

Not allocated. No existing root was adopted or scanned.

16. **Platform preflight**

Not executed, as required for a prelaunch authority discrepancy.

17. **Exact real-audit argv**

The governed argv was reconstructed exactly, but not executed:

```text
/usr/local/bin/python3.13
-I
-S
-B
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.pyz
--mode
audit
--runtime-authority
/Users/ds/Downloads/ES-repair10i-v3-replacement-schema-subject-clean-audit-harness-output-w1cef__3/gen2-replacement-schema-subject-independent-audit.authority-v1.json
--subject-root
/Users/ds/Downloads/ES-repair10i-v3-schema-subject-reconstruction-z1o1vs54
--construction-wrapper
/private/tmp/ES-repair10i-v3-replacement-schema-subject-construction-wrapper-v3-ewh59_5a
--content-bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--content-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json
--accepted-implementation-audit
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-mp6hex04
--accepted-implementation-wrapper
/private/tmp/ES-repair10i-v3-fresh-independent-audit-v4-wrapper-se4f_xxg
--output-root
<FRESH_PRIVATE_AUDIT_ROOT>
```

18. **Exact cwd/environment/process posture**

The intended controls were authenticated: cwd equal to the fresh audit root; exact five-variable environment; `DEVNULL`; shell/TTY/detachment false; foreground and synchronous true. None were submitted to an audit process.

19. **Top-level process custody**

No audit parent was created. Consequently no audit PID or custody ID exists and the authorization remains unconsumed.

20. **Raw streams**

No audit stdout or stderr exists. No stream was fabricated or parsed.

21. **Exit/signal**

Not applicable; no audit process was created.

22. **Terminal-frame result**

No terminal frame exists.

23. **Audit-root authentication**

Not applicable; no audit root was allocated.

24. **Audit-source/freeze/no-Git posture**

Source freeze authenticated: size `4,030`, SHA-256 `91d989e32750585b924e45f0fa8343b9ad4ddec502db6ad6ffdc548be113151d`, ten frozen sources. Entrypoint, audit parent, core, both oracles, and governance records matched the member registry. No Git/VCS invocation occurred.

25. **Subject terminal closure**

Not reached; no audit capsule exists.

26. **Normative contract**

Embedded bytes remained unchanged, but no audit-capsule application result exists.

27. **Fifteen schema roles**

The frozen embedded 15/14 model authenticated prelaunch. No real-audit result was produced.

28. **Fourteen generated families**

The frozen model authenticated fourteen families, excluding the normative construction parent. No capsule result exists.

29. **Role/family mapping**

Embedded mapping authenticated; real-audit application was not reached.

30. **Draft 2020-12 result**

Not reached for the real audit.

31. **Contract-witness rows**

Not produced.

32. **Schema-witness rows**

Not produced.

33. **Witness aggregate**

Not produced.

34. **Complete 946 result**

Not executed.

35. **Exact failed 946 rows**

None produced; no claim about subject rows is made.

36. **Complete 137 result**

Not executed.

37. **Exact failed 137 rows**

None produced; no claim about subject rows is made.

38. **Dual-oracle crosswalk**

Frozen oracle identities authenticated; no real-subject oracle evaluation occurred.

39. **766/333 field map**

Existing subject/package evidence was not promoted as a real-audit result.

40. **Documentary-validator closure**

Not reached.

41. **Confirmation derivation**

Not reached.

42. **Derivative-confirmation ledger**

Not produced.

43. **Occupancy, lineage, and producer status**

Prelaunch identities authenticated; no capsule adjudication occurred.

44. **Findings**

One launch-provenance finding:

- Direct evidence: profile requires an existing `mkdtemp` output/cwd root.
- Frozen runtime evidence: `core.create_synthetic_capsule` requires the identical root to be absent.
- Repair surface: external launch-profile/root contract or frozen harness root-creation semantics.
- Subject bytes must change: no.
- Subject reconstruction required: no.
- Unchanged-subject audit after separately governed repair: potentially yes.
- No subject blocker is asserted.

45. **Repair-owner registry**

No audit-generated repair-owner registry exists. The prelaunch defect belongs to the external launch-authority/harness integration boundary, not the replacement subject.

46. **Dependency graph**

`mkdtemp` creates root → profile submits same root as cwd/output → audit forwards output unchanged → capsule creator requires absent root → deterministic unhandled failure if launched.

47. **A00–A15**

Not created.

48. **Child custody**

No governed preflight or audit child was created.

49. **Audit cleanup**

Not applicable; no audit-owned objects were created.

50. **Capsule supplied-root equality**

Not applicable; no capsule exists.

51. **Wrapper fixed-input equality**

No supplied input was mutated during prelaunch authentication. No wrapper root was allocated.

52. **Audit temporal identity**

Not created.

53. **Audit manifest identities**

Not created.

54. **A/B equality**

Not applicable.

55. **Final reprojection**

Not performed.

56. **Physical topology/modes**

No audit capsule exists to inspect.

57. **A15/closure agreement**

Not applicable.

58. **Seal/no-postseal result**

No audit seal occurred and no postseal operation was performed.

59. **Confirmation subject unchanged**

The replacement subject was read-only authenticated and remained unchanged.

60. **Confirmation no authority promotion**

No promotion or rebinding occurred.

61. **Confirmation no product/runtime/target/A6 activity**

Confirmed. No product/live-service mode, target audit, runtime validation rerun, publication, deployment, or A6 activity occurred.

62. **Remaining uncertainty/nonclaims**

The replacement subject’s audit disposition remains unknown. A separately governed repair must either make the harness accept a precreated wrapper-owned root or change the launch contract so the harness receives an absent output path while retaining a valid cwd. No workaround was attempted.

63. **Explicit wrapper confirmations**

Confirmed prelaunch:

```text
FINAL_AUDIT_PYZ_IDENTITY_MATCHED
FINAL_RUNTIME_AUTHORITY_IDENTITY_MATCHED
CURRENT_LAUNCH_PROFILE_IDENTITY_MATCHED
CURRENT_SUCCESSOR_CERTIFICATE_IDENTITY_MATCHED
PREDECESSOR_LAUNCH_CERTIFICATE_IDENTITY_MATCHED
PREDECESSOR_CERTIFICATE_NOT_CURRENT
EXACTLY_ONE_ACTIVE_REAL_AUDIT_AUTHORIZATION
REPLACEMENT_SUBJECT_ROOT_IDENTITY_MATCHED
REPLACEMENT_CONSTRUCTION_WRAPPER_AUTHENTICATED
ACCEPTED_IMPLEMENTATION_AUDIT_CHAIN_AUTHENTICATED
CURRENT_CONTENT_BUNDLE_IDENTITY_MATCHED
CURRENT_CONTENT_AUTHORITY_IDENTITY_MATCHED
AUDIT_PYZ_MEMBER_SET_89_CLOSED
QUALIFICATION_MODE_NOT_EXECUTED
REPLACEMENT_AUDIT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
AUDIT_ROOT_SCAN_NOT_PERFORMED
CLEAN_AUDIT_SOURCE_FREEZE_AUTHENTICATED
NO_GIT_OR_VCS_INVOCATION
NORMATIVE_CONTRACT_BYTES_UNCHANGED
REPLACEMENT_SUBJECT_MUTATION_NOT_PERFORMED
REPLACEMENT_SUBJECT_CLEANUP_NOT_PERFORMED
CURRENT_AUTHORITY_PROMOTION_NOT_PERFORMED
CURRENT_AUTHORITY_REBINDING_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
REAL_REPLACEMENT_SUBJECT_AUDIT_NOT_EXECUTED
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_NOT_CONSUMED
```

Not reached and therefore not asserted:

```text
CURRENT_LAUNCH_AUTHORITY_CURRENT_AND_COHERENT
PLATFORM_CAPTURE_PREFLIGHT_PASSED
REAL_SUBJECT_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_REAL_SUBJECT_AUDIT_AUTHORIZATION_CONSUMED
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
TERMINAL_FRAME_STRICTLY_PARSED
TERMINAL_FRAME_ROOT_EQUALS_SUPPLIED_ROOT
SUBJECT_TERMINAL_REPROJECTION_PASSED
EXACTLY_FIFTEEN_CURRENT_SCHEMA_ROLES
EXACTLY_FOURTEEN_GENERATED_RECORD_FAMILIES
NORMATIVE_CONSTRUCTION_PARENT_NOT_COUNTED_AS_GENERATED_FAMILY
SCHEMA_ROLE_TO_FAMILY_MAPPING_COMPLETE
ALL_FIFTEEN_SCHEMAS_METASCHEMA_VALID
FOURTEEN_CONTRACT_WITNESSES_SCHEMA_VALID
FOURTEEN_SCHEMA_WITNESSES_CONTRACT_VALID
WITNESS_AGGREGATE_HAS_EXACT_ROW_EVIDENCE
GENERATED_RECORD_NEGATIVE_MATRIX_946_COMPLETED
EVERY_NONPASSING_946_ROW_RETAINED
CONTRADICTION_REGRESSION_137_COMPLETED
EVERY_NONPASSING_137_ROW_RETAINED
DUAL_ORACLE_RESULTS_AGREE
NO_ORACLE_EXCEPTION
EXACT_GOVERNED_OUTCOME_VOCABULARY_USED
CONTRACT_SCHEMA_FIELD_MAP_766_333_CLOSED
EXACT_CURRENT_DOCUMENTARY_VALIDATOR_ROLE_SET
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PRESENT
ALL_CURRENT_DOCUMENTARY_VALIDATOR_RESULTS_PASSED
CONFIRMATION_EVIDENCE_MAP_COMPLETED
DERIVATIVE_CONFIRMATIONS_NOT_COUNTED_AS_DIRECT_BLOCKERS
NO_HARDCODED_CONFIRMATION_SUCCESS
CURRENT_ROLE_OCCUPANCY_COMPLETE
GOVERNED_DOCUMENTARY_VALIDATOR_PREFIX_USED
NO_HISTORICAL_CLOSURE_OUTPUT_CURRENT
NO_FAILED_ARTIFACT_CURRENT
IMPLEMENTATION_PRESENT_FALSE
IMPLEMENTATION_AUTHORITY_FALSE
PRODUCER_PACKAGE_NOT_SELF_PROMOTED
INDEPENDENT_ACCEPTANCE_NOT_PRECLAIMED
EVERY_DIRECT_BLOCKER_HAS_NON_NULL_DIRECT_EVIDENCE
EVERY_DIRECT_BLOCKER_HAS_PRIMARY_REPAIR_OWNER
FINDING_OWNERSHIP_COMPLETE
EVERY_REQUIRED_AUDIT_PHASE_TERMINAL
A15_STATUS_EQUALS_FINAL_CLOSURE_PASS
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
AUDIT_CLEANUP_SET_EQUALITY_PASSED
CAPSULE_SUPPLIED_ROOT_CLOSING_EQUALITY_PASSED
WRAPPER_FIXED_INPUT_CLOSING_EQUALITY_PASSED
AUDIT_TEMPORAL_INVENTORY_CREATED
AUDIT_TEMPORAL_INVENTORY_VERIFIED
AUDIT_MANIFEST_A_CREATED
AUDIT_MANIFEST_B_CREATED
AUDIT_MANIFESTS_BYTE_IDENTICAL
AUDIT_TERMINAL_REPROJECTION_PASSED
AUDIT_ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_AUDIT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_AUDIT_DIRECTORY_MODES_0700
ALL_AUDIT_FILE_MODES_0600
NO_AUDIT_CACHE_OR_BYTECODE_RETAINED
SINGLE_AUDIT_SEAL_TRANSITION
NO_WRITE_AFTER_AUDIT_TERMINAL_SEAL
```
