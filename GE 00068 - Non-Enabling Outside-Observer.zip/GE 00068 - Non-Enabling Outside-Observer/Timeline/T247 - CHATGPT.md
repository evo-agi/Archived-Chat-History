## Assessment

This result is decisive. **The governance implementation is not defective; the proposed parent commit is wrong.**

The seven accepted files are the exact **B→F governance delta**, but the attempted commit applied their complete current blobs directly to **H**:

- **H** — current Git HEAD.
- **B** — authenticated pre-governance dirty baseline: 36 changed paths, comprising 22 modifications and 14 additions.
- **F** — current audited governance state.
- **S** — synthetic `H + seven current files`, which failed 10 of 106 documentary tests.

The H/S/B/F matrix proves the failures are causal, not an environment or test-harness anomaly:

- All ten fail on **S**.
- All ten pass on **B** and **F**.
- Nine are direct documentary or path-presence dependencies.
- The remaining P0r failure depends on older test infrastructure excluded from S.
- Minimal overlays identified eight immediate prerequisite paths, all byte-identical in B and F and therefore predating governance.

The eight-path union is only a **diagnostic minimum**, not a safe commit expansion. The coherent predecessor state is B’s full 36-path delta.

A particularly important consequence resolves the earlier staging-classification confusion: the deployment document is untracked against H, but it already exists in B. Once H→B is represented in Git, that document becomes tracked. The later B→F governance commit should then contain **seven modified paths**, exactly as the original governance model expected.

### Decision

Stop all governance commit-gate retries.

The critical path is now:

1. Recover the authoritative logical commit topology from H to B.
2. Validate and independently qualify those predecessor commit units.
3. Publish the predecessor sequence so the resulting committed tree equals B exactly.
4. Run a fresh parent-only commit gate for the unchanged B→F governance delta.
5. Keep A6 and semantic-successor implementation blocked throughout.

Do **not**:

- commit the seven files directly onto H;
- expand the commit to the eight causal paths;
- make a monolithic 36-path commit merely because B passes;
- narrow the 106-test gate;
- reconstruct a direct H→F governance patch;
- edit the audited F bytes.

The report says no repository-byte repair is needed. The unresolved problem is the historical publication topology of the already-authenticated H→B work.

## Prompt for Codex

```text
REPAIR 10I PREDECESSOR COMMIT-TOPOLOGY RECONNAISSANCE

Perform a fresh, parent-only, read-only reconstruction of the authoritative Git
publication topology from current HEAD H to the authenticated pre-governance
baseline B.

Do not create subagents.

This is not implementation, staging, committing, or an independent audit. Do
not mutate the candidate repository, its index, or any supplied evidence.

Return exactly one primary verdict:

PREDECESSOR_COMMIT_TOPOLOGY_RECOVERED
PREDECESSOR_TOPOLOGY_REQUIRES_FRESH_AUDIT
PREDECESSOR_TOPOLOGY_REQUIRES_REIMPLEMENTATION
RECONCILIATION_PROVENANCE_MISMATCH
RECONCILIATION_INCONCLUSIVE

OBJECTIVE

Recover the exact logical commit DAG that should transform Git HEAD H into the
authenticated pre-governance state B, without changing B or the accepted B→F
governance delta.

The result must determine:

1. which logical tranches comprise H→B;
2. the exact path and byte set of every tranche;
3. each tranche’s dependencies and governing evidence;
4. which tranche boundaries are already independently accepted;
5. which require fresh audit or implementation;
6. the safe commit and validation order ending in a committed tree equal to B;
7. the conditions under which the existing B→F governance audit remains usable.

Do not assume H→B is one commit. Do not assume it must be split. Recover the
topology from retained authority, evidence, tests, and exact bytes.

──────────────────────────────────────────────────────────────────────────────
1. EXACT STATES
──────────────────────────────────────────────────────────────────────────────

Candidate repository:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

H — current Git baseline:

- commit:
  567bceced5df95ecfe787cc66038d463a854e12c
- tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f

B — authenticated pre-governance dirty baseline:

- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e
- inventory SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2
- governed files:
  389
- relative to H:
  22 modified tracked paths
  14 untracked/addition paths
  36 total changed paths

F — current accepted governance state:

- source T:
  f276536fea579d0842cda43b0290656b200b7f27
- inventory SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738
- governed files:
  389

S — rejected seven-path tree:

- Git tree:
  03490869d931e2eff93bc7dcd2d1f64813c776f1
- construction:
  H plus the seven complete current F governance files
- validation:
  96 pass
  10 fail
  0 skip

The reconciliation already established:

- all ten failing identities pass on B and F;
- all ten fail on S;
- the exact seven files were already dirty at B;
- the seven complete F blobs therefore include H→B predecessor bytes;
- whole-file staging against H conflates predecessor and governance work.

Verify these identities before deeper analysis.

Stop with RECONCILIATION_PROVENANCE_MISMATCH on drift.

──────────────────────────────────────────────────────────────────────────────
2. NAMED EVIDENCE ROOTS
──────────────────────────────────────────────────────────────────────────────

Failed staged-tree gate:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-commit-gate-v3-qv31qdyj

Commit-scope reconciliation:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-reconciliation-mmaexmlj

Governance-freeze implementation:

/Users/ds/Downloads/ES-repair10i-a6-successor-governance-freeze-implementation-37417ce2a5d7ebe2997294f2cd299ed2

Governance audit repair:

/Users/ds/Downloads/ES-repair10i-a6-governance-audit-repair-vv8mi2cl

Accepted governance/mode-provenance audit:

/Users/ds/Downloads/ES-repair10i-a6-governance-mode-provenance-final-audit-fjuro9xw

Repair 10 validation lineage:

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1

You may follow exact paths named by candidate governing documents and by records
inside these roots. Do not broadly scan unrelated Downloads or repository
siblings.

Treat all evidence roots as read-only.

──────────────────────────────────────────────────────────────────────────────
3. EFFECT BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Authorized:

- read candidate docs, source, tests, Git objects, and named evidence;
- create one fresh private reconciliation root beneath /Users/ds/Downloads;
- materialize H, B, F, and candidate intermediate trees only inside that root;
- create private Git repositories or alternate indexes inside that root;
- run bounded offline documentary or source tests against private
  materializations when needed to evaluate a proposed commit boundary;
- create reports, dependency graphs, and candidate patch-stack projections.

Forbidden:

- repository edits or index mutation;
- staging, commit, restore, reset, amend, rebase, cherry-pick, stash, merge, or
  worktree mutation in the candidate;
- supplied-evidence mutation;
- product or live-service invocation;
- installation;
- network contact;
- A6 work;
- subagents.

Every candidate Git read must use:

git -C "/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1"

with cwd equal to that repository and:

PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
GIT_OPTIONAL_LOCKS=0
GIT_CONFIG_NOSYSTEM=1
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1

──────────────────────────────────────────────────────────────────────────────
4. EXACT H→B PATH MANIFEST
──────────────────────────────────────────────────────────────────────────────

Derive and retain the complete 36-path H→B manifest from authenticated H and B
bytes.

For each path record:

- repo-relative path;
- H presence, logical mode, size, SHA-256;
- B presence, logical mode, size, SHA-256;
- classification:
  modified / added / deleted / renamed;
- current F identity;
- whether B→F later changes that path;
- exact authoritative source of B bytes;
- exact evidence records binding the H→B change.

Do not derive the 36-path set from current F status alone.

Require the reconstructed B tree to match:

- 389 governed files;
- source T:
  8de797304ea944b6a155924e0d1e9e8bbe79534e;
- inventory:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2.

──────────────────────────────────────────────────────────────────────────────
5. TRANCHE-LINEAGE RECOVERY
──────────────────────────────────────────────────────────────────────────────

For every H→B path, recover its logical origin from:

- PLANS.md;
- complete relevant .docs pages;
- docs_contract_test.go;
- product/source tests;
- retained implementation and audit reports;
- manifests, provenance records, deltas, and attempt indexes;
- exact earlier tranche names and boundaries.

At minimum distinguish:

- Remote Alpha status-observation implementation;
- status package and facade;
- prepare command/script;
- test-support isolation/process infrastructure;
- lifecycle/policy/current-target documentation;
- Repair 5 through Repair 10 documentary/test work;
- validation fixtures and testdata;
- any unrelated predecessor tranche.

Do not group paths merely by directory or filename. Use governing intent,
validation ownership, and retained provenance.

For each recovered logical tranche state:

- objective;
- authority classification;
- exact path set;
- exact before and after byte identities;
- dependencies;
- retained validation;
- retained independent audit;
- commit/publication status;
- whether its evidence is acceptance-bearing or report-only;
- unresolved seams.

──────────────────────────────────────────────────────────────────────────────
6. TEST AND DEPENDENCY DAG
──────────────────────────────────────────────────────────────────────────────

Build a path/test dependency DAG for H→B.

Include:

- every documentary test introduced or materially changed in H→B;
- every product/source test introduced or materially changed;
- each file read or required by those tests;
- compile-time package dependencies;
- path-presence dependencies;
- fixture dependencies;
- source-root/test-infrastructure dependencies;
- semantic documentation dependencies.

Incorporate the previously established eight-path diagnostic union:

- remote_alpha_normal_shell_runtime_image_check_test.go
- internal/testsupport/controlroot.go
- .docs/system_overview/remote_supported_host_alpha.md
- .docs/system_overview/remote_alpha_external_tls_lifecycle.md
- .docs/system_overview/remote_alpha_external_tls_policy_core_v1.md
- .docs/system_overview/remote_alpha_external_tls_status_observation_v1.md
- scripts/remote_alpha_prepare_external_tls_status.sh
- es/externaltls/internal/statuspackage/package.go

Treat this as causal evidence only, not as an authorized commit set.

Identify any additional dependency needed for a coherent logical tranche even
when it was not required by the ten failed tests.

──────────────────────────────────────────────────────────────────────────────
7. WHOLE-FILE LINEAGE
──────────────────────────────────────────────────────────────────────────────

For every path changed in more than one historical tranche, recover exact
whole-file generations and byte deltas.

At minimum, for the seven governance paths, retain:

- H bytes;
- B bytes;
- governance implementation bytes;
- audit-repair bytes;
- F bytes.

Identify exact hunks belonging to:

A. H→B predecessor work;
B. B→governance implementation;
C. governance implementation→audit repair;
D. later changes, if any.

Do not infer tranche ownership from the final H→F diff.

State which exact historical byte generation must be used in each predecessor
commit and which evidence supplies it.

──────────────────────────────────────────────────────────────────────────────
8. CANDIDATE COMMIT DAG
──────────────────────────────────────────────────────────────────────────────

Propose the narrowest coherent commit DAG that:

- begins at H;
- ends at a committed tree exactly equal to B;
- preserves logical tranche boundaries;
- does not create a commit that fails its own acceptance-bearing tests because
  companion paths are deferred;
- does not conflate unrelated product, test, and documentary work without
  retained authority;
- uses only exact authenticated bytes;
- makes no current F byte change.

For every proposed commit provide:

- ordinal and dependency parents;
- proposed exact subject;
- objective;
- exact path classifications;
- exact target blob identities;
- expected resulting tree or pure source identity;
- relevant tests;
- exact validation command set;
- available producer evidence;
- available independent audit;
- whether a fresh audit is required;
- whether publication can proceed without implementation;
- stop conditions.

Do not propose a monolithic H→B commit merely because B passes. A monolithic
commit is allowed only if retained governance and provenance establish H→B as
one intended logical tranche.

Do not propose the eight-path diagnostic union as a commit merely because it
repairs the ten failures.

──────────────────────────────────────────────────────────────────────────────
9. PRIVATE COMMIT-STACK SIMULATION
──────────────────────────────────────────────────────────────────────────────

Inside the reconciliation root only, simulate each proposed commit sequence.

The simulation must not write Git objects or index state into the candidate
repository.

For each proposed commit boundary:

- materialize the exact candidate tree;
- verify path membership and byte identities;
- run the tranche-specific documentary tests;
- run relevant product/source tests where retained governing evidence makes
  them acceptance-bearing;
- run complete docs_contract_test.go identities where the candidate tree
  changes that test;
- require zero unexplained failure or skip;
- prove the next commit applies cleanly to that exact tree.

A simulated tree passing tests is evidence of coherence, not authority to
commit.

If exact intermediate bytes or acceptance evidence are unavailable, stop that
candidate sequence and classify the gap.

──────────────────────────────────────────────────────────────────────────────
10. B→F GOVERNANCE DISPOSITION
──────────────────────────────────────────────────────────────────────────────

After recovering the H→B publication program, adjudicate the unchanged B→F
governance tranche.

Require acknowledgment that:

- all seven governance paths exist and are tracked once B is committed;
- the deployment document is therefore modified, not added, in B→F;
- B→F should leave no unrelated dirty state if H→B has been fully published;
- the accepted audit binds exact F bytes and exact correction evidence;
- no direct H→F governance patch is authorized.

State exactly whether:

A. the existing independent governance audit remains sufficient byte/correctness
   evidence after an exact committed B parent, with only a fresh parent-only
   commit gate required; or

B. a new independent audit is required because commit topology or reconstructed
   parent context materially changes the audited claim.

Do not silently assume audit reuse. Ground the answer in retained audit scope.

──────────────────────────────────────────────────────────────────────────────
11. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return PREDECESSOR_COMMIT_TOPOLOGY_RECOVERED only when:

- exact H→B bytes are complete;
- each logical tranche and dependency is recovered;
- the proposed commit DAG is coherent;
- private simulation passes at every boundary;
- every commit is backed by sufficient evidence, or explicitly marked for a
  fresh bounded audit;
- the resulting final predecessor tree is exactly B;
- B→F disposition is explicit.

Return PREDECESSOR_TOPOLOGY_REQUIRES_FRESH_AUDIT when:

- exact bytes and logical boundaries are recoverable;
- implementation is not needed;
- one or more predecessor commits lack sufficient independent acceptance
  evidence.

Return PREDECESSOR_TOPOLOGY_REQUIRES_REIMPLEMENTATION when:

- safe commit slicing requires changing, re-deriving, or reconstructing
  repository bytes not available as exact accepted artifacts.

Return RECONCILIATION_INCONCLUSIVE when a smallest named evidence gap prevents
a justified result.

Return RECONCILIATION_PROVENANCE_MISMATCH on target or supplied-input drift.

──────────────────────────────────────────────────────────────────────────────
12. REQUIRED FINAL REPORT
──────────────────────────────────────────────────────────────────────────────

Report:

1. Primary verdict
2. Opening and closing identities
3. Exact H/B/F/S state map
4. Complete 36-path H→B manifest
5. Per-path tranche lineage
6. Recovered logical tranche inventory
7. Test/path dependency DAG
8. Whole-file generation map for multi-tranche paths
9. Existing validation and audit coverage by tranche
10. Exact proposed commit DAG
11. Per-commit path/classification/blob manifest
12. Per-commit validation and audit requirements
13. Private simulation results
14. Missing or ambiguous evidence
15. B→F governance audit disposition
16. Recommended publication program and stop conditions
17. Artifact and cleanup result
18. Remaining uncertainty
19. Explicit confirmations

Confirm:

REPOSITORY_MUTATION_NOT_PERFORMED
INDEX_MUTATION_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
SUPPLIED_EVIDENCE_NOT_MUTATED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SUBAGENTS_CREATED: 0
```

## Strategic implication

The correct publication architecture is now visible:

**H → authenticated predecessor tranche sequence → B → audited governance commit → F**

The governance freeze is not being rejected. It is waiting for its proper parent.

### Source

Codex reconciliation report pasted in the preceding message, especially §§4–15.

**Confidence:** 0.995 that the seven-path commit must not be retried on H; 0.98 that H→B publication topology is now the sole critical path; 0.90 that the predecessor state will require multiple logical commits rather than one 36-path commit.
