## Assessment

This is a **package-closure failure**, not a target defect and not a demonstrated defect in the repaired selector or finalizer semantics.

Codex reports that the meaningful qualification work passed:

- The seven exported files were frozen and requalified at their expected identities.
- The binding selector, finalizer lifecycle, 32-case matrix, independent validator, success causal, failure causals, process custody, compilation, static analysis, and retained-evidence replay all passed.
- The real target audit did not run.
- Every supplied root closed unchanged.

But the package is unusable because it was never sealed:

- `closeout/temporal-final-inventory-v1.json` is absent.
- Terminal manifests A and B are absent.
- `source/__pycache__` and a `.pyc` remain.
- The cache directory has mode `0755`.
- The retained preterminal verdict explicitly says closure was pending and has no terminal authority.

Do **not** modify or resume `/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli`. Preserve it as failed packaging evidence. The next tranche should create a new immutable package from the exact frozen exports and qualified evidence, with **zero semantic source changes**, no Python imports, no bytecode generation, and complete terminal closure.

Forward this prompt:

```text
CLOSURE-ONLY REPACKAGE OF THE QUALIFIED V3 TARGET-AUDIT HARNESS

This task creates a new terminally sealed immutable package from the exact
qualified exports and retained qualification evidence in one failed, unsealed
package.

It is not:

- a target-audit harness semantic repair;
- a target repair;
- a target audit;
- a bootstrap repair;
- a validation rerun;
- a repository or product task.

Do not modify, clean, resume, finish, or reseal the failed package root.

Do not edit any exported source, contract, policy, or template byte.
Do not rerun the real target audit.
Do not rerun runtime validation.
Do not execute Plan V3 or Plan V4.
Do not import the target-audit payload as Python.
Do not run Git.
Do not use the network.
Do not invoke a product or live service.
Do not install, deploy, publish, commit, or start A6.
Do not create subagents or direct auditors.

Return exactly one primary verdict:

TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_READY
TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_BLOCKED
PREFLIGHT_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. FAILED UNSEALED PACKAGE
──────────────────────────────────────────────────────────────────────────────

FAILED_PACKAGE_ROOT:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli

Expected root identity:

- device/inode:
  16777234 / 180115518
- mode:
  0700
- retained task verdict:
  PREFLIGHT_PROVENANCE_MISMATCH
- physical paths reported:
  54
- reported directories:
  10
- reported regular files:
  44

Preserve this root unchanged as failed package-closure evidence.

Authenticate and inspect at minimum:

closeout/primary-verdict.json
opening/target-audit-harness-freeze-v1.json
validation/frozen-harness-requalification-v1.json
validation/support-binding-mutation-matrix-v1.json
validation/support-binding-live-replay-v1.json
validation/finalizer-mutation-matrix-v2.json
validation/independent-finalizer-validator-v1.json
validation/retained-failed-audit-replay-v1.json
qualification/direct-finalizer-process-custody-v1.json
validation/exact-semantic-delta-v1.json

and every source, contract, template, validation, qualification, analysis,
opening, closing, and provenance file referenced by the freeze and
requalification records.

Do not treat `closeout/primary-verdict.json` as current package authority. It is
a preterminal failed-attempt record whose own content states terminal closure
was pending.

──────────────────────────────────────────────────────────────────────────────
2. EXACT FROZEN EXPORTS
──────────────────────────────────────────────────────────────────────────────

The following seven files are the sole frozen consumer-facing exports.

Require exact identities:

source/target_audit_payload_v2.py

- size:
  203704
- SHA-256:
  3528fc8b06665c4a1ec18a12b6ae0e0bbd0c1496767420139627d8064af7ee42

contract/target-audit-plan-v2.json

- size:
  8544
- SHA-256:
  5ea0060b...0e00

contract/support-root-binding-policy-v1.json

- size:
  4051
- SHA-256:
  0cc44dc9...a87d

contract/finalizer-lifecycle-v1.json

- size:
  2261
- SHA-256:
  73f30bed...fef8

contract/finalizer-process-custody-v1.json

- size:
  1068
- SHA-256:
  b9e3ccd4...7bd7

templates/carrier-0003-request-template-v2.json

- size:
  2941
- SHA-256:
  89bb7eb2...20e7

templates/finalizer-invocation-contract-template-v1.json

- size:
  3557
- SHA-256:
  569509be...0dab

Resolve every abbreviated digest from the authenticated failed-package freeze
record. Retain complete 64-character values in all new records.

Freeze-record input:

opening/target-audit-harness-freeze-v1.json

- size:
  12063
- SHA-256:
  d37288c835598be83841c58163847817da333c08c38df8cd6f3edd2584f98e1a

No exported file may change.

Do not rewrite absolute paths silently. Scan the seven export files for the
failed-package absolute root.

If an acceptance-bearing export contains the failed-package physical path and
is not explicitly parameterized by contract, stop with:

TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_BLOCKED

Report the exact file and field. Do not rebind it in this task.

──────────────────────────────────────────────────────────────────────────────
3. FRESH PACKAGE ROOT
──────────────────────────────────────────────────────────────────────────────

Allocate one fresh private root beneath `/Users/ds/Downloads` using
`tempfile.mkdtemp`, umask `077`, prefix:

ES-repair10i-v3-target-audit-harness-package-

Immediately emit:

PACKAGE_ROOT=<absolute-path>

Before copying content retain:

opening/bootstrap-start.json

including:

- fresh-root identity;
- allocation method;
- umask;
- failed-package identity;
- failed-package opening inventory identity;
- frozen-export identities;
- closure-only authority;
- semantic changes authorized:
  false;
- target audit executed:
  false;
- runtime validation rerun:
  false.

Create directories lazily.

Do not retain an empty directory.

──────────────────────────────────────────────────────────────────────────────
4. COMPLETE FAILED-PACKAGE MEMBERSHIP LEDGER
──────────────────────────────────────────────────────────────────────────────

Independently enumerate all current failed-package paths with lstat/no-follow.

Retain:

analysis/failed-package-membership-ledger-v1.json

Classify every path exactly once as one of:

CURRENT_FROZEN_EXPORT
CURRENT_QUALIFICATION_EVIDENCE
CURRENT_PROVENANCE_OR_LINEAGE
HISTORICAL_FAILED_CLOSURE_EVIDENCE
REGENERATED_CURRENT_CLOSURE_OUTPUT
FORBIDDEN_INCIDENTAL_ARTIFACT
UNKNOWN

Required classifications:

source/__pycache__
source/__pycache__/*.pyc

→ FORBIDDEN_INCIDENTAL_ARTIFACT

closeout/primary-verdict.json

→ HISTORICAL_FAILED_CLOSURE_EVIDENCE

The absent current temporal inventory and manifests:

closeout/temporal-final-inventory-v1.json
manifest/canonical-manifest-a-v1.json
manifest/canonical-manifest-b-v1.json

→ REGENERATED_CURRENT_CLOSURE_OUTPUT

Any `UNKNOWN` path blocks the task.

For each path retain:

- type;
- mode;
- link count;
- size;
- SHA-256 for regular files;
- producing record or inferred producer;
- role;
- consumer;
- current-authority eligibility;
- copy disposition;
- destination path, if copied;
- justification.

──────────────────────────────────────────────────────────────────────────────
5. BYTECODE-CACHE ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Inspect the existing cache read-only.

Retain:

analysis/bytecode-cache-adjudication-v1.json

Record:

- exact cache directory identity and mode;
- every `.pyc` path;
- size and SHA-256;
- parsed pyc header when safely possible;
- referenced source identity;
- mtime/creation chronology;
- most likely producing qualification or closure phase;
- whether the cache contributed to any qualified result;
- classification:
  incidental disallowed artifact;
- copy disposition:
  excluded.

Do not execute or import the `.pyc`.

Do not remove it from the failed root.

The new package must contain:

- no `__pycache__`;
- no `.pyc`;
- no bytecode cache of any kind.

All package-building Python processes must use:

-I -S -B

and:

PYTHONDONTWRITEBYTECODE=1

Do not import any copied package Python source.

──────────────────────────────────────────────────────────────────────────────
6. CLOSED COPY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

Copy byte-for-byte only paths classified as:

CURRENT_FROZEN_EXPORT
CURRENT_QUALIFICATION_EVIDENCE
CURRENT_PROVENANCE_OR_LINEAGE

Use:

- no-follow source opens;
- exclusive destination creation;
- files mode 0600;
- directories mode 0700;
- complete write;
- fsync;
- close;
- no-follow reopen;
- exact byte comparison.

Do not copy:

- forbidden incidental artifacts;
- stale current closeout verdicts;
- stale temporal inventory;
- partial or absent manifests;
- a directory merely because it existed in the failed root.

Represent excluded historical package-closure records through an external
identity ledger rather than copying them into current authority paths.

Retain:

lineage/failed-unsealed-package-binding-v1.json

Bind:

- failed package root identity;
- complete failed-package inventory identity;
- preterminal verdict identity;
- missing terminal paths;
- cache identities;
- closure failure reason;
- nonauthority;
- superseding new package root;
- semantic export equality.

Historical failed-package bytes must not become current verdict or current
closure authority.

──────────────────────────────────────────────────────────────────────────────
7. CURRENT PACKAGE AUTHORITY
──────────────────────────────────────────────────────────────────────────────

Retain:

opening/current-package-authority-v1.json

Require:

- exactly seven consumer-facing exports;
- their exact fixed identities;
- exact qualification-evidence set;
- exact provenance/lineage set;
- failed package:
  historical and nonauthoritative;
- semantic source changes:
  none;
- contract changes:
  none;
- template changes:
  none;
- validation rerun:
  false;
- qualification causals rerun:
  false;
- target audit run:
  false.

The new package is a closure-only successor.

It does not supersede or alter the semantic content of the frozen exports.

──────────────────────────────────────────────────────────────────────────────
8. FREEZE AND QUALIFICATION-EVIDENCE CROSSWALK
──────────────────────────────────────────────────────────────────────────────

Independently parse the old freeze record and frozen requalification record.

Retain:

analysis/freeze-and-evidence-crosswalk-v1.json

For every identity referenced by the freeze record:

- locate the exact failed-package path;
- authenticate current bytes;
- classify its role;
- state whether it is copied;
- bind its destination path;
- prove byte equality.

Require every qualification claim used by the package to have a retained,
authenticated supporting record.

Do not invent a passing result from the preterminal confirmation file.

Use the actual underlying records for:

- support-binding matrix;
- support-binding replay;
- finalizer matrix;
- independent validator;
- successful finalization causal;
- failure causals;
- process custody;
- retained failed-audit replay;
- compilation;
- static analyses;
- frozen requalification;
- supplied-root closing equality.

If any indispensable supporting record is missing or inconsistent, return:

TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_BLOCKED

──────────────────────────────────────────────────────────────────────────────
9. EXPORT ROOT-INDEPENDENCE CHECK
──────────────────────────────────────────────────────────────────────────────

Strictly inspect all seven frozen exports for:

- failed-package absolute path;
- fresh-package absolute path;
- hard-coded qualification fixture roots;
- stale synthetic roots;
- mutable latest/prefix authority;
- package-root device/inode dependence.

Retain:

analysis/export-root-independence-v1.json

Classify every absolute path occurrence by exact file and field.

Require:

- consumer-facing semantics remain parameterized or fixed to legitimate
  external inputs;
- no acceptance-bearing reference to the failed package root;
- no silent root rebinding required.

This is a read-only check. Do not alter exports.

──────────────────────────────────────────────────────────────────────────────
10. NEW PACKAGE CLOSURE RECORD
──────────────────────────────────────────────────────────────────────────────

Retain:

opening/target-audit-harness-package-closure-v1.json

Bind:

- fresh package root identity;
- failed package binding;
- exact seven export identities;
- qualification-evidence identities;
- copy ledger identity;
- cache exclusion identity;
- root-independence result;
- semantic change:
  false;
- package status:
  proposed-current-pending-fresh-target-audit;
- target audit executed:
  false;
- no package repair beyond closure;
- no bootstrap or target authority.

This record is package metadata, not a semantic target-audit export.

──────────────────────────────────────────────────────────────────────────────
11. NO SEMANTIC OR DYNAMIC REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Do not rerun:

- support-binding mutation cases;
- finalizer mutation cases;
- independent validator cases;
- success/failure finalizer causals;
- direct finalizer launches;
- target audit payload;
- runtime validation;
- package producer tests.

The prior records are copied and authenticated as retained qualification
evidence.

Allowed checks are limited to:

- strict parsing;
- hashing;
- byte comparison;
- membership;
- role classification;
- root-independence inspection;
- capsule closure.

Do not import or execute the frozen payload.

──────────────────────────────────────────────────────────────────────────────
12. FINAL REPORT AND CONFIRMATIONS
──────────────────────────────────────────────────────────────────────────────

Finalize a complete current report before terminal inventory creation:

closeout/final-package-closure-report-v1.md

Return the same complete report inline. The retained file may mirror the inline
report but must not replace it.

Retain:

closeout/explicit-confirmations-v1.json

Required current confirmations:

FAILED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
FAILED_PACKAGE_ROOT_NOT_RESUMED
FAILED_PACKAGE_ROOT_NOT_CLEANED
EXACT_SEVEN_EXPORT_IDENTITIES_PRESERVED
EXPORTED_SOURCE_BYTES_UNCHANGED
EXPORTED_CONTRACT_BYTES_UNCHANGED
EXPORTED_TEMPLATE_BYTES_UNCHANGED
SEMANTIC_CHANGE_NOT_PERFORMED
VALIDATION_RERUN_NOT_PERFORMED
QUALIFICATION_CAUSALS_NOT_RERUN
REAL_TARGET_AUDIT_NOT_EXECUTED
BYTECODE_CACHE_NOT_COPIED
PYC_NOT_COPIED
PRETERMINAL_VERDICT_NOT_CURRENT
FAILED_PACKAGE_BOUND_AS_HISTORICAL_EVIDENCE
QUALIFICATION_EVIDENCE_COPIED_AND_AUTHENTICATED
EXPORT_ROOT_INDEPENDENCE_VERIFIED
NO_UNKNOWN_PACKAGE_PATH
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

Do not mark package closure complete yet.

──────────────────────────────────────────────────────────────────────────────
13. TEMPORAL FINAL INVENTORY
──────────────────────────────────────────────────────────────────────────────

After every nonmanifest artifact is final, generate:

closeout/temporal-final-inventory-v1.json

Use a stable no-follow grammar.

Require:

- root represented;
- all current directories represented;
- all current nonmanifest regular files represented;
- exact declared exclusions:
  - this temporal inventory;
  - future manifest A;
  - future manifest B;
- future manifest directory treatment explicitly declared;
- no unstable directory size/link metadata when excluded by the grammar;
- no symlink;
- no special object;
- no multi-link regular file;
- all directories mode 0700;
- all files mode 0600;
- no empty retained directory except an explicitly reserved future
  `manifest/` directory at the premanifest checkpoint;
- no `__pycache__`;
- no `.pyc`.

Reopen and reverify the inventory before manifest generation.

──────────────────────────────────────────────────────────────────────────────
14. TERMINAL MANIFEST GENERATION
──────────────────────────────────────────────────────────────────────────────

After temporal inventory verification:

1. Ensure the exact reserved `manifest/` directory exists at mode 0700.
2. Independently generate manifest A with one implementation.
3. Independently generate manifest B with a separate implementation.
4. Require generated bytes to be byte-identical before writing.
5. Exclusively create:
   `manifest/canonical-manifest-a-v1.json`
6. Write all bytes, fsync, close.
7. Exclusively create:
   `manifest/canonical-manifest-b-v1.json`
8. Write all bytes, fsync, close.
9. Fsync the manifest directory.
10. Reopen both no-follow.
11. Verify size and SHA-256.
12. Require on-disk A equals generated A.
13. Require on-disk B equals generated B.
14. Require A equals B.
15. Independently regenerate whole-root closure.
16. Require exact equality with A and B.
17. Require no empty directory at terminal closure.
18. Require no cache, bytecode, symlink, special object, or multi-link file.
19. Require all directory/file modes `0700/0600`.

After terminal manifest closure, perform no filesystem write.

──────────────────────────────────────────────────────────────────────────────
15. CURRENT VERDICT AUTHORITY
──────────────────────────────────────────────────────────────────────────────

The package becomes current only when:

- temporal inventory exists and verifies;
- both manifests exist;
- manifests are byte-identical;
- independent reprojection passes;
- terminal posture passes;
- no write occurs afterward.

Do not create a success verdict before manifest closure.

The final inline verdict is the task response after read-only observation of the
sealed package.

Do not place an additional verdict file after terminal closure.

──────────────────────────────────────────────────────────────────────────────
16. FAILED-PACKAGE CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat a complete lstat/no-follow inventory of:

/Users/ds/Downloads/ES-repair10i-v3-target-audit-harness-repair-odqwbxli

Require exact opening/closing equality.

Do not open unrelated supplied roots unless an internal qualification record is
missing or inconsistent.

Any additionally opened supplied root requires exact opening/closing equality.

──────────────────────────────────────────────────────────────────────────────
17. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_READY

only when:

- failed package authenticates and closes unchanged;
- all failed-package paths are classified;
- no unknown path remains;
- seven frozen exports match exactly;
- no root-bound semantic defect exists;
- every indispensable qualification record is copied and authenticated;
- no semantic file changes;
- no dynamic validation rerun;
- no cache or pyc is copied;
- stale preterminal verdict is historical only;
- new package authority record is exact;
- temporal final inventory exists and verifies;
- terminal manifests exist;
- terminal manifests are byte-identical;
- independent terminal reprojection passes;
- terminal posture passes;
- no write follows terminal closure.

Return:

TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_BLOCKED

when:

- an export is root-bound to the failed package;
- an indispensable qualification record is missing;
- path authority is ambiguous;
- closure-only copying cannot produce a self-contained package without
  semantic changes;
- any unexpected or unknown path remains.

Return:

PREFLIGHT_PROVENANCE_MISMATCH

for:

- failed-package mutation;
- failed-package closing inequality;
- export identity mismatch;
- unauthorized semantic drift;
- new package closure failure;
- any filesystem write after terminal closure.

──────────────────────────────────────────────────────────────────────────────
18. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Fresh package-root identity
3. Failed-package identity and closure
4. Complete failed-package membership classification
5. Bytecode-cache adjudication
6. Exact seven export identities
7. Export root-independence result
8. Closed copy boundary
9. Qualification-evidence crosswalk
10. Failed-package historical binding
11. Current package authority record
12. Confirmation semantic files are unchanged
13. Confirmation validation was not rerun
14. Confirmation real target audit did not run
15. Failed-package closing equality
16. New package temporal-inventory identity
17. New package manifest A identity
18. New package manifest B identity
19. Independent terminal reprojection
20. Terminal membership and mode closure
21. Cache/bytecode absence
22. No-write-after-closure result
23. Complete current package membership
24. Remaining uncertainty and nonclaims
25. Explicit confirmations

Required confirmations:

FAILED_PACKAGE_ROOT_MUTATION_NOT_PERFORMED
FAILED_PACKAGE_ROOT_NOT_RESUMED
FAILED_PACKAGE_ROOT_NOT_CLEANED
EXACT_SEVEN_EXPORT_IDENTITIES_PRESERVED
EXPORTED_SOURCE_BYTES_UNCHANGED
EXPORTED_CONTRACT_BYTES_UNCHANGED
EXPORTED_TEMPLATE_BYTES_UNCHANGED
SEMANTIC_CHANGE_NOT_PERFORMED
VALIDATION_RERUN_NOT_PERFORMED
QUALIFICATION_CAUSALS_NOT_RERUN
REAL_TARGET_AUDIT_NOT_EXECUTED
BYTECODE_CACHE_ADJUDICATED
BYTECODE_CACHE_NOT_COPIED
PYC_NOT_COPIED
PRETERMINAL_VERDICT_NOT_CURRENT
FAILED_PACKAGE_BOUND_AS_HISTORICAL_EVIDENCE
QUALIFICATION_EVIDENCE_COPIED_AND_AUTHENTICATED
EXPORT_ROOT_INDEPENDENCE_VERIFIED
NO_UNKNOWN_PACKAGE_PATH
TEMPORAL_FINAL_INVENTORY_CREATED
TEMPORAL_FINAL_INVENTORY_VERIFIED
TERMINAL_MANIFEST_A_CREATED
TERMINAL_MANIFEST_B_CREATED
TERMINAL_MANIFESTS_BYTE_IDENTICAL
INDEPENDENT_TERMINAL_REPROJECTION_PASSED
NO_EMPTY_DIRECTORY_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_BYTECODE_OR_CACHE_RETAINED
NO_WRITE_AFTER_TERMINAL_CLOSURE
FAILED_PACKAGE_CLOSING_EQUALITY_PASSED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

After `TARGET_AUDIT_HARNESS_PACKAGE_CLOSURE_READY`, run one fresh target audit
using the accepted bootstrap and the exact newly sealed harness package. Do not
regenerate or edit the exports.
```

**Source:** Codex’s `PREFLIGHT_PROVENANCE_MISMATCH` report in the current turn.  
**Confidence:** 1.00 that the current package is unusable and must not be executed; 0.995 that no semantic harness or target repair is authorized; 0.98 that a fresh closure-only package is the narrowest correct next step.
