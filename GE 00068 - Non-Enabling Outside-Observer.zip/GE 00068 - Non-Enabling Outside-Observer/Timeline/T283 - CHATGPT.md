## Assessment

This is a credible repair implementation and is ready for a **fresh independent audit**.

The report closes the two substantive blockers from the previous audit without changing the V3 contract or Plan V4:

- The new capsule contains exactly one current normative V3 contract and one current Plan V4. The predecessor failed-attempt contract and plan were not copied; they are now represented only by a typed, explicitly nonnormative lineage index.
- The V2 adoption record preserves the two raw `pass:false` results and now binds the exact correction record for the eight-command and cleanup observations. The V2 audit verdict remains `BLOCK`.

It also addresses the evidence-hardening findings:

- Two independent manifest generators use no-follow enumeration, detect directory symlinks, reject special objects and hardlinks, and exclude unstable directory metadata.
- The final inventory has a bounded temporal model.
- The sensitive-material scan covers the finalized implementation report and explicitly describes what did not yet exist.
- Two independent validators pin their own 64-name mutation sets and rejection reasons.

There is no basis for repository work or runtime replay. The next step is an independent audit of the new capsule.

The fresh audit should pay particular attention to four matters:

1. Whether `replay-and-cleanup-corrections.json`, despite having no schema field, actually supports the two corrected technical observations without widening them.
2. Whether the whole-root authority scan truly leaves exactly one current contract and one current Plan V4.
3. Whether the manifest generators dynamically reject directory symlinks, special files, hardlinks, empty directories, and unsupported paths—not merely claim to.
4. Whether the final scan/inventory/report chronology is represented truthfully. The audit should scan the complete terminal capsule itself rather than treating the producer scan as exhaustive.

## Fresh independent-audit prompt

```text
FRESH INDEPENDENT AUDIT —
REPAIR 10I T2A-P VALIDATION-CUSTODY V3 AUDIT-REPAIR CAPSULE

Perform a wholly fresh, independent, read-only audit of the exact
Validation-Custody V3 audit-repair capsule and its bounded lineage.

Do not repair anything.
Do not mutate any supplied root.
Do not rerun runtime validation.
Do not run repository tests, product code, Plan V3, or Plan V4.
Do not make network contact.
Do not stage or commit.
Do not start A6.
Do not create nested subagents.

Return exactly one primary verdict:

ACCEPT
BLOCK
REJECT
AUDIT_PROVENANCE_MISMATCH

OBJECTIVE

Determine whether the exact source-external audit-repair capsule:

1. preserves the accepted V3 contract and Plan V4 semantics byte-for-byte;
2. establishes exactly one current normative V3 writer and one current Plan V4;
3. keeps all failed-attempt normative bytes historical, external, noncurrent,
   nonauthoritative, and runtime-ineligible;
4. repairs the complete V2 technical-evidence adoption lineage without hiding
   raw failures or promoting the V2 audit’s BLOCK verdict;
5. independently preserves Plan V3→V4 semantic equivalence;
6. preserves the exact five-source closure and 86-byte path derivation;
7. has robust file-and-directory membership closure, including directory
   symlink detection;
8. has complete mutation resistance;
9. has truthful inventory, sensitive-material, and temporal closure;
10. leaves every supplied root unchanged.

An ACCEPT qualifies only the exact static validation-custody contract,
Plan V4, provenance lineage, and bounded technical-evidence composition.
It grants no publication, commit, product, runtime, deployment, readiness,
semantic-successor, orchestrator, or A6 authority.

──────────────────────────────────────────────────────────────────────────────
1. PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

Use the accepted transcript-authoritative carrier model.

Generic wrapper capability root:

/Users/ds/Downloads/ES-repair10i-generic-phase-wrapper-probe-sj1gm5ns

Accepted wrapper:

provenance/phase_runner.py

SHA-256:

6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

The Codex platform transcript is authoritative for:

- top-level local-process carrier ordering;
- submitted cwd;
- platform-reported outcome class;
- direct-auditor creation, scheduling, identity, and completion.

The audit root is authoritative for:

- bootstrap identity;
- phase-start and phase-outcome records;
- child-process records;
- target observations;
- retained artifacts;
- opening and closing equality;
- audit-owned cleanup.

No persistent supervisor is required or permitted.

Read this entire prompt before invoking a tool. Administrative prompt intake
before the audit epoch is excluded from evidence.

Then state exactly:

AUDIT_EPOCH_START

The first post-epoch local-process carrier is the bootstrap exception. Every
later local target-facing or audit-artifact-facing process carrier must invoke
the exact copied generic wrapper.

No unwrapped diagnostic local-process carrier is permitted after bootstrap.

Direct auditor interactions are not local-process carriers. Index them
separately under the four-auditor interaction record.

──────────────────────────────────────────────────────────────────────────────
2. STABLE CARRIER-INDEX CONTRACT
──────────────────────────────────────────────────────────────────────────────

Do not require the retained carrier index to reproduce opaque tool-internal
command expansions that are not exposed by the platform.

For every local-process carrier, retain only these stable fields:

- contiguous carrier ordinal;
- phase name;
- wrapper path, size, and SHA-256;
- payload path, size, and SHA-256;
- submitted cwd;
- explicit environment record path and SHA-256;
- platform-reported outcome class:
  success, recorded-failure, or unavailable;
- phase-start path, size, and SHA-256;
- phase-outcome path, size, and SHA-256;
- child-process ordinal range;
- artifact references;
- discrepancy status.

The visible platform transcript remains authoritative for actual launch and
ordering.

The carrier index must state:

`carrier_launch_authority = "codex-platform-tool-transcript"`

and:

`audit_root_does_not_self_attest_parent_process_creation = true`

Return AUDIT_PROVENANCE_MISMATCH if:

- a visible local-process carrier is omitted;
- a retained carrier has no corresponding visible tool call;
- a post-bootstrap target-facing carrier lacks wrapper records;
- carrier order is ambiguous;
- submitted cwd conflicts with the wrapper’s observed cwd;
- an unwrapped diagnostic local process is launched.

Do not fail merely because the platform does not expose an internal command
serialization.

──────────────────────────────────────────────────────────────────────────────
3. EXACT INPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

CANDIDATE_R:

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Expected candidate:

- branch:
  codex/remote-alpha-external-tls-status-observation-v1
- HEAD:
  567bceced5df95ecfe787cc66038d463a854e12c
- HEAD tree:
  b7cab23732572c2aaea9d5f2f1593338e2e75338
- sole parent:
  05dde14d185b6e022dcc169ef1a658a97961850f
- upstream:
  absent
- governed/tracked/untracked:
  389 / 375 / 14
- tracked modifications:
  22
- staged/deleted/renamed/unmerged:
  0 / 0 / 0 / 0
- F source T:
  f276536fea579d0842cda43b0290656b200b7f27
- F inventory:
  54314 bytes
  SHA-256:
  2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738

STRATEGIC_B_GATE_ROOT:

/Users/ds/Downloads/ES-strategic-b-gate-requalification-uTwKU7hS

Accepted gate record:

closeout/accepted-strategic-b-opening-gate-v1.json

- 4173 bytes
- SHA-256:
  555041298ee49db603a7c3ff64e022cdf8bf79cd7d7edc6007dcd32e35998212

Accepted gate manifests:

- 10066 bytes each
- SHA-256:
  d58de35fdf630829b1fb7efe80a04f0616a66c98039fdf27a2b49a622c49bd05
- byte-identical

STRATEGIC_B_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-snapshot-tx56oir2

Accepted stable identities:

- canonical projection:
  96657 bytes
  SHA-256:
  4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360

- B source inventory:
  54314 bytes
  SHA-256:
  64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2

- B source tree:
  8de797304ea944b6a155924e0d1e9e8bbe79534e

BLOCKED_V1_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf

VALIDATION_CUSTODY_V2_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-v2-8r8lyfra

V2_INDEPENDENT_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v2-independent-audit-znleuyfy

Expected V2 verdict:

BLOCK

Expected V2 report:

- 92491 bytes
- SHA-256:
  e977c8ed3394f5e890a1cc1d6b0bf0067b7c430de9b264b5bd9d8028eb6c1e05

Expected V2 inventory:

- 69706 bytes
- SHA-256:
  9d29fb1b53f56768fc03762fb152562368f5f3903a02dc4aa0c10d14c2292caf

V3_PREDECESSOR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-record-repair-emh5kxis

PREVIOUS_BLOCKING_AUDIT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-independent-audit-cjba38lf

V3_AUDIT_REPAIR_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-0mwnrf5b

Expected repair-root identity:

- device/inode/mode:
  16777234 / 178948757 / 0700

FAILED_AUDIT_REPAIR_ATTEMPT_ROOT:

/Users/ds/Downloads/ES-repair10i-t2ap-validation-custody-v3-audit-repair-4i5hddd3

Expected:

- device/inode/mode:
  16777234 / 178947279 / 0700
- complete inventory digest:
  1637998409dc36c50d2cf9f40d7b4b05891fe0d141d8c6f53a680064e18108e3
- disposition:
  immutable failed repair attempt
- expected current contract or Plan:
  none

──────────────────────────────────────────────────────────────────────────────
4. FIXED REPAIR-CAPSULE IDENTITIES
──────────────────────────────────────────────────────────────────────────────

Current V3 contract:

contract/strategic-b-validation-custody-v3.json

- 4878 bytes
- SHA-256:
  16bfae705924cc67ce21dc8b4a2aada0d181b930a395fc03616f2d05aa017d55

Current Plan V4:

contract/validation-plan-v4.json

- 26001 bytes
- SHA-256:
  af1a4349ce6abfc4eadba43297b634c27b8069e2407c4c980737760599098dea

Failed-attempt index:

lineage/failed-and-superseded-attempt-index-v2.json

- 6884 bytes
- SHA-256:
  f7e19e44047e764f80f72e4f59b7d9f055d8a52e905c3b6482a790bd4bfc9d83

Authoritative supersession:

lineage/authoritative-supersession-v1.json

- 4816 bytes
- SHA-256:
  1db6abcf4c077d1b303772ad190981ad11de5af49e6d6430cebd8a836bbfdc4c

V2 adoption V2:

adoption/v2-technical-evidence-adoption-v2.json

- 56563 bytes
- SHA-256:
  fdafef48a62bbe04e71c3cf5f805c93e25b71daa86aec1a7b521a781383674e9

Complete observation-lineage ledger:

adoption/complete-observation-lineage-ledger-v1.json

- 50136 bytes
- SHA-256:
  d7afb786f724e620c49c74fac68b09aba4ac5fd0a1b96d67837a39979c04f396

Authority scan:

- 2234 bytes
- SHA-256:
  f9c4190764a8a238e0205d9647a161e3ce1f322f347c62fa245b36e2b7c4aa3b

Independent V3 field map:

- 10977 bytes
- SHA-256:
  4bdfc5a910261ebcdde9b4afefd59c2ea1c9daf0e682eecedc516ec2d91e72de

Authority and nonauthority revalidation:

- 1102 bytes
- SHA-256:
  20c87446a772b06706d8fe4c5f78bf83ce32d9a3119ff5c92664dac8ef7e9133

Repair-owned Plan-equivalence result:

- 2392 bytes
- SHA-256:
  26b309dbed6fefd83d72d0378cd6a37cceff2bf95fedb7e51cadf6781cd5850b

Repair-owned source-closure revalidation:

- 2109 bytes
- SHA-256:
  e5db881ba95196a6ef4ed71f910e39d32f5099814ec5f0aa577fddc289ac5251

Producer validator:

- source:
  22097 bytes
  SHA-256:
  5702a316c7a2066f9ba25a4a62c4e31ee2847e6f02cb5d52678717dcc41efa5b
- result:
  17890 bytes
  SHA-256:
  ce8d0ab299ed1fe7af1cd1b8d512622394c5d6d7786b82c9fcfbd2bee4fafb09

Independent validator:

- source:
  21623 bytes
  SHA-256:
  480d04da1e57eda709171f570e0baa7d500e66945f8dbe110a57d59224e21922
- result:
  18229 bytes
  SHA-256:
  1119953ad7d5108035d82853073822291cb02bb1fcb68c7c5c4e6d01fd032384

Final evidence inventory:

closeout/final-evidence-inventory-v2.json

- 12106 bytes
- SHA-256:
  fb8b2c509121cde9bc80365ec25597b1aab1e3bfe9e7a5f274da8c2b9a4811e6

Final sensitive-material scan:

closeout/final-sensitive-material-scan-v1.json

- 18332 bytes
- SHA-256:
  5f70142c1c0460920b3dcf419d436ec2009f754ec32aedb92f04cf0bc6455801

Closing equality:

- 5400 bytes
- SHA-256:
  1ed0984e824685d51df19e52a0d56de24e4e47bfbeeeef037214c9dfc6d4b55a

Cleanup record:

- 841 bytes
- SHA-256:
  9732eaed3c75a867c5180e6670f5a8b6b7469b3c7ebb4491df313daf10204c65

Final implementation report:

closeout/final-implementation-report-v2.md

- 10650 bytes
- SHA-256:
  b6efb70d366844ed41a386d30d912e2df01c8e499fc97544aab65473b34a51e5

Manifest pair:

manifest/canonical-manifest-a-v2.json
manifest/canonical-manifest-b-v2.json

- 12587 bytes each
- SHA-256:
  b7836cb66f5e23811914e69e140d544b7dbabb1e6437f819e7ff2da4a0849206
- required byte-identical

Expected final closure:

- 9 directories including root
- 61 physical regular files including manifests
- 59 nonmanifest regular files
- 68 represented entries
- exactly two manifest self-exclusions
- no empty directory
- no symlink or special object
- directories mode 0700
- files regular, single-link, mode 0600

──────────────────────────────────────────────────────────────────────────────
5. FRESH AUDIT ROOT AND WRAPPED PROCESS MODEL
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh audit root beneath `/Users/ds/Downloads` with
`tempfile.mkdtemp`, umask 077, prefix:

ES-repair10i-t2ap-validation-custody-v3-audit-repair-independent-audit-

Bootstrap may be one unwrapped local carrier and must inspect no target.

Copy the exact accepted generic wrapper to:

provenance/phase_runner.py

Require SHA-256:

6e911ca17dedc6c5838b8b880548761b9009bb18fc26f1e7b6934d274f040f56

Every later local-process carrier must invoke that wrapper.

Do not launch an unwrapped diagnostic local process.

Create and retain a child recorder. Before target inspection, prove:

- recorded missing-executable ENOENT causal;
- recorded `/usr/bin/true` exit-0 causal;
- complete stream files;
- reaping;
- descriptor closure.

Every later child process must use the same recorder.

──────────────────────────────────────────────────────────────────────────────
6. OPENING PROVENANCE GATE
──────────────────────────────────────────────────────────────────────────────

Before correctness inspection:

1. Verify candidate identity and applicable repository guidance.
2. Verify accepted Strategic B gate root.
3. Re-run both Strategic B canonical generators and require:
   96657 /
   4c5556d5c74a5c9a8669e4ba9f2ec061d97fa6fa6e6276459439d9d376370360
4. Verify Strategic B source inventory and tree.
5. Verify complete blocked-V1 closure.
6. Verify complete V2 closure.
7. Verify complete V2-audit closure and verdict BLOCK.
8. Verify complete predecessor-V3 closure.
9. Verify complete previous blocking-audit closure.
10. Verify complete failed audit-repair attempt closure.
11. Verify complete repair-root closure and every fixed identity above.
12. Retain complete lstat/no-follow inventories.
13. Verify candidate Git locks and operation markers absent.
14. Verify carrier and child-record continuity.

Stop with AUDIT_PROVENANCE_MISMATCH on any mismatch.

Do not use either legacy Strategic B ordering-dependent inventory as an
acceptance gate.

──────────────────────────────────────────────────────────────────────────────
7. FOUR DIRECT AUDITORS
──────────────────────────────────────────────────────────────────────────────

After opening provenance passes, start exactly three distinct direct auditors
concurrently. Start a fourth after the first completes.

Auditor 1 — normative authority and supersession

Inspect:

- current contract and Plan;
- failed-attempt index;
- authoritative supersession;
- whole-root authority claims;
- predecessor failed-attempt bytes by reference.

Determine whether exactly one current contract and one current Plan exist.

Auditor 2 — V2 adoption and correction lineage

Inspect:

- all nine adoption rows;
- all raw V2 records;
- correction record;
- complete observation-lineage ledger;
- V2 report and verdict.

Determine whether every adopted fact is precisely supported without promoting
the V2 BLOCK verdict.

Auditor 3 — static semantics and contradiction resistance

Inspect:

- V3 contract;
- Plan V3 and Plan V4;
- source closure;
- path derivation;
- both validators and result sets.

Determine whether semantics remain exact and mutation resistance is adequate.

Auditor 4 — capsule, manifests, inventory, scan, and security

Inspect every repair-root object.

Determine:

- complete membership;
- directory-symlink safety;
- stable inventory fields;
- temporal exclusions;
- final scan completeness;
- sensitive-material posture;
- supplied-root invariance.

Auditors run no Git, tests, runtime validation, product code, network, or
nested agents. Retain exact prompts, authorized operands, reports, and limits.

──────────────────────────────────────────────────────────────────────────────
8. NORMATIVE AUTHORITY AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently scan every retained repair-root file.

Classify:

- standalone current normative JSON objects;
- historical references;
- mutation values inside validator code;
- report prose;
- nonnormative validators;
- nonnormative evidence records.

Require exactly:

- one standalone current V3 contract;
- one standalone current Plan V4;
- one current contract sole-writer claim;
- zero historical copied contract or Plan objects;
- zero other file claiming current normativity;
- zero failed-attempt artifact eligible for runtime or acceptance use.

Independently verify every failed-attempt index entry against its predecessor
path, size, and SHA-256.

Independently verify the supersession record does not widen semantic scope.

Return BLOCK for any competing or ambiguous authority.

──────────────────────────────────────────────────────────────────────────────
9. V2 ADOPTION AND CORRECTION AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently parse all nine rows of:

adoption/v2-technical-evidence-adoption-v2.json

For every row:

- authenticate raw path, size, SHA-256, and schema presence/absence;
- read the exact raw status fields;
- decide whether the adopted fact follows from the raw record;
- when a correction is cited, authenticate the correction record and exact
  supporting fields;
- verify adoption basis is correct;
- verify the adopted fact is no broader than its evidence;
- verify all authority flags remain false;
- verify `dynamic_replay:false`;
- verify `v2_audit_verdict:BLOCK`;
- verify `verdict_promoted:false`.

For OBS-05:

- preserve raw `pass:false` and `all_accepted:false`;
- verify the exact eight-command correction fields;
- verify exact expected failure/skip identity handling;
- reject any claim that the raw summary alone passed.

For OBS-06:

- verify all eight cross-command-isolation subrecords individually support the
  isolation-only adopted fact despite the false aggregate.

For OBS-07:

- preserve raw cleanup `pass:false`;
- verify the bounded `/bin/ps` false-positive explanation;
- verify two actual ENOENT observations;
- verify the empty post-run PID query;
- reject any broader cleanup claim.

The correction record has no `schema` field. Record that fact literally. Do not
invent one.

Independently reconcile the complete lineage ledger with the adoption record.

Return BLOCK on an unsupported, ambiguous, strengthened, or verdict-promoting
fact.

──────────────────────────────────────────────────────────────────────────────
10. STATIC SEMANTIC REVALIDATION
──────────────────────────────────────────────────────────────────────────────

Without runtime replay, independently verify:

- complete V3 typed field map;
- eight false authority flags;
- six false unsupported-host/alias flags;
- child/environment layout;
- allocator contract;
- 57/59/12/13/86/100 path budget;
- exact five-source closure;
- Plan V3→V4 normalized equality;
- exactly eight preserved commands;
- exact argv, environment, identity policy, expected fail/skip policy, B
  identity, and shared-r custody;
- exact 86-byte derivation reaching `itoa.go`.

Do not use producer static results as the oracle.

──────────────────────────────────────────────────────────────────────────────
11. INDEPENDENT MUTATION MATRIX
──────────────────────────────────────────────────────────────────────────────

Do not import either producer validator or consume its fixtures as case
generators.

Independently construct and execute at least the exact 64 named cases in the
implementation report.

For every case require:

- unique name;
- explicit intended mechanism;
- specific rejection reason;
- no fallback to unrelated parse failure;
- zero false acceptances.

Add audit-only cases when useful, including:

- contract ID collision under another path;
- current Plan embedded in a report-shaped JSON envelope;
- correction record path changed but digest retained;
- correction digest changed but path retained;
- correction fields contradict raw observation;
- failed-attempt reference points outside predecessor root;
- sensitive scan excludes an undeclared file;
- manifest generator follows a directory symlink;
- final inventory includes directory link count;
- a report omits `REPORT_NORMATIVE:false`.

Retain the independent validator source and complete result matrix.

──────────────────────────────────────────────────────────────────────────────
12. MANIFEST-GENERATOR SOURCE AND DYNAMIC CAUSALS
──────────────────────────────────────────────────────────────────────────────

Inspect both producer manifest generators completely.

Independently establish that both:

- use lstat/no-follow semantics;
- inspect directory entries without following links;
- reject directory symlinks;
- reject file symlinks;
- reject special objects;
- reject multiply linked files;
- reject empty retained directories;
- use complete relative-path UTF-8 byte ordering;
- omit directory size and link count;
- include all directories and all nonmanifest files.

Create only audit-owned fixtures beneath the audit root and test both generators
against:

1. stable regular tree — both accept with byte-identical output;
2. directory symlink — both reject;
3. file symlink — both reject;
4. FIFO or another special object — both reject;
5. multiply linked regular file — both reject;
6. empty directory — both reject;
7. invalid or unsupported path encoding where safely constructible — fail
   closed;
8. directory metadata changes that do not alter path/type/mode — manifest bytes
   remain stable.

Do not mutate the supplied repair capsule.

Independently enumerate the real repair root and require exact equality with
both supplied manifests.

──────────────────────────────────────────────────────────────────────────────
13. FINAL INVENTORY AND TEMPORAL AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently inspect:

closeout/final-evidence-inventory-v2.json

Require its exact exclusions to be:

1. itself;
2. manifest A;
3. manifest B.

Require:

- every represented directory is present;
- every represented regular file is present;
- no unrepresented nonmanifest path;
- no directory size;
- no directory link count;
- no volatile timestamp/device/inode field used as stable authority;
- final manifests cover the final inventory.

Confirm that the inventory does not claim to hash itself or future manifest
bytes.

──────────────────────────────────────────────────────────────────────────────
14. FINAL SENSITIVE-MATERIAL AUDIT
──────────────────────────────────────────────────────────────────────────────

Independently scan the complete terminal repair capsule, including:

- final implementation report;
- final inventory;
- final sensitive scan;
- both manifests;
- validators;
- adoption and lineage records;
- reports and revalidation records.

Do not emit matched payload content.

Compare with the producer scan:

- verify every producer-scanned path and identity;
- verify the producer’s temporal exclusions were truthful;
- record that the producer final inventory did not yet exist at scan time;
- determine whether any terminal file introduces a plausible live secret.

Hashes, fixtures, redaction expressions, and placeholders are not live secrets
unless content establishes otherwise.

Any plausible live secret blocks acceptance.

──────────────────────────────────────────────────────────────────────────────
15. NO RUNTIME REPLAY
──────────────────────────────────────────────────────────────────────────────

Do not execute:

- Plan V3 or Plan V4;
- repository tests;
- product code;
- V2 allocator or causals;
- live service or route.

Allowed executable work is limited to audit-owned:

- parsers;
- inventory builders;
- hashers;
- static source analyzers;
- plan comparators;
- mutation validators;
- manifest-fixture causals;
- scanners;
- cleanup tools;
- candidate Git reads.

──────────────────────────────────────────────────────────────────────────────
16. CLOSING EQUALITY AND CLEANUP
──────────────────────────────────────────────────────────────────────────────

After all auditors and parent correctness work complete:

- repeat candidate Git identity and status;
- repeat complete inventories for every supplied root;
- require byte-for-byte equality with opening;
- verify the five pinned source files unchanged;
- verify all carrier and child records complete;
- verify no child, process, or descriptor survivor;
- remove only the exact audit-owned `private/` path;
- make two fresh `lstat` observations on that exact path;
- require ENOENT twice.

Retain complete closing records.

──────────────────────────────────────────────────────────────────────────────
17. PLATFORM-CARRIER INDEX
──────────────────────────────────────────────────────────────────────────────

Index every local-process carrier using only the stable fields defined in §2.

Direct auditor interactions belong in a separate auditor-interaction index.

For the final inventory carrier, it is permitted to record:

`platform_outcome_class = "pending-at-index-time; supplied-by-platform-transcript"`

The inline final report must reconcile that final platform result.

Do not require exact opaque tool-internal command serialization.

Return AUDIT_PROVENANCE_MISMATCH only for an actual missing or conflicting
carrier, wrapper record, child quartet, cwd, environment identity, ordering, or
supplied-root equality—not for unavailable tool-internal formatting.

──────────────────────────────────────────────────────────────────────────────
18. FINAL AUDIT INVENTORY
──────────────────────────────────────────────────────────────────────────────

Use one final wrapped inventory carrier.

Its payload must verify all earlier carriers, child records, auditor records,
expected artifacts, and cleanup.

It must create:

closeout/final-audit-root-inventory.json

Its exactly two temporal self-exclusions are:

1. itself;
2. its own wrapper-created phase-outcome record.

No other exclusion is permitted.

After the payload returns, the wrapper writes the final outcome. No later
filesystem-writing carrier is permitted.

The inline report must disclose the final-outcome temporal exclusion and bind
the outcome’s terminal size and SHA-256 from the completed filesystem.

──────────────────────────────────────────────────────────────────────────────
19. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return ACCEPT only if:

- opening and closing provenance qualify;
- every fixed repair identity matches;
- exactly one current normative contract and Plan exist;
- every failed-attempt reference is exact and nonauthoritative;
- every V2 adopted fact is supported by raw or raw-plus-correction evidence;
- V2 remains BLOCK;
- V3 and Plan V4 semantics remain unchanged;
- static field, equivalence, source, and path derivations pass;
- independent mutation matrix passes;
- both manifest generators pass source review and dynamic causals;
- real capsule closure passes;
- final inventory chronology is truthful;
- terminal sensitive-material scan passes;
- four independent auditors complete;
- process and artifact continuity pass;
- no acceptance-affecting residual finding remains.

Return BLOCK for a repairable authority, adoption, contract, plan, lineage,
manifest, inventory, scan, contradiction-resistance, or artifact defect.

Return REJECT only for fundamental unsoundness outside the bounded repair
scope.

Return AUDIT_PROVENANCE_MISMATCH for actual input drift, supplied-root
mutation, missing fixed input, failed opening/closing equality, unrecorded
local carrier, missing phase record, missing child quartet, or unknown process
activity.

Do not repair anything.

──────────────────────────────────────────────────────────────────────────────
20. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return:

1. Primary verdict
2. Audit-root and bootstrap identity
3. Process-authority split
4. Candidate and supplied-root opening identities
5. Repair-capsule fixed identities
6. Four auditor identities, scheduling, reports, and limits
7. Normative-authority and supersession adjudication
8. Failed-attempt lineage verification
9. Complete V2 adoption-row adjudication
10. Raw and correction lineage for OBS-05 and OBS-07
11. V2 BLOCK preservation
12. Independent V3 field-map result
13. Independent Plan V3→V4 equivalence
14. Exact-source and 86-byte derivation
15. Independent mutation matrix
16. Manifest-generator source review
17. Dynamic manifest-generator causals
18. Real capsule and manifest closure
19. Final inventory temporal adjudication
20. Terminal sensitive-material adjudication
21. Confirmation no runtime replay occurred
22. Authority and nonauthority
23. Severity-ranked residual findings
24. Minority findings and parent resolution
25. Cleanup and exact-private-path ENOENT observations
26. Candidate and supplied-root closing equality
27. Platform-carrier and child-process audits
28. Final audit-root inventory and temporal exclusions
29. Audit-created paths and retained membership
30. Remaining uncertainty and explicit nonclaims
31. Explicit confirmations

Required confirmations:

CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_GATE_ROOT_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKED_V1_REPAIR_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V2_CAPSULE_MUTATION_NOT_PERFORMED
V2_INDEPENDENT_AUDIT_MUTATION_NOT_PERFORMED
VALIDATION_CUSTODY_V3_PREDECESSOR_MUTATION_NOT_PERFORMED
PREVIOUS_BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
FAILED_AUDIT_REPAIR_ATTEMPT_MUTATION_NOT_PERFORMED
V3_AUDIT_REPAIR_CAPSULE_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
V3_CONTRACT_SEMANTICS_NOT_CHANGED
PLAN_V4_SEMANTICS_NOT_CHANGED
EXACTLY_ONE_CURRENT_V3_NORMATIVE_WRITER
EXACTLY_ONE_CURRENT_PLAN_V4_WRITER
FAILED_ATTEMPT_NORMATIVE_BYTES_NOT_CURRENT
V2_RAW_FAILURES_PRESERVED
V2_CORRECTION_LINEAGE_EXPLICIT
V2_BLOCK_VERDICT_NOT_PROMOTED
RUNTIME_VALIDATION_NOT_RERUN
PERSISTENT_SUPERVISOR_NOT_USED
GENERIC_WRAPPER_RETAINED_AND_HASH_BOUND
TOP_LEVEL_CARRIERS_COMPLETELY_INDEXED
TOP_LEVEL_PHASE_RECORDS_COMPLETE_AND_CONTIGUOUS
CHILD_PROCESS_RECORDS_COMPLETE_AND_CONTIGUOUS
NO_LOCAL_PROCESS_BYPASSED_PHASE_RECORDING
NO_CHILD_PROCESS_BYPASSED_CHILD_RECORDER
FOUR_AUDITOR_INTERACTIONS_RECONCILED
DIRECTORY_SYMLINK_REJECTION_CAUSAL_PASSED
SPECIAL_OBJECT_REJECTION_CAUSAL_PASSED
HARDLINK_REJECTION_CAUSAL_PASSED
EMPTY_DIRECTORY_REJECTION_CAUSAL_PASSED
PRIVATE_SUBTREE_REMOVED
TWO_EXACT_PRIVATE_PATH_ABSENCE_OBSERVATIONS_COMPLETED
FINAL_AUDIT_INVENTORY_TEMPORAL_EXCLUSIONS_EXACT
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
NESTED_SUBAGENTS_CREATED: 0
```

After an `ACCEPT`, the next program is the real H→B commit gate. No further V3 implementation or runtime validation should intervene.

**Source:** Codex’s V3 audit-repair implementation report above.

**Confidence:** 0.99 that the producer addressed both target blockers correctly; 0.97 that the expanded evidence-hardening fixes are sufficient; 0.95 that the capsule is ready for a clean independent audit under the corrected carrier-index contract.
