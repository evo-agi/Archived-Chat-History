Here is Codex's response:

## 1. Primary verdict

`REPAIR10I_T2AP_STRATEGIC_B_VALIDATION_CUSTODY_REPAIR_BLOCKED`

The 57-byte short root proves an 86-byte worst-case socket path, safely below the 100-byte limit. However, the prescribed bindings make `TMPDIR=<SHORT_ROOT>/t` and `ES_REPAIR10_CONTROL_ROOT=<SHORT_ROOT>/r` siblings. Exact B requires TMPDIR to be contained by the control root, so both mandatory short-root positive tests fail before socket allocation or bind.

Retained capsule: [final implementation report](/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf/closeout/final-implementation-report-v1.md).

## 2. Opening identities

Candidate:

- Branch: `codex/remote-alpha-external-tls-status-observation-v1`
- HEAD: `567bceced5df95ecfe787cc66038d463a854e12c`
- Tree: `b7cab23732572c2aaea9d5f2f1593338e2e75338`
- Sole parent: `05dde14d185b6e022dcc169ef1a658a97961850f`
- Upstream absent
- 375 tracked, 14 untracked, 389 governed
- 22 tracked modifications
- 0 staged/deleted/renamed/unmerged
- F source T: `f276536fea579d0842cda43b0290656b200b7f27`
- F inventory: 54,314 bytes, SHA-256 `2c152fd6a6d558bff3a56d906f0bd0b8c7f346fcb647d40fe386cfd02163d738`
- Candidate index SHA-256: `b2856028ec627e9f5f07d508a08b840545750419e98ce32a869d8d7197a20d91`

Strategic snapshot:

- Root device/inode: `16777234/178255587`
- 569 total entries: 107 directories, 462 regular files
- Full fingerprint: `bc48896d63540b7db0cb75ade6e5c19aba525cea7dea1d8dca3ceaabf7814826`
- All four required closeout identities matched, including byte-identical snapshot manifests.

Blocking audit:

- Root device/inode: `16777234/178361381`
- 85 total entries: 6 directories, 79 regular files
- Full fingerprint: `1ae5c09749d7d6bcef5a0bc4000e8561e0e193ab81df9190fe9cebd3ac97476a`
- Required report and inventory hashes matched.
- Required prior verdict `BLOCK` was present.

The pinned Go files and all 80 module-cache seed objects across 20 modules were also bound at opening.

## 3. Correction-root identity

- Path: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf`
- Allocator: `tempfile.mkdtemp`
- Required prefix used
- Direct child of `/Users/ds/Downloads`
- Device/inode: `16777234/178515489`
- UID/GID: `501/20`
- Mode: `0700`

## 4. Blocking findings consumed

1. `TestRepair10ControlRootPolicyV1` previously failed the 100-byte fail-closed path limit.
2. `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` previously reached a 105-byte Unix-socket bind failure.
3. The earlier producer placed control/TMP custody in the mutable supplied snapshot.
4. An independent audit cannot mutate that supplied snapshot.
5. All source, tree, provenance, synthetic-commit, plan, and closure identities otherwise qualified.

## 5. Exact validation-custody contract

Contract ID: `execution-substrate.repair10i-t2ap.strategic-b-validation-custody.v1`

```text
ES_REPAIR10_SOURCE_ROOT=${SHORT_ROOT}/s
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
HOME=${SHORT_ROOT}/h
TMPDIR=${SHORT_ROOT}/t
GOTMPDIR=${SHORT_ROOT}/u
GOCACHE=${SHORT_ROOT}/c
GOMODCACHE=${SHORT_ROOT}/m
```

The only direct short-root children were `s h t u c m r`, all physical directories at mode `0700`. No supplied path was used for generated-state custody.

## 6. Short-root allocation

Successful causal root:

`/Users/ds/Downloads/r10b-e439822d67ed90213cf83702327682df`

- 16 CSPRNG bytes encoded as 32 lowercase hexadecimal characters
- One allocation attempt
- Absolute path length: 57 bytes
- Device/inode: `16777234/178535964`
- UID/GID/mode: `501/20/0700`
- `/Users/ds/Downloads` opened component-by-component with no link following
- Root created descriptor-relatively and exclusively
- Parent/root/child descriptors and identities held during execution
- Direct parentage, stable identity, ownership, GID, mode, and non-alias/non-containment checks passed
- No existing path was adopted, renamed, mounted, or linked

## 7. Source-derived 100-byte path budget

Exact sources inspected:

- `internal/testsupport/controlroot.go`: 8,695 bytes, SHA-256 `3242abc3bfd62400834b99d1386f88974f463ca5287be7faf4182161f8ec57f3`
- `internal/testsupport/controlroot_test.go`: 1,359 bytes, SHA-256 `de224a8fe61becb88237fca683c1bd91406d8952d1f776819f3f069ef5509e6f`
- `es/runtimehelper/helper_test.go`: 5,017 bytes, SHA-256 `715b6e1ada4f24a51457b31f28782966804479b18d0ba7b90c73609d17d0a1e0`
- Pinned Go `src/os/tempfile.go`: 4,002 bytes, SHA-256 `a337c2a6dc2e4368b2dc0015ea7c0b935b68b14885a0771a6cbe27e588c2cd16`

The generated directory grammar is a two-byte prefix (`t.` or `s.`) plus a decimal `uint32`, whose maximum is 10 bytes. With `identity.sock` at 13 bytes:

```text
59-byte <SHORT_ROOT>/r-or-t
+ 1 separator
+ 12-byte maximum generated component
+ 1 separator
+ 13-byte socket leaf
= 86 bytes
```

Both relevant maximum complete paths are therefore 86 bytes, satisfying `86 <= 100`.

The blocker is separate: `filepath.Rel(<SHORT_ROOT>/r, <SHORT_ROOT>/t)` is `../t`. Exact B’s `within(control, tmp)` predicate rejects it in `AllocateControlDir`, `AllocateShortDir`, and `PhysicalTMPDir`.

## 8. Long-root negative causal

Long root: `/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf/private-long-validation-control-root-b3x9hwfi`, 130 bytes.

Both `ES_REPAIR10_CONTROL_ROOT` and `TMPDIR` were this long root; source, home, and caches remained in the private short root.

- `TestRepair10ControlRootPolicyV1`: exit 1, exact terminal `fail`; required `socket path exceeds 100 bytes` fragment present.
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`: exit 1, exact terminal `fail`; required `bind: invalid argument` fragment present.
- No skips or malformed JSON events.
- All raw streams were complete.
- Stdout identities:
  - Control-root: 1,581 bytes, SHA-256 `5107e9d381dd70ef8eb559283bb8cbb689df0a19f2080e958acd0738a2a8aa8a`
  - Runtime-helper: 1,835 bytes, SHA-256 `8bf145354293affd73831a99fc167d6b1e875a14504dcf50b6f07b5be07bba10`
- Both stderr streams were empty.
- The long root was removed.

## 9. Short-root positive causal

Using the prescribed sibling bindings:

```text
ES_REPAIR10_CONTROL_ROOT=/Users/ds/Downloads/r10b-e439822d67ed90213cf83702327682df/r
TMPDIR=/Users/ds/Downloads/r10b-e439822d67ed90213cf83702327682df/t
```

Results:

- `TestRepair10ControlRootPolicyV1`: exit 1, exact terminal `fail`, with `is outside control root`.
- `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT`: exit 1, exact terminal `fail`, with `is outside control root`.
- No skip and no malformed event.
- Stdout identities:
  - Control-root: 1,701 bytes, SHA-256 `e9bfdef55f87ccd65379eebec56a3f23228a37fb081bcc995efd3b6c9bf30502`
  - Runtime-helper: 1,820 bytes, SHA-256 `e995960c346659880e15f18f0f177b91550d6cff377a390a81c655b2b3745c53`
- Both stderr streams were empty.
- B remained exactly 389 files, tree/T `8de797304ea944b6a155924e0d1e9e8bbe79534e`, and inventory SHA-256 `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`.

The required positive causal therefore failed.

## 10. Boundary causal

Not executed after the mandatory short-positive stop condition.

Static source adjudication establishes that the exact predicate admits a complete path of exactly 100 bytes and rejects a path over 100 bytes. No empirical 100/101 execution result is claimed.

## 11. Validation-plan v1→v2 supersession

Base plan:

- Size: 28,615 bytes
- SHA-256: `b8627359a3df382d8a9d9bb40b03c3e864f632304581bb614557ab36a74fa8ad`

Proposed v2 plan:

- [validation-plan-v2.json](/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf/contract/validation-plan-v2.json)
- Size: 28,443 bytes
- SHA-256: `177ea4e983a3d3eae5b23302bf5ae7ac7cf1aedaa7335027607f3e4e5ad65ea4`
- Eight command IDs, ordering, expectations, pinned tools, B tree, and synthetic commit preserved
- All execution paths parameterized by `${SHORT_ROOT}`
- No producer-random transient pathname remains
- Status: `blocked_unusable`
- Effective supersession: not claimed

The base snapshot remains the sole source/provenance authority.

## 12. Proof B remained unchanged

The private exact-B materialization independently produced:

- 389 governed files
- Source T/tree: `8de797304ea944b6a155924e0d1e9e8bbe79534e`
- Inventory: 54,314 bytes
- Inventory SHA-256: `64b2f9fcf02f664cc0ee0abc5ccb875ebb5048a45658a45dc10fa9a3512465c2`
- Synthetic commit: `e42aac659299e023df07a842df17e9fc84a135c1`
- Clean private Git state
- No candidate or supplied-root inode aliases

The same identities remained after the causal executions. No B byte, logical mode, H→B classification, tree, inventory, or synthetic identity changed.

## 13. Exact eight-command plan, environment, and results

Exact common environment:

```text
PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
HOME=${SHORT_ROOT}/h
TMPDIR=${SHORT_ROOT}/t
GOTMPDIR=${SHORT_ROOT}/u
GOCACHE=${SHORT_ROOT}/c
GOMODCACHE=${SHORT_ROOT}/m
ES_REPAIR10_SOURCE_ROOT=${SHORT_ROOT}/s
ES_REPAIR10_CONTROL_ROOT=${SHORT_ROOT}/r
GOROOT=/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64
GOENV=off
GOFLAGS=-mod=readonly
GOPROXY=off
GOSUMDB=off
GOTELEMETRY=off
GOTOOLCHAIN=local
GOWORK=off
GIT_CONFIG_NOSYSTEM=1
GIT_OPTIONAL_LOCKS=0
LC_ALL=C
LANG=C
PYTHONDONTWRITEBYTECODE=1
```

All commands have `cwd=${SHORT_ROOT}/s`.

1. `go-version`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go version
```

2. `complete-docs-105`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw . -run '^(TestDocsRemoteAlphaOperatorFacadeBoundaries|TestDocsRemoteAlphaOperatorP0cFirstDelegationBoundary|TestGo1265ToolchainBaselineDocsAndBuildContract|TestGoldenProducerProofPathIsDocumented|TestHybridIntegrationArchitectureADRDocsContract|TestHybridIntegrationBridgeCodexRowPinsEvidenceBoundary|TestMilestone1BoundaryPostureMatrixIsDocumented|TestMilestone1LeastPrivilegeBoundaryCloseoutIsDocumented|TestPrimaryMilestoneRealignmentPreservesESOwnership|TestProducerFailurePathDistinctionsAreDocumented|TestReliableSubmitContractAdapterFoundationDocsAndSourceContract|TestReliableSubmitPersistenceAndConcurrencyADRDocsContract|TestReliableSubmitPublicOptInAndVersioningDocsContract|TestReliableSubmitPureModelDocsAndSourceContract|TestRemoteAlphaExternalTLSIncidentCompatibilityAndMigration|TestRemoteAlphaExternalTLSLifecycleCurrentAndTargetContract|TestRemoteAlphaExternalTLSLifecycleHasExactPolicyCoreConsumer|TestRemoteAlphaExternalTLSLifecyclePlanningAndBoundaryAlignment|TestRemoteAlphaExternalTLSLifecycleRejectsTargetWidening|TestRemoteAlphaExternalTLSLifecycleSecurityAndOwnership|TestRemoteAlphaExternalTLSPolicyCoreDocumentationContract|TestRemoteAlphaExternalTLSRestorationAndChat00054Boundary|TestRemoteAlphaExternalTLSStatusObservationV1Contract|TestRemoteAlphaExternalTLSStatusT2APackageAndFacadeContract|TestRemoteAlphaExternalTLST2APCurrentTargetMatrixV1|TestRemoteAlphaExternalTLST2APRepair10Contract|TestRemoteAlphaExternalTLST2APRepair5LifecycleOrderV1|TestRemoteAlphaExternalTLST2APRepair7Contract|TestRemoteAlphaExternalTLST2APRepair8Contract|TestRemoteAlphaExternalTLST2APRepair9Contract|TestRemoteAlphaMaintenanceMonitorBoundaryAndRouteMatrix|TestRemoteAlphaOperatorDocsInvolvementAndP0dEvidenceBoundaries|TestRemoteAlphaOperatorHealthcheckTLSCompanionDocsCurrentAndTargetSeparation|TestRemoteAlphaOperatorP0dDocsFirstDelegationBoundary|TestRemoteAlphaOperatorP0fDocsReadinessSessionBoundary|TestRemoteAlphaOperatorP0gDocsRecoverySessionBoundary|TestRemoteAlphaOperatorP0hDocsSchemaAwareRecoveryEvidenceBoundary|TestRemoteAlphaOperatorP0iDocsHostLocalUnsealBoundary|TestRemoteAlphaOperatorP0jDocsMacSideUnsealBoundary|TestRemoteAlphaOperatorP0kDocsMacSideResetDryRunBoundary|TestRemoteAlphaOperatorP0lDocsMacSideResetExecuteContractPrep|TestRemoteAlphaOperatorP0mDocsMacSideResetExecuteImplementationBoundary|TestRemoteAlphaOperatorP0nDocsMacSideWorkloadAuthCheckBoundary|TestRemoteAlphaOperatorP0oDocsVaultWorkloadAuthBootstrapPlanningBoundary|TestRemoteAlphaOperatorP0pDocsVaultWorkloadAuthBootstrapExecutionContractPrep|TestRemoteAlphaOperatorP0qDocsVaultWorkloadAuthBootstrapExecutionRoute|TestRemoteAlphaOperatorP0rDocsRuntimeIdentitySummaryRoute|TestRemoteAlphaOperatorP0sDocsESServiceTLSRenewRoute|TestRemoteAlphaOperatorP0tDocsESGovernanceTLSRenewRoute|TestRemoteAlphaOperatorP0uDocsOperatorHealthcheckTLSRenewRoute|TestRemoteAlphaOperatorP0vCompanionDocsCurrentStatusAlignment|TestRemoteAlphaOperatorP0vDocsOperatorHealthcheckTLSNoninteractiveStatusDesign|TestRemoteSupportedHostAlphaAGSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaARSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaDirectBoundaryIsDocumented|TestRemoteSupportedHostAlphaDoctorVocabularyIsDocumented|TestRemoteSupportedHostAlphaEGSServiceHardeningSliceIsDocumented|TestRemoteSupportedHostAlphaESBinaryDeploymentOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESConfigTLSPrepOperatorStagingFlowIsDocumented|TestRemoteSupportedHostAlphaESConfigTLSPrepSliceIsDocumented|TestRemoteSupportedHostAlphaESServiceUserMigrationOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESServiceUserRollbackRehearsalIsDocumented|TestRemoteSupportedHostAlphaESWritableStateOwnershipOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaESWritableStateReadinessOperatorFlowIsDocumented|TestRemoteSupportedHostAlphaNormalShellRuntimeImageSummarySchemaIsDocumented|TestRemoteSupportedHostAlphaRuntimeSecurityBoundaryCheckerIsDocumented|TestRemoteSupportedHostAlphaSupportBundleSummarySectionsAreDocumented|TestRemoteSupportedHostAlphaVaultServiceUserMigrationSurfaceIsDocumented|TestRemoteSupportedHostAlphaVaultWorkloadAuthSummarySchemaIsDocumented|TestSubmitIdempotencyCorrelationAndRecoveryDocsContract|TestSupportedLocalCPConsumerRunbookPreservesControlPlaneBoundaries|TestSystemOverviewAuthorityHeadersFollowRepoHierarchy|TestWorkstreamASharedKernelDecisionIsDocumented|TestWorkstreamB0ArtifactBoundaryGateIsDocumented|TestWorkstreamB1ArtifactBoundaryGuardrailPostureIsDocumented|TestWorkstreamBArtifactCompatibilityEdgesStayConsistent|TestWorkstreamBArtifactPublicationStorageDecisionIsDocumented|TestWorkstreamC0BoundarySurfaceAssertionsAreDocumented|TestWorkstreamC0ExecutionOwnershipGateIsDocumented|TestWorkstreamC0ExternalAuthorityAndEvidenceNonOwnershipIsDocumented|TestWorkstreamC1PrepareAdmissionGuardrailPostureIsDocumented|TestWorkstreamC2SubmitLifecycleProjectionGuardrailPostureIsDocumented|TestWorkstreamC3RetainedResultAuthorityHandoffGuardrailPostureIsDocumented|TestWorkstreamC4RuntimeIdentityVaultHandoffGuardrailPostureIsDocumented|TestWorkstreamC5StatusLogsResultCancelCompatibilityGuardrailPostureIsDocumented|TestWorkstreamC6AdmissionPolicyLayerV0ContractIsDocumented|TestWorkstreamC6AdmissionPolicyNonClaimsAreDocumented|TestWorkstreamC6ConfigurableAdmissionPolicyInputsAreDocumented|TestWorkstreamC7CheckpointDocsContract|TestWorkstreamCESExecutionAdmissionModelDecisionIsDocumented|TestWorkstreamCLifecycleProjectionAuthorityLabelsAreDocumented|TestWorkstreamCProducerContractPrepareBoundaryTestsAreDocumented|TestWorkstreamCResultSurfaceClassificationStaysConsistent|TestWorkstreamCRetainedResultBundleClarificationIsDocumented|TestWorkstreamCRuntimeProfileBoundaryStaysNarrow|TestWorkstreamCRuntimeProfileCompatibilityMatrixIsDocumented|TestWorkstreamD1bCGSV2AuthorizeContractDesignIsDocumented|TestWorkstreamD1cEGSVersionedRuntimeTrustWrapperDesignIsDocumented|TestWorkstreamD1dIDConfCompatibilityDowngradeIsDocumented|TestWorkstreamDPolicyAuthorizationBoundaryClarificationIsDocumented|TestWorkstreamDVersioningGuardrailBeforeSemanticExpansionIsDocumented|TestWorkstreamERuntimeConfigOwnershipDecisionIsDocumented|TestWorkstreamERuntimeConfigOwnershipKeepsESCGSOutOfESInternal|TestWorkstreamFRuntimeIdentityHandoffOwnershipDecisionIsDocumented|TestWorkstreamFRuntimeIdentityKeepsESCGSOutOfESInternal)$' -count=1 -p=1 -parallel=1 -json
```

3. `testsupport-acceptance`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./internal/testsupport -run '^(TestRepair10ControlRootPolicyV1|TestRepair10OwnedProcessLifecycleV1|TestRepair10SignalBirthMismatchNeverSignalsV1)$' -count=1 -p=1 -parallel=1 -json
```

4. `external-tls-all`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./es/externaltls/... -count=1 -p=1 -parallel=1 -json
```

5. `repair10-current-affected-pass`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw . -run '^(TestRemoteAlphaPrepareExternalTLSStatusDirectExecEnvironmentForwardingAndFailuresV3|TestRemoteAlphaPrepareExternalTLSStatusFreshBootstrapClosureV2|TestRemoteAlphaPrepareExternalTLSStatusParseSafeDirectStartupBoundary|TestRemoteAlphaPrepareExternalTLSStatusPreGoResiduePreservationAndNoShellCleanupV3|TestRemoteAlphaPrepareExternalTLSStatusWrapperExactGrammar|TestRemoteAlphaT2APRepair10CClosingConfigAndSourceSessionActualFlowV9|TestRemoteAlphaT2APRepair10ExactBlobSizeAndLongListingCausalV8|TestRemoteAlphaT2APRepair10ShellBoundedGitRunnerCausalV7|TestRemoteAlphaT2APRepair10ShellConfigLeafBracketCausalV7|TestRemoteAlphaT2APRepair10ShellPrivateReaderCausalV7|TestRemoteAlphaT2APRepair9SequentialSixCallerPrivateSlotNamespacesV6|TestRemoteAlphaT2APRepair9ShellObjectBoundaryTimestampDigestV6|TestRemoteAlphaT2APRepair9ShellPackedLooseDirectoryPrefixCaseFoldV6|TestRemoteAlphaT2APShellGitTopologyResolutionAndZeroObjectSentinelV5|TestRemoteAlphaT2APShellLexicalDirectoryGateV4|TestRemoteAlphaT2APShellRawRefGrammarConformanceV5|TestRemoteAlphaT2APShellSingleAlternateColonDecoyV5|TestRepair10IDualSetpgidRaceReconciliationV1|TestRepair10ISetpgidFailureRequiresExactGroupProofV1|TestRepair10ISetpgidInverseMutantsV1)$' -count=1 -p=1 -parallel=1 -json
```

6. `changed-nonroot-product-tests`

```text
/Users/ds/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.darwin-arm64/bin/go test -modcacherw ./es/admission ./es/admission/internal/reliablesubmit ./es/app ./es/runtimehelper -run '^(TestExecutionWorkspaceTempDirUsesControlRoot|TestMaterializeHelperPrivateSPIRESocketCreatesStableAliasForMountedSourceDir|TestNomadHarnessProcessCustodianFixtureV1|TestNomadHarnessProcessCustodianWithoutServiceV1|TestSQLiteClaimStoreTwoHandlesBusyTimeoutAndHelperProcessContention|TestValidateExecutionRuntimeInputsAcceptsRegularBinaryWithoutLiveSPIRESocketAccess|TestValidateExecutionRuntimeInputsRejectsNonAbsoluteSPIRESocketPath|TestValidateExecutionRuntimeInputsRejectsNonRegularBinary|TestWaitForHelperReadinessReturnsWhenEndpointServesJWT)$' -count=1 -p=1 -parallel=1 -json
```

7. `bash-syntax`

```text
/bin/bash -n scripts/remote_alpha_prepare_external_tls_status.sh scripts/remote_alpha_operator.sh
```

8. `private-git-diff-check`

```text
git -C '${SHORT_ROOT}/s' diff --check 567bceced5df95ecfe787cc66038d463a854e12c e42aac659299e023df07a842df17e9fc84a135c1 --
```

Results for all eight commands: `NOT_EXECUTED`. No exit, signal, stdout, stderr, or test outcome is claimed because the short-positive causal triggered the mandatory stop condition first.

The pinned Go binary did match SHA-256 `3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19`; its planned `go version` output was not re-observed.

## 14. Identity adjudication

Observed causal identities:

| Causal | Identity | Terminal | Classification |
|---|---|---:|---|
| Long | `TestRepair10ControlRootPolicyV1` | fail | Expected negative; 100-byte policy reproduced |
| Long | `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` | fail | Expected negative; bind rejection reproduced |
| Short | `TestRepair10ControlRootPolicyV1` | fail | Unexpected for required positive; sibling containment rejection |
| Short | `TestWaitForHelperReadinessReturnsWhenEndpointServesJWT` | fail | Unexpected for required positive; sibling containment rejection |

All four produced exactly one terminal identity, no skip, and no malformed JSON event.

The unexecuted eight-command policy remains unchanged:

- 105/105 documentation tests pass
- Three testsupport identities pass
- External TLS: exactly one allowed failure and four governed skips
- 20/20 current-affected tests pass
- Changed non-root: eight passes and one governed fixture skip
- Bash syntax and private diff exit zero with empty streams

No unobserved expected result is presented as a pass.

## 15. Failed and superseded attempts

- Attempt 1 completed both long commands, then hit an evidence-parser list-flattening defect. Its raw streams and allocation/cleanup records were retained; short root `r10b-415815f6266b87092b0da5c99b69af2c` was removed.
- Attempt 2 stopped before causal commands because the retained `causals/logs` directory already existed. Its allocation/cleanup record was retained; short root `r10b-ab7e592dbc5046df0ec683afcad85db4` was removed.
- The accepted causal attempt used `r10b-e439822d67ed90213cf83702327682df`.
- The first cleanup check observed only non-task-owned macOS Spotlight `mdworker` read descriptors. They were not signaled or modified; cleanup resumed after they closed.
- Closure review found and removed one old producer-random path from the proposed plan’s descriptive exact-source field, rebinding its hash without touching any supplied root.

## 16. Capsule authority and nonauthority

The capsule claims only:

- The transient-root allocation contract
- The exact-source path-budget analysis
- The proposed custody/environment change
- The observed long and short causal results
- The blocked supersession record

It does not claim new B source/tree authority, publication, current-repository truth, deployment readiness, A6 readiness, semantic-successor implementation, orchestrator implementation, hostile/shared-host support, or symlink/mount authority.

## 17. Artifact and sensitive-material findings

- No release, deployable, or governed product artifact was created.
- No credential, private key, token, or other sensitive material was observed or retained.
- No product or live service was invoked.
- No network or installation operation occurred.
- The 80 copied module objects and exact-B private Git materialization existed only under transient custody and were removed.
- The retained content is audit evidence and reproducibility source, not B source authority.

## 18. Cleanup and ENOENT observations

Successful root `/Users/ds/Downloads/r10b-e439822d67ed90213cf83702327682df` was removed.

Two fresh `lstat` observations returned `ENOENT`/errno 2:

- `1789865126822301000` ns
- `1789865126875203000` ns

Final process and descriptor survivor sets were empty. All three task-owned `r10b-*` roots and both known task-owned long roots are absent.

## 19. Closing equality

- Candidate opening equals closing: true
- Strategic snapshot opening equals closing: true
- Blocking audit opening equals closing: true
- Pinned Go and every named module-cache seed object opening equals closing: true
- Candidate index remained unchanged
- No supplied-root drift or provenance mismatch was found

## 20. Retained membership and manifests

Complete retained membership, grouped by directory:

```text
opening/
  blocking-audit-binding.json
  blocking-audit-full-inventory.jsonl
  candidate-and-supplied-root-identities.json
  correction-root-identity.json
  other-named-provenance-identities.json
  strategic-snapshot-binding.json
  strategic-snapshot-full-inventory.jsonl

contract/
  path-budget-v1.json
  short-root-allocation-v1.json
  strategic-b-validation-custody-v1.json
  validation-plan-supersession-v1.json
  validation-plan-v2.json

causals/
  long-root-expected-negative.json
  path-budget-boundary.json
  short-root-positive.json
causals/logs/
  long-control-root.stderr
  long-control-root.stdout
  long-runtimehelper.stderr
  long-runtimehelper.stdout
  short-control-root.stderr
  short-control-root.stdout
  short-runtimehelper.stderr
  short-runtimehelper.stdout

validation/
  cleanup-retry-record-v1.json
  eight-command-records-not-executed-v2.json
  failed-and-superseded-attempt-index-v1.json
  identity-level-result-summary-v2.json
  postclosure-plan-parameterization-correction-v1.json
  validation-summary-v2.json
validation/superseded-harness-attempt-2/
  short-root-allocation-v1.json
  superseded-attempt-record-v1.json
validation/superseded-parser-attempt-1/
  long-control-root.stderr
  long-control-root.stdout
  long-runtimehelper.stderr
  long-runtimehelper.stdout
  short-root-allocation-v1.json
  superseded-attempt-record-v1.json

provenance/
  B-source-inventory.txt
  allocator.py
  build_capsule.py
  cleanup.py
  exact-B-materialization.json
  exact_b_materializer.py
  finalize_capsule.py
  module-cache-seed.json
  path_budget_checker.py
  reclose_capsule.py
  recover_failed_attempt.py
  recover_failed_attempt_2.py
  source-hashes.json
  validation_runner.py

closeout/
  absence-observation-1-v1.json
  absence-observation-2-v1.json
  artifact-and-sensitive-material-findings-v1.json
  blocking-audit-closing-inventory.jsonl
  cleanup-v1.json
  closing-equality-v1.json
  final-evidence-inventory-v1.json
  final-implementation-report-v1.md
  strategic-snapshot-closing-inventory.jsonl

manifest/
  canonical-manifest-a-v1.json
  canonical-manifest-b-v1.json
```

Manifest closure:

- 11 directories including root
- 60 represented nonmanifest files
- 71 represented entries
- Only the two manifests self-excluded
- No empty, symlink, special, or multiply linked object
- All directories `0700`
- All files regular, single-link, `0600`
- Independent manifests byte-identical
- Each manifest: 17,363 bytes
- SHA-256: `73bafd4bf6eeaa7a2511af1a7ac01106ed0d32ab4d719c0dcbab1674985eb498`

Final inventory: [final-evidence-inventory-v1.json](/Users/ds/Downloads/ES-repair10i-t2ap-strategic-b-validation-custody-repair-ivliq7wf/closeout/final-evidence-inventory-v1.json), 16,030 bytes, SHA-256 `42d0bd7607af442a4dd943c88175f7e2ef8baff739f72d7b01cccb637e73d3e0`.

## 21. Remaining uncertainty

There is no remaining uncertainty about the immediate blocker: exact B and the frozen external contract are structurally incompatible.

Resolving it requires a governed choice outside this task—either nest TMPDIR under the control root or revise exact B’s containment rule. The requested task forbids both. Consequently, the boundary causal and complete eight-command validation remain unexecuted, and the proposed v2 plan cannot become effective authority.

## 22. Explicit confirmations

```text
CANDIDATE_REPOSITORY_MUTATION_NOT_PERFORMED
CANDIDATE_INDEX_MUTATION_NOT_PERFORMED
STRATEGIC_B_SNAPSHOT_MUTATION_NOT_PERFORMED
BLOCKING_AUDIT_MUTATION_NOT_PERFORMED
OTHER_SUPPLIED_EVIDENCE_NOT_MUTATED
B_SOURCE_BYTES_NOT_MODIFIED
B_LOGICAL_MODES_NOT_MODIFIED
B_SOURCE_T_NOT_MODIFIED
B_GIT_TREE_NOT_MODIFIED
VALIDATION_COMMAND_SET_NOT_REDUCED
SHORT_TRANSIENT_ROOT_ALLOCATED
SHORT_TRANSIENT_ROOT_REMOVED
TWO_ABSENCE_OBSERVATIONS_COMPLETED
PRODUCT_OR_LIVE_SERVICE_NOT_INVOKED
NETWORK_CONTACT_NOT_PERFORMED
A6_NOT_STARTED
SEMANTIC_SUCCESSOR_NOT_IMPLEMENTED
ORCHESTRATOR_NOT_IMPLEMENTED
INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED_IN_CANDIDATE
COMMIT_NOT_PERFORMED_IN_CANDIDATE
```
