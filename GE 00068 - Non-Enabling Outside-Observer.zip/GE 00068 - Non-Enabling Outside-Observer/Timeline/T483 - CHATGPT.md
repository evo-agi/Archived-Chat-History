## Engineering assessment

This was a **near-complete harness qualification**, stopped by one real acceptance-evidence contradiction:

- The frozen source record asserted `matrix_case_count = 645`.
- The authenticated suite contained 15 matrices totaling **595** cases.
- The qualification evidence also reported 595.
- The per-matrix counts sum exactly to 595.
- The independent validator and frozen-PYZ requalification failed to recompute and reconcile that aggregate. :chatgpt-content-reference{index="0"} :chatgpt-content-reference{index="1"}

The substantive implementation work was otherwise strong:

- The bundle and authority file authenticated.
- All eight bundle roles resolved.
- All 20 sources compiled and passed static analysis.
- B00 and D01–D14 all passed.
- The suite’s exact total is 595: `70 + 30 + 25 + 30 + 30 + 35 + 100 + 30 + 40 + 40 + 30 + 50 + 35 + 25 + 25`.
- Process custody passed.
- Synthetic ACCEPT, BLOCK, provenance-failure, and subject-pair lanes passed.
- Bounded compatibility replay passed without issuing a verdict.
- Both rehearsals passed and produced byte-identical provisional PYZ files.
- PYZ Build A and B were byte-identical.
- The source was frozen and remained unchanged. :chatgpt-content-reference{index="2"} :chatgpt-content-reference{index="3"} :chatgpt-content-reference{index="4"} :chatgpt-content-reference{index="5"}

This is **not**:

- an input-bundle provenance failure;
- a Generation-2 implementation-package defect;
- a failure of the audit semantics;
- a reason to reopen the content-snapshot authority work.

It is a harness-side **aggregate evidence-authority defect**. The frozen summary had an independently written, incorrect total, and the validators checked identity linkage without recomputing semantic agreement from the 15 matrix results. :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

### Progression decision

Use the **third and final permitted source attempt** for one bounded repair:

1. establish a single authoritative writer for all acceptance-bearing aggregates;
2. derive the matrix total exclusively from the exact 15 matrix-result rows;
3. remove the independent `645` writer;
4. independently recompute every acceptance-bearing count across freeze, qualification, package authority, confirmations, report, PYZ member registry, and requalification;
5. rerun the complete qualification and packaging sequence;
6. do not run the real audit.

Two attempts have been consumed and one remains. If Attempt 3 fails, retire this harness implementation generation. Do not issue another localized repair. :chatgpt-content-reference{index="8"}

One practical risk remains: the report gives exact source identities but does not itself prove that an authoritative copy of the Attempt-2 source bytes survived cleanup. The final attempt must first establish those exact bytes through retained evidence. If they are unavailable, Attempt 3 must be cleanly reauthored from the frozen contracts and registries—not reconstructed from hashes, transcript prose, or the deleted PYZ.

## Replacement Codex prompt

```text
FINAL SOURCE ATTEMPT 3 — AGGREGATE-EVIDENCE AUTHORITY REPAIR,
FULL REQUALIFICATION, DETERMINISTIC PYZ PACKAGING

Objective

Complete the third and final permitted clean-source attempt for the Generation-2
source-external independent-audit harness.

Repair the exact aggregate-evidence defect that caused the prior package to be
rejected:

- the frozen source record asserted `matrix_case_count = 645`;
- the exact 15-matrix suite contained 595 cases;
- qualification evidence contained 595;
- the sum of the exact matrix rows is 595;
- independent validation and frozen-PYZ requalification failed to detect the
  cross-document contradiction.

The repair must establish one authoritative derivation model for every
acceptance-bearing aggregate and must independently recompute those aggregates
from their owning rows.

Then rerun the complete qualification, freeze, deterministic PYZ build,
authority generation, and frozen-PYZ requalification.

Do not execute the real full independent audit.

Do not adjudicate the Generation-2 implementation package.

Do not execute implementation production source.

Do not construct the current schema subject.

Do not modify the current-authority bundle or its authority JSON.

Do not reopen any original contaminated package directory.

Do not perform another historical findings reconciliation.

Do not create subagents or direct auditors.
Do not use Git or another VCS.
Do not read `.git` metadata.
Do not use the network.
Do not install dependencies.
Do not invoke product or live-service behavior.
Do not publish, deploy, externally commit, or start A6.

This is the final source attempt in this harness implementation generation.

Attempt budget:

- maximum complete source attempts:
  3;
- consumed:
  2;
- remaining:
  1;
- new Attempt 4:
  forbidden.

Return the complete operative report inline.

Return exactly one primary verdict:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

──────────────────────────────────────────────────────────────────────────────
1. CURRENT INPUT AUTHORITY
──────────────────────────────────────────────────────────────────────────────

CURRENT_AUTHORITY_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_AUTHORITY_JSON:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

Authenticate both exact files before source work.

The containing directory is nonauthoritative.

Do not open any original source-package directory or historical audit root.

Require exact opening/closing equality for the two input files.

──────────────────────────────────────────────────────────────────────────────
2. PRIOR BLOCKED HARNESS RESULT
──────────────────────────────────────────────────────────────────────────────

The preceding operative report established:

- verdict:
  GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED;
- source attempts consumed:
  2 / 3;
- final source:
  frozen and unmodified;
- full audit:
  not executed;
- implementation verdict:
  not issued;
- final PYZ and authority JSON:
  rejected, removed, and twice observed absent;
- input bundle and authority:
  closed equal;
- sole terminal blocker:
  frozen aggregate count 645 versus authenticated matrix total 595.

Expected exact matrix rows:

- B00:
  70
- D01:
  30
- D02:
  25
- D03:
  30
- D04:
  30
- D05:
  35
- D06:
  100
- D07:
  30
- D08:
  40
- D09:
  40
- D10:
  30
- D11:
  50
- D12:
  35
- D13:
  25
- D14:
  25

Required exact derived values:

- matrix_count:
  15
- matrix_case_count:
  595

The value 645 has no current authority.

Retain:

opening/prior-blocked-harness-disposition-v1.json

Classify the prior result as:

historical_noncurrent_aggregate_evidence_validation_failure

Bind:

- source semantics otherwise qualified:
  report-only, pending final Attempt-3 reproduction;
- previous final files:
  absent;
- previous package authority:
  false;
- same-root retry:
  forbidden;
- Attempt 3:
  final permitted attempt.

──────────────────────────────────────────────────────────────────────────────
3. ATTEMPT-2 SOURCE-BYTE AUTHORITY GATE
──────────────────────────────────────────────────────────────────────────────

Before choosing an Attempt-3 source strategy, determine whether the exact
Attempt-2 source bytes remain available through an authenticated retained source
capsule or source-member registry.

Required prior production identities:

Production registry:

- size:
  2160
- SHA-256:
  22321e97c4abb4bc4c1b8564df055d92a5dd938036cb20b10c066d244a7fc66b

Production files:

- `__main__.py`
  - size: 1518
  - SHA-256:
    374f78ea58e710cc076378e5e6b988f6cac4f0dcc5226e4cc482d6db6f3236de

- `harness/__init__.py`
  - size: 97
  - SHA-256:
    65be7ab6a4d1315fb466683af3817b1c291d0df40c6bc1eb0e11b1307c69d5ef

- `harness/adapters.py`
  - size: 18281
  - SHA-256:
    bfa2d084ea7fc0dc328255175352098661af50f0529c2616d81cc1a74ac5e622

- `harness/audit.py`
  - size: 15353
  - SHA-256:
    f7b8d4f5f7438ac8c002c96fe1b279a22337b45233e67ce397b882c84a3c022d

- `harness/bundle.py`
  - size: 17649
  - SHA-256:
    0c973db8ef7bd2d1c9e1c143ee4f75e1eac8d48447ba462573d3d5b859d8b8a3

- `harness/confirmations.py`
  - size: 6946
  - SHA-256:
    9fe221dc20db841a49cb0b73196b1d0f8c397b2609b5a047a9faab17f38dd9bc

- `harness/constants.py`
  - size: 4462
  - SHA-256:
    e30a5a6603f2643113c4a37d5ad5646fe450fe5581fdd7ffd5bad33aa76e780d

- `harness/custody.py`
  - size: 13140
  - SHA-256:
    31efe73ea2769e08cf6c52b100ccfd0751c2aa1b2a9fad70c4aafcb93e3ad64b

- `harness/findings.py`
  - size: 6774
  - SHA-256:
    cc77c3604266013fad49bc5db3c55db87b35456ae0234c2ecdc928bbc571a6fc

- `harness/lifecycle.py`
  - size: 5466
  - SHA-256:
    5d0a0119dbcb15a208bb3b98e78841ef77021acaa99180deeb34ad3efa401c5a

- `harness/reporting.py`
  - size: 3587
  - SHA-256:
    2807b8a22f22ba268391903949db12fd5d626076e4da7db783f92f21e6f5f549

- `harness/strictio.py`
  - size: 7003
  - SHA-256:
    aca03c8c23f8625a574a0467dd4f42a2cf8c0b26a4b9b477cc10d2fb99b3c7f0

Required qualification identities:

Qualification registry:

- size:
  1143
- SHA-256:
  a614ae8f23d93f3895e2b4c58207b9250c3e2b4cf6a8c7fb0f42d9fd6e7a1e66

- `qualification/__init__.py`
  - size: 111
  - SHA-256:
    ce3cd84db3408a4fa20aee3ddbdea1dcf9ce392108efaf3ed5c320457e29f04e

- `qualification/compatibility.py`
  - size: 27535
  - SHA-256:
    29efd0d96e91ade808ac38e6c3a9eea0f7883a464bf6f645d9057dda6d4171d5

- `qualification/driver.py`
  - size: 19785
  - SHA-256:
    4a848bd53b08e2a93c0e39f89d7f98a4f16e6965dbf356ea4fa5414d0bc3586d

- `qualification/matrices.py`
  - size: 29110
  - SHA-256:
    dd69f4251d38d10ae8b4f14e30c3061417e46ddcb6be58b9ce0a0d6694bf7abb

- `qualification/synthetic.py`
  - size: 17942
  - SHA-256:
    cb82d275f96d800739abc0a907ab3f5e65776a48afe52c34ca20d66934d09517

Required independent identities:

Independent registry:

- size:
  928
- SHA-256:
  cd8cfac11c189065f70a073381a7e84c05b81567cfcaad83e88e027f22fea10a

- `independent/__init__.py`
  - size: 116
  - SHA-256:
    bddf13350f9b48643a5e65742e01b6e39fbb3773e4289fc837d7312c5858fed0

- `independent/evidence_validator.py`
  - size: 13243
  - SHA-256:
    77e3cbf16d618791f3773be3047135ee5e8946f9328242edd3113c7d51204020

- `independent/package_validator.py`
  - size: 8324
  - SHA-256:
    542a3b3b09d8744a8039cea62df903a602410a708164e5a2f9ecfea48cf9de77

Permitted source strategies:

A. EXACT_ATTEMPT_2_BYTE_REPAIR

Use only if every exact Attempt-2 source byte is available through one
authenticated retained source authority.

No selection by basename, size, hash scan, recency, or similarity.

B. CLEAN_ATTEMPT_3_REAUTHOR

Use when an exact source-byte authority does not exist.

Author source anew from the frozen contracts, registries, matrices, report
contract, confirmation contract, phase plan, and current bundle.

Do not reconstruct source from hashes, transcript prose, disassembly, or deleted
PYZ members.

Retain:

opening/attempt-3-source-strategy-v1.json

The source strategy decision itself does not consume Attempt 3.

──────────────────────────────────────────────────────────────────────────────
4. FRESH BUILD AND OUTPUT ROOTS
──────────────────────────────────────────────────────────────────────────────

Allocate a fresh private build root beneath `/private/tmp` using:

- `tempfile.mkdtemp`;
- umask `077`;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-attempt-3-

Immediately emit:

HARNESS_BUILD_ROOT=<absolute-path>

Allocate a separate output directory beneath `/Users/ds/Downloads` using:

- `tempfile.mkdtemp`;
- umask `077`;
- prefix:

ES-repair10i-v3-gen2-clean-independent-audit-harness-attempt-3-output-

Immediately emit:

HARNESS_OUTPUT_ROOT=<absolute-path>

The output directory is nonauthoritative.

Successful final authority-bearing files:

gen2-clean-source-external-independent-audit-harness-v1.pyz

gen2-clean-source-external-independent-audit-harness-v1.authority.json

Before source creation retain:

opening/bootstrap-start.json
opening/final-attempt-authority-v1.json
opening/input-file-registry-v1.json
opening/attempt-3-source-strategy-v1.json
opening/process-execution-policy-v1.json
opening/aggregate-evidence-authority-contract-v1.json

Bind:

- source attempt:
  3 / 3;
- no Attempt 4;
- same-root retry:
  false;
- input bundle and authority:
  read-only;
- implementation verdict:
  forbidden;
- real full audit:
  forbidden;
- implementation production execution:
  forbidden;
- current-subject construction:
  forbidden;
- product/runtime/target/repository/publication/deployment/A6:
  forbidden.

──────────────────────────────────────────────────────────────────────────────
5. AGGREGATE-EVIDENCE AUTHORITY CONTRACT
──────────────────────────────────────────────────────────────────────────────

Before source modification or authorship retain:

contract/aggregate-evidence-authority-v1.json

Define one authoritative derivation row for every acceptance-bearing aggregate.

At minimum include:

A. Matrix suite

Owner:

exact serialized matrix-result registry

Required exact matrix IDs and case counts:

- B00: 70
- D01: 30
- D02: 25
- D03: 30
- D04: 30
- D05: 35
- D06: 100
- D07: 30
- D08: 40
- D09: 40
- D10: 30
- D11: 50
- D12: 35
- D13: 25
- D14: 25

Derived:

- matrix_count = len(exact unique rows) = 15
- matrix_case_count = sum(row.case_count) = 595

Rules:

- no independent matrix-total writer;
- no hard-coded 645;
- no duplicate matrix row;
- no missing row;
- no extra row;
- no Boolean-as-integer;
- no string count;
- no negative count;
- no absence-as-zero;
- row ordering nonauthoritative after exact ID-set equality;
- every matrix result identity bound.

All downstream records must consume this exact derived result:

- source freeze;
- qualification result;
- independent-evidence result;
- package member registry when represented;
- authority JSON;
- frozen-PYZ requalification;
- report;
- explicit confirmations.

B. Report sections

Owner:

exact ordered report-section registry

Derived:

- report_section_count = len(section registry) = 66

No independent literal writer.

C. Confirmation names

Owner:

exact confirmation-name registry

Derived:

- confirmation_count = len(unique names) = 81

No verdict token in confirmations.

D. Source registries

Derived from exact registry rows:

- production source count;
- qualification source count;
- independent source count;
- total source count.

E. Architecture roles

Derived from exact role registry.

F. Cross-module interfaces

Derived from exact interface registry:

- interface_count = 21.

G. PYZ members

Derived from the final exact member registry.

H. Bundle inputs

Derived from the authenticated input bundle:

- role count:
  8;
- member count:
  479.

For every aggregate bind:

- owner record;
- row pointer;
- unique ID pointer;
- value pointer;
- derivation;
- consumers;
- independent recomputation method;
- failure reason;
- unknown-field rule;
- type rule.

A copied aggregate field is not authority unless the consumer independently
recomputes it from the owning rows.

──────────────────────────────────────────────────────────────────────────────
6. AGGREGATE ROOT-CAUSE ADJUDICATION
──────────────────────────────────────────────────────────────────────────────

Before changing source, identify the exact writer of 645.

Retain:

analysis/matrix-count-645-root-cause-v1.json

Determine whether 645 arose from:

- hard-coded literal;
- duplicated matrix family;
- duplicated D11 count;
- stale earlier specification;
- arithmetic error;
- copied summary field;
- another exact cause.

Retain:

- source file/function or generator;
- original expression;
- downstream consumers;
- why existing validators missed it;
- why 595 is authoritative;
- exact repair owner;
- semantic effect:
  none;
- package-verdict effect:
  none;
- matrix-case effect:
  none.

Do not simply replace one literal with another without removing the independent
aggregate writer.

──────────────────────────────────────────────────────────────────────────────
7. BOUNDED REPAIR SURFACE
──────────────────────────────────────────────────────────────────────────────

When using `EXACT_ATTEMPT_2_BYTE_REPAIR`, permitted changes are limited to:

- aggregate-count derivation;
- aggregate registry;
- source-freeze generation;
- qualification evidence generation;
- independent aggregate validation;
- authority-JSON generation;
- frozen-PYZ requalification;
- report projection of aggregate evidence;
- aggregate-specific matrices and causals.

Protected:

- bundle authentication;
- role resolution;
- audit authority;
- full-audit phase semantics;
- B00 and D01–D14 case definitions;
- all expected outcomes;
- process custody;
- synthetic verdict semantics;
- compatibility replay semantics;
- report section IDs and order;
- confirmation names;
- package verdict rules;
- findings ownership;
- cleanup;
- terminal lifecycle.

Every unrelated common function/class must remain AST-identical.

When using `CLEAN_ATTEMPT_3_REAUTHOR`, the same semantic protection applies,
but no source-text equality claim is made.

Retain:

analysis/attempt-3-repair-or-reauthor-surface-v1.json

──────────────────────────────────────────────────────────────────────────────
8. AGGREGATE-COHERENCE MATRIX
──────────────────────────────────────────────────────────────────────────────

Run at least 45 uniquely named cases.

Include:

- exact 15-row/595-case baseline;
- stale 645 summary;
- missing B00;
- missing D14;
- duplicate D11;
- extra matrix;
- wrong per-row count;
- correct total but wrong row;
- wrong total but correct rows;
- matrix_count 14;
- matrix_count 16;
- unordered valid rows;
- duplicate ID;
- missing ID;
- Boolean count;
- string count;
- float count;
- negative count;
- null count;
- missing count;
- absence interpreted as zero;
- freeze 595 / qualification 645;
- freeze 645 / suite 595;
- authority 645 / suite 595;
- requalification checks identity only;
- independent validator checks summary only;
- independent validator recomputes rows;
- report count mismatch;
- confirmation count mismatch;
- interface count mismatch;
- source count mismatch;
- PYZ member-count mismatch;
- bundle role-count mismatch;
- bundle member-count mismatch;
- stale aggregate copied through every consumer;
- exact all-consumer baseline.

Require:

- unique names;
- exact expected-name closure;
- zero false acceptance;
- zero false rejection;
- zero reason mismatch;
- zero skip;
- zero unexpected exception.

Retain:

validation/aggregate-evidence-coherence-matrix-v1.json

──────────────────────────────────────────────────────────────────────────────
9. INDEPENDENT AGGREGATE VALIDATOR
──────────────────────────────────────────────────────────────────────────────

Implement a source-external validator that imports neither:

- production harness modules;
- qualification helpers;
- aggregate generator;
- matrix generator;
- expected-result map;
- report projector;
- authority writer.

It must independently:

1. parse every matrix result;
2. enforce exact 15-ID closure;
3. recompute every row count;
4. recompute 595;
5. compare freeze, qualification, authority, report, confirmation, member, and
   requalification consumers;
6. recompute report-section count;
7. recompute confirmation count;
8. recompute source counts;
9. recompute interface count;
10. recompute final PYZ member count;
11. validate bundle role/member counts;
12. reject stale 645 anywhere acceptance-bearing;
13. reject copied-but-unrecomputed aggregate claims.

Require zero errors.

Retain:

validation/independent-aggregate-evidence-validator-v1.json

This validator must run:

- before source freeze;
- against frozen source evidence;
- against final PYZ and authority JSON;
- during frozen-PYZ requalification.

──────────────────────────────────────────────────────────────────────────────
10. PRECOMPILATION GATE
──────────────────────────────────────────────────────────────────────────────

Before final source registries close require:

- aggregate contract complete;
- root cause adjudicated;
- repair surface closed;
- exact matrix IDs and expected counts frozen;
- report registry unchanged;
- confirmation registry unchanged;
- phase plan unchanged;
- package verdict rules unchanged;
- every aggregate consumer registered;
- independent aggregate-validator source present;
- no historical source-origin violation;
- no Git/VCS mechanism.

Failure here does not consume Attempt 3.

──────────────────────────────────────────────────────────────────────────────
11. FINAL SOURCE ATTEMPT 3
──────────────────────────────────────────────────────────────────────────────

Attempt 3 begins only when:

- final production registry closes;
- final qualification registry closes;
- final independent registry closes;
- compilation begins.

Retain:

analysis/final-source-attempt-3-ledger-v1.json

Bind:

- strategy;
- predecessor source authority, when applicable;
- exact source identities;
- exact textual/AST delta, when applicable;
- changed functions;
- protected-function comparison;
- aggregate contracts;
- compilation;
- all validation reached;
- first blocker or null;
- terminal disposition.

No source change is permitted after compilation without failing this final
attempt.

There is no Attempt 4.

──────────────────────────────────────────────────────────────────────────────
12. COMPILATION AND STATIC QUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Compile all sources with pinned Python `-I -S -B`.

Require exit zero and empty stderr.

Rerun the full prior static qualification:

- AST;
- call graph;
- dataflow;
- bytecode;
- exception table;
- CFG;
- bundle member access;
- provider/consumer shapes;
- report sections;
- confirmation names;
- process launch;
- filesystem operations;
- terminal operations;
- forbidden executable/library/path checks.

Add aggregate crosswalk analysis:

- every acceptance-bearing count writer;
- every count consumer;
- every count derivation;
- no stale literal 645;
- no duplicate aggregate authority;
- every consumer independently recomputed or consumes a validated immutable
  aggregate result.

Require all prior prohibitions and no postseal operation.

──────────────────────────────────────────────────────────────────────────────
13. FULL QUALIFICATION RERUN
──────────────────────────────────────────────────────────────────────────────

Rerun all prior qualification exactly:

- B00:
  70 cases;
- D01:
  30;
- D02:
  25;
- D03:
  30;
- D04:
  30;
- D05:
  35;
- D06:
  100;
- D07:
  30;
- D08:
  40;
- D09:
  40;
- D10:
  30;
- D11:
  50;
- D12:
  35;
- D13:
  25;
- D14:
  25.

Require exact total:

595

Do not add aggregate-coherence cases to the B00/D01–D14 total.

The aggregate-coherence matrix is a separate validation family.

Also rerun:

- process-custody qualification;
- synthetic ACCEPT;
- synthetic BLOCK;
- synthetic provenance failure;
- synthetic subject pair;
- bounded real-bundle compatibility replay.

Require prior exact case names and expected outcomes.

──────────────────────────────────────────────────────────────────────────────
14. TWO COMPLETE HARNESS REHEARSALS
──────────────────────────────────────────────────────────────────────────────

Run two physically distinct complete rehearsals using identical Attempt-3
candidate bytes.

Each must complete:

- B00 and D01–D14;
- aggregate-coherence matrix;
- independent aggregate validator;
- process custody;
- all synthetic lanes;
- bounded compatibility replay;
- report generation;
- confirmation generation;
- audit-capsule closure;
- cleanup.

Retain complete evidence before cleanup.

Require provisional rehearsal PYZ files to be byte-identical.

Normalize only governed physical fields.

Require zero unexplained semantic difference.

Remove rehearsal roots and provisional packages only after evidence retention,
with double ENOENT observations.

──────────────────────────────────────────────────────────────────────────────
15. INDEPENDENT HARNESS VALIDATION
──────────────────────────────────────────────────────────────────────────────

Rerun the independent harness validators.

They must independently verify:

- clean-room or exact-byte repair provenance;
- input bundle/authority;
- source registries;
- phase plan;
- B00 and D01–D14;
- exact 595 total;
- aggregate-coherence matrix;
- all aggregate consumers;
- process custody;
- synthetic lanes;
- compatibility replay;
- rehearsals;
- normalized comparison;
- report sections;
- confirmations;
- evidence retention;
- cleanup;
- source-freeze candidate.

Summary pass Booleans are insufficient.

The validator must fail if any acceptance-bearing document contains 645.

Require zero errors.

──────────────────────────────────────────────────────────────────────────────
16. SOURCE FREEZE
──────────────────────────────────────────────────────────────────────────────

Freeze only after all gates above pass.

Retain:

opening/clean-independent-audit-harness-source-freeze-v2.json

The freeze must bind:

- final source registries;
- exact source identities;
- aggregate authority contract;
- exact 15 matrix IDs;
- exact per-matrix counts;
- derived total 595;
- aggregate-coherence matrix;
- independent aggregate validator;
- all prior matrices;
- process custody;
- synthetic lanes;
- compatibility replay;
- rehearsal identities;
- normalized comparison;
- independent harness validation;
- input identities;
- full real audit not executed;
- later source modification:
  forbidden.

Do not write an independent literal matrix total.

The freeze’s matrix total must be derived directly from the serialized exact
matrix rows.

Reopen every source no-follow.

Do not modify source afterward.

──────────────────────────────────────────────────────────────────────────────
17. DETERMINISTIC PYZ BUILDS
──────────────────────────────────────────────────────────────────────────────

Build final PYZ A and B independently from exact frozen bytes.

Final name:

gen2-clean-source-external-independent-audit-harness-v1.pyz

Required deterministic ZIP posture:

- `ZIP_STORED`;
- raw UTF-8 sorted member names;
- fixed 1980 timestamp;
- `create_system = 3`;
- fixed `0600` member permissions;
- no duplicate/unsafe/directory/symlink/special member;
- no comments;
- no uncontrolled extras;
- no cache or bytecode.

Require A/B byte equality.

The exact final member registry owns:

- member_count.

No separate literal member-count writer.

Retain:

validation/final-pyz-build-a-b-comparison-v1.json

──────────────────────────────────────────────────────────────────────────────
18. FINAL AUTHORITY JSON
──────────────────────────────────────────────────────────────────────────────

Create:

gen2-clean-source-external-independent-audit-harness-v1.authority.json

It must bind:

- exact PYZ path and identity;
- exact member registry and derived count;
- source registries;
- source freeze;
- aggregate authority;
- matrix suite identity;
- exact derived total 595;
- aggregate-coherence result;
- independent aggregate-validator result;
- prior qualification results;
- rehearsal identities;
- future invocation;
- current input bundle identity;
- current input authority identity;
- full audit executed:
  false;
- implementation verdict:
  not issued.

Before authority becomes current, independently recompute every aggregate from
its owning rows.

Any copied stale aggregate blocks authority.

──────────────────────────────────────────────────────────────────────────────
19. FROZEN-PYZ REQUALIFICATION
──────────────────────────────────────────────────────────────────────────────

Run exact final PYZ under pinned Python:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
<FINAL_PYZ>
--mode
qualify-harness
--bundle
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip
--bundle-authority
/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Require:

- exit zero;
- empty stderr;
- exact qualification terminal record;
- self-authentication;
- bundle authentication;
- frozen-source linkage;
- B00/D01–D14 identities;
- exact recomputed total 595;
- aggregate-coherence linkage;
- independent aggregate validation;
- process-custody linkage;
- synthetic-lane linkage;
- compatibility-replay linkage;
- rehearsal-source linkage;
- member closure;
- authority-JSON coherence;
- no run-full-audit execution;
- no implementation verdict.

The requalification must parse and recompute matrix counts from serialized
matrix rows. Identity linkage alone is insufficient.

Retain:

validation/frozen-pyz-requalification-v2.json

──────────────────────────────────────────────────────────────────────────────
20. FINAL PACKAGE TERMINAL GATE
──────────────────────────────────────────────────────────────────────────────

Before declaring success independently verify:

- no acceptance-bearing `645` exists in:
  - source freeze;
  - qualification results;
  - independent results;
  - report;
  - confirmations;
  - member registry;
  - authority JSON;
  - frozen requalification;
- exact matrix count:
  15;
- exact matrix case total:
  595;
- report section count:
  66;
- confirmation count:
  81;
- interface count:
  21;
- source counts match source registries;
- member count matches member registry;
- bundle role/member counts match current inputs.

Retain:

validation/final-cross-document-aggregate-reconciliation-v1.json

Require zero errors.

Only then:

- set final PYZ mode `0400`;
- set final authority JSON mode `0400`;
- reopen both no-follow;
- verify exact identities;
- retain final authority;
- prohibit later modification.

──────────────────────────────────────────────────────────────────────────────
21. INPUT-FILE CLOSING EQUALITY
──────────────────────────────────────────────────────────────────────────────

Repeat exact no-follow identity checks for:

- current authority bundle;
- current authority JSON.

Require exact opening/closing:

- device;
- inode;
- mode;
- link count;
- size;
- SHA-256.

Do not open original contaminated roots.

──────────────────────────────────────────────────────────────────────────────
22. CLEANUP
──────────────────────────────────────────────────────────────────────────────

Before removing build/rehearsal roots retain:

- root identity;
- complete inventory;
- process streams;
- all validation results;
- failure outcome where applicable.

Revalidate identity, remove the exact root, and observe ENOENT twice.

Require:

created roots
=
inventoried roots
=
evidence-retained roots
=
cleanup rows
=
twice absent

Do not remove successful final output files.

──────────────────────────────────────────────────────────────────────────────
23. FAILURE CLOSEOUT
──────────────────────────────────────────────────────────────────────────────

On failure retain:

- final Attempt-3 source posture;
- first blocker;
- structured exception;
- process ledger and streams;
- partial build inventory;
- indispensable evidence;
- cleanup;
- input closing equality;
- source-freeze posture;
- package posture;
- same-root retry false;
- harness implementation generation retired:
  true;
- further localized repair:
  false;
- new clean generation required:
  true.

Do not create authoritative final outputs on failure.

If provisional final files exist:

- retain identities;
- classify nonauthoritative;
- remove after evidence retention;
- observe ENOENT twice.

Return provenance mismatch for:

- input mismatch;
- source-provenance violation;
- Git/VCS use;
- unregistered effect;
- evidence loss;
- cleanup inequality;
- input closing inequality;
- source drift after freeze;
- final PYZ/authority mismatch;
- post-finalization modification.

──────────────────────────────────────────────────────────────────────────────
24. VERDICT RULES
──────────────────────────────────────────────────────────────────────────────

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

only when:

- Attempt-3 source authority closes;
- aggregate authority contract closes;
- 645 root cause is identified;
- one authoritative aggregate writer per fact is established;
- compilation/static gates pass;
- B00 and D01–D14 pass with exact total 595;
- aggregate-coherence matrix passes;
- process custody passes;
- synthetic lanes pass;
- compatibility replay passes without verdict;
- both rehearsals pass;
- rehearsal PYZs match;
- independent harness validators pass;
- independent aggregate validator passes;
- evidence retention and cleanup pass;
- source freezes;
- PYZ A/B match;
- authority JSON binds the PYZ;
- frozen-PYZ requalification recomputes 595;
- final cross-document aggregate reconciliation passes;
- input files close equal;
- final files are mode `0400`;
- full real audit remains unexecuted;
- no implementation verdict is issued.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_IMPLEMENTATION_BLOCKED

when:

- Attempt 3 cannot qualify;
- exact source authority cannot be established and clean reauthoring fails;
- aggregate authority remains ambiguous;
- a matrix, rehearsal, validator, or requalification fails without provenance
  failure;
- changing governing audit semantics would be required.

On this verdict:

- harness implementation generation retired:
  true;
- further localized repair:
  false;
- new clean implementation generation required:
  true.

Return:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PROVENANCE_MISMATCH

for the provenance failures in Section 23.

──────────────────────────────────────────────────────────────────────────────
25. REQUIRED INLINE REPORT
──────────────────────────────────────────────────────────────────────────────

Return the frozen exact ordered report-section registry.

At minimum include:

1. Primary verdict
2. Fresh Attempt-3 build-root identity
3. Fresh output-root identity
4. Input bundle identity
5. Input authority identity
6. Prior blocked harness disposition
7. Confirmation two attempts consumed and one remained
8. Attempt-2 source-byte authority gate
9. Attempt-3 source strategy
10. Aggregate-evidence authority contract
11. Matrix-count 645 root cause
12. Bounded repair or clean-reauthor surface
13. Source-attempt ledger
14. Final production registry
15. Final qualification registry
16. Final independent registry
17. Precompilation gate
18. Compilation/static gates
19. Exact 15-matrix registry
20. Exact per-matrix counts
21. Exact derived matrix total
22. Aggregate-coherence matrix
23. Independent aggregate validator
24. B00 result
25–38. D01–D14 results
39. Process custody
40. Synthetic ACCEPT
41. Synthetic BLOCK
42. Synthetic provenance failure
43. Synthetic subject pair
44. Bounded compatibility replay
45. Rehearsal A
46. Rehearsal B
47. Rehearsal PYZ equality
48. Rehearsal semantic comparison
49. Independent harness validation
50. Evidence retention
51. Cleanup
52. Source freeze
53. PYZ Build A
54. PYZ Build B
55. PYZ equality
56. PYZ member closure
57. Authority JSON identity
58. Frozen-PYZ requalification
59. Final cross-document aggregate reconciliation
60. Confirmation full audit not executed
61. Confirmation implementation verdict not issued
62. Harness-package status
63. Input-file closing equality
64. Failure-closeout capability/use
65. Final PYZ path/identity
66. Final authority path/identity
67. Remaining uncertainty/nonclaims
68. Explicit confirmation registry

The actual section count must be derived from the final frozen registry.

Freeze the exact confirmation-name registry before final source compilation.

Required confirmations include:

CURRENT_AUTHORITY_BUNDLE_IDENTITY_MATCHED
CURRENT_AUTHORITY_JSON_IDENTITY_MATCHED
PRIOR_BLOCKED_HARNESS_RESULT_AUTHENTICATED
TWO_SOURCE_ATTEMPTS_CONSUMED
EXACTLY_ONE_SOURCE_ATTEMPT_REMAINED
ATTEMPT_3_SOURCE_STRATEGY_FROZEN
SOURCE_ATTEMPT_LIMIT_RESPECTED
MATRIX_COUNT_645_ROOT_CAUSE_IDENTIFIED
MATRIX_COUNT_645_REJECTED_AS_NONAUTHORITATIVE
AGGREGATE_EVIDENCE_AUTHORITY_CONTRACT_FROZEN
ONE_AUTHORITATIVE_WRITER_PER_AGGREGATE
EXACT_FIFTEEN_MATRIX_IDS_CLOSED
EXACT_MATRIX_COUNT_FIFTEEN
EXACT_MATRIX_CASE_TOTAL_595
NO_STALE_MATRIX_TOTAL_645_ACCEPTED
REPORT_SECTION_COUNT_DERIVED
CONFIRMATION_COUNT_DERIVED
SOURCE_COUNTS_DERIVED
INTERFACE_COUNT_DERIVED
PYZ_MEMBER_COUNT_DERIVED
BUNDLE_COUNTS_RECOMPUTED
FINAL_SOURCE_REGISTRIES_COMPLETE
ALL_SOURCES_COMPILED
STATIC_SOURCE_GATES_PASSED
BUNDLE_AUTHORITY_MATRIX_PASSED
D01_D14_MATRICES_PASSED
AGGREGATE_COHERENCE_MATRIX_PASSED
INDEPENDENT_AGGREGATE_VALIDATOR_PASSED
PROCESS_CUSTODY_QUALIFICATION_PASSED
SYNTHETIC_ACCEPTED_PACKAGE_AUDIT_PASSED
SYNTHETIC_BLOCK_PACKAGE_AUDIT_PASSED
SYNTHETIC_PROVENANCE_FAILURE_AUDIT_PASSED
SYNTHETIC_CONSTRUCTED_SUBJECT_PAIR_PASSED
BOUNDED_COMPATIBILITY_REPLAY_PASSED
BOUNDED_COMPATIBILITY_REPLAY_EMITTED_NO_PACKAGE_VERDICT
COMPLETE_HARNESS_REHEARSAL_A_PASSED
COMPLETE_HARNESS_REHEARSAL_B_PASSED
TWO_HARNESS_REHEARSAL_PYZS_BYTE_IDENTICAL
TWO_HARNESS_REHEARSALS_NORMALIZED_EQUAL
INDEPENDENT_HARNESS_VALIDATORS_PASSED
EVIDENCE_RETAINED_BEFORE_CLEANUP
HARNESS_OWNED_CLEANUP_SET_EQUALITY_PASSED
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
NO_PROCESS_SURVIVOR
NO_DESCRIPTOR_SURVIVOR
NO_CACHE_OR_BYTECODE_RETAINED
HARNESS_SOURCE_FROZEN
HARNESS_SOURCE_NOT_MODIFIED_AFTER_FREEZE
PYZ_BUILD_A_CREATED
PYZ_BUILD_B_CREATED
PYZ_BUILD_A_B_BYTES_IDENTICAL
FINAL_PYZ_MEMBER_SET_CLOSED
FINAL_AUTHORITY_JSON_BINDS_PYZ
FROZEN_PYZ_REQUALIFICATION_PASSED
FINAL_CROSS_DOCUMENT_AGGREGATE_RECONCILIATION_PASSED
FULL_INDEPENDENT_AUDIT_NOT_EXECUTED
IMPLEMENTATION_PACKAGE_NOT_READJUDICATED
IMPLEMENTATION_PRODUCTION_SOURCE_NOT_EXECUTED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
INPUT_BUNDLE_CLOSING_EQUALITY_PASSED
INPUT_AUTHORITY_JSON_CLOSING_EQUALITY_PASSED
FINAL_PYZ_CREATED
FINAL_PYZ_MODE_0400
FINAL_PYZ_IDENTITY_VERIFIED
FINAL_AUTHORITY_JSON_CREATED
FINAL_AUTHORITY_JSON_MODE_0400
FINAL_AUTHORITY_JSON_IDENTITY_VERIFIED
CONTAINING_DIRECTORY_NOT_USED_AS_AUTHORITY
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED

After:

GEN2_CLEAN_SOURCE_EXTERNAL_INDEPENDENT_AUDIT_HARNESS_PYZ_IMPLEMENTED_QUALIFIED_FROZEN_READY_FOR_FRESH_AUDIT

the next tranche is exactly one fresh independent audit of the unchanged
Generation-2 implementation evidence in the current-authority bundle, using
the exact final harness PYZ and authority JSON.

Do not combine that audit with this final implementation attempt.

Do not construct the authoritative current schema subject until the later audit
accepts the implementation package.
```

### Sources

The report establishes that the only terminal blocker was the frozen `645` aggregate contradicting the exact 595-case matrix suite, while all fifteen matrices individually passed. :chatgpt-content-reference{index="9"} :chatgpt-content-reference{index="10"}

It also establishes that both rehearsals passed, their provisional PYZ files were byte-identical, all synthetic and compatibility lanes passed, and the source remained frozen and unchanged. :chatgpt-content-reference{index="11"} :chatgpt-content-reference{index="12"}

The independent validators and frozen-PYZ requalification were correctly rejected because they linked identities without recomputing semantic agreement between the matrix rows and the frozen aggregate. :chatgpt-content-reference{index="13"} :chatgpt-content-reference{index="14"}

No real audit or implementation verdict occurred; the rejected final files were removed, both input files closed equal, and one source attempt remains. :chatgpt-content-reference{index="15"}

**Confidence:** 0.999 that the implementation package remains unadjudicated; 0.999 that the correct matrix total is 595; 0.99 that the remaining repair is bounded to aggregate evidence authority and validation; 0.96 that a successful Attempt 3 should proceed directly to one fresh audit rather than another harness-repair tranche.

The current attachment was available. Some older project uploads have expired; re-upload them only if a later task needs their original bytes rather than the retained reports and identities.
