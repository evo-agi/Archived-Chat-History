## Engineering assessment

The external launch-authority seam is now closed without modifying the harness.

The final launch certificate is:

```text
/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-launch-certificate-v2-output-mchfmdqd/gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json
```

- device/inode: `16777234 / 182301064`
- mode/link count: `0400 / 1`
- size: `67,057`
- SHA-256: `eaee84d823cbea4ae88ccf0a7ed01429e2b451f5bac128190e760e4d4e528bb8` :chatgpt-content-reference{index="0"}

The certificate-generation tranche successfully closed every previously missing external predicate:

- all four fixed inputs authenticated through two stable no-follow reads;
- the schema-distinct governing identities were compared through an exact two-row projection registry rather than generic aliases;
- both documentary packages’ canonical identities matched;
- the projection matrix passed 50 cases and the independent projection validator reported zero errors;
- the 124-member PYZ was independently reconstructed twice, and both replay archives were byte-identical to each other **and to the original PYZ**;
- the exact qualification and real-audit stream contracts were frozen from current PYZ bytes;
- platform capture passed;
- `qualify-harness` ran exactly once with full custody and exited `0`;
- fresh qualification passed;
- the 29-fact post-package crosswalk passed;
- the independent source-external evidence validator reported zero errors;
- two independently generated certificate byte streams were identical;
- the final certificate is self-contained and has no build-root dependency. :chatgpt-content-reference{index="1"} :chatgpt-content-reference{index="2"}

No harness source was repaired, the PYZ was neither modified nor replaced, no real audit ran, no implementation verdict was issued, and the single audit authorization remains available. :chatgpt-content-reference{index="3"}

### Final authority split

The five-file launch boundary is now complete:

1. **PYZ v2** — executable package.
2. **Authority v3** — passed to the harness through `--harness-authority`.
3. **Launch certificate v1** — authenticated by the external wrapper; not passed to the harness.
4. **Current content bundle**.
5. **Current content authority JSON**.

The certificate contains the post-package evidence authority v3 lacked as a standalone wrapper authorization, while avoiding circular self-validation. The future wrapper validates the certificate’s exact pinned bytes and contents at launch time.

### Progression decision

Run **exactly one fresh independent audit now**.

No further qualification, certificate, authority, documentary, harness, or source tranche is justified before that audit.

The wrapper must use the terminal frame’s `audit_root` field as the sole locator. The frozen stream contract expressly has **no separate locator line**. :chatgpt-content-reference{index="4"}

The single audit authorization is consumed only when the `run-full-audit` process is successfully created. A prelaunch or platform-preflight failure leaves it unconsumed. After process creation, it is consumed regardless of the resulting verdict.

---

## Complete replacement Codex prompt

```text
EXECUTE EXACTLY ONE FRESH INDEPENDENT AUDIT OF THE SEALED
GENERATION-2 RECONSTRUCTION-PARENT IMPLEMENTATION EVIDENCE

USING PYZ V2, RUNTIME AUTHORITY V3, AND THE FINAL EXTERNAL
LAUNCH CERTIFICATE V1

Objective

Execute exactly one fresh independent audit using these five exact files:

1. unchanged harness PYZ v2;
2. unchanged runtime harness authority v3;
3. final external launch certificate v1;
4. current-authority content snapshot ZIP;
5. current content-snapshot authority JSON.

The external wrapper must authenticate the launch certificate.

The harness must receive authority v3 through `--harness-authority`.

The launch certificate must not be passed to the harness because the unchanged
CLI does not require it.

Capture the top-level audit-parent launch and completion exactly.

The frozen `run-full-audit` stream contract emits exactly one canonical
terminal-frame JSON object plus LF. Its `audit_root` field is the sole audit-root
locator.

There is no separate locator line.

After completion:

- use only that exact `audit_root` field;
- inspect the audit capsule read-only;
- authenticate terminal closure;
- report the exact final verdict;
- stop.

Do not modify, repair, resume, clean, remove, or rerun the audit capsule.

Do not execute `qualify-harness`.

Do not launch a replacement, recovery, continuation, or second audit parent.

Do not run a direct implementation auditor outside the frozen harness.

Do not execute implementation production source.

Do not construct the authoritative current schema subject.

Do not modify any repository.

Do not use Git or another VCS.

Do not read `.git`.

Do not use the network.

Do not invoke product or live-service behavior.

Do not run a target audit.

Do not rerun runtime validation.

Do not publish, deploy, externally commit, or begin A6.

Do not create subagents or direct auditors.

Return the complete operative report inline.

The exact primary verdict must be one of:

ACCEPT

BLOCK

AUDIT_PROVENANCE_MISMATCH

If the audit parent is not created because a fixed-input or platform-preflight
gate fails, return:

AUDIT_PROVENANCE_MISMATCH

and state:

FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED
FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED

──────────────────────────────────────────────────────────────────────────────
1. EXACT FIVE-FILE AUTHORITY BOUNDARY
──────────────────────────────────────────────────────────────────────────────

FINAL_HARNESS_PYZ_V2:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.pyz

Expected identity:

- device:
  16777234
- inode:
  182181777
- mode:
  0400
- link count:
  1
- size:
  2822218
- SHA-256:
  2886c0cddcb379d4bbecfc1bbae552eca2dc5e13a47cfbf99b7b7ee948ba59b2

FINAL_HARNESS_AUTHORITY_V3:

/Users/ds/Downloads/ES-repair10i-v3-clean-independent-audit-harness-v2-new-generation-output-lzequ6fk/gen2-clean-source-external-independent-audit-harness-v2.authority-v3.json

Expected identity:

- device:
  16777234
- inode:
  182181917
- mode:
  0400
- link count:
  1
- size:
  7193
- SHA-256:
  349a88f9706fda67a613d4075514fe0137ae746e940d958234f123f4a315d986

FINAL_EXTERNAL_LAUNCH_CERTIFICATE_V1:

/Users/ds/Downloads/ES-repair10i-v3-clean-harness-external-launch-certificate-v2-output-mchfmdqd/gen2-clean-source-external-independent-audit-harness-v2.launch-certificate-v1.json

Expected identity:

- device:
  16777234
- inode:
  182301064
- mode:
  0400
- link count:
  1
- size:
  67057
- SHA-256:
  eaee84d823cbea4ae88ccf0a7ed01429e2b451f5bac128190e760e4d4e528bb8

CURRENT_CONTENT_BUNDLE:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.zip

Expected identity:

- device:
  16777234
- inode:
  181651092
- mode:
  0400
- link count:
  1
- size:
  13598758
- SHA-256:
  b494b9182e333fdd4a7efb10396283bc3887bfe391b29ec2e6f48e0e24613671

CURRENT_CONTENT_AUTHORITY:

/Users/ds/Downloads/ES-repair10i-v3-current-authority-content-snapshot-output-obhfr_7x/gen2-current-authority-manifest-content-snapshot-v1.authority.json

Expected identity:

- device:
  16777234
- inode:
  181651098
- mode:
  0400
- link count:
  1
- size:
  19737
- SHA-256:
  276fde7dcbfd49902b9f63f4a254d79b099c4f1527e35268998c5e9c4a6b1563

All containing directories are nonauthoritative.

Do not inspect or depend on any unrelated directory member.

Do not open predecessor harness, authority, certificate, builder, repair, or
audit roots.

──────────────────────────────────────────────────────────────────────────────
2. PRELAUNCH STABLE FILE AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Before any process launch, authenticate all five files.

For each file:

1. open no-follow;
2. require a regular file;
3. require mode `0400`;
4. require link count one;
5. retain device, inode, size, and SHA-256;
6. perform two stable reads;
7. require metadata and byte equality.

Strict-parse:

- authority v3;
- launch certificate v1;
- content authority JSON;

using:

- UTF-8;
- duplicate-key rejection;
- nonfinite-number rejection.

If any fixed-input predicate fails:

- do not run platform preflight;
- do not launch the audit parent;
- return `AUDIT_PROVENANCE_MISMATCH`;
- retain the exact first blocker;
- state:
  `FRESH_INDEPENDENT_AUDIT_NOT_EXECUTED`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
3. LAUNCH-CERTIFICATE AUTHENTICATION
──────────────────────────────────────────────────────────────────────────────

Require certificate schema:

execution-substrate.gen2-clean-harness.external-launch-certificate.v1

Require:

- certificate version:
  1;
- certificate current:
  true;
- wrapper launch authorized:
  true;
- authorized future audit count:
  1;
- containing directory:
  nonauthoritative.

Authenticate the certificate’s exact bindings to:

- PYZ v2;
- authority v3;
- content bundle;
- content authority;
- exact 124-member PYZ closure;
- deterministic replay A;
- deterministic replay B;
- replay A/B equality;
- replay A/original equality;
- replay B/original equality;
- source freeze;
- final source registries;
- five-domain package identity;
- interpreter-observation package identity;
- typed governing-identity projection contract;
- governing-identity projection matrix;
- independent projection validator;
- fresh platform-capture preflight;
- fresh qualification process custody;
- raw qualification streams;
- fresh qualification result;
- post-package qualification crosswalk;
- source-external evidence-validator result;
- qualify-harness stream contract;
- run-full-audit stream contract;
- exact future run-full-audit invocation;
- exact future cwd;
- exact future submitted environment;
- stdin/shell/TTY/detachment;
- derived values:
  - documentary domains:
    5;
  - runtime report rows:
    66;
  - runtime confirmation names:
    81;
  - runtime matrices:
    15;
  - runtime matrix cases:
    595;
  - PYZ members:
    124;
  - content roles:
    8;
  - content members:
    479;
- source frozen:
  true;
- source unchanged after freeze:
  true;
- deterministic package:
  true;
- fresh post-package qualification:
  passed;
- external evidence validation:
  passed;
- full real audit executed:
  false;
- implementation verdict:
  not issued;
- current subject constructed:
  false;
- source repair:
  false;
- PYZ modification/replacement:
  false.

The launch certificate is the current external wrapper launch authority.

Authority v3 remains the runtime authority passed to the harness.

Do not require authority v3 alone to establish wrapper launch authorization.

Do not require the certificate to contain its own hash or validation of its own
final bytes.

Its exact pinned file identity and this wrapper’s strict validation are the
final validation of certificate bytes.

Any certificate mismatch:

- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`;
- leave the future audit authorization unconsumed.

──────────────────────────────────────────────────────────────────────────────
4. PYZ AND GOVERNANCE CLOSURE
──────────────────────────────────────────────── LIMITED TO CURRENT AUTHORITY
────────────────────────────────────────────────

Parse the PYZ directly.

Require:

- exactly 124 members;
- exact member-registry equality;
- raw UTF-8 byte-sorted names;
- ZIP_STORED only;
- frozen timestamp;
- `create_system=3`;
- member mode `0600`;
- no duplicate member;
- no unsafe path;
- no directory member;
- no symlink or special member;
- no archive/member comment;
- no uncontrolled extra field;
- no cache or bytecode.

Resolve current embedded roles only through exact embedded registries.

Independently recompute and require:

- documentary domains:
  5;
- runtime report rows:
  66;
- runtime confirmation names:
  81;
- runtime matrices:
  15;
- runtime matrix cases:
  595;
- stale 645:
  rejected;
- interpreter roles:
  3;
- terminal-runtime-image role:
  absent;
- content roles:
  8;
- content members:
  479.

Require exact correspondence among:

- certificate;
- authority v3;
- PYZ member registry;
- source freeze;
- source registries;
- governing records;
- matrix results;
- process-custody qualification;
- synthetic lanes;
- compatibility replay;
- real-path rehearsals;
- independent validators;
- package status.

Do not invent a stronger launch predicate than the launch certificate and
embedded contracts.

Do not weaken a sealed predicate.

Any discrepancy:

- do not launch;
- return `AUDIT_PROVENANCE_MISMATCH`.

──────────────────────────────────────────────────────────────────────────────
5. PLATFORM-CAPTURE PREFLIGHT
──────────────────────────────────────────────── LIMITED TO WRAPPER CUSTODY
────────────────────────────────────────────────

After Sections 2–4 pass, run exactly one harmless synchronous platform-capture
preflight.

This is not an audit and does not consume the one authorized audit launch.

Use:

/Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13
-I
-S
-B
-c
<EXACT_PREFLIGHT_PROGRAM>

The program must:

- write exactly:
  `PLATFORM_CAPTURE_STDOUT_V1\n`
  to stdout;
- write exactly:
  `PLATFORM_CAPTURE_STDERR_V1\n`
  to stderr;
- exit exactly:
  23;
- read no stdin;
- create no file;
- create no child.

Submitted environment exactly:

PATH=/usr/bin:/bin
LANG=C
LC_ALL=C
PYTHONDONTWRITEBYTECODE=1
PYTHONHASHSEED=0

No inherited environment.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Retain complete platform custody.

Expected stdout:

- size:
  27;
- SHA-256:
  6cb09bf021fd7f69734021bddfa2cc37d96d944ba51d93c65171523a967dd8c2

Expected stderr:

- size:
  27;
- SHA-256:
  bd0334ca484e143274e8f1438c0eaae701f034b72a466aeab8a7baa800beeec5

Expected exit:

23

Expected signal:

null

If preflight fails:

- do not launch the audit;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_NOT_CONSUMED`;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
6. EXACT REAL-AUDIT INVOCATION
──────────────────────────────────────────────── LIMITED TO ONE LAUNCH
────────────────────────────────────────────────

After preflight passes, derive the invocation from the launch certificate and
require exact equality with the certificate’s frozen invocation.

It must use:

- pinned Framework Python;
- `-I`;
- `-S`;
- `-B`;
- exact PYZ v2;
- `--mode run-full-audit`;
- `--harness-authority`;
- exact authority v3;
- `--bundle`;
- exact content bundle;
- `--bundle-authority`;
- exact content authority.

Do not pass the launch certificate to the harness.

Do not pass:

- predecessor authority;
- documentary roots;
- implementation root;
- historical root;
- continuation/recovery option;
- any extra operand.

Use exact cwd and submitted environment from the certificate.

No fallback cwd or environment is permitted.

stdin:
DEVNULL

shell:
false

TTY:
false

detachment:
false

Launch synchronously.

Launch count:

exactly one.

The audit authorization is consumed when process creation succeeds, regardless
of terminal result or later completion-custody failure.

Do not launch:

- `qualify-harness`;
- replacement/recovery parent;
- continuation;
- direct auditor;
- post-failure validator;
- second audit.

──────────────────────────────────────────────────────────────────────────────
7. TOP-LEVEL PROCESS CUSTODY
──────────────────────────────────────────────── LIMITED TO PLATFORM
────────────────────────────────────────────────

Retain before parsing:

- custody ID;
- PID;
- process-creation result;
- start/completion;
- duration;
- exact argv;
- exact cwd;
- exact submitted environment;
- stdin/shell/TTY/detachment;
- raw stdout;
- raw stderr;
- stream sizes and SHA-256;
- exit code;
- signal;
- process error;
- reaping;
- descriptor closure;
- identities of all five fixed files at launch.

Platform custody is authoritative for top-level process creation and
completion.

Capsule self-authentication does not replace it.

If completion capture is missing after creation:

- do not scan for a root;
- do not guess;
- do not retry;
- return `AUDIT_PROVENANCE_MISMATCH`;
- state:
  `FUTURE_AUDIT_AUTHORIZATION_CONSUMED`.

──────────────────────────────────────────────────────────────────────────────
8. STREAM AND TERMINAL-FRAME CONTRACT
──────────────────────────────────────────────── LIMITED TO FROZEN FRAMING
────────────────────────────────────────────────

Retain raw streams before parsing.

For a handled `run-full-audit` terminal result require:

- stdout:
  exactly one canonical UTF-8 JSON object plus LF;
- schema:
  `clean-independent-audit-terminal-frame-v2`;
- `audit_root` field:
  sole root locator;
- no separate locator line;
- no duplicate frame;
- no trailing bytes;
- stderr:
  empty;
- exit:
  0.

Allowed final verdicts:

ACCEPT
BLOCK
AUDIT_PROVENANCE_MISMATCH

Strict-parse with duplicate-key and nonfinite rejection.

Require terminal-frame fields and identities under its exact embedded schema.

Require consistency among:

- terminal frame;
- platform exit/signal;
- audit-root path;
- terminal marker;
- preseal result;
- terminal result;
- temporal inventory;
- manifest A;
- manifest B.

If the process exits under the frozen unhandled-failure posture:

- return `AUDIT_PROVENANCE_MISMATCH`;
- do not scan for a root;
- do not retry.

──────────────────────────────────────────────────────────────────────────────
9. AUDIT-ROOT SELECTION
──────────────────────────────────────────────── LIMITED TO TERMINAL FRAME
────────────────────────────────────────────────

Use only:

terminal_frame["audit_root"]

Do not scan any directory.

Do not use:

- prefix;
- recency;
- inode search;
- hash search;
- basename;
- score;
- historical root reuse.

Authenticate:

- absolute path;
- directory;
- no symlink;
- mode 0700;
- observed device/inode;
- equality with every capsule reference;
- fresh-creation evidence.

If authentication fails:

- preserve the terminal path as report-only evidence;
- return `AUDIT_PROVENANCE_MISMATCH`;
- inspect no alternative path.

──────────────────────────────────────────────────────────────────────────────
10. READ-ONLY CAPSULE INSPECTION
──────────────────────────────────────────────── LIMITED TO OUTPUT EVIDENCE
────────────────────────────────────────────────

Inspect only the exact audit root.

Do not:

- modify;
- chmod;
- delete;
- clean;
- resume;
- execute capsule source;
- execute implementation source;
- run another validator;
- regenerate evidence;
- add/replace any record or manifest.

Resolve authoritative paths through:

- terminal frame;
- embedded capsule path registry;
- capsule indexes;
- manifests.

For every record retain:

- relative path;
- schema;
- mode;
- link count;
- size;
- SHA-256;
- authority role.

──────────────────────────────────────────────────────────────────────────────
11. PARENT SELF-AUTHENTICATION
──────────────────────────────────────────────── LIMITED TO TYPED CROSSWALK
────────────────────────────────────────────────

Authenticate the capsule’s parent runtime self-authentication record.

Crosswalk with external platform custody.

Require exact three-role interpreter tuple:

1. platform-declared launcher;
2. launcher-valued runtime `sys.executable` and `_base_executable`;
3. Python.app-valued `sys.orig_argv[0]`.

Require:

- no terminal-runtime-image role;
- no kernel-image claim;
- no role substitution;
- no basename/prefix/realpath/score fallback;
- exact `sys.orig_argv[1:]` to submitted argv tail;
- exact `sys.argv` application sequence;
- exact cwd and PID crosswalks;
- exact Python flags;
- exact source/PYZ identity;
- exact five declared environment rows;
- optional exact:
  `__CF_USER_TEXT_ENCODING=0x1F5:0x0:0x0`;
- UID relation:
  501;
- no unknown extra environment key;
- `top_level_process_authority=external_platform_wrapper`.

Any self-authentication failure is an audit-provenance finding, not a package
finding.

──────────────────────────────────────────────────────────────────────────────
12. CAPSULE AUTHORITY, PHASES, AND CUSTODY
──────────────────────────────────────────────── LIMITED TO CURRENT CAPSULE
────────────────────────────────────────────────

Authenticate every required capsule role through its path/writer registries.

Require:

- all capsule JSON files have schema;
- exclusive single write;
- mode 0600;
- single link;
- strict canonical JSON.

Authenticate P00 through P24.

Every phase must contain:

- phase ID/name;
- prerequisites;
- explicit status;
- terminal true;
- phase-specific evidence;
- findings;
- first blocker or null;
- continuation;
- cleanup obligations;
- authority contribution;
- completion timestamp.

Reject generic evidence and terminal-as-passed inference.

Authenticate child ledger and custody.

Zero-child is valid only when explicit.

Require every created child reaped and every descriptor closed.

Top-level parent custody remains externally owned.

──────────────────────────────────────────────────────────────────────────────
13. RUNTIME REPORT, CONFIRMATIONS, AND MATRICES
──────────────────────────────────────────────── LIMITED TO GOVERNED SETS
────────────────────────────────────────────────

Require:

Runtime report:

- exact R01–R66 order;
- 66 rows;
- mode `run-full-audit`;
- explicit applicability/status/value/evidence/authority;
- no blanket N/A;
- verdict separate.

Runtime confirmations:

- exact 81-name registry;
- 81 rows;
- mode `run-full-audit`;
- observed/expected/pass;
- evidence pointers;
- no hard-coded all-true projection.

Specifically require audit-mode rows such as:

- RUN_FULL_AUDIT_MODE_NOT_EXECUTED:
  observed false,
  expected false,
  pass true;

- FULL_INDEPENDENT_AUDIT_NOT_EXECUTED:
  observed false,
  expected false,
  pass true;

- IMPLEMENTATION_PACKAGE_NOT_READJUDICATED:
  observed false,
  expected false,
  pass true.

Runtime matrices:

- exact B00 and D01–D14;
- 15 matrices;
- 595 cases;
- zero false accept/reject/mismatch/skip/exception;
- stale 645 rejected.

Require all report/confirmation evidence pointers to resolve.

──────────────────────────────────────────────────────────────────────────────
14. IMPLEMENTATION AUDIT EVIDENCE
──────────────────────────────────────────────── LIMITED TO SOURCE-EXTERNAL AUDIT
────────────────────────────────────────────────

Authenticate and report:

- content bundle/index/role closure;
- implementation attempt lineage;
- source registries;
- source freeze and frozen requalification;
- production authority/static security;
- E00/G00–G29 crosswalk;
- documentary lifecycle/writer ownership;
- 946 negative cases;
- 137 contradiction cases;
- 766/333 field map;
- producer rehearsals;
- Attempt-2 bounded failure evidence;
- implementation confirmations;
- constructed-subject evidence domain;
- fresh audit-owned behavioral causals;
- fresh source-external validation;
- security/authority closure.

Do not execute implementation source.

Separate direct package, audit, derivative, mixed, and unresolved findings.

Every direct package blocker requires current direct evidence.

──────────────────────────────────────────────────────────────────────────────
15. CLEANUP, INPUT EQUALITY, AND FINDINGS
──────────────────────────────────────────────── LIMITED TO TERMINAL EVIDENCE
────────────────────────────────────────────────

Authenticate canonical cleanup rows and exact cleanup-set equality.

Equal empty sets pass.

Require zero process, descriptor, cache, and bytecode survivors.

Authenticate capsule fixed-input closing equality for:

- PYZ v2;
- authority v3;
- content bundle;
- content authority.

The launch certificate is wrapper-only and is verified by wrapper opening and
closing identity checks, not by the unchanged harness capsule.

Authenticate:

- complete findings registry;
- finding ownership;
- dependency graph;
- severity;
- first blocker.

Preseal result is nonauthoritative until closure.

──────────────────────────────────────────────────────────────────────────────
16. TERMINAL CAPSULE CLOSURE
──────────────────────────────────────────────── LIMITED TO FINAL AUTHORITY
────────────────────────────────────────────────

Authenticate:

- temporal inventory;
- terminal result;
- manifest A;
- manifest B;
- terminal frame.

Require:

- temporal immediate reprojection;
- root row exactly once;
- A/B existence;
- A/B byte equality;
- exact manifest identities;
- final independent reprojection;
- no empty descendant;
- no symlink/special object;
- no multiply linked file;
- modes 0700/0600;
- no cache/bytecode;
- one seal transition;
- terminal marker;
- no postseal filesystem/process operation.

Failure forces wrapper verdict:

AUDIT_PROVENANCE_MISMATCH

Do not promote preseal ACCEPT/BLOCK through failed closure.

──────────────────────────────────────────────────────────────────────────────
17. FINAL VERDICT RULES
──────────────────────────────────────────────── LIMITED TO AUDIT RESULT
────────────────────────────────────────────────

Report ACCEPT only when:

- all five fixed files authenticate;
- launch certificate authorizes launch;
- platform custody completes;
- self-authentication passes;
- no direct blocker remains;
- preseal and terminal frame say ACCEPT;
- cleanup/equality/closure pass.

Report BLOCK only when:

- provenance passes;
- at least one direct package blocker exists;
- findings/dependencies are complete;
- preseal/frame say BLOCK;
- cleanup/equality/closure pass.

Report AUDIT_PROVENANCE_MISMATCH on any failure of:

- fixed inputs/certificate;
- custody/framing;
- root authentication;
- self-authentication;
- evidence/phase/custody completeness;
- finding ownership;
- cleanup/equality;
- temporal/manifests/reprojection/seal.

Do not retry.

──────────────────────────────────────────────────────────────────────────────
18. NO FOLLOW-ON EXECUTION
──────────────────────────────────────────────── LIMITED TO REPORTING
────────────────────────────────────────────────

After reporting:

- stop;
- preserve all five fixed files;
- preserve the audit capsule unchanged;
- do not clean the capsule;
- do not construct the current subject;
- do not execute product modes;
- do not run target audit or runtime validation;
- do not modify a repository;
- do not commit/push;
- do not publish/deploy;
- do not begin A6;
- do not launch another agent.

──────────────────────────────────────────────────────────────────────────────
19. REQUIRED INLINE OPERATIVE REPORT
──────────────────────────────────────────────── LIMITED TO COMPLETE RESULT
────────────────────────────────────────────────

Return:

1. Exact primary verdict
2. Five fixed-file identities
3. Stable prelaunch authentication
4. Launch-certificate authentication
5. Certificate authority model
6. Authority-v3 runtime role
7. PYZ member/governance closure
8. Platform-capture preflight
9. Exact audit argv
10. Exact cwd/environment
11. Top-level process custody
12. Raw stdout/stderr identities
13. Exit/signal
14. Terminal frame
15. Audit-root identity
16. Parent runtime self-authentication
17. Interpreter tuple result
18. Environment crosswalk
19. P00–P24 phase results
20. Child ledger/custody
21. Content role closure
22. Implementation source/freeze closure
23. Production authority/security
24. E00/G00–G29 crosswalk
25. Documentary lifecycle/writers
26. Runtime matrices
27. 946 negative cases
28. 137 contradiction cases
29. 766/333 field map
30. Producer rehearsals
31. Attempt-2 evidence
32. Implementation confirmations
33. Constructed-subject evidence
34. Fresh behavioral causals
35. Fresh source-external validation
36. Security/authority closure
37. R01–R66 report
38. 81-name confirmations
39. Complete findings
40. Finding ownership
41. Dependency graph
42. Severity findings
43. Preseal disposition
44. Cleanup
45. Capsule fixed-input equality
46. Wrapper five-file closing equality
47. Temporal identity
48. Manifest A identity
49. Manifest B identity
50. Final reprojection
51. Terminal topology/modes
52. Seal/marker
53. No-write result
54. Confirmation current subject not constructed
55. Confirmation no product/runtime/target/A6 activity
56. Remaining uncertainty/nonclaims
57. Explicit wrapper confirmations

Required confirmations:

PYZ_V2_IDENTITY_MATCHED
AUTHORITY_V3_IDENTITY_MATCHED
LAUNCH_CERTIFICATE_IDENTITY_MATCHED
CONTENT_BUNDLE_IDENTITY_MATCHED
CONTENT_AUTHORITY_IDENTITY_MATCHED
LAUNCH_CERTIFICATE_CURRENT_AND_COHERENT
LAUNCH_CERTIFICATE_AUTHORIZED_ONE_AUDIT
PYZ_MEMBER_SET_124_CLOSED
PLATFORM_CAPTURE_PREFLIGHT_PASSED
RUN_FULL_AUDIT_EXECUTED_EXACTLY_ONCE
FUTURE_AUDIT_AUTHORIZATION_CONSUMED
QUALIFY_HARNESS_MODE_NOT_EXECUTED
LAUNCH_CERTIFICATE_NOT_PASSED_TO_HARNESS
REPLACEMENT_PARENT_NOT_LAUNCHED
ADMINISTRATIVE_CONTINUATION_NOT_USED
NO_DIRECT_AUDITOR_USED_OUTSIDE_HARNESS
RAW_STDOUT_RETAINED
RAW_STDERR_RETAINED
PLATFORM_EXIT_AND_SIGNAL_RETAINED
AUDIT_ROOT_FROM_TERMINAL_FRAME_USED
AUDIT_ROOT_SCAN_NOT_PERFORMED
TERMINAL_FRAME_STRICTLY_PARSED
PARENT_RUNTIME_SELF_AUTHENTICATION_RETAINED
INTERPRETER_OBSERVATION_TUPLE_PASSED
RUNTIME_ENVIRONMENT_POLICY_PASSED
CAPSULE_PRIMARY_VERDICT_REPORTED_EXACTLY
COMPLETE_RUNTIME_REPORT_RETAINED
COMPLETE_RUNTIME_CONFIRMATIONS_RETAINED
EVERY_REQUIRED_PHASE_TERMINAL
CHILD_ORDINALS_COMPLETE_AND_CONTIGUOUS
ALL_CREATED_CHILDREN_REAPED
ALL_CHILD_DESCRIPTORS_CLOSED
CLEANUP_RESULT_RETAINED
CAPSULE_FIXED_INPUT_CLOSING_EQUALITY_RETAINED
WRAPPER_FIVE_FILE_CLOSING_EQUALITY_PASSED
TEMPORAL_INVENTORY_RETAINED
MANIFEST_A_RETAINED
MANIFEST_B_RETAINED
MANIFESTS_BYTE_IDENTICAL
TERMINAL_REPROJECTION_PASSED
ROOT_ROW_PRESENT_EXACTLY_ONCE
NO_EMPTY_DESCENDANT_AT_TERMINAL_CLOSURE
NO_SYMLINK_OR_SPECIAL_OBJECT
NO_MULTIPLY_LINKED_FILE
ALL_DIRECTORY_MODES_0700
ALL_FILE_MODES_0600
NO_CACHE_OR_BYTECODE_RETAINED
SINGLE_SEAL_TRANSITION
NO_WRITE_AFTER_TERMINAL_SEAL
AUDIT_CAPSULE_MUTATION_NOT_PERFORMED
AUDIT_CAPSULE_CLEANUP_NOT_PERFORMED
CURRENT_SCHEMA_SUBJECT_NOT_CONSTRUCTED
IMPLEMENTATION_REPAIR_NOT_PERFORMED
NO_NETWORK_CONTACT
NO_GIT_INVOCATION
NO_PRODUCT_OR_LIVE_SERVICE_INVOCATION
NO_TARGET_AUDIT_EXECUTED
NO_RUNTIME_VALIDATION_RERUN
NO_A6_ACTIVITY
NO_SUBAGENTS_CREATED
```

### Sources

The attached Codex report establishes the successful final certificate, including its exact identity, deterministic replay equality, fresh qualification, post-package crosswalk, independent evidence validation, and one-audit authorization. :chatgpt-content-reference{index="5"} :chatgpt-content-reference{index="6"} :chatgpt-content-reference{index="7"}

**Confidence:** 0.999 that the launch-certificate seam is now closed; 0.999 that the audit authorization remains unconsumed; 0.995 that no source, PYZ, authority, or documentary work is justified before the actual audit; 0.98 that the wrapper prompt above accurately respects the frozen one-object `run-full-audit` stream contract without inventing a separate locator line.

Some older project uploads are no longer available. Re-upload an older file only if a future review needs its original bytes rather than the retained identities and reports.
