## Assessment

Codex’s `REPAIR10H_RECONNAISSANCE_READY` verdict is justified. This is the first pass in this sequence that cleanly separates five different things that Phase G had conflated:

- production behavior;
- product-test semantics;
- diagnostic canonicalization;
- control qualification;
- validation/readiness adjudication.

The strongest conclusion is that **no production product byte needs to change**. The two final-versus-fresh lifecycle failures came from tests that searched serialized JSON for the bare decimal `7002`; legitimate public fields can contain those same digits. The frozen replacement—structural decoding, a field/path/type allowlist, an independently derived public projection, and paired private-data noninterference—is materially stronger than substituting a different sentinel or adding another substring exception. 

The 200-difference analysis is also sufficient to proceed. It accounts for every entry: two test-failure diagnostics, 18 control-local identities, 112 typed nondeterministic values, and 68 panic-runtime entries, leaving zero unclassified entries.  The `logical_bytes` treatment is narrow enough to accept provisionally: its exact producer and bounded contract were recovered, and the proposed rule applies only to that test/template/field while preserving `entries`, `depth`, sign, encoding, and the 128 MiB boundary. 

The qualification correction is likewise sound. Comparison acceptance will no longer trust a semantic envelope’s embedded caption: it must bind an external qualification record and independently recompute qualification from the referenced suite evidence. Factual equality and accepted equality are separated, and unknown output or an unqualified side forces exit `1`.  The historical mutant was correctly found to be unqualified because it mutated after pristine materialization; Repair 10H will instead construct and bind the mutant before execution as its own source class. 

The touched-file freeze is proportionate: eight repository files, seven successor files, and no product production source. 

### Four refinements to carry into implementation

These do not require another reconnaissance turn.

1. **Bind a logical suite fingerprint separately from the complete suite-spec hash.** Final and fresh necessarily have different control IDs, roots, evidence paths, command names, and peer-runner sides. Retain and bind the full spec bytes, but compare a separately derived logical fingerprint over the stable command membership, argv, lane, limits, environment policy, expected source class, and semantic policy.

2. **Define “unknown” separately from an exact material difference.** For HEAD↔final and Repair-9↔final, exact unmatched diagnostic text may be retained as a material diagnostic difference. “Unknown” should mean malformed, partially recognized, ambiguously canonicalized, unsupported, or custody-unbound output—not simply “different text.” For final↔fresh, any material difference still blocks equality.

3. **Require the deliberate mutant’s exact declared delta.** `qualified-different` alone is too weak. Final↔mutant and mutant↔fresh must show exactly the declared test failure and its necessary enclosing package outcome, with no additional lifecycle, diagnostic, skip, panic, race, warning, unknown, or package-abort delta.

4. **Rerun exact-candidate product preparation.** Although production source is byte-identical, the repository tree `T` will change because docs and tests change. Run two independent exact-candidate C/T/D/E preparations and compiler-input checks against the final Repair 10H tree. This rebinds retained preparation evidence to the new source identity rather than inheriting Phase G’s `T`.

The next move is parent-only implementation—not another design pass.

## Prompt for Codex

```text
Permission is now workspace-write.

Implement Repair 10H from the immediately preceding
REPAIR10H_RECONNAISSANCE_READY report.

You are the sole writer. Do not create or resume subagents. Do not perform or
claim an independent audit.

Repository

/Users/ds/Repositories/Execution Substrate - external-tls-status-observation-v1

Objective

Deliver one bounded Repair 10H implementation that:

1. replaces the two collision-prone decimal-substring privacy tests with
   structural privacy and noninterference assertions;
2. adds only allowlisted, typed diagnostic canonicalization for the exhaustive
   Phase G final/fresh difference taxonomy;
3. binds comparison eligibility to independently recomputed external control
   qualification;
4. constructs and qualifies the deliberate mutant as its own immutable source
   before execution;
5. requires final versus fresh to be qualified-equal with AcceptedEqual=true,
   UnknownDifferenceCount=0, and exit 0;
6. prevents closeout readiness when that requirement is absent;
7. leaves all product production bytes unchanged.

This is an implementation and validation turn. It is not an audit, snapshot,
commit, publication, installation, or live-operation turn.

Authority and seam classification

- T1 remains a Current invariant.
- Repair 10H remains an unaccepted T2A-P Bounded slice rule.
- Legacy operator behavior remains a Temporary compatibility edge.
- T2A-I and T2B remain absent.
- No Reopened redesign seam is exercised.
- Phase G remains exact, sealed, immutable, historically nonqualifying evidence.
- Generated evidence remains non-authoritative.

Opening baseline

Require exactly:

Branch:
codex/remote-alpha-external-tls-status-observation-v1

HEAD:
567bceced5df95ecfe787cc66038d463a854e12c

Parent:
05dde14d185b6e022dcc169ef1a658a97961850f

HEAD tree:
b7cab23732572c2aaea9d5f2f1593338e2e75338

Candidate T:
c7c27cb21dbea12d36324f66e3e5feed4c0ddeea

Inventory SHA-256:
3b60a85f9eeccc12fd02405a2ba41c2e49f22931d33213ba5ad7fd4b2d42f80b

Membership:
389 total
375 tracked
14 nonignored untracked

Staged/deleted/renamed/unmerged:
0/0/0/0

Index SHA-256:
012df0ac71da4dac9e1afc32c424be8f0fb219e93e04ec0f6251aa821dea7a31

Upstream:
absent

Sealed Phase G

/Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/phase-g-closure-4af76ce4d256

Manifest SHA-256:
5dd8ac31bf841e3a371a42a92894cd526ae8e5d886f1b13afc940211a5017c49

Before editing:

1. Verify the repository identity, candidate source identity, inventory,
   membership, index, and posture above.
2. Fully reverify Phase G’s manifest, detached digest, full path set, modes,
   sizes, hashes, single-link regular-file policy, directory modes, and zero
   symlinks.
3. Verify there is no active repository writer, Git operation, stage, lock, or
   unexplained process.
4. Create exactly one new, exclusive, mode-0700 Phase H evidence child under:

   /Users/ds/Downloads/ES-T2AP-repair10-validation-evidence-v1/

   Use a new phase-h-closure-* name, require it to be absent, never reuse an
   existing or failed child, and report the exact selected path.
5. Stop before mutation on any mismatch with:

   REPAIR10H_BASELINE_MISMATCH

Immutable inputs

Do not modify, chmod, relink, rewrite, amend, or add files beneath Phase G.

Do not treat Phase G’s readiness conclusion as accepted. Its source and evidence
are historical inputs only.

Exact repository touched-file set

Only these eight repository files may change:

PLANS.md
.docs/system_overview/remote_alpha_external_tls_status_deployment_v1.md
.docs/system_overview/boundaries.md
.docs/system_overview/capability_probing.md
.docs/system_overview/artifact_hygiene.md
.docs/system_overview/configuration.md
docs_contract_test.go
es/externaltls/internal/statusobservation/remoteobserver/observe_test.go

Every other repository member must remain byte- and mode-identical.

In particular, do not change:

- production remoteobserver source;
- protocol.DocumentV1 or any public/canonical product schema;
- externaltlsruntimewitness production source;
- statuspackage implementation or tests;
- public CLI or scripts;
- operator production or tests;
- go.mod or go.sum;
- T1 source or tests;
- remote_alpha_external_tls_status_observation_v1.md.

Exact successor-source treatment

Copy Phase G’s twelve successor source members, without hardlinks, into the new
Phase H evidence child.

Modify exactly:

FORMAT.md
envelope/runner.go
envelope/semantic.go
envelope/envelope_test.go
cmd/repair10-runner/main.go
cmd/repair10-semantic/main.go
cmd/repair10-compare/main.go

Keep byte-identical:

cmd/repair10-fixture/main.go
envelope/source.go
envelope/testdata/evidence-manifest-v1.golden
envelope/testdata/source-inventory-v1.golden
go.mod

No thirteenth successor source member is authorized.

Private Phase H schemas

Use these exact schema IDs:

execution-substrate.repair10h.suite-spec.v1
execution-substrate.repair10h.suite-result.v1
execution-substrate.repair10h.control-qualification.v1
execution-substrate.repair10h.intentional-mutant-provenance.v1
execution-substrate.repair10h.go-test-semantics.v1
execution-substrate.repair10h.semantic-comparison-spec.v1
execution-substrate.repair10h.semantic-comparison-result.v1
execution-substrate.repair10h.semantic-comparison-custody.v1
execution-substrate.repair10h.semantic-comparison-adjudication.v1
execution-substrate.repair10h.phase-h-closeout-adjudication.v1
execution-substrate.repair10h.literal-assertion-mapping.v1
execution-substrate.repair10h.provenance-recipe-inventory.v1
execution-substrate.repair10h.failed-and-superseded-attempt-index.v1
execution-substrate.repair10h.command-index.v1

Repair 10G qualification, semantic, and comparison records remain parseable only
as historical nonqualifying inputs.

Implementation order

1. Update PLANS.md and the five authoritative system-overview pages.
2. Update docs_contract_test.go.
3. Update the remoteobserver privacy tests and add their causal controls.
4. Update FORMAT.md and successor causal tests.
5. Implement the seven successor changes.
6. Add the new Phase H orchestration/spec/report sources.
7. Build and qualify two independent successor controls.
8. Run repository and successor validation.
9. Materialize and qualify final, fresh final, intentional mutant, HEAD, and
   Repair 9 controls.
10. Run all five comparisons.
11. Run two independent exact-candidate product C/T/D/E preparations.
12. Perform closeout and seal Phase H, installing its manifest as the final
    bundle mutation.
13. Stop without snapshotting, auditing, staging, committing, or pushing.

Product-test repair

Replace the two raw decimal-substring assertions in:

- TestObserveV1WitnessCustodyClassificationAndContextV1
- TestObserverClosingWitnessPrivacyV1

Do not simply choose different sentinel numbers or add substring exclusions.

The replacement must:

- decode canonical JSON with number preservation;
- walk and validate an independent key/path/type allowlist for:
  - protocol.DocumentV1;
  - the witness envelope;
  - externaltlsruntimewitness.WitnessV1;
- derive an expected public projection independently from production serializer
  implementation;
- compare actual permitted leaves to that expected projection;
- use paired inputs differing only in private custody/closing data and prove
  public-output noninterference;
- reject prohibited private keys;
- reject prohibited private scalar values;
- reject prohibited structured values and nested contexts;
- reject laundering of private data into otherwise permitted fields.

Positive controls must include legitimate public values containing 7001 and
7002 in:

- pid and main_pid;
- timestamps;
- request IDs;
- counters;
- digests;
- source/public string values.

Production remoteobserver and schema bytes must remain unchanged unless a
genuine production disclosure is demonstrated. If a production disclosure is
found, stop and return:

REPAIR10H_SCOPE_REOPEN_REQUIRED

Typed canonicalization

Implement only the frozen allowlisted rules from reconnaissance:

- command-result.source-root-v1
- command-result.control-root-v1
- go-testing-tempdir-parent-v1
- remote-alpha-vault-reset-run-id-v1
- darwin-mktemp-failed-candidate-v1
- observability-inbound-request-complete-v1
- go-panic-runtime-identities-v1
- fresh-bootstrap-logical-bytes-bound-v1

All matching is full-template and field-aware. Partial matches fail closed and
remain unknown.

No generic replacement is allowed for:

- decimal numbers;
- hexadecimal strings;
- UUIDs;
- paths;
- timestamps;
- durations;
- PIDs;
- ports;
- tmp.* strings;
- digests or OIDs.

Preserve:

- package, test and subtest identity;
- occurrence ordinal;
- within-occurrence diagnostic order;
- multiplicity;
- correlation topology;
- panic type and message;
- function, file, source line, +0x offset and frame order;
- scalar/nil shape;
- repeated-versus-distinct identifier relationships.

Only cross-package scheduler ordering may be ignored.

For fresh-bootstrap-logical-bytes-bound-v1:

- apply only to the exact named test, package, source line/template and
  logical_bytes field;
- require canonical nonnegative decimal syntax;
- preserve entries and depth exactly;
- map only values below 134217728;
- 134217728 or above remains visible and blocking;
- sign, leading zero, overflow, field rename/reorder or extra text remains
  visible and blocking.

Unknown handling and baseline policy

Distinguish:

1. exact material diagnostic difference;
2. recognized typed nondeterminism;
3. malformed, partial, ambiguous or unsupported unknown output.

An exact unmatched diagnostic may be retained as a material difference in the
HEAD↔final and Repair-9↔final expected-difference comparisons.

It must not be silently normalized.

For final↔fresh, any lifecycle or material diagnostic difference blocks
AcceptedEqual.

For final↔mutant and mutant↔fresh, require the exact declared mutant semantic
delta. No additional lifecycle, diagnostic, skip, panic, race, warning,
unknown, malformed-stream, package-abort or resource delta is accepted.

UnknownDifferenceCount must be zero in every qualifying comparison.

Logical suite binding

Retain and hash the complete suite specification for each control.

Additionally derive and bind a LogicalSuiteFingerprint over only the stable
logical contract:

- source class and intended comparison role;
- logical command membership and order;
- argv;
- lane;
- timeout and output limits;
- non-root-derived environment policy;
- required command outcomes;
- semantic-extraction and canonicalization policy;
- required tool identities.

Exclude only declared control-local values such as control ID, private root,
evidence path, peer-runner side and root-derived path values.

Final and fresh must have:

- distinct full spec identities;
- equal LogicalSuiteFingerprint;
- equal logical command membership.

Any undeclared logical-spec difference blocks qualification.

Qualification

The comparator must:

- bind a peer-authored external qualification record by path, size and SHA-256;
- independently reopen and identity-bracket the qualification inputs;
- independently recompute qualification from the referenced suite result,
  command result, terminal reconciliation, raw stream, semantic envelope and
  custody/resource evidence;
- require canonical recomputation to equal the retained external record;
- ignore the semantic envelope’s embedded qualification caption for acceptance.

Bind at minimum:

- control ID;
- source_class;
- base and effective T and inventory;
- mutation provenance when required;
- logical suite fingerprint and complete spec hash;
- command/suite/terminal record identities;
- raw stream identity, EOF and stable opening/closing identity;
- semantic extractor and mapping-table identities;
- physical cross-control disjointness;
- custody, resource, cleanup and late-fault results.

Required comparison fields

Every Repair 10H comparison result must contain:

LifecycleEqual
DiagnosticsEqual
RawBytesEqual
CanonicalSemanticsEqual
LeftQualified
RightQualified
AcceptedEqual
Outcome
ReasonCodes
QualificationRecordRefs
UnknownDifferenceCount
LogicalSuiteFingerprintEqual

Factual equality fields remain factual after a later qualification or custody
failure. AcceptedEqual must become false.

Exit policy

- Exit 0:
  qualified-equal and AcceptedEqual=true.
- Exit 2:
  qualified-different, both controls qualified, all custody and resource checks
  clean, UnknownDifferenceCount=0, and the pair-specific expected-difference
  policy satisfied exactly.
- Exit 1:
  rejected-left, rejected-right, rejected-both, blocked-uncertain, historical
  nonqualifying schema, unknown text, qualification/reference/recomputation
  failure, custody/resource/terminal fault, logical-suite mismatch or late
  fault.

Use at least the frozen closed reason-code vocabulary from reconnaissance.

Intentional mutant

Construct the deliberate mutant before suite execution.

Record and independently verify:

- source_class=intentional-mutant;
- exact pristine base T and inventory;
- exact sole changed path;
- before and after mode, size and SHA-256;
- effective mutant T and inventory;
- mutation-construction source and identity;
- no later source mutation during execution.

The mutant must be containment-, custody-, resource- and terminal-qualified
against its declared mutant source.

Do not qualify the historical Phase G mutant.

Comparison matrix

Require exactly:

1. final ↔ fresh
   - qualified-equal
   - AcceptedEqual=true
   - LifecycleEqual=true
   - DiagnosticsEqual=true
   - CanonicalSemanticsEqual=true
   - UnknownDifferenceCount=0
   - expected exit 0

2. final ↔ deliberate mutant
   - qualified-different
   - both controls qualified
   - exact declared mutant delta only
   - UnknownDifferenceCount=0
   - expected exit 2

3. mutant ↔ fresh
   - qualified-different
   - both controls qualified
   - exact declared mutant delta only
   - UnknownDifferenceCount=0
   - expected exit 2

4. HEAD ↔ final
   - qualified-different
   - both controls qualified
   - UnknownDifferenceCount=0
   - expected exit 2
   - separately prove no undeclared final-only pass-to-fail, skip, package abort,
     panic, race, warning or malformed-stream regression

5. Repair 9 ↔ final
   - same policy as HEAD ↔ final

Closeout readiness must directly require comparison 1 AcceptedEqual=true and
UnknownDifferenceCount=0.

“All configured exits occurred” or “all expected differences occurred” is not
a readiness condition.

Phase H orchestration/evidence sources

Create the exact source set frozen in reconnaissance:

commands/generate-repository-validation-specs-v1.py
commands/repair10h-pristine-final-v1.json
commands/repair10h-fresh-independent-final-v1.json
commands/repair10h-final-only-mutant-v1.json
commands/repair10h-head-v1.json
commands/repair10h-repair9-v1.json
commands/repair10h-final-semantic-comparisons-v1.json
commands/finalize-semantic-comparisons-v1.py
commands/successor-build-a-v1.sh
commands/successor-build-b-v1.sh
commands/successor-selftest-a-v1.sh
commands/successor-selftest-b-v1.sh
commands/successor-hard-gate-v1.py
preparation/construct-deliberate-mutant-v1.py
preparation/derive-final-semantic-suite-v1.py
preparation/semantic-comparison-specs/final-fresh-spec-v1.json
preparation/semantic-comparison-specs/final-mutant-spec-v1.json
preparation/semantic-comparison-specs/mutant-fresh-spec-v1.json
preparation/semantic-comparison-specs/head-final-spec-v1.json
preparation/semantic-comparison-specs/repair9-final-spec-v1.json
closeout/adjudicate-repair10h-closeout-v1.py
closeout/capture-git-closeout-v1.py
closeout/cleanup-private-roots-v1.py
closeout/normalize-phase-h-modes-v1.py
closeout/implementation-report-v1.md

Do not create an amendment chain. The first retained Phase H closeout reducer
must compute readiness truthfully.

Validation

Run everything offline, in physically separate, no-hardlink private controls
with private HOME/XDG/GOPATH/GOMODCACHE/GOCACHE/GOTMPDIR/TMPDIR roots.

At minimum retain exact argv, cwd, environment, timeout, output caps, raw
stdout/stderr, exit, terminal reconciliation, resource ledger, semantic
extraction and command result for:

1. Bash syntax for protected public scripts.
2. gofmt -d for the changed Go repository file and changed successor Go files;
   require empty output.
3. docs contract tests.
4. Updated remoteobserver privacy tests, including all positive and negative
   causal controls, with count=3.
5. Successor unit tests with count=3.
6. Successor race tests with pinned race-only tool inputs.
7. Independent successor A/B builds:
   - byte-identical source inventories and logical modes;
   - independent caches and roots;
   - byte-identical runner, semantic and comparator binaries;
   - self-tests and cross-qualification.
8. Full relevant status-observation and external-TLS regressions.
9. go mod verify from a complete private cache.
10. go vet ./....
11. Literal full suite:
    go test -json -count=1 -p=1 -parallel=1 ./...
12. Final, fresh, mutant, HEAD and Repair-9 controls and all five comparisons.
13. Two independent exact-candidate product preparations against final T:
    - independently materialized source/Git/cache/temp/runtime/PackageFloor roots;
    - exact C/T/D/E bindings;
    - direct artifact and build-evidence comparison through EOF;
    - source/compiler/module/GOROOT/tool binding checks;
    - cleanup and absence checks.
14. Darwin arm64 status-package and status builds.
15. Linux amd64 and arm64 observer cross-builds, not executed.
16. Fresh final repository source inventory, pure T, membership and Git posture.

Product production bytes are expected to remain unchanged. Treat any changed
product artifact D/E as a stop requiring explanation, not an automatic pass.

Causal requirements

Prove at minimum:

- public 77002 PID/main-PID and unrelated 7001/7002 digits pass;
- prohibited private key/scalar/structure/nested context fails;
- each allowlisted nondeterminism grammar canonicalizes;
- partial or malformed grammar remains unknown and blocking;
- one-nibble OID/SHA mutation remains visible;
- EPERM versus EACCES remains visible;
- route/status changes remain visible;
- panic message/type/frame changes remain visible;
- scalar/nil changes remain visible;
- pass/fail/skip changes remain visible;
- logical_bytes=134217727 qualifies and 134217728 remains material/blocking;
- wrong qualification SHA, control ID, T/inventory or logical suite fingerprint
  fails;
- inode alias, late close fault and resource fault fail;
- undeclared second mutant path fails;
- unqualified mutant cannot be represented as qualified;
- final/fresh difference cannot satisfy readiness;
- closeout cannot set readiness when AcceptedEqual=false;
- Repair 10G schema input remains historical and nonqualifying.

Evidence and sealing

Retain:

- opening baseline and full Phase G verification;
- exact repository and successor source inventories;
- all successor build/self-test evidence;
- every complete suite spec and logical suite fingerprint;
- command intents/results/terminal records/resource ledgers/raw streams;
- external and independently recomputed qualification records;
- semantic envelopes, mapping tables and rule corpora;
- all five comparison specs, custody records and results;
- exact mutant provenance;
- A/B product preparation records and retained payload comparisons;
- literal assertion mapping;
- provenance recipe inventory;
- failed-and-superseded attempt index;
- command index with expected and actual exits;
- Git/source/admin closeout;
- implementation report and closeout adjudication.

Use mode 0600 files and 0700 directories, regular single-link files only, no
hardlinks or symlinks.

Precompute and install the detached digest, then install
evidence-manifest-v1.txt as the final Phase H mutation. Write nothing afterward.

After sealing, perform read-only complete verification of path set, modes,
sizes, hashes and link counts.

Do not create an integrated source ZIP in this turn. Snapshot/capture and fresh
independent audit are separately authorized later gates.

Stop conditions

Stop without widening or claiming readiness if:

- repository or Phase G baseline drifts;
- a ninth repository file or eighth successor file is needed;
- production source appears to require change;
- the privacy contract cannot be tested structurally without weakening it;
- any canonicalization requires generic number/path/hex/UUID scrubbing;
- logical_bytes cannot be confined to its exact typed producer and bound;
- any unclassified final/fresh diagnostic remains;
- final/fresh lifecycle or canonical semantics differ;
- the deliberate mutant cannot be independently qualified as its declared
  source;
- qualification cannot be independently recomputed and bound;
- full spec and logical suite identity cannot both be retained;
- an expected-different pair has unknown output or an undeclared delta;
- final/fresh does not exit 0;
- any late fault leaves AcceptedEqual=true;
- successor A/B binaries differ;
- product A/B C/T/D/E differs;
- a required positive skips or fails;
- containment, resource cleanup, terminal reconciliation or zero-observation
  fails;
- evidence manifest cannot be the final mutation;
- any public/product schema, T1 behavior, authority, module graph, installation,
  live route, network, T2A-I or T2B effect would be required.

Closeout verdict

Return:

REPAIR10H_IMPLEMENTED_PHASE_H_SEALED_READY_FOR_INTEGRATED_SNAPSHOT_AND_FRESH_AUDIT

only if every required gate passes.

Otherwise return a precise blocking verdict, preserve all failed evidence, leave
Phase G untouched, and do not claim semantic restoration.

Final report must include:

- opening and closing repository/Phase G identities;
- exact repository and successor touched files;
- final repository inventory and T;
- product production-byte equality;
- privacy-test implementation and causal results;
- complete implemented diagnostic taxonomy;
- logical_bytes result;
- successor source/tree and A/B binary identities;
- qualification and comparison schema identities;
- logical suite fingerprints;
- five comparison outcomes and reason codes;
- exact mutant delta;
- baseline directional regression results;
- product C/T/D/E A/B results;
- validation commands/results and all failed/superseded attempts;
- evidence manifest identity and post-seal verification;
- remaining limitations and nonclaims.

End with:

INDEPENDENT_AUDIT_NOT_PERFORMED
INTEGRATED_SNAPSHOT_NOT_CREATED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
INSTALLATION_NOT_PERFORMED
LIVE_ROUTE_NOT_INVOKED
REMOTE_CONTACT_NOT_PERFORMED
```

The project workflow requires parent-only implementation after reconnaissance and a later fresh read-only audit after any changed bytes.  

**Sources:** Codex’s attached Repair 10H reconnaissance, especially its baseline, exhaustive difference taxonomy, qualification contract, scope freeze, validation matrix, and stop conditions.    

**Confidence:** 0.99 that reconnaissance is complete enough for implementation; 0.94 that the four refinements above close the remaining design ambiguity; 0.88 that Repair 10H can complete without changing production runtime bytes.
